"""Tree evaluator."""
import copy
from collections.abc import Mapping

from .functions import Expref, Functions, is_cmp_number, is_number, json_eq

_DEFAULT_FUNCS = Functions()


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, (str, list)) and len(v) == 0:
        return True
    if isinstance(v, Mapping) and len(v) == 0:
        return True
    return False


def _slice(arr, start, stop, step):
    n = len(arr)
    if step is None:
        step = 1
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = max(0, min(n, s))
        e = max(0, min(n, e))
        return [arr[i] for i in range(s, e, step)]
    s = n - 1 if start is None else (start + n if start < 0 else start)
    e = -1 if stop is None else (stop + n if stop < 0 else stop)
    s = max(-1, min(n - 1, s))
    e = max(-1, min(n - 1, e))
    return [arr[i] for i in range(s, e, step)]


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) or dict
        self.funcs = getattr(options, "custom_functions", None) or _DEFAULT_FUNCS

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_identity(self, node, value):
        return value

    v_current = v_identity

    def v_field(self, node, value):
        if isinstance(value, Mapping):
            try:
                return value.get(node[1])
            except Exception:
                return None
        return None

    def v_literal(self, node, value):
        return copy.deepcopy(node[1])

    def v_sub(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_pipe(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_index(self, node, value):
        if not isinstance(value, list):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if not isinstance(value, list):
            return None
        return _slice(value, node[1], node[2], node[3])

    def v_flatten(self, node, value):
        v = self.visit(node[1], value)
        if not isinstance(v, list):
            return None
        out = []
        for x in v:
            if isinstance(x, list):
                out.extend(x)
            else:
                out.append(x)
        return out

    def _collect(self, items, rhs):
        out = []
        for x in items:
            r = self.visit(rhs, x)
            if r is not None:
                out.append(r)
        return out

    def v_proj(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, list):
            return None
        return self._collect(base, node[2])

    def v_valproj(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, Mapping):
            return None
        return self._collect(list(base.values()), node[2])

    def v_filter(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, list):
            return None
        kept = [x for x in base if not is_false(self.visit(node[2], x))]
        return self._collect(kept, node[3])

    def v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def v_or(self, node, value):
        l = self.visit(node[1], value)
        return self.visit(node[2], value) if is_false(l) else l

    def v_and(self, node, value):
        l = self.visit(node[1], value)
        return l if is_false(l) else self.visit(node[2], value)

    def v_cmp(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return json_eq(a, b)
        if op == "ne":
            return not json_eq(a, b)
        if isinstance(a, bool) or isinstance(b, bool):
            return None
        if (is_cmp_number(a) and is_cmp_number(b)) or \
                (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def v_mlist(self, node, value):
        if value is None:
            return None
        return [self.visit(n, value) for n in node[1]]

    def v_mhash(self, node, value):
        if value is None:
            return None
        out = self.dict_cls()
        for k, n in node[1]:
            out[k] = self.visit(n, value)
        return out

    def v_expref(self, node, value):
        return Expref(node[1], self)

    def v_func(self, node, value):
        name, args = node[1], node[2]
        funcs = self.funcs
        if not hasattr(funcs, "invoke"):
            funcs = _DEFAULT_FUNCS
        return funcs.invoke(name, len(args),
                            lambda: [self.visit(a, value) for a in args])
