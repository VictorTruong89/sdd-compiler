"""Lexer and Pratt parser producing a tuple-based AST."""
import json
import re

from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         LexerError, PathSelSyntaxError, ZeroSliceStepError)

WS = " \t\n\r"
_IDSTART = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDCHARS = _IDSTART | set("0123456789")
_DIGITS = set("0123456789")
_U_RE = re.compile(r"\\u([0-9a-fA-F]{4})")

BP = {
    "eof": 0, "id": 0, "qid": 0, "literal": 0, "raw": 0, "rbracket": 0,
    "rparen": 0, "comma": 0, "rbrace": 0, "number": 0, "current": 0,
    "expref": 0, "colon": 0, "lparen": 0, "lbrace": 0,
    "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "ne": 5, "lt": 5, "lte": 5, "gt": 5, "gte": 5,
    "flatten": 9, "star": 20, "filter": 21, "dot": 40, "not": 45,
    "lbracket": 55,
}
COMPARATORS = ("eq", "ne", "lt", "lte", "gt", "gte")


def _decode_raw(s):
    s = s.replace("\\'", "'")

    def rep(m):
        return chr(int(m.group(1), 16))
    out = _U_RE.sub(rep, s)
    # combine surrogate pairs if any
    try:
        out.encode("utf-16", "surrogatepass").decode("utf-16")
        out = out.encode("utf-16", "surrogatepass").decode("utf-16", "surrogatepass")
    except Exception:
        pass
    return out


def tokenize(text):
    toks = []  # (type, value, pos)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c in WS:
            i += 1
        elif c in _IDSTART:
            j = i + 1
            while j < n and text[j] in _IDCHARS:
                j += 1
            toks.append(("id", text[i:j], i))
            i = j
        elif c == "-" or c in _DIGITS:
            j = i + 1 if c == "-" else i
            k = j
            while k < n and text[k] in _DIGITS:
                k += 1
            if k == j:
                raise LexerError("unexpected '-'", i)
            toks.append(("number", int(text[i:k]), i))
            i = k
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            if j >= n:
                raise LexerError("unterminated quoted identifier", i)
            try:
                val = json.loads(text[i:j + 1])
            except ValueError:
                raise LexerError("invalid quoted identifier", i)
            toks.append(("qid", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and text[j] != "'":
                j += 2 if text[j] == "\\" and j + 1 < n and text[j + 1] == "'" else 1
            if j >= n:
                raise LexerError("unterminated raw string", i)
            toks.append(("raw", _decode_raw(text[i + 1:j]), i))
            i = j + 1
        elif c == "`":
            j = i + 1
            while j < n and text[j] != "`":
                j += 2 if text[j] == "\\" and j + 1 < n and text[j + 1] == "`" else 1
            if j >= n:
                raise LexerError("unterminated literal", i)
            lex = text[i + 1:j].replace("\\`", "`")
            try:
                val = json.loads(lex)
            except ValueError:
                try:
                    val = json.loads('"%s"' % lex.lstrip())
                except ValueError:
                    raise LexerError("invalid literal", i)
            toks.append(("literal", val, i))
            i = j + 1
        elif c == "[":
            j = i + 1
            while j < n and text[j] in WS:
                j += 1
            if j < n and text[j] == "]":
                toks.append(("flatten", "[]", i))
                i = j + 1
            elif j < n and text[j] == "?":
                toks.append(("filter", "[?", i))
                i = j + 1
            else:
                toks.append(("lbracket", "[", i))
                i += 1
        elif c == "|":
            if text[i + 1:i + 2] == "|":
                toks.append(("or", "||", i)); i += 2
            else:
                toks.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if text[i + 1:i + 2] == "&":
                toks.append(("and", "&&", i)); i += 2
            else:
                toks.append(("expref", "&", i)); i += 1
        elif c in "<>!":
            name = {"<": "lt", ">": "gt", "!": "not"}[c]
            if text[i + 1:i + 2] == "=":
                name = {"lt": "lte", "gt": "gte", "not": "ne"}[name]
                toks.append((name, c + "=", i)); i += 2
            else:
                toks.append((name, c, i)); i += 1
        elif c == "=":
            if text[i + 1:i + 2] == "=":
                toks.append(("eq", "==", i)); i += 2
            else:
                raise LexerError("unexpected '='", i)
        elif c in "]{}(),:.*@":
            name = {"]": "rbracket", "{": "lbrace", "}": "rbrace",
                    "(": "lparen", ")": "rparen", ",": "comma", ":": "colon",
                    ".": "dot", "*": "star", "@": "current"}[c]
            toks.append((name, c, i)); i += 1
        else:
            raise LexerError("unexpected character %r" % c, i)
    toks.append(("eof", None, n))
    return toks


IDENT = ("identity",)


class Parser:
    def __init__(self, text):
        self.text = text
        self.toks = tokenize(text)
        self.i = 0

    # helpers
    def cur(self):
        return self.toks[self.i][0]

    def la(self, k=1):
        j = min(self.i + k, len(self.toks) - 1)
        return self.toks[j][0]

    def adv(self):
        t = self.toks[self.i]
        if t[0] != "eof":
            self.i += 1
        return t

    def fail(self, force_syntax=False):
        t = self.toks[self.i]
        if t[0] == "eof" and not force_syntax:
            raise IncompleteExpressionError("unexpected end of expression", t[2])
        raise PathSelSyntaxError("unexpected token %r" % (t[1],), t[2])

    def match(self, typ):
        if self.cur() != typ:
            self.fail()
        return self.adv()

    # entry
    def parse(self):
        if self.text == "":
            raise EmptyExpressionError("empty expression")
        node = self.expr(0)
        if self.cur() != "eof":
            self.fail()
        return node

    def expr(self, bp):
        t = self.adv()
        left = self.nud(t)
        while bp < BP[self.cur()]:
            left = self.led(self.adv(), left)
        return left

    def nud(self, t):
        typ, val, pos = t
        if typ == "id":
            if self.cur() == "lparen":
                return self.function(val)
            return ("field", val)
        if typ == "qid":
            return ("field", val)
        if typ == "literal":
            return ("literal", val)
        if typ == "raw":
            return ("literal", val)
        if typ == "current":
            return ("current",)
        if typ == "star":
            return ("valproj", IDENT, self.proj_rhs(20))
        if typ == "filter":
            return self.filter(IDENT)
        if typ == "flatten":
            return ("proj", ("flatten", IDENT), self.proj_rhs(9))
        if typ == "lbracket":
            c = self.cur()
            if c in ("number", "colon"):
                return self.index_or_slice(IDENT)
            if c == "star" and self.la() == "rbracket":
                self.adv(); self.adv()
                return ("proj", IDENT, self.proj_rhs(20))
            return self.multilist()
        if typ == "lbrace":
            return self.multihash()
        if typ == "lparen":
            e = self.expr(0)
            self.match("rparen")
            return e
        if typ == "not":
            return ("not", self.expr(45))
        if typ == "expref":
            return ("expref", self.expr(0))
        self.i -= 0 if typ == "eof" else 1
        self.fail()

    def led(self, t, left):
        typ = t[0]
        if typ == "dot":
            c = self.cur()
            if c in ("id", "qid", "star"):
                return ("sub", left, self.expr(40))
            if c == "lbracket":
                self.adv()
                return ("sub", left, self.multilist())
            if c == "lbrace":
                self.adv()
                return ("sub", left, self.multihash())
            self.fail(force_syntax=True)
        if typ == "pipe":
            return ("pipe", left, self.expr(1))
        if typ == "or":
            return ("or", left, self.expr(2))
        if typ == "and":
            return ("and", left, self.expr(3))
        if typ in COMPARATORS:
            return ("cmp", typ, left, self.expr(5))
        if typ == "flatten":
            return ("proj", ("flatten", left), self.proj_rhs(9))
        if typ == "filter":
            return self.filter(left)
        if typ == "lbracket":
            c = self.cur()
            if c in ("number", "colon"):
                return self.index_or_slice(left)
            if c == "star":
                self.adv()
                self.match("rbracket")
                return ("proj", left, self.proj_rhs(20))
            self.fail()
        self.i -= 1
        self.fail()

    def proj_rhs(self, bp):
        c = self.cur()
        if BP[c] < 10:
            return IDENT
        if c in ("lbracket", "filter"):
            return self.expr(bp)
        if c == "dot":
            self.adv()
            c = self.cur()
            if c in ("id", "qid", "star"):
                return self.expr(bp)
            if c == "lbracket":
                self.adv()
                return self.multilist()
            if c == "lbrace":
                self.adv()
                return self.multihash()
            self.fail(force_syntax=True)
        self.fail()

    def filter(self, left):
        cond = self.expr(0)
        self.match("rbracket")
        return ("filter", left, cond, self.proj_rhs(21))

    def index_or_slice(self, left):
        parts = [None]
        colons = 0
        # current token is number or colon
        while True:
            c = self.cur()
            if c == "number":
                if parts[-1] is not None:
                    self.fail()
                parts[-1] = self.adv()[1]
            elif c == "colon":
                colons += 1
                if colons > 2:
                    self.fail()
                self.adv()
                parts.append(None)
            elif c == "rbracket":
                self.adv()
                break
            else:
                self.fail()
        if colons == 0:
            return ("sub", left, ("index", parts[0]))
        start, stop = parts[0], parts[1]
        step = parts[2] if len(parts) > 2 else None
        if step == 0:
            raise ZeroSliceStepError("slice step cannot be zero")
        return ("proj", ("sub", left, ("slice", start, stop, step)),
                self.proj_rhs(20))

    def multilist(self):
        items = []
        while True:
            items.append(self.expr(0))
            if self.cur() == "comma":
                self.adv()
                continue
            self.match("rbracket")
            break
        return ("mlist", items)

    def multihash(self):
        pairs = []
        while True:
            c = self.cur()
            if c not in ("id", "qid"):
                self.fail()
            key = self.adv()[1]
            self.match("colon")
            pairs.append((key, self.expr(0)))
            if self.cur() == "comma":
                self.adv()
                continue
            self.match("rbrace")
            break
        return ("mhash", pairs)

    def function(self, name):
        self.adv()  # lparen
        args = []
        if self.cur() == "rparen":
            self.adv()
            return ("func", name, args)
        while True:
            args.append(self.expr(0))
            if self.cur() == "comma":
                self.adv()
                continue
            self.match("rparen")
            break
        return ("func", name, args)


def parse(text):
    return Parser(text).parse()
