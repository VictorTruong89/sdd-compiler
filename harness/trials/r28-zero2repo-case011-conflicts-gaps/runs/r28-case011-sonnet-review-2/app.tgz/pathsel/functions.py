"""Function provider: built-in functions and the ``signature`` decorator."""
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import ArityError, InvalidTypeError, UnknownFunctionError


class Expref:
    """Deferred expression reference."""

    def __init__(self, node, interpreter):
        self.node = node
        self.interpreter = interpreter

    def __call__(self, value):
        return self.interpreter.visit(self.node, value)

    def __repr__(self):
        return "<expref>"


def is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_cmp_number(v):
    return is_number(v) or isinstance(v, Decimal)


def json_eq(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_cmp_number(a) and is_cmp_number(b):
        return a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(json_eq(x, y) for x, y in zip(a, b))
    if isinstance(a, Mapping) and isinstance(b, Mapping):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_eq(a[k], b[k]):
                return False
        return True
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (list, Mapping)) or isinstance(b, (list, Mapping)):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


def _check(value, name):
    if name == "number":
        return is_number(value)
    if name == "string":
        return isinstance(value, str)
    if name == "array":
        return isinstance(value, list)
    if name == "object":
        return isinstance(value, Mapping)
    if name == "null":
        return value is None
    if name == "boolean":
        return isinstance(value, bool)
    if name == "any":
        return not isinstance(value, Expref)
    if name == "expref":
        return isinstance(value, Expref)
    if name == "array-number":
        return isinstance(value, list) and all(is_number(x) for x in value)
    if name == "array-string":
        return isinstance(value, list) and all(isinstance(x, str) for x in value)
    return False


def signature(*arguments):
    def decorator(func):
        func._signature = list(arguments)
        return func
    return decorator


def _sig(*types, variadic=False):
    d = {"types": list(types)}
    if variadic:
        d["variadic"] = True
    return d


def _key_check(keys):
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise InvalidTypeError("sort key must be all numbers or all strings")


class Functions:
    def call(self, name, args_nodes_count, evaluate_args):
        raise NotImplementedError  # pragma: no cover

    # ---- dispatch used by the interpreter ----
    def _lookup(self, name):
        fn = getattr(self, "_func_" + name, None)
        if fn is None or not hasattr(fn, "_signature"):
            raise UnknownFunctionError("unknown function: %s" % name)
        return fn

    def invoke(self, name, nargs, eval_args):
        fn = self._lookup(name)
        sig = fn._signature
        variadic = bool(sig) and bool(sig[-1].get("variadic"))
        if variadic:
            if nargs < len(sig):
                raise ArityError("%s expects at least %d arguments" % (name, len(sig)))
        elif nargs != len(sig):
            raise ArityError("%s expects %d arguments, got %d" % (name, len(sig), nargs))
        args = eval_args()
        for i, a in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not any(_check(a, t) for t in spec["types"]):
                raise InvalidTypeError("invalid argument %d type for %s" % (i + 1, name))
        return fn(*args)

    # ---- built-ins ----
    @signature(_sig("number"))
    def _func_abs(self, v):
        return abs(v)

    @signature(_sig("array-number"))
    def _func_avg(self, v):
        return sum(v) / len(v) if v else None

    @signature(_sig("number"))
    def _func_ceil(self, v):
        return math.ceil(v)

    @signature(_sig("number"))
    def _func_floor(self, v):
        return math.floor(v)

    @signature(_sig("array", "string"), _sig("any"))
    def _func_contains(self, subject, item):
        if isinstance(subject, str):
            return isinstance(item, str) and item in subject
        return any(json_eq(x, item) for x in subject)

    @signature(_sig("string"), _sig("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_sig("string"), _sig("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_sig("string", "array", "object"))
    def _func_length(self, v):
        return len(v)

    @signature(_sig("array", "string"))
    def _func_reverse(self, v):
        return v[::-1]

    @signature(_sig("string"), _sig("array-string"))
    def _func_join(self, sep, arr):
        return sep.join(arr)

    @signature(_sig("object"))
    def _func_keys(self, o):
        return list(o.keys())

    @signature(_sig("object"))
    def _func_values(self, o):
        return list(o.values())

    @signature(_sig("any"))
    def _func_type(self, v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "boolean"
        if is_number(v):
            return "number"
        if isinstance(v, str):
            return "string"
        if isinstance(v, list):
            return "array"
        if isinstance(v, Mapping):
            return "object"
        return "null"

    @signature(_sig("any"))
    def _func_to_array(self, v):
        return v if isinstance(v, list) else [v]

    @signature(_sig("any"))
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return json.dumps(v, separators=(",", ":"), ensure_ascii=True, default=str)

    @signature(_sig("any"))
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if re.fullmatch(r"[+-]?[0-9]+", v):
                return int(v)
            if re.fullmatch(r"[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?", v):
                try:
                    return float(v)
                except ValueError:
                    return None
        return None

    @signature(_sig("array-number", "array-string"))
    def _func_max(self, v):
        return max(v) if v else None

    @signature(_sig("array-number", "array-string"))
    def _func_min(self, v):
        return min(v) if v else None

    @signature(_sig("array-number", "array-string"))
    def _func_sort(self, v):
        return sorted(v)

    @signature(_sig("array-number"))
    def _func_sum(self, v):
        return sum(v)

    @signature(_sig("object"), _sig("object", variadic=True))
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in o:
                out[k] = o[k]
        return out

    @signature(_sig("any"), _sig("any", variadic=True))
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_sig("expref"), _sig("array"))
    def _func_map(self, ref, arr):
        return [ref(x) for x in arr]

    @signature(_sig("array"), _sig("expref"))
    def _func_sort_by(self, arr, ref):
        keyed = [(ref(x), x) for x in arr]
        _key_check([k for k, _ in keyed])
        return [x for _, x in sorted(keyed, key=lambda p: p[0])]

    @signature(_sig("array"), _sig("expref"))
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature(_sig("array"), _sig("expref"))
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]
