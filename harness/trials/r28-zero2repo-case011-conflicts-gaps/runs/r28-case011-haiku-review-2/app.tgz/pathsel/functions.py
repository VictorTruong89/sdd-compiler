"""Built-in PathSel functions, the ``signature`` decorator, and provider lookup.

A provider is an instance of :class:`Functions` (or a subclass). Every attribute named
``_func_<name>`` that passed through :func:`signature` defines the language function ``<name>``.
The built-in set is the set of such attributes on :class:`Functions` itself.
"""

import json
import math
import re

from .errors import InvalidTypeError, UnknownFunctionError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    is_numeric,
    is_object,
    json_equal,
)

_FUNC_PREFIX = "_func_"

# Type names accepted in a signature. "any" accepts every value; "expref" requires an expression reference.
KNOWN_TYPES = frozenset({"any", "number", "string", "boolean", "array", "object", "null", "expref"})


def signature(*arguments):
    """Declare the parameter types of a function implementation.

    Each argument is a mapping ``{"types": [...]}``, one per parameter, in call order. A parameter
    accepts a value that matches any listed type name. An optional ``"variadic": True`` on the last
    parameter means one or more arguments of that type. The decorator does not call the function.
    """
    specs = []
    variadic = False
    for argument in arguments:
        if not isinstance(argument, dict) or "types" not in argument:
            raise TypeError('signature arguments must be mappings of the form {"types": [...]}')
        names = tuple(argument["types"])
        if not names or any(name not in KNOWN_TYPES for name in names):
            raise TypeError("unknown type name in signature: %r" % (names,))
        specs.append(names)
        if argument.get("variadic"):
            variadic = True
    spec_tuple = tuple(specs)

    def decorate(implementation):
        implementation._pathsel_types = spec_tuple
        implementation._pathsel_variadic = variadic
        return implementation

    return decorate


def _require_all(items, check, what):
    for item in items:
        if not check(item):
            raise InvalidTypeError("expected an array of %s" % what)


def _require_orderable(items):
    """Every item a number, or every item a string (an empty sequence passes)."""
    if all(is_number(item) for item in items):
        return
    if all(isinstance(item, str) for item in items):
        return
    raise InvalidTypeError("expected every element to be a number, or every element to be a string")


_INT_RE = re.compile(r"-?[0-9]+")
_FLOAT_RE = re.compile(r"-?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _dump_json(value):
    """Compact JSON text: no spaces, ASCII-only escapes, numbers as the host writes them."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return json.dumps(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=True)
    if is_array(value):
        return "[" + ",".join(_dump_json(item) for item in value) + "]"
    if is_object(value):
        parts = []
        for key in value.keys():
            parts.append(json.dumps(str(key), ensure_ascii=True) + ":" + _dump_json(value[key]))
        return "{" + ",".join(parts) + "}"
    if is_numeric(value):  # host Decimal
        return str(value)
    return json.dumps(str(value), ensure_ascii=True)


def _type_name(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if is_numeric(value):
        return "number"
    if isinstance(value, str):
        return "string"
    if is_array(value):
        return "array"
    if is_object(value):
        return "object"
    return None  # a host value that is not one of the six JSON types


class Functions:
    """The built-in function provider. Subclass it and decorate ``_func_<name>`` methods to add functions."""

    # ----- numbers -----

    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array"]})
    def _func_avg(self, values):
        _require_all(values, is_number, "numbers")
        if not values:
            return None
        return sum(values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return math.ceil(value)

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return math.floor(value)

    @signature({"types": ["array"]})
    def _func_sum(self, values):
        _require_all(values, is_number, "numbers")
        return sum(values)

    # ----- strings and arrays -----

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, haystack, needle):
        if is_array(haystack):
            return any(json_equal(item, needle) for item in haystack)
        if not isinstance(needle, str):
            raise InvalidTypeError("contains on a string requires a string second argument")
        return needle in haystack

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        if isinstance(value, str):
            return len(value)
        if is_array(value):
            return len(value)
        return len(list(value.keys()))

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, glue, values):
        _require_all(values, lambda item: isinstance(item, str), "strings")
        return glue.join(values)

    # ----- objects -----

    @signature({"types": ["object"]})
    def _func_keys(self, obj):
        return list(obj.keys())

    @signature({"types": ["object"]})
    def _func_values(self, obj):
        return [obj[key] for key in obj.keys()]

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objects):
        merged = {}
        for obj in objects:
            for key in obj.keys():
                merged[key] = obj[key]
        return merged

    # ----- conversion and inspection -----

    @signature({"types": ["any"]})
    def _func_type(self, value):
        return _type_name(value)

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if isinstance(value, list):
            return value
        if is_array(value):
            return list(value)
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return _dump_json(value)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if isinstance(value, bool):
            return None
        if is_numeric(value):
            return value
        if isinstance(value, str):
            if _INT_RE.fullmatch(value):
                return int(value)
            if _FLOAT_RE.fullmatch(value):
                return float(value)
        return None

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    # ----- ordering and selection -----

    @signature({"types": ["array"]})
    def _func_max(self, values):
        _require_orderable(values)
        return max(values) if values else None

    @signature({"types": ["array"]})
    def _func_min(self, values):
        _require_orderable(values)
        return min(values) if values else None

    @signature({"types": ["array"]})
    def _func_sort(self, values):
        _require_orderable(values)
        return sorted(values)

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, reference, values):
        return [reference(item) for item in values]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, values, reference):
        keys = [reference(item) for item in values]
        _require_orderable(keys)
        order = sorted(range(len(values)), key=lambda index: keys[index])
        return [values[index] for index in order]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, values, reference):
        if not values:
            return None
        keys = [reference(item) for item in values]
        _require_orderable(keys)
        best = 0
        for index in range(1, len(values)):
            if keys[index] > keys[best]:
                best = index
        return values[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, values, reference):
        if not values:
            return None
        keys = [reference(item) for item in values]
        _require_orderable(keys)
        best = 0
        for index in range(1, len(values)):
            if keys[index] < keys[best]:
                best = index
        return values[best]


BUILTIN_PROVIDER = Functions()
BUILTIN_NAMES = frozenset(
    name[len(_FUNC_PREFIX):] for name in dir(Functions) if name.startswith(_FUNC_PREFIX)
)


def resolve_function(name, provider):
    """Return the bound implementation for a function name, or raise UnknownFunctionError.

    Built-in names resolve to the built-in implementation first, so a provider cannot change
    their behavior. Other names resolve to a signature-decorated attribute of the provider.
    """
    if name in BUILTIN_NAMES:
        return getattr(BUILTIN_PROVIDER, _FUNC_PREFIX + name)
    if provider is not None:
        implementation = getattr(provider, _FUNC_PREFIX + name, None)
        if implementation is not None and hasattr(implementation, "_pathsel_types"):
            return implementation
    raise UnknownFunctionError("unknown function: %s" % name)


__all__ = ["Functions", "signature", "ExpressionReference", "resolve_function", "BUILTIN_NAMES"]
