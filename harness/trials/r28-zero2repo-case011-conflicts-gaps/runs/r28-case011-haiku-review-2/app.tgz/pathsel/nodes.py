"""Expression tree nodes. Each node knows how to evaluate itself against a current value."""

import copy
import operator

from .errors import InvalidArityError, InvalidTypeError, ZeroSliceStepError
from .functions import resolve_function
from .values import (
    ExpressionReference,
    is_array,
    is_numeric,
    is_object,
    is_truthy,
    json_equal,
    matches_type,
)


class Context:
    """Per-search evaluation state derived from the optional evaluation options."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, options):
        self.dict_cls = None
        self.provider = None
        if options is not None:
            self.dict_cls = getattr(options, "dict_cls", None)
            self.provider = getattr(options, "custom_functions", None)

    def new_object(self):
        if self.dict_cls is not None:
            return self.dict_cls()
        return {}


class Node:
    def evaluate(self, ctx, cur):
        raise NotImplementedError


class Identity(Node):
    def evaluate(self, ctx, cur):
        return cur


class Literal(Node):
    def __init__(self, value):
        self.value = value

    def evaluate(self, ctx, cur):
        return copy.deepcopy(self.value)


class Field(Node):
    def __init__(self, name):
        self.name = name

    def evaluate(self, ctx, cur):
        if not is_object(cur):
            return None
        try:
            return cur[self.name]
        except KeyError:
            return None


class Subexpression(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, ctx, cur):
        return self.right.evaluate(ctx, self.left.evaluate(ctx, cur))


class Index(Node):
    def __init__(self, source, index):
        self.source = source
        self.index = index

    def evaluate(self, ctx, cur):
        value = self.source.evaluate(ctx, cur)
        if not is_array(value):
            return None
        size = len(value)
        index = self.index + size if self.index < 0 else self.index
        if 0 <= index < size:
            return value[index]
        return None


def _slice_indices(size, start, stop, step):
    if step > 0:
        lower, upper = 0, size
        start_default, stop_default = 0, size
    else:
        lower, upper = -1, size - 1
        start_default, stop_default = size - 1, -1

    def normalize(value, default):
        if value is None:
            return default
        if value < 0:
            value += size
        return min(max(value, lower), upper)

    begin = normalize(start, start_default)
    end = normalize(stop, stop_default)
    indices = []
    index = begin
    if step > 0:
        while index < end:
            indices.append(index)
            index += step
    else:
        while index > end:
            indices.append(index)
            index += step
    return indices


class Slice(Node):
    def __init__(self, source, start, stop, step):
        self.source = source
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, ctx, cur):
        step = 1 if self.step is None else self.step
        if step == 0:
            raise ZeroSliceStepError("slice step must not be zero")
        value = self.source.evaluate(ctx, cur)
        if not is_array(value):
            return None
        return [value[i] for i in _slice_indices(len(value), self.start, self.stop, step)]


class Flatten(Node):
    def __init__(self, source):
        self.source = source

    def evaluate(self, ctx, cur):
        value = self.source.evaluate(ctx, cur)
        if not is_array(value):
            return None
        flat = []
        for item in value:
            if is_array(item):
                flat.extend(item)
            else:
                flat.append(item)
        return flat


def _collect(ctx, items, right):
    out = []
    for item in items:
        result = right.evaluate(ctx, item)
        if result is not None:
            out.append(result)
    return out


class Projection(Node):
    """Applies ``right`` to each element of an array and collects the non-null results."""

    def __init__(self, source, right):
        self.source = source
        self.right = right

    def evaluate(self, ctx, cur):
        value = self.source.evaluate(ctx, cur)
        if not is_array(value):
            return None
        return _collect(ctx, value, self.right)


class ObjectProjection(Node):
    """Applies ``right`` to each value of an object and collects the non-null results."""

    def __init__(self, source, right):
        self.source = source
        self.right = right

    def evaluate(self, ctx, cur):
        value = self.source.evaluate(ctx, cur)
        if not is_object(value):
            return None
        return _collect(ctx, [value[key] for key in value.keys()], self.right)


class FilterProjection(Node):
    def __init__(self, source, predicate, right):
        self.source = source
        self.predicate = predicate
        self.right = right

    def evaluate(self, ctx, cur):
        value = self.source.evaluate(ctx, cur)
        if not is_array(value):
            return None
        kept = [item for item in value if is_truthy(self.predicate.evaluate(ctx, item))]
        return _collect(ctx, kept, self.right)


class MultiList(Node):
    def __init__(self, items):
        self.items = items

    def evaluate(self, ctx, cur):
        if cur is None:
            return None
        return [item.evaluate(ctx, cur) for item in self.items]


class MultiHash(Node):
    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, ctx, cur):
        if cur is None:
            return None
        obj = ctx.new_object()
        for key, expr in self.pairs:
            obj[key] = expr.evaluate(ctx, cur)
        return obj


class Pipe(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, ctx, cur):
        return self.right.evaluate(ctx, self.left.evaluate(ctx, cur))


_ORDER_OPS = {
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
}


class Comparison(Node):
    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, ctx, cur):
        a = self.left.evaluate(ctx, cur)
        b = self.right.evaluate(ctx, cur)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        comparable = (is_numeric(a) and is_numeric(b)) or (isinstance(a, str) and isinstance(b, str))
        if not comparable:
            return None
        return _ORDER_OPS[self.op](a, b)


class And(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, ctx, cur):
        a = self.left.evaluate(ctx, cur)
        if not is_truthy(a):
            return a
        return self.right.evaluate(ctx, cur)


class Or(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, ctx, cur):
        a = self.left.evaluate(ctx, cur)
        if is_truthy(a):
            return a
        return self.right.evaluate(ctx, cur)


class Not(Node):
    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, ctx, cur):
        return not is_truthy(self.operand.evaluate(ctx, cur))


class ExpressionRef(Node):
    """``&expr``: a deferred expression. Its value is a reference that functions apply later."""

    def __init__(self, expr):
        self.expr = expr

    def evaluate(self, ctx, cur):
        expr = self.expr
        return ExpressionReference(lambda value: expr.evaluate(ctx, value))


class FunctionCall(Node):
    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, ctx, cur):
        implementation = resolve_function(self.name, ctx.provider)
        specs = implementation._pathsel_types
        variadic = implementation._pathsel_variadic
        count = len(self.args)
        if variadic:
            if count < len(specs):
                raise InvalidArityError("%s takes one or more arguments" % self.name)
        elif count != len(specs):
            raise InvalidArityError("%s takes %d argument(s), got %d" % (self.name, len(specs), count))

        values = []
        for index, arg in enumerate(self.args):
            value = arg.evaluate(ctx, cur)
            allowed = specs[index] if index < len(specs) else specs[-1]
            if not any(matches_type(value, type_name) for type_name in allowed):
                raise InvalidTypeError("argument %d of %s has the wrong type" % (index + 1, self.name))
            values.append(value)
        return implementation(*values)
