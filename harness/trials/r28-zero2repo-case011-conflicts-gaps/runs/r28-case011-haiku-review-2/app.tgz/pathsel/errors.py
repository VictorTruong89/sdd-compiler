"""Refusal kinds raised by pathsel.

Every refusal is a ``ValueError``. The kind is carried by the exception type.
Syntax and incomplete-expression refusals also carry ``lex_position``, the
zero-based character offset where the failure was detected.
"""


class PathSelError(ValueError):
    """Base class of every refusal. Not raised directly."""

    def __init__(self, message, lex_position=None):
        super().__init__(message)
        self.lex_position = lex_position


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing bracket/brace/parenthesis is still required."""


class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure."""


class TokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is zero."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor supplied by the attached provider."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
