"""Value model helpers: JSON type tests, truthiness, equality, and expression references."""

from collections.abc import Mapping
from decimal import Decimal


class ExpressionReference:
    """A deferred expression (written ``&expr``). Calling it applies the expression to one value."""

    __slots__ = ("_evaluate",)

    def __init__(self, evaluate):
        self._evaluate = evaluate

    def __call__(self, value):
        return self._evaluate(value)

    def __repr__(self):
        return "<pathsel expression reference>"


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    """A mapping: an ordinary Mapping, or any object with the mapping protocol (e.g. a caller's dict_cls)."""
    if isinstance(value, Mapping):
        return True
    if isinstance(value, (str, bytes, list, tuple)):
        return False
    return callable(getattr(value, "keys", None)) and hasattr(value, "__getitem__")


def is_number(value):
    """A JSON number: int or float, never a boolean."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_numeric(value):
    """A number for comparison purposes: a JSON number or a host Decimal."""
    return is_number(value) or isinstance(value, Decimal)


def is_truthy(value):
    """True for every value except the false values: false, null, "", [], and empty objects."""
    if value is None or value is False:
        return False
    if isinstance(value, (str, list, tuple)):
        return len(value) > 0
    if is_object(value):
        try:
            return len(value) > 0
        except TypeError:
            return True
    return True


def matches_type(value, type_name):
    """Whether ``value`` satisfies one signature type name."""
    if type_name == "any":
        return True
    if type_name == "number":
        return is_number(value)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "boolean":
        return isinstance(value, bool)
    if type_name == "array":
        return is_array(value)
    if type_name == "object":
        return is_object(value)
    if type_name == "null":
        return value is None
    if type_name == "expref":
        return isinstance(value, ExpressionReference)
    return False


def _kind(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "bool"
    if is_numeric(value):
        return "num"
    if isinstance(value, str):
        return "str"
    if is_array(value):
        return "arr"
    if is_object(value):
        return "obj"
    return "other"


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects; a boolean never equals a number."""
    kind = _kind(a)
    if kind != _kind(b):
        return False
    if kind == "null":
        return True
    if kind in ("bool", "num", "str"):
        return a == b
    if kind == "arr":
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if kind == "obj":
        a_keys = list(a.keys())
        if len(a_keys) != len(list(b.keys())):
            return False
        for key in a_keys:
            try:
                other = b[key]
            except KeyError:
                return False
            if not json_equal(a[key], other):
                return False
        return True
    try:
        return bool(a == b)
    except Exception:  # host values with an unusable __eq__
        return False
