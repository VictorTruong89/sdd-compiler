"""Tokenizer for the PathSel language.

The lexer never raises. A token-level failure becomes an ``error`` token that carries the
exception; the parser raises it when it reaches that token, so the first failure in the text wins.
"""

import json

from .errors import TokenSyntaxError

_LETTERS = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDENT_BODY = _LETTERS | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_HEX = frozenset("0123456789abcdefABCDEF")
_WS = frozenset(" \t\n\r")

_SINGLE = {
    ".": "dot",
    "*": "star",
    "]": "rbracket",
    "(": "lparen",
    ")": "rparen",
    "{": "lbrace",
    "}": "rbrace",
    ",": "comma",
    ":": "colon",
    "@": "current",
}


class Token:
    __slots__ = ("type", "value", "pos")

    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.type, self.value, self.pos)


def _token_error(message, pos):
    return Token("error", TokenSyntaxError(message, pos), pos)


def _parse_literal(body):
    """Literal text: JSON if it is JSON, otherwise the content of a JSON string (leading whitespace dropped)."""
    try:
        return True, json.loads(body)
    except ValueError:
        pass
    try:
        return True, json.loads('"' + body.lstrip(" \t\n\r") + '"')
    except ValueError:
        return False, None


def tokenize(text):
    """Split text into tokens. The list always ends with an ``eof`` token."""
    tokens = []
    n = len(text)
    i = 0
    while i < n:
        c = text[i]
        if c in _WS:
            i += 1
            continue
        start = i

        if c in _LETTERS:
            j = i + 1
            while j < n and text[j] in _IDENT_BODY:
                j += 1
            tokens.append(Token("unquoted_identifier", text[i:j], start))
            i = j
            continue

        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1 if c == "-" else i
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token("number", int(text[i:j]), start))
            i = j
            continue

        if c == "-":
            tokens.append(_token_error("a hyphen begins no token", start))
            break

        if c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            if j >= n:
                tokens.append(_token_error("unterminated quoted identifier", start))
                break
            try:
                value = json.loads(text[i:j + 1])
            except ValueError:
                tokens.append(_token_error("quoted identifier is not a legal JSON string", start))
                break
            tokens.append(Token("quoted_identifier", value, start))
            i = j + 1
            continue

        if c == "'":
            j = i + 1
            buf = []
            closed = False
            while j < n:
                ch = text[j]
                if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                    buf.append("'")
                    j += 2
                    continue
                if ch == "\\" and j + 5 < n and text[j + 1] == "u" and all(h in _HEX for h in text[j + 2:j + 6]):
                    buf.append(chr(int(text[j + 2:j + 6], 16)))
                    j += 6
                    continue
                if ch == "'":
                    closed = True
                    j += 1
                    break
                buf.append(ch)
                j += 1
            if not closed:
                tokens.append(_token_error("unclosed raw string literal", start))
                break
            tokens.append(Token("raw_string", "".join(buf), start))
            i = j
            continue

        if c == "`":
            j = i + 1
            buf = []
            closed = False
            while j < n:
                ch = text[j]
                if ch == "\\" and j + 1 < n and text[j + 1] == "`":
                    buf.append("`")
                    j += 2
                    continue
                if ch == "`":
                    closed = True
                    j += 1
                    break
                buf.append(ch)
                j += 1
            if not closed:
                tokens.append(_token_error("unclosed JSON literal", start))
                break
            ok, value = _parse_literal("".join(buf))
            if not ok:
                tokens.append(_token_error("JSON literal is neither JSON nor JSON string content", start))
                break
            tokens.append(Token("literal", value, start))
            i = j
            continue

        if c == "[":
            j = i + 1
            while j < n and text[j] in _WS:
                j += 1
            if j < n and text[j] == "]":
                tokens.append(Token("flatten", None, start))
                i = j + 1
            elif j < n and text[j] == "?":
                tokens.append(Token("filter", None, start))
                i = j + 1
            else:
                tokens.append(Token("lbracket", None, start))
                i += 1
            continue

        if c in _SINGLE:
            tokens.append(Token(_SINGLE[c], None, start))
            i += 1
            continue

        nxt = text[i + 1] if i + 1 < n else ""
        if c == "|":
            if nxt == "|":
                tokens.append(Token("or", None, start))
                i += 2
            else:
                tokens.append(Token("pipe", None, start))
                i += 1
            continue
        if c == "&":
            if nxt == "&":
                tokens.append(Token("and", None, start))
                i += 2
            else:
                tokens.append(Token("expref", None, start))
                i += 1
            continue
        if c == "!":
            if nxt == "=":
                tokens.append(Token("ne", None, start))
                i += 2
            else:
                tokens.append(Token("not", None, start))
                i += 1
            continue
        if c == "=":
            if nxt == "=":
                tokens.append(Token("eq", None, start))
                i += 2
                continue
            tokens.append(_token_error("a lone '=' begins no token; equality is '=='", start))
            break
        if c == "<":
            if nxt == "=":
                tokens.append(Token("lte", None, start))
                i += 2
            else:
                tokens.append(Token("lt", None, start))
                i += 1
            continue
        if c == ">":
            if nxt == "=":
                tokens.append(Token("gte", None, start))
                i += 2
            else:
                tokens.append(Token("gt", None, start))
                i += 1
            continue

        tokens.append(_token_error("character %r begins no token" % c, start))
        break

    tokens.append(Token("eof", None, n))
    return tokens
