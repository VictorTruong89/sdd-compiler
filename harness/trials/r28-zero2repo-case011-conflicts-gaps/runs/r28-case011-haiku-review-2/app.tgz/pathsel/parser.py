"""Pratt parser for the PathSel language.

Binding powers (loosest to tightest): pipe 1, ``||`` 2, ``&&`` 3, comparators 5, flatten 9,
projection stop 10, filter 21, dot 40, bracket steps 55. ``!`` parses its operand with power 45,
so a dot step or a filter after ``!x`` applies to the result of ``!x``, while brackets bind to ``x``.

A projection's right-hand side is parsed with the power of the form that starts it (20 for a
list wildcard, slice, or object wildcard; 21 for a filter; 40 for a value projection after a dot;
9 for flatten). Steps that bind tighter than that power join the right-hand side.
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
)
from .lexer import tokenize
from .nodes import (
    And,
    Comparison,
    ExpressionRef,
    Field,
    FilterProjection,
    Flatten,
    FunctionCall,
    Identity,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    ObjectProjection,
    Or,
    Pipe,
    Projection,
    Slice,
    Subexpression,
)

BINDING = {
    "pipe": 1,
    "or": 2,
    "and": 3,
    "eq": 5,
    "ne": 5,
    "lt": 5,
    "lte": 5,
    "gt": 5,
    "gte": 5,
    "flatten": 9,
    "filter": 21,
    "dot": 40,
    "lbracket": 55,
}
PROJECTION_STOP = 10
NOT_BINDING = 45
WILDCARD_BINDING = 20
COMPARATORS = {"eq": "==", "ne": "!=", "lt": "<", "lte": "<=", "gt": ">", "gte": ">="}


class Parser:
    def __init__(self, text):
        self.length = len(text)
        self.tokens = tokenize(text)
        self.index = 0
        self._check_error()

    @property
    def cur(self):
        return self.tokens[self.index]

    def _check_error(self):
        token = self.tokens[self.index]
        if token.type == "error":
            raise token.value

    def advance(self):
        if self.index < len(self.tokens) - 1:
            self.index += 1
        self._check_error()

    def peek_type(self):
        if self.index + 1 < len(self.tokens):
            return self.tokens[self.index + 1].type
        return "eof"

    def _incomplete(self):
        return IncompleteExpressionError("expression is incomplete", self.length)

    def _syntax(self, token, message="syntax error"):
        if token.type == "eof":
            return PathSelSyntaxError(message, self.length)
        return PathSelSyntaxError(message, token.pos)

    def expect(self, type_):
        if self.cur.type == type_:
            self.advance()
            return
        if self.cur.type == "eof":
            raise self._incomplete()
        raise self._syntax(self.cur, "expected %s" % type_)

    # ----- Pratt core -----

    def expression(self, rbp=0):
        token = self.cur
        if token.type == "eof":
            raise self._incomplete()
        self.advance()
        left = self.nud(token)
        while rbp < BINDING.get(self.cur.type, 0):
            token = self.cur
            self.advance()
            left = self.led(token, left)
        return left

    def nud(self, token):
        kind = token.type
        if kind == "unquoted_identifier":
            if self.cur.type == "lparen":
                return self.function_call(token.value)
            return Field(token.value)
        if kind == "quoted_identifier":
            return Field(token.value)
        if kind in ("literal", "raw_string"):
            return Literal(token.value)
        if kind == "current":
            return Identity()
        if kind == "expref":
            return ExpressionRef(self.expression(0))
        if kind == "star":
            return ObjectProjection(Identity(), self.projection_rhs(WILDCARD_BINDING))
        if kind == "lbrace":
            return self.multi_hash()
        if kind == "lbracket":
            if self.cur.type in ("number", "colon", "star"):
                return self.bracket_step(Identity())
            return self.multi_list()
        if kind == "filter":
            return self.filter_rest(Identity())
        if kind == "flatten":
            return Projection(Flatten(Identity()), self.projection_rhs(9))
        if kind == "lparen":
            inner = self.expression(0)
            self.expect("rparen")
            return inner
        if kind == "not":
            return Not(self.expression(NOT_BINDING))
        raise self._syntax(token)

    def led(self, token, left):
        kind = token.type
        if kind == "dot":
            if self.cur.type == "star":
                self.advance()
                return ObjectProjection(left, self.projection_rhs(40))
            return Subexpression(left, self.dot_rhs(40))
        if kind == "pipe":
            return Pipe(left, self.expression(1))
        if kind == "or":
            return Or(left, self.expression(2))
        if kind == "and":
            return And(left, self.expression(3))
        if kind in COMPARATORS:
            return Comparison(COMPARATORS[kind], left, self.expression(5))
        if kind == "lbracket":
            return self.bracket_step(left)
        if kind == "flatten":
            return Projection(Flatten(left), self.projection_rhs(9))
        if kind == "filter":
            return self.filter_rest(left)
        raise self._syntax(token)

    # ----- pieces -----

    def function_call(self, name):
        self.advance()  # the opening parenthesis
        args = []
        if self.cur.type == "rparen":
            self.advance()
            return FunctionCall(name, args)
        while True:
            args.append(self.expression(0))
            if self.cur.type == "comma":
                self.advance()
                continue
            self.expect("rparen")
            break
        return FunctionCall(name, args)

    def filter_rest(self, source):
        predicate = self.expression(0)
        self.expect("rbracket")
        return FilterProjection(source, predicate, self.projection_rhs(21))

    def bracket_step(self, source):
        """Parse the inside of a bracket after ``[`` when the next token is a number, a colon, or a star."""
        if self.cur.type == "star":
            self.advance()
            self.expect("rbracket")
            return Projection(source, self.projection_rhs(WILDCARD_BINDING))

        parts = [None]
        if self.cur.type == "number":
            parts[0] = self.cur.value
            self.advance()
        colons = 0
        while self.cur.type == "colon":
            if len(parts) >= 3:
                raise self._syntax(self.cur, "a slice has at most three parts")
            self.advance()
            if self.cur.type == "number":
                parts.append(self.cur.value)
                self.advance()
            elif self.cur.type in ("colon", "rbracket"):
                parts.append(None)
            elif self.cur.type == "eof":
                raise self._incomplete()
            else:
                raise self._syntax(self.cur, "slice parts must be integers")
            colons += 1

        self.expect("rbracket")
        if colons == 0:
            return Index(source, parts[0])
        parts.extend([None] * (3 - len(parts)))
        return Projection(Slice(source, parts[0], parts[1], parts[2]), self.projection_rhs(WILDCARD_BINDING))

    def multi_list(self):
        items = [self.expression(0)]
        while self.cur.type == "comma":
            self.advance()
            items.append(self.expression(0))
        self.expect("rbracket")
        return MultiList(items)

    def multi_hash(self):
        pairs = []
        while True:
            token = self.cur
            if token.type not in ("unquoted_identifier", "quoted_identifier"):
                if token.type == "eof":
                    raise self._incomplete()
                raise self._syntax(token, "expected a key")
            self.advance()
            self.expect("colon")
            pairs.append((token.value, self.expression(0)))
            if self.cur.type == "comma":
                self.advance()
                continue
            self.expect("rbrace")
            break
        return MultiHash(pairs)

    def projection_rhs(self, rbp):
        kind = self.cur.type
        if BINDING.get(kind, 0) < PROJECTION_STOP:
            return Identity()
        if kind in ("lbracket", "filter"):
            return self.expression(rbp)
        if kind == "dot":
            self.advance()
            return self.dot_rhs(rbp)
        raise self._syntax(self.cur)

    def dot_rhs(self, rbp):
        token = self.cur
        if token.type == "eof":
            raise self._syntax(token, "expression may not end with a dot")
        if token.type in ("unquoted_identifier", "quoted_identifier", "lbrace", "star"):
            return self.expression(rbp)
        if token.type == "lbracket" and self.peek_type() not in ("number", "colon", "star"):
            return self.expression(rbp)
        raise self._syntax(token)


def parse(text):
    if len(text) == 0:
        raise EmptyExpressionError("expression is empty", 0)
    parser = Parser(text)
    node = parser.expression(0)
    if parser.cur.type != "eof":
        raise parser._syntax(parser.cur)
    return node
