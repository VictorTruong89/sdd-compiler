"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public entries:

* ``search(expression, data, options=None)`` evaluates an expression in one shot.
* ``compile(expression)`` parses an expression once and returns a parsed expression whose
  ``search(value, options=None)`` can be applied to many documents.

Refusals are ``ValueError`` subclasses; see ``pathsel.errors``.
"""

from .nodes import Context
from .parser import parse

__all__ = ["search", "compile", "ParsedExpression"]


class ParsedExpression:
    """A parsed PathSel expression. Searching it does not re-parse the expression text."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return self._node.evaluate(Context(options), value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    """Parse an expression text and return a ParsedExpression. Raises a PathSel refusal on failure."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    """Evaluate an expression against data in one shot and return the selected value."""
    return compile(expression).search(data, options)
