"""Behavior tests for pathsel, derived from spec/Full_PRD.md and spec/Interface_Contract.md."""

from collections import OrderedDict
from types import SimpleNamespace

import pytest

from pathsel import compile, search
from pathsel.errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature

DOC = {
    "a": {"b": {"c": 1}},
    "people": [
        {"first": "a", "age": 30, "tags": [1, 2]},
        {"first": "b", "age": 20, "tags": [3]},
        {"first": "c", "age": 40, "tags": []},
    ],
    "arr": [0, 1, 2, 3, 4, 5],
    "obj": {"x": 1, "y": 2},
    "foo": [{"bar": [{"x": 1}, {"x": 5}], "z": 1}, {"bar": [{"x": 7}], "z": 2}, {"bar": "nope"}],
}


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("a.b.c", 1),
        ("a.b.zz", None),
        ("a.zz.c", None),
        ("people[*].first", ["a", "b", "c"]),
        ("people[?age > `25`].first", ["a", "c"]),
        ("people[0].age", 30),
        ("arr[-1]", 5),
        ("arr[10]", None),
        ("arr[::-2]", [5, 3, 1]),
        ("arr[1:4]", [1, 2, 3]),
        ("arr[:2]", [0, 1]),
        ("arr[5:0:-2]", [5, 3, 1]),
        ("arr[-1:-100:-1]", [5, 4, 3, 2, 1, 0]),
        ("arr[0:0]", []),
        ("arr[1:3:1]", [1, 2]),
        ("people[*].tags[]", [1, 2, 3]),
        ("obj.*", [1, 2]),
        ("'a'", "a"),
        ('"a"', {"b": {"c": 1}}),
        ("`[1,2]`[1]", 2),
        ('`"abc"`', "abc"),
        ("`abc`", "abc"),
        ("'a\\'b'", "a'b"),
        ("'\\u0041'", "A"),
        ("people[*].{n: first}", [{"n": "a"}, {"n": "b"}, {"n": "c"}]),
    ],
)
def test_selection(expr, expected):
    assert search(expr, DOC) == expected


def test_pipe_and_constructors():
    assert search("a | b", {"a": {"b": 5}}) == 5
    assert search("a.b | c", {"a": {"b": {"c": 9}}, "c": 1}) == 9
    assert search("[a, b]", {"a": 1, "b": 2}) == [1, 2]
    assert search("{x: a}", {"a": 1}) == {"x": 1}


def test_quoted_identifier_selects_hyphenated_key():
    assert search('"x-y"', {"x-y": 4}) == 4
    assert search('a."b\\u0041"', {"a": {"bA": 3}}) == 3


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("foo[*].bar[?x > `2`].x", [[5], [7]]),
        ("foo[*].bar[0].x", [1, 7]),
        ("foo[*].bar[].x", [1, 5, 7]),
        ("foo[*].z | length(@)", 2),
        ("foo[*].z == `[1,2]`", True),
        ("!foo[0].z", None),
        ("foo[*].[z, 'k']", [[1, "k"], [2, "k"], [None, "k"]]),
    ],
)
def test_projection_ranking(expr, expected):
    assert search(expr, DOC) == expected


def test_logic_returns_operands():
    assert search("a || b", {"a": 0, "b": 7}) == 0
    assert search("!a", {"a": 0}) is False
    assert search("a && b", {"a": [], "b": 1}) == []
    assert search("`0` || `1`", {}) == 0


def test_json_equality_separates_bool_and_number():
    assert search("`true` == `1`", {}) is False
    assert search("`0` == `false`", {}) is False
    assert search("obj.x == `1.0`", DOC) is True


def test_functions():
    assert search("length(arr)", DOC) == 6
    assert search("length('héllo')", {}) == 5
    assert search("abs(`-3`)", {}) == 3
    assert search("ceil(`1.2`)", {}) == 2
    assert search("floor(`1.8`)", {}) == 1
    assert search("avg(arr)", DOC) == 2.5
    assert search("avg(`[]`)", {}) is None
    assert search("sum(`[]`)", {}) == 0
    assert search("max(arr)", DOC) == 5
    assert search("min(`[]`)", {}) is None
    assert search("sort(`[3,1,2]`)", {}) == [1, 2, 3]
    assert search("join(', ', `[\"x\",\"y\"]`)", {}) == "x, y"
    assert search("join(',', `[]`)", {}) == ""
    assert search("reverse('abc')", {}) == "cba"
    assert search("contains(arr, `3`)", DOC) is True
    assert search("contains('abc', 'b')", {}) is True
    assert search("starts_with('hello', 'he')", {}) is True
    assert search("ends_with('hello', 'lo')", {}) is True
    assert search("to_number('5')", {}) == 5
    assert search("to_number('1.5e2')", {}) == 150.0
    assert search("to_number('x')", {}) is None
    assert search("to_string(`{\"a\":[1,2]}`)", {}) == '{"a":[1,2]}'
    assert search("to_string(`1.5`)", {}) == "1.5"
    assert search("to_array(`1`)", {}) == [1]
    assert search("type(`true`)", {}) == "boolean"
    assert search("type(obj)", DOC) == "object"
    assert search("not_null(zz, `0`)", DOC) == 0
    assert search("keys(obj)", DOC) == ["x", "y"]
    assert search("values(obj)", DOC) == [1, 2]
    assert search("merge(obj, `{\"z\": 3}`)", DOC) == {"x": 1, "y": 2, "z": 3}


def test_expression_reference_functions():
    assert search("map(&first, people)", DOC) == ["a", "b", "c"]
    assert search("sort_by(people, &age)[*].first", DOC) == ["b", "a", "c"]
    assert search("max_by(people, &age).first", DOC) == "c"
    assert search("min_by(people, &age).first", DOC) == "b"
    assert search("max_by(`[]`, &age)", DOC) is None


def test_bare_expression_reference_is_not_null():
    assert search("&foo", {"foo": 1}) is not None


def test_options_dict_cls_and_custom_functions():
    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["number"]})
        def _func_add(self, a, b):
            return a + b

        @signature({"types": ["string"]})
        def _func_zero(self, s):
            return 0

    options = SimpleNamespace(dict_cls=OrderedDict, custom_functions=Provider())
    result = search("{a: `1`, b: `2`}", {}, options)
    assert isinstance(result, OrderedDict)
    assert search("length({a: `1`})", {}, options) == 1
    assert search("add(`1`, `2`)", {}, options) == 3
    assert search("zero('x')", {}, options) == 0
    with pytest.raises(UnknownFunctionError):
        search("add(`1`, `2`)", {})
    with pytest.raises(InvalidArityError):
        search("add(`1`)", {}, options)
    with pytest.raises(InvalidTypeError):
        search("add(`true`, `2`)", {}, options)


def test_compile_then_search_matches_search():
    parsed = compile("a.b[*].c")
    data = {"a": {"b": [{"c": 1}, {"c": 2}]}}
    assert parsed.search(data) == search("a.b[*].c", data) == [1, 2]
    assert parsed.search({}) is None


def test_compile_defers_function_checks():
    parsed = compile("unknownfn(`1`)")
    with pytest.raises(UnknownFunctionError):
        parsed.search({})


@pytest.mark.parametrize(
    "expr, kind",
    [
        ("", EmptyExpressionError),
        ("   ", IncompleteExpressionError),
        ("foo[0", IncompleteExpressionError),
        ("foo |", IncompleteExpressionError),
        ("foo.", PathSelSyntaxError),
        ("foo.[0]", PathSelSyntaxError),
        ("foo.1", PathSelSyntaxError),
        ("foo[*]bar", PathSelSyntaxError),
        ("foo[1:2:3:4]", PathSelSyntaxError),
        ("foo[a:1]", PathSelSyntaxError),
        ("foo[a,b]", PathSelSyntaxError),
        ("a)", PathSelSyntaxError),
        ("foo*", PathSelSyntaxError),
        ("foo.'x'", PathSelSyntaxError),
        ('foo."bar"(x)', PathSelSyntaxError),
        ("foo-bar", TokenSyntaxError),
        ("foo = bar", TokenSyntaxError),
        ("`abc", TokenSyntaxError),
        ("'abc", TokenSyntaxError),
        ("arr[::0]", ZeroSliceStepError),
        ("length(`1`, `2`)", InvalidArityError),
        ("length(`true`)", InvalidTypeError),
        ("sort_by(people, `1`)", InvalidTypeError),
    ],
)
def test_refusal_kinds(expr, kind):
    with pytest.raises(kind) as info:
        search(expr, DOC)
    assert isinstance(info.value, ValueError)
    if issubclass(kind, (PathSelSyntaxError, IncompleteExpressionError)):
        assert isinstance(info.value.lex_position, int)


def test_token_syntax_is_subclass_of_syntax_not_equal():
    with pytest.raises(TokenSyntaxError) as info:
        search("foo-bar", {})
    assert isinstance(info.value, PathSelSyntaxError)
    assert type(info.value) is not PathSelSyntaxError
    assert info.value.lex_position == 3


def test_syntax_position():
    with pytest.raises(PathSelSyntaxError) as info:
        search("a)", {})
    assert info.value.lex_position == 1
    with pytest.raises(IncompleteExpressionError) as info:
        search("foo |", {})
    assert info.value.lex_position == 5
