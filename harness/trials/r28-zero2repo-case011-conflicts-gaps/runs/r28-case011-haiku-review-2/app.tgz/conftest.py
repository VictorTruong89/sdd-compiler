# Keeps the project root on sys.path so tests can `import pathsel` from the flat layout
# without an install step.
