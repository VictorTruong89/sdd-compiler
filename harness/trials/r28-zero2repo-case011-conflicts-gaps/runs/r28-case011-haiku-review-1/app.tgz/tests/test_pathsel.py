"""Behavioural tests for pathsel. Run from the repository root:

    python3 -m unittest discover -s tests -t . -v
"""

import collections
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    Options,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile,
    search,
)
from pathsel.functions import Functions, signature  # noqa: E402

DOC = {
    "foo": {"bar": {"baz": "value"}},
    "people": [
        {"name": "a", "age": 30, "tags": ["x", "y"]},
        {"name": "b", "age": 20, "tags": []},
        {"name": None, "age": 40},
    ],
    "a": [1, 2, 3],
    "nums": [1, None, 2],
    "z": 0,
    "empty": "",
    "key with space": 1,
    "dash-key": 2,
    "é": "unicode",
}


class ExpectMixin(object):
    def check(self, expr, expected, data=DOC, options=None):
        self.assertEqual(search(expr, data, options), expected, expr)
        self.assertEqual(compile(expr).search(data, options), expected, expr)

    def refuse(self, expr, exc_type, data=DOC):
        with self.assertRaises(exc_type, msg=expr):
            search(expr, data)
        with self.assertRaises(exc_type, msg=expr):
            compile(expr).search(data)


class FieldTests(ExpectMixin, unittest.TestCase):
    def test_dotted_path(self):
        self.check("foo.bar.baz", "value")

    def test_missing_is_null(self):
        self.check("foo.nope.deeper", None)
        self.check("a.b", None)

    def test_identifier_on_array_is_null(self):
        self.check("a.b", None)

    def test_quoted_identifier(self):
        self.check('"key with space"', 1)
        self.check('"dash-key"', 2)
        self.check('"é"', "unicode")
        self.check('"foo.bar"', None)
        self.check('"\\u00e9"', "unicode")

    def test_whitespace_between_tokens(self):
        self.check("foo \t.\n bar . baz", "value")

    def test_number_after_dot_is_syntax(self):
        self.refuse("foo.1", SyntaxFailure)
        self.refuse("foo.-1", SyntaxFailure)

    def test_hyphen_is_token_error(self):
        self.refuse("dash-key", TokenSyntaxFailure)

    def test_quoted_call_is_syntax(self):
        self.refuse('"abs"(1)', SyntaxFailure)


class RefusalTests(ExpectMixin, unittest.TestCase):
    def test_empty(self):
        self.refuse("", EmptyExpressionError)
        with self.assertRaises(EmptyExpressionError):
            compile("")

    def test_incomplete(self):
        for expr in ["  ", "\t\n", "foo[", "foo[*", "(foo", "{a: b", "[a, b", "a &&", "a |", "a.b ==", "foo[?a"]:
            with self.assertRaises(IncompleteExpressionError, msg=expr) as cm:
                search(expr, DOC)
            self.assertIsInstance(cm.exception.lex_position, int)
            self.assertIsInstance(cm.exception, ValueError)

    def test_trailing_dot_is_syntax(self):
        self.refuse("foo.", SyntaxFailure)
        self.refuse(".foo", SyntaxFailure)
        self.refuse("foo..bar", SyntaxFailure)

    def test_token_errors_are_subclass_of_syntax(self):
        for expr in ['"abc', "`abc", "'abc", "foo ~ bar", "a = b"]:
            with self.assertRaises(TokenSyntaxFailure, msg=expr) as cm:
                search(expr, DOC)
            self.assertTrue(issubclass(TokenSyntaxFailure, SyntaxFailure))
            self.assertFalse(isinstance(cm.exception, (EmptyExpressionError, IncompleteExpressionError)))
            self.assertIsInstance(cm.exception.lex_position, int)

    def test_grammar_syntax(self):
        for expr in ["foo[*]abc", "foo[1:2:3:4]", "foo[1.5]", "foo[a]", "foo[0][a,b]", "a b", "{a b}", "[1,]", "x.@"]:
            with self.assertRaises(SyntaxFailure, msg=expr) as cm:
                search(expr, DOC)
            self.assertFalse(isinstance(cm.exception, TokenSyntaxFailure), expr)

    def test_syntax_position_is_offset_of_offending_token(self):
        with self.assertRaises(SyntaxFailure) as cm:
            search("foo[*]abc", DOC)
        self.assertEqual(cm.exception.lex_position, 6)
        with self.assertRaises(SyntaxFailure) as cm:
            search("foo.", DOC)
        self.assertEqual(cm.exception.lex_position, 4)

    def test_zero_slice_step(self):
        self.refuse("a[::0]", ZeroSliceStepError)
        self.refuse("a[0:1:0]", ZeroSliceStepError)
        self.assertFalse(issubclass(ZeroSliceStepError, SyntaxFailure))


class IndexSliceTests(ExpectMixin, unittest.TestCase):
    def test_index_and_negative(self):
        self.check("a[0]", 1)
        self.check("a[-1]", 3)
        self.check("a[3]", None)
        self.check("a[-4]", None)
        self.check("z[0]", None)

    def test_slices(self):
        self.check("a[0:2]", [1, 2])
        self.check("a[::-1]", [3, 2, 1])
        self.check("a[-2:]", [2, 3])
        self.check("a[5:9]", [])
        self.check("a[::2]", [1, 3])
        self.check("a[2:0:-1]", [3, 2])

    def test_slice_of_non_array_is_null(self):
        self.check("z[0:1]", None)

    def test_flatten_one_level(self):
        data = {"a": [[1, [2]], 3, [4]]}
        self.check("a[]", [1, [2], 3, 4], data)

    def test_flatten_of_non_array_is_null(self):
        self.check("foo[]", None)

    def test_flatten_after_projection(self):
        self.check("people[*].tags[]", ["x", "y"])


class ProjectionTests(ExpectMixin, unittest.TestCase):
    def test_list_wildcard(self):
        self.check("people[*].name", ["a", "b"])
        self.check("people[*].age", [30, 20, 40])
        self.check("people[*]", [{"name": "a", "age": 30, "tags": ["x", "y"]}, {"name": "b", "age": 20, "tags": []}, {"name": None, "age": 40}])

    def test_list_wildcard_on_non_array_is_null(self):
        self.check("foo[*]", None)

    def test_nested_wildcards(self):
        data = {"r": [{"i": [{"s": 1}, {"s": 2}]}, {"i": [{"s": 3}]}]}
        self.check("r[*].i[*].s", [[1, 2], [3]], data)
        self.check("r[*].i[].s", [1, 2, 3], data)

    def test_dot_chain_after_wildcard(self):
        data = {"r": [{"a": {"b": 1}}, {"a": {"b": 2}}]}
        self.check("r[*].a.b", [1, 2], data)

    def test_object_wildcard_values(self):
        data = {"m": {"x": {"v": 1}, "y": {"v": 2}, "z": None}}
        self.check("m.*.v", [1, 2], data)
        self.check("m.*", [{"v": 1}, {"v": 2}], data)

    def test_object_wildcard_on_non_object_is_null(self):
        self.check("a.*", None)
        self.check("*", None, data=[1])

    def test_filter(self):
        self.check("people[?age > `25`].name", ["a"])
        self.check("people[?tags]", [{"name": "a", "age": 30, "tags": ["x", "y"]}])
        self.check("people[?!tags].name", ["b"])

    def test_filter_on_non_array_is_null(self):
        self.check("foo[?a]", None)

    def test_filter_zero_is_true(self):
        self.check("[?@ == `0`]", [0], data=[0, 1])
        self.check("nums[?@]", [1, 2])

    def test_projection_stops_at_comparison(self):
        self.check("a[*] == `1`", False)
        self.check("people[*].name == `null`", False)

    def test_projection_stops_at_pipe(self):
        self.check("people[*].name | [0]", "a")

    def test_projection_null_drop(self):
        self.check("nums[*]", [1, 2])

    def test_star_at_operand_start(self):
        self.check("*.name", [1, 2], data={"x": {"name": 1}, "y": {"name": 2}})

    def test_slice_is_projection(self):
        self.check("nums[0:3]", [1, 2])

    def test_projection_form_followed_by_identifier_is_syntax(self):
        self.refuse("people[*]name", SyntaxFailure)
        self.refuse("people[*]*", SyntaxFailure)

    def test_wildcard_then_multiselect_first_step(self):
        self.check("people[*][name, age][0]", ["a", "b"])


class ConstructTests(ExpectMixin, unittest.TestCase):
    def test_multiselect_list(self):
        self.check("[foo.bar.baz, z]", ["value", 0])
        self.check("[foo.nope, z]", [None, 0])

    def test_multiselect_list_on_null_is_null(self):
        self.check("nope.[a, b]", None)

    def test_multiselect_hash(self):
        self.check("{v: foo.bar.baz, n: nope}", {"v": "value", "n": None})

    def test_multiselect_as_projection_rhs(self):
        self.check("people[*].{n: name}", [{"n": "a"}, {"n": "b"}, {"n": None}])
        self.check("people[*].[name, age]", [["a", 30], ["b", 20], [None, 40]])

    def test_multiselect_list_after_operand_is_syntax(self):
        self.refuse("foo[a, b]", SyntaxFailure)

    def test_pipe(self):
        self.check("foo | bar", {"baz": "value"})
        self.check("foo.bar | baz", "value")
        self.check("people[*].name | length(@)", 2)

    def test_current(self):
        self.check("@", DOC)
        self.refuse("foo.@", SyntaxFailure)  # a dot must be followed by a name, wildcard or multiselect

    def test_json_literals(self):
        self.check("`[1, 2]`[1]", 2)
        self.check("`null`", None)
        self.check("`true`", True)
        self.check("`abc`", "abc")
        self.check("`\"quoted\"`", "quoted")
        self.check("` 42 `", 42)

    def test_raw_strings(self):
        self.check("'a\\'b'", "a'b")
        self.check("'123'", "123")
        self.check("'\\u00e9'", "é")
        self.check("'a\\nb'", "a\\nb")

    def test_literal_cannot_follow_dot(self):
        self.refuse("foo.'x'", SyntaxFailure)

    def test_expression_reference_is_non_null(self):
        value = search("&foo.bar", DOC)
        self.assertIsNotNone(value)
        self.assertIsNot(value, DOC)

    def test_expression_reference_outside_function_is_not_null(self):
        self.assertIsNotNone(search("&nope", DOC))


class LogicTests(ExpectMixin, unittest.TestCase):
    def test_comparators(self):
        self.check("foo.bar.baz == 'value'", True)
        self.check("a[0] < a[1]", True)
        self.check("'a' < 'b'", True)
        self.check("a[0] != a[1]", True)
        self.check("z == `false`", False)
        self.check("a[0] == `1.0`", True)

    def test_ordering_on_mixed_is_null(self):
        self.check("'a' < `1`", None)

    def test_or_and_return_operands(self):
        self.check("empty || z", 0)
        self.check("nope || 'x'", "x")
        self.check("z && 'x'", "x")  # 0 is a true value, so && returns its right operand
        self.check("foo && 'x'", "x")

    def test_not(self):
        self.check("!z", False)
        self.check("!empty", True)
        self.check("!nope", True)

    def test_not_binding(self):
        self.check("!foo.bar", None)
        self.check("!(foo.bar)", False)

    def test_grouping(self):
        self.check("(nope || z) || 'b'", 0)  # 0 is a true value
        self.check("(nope || empty) || 'b'", "b")

    def test_lone_ampersand(self):
        self.refuse("a & b", SyntaxFailure)


class FunctionTests(ExpectMixin, unittest.TestCase):
    def test_numeric(self):
        self.check("abs(`-3`)", 3)
        self.check("ceil(`1.2`)", 2)
        self.check("floor(`1.8`)", 1)
        self.check("sum(`[1, 2.5]`)", 3.5)
        self.check("avg(`[]`)", None)
        self.check("avg(`[1, 3]`)", 2)

    def test_string(self):
        self.check("length('héllo')", 5)
        self.check("starts_with('abc', 'ab')", True)
        self.check("ends_with('abc', 'bc')", True)
        self.check("reverse('abc')", "cba")
        self.check("join(', ', `[\"a\", \"b\"]`)", "a, b")
        self.check("join(', ', `[]`)", "")
        self.check("contains('abc', 'b')", True)
        self.check("contains(`[1, 2]`, `2`)", True)
        self.check("contains(`[true]`, `1`)", False)

    def test_length_on_array_and_object(self):
        self.check("length(a)", 3)
        self.check("length(foo)", 1)

    def test_conversions(self):
        self.check("to_number('5')", 5)
        self.check("to_number('2.5')", 2.5)
        self.check("to_number('1e3')", 1000.0)
        self.check("to_number('abc')", None)
        self.check("to_number(`true`)", None)
        self.check("to_string(`[1,2]`)", "[1,2]")
        self.check("to_string(`true`)", "true")
        self.check("to_string(`{\"a\": \"é\"}`)", '{"a":"\\u00e9"}')
        self.check("to_array(z)", [0])
        self.check("to_array(a)", [1, 2, 3])
        self.check("type(z)", "number")
        self.check("type(`null`)", "null")
        self.check("type(empty)", "string")

    def test_max_min_sort(self):
        self.check("max(a)", 3)
        self.check("min(`[\"b\", \"a\"]`)", "a")
        self.check("max(`[]`)", None)
        self.check("sort(`[3, 1, 2]`)", [1, 2, 3])
        self.check("sort(`[\"b\", \"a\"]`)", ["a", "b"])

    def test_keys_values_merge(self):
        self.check("keys(foo)", ["bar"])
        self.check("values(foo)", [{"baz": "value"}])
        self.check("merge(`{\"a\": 1}`, `{\"a\": 2, \"b\": 3}`)", {"a": 2, "b": 3})

    def test_not_null(self):
        self.check("not_null(nope, z, a)", 0)
        self.check("not_null(nope, nope)", None)
        self.check("not_null(empty, 'x')", "")

    def test_map_keeps_nulls(self):
        self.check("map(&age, people)", [30, 20, 40])
        self.check("map(&name, people)", ["a", "b", None])

    def test_sort_by_stable(self):
        self.check("sort_by(people, &age)[].age", [20, 30, 40])
        # A null key (the third person has no name) is not a number or string.
        self.refuse("sort_by(people, &name)[0].age", InvalidTypeError)
        self.check("sort_by(people[0:2], &name)[0].age", 30)

    def test_max_by_min_by(self):
        self.check("max_by(people, &age).name", None)
        self.check("max_by(people, &age).age", 40)
        self.check("min_by(people, &age).age", 20)
        self.check("max_by(`[]`, &age)", None)

    def test_function_results_in_projections(self):
        self.check("people[*].age.abs(@)", [30, 20, 40])

    def test_unknown_function(self):
        self.refuse("bogus(a)", UnknownFunctionError)

    def test_unknown_function_is_refused_at_search_not_compile(self):
        compiled = compile("bogus(a)")
        with self.assertRaises(UnknownFunctionError):
            compiled.search(DOC)

    def test_arity(self):
        self.refuse("abs()", InvalidArityError)
        self.refuse("length(a, a)", InvalidArityError)
        self.refuse("merge()", InvalidArityError)

    def test_type(self):
        self.refuse("abs(`true`)", InvalidTypeError)
        self.refuse("avg(nope)", InvalidTypeError)
        self.refuse("join(',', nums)", InvalidTypeError)
        self.refuse("max(`[1, 'a']`)", InvalidTypeError)
        self.refuse("sort_by(people, &tags)", InvalidTypeError)
        self.refuse("starts_with(a, 'x')", InvalidTypeError)
        self.refuse("map(a, a)", InvalidTypeError)

    def test_quoted_function_name_is_syntax(self):
        self.refuse('"abs"(`1`)', SyntaxFailure)


class OptionsTests(ExpectMixin, unittest.TestCase):
    def test_dict_cls_used_for_hashes(self):
        opts = Options(dict_cls=collections.OrderedDict)
        result = search("{x: foo.bar.baz}", DOC, opts)
        self.assertIsInstance(result, collections.OrderedDict)
        self.assertEqual(result, {"x": "value"})
        self.assertEqual(search("{x: foo.bar.baz}.x", DOC, opts), "value")
        self.assertEqual(search("merge({a: `1`}, {b: `2`})", DOC, opts), {"a": 1, "b": 2})

    def test_custom_function(self):
        class Provider(Functions):
            @signature({"types": ["string"]}, {"types": ["number"]})
            def _func_repeat(self, text, times):
                return text * int(times)

            @signature({"types": ["array"]})
            def _func_first(self, values):
                return values[0] if values else 0

        opts = Options(custom_functions=Provider())
        self.assertEqual(search("repeat('ab', `2`)", DOC, opts), "abab")
        self.assertEqual(search("first(`[]`)", DOC, opts), 0)
        self.assertEqual(search("abs(`-1`)", DOC, opts), 1)
        self.assertEqual(compile("repeat('ab', `2`)").search(DOC, opts), "abab")
        with self.assertRaises(UnknownFunctionError):
            search("repeat('ab', `2`)", DOC)
        with self.assertRaises(InvalidArityError):
            search("repeat('ab')", DOC, opts)
        with self.assertRaises(InvalidTypeError):
            search("repeat('ab', 'x')", DOC, opts)

    def test_custom_function_null_type(self):
        class Provider(Functions):
            @signature({"types": ["null"]})
            def _func_only_null(self, value):
                return "ok"

        opts = Options(custom_functions=Provider())
        self.assertEqual(search("only_null(nope)", DOC, opts), "ok")
        with self.assertRaises(InvalidTypeError):
            search("only_null(z)", DOC, opts)

    def test_custom_function_name_on_other_provider_is_unknown(self):
        class Provider(Functions):
            @signature({"types": ["any"]})
            def _func_mine(self, value):
                return 1

        self.assertEqual(search("mine(a)", DOC, Options(custom_functions=Provider())), 1)
        with self.assertRaises(UnknownFunctionError):
            search("mine(a)", DOC, Options(custom_functions=Functions()))


class CompileTests(ExpectMixin, unittest.TestCase):
    def test_compile_reuse(self):
        compiled = compile("foo.bar.baz")
        self.assertEqual(compiled.search(DOC), "value")
        self.assertEqual(compiled.search({"foo": {"bar": {"baz": 1}}}), 1)
        self.assertIsNone(compiled.search({}))

    def test_compile_of_null_is_success(self):
        self.assertIsNotNone(compile("nope"))

    def test_search_does_not_mutate_input(self):
        import copy

        before = copy.deepcopy(DOC)
        search("people[?age > `1`] | sort_by(@, &age)", DOC)
        self.assertEqual(DOC, before)


if __name__ == "__main__":
    unittest.main()
