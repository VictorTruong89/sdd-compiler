"""Expression tree and evaluation.

Every node is evaluated with the value it is applied to (the "current value")
and a :class:`Context` that carries the evaluation options. A chain such as
``a.b`` is ``Sub(Field(a), Field(b))``: the right node is applied to the result
of the left node. A projection holds a right-hand node that is applied to each
element it collects.
"""

import copy
from collections.abc import Mapping

from .exceptions import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .functions import DEFAULT_FUNCTIONS, type_accepts
from .values import ExpressionReference, is_array, is_false, is_number, json_equal


class Context(object):
    """Per-search evaluation options: a mapping type and a function provider."""

    __slots__ = ("dict_cls", "functions")

    def __init__(self, dict_cls=None, functions=None):
        self.dict_cls = dict_cls
        self.functions = functions if functions is not None else DEFAULT_FUNCTIONS

    def new_mapping(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()

    def lookup_function(self, name):
        """Find ``_func_<name>`` on the attached provider, then on the built-ins."""
        attr = "_func_" + name
        for provider in (self.functions, DEFAULT_FUNCTIONS):
            impl = getattr(provider, attr, None)
            if impl is not None and getattr(impl, "_pathsel_signature", None) is not None:
                return impl
        return None


class Node(object):
    __slots__ = ()

    def evaluate(self, value, ctx):
        raise NotImplementedError


class Identity(Node):
    """The current value (``@``, and the empty right-hand side of a projection)."""

    __slots__ = ()

    def evaluate(self, value, ctx):
        return value


IDENTITY = Identity()


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, ctx):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, ctx):
        if isinstance(value, Mapping):
            return value.get(self.name)
        return None


class Sub(Node):
    """Apply ``right`` to the result of ``left`` (dot chains and pipes)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Index(Node):
    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        try:
            return value[self.index]
        except IndexError:
            return None


class Projection(Node):
    """Collects the non-null results of ``rhs`` over the elements a form selects.

    ``kind`` is one of: ``list`` (``[*]``), ``object`` (``*``), ``flatten``
    (``[]``), ``slice``, ``filter`` (``[?pred]``).
    """

    __slots__ = ("kind", "rhs", "pred", "start", "stop", "step")

    def __init__(self, kind, rhs, pred=None, start=None, stop=None, step=None):
        self.kind = kind
        self.rhs = rhs
        self.pred = pred
        self.start = start
        self.stop = stop
        self.step = step

    def _items(self, value, ctx):
        kind = self.kind
        if kind == "list":
            return value if is_array(value) else None
        if kind == "object":
            return list(value.values()) if isinstance(value, Mapping) else None
        if kind == "flatten":
            if not is_array(value):
                return None
            out = []
            for element in value:
                if is_array(element):
                    out.extend(element)
                else:
                    out.append(element)
            return out
        if kind == "slice":
            if not is_array(value):
                return None
            return list(value[slice(self.start, self.stop, self.step)])
        if kind == "filter":
            if not is_array(value):
                return None
            pred = self.pred
            return [e for e in value if not is_false(pred.evaluate(e, ctx))]
        raise AssertionError("unknown projection kind: %r" % (kind,))

    def evaluate(self, value, ctx):
        items = self._items(value, ctx)
        if items is None:
            return None
        rhs = self.rhs
        out = []
        if rhs is IDENTITY:
            for element in items:
                if element is not None:
                    out.append(element)
            return out
        for element in items:
            result = rhs.evaluate(element, ctx)
            if result is not None:
                out.append(result)
        return out


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, ctx):
        if value is None:
            return None
        return [item.evaluate(value, ctx) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, ctx):
        if value is None:
            return None
        result = ctx.new_mapping()
        for key, node in self.pairs:
            result[key] = node.evaluate(value, ctx)
        return result


class Not(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def evaluate(self, value, ctx):
        return is_false(self.child.evaluate(value, ctx))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if is_false(left):
            return left
        return self.right.evaluate(value, ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if not is_false(left):
            return left
        return self.right.evaluate(value, ctx)


def _ordered(left, right):
    if is_number(left) and is_number(right):
        return True
    return isinstance(left, str) and isinstance(right, str)


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        right = self.right.evaluate(value, ctx)
        op = self.op
        if op == "==":
            return json_equal(left, right)
        if op == "!=":
            return not json_equal(left, right)
        if not _ordered(left, right):
            return None
        if op == "<":
            return left < right
        if op == "<=":
            return left <= right
        if op == ">":
            return left > right
        if op == ">=":
            return left >= right
        raise AssertionError("unknown comparator: %r" % (op,))


class ExpressionRef(Node):
    """``&expr``: yields a reference that built-in functions apply later."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, ctx):
        return ExpressionReference(self.node, ctx)


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, ctx):
        impl = ctx.lookup_function(self.name)
        if impl is None:
            raise UnknownFunctionError("unknown function: %s" % self.name)
        specs = impl._pathsel_signature
        count = len(self.args)
        if getattr(impl, "_pathsel_variadic", False):
            if count < len(specs):
                raise InvalidArityError("%s: expected at least %d argument(s), got %d" % (self.name, len(specs), count))
        elif count != len(specs):
            raise InvalidArityError("%s: expected %d argument(s), got %d" % (self.name, len(specs), count))
        args = [arg.evaluate(value, ctx) for arg in self.args]
        for index, arg in enumerate(args):
            accepted = specs[index] if index < len(specs) else specs[-1]
            if not type_accepts(accepted, arg):
                raise InvalidTypeError("%s: argument %d has an invalid type" % (self.name, index + 1))
        return impl(*args)
