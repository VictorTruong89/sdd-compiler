"""Refusal kinds raised by pathsel.

Every refusal is an instance of ``ValueError``. The kind is carried by the
exception type:

* ``EmptyExpressionError``      -- zero-length expression text.
* ``IncompleteExpressionError`` -- text ends where an operand or a closing
  bracket, brace or parenthesis is still required. Has ``lex_position``.
* ``SyntaxFailure``             -- grammar-level syntax failure. Has ``lex_position``.
* ``TokenSyntaxFailure``        -- token-level syntax failure; a subclass of
  ``SyntaxFailure`` and not ``SyntaxFailure`` itself. Has ``lex_position``.
* ``ZeroSliceStepError``        -- a slice whose step is 0.
* ``UnknownFunctionError``      -- function name is neither built-in nor provided.
* ``InvalidArityError``         -- wrong number of function arguments.
* ``InvalidTypeError``          -- function argument outside its accepted types.
"""


class PathSelError(ValueError):
    """Base class of every pathsel refusal."""


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class IncompleteExpressionError(PathSelError):
    """Text ends where an operand, or a required closing token, is still missing."""

    def __init__(self, message, lex_position):
        super(IncompleteExpressionError, self).__init__(message)
        self.lex_position = int(lex_position)


class SyntaxFailure(PathSelError):
    """A grammar-level syntax failure."""

    def __init__(self, message, lex_position):
        super(SyntaxFailure, self).__init__(message)
        self.lex_position = int(lex_position)


class TokenSyntaxFailure(SyntaxFailure):
    """A token-level syntax failure (a more specific form of the syntax kind)."""


class ZeroSliceStepError(PathSelError):
    """A slice was written with a step of 0."""


class UnknownFunctionError(PathSelError):
    """The function name is neither built-in nor supplied by the attached provider."""


class InvalidArityError(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument is outside the types the function accepts."""
