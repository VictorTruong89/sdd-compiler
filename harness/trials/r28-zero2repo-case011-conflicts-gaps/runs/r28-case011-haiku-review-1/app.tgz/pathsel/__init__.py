"""pathsel: evaluate PathSel expressions against ordinary Python data."""

from .api import Options, ParsedExpression, compile, search
from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .values import ExpressionReference

__version__ = "1.0.0"

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Options",
    "ExpressionReference",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
