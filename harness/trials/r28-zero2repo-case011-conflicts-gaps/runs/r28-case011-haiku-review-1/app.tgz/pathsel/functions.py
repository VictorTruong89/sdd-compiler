"""Built-in language functions and the provider mechanism (FP-07, FP-08).

A provider is an instance of :class:`Functions` or of a subclass. Each method
named ``_func_<name>`` that has been decorated with :func:`signature` defines
the language function ``<name>``. The decorator records the declared argument
types on the function; the evaluator checks them before calling it.
"""

import json
import math
import re
from collections.abc import Mapping

from .exceptions import InvalidTypeError
from .values import ExpressionReference, is_array, is_number, json_equal


def _is_string(value):
    return isinstance(value, str)


def _is_array_of_numbers(value):
    return is_array(value) and all(is_number(e) for e in value)


def _is_array_of_strings(value):
    return is_array(value) and all(isinstance(e, str) for e in value)


def _is_array_of_numbers_or_strings(value):
    return is_array(value) and (
        all(is_number(e) for e in value) or all(isinstance(e, str) for e in value)
    )


# Type names accepted in a signature. The first five are the public names
# from the Interface Contract; the rest are internal refinements used by the
# built-in functions.
_CHECKERS = {
    "any": lambda value: True,
    "number": is_number,
    "string": _is_string,
    "array": is_array,
    "object": lambda value: isinstance(value, Mapping),
    "null": lambda value: value is None,
    "expref": lambda value: isinstance(value, ExpressionReference),
    "array_of_numbers": _is_array_of_numbers,
    "array_of_strings": _is_array_of_strings,
    "array_of_numbers_or_strings": _is_array_of_numbers_or_strings,
}


def type_accepts(type_names, value):
    """True when ``value`` satisfies at least one of ``type_names``."""
    for name in type_names:
        if _CHECKERS[name](value):
            return True
    return False


def signature(*arguments):
    """Declare the accepted types of a function's arguments.

    Each argument is a mapping ``{"types": [<type-name>, ...]}``; the value must
    satisfy one of the listed names. The last argument may carry
    ``"variadic": True``, meaning it repeats for every further argument (one or
    more arguments in total). The decorator does not call the function.
    """
    specs = []
    variadic = False
    for index, argument in enumerate(arguments):
        if not isinstance(argument, Mapping):
            raise TypeError("signature arguments must be mappings")
        types = argument.get("types")
        if not isinstance(types, (list, tuple)) or not types:
            raise TypeError('signature argument needs a non-empty "types" list')
        for name in types:
            if name not in _CHECKERS:
                raise ValueError("unknown type name in signature: %r" % (name,))
        if argument.get("variadic"):
            if index != len(arguments) - 1:
                raise ValueError("only the last signature argument may be variadic")
            variadic = True
        specs.append(tuple(types))

    def decorator(func):
        func._pathsel_signature = tuple(specs)
        func._pathsel_variadic = variadic
        return func

    return decorator


def _keys_of(values, ref):
    """Evaluate the reference against each element; keys must be all numbers or all strings."""
    keys = [ref.apply(element) for element in values]
    if keys and not (
        all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys)
    ):
        raise InvalidTypeError("sort key must be a number or a string, and the same kind for every element")
    return keys


_INTEGER_RE = re.compile(r"[+-]?[0-9]+")
_DECIMAL_RE = re.compile(r"[+-]?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _plain(value):
    """Copy mappings and sequences into dict and list so that json can write them."""
    if isinstance(value, Mapping):
        return dict((k, _plain(v)) for k, v in value.items())
    if is_array(value):
        return [_plain(v) for v in value]
    return value


class Functions(object):
    """The built-in function provider. Subclass it to add custom functions."""

    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array_of_numbers"]})
    def _func_avg(self, values):
        if not values:
            return None
        return sum(values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return math.ceil(value)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, item):
        if isinstance(subject, str):
            if not isinstance(item, str):
                raise InvalidTypeError("contains: the second argument must be a string when the first is a string")
            return item in subject
        return any(json_equal(element, item) for element in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, subject, suffix):
        return subject.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, subject, prefix):
        return subject.startswith(prefix)

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return math.floor(value)

    @signature({"types": ["string"]}, {"types": ["array_of_strings"]})
    def _func_join(self, glue, parts):
        if not parts:
            return ""
        return glue.join(parts)

    @signature({"types": ["object"]})
    def _func_keys(self, obj):
        return list(obj.keys())

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, values):
        return [ref.apply(element) for element in values]

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_max(self, values):
        return max(values) if values else None

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_min(self, values):
        return min(values) if values else None

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, values, ref):
        if not values:
            return None
        keys = _keys_of(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, values, ref):
        if not values:
            return None
        keys = _keys_of(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] < keys[best]:
                best = i
        return values[best]

    @signature({"variadic": True, "types": ["object"]})
    def _func_merge(self, *objects):
        result = {}
        for obj in objects:
            for key, value in obj.items():
                result[key] = value
        return result

    @signature({"variadic": True, "types": ["any"]})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, values, ref):
        keys = _keys_of(values, ref)
        order = sorted(range(len(values)), key=keys.__getitem__)
        return [values[i] for i in order]

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_sort(self, values):
        return sorted(values)

    @signature({"types": ["array_of_numbers"]})
    def _func_sum(self, values):
        return sum(values)

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if is_array(value):
            return value
        return [value]

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INTEGER_RE.fullmatch(value):
                return int(value)
            if _DECIMAL_RE.fullmatch(value):
                return float(value)
        return None

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return json.dumps(_plain(value), separators=(",", ":"), ensure_ascii=True, default=str)

    @signature({"types": ["any"]})
    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        return "object"

    @signature({"types": ["object"]})
    def _func_values(self, obj):
        return list(obj.values())


DEFAULT_FUNCTIONS = Functions()
