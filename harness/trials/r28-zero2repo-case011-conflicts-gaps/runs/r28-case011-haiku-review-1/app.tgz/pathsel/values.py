"""Value model helpers: type predicates, truthiness and JSON equality."""

from collections.abc import Mapping
from decimal import Decimal


class ExpressionReference(object):
    """The value of a bare ``&expression``: a deferred subexpression.

    Built-in functions such as ``map``, ``sort_by``, ``max_by`` and ``min_by``
    call :meth:`apply` to evaluate the referenced expression against an element.
    """

    __slots__ = ("node", "context")

    def __init__(self, node, context):
        self.node = node
        self.context = context

    def apply(self, value):
        return self.node.evaluate(value, self.context)

    def __repr__(self):
        return "<pathsel expression reference>"


def is_number(value):
    """Integers, floats and host decimals; booleans are not numbers."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    """Sequences that are JSON arrays: lists and tuples (strings are not arrays)."""
    return isinstance(value, (list, tuple))


def is_object(value):
    """Mappings, including OrderedDict and any other Mapping type."""
    return isinstance(value, Mapping)


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None or value is False:
        return True
    if isinstance(value, (str, list, tuple, Mapping)):
        return len(value) == 0
    return False


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects, numeric by value, never bool == number."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) or is_object(b):
        if not (is_object(a) and is_object(b)) or len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    try:
        return bool(a == b)
    except Exception:
        return False
