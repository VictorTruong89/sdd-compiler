"""Recursive-descent parser for PathSel expressions.

Precedence, loosest to tightest: pipe, ``||``, ``&&``, comparators, ``!``.
Path steps (dot steps, brackets) form a chain. A projection form (``[*]``,
``*``, ``[]``, a slice, ``[?...]``) collects a right-hand side: the steps that
follow it while they rank tighter than the projection. The thresholds are:

* flatten ``[]``                 -> 1; joins only steps ranked above 1
* list ``[*]``, slice, object ``*`` -> 2
* filter ``[?...]``              -> 3

A later step's rank is: dot step 4, filter 3, index / slice / list-wildcard
bracket 5, flatten 1. The first step directly after a projection form always
begins its right-hand side, whatever its rank.
"""

from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailure,
    ZeroSliceStepError,
)
from .lexer import (
    AMP, AND, AT, BANG, COLON, COMMA, DOT, EOF, EQ, GT, GTE, IDENT, LBRACE, LBRACKET,
    LITERAL, LPAREN, LT, LTE, NE, NUMBER, OR, PIPE, QUESTION, QUOTED, RAW, RBRACE,
    RBRACKET, RPAREN, STAR, Lexer,
)
from .nodes import (
    IDENTITY, And, Compare, ExpressionRef, Field, FunctionCall, Index, Literal,
    MultiHash, MultiList, Not, Or, Projection, Sub,
)

THRESHOLD_FLATTEN = 1
THRESHOLD_LIST = 2
THRESHOLD_FILTER = 3
RANK_DOT = 4
RANK_FILTER = 3
RANK_FLATTEN = 1

_COMPARATORS = {
    EQ: "==",
    NE: "!=",
    LT: "<",
    LTE: "<=",
    GT: ">",
    GTE: ">=",
}


class Parser(object):
    def __init__(self, text):
        self._text = text
        self._lexer = Lexer(text)
        self._buffer = []
        self._index = 0

    # ----- token access -------------------------------------------------

    def _tok(self, ahead=0):
        idx = self._index + ahead
        while len(self._buffer) <= idx:
            if self._buffer and self._buffer[-1].type == EOF:
                return self._buffer[-1]
            self._buffer.append(self._lexer.next_token())
        return self._buffer[idx]

    def _advance(self):
        tok = self._tok()
        if tok.type != EOF:
            self._index += 1
        return tok

    def _expect(self, type_):
        tok = self._tok()
        if tok.type == type_:
            return self._advance()
        self._unexpected(tok)

    # ----- failures -----------------------------------------------------

    def _incomplete(self):
        raise IncompleteExpressionError(
            "expression is incomplete at offset %d" % len(self._text), len(self._text)
        )

    def _syntax(self, tok):
        raise SyntaxFailure("syntax error at offset %d" % tok.pos, tok.pos)

    def _unexpected(self, tok):
        if tok.type == EOF:
            self._incomplete()
        self._syntax(tok)

    # ----- grammar levels -----------------------------------------------

    def parse(self):
        node = self._pipe()
        tok = self._tok()
        if tok.type != EOF:
            self._syntax(tok)
        return node

    def _pipe(self):
        left = self._or()
        while self._tok().type == PIPE:
            self._advance()
            left = Sub(left, self._pipe())
        return left

    def _or(self):
        left = self._and()
        while self._tok().type == OR:
            self._advance()
            left = Or(left, self._and())
        return left

    def _and(self):
        left = self._comparison()
        while self._tok().type == AND:
            self._advance()
            left = And(left, self._comparison())
        return left

    def _comparison(self):
        left = self._not()
        while self._tok().type in _COMPARATORS:
            op = _COMPARATORS[self._advance().type]
            left = Compare(op, left, self._not())
        return left

    def _not(self):
        if self._tok().type == BANG:
            self._advance()
            operand = self._not_operand()
            # A dot step, filter, flatten or binary operator after `!` applies to its result.
            return self._chain(Not(operand), 0)
        return self._chain(self._primary(), 0)

    def _not_operand(self):
        if self._tok().type == BANG:
            self._advance()
            return Not(self._not_operand())
        return self._chain(self._primary(), 0, restricted=True)

    # ----- primaries ----------------------------------------------------

    def _primary(self):
        tok = self._tok()
        kind = tok.type
        if kind == IDENT:
            self._advance()
            if self._tok().type == LPAREN:
                return self._call(tok.value)
            return Field(tok.value)
        if kind == QUOTED:
            self._advance()
            if self._tok().type == LPAREN:
                self._syntax(self._tok())
            return Field(tok.value)
        if kind == STAR:
            self._advance()
            return Projection("object", self._rhs(THRESHOLD_LIST))
        if kind == LBRACKET:
            nxt = self._tok(1).type
            if nxt == RBRACKET:
                return self._flatten_step()
            if nxt == QUESTION:
                return self._filter_step()
            if nxt in (NUMBER, COLON, STAR):
                return self._index_slice_or_list()
            return self._multi_list()
        if kind == LBRACE:
            return self._multi_hash()
        if kind == LPAREN:
            self._advance()
            inner = self._pipe()
            self._expect(RPAREN)
            return inner
        if kind == AT:
            self._advance()
            return IDENTITY
        if kind == LITERAL or kind == RAW:
            self._advance()
            return Literal(tok.value)
        if kind == AMP:
            self._advance()
            return ExpressionRef(self._pipe())
        self._unexpected(tok)

    def _call(self, name):
        self._expect(LPAREN)
        args = []
        if self._tok().type == RPAREN:
            self._advance()
            return FunctionCall(name, args)
        while True:
            args.append(self._pipe())
            tok = self._tok()
            if tok.type == COMMA:
                self._advance()
                continue
            if tok.type == RPAREN:
                self._advance()
                break
            self._unexpected(tok)
        return FunctionCall(name, args)

    def _multi_list(self):
        self._expect(LBRACKET)
        items = []
        while True:
            items.append(self._pipe())
            tok = self._tok()
            if tok.type == COMMA:
                self._advance()
                continue
            if tok.type == RBRACKET:
                self._advance()
                break
            self._unexpected(tok)
        return MultiList(items)

    def _multi_hash(self):
        self._expect(LBRACE)
        pairs = []
        while True:
            tok = self._tok()
            if tok.type not in (IDENT, QUOTED):
                self._unexpected(tok)
            self._advance()
            self._expect(COLON)
            pairs.append((tok.value, self._pipe()))
            tok = self._tok()
            if tok.type == COMMA:
                self._advance()
                continue
            if tok.type == RBRACE:
                self._advance()
                break
            self._unexpected(tok)
        return MultiHash(pairs)

    # ----- chains and projections --------------------------------------

    def _chain(self, node, threshold, restricted=False, rhs_first=False):
        """Extend ``node`` with the steps that rank above ``threshold``.

        ``restricted`` limits the steps to index, slice and list-wildcard
        brackets (the operand of ``!``). ``rhs_first`` means the first step
        begins a projection's right-hand side, so it is accepted whatever its rank.
        """
        first = rhs_first
        while True:
            tok = self._tok()
            if tok.type == DOT:
                if restricted or (not first and RANK_DOT <= threshold):
                    break
                self._advance()
                step = self._dot_step()
            elif tok.type == LBRACKET:
                nxt = self._tok(1).type
                if nxt == RBRACKET:
                    if restricted or (not first and RANK_FLATTEN <= threshold):
                        break
                    step = self._flatten_step()
                elif nxt == QUESTION:
                    if restricted or (not first and RANK_FILTER <= threshold):
                        break
                    step = self._filter_step()
                elif nxt in (NUMBER, COLON, STAR):
                    step = self._index_slice_or_list()
                elif nxt == EOF:
                    self._incomplete()
                else:
                    if restricted:
                        break
                    if not first:
                        self._syntax(tok)
                    step = self._multi_list()
            else:
                break
            node = step if node is IDENTITY else Sub(node, step)
            first = False
        return node

    def _rhs(self, threshold):
        """The right-hand side of a projection form that has just been consumed."""
        tok = self._tok()
        if tok.type == DOT or (tok.type == LBRACKET and self._tok(1).type != RBRACKET):
            return self._chain(IDENTITY, threshold, rhs_first=True)
        return IDENTITY

    def _dot_step(self):
        tok = self._tok()
        if tok.type == IDENT:
            self._advance()
            if self._tok().type == LPAREN:
                return self._call(tok.value)
            return Field(tok.value)
        if tok.type == QUOTED:
            self._advance()
            if self._tok().type == LPAREN:
                self._syntax(self._tok())
            return Field(tok.value)
        if tok.type == STAR:
            self._advance()
            return Projection("object", self._rhs(THRESHOLD_LIST))
        if tok.type == LBRACKET:
            return self._multi_list()
        if tok.type == LBRACE:
            return self._multi_hash()
        if tok.type == EOF:
            raise SyntaxFailure("dot at end of expression at offset %d" % tok.pos, tok.pos)
        self._syntax(tok)

    def _flatten_step(self):
        self._advance()  # [
        self._advance()  # ]
        return Projection("flatten", self._rhs(THRESHOLD_FLATTEN))

    def _filter_step(self):
        self._advance()  # [
        self._advance()  # ?
        predicate = self._pipe()
        self._expect(RBRACKET)
        return Projection("filter", self._rhs(THRESHOLD_FILTER), pred=predicate)

    def _index_slice_or_list(self):
        self._advance()  # [
        if self._tok().type == STAR:
            self._advance()
            self._expect(RBRACKET)
            return Projection("list", self._rhs(THRESHOLD_LIST))
        parts = [None]
        while True:
            tok = self._tok()
            if tok.type == NUMBER:
                if parts[-1] is not None:
                    self._syntax(tok)
                parts[-1] = tok.value
            elif tok.type == COLON:
                parts.append(None)
                if len(parts) > 3:
                    self._syntax(tok)
            elif tok.type == RBRACKET:
                break
            else:
                self._unexpected(tok)
            self._advance()
        self._advance()  # ]
        if len(parts) == 1:
            return Index(parts[0])
        start, stop, step = (parts + [None, None])[:3]
        if step == 0:
            raise ZeroSliceStepError("slice step must not be zero")
        return Projection("slice", self._rhs(THRESHOLD_LIST), start=start, stop=stop, step=step)


def parse(text):
    """Parse expression text into a node tree, or raise a refusal."""
    if len(text) == 0:
        raise EmptyExpressionError("empty expression")
    return Parser(text).parse()
