"""Public entry points: ``search`` (one shot) and ``compile`` (parse once)."""

from .nodes import Context
from .parser import parse


class Options(object):
    """Evaluation options. Any object with ``dict_cls`` and ``custom_functions`` works too.

    ``dict_cls``: a mapping type built with no arguments and filled by item
    assignment, used for multiselect hashes; ``None`` means a plain dict.
    ``custom_functions``: a provider (a ``pathsel.functions.Functions`` instance
    or subclass instance); ``None`` means the built-ins only.
    """

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


def _context(options):
    if options is None:
        return Context()
    return Context(
        dict_cls=getattr(options, "dict_cls", None),
        functions=getattr(options, "custom_functions", None),
    )


class ParsedExpression(object):
    """A compiled expression. Search it against any number of documents."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return self._node.evaluate(value, _context(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    """Parse ``expression`` once; returns a :class:`ParsedExpression` or raises a refusal."""
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data``; returns the value or raises a refusal."""
    return compile(expression).search(data, options)
