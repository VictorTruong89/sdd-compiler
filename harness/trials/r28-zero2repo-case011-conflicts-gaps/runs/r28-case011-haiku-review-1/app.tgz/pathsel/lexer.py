"""Tokenizer for the PathSel language.

Tokens are produced on demand (the parser pulls them), so a token-level
failure is raised only when the parser reaches that part of the text.
"""

import json
import re

from .exceptions import TokenSyntaxFailure

EOF = "eof"
IDENT = "ident"
QUOTED = "quoted"        # double-quoted identifier; value is the decoded key
NUMBER = "number"        # integer, optionally with a leading minus
LITERAL = "literal"      # backtick JSON literal; value is the parsed value
RAW = "raw"              # single-quoted raw string; value is the string
DOT = "dot"
STAR = "star"
LBRACKET = "lbracket"
RBRACKET = "rbracket"
LBRACE = "lbrace"
RBRACE = "rbrace"
LPAREN = "lparen"
RPAREN = "rparen"
COMMA = "comma"
COLON = "colon"
AT = "at"
QUESTION = "question"
PIPE = "pipe"
OR = "or"
AND = "and"
AMP = "amp"
BANG = "bang"
EQ = "eq"
NE = "ne"
LT = "lt"
LTE = "lte"
GT = "gt"
GTE = "gte"

_WHITESPACE = " \t\r\n"
_SINGLE = {
    ".": DOT,
    "*": STAR,
    "[": LBRACKET,
    "]": RBRACKET,
    "{": LBRACE,
    "}": RBRACE,
    "(": LPAREN,
    ")": RPAREN,
    ",": COMMA,
    ":": COLON,
    "@": AT,
    "?": QUESTION,
    "|": PIPE,
    "&": AMP,
    "!": BANG,
    "<": LT,
    ">": GT,
}
_DOUBLE = {
    "||": OR,
    "&&": AND,
    "==": EQ,
    "!=": NE,
    "<=": LTE,
    ">=": GTE,
}
_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_NUMBER_RE = re.compile(r"-?[0-9]+")
_HEX4_RE = re.compile(r"[0-9A-Fa-f]{4}")
_MISSING = object()


class Token(object):
    __slots__ = ("type", "value", "pos")

    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.type, self.value, self.pos)


def _reject_constant(name):
    raise ValueError("non-JSON constant: " + name)


def _parse_literal(content):
    """Read a backtick literal: JSON first, otherwise the content of a JSON string."""
    try:
        return json.loads(content, parse_constant=_reject_constant)
    except ValueError:
        pass
    try:
        return json.loads('"' + content.lstrip(" \t\r\n") + '"', parse_constant=_reject_constant)
    except ValueError:
        return _MISSING


class Lexer(object):
    def __init__(self, text):
        self.text = text
        self.pos = 0

    def _fail(self, pos, message):
        raise TokenSyntaxFailure("%s at offset %d" % (message, pos), pos)

    def next_token(self):
        text = self.text
        n = len(text)
        i = self.pos
        while i < n and text[i] in _WHITESPACE:
            i += 1
        if i >= n:
            self.pos = n
            return Token(EOF, None, n)

        start = i
        two = text[i:i + 2]
        if two in _DOUBLE:
            self.pos = i + 2
            return Token(_DOUBLE[two], None, start)

        c = text[i]
        if c in _SINGLE:
            self.pos = i + 1
            return Token(_SINGLE[c], None, start)
        if c == "=":
            self._fail(start, "lone '=' (equality is '==')")
        if c == '"':
            return self._quoted(start)
        if c == "`":
            return self._literal(start)
        if c == "'":
            return self._raw(start)
        if c == "-" or "0" <= c <= "9":
            match = _NUMBER_RE.match(text, i)
            if match is None:
                self._fail(start, "hyphen that does not begin a number")
            self.pos = match.end()
            return Token(NUMBER, int(match.group()), start)
        match = _IDENT_RE.match(text, i)
        if match is not None:
            self.pos = match.end()
            return Token(IDENT, match.group(), start)
        self._fail(start, "character that begins no token")

    def _quoted(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        while j < n:
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == '"':
                break
            j += 1
        if j >= n:
            self._fail(start, "unterminated quoted identifier")
        try:
            value = json.loads(text[start:j + 1], parse_constant=_reject_constant)
        except ValueError:
            self._fail(start, "quoted identifier is not a valid JSON string")
        self.pos = j + 1
        return Token(QUOTED, value, start)

    def _literal(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        while j < n:
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == "`":
                break
            j += 1
        if j >= n:
            self._fail(start, "unterminated JSON literal")
        content = text[start + 1:j].replace("\\`", "`")
        value = _parse_literal(content)
        if value is _MISSING:
            self._fail(start, "JSON literal is neither JSON nor JSON string content")
        self.pos = j + 1
        return Token(LITERAL, value, start)

    def _raw(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        out = []
        while j < n:
            ch = text[j]
            if ch == "'":
                break
            if ch == "\\" and j + 1 < n:
                nxt = text[j + 1]
                if nxt == "'":
                    out.append("'")
                    j += 2
                    continue
                if nxt == "u" and _HEX4_RE.match(text, j + 2):
                    code = int(text[j + 2:j + 6], 16)
                    j += 6
                    if 0xD800 <= code <= 0xDBFF and text.startswith("\\u", j) and _HEX4_RE.match(text, j + 2):
                        low = int(text[j + 2:j + 6], 16)
                        if 0xDC00 <= low <= 0xDFFF:
                            code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                            j += 6
                    out.append(chr(code))
                    continue
            out.append(ch)
            j += 1
        if j >= n:
            self._fail(start, "unterminated raw string literal")
        self.pos = j + 1
        return Token(RAW, "".join(out), start)
