"""Built-in functions (FP-07) and the function lookup used at call time (FP-08).

Each built-in is registered with its accepted argument types. ``check`` names
are resolved by ``_TYPE_TESTS``; a value failing a check is the invalid-type
kind (spec: FP-07, N-000314 .. N-000320).
"""

from __future__ import annotations

import json
import math
import re

from .errors import InvalidTypeError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    is_object,
    is_string,
    json_equal,
    obj_items,
)


# ---------------------------------------------------------------- type tests

def _all_numbers(seq):
    return all(is_number(x) for x in seq)


def _all_strings(seq):
    return all(is_string(x) for x in seq)


_TYPE_TESTS = {
    "any": lambda v, ctx: True,
    "number": lambda v, ctx: is_number(v),
    "string": lambda v, ctx: is_string(v),
    "array": lambda v, ctx: is_array(v),
    "object": lambda v, ctx: is_object(v, ctx),
    "null": lambda v, ctx: v is None,
    "ref": lambda v, ctx: isinstance(v, ExpressionReference),
    "arr_num": lambda v, ctx: is_array(v) and _all_numbers(v),
    "arr_str": lambda v, ctx: is_array(v) and _all_strings(v),
    "arr_num_or_str": lambda v, ctx: is_array(v) and (_all_numbers(v) or _all_strings(v)),
    "arr_or_str": lambda v, ctx: is_array(v) or is_string(v),
    "len_arg": lambda v, ctx: is_string(v) or is_array(v) or is_object(v, ctx),
}


class Function:
    """A callable language function: argument checks, arity bounds, and the call."""

    __slots__ = ("checks", "min_args", "max_args", "call")

    def __init__(self, checks, min_args, max_args, call):
        self.checks = checks          # list of (value, ctx) -> bool; last one repeats if variadic
        self.min_args = min_args
        self.max_args = max_args      # None means unbounded
        self.call = call              # (ctx, args) -> value


# ---------------------------------------------------------------- helpers

def _sum(xs):
    total = 0
    for x in xs:
        try:
            total = total + x
        except TypeError:
            total = float(total) + float(x)
    return total


def _keys_for(ctx, xs, ref):
    keys = [ref.apply(e, ctx) for e in xs]
    if keys and not (_all_numbers(keys) or _all_strings(keys)):
        raise InvalidTypeError("sort key must be a number for every element or a string for every element")
    return keys


_INT_RE = re.compile(r"-?[0-9]+")
_FLOAT_RE = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _jsonable(v):
    import decimal

    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, dict):
        return {k: _jsonable(x) for k, x in v.items()}
    return v


# ---------------------------------------------------------------- implementations

def _abs(ctx, x):
    return abs(x)


def _avg(ctx, xs):
    if not xs:
        return None
    return _sum(xs) / len(xs)


def _ceil(ctx, x):
    return math.ceil(x)


def _floor(ctx, x):
    return math.floor(x)


def _contains(ctx, hay, needle):
    if is_array(hay):
        return any(json_equal(e, needle, ctx) for e in hay)
    if not is_string(needle):
        raise InvalidTypeError("contains on a string needs a string second argument")
    return needle in hay


def _ends_with(ctx, s, suffix):
    return s.endswith(suffix)


def _starts_with(ctx, s, prefix):
    return s.startswith(prefix)


def _length(ctx, v):
    # string: Unicode code points (spec FP-07, N-000277); array: elements; object: keys
    return len(v)


def _reverse(ctx, v):
    if is_string(v):
        return v[::-1]
    return list(reversed(v))


def _join(ctx, sep, xs):
    if not xs:
        return None  # spec: join of an empty array yields null (FP-07, N-000268)
    return sep.join(xs)


def _keys(ctx, obj):
    return list(obj.keys())


def _values(ctx, obj):
    return [v for _, v in obj_items(obj)]


def _type(ctx, v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if is_string(v):
        return "string"
    if is_number(v):
        return "number"
    if is_array(v):
        return "array"
    if is_object(v, ctx):
        return "object"
    return None


def _to_array(ctx, v):
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return [v]


def _to_string(ctx, v):
    if is_string(v):
        return v
    return json.dumps(_jsonable(v), separators=(",", ":"), ensure_ascii=True, default=str)


def _to_number(ctx, v):
    if is_number(v):
        return v
    if is_string(v):
        if _INT_RE.fullmatch(v):
            return int(v)
        if _FLOAT_RE.fullmatch(v):
            return float(v)
    return None


def _max(ctx, xs):
    return max(xs) if xs else None


def _min(ctx, xs):
    return min(xs) if xs else None


def _sort(ctx, xs):
    return sorted(xs)


def _sum_fn(ctx, xs):
    return _sum(xs)


def _merge(ctx, *objs):
    out = {}
    for o in objs:
        for k, v in obj_items(o):
            out[k] = v
    return out


def _not_null(ctx, *vals):
    for v in vals:
        if v is not None:
            return v
    return None


def _map(ctx, ref, xs):
    return [ref.apply(e, ctx) for e in xs]


def _sort_by(ctx, xs, ref):
    keys = _keys_for(ctx, xs, ref)
    order = sorted(range(len(xs)), key=lambda i: keys[i])  # stable
    return [xs[i] for i in order]


def _max_by(ctx, xs, ref):
    keys = _keys_for(ctx, xs, ref)
    if not xs:
        return None
    best = 0
    for i in range(1, len(xs)):
        if keys[i] > keys[best]:
            best = i
    return xs[best]


def _min_by(ctx, xs, ref):
    keys = _keys_for(ctx, xs, ref)
    if not xs:
        return None
    best = 0
    for i in range(1, len(xs)):
        if keys[i] < keys[best]:
            best = i
    return xs[best]


def _fixed(types, impl):
    checks = [_TYPE_TESTS[t] for t in types]
    n = len(types)
    return Function(checks, n, n, lambda ctx, args: impl(ctx, *args))


def _variadic(type_name, impl, minimum):
    return Function([_TYPE_TESTS[type_name]], minimum, None, lambda ctx, args: impl(ctx, *args))


# spec: N-000262..N-000322 (FP-07: names, arity, types, each function's definition)
BUILTINS = {
    "abs": _fixed(["number"], _abs),
    "avg": _fixed(["arr_num"], _avg),
    "ceil": _fixed(["number"], _ceil),
    "contains": _fixed(["arr_or_str", "any"], _contains),
    "ends_with": _fixed(["string", "string"], _ends_with),
    "floor": _fixed(["number"], _floor),
    "join": _fixed(["string", "arr_str"], _join),
    "keys": _fixed(["object"], _keys),
    "length": _fixed(["len_arg"], _length),
    "map": _fixed(["ref", "array"], _map),
    "max": _fixed(["arr_num_or_str"], _max),
    "max_by": _fixed(["array", "ref"], _max_by),
    "merge": _variadic("object", _merge, 1),
    "min": _fixed(["arr_num_or_str"], _min),
    "min_by": _fixed(["array", "ref"], _min_by),
    "not_null": _variadic("any", _not_null, 1),
    "reverse": _fixed(["arr_or_str"], _reverse),
    "sort": _fixed(["arr_num_or_str"], _sort),
    "sort_by": _fixed(["array", "ref"], _sort_by),
    "starts_with": _fixed(["string", "string"], _starts_with),
    "sum": _fixed(["arr_num"], _sum_fn),
    "to_array": _fixed(["any"], _to_array),
    "to_number": _fixed(["any"], _to_number),
    "to_string": _fixed(["any"], _to_string),
    "type": _fixed(["any"], _type),
    "values": _fixed(["object"], _values),
}


# ---------------------------------------------------------------- custom functions

_JSON_TYPE_TESTS = {
    "number": lambda v, ctx: is_number(v),
    "string": lambda v, ctx: is_string(v),
    "array": lambda v, ctx: is_array(v),
    "object": lambda v, ctx: is_object(v, ctx),
    "null": lambda v, ctx: v is None,
}


def _custom_function(provider, name):
    """Function declared on ``provider`` as ``_func_<name>`` through ``signature``, or None."""
    attr = getattr(provider, "_func_" + name, None)
    if attr is None or not callable(attr):
        return None
    specs = getattr(attr, "_pathsel_signature", None)
    if specs is None:
        return None
    checks = []
    for types in specs:
        tests = [_JSON_TYPE_TESTS[t] for t in types]
        checks.append(lambda v, ctx, tests=tests: any(t(v, ctx) for t in tests))
    n = len(checks)
    return Function(checks, n, n, lambda ctx, args: attr(*args))


def lookup_function(name, provider):
    """Built-ins first (their behaviour is fixed), then the provider; None if neither has it."""
    fn = BUILTINS.get(name)
    if fn is not None:
        return fn
    if provider is not None:
        return _custom_function(provider, name)
    return None
