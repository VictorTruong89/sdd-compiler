"""pathsel: evaluate PathSel expressions against ordinary Python data.

Entries:
    search(expression, data, options=None) -> value
    compile(expression) -> parsed expression; ``.search(data, options=None)``

Failures raise a ``ValueError`` subclass (see ``pathsel.errors``).
"""

from __future__ import annotations

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature
from .parser import parse_expression
from .values import Context, context_from_options

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


class ParsedExpression:
    """A compiled expression. Searching it never re-parses the text."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return self._node.eval(value, context_from_options(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


# spec: N-000372..N-000388 (Interface Contract: pathsel.search, pathsel.compile, parsed .search)
def compile(expression):  # noqa: A001 - published name (Interface Contract)
    """Parse ``expression`` once; raises the refusal for a text that does not compile."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(expression, parse_expression(expression))


def search(expression, data, options=None):
    """One-shot search: compile then search (same results as compile-then-search)."""
    return compile(expression).search(data, options)
