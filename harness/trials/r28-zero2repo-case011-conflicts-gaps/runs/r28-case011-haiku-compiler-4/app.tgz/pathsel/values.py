"""Value model: type tests, truthiness, JSON equality and ordering.

Arrays are ``list`` or ``tuple``. Objects are ``collections.abc.Mapping``
instances, plus instances of the caller's ``dict_cls`` when evaluation
options supply one (spec: FP-08, N-000330). Numbers are ``int``, ``float``
and ``decimal.Decimal`` (never ``bool``). Strings are ``str``. Null is
``None``.
"""

from __future__ import annotations

import decimal
from collections.abc import Mapping

_NUMBER_TYPES = (int, float, decimal.Decimal)


class Context:
    """Evaluation context derived from the caller's options (spec: Evaluation options)."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider


def context_from_options(options) -> Context:
    """Read ``dict_cls`` and ``custom_functions`` from an options object (or None)."""
    if options is None:
        return Context()
    return Context(
        getattr(options, "dict_cls", None),
        getattr(options, "custom_functions", None),
    )


class ExpressionReference:
    """Value of an expression reference (``&expr``): deferred, applied later by functions."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def apply(self, element, ctx):
        return self.node.eval(element, ctx)

    def __repr__(self):
        return "ExpressionReference(...)"


def is_number(v) -> bool:
    return isinstance(v, _NUMBER_TYPES) and not isinstance(v, bool)


def is_string(v) -> bool:
    return isinstance(v, str)


def is_array(v) -> bool:
    return isinstance(v, (list, tuple))


# spec: N-000330..N-000334 (FP-08: constructed hashes are objects whatever the mapping type)
def is_object(v, ctx=None) -> bool:
    if isinstance(v, Mapping):
        return True
    dict_cls = None if ctx is None else ctx.dict_cls
    return dict_cls is not None and isinstance(v, dict_cls)


def obj_get(obj, key):
    """Value stored under ``key`` or None when the key is absent."""
    try:
        return obj[key] if key in obj else None
    except (KeyError, TypeError):
        return None


def obj_items(obj):
    return list(obj.items())


def _length_or_none(v):
    try:
        return len(v)
    except TypeError:
        return None


def is_false(v, ctx=None) -> bool:
    """False-value set: false, null, empty string, empty array, empty object (Terminology)."""
    if v is None:
        return True
    if isinstance(v, bool):
        return not v
    if is_string(v) or is_array(v):
        return len(v) == 0
    if is_object(v, ctx):
        n = _length_or_none(v)
        return n == 0
    return False


def json_equal(a, b, ctx=None) -> bool:
    """JSON value equality (FP-06): deep for arrays and objects; a number is never a boolean."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if is_string(a) or is_string(b):
        return is_string(a) and is_string(b) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y, ctx) for x, y in zip(a, b))
    if is_object(a, ctx) or is_object(b, ctx):
        if not (is_object(a, ctx) and is_object(b, ctx)):
            return False
        if _length_or_none(a) != _length_or_none(b):
            return False
        for k, v in obj_items(a):
            if k not in b or not json_equal(v, b[k], ctx):
                return False
        return True
    try:
        return bool(a == b)
    except Exception:  # host values with unusual equality
        return a is b


def compare_order(op: str, a, b):
    """Ordering comparison: numbers numerically, strings by code point; otherwise null."""
    if (is_number(a) and is_number(b)) or (is_string(a) and is_string(b)):
        if op == "<":
            return a < b
        if op == "<=":
            return a <= b
        if op == ">":
            return a > b
        if op == ">=":
            return a >= b
    return None
