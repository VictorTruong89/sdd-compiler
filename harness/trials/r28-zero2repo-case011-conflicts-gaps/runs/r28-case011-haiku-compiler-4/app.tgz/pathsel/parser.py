"""Pratt parser for PathSel expressions.

Binding powers follow the spec's ranking (FP-04 "Reach of a projection", FP-06
"Binding"): pipe 1 < ``||`` 2 < ``&&`` 3 < comparators 5 < flatten 9 < list
wildcard and slice 20 < filter 21 < dot 40 < ``!`` operand 45 < bracket step 55.

A projection's right-hand side is parsed with the projection's own binding
power, so later steps join it only when they bind tighter (``rhs``). The step
written directly after the form always begins it (dot step, index, slice,
list wildcard, multiselect list, filter).

Refusals: an empty text raises ``EmptyExpressionError``. Text that ends where
an operand or a closing token is still required raises
``IncompleteExpressionError``; a dot followed by the end of the text is a
syntax failure (N-000094). Everything else is ``PathSelSyntaxError``, or
``TokenSyntaxError`` when the failure is in the tokens.
"""

from __future__ import annotations

from . import nodes as N
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from .lexer import tokenize

_CMP = {"eq": "==", "ne": "!=", "lt": "<", "lte": "<=", "gt": ">", "gte": ">="}
_LBP = {"pipe": 1, "or": 2, "and": 3, "dot": 40}
_LBP.update({k: 5 for k in _CMP})


class Parser:
    def __init__(self, text):
        self.text = text
        self.toks = tokenize(text)
        self.i = 0

    # ------------------------------------------------------------ token access

    @property
    def cur(self):
        return self.peek(0)

    def peek(self, k=0):
        j = self.i + k
        if j >= len(self.toks):
            return self.toks[-1]
        return self.toks[j]

    def advance(self):
        self.i += 1

    def fail(self, tok):
        """Raise the refusal for an unexpected token."""
        if tok.type == "error":
            raise tok.error
        if tok.type == "eof":
            raise IncompleteExpressionError(lex_position=len(self.text))
        raise PathSelSyntaxError(lex_position=tok.pos)

    def expect(self, ty):
        if self.cur.type != ty:
            self.fail(self.cur)
        self.advance()

    def lbp(self, k=0):
        t = self.peek(k)
        if t.type in _LBP:
            return _LBP[t.type]
        if t.type == "lbracket":
            nxt = self.peek(k + 1).type
            if nxt == "rbracket":
                return 9   # flatten
            if nxt == "question":
                return 21  # filter
            return 55      # index, slice, list wildcard
        return 0

    # ------------------------------------------------------------ Pratt core

    def parse(self, bp):
        return self.loop(self.nud(), bp)

    def loop(self, left, bp):
        while bp < self.lbp():
            left = self.led(left)
        return left

    def nud(self):
        t = self.cur
        ty = t.type
        if ty == "ident":
            self.advance()
            if self.cur.type == "lparen":
                return self.call(t.value)
            return N.Field(t.value)
        if ty == "qident":
            self.advance()
            return N.Field(t.value)
        if ty in ("lit", "raw"):
            self.advance()
            return N.Literal(t.value)
        if ty == "current":
            self.advance()
            return N.Identity()
        if ty == "expref":
            self.advance()
            return N.ExprRef(self.parse(0))
        if ty == "star":
            self.advance()
            return N.ObjProj(N.Identity(), self.rhs(20))
        if ty == "not":
            self.advance()
            return N.Not(self.parse(45))
        if ty == "lparen":
            self.advance()
            e = self.parse(0)
            self.expect("rparen")
            return e
        if ty == "lbrace":
            self.advance()
            return self.multihash()
        if ty == "lbracket":
            self.advance()
            return self.bracket(N.Identity(), multi=True)
        self.fail(t)

    def led(self, left):
        t = self.cur
        ty = t.type
        if ty == "pipe":
            self.advance()
            return N.Pipe(left, self.parse(1))
        if ty == "or":
            self.advance()
            return N.Or(left, self.parse(2))
        if ty == "and":
            self.advance()
            return N.And(left, self.parse(3))
        if ty in _CMP:
            self.advance()
            return N.Compare(_CMP[ty], left, self.parse(5))
        if ty == "dot":
            self.advance()
            return self.dot_step(left)
        if ty == "lbracket":
            self.advance()
            return self.bracket(left, multi=False)
        self.fail(t)

    # ------------------------------------------------------------ pieces

    def call(self, name):
        """Function call; the identifier is consumed, the current token is '('."""
        self.expect("lparen")
        args = []
        if self.cur.type == "rparen":
            self.advance()
            return N.FuncCall(name, args)
        while True:
            args.append(self.parse(0))
            if self.cur.type == "comma":
                self.advance()
                continue
            self.expect("rparen")
            break
        return N.FuncCall(name, args)

    def rhs(self, bp):
        """Right-hand side of a projection whose own binding power is ``bp``."""
        t = self.cur
        if t.type == "dot":
            self.advance()
            return self.loop(self.dot_step(N.Identity()), bp)
        if t.type == "lbracket" and self.lbp() >= 10:
            return self.loop(self.nud(), bp)
        return N.Identity()

    def dot_step(self, base):
        """The step after a dot; the dot is already consumed."""
        t = self.cur
        if t.type == "star":
            self.advance()
            return N.ObjProj(base, self.rhs(40))
        if t.type in ("ident", "qident"):
            self.advance()
            if t.type == "ident" and self.cur.type == "lparen":
                # A function call as a step: `people[*].length(@)` (spec N-000309).
                return N.Subexpr(base, self.call(t.value))
            return N.Subexpr(base, N.Field(t.value))
        if t.type == "lbrace":
            self.advance()
            return N.Subexpr(base, self.multihash())
        if t.type == "lbracket":
            if self.peek(1).type == "rbracket":
                self.fail(t)
            self.advance()
            return N.Subexpr(base, self.multilist())
        if t.type == "eof":
            raise PathSelSyntaxError(lex_position=len(self.text))  # dot before end of text
        self.fail(t)

    def bracket(self, base, multi):
        """Bracket body; the '[' is consumed. ``multi`` allows a multiselect list."""
        t = self.cur
        if t.type == "rbracket":
            self.advance()
            return N.FlattenProj(base, self.rhs(9))
        if t.type == "question":
            return self.filter_body(base)
        if t.type == "star" and self.peek(1).type == "rbracket":
            self.advance()
            self.advance()
            return N.ListProj(base, self.rhs(20))
        if t.type in ("num", "colon"):
            return self.index_body(base)
        if multi:
            return self.multilist()
        self.fail(t)

    def filter_body(self, base):
        self.advance()  # '?'
        pred = self.parse(0)
        self.expect("rbracket")
        return N.FilterProj(base, pred, self.rhs(21))

    def index_body(self, base):
        """``[n]``, ``[a:b]``, ``[a:b:c]``; cur is a number or a colon."""
        first = None
        if self.cur.type == "num":
            first = self.cur.value
            self.advance()
        if self.cur.type != "colon":
            self.expect("rbracket")
            return N.Index(base, first)
        parts = [first]
        while self.cur.type == "colon":
            if len(parts) >= 3:
                self.fail(self.cur)  # more than three parts
            self.advance()
            part = None
            if self.cur.type == "num":
                part = self.cur.value
                self.advance()
            parts.append(part)
        self.expect("rbracket")
        parts += [None] * (3 - len(parts))
        start, stop, step = parts
        if step == 0:
            raise ZeroSliceStepError("slice step is 0")
        return N.SliceProj(base, start, stop, step, self.rhs(20))

    def multilist(self):
        """Multiselect list body; the '[' is consumed."""
        items = [self.parse(0)]
        while self.cur.type == "comma":
            self.advance()
            items.append(self.parse(0))
        self.expect("rbracket")
        return N.MultiList(items)

    def multihash(self):
        """Multiselect hash body; the '{' is consumed."""
        pairs = []
        while True:
            t = self.cur
            if t.type not in ("ident", "qident"):
                self.fail(t)
            self.advance()
            self.expect("colon")
            pairs.append((t.value, self.parse(0)))
            if self.cur.type == "comma":
                self.advance()
                continue
            self.expect("rbrace")
            break
        return N.MultiHash(pairs)


# spec: N-000087..N-000106 (FP-01 refusals and positions); N-000183..N-000199 (projection RHS);
#       N-000107..N-000125 (FP-02 steps); N-000126..N-000157 (FP-03 brackets); N-000158..N-000205
#       (FP-04 wildcards, filters); N-000206..N-000241 (FP-05 constructs); N-000242..N-000261 (FP-06 binding)
def parse_expression(text: str):
    """Compile ``text`` to a node tree, or raise the refusal for it."""
    if text == "":
        raise EmptyExpressionError("empty expression")
    p = Parser(text)
    node = p.parse(0)
    if p.cur.type != "eof":
        p.fail(p.cur)
    return node
