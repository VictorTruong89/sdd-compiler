"""Expression tree and its evaluation.

``eval(cur, ctx)`` evaluates a node against the current value ``cur``.
Projections collect an array and apply their right-hand side to each element,
dropping null results (FP-04, FP-03, N-000143 .. N-000150).
"""

from __future__ import annotations

import copy

from .builtins import lookup_function
from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .values import (
    ExpressionReference,
    compare_order,
    is_array,
    is_false,
    is_object,
    json_equal,
    obj_get,
    obj_items,
)


class Node:
    __slots__ = ()

    def eval(self, cur, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Identity(Node):
    """``@``: the current value itself."""

    __slots__ = ()

    def eval(self, cur, ctx):
        return cur


class Literal(Node):
    """JSON literal or raw string literal (FP-05, N-000223 .. N-000230)."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, cur, ctx):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class Field(Node):
    """Unquoted or quoted identifier: the field of the current object (FP-02)."""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, cur, ctx):
        if is_object(cur, ctx):
            return obj_get(cur, self.name)
        return None


class Index(Node):
    """``[n]`` with a negative index counting from the end (FP-03, N-000126 .. N-000129)."""

    __slots__ = ("base", "index")

    def __init__(self, base, index):
        self.base = base
        self.index = index

    def eval(self, cur, ctx):
        v = self.base.eval(cur, ctx)
        if not is_array(v):
            return None
        n = len(v)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return v[i]
        return None


class Subexpr(Node):
    """``left.right``: the right step applied to the value of the left step."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


# spec: N-000130..N-000141 (slice selection rules)
def slice_indices(n, start, stop, step):
    """Indices selected by ``[start:stop:step]`` over an array of length ``n`` (FP-03)."""
    if step is None:
        step = 1
    if step == 0:
        return []
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, 0), n)
        e = min(max(e, 0), n)
    else:
        s = n - 1 if start is None else (start + n if start < 0 else start)
        e = -1 if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, -1), n - 1)
        e = min(max(e, -1), n - 1)
    return list(range(s, e, step))


class _Projection(Node):
    """Collect an array from ``base``, then apply ``rhs`` to each element, dropping nulls."""

    __slots__ = ("base", "rhs")

    def __init__(self, base, rhs):
        self.base = base
        self.rhs = rhs

    def collect(self, v, ctx):  # pragma: no cover - abstract
        raise NotImplementedError

    def eval(self, cur, ctx):
        items = self.collect(self.base.eval(cur, ctx), ctx)
        if items is None:
            return None
        out = []
        rhs = self.rhs
        for e in items:
            r = rhs.eval(e, ctx)
            if r is not None:
                out.append(r)
        return out


class ListProj(_Projection):
    """``[*]`` (FP-04)."""

    __slots__ = ()

    def collect(self, v, ctx):
        return list(v) if is_array(v) else None


class ObjProj(_Projection):
    """``*`` or ``<expr>.*``: projects over an object's values (FP-04)."""

    __slots__ = ()

    def collect(self, v, ctx):
        if is_object(v, ctx):
            return [val for _, val in obj_items(v)]
        return None


class SliceProj(_Projection):
    """``[start:stop:step]``: a slice is a projection (FP-03)."""

    __slots__ = ("start", "stop", "step")

    def __init__(self, base, start, stop, step, rhs):
        super().__init__(base, rhs)
        self.start = start
        self.stop = stop
        self.step = step

    def collect(self, v, ctx):
        if not is_array(v):
            return None
        return [v[i] for i in slice_indices(len(v), self.start, self.stop, self.step)]


class FilterProj(_Projection):
    """``[?predicate]`` (FP-04)."""

    __slots__ = ("pred",)

    def __init__(self, base, pred, rhs):
        super().__init__(base, rhs)
        self.pred = pred

    def collect(self, v, ctx):
        if not is_array(v):
            return None
        return [e for e in v if not is_false(self.pred.eval(e, ctx), ctx)]


class FlattenProj(_Projection):
    """``[]``: one-level flatten, then a projection (FP-03)."""

    __slots__ = ()

    def collect(self, v, ctx):
        if not is_array(v):
            return None
        out = []
        for e in v:
            if is_array(e):
                out.extend(e)
            else:
                out.append(e)
        return out


class Pipe(Node):
    """``left | right``: right is evaluated with left's result as current value (FP-05)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        lv = self.left.eval(cur, ctx)
        if not is_false(lv, ctx):
            return lv
        return self.right.eval(cur, ctx)


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        lv = self.left.eval(cur, ctx)
        if is_false(lv, ctx):
            return lv
        return self.right.eval(cur, ctx)


class Not(Node):
    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand

    def eval(self, cur, ctx):
        return is_false(self.operand.eval(cur, ctx), ctx)


class Compare(Node):
    """``==``, ``!=``, ``<``, ``<=``, ``>``, ``>=`` (FP-06)."""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        a = self.left.eval(cur, ctx)
        b = self.right.eval(cur, ctx)
        if self.op == "==":
            return json_equal(a, b, ctx)
        if self.op == "!=":
            return not json_equal(a, b, ctx)
        return compare_order(self.op, a, b)


class MultiList(Node):
    """``[e1, e2]`` (FP-05)."""

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def eval(self, cur, ctx):
        if cur is None:
            return None
        return [item.eval(cur, ctx) for item in self.items]


class MultiHash(Node):
    """``{k: e, ...}`` (FP-05, FP-08)."""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, cur, ctx):
        if cur is None:
            return None
        obj = ctx.dict_cls() if ctx.dict_cls is not None else {}
        for key, node in self.pairs:
            obj[key] = node.eval(cur, ctx)
        return obj


class ExprRef(Node):
    """``&expr``: a deferred expression (FP-05). Evaluates to a reference value."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return ExpressionReference(self.node)


class FuncCall(Node):
    """``name(arg, ...)``: checked at evaluation time (FP-07, FP-08)."""

    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, cur, ctx):
        fn = lookup_function(self.name, ctx.provider)
        if fn is None:
            raise UnknownFunctionError("unknown function " + self.name)
        n = len(self.args)
        if n < fn.min_args or (fn.max_args is not None and n > fn.max_args):
            raise InvalidArityError("wrong number of arguments to " + self.name)
        values = []
        for a in self.args:
            if isinstance(a, ExprRef):
                values.append(ExpressionReference(a.node))
            else:
                values.append(a.eval(cur, ctx))
        for i, v in enumerate(values):
            check = fn.checks[min(i, len(fn.checks) - 1)]
            if not check(v, ctx):
                raise InvalidTypeError("argument %d of %s has an invalid type" % (i + 1, self.name))
        return fn.call(ctx, values)
