"""Custom language functions (FP-08, Interface Contract ``pathsel.functions``).

Subclass ``Functions`` and declare methods named ``_func_<name>`` decorated with
``signature``. Attach an instance as ``custom_functions`` in the evaluation
options. A call to ``<name>`` that is not a built-in is looked up on the
provider (spec: N-000397 .. N-000404).
"""

from __future__ import annotations

from collections.abc import Mapping

_JSON_TYPE_NAMES = frozenset({"number", "string", "array", "object", "null"})


class Functions:
    """Provider base class. Instances carry no state; subclasses add ``_func_`` methods."""

    def __init__(self):
        pass


# spec: N-000393..N-000404 (Interface Contract: pathsel.functions, signature)
def signature(*arguments):
    """Declare argument types of a provider function.

    Each argument is ``{"types": [<type-name>, ...]}`` with names from
    ``number``, ``string``, ``array``, ``object``, ``null``. Returns a decorator
    that marks the implementation without calling it.
    """
    specs = []
    for arg in arguments:
        if not isinstance(arg, Mapping) or "types" not in arg:
            raise TypeError('each signature argument must be a mapping with a "types" list')
        types = list(arg["types"])
        for t in types:
            if t not in _JSON_TYPE_NAMES:
                raise TypeError("unknown JSON type name in signature: %r" % (t,))
        specs.append(types)

    def decorate(fn):
        fn._pathsel_signature = [list(t) for t in specs]
        return fn

    return decorate


__all__ = ["Functions", "signature"]
