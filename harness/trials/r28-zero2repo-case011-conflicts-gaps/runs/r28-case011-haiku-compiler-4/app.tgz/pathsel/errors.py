"""Refusal kinds.

Every refusal is an instance of ``ValueError`` (spec: Failure carriers,
N-000405). The kind is carried by the exception type:

* ``EmptyExpressionError``        - empty-expression kind (N-000409)
* ``IncompleteExpressionError``   - incomplete-expression kind (N-000410)
* ``PathSelSyntaxError``          - syntax kind, grammar-level (N-000411)
* ``TokenSyntaxError``            - syntax kind, token-level; a subclass of
                                    ``PathSelSyntaxError`` (N-000412)
* ``ZeroSliceStepError``          - zero-slice-step kind (N-000415)
* ``UnknownFunctionError``        - unknown-function kind (N-000416)
* ``InvalidArityError``           - invalid-arity kind (N-000417)
* ``InvalidTypeError``            - invalid-type kind (N-000418)

Syntax and incomplete-expression refusals carry an ``int`` attribute
``lex_position`` (N-000421, N-000422).
"""

from __future__ import annotations


# spec: N-000405..N-000422 (Interface Contract: failure carriers and lex_position)
class PathSelError(ValueError):
    """Base class of every refusal. Never raised on its own."""


class EmptyExpressionError(PathSelError):
    """The zero-length expression text does not succeed (FP-01)."""


class IncompleteExpressionError(PathSelError):
    """Text ends where an operand or a closing token is still required (FP-01)."""

    def __init__(self, message: str = "incomplete expression", lex_position: int = 0):
        super().__init__(message)
        self.lex_position = int(lex_position)


class PathSelSyntaxError(PathSelError):
    """A well-formed-expression violation detected on valid tokens (FP-01)."""

    def __init__(self, message: str = "syntax error", lex_position: int = 0):
        super().__init__(message)
        self.lex_position = int(lex_position)


class TokenSyntaxError(PathSelSyntaxError):
    """A syntax failure detected while splitting the text into tokens."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0 (FP-03)."""


class UnknownFunctionError(PathSelError):
    """A call names neither a built-in nor a provider function (FP-07, FP-08)."""


class InvalidArityError(PathSelError):
    """A call gives the wrong number of arguments (FP-07, FP-08)."""


class InvalidTypeError(PathSelError):
    """A call gives an argument outside its accepted types (FP-07, FP-08)."""
