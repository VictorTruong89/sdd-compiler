"""Tokenizer for the PathSel language (FP-01 .. FP-07 token rules).

``tokenize`` never raises. When the text contains a character that begins no
token, or a literal that cannot be read, the token list ends with an ``error``
token carrying the ``TokenSyntaxError`` to raise. The parser raises it only
when it reaches that point, so an earlier grammar failure is reported first.
"""

from __future__ import annotations

import json

from .errors import TokenSyntaxError

_WS = " \t\n\r"
_JSON_WS = " \t\n\r"
_IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT_CHARS = _IDENT_START | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_HEX = frozenset("0123456789abcdefABCDEF")

_TWO_CHAR = {
    "&&": "and",
    "||": "or",
    "==": "eq",
    "!=": "ne",
    "<=": "lte",
    ">=": "gte",
}

_ONE_CHAR = {
    ".": "dot",
    "*": "star",
    "@": "current",
    "&": "expref",
    "|": "pipe",
    "!": "not",
    "<": "lt",
    ">": "gt",
    ",": "comma",
    ":": "colon",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    "[": "lbracket",
    "]": "rbracket",
    "?": "question",
}


class Token:
    __slots__ = ("type", "value", "pos", "error")

    def __init__(self, type_, value, pos, error=None):
        self.type = type_
        self.value = value
        self.pos = pos
        self.error = error

    def __repr__(self):  # pragma: no cover - debugging aid
        return f"Token({self.type!r}, {self.value!r}, {self.pos})"


def _reject_constant(name):
    raise ValueError("non-JSON constant " + name)


def literal_value(body: str):
    """Value of a backtick literal body (FP-05). Returns (value, ok)."""
    stripped = body.strip(_JSON_WS)
    try:
        return json.loads(stripped, parse_constant=_reject_constant), True
    except ValueError:
        pass
    # Not valid JSON: read as the content of a JSON string after leading whitespace.
    content = body.lstrip(_JSON_WS)
    try:
        return json.loads('"' + content + '"'), True
    except ValueError:
        return None, False


def _is_hex4(s: str) -> bool:
    return len(s) == 4 and all(ch in _HEX for ch in s)


def tokenize(text: str):
    toks = []
    n = len(text)
    i = 0

    def error(pos, message):
        toks.append(Token("error", None, pos, TokenSyntaxError(message, pos)))
        return toks

    while True:
        while i < n and text[i] in _WS:
            i += 1
        if i >= n:
            toks.append(Token("eof", None, n))
            return toks
        c = text[i]
        start = i

        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CHARS:
                j += 1
            toks.append(Token("ident", text[i:j], start))
            i = j
            continue

        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            toks.append(Token("num", int(text[i:j]), start))
            i = j
            continue

        if c == "-":
            return error(start, "a hyphen that does not begin a number begins no token")

        if c == '"':
            j = i + 1
            while j < n:
                ch = text[j]
                if ch == "\\":
                    j += 2
                    continue
                if ch == '"':
                    break
                j += 1
            if j >= n:
                return error(start, "unterminated quoted identifier")
            try:
                value = json.loads(text[i : j + 1])
            except ValueError:
                return error(start, "quoted identifier is not a legal JSON string")
            toks.append(Token("qident", value, start))
            i = j + 1
            continue

        if c == "'":
            j = i + 1
            buf = []
            closed = False
            while j < n:
                ch = text[j]
                if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                    buf.append("'")
                    j += 2
                    continue
                if ch == "\\" and text[j + 1 : j + 2] == "u" and _is_hex4(text[j + 2 : j + 6]):
                    buf.append(chr(int(text[j + 2 : j + 6], 16)))
                    j += 6
                    continue
                if ch == "'":
                    closed = True
                    break
                buf.append(ch)
                j += 1
            if not closed:
                return error(start, "unterminated raw string literal")
            toks.append(Token("raw", "".join(buf), start))
            i = j + 1
            continue

        if c == "`":
            j = i + 1
            while j < n:
                ch = text[j]
                if ch == "\\" and j + 1 < n:
                    j += 2
                    continue
                if ch == "`":
                    break
                j += 1
            if j >= n:
                return error(start, "unterminated JSON literal")
            body = text[i + 1 : j].replace("\\`", "`")
            value, ok = literal_value(body)
            if not ok:
                return error(start, "JSON literal is neither JSON nor JSON string content")
            toks.append(Token("lit", value, start))
            i = j + 1
            continue

        two = text[i : i + 2]
        if two in _TWO_CHAR:
            toks.append(Token(_TWO_CHAR[two], None, start))
            i += 2
            continue

        if c == "=":
            return error(start, "a lone '=' begins no token; equality is '=='")

        if c in _ONE_CHAR:
            toks.append(Token(_ONE_CHAR[c], None, start))
            i += 1
            continue

        return error(start, "character begins no token")
