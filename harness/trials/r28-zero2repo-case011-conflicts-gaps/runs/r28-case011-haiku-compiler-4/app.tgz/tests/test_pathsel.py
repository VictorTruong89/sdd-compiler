"""Tests for pathsel, named after the feature point they check (spec packs 06-13, 17-25).

Run from /app: python3 -m pytest -q tests
"""

import collections
import decimal
import os
import sys
from types import SimpleNamespace

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    Functions,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile,
    search,
    signature,
)

DOC = {
    "a": {"b": {"c": 1}},
    "arr": [1, [2, 3], 4],
    "people": [
        {"first": "J", "age": 3},
        {"first": "K", "age": 0},
        {"first": None, "age": 5},
    ],
    "o": {"x": {"y": 7}, "z": {"y": 8}},
    "n": None,
    "str": "abc",
    "ks": {"k1": [1, 2], "k2": [3]},
}


def s(expr, data=DOC, options=None):
    return search(expr, data, options)


# ---------------------------------------------------------------- FP-01 entries and refusals

def test_FP01_dotted_path_returns_nested_value():
    assert s("a.b.c") == 1


def test_FP01_missing_path_is_null_not_failure():
    assert s("a.missing.deep") is None


def test_FP01_compile_then_search_equals_one_shot():
    for expr in ["a.b.c", "people[*].first", "arr[-1]", "people[?age == `0`].first"]:
        assert compile(expr).search(DOC) == search(expr, DOC)


def test_FP01_parsed_expression_reused_on_many_documents():
    p = compile("a.v")
    assert p.search({"a": {"v": 1}}) == 1
    assert p.search({"a": {"v": 2}}) == 2
    assert p.search({}) is None


def test_FP01_compile_succeeds_when_search_is_null():
    compile("people[?nope == `1`].x")  # does not raise


def test_FP01_empty_expression_refused_on_both_entries():
    with pytest.raises(EmptyExpressionError):
        search("", DOC)
    with pytest.raises(EmptyExpressionError):
        compile("")


def test_FP01_whitespace_only_is_incomplete_not_empty():
    with pytest.raises(IncompleteExpressionError) as info:
        search("  \t\n\r", DOC)
    assert info.value.lex_position == 5


@pytest.mark.parametrize("expr", ["a |", "a ||", "a &&", "(a", "a[0", "a[", "!", "x == "])
def test_FP01_incomplete_expressions(expr):
    with pytest.raises(IncompleteExpressionError) as info:
        compile(expr)
    assert info.value.lex_position == len(expr)


@pytest.mark.parametrize("expr", ["foo.", "a..b", ".a", "a b", "a)", "}", "a[*]foo", "a.1"])
def test_FP01_syntax_failures(expr):
    with pytest.raises(PathSelSyntaxError) as info:
        compile(expr)
    assert isinstance(info.value.lex_position, int)
    assert 0 <= info.value.lex_position <= len(expr)


def test_FP01_positions_differ_at_different_offsets():
    with pytest.raises(PathSelSyntaxError) as first:
        compile("a..b")
    with pytest.raises(PathSelSyntaxError) as second:
        compile("foo bar")
    assert first.value.lex_position != second.value.lex_position


@pytest.mark.parametrize("expr", ["`1", "'abc", "\"abc", "a = b", "a-b", "#", '"\\x"'])
def test_FP01_token_level_failures_are_syntax_subclass(expr):
    with pytest.raises(TokenSyntaxError) as info:
        compile(expr)
    assert isinstance(info.value, PathSelSyntaxError)
    assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


def test_FP01_every_refusal_is_value_error():
    for expr in ["", " ", "a.", "`x", "a[0:1:0]", "nofunc()", "length()", "abs(`true`)"]:
        with pytest.raises(ValueError):
            s(expr)


def test_FP01_grammar_syntax_is_not_token_syntax():
    with pytest.raises(PathSelSyntaxError) as info:
        compile("a..b")
    assert not isinstance(info.value, TokenSyntaxError)


# ---------------------------------------------------------------- FP-02 identifiers

def test_FP02_unquoted_identifier_and_chain():
    assert s("a.b.c") == 1


def test_FP02_whitespace_between_tokens():
    assert s("a . b") == {"c": 1}
    assert s("a\t.\nb") == {"c": 1}


def test_FP02_quoted_identifier_names_any_key():
    data = {"a b": 1, "x.y": 2, "n-1": 3, "9": 4, 'q"uote': 5, "é": 6}
    assert s('"a b"', data) == 1
    assert s('"x.y"', data) == 2
    assert s('"n-1"', data) == 3
    assert s('"9"', data) == 4
    assert s('"q\\"uote"', data) == 5
    assert s('"\\u00e9"', data) == 6


def test_FP02_quoted_identifier_with_dot_is_one_key():
    assert s('"o.x"', {"o.x": 1, "o": {"x": 2}}) == 1


def test_FP02_identifier_on_array_is_null():
    assert s("arr.foo") is None


def test_FP02_number_after_dot_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("a.1")
    with pytest.raises(PathSelSyntaxError):
        compile("a.-1")


def test_FP02_hyphen_after_identifier_is_token_failure():
    with pytest.raises(TokenSyntaxError):
        compile("a-b")


def test_FP02_quoted_function_name_is_grammar_syntax():
    with pytest.raises(PathSelSyntaxError) as info:
        compile('"length"(@)')
    assert not isinstance(info.value, (UnknownFunctionError, InvalidArityError, InvalidTypeError))


def test_FP02_identifier_on_non_object_is_null():
    assert s("str.x") is None
    assert s("n.x") is None


# ---------------------------------------------------------------- FP-03 index, slice, flatten

def test_FP03_index_and_negative_index():
    assert s("arr[0]") == 1
    assert s("arr[-1]") == 4
    assert s("arr[3]") is None
    assert s("arr[-4]") is None


def test_FP03_index_on_non_array_is_null():
    assert s("str[0]") is None
    assert s("a[0]") is None


def test_FP03_slice_forms():
    assert s("arr[0:2]") == [1, [2, 3]]
    assert s("arr[1:]") == [[2, 3], 4]
    assert s("arr[:-1]") == [1, [2, 3]]
    assert s("arr[::2]") == [1, 4]
    assert s("arr[::-1]") == [4, [2, 3], 1]
    assert s("arr[-1:-10:-1]") == [4, [2, 3], 1]


def test_FP03_slice_selects_nothing_is_empty_array():
    assert s("arr[10:]") == []
    assert s("arr[2:1]") == []


def test_FP03_slice_on_non_array_is_null():
    assert s("str[0:1]") is None


def test_FP03_slice_zero_step_refused():
    with pytest.raises(ZeroSliceStepError):
        compile("arr[::0]")
    with pytest.raises(ZeroSliceStepError):
        search("arr[0:1:0]", DOC)


def test_FP03_slice_with_four_parts_or_non_integer_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("arr[0:1:2:3]")
    with pytest.raises(PathSelSyntaxError):
        compile("arr[a:1]")


def test_FP03_flatten_one_level():
    assert s("arr[]") == [1, 2, 3, 4]
    assert s("ks.*[]") == [1, 2, 3]


def test_FP03_flatten_of_non_array_is_null():
    assert s("str[]") is None


def test_FP03_slice_is_projection_dropping_nulls():
    assert s("people[0:2].first") == ["J", "K"]


# ---------------------------------------------------------------- FP-04 wildcards and filters

def test_FP04_list_wildcard_projects_and_drops_nulls():
    assert s("people[*].first") == ["J", "K"]
    assert s("arr[*].foo") == []


def test_FP04_list_wildcard_on_non_array_is_null():
    assert s("str[*]") is None
    assert s("n[*]") is None
    assert s("missing[*]") is None


def test_FP04_object_wildcard_projects_values():
    assert s("o.*.y") == [7, 8]
    assert s("ks.*[0]") == [1, 3]


def test_FP04_object_wildcard_on_non_object_is_null():
    assert s("arr.*") is None
    assert s("str.*") is None


def test_FP04_star_at_operand_start_projects_object_values():
    assert s("*.y", {"p": {"y": 1}, "q": {"y": 2}}) == [1, 2]


def test_FP04_nested_projection_inner_null_dropped():
    assert s("arr[*][0]") == [2]


def test_FP04_filter_keeps_true_values_in_order():
    # 0 is a true value, so every person is kept; the RHS drops the null first name
    assert s("people[?age].first") == ["J", "K"]
    assert s("people[?age == `0`]") == [{"first": "K", "age": 0}]
    assert s("people[?age].age") == [3, 0, 5]


def test_FP04_filter_on_non_array_is_null():
    assert s("str[?@]") is None


def test_FP04_filter_projection_applies_rhs():
    assert s("people[?age == `0`].first") == ["K"]


def test_FP04_filter_predicate_zero_is_true_null_is_false():
    data = {"xs": [{"v": 0}, {"v": None}, {}]}
    assert s("xs[?v].v", data) == [0]


def test_FP04_wildcard_followed_by_identifier_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("arr[*]foo")


def test_FP04_star_directly_after_identifier_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("a*")


def test_FP04_filter_ill_formed_predicate_refused():
    with pytest.raises(PathSelSyntaxError):
        compile("arr[?]")


def test_FP04_projection_rhs_joins_only_tighter_steps():
    # `.*` then `.y` begins the RHS; the following `.z` does not join, so it applies to the collected array
    assert s("o.*.y.z") is None
    assert s("people[*].age") == [3, 0, 5]


def test_FP04_flatten_applies_to_preceding_projection_result():
    assert s("people[*].age[]") == [3, 0, 5]


# ---------------------------------------------------------------- FP-05 constructs, pipe, literals

def test_FP05_multiselect_hash_stores_null():
    assert s("{x: a.b.c, y: missing}") == {"x": 1, "y": None}


def test_FP05_multiselect_list_stores_nulls():
    assert s("[a.b.c, missing]") == [1, None]


def test_FP05_multiselect_on_null_current_is_null():
    assert s("n.[a, b]") is None
    assert s("n.{a: a}") is None


def test_FP05_multiselect_after_projection_per_element():
    assert s("people[*].[first, age]") == [["J", 3], ["K", 0], [None, 5]]


def test_FP05_multiselect_list_as_first_step_of_projection_rhs():
    assert s("people[*][first, age]") == [["J", 3], ["K", 0], [None, 5]]


def test_FP05_multiselect_list_after_operand_without_dot_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("a[b, c]")


def test_FP05_pipe_passes_whole_result():
    assert s("people[*].age | length(@)") == 3
    assert s("a | b") == {"c": 1}


def test_FP05_pipe_binds_loosest():
    assert s("a.b | a") is None
    assert s("a.b | length(@)") == 1  # pipe is looser than the dot step
    assert s("`0` || `2` | @") == 0  # `||` binds tighter than the pipe; 0 is a true value


def test_FP05_current_value_token():
    assert s("@", {"k": 1}) == {"k": 1}
    assert s("people[*].age | @", DOC) == [3, 0, 5]


def test_FP05_json_literal_is_read_as_json():
    assert s("`1`") == 1
    assert s("`[1, 2]`") == [1, 2]
    assert s("`true`") is True
    assert s("`null`") is None
    assert s("`{\"x\": 1}`.x") == 1


def test_FP05_json_literal_fallback_to_string_content():
    assert s("`abc`") == "abc"
    assert s("`  abc def`") == "abc def"


def test_FP05_unreadable_json_literal_is_token_failure():
    with pytest.raises(TokenSyntaxError):
        compile('`"`')


def test_FP05_literal_directly_after_dot_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        compile("a.`1`")


def test_FP05_raw_string_literal():
    assert s("'hello'") == "hello"
    assert s("'it\\'s'") == "it's"
    assert s("'123'") == "123"
    assert s("'a\\nb'") == "a\\nb"


def test_FP05_raw_string_unicode_escape_decoded():
    assert s("'a\\u0041'") == "aA"


def test_FP05_unclosed_raw_string_is_token_failure():
    with pytest.raises(TokenSyntaxError):
        compile("'abc")


def test_FP05_expression_reference_alone_is_not_null():
    assert s("&a") is not None


def test_FP05_multiselect_missing_closer_is_refused():
    with pytest.raises(IncompleteExpressionError):
        compile("[a, b")
    with pytest.raises(PathSelSyntaxError):
        compile("{a: 1,}")


# ---------------------------------------------------------------- FP-06 comparisons and logic

def test_FP06_equality_is_json_equality():
    assert s("`1` == `1.0`") is True
    assert s("`1` == `true`") is False
    assert s("`0` == `false`") is False
    assert s("`[1, {\"a\": 2}]` == `[1, {\"a\": 2}]`") is True
    assert s("`[1]` != `[2]`") is True


def test_FP06_ordering_numbers_and_strings():
    assert s("`1` < `2`") is True
    assert s("`\"a\"` < `\"b\"`") is True
    assert s("`2` >= `2`") is True


def test_FP06_ordering_across_types_is_null():
    assert s("`1` < `\"b\"`") is None


def test_FP06_or_and_return_operands():
    assert s("`0` || `2`") == 0
    assert s("`null` || `2`") == 2
    assert s("`0` && `2`") == 2
    assert s("`[]` && `2`") == []


def test_FP06_not_returns_boolean():
    assert s("!`0`") is False
    assert s("!`null`") is True
    assert s("!`[]`") is True


def test_FP06_negation_binds_tighter_than_comparison():
    assert s("!`false` == `true`") is True


def test_FP06_dot_after_negation_applies_to_result():
    assert s("!a.b") is None  # (!a).b : a boolean has no fields


def test_FP06_negated_bracket_operand_is_grouped():
    assert s("!people[0].age") is None
    assert s("!people[*].age") is False


def test_FP06_lone_equals_and_lone_ampersand_fail():
    with pytest.raises(TokenSyntaxError):
        compile("a = b")
    with pytest.raises(PathSelSyntaxError):
        compile("a & b")


def test_FP06_missing_side_of_logic_is_refused():
    with pytest.raises(IncompleteExpressionError):
        compile("a &&")


# ---------------------------------------------------------------- FP-07 built-in functions

@pytest.mark.parametrize(
    "expr,expected",
    [
        ("abs(`-3`)", 3),
        ("avg(`[1, 2, 3]`)", 2),
        ("avg(`[]`)", None),
        ("ceil(`1.2`)", 2),
        ("floor(`1.7`)", 1),
        ("contains(`[1, 2]`, `2`)", True),
        ("contains(`\"abc\"`, `\"b\"`)", True),
        ("ends_with(`\"abc\"`, `\"bc\"`)", True),
        ("starts_with(`\"abc\"`, `\"ab\"`)", True),
        ("length(`\"héllo\"`)", 5),
        ("length(`[1, 2]`)", 2),
        ("length(`{\"a\": 1}`)", 1),
        ("reverse(`\"abc\"`)", "cba"),
        ("reverse(`[1, 2]`)", [2, 1]),
        ("join(`\",\"`, `[\"a\", \"b\"]`)", "a,b"),
        ("join(`\",\"`, `[]`)", None),
        ("keys(`{\"a\": 1, \"b\": 2}`)", ["a", "b"]),
        ("values(`{\"a\": 1, \"b\": 2}`)", [1, 2]),
        ("type(`1`)", "number"),
        ("type(`\"s\"`)", "string"),
        ("type(`true`)", "boolean"),
        ("type(`[]`)", "array"),
        ("type(`{}`)", "object"),
        ("type(`null`)", "null"),
        ("to_array(`1`)", [1]),
        ("to_array(`[1]`)", [1]),
        ("to_string(`\"s\"`)", "s"),
        ("to_string(`[1,2]`)", "[1,2]"),
        ("to_string(`{\"a\":\"é\"}`)", '{"a":"\\u00e9"}'),
        ("to_number(`\"12\"`)", 12),
        ("to_number(`\"1.5\"`)", 1.5),
        ("to_number(`\"1e3\"`)", 1000.0),
        ("to_number(`\"x\"`)", None),
        ("to_number(`true`)", None),
        ("max(`[1, 3, 2]`)", 3),
        ("min(`[\"b\", \"a\"]`)", "a"),
        ("max(`[]`)", None),
        ("sort(`[3, 1, 2]`)", [1, 2, 3]),
        ("sum(`[1, 2.5]`)", 3.5),
        ("merge(`{\"a\": 1}`, `{\"a\": 2, \"b\": 3}`)", {"a": 2, "b": 3}),
        ("not_null(`null`, `\"x\"`, `1`)", "x"),
        ("not_null(`null`)", None),
        ("map(&a.b, `[{\"a\": {\"b\": 1}}, {}]`)", [1, None]),
        ("sort_by(`[{\"v\": 2}, {\"v\": 1}]`, &v)", [{"v": 1}, {"v": 2}]),
        ("max_by(`[{\"v\": 2}, {\"v\": 9}, {\"v\": 9}]`, &v)", {"v": 9}),
        ("min_by(`[{\"v\": 2}, {\"v\": 1}]`, &v)", {"v": 1}),
        ("max_by(`[]`, &v)", None),
    ],
)
def test_FP07_builtin_results(expr, expected):
    assert s(expr) == expected


def test_FP07_names_are_exact_set():
    from pathsel.builtins import BUILTINS

    assert set(BUILTINS) == {
        "abs", "avg", "ceil", "contains", "ends_with", "floor", "join", "keys", "length",
        "map", "max", "max_by", "merge", "min", "min_by", "not_null", "reverse", "sort",
        "sort_by", "starts_with", "sum", "to_array", "to_number", "to_string", "type", "values",
    }


def test_FP07_unknown_function_refused_at_search_not_compile():
    compile("nosuch(@)")
    with pytest.raises(UnknownFunctionError):
        search("nosuch(@)", DOC)


def test_FP07_arity_checked_at_search():
    compile("abs()")
    with pytest.raises(InvalidArityError):
        search("abs()", DOC)
    with pytest.raises(InvalidArityError):
        search("abs(`1`, `2`)", DOC)
    with pytest.raises(InvalidArityError):
        search("merge()", DOC)
    with pytest.raises(InvalidArityError):
        search("not_null()", DOC)


def test_FP07_variadic_functions_accept_many_arguments():
    assert s("not_null(`null`, `null`, `3`)") == 3
    assert s("merge(`{\"a\": 1}`, `{\"b\": 2}`, `{\"c\": 3}`)") == {"a": 1, "b": 2, "c": 3}


@pytest.mark.parametrize(
    "expr",
    [
        "abs(`true`)",
        "abs(`\"1\"`)",
        "avg(`[1, \"a\"]`)",
        "contains(`1`, `1`)",
        "contains(`\"abc\"`, `1`)",
        "length(`1`)",
        "keys(`[1]`)",
        "join(`\"-\"`, `[1]`)",
        "max(`[1, \"a\"]`)",
        "sort_by(`[{\"v\": 1}, {\"v\": \"a\"}]`, &v)",
        "map(a, `[1]`)",
        "sort_by(`[{\"v\": null}]`, &v)",
        "reverse(missing)",
        "abs(missing)",
    ],
)
def test_FP07_invalid_type(expr):
    with pytest.raises(InvalidTypeError):
        search(expr, DOC)


def test_FP07_expression_reference_as_value_argument_is_invalid_type():
    with pytest.raises(InvalidTypeError):
        search("map(`[1]`, `[1]`)", DOC)


def test_FP07_projection_as_function_argument():
    assert s("length(people[*].first)") == 2


def test_FP07_function_as_projection_rhs():
    assert s("people[*].length(@)") == [2, 2, 2]  # each person object has two keys
    assert s("ks.*.length(@)") == [2, 1]


def test_FP07_quoted_identifier_cannot_be_called():
    with pytest.raises(PathSelSyntaxError):
        compile('"abs"(`1`)')


# ---------------------------------------------------------------- FP-08 options and providers

def test_FP08_mapping_type_applies_to_constructed_hash():
    opts = SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
    result = search("{x: a.b.c}", DOC, opts)
    assert isinstance(result, collections.OrderedDict)
    assert result == {"x": 1}


def test_FP08_constructed_hash_treated_as_object_by_field_selection():
    opts = SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
    assert search("{x: a.b.c}.x", DOC, opts) == 1
    assert search("keys({x: a.b.c})", DOC, opts) == ["x"]


def test_FP08_mapping_type_without_options_is_ordinary_dict():
    assert type(search("{x: `1`}", DOC)) is dict


def test_FP08_one_shot_and_compiled_agree_with_options():
    opts = SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=Functions())
    expr = "{x: a.b.c}"
    assert search(expr, DOC, opts) == compile(expr).search(DOC, opts)


class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["string", "null"]})
    def _func_double(self, n, tag):
        return [n * 2] if tag is None else [n * 2, tag]

    @signature()
    def _func_zero(self):
        return 0

    @signature({"types": ["array"]})
    def _func_first_or_empty(self, xs):
        return xs[0] if xs else []


def _opts(extra=None):
    return SimpleNamespace(dict_cls=None, custom_functions=Provider())


def test_FP08_custom_function_called_with_evaluated_args():
    assert search("double(a, `null`)", {"a": 3}, _opts()) == [6]
    assert search("double(a, `\"t\"`)", {"a": 3}, _opts()) == [6, "t"]


def test_FP08_custom_function_return_value_including_zero():
    assert search("zero()", {}, _opts()) == 0


def test_FP08_custom_function_arity_and_type_errors():
    with pytest.raises(InvalidArityError):
        search("double(`1`)", {}, _opts())
    with pytest.raises(InvalidTypeError):
        search("double(`\"x\"`, `null`)", {}, _opts())
    with pytest.raises(InvalidTypeError):
        search("first_or_empty(`true`)", {}, _opts())


def test_FP08_custom_function_missing_without_provider_is_unknown():
    compile("double(`1`, `null`)")
    with pytest.raises(UnknownFunctionError):
        search("double(`1`, `null`)", {}, None)


def test_FP08_provider_does_not_change_builtins():
    assert search("length(`\"ab\"`)", {}, _opts()) == 2


def test_FP08_compile_naming_custom_function_succeeds_without_provider():
    compile("double(a, `null`)")


def test_FP08_signature_does_not_call_implementation():
    calls = []

    def impl(self, n):
        calls.append(n)
        return n

    decorated = signature({"types": ["number"]})(impl)
    assert calls == []
    assert callable(decorated)


def test_FP08_signature_rejects_unknown_type_name():
    with pytest.raises(TypeError):
        signature({"types": ["boolean"]})


# ---------------------------------------------------------------- non-goals / constraints

def test_NFR_input_document_not_mutated():
    import copy

    doc = copy.deepcopy(DOC)
    s("people[*].first | length(@)", doc)
    s("sort_by(people[?age], &age)", doc)
    s("merge(a, o)", doc)
    assert doc == DOC


def test_NFR_decimal_numbers_are_numbers_for_comparison():
    data = {"x": decimal.Decimal("2.5")}
    assert s("x > `2`", data) is True
    assert s("type(x)", data) == "number"


def test_NFR_host_non_json_values_selected_and_returned():
    marker = object()
    assert s("v", {"v": marker}) is marker


def test_NFR_ints_and_floats_compare_by_value():
    assert s("`2` == `2.0`") is True


def test_pathsel_root_exposes_entries():
    assert callable(pathsel.search)
    assert callable(pathsel.compile)


def test_FP24_refusal_kinds_are_distinct_types():
    from pathsel import UnknownFunctionError as U

    kinds = [EmptyExpressionError, IncompleteExpressionError, PathSelSyntaxError,
             ZeroSliceStepError, U, InvalidArityError, InvalidTypeError]
    for kind in kinds:
        assert issubclass(kind, ValueError)
    # token-level syntax is a subclass of syntax, but not of empty or incomplete
    assert issubclass(TokenSyntaxError, PathSelSyntaxError)
    assert not issubclass(TokenSyntaxError, (EmptyExpressionError, IncompleteExpressionError))
    # function-call kinds are not instances of each other or of syntax
    for a in (U, InvalidArityError, InvalidTypeError):
        for b in (U, InvalidArityError, InvalidTypeError):
            if a is not b:
                assert not issubclass(a, b)
        assert not issubclass(a, PathSelSyntaxError)


def test_FP24_lex_position_is_int_within_expression():
    for expr in ["a..b", "a |", "a b", "`x"]:
        with pytest.raises(ValueError) as info:
            compile(expr)
        pos = info.value.lex_position
        assert isinstance(pos, int)
        assert 0 <= pos <= len(expr)


def test_FP25_expression_reference_value_is_not_none():
    assert search("&a.b", DOC) is not None
