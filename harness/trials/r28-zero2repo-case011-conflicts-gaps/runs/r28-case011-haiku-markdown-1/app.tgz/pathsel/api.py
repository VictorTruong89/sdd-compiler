"""Public entry points: :func:`search` (one shot) and :func:`compile`
(parse once, search many times). Both produce the same results and refusals.
"""

from . import values as V
from .nodes import Context
from .parser import parse


class ParsedExpression:
    """A compiled PathSel expression. Returned by :func:`compile`."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return _run(self._node, value, options)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def _check_text(expression):
    if not isinstance(expression, str):
        raise TypeError("expression must be a str, not %s" % type(expression).__name__)


def _run(node, data, options):
    dict_cls = None
    provider = None
    if options is not None:
        dict_cls = getattr(options, "dict_cls", None)
        provider = getattr(options, "custom_functions", None)
    context = Context(dict_cls, provider)
    token = V.set_object_types(dict_cls)
    try:
        return node.evaluate(data, context)
    finally:
        V.reset_object_types(token)


def compile(expression):
    """Parse ``expression`` once; returns a :class:`ParsedExpression`."""
    _check_text(expression)
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` and return the selected value."""
    _check_text(expression)
    return _run(parse(expression), data, options)
