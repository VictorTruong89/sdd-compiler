"""Pratt parser for PathSel.

Binding powers (loosest to tightest): pipe 1, ``||`` 2, ``&&`` 3, comparators 5,
flatten 9, wildcard/slice 20, filter 21, dot 40, ``!`` 45, multiselect hash 50,
bracket 55, call 60. A projection's right-hand side takes the steps that rank
tighter than the projection itself (FP-04); the first step after the
projection always joins.
"""

from . import nodes as N
from .errors import EmptyExpressionError, ExpressionSyntaxError, IncompleteExpressionError
from .lexer import tokenize


BINDING_POWER = {
    "eof": 0,
    "unquoted_identifier": 0,
    "quoted_identifier": 0,
    "number": 0,
    "literal": 0,
    "raw_string": 0,
    "current": 0,
    "expref": 0,
    "rbracket": 0,
    "rparen": 0,
    "rbrace": 0,
    "comma": 0,
    "colon": 0,
    "pipe": 1,
    "or": 2,
    "and": 3,
    "eq": 5,
    "ne": 5,
    "lt": 5,
    "lte": 5,
    "gt": 5,
    "gte": 5,
    "flatten": 9,
    "star": 20,
    "filter": 21,
    "dot": 40,
    "not": 45,
    "lbrace": 50,
    "lbracket": 55,
    "lparen": 60,
}

PROJECTION_STOP = 10
_COMPARATORS = frozenset(["eq", "ne", "lt", "lte", "gt", "gte"])
_IDENTIFIER_TOKENS = frozenset(["unquoted_identifier", "quoted_identifier"])
_DOT_OPERAND_TOKENS = frozenset(["unquoted_identifier", "quoted_identifier", "star", "lbrace", "lbracket"])


class _Parser:
    def __init__(self, tokens):
        self._tokens = tokens
        self._pos = 0

    # -- token access -----------------------------------------------------

    def _peek(self, ahead=0):
        index = min(self._pos + ahead, len(self._tokens) - 1)
        return self._tokens[index]

    def _advance(self):
        token = self._tokens[self._pos]
        if token.type != "eof":
            self._pos += 1
        return token

    def _expect(self, token_type):
        token = self._peek()
        if token.type != token_type:
            self._fail(token)
        return self._advance()

    def _fail(self, token):
        """Raise incomplete at end of text, otherwise a grammar-level syntax error."""
        if token.type == "eof":
            raise IncompleteExpressionError(
                "expression is incomplete at position %d" % token.start, token.start)
        self._syntax(token)

    def _syntax(self, token):
        raise ExpressionSyntaxError(
            "syntax error at position %d (%s)" % (token.start, token.type), token.start)

    # -- Pratt core -------------------------------------------------------

    def expression(self, rbp):
        token = self._advance()
        left = self._nud(token)
        while rbp < BINDING_POWER[self._peek().type]:
            token = self._advance()
            left = self._led(token, left)
        return left

    def _nud(self, token):
        kind = token.type
        if kind == "unquoted_identifier":
            if self._peek().type == "lparen":
                return self._function_call(token.value)
            return N.Field(token.value)
        if kind == "quoted_identifier":
            return N.Field(token.value)
        if kind == "current":
            return N.Identity()
        if kind in ("literal", "raw_string"):
            return N.Literal(token.value)
        if kind == "star":
            return N.ValueProjection(N.Identity(), self._projection_rhs(20))
        if kind == "flatten":
            return N.Projection(N.Flatten(N.Identity()), self._projection_rhs(9))
        if kind == "filter":
            return self._filter(N.Identity())
        if kind == "lbracket":
            return self._bracket_nud()
        if kind == "lbrace":
            return self._multi_hash()
        if kind == "lparen":
            node = self.expression(0)
            self._expect("rparen")
            return node
        if kind == "expref":
            return N.ExpressionRef(self.expression(0))
        if kind == "not":
            return N.Not(self.expression(45))
        self._fail(token)

    def _led(self, token, left):
        kind = token.type
        if kind == "dot":
            if self._peek().type == "star":
                self._advance()
                return N.ValueProjection(left, self._projection_rhs(40))
            return N.Subexpression(left, self._dot_operand(40))
        if kind == "lbracket":
            return self._bracket_led(left)
        if kind == "flatten":
            return N.Projection(N.Flatten(left), self._projection_rhs(9))
        if kind == "filter":
            return self._filter(left)
        if kind == "pipe":
            return N.Pipe(left, self.expression(1))
        if kind == "or":
            return N.Or(left, self.expression(2))
        if kind == "and":
            return N.And(left, self.expression(3))
        if kind in _COMPARATORS:
            return N.Comparison(kind, left, self.expression(5))
        self._syntax(token)

    # -- brackets, filters, multiselects ----------------------------------

    def _bracket_nud(self):
        """After ``[`` at the start of an operand: index, slice, wildcard or multiselect."""
        token = self._peek()
        if token.type in ("number", "colon"):
            return self._index_or_slice(N.Identity())
        if token.type == "star" and self._peek(1).type == "rbracket":
            self._advance()
            self._advance()
            return N.Projection(N.Identity(), self._projection_rhs(20))
        return self._multi_list()

    def _bracket_led(self, left):
        """After ``[`` following an operand: only index, slice or wildcard are allowed."""
        token = self._peek()
        if token.type in ("number", "colon"):
            return self._index_or_slice(left)
        if token.type == "star":
            self._advance()
            self._expect("rbracket")
            return N.Projection(left, self._projection_rhs(20))
        self._fail(token)

    def _index_or_slice(self, left):
        """After ``[``: parse ``[n]`` or ``[start:stop:step]`` and consume ``]``."""
        parts = [None, None, None]
        part = 0
        has_colon = False
        while True:
            token = self._peek()
            if token.type == "rbracket":
                break
            if token.type == "colon":
                has_colon = True
                part += 1
                if part > 2:
                    self._syntax(token)
                self._advance()
            elif token.type == "number":
                if parts[part] is not None:
                    self._syntax(token)
                parts[part] = token.value
                self._advance()
            else:
                self._fail(token)
        self._advance()
        if not has_colon:
            return N.Subexpression(left, N.Index(parts[0]))
        slice_node = N.Slice(parts[0], parts[1], parts[2])
        return N.Projection(N.Subexpression(left, slice_node), self._projection_rhs(20))

    def _multi_list(self):
        """After ``[`` of a multiselect list: comma-separated expressions then ``]``."""
        items = []
        while True:
            items.append(self.expression(0))
            token = self._peek()
            if token.type == "comma":
                self._advance()
                continue
            if token.type == "rbracket":
                self._advance()
                return N.MultiList(items)
            self._fail(token)

    def _multi_hash(self):
        """After ``{`` of a multiselect hash: ``key: expr`` pairs then ``}``."""
        pairs = []
        while True:
            key = self._advance()
            if key.type not in _IDENTIFIER_TOKENS:
                self._fail(key)
            self._expect("colon")
            pairs.append((key.value, self.expression(0)))
            token = self._peek()
            if token.type == "comma":
                self._advance()
                continue
            if token.type == "rbrace":
                self._advance()
                return N.MultiHash(pairs)
            self._fail(token)

    def _filter(self, left):
        """After ``[?``: predicate, ``]``, then the projection right-hand side."""
        predicate = self.expression(0)
        self._expect("rbracket")
        return N.FilterProjection(left, predicate, self._projection_rhs(21))

    def _function_call(self, name):
        """At ``(`` after a function name: comma-separated arguments then ``)``."""
        self._advance()
        args = []
        if self._peek().type == "rparen":
            self._advance()
            return N.FunctionCall(name, args)
        while True:
            args.append(self.expression(0))
            token = self._peek()
            if token.type == "comma":
                self._advance()
                continue
            if token.type == "rparen":
                self._advance()
                return N.FunctionCall(name, args)
            self._fail(token)

    # -- dots and projections ---------------------------------------------

    def _dot_operand(self, bp):
        """The step after a dot: identifier, wildcard, multiselect list or hash."""
        token = self._peek()
        if token.type == "eof":
            # A dot followed by the end of the text is a syntax failure.
            self._syntax(token)
        if token.type not in _DOT_OPERAND_TOKENS:
            self._syntax(token)
        if token.type == "lbracket":
            after = self._peek(1)
            if after.type in ("number", "colon"):
                self._syntax(after)
            if after.type == "star" and self._peek(2).type == "rbracket":
                self._syntax(after)
        return self.expression(bp)

    def _projection_rhs(self, bp):
        """Right-hand side of a projection whose own binding power is ``bp``."""
        token = self._peek()
        if BINDING_POWER[token.type] < PROJECTION_STOP:
            return N.Identity()
        if token.type in ("lbracket", "filter"):
            return self.expression(bp)
        if token.type == "dot":
            self._advance()
            return self._dot_operand(bp)
        self._fail(token)


def parse(text):
    """Parse expression text into an AST node, or raise a refusal."""
    if text == "":
        raise EmptyExpressionError("empty expression")
    parser = _Parser(tokenize(text))
    node = parser.expression(0)
    token = parser._peek()
    if token.type != "eof":
        parser._fail(token)
    return node
