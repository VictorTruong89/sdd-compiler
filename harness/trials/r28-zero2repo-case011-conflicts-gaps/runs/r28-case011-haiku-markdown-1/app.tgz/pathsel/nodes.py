"""AST nodes for PathSel and their evaluation.

Every node has ``evaluate(value, context)``; ``value`` is the current value and
``context`` is a :class:`Context` for the search in progress.
"""

import copy
import operator

from . import values as V
from .errors import (
    InvalidArityError,
    InvalidTypeError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import function_table
from .values import ExpressionReference


class Context:
    """Per-search state: the object constructor and the function provider."""

    __slots__ = ("dict_cls", "provider", "_table")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider
        self._table = None

    def new_object(self):
        return self.dict_cls() if self.dict_cls is not None else {}

    def functions(self):
        if self._table is None:
            self._table = function_table(self.provider)
        return self._table


class Node:
    __slots__ = ()

    def evaluate(self, value, context):
        raise NotImplementedError


def _project(items, rhs, context):
    """Apply ``rhs`` to each item, collecting non-null results."""
    out = []
    for item in items:
        result = rhs.evaluate(item, context)
        if result is not None:
            out.append(result)
    return out


def _slice_list(items, start, stop, step):
    n = len(items)
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, 0), n)
        e = min(max(e, 0), n)
        return [items[i] for i in range(s, e, step)]
    s = n - 1 if start is None else (start + n if start < 0 else start)
    e = -1 if stop is None else (stop + n if stop < 0 else stop)
    s = min(max(s, -1), n - 1)
    e = min(max(e, -1), n - 1)
    return [items[i] for i in range(s, e, step)]


class Identity(Node):
    __slots__ = ()

    def evaluate(self, value, context):
        return value


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, context):
        if isinstance(self.value, (dict, list)):
            return copy.deepcopy(self.value)
        return self.value


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, context):
        if V.is_object(value):
            try:
                if self.name in value:
                    return value[self.name]
            except TypeError:
                pass
        return None


class Index(Node):
    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def evaluate(self, value, context):
        if V.is_array(value):
            n = len(value)
            if -n <= self.index < n:
                return value[self.index]
        return None


class Slice(Node):
    __slots__ = ("start", "stop", "step")

    def __init__(self, start, stop, step):
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, value, context):
        step = 1 if self.step is None else self.step
        if step == 0:
            raise ZeroSliceStepError("slice step must not be zero")
        if not V.is_array(value):
            return None
        return _slice_list(value, self.start, self.stop, step)


class Flatten(Node):
    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, context):
        base = self.node.evaluate(value, context)
        if not V.is_array(base):
            return None
        out = []
        for element in base:
            if V.is_array(element):
                out.extend(element)
            else:
                out.append(element)
        return out


class Subexpression(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        return self.right.evaluate(self.left.evaluate(value, context), context)


class Projection(Node):
    """List projection: ``source`` must be an array; ``rhs`` runs per element."""

    __slots__ = ("source", "rhs")

    def __init__(self, source, rhs):
        self.source = source
        self.rhs = rhs

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not V.is_array(base):
            return None
        return _project(base, self.rhs, context)


class ValueProjection(Node):
    """Object wildcard: ``source`` must be an object; ``rhs`` runs per value."""

    __slots__ = ("source", "rhs")

    def __init__(self, source, rhs):
        self.source = source
        self.rhs = rhs

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not V.is_object(base):
            return None
        return _project([base[key] for key in base], self.rhs, context)


class FilterProjection(Node):
    __slots__ = ("source", "predicate", "rhs")

    def __init__(self, source, predicate, rhs):
        self.source = source
        self.predicate = predicate
        self.rhs = rhs

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not V.is_array(base):
            return None
        kept = [item for item in base
                if not V.is_false(self.predicate.evaluate(item, context))]
        return _project(kept, self.rhs, context)


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, context):
        if value is None:
            return None
        return [item.evaluate(value, context) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, context):
        if value is None:
            return None
        obj = context.new_object()
        for key, node in self.pairs:
            obj[key] = node.evaluate(value, context)
        return obj


class Pipe(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        return self.right.evaluate(self.left.evaluate(value, context), context)


_ORDERING = {
    "lt": operator.lt,
    "lte": operator.le,
    "gt": operator.gt,
    "gte": operator.ge,
}


class Comparison(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        right = self.right.evaluate(value, context)
        if self.op == "eq":
            return V.equal(left, right)
        if self.op == "ne":
            return not V.equal(left, right)
        return V.compare(_ORDERING[self.op], left, right)


class Not(Node):
    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, context):
        return V.is_false(self.node.evaluate(value, context))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        if V.is_false(left):
            return left
        return self.right.evaluate(value, context)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        if not V.is_false(left):
            return left
        return self.right.evaluate(value, context)


class ExpressionRef(Node):
    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, context):
        return ExpressionReference(self.node, context)


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, context):
        entry = context.functions().get(self.name)
        if entry is None:
            raise UnknownFunctionError("unknown function %r" % self.name)
        spec = entry.signature
        count = len(self.args)
        if spec and spec[-1]["repeat"]:
            arity_ok = count >= len(spec)
        else:
            arity_ok = count == len(spec)
        if not arity_ok:
            raise InvalidArityError(
                "function %r takes %d arguments, got %d" % (self.name, len(spec), count))
        args = [arg.evaluate(value, context) for arg in self.args]
        for index, arg_value in enumerate(args):
            param = spec[min(index, len(spec) - 1)]
            if not any(V.matches_type(arg_value, t) for t in param["types"]):
                raise InvalidTypeError(
                    "argument %d of %r has an invalid type" % (index + 1, self.name))
        return entry.impl(*args)
