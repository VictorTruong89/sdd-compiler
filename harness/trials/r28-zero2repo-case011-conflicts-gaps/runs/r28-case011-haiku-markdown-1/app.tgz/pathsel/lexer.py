"""Tokenizer for the PathSel language.

The whole text is tokenized before parsing, so a token-level failure anywhere
in the text is reported in preference to a grammar-level failure.
"""

import json
import re

from .errors import TokenSyntaxError


_WHITESPACE = frozenset(" \t\n\r")
_DIGITS = frozenset("0123456789")
_IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT_CHAR = _IDENT_START | _DIGITS

_SIMPLE = {
    ".": "dot",
    "*": "star",
    "]": "rbracket",
    "(": "lparen",
    ")": "rparen",
    "{": "lbrace",
    "}": "rbrace",
    ",": "comma",
    ":": "colon",
    "@": "current",
}

_UNICODE_ESCAPE = re.compile(r"\\u([0-9a-fA-F]{4})")


class Token:
    __slots__ = ("type", "value", "start")

    def __init__(self, type_, value, start):
        self.type = type_
        self.value = value
        self.start = start

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.type, self.value, self.start)


def _token_error(start, what):
    return TokenSyntaxError("%s at position %d" % (what, start), start)


def _decode_raw_unicode(text):
    """Decode ``\\uXXXX`` escapes in a raw string literal (surrogate pairs too)."""
    if "\\u" not in text:
        return text
    text = _UNICODE_ESCAPE.sub(lambda m: chr(int(m.group(1), 16)), text)
    try:
        return text.encode("utf-16-le", "surrogatepass").decode("utf-16-le")
    except UnicodeDecodeError:
        return text


def tokenize(text):
    """Split ``text`` into tokens, ending with an ``eof`` token at ``len(text)``."""
    tokens = []
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        if ch in _WHITESPACE:
            i += 1
            continue
        start = i
        nxt = text[i + 1] if i + 1 < n else ""

        if ch in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CHAR:
                j += 1
            tokens.append(Token("unquoted_identifier", text[i:j], start))
            i = j
        elif ch in _DIGITS or (ch == "-" and nxt in _DIGITS and nxt != ""):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token("number", int(text[i:j]), start))
            i = j
        elif ch == "-":
            raise _token_error(start, "unexpected '-'")
        elif ch == "[":
            if nxt == "]":
                tokens.append(Token("flatten", "[]", start))
                i += 2
            elif nxt == "?":
                tokens.append(Token("filter", "[?", start))
                i += 2
            else:
                tokens.append(Token("lbracket", "[", start))
                i += 1
        elif ch == "|":
            if nxt == "|":
                tokens.append(Token("or", "||", start))
                i += 2
            else:
                tokens.append(Token("pipe", "|", start))
                i += 1
        elif ch == "&":
            if nxt == "&":
                tokens.append(Token("and", "&&", start))
                i += 2
            else:
                tokens.append(Token("expref", "&", start))
                i += 1
        elif ch == "<":
            if nxt == "=":
                tokens.append(Token("lte", "<=", start))
                i += 2
            else:
                tokens.append(Token("lt", "<", start))
                i += 1
        elif ch == ">":
            if nxt == "=":
                tokens.append(Token("gte", ">=", start))
                i += 2
            else:
                tokens.append(Token("gt", ">", start))
                i += 1
        elif ch == "=":
            if nxt == "=":
                tokens.append(Token("eq", "==", start))
                i += 2
            else:
                raise _token_error(start, "lone '=' (equality is '==')")
        elif ch == "!":
            if nxt == "=":
                tokens.append(Token("ne", "!=", start))
                i += 2
            else:
                tokens.append(Token("not", "!", start))
                i += 1
        elif ch == '"':
            i = _quoted_identifier(text, i, tokens)
        elif ch == "'":
            i = _raw_string(text, i, tokens)
        elif ch == "`":
            i = _json_literal(text, i, tokens)
        elif ch in _SIMPLE:
            tokens.append(Token(_SIMPLE[ch], ch, start))
            i += 1
        else:
            raise _token_error(start, "unexpected character %r" % ch)
    tokens.append(Token("eof", None, n))
    return tokens


def _quoted_identifier(text, start, tokens):
    n = len(text)
    j = start + 1
    while True:
        if j >= n:
            raise _token_error(start, "unterminated quoted identifier")
        c = text[j]
        if c == "\\":
            j += 2
            continue
        if c == '"':
            break
        j += 1
    try:
        value = json.loads(text[start:j + 1])
    except ValueError:
        raise _token_error(start, "quoted identifier is not a valid JSON string")
    tokens.append(Token("quoted_identifier", value, start))
    return j + 1


def _raw_string(text, start, tokens):
    n = len(text)
    j = start + 1
    buf = []
    while True:
        if j >= n:
            raise _token_error(start, "unterminated raw string literal")
        c = text[j]
        if c == "\\" and j + 1 < n and text[j + 1] == "'":
            buf.append("'")
            j += 2
            continue
        if c == "'":
            break
        buf.append(c)
        j += 1
    tokens.append(Token("raw_string", _decode_raw_unicode("".join(buf)), start))
    return j + 1


def _json_literal(text, start, tokens):
    n = len(text)
    j = start + 1
    buf = []
    while True:
        if j >= n:
            raise _token_error(start, "unterminated JSON literal")
        c = text[j]
        if c == "\\" and j + 1 < n and text[j + 1] == "`":
            buf.append("`")
            j += 2
            continue
        if c == "`":
            break
        buf.append(c)
        j += 1
    body = "".join(buf)
    try:
        value = json.loads(body)
    except ValueError:
        try:
            value = json.loads('"' + body.lstrip() + '"')
        except ValueError:
            raise _token_error(start, "JSON literal is neither JSON nor a JSON string body")
    tokens.append(Token("literal", value, start))
    return j + 1
