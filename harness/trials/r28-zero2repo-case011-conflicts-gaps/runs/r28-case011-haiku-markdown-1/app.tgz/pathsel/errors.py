"""Refusal kinds raised by pathsel.

Every refusal is an instance of ``PathSelError``, which is a ``ValueError``.
The kind of a refusal is carried by the exception type:

* ``EmptyExpressionError``      - the expression text has zero length.
* ``IncompleteExpressionError`` - the text ends where more text is required.
* ``ExpressionSyntaxError``     - grammar-level syntax failure.
* ``TokenSyntaxError``          - token-level syntax failure (a subclass of
                                  ``ExpressionSyntaxError``).
* ``ZeroSliceStepError``        - a slice whose step is 0 was evaluated.
* ``UnknownFunctionError``      - the called name is not a known function.
* ``InvalidArityError``         - wrong number of function arguments.
* ``InvalidTypeError``          - a function argument has an unaccepted type.

Syntax and incomplete-expression refusals carry ``lex_position``, an ``int``
offset into the expression text.
"""


class PathSelError(ValueError):
    """Base class of every pathsel refusal."""

    lex_position = None


class EmptyExpressionError(PathSelError):
    """The expression text is zero-length."""

    lex_position = 0


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class ExpressionSyntaxError(PathSelError):
    """Grammar-level syntax failure."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxError(ExpressionSyntaxError):
    """Syntax failure detected while splitting the text into tokens."""


class ZeroSliceStepError(PathSelError):
    """A slice with step 0 was evaluated."""


class UnknownFunctionError(PathSelError):
    """The function name is neither built in nor provided."""


class InvalidArityError(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument is outside its accepted types."""
