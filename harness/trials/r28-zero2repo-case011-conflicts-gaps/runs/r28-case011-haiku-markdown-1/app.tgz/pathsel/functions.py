"""Function provider: the built-in functions, the ``signature`` decorator, and
the function table used by a search.

A provider subclasses :class:`Functions`. Each ``_func_<name>`` attribute that
has passed through :func:`signature` defines the language function ``<name>``.
Built-in names always resolve to the built-in implementation.
"""

import functools
import json
import decimal
import math
import re
from collections import namedtuple
from collections.abc import Mapping

from . import values as V
from .errors import InvalidTypeError


_PREFIX = "_func_"
_KNOWN_TYPES = frozenset(["number", "string", "array", "object", "null", "any", "expref"])

FunctionEntry = namedtuple("FunctionEntry", ["signature", "impl"])


def signature(*arguments):
    """Declare the accepted types of a function's parameters.

    Each argument is ``{"types": [...]}`` for one parameter. The type names are
    ``number``, ``string``, ``array``, ``object``, ``null``. Two extra names are
    used internally by the built-ins: ``any`` and ``expref`` (an expression
    reference). An optional ``"repeat": True`` on the last parameter means it
    may be given one or more times (used by ``merge`` and ``not_null``).

    Returns a decorator. The decorator does not call the implementation.
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise ValueError('each signature argument must be a mapping with "types"')
        types = list(argument["types"])
        if not types:
            raise ValueError("a signature parameter needs at least one type")
        for type_label in types:
            if type_label not in _KNOWN_TYPES:
                raise ValueError("unknown type name %r" % (type_label,))
        specs.append({"types": types, "repeat": bool(argument.get("repeat", False))})
    for spec in specs[:-1]:
        if spec["repeat"]:
            raise ValueError('only the last signature parameter may use "repeat"')

    def decorator(implementation):
        @functools.wraps(implementation)
        def wrapper(*args, **kwargs):
            return implementation(*args, **kwargs)

        wrapper._pathsel_signature = specs
        return wrapper

    return decorator


def _collect(provider):
    """Map function names to entries for every signature-decorated ``_func_`` attribute."""
    table = {}
    for attribute in dir(provider):
        if not attribute.startswith(_PREFIX) or attribute == _PREFIX:
            continue
        bound = getattr(provider, attribute, None)
        spec = getattr(bound, "_pathsel_signature", None)
        if spec is None:
            continue
        table[attribute[len(_PREFIX):]] = FunctionEntry(spec, bound)
    return table


def function_table(provider):
    """The functions visible to a search: the provider's, plus the built-ins.

    Built-in names always win, so the built-in behaviour is unchanged.
    """
    table = {}
    if provider is not None:
        table.update(_collect(provider))
    table.update(_BUILTINS)
    return table


# -- helpers for built-in argument checks ---------------------------------

def _require_numbers(items):
    for item in items:
        if not V.is_number(item):
            raise InvalidTypeError("expected an array of numbers")


def _require_strings(items):
    for item in items:
        if not isinstance(item, str):
            raise InvalidTypeError("expected an array of strings")


def _require_numbers_or_strings(items):
    if all(V.is_number(item) for item in items):
        return
    if all(isinstance(item, str) for item in items):
        return
    raise InvalidTypeError("expected all numbers or all strings")


def _json_default(obj):
    if V.is_object(obj):
        return dict(obj)
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    return str(obj)


def _json_text(value):
    if isinstance(value, str):
        return value
    return json.dumps(value, separators=(",", ":"), ensure_ascii=True, default=_json_default)


_INT_NUMERAL = re.compile(r"-?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


class Functions:
    """Provider of the built-in functions. Subclass it to add custom functions."""

    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array"]})
    def _func_avg(self, values):
        _require_numbers(values)
        if not values:
            return None
        return sum(float(v) for v in values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        return math.ceil(value)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, container, item):
        if V.is_array(container):
            return any(V.equal(element, item) for element in container)
        if not isinstance(item, str):
            raise InvalidTypeError("contains on a string needs a string")
        return item in container

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, subject, suffix):
        return subject.endswith(suffix)

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        return math.floor(value)

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, values):
        _require_strings(values)
        return separator.join(values)

    @signature({"types": ["object"]})
    def _func_keys(self, value):
        return list(value.keys())

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, reference, values):
        return [reference(element) for element in values]

    @signature({"types": ["array"]})
    def _func_max(self, values):
        _require_numbers_or_strings(values)
        return max(values) if values else None

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, values, reference):
        keys = [reference(element) for element in values]
        _require_numbers_or_strings(keys)
        if not values:
            return None
        best = 0
        for index in range(1, len(values)):
            if keys[index] > keys[best]:
                best = index
        return values[best]

    @signature({"types": ["object"], "repeat": True})
    def _func_merge(self, *objects):
        merged = {}
        for obj in objects:
            for key in obj:
                merged[key] = obj[key]
        return merged

    @signature({"types": ["array"]})
    def _func_min(self, values):
        _require_numbers_or_strings(values)
        return min(values) if values else None

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, values, reference):
        keys = [reference(element) for element in values]
        _require_numbers_or_strings(keys)
        if not values:
            return None
        best = 0
        for index in range(1, len(values)):
            if keys[index] < keys[best]:
                best = index
        return values[best]

    @signature({"types": ["any"], "repeat": True})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["array"]})
    def _func_sort(self, values):
        _require_numbers_or_strings(values)
        return sorted(values)

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, values, reference):
        keys = [reference(element) for element in values]
        _require_numbers_or_strings(keys)
        order = sorted(range(len(values)), key=keys.__getitem__)
        return [values[index] for index in order]

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, subject, prefix):
        return subject.startswith(prefix)

    @signature({"types": ["array"]})
    def _func_sum(self, values):
        _require_numbers(values)
        numbers = list(values)
        if any(isinstance(v, float) for v in numbers):
            numbers = [float(v) for v in numbers]
        return sum(numbers)

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if isinstance(value, list):
            return value
        if V.is_array(value):
            return list(value)
        return [value]

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if V.is_number(value):
            return value
        if isinstance(value, str):
            if _INT_NUMERAL.fullmatch(value):
                return int(value)
            if _FLOAT_NUMERAL.fullmatch(value):
                return float(value)
        return None

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        return _json_text(value)

    @signature({"types": ["any"]})
    def _func_type(self, value):
        return V.type_name(value)

    @signature({"types": ["object"]})
    def _func_values(self, value):
        return list(value.values())


_BUILTINS = _collect(Functions())
