"""Value model helpers: type tests, truthiness, equality, ordering.

Arrays are ``list`` and ``tuple``. Objects are ``collections.abc.Mapping``
instances, plus the evaluation option's ``dict_cls`` while a search runs.
Numbers are ``int``, ``float`` and ``decimal.Decimal`` (never ``bool``).
Strings are ``str``. Null is ``None``.
"""

import decimal
from collections.abc import Mapping
from contextvars import ContextVar


_object_types = ContextVar("pathsel_object_types", default=(Mapping,))


def set_object_types(dict_cls):
    """Make instances of ``dict_cls`` count as objects; returns a reset token."""
    if dict_cls is None:
        return _object_types.set((Mapping,))
    return _object_types.set((Mapping, dict_cls))


def reset_object_types(token):
    _object_types.reset(token)


def is_number(value):
    return isinstance(value, (int, float, decimal.Decimal)) and not isinstance(value, bool)


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, _object_types.get())


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None or value is False:
        return True
    if isinstance(value, str):
        return len(value) == 0
    if is_array(value) or is_object(value):
        return len(value) == 0
    return False


def type_name(value):
    """JSON type name of a value, as returned by the ``type`` function.

    Host values without a JSON type are reported as ``null`` (not specified
    by the PRD; see NOTES.md).
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if is_number(value):
        return "number"
    if isinstance(value, str):
        return "string"
    if is_array(value):
        return "array"
    if is_object(value):
        return "object"
    return "null"


def equal(a, b):
    """JSON value equality: deep for arrays and objects, 0 is never false."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b or not equal(a[key], b[key]):
                return False
        return True
    if is_array(a) or is_array(b) or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:  # host values with hostile __eq__
        return False


def compare(op, a, b):
    """Ordering for two numbers or two strings; anything else yields null."""
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        return op(a, b)
    return None


def matches_type(value, type_label):
    """Whether ``value`` belongs to the named type."""
    if type_label == "any":
        return True
    if type_label == "number":
        return is_number(value)
    if type_label == "string":
        return isinstance(value, str)
    if type_label == "array":
        return is_array(value)
    if type_label == "object":
        return is_object(value)
    if type_label == "null":
        return value is None
    if type_label == "expref":
        return isinstance(value, ExpressionReference)
    return False


class ExpressionReference:
    """A deferred subexpression (``&expr``) that functions apply later."""

    __slots__ = ("node", "context")

    def __init__(self, node, context):
        self.node = node
        self.context = context

    def __call__(self, value):
        return self.node.evaluate(value, self.context)

    def __repr__(self):
        return "<pathsel expression reference>"
