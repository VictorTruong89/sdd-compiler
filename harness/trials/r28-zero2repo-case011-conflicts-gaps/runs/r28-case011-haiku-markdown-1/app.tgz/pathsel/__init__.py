"""pathsel: evaluate PathSel expressions against ordinary Python data.

Usage::

    import pathsel
    pathsel.search("a.b", {"a": {"b": 1}})        # -> 1
    pathsel.compile("a.b").search({"a": {"b": 1}})  # -> 1
"""

from .api import ParsedExpression, compile, search
from .errors import (
    EmptyExpressionError,
    ExpressionSyntaxError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature

__version__ = "1.0.0"

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "ExpressionSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
