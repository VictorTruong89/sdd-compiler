"""Behaviour checks for pathsel, run with ``python -m pytest tests`` or unittest."""

import collections
import unittest

import pathsel
from pathsel.functions import Functions, signature


DOC = {
    "a": {"b": {"c": 1}},
    "people": [
        {"name": "x", "age": 3, "tags": ["q"]},
        {"name": "y", "age": 7, "tags": []},
        {"name": "z"},
    ],
    "n": [1, [2, 3], [[4]]],
    "s": "héllo",
    "zero": 0,
    "f": False,
    "empty": "",
    "key with space": 5,
    "a.b": "dotted",
    "1": "digit key",
}


def opts(dict_cls=None, provider=None):
    class _Opts:
        pass

    o = _Opts()
    o.dict_cls = dict_cls
    o.custom_functions = provider
    return o


class PathSelTests(unittest.TestCase):
    def s(self, expr, data=DOC, options=None):
        return pathsel.search(expr, data, options)

    # FP-01 / FP-02
    def test_dotted_path(self):
        self.assertEqual(self.s("a.b.c"), 1)
        self.assertEqual(self.s("a.b"), {"c": 1})

    def test_missing_is_null(self):
        self.assertIsNone(self.s("a.x.y"))
        self.assertIsNone(self.s("nope"))

    def test_identifier_on_array_is_null(self):
        self.assertIsNone(self.s("n.x"))

    def test_quoted_identifiers(self):
        self.assertEqual(self.s('"key with space"'), 5)
        self.assertEqual(self.s('"a.b"'), "dotted")
        self.assertEqual(self.s('"1"'), "digit key")
        self.assertEqual(self.s('a . b'), {"c": 1})

    def test_whitespace_between_tokens(self):
        self.assertEqual(self.s(" a\t.\n b . c "), 1)

    # FP-03
    def test_index_and_negative_index(self):
        self.assertEqual(self.s("people[0].name"), "x")
        self.assertEqual(self.s("people[-1].name"), "z")
        self.assertIsNone(self.s("people[9]"))
        self.assertIsNone(self.s("a[0]"))

    def test_slices(self):
        self.assertEqual(self.s("n[0:2]"), [1, [2, 3]])
        self.assertEqual(self.s("n[::-1]"), [[[4]], [2, 3], 1])
        self.assertEqual(self.s("n[-1:-4:-1]"), [[[4]], [2, 3], 1])
        self.assertEqual(self.s("n[5:9]"), [])

    def test_slice_on_non_array_is_null(self):
        self.assertIsNone(self.s("s[0:2]"))

    def test_flatten_one_level(self):
        self.assertEqual(self.s("n[]"), [1, 2, 3, [4]])
        self.assertIsNone(self.s("s[]"))

    # FP-04
    def test_list_wildcard_projection(self):
        self.assertEqual(self.s("people[*].name"), ["x", "y", "z"])
        self.assertEqual(self.s("people[*].tags[]"), ["q"])
        self.assertIsNone(self.s("a[*].name"))

    def test_object_wildcard(self):
        self.assertEqual(self.s("a.*"), [{"c": 1}])
        self.assertIsNone(self.s("people[0].name.*"))

    def test_filter(self):
        self.assertEqual(self.s("people[?age > `5`].name"), ["y"])
        self.assertEqual(self.s("people[?age]"), [
            {"name": "x", "age": 3, "tags": ["q"]},
            {"name": "y", "age": 7, "tags": []},
        ])
        self.assertIsNone(self.s("a[?b]"))

    def test_zero_is_true_in_predicates(self):
        self.assertEqual(self.s("people[?age].name"), ["x", "y"])
        self.assertEqual(self.s("n[?@]", {"n": [0, 1]}), [0, 1])

    def test_comparison_after_projection_compares_whole_array(self):
        self.assertEqual(self.s("people[*].name == `[\"x\", \"y\", \"z\"]`"), True)

    # FP-05
    def test_multiselect(self):
        self.assertEqual(self.s("people[0].[name, age]"), ["x", 3])
        self.assertEqual(self.s("people[*].[name, age]")[0], ["x", 3])
        self.assertEqual(self.s("{x: a.b.c, y: missing}"), {"x": 1, "y": None})

    def test_pipe(self):
        self.assertEqual(self.s("a | b | c"), 1)
        self.assertEqual(self.s("people[*].name | [0]"), "x")

    def test_current_and_literals(self):
        self.assertEqual(self.s("@.zero"), 0)
        self.assertEqual(self.s("`[1, 2]`[1]"), 2)
        self.assertEqual(self.s("`abc`"), "abc")
        self.assertEqual(self.s("'a\\nb'"), "a\\nb")
        self.assertEqual(self.s("'\\u0041'"), "A")
        self.assertEqual(self.s("'it\\'s'"), "it's")
        self.assertEqual(self.s("'10'"), "10")

    def test_expression_reference_is_non_null(self):
        self.assertIsNotNone(self.s("&a.b"))

    # FP-06
    def test_equality_zero_is_not_false(self):
        self.assertEqual(self.s("zero == `false`"), False)
        self.assertEqual(self.s("`1` == `true`"), False)
        self.assertEqual(self.s("`1.0` == `1`"), True)

    def test_logic_returns_operands(self):
        self.assertEqual(self.s("missing || zero"), 0)
        self.assertEqual(self.s("zero && a"), {"b": {"c": 1}})
        self.assertEqual(self.s("a && zero"), 0)
        self.assertIsNone(self.s("missing && a"))
        self.assertEqual(self.s("!zero"), False)
        self.assertEqual(self.s("!missing"), True)

    def test_not_binds_to_bracket_operand(self):
        # "!" binds to people[0]; the following dot applies to its result (null).
        self.assertIsNone(self.s("!people[0].name"))
        self.assertEqual(self.s("!people[0]"), False)

    def test_ordering(self):
        self.assertEqual(self.s("zero < `1`"), True)
        self.assertEqual(self.s("s < `1`"), None)

    # FP-07
    def test_functions(self):
        self.assertEqual(self.s("length(s)"), 5)
        self.assertEqual(self.s("abs(`-3`)"), 3)
        self.assertEqual(self.s("ceil(`1.2`)"), 2)
        self.assertEqual(self.s("floor(`1.8`)"), 1)
        self.assertEqual(self.s("avg(`[1, 2]`)"), 1.5)
        self.assertIsNone(self.s("avg(`[]`)"))
        self.assertEqual(self.s("sum(`[1, 2.5]`)"), 3.5)
        self.assertEqual(self.s("max(`[1, 3, 2]`)"), 3)
        self.assertEqual(self.s("min(`[\"b\", \"a\"]`)"), "a")
        self.assertIsNone(self.s("max(`[]`)"))
        self.assertEqual(self.s("sort(`[3, 1]`)"), [1, 3])
        self.assertEqual(self.s("join(', ', `[\"a\", \"b\"]`)"), "a, b")
        self.assertEqual(self.s("join(', ', `[]`)"), "")
        self.assertEqual(self.s("reverse(s)"), "olléh")
        self.assertEqual(self.s("contains(`[1, 2]`, `2`)"), True)
        self.assertEqual(self.s("contains(`[1, 2]`, `true`)"), False)
        self.assertEqual(self.s("starts_with(s, 'h')"), True)
        self.assertEqual(self.s("ends_with(s, 'llo')"), True)
        self.assertEqual(self.s("type(a)"), "object")
        self.assertEqual(self.s("type(zero)"), "number")
        self.assertEqual(self.s("type(f)"), "boolean")
        self.assertEqual(self.s("type(missing)"), "null")
        self.assertEqual(self.s("to_array(`1`)"), [1])
        self.assertEqual(self.s("to_array(`[1]`)"), [1])
        self.assertEqual(self.s("to_string(`1`)"), "1")
        self.assertEqual(self.s("to_string(`{\"a\": \"é\"}`)"), '{"a":"\\u00e9"}')
        self.assertEqual(self.s("to_number('12')"), 12)
        self.assertIsInstance(self.s("to_number('12')"), int)
        self.assertEqual(self.s("to_number('1.5e2')"), 150.0)
        self.assertIsNone(self.s("to_number('abc')"))
        self.assertEqual(self.s("keys(a)"), ["b"])
        self.assertEqual(self.s("values(a)"), [{"c": 1}])
        self.assertEqual(self.s("merge(a, `{\"z\": 1}`)"), {"b": {"c": 1}, "z": 1})
        self.assertEqual(self.s("not_null(missing, `0`, `1`)"), 0)
        self.assertEqual(self.s("not_null(`\"\"`, `1`)"), "")
        self.assertEqual(self.s("map(&name, people)"), ["x", "y", "z"])
        self.assertEqual(self.s("sort_by(people[?age], &age)[*].name"), ["x", "y"])
        self.assertEqual(self.s("max_by(people[?age], &age).name"), "y")
        self.assertEqual(self.s("min_by(people[?age], &age).name"), "x")
        self.assertIsNone(self.s("max_by(`[]`, &age)"))

    def test_function_on_array_of_strings_join_check(self):
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("join(',', `[1]`)")

    # FP-01 refusals and kinds
    def test_empty_expression(self):
        with self.assertRaises(pathsel.EmptyExpressionError):
            self.s("")
        with self.assertRaises(pathsel.EmptyExpressionError):
            pathsel.compile("")

    def test_whitespace_only_is_incomplete(self):
        for text in (" ", "\t", "\n\r"):
            with self.assertRaises(pathsel.IncompleteExpressionError) as cm:
                self.s(text)
            self.assertEqual(cm.exception.lex_position, len(text))

    def test_incomplete_expressions(self):
        for text in ("a[", "a[0", "a |", "a ==", "(a", "{a: b", "f(", "a(", "&", "a[*"):
            with self.assertRaises(pathsel.IncompleteExpressionError, msg=text):
                self.s(text)

    def test_dot_errors_are_syntax(self):
        for text in (".a", "a.", "a..b", "a.0", "a.-1", "a.'x'", "a.`1`", "a.@", "a.&b", "."):
            with self.assertRaises(pathsel.ExpressionSyntaxError, msg=text):
                self.s(text)

    def test_grammar_syntax_errors(self):
        for text in ("a)", "a b", "a[foo]", "a[1 2]", "a[1:2:3:4]", "a[1.5]", "a[*]b", "a*",
                     "*b", "5", "{}", "[a,]", "[ ]", "foo(`1`,)", "\"x\"(`1`)"):
            with self.assertRaises(pathsel.ExpressionSyntaxError, msg=text) as cm:
                self.s(text)
            self.assertNotIsInstance(cm.exception, pathsel.TokenSyntaxError, msg=text)

    def test_token_syntax_errors(self):
        for text in ("a-b", "a = b", "#", "\"abc", "'abc", "`1", "\"a\\q\""):
            with self.assertRaises(pathsel.TokenSyntaxError, msg=text) as cm:
                self.s(text)
            self.assertIsInstance(cm.exception, pathsel.ExpressionSyntaxError)
            self.assertIsInstance(cm.exception.lex_position, int)

    def test_error_kinds_distinct_types(self):
        def kind(text):
            try:
                pathsel.search(text, DOC)
            except ValueError as e:
                return type(e)
            return None

        self.assertIs(kind("a b"), kind("c d"))
        self.assertIsNot(kind("a b"), kind("a ="))
        self.assertIsNot(kind("a ="), kind("a b"))
        self.assertTrue(issubclass(pathsel.TokenSyntaxError, pathsel.ExpressionSyntaxError))
        self.assertFalse(issubclass(pathsel.ExpressionSyntaxError, pathsel.TokenSyntaxError))

    def test_position(self):
        with self.assertRaises(pathsel.ExpressionSyntaxError) as cm:
            self.s("a b")
        self.assertEqual(cm.exception.lex_position, 2)
        with self.assertRaises(pathsel.ExpressionSyntaxError) as cm:
            self.s("a..b")
        self.assertEqual(cm.exception.lex_position, 2)

    def test_all_refusals_are_value_errors(self):
        for text in ("", " ", "a b", "a =", "a ==", "\"x"):
            with self.assertRaises(ValueError):
                self.s(text)

    def test_zero_slice_step(self):
        with self.assertRaises(pathsel.ZeroSliceStepError):
            self.s("n[::0]")
        with self.assertRaises(pathsel.ZeroSliceStepError):
            pathsel.compile("n[::0]").search(DOC)

    def test_function_refusals(self):
        with self.assertRaises(pathsel.UnknownFunctionError):
            self.s("nosuch(`1`)")
        with self.assertRaises(pathsel.InvalidArityError):
            self.s("abs(`1`, `2`)")
        with self.assertRaises(pathsel.InvalidArityError):
            self.s("not_null()")
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("abs(`true`)")
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("max(`[1, \"a\"]`)")
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("map(zero, people)")
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("sort_by(people, &missing)")

    def test_compile_defers_function_checks(self):
        parsed = pathsel.compile("nosuch(`1`) || abs(`true`)")
        with self.assertRaises(pathsel.UnknownFunctionError):
            parsed.search(DOC)

    def test_compile_matches_search(self):
        parsed = pathsel.compile("people[?age > `5`].name")
        self.assertEqual(parsed.search(DOC), self.s("people[?age > `5`].name"))
        self.assertIsNone(parsed.search({"x": 1}))

    def test_document_not_mutated(self):
        import copy

        before = copy.deepcopy(DOC)
        self.s("people[*].name")
        self.s("n[]")
        self.assertEqual(DOC, before)

    # FP-08
    def test_dict_cls_option(self):
        result = self.s("{x: a.b.c}", options=opts(dict_cls=collections.OrderedDict))
        self.assertIsInstance(result, collections.OrderedDict)
        self.assertEqual(result, {"x": 1})
        nested = self.s("{x: a}.x.b.c", options=opts(dict_cls=collections.OrderedDict))
        self.assertEqual(nested, 1)

    def test_custom_function(self):
        class Provider(Functions):
            @signature({"types": ["number"]}, {"types": ["string"]})
            def _func_repeat(self, count, text):
                return text * int(count)

            @signature({"types": ["null"]})
            def _func_nothing(self, value):
                return 0

        provider = Provider()
        self.assertEqual(self.s("repeat(`2`, 'ab')", options=opts(provider=provider)), "abab")
        self.assertEqual(self.s("nothing(`null`)", options=opts(provider=provider)), 0)
        self.assertEqual(self.s("abs(`-2`)", options=opts(provider=provider)), 2)
        with self.assertRaises(pathsel.UnknownFunctionError):
            self.s("repeat(`2`, 'ab')")
        with self.assertRaises(pathsel.InvalidArityError):
            self.s("repeat(`2`)", options=opts(provider=provider))
        with self.assertRaises(pathsel.InvalidTypeError):
            self.s("repeat('x', 'ab')", options=opts(provider=provider))

    def test_compile_custom_function_without_provider(self):
        parsed = pathsel.compile("repeat(`2`, 'ab')")
        with self.assertRaises(pathsel.UnknownFunctionError):
            parsed.search(DOC)

    def test_signature_does_not_call_implementation(self):
        calls = []

        @signature({"types": ["any"]})
        def impl(self, value):
            calls.append(value)
            return value

        self.assertEqual(calls, [])
        self.assertEqual(impl(None, 1), 1)
        self.assertEqual(calls, [1])


if __name__ == "__main__":
    unittest.main()
