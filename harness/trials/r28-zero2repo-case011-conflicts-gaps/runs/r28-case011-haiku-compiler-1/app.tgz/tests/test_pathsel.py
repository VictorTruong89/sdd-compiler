"""Behavioural tests for pathsel, grouped by spec feature point.

Each test group lists the checklist ids it exercises in ``# spec:`` comments.
Run from /app with: python3 -m pytest -q tests
"""

# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007 N-000008
# spec: N-000009 N-000010 N-000011 N-000012 N-000013 N-000014 N-000015 N-000016
# spec: N-000017 N-000018 N-000019 N-000020 N-000021 N-000022 N-000023 N-000024
# spec: N-000025 N-000026 N-000027 N-000028 N-000029 N-000030 N-000031 N-000032
# spec: N-000033 N-000034 N-000035 N-000036 N-000037 N-000038 N-000039 N-000040
# spec: N-000041 N-000042 N-000043 N-000044 N-000045 N-000046 N-000047 N-000048
# spec: N-000049 N-000050 N-000055 N-000056 N-000057 N-000058 N-000059 N-000060
# spec: N-000061 N-000062 N-000063 N-000064 N-000065 N-000066 N-000067 N-000068
# spec: N-000069 N-000070 N-000071 N-000072 N-000073 N-000074 N-000075 N-000076
# spec: N-000077 N-000078 N-000079 N-000080 N-000081 N-000082 N-000083 N-000084
# spec: N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092
# spec: N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100
# spec: N-000101 N-000102 N-000103 N-000104 N-000105 N-000106 N-000107 N-000108
# spec: N-000109 N-000110 N-000111 N-000112 N-000113 N-000114 N-000115 N-000116
# spec: N-000117 N-000118 N-000119 N-000120 N-000121 N-000122 N-000123 N-000124
# spec: N-000125 N-000126 N-000127 N-000128 N-000129 N-000130 N-000131 N-000132
# spec: N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140
# spec: N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148
# spec: N-000149 N-000150 N-000151 N-000152 N-000153 N-000154 N-000155 N-000156
# spec: N-000157 N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164
# spec: N-000165 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
# spec: N-000173 N-000174 N-000175 N-000176 N-000177 N-000178 N-000179 N-000180
# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187 N-000188
# spec: N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196
# spec: N-000197 N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204
# spec: N-000205 N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212
# spec: N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220
# spec: N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228
# spec: N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235 N-000236
# spec: N-000237 N-000238 N-000239 N-000240 N-000241 N-000242 N-000243 N-000244
# spec: N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251 N-000252
# spec: N-000253 N-000254 N-000255 N-000256 N-000257 N-000258 N-000259 N-000260
# spec: N-000261 N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268
# spec: N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000276
# spec: N-000277 N-000278 N-000279 N-000280 N-000281 N-000282 N-000283 N-000284
# spec: N-000285 N-000286 N-000287 N-000288 N-000289 N-000290 N-000291 N-000292
# spec: N-000293 N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300
# spec: N-000301 N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308
# spec: N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316
# spec: N-000317 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323 N-000324
# spec: N-000325 N-000326 N-000327 N-000328 N-000329 N-000330 N-000331 N-000332
# spec: N-000333 N-000334 N-000335 N-000336 N-000337 N-000338 N-000339 N-000340
# spec: N-000341 N-000342 N-000343 N-000344 N-000345 N-000346 N-000347 N-000348
# spec: N-000349 N-000350 N-000351 N-000352 N-000353 N-000354 N-000355 N-000356
# spec: N-000357 N-000358 N-000359 N-000360 N-000361 N-000362 N-000363 N-000364
# spec: N-000365 N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000372
# spec: N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379 N-000380
# spec: N-000381 N-000382 N-000383 N-000384 N-000385 N-000386 N-000387 N-000388
# spec: N-000389 N-000390 N-000391 N-000392 N-000393 N-000394 N-000395 N-000396
# spec: N-000397 N-000398 N-000399 N-000400 N-000401 N-000402 N-000403 N-000404
# spec: N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412
# spec: N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000421 N-000422 N-000423

import collections
from collections import OrderedDict
from decimal import Decimal
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import compile as pathsel_compile
from pathsel import search
from pathsel.errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature

DOC = {
    "a": {"b": {"c": 42}},
    "arr": [1, [2, 3], None, {"x": 1}, 5],
    "items": [
        {"name": "x", "v": 1, "t": [1, 2]},
        {"name": "y", "v": 0, "t": []},
        {"name": None, "v": 2, "t": [3]},
    ],
    "m": {"p": {"q": 1}, "r": {"q": 2}},
    "s": "héllo",
    "t": True,
    "z": 0,
    "e": [],
    "nul": None,
    "hy-phen": 7,
    "dot.key": 8,
    "1abc": 9,
}


# --- Entry points and product form (FP-01, Interface Contract) ------------

def test_search_and_compile_agree_for_every_expression():
    # spec: N-000080 N-000081 N-000082 N-000342 N-000343
    exprs = ["a.b.c", "items[*].name", "arr[1:3]", "missing.x", "t && z", "items[?v == `0`]"]
    for expr in exprs:
        parsed = pathsel_compile(expr)
        assert parsed.search(DOC) == search(expr, DOC)


def test_parsed_expression_reused_against_many_documents():
    # spec: N-000078 N-000079 N-000086 N-000018 N-000006 N-000075 N-000076
    parsed = pathsel_compile("a.b.c")
    assert parsed.search({"a": {"b": {"c": 1}}}) == 1
    assert parsed.search({"a": {"b": {"c": 2}}}) == 2
    assert parsed.search({}) is None


def test_dotted_path_and_missing_is_null():
    # spec: N-000001 N-000002 N-000003 N-000059 N-000060 N-000077 N-000083 N-000084 N-000085
    assert search("a.b.c", DOC) == 42
    assert search("a.b.c.d", DOC) is None
    assert search("a.nope", DOC) is None
    assert search("arr.x", DOC) is None  # identifier on an array is null


def test_package_surface_names():
    # spec: N-000372 N-000373 N-000374 N-000366 N-000367 N-000368 N-000038 N-000039
    assert callable(pathsel.search)
    assert callable(pathsel.compile)
    assert pathsel.search.__name__ == "search"


def test_search_does_not_mutate_input():
    # spec: N-000069 N-000070
    import copy

    doc = copy.deepcopy(DOC)
    search("items[*].name | [0]", doc)
    search("sort(arr[*].x)", doc)
    search("reverse(arr)", doc)
    assert doc == DOC


def test_options_positional_argument():
    # spec: N-000375 N-000376 N-000377 N-000386 N-000387 N-000389 N-000390 N-000391 N-000392
    opts = SimpleNamespace(dict_cls=None, custom_functions=None)
    assert search("a.b.c", DOC, opts) == 42
    assert pathsel_compile("a.b.c").search(DOC, opts) == 42


def test_literal_results_are_fresh_copies():
    # spec: N-000066 N-000069
    parsed = pathsel_compile("`[1, 2]`")
    first = parsed.search(None)
    first.append(99)
    assert parsed.search(None) == [1, 2]


# --- Empty, incomplete, syntax and position (FP-01) ----------------------

def test_empty_expression_refused():
    # spec: N-000087 N-000088 N-000089 N-000105 N-000106 N-000409 N-000406
    with pytest.raises(EmptyExpressionError) as info:
        search("", DOC)
    assert isinstance(info.value, ValueError)
    assert info.value.lex_position == 0
    with pytest.raises(EmptyExpressionError):
        pathsel_compile("")


def test_whitespace_only_is_incomplete_not_empty():
    # spec: N-000090 N-000091 N-000092 N-000093 N-000410 N-000102 N-000104
    with pytest.raises(IncompleteExpressionError) as info:
        search("  \t\n\r ", DOC)
    assert not isinstance(info.value, EmptyExpressionError)
    assert info.value.lex_position == len("  \t\n\r ")


@pytest.mark.parametrize("text", ["a[0", "(a", "a ||", "items[?v", "foo(", "a == ", "!", "{a: `1`"])
def test_incomplete_expressions(text):
    # spec: N-000090 N-000091 N-000092 N-000093 N-000410
    with pytest.raises(IncompleteExpressionError) as info:
        search(text, DOC)
    assert info.value.lex_position == len(text)


@pytest.mark.parametrize("text", ["a.", "a..b", "a.0", "a.@", "a.`1`", "a b", "a)", "[1,]", "{a:`1`,}", "a[*]b", "a[*]*", "*foo", "**", "items[?]"])
def test_grammar_level_syntax_failures(text):
    # spec: N-000094 N-000095 N-000097 N-000117 N-000123 N-000200 N-000201 N-000240 N-000241 N-000411
    with pytest.raises(PathSelSyntaxError) as info:
        search(text, DOC)
    assert type(info.value) is PathSelSyntaxError
    assert isinstance(info.value, ValueError)


@pytest.mark.parametrize("text", ["a-b", "a-", "'unterminated", '"bad\\q"', "`bad json", "=", "a = b", "é", "a[0 ~"])
def test_token_level_syntax_failures_are_subclasses(text):
    # spec: N-000098 N-000100 N-000101 N-000119 N-000120 N-000121 N-000122 N-000124 N-000237 N-000260 N-000412 N-000413 N-000414
    with pytest.raises(PathSelSyntaxError) as info:
        search(text, DOC)
    assert isinstance(info.value, TokenSyntaxError)
    assert type(info.value) is not PathSelSyntaxError
    assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


def test_syntax_positions_differ_by_offset():
    # spec: N-000102 N-000103 N-000104 N-000421 N-000422
    with pytest.raises(PathSelSyntaxError) as first:
        search("a b", DOC)
    with pytest.raises(PathSelSyntaxError) as second:
        search("a . 0", DOC)
    assert first.value.lex_position == 2
    assert second.value.lex_position == 4
    with pytest.raises(PathSelSyntaxError) as third:
        search("a[0:1:2:3]", DOC)
    assert third.value.lex_position == 7
    assert isinstance(third.value.lex_position, int)


def test_failure_kinds_are_distinct_types():
    # spec: N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000036
    with pytest.raises(PathSelError) as empty:
        search("", DOC)
    with pytest.raises(PathSelError) as incomplete:
        search("a ||", DOC)
    with pytest.raises(PathSelError) as syntax:
        search("a b", DOC)
    with pytest.raises(PathSelError) as zero:
        search("a[::0]", DOC)
    with pytest.raises(PathSelError) as unknown:
        search("nosuch(a)", DOC)
    with pytest.raises(PathSelError) as arity:
        search("abs()", DOC)
    with pytest.raises(PathSelError) as typed:
        search("abs(`true`)", DOC)
    types = {type(e.value) for e in (empty, incomplete, syntax, zero, unknown, arity, typed)}
    assert len(types) == 7
    assert not isinstance(zero.value, PathSelSyntaxError)
    assert isinstance(unknown.value, UnknownFunctionError)
    assert isinstance(arity.value, InvalidArityError)
    assert isinstance(typed.value, InvalidTypeError)
    for err in (empty, incomplete, syntax, zero, unknown, arity, typed):
        assert isinstance(err.value, ValueError)


def test_every_refusal_is_a_value_error():
    # spec: N-000405 N-000061 N-000037 N-000408 N-000065 N-000063 N-000064
    for text in ["", "a ||", "a b", "a-", "a[::0]", "nosuch()", "abs()", "abs(`true`)"]:
        with pytest.raises(ValueError):
            search(text, DOC)


def test_not_a_refusal_for_successful_null():
    # spec: N-000106 N-000105 N-000083
    assert search("missing", DOC) is None


def test_compile_does_not_refuse_unknown_function_or_arity():
    # spec: N-000263 N-000344 N-000343 N-000264
    parsed = pathsel_compile("nosuch(a, b) && abs()")
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)


# --- Field selection (FP-02) ------------------------------------------------

def test_quoted_identifiers_name_any_key():
    # spec: N-000110 N-000111 N-000112 N-000113 N-000114 N-000118 N-000122
    assert search('"hy-phen"', DOC) == 7
    assert search('"dot.key"', DOC) == 8
    assert search('"1abc"', DOC) == 9
    assert search('"a".b.c', DOC) == 42
    assert search('"\\u0061"', DOC) == DOC["a"]  # \uXXXX inside JSON string decodes


def test_quoted_identifier_with_dot_is_one_key():
    # spec: N-000112 N-000113
    doc = {"a.b": 1, "a": {"b": 2}}
    assert search('"a.b"', doc) == 1


def test_whitespace_between_tokens_is_ignored():
    # spec: N-000109 N-000220
    assert search(" a . b . c ", DOC) == 42
    assert search("a\t.\nb", DOC) == {"c": 42}


def test_identifier_on_non_object_is_null_and_does_not_project():
    # spec: N-000115 N-000116 N-000125
    assert search("arr.x", DOC) is None
    assert search("s.x", DOC) is None


def test_hyphen_not_allowed_unquoted():
    # spec: N-000119 N-000121
    with pytest.raises(TokenSyntaxError):
        search("hy-phen", DOC)


def test_number_cannot_follow_dot():
    # spec: N-000117 N-000118
    with pytest.raises(PathSelSyntaxError):
        search("a.-1", DOC)


# --- Index, slice and flatten (FP-03) ---------------------------------------

def test_index_including_negative_and_out_of_range():
    # spec: N-000126 N-000127 N-000128 N-000129 N-000156
    assert search("arr[0]", DOC) == 1
    assert search("arr[-1]", DOC) == 5
    assert search("arr[99]", DOC) is None
    assert search("arr[-99]", DOC) is None
    assert search("s[0]", DOC) is None
    assert search("a[0]", DOC) is None


def test_slices_match_python_semantics_for_positive_step():
    # spec: N-000130 N-000131 N-000134 N-000135 N-000136 N-000137 N-000141 N-000143 N-000144
    values = list(range(10))
    doc = {"v": values}
    assert search("v[2:5]", doc) == values[2:5]
    assert search("v[-3:]", doc) == values[-3:]
    assert search("v[:-7]", doc) == values[:-7]
    assert search("v[::3]", doc) == values[::3]
    assert search("v[5:2]", doc) == []
    assert search("v[100:200]", doc) == []


def test_slices_with_negative_step():
    # spec: N-000132 N-000133 N-000138 N-000139 N-000140
    values = list(range(10))
    doc = {"v": values}
    assert search("v[::-1]", doc) == values[::-1]
    assert search("v[7:2:-2]", doc) == values[7:2:-2]
    assert search("v[-1::-4]", doc) == values[-1::-4]
    assert search("v[:-100:-1]", doc) == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]


def test_zero_slice_step_refused_on_compile_or_search():
    # spec: N-000152 N-000153 N-000154 N-000415
    with pytest.raises(ZeroSliceStepError) as info:
        pathsel_compile("v[::0]")
    assert isinstance(info.value, ValueError)
    assert not isinstance(info.value, PathSelSyntaxError)


def test_slice_on_non_array_is_null():
    # spec: N-000142 N-000157
    assert search("s[0:2]", DOC) is None
    assert search("a[0:2]", DOC) is None


def test_slice_is_a_projection():
    # spec: N-000143 N-000144
    assert search("arr[0:4].x", DOC) == [1]
    assert search("arr[:]", {"arr": [None, 1]}) == [1]


def test_flatten_one_level():
    # spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150
    # Flatten is a projection, so the null element is dropped (spec FP-03).
    assert search("arr[]", DOC) == [1, 2, 3, {"x": 1}, 5]
    assert search("e[]", DOC) == []
    assert search("s[]", DOC) is None
    assert search("items[].name", DOC) == ["x", "y"]


def test_flatten_applies_to_whole_left_result():
    # spec: N-000148 N-000150 N-000151
    doc = {"foo": [[1, 2], [3], [4, [5]]]}
    assert search("foo[][]", doc) == [1, 2, 3, 4, 5]
    assert search("foo[*][]", doc) == [1, 2, 3, 4, [5]]
    assert search("[]", doc) is None
    assert search("foo[0][]", doc) == [1, 2]


def test_bracket_steps_join_projection_right_hand_side():
    # spec: N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000192
    doc = {"foo": [[1, 2], [3], [4, [5]]]}
    assert search("foo[*][0]", doc) == [1, 3, 4]
    assert search("items[*].t[0]", DOC) == [1, 3]


def test_comparison_ends_projection_then_pipe_continues():
    # spec: N-000193 N-000194 N-000195 N-000196 N-000197
    assert search("items[*].name == `null`", DOC) is False
    assert search("items[*].name | [0]", DOC) == "x"


# --- Wildcards and filters (FP-04) ------------------------------------------

def test_list_wildcard_projects_non_null_results():
    # spec: N-000159 N-000160 N-000161 N-000162 N-000204 N-000205
    assert search("items[*].name", DOC) == ["x", "y"]
    assert search("items[*]", DOC) == DOC["items"]
    assert search("s[*]", DOC) is None
    assert search("missing[*]", DOC) is None


def test_object_wildcard_projects_values():
    # spec: N-000163 N-000164 N-000165 N-000168 N-000169
    assert search("m.*.q", DOC) == [1, 2]
    assert search("*", {"x": 1, "y": None, "z": 3}) == [1, 3]
    assert search("arr.*", DOC) is None
    assert search("s.*", DOC) is None


def test_projection_inside_projection_yields_inner_arrays():
    # spec: N-000166 N-000167
    assert search("items[*].t[*]", DOC) == [[1, 2], [], [3]]
    doc = {"outer": [{"inner": [1, 2]}, {"inner": None}, {"inner": [3]}]}
    assert search("outer[*].inner[*]", doc) == [[1, 2], [3]]


def test_filter_predicates():
    # spec: N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000174 N-000175
    # spec: N-000176 N-000177 N-000178 N-000179 N-000180 N-000181 N-000258 N-000259
    assert search("items[?v == `0`].name", DOC) == ["y"]
    assert search("items[?t].name", DOC) == ["x"]  # the null name of the kept item is dropped
    assert search("items[?v == `1` || v == `2`].v", DOC) == [1, 2]
    assert search("items[?v > `0`].name", DOC) == ["x"]


def test_filter_on_non_array_is_null():
    # spec: N-000202 N-000203
    assert search("s[?x]", DOC) is None
    assert search("a[?x]", DOC) is None


def test_bare_field_predicate_truthiness_zero_is_true():
    # spec: N-000174 N-000175
    assert search("items[?v].name", DOC) == ["x", "y"]


def test_wildcard_then_identifier_is_syntax_error():
    # spec: N-000200 N-000201
    with pytest.raises(PathSelSyntaxError):
        search("*foo", DOC)


def test_object_wildcard_on_non_object_is_null():
    # spec: N-000165
    assert search("arr.*", DOC) is None


def test_equality_in_filter_is_json_equality():
    # spec: N-000180 N-000181
    doc = {"l": [{"v": 0}, {"v": False}, {"v": 1}, {"v": True}, {"v": 0.0}]}
    assert search("l[?v == `0`]", doc) == [{"v": 0}, {"v": 0.0}]
    assert search("l[?v == `1`]", doc) == [{"v": 1}]


# --- Constructed results, pipe, current value, literals (FP-05) -------------

def test_multiselect_hash_and_list():
    # spec: N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212
    assert search("{x: a.b.c, y: t}", DOC) == {"x": 42, "y": True}
    assert search("{x: nosuch}", DOC) == {"x": None}
    assert search("[a.b.c, nul]", DOC) == [42, None]
    assert search('{"hy-phen": z}', DOC) == {"hy-phen": 0}


def test_multiselect_on_null_current_value_is_null():
    # spec: N-000218 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217
    assert search("nosuch.[a, b]", DOC) is None
    assert search("nosuch.{a: a}", DOC) is None


def test_multiselect_after_projection_bracket():
    # spec: N-000213 N-000216
    assert search("items[*][name, v]", DOC) == [["x", 1], ["y", 0], [None, 2]]
    assert search("items[*].[name, v]", DOC) == [["x", 1], ["y", 0], [None, 2]]


def test_multiselect_directly_after_operand_is_syntax():
    # spec: N-000214 N-000217
    with pytest.raises(PathSelSyntaxError):
        search("a[b, c]", DOC)


def test_pipe_stops_projection_and_binds_loosest():
    # spec: N-000219 N-000220 N-000221 N-000222 N-000253
    assert search("items[*].name | [0]", DOC) == "x"
    assert search("items[*]|[0].name", DOC) == "x"
    assert search("`1` | `2`", DOC) == 2
    assert search("a | b", DOC) == {"c": 42}


def test_current_value_token():
    # spec: N-000036 N-000033
    assert search("@", {"k": 1}) == {"k": 1}
    assert search("items[?@.v == `1`].name", DOC) == ["x"]


def test_json_literals_and_raw_strings():
    # spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230
    assert search("`1`", DOC) == 1
    assert search("` [1,2] `", DOC) == [1, 2]
    assert search("`\"hi\"`", DOC) == "hi"
    assert search("`bare text`", DOC) == "bare text"  # not JSON -> JSON string content
    assert search("'raw \\n'", DOC) == "raw \\n"
    assert search("'it\\'s'", DOC) == "it's"
    assert search("'123'", DOC) == "123"
    assert search("`{\"a\": 1}`.a", DOC) == 1


def test_raw_string_unicode_escape_is_decoded():
    # spec: N-000239 N-000049
    assert search("'\\u00e9'", DOC) == "é"


def test_literal_after_dot_is_syntax():
    # spec: N-000238
    with pytest.raises(PathSelSyntaxError):
        search("a.`1`", DOC)


def test_expression_reference_standalone_is_non_null():
    # spec: N-000231 N-000232 N-000233 N-000234 N-000235 N-000236 N-000423
    assert search("&a", DOC) is not None
    assert search("&a.b", DOC) is not None


def test_pipe_with_missing_side_refused():
    # spec: N-000241
    with pytest.raises(IncompleteExpressionError):
        search("a |", DOC)


# --- Comparison and logic (FP-06) ------------------------------------------

def test_equality_is_json_value_equality():
    # spec: N-000242 N-000243 N-000244 N-000251 N-000252
    assert search("`1` == `1.0`", DOC) is True
    assert search("`0` == `false`", DOC) is False
    assert search("`1` == `true`", DOC) is False
    assert search("`[1, {\"a\": 2}]` == `[1.0, {\"a\": 2}]`", DOC) is True
    assert search("`1` != `2`", DOC) is True
    assert search("!z", DOC) is False  # 0 is a true value
    assert search("!e", DOC) is True  # empty array is false
    assert search("!nul", DOC) is True


def test_ordering_numbers_and_strings():
    # spec: N-000245 N-000246 N-000024
    assert search("`1` < `2`", DOC) is True
    assert search("`2` >= `2`", DOC) is True
    assert search("`\"a\"` < `\"b\"`", DOC) is True
    assert search("`\"é\"` > `\"z\"`", DOC) is True  # code-point order
    assert search("`true` < `false`", DOC) is None  # unlike kinds yield null


def test_and_or_return_operands():
    # spec: N-000247 N-000248 N-000249 N-000250
    assert search("z || `5`", DOC) == 0
    assert search("e || `5`", DOC) == 5
    assert search("z && nul", DOC) is None
    assert search("nul && z", DOC) is None
    assert search("t && a.b.c", DOC) == 42


def test_not_binds_tighter_than_comparison_and_logic():
    # spec: N-000253 N-000254 N-000255 N-000256 N-000257 N-000222
    assert search("!a[0] && a.b", DOC) == {"c": 42}
    assert search("!(a[0] && a.b)", DOC) is True
    assert search("!a.b", DOC) is None  # dot applies to the result of !


def test_comparison_after_projection_compares_whole_array():
    # spec: N-000195 N-000196 N-000197
    assert search("items[*].v == `[1, 0, 2]`", DOC) is True


def test_lone_ampersand_and_missing_side_refused():
    # spec: N-000261
    with pytest.raises(IncompleteExpressionError):
        search("a &&", DOC)
    with pytest.raises(PathSelSyntaxError):
        search("&& a", DOC)


# --- Built-in functions (FP-07) ----------------------------------------------

def test_builtin_names_are_exactly_the_spec_set():
    # spec: N-000262 N-000263
    names = sorted(n[len("_func_"):] for n in dir(Functions) if n.startswith("_func_"))
    expected = sorted(
        "abs avg ceil contains ends_with floor join keys length map max max_by merge min min_by not_null reverse sort sort_by starts_with sum to_array to_number to_string type values".split()
    )
    assert names == expected


def test_numeric_functions():
    # spec: N-000269 N-000270 N-000271 N-000272 N-000273 N-000294
    assert search("abs(`-3`)", DOC) == 3
    assert search("abs(`-2.5`)", DOC) == 2.5
    assert search("avg(`[1, 2, 3, 4]`)", DOC) == 2.5
    assert search("avg(`[]`)", DOC) is None
    assert search("ceil(`1.2`)", DOC) == 2
    assert isinstance(search("ceil(`1.2`)", DOC), int)
    assert search("floor(`-1.2`)", DOC) == -2
    assert isinstance(search("floor(`-1.2`)", DOC), int)
    assert search("sum(`[1, 2.5]`)", DOC) == 3.5
    assert search("sum(`[]`)", DOC) == 0


def test_string_and_membership_functions():
    # spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280
    assert search("contains(`[1, 2]`, `2`)", DOC) is True
    assert search("contains(`[1, 2]`, `\"2\"`)", DOC) is False
    assert search("contains(s, 'll')", DOC) is True
    assert search("ends_with(s, 'llo')", DOC) is True
    assert search("starts_with(s, 'hé')", DOC) is True
    assert search("length(s)", DOC) == 5  # Unicode characters, not bytes (CF-000035)
    assert search("reverse(s)", DOC) == "olléh"
    assert search("reverse(`[1, 2]`)", DOC) == [2, 1]
    assert search("join(', ', `[\"a\", \"b\"]`)", DOC) == "a, b"
    assert search("join('-', `[]`)", DOC) == ""  # see NOTES.md (join of empty array)


def test_object_and_type_functions():
    # spec: N-000281 N-000282 N-000283 N-000295 N-000296 N-000297
    assert search("keys(a)", DOC) == ["b"]
    assert search("values(m.p)", DOC) == [1]
    assert search("type(z)", DOC) == "number"
    assert search("type(t)", DOC) == "boolean"
    assert search("type(nul)", DOC) == "null"
    assert search("type(s)", DOC) == "string"
    assert search("type(arr)", DOC) == "array"
    assert search("type(a)", DOC) == "object"
    assert search("to_array(s)", DOC) == ["héllo"]
    assert search("to_array(e)", DOC) == []
    assert search("merge(a, `{\"q\": 1}`)", DOC) == {"b": {"c": 42}, "q": 1}
    assert search("merge(`{\"k\": 1}`, `{\"k\": 2}`)", DOC) == {"k": 2}


def test_string_conversion_functions():
    # spec: N-000284 N-000285 N-000286 N-000287 N-000288 N-000289
    assert search("to_string(s)", DOC) == "héllo"
    assert search("to_string(`[1, 2.5, true, null]`)", DOC) == "[1,2.5,true,null]"
    assert search("to_string(`{\"a\": \"é\"}`)", DOC) == '{"a":"\\u00e9"}'
    assert search("to_number(`\"12\"`)", DOC) == 12
    assert search("to_number(`\"1.5\"`)", DOC) == 1.5
    assert search("to_number(`\"1e3\"`)", DOC) == 1000.0
    assert search("to_number(`\"x\"`)", DOC) is None
    assert search("to_number(`true`)", DOC) is None
    assert search("to_number(`[1]`)", DOC) is None


def test_min_max_sort_functions():
    # spec: N-000290 N-000291 N-000292 N-000293
    assert search("max(`[1, 3, 2]`)", DOC) == 3
    assert search("min(`[\"b\", \"a\"]`)", DOC) == "a"
    assert search("max(`[]`)", DOC) is None
    assert search("sort(`[3, 1, 2]`)", DOC) == [1, 2, 3]
    assert search("sort(`[\"b\", \"a\"]`)", DOC) == ["a", "b"]


def test_not_null_keeps_empty_containers():
    # spec: N-000298 N-000299 N-000300
    assert search("not_null(nul, e, z)", DOC) == []
    assert search("not_null(nul, nul)", DOC) is None
    assert search("not_null(`\"\"`, `1`)", DOC) == ""


def test_map_includes_nulls_and_projection_drops_them():
    # spec: N-000301 N-000302
    assert search("map(&v, items)", DOC) == [1, 0, 2]
    assert search("map(&name, items)", DOC) == ["x", "y", None]
    assert search("items[*].name", DOC) == ["x", "y"]


def test_sort_by_stable_and_key_type_checked():
    # spec: N-000303 N-000304 N-000305
    doc = {"rows": [{"k": 2, "n": "a"}, {"k": 1, "n": "b"}, {"k": 1, "n": "c"}]}
    assert search("sort_by(rows, &k)[*].n", doc) == ["b", "c", "a"]
    with pytest.raises(InvalidTypeError):
        search("sort_by(rows, &missing)", doc)
    mixed = {"rows": [{"k": 1}, {"k": "x"}]}
    with pytest.raises(InvalidTypeError):
        search("sort_by(rows, &k)", mixed)


def test_max_by_min_by_ties_first_and_empty():
    # spec: N-000306 N-000307 N-000308
    doc = {"rows": [{"k": 1, "n": "a"}, {"k": 1, "n": "b"}, {"k": 0, "n": "c"}]}
    assert search("max_by(rows, &k).n", doc) == "a"
    assert search("min_by(rows, &k).n", doc) == "c"
    assert search("max_by(`[]`, &k)", doc) is None


def test_function_call_can_be_projection_right_hand_side():
    # spec: N-000309 N-000310
    assert search("items[*].to_string(@)", {"items": [1, None, 2]}) == ["1", "null", "2"]


def test_wrong_argument_count_is_arity_kind():
    # spec: N-000311 N-000312 N-000313 N-000345 N-000346
    with pytest.raises(InvalidArityError):
        search("abs(a, b)", DOC)
    with pytest.raises(InvalidArityError):
        search("not_null()", DOC)
    with pytest.raises(InvalidArityError):
        search("merge()", DOC)


def test_wrong_argument_type_is_type_kind():
    # spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000347 N-000348 N-000349
    with pytest.raises(InvalidTypeError):
        search("abs(`true`)", DOC)
    with pytest.raises(InvalidTypeError):
        search("sum(`[1, \"a\"]`)", DOC)
    with pytest.raises(InvalidTypeError):
        search("keys(a.missing)", DOC)
    with pytest.raises(InvalidTypeError):
        search("map(v, items)", DOC)  # not a reference
    with pytest.raises(InvalidTypeError):
        search("max(`[1, \"a\"]`)", DOC)
    with pytest.raises(InvalidTypeError):
        search("merge(`1`)", DOC)


def test_unknown_function_and_quoted_function_name():
    # spec: N-000344 N-000321 N-000322 N-000263
    with pytest.raises(UnknownFunctionError):
        search("nosuch(a)", DOC)
    with pytest.raises(PathSelSyntaxError):
        search('"abs"(a)', DOC)


def test_compile_defers_function_checks_to_search():
    # spec: N-000264 N-000265 N-000266 N-000267
    parsed = pathsel_compile("abs(a, b)")
    with pytest.raises(InvalidArityError):
        parsed.search(DOC)


# --- Evaluation options and custom functions (FP-08, Interface Contract) ----

class _Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["number"]})
    def _func_add(self, a, b):
        return a + b

    @signature()
    def _func_zero(self):
        return 0

    @signature({"types": ["array"]})
    def _func_first_or_none(self, values):
        return values[0] if values else None

    def _func_unsigned(self, value):
        return value


def test_custom_function_declared_and_called():
    # spec: N-000335 N-000336 N-000337 N-000338 N-000393 N-000395 N-000397 N-000398 N-000400 N-000401 N-000402 N-000403
    opts = SimpleNamespace(dict_cls=None, custom_functions=_Provider())
    assert search("add(`1`, `2`)", DOC, opts) == 3
    assert search("zero()", DOC, opts) == 0  # falsy return value is kept
    assert search("first_or_none(`[]`)", DOC, opts) is None


def test_custom_function_checks_arity_and_types():
    # spec: N-000344 N-000345 N-000346 N-000350
    opts = SimpleNamespace(dict_cls=None, custom_functions=_Provider())
    with pytest.raises(InvalidArityError):
        search("add(`1`)", DOC, opts)
    with pytest.raises(InvalidTypeError):
        search("add(`1`, `true`)", DOC, opts)
    with pytest.raises(InvalidTypeError):
        search("add(`1`, `\"x\"`)", DOC, opts)


def test_undeclared_or_unsigned_custom_function_is_unknown():
    # spec: N-000344 N-000396 N-000397
    opts = SimpleNamespace(dict_cls=None, custom_functions=_Provider())
    with pytest.raises(UnknownFunctionError):
        search("unsigned(a)", DOC, opts)
    with pytest.raises(UnknownFunctionError):
        search("add(`1`, `2`)", DOC)  # no provider attached


def test_provider_extends_but_cannot_change_builtins():
    # spec: N-000339 N-000340
    class Override(Functions):
        @signature({"types": ["number"]})
        def _func_abs(self, value):
            return -1

    opts = SimpleNamespace(dict_cls=None, custom_functions=Override())
    assert search("abs(`-3`)", DOC, opts) == 3
    assert search("length(s)", DOC, opts) == 5


def test_mapping_type_applies_to_constructed_hashes():
    # spec: N-000323 N-000328 N-000329 N-000330 N-000331 N-000332 N-000334 N-000341
    opts = SimpleNamespace(dict_cls=OrderedDict, custom_functions=None)
    result = search("{x: a.b.c, y: t}", DOC, opts)
    assert isinstance(result, OrderedDict)
    assert list(result) == ["x", "y"]
    assert search("keys(`{}`)", DOC, opts) == []
    assert search("merge({x: a.b.c}, {y: t})", DOC, opts) == {"x": 42, "y": True}


def test_mapping_type_and_provider_together():
    # spec: N-000341 N-000343
    opts = SimpleNamespace(dict_cls=OrderedDict, custom_functions=_Provider())
    assert isinstance(search("{x: add(`1`, `2`)}", DOC, opts), OrderedDict)


def test_options_without_attributes_use_defaults():
    # spec: N-000389 N-000390 N-000391
    assert search("{x: a.b.c}", DOC, SimpleNamespace()) == {"x": 42}


def test_signature_rejects_unknown_type_names():
    # spec: N-000402 N-000404
    with pytest.raises(ValueError):
        signature({"types": ["nonsense"]})
    with pytest.raises(ValueError):
        signature("number")


def test_import_is_pure_python_package_at_root():
    # spec: N-000371 N-000054 N-000055 N-000053 N-000052 N-000050 N-000051
    import os

    root = os.path.dirname(os.path.dirname(os.path.abspath(pathsel.__file__)))
    assert os.path.isdir(os.path.join(root, "pathsel"))
    assert not any(name.endswith((".so", ".pyd", ".dll")) for name in os.listdir(os.path.join(root, "pathsel")))
