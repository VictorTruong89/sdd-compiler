"""Every checklist id in spec/CHECKLIST.md must appear in a `# spec:` marker.

Markers live beside the code or test that satisfies the id (spec MAP.md, How to use, 4).
"""

# spec: N-000405 N-000420

import pathlib
import re

import pytest

ROOT = pathlib.Path(__file__).resolve().parent.parent
CHECKLIST = ROOT / "spec" / "CHECKLIST.md"
ID = re.compile(r"N-\d{6}")


def _checklist_ids():
    if not CHECKLIST.exists():
        pytest.skip("spec/CHECKLIST.md not present")
    return ID.findall(CHECKLIST.read_text(encoding="utf-8"))


def _marked_ids():
    marked = set()
    for folder in ("pathsel", "tests"):
        for path in (ROOT / folder).rglob("*.py"):
            for line in path.read_text(encoding="utf-8").splitlines():
                if "# spec:" in line:
                    marked.update(ID.findall(line))
    return marked


def test_every_checklist_id_is_marked_in_code_or_tests():
    missing = [i for i in _checklist_ids() if i not in _marked_ids()]
    assert missing == []


def test_no_marker_names_an_id_outside_the_checklist():
    known = set(_checklist_ids())
    stray = sorted(i for i in _marked_ids() if i not in known)
    assert stray == []
