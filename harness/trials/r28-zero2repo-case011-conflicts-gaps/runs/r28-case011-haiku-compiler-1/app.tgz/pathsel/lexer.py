"""Tokenizer for the PathSel language.

Token-level failures raise ``TokenSyntaxError`` at the offset where the
unreadable token begins (spec: FP-01 Position; Terminology 'Token-level').
"""

# spec: N-000014

# spec: N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000113 N-000114
# spec: N-000117 N-000118 N-000119 N-000120 N-000121 N-000122 N-000124 N-000237
# spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000260 N-000261
# spec: N-000227 N-000228 N-000229 N-000230 N-000231 N-000239 N-000223 N-000224
# spec: N-000225 N-000226 N-000160 N-000152 N-000155 N-000089 N-000090 N-000091
# spec: N-000092 N-000093 N-000094 N-000095

import json

from .errors import EmptyExpressionError, TokenSyntaxError

_WHITESPACE = " \t\n\r"
_IDENT_START = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDENT_BODY = _IDENT_START | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_HEX = frozenset("0123456789abcdefABCDEF")

# Single-character tokens that always stand alone.
_SIMPLE = {
    ".": "dot",
    "*": "star",
    ",": "comma",
    ":": "colon",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    "@": "current",
    "]": "rbracket",
}


class Token:
    __slots__ = ("type", "value", "pos")

    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos

    def __repr__(self):  # pragma: no cover - debugging aid
        return "Token(%r, %r, %d)" % (self.type, self.value, self.pos)


def _token_error(message, pos):
    return TokenSyntaxError(message, lex_position=pos)


def _read_quoted_identifier(text, start):
    """Read a double-quoted JSON string starting at ``start``. Returns (value, end)."""
    end = start + 1
    n = len(text)
    while end < n:
        ch = text[end]
        if ch == "\\":
            end += 2
            continue
        if ch == '"':
            break
        end += 1
    else:
        raise _token_error("unterminated quoted identifier", start)
    raw = text[start:end + 1]
    try:
        value = json.loads(raw)
    except ValueError:
        raise _token_error("invalid quoted identifier", start)
    if not isinstance(value, str):  # pragma: no cover - always a string here
        raise _token_error("invalid quoted identifier", start)
    return value, end + 1


def _read_raw_string(text, start):
    """Read a single-quoted raw string. ``\\'`` is a quote; ``\\uXXXX`` is decoded."""
    out = []
    i = start + 1
    n = len(text)
    while i < n:
        ch = text[i]
        if ch == "'":
            return "".join(out), i + 1
        if ch == "\\" and i + 1 < n:
            nxt = text[i + 1]
            if nxt == "'":
                out.append("'")
                i += 2
                continue
            if nxt == "u" and i + 6 <= n and all(c in _HEX for c in text[i + 2:i + 6]):
                out.append(chr(int(text[i + 2:i + 6], 16)))
                i += 6
                continue
        out.append(ch)
        i += 1
    raise _token_error("unterminated raw string literal", start)


def _read_json_literal(text, start):
    """Read a backtick literal. Returns (value, end)."""
    end = start + 1
    n = len(text)
    while end < n:
        ch = text[end]
        if ch == "\\":
            end += 2
            continue
        if ch == "`":
            break
        end += 1
    else:
        raise _token_error("unterminated JSON literal", start)
    body = text[start + 1:end]
    try:
        value = json.loads(body)
    except ValueError:
        stripped = body.lstrip(_WHITESPACE)
        try:
            value = json.loads('"' + stripped + '"')
        except ValueError:
            raise _token_error("invalid JSON literal", start)
    return value, end + 1


def _read_number(text, start):
    end = start
    if text[end] == "-":
        end += 1
    while end < len(text) and text[end] in _DIGITS:
        end += 1
    return int(text[start:end]), end


def tokenize(text):
    """Split ``text`` into a list of tokens ending with an ``eof`` token."""
    if len(text) == 0:
        raise EmptyExpressionError(lex_position=0)
    tokens = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in _WHITESPACE:
            i += 1
            continue
        if ch in _IDENT_START:
            end = i + 1
            while end < n and text[end] in _IDENT_BODY:
                end += 1
            tokens.append(Token("unquoted_identifier", text[i:end], i))
            i = end
            continue
        if ch in _DIGITS or (ch == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            value, end = _read_number(text, i)
            tokens.append(Token("number", value, i))
            i = end
            continue
        if ch == "-":
            raise _token_error("unexpected hyphen", i)
        if ch == '"':
            value, end = _read_quoted_identifier(text, i)
            tokens.append(Token("quoted_identifier", value, i))
            i = end
            continue
        if ch == "'":
            value, end = _read_raw_string(text, i)
            tokens.append(Token("literal", value, i))
            i = end
            continue
        if ch == "`":
            value, end = _read_json_literal(text, i)
            tokens.append(Token("literal", value, i))
            i = end
            continue
        if ch == "[":
            # `[]` with nothing between the brackets is the flatten operator.
            if i + 1 < n and text[i + 1] == "]":
                tokens.append(Token("flatten", "[]", i))
                i += 2
                continue
            # `[` followed by optional whitespace and `?` is a filter opener.
            j = i + 1
            while j < n and text[j] in _WHITESPACE:
                j += 1
            if j < n and text[j] == "?":
                tokens.append(Token("filter", "[?", i))
                i = j + 1
                continue
            tokens.append(Token("lbracket", "[", i))
            i += 1
            continue
        if ch in _SIMPLE:
            tokens.append(Token(_SIMPLE[ch], ch, i))
            i += 1
            continue
        if ch == "&":
            if i + 1 < n and text[i + 1] == "&":
                tokens.append(Token("and", "&&", i))
                i += 2
            else:
                tokens.append(Token("expref", "&", i))
                i += 1
            continue
        if ch == "|":
            if i + 1 < n and text[i + 1] == "|":
                tokens.append(Token("or", "||", i))
                i += 2
            else:
                tokens.append(Token("pipe", "|", i))
                i += 1
            continue
        if ch == "=":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token("eq", "==", i))
                i += 2
                continue
            raise _token_error("lone '=' is not an operator", i)
        if ch == "!":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token("ne", "!=", i))
                i += 2
            else:
                tokens.append(Token("not", "!", i))
                i += 1
            continue
        if ch == "<":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token("lte", "<=", i))
                i += 2
            else:
                tokens.append(Token("lt", "<", i))
                i += 1
            continue
        if ch == ">":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token("gte", ">=", i))
                i += 2
            else:
                tokens.append(Token("gt", ">", i))
                i += 1
            continue
        if ch == "?":
            # A question mark outside a filter opener begins no token.
            raise _token_error("unexpected '?'", i)
        raise _token_error("character begins no token: %r" % ch, i)
    tokens.append(Token("eof", "", n))
    return tokens
