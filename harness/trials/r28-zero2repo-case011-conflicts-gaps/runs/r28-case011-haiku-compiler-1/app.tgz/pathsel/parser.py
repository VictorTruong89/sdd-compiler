"""Pratt parser for PathSel expressions.

Binding powers (loosest to tightest): pipe, ||, &&, comparators, !, then the
projection and postfix forms. A projection's right-hand side takes every
following step that binds tighter than the projection's own power, which is the
projection ranking in spec FP-04 (flatten loosest; index/slice/list-wildcard
brackets tightest).
"""

# spec: N-000014 N-000043 N-000044 N-000045 N-000046 N-000047 N-000048 N-000049 N-000158

# spec: N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094
# spec: N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
# spec: N-000103 N-000104 N-000105 N-000106 N-000107 N-000108 N-000117 N-000123
# spec: N-000126 N-000155 N-000183 N-000184 N-000185 N-000200 N-000201 N-000210
# spec: N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000237 N-000238
# spec: N-000240 N-000241 N-000242 N-000253 N-000254 N-000255 N-000256 N-000257
# spec: N-000258 N-000260 N-000261 N-000262 N-000263 N-000264 N-000321 N-000322
# spec: N-000336 N-000337 N-000338 N-000339 N-000042 N-000086 N-000264

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from .lexer import tokenize
from .nodes import (
    And,
    Comparison,
    Expref,
    Field,
    Filter,
    Flatten,
    FunctionCall,
    Identity,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    Or,
    Pipe,
    Projection,
    Slice,
    Subexpression,
    ValueProjection,
)

# Binding power of each token type when it appears in infix/postfix position.
BINDING_POWER = {
    "eof": 0,
    "unquoted_identifier": 0,
    "quoted_identifier": 0,
    "number": 0,
    "literal": 0,
    "current": 0,
    "expref": 0,
    "rbracket": 0,
    "rparen": 0,
    "rbrace": 0,
    "comma": 0,
    "colon": 0,
    "pipe": 1,
    "or": 2,
    "and": 3,
    "eq": 5,
    "ne": 5,
    "lt": 5,
    "lte": 5,
    "gt": 5,
    "gte": 5,
    "flatten": 9,
    "star": 20,
    "filter": 21,
    "dot": 40,
    "not": 45,
    "lbrace": 50,
    "lbracket": 55,
    "lparen": 60,
}

# A projection's right-hand side only starts when the next token binds at least this tightly.
PROJECTION_STOP = 10

_COMPARATORS = {"eq", "ne", "lt", "lte", "gt", "gte"}


class _Parser:
    def __init__(self, text):
        self.text = text
        self.tokens = tokenize(text)
        self.index = 0

    # -- token helpers -------------------------------------------------------

    def _cur(self):
        return self.tokens[self.index]

    def _peek(self, offset):
        i = min(self.index + offset, len(self.tokens) - 1)
        return self.tokens[i]

    def _advance(self):
        tok = self.tokens[self.index]
        if tok.type != "eof":
            self.index += 1
        return tok

    def _error(self, tok, dotted=False):
        """Refusal for an unexpected token.

        End of text is the incomplete kind (an operand or closer is still
        required), except directly after a dot, which is always a syntax failure.
        """
        if tok.type == "eof" and not dotted:
            return IncompleteExpressionError(
                "incomplete expression", lex_position=len(self.text)
            )
        return PathSelSyntaxError("syntax error", lex_position=tok.pos)

    def _match(self, type_):
        tok = self._cur()
        if tok.type != type_:
            raise self._error(tok)
        return self._advance()

    # -- entry ---------------------------------------------------------------

    def parse(self):
        node = self._expression(0)
        tok = self._cur()
        if tok.type != "eof":
            raise self._error(tok)
        return node

    def _expression(self, binding_power):
        tok = self._advance_and_return()
        left = self._nud(tok)
        return self._led_loop(left, binding_power)

    def _advance_and_return(self):
        tok = self._cur()
        self._advance()
        return tok

    def _led_loop(self, left, binding_power):
        while binding_power < BINDING_POWER[self._cur().type]:
            tok = self._advance_and_return()
            left = self._led(tok, left)
        return left

    # -- prefix (nud) forms --------------------------------------------------

    def _nud(self, tok):
        kind = tok.type
        if kind == "unquoted_identifier":
            if self._cur().type == "lparen":
                return FunctionCall(tok.value, self._function_args())
            return Field(tok.value)
        if kind == "quoted_identifier":
            return Field(tok.value)
        if kind == "literal":
            return Literal(tok.value)
        if kind == "current":
            return Identity()
        if kind == "expref":
            return Expref(self._expression(0))
        if kind == "not":
            return Not(self._expression(BINDING_POWER["not"]))
        if kind == "lparen":
            node = self._expression(0)
            self._match("rparen")
            return node
        if kind == "lbrace":
            return self._multiselect_hash()
        if kind == "lbracket":
            tok_next = self._cur()
            if tok_next.type in ("number", "colon"):
                return self._index_or_slice(Identity())
            if tok_next.type == "star" and self._peek(1).type == "rbracket":
                self._advance()
                self._advance()
                return _list_projection(Identity(), self._projection_rhs(BINDING_POWER["star"]))
            return self._multiselect_list()
        if kind == "flatten":
            return Projection(Flatten(Identity()), self._projection_rhs(BINDING_POWER["flatten"]))
        if kind == "filter":
            return self._filter_projection(Identity())
        if kind == "star":
            return ValueProjection(Identity(), self._projection_rhs(BINDING_POWER["star"]))
        raise self._error(tok)

    # -- infix / postfix (led) forms ----------------------------------------

    def _led(self, tok, left):
        kind = tok.type
        if kind == "dot":
            if self._cur().type == "star":
                self._advance()
                return ValueProjection(left, self._projection_rhs(BINDING_POWER["dot"]))
            return Subexpression(left, self._parse_dot(BINDING_POWER["dot"]))
        if kind == "pipe":
            return Pipe(left, self._expression(BINDING_POWER["pipe"]))
        if kind == "or":
            return Or(left, self._expression(BINDING_POWER["or"]))
        if kind == "and":
            return And(left, self._expression(BINDING_POWER["and"]))
        if kind in _COMPARATORS:
            return Comparison(kind, left, self._expression(BINDING_POWER[kind]))
        if kind == "flatten":
            return Projection(Flatten(left), self._projection_rhs(BINDING_POWER["flatten"]))
        if kind == "filter":
            return self._filter_projection(left)
        if kind == "lbracket":
            tok_next = self._cur()
            if tok_next.type in ("number", "colon"):
                return self._index_or_slice(left)
            if tok_next.type == "star" and self._peek(1).type == "rbracket":
                self._advance()
                self._advance()
                return _list_projection(left, self._projection_rhs(BINDING_POWER["star"]))
            raise self._error(tok_next)
        # Any other token that binds here (wildcard, not, object, parenthesis)
        # cannot follow an operand.
        raise self._error(tok)

    # -- pieces --------------------------------------------------------------

    def _filter_projection(self, base):
        predicate = self._expression(0)
        self._match("rbracket")
        return Projection(Filter(base, predicate), self._projection_rhs(BINDING_POWER["filter"]))

    def _index_or_slice(self, left):
        if self._cur().type == "colon" or self._peek(1).type == "colon":
            return self._slice(left)
        tok = self._cur()
        if tok.type != "number":
            raise self._error(tok)
        self._advance()
        self._match("rbracket")
        return Index(left, tok.value)

    def _slice(self, left):
        parts = [None, None, None]
        slot = 0
        tok = self._cur()
        while tok.type != "rbracket" and slot < 3:
            if tok.type == "colon":
                slot += 1
                if slot == 3:
                    raise self._error(tok)
                self._advance()
            elif tok.type == "number":
                parts[slot] = tok.value
                self._advance()
            else:
                raise self._error(tok)
            tok = self._cur()
        self._match("rbracket")
        start, stop, step = parts
        if step == 0:
            raise ZeroSliceStepError("slice step of 0")
        return _list_projection(Slice(left, start, stop, step), self._projection_rhs(BINDING_POWER["star"]))

    def _projection_rhs(self, binding_power):
        tok = self._cur()
        if BINDING_POWER[tok.type] < PROJECTION_STOP:
            return Identity()
        if tok.type in ("lbracket", "filter"):
            return self._expression(binding_power)
        if tok.type == "dot":
            self._advance()
            return self._parse_dot(binding_power)
        raise self._error(tok)

    def _parse_dot(self, binding_power):
        tok = self._cur()
        kind = tok.type
        if kind in ("unquoted_identifier", "quoted_identifier", "star", "lbrace"):
            return self._expression(binding_power)
        if kind == "lbracket":
            # After a dot, square brackets can only open a multiselect list.
            self._advance()
            return self._led_loop(self._multiselect_list(), binding_power)
        raise self._error(tok, dotted=True)

    def _multiselect_list(self):
        items = []
        while True:
            items.append(self._expression(0))
            if self._cur().type == "rbracket":
                break
            self._match("comma")
        self._advance()
        return MultiList(items)

    def _multiselect_hash(self):
        pairs = []
        while True:
            tok = self._cur()
            if tok.type not in ("unquoted_identifier", "quoted_identifier"):
                raise self._error(tok)
            self._advance()
            self._match("colon")
            pairs.append((tok.value, self._expression(0)))
            nxt = self._cur()
            if nxt.type == "comma":
                self._advance()
                continue
            if nxt.type == "rbrace":
                self._advance()
                break
            raise self._error(nxt)
        return MultiHash(pairs)

    def _function_args(self):
        self._advance()  # the opening parenthesis
        args = []
        if self._cur().type == "rparen":
            self._advance()
            return args
        while True:
            args.append(self._expression(0))
            nxt = self._cur()
            if nxt.type == "comma":
                self._advance()
                continue
            if nxt.type == "rparen":
                self._advance()
                break
            raise self._error(nxt)
        return args


def _list_projection(base, rhs):
    """A list-wildcard or slice projection: ``base`` must be an array."""
    return Projection(base, rhs)


def parse(text):
    """Parse ``text`` into an expression tree. Raises a PathSel refusal on failure."""
    if len(text) == 0:
        raise EmptyExpressionError("empty expression", lex_position=0)
    return _Parser(text).parse()
