"""Expression tree and its evaluation.

Each node evaluates against a current value and a context (evaluation options).
Null is Python ``None``; a missing field, an out-of-range index and a selector
applied to the wrong kind of value yield ``None`` rather than failing.
"""

# spec: N-000015 N-000019 N-000020 N-000158 N-000323 N-000324 N-000325 N-000326 N-000327 N-000423

# spec: N-000077 N-000078 N-000079 N-000083 N-000084 N-000085 N-000115 N-000116
# spec: N-000125 N-000126 N-000127 N-000128 N-000129 N-000130 N-000131 N-000132
# spec: N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140
# spec: N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148
# spec: N-000149 N-000150 N-000151 N-000152 N-000153 N-000154 N-000156 N-000157
# spec: N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166
# spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000182
# spec: N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190
# spec: N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000197 N-000198
# spec: N-000199 N-000202 N-000203 N-000204 N-000205 N-000206 N-000207 N-000208
# spec: N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216
# spec: N-000217 N-000218 N-000219 N-000220 N-000221 N-000222 N-000231 N-000232
# spec: N-000233 N-000234 N-000235 N-000236 N-000247 N-000248 N-000249 N-000250
# spec: N-000251 N-000253 N-000254 N-000255 N-000256 N-000257 N-000259 N-000254
# spec: N-000340 N-000341 N-000342 N-000343 N-000328 N-000329 N-000330 N-000331
# spec: N-000332 N-000334 N-000023 N-000024 N-000025 N-000245 N-000246 N-000242
# spec: N-000243 N-000244 N-000069 N-000070 N-000264 N-000265 N-000266 N-000267
# spec: N-000268

import copy

from .errors import ZeroSliceStepError
from .values import (
    ExpressionReference,
    is_array,
    is_false_value,
    is_object,
    is_true_value,
    json_equal,
    ordering,
)


class Context:
    """Per-search evaluation context built from the evaluation options."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    def new_mapping(self):
        # spec: FP-08 mapping type for constructed objects.
        if self.dict_cls is None:
            return {}
        return self.dict_cls()

    def make_reference(self, node):
        return ExpressionReference(node, self._apply_reference)

    def _apply_reference(self, node, value):
        return node.evaluate(value, self)


class Node:
    def evaluate(self, value, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Identity(Node):
    """``@``: the current value itself."""

    def evaluate(self, value, ctx):
        return value


class Field(Node):
    def __init__(self, name):
        self.name = name

    def evaluate(self, value, ctx):
        if is_object(value):
            return value.get(self.name)
        return None


class Subexpression(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Index(Node):
    def __init__(self, left, index):
        self.left = left
        self.index = index

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        n = len(base)
        if -n <= self.index < n:
            return base[self.index]
        return None


class Slice(Node):
    """``[start:stop:step]``. A slice that selects nothing is the empty array."""

    def __init__(self, left, start, stop, step):
        self.left = left
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        step = 1 if self.step is None else self.step
        if step == 0:
            raise ZeroSliceStepError("slice step of 0")
        length = len(base)
        start, stop = self.start, self.stop
        if step > 0:
            lo, hi = 0, length
            start = 0 if start is None else (start + length if start < 0 else start)
            stop = length if stop is None else (stop + length if stop < 0 else stop)
            start = min(max(start, lo), hi)
            stop = min(max(stop, lo), hi)
            out = []
            i = start
            while i < stop:
                out.append(base[i])
                i += step
            return out
        lo, hi = -1, length - 1
        start = hi if start is None else (start + length if start < 0 else start)
        stop = lo if stop is None else (stop + length if stop < 0 else stop)
        start = min(max(start, lo), hi)
        stop = min(max(stop, lo), hi)
        out = []
        i = start
        while i > stop:
            out.append(base[i])
            i += step
        return out


class Flatten(Node):
    """``[]``: one level of array splicing. Non-arrays yield null."""

    def __init__(self, left):
        self.left = left

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        out = []
        for item in base:
            if is_array(item):
                out.extend(item)
            else:
                out.append(item)
        return out


class Projection(Node):
    """Applies ``rhs`` to each element of the array ``base`` and collects non-null results."""

    def __init__(self, base, rhs):
        self.base = base
        self.rhs = rhs

    def evaluate(self, value, ctx):
        base = self.base.evaluate(value, ctx)
        if not is_array(base):
            return None
        out = []
        for item in base:
            result = self.rhs.evaluate(item, ctx)
            if result is not None:
                out.append(result)
        return out


class ValueProjection(Node):
    """Object wildcard: projects over the values of the object ``base``."""

    def __init__(self, base, rhs):
        self.base = base
        self.rhs = rhs

    def evaluate(self, value, ctx):
        base = self.base.evaluate(value, ctx)
        if not is_object(base):
            return None
        out = []
        for item in base.values():
            result = self.rhs.evaluate(item, ctx)
            if result is not None:
                out.append(result)
        return out


class Filter(Node):
    """``[?predicate]``: keeps elements whose predicate is a true value; non-arrays yield null."""

    def __init__(self, base, predicate):
        self.base = base
        self.predicate = predicate

    def evaluate(self, value, ctx):
        base = self.base.evaluate(value, ctx)
        if not is_array(base):
            return None
        return [item for item in base if is_true_value(self.predicate.evaluate(item, ctx))]


class Comparison(Node):
    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        right = self.right.evaluate(value, ctx)
        op = self.op
        if op == "eq":
            return json_equal(left, right)
        if op == "ne":
            return not json_equal(left, right)
        order = ordering(left, right)
        if order is None:
            # Ordering across unlike kinds is not specified; it yields null.
            return None
        if op == "lt":
            return order < 0
        if op == "lte":
            return order <= 0
        if op == "gt":
            return order > 0
        if op == "gte":
            return order >= 0
        raise AssertionError("unknown comparator %r" % op)  # pragma: no cover


class And(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if is_false_value(left):
            return left
        return self.right.evaluate(value, ctx)


class Or(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if is_true_value(left):
            return left
        return self.right.evaluate(value, ctx)


class Not(Node):
    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, value, ctx):
        return is_false_value(self.operand.evaluate(value, ctx))


class Pipe(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Literal(Node):
    def __init__(self, value):
        self.value = value

    def evaluate(self, value, ctx):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class MultiList(Node):
    def __init__(self, items):
        self.items = items

    def evaluate(self, value, ctx):
        if value is None:
            return None
        return [item.evaluate(value, ctx) for item in self.items]


class MultiHash(Node):
    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, ctx):
        if value is None:
            return None
        result = ctx.new_mapping()
        for key, node in self.pairs:
            result[key] = node.evaluate(value, ctx)
        return result


class Expref(Node):
    """``&expr``: a deferred expression reference."""

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, ctx):
        return ctx.make_reference(self.node)


class FunctionCall(Node):
    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, ctx):
        # Imported here to keep the module graph acyclic.
        from .functions import call_function

        return call_function(ctx, self.name, self.args, value)
