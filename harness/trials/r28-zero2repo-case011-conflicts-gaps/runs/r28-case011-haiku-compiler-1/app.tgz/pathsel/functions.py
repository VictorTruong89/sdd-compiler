"""Built-in functions, the provider class and the ``signature`` decorator.

Public names: ``Functions``, ``signature``. The built-in set (spec FP-07) is
implemented as ``_func_<name>`` methods on ``Functions``. A custom provider
subclasses ``Functions`` and adds ``_func_<name>`` methods decorated with
``signature`` (spec Interface Contract > pathsel.functions).
"""

# spec: N-000333 N-000048 N-000323 N-000326

# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268 N-000269
# spec: N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000276 N-000277
# spec: N-000278 N-000279 N-000280 N-000281 N-000282 N-000283 N-000284 N-000285
# spec: N-000286 N-000287 N-000288 N-000289 N-000290 N-000291 N-000292 N-000293
# spec: N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301
# spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
# spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
# spec: N-000318 N-000319 N-000320 N-000321 N-000322 N-000344 N-000345 N-000346
# spec: N-000347 N-000348 N-000349 N-000350 N-000335 N-000336 N-000337 N-000338
# spec: N-000339 N-000340 N-000393 N-000394 N-000395 N-000396 N-000397 N-000398
# spec: N-000399 N-000400 N-000401 N-000402 N-000403 N-000404 N-000058

import math
from collections.abc import Mapping  # noqa: F401  (documents the object check)

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .values import (
    ExpressionReference,
    is_array,
    is_boolean,
    is_number,
    is_object,
    is_string,
    json_equal,
    string_to_number,
    to_json_text,
    type_name,
)


# ---------------------------------------------------------------------------
# Type names accepted in signatures and by built-in parameter declarations.
# spec: N-000402 (the five JSON type names); 'boolean' and 'reference' are
# additions so that booleans and expression references can be declared.
# ---------------------------------------------------------------------------

def _all_numbers(values):
    return all(is_number(v) for v in values)


def _all_strings(values):
    return all(is_string(v) for v in values)


_TYPE_CHECKS = {
    "any": lambda v: True,
    "number": is_number,
    "string": is_string,
    "boolean": is_boolean,
    "array": is_array,
    "object": is_object,
    "null": lambda v: v is None,
    "reference": lambda v: isinstance(v, ExpressionReference),
    "array_of_numbers": lambda v: is_array(v) and _all_numbers(v),
    "array_of_strings": lambda v: is_array(v) and _all_strings(v),
    "array_of_numbers_or_strings": lambda v: is_array(v) and (_all_numbers(v) or _all_strings(v)),
}


def _param_accepts(alternatives, value):
    for name in alternatives:
        if _TYPE_CHECKS[name](value):
            return True
    return False


def _check_params(params, variadic, args):
    """Raise InvalidTypeError if an argument is outside its declared alternatives."""
    for i, arg in enumerate(args):
        if i < len(params):
            alternatives = params[i]
        elif variadic is not None:
            alternatives = variadic
        else:  # pragma: no cover - arity is checked before types
            raise InvalidArityError("too many arguments")
        if not _param_accepts(alternatives, arg):
            raise InvalidTypeError("argument %d has an invalid type" % (i + 1))


# ---------------------------------------------------------------------------
# Public decorator
# ---------------------------------------------------------------------------

_SIGNATURE_TYPE_NAMES = frozenset(
    ["number", "string", "array", "object", "null", "boolean", "any"]
)


def signature(*arguments):
    """Declare the accepted types of a custom function's arguments.

    Each positional argument is a mapping ``{"types": [<type-name>, ...]}``, one
    per parameter in call order. The decorator does not call the implementation;
    it returns the same callable with the declaration attached.
    """
    params = []
    for arg in arguments:
        if not isinstance(arg, Mapping) or "types" not in arg:
            raise ValueError('each signature argument must be {"types": [...]}')
        names = tuple(arg["types"])
        if not names:
            raise ValueError("a signature parameter needs at least one type name")
        for name in names:
            if name not in _SIGNATURE_TYPE_NAMES:
                raise ValueError("unknown type name %r" % (name,))
        params.append(names)

    def decorator(func):
        func._pathsel_params = tuple(params)
        func._pathsel_variadic = None
        return func

    return decorator


def _builtin(*params, variadic=None, min_args=None):
    """Attach a built-in parameter declaration (internal)."""

    declared = tuple((name,) if isinstance(name, str) else tuple(name) for name in params)
    variadic_names = None if variadic is None else (variadic,)

    def decorator(func):
        func._pathsel_params = declared
        func._pathsel_variadic = variadic_names
        func._pathsel_min_args = min_args
        return func

    return decorator


# ---------------------------------------------------------------------------
# Numeric helpers
# ---------------------------------------------------------------------------

def _sum(values):
    total = 0
    try:
        for value in values:
            total = total + value
    except TypeError:
        total = 0.0
        for value in values:
            total = total + float(value)
    return total


def _finite_or_refuse(value):
    """ceil/floor need a finite number; infinity and NaN are outside the accepted values."""
    if isinstance(value, float) and not math.isfinite(value):
        raise InvalidTypeError("argument must be a finite number")


def _key_type_check(keys):
    if not (_all_numbers(keys) or _all_strings(keys)):
        raise InvalidTypeError("sort key must be all numbers or all strings")


# ---------------------------------------------------------------------------
# The built-in provider
# ---------------------------------------------------------------------------

class Functions:
    """A provider implementing the built-in functions.

    Subclass it and add ``_func_<name>`` methods decorated with ``signature`` to
    define custom functions. Built-in names keep their built-in behaviour.
    """

    @_builtin("number")
    def _func_abs(self, value):
        return abs(value)

    @_builtin("array_of_numbers")
    def _func_avg(self, values):
        if len(values) == 0:
            return None
        return _sum(values) / len(values)

    @_builtin("number")
    def _func_ceil(self, value):
        _finite_or_refuse(value)
        return math.ceil(value)

    @_builtin("number")
    def _func_floor(self, value):
        _finite_or_refuse(value)
        return math.floor(value)

    @_builtin(("array", "string"), "any")
    def _func_contains(self, haystack, needle):
        if is_array(haystack):
            return any(json_equal(item, needle) for item in haystack)
        if isinstance(needle, str):
            return needle in haystack
        return False

    @_builtin("string", "string")
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @_builtin("string", "string")
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @_builtin(("string", "array", "object"))
    def _func_length(self, value):
        # spec: FP-07 length counts Unicode characters, not UTF-8 bytes (CF-000035).
        return len(value)

    @_builtin(("string", "array"))
    def _func_reverse(self, value):
        if is_array(value):
            return list(reversed(value))
        return value[::-1]

    @_builtin("string", "array_of_strings")
    def _func_join(self, separator, values):
        # spec: FP-07 'the empty array yields the empty string' (see NOTES.md).
        return separator.join(values)

    @_builtin("object")
    def _func_keys(self, mapping):
        return list(mapping.keys())

    @_builtin("object")
    def _func_values(self, mapping):
        return list(mapping.values())

    @_builtin("any")
    def _func_type(self, value):
        return type_name(value)

    @_builtin("any")
    def _func_to_array(self, value):
        if is_array(value):
            return list(value)
        return [value]

    @_builtin("any")
    def _func_to_string(self, value):
        if is_string(value):
            return value
        return to_json_text(value)

    @_builtin("any")
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if is_string(value):
            return string_to_number(value)
        return None

    @_builtin("array_of_numbers_or_strings")
    def _func_max(self, values):
        if len(values) == 0:
            return None
        return max(values)

    @_builtin("array_of_numbers_or_strings")
    def _func_min(self, values):
        if len(values) == 0:
            return None
        return min(values)

    @_builtin("array_of_numbers_or_strings")
    def _func_sort(self, values):
        return sorted(values)

    @_builtin("array_of_numbers")
    def _func_sum(self, values):
        return _sum(values)

    @_builtin("object", variadic="object", min_args=1)
    def _func_merge(self, *mappings):
        result = {}
        for mapping in mappings:
            for key in mapping:
                result[key] = mapping[key]
        return result

    @_builtin("any", variadic="any", min_args=1)
    def _func_not_null(self, *values):
        # spec: FP-07 not_null: an empty array or empty string is not null (CF-000015).
        for value in values:
            if value is not None:
                return value
        return None

    @_builtin("reference", "array")
    def _func_map(self, reference, values):
        return [reference.apply(item) for item in values]

    @_builtin("array", "reference")
    def _func_sort_by(self, values, reference):
        keys = [reference.apply(item) for item in values]
        _key_type_check(keys)
        order = sorted(range(len(values)), key=lambda i: keys[i])
        return [values[i] for i in order]

    @_builtin("array", "reference")
    def _func_max_by(self, values, reference):
        if len(values) == 0:
            return None
        keys = [reference.apply(item) for item in values]
        _key_type_check(keys)
        best = 0
        for i in range(1, len(values)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @_builtin("array", "reference")
    def _func_min_by(self, values, reference):
        if len(values) == 0:
            return None
        keys = [reference.apply(item) for item in values]
        _key_type_check(keys)
        best = 0
        for i in range(1, len(values)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


_BUILTIN_PROVIDER = Functions()
_BUILTIN_NAMES = frozenset(
    name[len("_func_"):] for name in dir(Functions) if name.startswith("_func_")
)


def _resolve(name, provider):
    """Return (callable, params, variadic, min_args, is_builtin) or raise UnknownFunctionError."""
    if name in _BUILTIN_NAMES:
        func = getattr(_BUILTIN_PROVIDER, "_func_" + name)
        return func, func._pathsel_params, func._pathsel_variadic, func._pathsel_min_args, True
    if provider is None:
        raise UnknownFunctionError("unknown function %r" % (name,))
    func = getattr(provider, "_func_" + name, None)
    params = getattr(func, "_pathsel_params", None)
    if func is None or params is None or not callable(func):
        raise UnknownFunctionError("unknown function %r" % (name,))
    return func, params, None, None, False


def call_function(ctx, name, arg_nodes, value):
    """Evaluate a function call: name check, arity check, argument evaluation, type check, call.

    spec: FP-07 'A call is checked before the function runs: first the name,
    then the argument count, then each argument's type.'
    """
    func, params, variadic, min_args, is_builtin = _resolve(name, ctx.provider)
    count = len(arg_nodes)
    if variadic is not None:
        lowest = 1 if min_args is None else min_args
        if count < lowest:
            raise InvalidArityError("function %r needs at least %d argument(s)" % (name, lowest))
    elif count != len(params):
        raise InvalidArityError("function %r takes %d argument(s)" % (name, len(params)))
    args = [node.evaluate(value, ctx) for node in arg_nodes]
    _check_params(params, variadic, args)
    # Both kinds are bound methods: the provider instance is already the first argument.
    return func(*args)
