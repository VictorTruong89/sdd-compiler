"""Value model helpers: type classification, truthiness, equality, JSON text.

Data model (spec: Full PRD > Non-functional constraints, Terminology):
object = Mapping, array = list or tuple, string = str, number = int/float or
host Decimal (never bool), boolean = bool, null = None.
"""

# spec: N-000014 N-000015 N-000019 N-000020 N-000021 N-000022 N-000023 N-000026 N-000027 N-000028 N-000029 N-000030 N-000031 N-000032 N-000033 N-000037

# spec: N-000056 N-000057 N-000058 N-000024 N-000026 N-000027 N-000028 N-000029
# spec: N-000030 N-000031 N-000032 N-000033 N-000181 N-000242 N-000243 N-000244
# spec: N-000251 N-000252 N-000180 N-000174 N-000175 N-000176 N-000177 N-000178
# spec: N-000179 N-000258 N-000330 N-000283 N-000284 N-000285 N-000286 N-000287
# spec: N-000288 N-000289 N-000282 N-000243

from collections.abc import Mapping
from decimal import Decimal
import json
import math
import re


def is_number(value):
    """True for int, float and host Decimal; a boolean is not a number."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, Mapping)


def is_string(value):
    return isinstance(value, str)


def is_boolean(value):
    return isinstance(value, bool)


def is_false_value(value):
    """The false-value set: false, null, empty string, empty array, empty object.

    spec: Terminology 'False value'. The number 0 is a true value.
    """
    if value is None:
        return True
    if isinstance(value, bool):
        return not value
    if isinstance(value, str):
        return len(value) == 0
    if is_array(value):
        return len(value) == 0
    if is_object(value):
        return len(value) == 0
    return False


def is_true_value(value):
    return not is_false_value(value)


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects, booleans never equal numbers."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) and isinstance(b, str):
        return a == b
    if is_array(a) and is_array(b):
        if len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b:
                return False
            if not json_equal(a[key], b[key]):
                return False
        return True
    if a is b:
        return True
    try:
        return bool(a == b)
    except Exception:  # pragma: no cover - defensive for exotic host values
        return False


def ordering(a, b):
    """Return -1, 0 or 1 for two numbers or two strings; None for other pairs.

    spec: FP-06 `<`, `<=`, `>`, `>=`. Unspecified mixed-type ordering yields
    null (see NOTES.md).
    """
    if is_number(a) and is_number(b):
        pass
    elif isinstance(a, str) and isinstance(b, str):
        pass
    else:
        return None
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


class ExpressionReference:
    """A deferred subexpression written with a leading ampersand.

    ``apply`` is bound by the interpreter so that built-in functions can run the
    referenced expression against each element. spec: FP-05 expression
    references; FP-07 map / sort_by / max_by / min_by.
    """

    __slots__ = ("node", "_apply")

    def __init__(self, node, apply):
        self.node = node
        self._apply = apply

    def apply(self, value):
        return self._apply(self.node, value)

    def __repr__(self):  # pragma: no cover - debugging aid
        return "<ExpressionReference>"


def _float_or_int_text(value):
    if isinstance(value, float):
        return repr(value)  # same spelling json uses for floats
    return str(value)


def to_json_text(value):
    """Compact JSON text: no spaces after ',' or ':', non-ASCII as \\uXXXX escapes.

    spec: FP-07 `to_string`.
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=True)
    if is_number(value):
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            return json.dumps(value)
        return _float_or_int_text(value)
    if is_array(value):
        return "[" + ",".join(to_json_text(item) for item in value) + "]"
    if is_object(value):
        parts = []
        for key in value:
            parts.append(json.dumps(str(key), ensure_ascii=True) + ":" + to_json_text(value[key]))
        return "{" + ",".join(parts) + "}"
    # Host values outside the JSON data model: written as their text, quoted.
    return json.dumps(str(value), ensure_ascii=True)


_INT_NUMERAL = re.compile(r"^-?[0-9]+$")
_FLOAT_NUMERAL = re.compile(r"^-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?$")


def string_to_number(text):
    """Integer numeral -> int; decimal or exponent numeral -> float; else None.

    spec: FP-07 `to_number`.
    """
    if _INT_NUMERAL.match(text):
        return int(text)
    if _FLOAT_NUMERAL.match(text) and ("." in text or "e" in text or "E" in text):
        return float(text)
    return None


def type_name(value):
    """spec: FP-07 `type`. Host values outside the JSON model report 'null'."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, str):
        return "string"
    if is_number(value):
        return "number"
    if is_array(value):
        return "array"
    if is_object(value):
        return "object"
    return "null"
