"""Failure carriers for pathsel.

Every refusal is an instance of ``PathSelError``, which is a ``ValueError``.
The kind of a refusal is carried by the exception type (spec: Interface
Contract > Failure carriers). Type names are the implementer's choice.
"""

# spec: N-000062 N-000036 N-000034 N-000035

# spec: N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412
# spec: N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000421 N-000422 N-000037 N-000061 N-000105 N-000106 N-000382 N-000381
# spec: N-000034 N-000036 N-000063 N-000064 N-000065 N-000102 N-000104 N-000385


class PathSelError(ValueError):
    """Base class of every refusal. Always a ValueError."""


class EmptyExpressionError(PathSelError):
    """The zero-length expression text (empty-expression kind)."""

    def __init__(self, message="empty expression", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class IncompleteExpressionError(PathSelError):
    """Text ends where an operand or a closing token is still required."""

    def __init__(self, message="incomplete expression", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure (the plain syntax kind)."""

    def __init__(self, message="syntax error", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor provided."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
