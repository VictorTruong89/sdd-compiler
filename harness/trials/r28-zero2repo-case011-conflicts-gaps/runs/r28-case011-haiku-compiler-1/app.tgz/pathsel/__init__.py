"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public entries:

* ``search(expression, data, options=None)`` -- one-shot evaluation.
* ``compile(expression)`` -- returns a parsed expression whose
  ``.search(value, options=None)`` evaluates it against any document.

Both entries return the same value for the same expression and document, and
refuse the same expression texts with the same failure kinds.
"""

# spec: N-000015 N-000016 N-000017 N-000018 N-000351 N-000352 N-000353 N-000354 N-000355 N-000356 N-000357 N-000358 N-000359 N-000360 N-000361 N-000362 N-000363 N-000364 N-000365 N-000423

# spec: N-000038 N-000039 N-000040 N-000041 N-000073 N-000074 N-000075 N-000076
# spec: N-000078 N-000079 N-000080 N-000081 N-000082 N-000086 N-000343 N-000372
# spec: N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379 N-000380
# spec: N-000381 N-000382 N-000383 N-000384 N-000385 N-000386 N-000387 N-000388
# spec: N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000050 N-000051
# spec: N-000052 N-000053 N-000054 N-000055 N-000056 N-000059 N-000060 N-000066
# spec: N-000067 N-000068 N-000070 N-000071 N-000072 N-000389 N-000390 N-000391
# spec: N-000392 N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007
# spec: N-000008 N-000009 N-000010 N-000011 N-000012 N-000013

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .nodes import Context
from .parser import parse as _parse

__all__ = [
    "search",
    "compile",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


def _context(options):
    """Read the two optional attributes of an evaluation-options object."""
    if options is None:
        return Context()
    return Context(
        dict_cls=getattr(options, "dict_cls", None),
        provider=getattr(options, "custom_functions", None),
    )


class ParsedExpression:
    """The successful result of ``compile``. Can be searched any number of times."""

    __slots__ = ("expression", "_tree")

    def __init__(self, expression, tree):
        self.expression = expression
        self._tree = tree

    def search(self, value, options=None):
        return self._tree.evaluate(value, _context(options))

    def __repr__(self):
        return "<pathsel.ParsedExpression %r>" % (self.expression,)


def compile(expression):  # noqa: A001 - published name (Interface Contract)
    """Parse ``expression`` once. Raises a PathSel refusal if it is not well-formed."""
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` in one shot."""
    return compile(expression).search(data, options)
