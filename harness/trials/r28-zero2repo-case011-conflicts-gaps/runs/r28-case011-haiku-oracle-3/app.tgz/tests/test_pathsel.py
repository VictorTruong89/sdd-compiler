"""Behavioural tests for pathsel. Names carry the spec node ids they check."""
import collections
from decimal import Decimal

import pytest

import pathsel
from pathsel import compile, search
from pathsel.errors import (EmptyExpressionError, IncompleteExpressionError,
                            InvalidArityError, InvalidTypeError,
                            SyntaxFailure, TokenSyntaxFailure,
                            UnknownFunctionError, ZeroSliceStepError)
from pathsel.functions import Functions, signature

DOC = {
    "a": {"b": {"c": 42}},
    "items": [{"n": 1, "v": "x"}, {"n": 2}, {"n": 3, "v": "z"}],
    "arr": [1, 2, 3, 4, 5],
    "nested": [[1, [2]], [3], 4],
    "s": "héllo",
    "t": True,
    "z": 0,
    "e": "",
    "empty": [],
    "eo": {},
    "k": {"my-key": 1, "has space": 2, "1st": 3, "a.b": 4},
}


def s(expr, data=DOC, options=None):
    return search(expr, data, options)


# ----- FP-01: search, compile, missing paths, failure kinds --------------------

def test_N_000077_dotted_path_returns_field_value():
    assert s("a.b.c") == 42


def test_N_000003_missing_path_is_null():
    assert s("a.missing.c") is None
    assert s("nope") is None


def test_N_000078_N_000079_parsed_expression_reused():
    e = compile("a.b.c")
    assert e.search(DOC) == 42
    assert e.search({"a": {"b": {"c": 7}}}) == 7
    assert e.search({}) is None


def test_N_000080_N_000082_one_shot_equals_compiled():
    for expr in ["items[*].n", "arr[1:4]", "{x: a.b.c}"]:
        assert s(expr) == compile(expr).search(DOC)


def test_N_000083_identifier_on_array_is_null():
    assert s("arr.x") is None


def test_N_000086_compile_succeeds_for_null_result():
    assert compile("nope.nope").search(DOC) is None


def test_N_000087_empty_expression():
    with pytest.raises(EmptyExpressionError) as info:
        s("")
    assert isinstance(info.value, ValueError)


def test_N_000090_N_000093_whitespace_only_is_incomplete_not_empty():
    for text in [" ", "\t", "\n", "\r\n "]:
        with pytest.raises(IncompleteExpressionError) as info:
            s(text)
        assert info.value.lex_position == len(text)


def test_incomplete_positions():
    for text, pos in [("a |", 3), ("a[", 2), ("a[0", 3), ("(a", 2), ("a ==", 4)]:
        with pytest.raises(IncompleteExpressionError) as info:
            s(text)
        assert info.value.lex_position == pos


def test_N_000094_N_000095_syntax_forms():
    for text in ["a.", ".a", "a..b", "a.1", "a.-1", "a.`1`", "a)", "a b",
                 "a[1:2:3:4]", "a[x]", "[1,]", "a.[0]", "foo[*]bar", "a*", "a{"]:
        with pytest.raises(SyntaxFailure) as info:
            s(text)
        assert type(info.value) is SyntaxFailure, text
        assert isinstance(info.value, ValueError)
        assert isinstance(info.value.lex_position, int)


def test_N_000096_N_000101_token_level_is_subclass_of_syntax():
    for text in ["a-b", "a = b", '"unterminated', "`unclosed", "'raw", "é", '"a\\q"']:
        with pytest.raises(TokenSyntaxFailure) as info:
            s(text)
        assert isinstance(info.value, SyntaxFailure)
        assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


def test_N_000102_N_000104_position_is_token_start():
    with pytest.raises(SyntaxFailure) as info:
        s("a b")
    assert info.value.lex_position == 2
    with pytest.raises(SyntaxFailure) as info:
        s("a.")
    assert info.value.lex_position == 2  # end of text counts as a token at its length
    with pytest.raises(TokenSyntaxFailure) as info:
        s("a-b")
    assert info.value.lex_position == 1


def test_N_000105_failures_are_value_errors_and_not_null():
    with pytest.raises(ValueError):
        s("a..b")


# ----- FP-02: identifiers ------------------------------------------------------

def test_N_000107_unquoted_identifier_grammar():
    assert s("_x1", {"_x1": 5}) == 5


def test_N_000110_N_000114_quoted_identifiers():
    assert s('k."my-key"') == 1
    assert s('k."has space"') == 2
    assert s('k."1st"') == 3
    assert s('k."a.b"') == 4
    assert s('"a"') == DOC["a"]
    assert s(r'k."a.b"') == 4


def test_N_000115_N_000116_field_on_non_object_is_null():
    assert s("arr.n") is None
    assert s("s.n") is None


def test_N_000117_number_as_identifier_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("a.1")


def test_N_000108_N_000109_whitespace_between_tokens():
    assert s("  a . b .  c  ") == 42


# ----- FP-03: index, slice, flatten --------------------------------------------

def test_index_and_negative_index_and_out_of_range():
    assert s("arr[0]") == 1
    assert s("arr[-1]") == 5
    assert s("arr[5]") is None
    assert s("arr[-6]") is None
    assert s("a[0]") is None
    assert s("s[0]") is None


def test_slices():
    assert s("arr[1:3]") == [2, 3]
    assert s("arr[:2]") == [1, 2]
    assert s("arr[3:]") == [4, 5]
    assert s("arr[::2]") == [1, 3, 5]
    assert s("arr[::-1]") == [5, 4, 3, 2, 1]
    assert s("arr[-2:]") == [4, 5]
    assert s("arr[10:20]") == []
    assert s("arr[3:1]") == []
    assert s("arr[4:0:-2]") == [5, 3]
    assert s("arr[-100:100]") == [1, 2, 3, 4, 5]


def test_slice_on_non_array_is_null():
    assert s("a[1:2]") is None


def test_zero_slice_step_refused_at_compile():
    with pytest.raises(ZeroSliceStepError) as info:
        compile("arr[::0]")
    assert not isinstance(info.value, SyntaxFailure)
    with pytest.raises(ZeroSliceStepError):
        s("arr[0:2:0]")


def test_flatten_one_level():
    assert s("nested[]") == [1, [2], 3, 4]
    assert s("arr[]") == [1, 2, 3, 4, 5]
    assert s("a[]") is None


def test_flatten_is_projection_and_applies_to_whole_left():
    # flatten is the loosest step: [] after a projection flattens its whole result
    assert s("items[*].n[]") == [1, 2, 3]


def test_flatten_of_projection_result():
    data = {"items": [{"n": [1, [2]]}, {"n": [3]}]}
    assert s("items[*].n[]", data) == [1, [2], 3]


def test_index_on_slice_is_projection():
    # slice is a projection: [0] applies to each selected element
    assert s("arr[0:3][0]") == []  # integers have no index: each projects to null
    assert s("nested[0:2][0]") == [1, 3]


# ----- FP-04: wildcards and filters ---------------------------------------------

def test_list_wildcard():
    assert s("items[*].n") == [1, 2, 3]
    assert s("items[*].v") == ["x", "z"]
    assert s("a[*]") is None
    assert s("arr[*]") == [1, 2, 3, 4, 5]


def test_object_wildcard():
    assert s("k.*") == [1, 2, 3, 4]
    assert s("a.*") == [{"c": 42}]
    assert s("arr.*") is None
    assert s("*", {"x": 1, "y": None, "z": 2}) == [1, 2]


def test_nested_projection_one_inner_array_per_outer():
    assert s("items[*].n[*]", {"items": [{"n": [1, 2]}, {"n": 3}]}) == [[1, 2]]


def test_filter_on_non_array_is_null():
    assert s("a[?x]") is None


def test_filter_keeps_true_values():
    assert s("items[?n > `1`].n") == [2, 3]
    assert s("items[?v].v") == ["x", "z"]
    assert s("arr[?@ > `2`]") == [3, 4, 5]
    assert s("nested[?@]") == [[1, [2]], [3], 4]


def test_zero_is_true_for_filter():
    assert s("arr[?@]") == [1, 2, 3, 4, 5]
    assert s("[`0`, `null`][?@]") == [0]


def test_filter_with_missing_predicate_refused():
    with pytest.raises(SyntaxFailure):
        s("arr[?]")


def test_projection_right_hand_side_ranks():
    # dot joins, comparison ends the projection and compares the whole array
    assert s("items[*].n == `[1, 2, 3]`") is True
    assert s("items[*].n | length(@)") == 3


def test_projection_followed_by_identifier_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("items[*]n")


def test_wildcard_followed_by_number_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("items[*]1")


# ----- FP-05: constructs, pipe, current value, literals ----------------------------

def test_multiselect_hash_and_list():
    assert s("{x: a.b.c, y: arr[0]}") == {"x": 42, "y": 1}
    assert s("{x: a.b.c, m: missing}") == {"x": 42, "m": None}
    assert s("[a.b.c, missing, arr[1]]") == [42, None, 2]


def test_multiselect_quoted_key():
    assert s('{"my key": arr[0]}') == {"my key": 1}


def test_multiselect_on_null_current_is_null():
    assert s("missing.[a, b]") is None
    assert s("missing.{a: b}") is None


def test_multiselect_after_projection_and_dot():
    assert s("items[*].{n: n}") == [{"n": 1}, {"n": 2}, {"n": 3}]
    assert s("items[*][n, v]") == [[1, "x"], [2, None], [3, "z"]]


def test_multiselect_bracket_after_operand_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("arr[a, b]")


def test_pipe_stops_projection():
    assert s("items[*].n | length(@)") == 3
    assert s("a | b") == {"c": 42}
    assert s("a.b | c") == 42


def test_pipe_with_missing_side():
    with pytest.raises(IncompleteExpressionError):
        s("a |")
    with pytest.raises(SyntaxFailure):
        s("| a")  # a pipe where an operand must begin is a syntax failure


def test_current_value():
    assert s("@", 5) == 5
    assert s("@.a", {"a": 1}) == 1
    with pytest.raises(SyntaxFailure):
        s("arr[*].@")


def test_json_literal():
    assert s("`[1, 2]`") == [1, 2]
    assert s("`\"x\"`") == "x"
    assert s("`abc`") == "abc"
    assert s("` hello`") == "hello"
    assert s("`{\"a\": 1}`.a") == 1
    assert s("`[1,2]`[1]") == 2


def test_json_literal_invalid_is_token_error():
    with pytest.raises(TokenSyntaxFailure):
        s('`"a`')


def test_literal_after_dot_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("a.`1`")


def test_raw_string_literal():
    assert s("'hello'", DOC) == "hello"
    assert s("'12'", DOC) == "12"
    assert s("'it\\'s'", DOC) == "it's"
    assert s("'a\\nb'", DOC) == "a\\nb"
    assert s("'  keep  '", DOC) == "  keep  "


def test_expression_reference_standalone_is_non_null():
    assert s("&a") is not None


# ----- FP-06: comparators and logic -------------------------------------------------

def test_equality_is_json_equality():
    assert s("`1` == `1.0`") is True
    assert s("`0` == `false`") is False
    assert s("`1` == `true`") is False
    assert s("`[1, {\"a\": 2}]` == `[1, {\"a\": 2}]`") is True
    assert s("`1` != `2`") is True


def test_ordering():
    assert s("`1` < `2`") is True
    assert s("'a' < 'b'") is True
    assert s("'b' <= 'a'") is False
    assert s("`1` < 'a'") is None


def test_or_and_return_operands():
    assert s("missing || `0`") == 0
    assert s("`1` || `2`") == 1
    assert s("`0` && `2`") == 2
    assert s("missing && `2`") is None
    assert s('`""` || \'x\'') == "x"


def test_not_and_falsy_set():
    assert s("!missing") is True
    assert s("!`0`") is False
    assert s("!`[]`") is True
    assert s("!`{}`") is True
    assert s("!''") is True
    assert s("!`false`") is True


def test_not_binding():
    assert s("!a.b") is None  # (!a).b - dot applies to result of !
    assert s("!a.b.c") is None
    assert s("!(a.b.c)") is False
    assert s("!arr[0]") is False


def test_lone_ampersand_is_syntax():
    with pytest.raises(SyntaxFailure):
        s("a & b")


def test_filter_with_logic_operators():
    assert s("items[?n > `1` && v].v") == ["z"]


# ----- FP-07: functions --------------------------------------------------------

def test_function_name_checked_at_evaluation_not_compile():
    e = compile("nosuch(@)")  # compile succeeds
    with pytest.raises(UnknownFunctionError):
        e.search(DOC)


def test_function_arity_and_type_checked_at_evaluation():
    e = compile("abs(`1`, `2`)")
    with pytest.raises(InvalidArityError):
        e.search(DOC)
    with pytest.raises(InvalidTypeError):
        s("abs(`true`)")
    with pytest.raises(InvalidTypeError):
        s("abs(missing)")


def test_function_kinds_are_distinct_value_errors():
    for text, kind in [("nosuch(@)", UnknownFunctionError), ("abs()", InvalidArityError),
                       ("abs('x')", InvalidTypeError)]:
        with pytest.raises(kind) as info:
            s(text)
        assert isinstance(info.value, ValueError)
        assert type(info.value) is kind


def test_quoted_identifier_cannot_be_function():
    with pytest.raises(SyntaxFailure):
        s('"abs"(@)')


def test_numeric_builtins():
    assert s("abs(`-3`)") == 3
    assert s("ceil(`1.2`)") == 2
    assert s("floor(`1.8`)") == 1
    assert s("sum(`[1, 2.5]`)") == 3.5
    assert s("avg(`[1, 2, 3]`)") == 2
    assert s("avg(`[]`)") is None
    assert s("max(`[1, 9, 3]`)") == 9
    assert s("min(`[1, 9, 3]`)") == 1
    assert s("max(`[]`)") is None
    with pytest.raises(InvalidTypeError):
        s("max(`[1, 'a']`)")


def test_string_builtins():
    assert s("contains(`[1, 2]`, `2`)") is True
    assert s("contains('hello', 'ell')") is True
    with pytest.raises(InvalidTypeError):
        s("contains('hello', `1`)")
    assert s("starts_with('hello', 'he')") is True
    assert s("ends_with('hello', 'lo')") is True
    assert s('join(\', \', `["a", "b"]`)') == "a, b"
    assert s("join(', ', `[]`)") is None
    assert s("reverse('abc')") == "cba"
    assert s("reverse(`[1,2]`)") == [2, 1]


def test_length_counts_characters_and_elements():
    assert s("length(s)") == 5          # 'héllo' is 5 Unicode characters
    assert s("length(arr)") == 5
    assert s("length(k)") == 4
    with pytest.raises(InvalidTypeError):
        s("length(missing)")


def test_keys_values_merge_type():
    assert s("keys(a)") == ["b"]
    assert s("values(a)") == [{"c": 42}]
    assert s("merge(a, `{\"x\": 1}`, `{\"b\": 9}`)") == {"b": 9, "x": 1}
    with pytest.raises(InvalidArityError):
        s("merge()")
    assert s("type(arr)") == "array"
    assert s("type(a)") == "object"
    assert s("type(s)") == "string"
    assert s("type(`1`)") == "number"
    assert s("type(t)") == "boolean"
    assert s("type(missing)") == "null"


def test_conversion_builtins():
    assert s("to_array(`1`)") == [1]
    assert s("to_array(arr)") == [1, 2, 3, 4, 5]
    assert s("to_string(`1`)") == "1"
    assert s("to_string(`{\"a\": [1, \"é\"]}`)") == '{"a":[1,"\\u00e9"]}'
    assert s("to_string(missing)") == "null"
    assert s("to_number('42')") == 42
    assert isinstance(s("to_number('42')"), int)
    assert s("to_number('4.5')") == 4.5
    assert s("to_number('1e2')") == 100.0
    assert s("to_number('abc')") is None
    assert s("to_number(t)") is None


def test_not_null():
    assert s("not_null(missing, a.b.c, arr)") == 42
    assert s("not_null(missing)") is None
    assert s("not_null(e)") == ""
    assert s("not_null(empty)") == []
    with pytest.raises(InvalidArityError):
        s("not_null()")


def test_map_includes_nulls_and_expression_reference():
    assert s("map(&n, items)") == [1, 2, 3]
    assert s("map(&v, items)") == ["x", None, "z"]
    with pytest.raises(InvalidTypeError):
        s("map(n, items)")


def test_sort_by_stable_and_key_checks():
    data = {"xs": [{"k": 2, "id": "a"}, {"k": 1, "id": "b"}, {"k": 2, "id": "c"}, {"k": 1, "id": "d"}]}
    assert [x["id"] for x in s("sort_by(xs, &k)", data)] == ["b", "d", "a", "c"]
    with pytest.raises(InvalidTypeError):
        s("sort_by(xs, &missing)", data)
    assert s("sort_by(`[]`, &k)") == []


def test_max_by_min_by_first_on_tie():
    data = {"xs": [{"k": 2, "id": "a"}, {"k": 1, "id": "b"}, {"k": 2, "id": "c"}]}
    assert s("max_by(xs, &k).id", data) == "a"
    assert s("min_by(xs, &k).id", data) == "b"
    assert s("max_by(`[]`, &k)") is None


def test_sort_builtin():
    assert s("sort(`[3, 1, 2]`)") == [1, 2, 3]
    assert s('sort(`["b", "a"]`)') == ["a", "b"]


def test_function_call_as_projection_right_hand_side():
    data = {"xs": [[1, 2], "ab", [3]]}
    # the call runs per element; nulls from the call are dropped by the projection
    assert s("xs[*]length(@)", data) == [2, 2, 1]
    with pytest.raises(InvalidTypeError):
        s("xs[*]length(@)", {"xs": [7]})  # a non-length argument is invalid-type, not null


# ----- FP-08: options --------------------------------------------------------------

class _Opts:
    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


def test_dict_cls_used_for_constructed_hashes_and_is_object_for_selection():
    out = s("{x: arr[0]}", DOC, _Opts(dict_cls=collections.OrderedDict))
    assert type(out) is collections.OrderedDict
    assert s("{x: arr[0]}.x", DOC, _Opts(dict_cls=collections.OrderedDict)) == 1
    assert s("length({x: arr[0]})", DOC, _Opts(dict_cls=collections.OrderedDict)) == 1
    assert s("keys({x: arr[0]})", DOC, _Opts(dict_cls=collections.OrderedDict)) == ["x"]


class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["string"]})
    def _func_repeat(self, n, text):
        return text * int(n)

    @signature({"types": ["array"]})
    def _func_zero(self, arr):
        return 0


def test_custom_function_and_builtins_remain():
    opts = _Opts(custom_functions=Provider())
    assert s("repeat(`2`, 'ab')", DOC, opts) == "abab"
    assert s("zero(arr)", DOC, opts) == 0
    assert s("abs(`-1`)", DOC, opts) == 1


def test_custom_function_arity_and_type():
    opts = _Opts(custom_functions=Provider())
    with pytest.raises(InvalidArityError):
        s("repeat(`2`)", DOC, opts)
    with pytest.raises(InvalidTypeError):
        s("repeat('x', 'ab')", DOC, opts)


def test_custom_name_only_on_other_provider_is_unknown():
    with pytest.raises(UnknownFunctionError):
        s("repeat(`2`, 'ab')")
    with pytest.raises(UnknownFunctionError):
        s("repeat(`2`, 'ab')", DOC, _Opts(custom_functions=Functions()))


def test_compile_custom_without_provider_succeeds():
    e = compile("repeat(`2`, 'ab')")
    with pytest.raises(UnknownFunctionError):
        e.search(DOC)
    assert e.search(DOC, _Opts(custom_functions=Provider())) == "abab"


def test_custom_function_returns_zero_and_empty_containers():
    class Q(Functions):
        @signature()
        def _func_zero_arg(self):
            return 0

        @signature({"types": ["number"]})
        def _func_empty(self, n):
            return {}

    opts = _Opts(custom_functions=Q())
    assert s("zero_arg()", DOC, opts) == 0
    with pytest.raises(InvalidArityError):
        s("zero_arg(`1`)", DOC, opts)
    assert s("empty(`1`)", DOC, opts) == {}


# ----- Constraints: values, mutability, no network, ValueError -------------------

def test_N_000056_N_000058_decimal_is_number():
    data = {"d": Decimal("1.5")}
    assert s("d", data) == Decimal("1.5")
    assert s("d > `1`", data) is True
    assert s("type(d)", data) == "number"


def test_N_000069_input_not_mutated():
    data = {"items": [{"n": 1}]}
    s("{x: items}", data)
    assert data == {"items": [{"n": 1}]}


def test_N_000063_all_refusals_are_value_errors():
    for text in ["", " ", "a.", "a-b", "abs()", "nosuch(1)", "arr[::0]"]:
        with pytest.raises(ValueError):
            s(text)


def test_package_public_names():
    assert callable(pathsel.search) and callable(pathsel.compile)
    assert issubclass(pathsel.PathSelError, ValueError)
