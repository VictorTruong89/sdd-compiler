# Traceability

Status of every checklist id in `spec/CHECKLIST.md` (423 ids).

- **implemented**: behaviour is in the code location given; exercised by `tests/test_pathsel.py` (81 tests, run with `python3 -m pytest tests`).
- **by design**: a statement about the product shape or packaging; satisfied by the layout, the absence of extra surfaces, or `pyproject.toml`, not by a runtime check.
- **choice**: an implementer's choice the spec leaves open; the choice is in NOTES.md §2.
- **partial**: implemented with the spec's own exception; reason given.
- **not done**: superseded by a conflict resolved the other way (NOTES.md §1); reason given.

Pack 14 (hardware requirements, overview) has no checklist ids.

| Pack | Ids | Status | Where | Notes |
|---|---|---|---|---|
| 01 | N-000001–N-000013 (13) | 9 implemented, 4 by design | api.py; parser.py; nodes.py | by design: N-000010, N-000011, N-000012, N-000013 |
| 02 | N-000014–N-000037 (24) | 19 implemented, 5 not done | values.py; api.py; nodes.py; errors.py | N-000022: superseded by N-000300 (CF-000015): empty string/array are not null for not_null; N-000023: superseded by N-000287 (CF-000057): an integer numeral gives an int from to_number; N-000026: superseded by N-000277 (CF-000035): length counts Unicode code points, not UTF-8 bytes; N-000028: superseded by N-000234 and N-000423 (CF-000056): a bare expression reference is non-null; N-000031: superseded by N-000165 (CF-000027): object wildcard on a non-object is null |
| 03 | N-000038–N-000049 (12) | 10 implemented, 2 by design | __init__.py; api.py | by design: N-000038, N-000039 |
| 04 | N-000050–N-000066 (17) | 11 implemented, 6 by design | values.py; errors.py; pyproject.toml | by design: N-000050, N-000051, N-000052, N-000053, N-000054, N-000055 |
| 05 | N-000067–N-000072 (6) | 2 implemented, 3 by design, 1 choice | nodes.py (no mutation: input is never written) | N-000071: decision: no development tooling is part of the product (no CLI, no tooling module); by design: N-000067, N-000068, N-000072 |
| 06 | N-000073–N-000106 (34) | 34 implemented | api.py; parser.py; errors.py | — |
| 07 | N-000107–N-000125 (19) | 19 implemented | lexer.py; nodes.py (Field) | — |
| 08 | N-000126–N-000157 (32) | 30 implemented, 2 not done | nodes.py (Index, SliceProjection, FlattenProjection) | N-000133: superseded by N-000152 (CF-000055): a step of 0 is refused, not an empty array; N-000157: superseded by N-000142 (CF-000007): a slice of a non-array is null |
| 09 | N-000158–N-000205 (48) | 46 implemented, 2 choice | nodes.py (ListProjection, ObjectProjection, FilterProjection); parser.py | N-000198: implementer's choice: a slice is always a projection (NOTES §2); N-000199: implementer's choice: later steps join a dot-then-hash/list right-hand side (NOTES §2) |
| 10 | N-000206–N-000241 (36) | 34 implemented, 1 partial, 1 not done | nodes.py (MultiList, MultiHash, Subexpression, Literal, ExpressionRef); parser.py; lexer.py | N-000212: superseded by N-000218 (CF-000011): a null current value yields null; N-000227: raw strings: only \uXXXX is decoded (N-000239, CF-000049); see NOTES §1.1 |
| 11 | N-000242–N-000261 (20) | 19 implemented, 1 not done | values.py (json_equal, is_false); nodes.py (Comparison, And, Or, Not); parser.py binding powers | N-000259: superseded by N-000202 (CF-000005): a filter of a non-array is null |
| 12 | N-000262–N-000322 (61) | 60 implemented, 1 not done | functions.py (Functions, Entry.check_count/check_types); nodes.py (FunctionCall) | N-000280: superseded by N-000268 (CF-000054): join of an empty array is null |
| 13 | N-000323–N-000350 (28) | 28 implemented | api.py (_context); functions.py (build_registry); nodes.py (MultiHash) | — |
| 15 | N-000351–N-000354 (4) | 4 by design | by design (pure Python) | by design: N-000351, N-000352, N-000353, N-000354 |
| 16 | N-000355–N-000365 (11) | 11 by design | pyproject.toml; flat layout | by design: N-000355, N-000356, N-000357, N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364, N-000365 |
| 17 | N-000366–N-000368 (3) | 3 by design | no CLI, no __main__ | by design: N-000366, N-000367, N-000368 |
| 18 | N-000369–N-000371 (3) | 3 by design | pathsel/ at repository root | by design: N-000369, N-000370, N-000371 |
| 19 | N-000372–N-000374 (3) | 3 implemented | __init__.py | — |
| 20 | N-000375–N-000382 (8) | 8 implemented | api.py (search) | — |
| 21 | N-000383–N-000388 (6) | 5 implemented, 1 choice | api.py (compile, ParsedExpression) | N-000385: implementer's choice: compile returns pathsel.ParsedExpression (NOTES §2) |
| 22 | N-000389–N-000392 (4) | 3 implemented, 1 choice | api.py (_context: dict_cls, custom_functions) | N-000392: implementer's choice: no options class; duck-typed attributes (NOTES §2) |
| 23 | N-000393–N-000404 (12) | 12 implemented | functions.py (Functions, signature) | — |
| 24 | N-000405–N-000422 (18) | 16 implemented, 2 choice | errors.py | N-000407: implementer's choice: exception type names (NOTES §2); N-000408: implementer's choice: report text (NOTES §2) |
| 25 | N-000423–N-000423 (1) | 1 implemented | values.py (ExpressionReference) | — |

## Not done (with reasons)

- N-000022: superseded by N-000300 (CF-000015): empty string/array are not null for not_null
- N-000023: superseded by N-000287 (CF-000057): an integer numeral gives an int from to_number
- N-000026: superseded by N-000277 (CF-000035): length counts Unicode code points, not UTF-8 bytes
- N-000028: superseded by N-000234 and N-000423 (CF-000056): a bare expression reference is non-null
- N-000031: superseded by N-000165 (CF-000027): object wildcard on a non-object is null
- N-000133: superseded by N-000152 (CF-000055): a step of 0 is refused, not an empty array
- N-000157: superseded by N-000142 (CF-000007): a slice of a non-array is null
- N-000212: superseded by N-000218 (CF-000011): a null current value yields null
- N-000259: superseded by N-000202 (CF-000005): a filter of a non-array is null
- N-000280: superseded by N-000268 (CF-000054): join of an empty array is null

