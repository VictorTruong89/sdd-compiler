"""Pratt parser for PathSel.

Binding powers (tighter = larger). Projection right-hand sides are parsed with
the binding power of their form, which realises the FP-04 ranking:
flatten 9 (loosest projection), list/slice/object wildcard 20, filter 21,
dot 40, index-like bracket 55.
"""

from . import nodes as N
from .errors import (EmptyExpressionError, IncompleteExpressionError,
                     SyntaxFailure, ZeroSliceStepError)
from .lexer import Lexer

LBP = {
    "|": 1,
    "||": 2,
    "&&": 3,
    "==": 5, "!=": 5, "<": 5, "<=": 5, ">": 5, ">=": 5,
    ".": 40,
    "[": 55,
}
COMPARATORS = frozenset(["==", "!=", "<", "<=", ">", ">="])
FLATTEN_BP = 9
LIST_WILDCARD_BP = 20
FILTER_BP = 21
NOT_BP = 45
# Tokens that may directly follow a projection form without starting a right-hand side.
PROJECTION_END = frozenset(["|", "||", "&&", ",", ")", "]", "}", ":"]) | COMPARATORS


class Parser:
    # spec: N-000073 N-000087 N-000090 N-000091 N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104 N-000123 N-000253 N-000254 N-000255 N-000256 N-000257 N-000261
    def __init__(self, text):
        self.text = text
        self.end = len(text)
        self.lexer = Lexer(text)
        self.buf = []

    # ----- token access -------------------------------------------------
    def peek(self, k=0):
        while len(self.buf) <= k:
            self.buf.append(self.lexer.next_token())
        return self.buf[k]

    def advance(self):
        tok = self.peek()
        self.buf.pop(0)
        return tok

    def is_punct(self, tok, value):
        return tok.kind == "punct" and tok.value == value

    def current_lbp(self):
        """Binding power of the next token as a continuation step.

        `[]` is a flatten step (rank 1) and `[?` a filter step (rank 3) even though
        both start with a bracket, so they do not join tighter projections.
        """
        tok = self.peek()
        if tok.kind != "punct":
            return 0
        if tok.value == "[":
            nxt = self.peek(1)
            if self.is_punct(nxt, "]"):
                return FLATTEN_BP
            if self.is_punct(nxt, "?"):
                return FILTER_BP
        return LBP.get(tok.value, 0)

    # ----- failures -----------------------------------------------------
    def syntax(self, tok):
        if tok.kind == "eof":
            return self.incomplete(tok)
        raise SyntaxFailure("unexpected token at %d" % tok.pos, tok.pos)

    def incomplete(self, tok=None):
        pos = self.end if tok is None else tok.pos
        raise IncompleteExpressionError("expression ends too early", pos)

    def expect(self, value):
        tok = self.peek()
        if self.is_punct(tok, value):
            return self.advance()
        return self.syntax(tok)

    # ----- Pratt core ---------------------------------------------------
    def expression(self, rbp=0):
        left = self.nud(self.advance())
        return self.continue_expression(left, rbp)

    def continue_expression(self, left, rbp):
        while rbp < self.current_lbp():
            tok = self.advance()
            left = self.led(tok, left)
        return left

    def nud(self, tok):
        kind, value = tok.kind, tok.value
        if kind == "eof":
            return self.incomplete(tok)
        if kind == "ident":
            if self.is_punct(self.peek(), "("):
                return self.function_call(value)
            return N.Field(value)
        if kind == "quoted":
            if self.is_punct(self.peek(), "("):
                raise SyntaxFailure("quoted identifier cannot name a function", self.peek().pos)
            return N.Field(value)
        if kind in ("literal", "raw"):
            return N.Literal(value)
        if kind == "punct":
            if value == "@":
                return N.Identity()
            if value == "&":
                return N.ExpressionRef(self.expression(0))
            if value == "!":
                return N.Not(self.expression(NOT_BP))
            if value == "(":
                inner = self.expression(0)
                self.expect(")")
                return inner
            if value == "[":
                return self.bracket(after_operand=False)
            if value == "*":
                return N.ObjectProjection(self.projection_rhs(LIST_WILDCARD_BP))
            if value == "{":
                return self.multi_hash()
        return self.syntax(tok)

    def led(self, tok, left):
        value = tok.value
        if value == ".":
            return N.Subexpression(left, self.dot_rhs())
        if value == "[":
            return N.Subexpression(left, self.bracket(after_operand=True))
        if value == "|":
            return N.Subexpression(left, self.expression(1))
        if value == "||":
            return N.Or(left, self.expression(2))
        if value == "&&":
            return N.And(left, self.expression(3))
        if value in COMPARATORS:
            return N.Comparison(value, left, self.expression(5))
        return self.syntax(tok)

    # ----- pieces -------------------------------------------------------
    def function_call(self, name):
        self.advance()  # '('
        args = []
        if self.is_punct(self.peek(), ")"):
            self.advance()
            return N.FunctionCall(name, args)
        while True:
            args.append(self.expression(0))
            tok = self.peek()
            if self.is_punct(tok, ","):
                self.advance()
                continue
            self.expect(")")
            return N.FunctionCall(name, args)

    def dot_rhs(self):
        """Right side of a dot: identifier, `*`, multiselect list or hash."""
        tok = self.peek()
        if tok.kind in ("ident", "quoted"):
            self.advance()
            return N.Field(tok.value)
        if self.is_punct(tok, "*"):
            self.advance()
            return N.ObjectProjection(self.projection_rhs(LIST_WILDCARD_BP))
        if self.is_punct(tok, "["):
            nxt = self.peek(1)
            if self.is_punct(nxt, "*"):
                raise SyntaxFailure("a dot cannot be followed by a list wildcard", nxt.pos)
            self.advance()
            return self.multi_list()
        if self.is_punct(tok, "{"):
            self.advance()
            return self.multi_hash()
        # a dot not followed by a valid step is syntax, including at end of text
        raise SyntaxFailure("a dot must be followed by a step", tok.pos)

    def multi_list(self):
        """After '[' has been consumed."""
        items = []
        while True:
            items.append(self.expression(0))
            tok = self.peek()
            if self.is_punct(tok, ","):
                self.advance()
                continue
            self.expect("]")
            return N.MultiList(items)

    def multi_hash(self):
        """After '{' has been consumed."""
        pairs = []
        while True:
            key_tok = self.advance()
            if key_tok.kind not in ("ident", "quoted"):
                self.syntax(key_tok)
            self.expect(":")
            pairs.append((key_tok.value, self.expression(0)))
            tok = self.peek()
            if self.is_punct(tok, ","):
                self.advance()
                continue
            self.expect("}")
            return N.MultiHash(pairs)

    def bracket(self, after_operand):
        """Bracket after '[' has been consumed; after_operand selects the led rules."""
        tok = self.peek()
        if tok.kind == "number" or self.is_punct(tok, ":"):
            return self.index_or_slice()
        if self.is_punct(tok, "*"):
            if self.is_punct(self.peek(1), "]"):
                self.advance()
                self.advance()
                return N.ListProjection(self.projection_rhs(LIST_WILDCARD_BP))
            if after_operand:
                if self.peek(1).kind == "eof":
                    self.incomplete(self.peek(1))
                raise SyntaxFailure("unexpected bracket content", tok.pos)
        if self.is_punct(tok, "]"):
            self.advance()
            return N.FlattenProjection(self.projection_rhs(FLATTEN_BP))
        if self.is_punct(tok, "?"):
            self.advance()
            predicate = self.expression(0)
            self.expect("]")
            return N.FilterProjection(predicate, self.projection_rhs(FILTER_BP))
        if after_operand:
            if tok.kind == "eof":
                return self.incomplete(tok)
            raise SyntaxFailure("unexpected bracket content", tok.pos)
        return self.multi_list()

    def index_or_slice(self):
        """After '[' has been consumed; current token is a number or ':'."""
        parts = [None]
        colons = 0
        tok = self.peek()
        if tok.kind == "number":
            parts[0] = self.advance().value
            tok = self.peek()
        if not self.is_punct(tok, ":"):
            self.expect("]")
            return N.Index(parts[0])
        while self.is_punct(self.peek(), ":"):
            colon = self.advance()
            colons += 1
            if colons > 2:
                raise SyntaxFailure("slice has more than three parts", colon.pos)
            parts.append(None)
            if self.peek().kind == "number":
                parts[-1] = self.advance().value
        self.expect("]")
        start, stop = parts[0], parts[1]
        step = parts[2] if len(parts) > 2 else None
        if step == 0:
            raise ZeroSliceStepError("slice step of 0")
        return N.SliceProjection(start, stop, step, self.projection_rhs(LIST_WILDCARD_BP))

    def projection_rhs(self, bp):
        """Right-hand side of a projection form, applied to each element."""
        tok = self.peek()
        if self.is_punct(tok, "."):
            self.advance()
            return self.continue_expression(N.Subexpression(N.Identity(), self.dot_rhs()), bp)
        if self.is_punct(tok, "["):
            if self.is_punct(self.peek(1), "]"):
                return N.Identity()  # flatten never begins a right-hand side
            return self.expression(bp)
        if tok.kind == "ident" and self.is_punct(self.peek(1), "("):
            return self.expression(bp)  # a function call may be a projection's right-hand side
        if tok.kind == "punct" and tok.value in ("*", "{", "("):
            raise SyntaxFailure("projection followed by an invalid form", tok.pos)
        return N.Identity()

    # ----- entry --------------------------------------------------------
    def parse(self):
        node = self.expression(0)
        tok = self.peek()
        if tok.kind != "eof":
            raise SyntaxFailure("token left over after a complete expression", tok.pos)
        return node


def parse(text):
    # spec: N-000087 N-000088 N-000089
    if text == "":
        raise EmptyExpressionError("empty expression")
    return Parser(text).parse()
