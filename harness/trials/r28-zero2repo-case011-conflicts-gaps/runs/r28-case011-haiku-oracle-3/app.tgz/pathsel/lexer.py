"""Tokenizer for the PathSel language.

Tokens are produced on demand, so the first failure in source order is the one
reported (FP-01 position rule).
"""

import json

from .errors import TokenSyntaxFailure

WHITESPACE = " \t\n\r"
IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
IDENT_CONT = IDENT_START | frozenset("0123456789")
DIGITS = frozenset("0123456789")
HEX = frozenset("0123456789abcdefABCDEF")

TWO_CHAR = {"||", "&&", "==", "!=", "<=", ">="}
ONE_CHAR = set(".*[]{}(),:@&|!<>?")


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind    # 'ident', 'quoted', 'number', 'literal', 'raw', 'punct', 'eof'
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.kind, self.value, self.pos)


class Lexer:
    # spec: N-000107 N-000109 N-000110 N-000111 N-000112 N-000113 N-000114 N-000117 N-000119 N-000120 N-000121 N-000122 N-000124 N-000227 N-000229 N-000230 N-000237 N-000238 N-000239 N-000260
    def __init__(self, text):
        self.text = text
        self.i = 0
        self.n = len(text)

    def fail(self, message, pos):
        raise TokenSyntaxFailure(message, pos)

    def next_token(self):
        text, n = self.text, self.n
        while self.i < n and text[self.i] in WHITESPACE:
            self.i += 1
        if self.i >= n:
            return Token("eof", None, n)
        start = self.i
        c = text[start]

        if c in IDENT_START:
            j = start + 1
            while j < n and text[j] in IDENT_CONT:
                j += 1
            self.i = j
            return Token("ident", text[start:j], start)

        if c in DIGITS or (c == "-" and start + 1 < n and text[start + 1] in DIGITS):
            j = start + 1
            while j < n and text[j] in DIGITS:
                j += 1
            self.i = j
            return Token("number", int(text[start:j]), start)

        if c == "-":
            self.fail("a hyphen begins no token", start)

        if c == '"':
            return self._quoted(start)
        if c == "`":
            return self._literal(start)
        if c == "'":
            return self._raw(start)

        two = text[start:start + 2]
        if two in TWO_CHAR:
            self.i = start + 2
            return Token("punct", two, start)
        if c == "=":
            self.fail("a lone '=' begins no token", start)
        if c in ONE_CHAR:
            self.i = start + 1
            return Token("punct", c, start)
        self.fail("character begins no token", start)

    def _quoted(self, start):
        text, n = self.text, self.n
        j = start + 1
        while j < n:
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == '"':
                break
            j += 1
        if j >= n:
            self.fail("unterminated quoted identifier", start)
        try:
            value = json.loads(text[start:j + 1])
        except ValueError:
            self.fail("quoted identifier is not a legal JSON string", start)
        self.i = j + 1
        return Token("quoted", value, start)

    def _literal(self, start):
        text, n = self.text, self.n
        j = start + 1
        while j < n:
            ch = text[j]
            if ch == "\\" and j + 1 < n and text[j + 1] == "`":
                j += 2
                continue
            if ch == "`":
                break
            j += 1
        if j >= n:
            self.fail("unclosed JSON literal", start)
        content = text[start + 1:j].replace("\\`", "`")
        self.i = j + 1
        try:
            return Token("literal", json.loads(content), start)
        except ValueError:
            pass
        try:
            return Token("literal", json.loads('"' + content.lstrip(WHITESPACE) + '"'), start)
        except ValueError:
            self.fail("JSON literal is neither JSON nor JSON string content", start)

    def _raw(self, start):
        text, n = self.text, self.n
        out = []
        j = start + 1
        while True:
            if j >= n:
                self.fail("unclosed raw string literal", start)
            ch = text[j]
            if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                out.append("'")
                j += 2
            elif (ch == "\\" and j + 6 <= n and text[j + 1] == "u"
                  and all(h in HEX for h in text[j + 2:j + 6])):
                out.append(chr(int(text[j + 2:j + 6], 16)))
                j += 6
            elif ch == "'":
                j += 1
                break
            else:
                out.append(ch)
                j += 1
        self.i = j
        return Token("raw", "".join(out), start)
