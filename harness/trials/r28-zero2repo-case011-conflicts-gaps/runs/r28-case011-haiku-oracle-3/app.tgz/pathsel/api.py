"""Public entries: search (one shot) and compile (parse once, search many).
"""

from .errors import UnknownFunctionError
from .functions import build_registry
from .parser import parse


class Context:
    """Per-search state: constructed-mapping type and the function registry."""

    def __init__(self, dict_cls, registry):
        self.dict_cls = dict_cls
        self.registry = registry

    def function(self, name):
        entry = self.registry.get(name)
        if entry is None:
            raise UnknownFunctionError("unknown function %r" % (name,))
        return entry


def _context(options):
    if options is None:
        return Context(None, build_registry(None))
    dict_cls = getattr(options, "dict_cls", None)
    provider = getattr(options, "custom_functions", None)
    return Context(dict_cls, build_registry(provider))


class ParsedExpression:
    # spec: N-000018 N-000078 N-000079 N-000383 N-000384 N-000385 N-000386 N-000387 N-000388
    """A compiled expression. Searching it is the same as one-shot search."""

    def __init__(self, text, node):
        self.text = text
        self._node = node

    def search(self, value, options=None):
        return self._node.evaluate(value, _context(options))

    def __repr__(self):
        return "<ParsedExpression %r>" % (self.text,)


def compile(expression):  # noqa: A001 - published name (Interface Contract)
    # spec: N-000004 N-000005 N-000006 N-000007 N-000017 N-000018 N-000080 N-000082 N-000086
    """Parse an expression once. Raises a failure kind (see errors) on refusal."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    # spec: N-000001 N-000002 N-000003 N-000004 N-000016 N-000080 N-000082 N-000372 N-000375 N-000376 N-000377 N-000378 N-000379 N-000380
    """Evaluate an expression against data in one shot."""
    return compile(expression).search(data, options)
