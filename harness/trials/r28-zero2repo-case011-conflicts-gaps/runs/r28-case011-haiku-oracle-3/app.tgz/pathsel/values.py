"""Value model helpers: JSON-like type predicates, truthiness and equality.
"""

from collections.abc import Mapping
from decimal import Decimal


def is_number(value):
    # spec: N-000023 N-000024 N-000025 N-000056
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, Mapping)


def is_string(value):
    return isinstance(value, str)


def is_false(value):
    # spec: N-000029 N-000174 N-000175
    """The false-value set: false, null, empty string, empty array, empty object.

    """
    if value is None or value is False:
        return True
    if isinstance(value, str):
        return value == ""
    if is_array(value) or is_object(value):
        return len(value) == 0
    return False


def is_true(value):
    return not is_false(value)


def json_equal(a, b):
    # spec: N-000242 N-000243 N-000244 N-000180 N-000181
    """Deep JSON equality; a number is never equal to a boolean.

    """
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and a == b
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) or is_object(b):
        if not (is_object(a) and is_object(b)) or len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    return a is b or a == b


class ExpressionReference:
    # spec: N-000028 N-000234 N-000235 N-000236 N-000423
    """A deferred subexpression (`&expr`). Built-ins apply it to elements.

    """

    __slots__ = ("node", "context")

    def __init__(self, node, context):
        self.node = node
        self.context = context

    def apply(self, value):
        return self.node.evaluate(value, self.context)

    def __repr__(self):
        return "<ExpressionReference>"
