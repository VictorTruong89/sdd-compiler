"""AST nodes. Every node evaluates against a current value.
"""

import copy

from .values import (ExpressionReference, is_array, is_false, is_number,
                     is_object, is_true, json_equal)


def _project(items, rhs, ctx):
    # spec: N-000204 N-000205
    """Apply rhs to each item and collect the non-null results (projection).

    """
    out = []
    for item in items:
        result = rhs.evaluate(item, ctx)
        if result is not None:
            out.append(result)
    return out


def slice_indices(length, start, stop, step):
    # spec: N-000131 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141
    """Index list selected by a slice (FP-03 rules). step must not be 0.

    """
    if step is None:
        step = 1

    def clamp(v, lo, hi):
        return lo if v < lo else hi if v > hi else v

    if start is not None and start < 0:
        start += length
    if stop is not None and stop < 0:
        stop += length
    if step > 0:
        start = 0 if start is None else clamp(start, 0, length)
        stop = length if stop is None else clamp(stop, 0, length)
    else:
        start = length - 1 if start is None else clamp(start, -1, length - 1)
        stop = -1 if stop is None else clamp(stop, -1, length - 1)
    out = []
    i = start
    if step > 0:
        while i < stop:
            out.append(i)
            i += step
    else:
        while i > stop:
            out.append(i)
            i += step
    return out


class Node:
    def evaluate(self, value, ctx):
        raise NotImplementedError


class Identity(Node):
    """The current value (`@`, or an empty projection right-hand side)."""

    def evaluate(self, value, ctx):
        return value


class Field(Node):
    # spec: N-000107 N-000108 N-000110 N-000114 N-000115 N-000116 N-000125
    """Field selection by identifier."""

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, ctx):
        if is_object(value):
            return value.get(self.name)
        return None


class Index(Node):
    # spec: N-000126 N-000128 N-000129
    """Single index, negative counts from the end."""

    def __init__(self, index):
        self.index = index

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        n = len(value)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return value[i]
        return None


class SliceProjection(Node):
    # spec: N-000130 N-000142 N-000143 N-000144
    """Slice; a projection over the selected elements."""

    def __init__(self, start, stop, step, rhs):
        self.start, self.stop, self.step, self.rhs = start, stop, step, rhs

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        picked = [value[i] for i in slice_indices(len(value), self.start, self.stop, self.step)]
        return _project(picked, self.rhs, ctx)


class FlattenProjection(Node):
    # spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150
    """`[]`: splice one level of arrays, then project."""

    def __init__(self, rhs):
        self.rhs = rhs

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        flat = []
        for item in value:
            if is_array(item):
                flat.extend(item)
            else:
                flat.append(item)
        return _project(flat, self.rhs, ctx)


class ListProjection(Node):
    # spec: N-000159 N-000160 N-000161 N-000162
    """`[*]`: projection over array elements."""

    def __init__(self, rhs):
        self.rhs = rhs

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        return _project(value, self.rhs, ctx)


class ObjectProjection(Node):
    # spec: N-000163 N-000164 N-000165
    """`*` / `<expr>.*`: projection over object values."""

    def __init__(self, rhs):
        self.rhs = rhs

    def evaluate(self, value, ctx):
        if not is_object(value):
            return None
        return _project(list(value.values()), self.rhs, ctx)


class FilterProjection(Node):
    # spec: N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000202
    """`[?predicate]`."""

    def __init__(self, predicate, rhs):
        self.predicate, self.rhs = predicate, rhs

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        kept = [item for item in value if is_true(self.predicate.evaluate(item, ctx))]
        return _project(kept, self.rhs, ctx)


class Subexpression(Node):
    """Evaluate right against the result of left (dot, pipe and bracket chaining)."""

    def __init__(self, left, right):
        self.left, self.right = left, right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Literal(Node):
    # spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000230
    """JSON literal or raw string."""

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, ctx):
        return copy.deepcopy(self.value)


class ExpressionRef(Node):
    # spec: N-000231 N-000232 N-000233 N-000234 N-000235 N-000236
    """`&expr`: a reference, not an evaluation."""

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, ctx):
        return ExpressionReference(self.node, ctx)


class Not(Node):
    # spec: N-000251 N-000252
    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, value, ctx):
        return is_false(self.operand.evaluate(value, ctx))


class And(Node):
    # spec: N-000247 N-000248 N-000249 N-000250
    def __init__(self, left, right):
        self.left, self.right = left, right

    def evaluate(self, value, ctx):
        lv = self.left.evaluate(value, ctx)
        if is_false(lv):
            return lv
        return self.right.evaluate(value, ctx)


class Or(Node):
    # spec: N-000247 N-000248 N-000249 N-000250
    def __init__(self, left, right):
        self.left, self.right = left, right

    def evaluate(self, value, ctx):
        lv = self.left.evaluate(value, ctx)
        if is_true(lv):
            return lv
        return self.right.evaluate(value, ctx)


class Comparison(Node):
    # spec: N-000242 N-000243 N-000244 N-000245 N-000246
    """== != < <= > >=. Ordering on numbers or strings; otherwise null.

    """

    def __init__(self, op, left, right):
        self.op, self.left, self.right = op, left, right

    def evaluate(self, value, ctx):
        a = self.left.evaluate(value, ctx)
        b = self.right.evaluate(value, ctx)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if self.op == "<":
                return a < b
            if self.op == "<=":
                return a <= b
            if self.op == ">":
                return a > b
            if self.op == ">=":
                return a >= b
        return None


class MultiList(Node):
    # spec: N-000211 N-000213 N-000218 (null current yields null, CF-000011)
    """Multiselect list."""

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, ctx):
        if value is None:
            return None
        return [item.evaluate(value, ctx) for item in self.items]


class MultiHash(Node):
    # spec: N-000206 N-000207 N-000208 N-000209 N-000210 N-000218 N-000328
    """Multiselect hash, built as ctx.dict_cls when set."""

    def __init__(self, pairs):
        self.pairs = pairs  # list of (key, node)

    def evaluate(self, value, ctx):
        if value is None:
            return None
        out = ctx.dict_cls() if ctx.dict_cls is not None else {}
        for key, node in self.pairs:
            out[key] = node.evaluate(value, ctx)
        return out


class FunctionCall(Node):
    # spec: N-000262 N-000264 N-000265 N-000266 N-000267 N-000268
    """Call of a named function. Name, count and types are checked at evaluation.

    """

    def __init__(self, name, args):
        self.name, self.args = name, args

    def evaluate(self, value, ctx):
        entry = ctx.function(self.name)  # raises unknown-function
        entry.check_count(len(self.args))  # raises invalid-arity
        args = [arg.evaluate(value, ctx) for arg in self.args]
        entry.check_types(args)  # raises invalid-type
        return entry.invoke(args)
