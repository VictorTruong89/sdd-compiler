"""Failure kinds. Every refusal is a ValueError; the kind is the exception type.
"""


class PathSelError(ValueError):
    # spec: N-000105 N-000106 N-000405 N-000406 N-000407 N-000416 N-000417 N-000418 N-000419 N-000420
    """Base of every refusal."""


class EmptyExpressionError(PathSelError):
    # spec: N-000087 N-000088 N-000089 N-000409 N-000413
    """The zero-length expression text."""


class IncompleteExpressionError(PathSelError):
    # spec: N-000090 N-000091 N-000092 N-000093 N-000410 N-000421 N-000422
    """Text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class SyntaxFailure(PathSelError):
    # spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104 N-000411 N-000421 N-000422
    """Grammar-level syntax failure (exactly this type, not a subclass)."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class TokenSyntaxFailure(SyntaxFailure):
    # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000412 N-000414
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    # spec: N-000152 N-000153 N-000154 N-000415
    """A slice whose step is 0."""


class UnknownFunctionError(PathSelError):
    # spec: N-000344 N-000420
    """Function name is neither built-in nor declared on the attached provider."""


class InvalidArityError(PathSelError):
    # spec: N-000345 N-000346 N-000347
    """Wrong number of arguments to a function."""


class InvalidTypeError(PathSelError):
    # spec: N-000348 N-000349 N-000350
    """An argument (or key) outside its accepted types."""
