"""Built-in functions and the provider interface (`Functions`, `signature`).
"""

import json
import math
import re
from decimal import Decimal

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .values import ExpressionReference, is_array, is_number, is_object, json_equal

_NAME_PREFIX = "_func_"
_SIG_ATTR = "_pathsel_signature"


def signature(*arguments):
    # spec: N-000393 N-000401 N-000402 N-000403 N-000404
    """Declare argument types for a `_func_<name>` implementation.

    Each argument is a mapping {"types": [...]} (a union of type names). An extra
    key "variadic": True on the final argument allows one or more arguments.
    The decorator does not call the implementation.
    """
    specs = []
    for arg in arguments:
        specs.append((list(arg["types"]), bool(arg.get("variadic", False))))

    def decorate(func):
        setattr(func, _SIG_ATTR, specs)
        return func

    return decorate


def _type_ok(name, value):
    if name == "any":
        return True
    if name == "number":
        return is_number(value)
    if name == "string":
        return isinstance(value, str)
    if name == "array":
        return is_array(value)
    if name == "object":
        return is_object(value)
    if name == "null":
        return value is None
    if name == "expref":
        return isinstance(value, ExpressionReference)
    if name == "array_of_numbers":
        return is_array(value) and all(is_number(v) for v in value)
    if name == "array_of_strings":
        return is_array(value) and all(isinstance(v, str) for v in value)
    if name == "array_of_numbers_or_strings":
        return is_array(value) and (all(is_number(v) for v in value)
                                    or all(isinstance(v, str) for v in value))
    raise ValueError("unknown type name %r" % (name,))


class Entry:
    # spec: N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000345 N-000346 N-000347 N-000348 N-000349 N-000350
    """A registered function: its signature and bound implementation."""

    def __init__(self, name, specs, impl):
        self.name = name
        self.specs = specs  # list of (types, variadic)
        self.impl = impl

    def check_count(self, count):
        if not self.specs:
            if count != 0:
                raise InvalidArityError("%s takes no arguments" % self.name)
            return
        if self.specs[-1][1]:  # variadic: one or more arguments
            if count < 1:
                raise InvalidArityError("%s takes one or more arguments" % self.name)
            return
        if count != len(self.specs):
            raise InvalidArityError("%s takes %d argument(s)" % (self.name, len(self.specs)))

    def _types_for(self, index):
        if index < len(self.specs) and not self.specs[index][1]:
            return self.specs[index][0]
        return self.specs[-1][0]

    def check_types(self, args):
        for i, value in enumerate(args):
            types = self._types_for(i)
            if not any(_type_ok(t, value) for t in types):
                raise InvalidTypeError("invalid argument %d to %s" % (i + 1, self.name))

    def invoke(self, args):
        return self.impl(*args)


class Functions:
    # spec: N-000263 N-000395 N-000396 N-000397 N-000398 N-000399 N-000400
    """Provider of language functions. Subclass and add `_func_<name>` methods.

    """

    # ----- numbers ----------------------------------------------------------
    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array_of_numbers"]})
    def _func_avg(self, values):
        if not values:
            return None
        return _total(values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return int(math.ceil(value))

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return int(math.floor(value))

    @signature({"types": ["array_of_numbers"]})
    def _func_sum(self, values):
        return _total(values)

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_max(self, values):
        return max(values) if values else None

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_min(self, values):
        return min(values) if values else None

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_sort(self, values):
        return sorted(values)

    # ----- strings and containers -------------------------------------------
    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, container, item):
        if isinstance(container, str):
            if not isinstance(item, str):
                raise InvalidTypeError("contains on a string needs a string")
            return item in container
        return any(json_equal(x, item) for x in container)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["string"]}, {"types": ["array_of_strings"]})
    def _func_join(self, separator, parts):
        if not parts:
            return None
        return separator.join(parts)

    @signature({"types": ["object"]})
    def _func_keys(self, mapping):
        return list(mapping.keys())

    @signature({"types": ["object"]})
    def _func_values(self, mapping):
        return list(mapping.values())

    @signature({"types": ["object"]}, {"types": ["object"], "variadic": True})
    def _func_merge(self, *mappings):
        out = {}
        for mapping in mappings:
            for key in mapping:
                out[key] = mapping[key]
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    # ----- type and conversion ----------------------------------------------
    @signature({"types": ["any"]})
    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        if is_object(value):
            return "object"
        return "null"

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if is_array(value):
            return value
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return _compact_json(value)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INT_RE.match(value):
                return int(value)
            if _FLOAT_RE.match(value):
                return float(value)
        return None

    # ----- by-key and mapping functions -------------------------------------
    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, values):
        return [ref.apply(v) for v in values]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, values, ref):
        keyed = _keyed(values, ref)
        return [v for _, v in sorted(keyed, key=lambda kv: kv[0])]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, values, ref):
        keyed = _keyed(values, ref)
        if not keyed:
            return None
        best = keyed[0]
        for pair in keyed[1:]:
            if pair[0] > best[0]:
                best = pair
        return best[1]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, values, ref):
        keyed = _keyed(values, ref)
        if not keyed:
            return None
        best = keyed[0]
        for pair in keyed[1:]:
            if pair[0] < best[0]:
                best = pair
        return best[1]


_INT_RE = re.compile(r"-?[0-9]+\Z")
_FLOAT_RE = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")


def _total(values):
    """Sum of numbers; a mix of Decimal and float is summed as float."""
    try:
        return sum(values)
    except TypeError:
        return sum(float(v) for v in values)


def _keyed(values, ref):
    """Pairs (key, element) for sort_by / max_by / min_by. Keys: all numbers or all strings."""
    pairs = []
    for v in values:
        key = ref.apply(v)
        pairs.append((key, v))
    if not pairs:
        return []
    if all(is_number(k) for k, _ in pairs) or all(isinstance(k, str) for k, _ in pairs):
        return pairs
    raise InvalidTypeError("sort key must be all numbers or all strings")


def _compact_json(value):
    """Compact JSON text: no spaces, non-ASCII escaped, host number text."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return json.dumps(value)
    if isinstance(value, str):
        return json.dumps(value)
    if is_array(value):
        return "[" + ",".join(_compact_json(v) for v in value) + "]"
    if is_object(value):
        return "{" + ",".join(json.dumps(str(k)) + ":" + _compact_json(v)
                              for k, v in value.items()) + "}"
    return json.dumps(str(value))


_BUILTIN_NAMES = None


def _builtin_entries():
    global _BUILTIN_NAMES
    if _BUILTIN_NAMES is None:
        provider = Functions()
        entries = {}
        for attr in dir(Functions):
            if attr.startswith(_NAME_PREFIX):
                func = getattr(Functions, attr)
                specs = getattr(func, _SIG_ATTR, None)
                if specs is not None:
                    name = attr[len(_NAME_PREFIX):]
                    entries[name] = Entry(name, specs, getattr(provider, attr))
        _BUILTIN_NAMES = entries
    return _BUILTIN_NAMES


def build_registry(provider):
    # spec: N-000339 N-000340 N-000341 N-000335 N-000344
    """Name -> Entry for built-ins plus a provider's declared functions.

    Built-in names always keep their built-in behaviour (FP-08).

    """
    entries = {}
    if provider is not None:
        for attr in dir(provider):
            if not attr.startswith(_NAME_PREFIX):
                continue
            bound = getattr(provider, attr)
            specs = getattr(bound, _SIG_ATTR, None)
            if specs is None:
                continue
            name = attr[len(_NAME_PREFIX):]
            entries[name] = Entry(name, specs, bound)
    entries.update(_builtin_entries())
    return entries
