"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public names: search, compile, plus the failure kinds in pathsel.errors.
"""

from .api import ParsedExpression, compile, search
from .errors import (EmptyExpressionError, IncompleteExpressionError,
                     InvalidArityError, InvalidTypeError, PathSelError,
                     SyntaxFailure, TokenSyntaxFailure, UnknownFunctionError,
                     ZeroSliceStepError)

__all__ = [
    "search", "compile", "ParsedExpression",
    "PathSelError", "EmptyExpressionError", "IncompleteExpressionError",
    "SyntaxFailure", "TokenSyntaxFailure", "ZeroSliceStepError",
    "UnknownFunctionError", "InvalidArityError", "InvalidTypeError",
]
