from collections.abc import Mapping

from .functions import Expref, Functions, is_number, is_array, is_object
from .exceptions import UnknownFunctionError
import copy

_BUILTIN = Functions()


def truthy(v):
    if v is None or v is False:
        return False
    if isinstance(v, (str, list, tuple)) or isinstance(v, Mapping):
        return len(v) > 0
    return True


def json_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_array(a) or is_array(b):
        return (is_array(a) and is_array(b) and len(a) == len(b)
                and all(json_equal(x, y) for x, y in zip(a, b)))
    if isinstance(a, Mapping) or isinstance(b, Mapping):
        if not (isinstance(a, Mapping) and isinstance(b, Mapping)) or len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_equal(a[k], b[k]):
                return False
        return True
    try:
        return bool(a == b)
    except Exception:
        return False


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = None
        self.provider = None
        if options is not None:
            self.dict_cls = getattr(options, "dict_cls", None)
            self.provider = getattr(options, "custom_functions", None)

    def search(self, node, value):
        return self.visit(node, value)

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_identity(self, node, value):
        return value

    v_current = v_identity

    def v_field(self, node, value):
        if isinstance(value, Mapping):
            return value.get(node[1])
        return None

    def v_literal(self, node, value):
        v = node[1]
        if isinstance(v, (list, dict)):
            return copy.deepcopy(v)
        return v

    def v_subexpression(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    v_pipe = v_subexpression

    def v_index_expression(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_index(self, node, value):
        if not is_array(value):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if not is_array(value):
            return None
        return list(value[slice(node[1], node[2], node[3])])

    def v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            r = self.visit(node[2], el)
            if r is not None:
                out.append(r)
        return out

    def v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, Mapping):
            return None
        out = []
        for el in list(base.values()):
            r = self.visit(node[2], el)
            if r is not None:
                out.append(r)
        return out

    def v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if truthy(self.visit(node[3], el)):
                r = self.visit(node[2], el)
                if r is not None:
                    out.append(r)
        return out

    def v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if is_array(el):
                out.extend(el)
            else:
                out.append(el)
        return out

    def v_multi_list(self, node, value):
        if value is None:
            return None
        return [self.visit(e, value) for e in node[1]]

    def v_multi_hash(self, node, value):
        if value is None:
            return None
        result = self.dict_cls() if self.dict_cls is not None else {}
        for key, expr in node[1]:
            result[key] = self.visit(expr, value)
        return result

    def v_or(self, node, value):
        left = self.visit(node[1], value)
        if truthy(left):
            return left
        return self.visit(node[2], value)

    def v_and(self, node, value):
        left = self.visit(node[1], value)
        if not truthy(left):
            return left
        return self.visit(node[2], value)

    def v_not(self, node, value):
        return not truthy(self.visit(node[1], value))

    def v_comparator(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return json_equal(a, b)
        if op == "ne":
            return not json_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def v_expref(self, node, value):
        return Expref(node[1], self)

    def v_function(self, node, value):
        name, arg_nodes = node[1], node[2]
        fn = None
        provider = self.provider
        if provider is not None:
            fn = Functions.lookup(provider, name)
        if fn is None:
            provider = _BUILTIN
            fn = Functions.lookup(provider, name)
        if fn is None:
            raise UnknownFunctionError("unknown function: %s()" % name)
        sig = fn.signature
        Functions.check_arity(name, sig, len(arg_nodes))
        args = [self.visit(a, value) for a in arg_nodes]
        Functions.check_types(name, sig, args)
        if isinstance(provider, Functions):
            saved = provider._dict_cls
            provider._dict_cls = self.dict_cls or dict
            try:
                return fn(*args)
            finally:
                provider._dict_cls = saved
        return fn(*args)
