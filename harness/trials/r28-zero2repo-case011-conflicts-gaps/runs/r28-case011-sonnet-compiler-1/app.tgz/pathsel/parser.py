from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         ParseError, SliceStepError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0, "number": 0,
    "current": 0, "expref": 0, "colon": 0, "unknown": 0,
    "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5,
    "flatten": 9, "star": 20, "filter": 21, "dot": 40, "not": 45,
    "lbrace": 50, "lbracket": 55, "lparen": 60,
}
_IDENT = ("quoted_identifier", "unquoted_identifier")
_IDENTITY = ("identity",)


def parse(expression):
    if expression == "":
        raise EmptyExpressionError("empty expression")
    return Parser(expression).parse()


class Parser:
    def __init__(self, expression):
        self.tokens = tokenize(expression)
        self.pos = 0

    # helpers
    def _tok(self, k=0):
        i = min(self.pos + k, len(self.tokens) - 1)
        return self.tokens[i]

    def _cur(self):
        return self._tok()[0]

    def _advance(self):
        self.pos += 1

    def _error(self, tok, msg="unexpected token"):
        if tok[0] == "eof":
            raise IncompleteExpressionError(tok[2])
        raise ParseError(tok[2], "%s %r" % (msg, tok[0]))

    def _match(self, ttype):
        if self._cur() == ttype:
            self._advance()
        else:
            self._error(self._tok(), "expected %s, got" % ttype)

    def parse(self):
        node = self._expression(0)
        if self._cur() != "eof":
            self._error(self._tok(), "unexpected token")
        return node

    def _expression(self, bp=0):
        tok = self._tok()
        self._advance()
        left = self._nud(tok)
        while bp < BP[self._cur()]:
            tok = self._tok()
            led = getattr(self, "_led_" + tok[0], None)
            if led is None:
                self._error(tok)
            self._advance()
            left = led(left, tok)
        return left

    # nud
    def _nud(self, tok):
        t = tok[0]
        fn = getattr(self, "_nud_" + t, None)
        if fn is None:
            self._error(tok)
        return fn(tok)

    def _nud_literal(self, tok):
        return ("literal", tok[1])

    def _nud_unquoted_identifier(self, tok):
        return ("field", tok[1])

    def _nud_quoted_identifier(self, tok):
        if self._cur() == "lparen":
            raise ParseError(self._tok()[2], "quoted identifier cannot name a function")
        return ("field", tok[1])

    def _nud_current(self, tok):
        return ("current",)

    def _nud_expref(self, tok):
        return ("expref", self._expression(BP["expref"]))

    def _nud_not(self, tok):
        return ("not", self._expression(BP["not"]))

    def _nud_lparen(self, tok):
        e = self._expression(0)
        self._match("rparen")
        return e

    def _nud_lbrace(self, tok):
        return self._multiselect_hash()

    def _nud_star(self, tok):
        left = _IDENTITY
        if self._cur() == "rbracket":
            right = _IDENTITY
        else:
            right = self._projection_rhs(BP["star"])
        return ("value_projection", left, right)

    def _nud_filter(self, tok):
        return self._led_filter(_IDENTITY, tok)

    def _nud_flatten(self, tok):
        return self._led_flatten(_IDENTITY, tok)

    def _nud_lbracket(self, tok):
        cur = self._cur()
        if cur in ("number", "colon"):
            right = self._index_expression()
            return self._project_if_slice(_IDENTITY, right)
        if cur == "star" and self._tok(1)[0] == "rbracket":
            self._advance()
            self._advance()
            right = self._projection_rhs(BP["star"])
            return ("projection", _IDENTITY, right)
        return self._multiselect_list()

    # led
    def _led_dot(self, left, tok):
        if self._cur() != "star":
            right = self._dot_rhs(BP["dot"])
            return ("subexpression", left, right)
        self._advance()
        right = self._projection_rhs(BP["star"])
        return ("value_projection", left, right)

    def _led_pipe(self, left, tok):
        return ("pipe", left, self._expression(BP["pipe"]))

    def _led_or(self, left, tok):
        return ("or", left, self._expression(BP["or"]))

    def _led_and(self, left, tok):
        return ("and", left, self._expression(BP["and"]))

    def _cmp(self, name):
        def led(left, tok):
            return ("comparator", name, left, self._expression(BP[name]))
        return led

    def __getattr__(self, name):
        if name.startswith("_led_") and name[5:] in ("eq", "ne", "lt", "lte", "gt", "gte"):
            return self._cmp(name[5:])
        raise AttributeError(name)

    def _led_lparen(self, left, tok):
        if left[0] != "field":
            raise ParseError(tok[2], "invalid function name")
        args = []
        if self._cur() != "rparen":
            while True:
                args.append(self._expression(0))
                if self._cur() == "comma":
                    self._advance()
                    continue
                break
        self._match("rparen")
        return ("function", left[1], args)

    def _led_filter(self, left, tok):
        cond = self._expression(0)
        self._match("rbracket")
        right = self._projection_rhs(BP["filter"])
        return ("filter_projection", left, right, cond)

    def _led_flatten(self, left, tok):
        right = self._projection_rhs(BP["flatten"])
        return ("projection", ("flatten", left), right)

    def _led_lbracket(self, left, tok):
        cur = self._cur()
        if cur in ("number", "colon"):
            right = self._index_expression()
            return self._project_if_slice(left, right)
        if cur == "star" and self._tok(1)[0] == "rbracket":
            self._advance()
            self._advance()
            right = self._projection_rhs(BP["star"])
            return ("projection", left, right)
        if cur == "star":
            self._advance()
            self._error(self._tok(), "expected rbracket, got")
        self._error(self._tok())

    # pieces
    def _project_if_slice(self, left, right):
        node = ("index_expression", left, right)
        if right[0] == "slice":
            return ("projection", node, self._projection_rhs(BP["star"]))
        return node

    def _index_expression(self):
        if self._cur() == "colon" or self._tok(1)[0] == "colon":
            return self._slice()
        tok = self._tok()
        self._advance()
        self._match("rbracket")
        return ("index", tok[1])

    def _slice(self):
        parts = [None, None, None]
        index = 0
        tok = self._tok()
        while tok[0] != "rbracket" and index < 3:
            if tok[0] == "colon":
                index += 1
                if index == 3:
                    self._error(tok)
                self._advance()
            elif tok[0] == "number":
                parts[index] = tok[1]
                self._advance()
            else:
                self._error(tok)
            tok = self._tok()
        self._match("rbracket")
        if parts[2] == 0:
            raise SliceStepError("slice step cannot be 0")
        return ("slice", parts[0], parts[1], parts[2])

    def _projection_rhs(self, bp):
        cur = self._cur()
        if BP[cur] < 10:
            return _IDENTITY
        if cur in ("lbracket", "filter"):
            return self._expression(bp)
        if cur == "dot":
            self._advance()
            return self._dot_rhs(bp)
        self._error(self._tok())

    def _dot_rhs(self, bp):
        cur = self._cur()
        if cur in _IDENT or cur == "star":
            return self._expression(bp)
        if cur == "lbracket":
            self._advance()
            return self._multiselect_list()
        if cur == "lbrace":
            self._advance()
            return self._multiselect_hash()
        # A dot followed by anything else (even end of text) is syntax kind.
        tok = self._tok()
        raise ParseError(tok[2], "expected identifier after dot")

    def _multiselect_list(self):
        exprs = []
        while True:
            exprs.append(self._expression(0))
            if self._cur() == "rbracket":
                break
            self._match("comma")
        self._match("rbracket")
        return ("multi_list", exprs)

    def _multiselect_hash(self):
        pairs = []
        while True:
            key = self._tok()
            if key[0] not in _IDENT:
                self._error(key)
            self._advance()
            self._match("colon")
            value = self._expression(0)
            pairs.append((key[1], value))
            if self._cur() == "comma":
                self._advance()
            elif self._cur() == "rbrace":
                self._advance()
                break
            else:
                self._error(self._tok())
        return ("multi_hash", pairs)
