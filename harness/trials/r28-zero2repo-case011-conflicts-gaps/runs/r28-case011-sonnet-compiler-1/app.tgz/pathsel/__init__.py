"""pathsel: declarative path expressions over Python data."""
from . import exceptions
from .exceptions import (ArityError, EmptyExpressionError, IncompleteExpressionError,
                         InvalidTypeError, LexerError, ParseError, SliceStepError,
                         UnknownFunctionError)
from .interpreter import Interpreter
from .parser import parse

__all__ = ["search", "compile", "Options", "ParsedExpression"]


class Options:
    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class ParsedExpression:
    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return Interpreter(options).search(self._node, value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)
