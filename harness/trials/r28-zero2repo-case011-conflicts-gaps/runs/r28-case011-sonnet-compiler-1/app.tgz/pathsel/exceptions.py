"""Failure kinds. Every refusal is a ValueError. # spec: N-000405"""


class PathselError(ValueError):
    """Base of every refusal."""


class EmptyExpressionError(PathselError):
    lex_position = 0


class IncompleteExpressionError(PathselError):
    def __init__(self, position, message="incomplete expression"):
        super().__init__("%s at position %d" % (message, position))
        self.lex_position = position


class ParseError(PathselError):
    """Syntax kind, grammar-level."""

    def __init__(self, position, message="syntax error"):
        super().__init__("%s at position %d" % (message, position))
        self.lex_position = position


class LexerError(ParseError):
    """Syntax kind, token-level (subclass of ParseError)."""


class SliceStepError(PathselError):
    """Zero slice step."""


class UnknownFunctionError(PathselError):
    pass


class ArityError(PathselError):
    pass


class InvalidTypeError(PathselError):
    pass
