"""Function provider and signature decorator."""
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal
from numbers import Real

from .exceptions import ArityError, InvalidTypeError


class Expref:
    """Expression reference value."""

    def __init__(self, node, interpreter):
        self.node = node
        self._interp = interpreter

    def eval(self, value):
        return self._interp.visit(self.node, value)

    def __repr__(self):
        return "<expref>"


def is_number(v):
    return isinstance(v, (Real, Decimal)) and not isinstance(v, bool)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v):
    return isinstance(v, Mapping)


def is_string(v):
    return isinstance(v, str)


def _all(pred):
    return lambda v: is_array(v) and all(pred(x) for x in v)


_CHECKS = {
    "number": is_number,
    "string": is_string,
    "array": is_array,
    "object": is_object,
    "null": lambda v: v is None,
    "boolean": lambda v: isinstance(v, bool),
    "expref": lambda v: isinstance(v, Expref),
    "array-number": _all(is_number),
    "array-string": _all(is_string),
    "any": lambda v: not isinstance(v, Expref),
}


def signature(*arguments):
    def decorator(func):
        func.signature = list(arguments)
        return func
    return decorator


def _matches(types, value):
    if not types:
        return _CHECKS["any"](value)
    for t in types:
        check = _CHECKS.get(t)
        if check is not None and check(value):
            return True
    return False


_INT_RE = re.compile(r"^[+-]?[0-9]+$")
_FLOAT_RE = re.compile(r"^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$")


class Functions:
    """Built-in function provider; subclass to add `_func_<name>` methods."""

    # dict_cls is set by the interpreter for the duration of a call
    _dict_cls = dict

    def call_function(self, name, resolved_args, evaluate_args=None):
        raise NotImplementedError

    @classmethod
    def lookup(cls, provider, name):
        fn = getattr(provider, "_func_" + name, None)
        if fn is None or not hasattr(fn, "signature"):
            return None
        return fn

    @staticmethod
    def check_arity(name, sig, n):
        if sig and sig[-1].get("variadic"):
            ok = n >= len(sig)
        else:
            ok = n == len(sig)
        if not ok:
            raise ArityError("%s() takes wrong number of arguments (%d)" % (name, n))

    @staticmethod
    def check_types(name, sig, args):
        for i, arg in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not _matches(spec.get("types", []), arg):
                raise InvalidTypeError("%s(): invalid type for argument %d" % (name, i + 1))

    # --- built-ins ---
    @signature({"types": ["number"]})
    def _func_abs(self, a):
        return abs(a)

    @signature({"types": ["array-number"]})
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature({"types": ["number"]})
    def _func_ceil(self, a):
        return math.ceil(a)

    @signature({"types": ["number"]})
    def _func_floor(self, a):
        return math.floor(a)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        from .interpreter import json_equal
        return any(json_equal(x, search) for x in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, a):
        return len(a)

    @signature({"types": ["string", "array"]})
    def _func_reverse(self, a):
        if isinstance(a, str):
            return a[::-1]
        return list(reversed(a))

    @signature({"types": ["string"]}, {"types": ["array-string"]})
    def _func_join(self, sep, arr):
        return sep.join(arr)

    @signature({"types": ["object"]})
    def _func_keys(self, o):
        return list(o.keys())

    @signature({"types": ["object"]})
    def _func_values(self, o):
        return list(o.values())

    @signature({"types": ["any"]})
    def _func_type(self, a):
        if a is None:
            return "null"
        if isinstance(a, bool):
            return "boolean"
        if is_number(a):
            return "number"
        if isinstance(a, str):
            return "string"
        if is_array(a):
            return "array"
        return "object"

    @signature({"types": ["any"]})
    def _func_to_array(self, a):
        if is_array(a):
            return list(a) if isinstance(a, tuple) else a
        return [a]

    @signature({"types": ["any"]})
    def _func_to_string(self, a):
        if isinstance(a, str):
            return a
        return json.dumps(a, separators=(",", ":"), default=_default)

    @signature({"types": ["any"]})
    def _func_to_number(self, a):
        if is_number(a):
            return a
        if isinstance(a, str):
            if _INT_RE.match(a):
                return int(a)
            if _FLOAT_RE.match(a):
                return float(a)
        return None

    @signature({"types": ["array-number", "array-string"]})
    def _func_max(self, a):
        return max(a) if a else None

    @signature({"types": ["array-number", "array-string"]})
    def _func_min(self, a):
        return min(a) if a else None

    @signature({"types": ["array-number", "array-string"]})
    def _func_sort(self, a):
        return sorted(a)

    @signature({"types": ["array-number"]})
    def _func_sum(self, a):
        return sum(a)

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objs):
        out = self._dict_cls()
        for o in objs:
            for k, v in o.items():
                out[k] = v
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, arr):
        return [ref.eval(x) for x in arr]

    @staticmethod
    def _keys(ref, arr):
        keys = [ref.eval(x) for x in arr]
        if keys:
            if all(is_number(k) for k in keys) or all(is_string(k) for k in keys):
                return keys
            raise InvalidTypeError("sort key must be number or string, consistently")
        return keys

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, arr, ref):
        keys = self._keys(ref, arr)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = self._keys(ref, arr)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = self._keys(ref, arr)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]


def _default(o):
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, tuple):
        return list(o)
    return str(o)
