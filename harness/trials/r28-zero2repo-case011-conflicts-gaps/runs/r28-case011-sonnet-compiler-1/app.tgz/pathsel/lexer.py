import json

from .exceptions import LexerError

_WS = " \t\n\r"
_START = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_CONT = _START | set("0123456789")
_DIGITS = set("0123456789")
_SIMPLE = {".": "dot", "*": "star", ",": "comma", ":": "colon", "@": "current",
           "{": "lbrace", "}": "rbrace", "(": "lparen", ")": "rparen",
           "]": "rbracket"}


def _bad_const(name):
    raise ValueError(name)


def _consume_until(expr, i, delim, start):
    """i is just after the opening delimiter; returns (text, index after closer)."""
    n = len(expr)
    j = i
    while j < n:
        c = expr[j]
        if c == "\\":
            j += 2
            continue
        if c == delim:
            return expr[i:j], j + 1
        j += 1
    raise LexerError(start, "unterminated token")


def tokenize(expr):
    """Return list of (type, value, start). Ends with an eof token."""
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        nxt = expr[i + 1] if i + 1 < n else ""
        if c in _WS:
            i += 1
        elif c in _START:
            j = i + 1
            while j < n and expr[j] in _CONT:
                j += 1
            tokens.append(("unquoted_identifier", expr[i:j], i))
            i = j
        elif c == "[":
            if nxt == "?":
                tokens.append(("filter", "[?", i)); i += 2
            elif nxt == "]":
                tokens.append(("flatten", "[]", i)); i += 2
            else:
                tokens.append(("lbracket", "[", i)); i += 1
        elif c in _SIMPLE:
            tokens.append((_SIMPLE[c], c, i)); i += 1
        elif c == "|":
            if nxt == "|":
                tokens.append(("or", "||", i)); i += 2
            else:
                tokens.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if nxt == "&":
                tokens.append(("and", "&&", i)); i += 2
            else:
                tokens.append(("expref", "&", i)); i += 1
        elif c == "<":
            if nxt == "=":
                tokens.append(("lte", "<=", i)); i += 2
            else:
                tokens.append(("lt", "<", i)); i += 1
        elif c == ">":
            if nxt == "=":
                tokens.append(("gte", ">=", i)); i += 2
            else:
                tokens.append(("gt", ">", i)); i += 1
        elif c == "!":
            if nxt == "=":
                tokens.append(("ne", "!=", i)); i += 2
            else:
                tokens.append(("not", "!", i)); i += 1
        elif c == "=":
            if nxt == "=":
                tokens.append(("eq", "==", i)); i += 2
            else:
                tokens.append(("unknown", "=", i)); i += 1
        elif c in _DIGITS or c == "-":
            j = i + 1
            if c == "-" and not (nxt in _DIGITS and nxt != ""):
                raise LexerError(i, "unknown token '-'")
            while j < n and expr[j] in _DIGITS:
                j += 1
            tokens.append(("number", int(expr[i:j]), i))
            i = j
        elif c == '"':
            _, j = _consume_until(expr, i + 1, '"', i)
            try:
                val = json.loads(expr[i:j])
            except ValueError:
                raise LexerError(i, "invalid quoted identifier")
            tokens.append(("quoted_identifier", val, i))
            i = j
        elif c == "'":
            text, j = _consume_until(expr, i + 1, "'", i)
            tokens.append(("literal", text.replace("\\'", "'"), i))
            i = j
        elif c == "`":
            text, j = _consume_until(expr, i + 1, "`", i)
            text = text.replace("\\`", "`")
            try:
                val = json.loads(text, parse_constant=_bad_const)
            except ValueError:
                try:
                    val = json.loads('"%s"' % text.lstrip(),
                                     parse_constant=_bad_const)
                except ValueError:
                    raise LexerError(i, "invalid JSON literal")
            tokens.append(("literal", val, i))
            i = j
        else:
            raise LexerError(i, "unknown character %r" % c)
    tokens.append(("eof", "", n))
    return tokens
