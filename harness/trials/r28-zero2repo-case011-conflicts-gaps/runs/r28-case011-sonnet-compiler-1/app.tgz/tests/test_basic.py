import collections
import pytest
import pathsel
from pathsel import search, compile
from pathsel.functions import Functions, signature
from pathsel.exceptions import *


def test_basic():
    d = {"a": {"b": [1, 2, {"c": 3}]}, "n": [{"x": 1}, {"x": None}, {"x": 3}]}
    assert search("a.b[2].c", d) == 3
    assert search("a.z.y", d) is None
    assert search("n[*].x", d) == [1, 3]
    assert search("n[?x > `1`].x", d) == [3]
    assert search("(a.b[::-1])[0].c", d) == 3
    assert search("[a.b[0], `1`]", d)[1] == 1
    assert search("length('héé')", None) == 3
    assert search("foo[].a", {"foo": [[{"a": 1}], [{"a": 2}]]}) == [1, 2]
    assert search("!a[0]", {"a": [0]}) is False
    assert search("sort_by(n[?x], &x)[0].x", d) == 1
    assert search("`true` == `1`", None) is False
    assert search("to_string(@)", {"a": "é"}) == '{"a":"\\u00e9"}'
    assert search("&a", {}) is not None


def test_errors():
    with pytest.raises(EmptyExpressionError): search("", {})
    with pytest.raises(IncompleteExpressionError): search("  ", {})
    with pytest.raises(IncompleteExpressionError) as e: search("a ||", {})
    assert e.value.lex_position == 4
    for bad in ["a.", "a..b", "a.1", ".a", "a b", "a = b", "foo[1:2:3:4]", "foo[*]bar", "[]]"]:
        with pytest.raises(ParseError): search(bad, {})
    with pytest.raises(LexerError): search("a-b", {})
    with pytest.raises(LexerError): search('"abc', {})
    with pytest.raises(SliceStepError): search("a[::0]", {})
    with pytest.raises(UnknownFunctionError): search("nope()", {})
    with pytest.raises(ArityError): search("abs()", {})
    with pytest.raises(InvalidTypeError): search("abs(`true`)", {})
    with pytest.raises(ParseError): search('"abs"(@)', {})


def test_options():
    class P(Functions):
        @signature({"types": ["number"]})
        def _func_zero(self, x):
            return 0
    class O: dict_cls = collections.OrderedDict; custom_functions = P()
    r = search("{a: `1`}", {}, O())
    assert type(r) is collections.OrderedDict
    assert search("zero(`1`)", {}, O()) == 0
    assert search("merge({a: `1`}, {b: `2`})", {}, O()) == {"a": 1, "b": 2}
    with pytest.raises(UnknownFunctionError): search("zero(`1`)", {})
    with pytest.raises(InvalidTypeError): search("zero(object)", {}, O())
