import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import InvalidTypeError


class ExpRef(object):
    """A deferred expression reference."""

    def __init__(self, node, visit):
        self.node = node
        self._visit = visit

    def visit(self, value):
        return self._visit(self.node, value)

    def __repr__(self):
        return "<expref>"


def is_number(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def is_array(v):
    return isinstance(v, (list, tuple))


def _type_ok(v, t):
    if t == "any":
        return not isinstance(v, ExpRef)
    if t == "number":
        return is_number(v)
    if t == "string":
        return isinstance(v, str)
    if t == "array":
        return is_array(v)
    if t == "object":
        return isinstance(v, Mapping)
    if t == "null":
        return v is None
    if t == "boolean":
        return isinstance(v, bool)
    if t == "expref":
        return isinstance(v, ExpRef)
    if t == "array-number":
        return is_array(v) and all(is_number(x) for x in v)
    if t == "array-string":
        return is_array(v) and all(isinstance(x, str) for x in v)
    return False


def type_matches(v, types):
    return any(_type_ok(v, t) for t in types)


def signature(*arguments):
    def decorator(func):
        func.signature = [dict(a) for a in arguments]
        return func
    return decorator


def json_eq(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_eq(x, y) for x, y in zip(a, b))
    if isinstance(a, Mapping) and isinstance(b, Mapping):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_eq(a[k], b[k]):
                return False
        return True
    if is_number(a) or is_number(b):
        return False
    if is_array(a) or is_array(b) or isinstance(a, Mapping) or isinstance(b, Mapping):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


_INT = re.compile(r'^[+-]?[0-9]+$')
_FLOAT = re.compile(r'^[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?$')

_N = {"types": ["number"]}
_S = {"types": ["string"]}
_A = {"types": ["array"]}
_O = {"types": ["object"]}
_ANY = {"types": ["any"]}
_REF = {"types": ["expref"]}
_NS = {"types": ["array-number", "array-string"]}


def _keytype_check(keys):
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise InvalidTypeError("sort key must be all numbers or all strings")


class Functions(object):
    def get_function(self, name):
        f = getattr(self, "_func_" + name, None)
        sig = getattr(f, "signature", None)
        if f is None or sig is None:
            return None
        return f, sig

    @signature(_N)
    def _func_abs(self, v):
        return abs(v)

    @signature({"types": ["array-number"]})
    def _func_avg(self, v):
        if not v:
            return None
        return sum(v) / len(v)

    @signature(_N)
    def _func_ceil(self, v):
        return math.ceil(v)

    @signature(_N)
    def _func_floor(self, v):
        return math.floor(v)

    @signature({"types": ["array", "string"]}, _ANY)
    def _func_contains(self, subject, item):
        if isinstance(subject, str):
            return isinstance(item, str) and item in subject
        return any(json_eq(x, item) for x in subject)

    @signature(_S, _S)
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_S, _S)
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, v):
        return len(v)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, v):
        if isinstance(v, str):
            return v[::-1]
        return list(reversed(v))

    @signature(_S, {"types": ["array-string"]})
    def _func_join(self, sep, items):
        return sep.join(items)

    @signature(_O)
    def _func_keys(self, o):
        return list(o.keys())

    @signature(_O)
    def _func_values(self, o):
        return list(o.values())

    @signature(_ANY)
    def _func_type(self, v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "boolean"
        if is_number(v):
            return "number"
        if isinstance(v, str):
            return "string"
        if is_array(v):
            return "array"
        return "object"

    @signature(_ANY)
    def _func_to_array(self, v):
        if is_array(v):
            return v
        return [v]

    @signature(_ANY)
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return json.dumps(v, separators=(",", ":"), ensure_ascii=True, default=str)

    @signature(_ANY)
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if _INT.match(v):
                return int(v)
            if _FLOAT.match(v):
                return float(v)
        return None

    @signature(_NS)
    def _func_max(self, v):
        if not v:
            return None
        return max(v)

    @signature(_NS)
    def _func_min(self, v):
        if not v:
            return None
        return min(v)

    @signature(_NS)
    def _func_sort(self, v):
        return sorted(v)

    @signature({"types": ["array-number"]})
    def _func_sum(self, v):
        return sum(v)

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k, val in o.items():
                out[k] = val
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_REF, _A)
    def _func_map(self, ref, arr):
        return [ref.visit(x) for x in arr]

    @signature(_A, _REF)
    def _func_sort_by(self, arr, ref):
        if not arr:
            return []
        keys = [ref.visit(x) for x in arr]
        _keytype_check(keys)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature(_A, _REF)
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.visit(x) for x in arr]
        _keytype_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature(_A, _REF)
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.visit(x) for x in arr]
        _keytype_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]
