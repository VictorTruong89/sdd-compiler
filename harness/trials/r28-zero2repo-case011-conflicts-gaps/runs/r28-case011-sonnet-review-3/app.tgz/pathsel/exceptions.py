"""Failure kinds. Every refusal is a ValueError."""


class PathSelError(ValueError):
    pass


class _Positioned(PathSelError):
    def __init__(self, message="", lex_position=0):
        PathSelError.__init__(self, "%s (position %d)" % (message, lex_position))
        self.lex_position = int(lex_position)


class EmptyExpressionError(_Positioned):
    pass


class IncompleteExpressionError(_Positioned):
    pass


class ParseError(_Positioned):
    """Grammar-level syntax failure."""


class LexerError(ParseError):
    """Token-level syntax failure (subclass of ParseError)."""


class ZeroSliceStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
