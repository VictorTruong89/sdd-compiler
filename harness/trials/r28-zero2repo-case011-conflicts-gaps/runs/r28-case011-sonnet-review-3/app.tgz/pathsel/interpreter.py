import copy
from collections.abc import Mapping

from .exceptions import (ZeroSliceStepError, UnknownFunctionError, ArityError,
                         InvalidTypeError)
from .functions import (Functions, ExpRef, is_number, is_array, json_eq,
                        type_matches)

_DEFAULT = Functions()


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, str):
        return v == ""
    if is_array(v) or isinstance(v, Mapping):
        return len(v) == 0
    return False


class Interpreter(object):
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) or dict
        self.provider = getattr(options, "custom_functions", None)

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_current(self, node, value):
        return value

    def v_field(self, node, value):
        if isinstance(value, Mapping):
            try:
                return value.get(node[1])
            except Exception:
                return None
        return None

    def v_literal(self, node, value):
        return copy.deepcopy(node[1])

    def v_subexpression(self, node, value):
        for child in node[1]:
            value = self.visit(child, value)
        return value

    def v_index(self, node, value):
        if not is_array(value):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if node[3] == 0:
            raise ZeroSliceStepError("Slice step cannot be zero")
        if not is_array(value):
            return None
        return list(value[slice(node[1], node[2], node[3])])

    def v_pipe(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_or(self, node, value):
        left = self.visit(node[1], value)
        if not is_false(left):
            return left
        return self.visit(node[2], value)

    def v_and(self, node, value):
        left = self.visit(node[1], value)
        if is_false(left):
            return left
        return self.visit(node[2], value)

    def v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def v_comparator(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == 'eq':
            return json_eq(a, b)
        if op == 'ne':
            return not json_eq(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == 'lt':
                return a < b
            if op == 'lte':
                return a <= b
            if op == 'gt':
                return a > b
            return a >= b
        return None

    def v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if is_array(el):
                out.extend(el)
            else:
                out.append(el)
        return out

    def _project(self, items, rhs):
        out = []
        for el in items:
            r = self.visit(rhs, el)
            if r is not None:
                out.append(r)
        return out

    def v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        return self._project(base, node[2])

    def v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, Mapping):
            return None
        return self._project(list(base.values()), node[2])

    def v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        kept = [el for el in base if not is_false(self.visit(node[3], el))]
        return self._project(kept, node[2])

    def v_multi_list(self, node, value):
        if value is None:
            return None
        return [self.visit(c, value) for c in node[1]]

    def v_multi_hash(self, node, value):
        if value is None:
            return None
        out = self.dict_cls()
        for k, c in node[1]:
            out[k] = self.visit(c, value)
        return out

    def v_expref(self, node, value):
        return ExpRef(node[1], self.visit)

    def v_function(self, node, value):
        name, argnodes = node[1], node[2]
        found = None
        if self.provider is not None:
            lookup = getattr(self.provider, "get_function", None)
            if lookup is not None:
                found = lookup(name)
            else:
                f = getattr(self.provider, "_func_" + name, None)
                sig = getattr(f, "signature", None)
                if f is not None and sig is not None:
                    found = (f, sig)
        if found is None:
            found = _DEFAULT.get_function(name)
        if found is None:
            raise UnknownFunctionError("Unknown function: %s" % name)
        func, sig = found
        variadic = bool(sig) and bool(sig[-1].get("variadic"))
        n = len(argnodes)
        if variadic:
            if n < len(sig):
                raise ArityError("Function %s expects at least %d arguments" % (name, len(sig)))
        elif n != len(sig):
            raise ArityError("Function %s expects %d arguments, got %d" % (name, len(sig), n))
        args = [self.visit(a, value) for a in argnodes]
        for i, a in enumerate(args):
            spec = sig[i] if i < len(sig) else sig[-1]
            if not type_matches(a, spec.get("types", [])):
                raise InvalidTypeError("Invalid type for argument %d of %s" % (i + 1, name))
        return func(*args)
