import json
import re

from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         ParseError, LexerError)

WS = " \t\n\r"
IDSTART = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
IDCHARS = IDSTART | set("0123456789")
DIGITS = set("0123456789")

BP = {
    'eof': 0, 'unquoted_identifier': 0, 'quoted_identifier': 0, 'literal': 0,
    'rbracket': 0, 'rparen': 0, 'comma': 0, 'rbrace': 0, 'number': 0,
    'current': 0, 'expref': 0, 'colon': 0, 'lbrace': 0,
    'pipe': 1, 'or': 2, 'and': 3,
    'eq': 5, 'gt': 5, 'lt': 5, 'gte': 5, 'lte': 5, 'ne': 5,
    'flatten': 9, 'star': 20, 'filter': 21, 'dot': 40, 'not': 45,
    'lbracket': 55, 'lparen': 60,
}
PROJECTION_STOP = 10
COMPARATORS = {'eq', 'ne', 'lt', 'lte', 'gt', 'gte'}


def tokenize(text):
    tokens = []
    n = len(text)
    i = 0

    def consume_until(start, delim):
        # start is index after the opening delimiter; returns (content, next index)
        j = start
        while j < n:
            c = text[j]
            if c == '\\' and j + 1 < n:
                j += 2
                continue
            if c == delim:
                return text[start:j], j + 1
            j += 1
        return None, n

    while i < n:
        c = text[i]
        if c in WS:
            i += 1
        elif c in IDSTART:
            j = i + 1
            while j < n and text[j] in IDCHARS:
                j += 1
            tokens.append(('unquoted_identifier', text[i:j], i))
            i = j
        elif c in DIGITS or (c == '-' and i + 1 < n and text[i + 1] in DIGITS):
            j = i + 1
            while j < n and text[j] in DIGITS:
                j += 1
            tokens.append(('number', int(text[i:j]), i))
            i = j
        elif c == '.':
            tokens.append(('dot', c, i)); i += 1
        elif c == '*':
            tokens.append(('star', c, i)); i += 1
        elif c == ',':
            tokens.append(('comma', c, i)); i += 1
        elif c == ':':
            tokens.append(('colon', c, i)); i += 1
        elif c == '{':
            tokens.append(('lbrace', c, i)); i += 1
        elif c == '}':
            tokens.append(('rbrace', c, i)); i += 1
        elif c == ']':
            tokens.append(('rbracket', c, i)); i += 1
        elif c == '(':
            tokens.append(('lparen', c, i)); i += 1
        elif c == ')':
            tokens.append(('rparen', c, i)); i += 1
        elif c == '@':
            tokens.append(('current', c, i)); i += 1
        elif c == '[':
            j = i + 1
            while j < n and text[j] in WS:
                j += 1
            if j < n and text[j] == ']':
                tokens.append(('flatten', '[]', i)); i = j + 1
            elif j < n and text[j] == '?':
                tokens.append(('filter', '[?', i)); i = j + 1
            else:
                tokens.append(('lbracket', c, i)); i += 1
        elif c == '|':
            if text[i + 1:i + 2] == '|':
                tokens.append(('or', '||', i)); i += 2
            else:
                tokens.append(('pipe', c, i)); i += 1
        elif c == '&':
            if text[i + 1:i + 2] == '&':
                tokens.append(('and', '&&', i)); i += 2
            else:
                tokens.append(('expref', c, i)); i += 1
        elif c == '<':
            if text[i + 1:i + 2] == '=':
                tokens.append(('lte', '<=', i)); i += 2
            else:
                tokens.append(('lt', c, i)); i += 1
        elif c == '>':
            if text[i + 1:i + 2] == '=':
                tokens.append(('gte', '>=', i)); i += 2
            else:
                tokens.append(('gt', c, i)); i += 1
        elif c == '!':
            if text[i + 1:i + 2] == '=':
                tokens.append(('ne', '!=', i)); i += 2
            else:
                tokens.append(('not', c, i)); i += 1
        elif c == '=':
            if text[i + 1:i + 2] == '=':
                tokens.append(('eq', '==', i)); i += 2
            else:
                raise LexerError("Unknown token '='", i)
        elif c == '"':
            content, nxt = consume_until(i + 1, '"')
            if content is None:
                raise LexerError("Unterminated quoted identifier", i)
            try:
                val = json.loads('"' + content + '"')
            except ValueError:
                raise LexerError("Invalid quoted identifier", i)
            tokens.append(('quoted_identifier', val, i)); i = nxt
        elif c == "'":
            content, nxt = consume_until(i + 1, "'")
            if content is None:
                raise LexerError("Unterminated raw string", i)
            content = content.replace("\\'", "'")

            def dec(m):
                try:
                    return json.loads('"' + m.group(0) + '"')
                except ValueError:
                    return m.group(0)
            content = re.sub(r'(?:\\u[0-9a-fA-F]{4})+', dec, content)
            tokens.append(('literal', content, i)); i = nxt
        elif c == '`':
            content, nxt = consume_until(i + 1, '`')
            if content is None:
                raise LexerError("Unterminated literal", i)
            content = content.replace("\\`", "`")
            try:
                val = json.loads(content.strip(WS))
            except ValueError:
                try:
                    val = json.loads('"' + content.lstrip(WS) + '"')
                except ValueError:
                    raise LexerError("Invalid literal", i)
            tokens.append(('literal', val, i)); i = nxt
        else:
            raise LexerError("Unknown character %r" % c, i)
    tokens.append(('eof', '', n))
    return tokens


class Parser(object):
    def __init__(self, text):
        self.text = text
        self.tokens = tokenize(text)
        self.pos = 0

    @property
    def cur(self):
        return self.tokens[self.pos]

    def ctype(self):
        return self.tokens[self.pos][0]

    def look(self, k):
        p = self.pos + k
        if p < len(self.tokens):
            return self.tokens[p][0]
        return 'eof'

    def advance(self):
        self.pos += 1

    def fail(self, tok=None):
        tok = tok or self.cur
        if tok[0] == 'eof':
            raise IncompleteExpressionError("Unexpected end of expression", tok[2])
        raise ParseError("Unexpected token %r" % (tok[1],), tok[2])

    def match(self, ttype):
        if self.ctype() == ttype:
            self.advance()
        else:
            self.fail()

    def parse(self):
        if self.text == "":
            raise EmptyExpressionError("Empty expression", 0)
        node = self.expression(0)
        if self.ctype() != 'eof':
            self.fail()
        return node

    def expression(self, bp=0):
        tok = self.cur
        self.advance()
        left = self.nud(tok)
        while bp < BP[self.ctype()]:
            tok = self.cur
            self.advance()
            left = self.led(tok, left)
        return left

    # --- nud
    def nud(self, tok):
        t = tok[0]
        if t == 'literal':
            return ('literal', tok[1])
        if t == 'unquoted_identifier':
            return ('field', tok[1])
        if t == 'quoted_identifier':
            if self.ctype() == 'lparen':
                raise ParseError("Quoted identifier cannot be a function name", self.cur[2])
            return ('field', tok[1])
        if t == 'star':
            rhs = self.projection_rhs(BP['star'])
            return ('value_projection', ('current',), rhs)
        if t == 'filter':
            return self.filter_led(('current',))
        if t == 'lbrace':
            return self.multi_hash()
        if t == 'flatten':
            rhs = self.projection_rhs(BP['flatten'])
            return ('projection', ('flatten', ('current',)), rhs)
        if t == 'lbracket':
            ct = self.ctype()
            if ct in ('number', 'colon'):
                right = self.index_expression()
                return self.project_if_slice(('current',), right)
            if ct == 'star' and self.look(1) == 'rbracket':
                self.advance(); self.advance()
                rhs = self.projection_rhs(BP['star'])
                return ('projection', ('current',), rhs)
            return self.multi_list()
        if t == 'current':
            return ('current',)
        if t == 'expref':
            return ('expref', self.expression(BP['expref']))
        if t == 'not':
            return ('not', self.expression(BP['not']))
        if t == 'lparen':
            node = self.expression(0)
            self.match('rparen')
            return node
        self.fail(tok)

    # --- led
    def led(self, tok, left):
        t = tok[0]
        if t == 'dot':
            if self.ctype() == 'star':
                self.advance()
                rhs = self.projection_rhs(BP['dot'])
                return ('value_projection', left, rhs)
            right = self.dot_rhs(BP['dot'])
            if left[0] == 'subexpression':
                return ('subexpression', left[1] + [right])
            return ('subexpression', [left, right])
        if t == 'pipe':
            return ('pipe', left, self.expression(BP['pipe']))
        if t == 'or':
            return ('or', left, self.expression(BP['or']))
        if t == 'and':
            return ('and', left, self.expression(BP['and']))
        if t in COMPARATORS:
            return ('comparator', t, left, self.expression(BP[t]))
        if t == 'flatten':
            rhs = self.projection_rhs(BP['flatten'])
            return ('projection', ('flatten', left), rhs)
        if t == 'filter':
            return self.filter_led(left)
        if t == 'lbracket':
            ct = self.ctype()
            if ct in ('number', 'colon'):
                right = self.index_expression()
                return self.project_if_slice(left, right)
            self.match('star')
            self.match('rbracket')
            rhs = self.projection_rhs(BP['star'])
            return ('projection', left, rhs)
        if t == 'lparen':
            if left[0] != 'field':
                raise ParseError("Invalid function call", tok[2])
            args = []
            if self.ctype() != 'rparen':
                while True:
                    args.append(self.expression(0))
                    if self.ctype() == 'comma':
                        self.advance()
                        continue
                    break
            self.match('rparen')
            return ('function', left[1], args)
        self.fail(tok)

    def filter_led(self, left):
        cond = self.expression(0)
        self.match('rbracket')
        rhs = self.projection_rhs(BP['filter'])
        return ('filter_projection', left, rhs, cond)

    def project_if_slice(self, left, right):
        idx = ('subexpression', [left, right])
        if right[0] == 'slice':
            return ('projection', idx, self.projection_rhs(BP['star']))
        return idx

    def index_expression(self):
        if self.ctype() == 'colon' or self.look(1) == 'colon':
            return self.slice_expression()
        node = ('index', self.cur[1])
        self.advance()
        self.match('rbracket')
        return node

    def slice_expression(self):
        parts = [None, None, None]
        index = 0
        while self.ctype() != 'rbracket':
            ct = self.ctype()
            if ct == 'colon':
                index += 1
                if index == 3:
                    raise ParseError("Too many slice parts", self.cur[2])
                self.advance()
            elif ct == 'number' and parts[index] is None:
                parts[index] = self.cur[1]
                self.advance()
            else:
                self.fail()
        self.match('rbracket')
        return ('slice', parts[0], parts[1], parts[2])

    def projection_rhs(self, bp):
        ct = self.ctype()
        if BP[ct] < PROJECTION_STOP:
            return ('current',)
        if ct == 'lbracket' or ct == 'filter':
            return self.expression(bp)
        if ct == 'dot':
            self.advance()
            return self.dot_rhs(bp)
        self.fail()

    def dot_rhs(self, bp):
        ct = self.ctype()
        if ct in ('unquoted_identifier', 'quoted_identifier', 'star'):
            return self.expression(bp)
        if ct == 'lbracket':
            self.advance()
            return self.multi_list()
        if ct == 'lbrace':
            self.advance()
            return self.multi_hash()
        raise ParseError("Expected identifier, wildcard or multiselect after '.'", self.cur[2])

    def multi_list(self):
        items = []
        while True:
            items.append(self.expression(0))
            if self.ctype() == 'comma':
                self.advance()
                continue
            break
        self.match('rbracket')
        return ('multi_list', items)

    def multi_hash(self):
        pairs = []
        while True:
            tok = self.cur
            if tok[0] not in ('unquoted_identifier', 'quoted_identifier'):
                self.fail()
            self.advance()
            self.match('colon')
            pairs.append((tok[1], self.expression(0)))
            if self.ctype() == 'comma':
                self.advance()
                continue
            break
        self.match('rbrace')
        return ('multi_hash', pairs)


def parse(text):
    return Parser(text).parse()
