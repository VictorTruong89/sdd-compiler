import copy

from .exceptions import (InvalidArityError, InvalidTypeError,
                         UnknownFunctionError, ZeroSliceStepError)
from .functions import (Expref, Functions, check_arg, is_array, is_number,
                        is_object, json_equal, truthy)

_DEFAULT = Functions()


def _slice(seq, start, stop, step):
    n = len(seq)
    if step is None:
        step = 1
    if step == 0:
        raise ZeroSliceStepError("slice step cannot be zero")
    if step > 0:
        start = 0 if start is None else (start + n if start < 0 else start)
        stop = n if stop is None else (stop + n if stop < 0 else stop)
        start = min(max(start, 0), n)
        stop = min(max(stop, 0), n)
        return [seq[i] for i in range(start, stop, step)]
    start = n - 1 if start is None else (start + n if start < 0 else start)
    stop = -1 if stop is None else (stop + n if stop < 0 else stop)
    start = min(max(start, -1), n - 1)
    stop = min(max(stop, -1), n - 1)
    return [seq[i] for i in range(start, stop, step)]


def _flatten(v):
    out = []
    for x in v:
        if is_array(x):
            out.extend(x)
        else:
            out.append(x)
    return out


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) if options is not None else None
        prov = getattr(options, "custom_functions", None) if options is not None else None
        self.provider = prov if prov is not None else _DEFAULT

    def visit(self, node, value):
        return getattr(self, "_v_" + node[0])(node, value)

    def _v_identity(self, node, v):
        return v

    def _v_field(self, node, v):
        if is_object(v):
            try:
                return v[node[1]]
            except KeyError:
                return None
        return None

    def _v_subexpression(self, node, v):
        return self.visit(node[2], self.visit(node[1], v))

    def _v_index_expression(self, node, v):
        return self.visit(node[2], self.visit(node[1], v))

    def _v_pipe(self, node, v):
        return self.visit(node[2], self.visit(node[1], v))

    def _v_index(self, node, v):
        if not is_array(v):
            return None
        try:
            return v[node[1]]
        except IndexError:
            return None

    def _v_slice(self, node, v):
        if node[3] == 0:
            raise ZeroSliceStepError("slice step cannot be zero")
        if not is_array(v):
            return None
        return _slice(v, node[1], node[2], node[3])

    def _v_flatten(self, node, v):
        base = self.visit(node[1], v)
        if not is_array(base):
            return None
        return _flatten(base)

    def _v_projection(self, node, v):
        base = self.visit(node[1], v)
        if not is_array(base):
            return None
        out = []
        for e in base:
            r = self.visit(node[2], e)
            if r is not None:
                out.append(r)
        return out

    def _v_value_projection(self, node, v):
        base = self.visit(node[1], v)
        if not is_object(base):
            return None
        out = []
        for k in list(base.keys()):
            r = self.visit(node[2], base[k])
            if r is not None:
                out.append(r)
        return out

    def _v_filter_projection(self, node, v):
        base = self.visit(node[1], v)
        if not is_array(base):
            return None
        out = []
        for e in base:
            if truthy(self.visit(node[3], e)):
                r = self.visit(node[2], e)
                if r is not None:
                    out.append(r)
        return out

    def _v_comparator(self, node, v):
        op = node[1]
        a = self.visit(node[2], v)
        b = self.visit(node[3], v)
        if op == "eq":
            return json_equal(a, b)
        if op == "ne":
            return not json_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def _v_or(self, node, v):
        a = self.visit(node[1], v)
        return a if truthy(a) else self.visit(node[2], v)

    def _v_and(self, node, v):
        a = self.visit(node[1], v)
        return self.visit(node[2], v) if truthy(a) else a

    def _v_not(self, node, v):
        return not truthy(self.visit(node[1], v))

    def _v_literal(self, node, v):
        return copy.deepcopy(node[1])

    def _v_expref(self, node, v):
        return Expref(node[1], self)

    def _v_multi_list(self, node, v):
        if v is None:
            return None
        return [self.visit(e, v) for e in node[1]]

    def _v_multi_hash(self, node, v):
        if v is None:
            return None
        out = self.dict_cls() if self.dict_cls is not None else {}
        for k, e in node[1]:
            out[k] = self.visit(e, v)
        return out

    def _v_function(self, node, v):
        name, argnodes = node[1], node[2]
        fn = getattr(self.provider, "_func_" + name, None)
        if fn is None or not hasattr(fn, "__pathsel_signature__"):
            fn = getattr(_DEFAULT, "_func_" + name, None) if self.provider is not _DEFAULT and isinstance(self.provider, Functions) else None
            if fn is None or not hasattr(fn, "__pathsel_signature__"):
                raise UnknownFunctionError("unknown function: %s" % name)
        spec = fn.__pathsel_signature__
        variadic = bool(spec) and bool(spec[-1].get("variadic"))
        n = len(argnodes)
        if variadic:
            ok = n >= len(spec)
        else:
            ok = n == len(spec)
        if not ok:
            raise InvalidArityError("invalid arity calling %s" % name)
        args = [self.visit(a, v) for a in argnodes]
        for i, a in enumerate(args):
            s = spec[min(i, len(spec) - 1)]
            if not check_arg(a, s):
                raise InvalidTypeError("invalid type for argument %d of %s" % (i + 1, name))
        return fn(*args)
