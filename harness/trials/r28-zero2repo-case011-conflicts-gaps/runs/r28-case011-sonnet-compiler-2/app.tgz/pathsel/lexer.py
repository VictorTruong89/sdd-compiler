import json
import string

from .exceptions import LexerError

_START = set(string.ascii_letters + "_")
_CONT = set(string.ascii_letters + string.digits + "_")
_DIGITS = set(string.digits)
_WS = set(" \t\n\r")
_SIMPLE = {".": "dot", "*": "star", ",": "comma", ":": "colon", "@": "current",
           "]": "rbracket", "{": "lbrace", "}": "rbrace", "(": "lparen", ")": "rparen"}


def _consume_until(text, i, delim, start):
    """text[i] is first char after opening delimiter. Returns (content, index after delim)."""
    n = len(text)
    buf = []
    while i < n:
        c = text[i]
        if c == delim:
            return "".join(buf), i + 1
        if c == "\\":
            buf.append(c)
            i += 1
            if i >= n:
                break
            buf.append(text[i])
            i += 1
            continue
        buf.append(c)
        i += 1
    raise LexerError("unterminated token", start)


def tokenize(text):
    """Returns list of (type, value, position); last is eof at len(text)."""
    toks = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c in _WS:
            i += 1
        elif c in _START:
            j = i + 1
            while j < n and text[j] in _CONT:
                j += 1
            toks.append(("unquoted_identifier", text[i:j], i))
            i = j
        elif c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            toks.append(("number", int(text[i:j]), i))
            i = j
        elif c == "-":
            raise LexerError("unknown token '-'", i)
        elif c == "[":
            if i + 1 < n and text[i + 1] == "]":
                toks.append(("flatten", "[]", i))
                i += 2
            elif i + 1 < n and text[i + 1] == "?":
                toks.append(("filter", "[?", i))
                i += 2
            else:
                toks.append(("lbracket", "[", i))
                i += 1
        elif c in _SIMPLE:
            toks.append((_SIMPLE[c], c, i))
            i += 1
        elif c == '"':
            content, j = _consume_until(text, i + 1, '"', i)
            try:
                val = json.loads('"%s"' % content)
            except ValueError:
                raise LexerError("invalid quoted identifier", i)
            toks.append(("quoted_identifier", val, i))
            i = j
        elif c == "'":
            content, j = _consume_until(text, i + 1, "'", i)
            toks.append(("literal", content.replace("\\'", "'"), i))
            i = j
        elif c == "`":
            content, j = _consume_until(text, i + 1, "`", i)
            content = content.replace("\\`", "`")
            try:
                val = json.loads(content)
            except ValueError:
                try:
                    val = json.loads('"%s"' % content.lstrip())
                except ValueError:
                    raise LexerError("invalid json literal", i)
            toks.append(("json_literal", val, i))
            i = j
        elif c == "|":
            if i + 1 < n and text[i + 1] == "|":
                toks.append(("or", "||", i))
                i += 2
            else:
                toks.append(("pipe", "|", i))
                i += 1
        elif c == "&":
            if i + 1 < n and text[i + 1] == "&":
                toks.append(("and", "&&", i))
                i += 2
            else:
                toks.append(("expref", "&", i))
                i += 1
        elif c == "!":
            if i + 1 < n and text[i + 1] == "=":
                toks.append(("ne", "!=", i))
                i += 2
            else:
                toks.append(("not", "!", i))
                i += 1
        elif c == "=":
            if i + 1 < n and text[i + 1] == "=":
                toks.append(("eq", "==", i))
                i += 2
            else:
                raise LexerError("unknown token '='", i)
        elif c in "<>":
            if i + 1 < n and text[i + 1] == "=":
                toks.append(("lte" if c == "<" else "gte", c + "=", i))
                i += 2
            else:
                toks.append(("lt" if c == "<" else "gt", c, i))
                i += 1
        else:
            raise LexerError("unknown token %r" % c, i)
    toks.append(("eof", "", n))
    return toks
