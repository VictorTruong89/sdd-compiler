from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         PathSyntaxError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "json_literal": 0, "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0,
    "number": 0, "current": 0, "expref": 0, "colon": 0, "lbrace": 0,
    "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5,
    "flatten": 9, "star": 20, "filter": 21, "dot": 40, "not": 45,
    "lbracket": 55, "lparen": 60,
}
PROJECTION_STOP = 10
COMPARATORS = ("eq", "ne", "lt", "lte", "gt", "gte")


class Parser:
    def parse(self, text):
        if text == "":
            raise EmptyExpressionError("empty expression")
        self._tokens = tokenize(text)
        self._i = 0
        node = self._expression(0)
        if self._cur() != "eof":
            self._error(self._tokens[self._i])
        return node

    # token helpers
    def _cur(self):
        return self._tokens[self._i][0]

    def _look(self, k=0):
        j = self._i + k
        if j >= len(self._tokens):
            return "eof"
        return self._tokens[j][0]

    def _advance(self):
        self._i += 1

    def _error(self, tok, eof_syntax=False):
        if tok[0] == "eof" and not eof_syntax:
            raise IncompleteExpressionError("incomplete expression", tok[2])
        raise PathSyntaxError("unexpected token %r" % (tok[1],), tok[2])

    def _match(self, ttype):
        if self._cur() == ttype:
            self._advance()
        else:
            self._error(self._tokens[self._i])

    def _expression(self, bp=0):
        tok = self._tokens[self._i]
        self._advance()
        left = getattr(self, "_nud_" + tok[0], None)
        if left is None:
            self._error(tok)
        left = left(tok)
        while bp < BP[self._cur()]:
            led = getattr(self, "_led_" + self._cur(), None)
            tok = self._tokens[self._i]
            if led is None:
                self._error(tok)
            self._advance()
            left = led(left, tok)
        return left

    # nuds
    def _nud_json_literal(self, tok):
        return ("literal", tok[1])

    _nud_literal = _nud_json_literal

    def _nud_unquoted_identifier(self, tok):
        return ("field", tok[1])

    def _nud_quoted_identifier(self, tok):
        if self._cur() == "lparen":
            raise PathSyntaxError("quoted identifier cannot be a function name",
                                  self._tokens[self._i][2])
        return ("field", tok[1])

    def _nud_star(self, tok):
        return ("value_projection", ("identity",), self._proj_rhs(BP["star"]))

    def _nud_filter(self, tok):
        return self._led_filter(("identity",), tok)

    def _nud_lbrace(self, tok):
        return self._multi_hash()

    def _nud_flatten(self, tok):
        return self._led_flatten(("identity",), tok)

    def _nud_not(self, tok):
        return ("not", self._expression(BP["not"]))

    def _nud_lparen(self, tok):
        e = self._expression(0)
        self._match("rparen")
        return e

    def _nud_current(self, tok):
        return ("identity",)

    def _nud_expref(self, tok):
        return ("expref", self._expression(0))

    def _nud_lbracket(self, tok):
        if self._cur() in ("number", "colon"):
            right = self._index_expr()
            return self._project_if_slice(("identity",), right)
        if self._cur() == "star" and self._look(1) == "rbracket":
            self._advance()
            self._advance()
            return ("projection", ("identity",), self._proj_rhs(BP["star"]))
        return self._multi_list()

    # leds
    def _led_dot(self, left, tok):
        if self._cur() != "star":
            right = self._dot_rhs(BP["dot"])
            return ("subexpression", left, right)
        self._advance()
        right = self._proj_rhs(BP["dot"])
        return ("value_projection", left, right)

    def _led_pipe(self, left, tok):
        return ("pipe", left, self._expression(BP["pipe"]))

    def _led_or(self, left, tok):
        return ("or", left, self._expression(BP["or"]))

    def _led_and(self, left, tok):
        return ("and", left, self._expression(BP["and"]))

    def _comp(self, left, tok):
        return ("comparator", tok[0], left, self._expression(BP[tok[0]]))

    _led_eq = _led_ne = _led_lt = _led_lte = _led_gt = _led_gte = _comp

    def _led_lparen(self, left, tok):
        if left[0] != "field":
            raise PathSyntaxError("invalid function name", tok[2])
        args = []
        while self._cur() != "rparen":
            args.append(self._expression(0))
            if self._cur() == "comma":
                self._advance()
                if self._cur() == "rparen":
                    self._error(self._tokens[self._i])
        self._match("rparen")
        return ("function", left[1], args, tok[2])

    def _led_flatten(self, left, tok):
        left = ("flatten", left)
        return ("projection", left, self._proj_rhs(BP["flatten"]))

    def _led_filter(self, left, tok):
        cond = self._expression(0)
        self._match("rbracket")
        right = self._proj_rhs(BP["filter"])
        return ("filter_projection", left, right, cond)

    def _led_lbracket(self, left, tok):
        if self._cur() in ("number", "colon"):
            right = self._index_expr()
            if right[0] == "index":
                return ("index_expression", left, right)
            return self._project_if_slice(left, right)
        if self._cur() == "star" and self._look(1) == "rbracket":
            self._advance()
            self._advance()
            return ("projection", left, self._proj_rhs(BP["star"]))
        self._error(self._tokens[self._i])

    # helpers
    def _project_if_slice(self, left, right):
        if right[0] == "index":
            return ("index_expression", left, right)
        return ("projection", ("index_expression", left, right),
                self._proj_rhs(BP["star"]))

    def _index_expr(self):
        if self._cur() == "colon" or self._look(1) == "colon":
            return self._slice()
        node = ("index", self._tokens[self._i][1])
        self._advance()
        self._match("rbracket")
        return node

    def _slice(self):
        parts = [None, None, None]
        idx = 0
        while self._cur() != "rbracket":
            tok = self._tokens[self._i]
            if tok[0] == "colon":
                idx += 1
                if idx == 3:
                    self._error(tok)
                self._advance()
            elif tok[0] == "number" and parts[idx] is None:
                parts[idx] = tok[1]
                self._advance()
            else:
                self._error(tok)
        self._match("rbracket")
        return ("slice", parts[0], parts[1], parts[2])

    def _proj_rhs(self, bp):
        c = self._cur()
        if BP[c] < PROJECTION_STOP:
            return ("identity",)
        if c == "lbracket" or c == "filter":
            return self._expression(bp)
        if c == "dot":
            self._advance()
            return self._dot_rhs(bp)
        self._error(self._tokens[self._i])

    def _dot_rhs(self, bp):
        c = self._cur()
        if c in ("quoted_identifier", "unquoted_identifier", "star"):
            return self._expression(bp)
        if c == "lbracket":
            self._advance()
            return self._multi_list()
        if c == "lbrace":
            self._advance()
            return self._multi_hash()
        self._error(self._tokens[self._i], eof_syntax=True)

    def _multi_list(self):
        exprs = []
        while True:
            exprs.append(self._expression(0))
            if self._cur() == "rbracket":
                break
            self._match("comma")
        self._match("rbracket")
        return ("multi_list", exprs)

    def _multi_hash(self):
        pairs = []
        while True:
            tok = self._tokens[self._i]
            if tok[0] not in ("quoted_identifier", "unquoted_identifier"):
                self._error(tok)
            self._advance()
            self._match("colon")
            pairs.append((tok[1], self._expression(0)))
            if self._cur() == "comma":
                self._advance()
            elif self._cur() == "rbrace":
                self._advance()
                break
            else:
                self._error(self._tokens[self._i])
        return ("multi_hash", pairs)


def parse(text):
    return Parser().parse(text)
