"""Built-in functions and the provider/signature extension surface."""
import json
import math
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import InvalidTypeError


def is_object(x):
    if isinstance(x, Mapping):
        return True
    if isinstance(x, (list, tuple, str, bytes)):
        return False
    return (hasattr(x, "keys") and hasattr(x, "__getitem__")
            and hasattr(x, "items"))


def is_array(x):
    return isinstance(x, (list, tuple))


def is_number(x):
    return (isinstance(x, (int, float, Decimal)) and not isinstance(x, bool))


def truthy(x):
    if x is None or x is False:
        return False
    if isinstance(x, str) or is_array(x):
        return len(x) > 0
    if is_object(x):
        return len(list(x.keys())) > 0
    return True


def json_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_array(a):
        if not is_array(b) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a):
        if not is_object(b):
            return False
        ka = list(a.keys())
        kb = list(b.keys())
        if len(ka) != len(kb):
            return False
        kbs = set(kb)
        for k in ka:
            if k not in kbs or not json_equal(a[k], b[k]):
                return False
        return True
    if is_array(b) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


class Expref:
    def __init__(self, node, interp):
        self.node = node
        self.interp = interp

    def visit(self, value):
        return self.interp.visit(self.node, value)


def signature(*arguments):
    """spec: pathsel.functions.signature"""
    def decorator(func):
        func.__pathsel_signature__ = list(arguments)
        return func
    return decorator


def _type_ok(value, tname):
    if tname == "any":
        return True
    if tname == "expref":
        return isinstance(value, Expref)
    if isinstance(value, Expref):
        return False
    if tname == "number":
        return is_number(value)
    if tname == "string":
        return isinstance(value, str)
    if tname == "boolean":
        return isinstance(value, bool)
    if tname == "array":
        return is_array(value)
    if tname == "object":
        return is_object(value)
    if tname == "null":
        return value is None
    if tname == "array-number":
        return is_array(value) and all(is_number(v) for v in value)
    if tname == "array-string":
        return is_array(value) and all(isinstance(v, str) for v in value)
    return False


def check_arg(value, spec):
    for t in spec.get("types", []):
        if _type_ok(value, t):
            return True
    return False


def _json_default(o):
    if isinstance(o, Decimal):
        return float(o)
    if is_object(o):
        return dict(o.items())
    if isinstance(o, tuple):
        return list(o)
    return str(o)


def _plain(v):
    return v


def _key_check(keys):
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise InvalidTypeError("invalid sort key type")


_NUMSTR = ("array-number", "array-string")


class Functions:
    @signature({"types": ["number"]})
    def _func_abs(self, a):
        return abs(a)

    @signature({"types": ["array-number"]})
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature({"types": ["number"]})
    def _func_ceil(self, a):
        return math.ceil(a)

    @signature({"types": ["number"]})
    def _func_floor(self, a):
        return math.floor(a)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(json_equal(x, search) for x in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({"types": ["string"]}, {"types": ["array-string"]})
    def _func_join(self, sep, items):
        return sep.join(items)

    @signature({"types": ["object"]})
    def _func_keys(self, o):
        return list(o.keys())

    @signature({"types": ["object"]})
    def _func_values(self, o):
        return [o[k] for k in o.keys()]

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, a):
        if is_object(a):
            return len(list(a.keys()))
        return len(a)

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, arr):
        return [ref.visit(x) for x in arr]

    @signature({"types": list(_NUMSTR)})
    def _func_max(self, a):
        return max(a) if a else None

    @signature({"types": list(_NUMSTR)})
    def _func_min(self, a):
        return min(a) if a else None

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.visit(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.visit(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, arr, ref):
        if not arr:
            return []
        keys = [ref.visit(x) for x in arr]
        _key_check(keys)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in o.keys():
                out[k] = o[k]
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, a):
        if isinstance(a, str):
            return a[::-1]
        return list(reversed(a))

    @signature({"types": list(_NUMSTR)})
    def _func_sort(self, a):
        return sorted(a)

    @signature({"types": ["array-number"]})
    def _func_sum(self, a):
        return sum(a)

    @signature({"types": ["any"]})
    def _func_to_array(self, a):
        if is_array(a):
            return list(a) if isinstance(a, tuple) else a
        return [a]

    @signature({"types": ["any"]})
    def _func_to_string(self, a):
        if isinstance(a, str):
            return a
        return json.dumps(a, separators=(",", ":"), ensure_ascii=True,
                          default=_json_default)

    @signature({"types": ["any"]})
    def _func_to_number(self, a):
        if is_number(a):
            return a
        if isinstance(a, str):
            import re
            if re.fullmatch(r"[+-]?[0-9]+", a):
                return int(a)
            if re.fullmatch(r"[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?", a):
                try:
                    return float(a)
                except ValueError:
                    return None
        return None

    @signature({"types": ["any"]})
    def _func_type(self, a):
        if a is None:
            return "null"
        if isinstance(a, bool):
            return "boolean"
        if is_number(a):
            return "number"
        if isinstance(a, str):
            return "string"
        if is_array(a):
            return "array"
        if is_object(a):
            return "object"
        return "object"  # not stated in spec: host value
