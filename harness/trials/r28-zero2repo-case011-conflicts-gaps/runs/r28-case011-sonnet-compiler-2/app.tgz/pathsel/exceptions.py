"""Failure kinds. # spec: N-000405"""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    pass


class IncompleteExpressionError(PathSelError):
    def __init__(self, message="incomplete expression", lex_position=0):
        PathSelError.__init__(self, message)
        self.lex_position = lex_position


class PathSyntaxError(PathSelError):
    def __init__(self, message="syntax error", lex_position=0):
        PathSelError.__init__(self, message)
        self.lex_position = lex_position


class LexerError(PathSyntaxError):
    """Token-level syntax failure (subclass of PathSyntaxError)."""


class ZeroSliceStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class InvalidArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
