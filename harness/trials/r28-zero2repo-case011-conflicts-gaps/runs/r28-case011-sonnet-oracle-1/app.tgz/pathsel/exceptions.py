"""Failure kinds. Every refusal is a ValueError; the kind is the exception type."""


class PathselError(ValueError):
    """Base of every refusal."""


class EmptyExpressionError(PathselError):
    pass


class IncompleteExpressionError(PathselError):
    def __init__(self, message="incomplete expression", lex_position=0):
        super().__init__("%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class SyntaxFailure(PathselError):
    """Grammar-level syntax failure."""

    def __init__(self, message="syntax error", lex_position=0):
        super().__init__("%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class TokenSyntaxFailure(SyntaxFailure):
    """Token-level syntax failure (a more specific syntax kind)."""


class ZeroSliceStepError(PathselError):
    pass


class UnknownFunctionError(PathselError):
    pass


class InvalidArityError(PathselError):
    pass


class InvalidTypeError(PathselError):
    pass
