"""pathsel: evaluate path expressions against JSON-like Python data."""
from . import exceptions
from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         InvalidArityError, InvalidTypeError, PathselError,
                         SyntaxFailure, TokenSyntaxFailure,
                         UnknownFunctionError, ZeroSliceStepError)
from .interp import Interpreter
from .parser import parse as _parse

__all__ = ["search", "compile", "ParsedExpression"]


class ParsedExpression(object):
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)
