"""Built-in functions and the provider machinery."""
import decimal
import functools
import json
import math
import re

from .exceptions import InvalidArityError, InvalidTypeError
from .interp import (Expref, is_array, is_number, is_object, values_equal)


def signature(*arguments):
    """Declare argument specs: {"types": [...]} (optional "variadic": True)."""
    specs = [dict(a) for a in arguments]

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        wrapper._pathsel_signature = specs
        return wrapper
    return decorator


def type_name(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if is_number(v):
        return "number"
    if isinstance(v, str):
        return "string"
    if is_object(v):
        return "object"
    if is_array(v):
        return "array"
    if isinstance(v, Expref):
        return "expref"
    return "other"


def _matches(v, t):
    if t == "any":
        return True
    if t == "array-number":
        return is_array(v) and all(is_number(x) for x in v)
    if t == "array-string":
        return is_array(v) and all(isinstance(x, str) for x in v)
    return type_name(v) == t


def check_arguments(name, spec, nargs=None, args=None):
    variadic = bool(spec) and spec[-1].get("variadic", False)
    if args is None:
        n = nargs
        if (variadic and n < len(spec)) or (not variadic and n != len(spec)):
            raise InvalidArityError(
                "function %s called with %d argument(s), expected %s%d"
                % (name, n, "at least " if variadic else "", len(spec)))
        return
    for i, a in enumerate(args):
        s = spec[min(i, len(spec) - 1)]
        if not any(_matches(a, t) for t in s.get("types", [])):
            raise InvalidTypeError(
                "invalid type for argument %d of %s: %s (expected %s)"
                % (i + 1, name, type_name(a), "/".join(s.get("types", []))))


def _s(*types, **kw):
    d = {"types": list(types)}
    d.update(kw)
    return d


_INT_RE = re.compile(r"^-?[0-9]+$")
_FLOAT_RE = re.compile(r"^-?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$")


def _json_default(o):
    if isinstance(o, decimal.Decimal):
        return float(o)
    if isinstance(o, tuple):
        return list(o)
    if is_object(o):
        return dict(o)
    return str(o)


def _key_check(keys):
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise InvalidTypeError("sort key must be a number or string, consistently")


class Functions(object):
    @signature(_s("number"))
    def _func_abs(self, x):
        return abs(x)

    @signature(_s("array-number"))
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature(_s("number"))
    def _func_ceil(self, x):
        return math.ceil(x)

    @signature(_s("number"))
    def _func_floor(self, x):
        return math.floor(x)

    @signature(_s("array", "string"), _s("any"))
    def _func_contains(self, subject, item):
        if isinstance(subject, str):
            return isinstance(item, str) and item in subject
        return any(values_equal(x, item) for x in subject)

    @signature(_s("string"), _s("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_s("string"), _s("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_s("string", "array", "object"))
    def _func_length(self, x):
        return len(x)

    @signature(_s("array", "string"))
    def _func_reverse(self, x):
        if isinstance(x, str):
            return x[::-1]
        return list(x)[::-1]

    @signature(_s("string"), _s("array-string"))
    def _func_join(self, sep, items):
        return sep.join(items)

    @signature(_s("object"))
    def _func_keys(self, o):
        return list(o.keys())

    @signature(_s("object"))
    def _func_values(self, o):
        return list(o.values())

    @signature(_s("any"))
    def _func_type(self, x):
        t = type_name(x)
        return "null" if t in ("other", "expref") else t

    @signature(_s("any"))
    def _func_to_array(self, x):
        if is_array(x):
            return x if isinstance(x, list) else list(x)
        return [x]

    @signature(_s("any"))
    def _func_to_string(self, x):
        if isinstance(x, str):
            return x
        return json.dumps(x, separators=(",", ":"), ensure_ascii=True,
                          default=_json_default)

    @signature(_s("any"))
    def _func_to_number(self, x):
        if is_number(x):
            return x
        if isinstance(x, str):
            if _INT_RE.match(x):
                return int(x)
            if _FLOAT_RE.match(x):
                try:
                    return float(x)
                except ValueError:
                    return None
        return None

    @signature(_s("array-number", "array-string"))
    def _func_max(self, a):
        return self._extreme(a, max)

    @signature(_s("array-number", "array-string"))
    def _func_min(self, a):
        return self._extreme(a, min)

    @staticmethod
    def _extreme(a, f):
        if not a:
            return None
        _key_check(a)
        return f(a)

    @signature(_s("array-number", "array-string"))
    def _func_sort(self, a):
        _key_check(a)
        return sorted(a)

    @signature(_s("array-number"))
    def _func_sum(self, a):
        return sum(a)

    @signature(_s("object", variadic=True))
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in o:
                out[k] = o[k]
        return out

    @signature(_s("any", variadic=True))
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_s("expref"), _s("array"))
    def _func_map(self, ref, arr):
        return [ref.visit(e) for e in arr]

    @signature(_s("array"), _s("expref"))
    def _func_sort_by(self, arr, ref):
        keyed = [(ref.visit(e), e) for e in arr]
        if not keyed:
            return []
        keys = [k for k, _ in keyed]
        self._check_keys(keys)
        keyed.sort(key=lambda p: p[0])
        return [e for _, e in keyed]

    @staticmethod
    def _check_keys(keys):
        if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
            return
        raise InvalidTypeError("key must be a number or string, consistently")

    def _by(self, arr, ref, better):
        if not arr:
            return None
        keys = [ref.visit(e) for e in arr]
        self._check_keys(keys)
        best = 0
        for i in range(1, len(arr)):
            if better(keys[i], keys[best]):
                best = i
        return arr[best]

    @signature(_s("array"), _s("expref"))
    def _func_max_by(self, arr, ref):
        return self._by(arr, ref, lambda a, b: a > b)

    @signature(_s("array"), _s("expref"))
    def _func_min_by(self, arr, ref):
        return self._by(arr, ref, lambda a, b: a < b)
