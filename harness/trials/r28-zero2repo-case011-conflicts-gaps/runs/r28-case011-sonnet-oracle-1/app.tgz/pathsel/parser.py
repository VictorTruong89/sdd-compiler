"""Lexer and Pratt parser producing tuple-based ASTs."""
import json
import re

from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         SyntaxFailure, TokenSyntaxFailure, ZeroSliceStepError)

WS = " \t\n\r"
_ID_START = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_ID_CONT = _ID_START | set("0123456789")
_DIGITS = set("0123456789")

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0, "number": 0,
    "current": 0, "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5, "flatten": 9,
    "star": 20, "filter": 21, "dot": 40, "not": 45, "lbrace": 50,
    "lbracket": 55, "lparen": 60,
}
_SIMPLE = {".": "dot", "*": "star", ",": "comma", ":": "colon", "@": "current",
           "(": "lparen", ")": "rparen", "{": "lbrace", "}": "rbrace",
           "]": "rbracket"}


def tokenize(text):
    toks = []  # (type, value, start)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c in WS:
            i += 1
        elif c in _ID_START:
            j = i + 1
            while j < n and text[j] in _ID_CONT:
                j += 1
            toks.append(("unquoted_identifier", text[i:j], i))
            i = j
        elif c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            toks.append(("number", int(text[i:j]), i))
            i = j
        elif c == "-":
            raise TokenSyntaxFailure("unexpected '-'", i)
        elif c == "[":
            if i + 1 < n and text[i + 1] == "?":
                toks.append(("filter", "[?", i)); i += 2
            elif i + 1 < n and text[i + 1] == "]":
                toks.append(("flatten", "[]", i)); i += 2
            else:
                toks.append(("lbracket", "[", i)); i += 1
        elif c in _SIMPLE:
            toks.append((_SIMPLE[c], c, i)); i += 1
        elif c == "|":
            if text[i + 1:i + 2] == "|":
                toks.append(("or", "||", i)); i += 2
            else:
                toks.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if text[i + 1:i + 2] == "&":
                toks.append(("and", "&&", i)); i += 2
            else:
                toks.append(("expref", "&", i)); i += 1
        elif c == "!":
            if text[i + 1:i + 2] == "=":
                toks.append(("ne", "!=", i)); i += 2
            else:
                toks.append(("not", "!", i)); i += 1
        elif c == "=":
            if text[i + 1:i + 2] == "=":
                toks.append(("eq", "==", i)); i += 2
            else:
                raise TokenSyntaxFailure("unexpected '='", i)
        elif c in "<>":
            nm = {"<": ("lt", "lte"), ">": ("gt", "gte")}[c]
            if text[i + 1:i + 2] == "=":
                toks.append((nm[1], c + "=", i)); i += 2
            else:
                toks.append((nm[0], c, i)); i += 1
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            if j >= n:
                raise TokenSyntaxFailure("unterminated quoted identifier", i)
            try:
                val = json.loads(text[i:j + 1])
            except ValueError:
                raise TokenSyntaxFailure("invalid quoted identifier", i)
            if not isinstance(val, str):
                raise TokenSyntaxFailure("invalid quoted identifier", i)
            toks.append(("quoted_identifier", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            buf = []
            while j < n and text[j] != "'":
                if text[j] == "\\" and j + 1 < n and text[j + 1] == "'":
                    buf.append("'"); j += 2
                else:
                    buf.append(text[j]); j += 1
            if j >= n:
                raise TokenSyntaxFailure("unterminated raw string", i)
            toks.append(("literal", "".join(buf), i))
            i = j + 1
        elif c == "`":
            j = i + 1
            buf = []
            while j < n and text[j] != "`":
                if text[j] == "\\" and j + 1 < n and text[j + 1] == "`":
                    buf.append("`"); j += 2
                else:
                    buf.append(text[j]); j += 1
            if j >= n:
                raise TokenSyntaxFailure("unterminated literal", i)
            lex = "".join(buf)
            try:
                val = json.loads(lex)
            except ValueError:
                try:
                    val = json.loads('"%s"' % lex.lstrip())
                except ValueError:
                    raise TokenSyntaxFailure("invalid literal", i)
            toks.append(("literal", val, i))
            i = j + 1
        else:
            raise TokenSyntaxFailure("unknown character %r" % c, i)
    toks.append(("eof", "", n))
    return toks


class Parser:
    def __init__(self, text):
        self.text = text
        self.toks = tokenize(text)
        self.pos = 0

    # helpers
    def cur(self):
        return self.toks[self.pos][0]

    def look(self, k=1):
        p = min(self.pos + k, len(self.toks) - 1)
        return self.toks[p][0]

    def advance(self):
        self.pos += 1

    def fail(self, tok=None):
        t = tok or self.toks[self.pos]
        if t[0] == "eof":
            raise IncompleteExpressionError("unexpected end of expression", len(self.text))
        raise SyntaxFailure("unexpected token %r" % (t[1],), t[2])

    def match(self, ttype):
        if self.cur() == ttype:
            self.advance()
        else:
            self.fail()

    def parse(self):
        if self.text == "":
            raise EmptyExpressionError("empty expression")
        node = self.expr(0)
        if self.cur() != "eof":
            self.fail()
        return node

    def expr(self, bp):
        tok = self.toks[self.pos]
        self.advance()
        left = self.nud(tok)
        while bp < BP[self.cur()]:
            tok = self.toks[self.pos]
            self.advance()
            left = self.led(tok, left)
        return left

    def nud(self, tok):
        t = tok[0]
        if t == "literal":
            return ("literal", tok[1])
        if t == "unquoted_identifier":
            return ("field", tok[1], False)
        if t == "quoted_identifier":
            return ("field", tok[1], True)
        if t == "star":
            return ("valproj", ("current",), self.proj_rhs(BP["star"]))
        if t == "filter":
            return self.filter_tail(("current",))
        if t == "lbrace":
            return self.multi_hash()
        if t == "flatten":
            return ("proj", ("flatten", ("current",)), self.proj_rhs(BP["flatten"]))
        if t == "lbracket":
            c = self.cur()
            if c in ("number", "colon"):
                right = self.index_expr()
                return self.project_if_slice(("current",), right)
            if c == "star" and self.look() == "rbracket":
                self.advance(); self.advance()
                return ("proj", ("current",), self.proj_rhs(BP["star"]))
            return self.multi_list()
        if t == "current":
            return ("current",)
        if t == "expref":
            return ("expref", self.expr(0))
        if t == "not":
            return ("not", self.expr(BP["not"]))
        if t == "lparen":
            e = self.expr(0)
            self.match("rparen")
            return ("group", e)
        self.fail(tok)

    def led(self, tok, left):
        t = tok[0]
        if t == "dot":
            if self.cur() == "star":
                self.advance()
                return ("valproj", left, self.proj_rhs(BP["star"]))
            return ("sub", left, self.dot_rhs(BP["dot"]))
        if t == "pipe":
            return ("pipe", left, self.expr(BP["pipe"]))
        if t == "or":
            return ("or", left, self.expr(BP["or"]))
        if t == "and":
            return ("and", left, self.expr(BP["and"]))
        if t in ("eq", "ne", "lt", "lte", "gt", "gte"):
            return ("cmp", t, left, self.expr(BP[t]))
        if t == "lparen":
            if left[0] != "field" or left[2]:
                raise SyntaxFailure("invalid function name", tok[2])
            args = []
            while self.cur() != "rparen":
                args.append(self.expr(0))
                if self.cur() == "comma":
                    self.advance()
                    if self.cur() == "rparen":
                        self.fail()
            self.match("rparen")
            return ("call", left[1], args)
        if t == "filter":
            return self.filter_tail(left)
        if t == "flatten":
            return ("proj", ("flatten", left), self.proj_rhs(BP["flatten"]))
        if t == "lbracket":
            c = self.cur()
            if c in ("number", "colon"):
                right = self.index_expr()
                return self.project_if_slice(left, right)
            if c == "star" and self.look() == "rbracket":
                self.advance(); self.advance()
                return ("proj", left, self.proj_rhs(BP["star"]))
            self.fail()
        self.fail(tok)

    def filter_tail(self, left):
        pred = self.expr(0)
        self.match("rbracket")
        return ("proj", ("filter", left, pred), self.proj_rhs(BP["filter"]))

    def project_if_slice(self, left, right):
        if right[0] == "slice":
            return ("proj", ("sub", left, right), self.proj_rhs(BP["star"]))
        return ("sub", left, right)

    def index_expr(self):
        if self.look() == "colon" or self.cur() == "colon":
            parts = [None, None, None]
            idx = 0
            while self.cur() != "rbracket":
                c = self.cur()
                if c == "colon":
                    idx += 1
                    if idx > 2:
                        self.fail()
                    self.advance()
                elif c == "number":
                    if parts[idx] is not None:
                        self.fail()
                    parts[idx] = self.toks[self.pos][1]
                    self.advance()
                else:
                    self.fail()
            self.advance()
            if parts[2] == 0:
                raise ZeroSliceStepError("slice step cannot be 0")
            return ("slice", parts[0], parts[1], parts[2])
        val = self.toks[self.pos][1]
        self.advance()
        self.match("rbracket")
        return ("index", val)

    def proj_rhs(self, bp):
        c = self.cur()
        if BP[c] < 10:
            return ("current",)
        if c == "lbracket":
            return self.expr(bp)
        if c == "filter":
            return self.expr(bp)
        if c == "dot":
            self.advance()
            return self.dot_rhs(bp)
        self.fail()

    def dot_rhs(self, bp):
        c = self.cur()
        if c in ("unquoted_identifier", "quoted_identifier", "star"):
            return self.expr(bp)
        if c == "lbracket":
            self.advance()
            return self.multi_list()
        if c == "lbrace":
            self.advance()
            return self.multi_hash()
        t = self.toks[self.pos]
        if t[0] == "eof":
            raise SyntaxFailure("dot at end of expression", t[2])
        self.fail()

    def multi_list(self):
        items = []
        while True:
            items.append(self.expr(0))
            if self.cur() == "comma":
                self.advance()
                continue
            self.match("rbracket")
            break
        return ("mlist", items)

    def multi_hash(self):
        pairs = []
        while True:
            c = self.cur()
            if c not in ("unquoted_identifier", "quoted_identifier"):
                self.fail()
            key = self.toks[self.pos][1]
            self.advance()
            self.match("colon")
            pairs.append((key, self.expr(0)))
            if self.cur() == "comma":
                self.advance()
                continue
            self.match("rbrace")
            break
        return ("mhash", pairs)


def parse(text):
    return Parser(text).parse()
