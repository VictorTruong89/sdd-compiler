"""Tree interpreter."""
import collections.abc as cabc
import decimal
import numbers

from .exceptions import InvalidTypeError


class Expref(object):
    """A deferred expression (value of `&expr`)."""

    def __init__(self, node, interp):
        self.node = node
        self.interp = interp

    def visit(self, value):
        return self.interp.visit(self.node, value)

    def __repr__(self):
        return "<expref>"


def is_number(v):
    return (not isinstance(v, bool)
            and isinstance(v, (numbers.Real, decimal.Decimal)))


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v):
    return isinstance(v, cabc.Mapping)


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, str):
        return v == ""
    if is_array(v) or is_object(v):
        return len(v) == 0
    return False


def values_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(values_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not values_equal(a[k], b[k]):
                return False
        return True
    if is_number(a) or is_number(b) or is_array(a) or is_array(b) \
            or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


class Interpreter(object):
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) or dict
        self.provider = getattr(options, "custom_functions", None)
        from .functions import Functions
        self.builtin = _builtin_provider(Functions)

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_current(self, node, v):
        return v

    def v_literal(self, node, v):
        x = node[1]
        if isinstance(x, (list, dict)):
            import copy
            return copy.deepcopy(x)
        return x

    def v_field(self, node, v):
        if is_object(v):
            try:
                return v.get(node[1]) if hasattr(v, "get") else v[node[1]]
            except Exception:
                return None
        return None

    def v_group(self, node, v):
        return self.visit(node[1], v)

    def v_sub(self, node, v):
        return self.visit(node[2], self.visit(node[1], v))

    def v_pipe(self, node, v):
        return self.visit(node[2], self.visit(node[1], v))

    def v_index(self, node, v):
        if not is_array(v):
            return None
        try:
            return v[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, v):
        if not is_array(v):
            return None
        return list(v[slice(node[1], node[2], node[3])])

    def v_flatten(self, node, v):
        v = self.visit(node[1], v)
        if not is_array(v):
            return None
        out = []
        for e in v:
            if is_array(e):
                out.extend(e)
            else:
                out.append(e)
        return out

    def v_filter(self, node, v):
        base = self.visit(node[1], v)
        if not is_array(base):
            return None
        return [e for e in base if not is_false(self.visit(node[2], e))]

    def v_proj(self, node, v):
        base = self.visit(node[1], v)
        if not is_array(base):
            return None
        out = []
        for e in base:
            r = self.visit(node[2], e)
            if r is not None:
                out.append(r)
        return out

    def v_valproj(self, node, v):
        base = self.visit(node[1], v)
        if not is_object(base):
            return None
        out = []
        for e in list(base.values()):
            r = self.visit(node[2], e)
            if r is not None:
                out.append(r)
        return out

    def v_mlist(self, node, v):
        if v is None:
            return None
        return [self.visit(n, v) for n in node[1]]

    def v_mhash(self, node, v):
        if v is None:
            return None
        d = self.dict_cls()
        for k, n in node[1]:
            d[k] = self.visit(n, v)
        return d

    def v_or(self, node, v):
        l = self.visit(node[1], v)
        return self.visit(node[2], v) if is_false(l) else l

    def v_and(self, node, v):
        l = self.visit(node[1], v)
        return l if is_false(l) else self.visit(node[2], v)

    def v_not(self, node, v):
        return is_false(self.visit(node[1], v))

    def v_expref(self, node, v):
        return Expref(node[1], self)

    def v_cmp(self, node, v):
        op = node[1]
        a = self.visit(node[2], v)
        b = self.visit(node[3], v)
        if op == "eq":
            return values_equal(a, b)
        if op == "ne":
            return not values_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def v_call(self, node, v):
        name = node[1]
        fn = None
        if self.provider is not None:
            fn = getattr(self.provider, "_func_" + name, None)
            owner = self.provider
        if fn is None:
            fn = getattr(self.builtin, "_func_" + name, None)
            owner = self.builtin
        if fn is None or not hasattr(fn, "_pathsel_signature"):
            from .exceptions import UnknownFunctionError
            raise UnknownFunctionError("unknown function: %s" % name)
        from .functions import check_arguments
        nargs = len(node[2])
        check_arguments(name, fn._pathsel_signature, nargs=nargs)
        args = [self.visit(a, v) for a in node[2]]
        check_arguments(name, fn._pathsel_signature, args=args)
        return fn(*args)


_BUILTIN = []


def _builtin_provider(cls):
    if not _BUILTIN:
        _BUILTIN.append(cls())
    return _BUILTIN[0]
