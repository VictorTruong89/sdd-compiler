"""AST nodes for PathSel and their evaluation.

Every node is evaluated as ``node.eval(current, ctx)``. ``current`` is the
value the expression is looking at; ``ctx`` carries the evaluation options
(mapping type and function table) for the search in progress.
"""

import copy
from collections.abc import Mapping

from . import _values as V
from .errors import (
    InvalidArityError,
    InvalidTypeError,
    UnknownFunctionError,
)


class Node:
    __slots__ = ()

    def eval(self, cur, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Current(Node):
    """``@`` and the identity of a projection's right-hand side."""

    __slots__ = ()

    def eval(self, cur, ctx):
        return cur


CURRENT = Current()


def _sub(left, right):
    """Chain two nodes: the right one is applied to the left one's result."""
    if isinstance(left, Current):
        return right
    if isinstance(right, Current):
        return left
    return Subexpr(left, right)


class Field(Node):
    """An identifier (bare or quoted): the named field of an object."""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, cur, ctx):
        if isinstance(cur, Mapping):
            return cur.get(self.name)
        return None


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, cur, ctx):
        return copy.deepcopy(self.value)


class Subexpr(Node):
    """``left`` then ``right`` applied to the result (dot and pipe)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Index(Node):
    __slots__ = ("source", "index")

    def __init__(self, source, index):
        self.source = source
        self.index = index

    def eval(self, cur, ctx):
        value = self.source.eval(cur, ctx)
        if not V.is_array(value):
            return None
        n = len(value)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return value[i]
        return None


def slice_values(items, start, stop, step):
    """Python-style slice with the PathSel rules (step 0 is refused earlier)."""
    n = len(items)
    if step is None:
        step = 1
    if step > 0:
        s = 0 if start is None else start
        if s < 0:
            s += n
        s = min(max(s, 0), n)
        e = n if stop is None else stop
        if e < 0:
            e += n
        e = min(max(e, 0), n)
    else:
        s = n - 1 if start is None else start
        if s < 0:
            s += n
        s = min(max(s, -1), n - 1)
        if stop is None:
            e = -1  # past the beginning; must not have the length added
        else:
            e = stop + n if stop < 0 else stop
        e = min(max(e, -1), n - 1)
    return [items[i] for i in range(s, e, step)]


class Slice(Node):
    __slots__ = ("source", "start", "stop", "step")

    def __init__(self, source, start, stop, step):
        self.source = source
        self.start = start
        self.stop = stop
        self.step = step

    def eval(self, cur, ctx):
        value = self.source.eval(cur, ctx)
        if not V.is_array(value):
            return None
        return slice_values(value, self.start, self.stop, self.step)


class Flatten(Node):
    __slots__ = ("source",)

    def __init__(self, source):
        self.source = source

    def eval(self, cur, ctx):
        value = self.source.eval(cur, ctx)
        if not V.is_array(value):
            return None
        out = []
        for item in value:
            if V.is_array(item):
                out.extend(item)
            else:
                out.append(item)
        return out


class FilterSelect(Node):
    """Keep the elements of an array whose predicate is a true value."""

    __slots__ = ("source", "predicate")

    def __init__(self, source, predicate):
        self.source = source
        self.predicate = predicate

    def eval(self, cur, ctx):
        value = self.source.eval(cur, ctx)
        if not V.is_array(value):
            return None
        return [item for item in value
                if not V.is_false(self.predicate.eval(item, ctx))]


class Projection(Node):
    """Apply ``rhs`` to each element (or object value) of ``source``.

    Null results are dropped. ``kind`` is 'list' for arrays and 'object'
    for the values of an object. A non-matching source yields null.
    """

    __slots__ = ("source", "rhs", "kind")

    def __init__(self, source, rhs, kind):
        self.source = source
        self.rhs = rhs
        self.kind = kind

    def eval(self, cur, ctx):
        value = self.source.eval(cur, ctx)
        if self.kind == "object":
            if not isinstance(value, Mapping):
                return None
            items = list(value.values())
        else:
            if not V.is_array(value):
                return None
            items = value
        out = []
        for item in items:
            result = self.rhs.eval(item, ctx)
            if result is not None:
                out.append(result)
        return out


class Not(Node):
    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return V.is_false(self.node.eval(cur, ctx))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if V.is_false(value):
            return value
        return self.right.eval(cur, ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not V.is_false(value):
            return value
        return self.right.eval(cur, ctx)


_ORDER_OPS = {
    "lt": lambda a, b: a < b,
    "lte": lambda a, b: a <= b,
    "gt": lambda a, b: a > b,
    "gte": lambda a, b: a >= b,
}


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        a = self.left.eval(cur, ctx)
        b = self.right.eval(cur, ctx)
        if self.op == "eq":
            return V.json_equal(a, b)
        if self.op == "ne":
            return not V.json_equal(a, b)
        if not V.orderable(a, b):
            return None
        return bool(_ORDER_OPS[self.op](a, b))


class MultiList(Node):
    """``[e1, e2, ...]``: one element per expression, nulls stored.

    Unlike a multiselect hash, a null current value still yields one element
    per expression (see NOTES.md).
    """

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def eval(self, cur, ctx):
        return [item.eval(cur, ctx) for item in self.items]


class MultiHash(Node):
    """``{k: e, ...}``: a new mapping; a null current value yields null."""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, cur, ctx):
        if cur is None:
            return None
        out = ctx.new_mapping()
        for key, node in self.pairs:
            out[key] = node.eval(cur, ctx)
        return out


class ExpressionRef(Node):
    """``&expr``: a deferred expression, evaluated by functions later."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return ExpressionReference(self.node, ctx)


class ExpressionReference:
    """The value of an expression reference. Built-ins call :meth:`apply`."""

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def apply(self, value):
        return self.node.eval(value, self.ctx)


def _accepts(value, type_names):
    for name in type_names:
        if name == "any":
            return True
        if name == "reference":
            if isinstance(value, ExpressionReference):
                return True
        elif V.json_type(value) == name:
            return True
    return False


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, cur, ctx):
        entry = ctx.lookup(self.name)
        if entry is None:
            raise UnknownFunctionError("unknown function %r" % self.name)
        count = len(self.args)
        if entry.variadic:
            if count < 1:
                raise InvalidArityError("%s takes one or more arguments" % self.name)
        elif count != len(entry.types):
            raise InvalidArityError(
                "%s takes %d argument(s), got %d" % (self.name, len(entry.types), count))
        values = [arg.eval(cur, ctx) for arg in self.args]
        for index, value in enumerate(values):
            if entry.variadic:
                accepted = entry.types[0]
            else:
                accepted = entry.types[index]
            if not _accepts(value, accepted):
                raise InvalidTypeError(
                    "%s: argument %d has an invalid type" % (self.name, index + 1))
        return entry.func(*values)
