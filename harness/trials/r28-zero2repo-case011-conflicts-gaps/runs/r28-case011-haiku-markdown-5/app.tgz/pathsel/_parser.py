"""Pratt parser for PathSel.

Binding powers (higher binds tighter):

  pipe 1 | or 2 | and 3 | comparators 5 | flatten 9 | list/slice/object
  wildcard that starts an operand 20 | filter 21 | dot 40 | index, slice or
  wildcard bracket as a step 55 | ``!`` operand 45.

A projection's right-hand side keeps consuming steps while the next step's
binding power is greater than the projection's (FP-04, "Reach of a
projection"). The first step after the projection's form is always taken
into the right-hand side when it is a dot step or a bracket/filter step.
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailure,
    ZeroSliceStepError,
)
from ._ast import (
    CURRENT,
    And,
    Compare,
    Field,
    FilterSelect,
    FunctionCall,
    Flatten,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    ExpressionRef,
    Or,
    Projection,
    Slice,
    _sub,
)
from ._lexer import Lexer

_COMPARATORS = frozenset(["eq", "ne", "lt", "lte", "gt", "gte"])

_BP_PIPE = 1
_BP_OR = 2
_BP_AND = 3
_BP_COMPARE = 5
_BP_NOT = 45
_BP_FLATTEN = 9
_BP_WILDCARD = 20
_BP_FILTER = 21
_BP_DOT = 40
_BP_STEP = 55


class Parser:
    def __init__(self, text):
        self.text = text
        self.lexer = Lexer(text)
        self.buffer = []

    # ----- token access -------------------------------------------------

    def peek(self, k=0):
        while len(self.buffer) <= k:
            self.buffer.append(self.lexer.next_token())
        return self.buffer[k]

    def advance(self):
        tok = self.peek(0)
        del self.buffer[0]
        return tok

    def expect(self, ttype):
        tok = self.peek(0)
        if tok.type != ttype:
            self.unexpected(tok)
        return self.advance()

    # ----- failures -------------------------------------------------------

    def unexpected(self, tok):
        """End of text where more input is required is incomplete; else syntax."""
        if tok.type == "eof":
            raise IncompleteExpressionError(
                "expression ends where more input is required", len(self.text))
        raise SyntaxFailure("unexpected token %s at offset %d" % (tok.type, tok.pos), tok.pos)

    def syntax_at(self, tok):
        """Syntax failure even at the end of the text (e.g. a dot at the end)."""
        pos = len(self.text) if tok.type == "eof" else tok.pos
        raise SyntaxFailure("syntax error at offset %d" % pos, pos)

    # ----- binding powers -------------------------------------------------

    def lbp(self, tok):
        t = tok.type
        if t == "pipe":
            return _BP_PIPE
        if t == "or":
            return _BP_OR
        if t == "and":
            return _BP_AND
        if t in _COMPARATORS:
            return _BP_COMPARE
        if t == "dot":
            return _BP_DOT
        if t == "lbracket":
            nxt = self.peek(1).type
            if nxt == "rbracket":
                return _BP_FLATTEN
            if nxt == "question":
                return _BP_FILTER
            return _BP_STEP
        return 0

    # ----- core loop ------------------------------------------------------

    def parse_expression(self, rbp):
        tok = self.advance()
        left = self.nud(tok)
        return self.led_loop(rbp, left)

    def led_loop(self, rbp, left):
        while True:
            tok = self.peek(0)
            if rbp >= self.lbp(tok):
                return left
            self.advance()
            left = self.led(tok, left)

    def nud(self, tok):
        t = tok.type
        if t == "ident":
            if self.peek(0).type == "lparen":
                self.advance()
                return FunctionCall(tok.value, self.parse_args())
            return Field(tok.value)
        if t == "qident":
            return Field(tok.value)
        if t == "at":
            return CURRENT
        if t == "star":
            return Projection(CURRENT, self.projection_rhs(_BP_WILDCARD), "object")
        if t == "lbracket":
            return self.nud_lbracket()
        if t == "lbrace":
            return self.parse_multihash()
        if t == "lparen":
            node = self.parse_expression(0)
            self.expect("rparen")
            return node
        if t == "amp":
            return ExpressionRef(self.parse_expression(0))
        if t == "not":
            return Not(self.parse_expression(_BP_NOT))
        if t in ("literal", "raw"):
            return Literal(tok.value)
        self.unexpected(tok)

    def led(self, tok, left):
        t = tok.type
        if t == "pipe":
            return _sub(left, self.parse_expression(_BP_PIPE))
        if t == "or":
            return Or(left, self.parse_expression(_BP_OR))
        if t == "and":
            return And(left, self.parse_expression(_BP_AND))
        if t in _COMPARATORS:
            return Compare(t, left, self.parse_expression(_BP_COMPARE))
        if t == "dot":
            return self.parse_dot(left)
        if t == "lbracket":
            nxt = self.peek(0).type
            if nxt == "rbracket":
                self.advance()
                return Projection(Flatten(left), self.projection_rhs(_BP_FLATTEN), "list")
            if nxt == "question":
                self.advance()
                return self.filter_tail(left)
            if nxt == "star":
                self.advance()
                self.expect("rbracket")
                return Projection(left, self.projection_rhs(_BP_WILDCARD), "list")
            if nxt in ("number", "colon"):
                return self.index_or_slice(left)
            self.unexpected(self.peek(0))
        self.unexpected(tok)

    # ----- brackets -------------------------------------------------------

    def nud_lbracket(self):
        """A bracket that starts an operand (the ``[`` is already consumed)."""
        nxt = self.peek(0).type
        if nxt in ("number", "colon"):
            return self.index_or_slice(CURRENT)
        if nxt == "star" and self.peek(1).type == "rbracket":
            self.advance()
            self.advance()
            return Projection(CURRENT, self.projection_rhs(_BP_WILDCARD), "list")
        if nxt == "rbracket":
            self.advance()
            return Projection(Flatten(CURRENT), self.projection_rhs(_BP_FLATTEN), "list")
        if nxt == "question":
            self.advance()
            return self.filter_tail(CURRENT)
        return self.multilist_body()

    def index_or_slice(self, source):
        """Parse the inside of ``[...]`` after the opening bracket was seen."""
        parts = [self.slice_part()]
        while self.peek(0).type == "colon":
            colon = self.advance()
            if len(parts) == 3:
                raise SyntaxFailure("slice has more than three parts", colon.pos)
            parts.append(self.slice_part())
        self.expect("rbracket")
        if len(parts) == 1:
            if parts[0] is None:
                raise SyntaxFailure("empty index", self.peek(0).pos)
            return Index(source, parts[0])
        start, stop = parts[0], parts[1]
        step = parts[2] if len(parts) == 3 else None
        if step == 0:
            raise ZeroSliceStepError("slice step must not be 0")
        return Projection(Slice(source, start, stop, step), self.projection_rhs(_BP_WILDCARD), "list")

    def slice_part(self):
        tok = self.peek(0)
        if tok.type == "number":
            self.advance()
            return tok.value
        if tok.type in ("colon", "rbracket"):
            return None
        self.unexpected(tok)

    def filter_tail(self, source):
        """Parse ``predicate]`` after ``[?`` was consumed."""
        predicate = self.parse_expression(0)
        self.expect("rbracket")
        return Projection(FilterSelect(source, predicate), self.projection_rhs(_BP_FILTER), "list")

    def multilist_body(self):
        """Parse ``e1, e2, ...]`` after ``[`` was consumed."""
        items = []
        while True:
            items.append(self.parse_expression(0))
            tok = self.peek(0)
            if tok.type == "comma":
                self.advance()
                continue
            if tok.type == "rbracket":
                self.advance()
                return MultiList(items)
            self.unexpected(tok)

    def parse_multihash(self):
        """Parse ``key: e, ...}`` after ``{`` was consumed."""
        pairs = []
        while True:
            key = self.advance()
            if key.type not in ("ident", "qident"):
                self.unexpected(key)
            self.expect("colon")
            pairs.append((key.value, self.parse_expression(0)))
            tok = self.peek(0)
            if tok.type == "comma":
                self.advance()
                continue
            if tok.type == "rbrace":
                self.advance()
                return MultiHash(pairs)
            self.unexpected(tok)

    def parse_args(self):
        """Parse ``e1, e2)`` after ``(`` was consumed."""
        args = []
        if self.peek(0).type == "rparen":
            self.advance()
            return args
        while True:
            args.append(self.parse_expression(0))
            tok = self.peek(0)
            if tok.type == "comma":
                self.advance()
                continue
            if tok.type == "rparen":
                self.advance()
                return args
            self.unexpected(tok)

    # ----- dot and projections --------------------------------------------

    def parse_dot(self, left):
        """Parse the step after a dot (the dot is already consumed)."""
        tok = self.advance()
        t = tok.type
        if t in ("ident", "qident"):
            return _sub(left, Field(tok.value))
        if t == "star":
            return Projection(left, self.projection_rhs(_BP_DOT), "object")
        if t == "lbracket":
            return _sub(left, self.multilist_body())
        if t == "lbrace":
            return _sub(left, self.parse_multihash())
        self.syntax_at(tok)

    def projection_rhs(self, bp):
        """Right-hand side of a projection whose binding power is ``bp``."""
        tok = self.peek(0)
        if tok.type == "dot":
            self.advance()
            step = self.parse_dot(CURRENT)
            return self.led_loop(bp, step)
        if tok.type == "lbracket" and self.peek(1).type != "rbracket":
            return self.parse_expression(bp)
        return CURRENT


def parse(text):
    """Parse expression text into a node; raise the FP-01 failure kinds."""
    if len(text) == 0:
        raise EmptyExpressionError("empty expression")
    parser = Parser(text)
    node = parser.parse_expression(0)
    tok = parser.peek(0)
    if tok.type != "eof":
        raise SyntaxFailure("unexpected token %s at offset %d" % (tok.type, tok.pos), tok.pos)
    return node
