"""Value classification, truthiness, equality and ordering.

Mapping values are objects, list/tuple values are arrays, ``str`` is a string,
``bool`` is a boolean (never a number), ``int``/``float`` are numbers, and
``None`` is null. ``decimal.Decimal`` counts as a number for comparisons only;
any other host value is "host" and is refused by built-in argument checks.
"""

from collections.abc import Mapping
from decimal import Decimal


def json_type(value):
    """Return one of 'null', 'boolean', 'number', 'string', 'array', 'object', 'host'."""
    if value is None:
        return "null"
    if value is True or value is False:
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, Mapping):
        return "object"
    if isinstance(value, (list, tuple)):
        return "array"
    return "host"


def is_array(value):
    return isinstance(value, (list, tuple))


def is_json_number(value):
    """A JSON number: int or float, but not bool."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_comparable_number(value):
    """A number for comparison purposes: JSON numbers plus host decimals."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None or value is False:
        return True
    if isinstance(value, (str, list, tuple)):
        return len(value) == 0
    if isinstance(value, Mapping):
        return len(value) == 0
    return False


def json_equal(a, b):
    """Deep JSON equality; a number is never equal to a boolean."""
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_comparable_number(a) or is_comparable_number(b):
        return is_comparable_number(a) and is_comparable_number(b) and a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if isinstance(a, Mapping) or isinstance(b, Mapping):
        if not (isinstance(a, Mapping) and isinstance(b, Mapping)):
            return False
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)):
            return False
        if len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    try:
        return bool(a == b)
    except Exception:  # host values with hostile __eq__
        return False


def orderable(a, b):
    """True when a and b are both numbers or both strings."""
    if is_comparable_number(a) and is_comparable_number(b):
        return True
    return isinstance(a, str) and isinstance(b, str)
