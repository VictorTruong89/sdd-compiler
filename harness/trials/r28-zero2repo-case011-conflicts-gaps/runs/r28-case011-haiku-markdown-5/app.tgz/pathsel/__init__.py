"""PathSel: evaluate declarative path expressions against Python data.

Public entries:

* ``search(expression, data, options=None)`` - one-shot evaluation.
* ``compile(expression)`` - parse once; the result has ``.search(data, options=None)``.

Both return the same value, or raise a ``ValueError`` subclass from
:mod:`pathsel.errors` when the expression is refused.
"""

from ._context import make_context
from ._parser import parse
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


class ParsedExpression:
    """A parsed PathSel expression that can be searched many times."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return self._node.eval(value, make_context(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):  # noqa: A001 - published name (see Interface Contract)
    """Parse ``expression`` and return a :class:`ParsedExpression`."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` in one call."""
    return compile(expression).search(data, options)
