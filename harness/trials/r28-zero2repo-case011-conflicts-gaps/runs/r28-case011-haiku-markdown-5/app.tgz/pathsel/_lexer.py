"""Lazy tokenizer for the PathSel language.

Tokens are produced one at a time so that the parser meets failures in text
order: a token-level failure later in the text is not reported ahead of a
grammar-level failure earlier in the text.
"""

import json
import re

from .errors import TokenSyntaxFailure

WHITESPACE = " \t\r\n"

_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_DIGITS_RE = re.compile(r"[0-9]+")
_UNICODE_ESCAPE_RE = re.compile(r"\\u([0-9a-fA-F]{4})")

_TWO_CHAR = {
    "==": "eq",
    "!=": "ne",
    "<=": "lte",
    ">=": "gte",
    "&&": "and",
    "||": "or",
}

_ONE_CHAR = {
    "[": "lbracket",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    ".": "dot",
    "*": "star",
    "@": "at",
    "?": "question",
    "&": "amp",
    "|": "pipe",
    "!": "not",
    "<": "lt",
    ">": "gt",
}


class Token:
    __slots__ = ("type", "value", "pos")

    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.type, self.value, self.pos)


def _is_digit(ch):
    return "0" <= ch <= "9"


def _is_ident_start(ch):
    return ("A" <= ch <= "Z") or ("a" <= ch <= "z") or ch == "_"


def decode_raw_escapes(text):
    """Decode ``\\uXXXX`` escapes (with surrogate pairs) in a raw string."""
    if "\\u" not in text:
        return text
    text = _UNICODE_ESCAPE_RE.sub(lambda m: chr(int(m.group(1), 16)), text)
    return text.encode("utf-16", "surrogatepass").decode("utf-16", "surrogatepass")


def _json_literal_value(body, pos):
    """Read a backtick literal body as JSON, or as bare JSON-string content."""
    try:
        return json.loads(body)
    except ValueError:
        pass
    try:
        return json.loads('"' + body.lstrip(WHITESPACE) + '"')
    except ValueError:
        raise TokenSyntaxFailure("literal is neither JSON nor JSON string content", pos)


class Lexer:
    def __init__(self, text):
        self.text = text
        self.pos = 0

    def next_token(self):
        text = self.text
        n = len(text)
        i = self.pos
        while i < n and text[i] in WHITESPACE:
            i += 1
        if i >= n:
            self.pos = n
            return Token("eof", None, n)

        ch = text[i]
        pair = text[i:i + 2]
        if pair in _TWO_CHAR:
            self.pos = i + 2
            return Token(_TWO_CHAR[pair], None, i)
        if ch in _ONE_CHAR:
            self.pos = i + 1
            return Token(_ONE_CHAR[ch], None, i)
        if ch == "-":
            if i + 1 < n and _is_digit(text[i + 1]):
                m = _DIGITS_RE.match(text, i + 1)
                self.pos = m.end()
                return Token("number", int(text[i:m.end()]), i)
            raise TokenSyntaxFailure("a hyphen that does not begin a number begins no token", i)
        if _is_digit(ch):
            m = _DIGITS_RE.match(text, i)
            self.pos = m.end()
            return Token("number", int(text[i:m.end()]), i)
        if _is_ident_start(ch):
            m = _IDENT_RE.match(text, i)
            self.pos = m.end()
            return Token("ident", m.group(0), i)
        if ch == '"':
            return self._quoted_identifier(i)
        if ch == "'":
            return self._raw_string(i)
        if ch == "`":
            return self._json_literal(i)
        raise TokenSyntaxFailure("character %r begins no token" % ch, i)

    def _quoted_identifier(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        while j < n:
            c = text[j]
            if c == "\\":
                j += 2
                continue
            if c == '"':
                break
            j += 1
        if j >= n:
            raise TokenSyntaxFailure("unterminated quoted identifier", start)
        try:
            value = json.loads(text[start:j + 1])
        except ValueError:
            raise TokenSyntaxFailure("quoted identifier is not a legal JSON string", start)
        self.pos = j + 1
        return Token("qident", value, start)

    def _raw_string(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        buf = []
        closed = False
        while j < n:
            c = text[j]
            if c == "\\" and j + 1 < n and text[j + 1] == "'":
                buf.append("'")
                j += 2
                continue
            if c == "'":
                closed = True
                break
            buf.append(c)
            j += 1
        if not closed:
            raise TokenSyntaxFailure("unterminated raw string literal", start)
        self.pos = j + 1
        return Token("raw", decode_raw_escapes("".join(buf)), start)

    def _json_literal(self, start):
        text = self.text
        n = len(text)
        j = start + 1
        buf = []
        closed = False
        while j < n:
            c = text[j]
            if c == "\\" and j + 1 < n and text[j + 1] == "`":
                buf.append("`")
                j += 2
                continue
            if c == "`":
                closed = True
                break
            buf.append(c)
            j += 1
        if not closed:
            raise TokenSyntaxFailure("unclosed JSON literal", start)
        self.pos = j + 1
        return Token("literal", _json_literal_value("".join(buf), start), start)
