"""Per-search evaluation context built from the caller's options object."""

from .functions import BUILTIN_FUNCTIONS, collect_functions


class Context:
    __slots__ = ("dict_cls", "functions")

    def __init__(self, dict_cls, functions):
        self.dict_cls = dict_cls
        self.functions = functions

    def new_mapping(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()

    def lookup(self, name):
        return self.functions.get(name)


def make_context(options):
    """Build the context for one search. ``options`` may be None.

    Built-in functions always win over a provider's function of the same name,
    so every built-in keeps its behavior on a search that uses a provider.
    """
    dict_cls = getattr(options, "dict_cls", None)
    provider = getattr(options, "custom_functions", None)
    functions = dict(BUILTIN_FUNCTIONS)
    if provider is not None:
        for name, entry in collect_functions(provider).items():
            if name not in BUILTIN_FUNCTIONS:
                functions[name] = entry
    return Context(dict_cls, functions)
