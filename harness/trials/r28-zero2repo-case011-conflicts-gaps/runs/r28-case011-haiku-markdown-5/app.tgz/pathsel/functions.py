"""Built-in language functions and the provider API.

``Functions`` is the built-in provider. A provider is extended by subclassing
it and declaring methods named ``_func_<name>`` decorated with
:func:`signature`. Each such method receives the provider instance first and
then one already-evaluated argument per signature entry.
"""

import json
import math
import re
from collections import namedtuple
from collections.abc import Mapping
from decimal import Decimal

from . import _values as V
from .errors import InvalidTypeError

_KNOWN_TYPES = frozenset(
    ["number", "string", "array", "object", "null", "boolean", "any", "reference"]
)

FunctionEntry = namedtuple("FunctionEntry", "name func types variadic")

_INT_NUMERAL = re.compile(r"-?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def signature(*arguments):
    """Declare the accepted types of a function's arguments.

    Each argument is ``{"types": [<type-name>, ...]}``. Returns a decorator
    that marks the implementation and returns it (it does not call it).
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise TypeError("each signature argument must be a mapping with a 'types' list")
        types = argument["types"]
        if isinstance(types, str) or not isinstance(types, (list, tuple)) or not types:
            raise TypeError("'types' must be a non-empty list of type names")
        for name in types:
            if name not in _KNOWN_TYPES:
                raise TypeError("unknown type name %r" % (name,))
        specs.append(list(types))

    def decorator(fn):
        fn._pathsel_types = [list(spec) for spec in specs]
        fn._pathsel_variadic = False
        return fn

    return decorator


def _variadic(argument):
    """Internal: a signature whose single argument spec repeats (one or more)."""
    base = signature(argument)

    def decorator(fn):
        base(fn)
        fn._pathsel_variadic = True
        return fn

    return decorator


def _t(*names):
    return {"types": list(names)}


def _require_json_numbers(values):
    for item in values:
        if not V.is_json_number(item):
            raise InvalidTypeError("expected an array of numbers")


def _ordered_kind(values):
    """'number' or 'string' when all values share that kind; None when empty."""
    if not values:
        return None
    if all(V.is_json_number(v) for v in values):
        return "number"
    if all(isinstance(v, str) for v in values):
        return "string"
    raise InvalidTypeError("expected numbers or strings, not mixed")


def _jsonable(value):
    if isinstance(value, Mapping):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


class Functions:
    """The built-in provider. Subclass it to add custom functions."""

    @signature(_t("number"))
    def _func_abs(self, value):
        return abs(value)

    @signature(_t("array"))
    def _func_avg(self, values):
        _require_json_numbers(values)
        if not values:
            return None
        return sum(values) / len(values)

    @signature(_t("number"))
    def _func_ceil(self, value):
        return math.ceil(value)

    @signature(_t("number"))
    def _func_floor(self, value):
        return math.floor(value)

    @signature(_t("array", "string"), _t("any"))
    def _func_contains(self, haystack, needle):
        if isinstance(haystack, str):
            if not isinstance(needle, str):
                raise InvalidTypeError("contains: a string needs a string second argument")
            return needle in haystack
        return any(V.json_equal(item, needle) for item in haystack)

    @signature(_t("string"), _t("string"))
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature(_t("string"), _t("string"))
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @signature(_t("string", "array", "object"))
    def _func_length(self, value):
        return len(value)

    @signature(_t("array", "string"))
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature(_t("string"), _t("array"))
    def _func_join(self, separator, parts):
        for part in parts:
            if not isinstance(part, str):
                raise InvalidTypeError("join expects an array of strings")
        return separator.join(parts)

    @signature(_t("object"))
    def _func_keys(self, mapping):
        return list(mapping.keys())

    @signature(_t("object"))
    def _func_values(self, mapping):
        return list(mapping.values())

    @signature(_t("any"))
    def _func_type(self, value):
        kind = V.json_type(value)
        if kind == "host":
            return "number" if isinstance(value, Decimal) else "object"
        return kind

    @signature(_t("any"))
    def _func_to_array(self, value):
        if V.is_array(value):
            return value
        return [value]

    @signature(_t("any"))
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        if isinstance(value, Decimal):
            return str(value)
        try:
            return json.dumps(_jsonable(value), separators=(",", ":"), default=str)
        except (TypeError, ValueError):
            return str(value)

    @signature(_t("any"))
    def _func_to_number(self, value):
        if V.is_json_number(value) or isinstance(value, Decimal):
            return value
        if isinstance(value, str):
            if _INT_NUMERAL.fullmatch(value):
                return int(value)
            if _FLOAT_NUMERAL.fullmatch(value):
                return float(value)
        return None

    @signature(_t("array"))
    def _func_max(self, values):
        if _ordered_kind(values) is None:
            return None
        return max(values)

    @signature(_t("array"))
    def _func_min(self, values):
        if _ordered_kind(values) is None:
            return None
        return min(values)

    @signature(_t("array"))
    def _func_sort(self, values):
        if _ordered_kind(values) is None:
            return []
        return sorted(values)

    @signature(_t("array"))
    def _func_sum(self, values):
        _require_json_numbers(values)
        return sum(values)

    @_variadic(_t("object"))
    def _func_merge(self, *objects):
        out = {}
        for mapping in objects:
            out.update(mapping)
        return out

    @_variadic(_t("any"))
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature(_t("reference"), _t("array"))
    def _func_map(self, ref, values):
        return [ref.apply(item) for item in values]

    @signature(_t("array"), _t("reference"))
    def _func_sort_by(self, values, ref):
        keys = [ref.apply(item) for item in values]
        _ordered_kind(keys)
        order = sorted(range(len(values)), key=keys.__getitem__)
        return [values[i] for i in order]

    @signature(_t("array"), _t("reference"))
    def _func_max_by(self, values, ref):
        keys = [ref.apply(item) for item in values]
        if _ordered_kind(keys) is None:
            return None
        best = 0
        for i in range(1, len(keys)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @signature(_t("array"), _t("reference"))
    def _func_min_by(self, values, ref):
        keys = [ref.apply(item) for item in values]
        if _ordered_kind(keys) is None:
            return None
        best = 0
        for i in range(1, len(keys)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


def collect_functions(provider):
    """Return {name: FunctionEntry} for every signature-marked ``_func_`` attribute."""
    found = {}
    for attr in dir(provider):
        if not attr.startswith("_func_") or len(attr) == len("_func_"):
            continue
        fn = getattr(provider, attr, None)
        types = getattr(fn, "_pathsel_types", None)
        if types is None:
            continue
        name = attr[len("_func_"):]
        found[name] = FunctionEntry(
            name,
            fn,
            [list(spec) for spec in types],
            bool(getattr(fn, "_pathsel_variadic", False)),
        )
    return found


BUILTIN_FUNCTIONS = collect_functions(Functions())
