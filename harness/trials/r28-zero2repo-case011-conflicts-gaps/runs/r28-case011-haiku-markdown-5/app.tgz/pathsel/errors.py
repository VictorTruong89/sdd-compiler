"""Failure kinds raised by pathsel.

Every refusal is an instance of ``ValueError``. The kind of a refusal is the
type of the raised exception:

* ``EmptyExpressionError``       - the expression text has zero length.
* ``IncompleteExpressionError``  - text ends where more input is required.
* ``SyntaxFailure``              - grammar-level syntax failure.
* ``TokenSyntaxFailure``         - token-level syntax failure (a subclass of
                                   ``SyntaxFailure``, not ``SyntaxFailure`` itself).
* ``ZeroSliceStepError``         - a slice whose step is 0.
* ``UnknownFunctionError``       - call of a name that no provider declares.
* ``InvalidArityError``          - wrong number of function arguments.
* ``InvalidTypeError``           - a function argument outside its accepted types.

Syntax and incomplete-expression failures carry ``lex_position``, the
zero-based character offset of the token where the expression went wrong.
"""


class PathSelError(ValueError):
    """Base class of every pathsel refusal."""


class EmptyExpressionError(PathSelError):
    """The expression text is zero-length."""


class _PositionedError(PathSelError):
    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class IncompleteExpressionError(_PositionedError):
    """The text ends where an operand or a closing token is still required."""


class SyntaxFailure(_PositionedError):
    """The text is not a well-formed expression (grammar-level)."""


class TokenSyntaxFailure(SyntaxFailure):
    """A syntax failure detected while splitting the text into tokens."""


class ZeroSliceStepError(PathSelError):
    """A slice was written with a step of 0."""


class UnknownFunctionError(PathSelError):
    """A function name is neither built-in nor declared by the provider."""


class InvalidArityError(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument is outside the types the function accepts."""


__all__ = [
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
