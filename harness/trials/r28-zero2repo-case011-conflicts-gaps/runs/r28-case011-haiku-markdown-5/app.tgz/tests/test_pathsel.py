"""Behavior tests for pathsel (stdlib unittest; run from the repository root)."""

import collections
import copy
import os
import sys
import types
import unittest
from decimal import Decimal

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pathsel  # noqa: E402
from pathsel import functions as pf  # noqa: E402
from pathsel.errors import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)

DOC = {
    "a": {"b": {"c": 1}},
    "people": [
        {"name": "x", "age": 31, "tags": ["p", "q"]},
        {"name": "y", "age": 20, "tags": []},
        {"name": "z", "age": 40, "tags": ["r"]},
    ],
    "n": None,
    "arr": [1, [2, 3], None, 4],
    "s": "hello",
    "key with space": 5,
    "dash-key": 6,
    "b": True,
    "zero": 0,
}


def s(expr, data=DOC, options=None):
    return pathsel.search(expr, data, options)


class SearchBasics(unittest.TestCase):
    def test_dotted_path(self):
        self.assertEqual(s("a.b.c"), 1)
        self.assertEqual(s("a.b"), {"c": 1})

    def test_missing_is_null(self):
        self.assertIsNone(s("a.missing.x"))
        self.assertIsNone(s("people.name"))  # identifier on an array
        self.assertIsNone(s("s.x"))

    def test_quoted_identifiers(self):
        self.assertEqual(s('"key with space"'), 5)
        self.assertEqual(s('"dash-key"'), 6)
        self.assertEqual(s('a."b".c'), 1)

    def test_whitespace_between_tokens(self):
        self.assertEqual(s(" a \t.\n b .c\r"), 1)

    def test_compile_matches_search(self):
        parsed = pathsel.compile("people[?age > `25`].name")
        self.assertEqual(parsed.search(DOC), s("people[?age > `25`].name"))
        self.assertEqual(parsed.search({"people": []}), [])
        self.assertIsNone(parsed.search({}))

    def test_boolean_is_not_number(self):
        self.assertEqual(s("zero == `false`"), False)
        self.assertEqual(s("b == `1`"), False)
        self.assertEqual(s("zero == `0`"), True)


class FailureKinds(unittest.TestCase):
    def assertKind(self, expr, kind, data=DOC):
        with self.assertRaises(kind) as cm:
            s(expr, data)
        self.assertIsInstance(cm.exception, ValueError)
        return cm.exception

    def test_empty(self):
        self.assertKind("", EmptyExpressionError)
        with self.assertRaises(EmptyExpressionError):
            pathsel.compile("")

    def test_incomplete(self):
        for expr in [" ", "\t\n", "a |", "a ==", "[", "foo(", "a[1", "a[?", "!", "{a: `1`",
                     "&"]:
            exc = self.assertKind(expr, IncompleteExpressionError)
            self.assertIsInstance(exc.lex_position, int)

    def test_dot_at_end_is_syntax_not_incomplete(self):
        for expr in ["a.", "a[*].", "."]:
            self.assertKind(expr, SyntaxFailure)

    def test_syntax(self):
        for expr in ["a..b", "a.1", "a.-1", "a.'x'", "a.`1`", "a)", "a b", "]", "a[1:2:3:4]",
                     "a[b:c]", "a[*]b", "a[*]*", "a[b]", "foo(a,)", "{}", "{a: `1`,}",
                     "a @ b", "a & b", "a[*]!", '"x"(1)', "[1, 2]", "1"]:
            self.assertKind(expr, SyntaxFailure)

    def test_token_level_is_subclass_of_syntax(self):
        grammar = self.assertKind("a.1", SyntaxFailure)
        token = self.assertKind("a-b", SyntaxFailure)
        self.assertIsInstance(token, TokenSyntaxFailure)
        self.assertIsNot(type(token), type(grammar))
        self.assertIsNot(type(token), SyntaxFailure)
        self.assertNotIsInstance(token, IncompleteExpressionError)
        self.assertNotIsInstance(token, EmptyExpressionError)
        for expr in ["a=b", "'unterminated", "`unterminated", '"unterminated', '"\\q"', "a # b",
                     "-", '`a"b`']:
            self.assertKind(expr, TokenSyntaxFailure)

    def test_position(self):
        exc = self.assertKind("a..b", SyntaxFailure)
        self.assertEqual(exc.lex_position, 2)
        exc = self.assertKind("a.b c", SyntaxFailure)
        self.assertEqual(exc.lex_position, 4)
        exc = self.assertKind("a |", IncompleteExpressionError)
        self.assertEqual(exc.lex_position, 3)

    def test_zero_slice_step(self):
        with self.assertRaises(ZeroSliceStepError) as cm:
            pathsel.compile("arr[::0]")
        self.assertNotIsInstance(cm.exception, SyntaxFailure)

    def test_function_kinds_are_distinct(self):
        unknown = self.assertKind("nope(a)", UnknownFunctionError)
        arity = self.assertKind("abs(a, a)", InvalidArityError)
        typ = self.assertKind("abs(s)", InvalidTypeError)
        self.assertEqual(len({type(unknown), type(arity), type(typ)}), 3)
        for exc in (unknown, arity, typ):
            self.assertNotIsInstance(exc, SyntaxFailure)

    def test_compile_of_bad_call_succeeds(self):
        parsed = pathsel.compile("nope(`1`) || abs(`1`, `2`)")
        with self.assertRaises(UnknownFunctionError):
            parsed.search(DOC)

    def test_quoted_identifier_cannot_be_function(self):
        self.assertKind('"abs"(a)', SyntaxFailure)


class Indexing(unittest.TestCase):
    def test_index(self):
        self.assertEqual(s("arr[0]"), 1)
        self.assertEqual(s("arr[-1]"), 4)
        self.assertIsNone(s("arr[99]"))
        self.assertIsNone(s("arr[-99]"))
        self.assertIsNone(s("s[0]"))
        self.assertIsNone(s("a[0]"))

    def test_slices(self):
        self.assertEqual(s("arr[0:2]"), [1, [2, 3]])
        self.assertEqual(s("arr[::-1]"), [4, [2, 3], 1])  # the null is dropped
        self.assertEqual(s("people[::2].name"), ["x", "z"])
        self.assertEqual(s("arr[10:20]"), [])
        self.assertIsNone(s("s[1:2]"))
        self.assertEqual(s("arr[-2:]"), [4])
        self.assertEqual(s("arr[-1:-3:-1]"), [4])
        self.assertEqual(s("`[1, 2, 3]`[-1:-4:-1]"), [3, 2, 1])

    def test_flatten(self):
        self.assertEqual(s("arr[]"), [1, 2, 3, 4])
        self.assertEqual(s("people[*].tags[]"), ["p", "q", "r"])
        self.assertIsNone(s("s[]"))
        # flatten is a projection: the null from n is dropped
        self.assertEqual(s("[[a.b.c, n], zero][]"), [1, 0])


class Projections(unittest.TestCase):
    def test_list_wildcard(self):
        self.assertEqual(s("people[*].name"), ["x", "y", "z"])
        self.assertEqual(s("people[*].tags"), [["p", "q"], [], ["r"]])
        self.assertEqual(s("arr[*]"), [1, [2, 3], 4])
        self.assertIsNone(s("a[*]"))

    def test_object_wildcard(self):
        self.assertEqual(s("a.*"), [{"c": 1}])
        self.assertEqual(s("a.b.*"), [1])
        self.assertIsNone(s("people.*"))

    def test_nested_projection(self):
        self.assertEqual(s("people[*].tags[*]"), [["p", "q"], [], ["r"]])

    def test_filter(self):
        self.assertEqual(s("people[?age > `25`].name"), ["x", "z"])
        self.assertEqual(s("people[?tags]"), [DOC["people"][0], DOC["people"][2]])
        self.assertEqual(s("people[?age == `20`].name"), ["y"])
        self.assertEqual(s("people[?age > `99`].name"), [])
        self.assertIsNone(s("a[?x]"))
        self.assertEqual(s("arr[?@ == `4`]"), [4])

    def test_filter_zero_is_true(self):
        self.assertEqual(s("arr[?@]"), [1, [2, 3], 4])

    def test_comparison_after_projection_compares_array(self):
        self.assertEqual(s("people[*].name == `1`"), False)
        self.assertEqual(s('people[*].name == `["x", "y", "z"]`'), True)

    def test_projection_reach(self):
        # dot and bracket steps join the right-hand side
        self.assertEqual(s("people[*].tags[0]"), ["p", "r"])
        # a comparison or pipe ends the projection: the whole array is the operand
        self.assertEqual(s("people[*].name | length(@)"), 3)

    def test_pipe_stops_projection(self):
        self.assertEqual(s("max(people[*].age)"), 40)


class Constructors(unittest.TestCase):
    def test_multiselect_list(self):
        self.assertEqual(s("[a.b.c, n, zero]"), [1, None, 0])
        self.assertEqual(s("people[*].[name, age]")[0], ["x", 31])

    def test_multiselect_list_on_null_builds_elements(self):
        self.assertEqual(s("n.[a, b]"), [None, None])

    def test_multiselect_hash(self):
        self.assertEqual(s("{x: a.b.c, y: n}"), {"x": 1, "y": None})
        self.assertEqual(s('{"key with space": a.b.c}'), {"key with space": 1})
        self.assertIsNone(s("n.{a: a}"))

    def test_pipe_and_current(self):
        self.assertEqual(s("a | b | c"), 1)
        self.assertEqual(s("people[0] | name"), "x")

    def test_literals(self):
        self.assertEqual(s("`[1, 2]`"), [1, 2])
        self.assertEqual(s("`foo`"), "foo")
        self.assertEqual(s("`  foo  `"), "foo  ")
        self.assertEqual(s('`"x"`'), "x")
        self.assertEqual(s('`{"a": 1}`.a'), 1)
        self.assertEqual(s("`1`"), 1)
        self.assertEqual(s("`true`"), True)
        self.assertIsNone(s("`null`"))
        self.assertEqual(s("''"), "")
        self.assertEqual(s("'a b'"), "a b")
        self.assertEqual(s("'123'"), "123")
        self.assertEqual(s("'it\\'s'"), "it's")
        self.assertEqual(s("'\\u0041'"), "A")
        self.assertEqual(s("'a\\nb'"), "a\\nb")

    def test_literal_after_dot_is_syntax(self):
        with self.assertRaises(SyntaxFailure):
            s('a.`"x"`')

    def test_expression_reference_bare(self):
        self.assertIsNotNone(s("&a.b"))


class Logic(unittest.TestCase):
    def test_truthiness(self):
        self.assertEqual(s("zero || `5`"), 0)
        self.assertEqual(s("n || `5`"), 5)
        self.assertEqual(s("s && `7`"), 7)
        self.assertIsNone(s("n && `7`"))
        self.assertEqual(s("!n"), True)
        self.assertEqual(s("!zero"), False)
        self.assertEqual(s("!people[0]"), False)

    def test_comparisons(self):
        self.assertEqual(s("a.b.c < `2`"), True)
        self.assertEqual(s("s < 'z'"), True)
        self.assertIsNone(s("s < `1`"))
        self.assertEqual(s("a.b.c == `1.0`"), True)
        self.assertEqual(s("a.b.c != `true`"), True)

    def test_not_binding(self):
        # a following dot step applies to the result of !
        self.assertIsNone(s("!a.b.c"))
        self.assertEqual(s("!(a.b.c == `1`)"), False)
        # brackets written directly after the operand bind to it
        self.assertEqual(s("!arr[0]"), False)

    def test_pipe_loosest(self):
        self.assertEqual(s("n || a.b.c | @"), 1)


class Functions_(unittest.TestCase):
    def test_numeric(self):
        self.assertEqual(s("abs(`-3`)"), 3)
        self.assertEqual(s("floor(`1.7`)"), 1)
        self.assertEqual(s("ceil(`1.2`)"), 2)
        self.assertEqual(s("sum(`[1, 2.5]`)"), 3.5)
        self.assertEqual(s("sum(`[]`)"), 0)
        self.assertEqual(s("avg(`[1, 2]`)"), 1.5)
        self.assertIsNone(s("avg(`[]`)"))
        self.assertEqual(s("max(`[1, 3, 2]`)"), 3)
        self.assertEqual(s('min(`["b", "a"]`)'), "a")
        self.assertIsNone(s("max(`[]`)"))
        self.assertEqual(s("sort(`[3, 1, 2]`)"), [1, 2, 3])
        self.assertEqual(s('sort(`["b", "a"]`)'), ["a", "b"])

    def test_numeric_type_checks(self):
        with self.assertRaises(InvalidTypeError):
            s("sum(`[1, true]`)")
        with self.assertRaises(InvalidTypeError):
            s("max(`[1, \"a\"]`)")
        with self.assertRaises(InvalidTypeError):
            s("abs(`true`)")
        with self.assertRaises(InvalidTypeError):
            s("abs(n)")

    def test_strings(self):
        self.assertEqual(s("contains(s, 'ell')"), True)
        self.assertEqual(s("contains(`[1, 2]`, `2`)"), True)
        self.assertEqual(s("contains(`[1, 2]`, `true`)"), False)
        self.assertEqual(s("starts_with(s, 'he')"), True)
        self.assertEqual(s("ends_with(s, 'lo')"), True)
        self.assertEqual(s("reverse(s)"), "olleh")
        self.assertEqual(s('join(`", "`, `["a", "b"]`)'), "a, b")
        self.assertEqual(s('join(`", "`, `[]`)'), "")
        self.assertEqual(s("length('héllo')"), 5)
        self.assertEqual(s("length(people)"), 3)
        self.assertEqual(s("length(a)"), 1)

    def test_length_counts_characters(self):
        self.assertEqual(s("length('€')"), 1)

    def test_type_and_conversion(self):
        self.assertEqual(s("type(s)"), "string")
        self.assertEqual(s("type(zero)"), "number")
        self.assertEqual(s("type(b)"), "boolean")
        self.assertEqual(s("type(n)"), "null")
        self.assertEqual(s("type(a)"), "object")
        self.assertEqual(s("type(arr)"), "array")
        self.assertEqual(s("to_array(s)"), ["hello"])
        self.assertEqual(s("to_array(people)"), DOC["people"])
        self.assertEqual(s("to_array(n)"), [None])
        self.assertEqual(s("to_string(`1.5`)"), "1.5")
        self.assertEqual(s('to_string(`[1,"é"]`)'), '[1,"\\u00e9"]')
        self.assertEqual(s("to_string(s)"), "hello")
        self.assertEqual(s("to_number('42')"), 42)
        self.assertEqual(s("to_number('4.5')"), 4.5)
        self.assertEqual(s("to_number('1e3')"), 1000.0)
        self.assertIsNone(s("to_number('abc')"))
        self.assertIsNone(s("to_number(`true`)"))
        self.assertIsNone(s("to_number(`[1]`)"))
        self.assertEqual(s("to_number(`2`)"), 2)

    def test_object_functions(self):
        self.assertEqual(s("keys(a)"), ["b"])
        self.assertEqual(s("values(a)"), [{"c": 1}])
        self.assertEqual(s('merge(a, `{"b": 2}`, `{"z": 3}`)'), {"b": 2, "z": 3})
        self.assertEqual(s('merge(`{"a": 1}`)'), {"a": 1})

    def test_not_null(self):
        self.assertEqual(s("not_null(n, zero, `1`)"), 0)
        self.assertEqual(s('not_null(n, `""`)'), "")
        self.assertIsNone(s("not_null(n, missing)"))

    def test_map_keeps_nulls(self):
        self.assertEqual(s("map(&name, people)"), ["x", "y", "z"])
        self.assertEqual(s("map(&@.zz, people)"), [None, None, None])
        with self.assertRaises(InvalidTypeError):
            s("map(name, people)")

    def test_sort_by_and_max_by(self):
        self.assertEqual([p["name"] for p in s("sort_by(people, &age)")], ["y", "x", "z"])
        self.assertEqual(s("max_by(people, &age).name"), "z")
        self.assertEqual(s("min_by(people, &age).name"), "y")
        self.assertIsNone(s("max_by(`[]`, &age)"))
        with self.assertRaises(InvalidTypeError):
            s("sort_by(arr, &@)")

    def test_stable_sort(self):
        data = {"l": [{"k": 1, "i": 0}, {"k": 0, "i": 1}, {"k": 1, "i": 2}]}
        self.assertEqual([x["i"] for x in s("sort_by(l, &k)", data)], [1, 0, 2])

    def test_max_by_tie_first(self):
        data = {"l": [{"k": 1, "i": 0}, {"k": 1, "i": 1}]}
        self.assertEqual(s("max_by(l, &k).i", data), 0)

    def test_function_arity_and_types(self):
        with self.assertRaises(InvalidArityError):
            s("not_null()")
        with self.assertRaises(InvalidArityError):
            s("merge()")
        with self.assertRaises(InvalidArityError):
            s("length()")
        with self.assertRaises(InvalidTypeError):
            s("keys(people)")
        with self.assertRaises(InvalidTypeError):
            s("ends_with(s, zero)")
        with self.assertRaises(InvalidTypeError):
            s("sort(people)")

    def test_builtin_names_all_present(self):
        names = {
            "abs", "avg", "ceil", "contains", "ends_with", "floor", "join", "keys", "length",
            "map", "max", "max_by", "merge", "min", "min_by", "not_null", "reverse", "sort",
            "sort_by", "starts_with", "sum", "to_array", "to_number", "to_string", "type", "values",
        }
        self.assertEqual(set(pf.BUILTIN_FUNCTIONS), names)


class Options(unittest.TestCase):
    def test_dict_cls_used_for_hashes(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
        result = s("{b: a.b.c, a: n}", DOC, opts)
        self.assertIsInstance(result, collections.OrderedDict)
        self.assertEqual(list(result.keys()), ["b", "a"])
        self.assertEqual(s("{x: a.b.c}.x", DOC, opts), 1)
        self.assertEqual(s("keys({x: a.b.c})", DOC, opts), ["x"])

    def test_custom_functions(self):
        class Provider(pf.Functions):
            @pf.signature({"types": ["number"]}, {"types": ["string", "null"]})
            def _func_repeat(self, n, text):
                return None if text is None else text * int(n)

            @pf.signature({"types": ["array"]})
            def _func_zero(self, items):
                return 0

        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        self.assertEqual(pathsel.search("repeat(`2`, 'ab')", DOC, opts), "abab")
        self.assertEqual(pathsel.search("zero(people)", DOC, opts), 0)
        self.assertEqual(pathsel.search("abs(`-1`)", DOC, opts), 1)  # built-ins still work
        with self.assertRaises(UnknownFunctionError):
            pathsel.search("repeat(`2`, 'ab')", DOC)
        with self.assertRaises(InvalidArityError):
            pathsel.search("repeat(`2`)", DOC, opts)
        with self.assertRaises(InvalidTypeError):
            pathsel.search("repeat(`2`, `1`)", DOC, opts)
        with self.assertRaises(InvalidTypeError):
            pathsel.search("repeat(`2`, a)", DOC, opts)

    def test_compile_custom_function_without_provider(self):
        parsed = pathsel.compile("zero(people)")
        with self.assertRaises(UnknownFunctionError):
            parsed.search(DOC)

    def test_custom_function_can_return_falsy(self):
        class Provider(pf.Functions):
            @pf.signature()
            def _func_nothing(self):
                return 0

        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        self.assertEqual(pathsel.search("nothing() || `9`", DOC, opts), 0)

    def test_decimal_compares_as_number(self):
        data = {"x": Decimal("2.5")}
        self.assertEqual(pathsel.search("x > `2`", data), True)
        self.assertEqual(pathsel.search("x", data), Decimal("2.5"))


class NoMutation(unittest.TestCase):
    def test_input_not_modified(self):
        before = copy.deepcopy(DOC)
        s("sort_by(people, &age)")
        s("people[*].tags[]")
        s("merge(a, a)")
        self.assertEqual(DOC, before)


class ImportSurface(unittest.TestCase):
    def test_public_names(self):
        self.assertTrue(callable(pathsel.search))
        self.assertTrue(callable(pathsel.compile))
        self.assertTrue(isinstance(pf.Functions, type))
        self.assertTrue(callable(pf.signature))


if __name__ == "__main__":
    unittest.main()
