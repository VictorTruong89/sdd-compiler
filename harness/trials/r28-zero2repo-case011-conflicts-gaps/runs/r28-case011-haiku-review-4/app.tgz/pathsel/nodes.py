"""Expression tree nodes and their evaluation.

Every node is evaluated against a current value and returns a Python value.
Nodes never mutate the document.
"""

from copy import deepcopy

from .exceptions import (
    InvalidArityError,
    InvalidTypeError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import BUILTIN_NAMES, BUILTINS, type_matches
from .values import ExpressionRef, is_array, is_number, is_object, json_equal, truthy

FLATTEN = "flatten"
LIST = "list"
OBJECT = "object"
FILTER = "filter"


class Context(object):
    """Per-search evaluation state: the constructed-mapping type and the custom provider."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    def new_mapping(self):
        if self.dict_cls is not None:
            return self.dict_cls()
        return {}

    def resolve(self, name):
        """Find the function for ``name``: built-ins first, then the attached provider."""
        attr = "_func_" + name
        if name in BUILTIN_NAMES:
            return getattr(BUILTINS, attr)
        fn = None
        if self.provider is not None:
            fn = getattr(self.provider, attr, None)
        if fn is None or not callable(fn) or not hasattr(fn, "signature"):
            raise UnknownFunctionError("unknown function %r" % name)
        return fn


def _flatten(values):
    out = []
    for item in values:
        if is_array(item):
            out.extend(item)
        else:
            out.append(item)
    return out


def _normalize_index(index, length, low, high, default):
    if index is None:
        return default
    if index < 0:
        index += length
    return max(low, min(high, index))


def slice_array(values, start, stop, step):
    """Python-style slice with the PathSel clamping rules (FP-03)."""
    length = len(values)
    if step is None:
        step = 1
    if step == 0:
        raise ZeroSliceStepError("slice step must not be 0")
    if step > 0:
        i = _normalize_index(start, length, 0, length, 0)
        end = _normalize_index(stop, length, 0, length, length)
    else:
        i = _normalize_index(start, length, -1, length - 1, length - 1)
        end = _normalize_index(stop, length, -1, length - 1, -1)
    out = []
    if step > 0:
        while i < end:
            out.append(values[i])
            i += step
    else:
        while i > end:
            out.append(values[i])
            i += step
    return out


class Node(object):
    __slots__ = ()

    def evaluate(self, value, ctx):
        raise NotImplementedError


class Identity(Node):
    __slots__ = ()

    def evaluate(self, value, ctx):
        return value


IDENTITY = Identity()


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, ctx):
        if isinstance(self.value, (list, dict)):
            return deepcopy(self.value)
        return self.value


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, ctx):
        if is_object(value):
            return value.get(self.name)
        return None


class Index(Node):
    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        length = len(value)
        if -length <= self.index < length:
            return value[self.index]
        return None


class Slice(Node):
    __slots__ = ("start", "stop", "step")

    def __init__(self, start, stop, step):
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, value, ctx):
        if not is_array(value):
            return None
        return slice_array(value, self.start, self.stop, self.step)


class Sub(Node):
    """Apply ``right`` to the value ``left`` selects (dot chains and pipes)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Projection(Node):
    """A projection: ``base`` yields the array (or object) to walk; ``rhs`` applies per element."""

    __slots__ = ("base", "rhs", "kind", "predicate")

    def __init__(self, base, rhs, kind, predicate=None):
        self.base = base
        self.rhs = rhs
        self.kind = kind
        self.predicate = predicate

    def evaluate(self, value, ctx):
        collection = self.base.evaluate(value, ctx)
        if self.kind == OBJECT:
            if not is_object(collection):
                return None
            items = list(collection.values())
        elif self.kind == FLATTEN:
            if not is_array(collection):
                return None
            items = _flatten(collection)
        else:
            if not is_array(collection):
                return None
            items = collection
            if self.kind == FILTER:
                items = [item for item in items if truthy(self.predicate.evaluate(item, ctx))]
        out = []
        for item in items:
            result = self.rhs.evaluate(item, ctx)
            if result is not None:
                out.append(result)
        return out


class Not(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def evaluate(self, value, ctx):
        return not truthy(self.child.evaluate(value, ctx))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if not truthy(left):
            return left
        return self.right.evaluate(value, ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        if truthy(left):
            return left
        return self.right.evaluate(value, ctx)


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        left = self.left.evaluate(value, ctx)
        right = self.right.evaluate(value, ctx)
        op = self.op
        if op == "==":
            return json_equal(left, right)
        if op == "!=":
            return not json_equal(left, right)
        ordered = (is_number(left) and is_number(right)) or (
            isinstance(left, str) and isinstance(right, str)
        )
        if not ordered:
            # Ordering is defined only for two numbers or two strings; otherwise null.
            return None
        if op == "<":
            return left < right
        if op == "<=":
            return left <= right
        if op == ">":
            return left > right
        return left >= right


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, ctx):
        if value is None:
            return None
        return [item.evaluate(value, ctx) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, ctx):
        if value is None:
            return None
        out = ctx.new_mapping()
        for key, node in self.pairs:
            out[key] = node.evaluate(value, ctx)
        return out


class Ref(Node):
    """An expression reference; evaluating it yields a reference object."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, ctx):
        return ExpressionRef(self.node, ctx)


class FuncCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, ctx):
        fn = ctx.resolve(self.name)
        specs = fn.signature
        varargs = getattr(fn, "varargs", False)
        count = len(self.args)
        if varargs:
            if count < len(specs):
                raise InvalidArityError("%s takes at least %d argument(s)" % (self.name, len(specs)))
        elif count != len(specs):
            raise InvalidArityError("%s takes %d argument(s), got %d" % (self.name, len(specs), count))
        values = [arg.evaluate(value, ctx) for arg in self.args]
        for index, argument in enumerate(values):
            spec = specs[min(index, len(specs) - 1)] if varargs else specs[index]
            if not type_matches(argument, spec["types"]):
                raise InvalidTypeError("argument %d of %s has an invalid type" % (index + 1, self.name))
        return fn(*values)
