"""Pratt parser for PathSel expressions.

Binding powers (loosest to tightest): pipe 1, or 2, and 3, comparators 5, flatten 9,
list wildcard / slice / object wildcard 20 (projection rank), filter 21, dot 40,
``!`` operand 45, bracket steps 55.

A projection parses its right-hand side with its own rank: the first step directly
after it always joins (dot, index, slice, list wildcard, multiselect list, filter),
and later steps join only while their binding power is tighter than the rank.
"""

from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailure,
    ZeroSliceStepError,
)
from .lexer import Token, tokenize
from .nodes import (
    FILTER,
    FLATTEN,
    IDENTITY,
    LIST,
    OBJECT,
    And,
    Compare,
    Field,
    FuncCall,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    Or,
    Projection,
    Ref,
    Slice,
    Sub,
)

BP_PIPE = 1
BP_OR = 2
BP_AND = 3
BP_CMP = 5
BP_FLATTEN = 9
BP_PROJECTION = 20
BP_FILTER = 21
BP_DOT = 40
BP_NOT = 45
BP_BRACKET = 55

_COMPARATORS = {"EQ": "==", "NE": "!=", "LT": "<", "LTE": "<=", "GT": ">", "GTE": ">="}

# Tokens that may directly follow a projection-starting form with an empty right-hand side.
_RHS_FOLLOW = frozenset(
    ["PIPE", "OR", "AND", "EQ", "NE", "LT", "LTE", "GT", "GTE",
     "COMMA", "RBRACKET", "RBRACE", "RPAREN", "EOF"]
)


class Parser(object):
    def __init__(self, text):
        self._text = text
        self._tokens = tokenize(text)
        self._pos = 0

    # -- entry point ---------------------------------------------------------

    def parse(self):
        if not self._text:
            raise EmptyExpressionError("empty expression")
        node = self._expr(0)
        tok = self._cur()
        if tok.type != "EOF":
            self._fail(tok)
        return node

    # -- token access --------------------------------------------------------

    def _peek(self, offset=0):
        index = self._pos + offset
        if index < len(self._tokens):
            return self._tokens[index]
        return Token("EOF", None, len(self._text))

    def _cur(self):
        tok = self._peek(0)
        if tok.type == "ERROR":
            raise tok.error
        return tok

    def _advance(self):
        self._pos += 1

    def _fail(self, tok):
        if tok.type == "EOF":
            raise IncompleteExpressionError(
                "expression ends where more is required", len(self._text)
            )
        raise SyntaxFailure("unexpected token %s" % tok.type, tok.pos)

    def _expect(self, kind):
        tok = self._cur()
        if tok.type != kind:
            self._fail(tok)
        self._advance()
        return tok

    # -- Pratt core ----------------------------------------------------------

    def _bp(self, tok):
        kind = tok.type
        if kind == "PIPE":
            return BP_PIPE
        if kind == "OR":
            return BP_OR
        if kind == "AND":
            return BP_AND
        if kind in _COMPARATORS:
            return BP_CMP
        if kind == "DOT":
            return BP_DOT
        if kind == "LBRACKET":
            following = self._peek(1).type
            if following == "RBRACKET":
                return BP_FLATTEN
            if following == "QMARK":
                return BP_FILTER
            return BP_BRACKET
        return 0

    def _expr(self, rbp):
        left = self._nud(self._cur())
        return self._loop(left, rbp)

    def _loop(self, left, rbp):
        while True:
            tok = self._cur()
            if self._bp(tok) <= rbp:
                return left
            left = self._led(left, tok, False)

    def _led(self, left, tok, allow_multi):
        self._advance()
        kind = tok.type
        if kind == "DOT":
            return Sub(left, self._dot_rhs())
        if kind == "LBRACKET":
            return self._bracket(left, allow_multi)
        if kind == "PIPE":
            return Sub(left, self._expr(BP_PIPE))
        if kind == "OR":
            return Or(left, self._expr(BP_OR))
        if kind == "AND":
            return And(left, self._expr(BP_AND))
        if kind in _COMPARATORS:
            return Compare(_COMPARATORS[kind], left, self._expr(BP_CMP))
        self._fail(tok)

    def _nud(self, tok):
        kind = tok.type
        if kind == "IDENT":
            self._advance()
            if self._cur().type == "LPAREN":
                return self._call(tok.value)
            return Field(tok.value)
        if kind == "QIDENT":
            self._advance()
            if self._cur().type == "LPAREN":
                self._fail(self._cur())
            return Field(tok.value)
        if kind == "AT":
            self._advance()
            return IDENTITY
        if kind == "STAR":
            self._advance()
            return self._object_projection(IDENTITY)
        if kind == "LBRACKET":
            self._advance()
            return self._bracket(IDENTITY, True)
        if kind == "LBRACE":
            self._advance()
            return self._multihash()
        if kind == "LPAREN":
            self._advance()
            node = self._expr(0)
            self._expect("RPAREN")
            return node
        if kind == "NOT":
            self._advance()
            return Not(self._expr(BP_NOT))
        if kind == "AMP":
            self._advance()
            return Ref(self._expr(0))
        if kind in ("LITERAL", "RAW"):
            self._advance()
            return Literal(tok.value)
        self._fail(tok)

    # -- compound forms ------------------------------------------------------

    def _call(self, name):
        """Parse a function call; the current token is the opening parenthesis."""
        self._advance()
        args = []
        if self._cur().type == "RPAREN":
            self._advance()
            return FuncCall(name, args)
        while True:
            args.append(self._expr(0))
            if self._cur().type == "COMMA":
                self._advance()
                continue
            self._expect("RPAREN")
            return FuncCall(name, args)

    def _object_projection(self, base):
        return Projection(base, self._rhs(BP_PROJECTION), OBJECT)

    def _bracket(self, left, allow_multi):
        """Parse bracket syntax after the opening '[' has been consumed."""
        tok = self._cur()
        kind = tok.type
        if kind == "RBRACKET":
            self._advance()
            return Projection(left, self._rhs(BP_FLATTEN), FLATTEN)
        if kind == "STAR":
            self._advance()
            self._expect("RBRACKET")
            return Projection(left, self._rhs(BP_PROJECTION), LIST)
        if kind == "QMARK":
            self._advance()
            predicate = self._expr(0)
            self._expect("RBRACKET")
            return Projection(left, self._rhs(BP_FILTER), FILTER, predicate)
        if kind == "NUMBER" and self._peek(1).type == "RBRACKET":
            self._advance()
            self._advance()
            return Sub(left, Index(tok.value))
        if kind in ("NUMBER", "COLON"):
            start, stop, step = self._slice_parts()
            if step == 0:
                raise ZeroSliceStepError("slice step must not be 0")
            self._expect("RBRACKET")
            return Projection(Sub(left, Slice(start, stop, step)), self._rhs(BP_PROJECTION), LIST)
        if allow_multi:
            return Sub(left, MultiList(self._multilist_items()))
        self._fail(tok)

    def _multilist_items(self):
        """Parse comma-separated expressions up to and including the closing ']'."""
        items = [self._expr(0)]
        while self._cur().type == "COMMA":
            self._advance()
            items.append(self._expr(0))
        self._expect("RBRACKET")
        return items

    def _slice_parts(self):
        parts = [None]
        while True:
            tok = self._cur()
            if tok.type == "NUMBER":
                parts[-1] = tok.value
                self._advance()
            elif tok.type in ("COLON", "RBRACKET"):
                pass
            else:
                self._fail(tok)
            if self._cur().type == "COLON":
                if len(parts) == 3:
                    self._fail(self._cur())
                self._advance()
                parts.append(None)
                continue
            break
        parts.extend([None] * (3 - len(parts)))
        return parts[0], parts[1], parts[2]

    def _multihash(self):
        """Parse 'key: expression' pairs; the opening '{' has been consumed."""
        pairs = []
        while True:
            tok = self._cur()
            if tok.type not in ("IDENT", "QIDENT"):
                self._fail(tok)
            self._advance()
            self._expect("COLON")
            pairs.append((tok.value, self._expr(0)))
            if self._cur().type == "COMMA":
                self._advance()
                continue
            self._expect("RBRACE")
            return MultiHash(pairs)

    def _dot_rhs(self):
        """Parse the step after a dot; the dot has been consumed."""
        tok = self._cur()
        kind = tok.type
        if kind == "IDENT":
            self._advance()
            if self._cur().type == "LPAREN":
                node = self._call(tok.value)
            else:
                node = Field(tok.value)
        elif kind == "QIDENT":
            self._advance()
            if self._cur().type == "LPAREN":
                self._fail(self._cur())
            node = Field(tok.value)
        elif kind == "STAR":
            self._advance()
            node = self._object_projection(IDENTITY)
        elif kind == "LBRACKET":
            self._advance()
            node = MultiList(self._multilist_items())
        elif kind == "LBRACE":
            self._advance()
            node = self._multihash()
        else:
            self._fail(tok)
        return self._loop(node, BP_DOT)

    def _rhs(self, rank):
        """Parse the right-hand side of a projection with the given rank (FP-04)."""
        tok = self._cur()
        kind = tok.type
        if kind == "DOT" or (kind == "LBRACKET" and self._peek(1).type != "RBRACKET"):
            first = self._led(IDENTITY, tok, True)
            return self._loop(first, rank)
        if kind == "LBRACKET" or kind in _RHS_FOLLOW:
            # A flatten '[]' directly after the form is left to the enclosing loop.
            return IDENTITY
        self._fail(tok)


def parse(text):
    """Parse ``text`` into an expression tree (raises a refusal on failure)."""
    return Parser(text).parse()
