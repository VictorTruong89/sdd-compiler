"""Built-in language functions and the provider mechanism (FP-07, FP-08).

A provider is an object whose ``_func_<name>`` attributes, decorated with
``signature``, define language functions. ``Functions`` implements the built-in set;
callers extend it by subclassing.
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import InvalidTypeError
from .values import ExpressionRef, is_array, is_number, is_object, json_equal


def signature(*arguments):
    """Declare a language function's argument types.

    Each argument is ``{"types": [<type-name>, ...]}``. Returns a decorator that
    marks the implementation (without wrapping it) so the provider can use it.
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise TypeError('signature arguments must be {"types": [...]} mappings')
        specs.append({"types": tuple(argument["types"])})

    def decorator(func):
        func.signature = specs
        return func

    return decorator


_INT_NUMERAL_RE = re.compile(r"[+-]?[0-9]+")
_FLOAT_NUMERAL_RE = re.compile(r"[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _require_numbers(values):
    if not all(is_number(v) for v in values):
        raise InvalidTypeError("array of numbers required")


def _require_numbers_or_strings(values):
    if not (all(is_number(v) for v in values) or all(isinstance(v, str) for v in values)):
        raise InvalidTypeError("array of numbers or array of strings required")


def _require_strings(values):
    if not all(isinstance(v, str) for v in values):
        raise InvalidTypeError("array of strings required")


def _total(values):
    if any(isinstance(v, float) for v in values) and any(isinstance(v, Decimal) for v in values):
        values = [float(v) if isinstance(v, Decimal) else v for v in values]
    return sum(values)


def _sort_keys(values, ref):
    """Evaluate the reference on each element; keys must all be numbers or all strings."""
    keys = [ref.evaluate(v) for v in values]
    if keys and not (all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys)):
        raise InvalidTypeError("sort keys must all be numbers or all be strings")
    return keys


def _jsonable(value):
    if is_object(value):
        return dict((str(k), _jsonable(v)) for k, v in value.items())
    if is_array(value):
        return [_jsonable(v) for v in value]
    if isinstance(value, Decimal):
        return float(value)
    return value


class Functions(object):
    """The built-in function set. Subclass and add ``_func_<name>`` methods to extend it."""

    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array"]})
    def _func_avg(self, values):
        _require_numbers(values)
        if not values:
            return None
        return _total(values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return int(math.ceil(value))

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return int(math.floor(value))

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            if not isinstance(search, str):
                raise InvalidTypeError("contains on a string requires a string argument")
            return search in subject
        return any(json_equal(item, search) for item in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, subject, suffix):
        return subject.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, subject, prefix):
        return subject.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, values):
        _require_strings(values)
        return separator.join(values)

    @signature({"types": ["object"]})
    def _func_keys(self, value):
        return list(value.keys())

    @signature({"types": ["object"]})
    def _func_values(self, value):
        return list(value.values())

    @signature({"types": ["any"]})
    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        if is_object(value):
            return "object"
        # Host values outside the six JSON types have no JSON type name; report null.
        return "null"

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if isinstance(value, list):
            return value
        if isinstance(value, tuple):
            return list(value)
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return json.dumps(_jsonable(value), separators=(",", ":"), ensure_ascii=True, default=str)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INT_NUMERAL_RE.fullmatch(value):
                return int(value)
            if _FLOAT_NUMERAL_RE.fullmatch(value):
                return float(value)
        return None

    @signature({"types": ["array"]})
    def _func_max(self, values):
        _require_numbers_or_strings(values)
        if not values:
            return None
        return max(values)

    @signature({"types": ["array"]})
    def _func_min(self, values):
        _require_numbers_or_strings(values)
        if not values:
            return None
        return min(values)

    @signature({"types": ["array"]})
    def _func_sort(self, values):
        _require_numbers_or_strings(values)
        return sorted(values)

    @signature({"types": ["array"]})
    def _func_sum(self, values):
        _require_numbers(values)
        return _total(values)

    @signature({"types": ["object"]})
    def _func_merge(self, *objects):
        result = {}
        for obj in objects:
            result.update(obj)
        return result

    _func_merge.varargs = True

    @signature({"types": ["any"]})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    _func_not_null.varargs = True

    @signature({"types": ["expression"]}, {"types": ["array"]})
    def _func_map(self, ref, values):
        return [ref.evaluate(v) for v in values]

    @signature({"types": ["array"]}, {"types": ["expression"]})
    def _func_sort_by(self, values, ref):
        keys = _sort_keys(values, ref)
        order = sorted(range(len(values)), key=lambda i: keys[i])
        return [values[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["expression"]})
    def _func_max_by(self, values, ref):
        if not values:
            return None
        keys = _sort_keys(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @signature({"types": ["array"]}, {"types": ["expression"]})
    def _func_min_by(self, values, ref):
        if not values:
            return None
        keys = _sort_keys(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


BUILTINS = Functions()

BUILTIN_NAMES = frozenset(
    name[len("_func_"):] for name in vars(Functions) if name.startswith("_func_")
)

# Type names accepted in ``signature`` declarations, and their checks.
_TYPE_CHECKS = {
    "any": lambda v: True,
    "number": is_number,
    "string": lambda v: isinstance(v, str),
    "array": is_array,
    "object": is_object,
    "null": lambda v: v is None,
    "boolean": lambda v: isinstance(v, bool),
    "expression": lambda v: isinstance(v, ExpressionRef),
}


def type_matches(value, type_names):
    """True if ``value`` satisfies at least one of the named types."""
    for name in type_names:
        check = _TYPE_CHECKS.get(name)
        if check is not None and check(value):
            return True
    return False
