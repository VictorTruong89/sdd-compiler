"""Refusal kinds for pathsel.

Every refusal is a subclass of ``PathSelError``, which is a ``ValueError``.
The kind of a refusal is carried by its exception type (FP-01, FP-07, FP-08).
"""


class PathSelError(ValueError):
    """Base class of every refusal raised by pathsel."""


class EmptyExpressionError(PathSelError):
    """The expression text has length zero (empty-expression kind)."""


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super(IncompleteExpressionError, self).__init__(message)
        self.lex_position = lex_position


class SyntaxFailure(PathSelError):
    """Grammar-level syntax failure (the plain syntax kind)."""

    def __init__(self, message, lex_position):
        super(SyntaxFailure, self).__init__(message)
        self.lex_position = lex_position


class TokenSyntaxFailure(SyntaxFailure):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0 (zero-slice-step kind)."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor provided (unknown kind)."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments (arity kind)."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types (type kind)."""
