"""Value model helpers: JSON-type predicates, truthiness, equality."""

from collections.abc import Mapping
from decimal import Decimal


def is_number(value):
    """Integers, floats and host decimals; booleans are not numbers."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    """Arrays are sequences: lists and tuples (strings are not arrays)."""
    return isinstance(value, (list, tuple))


def is_object(value):
    """Objects are mappings."""
    return isinstance(value, Mapping)


def truthy(value):
    """Truthiness: false values are false, null, empty string, empty array, empty object."""
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (str, list, tuple, Mapping)):
        return len(value) > 0
    return True


def json_equal(a, b):
    """Deep JSON equality; a number is never equal to a boolean."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and bool(a == b)
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) or is_object(b):
        if not (is_object(a) and is_object(b)) or len(a) != len(b):
            return False
        for key, val in a.items():
            if key not in b or not json_equal(val, b[key]):
                return False
        return True
    return a is b or bool(a == b)


class ExpressionRef(object):
    """A deferred subexpression (``&expr``) that functions apply later."""

    __slots__ = ("_node", "_context")

    def __init__(self, node, context):
        self._node = node
        self._context = context

    def evaluate(self, value):
        """Apply the referenced expression with ``value`` as the current value."""
        return self._node.evaluate(value, self._context)

    def __repr__(self):
        return "<ExpressionRef>"
