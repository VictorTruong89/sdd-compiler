"""Public entries: ``search`` (one shot) and ``compile`` (parse once, search many)."""

from .exceptions import EmptyExpressionError
from .nodes import Context
from .parser import Parser


class Options(object):
    """Evaluation options. Any object with ``dict_cls`` and ``custom_functions`` also works."""

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


def _context(options):
    if options is None:
        return Context()
    return Context(
        getattr(options, "dict_cls", None),
        getattr(options, "custom_functions", None),
    )


def _check_text(expression):
    if not isinstance(expression, str):
        raise TypeError("expression must be a str, not %s" % type(expression).__name__)
    if expression == "":
        raise EmptyExpressionError("empty expression")


class ParsedExpression(object):
    """A compiled expression; ``search`` it against any number of documents."""

    __slots__ = ("expression", "_root")

    def __init__(self, expression, root):
        self.expression = expression
        self._root = root

    def search(self, value, options=None):
        return self._root.evaluate(value, _context(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    """Parse ``expression`` and return a ParsedExpression (raises a refusal on failure)."""
    _check_text(expression)
    return ParsedExpression(expression, Parser(expression).parse())


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data``; missing paths yield None."""
    return compile(expression).search(data, options)
