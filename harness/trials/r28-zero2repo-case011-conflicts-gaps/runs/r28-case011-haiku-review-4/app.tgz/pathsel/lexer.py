"""Tokenizer for PathSel expressions.

Tokenization is lazy in error terms: the first token-level failure is stored as an
ERROR token at its position, and the parser raises it only when it reaches that token,
so the first failure in text order wins.
"""

import json
import re
import string

from .exceptions import TokenSyntaxFailure

_WHITESPACE = " \t\n\r"
_IDENT_START = frozenset(string.ascii_letters + "_")
_IDENT_BODY = frozenset(string.ascii_letters + string.digits + "_")
_DIGITS = frozenset(string.digits)
_NUMBER_RE = re.compile(r"-?[0-9]+")
_HEX4_RE = re.compile(r"[0-9a-fA-F]{4}")

_SINGLE = {
    ".": "DOT",
    "*": "STAR",
    "]": "RBRACKET",
    "[": "LBRACKET",
    "{": "LBRACE",
    "}": "RBRACE",
    "(": "LPAREN",
    ")": "RPAREN",
    ",": "COMMA",
    ":": "COLON",
    "@": "AT",
    "?": "QMARK",
}


class Token(object):
    __slots__ = ("type", "value", "pos", "error")

    def __init__(self, type_, value, pos, error=None):
        self.type = type_
        self.value = value
        self.pos = pos
        self.error = error

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.type, self.value, self.pos)


def _reject_constant(name):
    raise ValueError("non-JSON constant %s" % name)


def _json_loads(text):
    return json.loads(text, parse_constant=_reject_constant)


def _read_quoted(text, start):
    n = len(text)
    j = start + 1
    while j < n:
        ch = text[j]
        if ch == "\\":
            j += 2
            continue
        if ch == '"':
            break
        j += 1
    else:
        raise TokenSyntaxFailure("unterminated quoted identifier", start)
    try:
        value = _json_loads(text[start:j + 1])
    except ValueError:
        raise TokenSyntaxFailure("quoted identifier is not a legal JSON string", start)
    return Token("QIDENT", value, start), j + 1


def _read_raw(text, start):
    n = len(text)
    j = start + 1
    out = []
    while j < n:
        ch = text[j]
        if ch == "'":
            return Token("RAW", "".join(out), start), j + 1
        if ch == "\\" and j + 1 < n:
            nxt = text[j + 1]
            if nxt == "'":
                out.append("'")
                j += 2
                continue
            if nxt == "u" and _HEX4_RE.match(text, j + 2):
                code = int(text[j + 2:j + 6], 16)
                j += 6
                if 0xD800 <= code <= 0xDBFF and text[j:j + 2] == "\\u" and _HEX4_RE.match(text, j + 2):
                    low = int(text[j + 2:j + 6], 16)
                    if 0xDC00 <= low <= 0xDFFF:
                        code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        j += 6
                out.append(chr(code))
                continue
        out.append(ch)
        j += 1
    raise TokenSyntaxFailure("unclosed raw string literal", start)


def _read_literal(text, start):
    n = len(text)
    j = start + 1
    while j < n:
        ch = text[j]
        if ch == "\\" and j + 1 < n and text[j + 1] == "`":
            j += 2
            continue
        if ch == "`":
            break
        j += 1
    else:
        raise TokenSyntaxFailure("unclosed JSON literal", start)
    raw = text[start + 1:j].replace("\\`", "`")
    try:
        value = _json_loads(raw)
    except ValueError:
        # Not JSON: read as the content of a JSON string after removing leading whitespace.
        try:
            value = _json_loads('"' + raw.lstrip(_WHITESPACE) + '"')
        except ValueError:
            raise TokenSyntaxFailure("JSON literal is neither JSON nor JSON string content", start)
    return Token("LITERAL", value, start), j + 1


def _scan(text, i):
    """Scan one token starting at ``i`` (not whitespace). Returns (token, next_index)."""
    ch = text[i]
    n = len(text)
    if ch in _IDENT_START:
        j = i + 1
        while j < n and text[j] in _IDENT_BODY:
            j += 1
        return Token("IDENT", text[i:j], i), j
    if ch == '"':
        return _read_quoted(text, i)
    if ch == "'":
        return _read_raw(text, i)
    if ch == "`":
        return _read_literal(text, i)
    if ch in _DIGITS or ch == "-":
        match = _NUMBER_RE.match(text, i)
        if match is None:
            raise TokenSyntaxFailure("a hyphen that begins no number begins no token", i)
        return Token("NUMBER", int(match.group(0)), i), match.end()
    if ch == "=":
        if text.startswith("==", i):
            return Token("EQ", "==", i), i + 2
        raise TokenSyntaxFailure("a lone '=' begins no token (equality is '==')", i)
    if ch == "!":
        if text.startswith("!=", i):
            return Token("NE", "!=", i), i + 2
        return Token("NOT", "!", i), i + 1
    if ch == "<":
        if text.startswith("<=", i):
            return Token("LTE", "<=", i), i + 2
        return Token("LT", "<", i), i + 1
    if ch == ">":
        if text.startswith(">=", i):
            return Token("GTE", ">=", i), i + 2
        return Token("GT", ">", i), i + 1
    if ch == "&":
        if text.startswith("&&", i):
            return Token("AND", "&&", i), i + 2
        return Token("AMP", "&", i), i + 1
    if ch == "|":
        if text.startswith("||", i):
            return Token("OR", "||", i), i + 2
        return Token("PIPE", "|", i), i + 1
    if ch in _SINGLE:
        return Token(_SINGLE[ch], ch, i), i + 1
    raise TokenSyntaxFailure("character %r begins no token" % ch, i)


def tokenize(text):
    """Split ``text`` into tokens. The list ends with EOF, or with a single ERROR token."""
    tokens = []
    n = len(text)
    i = 0
    while True:
        while i < n and text[i] in _WHITESPACE:
            i += 1
        if i >= n:
            tokens.append(Token("EOF", None, n))
            return tokens
        try:
            token, i = _scan(text, i)
        except TokenSyntaxFailure as exc:
            tokens.append(Token("ERROR", None, exc.lex_position, exc))
            return tokens
        tokens.append(token)
