"""pathsel: evaluate PathSel expressions against Python data.

Public entries: ``search`` and ``compile``. See ``pathsel.functions`` for the
built-in function provider and the ``signature`` decorator used to add functions.
"""

from .api import Options, ParsedExpression, compile, search
from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)

__all__ = [
    "search",
    "compile",
    "Options",
    "ParsedExpression",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
