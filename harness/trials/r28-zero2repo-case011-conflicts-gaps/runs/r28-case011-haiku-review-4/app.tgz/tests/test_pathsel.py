"""Behavioural tests for pathsel, written from the specification in spec/."""

import sys
import os
from collections import OrderedDict
from types import SimpleNamespace

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pathsel  # noqa: E402
from pathsel import compile, search, Options  # noqa: E402
from pathsel.exceptions import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature  # noqa: E402

DOC = {
    "foo": {"bar": "baz", "qux": {"deep": 1}},
    "people": [
        {"name": "a", "age": 30, "tags": ["x", "y"]},
        {"name": "b", "age": 10, "tags": []},
        {"name": "c"},
    ],
    "nested": [[1, 2], [3], 4, [[5]]],
    "s": "héllo",
    "nums": [3, 1, 2],
    "obj": {"k1": {"v": 1}, "k2": {"v": 2}, "k3": 5},
    "zero": 0,
    "f": False,
    "empty": "",
}


def s(expr, data=DOC, options=None):
    return search(expr, data, options)


# -- FP-01 entries and missing-is-null ------------------------------------

def test_dotted_path_returns_nested_value():
    assert s("foo.bar") == "baz"
    assert s("foo.qux") == {"deep": 1}


def test_missing_path_is_null_at_any_depth():
    assert s("nope") is None
    assert s("foo.nope.deeper") is None


def test_identifier_on_array_is_null():
    assert s("people.name") is None


def test_compile_and_search_agree_and_compile_reusable():
    expr = compile("people[*].name")
    assert expr.search(DOC) == s("people[*].name")
    assert expr.search({"people": [{"name": "z"}]}) == ["z"]


def test_empty_expression_refusal():
    with pytest.raises(EmptyExpressionError):
        search("", DOC)
    with pytest.raises(EmptyExpressionError):
        compile("")


def test_whitespace_only_is_incomplete_not_empty():
    with pytest.raises(IncompleteExpressionError) as info:
        search("  \t\n", DOC)
    assert info.value.lex_position == 4


def test_refusals_are_value_errors():
    assert issubclass(EmptyExpressionError, ValueError)
    assert issubclass(SyntaxFailure, ValueError)
    assert issubclass(TokenSyntaxFailure, SyntaxFailure)
    assert not issubclass(TokenSyntaxFailure, EmptyExpressionError)
    assert not issubclass(TokenSyntaxFailure, IncompleteExpressionError)


@pytest.mark.parametrize(
    "expr, kind, position",
    [
        ("foo.", IncompleteExpressionError, 4),
        ("(a", IncompleteExpressionError, 2),
        ("foo[0", IncompleteExpressionError, 5),
        (".foo", SyntaxFailure, 0),
        ("foo..bar", SyntaxFailure, 4),
        ("foo.1", SyntaxFailure, 4),
        ("foo bar", SyntaxFailure, 4),
        ("a)", SyntaxFailure, 1),
        ("foo[1:2:3:4]", SyntaxFailure, 9),
        ("a-b", TokenSyntaxFailure, 1),
        ("foo=", TokenSyntaxFailure, 3),
        ('"abc', TokenSyntaxFailure, 0),
        ("`abc", TokenSyntaxFailure, 0),
        ("'abc", TokenSyntaxFailure, 0),
        ("foo#", TokenSyntaxFailure, 3),
    ],
)
def test_syntax_kinds_and_positions(expr, kind, position):
    with pytest.raises(kind) as info:
        search(expr, DOC)
    assert info.value.lex_position == position


def test_token_error_is_not_grammar_error_kind():
    # A token-level failure is a SyntaxFailure subclass, but not the plain kind.
    with pytest.raises(TokenSyntaxFailure) as info:
        compile("a-b")
    assert type(info.value) is not SyntaxFailure


# -- FP-02 identifiers -------------------------------------------------------

def test_quoted_identifier_names_any_key():
    data = {"a b": 1, "x.y": {"z": 2}, "1": 3, 'q"t': 4, "é": 5}
    assert s('"a b"', data) == 1
    assert s('"x.y".z', data) == 2  # the key "x.y", then field z
    assert s('x.y', data) is None  # unquoted x.y walks two levels: no "x" key here
    assert s('"x.y"', data) == {"z": 2}
    assert s('"1"', data) == 3
    assert s('"q\\"t"', data) == 4
    assert s('"\\u00e9"', data) == 5


def test_number_after_dot_and_hyphen_are_syntax():
    with pytest.raises(SyntaxFailure):
        compile("a.-1")


# -- FP-03 indices, slices, flatten -----------------------------------------

def test_index_and_negative_index():
    assert s("people[0].name") == "a"
    assert s("people[-1].name") == "c"
    assert s("people[9].name") is None
    assert s("nums[-9]") is None


def test_indexing_non_array_is_null():
    assert s("foo[0]") is None
    assert s("s[0]") is None


def test_slices_with_clamping_and_steps():
    assert s("nums[0:2]") == [3, 1]
    assert s("nums[::-1]") == [2, 1, 3]
    assert s("nums[-2:]") == [1, 2]
    assert s("nums[5:9]") == []
    assert s("nums[::2]") == [3, 2]
    assert s("nums[-1::-1]") == [2, 1, 3]


def test_slice_of_non_array_is_null_by_normal_rule():
    assert s("foo[0:1]") is None


def test_zero_slice_step_refuses_on_both_paths():
    with pytest.raises(ZeroSliceStepError):
        search("nums[::0]", DOC)
    with pytest.raises(ZeroSliceStepError):
        compile("nums[::0]")


def test_flatten_one_level():
    assert s("nested[]") == [1, 2, 3, 4, [5]]
    assert s("nested[][]") == [1, 2, 3, 4, 5]
    assert s("foo[]") is None


# -- FP-04 projections -------------------------------------------------------

def test_list_wildcard_drops_nulls():
    assert s("people[*].name") == ["a", "b", "c"]
    assert s("people[*].age") == [30, 10]
    assert s("people[*]") == DOC["people"]
    assert s("foo[*].bar") is None


def test_object_wildcard_projects_values():
    assert s("obj.*.v") == [1, 2]
    assert s("foo.*") == ["baz", {"deep": 1}]
    assert s("nums.*") is None


def test_filter_truthiness_and_comparisons():
    assert s("people[?age > `20`].name") == ["a"]
    assert s("people[?age].name") == ["a", "b"]
    assert s("people[?tags].name") == ["a"]  # empty array is false
    assert s("people[?!age].name") == ["c"]
    assert s("zero[?@]") is None
    assert s("nums[?@ == `1`]") == [1]


def test_filter_on_non_array_is_null():
    assert s("foo[?bar]") is None


def test_zero_is_truthy_in_predicate():
    data = {"items": [{"n": 0}, {"n": 1}, {"n": None}]}
    assert s("items[?n].n", data) == [0, 1]


def test_projection_rhs_reach_dot_then_index():
    assert s("people[*].tags[0]") == ["x"]


def test_nested_projection_drops_inner_null():
    assert s("people[*].tags[*]") == [["x", "y"], []]


def test_comparison_after_wildcard_compares_whole_array():
    assert s('people[*].name == `["a","b","c"]`') is True
    assert s('people[*].name == `["a"]`') is False


def test_projection_followed_by_identifier_is_syntax():
    with pytest.raises(SyntaxFailure):
        compile("people[*]name")


def test_wildcard_followed_by_star_is_syntax():
    with pytest.raises(SyntaxFailure):
        compile("people[*]*")


def test_star_wildcard_then_dot_chain():
    assert s("foo.*.bar") == []  # foo.* yields ['baz', {...}]; neither has .bar
    assert s("obj.*.v") == [1, 2]


# -- FP-05 constructors, pipe, current value, literals ----------------------

def test_multiselect_list_and_hash():
    assert s("[foo.bar, s]") == ["baz", "héllo"]
    assert s("foo.{b: bar, missing: nope}") == {"b": "baz", "missing": None}
    assert s("people[*].{n: name}") == [{"n": "a"}, {"n": "b"}, {"n": "c"}]
    assert s("people[*].{n: age}") == [{"n": 30}, {"n": 10}, {"n": None}]


def test_multiselect_on_null_current_value_is_null():
    assert s("nope.[a, b]") is None
    assert s("nope.{a: b}") is None


def test_pipe_sees_whole_result_and_binds_loosest():
    assert s("people[*].name | length(@)") == 3
    assert s("foo | bar") == "baz"  # bar is a field of the piped foo object
    assert s("foo | nope") is None
    assert s("foo.bar | length(@) == `3`") is True


def test_current_value_token():
    assert s("nums[?@ > `1`]") == [3, 2]
    assert s("@.foo.bar") == "baz"


def test_json_literal_and_raw_string():
    assert s("`{\"a\": 1}`.a") == 1
    assert s("`abc`") == "abc"  # not JSON -> JSON string content
    assert s("`1.5`") == 1.5
    assert s("'12'") == "12"
    assert s("'it\\'s'") == "it's"
    assert s("'a\\nb'") == "a\\nb"  # no JSON escapes in raw strings
    assert s("'\\u00e9'") == "é"


def test_literal_after_dot_is_syntax():
    with pytest.raises(SyntaxFailure):
        compile("foo.`1`")


def test_expression_reference_is_non_null_on_its_own():
    assert s("&foo") is not None


def test_multiselect_missing_closer_does_not_succeed():
    with pytest.raises((IncompleteExpressionError, SyntaxFailure)):
        compile("[a, b")
    with pytest.raises((IncompleteExpressionError, SyntaxFailure)):
        compile("{a: b")
    with pytest.raises(SyntaxFailure):
        compile("[a, b,]")


# -- FP-06 comparisons and logic --------------------------------------------

def test_equality_is_json_equality():
    assert s("zero == `false`") is False
    assert s("f == `false`") is True
    assert s("zero == `0.0`") is True
    assert s("people[0] == `{\"name\": \"a\"}`") is False
    assert s("foo == `{\"bar\": \"baz\", \"qux\": {\"deep\": 1}}`") is True


def test_ordering_on_numbers_and_strings():
    assert s("nums[0] > nums[1]") is True
    assert s("s < 'z'") is True
    assert s("s < `1`") is None


def test_or_and_return_operands():
    assert s("nope || foo.bar") == "baz"
    assert s("foo.bar && nope") is None
    assert s("empty || `0`") == 0
    assert s("zero && foo") == {"bar": "baz", "qux": {"deep": 1}}


def test_not_binding_and_parentheses():
    assert s("!zero") is False
    assert s("!nope") is True
    assert s("!foo.bar") is None  # (!foo).bar: dot applies to the boolean result
    assert s("!(foo.bar)") is False


def test_lone_equals_and_lone_ampersand_refused():
    with pytest.raises(TokenSyntaxFailure):
        compile("a = b")
    with pytest.raises(SyntaxFailure):
        compile("a & b")


# -- FP-07 built-ins ---------------------------------------------------------

@pytest.mark.parametrize(
    "expr, expected",
    [
        ("abs(`-3`)", 3),
        ("avg(`[1, 2, 3]`)", 2.0),
        ("avg(`[]`)", None),
        ("ceil(`1.2`)", 2),
        ("floor(`1.8`)", 1),
        ("contains(`[1, 2]`, `2`)", True),
        ("contains(`[1, 2]`, `true`)", False),
        ("contains('hello', 'ell')", True),
        ("ends_with('hello', 'lo')", True),
        ("starts_with('hello', 'he')", True),
        ("length('héllo')", 5),
        ("length(`[1, 2]`)", 2),
        ("length(foo)", 2),
        ("reverse('abc')", "cba"),
        ("reverse(`[1, 2]`)", [2, 1]),
        ("join(', ', `[\"a\", \"b\"]`)", "a, b"),
        ("join('-', `[]`)", ""),
        ("keys(foo)", ["bar", "qux"]),
        ("type(`1`)", "number"),
        ("type(`true`)", "boolean"),
        ("type(zero)", "number"),
        ("type(nope)", "null"),
        ("type(`[]`)", "array"),
        ("type(foo)", "object"),
        ("to_array(`1`)", [1]),
        ("to_array(`[1]`)", [1]),
        ("to_string(`1`)", "1"),
        ("to_string(`\"a\"`)", "a"),
        ("to_string(`{\"a\": [1, 2]}`)", '{"a":[1,2]}'),
        ("to_number('5')", 5),
        ("to_number('5.5')", 5.5),
        ("to_number('1e3')", 1000.0),
        ("to_number('abc')", None),
        ("to_number(`true`)", None),
        ("max(`[1, 3, 2]`)", 3),
        ('min(`["b", "a"]`)', "a"),
        ("max(`[]`)", None),
        ("sort(`[3, 1, 2]`)", [1, 2, 3]),
        ("sum(`[1, 2, 3]`)", 6),
        ("sum(`[]`)", 0),
        ("merge(foo, `{\"z\": 1}`)", {"bar": "baz", "qux": {"deep": 1}, "z": 1}),
        ("not_null(nope, `0`, `1`)", 0),
        ("not_null(nope)", None),
        ("not_null('', nope)", ""),
        ("map(&name, people)", ["a", "b", "c"]),
        ("map(&age, people)", [30, 10, None]),
        ("sort_by(people[?age], &age)[*].name", ["b", "a"]),
        ("max_by(people[?age], &age).name", "a"),
        ("min_by(people[?age], &age).name", "b"),
        ("max_by(`[]`, &age)", None),
        ("values(obj.k1)", [1]),
    ],
)
def test_builtin_results(expr, expected):
    assert s(expr) == expected


def test_sort_by_is_stable():
    data = {"items": [{"k": 1, "i": "a"}, {"k": 0, "i": "b"}, {"k": 1, "i": "c"}]}
    assert s("sort_by(items, &k)[*].i", data) == ["b", "a", "c"]


def test_function_as_projection_right_hand_side():
    assert s("people[*].name.length(@)") == [1, 1, 1]


@pytest.mark.parametrize(
    "expr, kind",
    [
        ("length()", InvalidArityError),
        ("abs(`1`, `2`)", InvalidArityError),
        ("length(s, s)", InvalidArityError),
        ("not_null()", InvalidArityError),
        ("merge()", InvalidArityError),
        ("bogus(`1`)", UnknownFunctionError),
        ("abs(`true`)", InvalidTypeError),
        ("abs(nope)", InvalidTypeError),
        ('sum(`[1, "a"]`)', InvalidTypeError),
        ('max(`[1, "a"]`)', InvalidTypeError),
        ("join(',', `[1]`)", InvalidTypeError),
        ("contains(nope, `1`)", InvalidTypeError),
        ("contains('abc', `1`)", InvalidTypeError),
        ("keys(`[1]`)", InvalidTypeError),
        ("map(people, people)", InvalidTypeError),
        ("sort_by(people, &age)", InvalidTypeError),
        ('max_by(`[1, "a"]`, &@)', InvalidTypeError),
        ("merge(foo, `1`)", InvalidTypeError),
        ("abs(`1`)", None),
    ],
)
def test_function_refusals_at_search_not_compile(expr, kind):
    compile(expr)  # compiling succeeds
    if kind is None:
        return
    with pytest.raises(kind) as info:
        search(expr, DOC)
    assert isinstance(info.value, ValueError)


def test_quoted_identifier_cannot_be_function():
    with pytest.raises(SyntaxFailure):
        compile('"abs"(`1`)')


def test_unknown_function_is_not_arity_or_type():
    with pytest.raises(UnknownFunctionError) as info:
        search("bogus()", DOC)
    assert not isinstance(info.value, (InvalidArityError, InvalidTypeError))


# -- FP-08 options and custom functions -------------------------------------

def test_dict_cls_used_for_constructed_hash():
    opts = Options(dict_cls=OrderedDict)
    out = s("foo.{a: bar}", options=opts)
    assert isinstance(out, OrderedDict)
    assert out == {"a": "baz"}


def test_ordered_dict_hash_accepted_where_object_required():
    opts = Options(dict_cls=OrderedDict)
    assert s("keys(foo.{a: bar, b: bar})", options=opts) == ["a", "b"]


def test_custom_functions_provider():
    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["number"]})
        def _func_add(self, a, b):
            return a + b

        @signature({"types": ["string"]})
        def _func_shout(self, text):
            return text.upper()

    opts = Options(custom_functions=Provider())
    assert s("add(`2`, `3`)", options=opts) == 5
    assert s("shout('hi')", options=opts) == "HI"
    assert s("abs(`-2`)", options=opts) == 2  # built-ins still available
    assert compile("add(`1`, `2`)").search(DOC, opts) == 3


def test_custom_function_zero_and_empty_returns_are_values():
    class Provider(Functions):
        @signature()
        def _func_zero(self):
            return 0

        @signature()
        def _func_none_list(self):
            return []

    opts = Options(custom_functions=Provider())
    assert s("zero()", options=opts) == 0
    assert s("none_list()", options=opts) == []


def test_custom_function_without_provider_is_unknown_at_search():
    expr = compile("add(`1`, `2`)")
    with pytest.raises(UnknownFunctionError):
        expr.search(DOC)


def test_custom_function_wrong_arity_and_type():
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_half(self, n):
            return n / 2

    opts = Options(custom_functions=Provider())
    with pytest.raises(InvalidArityError):
        s("half()", options=opts)
    with pytest.raises(InvalidTypeError):
        s("half('x')", options=opts)
    with pytest.raises(InvalidTypeError):
        s("half(`true`)", options=opts)


def test_provider_on_other_provider_name_is_unknown():
    class A(Functions):
        @signature()
        def _func_only_a(self):
            return 1

    class B(Functions):
        pass

    with pytest.raises(UnknownFunctionError):
        s("only_a()", options=Options(custom_functions=B()))


def test_duck_typed_options_object():
    opts = SimpleNamespace(dict_cls=None, custom_functions=None)
    assert s("foo.bar", options=opts) == "baz"


def test_search_does_not_mutate_document():
    import copy

    doc = copy.deepcopy(DOC)
    s("people[*].name", doc)
    s("people[?age].name | sort(@)", doc)
    assert doc == DOC
