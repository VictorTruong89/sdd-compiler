"""Built-in language functions and the custom-function provider.

A provider is an instance of ``Functions`` (or a subclass). Each attribute named
``_func_<name>`` that was decorated with ``signature`` defines the language
function ``<name>``. Built-in names are reserved: a provider cannot replace them,
so every FP-07 function keeps its behavior (FP-08).

# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268
# spec: N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275
# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000281 N-000282
# spec: N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289
# spec: N-000290 N-000291 N-000292 N-000293 N-000294 N-000295 N-000296
# spec: N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303
# spec: N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000310
# spec: N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
# spec: N-000318 N-000319 N-000320 N-000321 N-000322 N-000335 N-000336
# spec: N-000337 N-000338 N-000339 N-000340 N-000393 N-000394 N-000395
# spec: N-000396 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402
# spec: N-000403 N-000404
"""

import decimal
import functools
import json
import math

from ._values import (
    is_array,
    is_number,
    is_object,
    json_equal,
    parse_float_numeral,
    parse_integer_numeral,
)
from .errors import InvalidTypeError

_ALLOWED_TYPES = frozenset(["number", "string", "array", "object", "null", "any", "reference"])


def signature(*arguments, variadic=False):
    """Declare a custom function's argument types.

    Each positional argument is ``{"types": [<type-name>, ...]}``; the
    decorated implementation ``(provider, *args) -> value`` is wrapped without
    being called. ``variadic=True`` (used by built-ins such as ``merge``) means
    one or more arguments, each checked against the last declared spec.
    """
    specs = []
    for arg in arguments:
        types = tuple(arg["types"])
        for name in types:
            if name not in _ALLOWED_TYPES:
                raise TypeError("unknown argument type name: %r" % (name,))
        specs.append(types)
    declared = (tuple(specs), bool(variadic))

    def decorate(impl):
        @functools.wraps(impl)
        def method(self, *args):
            return impl(self, *args)

        method.__pathsel_signature__ = declared
        return method

    return decorate


def _compact_json(v):
    """Compact JSON text: no spaces, non-ASCII as \\u escapes, host number spelling."""
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, int):
        return str(int(v))
    if isinstance(v, float):
        return json.dumps(v)
    if isinstance(v, decimal.Decimal):
        return str(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=True)
    if is_array(v):
        return "[" + ",".join(_compact_json(x) for x in v) + "]"
    if is_object(v):
        parts = [json.dumps(str(k), ensure_ascii=True) + ":" + _compact_json(x) for k, x in v.items()]
        return "{" + ",".join(parts) + "}"
    return json.dumps(str(v), ensure_ascii=True)


def _type_name(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if is_number(v):
        return "number"
    if isinstance(v, str):
        return "string"
    if is_array(v):
        return "array"
    if is_object(v):
        return "object"
    return None


def _finite_or_refuse(number, name):
    """ceil/floor have no integer result for infinities or NaN (host floats only)."""
    if isinstance(number, float) and not math.isfinite(number):
        raise InvalidTypeError("%s takes a finite number" % name)


def _same_kind_keys(values):
    """Return 'number' or 'string' when all values share one such kind; else refuse.

    An empty sequence passes and returns None.
    """
    if not values:
        return None
    if all(is_number(v) for v in values):
        return "number"
    if all(isinstance(v, str) for v in values):
        return "string"
    raise InvalidTypeError("elements must all be numbers or all be strings")


class Functions:
    """The provider of the built-in functions. Subclass it to add custom functions."""

    @signature({"types": ["number"]})
    def _func_abs(self, number):
        return abs(number)

    @signature({"types": ["array"]})
    def _func_avg(self, numbers):
        if not numbers:
            return None
        if not all(is_number(x) for x in numbers):
            raise InvalidTypeError("avg takes an array of numbers")
        return sum(numbers) / len(numbers)

    @signature({"types": ["number"]})
    def _func_ceil(self, number):
        _finite_or_refuse(number, "ceil")
        return int(math.ceil(number))

    @signature({"types": ["number"]})
    def _func_floor(self, number):
        _finite_or_refuse(number, "floor")
        return int(math.floor(number))

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, haystack, needle):
        if is_array(haystack):
            return any(json_equal(x, needle) for x in haystack)
        if not isinstance(needle, str):
            raise InvalidTypeError("contains on a string takes a string")
        return needle in haystack

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, strings):
        if not all(isinstance(x, str) for x in strings):
            raise InvalidTypeError("join takes an array of strings")
        if not strings:
            return ""
        return separator.join(strings)

    @signature({"types": ["object"]})
    def _func_keys(self, obj):
        return list(obj.keys())

    @signature({"types": ["object"]})
    def _func_values(self, obj):
        return list(obj.values())

    @signature({"types": ["any"]})
    def _func_type(self, value):
        return _type_name(value)

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if is_array(value):
            return list(value)
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return _compact_json(value)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            as_int = parse_integer_numeral(value)
            if as_int is not None:
                return as_int
            return parse_float_numeral(value)
        return None

    @signature({"types": ["array"]})
    def _func_max(self, values):
        if not values:
            return None
        _same_kind_keys(values)
        return max(values)

    @signature({"types": ["array"]})
    def _func_min(self, values):
        if not values:
            return None
        _same_kind_keys(values)
        return min(values)

    @signature({"types": ["array"]})
    def _func_sort(self, values):
        _same_kind_keys(values)
        return sorted(values)

    @signature({"types": ["array"]})
    def _func_sum(self, numbers):
        if not all(is_number(x) for x in numbers):
            raise InvalidTypeError("sum takes an array of numbers")
        return sum(numbers)

    @signature({"types": ["object"]}, variadic=True)
    def _func_merge(self, *objects):
        result = {}
        for obj in objects:
            for key in obj:
                result[key] = obj[key]
        return result

    @signature({"types": ["any"]}, variadic=True)
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature({"types": ["reference"]}, {"types": ["array"]})
    def _func_map(self, ref, values):
        return [ref.apply(x) for x in values]

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_sort_by(self, values, ref):
        if not values:
            return []
        keys = [ref.apply(x) for x in values]
        _same_kind_keys(keys)
        order = sorted(range(len(values)), key=lambda i: keys[i])
        return [values[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_max_by(self, values, ref):
        return self._extreme_by(values, ref, greater=True)

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_min_by(self, values, ref):
        return self._extreme_by(values, ref, greater=False)

    @staticmethod
    def _extreme_by(values, ref, greater):
        if not values:
            return None
        keys = [ref.apply(x) for x in values]
        _same_kind_keys(keys)
        best = 0
        for i in range(1, len(values)):
            if (keys[i] > keys[best]) if greater else (keys[i] < keys[best]):
                best = i
        return values[best]


BUILTIN_NAMES = frozenset(
    name[len("_func_"):] for name in dir(Functions) if name.startswith("_func_")
)

_BUILTIN_PROVIDER = Functions()


def _entry_for(bound):
    specs, variadic = bound.__pathsel_signature__
    return (specs, variadic, bound)


def builtin_registry():
    """Name -> (specs, variadic, bound method) for the built-in set."""
    registry = {}
    for name in BUILTIN_NAMES:
        bound = getattr(_BUILTIN_PROVIDER, "_func_" + name)
        registry[name] = _entry_for(bound)
    return registry


_BUILTIN_REGISTRY = builtin_registry()


def registry_for(provider):
    """Full name table for an evaluation: built-ins plus the provider's own functions."""
    if provider is None:
        return _BUILTIN_REGISTRY
    registry = dict(_BUILTIN_REGISTRY)
    for attr in dir(provider):
        if not attr.startswith("_func_"):
            continue
        name = attr[len("_func_"):]
        if name in BUILTIN_NAMES:
            continue
        bound = getattr(provider, attr, None)
        if bound is None or not hasattr(bound, "__pathsel_signature__"):
            continue
        registry[name] = _entry_for(bound)
    return registry
