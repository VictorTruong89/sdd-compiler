"""Expression tree and evaluation.

Every node evaluates against a current value ``value`` and a context ``ctx``
(see ``core.Context``). Nodes that start a projection use ``Identity`` as their
source; a led (chained) step is wrapped in ``Subexpr``.

# spec: N-000083 N-000084 N-000085 N-000086 N-000125 N-000129 N-000130
# spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137
# spec: N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000144
# spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151
# spec: N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164
# spec: N-000165 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171
# spec: N-000172 N-000173 N-000174 N-000175 N-000176 N-000177 N-000178
# spec: N-000179 N-000180 N-000181 N-000182 N-000204 N-000205
# spec: N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212
# spec: N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000219
# spec: N-000220 N-000221 N-000222 N-000223 N-000225 N-000227 N-000228
# spec: N-000235 N-000236 N-000243 N-000247 N-000248 N-000249 N-000250
# spec: N-000253 N-000254 N-000255 N-000256 N-000257 N-000258 N-000259
# spec: N-000262 N-000264 N-000265 N-000266 N-000267 N-000268 N-000343
# spec: N-000344 N-000345 N-000346 N-000347 N-000348 N-000349 N-000350
"""

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from ._values import ExprRef, is_array, is_number, is_object, json_equal, ordered, truthy


class Node:
    __slots__ = ()

    def eval(self, value, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Identity(Node):
    """The current value (``@``, and the source of projection-starting forms)."""

    __slots__ = ()

    def eval(self, value, ctx):
        return value


IDENTITY = Identity()


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, value, ctx):
        return self.value


class Field(Node):
    """Select a field of an object; anything else yields null. # spec: N-000115 N-000116"""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, value, ctx):
        if is_object(value):
            return value.get(self.name)
        return None


class Subexpr(Node):
    """Evaluate ``right`` against the result of ``left`` (dot, pipe, chained steps)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        return self.right.eval(self.left.eval(value, ctx), ctx)


class Index(Node):
    """Zero-based index with negative counting from the end. # spec: N-000126 N-000127 N-000128"""

    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def eval(self, value, ctx):
        if not is_array(value):
            return None
        n = len(value)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return value[i]
        return None


def slice_indices(length, start, stop, step):
    """Indices selected by a slice over an array of ``length`` elements.

    # spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137
    # spec: N-000138 N-000139 N-000140 N-000141
    """
    if step is None:
        step = 1
    if step > 0:
        lo, hi = 0, length
        if start is None:
            s = 0
        else:
            s = start + length if start < 0 else start
            s = min(max(s, lo), hi)
        if stop is None:
            e = length
        else:
            e = stop + length if stop < 0 else stop
            e = min(max(e, lo), hi)
    else:
        lo, hi = -1, length - 1
        if start is None:
            s = length - 1
        else:
            s = start + length if start < 0 else start
            s = min(max(s, lo), hi)
        if stop is None:
            e = -1
        else:
            e = stop + length if stop < 0 else stop
            e = min(max(e, lo), hi)
    return list(range(s, e, step))


def flatten_one_level(items):
    out = []
    for item in items:
        if is_array(item):
            out.extend(item)
        else:
            out.append(item)
    return out


class Projection(Node):
    """A projection-starting form and its right-hand side.

    kind: 'list' ([*]), 'obj' (*), 'filter' ([?...]), 'flatten' ([]), 'slice'.
    The source is the current value. Null results of the right-hand side are
    dropped.  # spec: N-000143 N-000144 N-000148 N-000149 N-000150 N-000159-N-000173
    """

    __slots__ = ("kind", "rhs", "pred", "start", "stop", "step")

    def __init__(self, kind, rhs, pred=None, start=None, stop=None, step=None):
        self.kind = kind
        self.rhs = rhs
        self.pred = pred
        self.start = start
        self.stop = stop
        self.step = step

    def eval(self, value, ctx):
        kind = self.kind
        if kind == "obj":
            if not is_object(value):
                return None
            items = list(value.values())
        elif kind == "list":
            if not is_array(value):
                return None
            items = value
        elif kind == "filter":
            if not is_array(value):
                return None
            pred = self.pred
            items = [e for e in value if truthy(pred.eval(e, ctx))]
        elif kind == "flatten":
            if not is_array(value):
                return None
            items = flatten_one_level(value)
        elif kind == "slice":
            if not is_array(value):
                return None
            items = [value[i] for i in slice_indices(len(value), self.start, self.stop, self.step)]
        else:  # pragma: no cover
            raise AssertionError(kind)
        rhs = self.rhs
        out = []
        for item in items:
            r = rhs.eval(item, ctx)
            if r is not None:
                out.append(r)
        return out


class MultiList(Node):
    """Build an array; on a null current value the result is null. # spec: N-000211 N-000218"""

    __slots__ = ("elements",)

    def __init__(self, elements):
        self.elements = elements

    def eval(self, value, ctx):
        if value is None:
            return None
        return [e.eval(value, ctx) for e in self.elements]


class MultiHash(Node):
    """Build an object; a null current value yields null. # spec: N-000206 N-000207 N-000208 N-000218"""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, value, ctx):
        if value is None:
            return None
        obj = ctx.new_object()
        for key, expr in self.pairs:
            obj[key] = expr.eval(value, ctx)
        return obj


class Not(Node):
    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr

    def eval(self, value, ctx):
        return not truthy(self.expr.eval(value, ctx))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        left = self.left.eval(value, ctx)
        if not truthy(left):
            return left
        return self.right.eval(value, ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        left = self.left.eval(value, ctx)
        if truthy(left):
            return left
        return self.right.eval(value, ctx)


class Compare(Node):
    """== and != are JSON equality; ordering operators are null on mixed types."""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        a = self.left.eval(value, ctx)
        b = self.right.eval(value, ctx)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        return ordered(self.op, a, b)


class ExprRefNode(Node):
    """``&expr``: evaluates to a reference that built-ins apply later. # spec: N-000231 N-000234"""

    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr

    def eval(self, value, ctx):
        return ExprRef(self.expr, ctx)


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, value, ctx):
        entry = ctx.registry.get(self.name)
        if entry is None:
            raise UnknownFunctionError("unknown function: %s" % self.name)
        specs, variadic, bound = entry
        n = len(self.args)
        if variadic:
            if n < len(specs):
                raise InvalidArityError("%s takes at least %d argument(s)" % (self.name, len(specs)))
        elif n != len(specs):
            raise InvalidArityError("%s takes %d argument(s), got %d" % (self.name, len(specs), n))
        values = [a.eval(value, ctx) for a in self.args]
        for i, arg in enumerate(values):
            spec = specs[i] if i < len(specs) else specs[-1]
            if not any(type_matches(arg, t) for t in spec):
                raise InvalidTypeError("argument %d of %s has an invalid type" % (i + 1, self.name))
        return bound(*values)


def type_matches(v, type_name):
    if type_name == "any":
        return True
    if type_name == "number":
        return is_number(v)
    if type_name == "string":
        return isinstance(v, str)
    if type_name == "array":
        return is_array(v)
    if type_name == "object":
        return is_object(v)
    if type_name == "null":
        return v is None
    if type_name == "reference":
        return isinstance(v, ExprRef)
    return False  # pragma: no cover
