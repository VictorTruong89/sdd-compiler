"""Public entries: ``search`` (one shot) and ``compile`` (parse once, search many).

# spec: N-000073 N-000074 N-000075 N-000078 N-000079 N-000080 N-000081
# spec: N-000082 N-000086 N-000342 N-000343 N-000372 N-000373 N-000375
# spec: N-000376 N-000377 N-000378 N-000379 N-000380 N-000381 N-000382
# spec: N-000383 N-000384 N-000385 N-000386 N-000387 N-000388 N-000389
# spec: N-000390 N-000391 N-000392 N-000367 N-000368 N-000370 N-000371
"""

from ._parser import parse
from .functions import registry_for


class Context:
    """Per-search evaluation state: the configured mapping type and the function table."""

    __slots__ = ("dict_cls", "registry")

    def __init__(self, dict_cls, registry):
        self.dict_cls = dict_cls
        self.registry = registry

    def new_object(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()


def _context(options):
    if options is None:
        return Context(None, registry_for(None))
    dict_cls = getattr(options, "dict_cls", None)
    provider = getattr(options, "custom_functions", None)
    return Context(dict_cls, registry_for(provider))


class ParsedExpression:
    """The result of ``compile``: an expression that can be searched many times."""

    __slots__ = ("_node",)

    def __init__(self, node):
        self._node = node

    def search(self, value, options=None):
        """Evaluate against ``value``; refuse with a ``PathSelError`` subclass."""
        return self._node.eval(value, _context(options))

    def __repr__(self):
        return "<pathsel.ParsedExpression>"


def compile(expression):  # noqa: A001 - published name (Interface Contract)
    """Parse an expression once. Raises a refusal for empty or ill-formed text."""
    return ParsedExpression(parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` in one shot."""
    return compile(expression).search(data, options)
