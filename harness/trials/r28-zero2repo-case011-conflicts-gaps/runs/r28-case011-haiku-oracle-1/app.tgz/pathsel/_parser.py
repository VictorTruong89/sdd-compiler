"""Pratt parser for PathSel expressions.

Binding powers (higher binds tighter). A projection's right-hand side is parsed
with the projection's own power, so later steps join it only when they bind
tighter (FP-04, "Reach of a projection"):

  pipe 1 < || 2 < && 3 < comparators 5 < flatten 9 (projection stop 10)
  < list wildcard / slice / object wildcard 20 < filter 21 < ! operand 45
  < dot 40 ... index / slice / list-wildcard bracket 55 (as a step)

# spec: N-000073 N-000074 N-000075 N-000076 N-000078 N-000079 N-000087
# spec: N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094
# spec: N-000095 N-000098 N-000099 N-000100 N-000101 N-000105 N-000106
# spec: N-000107 N-000108 N-000109 N-000114 N-000117 N-000118 N-000123
# spec: N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000160
# spec: N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189
# spec: N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196
# spec: N-000197 N-000198 N-000199 N-000200 N-000201 N-000202 N-000203
# spec: N-000213 N-000214 N-000215 N-000216 N-000217 N-000221 N-000222
# spec: N-000238 N-000240 N-000241 N-000260 N-000261 N-000321 N-000322
"""

from . import _lexer as L
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from ._nodes import (
    IDENTITY,
    And,
    Compare,
    ExprRefNode,
    Field,
    FunctionCall,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    Or,
    Projection,
    Subexpr,
)

PROJECTION_STOP = 10
BP_PIPE = 1
BP_OR = 2
BP_AND = 3
BP_CMP = 5
BP_FLATTEN = 9
BP_LIST = 20
BP_FILTER = 21
BP_DOT = 40
BP_NOT = 45
BP_BRACKET = 55

_BP = {
    L.PIPE: BP_PIPE,
    L.OR: BP_OR,
    L.AND: BP_AND,
    L.EQ: BP_CMP,
    L.NE: BP_CMP,
    L.LT: BP_CMP,
    L.LTE: BP_CMP,
    L.GT: BP_CMP,
    L.GTE: BP_CMP,
    L.DOT: BP_DOT,
}

_COMPARATORS = {L.EQ: "==", L.NE: "!=", L.LT: "<", L.LTE: "<=", L.GT: ">", L.GTE: ">="}


class Parser:
    def __init__(self, text):
        self.text = text
        self.tokens = L.tokenize(text)
        self.i = 0

    # -- token access -------------------------------------------------------

    def peek(self, k=0):
        j = self.i + k
        if j >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[j]

    def advance(self):
        t = self.tokens[self.i]
        if t.type != L.EOF:
            self.i += 1
        return t

    def unexpected(self, tok):
        """Raise the failure for a token that cannot appear here."""
        if tok.type == L.ERROR:
            raise tok.error
        if tok.type == L.EOF:
            raise IncompleteExpressionError("expression is incomplete", lex_position=len(self.text))
        raise PathSelSyntaxError("unexpected token at position %d" % tok.pos, lex_position=tok.pos)

    def expect(self, type_):
        tok = self.peek()
        if tok.type != type_:
            self.unexpected(tok)
        return self.advance()

    def lbp(self):
        tok = self.peek()
        if tok.type == L.LBRACKET:
            nxt = self.peek(1).type
            if nxt == L.RBRACKET:
                return BP_FLATTEN
            if nxt == L.QMARK:
                return BP_FILTER
            return BP_BRACKET
        return _BP.get(tok.type, 0)

    # -- Pratt core ---------------------------------------------------------

    def expression(self, rbp):
        left = self.nud()
        return self.loop(left, rbp)

    def loop(self, left, rbp):
        while self.lbp() > rbp:
            left = self.led(left)
        return left

    def nud(self):
        tok = self.peek()
        t = tok.type
        if t == L.IDENT:
            self.advance()
            if self.peek().type == L.LPAREN:
                return self.call(tok.value)
            return Field(tok.value)
        if t == L.QIDENT:
            self.advance()
            return Field(tok.value)
        if t == L.STAR:
            self.advance()
            return Projection("obj", self.projection_rhs(BP_LIST))
        if t == L.LBRACKET:
            self.advance()
            return self.bracket(allow_multi=True)
        if t == L.LBRACE:
            self.advance()
            return self.multi_hash()
        if t == L.LPAREN:
            self.advance()
            inner = self.expression(0)
            self.expect(L.RPAREN)
            return inner
        if t == L.NOT:
            self.advance()
            return Not(self.expression(BP_NOT))
        if t == L.CURRENT:
            self.advance()
            return IDENTITY
        if t == L.EXPREF:
            self.advance()
            return ExprRefNode(self.expression(0))
        if t == L.LITERAL or t == L.RAW:
            self.advance()
            return Literal(tok.value)
        self.unexpected(tok)

    def led(self, left):
        tok = self.peek()
        t = tok.type
        if t == L.PIPE:
            self.advance()
            return Subexpr(left, self.expression(BP_PIPE))
        if t == L.OR:
            self.advance()
            return Or(left, self.expression(BP_OR))
        if t == L.AND:
            self.advance()
            return And(left, self.expression(BP_AND))
        if t in _COMPARATORS:
            self.advance()
            return Compare(_COMPARATORS[t], left, self.expression(BP_CMP))
        if t == L.DOT:
            self.advance()
            return Subexpr(left, self.parse_dot(BP_DOT))
        if t == L.LBRACKET:
            self.advance()
            return Subexpr(left, self.bracket(allow_multi=False))
        self.unexpected(tok)

    # -- pieces -------------------------------------------------------------

    def call(self, name):
        """Parse an argument list; the function name has been consumed."""
        self.expect(L.LPAREN)
        args = []
        if self.peek().type == L.RPAREN:
            self.advance()
            return FunctionCall(name, args)
        while True:
            args.append(self.expression(0))
            if self.peek().type == L.COMMA:
                self.advance()
                continue
            self.expect(L.RPAREN)
            break
        return FunctionCall(name, args)

    def projection_rhs(self, bp):
        """Right-hand side of a projection-starting form (FP-04)."""
        if self.lbp() < PROJECTION_STOP:
            return IDENTITY
        tok = self.peek()
        if tok.type == L.DOT:
            self.advance()
            return self.parse_dot(bp)
        if tok.type == L.LBRACKET:
            return self.expression(bp)
        return IDENTITY

    def parse_dot(self, bp):
        """Parse what follows a dot (the dot is consumed)."""
        tok = self.peek()
        t = tok.type
        if t == L.EOF:
            raise PathSelSyntaxError(
                "a dot must be followed by a selector", lex_position=len(self.text)
            )
        if t == L.IDENT:
            self.advance()
            if self.peek().type == L.LPAREN:
                node = self.call(tok.value)
            else:
                node = Field(tok.value)
        elif t == L.QIDENT:
            self.advance()
            node = Field(tok.value)
        elif t == L.STAR:
            self.advance()
            node = Projection("obj", self.projection_rhs(BP_LIST))
        elif t == L.LBRACKET:
            nxt = self.peek(1)
            if nxt.type in (L.NUMBER, L.COLON, L.QMARK, L.RBRACKET, L.STAR):
                self.unexpected(nxt)
            self.advance()
            node = self.multi_list_rest()
        elif t == L.LBRACE:
            self.advance()
            node = self.multi_hash()
        else:
            self.unexpected(tok)
        return self.loop(node, bp)

    def bracket(self, allow_multi):
        """Parse the inside of a bracket; the opening '[' is consumed.

        allow_multi: a multiselect list is allowed (expression start, or first
        step after a dot); after an operand it is a grammar-level failure.
        """
        tok = self.peek()
        t = tok.type
        if t == L.STAR:
            self.advance()
            self.expect(L.RBRACKET)
            return Projection("list", self.projection_rhs(BP_LIST))
        if t == L.QMARK:
            self.advance()
            pred = self.expression(0)
            self.expect(L.RBRACKET)
            return Projection("filter", self.projection_rhs(BP_FILTER), pred=pred)
        if t == L.RBRACKET:
            self.advance()
            return Projection("flatten", self.projection_rhs(BP_FLATTEN))
        if t == L.NUMBER or t == L.COLON:
            return self.index_or_slice()
        if allow_multi:
            return self.multi_list_rest()
        self.unexpected(tok)

    def index_or_slice(self):
        parts = [None]
        while True:
            if self.peek().type == L.NUMBER:
                parts[-1] = self.advance().value
            if self.peek().type == L.COLON:
                colon = self.peek()
                if len(parts) >= 3:
                    raise PathSelSyntaxError(
                        "a slice has at most three parts", lex_position=colon.pos
                    )
                self.advance()
                parts.append(None)
                continue
            break
        self.expect(L.RBRACKET)
        if len(parts) == 1:
            return Index(parts[0])
        start, stop, step = (parts + [None, None, None])[:3]
        if step is None:
            step = 1
        if step == 0:
            raise ZeroSliceStepError("a slice step of 0 selects nothing and refuses")
        return Projection("slice", self.projection_rhs(BP_LIST), start=start, stop=stop, step=step)

    def multi_list_rest(self):
        """Elements of a multiselect list; the opening '[' is consumed."""
        elements = [self.expression(0)]
        while self.peek().type == L.COMMA:
            self.advance()
            elements.append(self.expression(0))
        self.expect(L.RBRACKET)
        return MultiList(elements)

    def multi_hash(self):
        """Pairs of a multiselect hash; the opening '{' is consumed."""
        pairs = []
        while True:
            tok = self.peek()
            if tok.type not in (L.IDENT, L.QIDENT):
                self.unexpected(tok)
            self.advance()
            self.expect(L.COLON)
            pairs.append((tok.value, self.expression(0)))
            if self.peek().type == L.COMMA:
                self.advance()
                continue
            self.expect(L.RBRACE)
            break
        return MultiHash(pairs)


def parse(text):
    """Parse expression text into a node tree or raise a refusal."""
    if not isinstance(text, str):
        raise TypeError("expression must be a str")
    if text == "":
        raise EmptyExpressionError("the expression is empty", lex_position=0)
    parser = Parser(text)
    node = parser.expression(0)
    tok = parser.peek()
    if tok.type != L.EOF:
        parser.unexpected(tok)
    return node
