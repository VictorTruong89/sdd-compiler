"""Failure carriers for pathsel.

Every refusal is a ``ValueError``. The kind of a refusal is the type of the
raised exception (Interface Contract, "Failure carriers").
# spec: N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411
# spec: N-000412 N-000413 N-000414 N-000415 N-000416 N-000417 N-000418
# spec: N-000419 N-000420 N-000421 N-000422
"""


class PathSelError(ValueError):
    """Base of every refusal. Carries ``lex_position`` for positional kinds."""

    lex_position = None

    def __init__(self, message, lex_position=None):
        super().__init__(message)
        if lex_position is not None:
            self.lex_position = int(lex_position)


class EmptyExpressionError(PathSelError):
    """The zero-length expression text."""


class IncompleteExpressionError(PathSelError):
    """Text ends where an operand or a closing token is still required."""


class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure (the plain syntax kind)."""


class PathSelTokenError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor provided."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
