"""pathsel: evaluate PathSel expressions against ordinary Python data.

Importing this package performs no I/O, starts no processes and opens no sockets.

# spec: N-000366 N-000367 N-000369 N-000372 N-000373 N-000374
"""

from .core import ParsedExpression, compile, search
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    PathSelTokenError,
    UnknownFunctionError,
    ZeroSliceStepError,
)

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "PathSelTokenError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
