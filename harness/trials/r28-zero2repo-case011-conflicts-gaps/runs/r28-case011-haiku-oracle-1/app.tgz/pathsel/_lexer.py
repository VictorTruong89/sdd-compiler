"""Tokenizer for the PathSel language.

Token-level failures are emitted as an ERROR token at the offset where the
bad token begins. The parser raises it only when it reaches that token, so a
grammar failure earlier in the text is reported first.

# spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
# spec: N-000103 N-000104 N-000110 N-000111 N-000112 N-000113 N-000114
# spec: N-000119 N-000120 N-000121 N-000122 N-000124 N-000227 N-000228
# spec: N-000229 N-000230 N-000237 N-000239 N-000260
"""

import json

from .errors import PathSelTokenError

WS = frozenset(" \t\n\r")
ID_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
ID_CHARS = ID_START | frozenset("0123456789")
DIGITS = frozenset("0123456789")
HEX = frozenset("0123456789abcdefABCDEF")

# Token types
IDENT = "IDENT"          # unquoted identifier; value = name
QIDENT = "QIDENT"        # quoted identifier; value = decoded key
NUMBER = "NUMBER"        # integer; value = int
RAW = "RAW"              # raw string literal; value = str
LITERAL = "LITERAL"      # JSON literal; value = decoded JSON value
CURRENT = "CURRENT"      # @
EXPREF = "EXPREF"        # &
AND = "AND"              # &&
OR = "OR"                # ||
PIPE = "PIPE"            # |
NOT = "NOT"              # !
NE = "NE"                # !=
EQ = "EQ"                # ==
LT = "LT"
LTE = "LTE"
GT = "GT"
GTE = "GTE"
DOT = "DOT"
STAR = "STAR"
LBRACKET = "LBRACKET"
RBRACKET = "RBRACKET"
QMARK = "QMARK"
LBRACE = "LBRACE"
RBRACE = "RBRACE"
LPAREN = "LPAREN"
RPAREN = "RPAREN"
COMMA = "COMMA"
COLON = "COLON"
ERROR = "ERROR"
EOF = "EOF"

_SIMPLE = {
    ".": DOT,
    "*": STAR,
    "[": LBRACKET,
    "]": RBRACKET,
    "?": QMARK,
    "{": LBRACE,
    "}": RBRACE,
    "(": LPAREN,
    ")": RPAREN,
    ",": COMMA,
    ":": COLON,
    "@": CURRENT,
}


class Token:
    __slots__ = ("type", "value", "pos", "error")

    def __init__(self, type_, value, pos, error=None):
        self.type = type_
        self.value = value
        self.pos = pos
        self.error = error

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.type, self.value, self.pos)


def _no_constant(name):
    raise ValueError("non-JSON constant " + name)


def parse_literal_text(raw):
    """Read the text of a JSON literal; return (ok, value).

    Valid JSON is read as JSON. Otherwise the text, after removing leading
    whitespace, is read as the content of a JSON string.
    # spec: N-000224 N-000225 N-000226
    """
    try:
        return True, json.loads(raw, parse_constant=_no_constant)
    except ValueError:
        pass
    stripped = raw.lstrip(" \t\n\r")
    try:
        return True, json.loads('"' + stripped + '"', strict=True)
    except ValueError:
        return False, None


def _is_hex4(s):
    return len(s) == 4 and all(c in HEX for c in s)


def tokenize(text):
    """Split text into tokens. Always ends with an EOF token at len(text)."""
    toks = []
    n = len(text)
    i = 0

    def fail(message, pos):
        err = PathSelTokenError(message, lex_position=pos)
        toks.append(Token(ERROR, None, pos, err))
        toks.append(Token(EOF, None, n))
        return toks

    while True:
        while i < n and text[i] in WS:
            i += 1
        if i >= n:
            toks.append(Token(EOF, None, n))
            return toks
        c = text[i]
        start = i

        if c in ID_START:
            j = i + 1
            while j < n and text[j] in ID_CHARS:
                j += 1
            toks.append(Token(IDENT, text[i:j], start))
            i = j
            continue

        if c in DIGITS or (c == "-" and i + 1 < n and text[i + 1] in DIGITS):
            j = i + 1
            while j < n and text[j] in DIGITS:
                j += 1
            toks.append(Token(NUMBER, int(text[i:j]), start))
            i = j
            continue

        if c == "-":
            return fail("a hyphen begins no token", start)

        if c == '"':
            j = i + 1
            while True:
                if j >= n:
                    return fail("unterminated quoted identifier", start)
                ch = text[j]
                if ch == "\\":
                    j += 2
                    continue
                if ch == '"':
                    break
                j += 1
            raw = text[i:j + 1]
            try:
                value = json.loads(raw, strict=True)
            except ValueError:
                return fail("quoted identifier is not a legal JSON string", start)
            if not isinstance(value, str):
                return fail("quoted identifier is not a JSON string", start)
            toks.append(Token(QIDENT, value, start))
            i = j + 1
            continue

        if c == "'":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    return fail("unterminated raw string literal", start)
                ch = text[j]
                if ch == "'":
                    break
                if ch == "\\" and text[j + 1:j + 2] == "'":
                    buf.append("'")
                    j += 2
                    continue
                if ch == "\\" and text[j + 1:j + 2] == "u" and _is_hex4(text[j + 2:j + 6]):
                    k = j
                    run = []
                    while text.startswith("\\u", k) and _is_hex4(text[k + 2:k + 6]):
                        run.append(text[k:k + 6])
                        k += 6
                    buf.append(json.loads('"' + "".join(run) + '"'))
                    j = k
                    continue
                buf.append(ch)
                j += 1
            toks.append(Token(RAW, "".join(buf), start))
            i = j + 1
            continue

        if c == "`":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    return fail("unterminated JSON literal", start)
                ch = text[j]
                if ch == "`":
                    break
                if ch == "\\" and text[j + 1:j + 2] == "`":
                    buf.append("`")
                    j += 2
                    continue
                buf.append(ch)
                j += 1
            ok, value = parse_literal_text("".join(buf))
            if not ok:
                return fail("JSON literal is neither JSON nor JSON string content", start)
            toks.append(Token(LITERAL, value, start))
            i = j + 1
            continue

        if c == "|":
            if text[i + 1:i + 2] == "|":
                toks.append(Token(OR, "||", start))
                i += 2
            else:
                toks.append(Token(PIPE, "|", start))
                i += 1
            continue

        if c == "&":
            if text[i + 1:i + 2] == "&":
                toks.append(Token(AND, "&&", start))
                i += 2
            else:
                toks.append(Token(EXPREF, "&", start))
                i += 1
            continue

        if c == "!":
            if text[i + 1:i + 2] == "=":
                toks.append(Token(NE, "!=", start))
                i += 2
            else:
                toks.append(Token(NOT, "!", start))
                i += 1
            continue

        if c == "=":
            if text[i + 1:i + 2] == "=":
                toks.append(Token(EQ, "==", start))
                i += 2
                continue
            return fail("a lone '=' begins no token", start)

        if c in "<>":
            two = c + "="
            if text[i + 1:i + 2] == "=":
                kind = {"<": LTE, ">": GTE}[c]
                toks.append(Token(kind, two, start))
                i += 2
            else:
                kind = {"<": LT, ">": GT}[c]
                toks.append(Token(kind, c, start))
                i += 1
            continue

        if c in _SIMPLE:
            toks.append(Token(_SIMPLE[c], c, start))
            i += 1
            continue

        return fail("character begins no token", start)
