"""Value model helpers: type tests, truthiness, equality, ordering.

# spec: N-000050 N-000056 N-000057 N-000058 N-000242 N-000243 N-000244
# spec: N-000245 N-000246 N-000251 N-000252 N-000253 N-000180 N-000181
"""

import decimal
import re
from collections.abc import Mapping

_INT_NUMERAL = re.compile(r"-?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def is_number(v):
    """Integers, floats and host decimals; never booleans. # spec: N-000058"""
    return isinstance(v, (int, float, decimal.Decimal)) and not isinstance(v, bool)


def is_string(v):
    return isinstance(v, str)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v):
    """Any mapping (ordinary dict, OrderedDict, or a configured mapping type)."""
    return isinstance(v, Mapping)


def truthy(v):
    """True value per the Terminology false-value set. # spec: N-000251 N-000252"""
    if v is None:
        return False
    if isinstance(v, bool):
        return v
    if isinstance(v, (str, list, tuple)) or isinstance(v, Mapping):
        return len(v) > 0
    return True


def json_equal(a, b):
    """JSON value equality: a number is never equal to a boolean. # spec: N-000242 N-000243 N-000244"""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) and isinstance(b, str):
        return a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    if (is_number(a) or isinstance(a, str) or is_array(a) or is_object(a)) and (
        is_number(b) or isinstance(b, str) or is_array(b) or is_object(b)
    ):
        return False
    return bool(a == b)


def ordered(op, a, b):
    """<, <=, >, >=: numbers numerically, strings by code point; otherwise null."""
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        if op == "<":
            return a < b
        if op == "<=":
            return a <= b
        if op == ">":
            return a > b
        return a >= b
    return None


def parse_integer_numeral(s):
    """Return int for an integer numeral, else None. # spec: N-000287"""
    if _INT_NUMERAL.fullmatch(s):
        return int(s)
    return None


def parse_float_numeral(s):
    """Return float for a decimal or exponent numeral, else None. # spec: N-000288"""
    if _FLOAT_NUMERAL.fullmatch(s):
        return float(s)
    return None


class ExprRef:
    """A deferred subexpression (expression reference) bound to its evaluator.

    # spec: N-000231 N-000232 N-000233 N-000234 N-000235 N-000236 N-000423
    """

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def apply(self, value):
        return self.node.eval(value, self.ctx)

    def __repr__(self):
        return "<pathsel expression reference>"
