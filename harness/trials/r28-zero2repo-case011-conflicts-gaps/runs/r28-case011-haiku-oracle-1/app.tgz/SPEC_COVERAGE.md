# Spec coverage

Every id in `spec/CHECKLIST.md` (N-000001 to N-000423) is listed once below, grouped in runs.

Status legend:

- `T`: implemented and covered by tests
- `I`: implemented; no dedicated test
- `S`: satisfied by layout, packaging or descriptive text (no separate code path)
- `X`: not built as written: superseded by a conflict decision (see NOTES.md section 1)

Test names refer to `tests/test_pathsel.py`. Code paths refer to the `pathsel/` package. `# spec:` comments in the code carry the same ids.

| Ids | Status | Where / note |
|---|---|---|
| N-000001–N-000003 | T | dotted path, missing is null, search and compile (core.py, _parser.py, _nodes.py) |
| N-000004–N-000009 | T | search and compile entries, parsed-expression reuse, options (core.py, functions.py) |
| N-000010–N-000013 | S | descriptive: behavior-only scope; no CLI or config is added |
| N-000014 | T | expression text (_parser.py) |
| N-000015 | T | document is any host data (_nodes.py) |
| N-000016 | T | search entry (core.search) |
| N-000017 | T | compile entry (core.compile) |
| N-000018 | T | parsed expression reused (core.ParsedExpression) |
| N-000019–N-000020 | T | current value; @ and projection element (_nodes.Identity) |
| N-000021 | T | null from missing field and wrong kind (_nodes.Field, Index) |
| N-000022 | X | superseded by N-000300 (CF-000015): empty string/array are not null for not_null |
| N-000023 | X | superseded in part by N-000287 (CF-000057): integer numerals give int; decimal/exponent give float |
| N-000024 | I | host decimal counts as number (_values.is_number) |
| N-000025 | T | boolean is not a number (test_equality_is_json_equality) |
| N-000026 | X | superseded by N-000277 (CF-000035): length counts Unicode characters, not UTF-8 bytes |
| N-000027 | T | boolean is not 0/1 (test_equality_is_json_equality) |
| N-000028 | X | superseded by N-000234 (CF-000056): bare expression reference searches to a non-null value |
| N-000029 | T | false-value set (test_not_truthiness_and_zero) |
| N-000030 | T | projection definition (test_list_wildcard..., test_filter_projection) |
| N-000031 | X | superseded by N-000165 (CF-000027): object wildcard on non-object is null |
| N-000032 | T | evaluation options (test_mapping_type..., test_custom_function...) |
| N-000033 | T | built-in function set (test_builtin_functions) |
| N-000034–N-000036 | T | every refusal is a ValueError with a kind (test_every_refusal..., test_function_kinds...) |
| N-000037 | S | failure wording is informational; our messages are free text |
| N-000038–N-000039 | S | library only; no command-line program or __main__ module |
| N-000040–N-000049 | T | FP-01..FP-08 public surfaces (tests named test_*, see each FP group) |
| N-000050–N-000051 | S | pure Python, zero runtime dependencies, no compiled code (pyproject.toml) |
| N-000052 | S | Python 3.9+ floor: code avoids newer syntax; 3.9 is not installed here, so unverified |
| N-000053 | S | pure Python; run on Linux only here (macOS, Windows not run) |
| N-000054 | S | CPU-only: no accelerator calls |
| N-000055 | S | imported from the source tree: flat pathsel/ at the root |
| N-000056–N-000058 | I | six JSON types, host decimals, host values as current values (_values.py) |
| N-000059–N-000060 | T | missing is null (test_missing_path_is_null_not_failure) |
| N-000061 | S | failure wording is informational |
| N-000062 | T | success versus failure: value returned or refusal raised |
| N-000063 | T | every failure is a ValueError (test_every_refusal_is_a_value_error) |
| N-000064 | T | each failure has its kind (errors.py; kind tests) |
| N-000065 | T | syntax and incomplete positions (test_syntax_positions_are_offsets...) |
| N-000066 | T | results come from evaluation (_nodes.py) |
| N-000067–N-000068 | S | not a JSON encoder or decoder: literal text is read only inside expressions |
| N-000069–N-000070 | T | input never mutated (test_search_takes_document_without_mutating_it) |
| N-000071 | S | decision: tooling and caching are not part of the product; none is present |
| N-000072 | S | no later language revision is implemented |
| N-000073–N-000076 | T | FP-01 entries and failures prevent evaluation |
| N-000077 | T | dotted path selects the named field (test_dotted_path...) |
| N-000078–N-000079 | T | parsed expression searched repeatedly (test_compile_then_search...) |
| N-000080–N-000082 | T | one-shot equals compile-then-search, same refusals (test_compile_then_search...) |
| N-000083–N-000086 | T | missing path is null at any depth; compile succeeds (test_missing..., test_compile_succeeds...) |
| N-000087–N-000089 | T | empty expression kind (test_empty_expression_kind) |
| N-000090–N-000093 | T | incomplete expression kind (test_incomplete_expression_kind) |
| N-000094–N-000095 | T | grammar-level syntax kind (test_grammar_level_syntax_kind) |
| N-000096–N-000101 | T | token-level is a more specific syntax kind (test_token_level_...) |
| N-000102–N-000104 | T | positions (test_syntax_positions_are_offsets_of_failing_token) |
| N-000105–N-000106 | T | refusal is a value error and distinct from null (test_every_refusal...) |
| N-000107–N-000108 | T | identifiers and dotted chains (_parser.parse_dot, _nodes.Field) |
| N-000109 | T | whitespace between tokens (test_whitespace_between_tokens...) |
| N-000110–N-000114 | T | quoted identifiers decode as JSON (test_quoted_identifier_names_one_key...) |
| N-000115–N-000116 | T | identifier on non-object is null (test_identifier_on_array...) |
| N-000117–N-000118 | T | number is not an identifier; quoted number key (test_grammar_level_syntax_kind, test_quoted...) |
| N-000119–N-000122 | T | hyphen is token-level syntax (test_token_level_syntax...) |
| N-000123 | T | dot at start, end, doubled is syntax (test_grammar_level_syntax_kind) |
| N-000124 | T | unterminated quoted identifier is token-level (test_token_level_syntax...) |
| N-000125 | T | missing field null (test_missing_path...) |
| N-000126–N-000128 | T | index, negative index, out of range (test_index_including_negative...) |
| N-000129 | T | index on non-array is null (test_index_on_non_array_is_null) |
| N-000130–N-000132 | T | slice shape and default step (test_slices) |
| N-000133 | X | superseded by N-000152 (CF-000055): step 0 refuses, not empty array |
| N-000134–N-000141 | T | slice bounds, clamping, negative step, empty result (test_slices) |
| N-000142 | T | slice on non-array is null (test_slice_of_non_array_is_null) |
| N-000143–N-000144 | I | slice is a projection with null dropping (_nodes.Projection) |
| N-000145–N-000147 | T | flatten one level (test_flatten_one_level_only, test_flatten_of_non_array_is_null) |
| N-000148–N-000150 | T | flatten is a projection (test_flatten_with_right_hand_side) |
| N-000151 | T | index, slice, flatten may start an expression (test_index...) |
| N-000152–N-000154 | T | zero slice step is its own kind (test_zero_slice_step_is_its_own_kind) |
| N-000155 | T | slice with more than three parts is syntax (test_grammar_level_syntax_kind) |
| N-000156 | T | out of range does not fail (test_index_including_negative...) |
| N-000157 | X | superseded by N-000142 (CF-000007): slice of non-array is null |
| N-000158 | T | FP-04 public entries (test_list_wildcard...) |
| N-000159–N-000162 | T | list wildcard (test_list_wildcard_projects_and_drops_nulls) |
| N-000163 | T | object wildcard (test_object_wildcard_projects_values) |
| N-000164 | T | object wildcard projects values (test_object_wildcard_projects_values) |
| N-000165 | T | object wildcard on non-object is null (test_object_wildcard_on_non_object_is_null) |
| N-000166–N-000167 | T | nested projections (test_projection_nesting) |
| N-000168–N-000173 | T | filter projection (test_filter_projection) |
| N-000174–N-000179 | T | predicate forms (test_filter_projection, test_filter_predicate_uses_same_operators) |
| N-000180–N-000181 | I | JSON equality inside predicates (_values.json_equal) |
| N-000182–N-000194 | T | projection reach and ranks (test_projected_right_hand_side..., test_flatten_is_not...) |
| N-000195–N-000197 | T | comparator ends projection (test_projection_stops_at_comparator_and_pipe) |
| N-000198 | I | decision: a slice after an index or slice starts a projection (_parser.index_or_slice) |
| N-000199 | I | decision: later steps join a dot-led right-hand side (_parser.parse_dot) |
| N-000200–N-000201 | T | wildcard followed by identifier or star is syntax (test_grammar_level_syntax_kind) |
| N-000202 | T | filter on non-array is null (test_filter_on_non_array_is_null) |
| N-000203 | T | ill-formed or missing predicate does not succeed (test_grammar_level_syntax_kind) |
| N-000204–N-000205 | T | projected nulls dropped (test_list_wildcard_projects_and_drops_nulls) |
| N-000206–N-000208 | T | multiselect hash (test_multiselect_hash_keeps_null_values) |
| N-000209–N-000210 | I | hash keys unquoted or quoted (_parser.multi_hash) |
| N-000211 | T | multiselect list keeps nulls (test_multiselect_list_keeps_nulls) |
| N-000212 | X | superseded by N-000218 (CF-000011): null current value gives null |
| N-000213–N-000214 | T | multiselect as first step of projection (test_multiselect_as_first_step_of_projection) |
| N-000215–N-000216 | T | multiselect on projection (test_multiselect_hash_on_projection) |
| N-000217 | T | current value token (test_current_value_token) |
| N-000218 | T | null current value gives null (test_multiselect_on_null_current_value_is_null) |
| N-000219–N-000222 | T | pipe (test_pipe_binds_loosest_and_chains) |
| N-000223–N-000224 | T | JSON literal (test_json_literal_is_read_as_json) |
| N-000225 | T | JSON literal fallback string (test_json_literal_falls_back...) |
| N-000226 | T | literal starts a subexpression (test_json_literal_is_read_as_json) |
| N-000227 | X | implemented except the \uXXXX clause, which N-000239 overrides (CF-000049) |
| N-000228–N-000230 | T | raw string rules (test_raw_string_literal_rules) |
| N-000231–N-000232 | T | expression reference (test_expression_reference..., map in test_builtin_functions) |
| N-000233–N-000234 | T | bare reference searches to non-null (test_expression_reference_searches...) |
| N-000235–N-000236 | T | reference outside function; non-reference refused (test_function_call_failure_kinds) |
| N-000237 | T | unclosed literal is token-level (test_token_level_syntax...) |
| N-000238 | T | literal after dot is syntax (test_grammar_level_syntax_kind) |
| N-000239 | T | raw string \uXXXX decoded (test_raw_string_unicode_escape_decodes) |
| N-000240 | T | multiselect missing parts does not succeed (test_incomplete..., test_grammar...) |
| N-000241 | T | pipe with missing side does not succeed (test_incomplete_expression_kind) |
| N-000242–N-000244 | T | JSON equality (test_equality_is_json_equality) |
| N-000245–N-000246 | T | ordering (test_ordering_numbers_and_strings) |
| N-000247–N-000250 | T | or and and return operands (test_or_and_return_operands) |
| N-000251–N-000252 | T | not and truthiness (test_not_truthiness_and_zero) |
| N-000253–N-000257 | T | binding and parentheses (test_not_binds_tighter..., test_parentheses_override_binding) |
| N-000258 | T | same operators in predicate (test_filter_predicate_uses_same_operators) |
| N-000259 | X | superseded by N-000202 (CF-000005): filter on non-array is null |
| N-000260–N-000261 | T | lone = and lone & (test_lone_equals_and_ampersand_refused) |
| N-000262 | T | call form and reserved names (test_builtin_functions) |
| N-000263 | T | built-in name set (functions.BUILTIN_NAMES: 26 names) |
| N-000264–N-000267 | T | call checked name, count, type; compile succeeds (test_function_call_failure_kinds, test_function_name_checked_before_count) |
| N-000268 | X | superseded by N-000280 (CF-000054): join of empty array is empty string, not null |
| N-000269–N-000279 | T | built-in definitions (test_builtin_functions) |
| N-000280 | T | join of empty array is empty string (test_builtin_functions) |
| N-000281–N-000286 | T | built-in definitions (test_builtin_functions) |
| N-000287–N-000289 | T | to_number rules (test_builtin_functions) |
| N-000290–N-000292 | T | max and min (test_builtin_functions) |
| N-000293 | I | sort (functions._func_sort) |
| N-000294 | T | sum (test_builtin_functions) |
| N-000295–N-000297 | T | merge (test_builtin_functions) |
| N-000298–N-000299 | T | not_null (test_builtin_functions) |
| N-000300 | T | empty string is not null for not_null (test_builtin_functions) |
| N-000301–N-000302 | T | map (test_builtin_functions) |
| N-000303 | T | sort_by (test_builtin_functions) |
| N-000304 | T | sort_by key types (test_function_call_failure_kinds) |
| N-000305 | I | sort_by is stable (Python sorted, index keys) |
| N-000306–N-000308 | T | max_by and min_by (test_builtin_functions) |
| N-000309–N-000310 | T | function as projection rhs and projection as argument (test_function_call_on_projection_and_argument) |
| N-000311–N-000313 | T | arity (test_function_call_failure_kinds) |
| N-000314–N-000320 | T | argument types (test_function_call_failure_kinds) |
| N-000321–N-000322 | T | quoted identifier cannot be a function name (test_quoted_identifier_cannot_be_a_function_name) |
| N-000323–N-000327 | T | options refine FP-01 and FP-07 (test_mapping_type..., test_custom_function...) |
| N-000328–N-000332 | T | mapping type for constructed hashes (test_mapping_type_applies_to_constructed_hashes) |
| N-000333 | I | decision: other mapping types are accepted as objects (_values.is_object accepts any Mapping) |
| N-000334 | T | OrderedDict hash accepted where an object is required (test_mapping_type_applies...) |
| N-000335–N-000338 | T | custom function provider (test_custom_function_is_called_with_evaluated_arguments) |
| N-000339 | T | provider extends built-ins (test_builtin_name_cannot_be_replaced_by_provider) |
| N-000340 | T | built-ins unchanged with provider (test_builtin_name_cannot_be_replaced_by_provider) |
| N-000341 | I | mapping type and provider together (core._context reads both) |
| N-000342–N-000343 | T | same result one-shot and compiled; compile without provider (test_compile_then_search_with_options...) |
| N-000344 | T | name declared on another provider is unknown (test_name_on_other_provider_is_unknown) |
| N-000345–N-000347 | T | custom arity and type refusals (test_custom_function_arity_and_type_refusals) |
| N-000348–N-000349 | I | custom refusals use the built-in kinds (functions.py, _nodes.FunctionCall) |
| N-000350 | I | host non-JSON value refused by a typed custom argument (_nodes.type_matches) |
| N-000351–N-000352 | S | no compiled code; zero dependencies (pyproject.toml, layout) |
| N-000353 | S | Python 3.9 floor; not run on 3.9 here |
| N-000354 | S | MAY: any x86_64 or arm64 host; pure Python |
| N-000355 | S | cpu_baseline profile: pure CPU Python |
| N-000356 | S | platforms: pure Python; only Linux was run |
| N-000357 | T | required on Linux: test suite passes here |
| N-000358 | S | imported from the source tree (flat layout) |
| N-000359 | S | evaluates in an ordinary interpreter process |
| N-000360 | S | Python 3.9+, zero runtime deps; 3.9 not run here |
| N-000361–N-000362 | S | zero runtime deps; no extra system libraries |
| N-000363 | S | no native compile step |
| N-000364 | S | flat layout at the project root, packaged with setuptools (pyproject.toml) |
| N-000365 | S | MAY editable install: pyproject.toml provided; install not run |
| N-000366 | S | no command-line program, no python -m entry (no __main__ module) |
| N-000367 | T | importable Python library (test_public_names) |
| N-000368 | S | no network service or configuration file; no sys.exit anywhere |
| N-000369 | S | flat layout: pathsel/ at the root; distribution name pathsel |
| N-000370 | S | distribution name pathsel (pyproject.toml) |
| N-000371 | S | import performs no I/O, no processes, no sockets |
| N-000372 | T | search exported (test_public_names) |
| N-000373 | T | compile exported (test_public_names) |
| N-000374 | I | other root names: error classes and ParsedExpression exported |
| N-000375–N-000377 | T | search(expression, data, options) positional arguments (test helper s()) |
| N-000378–N-000381 | T | returns the selected value or raises (test suite) |
| N-000382 | T | refusals are value errors (test_every_refusal_is_a_value_error) |
| N-000383 | T | compile(expression) (test_compile_then_search_matches_one_shot) |
| N-000384 | T | compile never returns None (ParsedExpression) |
| N-000385 | I | decision: parsed-expression type is ParsedExpression |
| N-000386–N-000388 | T | parsed.search(value, options) (test_compile_then_search_with_options...) |
| N-000389–N-000391 | T | options read dict_cls and custom_functions by attribute (core._context) |
| N-000392 | S | decision: the library does not publish an options class |
| N-000393 | T | Functions class (test_signature_marks_only_decorated_methods) |
| N-000394 | T | signature callable (test_custom_function_is_called...) |
| N-000395 | T | Functions implements built-ins (test_builtin_functions) |
| N-000396 | T | subclass extends the provider (test_custom_function_is_called_with_evaluated_arguments) |
| N-000397 | T | _func_ attributes passed through signature define functions |
| N-000398 | T | implementation receives the provider first (test_custom_function...) |
| N-000399 | T | arguments already evaluated, in order (test_custom_function...) |
| N-000400 | T | provider instantiated with no arguments (test_custom_function...) |
| N-000401 | T | signature takes {"types": [...]} mappings (test_custom_function...) |
| N-000402 | T | spec type names accepted (number, string, array, object, null) |
| N-000403 | I | decorator returns a wrapper and does not call the implementation (functions.signature) |
| N-000404 | I | decorator never calls the implementation (functions.signature) |
| N-000405 | T | every refusal is a ValueError (test_every_refusal_is_a_value_error) |
| N-000406 | T | kind carried by exception type (errors.py) |
| N-000407 | S | decision: type names and importability are ours (errors.py) |
| N-000408 | S | decision: report text is ours |
| N-000409 | T | empty kind has its own type (EmptyExpressionError) |
| N-000410 | T | incomplete kind has its own type (IncompleteExpressionError) |
| N-000411 | T | grammar-level syntax kind is exactly PathSelSyntaxError (test_grammar_level_syntax_kind) |
| N-000412 | T | token-level is a subclass of the syntax kind (test_token_level_syntax...) |
| N-000413 | T | three distinct kinds (test_token_level_syntax...) |
| N-000414 | T | token-level is not empty or incomplete (test_token_level_syntax...) |
| N-000415 | T | zero slice step has its own type (test_zero_slice_step...) |
| N-000416 | T | unknown, arity, type each have a type (test_function_call_failure_kinds) |
| N-000417 | T | invalid-type and arity refusals are not empty or incomplete (test_function_call_failure_kinds) |
| N-000418 | T | other kinds are not instances of the function kinds (test_function_kinds_are_distinct) |
| N-000419 | T | unknown function is not the syntax type (test_function_kinds_are_distinct) |
| N-000420 | T | no refusal of another kind is a function-call kind (test_function_kinds_are_distinct) |
| N-000421 | T | syntax and incomplete carry lex_position (test_syntax_positions...) |
| N-000422 | T | lex_position between 0 and length (test_syntax_positions...) |
| N-000423 | T | bare expression reference searches to non-None (test_expression_reference_searches...) |

Superseded ids (status `X`): N-000022, N-000023, N-000026, N-000028, N-000031, N-000133, N-000157, N-000212, N-000227, N-000259, N-000268.
