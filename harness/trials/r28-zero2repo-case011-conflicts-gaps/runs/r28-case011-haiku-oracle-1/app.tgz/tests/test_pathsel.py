"""Behavioral tests for pathsel, one group per feature point of the spec.

Test names carry the spec ids they cover (see SPEC_COVERAGE.md).
"""

import copy
import collections
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    PathSelTokenError,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile as pcompile,
    search,
)
from pathsel.functions import Functions, signature

DOC = {
    "a": {"b": {"c": 1}},
    "a.b": 5,
    "my key": "spaced",
    "1": "numeric key",
    "people": [
        {"first": "x", "age": 30, "tags": [1, 2]},
        {"first": "y", "age": 10},
        {"first": None, "age": 50},
    ],
    "n": [1, [2, 3], [[4]]],
    "obj": {"k1": 1, "k2": None, "k3": "v"},
    "words": ["a", "bb", "ccc"],
    "café": "unicode key",
}


def s(expr, doc=DOC, options=None):
    return search(expr, doc, options)


# ---- FP-01 search and compile -------------------------------------------

def test_dotted_path_returns_nested_value():  # N-000002 N-000003 N-000077
    assert s("a.b.c") == 1


def test_missing_path_is_null_not_failure():  # N-000003 N-000083 N-000086
    assert s("a.x.y") is None
    assert s("a.b.c.d") is None


def test_compile_then_search_matches_one_shot():  # N-000078 N-000079 N-000080 N-000081
    parsed = pcompile("people[*].first")
    other = {"people": [{"first": "q"}]}
    assert parsed.search(DOC) == s("people[*].first") == ["x", "y"]
    assert parsed.search(other) == ["q"]
    assert parsed.search(DOC) == ["x", "y"]


def test_compile_succeeds_when_search_is_null():  # N-000086
    parsed = pcompile("zzz.yyy")
    assert parsed.search({}) is None


def test_compile_of_unknown_function_succeeds_and_search_refuses():  # N-000264 N-000344
    parsed = pcompile("nope(@)")
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)


def test_search_takes_document_without_mutating_it():  # N-000069 N-000070
    snapshot = copy.deepcopy(DOC)
    s("people[*].{f: first}")
    s("sort_by(people, &age)")
    assert DOC == snapshot


# ---- FP-01 failure kinds --------------------------------------------------

def test_empty_expression_kind():  # N-000087 N-000089
    with pytest.raises(EmptyExpressionError) as info:
        s("")
    assert isinstance(info.value, ValueError)
    assert not isinstance(info.value, IncompleteExpressionError)


@pytest.mark.parametrize("text", [" ", "\t\n\r ", "a |", "a ||", "a &&", "(a", "a[", "a[0", "!", "{a: @", "{a", "[a,", "&"])
def test_incomplete_expression_kind(text):  # N-000090 N-000091 N-000092 N-000093
    with pytest.raises(IncompleteExpressionError) as info:
        s(text)
    assert info.value.lex_position == len(text)


@pytest.mark.parametrize(
    "text",
    [".foo", "foo.", "foo..bar", "foo.1", "foo.-1", "foo.'x'", "foo.`1`", "foo.@", "foo bar", "a)", "foo*", "*foo", "[?]", "a == == b", "{a:1,}", "[a,]", "a.[0]", "@foo", "a[1:2:3:4]", "a[b]", "foo[*]x"],
)
def test_grammar_level_syntax_kind(text):  # N-000094 N-000095 N-000123
    with pytest.raises(PathSelSyntaxError) as info:
        s(text)
    assert type(info.value) is PathSelSyntaxError
    assert 0 <= info.value.lex_position <= len(text)


@pytest.mark.parametrize("text", ["foo-bar", "a=b", "`abc\"", "'abc", '"abc', "a % b", '"a\\x"', '`"a`'])
def test_token_level_syntax_is_a_more_specific_syntax_kind(text):  # N-000096 N-000098 N-000100
    with pytest.raises(PathSelTokenError) as info:
        s(text)
    assert isinstance(info.value, PathSelSyntaxError)
    assert type(info.value) is not PathSelSyntaxError
    assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


def test_syntax_positions_are_offsets_of_failing_token():  # N-000102 N-000103 N-000104
    with pytest.raises(PathSelSyntaxError) as a:
        s("foo bar")
    with pytest.raises(PathSelSyntaxError) as b:
        s("foo..bar")
    assert a.value.lex_position == 4
    assert b.value.lex_position == 4
    with pytest.raises(PathSelTokenError) as c:
        s("ab-c")
    assert c.value.lex_position == 2
    with pytest.raises(IncompleteExpressionError) as d:
        s("foo |")
    assert d.value.lex_position == 5


def test_every_refusal_is_a_value_error():  # N-000405 N-000105
    for text in ["", "a.", "foo-bar", "a[0:1:0]", "nope()", "length()", "length(`1`)"]:
        with pytest.raises(ValueError):
            s(text)


def test_zero_slice_step_is_its_own_kind():  # N-000152 N-000154 N-000415
    with pytest.raises(ZeroSliceStepError) as info:
        s("words[::0]")
    assert not isinstance(info.value, PathSelSyntaxError)
    with pytest.raises(ZeroSliceStepError):
        pcompile("a[1:2:0]")


# ---- FP-02 identifiers ----------------------------------------------------

def test_quoted_identifier_names_one_key_even_with_dot():  # N-000110 N-000111 N-000112
    assert s('"a.b"') == 5
    assert s('"my key"') == "spaced"
    assert s('"1"') == "numeric key"
    assert s('"caf\\u00e9"') == "unicode key"


def test_identifier_on_array_is_null_and_does_not_project():  # N-000115 N-000116
    assert s("words.a") is None
    assert s("people.first") is None


def test_whitespace_between_tokens_is_insignificant():  # N-000109
    assert s("  a \t . \n b . c  ") == 1


def test_quoted_identifier_cannot_be_a_function_name():  # N-000321 N-000322
    with pytest.raises(PathSelSyntaxError):
        s('"length"(words)')


# ---- FP-03 index, slice, flatten -----------------------------------------

def test_index_including_negative_and_out_of_range():  # N-000126 N-000127 N-000128
    assert s("n[0]") == 1
    assert s("n[-1]") == [[4]]
    assert s("n[10]") is None
    assert s("n[-10]") is None


def test_index_on_non_array_is_null():  # N-000129
    assert s("a[0]") is None
    assert s("words.x[0]") is None


def test_slices():  # N-000135 N-000137 N-000138 N-000140 N-000141
    assert s("words[1:]") == ["bb", "ccc"]
    assert s("words[:-1]") == ["a", "bb"]
    assert s("words[::-1]") == ["ccc", "bb", "a"]
    assert s("words[-1:-4:-1]") == ["ccc", "bb", "a"]
    assert s("words[1:0:-1]") == ["bb"]
    assert s("words[5:]") == []
    assert s("words[2:0]") == []


def test_slice_of_non_array_is_null():  # N-000142 (decided per CF-000007)
    assert s("obj[0:2]") is None


def test_flatten_one_level_only():  # N-000145 N-000146 N-000147 N-000148
    assert s("n[]") == [1, 2, 3, [4]]
    assert s("n[][]") == [1, 2, 3, 4]


def test_flatten_of_non_array_is_null():  # N-000147
    assert s("a[]") is None


def test_flatten_with_right_hand_side():  # N-000149
    assert s("n[][0]") == [4]


# ---- FP-04 projections ----------------------------------------------------

def test_list_wildcard_projects_and_drops_nulls():  # N-000159 N-000160 N-000161 N-000204
    assert s("people[*].first") == ["x", "y"]
    assert s("people[*]") == [p for p in DOC["people"]]
    assert s("words[*]") == ["a", "bb", "ccc"]


def test_list_wildcard_on_non_array_is_null():  # N-000162
    assert s("obj[*]") is None
    assert s("missing[*].x") is None


def test_object_wildcard_projects_values():  # N-000163 N-000164
    assert s("obj.*") == [1, "v"]


def test_object_wildcard_on_non_object_is_null():  # N-000165 (CF-000027: FP-04 wins)
    assert s("words.*") is None


def test_filter_projection():  # N-000168 N-000169 N-000170 N-000173
    assert s("people[?age > `20`].first") == ["x"]
    assert s("people[?first]") == [DOC["people"][0], DOC["people"][1]]


def test_filter_on_non_array_is_null():  # N-000202 (CF-000005: FP-04 wins)
    assert s("obj[?@]") is None


def test_projection_nesting():  # N-000166 N-000167
    assert s("people[*].tags[0]") == [1]
    assert s("people[*].tags[]") == [1, 2]


def test_projected_right_hand_side_applies_per_element():  # N-000183 N-000184 N-000191
    assert s("people[*].first[0]") == []  # strings index to null per element, all dropped
    assert s("people[*].tags[1]") == [2]


def test_flatten_is_not_a_right_hand_side_start():  # N-000185 N-000186 N-000199
    assert s("n[][]") == [1, 2, 3, 4]


def test_projection_stops_at_comparator_and_pipe():  # N-000195 N-000196 N-000219
    assert s("people[*].first == 'x'") is False
    assert s("people[*].first | [0]") == "x"


def test_multiselect_as_first_step_of_projection():  # N-000213 N-000214
    assert s("people[*][first, age]") == [["x", 30], ["y", 10], [None, 50]]


def test_projection_dot_chain_continues_right_hand_side():  # N-000192 N-000193
    # .tags.x joins the right-hand side; each tags array has no field x -> all nulls dropped
    assert s("people[*].tags.x") == []


# ---- FP-05 construction, pipe, literals ---------------------------------

def test_multiselect_hash_keeps_null_values():  # N-000206 N-000207 N-000208
    assert s("{x: a.b.c, y: missing}") == {"x": 1, "y": None}


def test_multiselect_list_keeps_nulls():  # N-000211
    assert s("[a.b.c, missing]") == [1, None]


def test_multiselect_on_null_current_value_is_null():  # N-000218
    assert s("missing.[a, b]") is None
    assert s("missing.{x: a}") is None


def test_multiselect_hash_on_projection():  # N-000215 N-000216
    assert s("people[*].{f: first}") == [{"f": "x"}, {"f": "y"}, {"f": None}]


def test_pipe_binds_loosest_and_chains():  # N-000221 N-000222
    assert s("a.b | c") == 1          # a.b is {"c": 1}
    assert s("a | b.c") == 1          # a is {"b": {"c": 1}}
    assert s("a.b | c | @") == 1
    assert s("people[*].first | length(@)") == 2


def test_current_value_token():  # N-000217
    assert s("@.a.b") == {"c": 1}
    assert s("people[*].first | @[0]") == "x"


def test_json_literal_is_read_as_json():  # N-000223
    assert s("`1`") == 1
    assert s("`[1, 2]`") == [1, 2]
    assert s('`{"a": 1}`.a') == 1


def test_json_literal_falls_back_to_string_content():  # N-000224 N-000225
    assert s("`abc`") == "abc"
    assert s("`   abc`") == "abc"


def test_raw_string_literal_rules():  # N-000227 N-000228 N-000229 N-000230
    assert s(r"'it\'s'") == "it's"
    assert s(r"'a\nb'") == "a\\nb"
    assert s("'  keep  '") == "  keep  "
    assert s("'42'") == "42"


def test_raw_string_unicode_escape_decodes():  # N-000239 (CF-000049 decision)
    assert s(r"'é'") == "é"


def test_expression_reference_searches_to_a_non_null_value():  # N-000234 N-000423
    ref = s("&a.b")
    assert ref is not None
    assert ref is not DOC


def test_expression_reference_outside_function_is_not_refused():  # N-000235 N-000236
    assert s("[&a]") is not None


# ---- FP-06 comparisons and logic -------------------------------------------

def test_equality_is_json_equality():  # N-000242 N-000243 N-000244
    assert s("`1` == `1.0`") is True
    assert s("`0` == `false`") is False
    assert s("`1` == `true`") is False
    assert s("`[1, 2]` == `[1, 2]`") is True
    assert s("`{\"a\": 1}` != `{\"a\": 2}`") is True


def test_ordering_numbers_and_strings():  # N-000245 N-000246
    assert s("`1` < `2`") is True
    assert s("'b' >= 'a'") is True
    assert s("'a' < `1`") is None


def test_or_and_return_operands():  # N-000247 N-000248 N-000249 N-000250
    assert s("missing || 'd'") == "d"
    assert s("`0` || 'x'") == 0
    assert s("missing && a") is None
    assert s("a.b && a.b.c") == 1
    assert s("'' || missing") is None


def test_not_truthiness_and_zero():  # N-000251 N-000252
    assert s("!missing") is True
    assert s("!`0`") is False
    assert s("!''") is True
    assert s("!`[]`") is True
    assert s("!`{}`") is True


def test_not_binds_tighter_than_dot_and_comparison():  # N-000253 N-000254 N-000255 N-000256 N-000257
    assert s("!a.b") is None  # parsed as (!a).b; False has no field b
    assert s("!(a.b)") is False
    assert s("!a == `false`") is True  # (!a) == false


def test_parentheses_override_binding():  # N-000257
    assert s("!(missing || `0`)") is False


def test_filter_predicate_uses_same_operators():  # N-000258 N-000259
    assert s("people[?!first].age") == [50]


def test_lone_equals_and_ampersand_refused():  # N-000260 N-000261
    with pytest.raises(PathSelTokenError):
        s("a = b")
    with pytest.raises(IncompleteExpressionError):
        s("a && ")


# ---- FP-07 built-in functions --------------------------------------------

@pytest.mark.parametrize(
    "expr, expected",
    [
        ("abs(`-3`)", 3),
        ("ceil(`1.2`)", 2),
        ("floor(`-1.5`)", -2),
        ("avg(`[1, 2, 3, 4]`)", 2.5),
        ("avg(`[]`)", None),
        ("contains(words, 'bb')", True),
        ("contains('abc', 'b')", True),
        ("contains(words, 'zz')", False),
        ("ends_with('abc', 'c')", True),
        ("starts_with('abc', 'ab')", True),
        ("length(words)", 3),
        ("length('café')", 4),
        ("length(obj)", 3),
        ("reverse(words)", ["ccc", "bb", "a"]),
        ("reverse('abc')", "cba"),
        ("join(', ', words)", "a, bb, ccc"),
        ("join(',', `[]`)", ""),
        ("keys(obj)", ["k1", "k2", "k3"]),
        ("values(obj)", [1, None, "v"]),
        ("type(a)", "object"),
        ("type(`true`)", "boolean"),
        ("type(`1`)", "number"),
        ("type(missing)", "null"),
        ("type('x')", "string"),
        ("type(words)", "array"),
        ("to_array(a.b.c)", [1]),
        ("to_array(words)", ["a", "bb", "ccc"]),
        ("to_string(`{\"a\": 1}`)", '{"a":1}'),
        ("to_string(`[\"é\"]`)", '["\\u00e9"]'),
        ("to_string(`1.0`)", "1.0"),
        ("to_string(`true`)", "true"),
        ("to_string(missing)", "null"),
        ("to_number('42')", 42),
        ("to_number('4.5')", 4.5),
        ("to_number('1e2')", 100.0),
        ("to_number('abc')", None),
        ("to_number(`true`)", None),
        ("max(`[1, 5, 3]`)", 5),
        ("max(`[\"a\", \"c\"]`)", "c"),
        ("max(`[]`)", None),
        ("min(`[1, 5, 3]`)", 1),
        ("sort(`[3, 1, 2]`)", [1, 2, 3]),
        ("sum(`[1, 2.5]`)", 3.5),
        ("sum(`[]`)", 0),
        ("merge(`{\"a\": 1}`, `{\"a\": 2, \"b\": 3}`)", {"a": 2, "b": 3}),
        ("not_null(missing, '', 'x')", ""),
        ("not_null(missing, missing)", None),
        ("map(&first, people)", ["x", "y", None]),
        ("sort_by(people, &age)[*].first", ["y", "x"]),
        ("max_by(people, &age).age", 50),
        ("min_by(people, &age).first", "y"),
        ("max_by(`[]`, &a)", None),
    ],
)
def test_builtin_functions(expr, expected):  # N-000270 .. N-000308
    assert s(expr) == expected


def test_function_call_on_projection_and_argument():  # N-000309 N-000310
    assert s("people[*].first | join('-', @)") == "x-y"


@pytest.mark.parametrize(
    "expr, kind",
    [
        ("length()", InvalidArityError),
        ("not_null()", InvalidArityError),
        ("abs(`1`, `2`)", InvalidArityError),
        ("length(`1`)", InvalidTypeError),
        ("avg(`[\"a\"]`)", InvalidTypeError),
        ("max(`[1, \"a\"]`)", InvalidTypeError),
        ("join(',', `[1]`)", InvalidTypeError),
        ("sort_by(words, &a)", InvalidTypeError),
        ("map(a, words)", InvalidTypeError),
        ("nope(@)", UnknownFunctionError),
    ],
)
def test_function_call_failure_kinds(expr, kind):  # N-000311 .. N-000320
    with pytest.raises(kind) as info:
        s(expr)
    assert isinstance(info.value, PathSelError)
    assert info.value.__class__.__name__ != "PathSelSyntaxError"


def test_function_kinds_are_distinct():  # N-000420
    with pytest.raises(UnknownFunctionError) as info:
        s("nope(@)")
    assert not isinstance(info.value, (InvalidArityError, InvalidTypeError))


def test_count_checked_before_type():  # N-000264 N-000265
    with pytest.raises(InvalidArityError):
        s("length(`1`, `2`)")


def test_function_name_checked_before_count():  # N-000264
    with pytest.raises(UnknownFunctionError):
        s("nope(`1`, `2`)")


def test_array_wildcard_compare_uses_projected_array():  # N-000196 N-000197
    assert s("length(people[*].first)") == 2


def test_function_refuses_at_search_not_compile():  # N-000266
    parsed = pcompile("length(`1`)")
    with pytest.raises(InvalidTypeError):
        parsed.search(DOC)


# ---- FP-08 options and custom functions -----------------------------------

def test_mapping_type_applies_to_constructed_hashes():  # N-000328 N-000329 N-000332
    opts = SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
    result = s("{x: a.b.c}", options=opts)
    assert type(result) is collections.OrderedDict
    assert s("keys({x: a.b.c, y: a.b.c})", options=opts) == ["x", "y"]


def test_custom_function_is_called_with_evaluated_arguments():  # N-000336 N-000337 N-000398

    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["string"]})
        def _func_repeat(self, times, text):
            return text * int(times)

        @signature()
        def _func_zero(self):
            return 0

    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert s("repeat(`2`, 'ab')", options=opts) == "abab"
    assert s("zero()", options=opts) == 0
    assert s("length(words)", options=opts) == 3


def test_custom_function_arity_and_type_refusals():  # N-000345 N-000346 N-000347
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_twice(self, n):
            return n * 2

    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    with pytest.raises(InvalidArityError):
        s("twice(`1`, `2`)", options=opts)
    with pytest.raises(InvalidTypeError):
        s("twice('x')", options=opts)


def test_builtin_name_cannot_be_replaced_by_provider():  # N-000339 N-000340
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_abs(self, n):
            return "replaced"

    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert s("abs(`-3`)", options=opts) == 3


def test_name_on_other_provider_is_unknown():  # N-000344
    class One(Functions):
        @signature()
        def _func_only_here(self):
            return 1

    class Two(Functions):
        pass

    with pytest.raises(UnknownFunctionError):
        s("only_here()", options=SimpleNamespace(dict_cls=None, custom_functions=Two()))
    assert s("only_here()", options=SimpleNamespace(dict_cls=None, custom_functions=One())) == 1


def test_compile_then_search_with_options_matches_one_shot():  # N-000342 N-000343
    opts = SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
    expr = "{x: people[*].first}"
    assert pcompile(expr).search(DOC, opts) == s(expr, options=opts)


def test_provider_custom_function_names_compile_without_provider():  # N-000343
    parsed = pcompile("mine(@)")
    assert parsed is not None


def test_signature_marks_only_decorated_methods():  # N-000403 N-000404 N-000397
    class Provider(Functions):
        def _func_plain(self):
            return 1

    assert not hasattr(Provider._func_plain, "__pathsel_signature__")
    assert hasattr(Functions._func_abs, "__pathsel_signature__")


def test_public_names():  # N-000372 N-000373 N-000367
    assert callable(pathsel.search)
    assert callable(pathsel.compile)
