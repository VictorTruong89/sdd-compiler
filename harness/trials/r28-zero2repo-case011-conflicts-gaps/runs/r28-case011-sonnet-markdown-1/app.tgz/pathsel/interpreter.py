from .errors import (ArityError, InvalidTypeError, UnknownFunctionError)
from .functions import (Expref, Functions, is_array, is_false, is_number,
                        is_object, json_equal, type_matches)

_DEFAULT_FUNCTIONS = Functions()


def _slice(arr, start, stop, step):
    n = len(arr)
    if step is None:
        step = 1
    out = []
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = max(0, min(n, s))
        e = max(0, min(n, e))
        i = s
        while i < e:
            out.append(arr[i])
            i += step
    else:
        s = n - 1 if start is None else (start + n if start < 0 else start)
        e = -1 if stop is None else (stop + n if stop < 0 else stop)
        s = max(-1, min(n - 1, s))
        e = max(-1, min(n - 1, e))
        i = s
        while i > e:
            out.append(arr[i])
            i += step
    return out


class Interpreter(object):
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) if options is not None else None
        provider = getattr(options, "custom_functions", None) if options is not None else None
        self.provider = provider if provider is not None else _DEFAULT_FUNCTIONS

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_current(self, node, value):
        return value

    def v_field(self, node, value):
        if is_object(value, self.dict_cls):
            try:
                return value[node[1]]
            except (KeyError, IndexError, TypeError):
                return None
        return None

    def v_subexpr(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_pipe(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_index(self, node, value):
        if not is_array(value):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if not is_array(value):
            return None
        return _slice(value, node[1], node[2], node[3])

    def v_literal(self, node, value):
        return node[1]

    def _collect(self, items, rhs):
        out = []
        for el in items:
            r = self.visit(rhs, el)
            if r is not None:
                out.append(r)
        return out

    def v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        return self._collect(base, node[2])

    def v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_object(base, self.dict_cls):
            return None
        return self._collect(list(base.values()), node[2])

    def v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        kept = [el for el in base if not is_false(self.visit(node[3], el))]
        return self._collect(kept, node[2])

    def v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if is_array(el):
                out.extend(el)
            else:
                out.append(el)
        return out

    def v_or(self, node, value):
        left = self.visit(node[1], value)
        if not is_false(left):
            return left
        return self.visit(node[2], value)

    def v_and(self, node, value):
        left = self.visit(node[1], value)
        if is_false(left):
            return left
        return self.visit(node[2], value)

    def v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def v_compare(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return json_equal(a, b)
        if op == "ne":
            return not json_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def v_multilist(self, node, value):
        if value is None:
            return None
        return [self.visit(n, value) for n in node[1]]

    def v_multihash(self, node, value):
        if value is None:
            return None
        d = self.dict_cls() if self.dict_cls is not None else {}
        for k, n in node[1]:
            d[k] = self.visit(n, value)
        return d

    def v_expref(self, node, value):
        return Expref(node[1], self)

    def v_function(self, node, value):
        name, argnodes = node[1], node[2]
        func = getattr(self.provider, "_func_" + name, None)
        sig = getattr(func, "signature", None) if func is not None else None
        if func is None or sig is None:
            raise UnknownFunctionError("Unknown function: %s" % name)
        n = len(argnodes)
        variadic = bool(sig) and bool(sig[-1].get("variadic"))
        if (n < len(sig)) if variadic else (n != len(sig)):
            raise ArityError("Invalid arity for %s" % name)
        args = [self.visit(a, value) for a in argnodes]
        for i, a in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not type_matches(a, spec, self.dict_cls):
                raise InvalidTypeError("Invalid type for argument %d of %s" % (i + 1, name))
        return func(*args)
