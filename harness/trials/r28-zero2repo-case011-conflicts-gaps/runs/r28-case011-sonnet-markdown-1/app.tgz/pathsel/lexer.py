import json
import re

from .errors import TokenSyntaxError

WS = " \t\n\r"
_IDSTART = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDCHARS = _IDSTART | set("0123456789")
_DIGITS = set("0123456789")
_PAIR = re.compile(r"\\u([dD][89abAB][0-9a-fA-F]{2})\\u([dD][c-fC-F][0-9a-fA-F]{2})")
_U = re.compile(r"\\u([0-9a-fA-F]{4})")

SINGLE = {
    ".": "dot", "*": "star", "]": "rbracket", ",": "comma", ":": "colon",
    "@": "current", "(": "lparen", ")": "rparen", "{": "lbrace", "}": "rbrace",
}


def _bad_const(name):
    raise ValueError(name)


def _raw_string(text):
    text = text.replace("\\'", "'")

    def pair(m):
        hi = int(m.group(1), 16)
        lo = int(m.group(2), 16)
        return chr(0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00))

    text = _PAIR.sub(pair, text)
    return _U.sub(lambda m: chr(int(m.group(1), 16)), text)


def tokenize(expr):
    """Return list of (type, value, position); last is ('eof', None, len)."""
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        if c in WS:
            i += 1
        elif c in _IDSTART:
            j = i + 1
            while j < n and expr[j] in _IDCHARS:
                j += 1
            tokens.append(("unquoted", expr[i:j], i))
            i = j
        elif c in _DIGITS or c == "-":
            j = i + 1
            if c == "-" and not (j < n and expr[j] in _DIGITS):
                raise TokenSyntaxError("Unknown token '-'", i)
            while j < n and expr[j] in _DIGITS:
                j += 1
            tokens.append(("number", int(expr[i:j]), i))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and expr[j] != '"':
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise TokenSyntaxError("Unterminated quoted identifier", i)
            try:
                val = json.loads(expr[i:j + 1])
            except ValueError:
                raise TokenSyntaxError("Invalid quoted identifier", i)
            tokens.append(("quoted", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and expr[j] != "'":
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise TokenSyntaxError("Unterminated raw string", i)
            tokens.append(("literal", _raw_string(expr[i + 1:j]), i))
            i = j + 1
        elif c == "`":
            j = i + 1
            while j < n and expr[j] != "`":
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise TokenSyntaxError("Unterminated literal", i)
            text = expr[i + 1:j].replace("\\`", "`")
            try:
                val = json.loads(text, parse_constant=_bad_const)
            except ValueError:
                try:
                    val = json.loads('"%s"' % text.lstrip())
                except ValueError:
                    raise TokenSyntaxError("Invalid literal", i)
            tokens.append(("literal", val, i))
            i = j + 1
        elif c == "[":
            nxt = expr[i + 1] if i + 1 < n else ""
            if nxt == "]":
                tokens.append(("flatten", "[]", i))
                i += 2
            elif nxt == "?":
                tokens.append(("filter", "[?", i))
                i += 2
            else:
                tokens.append(("lbracket", "[", i))
                i += 1
        elif c in SINGLE:
            tokens.append((SINGLE[c], c, i))
            i += 1
        elif c in "|&":
            if i + 1 < n and expr[i + 1] == c:
                tokens.append(("or" if c == "|" else "and", c * 2, i))
                i += 2
            else:
                tokens.append(("pipe" if c == "|" else "expref", c, i))
                i += 1
        elif c in "<>!=":
            if i + 1 < n and expr[i + 1] == "=":
                t = {"<": "lte", ">": "gte", "!": "ne", "=": "eq"}[c]
                tokens.append((t, c + "=", i))
                i += 2
            elif c == "=":
                raise TokenSyntaxError("Unknown token '='", i)
            else:
                tokens.append(({"<": "lt", ">": "gt", "!": "not"}[c], c, i))
                i += 1
        else:
            raise TokenSyntaxError("Unknown token %r" % c, i)
    tokens.append(("eof", None, n))
    return tokens
