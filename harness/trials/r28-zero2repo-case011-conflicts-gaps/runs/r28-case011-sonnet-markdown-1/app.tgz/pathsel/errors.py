"""Failure kinds. Every refusal is a ValueError."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    pass


class IncompleteExpressionError(PathSelError):
    def __init__(self, message, lex_position):
        PathSelError.__init__(self, message)
        self.lex_position = lex_position


class PathSelSyntaxError(PathSelError):
    def __init__(self, message, lex_position):
        PathSelError.__init__(self, message)
        self.lex_position = lex_position


class TokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure (subclass of the syntax kind)."""


class ZeroStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
