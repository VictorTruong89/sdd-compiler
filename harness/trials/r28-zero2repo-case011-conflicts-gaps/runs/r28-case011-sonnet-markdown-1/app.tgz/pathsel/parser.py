from .errors import (EmptyExpressionError, IncompleteExpressionError,
                     PathSelSyntaxError, ZeroStepError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted": 0, "quoted": 0, "literal": 0, "rbracket": 0,
    "rparen": 0, "comma": 0, "rbrace": 0, "number": 0, "current": 0,
    "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3, "eq": 5, "gt": 5,
    "lt": 5, "gte": 5, "lte": 5, "ne": 5, "flatten": 9, "star": 20,
    "filter": 21, "dot": 40, "not": 45, "lbrace": 50, "lbracket": 55,
    "lparen": 60,
}
COMPARATORS = ("eq", "ne", "lt", "lte", "gt", "gte")
IDENTITY = ("current",)


class Parser(object):
    def __init__(self, expr):
        self.expr = expr
        self.tokens = tokenize(expr)
        self.pos = 0

    # helpers
    def peek(self, k=0):
        i = min(self.pos + k, len(self.tokens) - 1)
        return self.tokens[i]

    def advance(self):
        t = self.tokens[self.pos]
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return t

    def fail(self, tok, force_syntax=False):
        if tok[0] == "eof" and not force_syntax:
            raise IncompleteExpressionError("Incomplete expression", tok[2])
        raise PathSelSyntaxError("Syntax error near %r" % (tok[1],), tok[2])

    def match(self, ttype):
        t = self.peek()
        if t[0] != ttype:
            self.fail(t)
        return self.advance()

    def parse(self):
        if self.expr == "":
            raise EmptyExpressionError("Empty expression")
        node = self.expression(0)
        t = self.peek()
        if t[0] != "eof":
            self.fail(t)
        return node

    def expression(self, bp):
        left = self.nud(self.advance())
        while bp < BP[self.peek()[0]]:
            tok = self.advance()
            led = getattr(self, "led_" + tok[0], None)
            if led is None:
                self.fail(tok)
            left = led(left, tok)
        return left

    # null denotations
    def nud(self, tok):
        tt = tok[0]
        if tt == "unquoted":
            if self.peek()[0] == "lparen":
                return self.function(tok)
            return ("field", tok[1])
        if tt == "quoted":
            return ("field", tok[1])
        if tt == "literal":
            return ("literal", tok[1])
        if tt == "current":
            return IDENTITY
        if tt == "star":
            return self.value_projection(IDENTITY)
        if tt == "flatten":
            return self.flatten(IDENTITY)
        if tt == "filter":
            return self.filter_projection(IDENTITY)
        if tt == "lbrace":
            return self.multiselect_hash()
        if tt == "lparen":
            e = self.expression(0)
            self.match("rparen")
            return e
        if tt == "not":
            return ("not", self.expression(BP["not"]))
        if tt == "expref":
            return ("expref", self.expression(0))
        if tt == "lbracket":
            nt = self.peek()[0]
            if nt in ("number", "colon"):
                return self.index_expr(IDENTITY)
            if nt == "star" and self.peek(1)[0] == "rbracket":
                self.advance()
                self.advance()
                return ("projection", IDENTITY, self.proj_rhs(BP["star"]))
            return self.multiselect_list()
        self.fail(tok)

    def function(self, tok):
        self.advance()  # lparen
        args = []
        if self.peek()[0] != "rparen":
            while True:
                args.append(self.expression(0))
                if self.peek()[0] == "comma":
                    self.advance()
                else:
                    break
        self.match("rparen")
        return ("function", tok[1], args)

    def multiselect_list(self):
        items = []
        while True:
            items.append(self.expression(0))
            if self.peek()[0] == "comma":
                self.advance()
            else:
                break
        self.match("rbracket")
        return ("multilist", items)

    def multiselect_hash(self):
        pairs = []
        while True:
            k = self.peek()
            if k[0] not in ("unquoted", "quoted"):
                self.fail(k)
            self.advance()
            self.match("colon")
            pairs.append((k[1], self.expression(0)))
            if self.peek()[0] == "comma":
                self.advance()
            else:
                break
        self.match("rbrace")
        return ("multihash", pairs)

    # projections
    def proj_rhs(self, bp):
        nt = self.peek()[0]
        if BP[nt] < 10:
            return IDENTITY
        if nt in ("lbracket", "filter"):
            return self.expression(bp)
        if nt == "dot":
            self.advance()
            return self.dot_rhs(bp)
        self.fail(self.peek())

    def value_projection(self, left):
        return ("value_projection", left, self.proj_rhs(BP["star"]))

    def flatten(self, left):
        return ("projection", ("flatten", left), self.proj_rhs(BP["flatten"]))

    def filter_projection(self, left):
        cond = self.expression(0)
        self.match("rbracket")
        return ("filter_projection", left, self.proj_rhs(BP["filter"]), cond)

    def index_expr(self, left):
        # positioned after '[' at a number or colon
        parts = [None]
        colons = 0
        while True:
            t = self.peek()
            if t[0] == "number" and parts[-1] is None and len(parts) == colons + 1:
                parts[-1] = t[1]
                self.advance()
            elif t[0] == "colon":
                colons += 1
                if colons > 2:
                    self.fail(t)
                parts.append(None)
                self.advance()
            elif t[0] == "rbracket":
                self.advance()
                break
            else:
                self.fail(t)
        if colons == 0:
            return ("subexpr", left, ("index", parts[0]))
        if len(parts) > 2 and parts[2] == 0:
            raise ZeroStepError("Slice step cannot be 0")
        while len(parts) < 3:
            parts.append(None)
        node = ("subexpr", left, ("slice", parts[0], parts[1], parts[2]))
        return ("projection", node, self.proj_rhs(BP["star"]))

    # leds
    def dot_rhs(self, bp):
        t = self.peek()
        if t[0] in ("unquoted", "quoted", "star"):
            return self.expression(bp)
        if t[0] == "lbracket":
            self.advance()
            return self.multiselect_list()
        if t[0] == "lbrace":
            self.advance()
            return self.multiselect_hash()
        self.fail(t, force_syntax=True)

    def led_dot(self, left, tok):
        if self.peek()[0] == "star":
            self.advance()
            return self.value_projection(left)
        return ("subexpr", left, self.dot_rhs(BP["dot"]))

    def led_pipe(self, left, tok):
        return ("pipe", left, self.expression(BP["pipe"]))

    def led_or(self, left, tok):
        return ("or", left, self.expression(BP["or"]))

    def led_and(self, left, tok):
        return ("and", left, self.expression(BP["and"]))

    def _cmp(self, left, tok):
        return ("compare", tok[0], left, self.expression(BP[tok[0]]))

    led_eq = led_ne = led_lt = led_lte = led_gt = led_gte = _cmp

    def led_flatten(self, left, tok):
        return self.flatten(left)

    def led_filter(self, left, tok):
        return self.filter_projection(left)

    def led_lbracket(self, left, tok):
        t = self.peek()
        if t[0] in ("number", "colon"):
            return self.index_expr(left)
        if t[0] == "star" and self.peek(1)[0] == "rbracket":
            self.advance()
            self.advance()
            return ("projection", left, self.proj_rhs(BP["star"]))
        self.fail(t)


def parse(expr):
    return Parser(expr).parse()
