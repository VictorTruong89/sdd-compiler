import functools
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError


class Expref(object):
    """Value of an expression reference."""

    def __init__(self, node, interpreter):
        self.node = node
        self.interpreter = interpreter

    def visit(self, value):
        return self.interpreter.visit(self.node, value)


def is_number(x):
    return isinstance(x, (int, float, Decimal)) and not isinstance(x, bool)


def is_array(x):
    return isinstance(x, (list, tuple))


def is_object(x, dict_cls=None):
    if isinstance(x, Mapping):
        return True
    return dict_cls is not None and isinstance(x, dict_cls)


def is_false(x):
    if x is None or x is False:
        return True
    if isinstance(x, (str, list, tuple)):
        return len(x) == 0
    if isinstance(x, Mapping):
        return len(x) == 0
    return False


def json_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_array(a):
        return (is_array(b) and len(a) == len(b)
                and all(json_equal(x, y) for x, y in zip(a, b)))
    if isinstance(a, Mapping):
        if not isinstance(b, Mapping) or len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_equal(a[k], b[k]):
                return False
        return True
    if is_array(b) or isinstance(b, Mapping):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


_TYPE_CHECKS = {
    "number": lambda v, d: is_number(v),
    "string": lambda v, d: isinstance(v, str),
    "array": lambda v, d: is_array(v),
    "object": lambda v, d: is_object(v, d),
    "null": lambda v, d: v is None,
    "boolean": lambda v, d: isinstance(v, bool),
    "any": lambda v, d: True,
    "expref": lambda v, d: isinstance(v, Expref),
    "array-number": lambda v, d: is_array(v) and all(is_number(e) for e in v),
    "array-string": lambda v, d: is_array(v) and all(isinstance(e, str) for e in v),
}


def type_matches(value, spec, dict_cls=None):
    for t in spec.get("types", []):
        check = _TYPE_CHECKS.get(t)
        if check is not None and check(value, dict_cls):
            return True
    return False


def signature(*arguments):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        wrapper.signature = list(arguments)
        return wrapper
    return decorator


def _spec(*types, **kw):
    d = {"types": list(types)}
    d.update(kw)
    return d


_NUM_STR_ARRAY = _spec("array-number", "array-string")
_NUMERIC = re.compile(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")
_INT = re.compile(r"^[+-]?\d+$")


def _json_default(o):
    if isinstance(o, Mapping):
        return dict(o)
    return str(o)


def _key_check(keys):
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise InvalidTypeError("invalid key type")


class Functions(object):
    @signature(_spec("number"))
    def _func_abs(self, a):
        return abs(a)

    @signature(_spec("array-number"))
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature(_spec("number"))
    def _func_ceil(self, a):
        return math.ceil(a)

    @signature(_spec("number"))
    def _func_floor(self, a):
        return math.floor(a)

    @signature(_spec("array", "string"), _spec("any"))
    def _func_contains(self, subject, item):
        if isinstance(subject, str):
            return isinstance(item, str) and item in subject
        return any(json_equal(e, item) for e in subject)

    @signature(_spec("string"), _spec("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_spec("string"), _spec("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_spec("string", "array", "object"))
    def _func_length(self, a):
        return len(a)

    @signature(_spec("array", "string"))
    def _func_reverse(self, a):
        if isinstance(a, str):
            return a[::-1]
        return list(reversed(a))

    @signature(_spec("string"), _spec("array-string"))
    def _func_join(self, sep, arr):
        if not arr:
            return ""
        return sep.join(arr)

    @signature(_spec("object"))
    def _func_keys(self, o):
        return list(o.keys())

    @signature(_spec("object"))
    def _func_values(self, o):
        return list(o.values())

    @signature(_spec("any"))
    def _func_type(self, a):
        if a is None:
            return "null"
        if isinstance(a, bool):
            return "boolean"
        if isinstance(a, str):
            return "string"
        if is_number(a):
            return "number"
        if is_array(a):
            return "array"
        if isinstance(a, Mapping):
            return "object"
        raise InvalidTypeError("not a JSON value")

    @signature(_spec("any"))
    def _func_to_array(self, a):
        if is_array(a):
            return list(a) if isinstance(a, tuple) else a
        return [a]

    @signature(_spec("any"))
    def _func_to_string(self, a):
        if isinstance(a, str):
            return a
        return json.dumps(a, separators=(",", ":"), ensure_ascii=True,
                          default=_json_default)

    @signature(_spec("any"))
    def _func_to_number(self, a):
        if is_number(a):
            return a
        if isinstance(a, str):
            if _INT.match(a):
                return int(a)
            if _NUMERIC.match(a):
                return float(a)
        return None

    @signature(_NUM_STR_ARRAY)
    def _func_max(self, a):
        return max(a) if a else None

    @signature(_NUM_STR_ARRAY)
    def _func_min(self, a):
        return min(a) if a else None

    @signature(_NUM_STR_ARRAY)
    def _func_sort(self, a):
        return sorted(a)

    @signature(_spec("array-number"))
    def _func_sum(self, a):
        return sum(a)

    @signature(_spec("object"), _spec("object", variadic=True))
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k, v in o.items():
                out[k] = v
        return out

    @signature(_spec("any"), _spec("any", variadic=True))
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_spec("expref"), _spec("array"))
    def _func_map(self, ref, arr):
        return [ref.visit(x) for x in arr]

    @signature(_spec("array"), _spec("expref"))
    def _func_sort_by(self, arr, ref):
        keyed = [(ref.visit(x), x) for x in arr]
        _key_check([k for k, _ in keyed])
        keyed.sort(key=lambda p: p[0])
        return [x for _, x in keyed]

    def _extreme(self, arr, ref, sign):
        if not arr:
            return None
        keyed = [(ref.visit(x), x) for x in arr]
        _key_check([k for k, _ in keyed])
        best = keyed[0]
        for item in keyed[1:]:
            if (item[0] > best[0]) if sign > 0 else (item[0] < best[0]):
                best = item
        return best[1]

    @signature(_spec("array"), _spec("expref"))
    def _func_max_by(self, arr, ref):
        return self._extreme(arr, ref, 1)

    @signature(_spec("array"), _spec("expref"))
    def _func_min_by(self, arr, ref):
        return self._extreme(arr, ref, -1)
