"""PathSel: declarative JSON path expressions."""
from .errors import (ArityError, EmptyExpressionError, IncompleteExpressionError,
                     InvalidTypeError, PathSelError, PathSelSyntaxError,
                     TokenSyntaxError, UnknownFunctionError, ZeroStepError)
from .interpreter import Interpreter
from .parser import parse

__all__ = ["search", "compile", "ParsedExpression"]


class ParsedExpression(object):
    def __init__(self, expression):
        self.expression = expression
        self._ast = parse(expression)

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)


def compile(expression):
    return ParsedExpression(expression)


def search(expression, data, options=None):
    return compile(expression).search(data, options)
