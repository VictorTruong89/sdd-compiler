"""Pytest anchor for the flat layout.

Pytest inserts the directory that holds this file into ``sys.path``, so the
importable ``pathsel`` package at the project root is found when the tests are
run from any working directory. It has no other effect.
"""
