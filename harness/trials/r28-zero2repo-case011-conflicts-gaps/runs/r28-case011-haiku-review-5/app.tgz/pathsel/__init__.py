"""pathsel: evaluate PathSel expressions against ordinary Python data.

Two equivalent entries:

* ``search(expression, data, options=None)`` evaluates in one shot.
* ``compile(expression)`` parses once; the returned object's
  ``search(data, options=None)`` evaluates the parsed expression.

Both return the selected value (``None`` for a missing path) or raise a
``ValueError`` subclass for a refusal.
"""

from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .parser import parse as _parse
from .runtime import Context, ExpressionReference, Options

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Options",
    "ExpressionReference",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


class ParsedExpression:
    """A compiled expression; searching it matches the one-shot ``search``."""

    __slots__ = ("expression", "_root")

    def __init__(self, expression, root):
        self.expression = expression
        self._root = root

    def search(self, value, options=None):
        return self._root.evaluate(value, Context.from_options(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    """Parse ``expression`` once and return a ParsedExpression, or raise."""
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` and return the selected value."""
    return compile(expression).search(data, options)
