"""Pratt parser for PathSel expressions.

Binding powers (loosest to tightest):
  pipe 1, or 2, and 3, comparators 5, flatten 9, list/object wildcard 20,
  filter 21, dot 40, not 45, multiselect hash 50, index/slice/wildcard bracket 55,
  function call 60.

A projection's right-hand side is parsed with the projection's own binding
power, and any step that is not tighter ends it (see ``_projection_rhs``).
"""

from . import nodes as N
from .exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailure,
    ZeroSliceStepError,
)
from .lexer import Lexer

_CMP = {
    "eq": "==",
    "ne": "!=",
    "lt": "<",
    "lte": "<=",
    "gt": ">",
    "gte": ">=",
}

BP_FLATTEN = 9
BP_PROJECTION_STOP = 10
BP_WILDCARD = 20
BP_FILTER = 21
BP_DOT = 40
BP_NOT = 45
BP_HASH = 50
BP_BRACKET = 55


def _unexpected(tok):
    """Raise for a token where an operand or a closing token was required."""
    if tok.kind == "eof":
        raise IncompleteExpressionError(
            "expression ends before it is complete at position %d" % tok.pos, tok.pos)
    raise SyntaxFailure("unexpected token at position %d" % tok.pos, tok.pos)


def _syntax(tok, reason):
    raise SyntaxFailure("%s at position %d" % (reason, tok.pos), tok.pos)


def _chain(left, node):
    """Chain ``node`` after ``left``, extending an existing chain in place."""
    if isinstance(left, N.Chain):
        left.steps.append(node)
        return left
    return N.Chain([left, node])


def _apply(left, node):
    """Chain ``node`` after ``left``; an identity left needs no chaining."""
    if isinstance(left, N.Identity):
        return node
    return _chain(left, node)


class Parser:
    def __init__(self, text):
        self._lexer = Lexer(text)
        self._buffer = []

    # -- token access -----------------------------------------------------

    def _tok(self, k=0):
        while len(self._buffer) <= k:
            self._buffer.append(self._lexer.next())
        return self._buffer[k]

    def _advance(self):
        tok = self._tok(0)
        self._buffer.pop(0)
        return tok

    def _expect(self, kind):
        tok = self._tok(0)
        if tok.kind == kind:
            return self._advance()
        _unexpected(tok)

    def _lbp(self, tok):
        """Binding power of a token in the loop; 0 means 'does not continue'."""
        kind = tok.kind
        if kind == "pipe":
            return 1
        if kind == "or":
            return 2
        if kind == "and":
            return 3
        if kind in _CMP:
            return 5
        if kind == "dot":
            return 40
        if kind == "lbracket":
            nxt = self._tok(1).kind
            if nxt == "rbracket":
                return BP_FLATTEN
            if nxt == "question":
                return BP_FILTER
            return BP_BRACKET
        if kind == "star":
            return BP_WILDCARD
        if kind == "lbrace":
            return BP_HASH
        if kind == "lparen":
            return 60
        return 0

    # -- Pratt core -------------------------------------------------------

    def _loop(self, left, bp):
        while bp < self._lbp(self._tok(0)):
            left = self._led(left)
        return left

    def _expr(self, bp=0):
        tok = self._advance()
        return self._loop(self._nud(tok), bp)

    def _nud(self, tok):
        kind = tok.kind
        if kind == "ident":
            if self._tok(0).kind == "lparen":
                self._advance()
                return self._call(tok.value)
            return N.Field(tok.value)
        if kind == "qident":
            return N.Field(tok.value)
        if kind == "literal":
            return N.Literal(tok.value)
        if kind == "at":
            return N.Identity()
        if kind == "star":
            return N.ValueProjection(N.Identity(), self._projection_rhs(BP_WILDCARD))
        if kind == "not":
            return N.Not(self._expr(BP_NOT))
        if kind == "amp":
            return N.ExpRef(self._expr(0))
        if kind == "lparen":
            inner = self._expr(0)
            self._expect("rparen")
            return inner
        if kind == "lbracket":
            return self._nud_bracket()
        if kind == "lbrace":
            return self._multi_hash()
        _unexpected(tok)

    def _led(self, left):
        tok = self._advance()
        kind = tok.kind
        if kind == "pipe":
            return _chain(left, self._expr(1))
        if kind == "or":
            return N.Or(left, self._expr(2))
        if kind == "and":
            return N.And(left, self._expr(3))
        if kind in _CMP:
            return N.Compare(_CMP[kind], left, self._expr(5))
        if kind == "dot":
            return self._dot_led(left)
        if kind == "lbracket":
            nxt = self._tok(0)
            if nxt.kind == "rbracket":
                self._advance()
                return N.Projection(N.Flatten(left), self._projection_rhs(BP_FLATTEN))
            if nxt.kind == "question":
                self._advance()
                return self._filter_rest(left)
            return self._bracket_led(left)
        _syntax(tok, "syntax error")

    # -- right-hand sides and steps --------------------------------------

    def _projection_rhs(self, bp):
        """Right-hand side of a projection-starting form.

        The first step directly after the form always begins the right-hand
        side. Later steps are taken by the caller's loop only when they bind
        tighter than ``bp``; here the caller only gets identity when the next
        token cannot start a step at all.
        """
        tok = self._tok(0)
        if self._lbp(tok) < BP_PROJECTION_STOP:
            return N.Identity()
        if tok.kind == "lbracket":
            return self._expr(bp)
        if tok.kind == "dot":
            self._advance()
            return self._dot_body(bp)
        _syntax(tok, "projection must be followed by a dot, a bracket, a filter, a flatten, "
                     "a pipe, an operator, a comma, a closing token or the end")

    def _dot_led(self, left):
        if self._tok(0).kind == "star":
            self._advance()
            return N.ValueProjection(left, self._projection_rhs(BP_DOT))
        return _chain(left, self._dot_body(BP_DOT))

    def _dot_body(self, bp):
        """Parse what follows a dot: identifier, wildcard, multiselect list or hash."""
        tok = self._tok(0)
        kind = tok.kind
        if kind in ("ident", "qident", "star", "lbrace"):
            return self._expr(bp)
        if kind == "lbracket":
            nxt = self._tok(1).kind
            if nxt in ("number", "colon", "rbracket", "question"):
                _syntax(tok, "a dot may not be followed by an index, slice, flatten or filter")
            if nxt == "star" and self._tok(2).kind == "rbracket":
                _syntax(tok, "a dot may not be followed by a list wildcard")
            self._advance()
            return self._loop(self._multi_list(), bp)
        _syntax(tok, "a dot must be followed by an identifier, a wildcard, a multiselect list or hash")

    def _nud_bracket(self):
        """A '[' that starts an operand (the '[' is already consumed)."""
        tok = self._tok(0)
        kind = tok.kind
        if kind in ("number", "colon"):
            return self._index_or_slice(N.Identity())
        if kind == "star" and self._tok(1).kind == "rbracket":
            self._advance()
            self._advance()
            return N.Projection(N.Identity(), self._projection_rhs(BP_WILDCARD))
        if kind == "rbracket":
            self._advance()
            return N.Projection(N.Flatten(N.Identity()), self._projection_rhs(BP_FLATTEN))
        if kind == "question":
            self._advance()
            return self._filter_rest(N.Identity())
        return self._multi_list()

    def _bracket_led(self, left):
        """A '[' that follows an operand: index, slice or list wildcard."""
        tok = self._tok(0)
        kind = tok.kind
        if kind in ("number", "colon"):
            return self._index_or_slice(left)
        if kind == "star":
            self._advance()
            self._expect("rbracket")
            return N.Projection(left, self._projection_rhs(BP_WILDCARD))
        _unexpected(tok)

    def _index_or_slice(self, left):
        """Parse the inside of an index or slice; the '[' is consumed, the ']' too."""
        parts = [None]
        is_slice = False
        while True:
            tok = self._tok(0)
            kind = tok.kind
            if kind == "number":
                if parts[-1] is not None:
                    _syntax(tok, "two integers in one slice part")
                parts[-1] = tok.value
                self._advance()
            elif kind == "colon":
                if len(parts) >= 3:
                    _syntax(tok, "a slice has at most three parts")
                parts.append(None)
                is_slice = True
                self._advance()
            elif kind == "rbracket":
                self._advance()
                break
            else:
                _unexpected(tok)
        if not is_slice:
            return _apply(left, N.Index(parts[0]))
        parts = parts + [None] * (3 - len(parts))
        start, stop, step = parts
        if step == 0:
            raise ZeroSliceStepError("a slice step of 0 selects nothing and is refused")
        return N.Projection(_apply(left, N.Slice(start, stop, step)),
                            self._projection_rhs(BP_WILDCARD))

    def _filter_rest(self, left):
        """A filter after '[?' has been consumed."""
        predicate = self._expr(0)
        self._expect("rbracket")
        return N.Projection(N.Filter(left, predicate), self._projection_rhs(BP_FILTER))

    # -- constructors and calls ------------------------------------------

    def _multi_list(self):
        """Multiselect list; the '[' is consumed, the ']' is consumed here."""
        items = []
        while True:
            items.append(self._expr(0))
            tok = self._tok(0)
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rbracket":
                self._advance()
                return N.MultiList(items)
            _unexpected(tok)

    def _multi_hash(self):
        """Multiselect hash; the '{' is consumed, the '}' is consumed here."""
        pairs = []
        while True:
            tok = self._tok(0)
            if tok.kind not in ("ident", "qident"):
                _unexpected(tok)
            self._advance()
            self._expect("colon")
            pairs.append((tok.value, self._expr(0)))
            tok = self._tok(0)
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rbrace":
                self._advance()
                return N.MultiHash(pairs)
            _unexpected(tok)

    def _call(self, name):
        """Argument list of a function call; the '(' is consumed."""
        args = []
        if self._tok(0).kind == "rparen":
            self._advance()
            return N.Function(name, args)
        while True:
            args.append(self._expr(0))
            tok = self._tok(0)
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rparen":
                self._advance()
                return N.Function(name, args)
            _unexpected(tok)


def parse(text):
    """Parse expression text into a node tree, or raise a refusal."""
    if text == "":
        raise EmptyExpressionError("the expression is empty")
    parser = Parser(text)
    root = parser._expr(0)
    tok = parser._tok(0)
    if tok.kind != "eof":
        _syntax(tok, "a token is left over after a complete expression")
    return root
