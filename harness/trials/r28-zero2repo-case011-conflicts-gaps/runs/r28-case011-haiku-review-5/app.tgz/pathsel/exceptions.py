"""Refusal types for pathsel.

Every refusal is a ``ValueError``. The kind of a refusal is carried by the
type of the raised exception (see Interface Contract, "Failure carriers").
"""


class PathSelError(ValueError):
    """Base class of every refusal raised by pathsel."""


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class SyntaxFailure(PathSelError):
    """Grammar-level syntax failure (text split into valid tokens that do not
    form a well-formed expression)."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxFailure(SyntaxFailure):
    """Token-level syntax failure: a more specific form of SyntaxFailure."""


class ZeroSliceStepError(PathSelError):
    """A slice was written with a step of 0."""


class UnknownFunctionError(PathSelError):
    """A function name is neither built-in nor supplied by the provider."""


class InvalidArityError(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument is outside its accepted types."""


__all__ = [
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
