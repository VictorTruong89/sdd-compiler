"""Lazy tokenizer for PathSel expression text.

Tokens are produced one at a time so that a token-level failure is reported
when the parser reaches it, in left-to-right order.
"""

import json

from .exceptions import TokenSyntaxFailure

_WHITESPACE = frozenset(" \t\n\r")
_IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_DIGITS = frozenset("0123456789")
_IDENT_PART = _IDENT_START | _DIGITS
_HEX = frozenset("0123456789abcdefABCDEF")
_JSON_WS = " \t\n\r"

_SINGLE = {
    ".": "dot",
    "*": "star",
    "[": "lbracket",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    "@": "at",
    "?": "question",
    "|": "pipe",
    "&": "amp",
    "!": "not",
    "<": "lt",
    ">": "gt",
}

_DOUBLE = {
    "||": "or",
    "&&": "and",
    "==": "eq",
    "!=": "ne",
    "<=": "lte",
    ">=": "gte",
}


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.kind, self.value, self.pos)


def _is_hex4(text):
    return len(text) == 4 and all(c in _HEX for c in text)


class Lexer:
    def __init__(self, text):
        self._text = text
        self._n = len(text)
        self._pos = 0

    def _fail(self, message, pos):
        raise TokenSyntaxFailure("%s at position %d" % (message, pos), pos)

    def next(self):
        text, n = self._text, self._n
        i = self._pos
        while i < n and text[i] in _WHITESPACE:
            i += 1
        if i >= n:
            self._pos = n
            return Token("eof", None, n)

        ch = text[i]
        if ch in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_PART:
                j += 1
            self._pos = j
            return Token("ident", text[i:j], i)

        if ch in _DIGITS or (ch == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            self._pos = j
            return Token("number", int(text[i:j]), i)

        if ch == '"':
            return self._quoted_identifier(i)
        if ch == "'":
            return self._raw_string(i)
        if ch == "`":
            return self._json_literal(i)

        two = text[i:i + 2]
        if two in _DOUBLE:
            self._pos = i + 2
            return Token(_DOUBLE[two], None, i)
        if ch in _SINGLE:
            self._pos = i + 1
            return Token(_SINGLE[ch], None, i)

        if ch == "-":
            self._fail("a hyphen begins no token", i)
        if ch == "=":
            self._fail("a lone '=' begins no token", i)
        self._fail("character %r begins no token" % ch, i)

    def _quoted_identifier(self, start):
        text, n = self._text, self._n
        i = start + 1
        while True:
            if i >= n:
                self._fail("unterminated quoted identifier", start)
            c = text[i]
            if c == "\\":
                i += 2
            elif c == '"':
                break
            else:
                i += 1
        raw = text[start:i + 1]
        try:
            value = json.loads(raw)
        except ValueError:
            self._fail("quoted identifier is not a legal JSON string", start)
        self._pos = i + 1
        return Token("qident", value, start)

    def _raw_string(self, start):
        text, n = self._text, self._n
        out = []
        i = start + 1
        while True:
            if i >= n:
                self._fail("unterminated raw string literal", start)
            c = text[i]
            if c == "'":
                break
            if c == "\\" and text[i + 1:i + 2] == "'":
                out.append("'")
                i += 2
                continue
            if c == "\\" and text[i + 1:i + 2] == "u" and _is_hex4(text[i + 2:i + 6]):
                run = []
                j = i
                while text[j:j + 2] == "\\u" and _is_hex4(text[j + 2:j + 6]):
                    run.append(text[j:j + 6])
                    j += 6
                out.append(json.loads('"' + "".join(run) + '"'))
                i = j
                continue
            out.append(c)
            i += 1
        self._pos = i + 1
        return Token("literal", "".join(out), start)

    def _json_literal(self, start):
        text, n = self._text, self._n
        i = start + 1
        while True:
            if i >= n:
                self._fail("unterminated JSON literal", start)
            c = text[i]
            if c == "`":
                break
            if c == "\\" and text[i + 1:i + 2] == "`":
                i += 2
                continue
            i += 1
        body = text[start + 1:i].replace("\\`", "`")
        try:
            value = json.loads(body)
        except ValueError:
            try:
                value = json.loads('"' + body.lstrip(_JSON_WS) + '"')
            except ValueError:
                self._fail("JSON literal is neither JSON nor JSON string content", start)
        self._pos = i + 1
        return Token("literal", value, start)
