"""Language functions: the provider base class, the signature decorator, and
the built-in function set.

A provider is an instance of ``Functions`` or of a subclass. Each attribute
named ``_func_<name>`` that was decorated with ``signature`` defines the
language function ``<name>``. Built-in functions are the ``_func_`` methods of
``Functions`` itself; they take precedence over a provider's functions of the
same name, so built-in behavior never changes.

Type names accepted by ``signature``: ``number``, ``string``, ``array``,
``object``, ``null`` (the names the Interface Contract lists), plus ``boolean``,
``reference`` (an expression reference) and ``any``.
"""

import functools
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import InvalidTypeError
from .runtime import is_array, is_number, json_equal, json_type

_KNOWN_TYPES = frozenset(
    ["number", "string", "array", "object", "null", "boolean", "reference", "any"]
)

_INTEGER_NUMERAL = re.compile(r"-?[0-9]+")
_DECIMAL_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def signature(*arguments, variadic=False):
    """Declare argument types for a provider function.

    Each positional argument is ``{"types": [<type-name>, ...]}``, one per
    parameter. ``variadic=True`` lets the last declared parameter repeat
    (one or more arguments in total). The decorator does not call the function.
    """
    specs = []
    for argument in arguments:
        types = tuple(argument["types"])
        for name in types:
            if name not in _KNOWN_TYPES:
                raise ValueError("unknown type name %r in signature" % (name,))
        specs.append(types)
    specs = tuple(specs)
    is_variadic = bool(variadic)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        wrapper._pathsel_signature = specs
        wrapper._pathsel_variadic = is_variadic
        return wrapper

    return decorator


def _require_items(values, check, what):
    for item in values:
        if not check(item):
            raise InvalidTypeError("expected %s" % what)


def _scalar_kind(values):
    """'number' or 'string' when all items share that kind; None when empty."""
    if not values:
        return None
    if all(is_number(v) for v in values):
        return "number"
    if all(isinstance(v, str) for v in values):
        return "string"
    raise InvalidTypeError("expected an array of numbers or an array of strings")


def _numeric_values(values):
    """Mixing host decimals with floats is not allowed by Python; widen decimals."""
    if any(isinstance(v, float) for v in values) and any(isinstance(v, Decimal) for v in values):
        return [float(v) if isinstance(v, Decimal) else v for v in values]
    return list(values)


def _dump(value):
    """Compact JSON text: no spaces, non-ASCII escaped as \\uXXXX."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return json.dumps(value)
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, str):
        return json.dumps(value)
    if is_array(value):
        return "[" + ",".join(_dump(item) for item in value) + "]"
    if isinstance(value, Mapping):
        return "{" + ",".join(
            json.dumps(str(key)) + ":" + _dump(item) for key, item in value.items()
        ) + "}"
    return json.dumps(str(value))


class Functions:
    """Provider of the built-in functions. Subclass it and add ``_func_<name>``
    methods decorated with ``signature`` to extend the language."""

    @signature({"types": ["number"]})
    def _func_abs(self, number):
        return abs(number)

    @signature({"types": ["array"]})
    def _func_avg(self, values):
        _require_items(values, is_number, "an array of numbers")
        if not values:
            return None
        numbers = _numeric_values(values)
        return sum(numbers) / len(numbers)

    @signature({"types": ["number"]})
    def _func_ceil(self, number):
        return math.ceil(number)

    @signature({"types": ["number"]})
    def _func_floor(self, number):
        return math.floor(number)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            if not isinstance(search, str):
                raise InvalidTypeError("contains on a string needs a string")
            return search in subject
        return any(json_equal(item, search) for item in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, subject, suffix):
        return subject.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, subject, prefix):
        return subject.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, subject):
        return len(subject)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, subject):
        if isinstance(subject, str):
            return subject[::-1]
        return list(reversed(subject))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, glue, parts):
        _require_items(parts, lambda p: isinstance(p, str), "an array of strings")
        if not parts:
            return ""
        return glue.join(parts)

    @signature({"types": ["object"]})
    def _func_keys(self, obj):
        return list(obj.keys())

    @signature({"types": ["object"]})
    def _func_values(self, obj):
        return list(obj.values())

    @signature({"types": ["any"]})
    def _func_type(self, value):
        name = json_type(value)
        if name is None or name == "reference":
            return "object"
        return name

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if is_array(value):
            return value
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return _dump(value)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            try:
                if _INTEGER_NUMERAL.fullmatch(value):
                    return int(value)
                if _DECIMAL_NUMERAL.fullmatch(value):
                    return float(value)
            except ValueError:
                return None
        return None

    @signature({"types": ["array"]})
    def _func_max(self, values):
        if _scalar_kind(values) is None:
            return None
        return max(values)

    @signature({"types": ["array"]})
    def _func_min(self, values):
        if _scalar_kind(values) is None:
            return None
        return min(values)

    @signature({"types": ["array"]})
    def _func_sort(self, values):
        _scalar_kind(values)
        return sorted(values)

    @signature({"types": ["array"]})
    def _func_sum(self, values):
        _require_items(values, is_number, "an array of numbers")
        return sum(_numeric_values(values))

    @signature({"types": ["object"]}, variadic=True)
    def _func_merge(self, *objects):
        merged = {}
        for obj in objects:
            merged.update(obj)
        return merged

    @signature({"types": ["any"]}, variadic=True)
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature({"types": ["reference"]}, {"types": ["array"]})
    def _func_map(self, reference, values):
        return [reference.apply(item) for item in values]

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_sort_by(self, values, reference):
        keys = [reference.apply(item) for item in values]
        _scalar_kind(keys)
        order = sorted(range(len(values)), key=keys.__getitem__)
        return [values[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_max_by(self, values, reference):
        keys = [reference.apply(item) for item in values]
        if _scalar_kind(keys) is None:
            return None
        best = 0
        for i in range(1, len(keys)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @signature({"types": ["array"]}, {"types": ["reference"]})
    def _func_min_by(self, values, reference):
        keys = [reference.apply(item) for item in values]
        if _scalar_kind(keys) is None:
            return None
        best = 0
        for i in range(1, len(keys)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


_BUILTINS = Functions()


def resolve_function(name, provider):
    """Return ``(function, specs, variadic)`` for a function name, or None.

    Built-ins are searched first, then the provider's ``_func_`` methods.
    """
    for owner in (_BUILTINS, provider):
        if owner is None:
            continue
        function = getattr(owner, "_func_" + name, None)
        specs = getattr(function, "_pathsel_signature", None)
        if specs is not None:
            return function, specs, bool(getattr(function, "_pathsel_variadic", False))
    return None


__all__ = ["Functions", "signature"]
