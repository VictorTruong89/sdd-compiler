"""Expression tree and its evaluation against Python data.

Every node has ``evaluate(value, context)`` where ``value`` is the current
value. Nodes never mutate the input document.
"""

import copy
import operator
from collections.abc import Mapping

from .exceptions import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .functions import resolve_function
from .runtime import (
    ExpressionReference,
    is_array,
    is_false,
    is_number,
    json_equal,
    json_type,
)

_ORDERING = {
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
}


class Node:
    __slots__ = ()

    def evaluate(self, value, context):
        raise NotImplementedError


class Identity(Node):
    __slots__ = ()

    def evaluate(self, value, context):
        return value


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, context):
        if isinstance(value, Mapping):
            return value.get(self.name)
        return None


class Index(Node):
    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def evaluate(self, value, context):
        if not is_array(value):
            return None
        n = len(value)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return value[i]
        return None


def _clamp(v, low, high):
    return low if v < low else high if v > high else v


class Slice(Node):
    __slots__ = ("start", "stop", "step")

    def __init__(self, start, stop, step):
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, value, context):
        if not is_array(value):
            return None
        n = len(value)
        step = 1 if self.step is None else self.step
        if step > 0:
            lo, hi = 0, n
            start = 0 if self.start is None else _clamp(
                self.start + n if self.start < 0 else self.start, lo, hi)
            stop = n if self.stop is None else _clamp(
                self.stop + n if self.stop < 0 else self.stop, lo, hi)
        else:
            lo, hi = -1, n - 1
            start = hi if self.start is None else _clamp(
                self.start + n if self.start < 0 else self.start, lo, hi)
            stop = lo if self.stop is None else _clamp(
                self.stop + n if self.stop < 0 else self.stop, lo, hi)
        return [value[i] for i in range(start, stop, step)]


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, context):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class Chain(Node):
    """Apply each step to the result of the one before (dot chains, pipes, index steps).

    Kept flat so that long chains evaluate without recursion per segment.
    """

    __slots__ = ("steps",)

    def __init__(self, steps):
        self.steps = steps

    def evaluate(self, value, context):
        for step in self.steps:
            value = step.evaluate(value, context)
        return value


class Projection(Node):
    """Apply ``right`` to each element of the array ``left`` and keep non-null results."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        base = self.left.evaluate(value, context)
        if not is_array(base):
            return None
        out = []
        for element in base:
            result = self.right.evaluate(element, context)
            if result is not None:
                out.append(result)
        return out


class ValueProjection(Node):
    """Object wildcard: apply ``right`` to each value of the object ``left``."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        base = self.left.evaluate(value, context)
        if not isinstance(base, Mapping):
            return None
        out = []
        for element in base.values():
            result = self.right.evaluate(element, context)
            if result is not None:
                out.append(result)
        return out


class Flatten(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def evaluate(self, value, context):
        base = self.child.evaluate(value, context)
        if not is_array(base):
            return None
        out = []
        for element in base:
            if is_array(element):
                out.extend(element)
            else:
                out.append(element)
        return out


class Filter(Node):
    __slots__ = ("child", "predicate")

    def __init__(self, child, predicate):
        self.child = child
        self.predicate = predicate

    def evaluate(self, value, context):
        base = self.child.evaluate(value, context)
        if not is_array(base):
            return None
        return [e for e in base if not is_false(self.predicate.evaluate(e, context))]


class Not(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def evaluate(self, value, context):
        return is_false(self.child.evaluate(value, context))


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        if is_false(left):
            return left
        return self.right.evaluate(value, context)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        if not is_false(left):
            return left
        return self.right.evaluate(value, context)


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        left = self.left.evaluate(value, context)
        right = self.right.evaluate(value, context)
        if self.op == "==":
            return json_equal(left, right)
        if self.op == "!=":
            return not json_equal(left, right)
        both_numbers = is_number(left) and is_number(right)
        both_strings = isinstance(left, str) and isinstance(right, str)
        if both_numbers or both_strings:
            return bool(_ORDERING[self.op](left, right))
        return None


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, context):
        return [item.evaluate(value, context) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, context):
        if value is None:
            return None
        result = context.new_mapping()
        for key, expr in self.pairs:
            result[key] = expr.evaluate(value, context)
        return result


class ExpRef(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def evaluate(self, value, context):
        return ExpressionReference(self.child, context)


class Function(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, context):
        entry = resolve_function(self.name, context.provider)
        if entry is None:
            raise UnknownFunctionError("unknown function %r" % self.name)
        function, specs, variadic = entry
        count = len(self.args)
        if (count < len(specs)) if variadic else (count != len(specs)):
            raise InvalidArityError(
                "function %r takes %s%d argument(s), got %d"
                % (self.name, "at least " if variadic else "", len(specs), count))
        arguments = [arg.evaluate(value, context) for arg in self.args]
        for index, argument in enumerate(arguments):
            allowed = specs[min(index, len(specs) - 1)]
            if "any" not in allowed and json_type(argument) not in allowed:
                raise InvalidTypeError(
                    "argument %d of %r has an invalid type" % (index + 1, self.name))
        return function(*arguments)
