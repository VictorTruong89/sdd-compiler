"""Value model helpers shared by the evaluator and the built-in functions."""

from collections.abc import Mapping
from decimal import Decimal


def is_number(value):
    """Integers, floats and host decimals are numbers; booleans are not."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    """Arrays are sequences built as lists (JSON arrays); tuples count too."""
    return isinstance(value, (list, tuple))


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None:
        return True
    if isinstance(value, bool):
        return not value
    if isinstance(value, (str, list, tuple, Mapping)):
        return len(value) == 0
    return False


def json_type(value):
    """Name of the JSON type of a value, or None for host values that are not JSON."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if is_number(value):
        return "number"
    if isinstance(value, str):
        return "string"
    if is_array(value):
        return "array"
    if isinstance(value, Mapping):
        return "object"
    if isinstance(value, ExpressionReference):
        return "reference"
    return None


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects; a boolean never equals a number."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and bool(a == b)
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, Mapping) or isinstance(b, Mapping):
        if not (isinstance(a, Mapping) and isinstance(b, Mapping)) or len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    return bool(a == b)


class ExpressionReference:
    """A deferred subexpression produced by ``&expr``.

    Built-in functions such as ``map`` and ``sort_by`` apply it to elements.
    """

    __slots__ = ("node", "context")

    def __init__(self, node, context):
        self.node = node
        self.context = context

    def apply(self, value):
        return self.node.evaluate(value, self.context)

    def __repr__(self):
        return "<pathsel expression reference>"


class Options:
    """Evaluation options: a mapping type for constructed hashes and a function provider.

    Any object with ``dict_cls`` and ``custom_functions`` attributes works too.
    """

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class Context:
    """Per-search evaluation state derived from the options."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    @classmethod
    def from_options(cls, options):
        if options is None:
            return cls()
        return cls(
            getattr(options, "dict_cls", None),
            getattr(options, "custom_functions", None),
        )

    def new_mapping(self):
        if self.dict_cls is not None:
            return self.dict_cls()
        return {}
