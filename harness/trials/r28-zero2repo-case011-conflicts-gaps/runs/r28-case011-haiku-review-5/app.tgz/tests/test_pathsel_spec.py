"""Behavioral checks for pathsel, derived from spec/Full_PRD.md and the Interface Contract."""

from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import compile as pcompile
from pathsel import search
from pathsel.exceptions import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature

DOC = {
    "foo": {"bar": 1, "baz": [1, 2, 3, 4], "quoted key": "q", "a.b": "dotted"},
    "people": [
        {"name": "a", "age": 30, "tags": ["x"]},
        {"name": "b", "age": 10, "tags": []},
        {"name": "c", "age": 50},
    ],
    "nested": [[1, [2]], 3, [4]],
    "obj": {"x": 1, "y": None, "z": 3},
    "zero": 0,
    "empty": "",
    "flag": False,
}


def both(expression, data=DOC, options=None):
    """Evaluate via one-shot search and compile-then-search; they must agree."""
    one_shot = search(expression, data, options)
    compiled = pcompile(expression).search(data, options)
    assert one_shot == compiled
    return one_shot


# -- FP-01 -----------------------------------------------------------------

def test_dotted_path_and_missing_is_null():
    assert both("foo.bar") == 1
    assert both("foo.missing.deep") is None
    assert both("nope") is None


def test_empty_and_whitespace_refusals():
    with pytest.raises(EmptyExpressionError):
        search("", DOC)
    with pytest.raises(IncompleteExpressionError):
        search("  \t\n\r", DOC)
    with pytest.raises(EmptyExpressionError):
        pcompile("")


def test_syntax_and_token_syntax_kinds_differ():
    grammar = None
    token = None
    with pytest.raises(SyntaxFailure) as info:
        search("foo.", DOC)
    grammar = info.value
    with pytest.raises(SyntaxFailure) as info:
        search("foo-bar", DOC)
    token = info.value
    assert type(grammar) is SyntaxFailure
    assert isinstance(token, TokenSyntaxFailure)
    assert type(token) is not SyntaxFailure
    assert not isinstance(token, (EmptyExpressionError, IncompleteExpressionError))
    assert grammar.lex_position == 4
    assert token.lex_position == 3


def test_lone_equals_is_token_level():
    with pytest.raises(TokenSyntaxFailure):
        search("a = b", DOC)


def test_incomplete_expression_position():
    with pytest.raises(IncompleteExpressionError) as info:
        search("foo[", DOC)
    assert info.value.lex_position == 4


def test_trailing_dot_is_syntax_not_incomplete():
    with pytest.raises(SyntaxFailure) as info:
        search("foo.", DOC)
    assert not isinstance(info.value, IncompleteExpressionError)


# -- FP-02 -----------------------------------------------------------------

def test_quoted_identifiers_name_any_key():
    assert both('foo."quoted key"') == "q"
    assert both('foo."a.b"') == "dotted"
    assert both('"foo"."bar"') == 1


def test_identifier_on_array_is_null():
    assert both("foo.baz.bar") is None
    assert both("people.name") is None


def test_hyphenated_key_requires_quotes():
    with pytest.raises(TokenSyntaxFailure):
        search("foo-bar", DOC)


# -- FP-03 -----------------------------------------------------------------

@pytest.mark.parametrize(
    "expression, expected",
    [
        ("foo.baz[0]", 1),
        ("foo.baz[-1]", 4),
        ("foo.baz[4]", None),
        ("foo.baz[-5]", None),
        ("foo.baz[1:3]", [2, 3]),
        ("foo.baz[::-1]", [4, 3, 2, 1]),
        ("foo.baz[::2]", [1, 3]),
        ("foo.baz[-2:]", [3, 4]),
        ("foo.baz[5:9]", []),
        ("foo.baz[3:1:-1]", [4, 3]),
        ("foo.bar[0]", None),
        ("foo.bar[0:2]", None),
        ("foo[0]", None),
        ("nested[]", [1, [2], 3, 4]),
        ("nested[][]", [1, 2, 3, 4]),
        ("foo[]", None),
    ],
)
def test_index_slice_flatten(expression, expected):
    assert both(expression) == expected


def test_zero_slice_step_refused_on_both_entries():
    with pytest.raises(ZeroSliceStepError):
        search("foo.baz[::0]", DOC)
    with pytest.raises(ZeroSliceStepError):
        pcompile("foo.baz[1:2:0]")


def test_slice_with_too_many_parts_is_syntax():
    with pytest.raises(SyntaxFailure):
        search("foo.baz[1:2:3:4]", DOC)


# -- FP-04 -----------------------------------------------------------------

def test_list_wildcard_and_filter():
    assert both("people[*].name") == ["a", "b", "c"]
    assert both("people[?age > `20`].name") == ["a", "c"]
    assert both("people[].tags") == [["x"], []]
    assert both("people[*].tags[0]") == ["x"]


def test_object_wildcard_projects_values():
    assert both("obj.*") == [1, 3]
    assert both("foo.bar.*") is None
    assert both("*") is not None


def test_wildcard_on_non_container_is_null():
    assert both("foo.bar[*]") is None
    assert both("obj[*]") is None
    assert both("foo.bar[?@ == `1`]") is None


def test_projection_ends_at_comparison():
    # The comparison compares the whole projected array, not each element.
    assert both("people[*].age == `30`") is False
    assert both("people[*].name | length(@)") == 3


def test_wildcard_followed_by_identifier_is_syntax():
    with pytest.raises(SyntaxFailure):
        search("people[*]name", DOC)


def test_star_directly_after_identifier_is_syntax():
    with pytest.raises(SyntaxFailure):
        search("foo*", DOC)


# -- FP-05 -----------------------------------------------------------------

def test_multiselect_list_and_hash():
    assert both("[foo.bar, foo.missing]") == [1, None]
    assert both("people[0].{n: name, a: age}") == {"n": "a", "a": 30}
    assert both("{x: foo.bar}") == {"x": 1}
    assert both("people[*].[name, age]") == [["a", 30], ["b", 10], ["c", 50]]


def test_multiselect_hash_on_null_is_null():
    assert both("missing.{a: foo}") is None


def test_multiselect_list_on_null_builds_nulls():
    assert both("missing.[a, b]") == [None, None]


def test_pipe_and_current_value():
    assert both("people[0].name | @") == "a"
    assert both("foo | bar") == 1
    assert both("foo | baz | [1]") == 2


def test_literals():
    assert both("`[1, 2]`[1]") == 2
    assert both("'it\\'s'") == "it's"
    assert both("'123'") == "123"
    assert both("`\"bare\"`") == "bare"
    assert both("`abc`") == "abc"
    assert both("'\\u00e9'") == "é"


def test_expression_reference_is_non_null_on_its_own():
    assert search("&foo", DOC) is not None


# -- FP-06 -----------------------------------------------------------------

def test_equality_distinguishes_booleans_and_numbers():
    assert both("zero == `false`") is False
    assert both("`1` == `true`") is False
    assert both("foo.bar == `1.0`") is True
    assert both("foo.baz == `[1,2,3,4]`") is True


def test_truthiness_and_logic():
    assert both("zero || foo.bar") == 0
    assert both("empty || foo.bar") == 1
    assert both("empty && foo.bar") == ""
    assert both("!zero") is False
    assert both("!empty") is True
    assert both("!foo.bar") is None


def test_ordering_numbers_and_strings():
    assert both("foo.bar < `2`") is True
    assert both("people[0].name < 'b'") is True


def test_lone_ampersand_and_missing_sides():
    with pytest.raises(IncompleteExpressionError):
        search("&", DOC)
    with pytest.raises(IncompleteExpressionError):
        search("foo.bar &&", DOC)
    with pytest.raises(IncompleteExpressionError):
        search("foo.bar ||", DOC)
    with pytest.raises(SyntaxFailure):
        search("&&", DOC)


# -- FP-07 -----------------------------------------------------------------

@pytest.mark.parametrize(
    "expression, expected",
    [
        ("abs(`-3`)", 3),
        ("avg(foo.baz)", 2.5),
        ("avg(`[]`)", None),
        ("ceil(`1.2`)", 2),
        ("floor(`-1.2`)", -2),
        ("contains(foo.baz, `2`)", True),
        ("contains(foo.baz, `\"2\"`)", False),
        ("contains('abc', 'b')", True),
        ("ends_with('abc', 'bc')", True),
        ("starts_with('abc', 'ab')", True),
        ("length('héllo')", 5),
        ("length(foo)", 4),
        ("reverse(foo.baz)", [4, 3, 2, 1]),
        ("reverse('abc')", "cba"),
        ("join(', ', `[\"a\", \"b\"]`)", "a, b"),
        ("join(', ', `[]`)", ""),
        ("keys(obj)", ["x", "y", "z"]),
        ("values(obj)", [1, None, 3]),
        ("type(foo)", "object"),
        ("type(`null`)", "null"),
        ("type(`1.5`)", "number"),
        ("type(`true`)", "boolean"),
        ("to_array(`1`)", [1]),
        ("to_array(foo.baz)", [1, 2, 3, 4]),
        ("to_string(`{\"a\": 1}`)", '{"a":1}'),
        ("to_string(`1`)", "1"),
        ("to_number('5')", 5),
        ("to_number('1.5e3')", 1500.0),
        ("to_number('abc')", None),
        ("to_number(`true`)", None),
        ("max(foo.baz)", 4),
        ("min(`[\"b\", \"a\"]`)", "a"),
        ("max(`[]`)", None),
        ("sort(`[3, 1, 2]`)", [1, 2, 3]),
        ("sum(foo.baz)", 10),
        ("merge(obj, `{\"q\": 1}`)", {"x": 1, "y": None, "z": 3, "q": 1}),
        ("not_null(missing, `\"\"`, `1`)", ""),
        ("not_null(missing, missing2)", None),
        ("map(&name, people)", ["a", "b", "c"]),
        ("sort_by(people, &age)[*].name", ["b", "a", "c"]),
        ("max_by(people, &age).name", "c"),
        ("min_by(people, &age).name", "b"),
        ("max_by(`[]`, &age)", None),
    ],
)
def test_builtin_functions(expression, expected):
    assert both(expression) == expected


@pytest.mark.parametrize(
    "expression, error",
    [
        ("abs()", InvalidArityError),
        ("length(foo, foo)", InvalidArityError),
        ("not_null()", InvalidArityError),
        ("merge()", InvalidArityError),
        ("abs(`true`)", InvalidTypeError),
        ("sum(foo)", InvalidTypeError),
        ("max(`[1, \"a\"]`)", InvalidTypeError),
        ("map(@, foo.baz)", InvalidTypeError),
        ("sort_by(people, `1`)", InvalidTypeError),
        ("nosuch(foo)", UnknownFunctionError),
    ],
)
def test_function_call_refusals(expression, error):
    with pytest.raises(error):
        search(expression, DOC)


def test_quoted_identifier_cannot_be_function_name():
    with pytest.raises(SyntaxFailure):
        search('"abs"(foo)', DOC)


def test_function_checks_happen_at_search_not_compile():
    compiled = pcompile("abs(`true`)")
    with pytest.raises(InvalidTypeError):
        compiled.search(DOC)
    compiled = pcompile("nosuch(foo)")  # compiles
    with pytest.raises(UnknownFunctionError):
        compiled.search(DOC)


def test_refusal_types_are_value_errors():
    for error_type in (
        EmptyExpressionError,
        IncompleteExpressionError,
        SyntaxFailure,
        ZeroSliceStepError,
        UnknownFunctionError,
        InvalidArityError,
        InvalidTypeError,
    ):
        assert issubclass(error_type, ValueError)


# -- FP-08 -----------------------------------------------------------------

class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["string"]})
    def _func_tag(self, number, text):
        return 0 if number == 0 else text + str(number)

    @signature({"types": ["any"]}, variadic=True)
    def _func_count(self, *values):
        return len(values)


def test_custom_functions_and_builtins_coexist():
    options = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert both("tag(foo.bar, 'n')", options=options) == "n1"
    assert both("tag(`0`, 'n')", options=options) == 0
    assert both("count(@, `null`)", options=options) == 2
    assert both("abs(`-2`)", options=options) == 2


def test_custom_function_refusals():
    options = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    with pytest.raises(InvalidArityError):
        search("tag(foo.bar)", DOC, options)
    with pytest.raises(InvalidTypeError):
        search("tag(`true`, 'n')", DOC, options)
    with pytest.raises(UnknownFunctionError):
        search("tag(foo.bar, 'n')", DOC)


def test_mapping_type_for_constructed_hashes():
    options = pathsel.Options(dict_cls=OrderedDict)
    result = search("{a: foo.bar, b: foo.baz}", DOC, options)
    assert isinstance(result, OrderedDict)
    assert list(result) == ["a", "b"]
    assert search("{a: foo.bar}", DOC) == {"a": 1}
    assert isinstance(search("{a: foo.bar}", DOC), dict)


def test_ordered_dict_hash_accepted_by_object_functions():
    options = pathsel.Options(dict_cls=OrderedDict)
    assert search("keys({a: foo.bar})", DOC, options) == ["a"]


def test_input_document_is_not_mutated():
    import copy

    before = copy.deepcopy(DOC)
    both("people[*].{n: name}")
    both("sort_by(people, &age)")
    both("foo.baz[::-1]")
    assert DOC == before
