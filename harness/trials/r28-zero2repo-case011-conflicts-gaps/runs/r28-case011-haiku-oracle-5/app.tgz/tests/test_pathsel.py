"""Behavioural tests for pathsel, named after the spec ids they check.

Each test cites the spec ids it covers (``# spec: N-...``) so the coverage
in NOTES.md can be checked against this file.
"""

from collections import OrderedDict
from decimal import Decimal
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import (
    Functions,
    PathSelArityError,
    PathSelEmptyError,
    PathSelError,
    PathSelIncompleteError,
    PathSelSyntaxError,
    PathSelTokenError,
    PathSelTypeError,
    PathSelUnknownFunctionError,
    PathSelZeroStepError,
    signature,
)

DOC = {
    "a": {"b": {"c": 1}},
    "arr": [1, 2, 3, [4, 5]],
    "people": [
        {"name": "x", "tags": [1, 2], "age": 3},
        {"name": "y", "tags": [3], "age": 7},
        {"name": None, "tags": [], "age": 9},
    ],
    "obj": {"k1": 1, "k2": None, "k3": "v"},
    "zero": 0,
    "empty": [],
    "s": "hello",
    "quoted key": {"with-dash": 5, "dot.key": 6, "7": 8},
}


def search(expr, doc=DOC, options=None):
    return pathsel.search(expr, doc, options)


# --- FP-01: paths, missing is null, compile-then-search -----------------------

# spec: N-000002, N-000077, N-000083, N-000085
def test_N_000077_dotted_path_returns_nested_value():
    assert search("a.b.c") == 1
    assert search("a.b") == {"c": 1}


# spec: N-000003, N-000041, N-000059, N-000060, N-000083
def test_N_000083_missing_path_is_null_at_any_depth():
    assert search("a.x.y.z") is None
    assert search("nothing") is None


# spec: N-000085
def test_N_000085_identifier_on_array_is_null():
    assert search("arr.x") is None


# spec: N-000006, N-000078, N-000079, N-000080, N-000081, N-000082
def test_N_000078_compiled_expression_searches_many_documents():
    compiled = pathsel.compile("a.b.c")
    assert compiled.search({"a": {"b": {"c": 10}}}) == 10
    assert compiled.search({"a": {"b": {"c": 20}}}) == 20
    assert compiled.search({}) is None
    assert compiled.search(DOC) == search("a.b.c")


# spec: N-000086
def test_N_000086_compile_succeeds_when_every_search_is_null():
    compiled = pathsel.compile("nope.never")
    assert compiled.search({}) is None


# spec: N-000087, N-000088, N-000089
def test_N_000087_empty_expression_is_empty_kind():
    with pytest.raises(PathSelEmptyError):
        search("")
    with pytest.raises(PathSelEmptyError):
        pathsel.compile("")


# spec: N-000090, N-000091, N-000092, N-000093, N-000421, N-000422
def test_N_000090_whitespace_only_is_incomplete_with_position():
    for text in [" ", "\t\n\r  "]:
        with pytest.raises(PathSelIncompleteError) as info:
            search(text)
        assert info.value.lex_position == len(text)
        assert isinstance(info.value.lex_position, int)


# spec: N-000090, N-000091, N-000092, N-000093
def test_N_000090_open_operand_and_brackets_are_incomplete():
    for text in ["a |", "a ==", "foo(", "[0", "(a", "a ||", "&"]:
        with pytest.raises(PathSelIncompleteError):
            search(text)


# spec: N-000094, N-000095, N-000123
@pytest.mark.parametrize(
    "text",
    ["a.", "a.1", "a.-1", ".a", "a..b", "a)", "]", "a b", "a[0,1]", "[1:2:3:4]", "[a:b]", "[*]foo", "a.*b", "@ @", "{}", "[1,]", "a[?]"],
)
def test_N_000094_grammar_errors_are_syntax_kind(text):
    with pytest.raises(PathSelSyntaxError) as info:
        search(text)
    assert not isinstance(info.value, PathSelTokenError)
    assert isinstance(info.value.lex_position, int)


# spec: N-000096, N-000098, N-000099, N-000100, N-000101, N-000412
@pytest.mark.parametrize("text", ["a-b", "a=b", "a ? b", "`abc", '"abc', "'abc", "a$"])
def test_N_000098_token_errors_are_a_subclass_of_syntax(text):
    with pytest.raises(PathSelTokenError) as info:
        search(text)
    assert isinstance(info.value, PathSelSyntaxError)
    assert not isinstance(info.value, (PathSelEmptyError, PathSelIncompleteError))


# spec: N-000102, N-000103, N-000104
def test_N_000102_position_is_offset_of_failing_token():
    with pytest.raises(PathSelSyntaxError) as info:
        search("a b")
    assert info.value.lex_position == 2
    with pytest.raises(PathSelSyntaxError) as info:
        search("[1:2:3:4]")
    assert info.value.lex_position == 6


# spec: N-000105, N-000106, N-000405
def test_N_000105_every_refusal_is_a_value_error_and_not_null():
    for text in ["", " ", "a.", "a-b", "[::0]", "nofn()", "length()"]:
        with pytest.raises(ValueError):
            search(text)
        assert issubclass(PathSelError, ValueError)


# spec: N-000008, N-000009, N-000001, N-000002, N-000003, N-000004, N-000005
def test_N_000004_one_shot_and_compiled_agree():
    for text in ["people[*].name", "arr[1:]", "obj.*", "people[?age > `3`].age"]:
        assert pathsel.compile(text).search(DOC) == search(text)


# --- FP-02: identifiers and subexpressions ----------------------------------

# spec: N-000107, N-000108, N-000109
def test_N_000107_unquoted_identifier_and_whitespace():
    assert search("  a . b   .c  ") == 1


# spec: N-000110, N-000111, N-000112, N-000114
def test_N_000110_quoted_identifiers_name_any_key():
    assert search('"quoted key"."with-dash"') == 5
    assert search('"quoted key"."dot.key"') == 6
    assert search('"quoted key"."7"') == 8
    assert search('"quoted key"') == {"with-dash": 5, "dot.key": 6, "7": 8}


# spec: N-000113, N-000117, N-000119, N-000121
@pytest.mark.parametrize("text", ["a.1", "a.-1", "a-b"])
def test_N_000117_numbers_and_hyphens_are_not_identifiers(text):
    with pytest.raises(PathSelError):
        search(text)


# spec: N-000115, N-000116
def test_N_000115_field_on_non_object_is_null_and_does_not_project():
    assert search("people.name") is None


# spec: N-000124
def test_N_000124_bad_quoted_identifier_is_token_error():
    with pytest.raises(PathSelTokenError):
        search('"a\\q"')


# --- FP-03: index, slice, flatten -------------------------------------------

# spec: N-000126, N-000127, N-000128, N-000129
def test_N_000126_index_and_negative_index():
    assert search("arr[0]") == 1
    assert search("arr[-1]") == [4, 5]
    assert search("arr[9]") is None
    assert search("arr[-9]") is None
    assert search("obj[0]") is None
    assert search("s[0]") is None


# spec: N-000130, N-000131, N-000132, N-000133, N-000134, N-000135, N-000136, N-000137
def test_N_000135_positive_step_slices():
    assert search("arr[0:2]") == [1, 2]
    assert search("arr[::2]") == [1, 3]
    assert search("arr[-2:]") == [3, [4, 5]]
    assert search("arr[10:20]") == []


# spec: N-000138, N-000139, N-000140, N-000141
def test_N_000138_negative_step_slices():
    assert search("arr[::-1]") == [[4, 5], 3, 2, 1]
    assert search("arr[2:0:-1]") == [3, 2]
    assert search("arr[-1:-100:-1]") == [[4, 5], 3, 2, 1]


# spec: N-000142
def test_N_000142_slice_of_non_array_is_null():
    assert search("obj[0:1]") is None


# spec: N-000143, N-000144
def test_N_000143_slice_is_projection_dropping_nulls():
    assert search("people[0:2].name") == ["x", "y"]
    assert search("arr[0:2].x") == []


# spec: N-000145, N-000146, N-000147
def test_N_000145_flatten_one_level():
    assert search("arr[]") == [1, 2, 3, 4, 5]
    assert search("obj[]") is None


# spec: N-000148, N-000149, N-000150
def test_N_000148_flatten_applies_to_whole_preceding_result():
    assert search("people[*].tags[]") == [1, 2, 3]
    assert search("people[*].tags") == [[1, 2], [3], []]


# spec: N-000151
def test_N_000151_index_and_flatten_at_document_root():
    assert search("[0]", [7, 8]) == 7
    assert search("[]", [[1], 2]) == [1, 2]


# spec: N-000152, N-000153, N-000154, N-000415
def test_N_000152_zero_slice_step_refuses_with_its_own_kind():
    with pytest.raises(PathSelZeroStepError) as info:
        search("arr[::0]")
    assert not isinstance(info.value, PathSelSyntaxError)
    with pytest.raises(PathSelZeroStepError):
        pathsel.compile("arr[0:5:0]")


# spec: N-000155, N-000156, N-000157
def test_N_000155_bad_slice_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        search("arr[1:2:3:4]")
    with pytest.raises(PathSelSyntaxError):
        search("arr[a:b]")


# --- FP-04: wildcards and filters -------------------------------------------

# spec: N-000159, N-000160, N-000161, N-000162
def test_N_000159_list_wildcard_projects_and_drops_nulls():
    assert search("people[*].name") == ["x", "y"]
    assert search("people[*]") == DOC["people"]
    assert search("obj[*]") is None


# spec: N-000163, N-000164, N-000165
def test_N_000163_object_wildcard_projects_values():
    assert search("obj.*") == [1, "v"]
    assert search("*") == [DOC["a"], DOC["arr"], DOC["people"], DOC["obj"], 0, [], "hello", DOC["quoted key"]]
    assert search("arr.*") is None


# spec: N-000166, N-000167
def test_N_000166_nested_projection_drops_null_inner_results():
    assert search("arr[*][0]") == [4]  # [4,5] is the only array element
    assert search("people[*].tags[0]") == [1, 3]


# spec: N-000168, N-000169, N-000170, N-000171, N-000172, N-000173
def test_N_000168_filter_keeps_true_values():
    assert search("people[?age > `5`].name") == ["y"]
    assert search("people[?name]") == [DOC["people"][0], DOC["people"][1]]
    assert search("people[?tags]") == [DOC["people"][0], DOC["people"][1]]
    assert search("obj[?age]") is None


# spec: N-000174, N-000175, N-000176, N-000177, N-000178, N-000179, N-000180, N-000181
def test_N_000174_predicates_use_truthiness_and_json_equality():
    doc = [{"v": 0}, {"v": False}, {"v": None}, {"v": 1}]
    assert search("[?v]", doc) == [{"v": 0}, {"v": 1}]
    assert search("[?v == `0`]", doc) == [{"v": 0}]
    assert search("[?v == `false`]", doc) == [{"v": False}]
    assert search("[?v == `1`]", doc) == [{"v": 1}]


# spec: N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000194
def test_N_000182_projection_reach_and_ranking():
    assert search("people[*].tags[0]") == [1, 3]
    assert search("people[*].tags[*]") == [[1, 2], [3], []]
    assert search("people[*].name | length(@)") == 2
    assert search("people[*].age == `[3, 7, 9]`") is True


# spec: N-000195, N-000196, N-000197
def test_N_000195_comparison_compares_whole_projection():
    assert search("people[*].age == `[3, 7, 9]`") is True
    assert search("people[*].age[0] == `1`") is False


# spec: N-000200, N-000201
def test_N_000200_wildcard_followed_directly_by_identifier_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        search("*foo")
    with pytest.raises(PathSelSyntaxError):
        search("[*]2")


# spec: N-000202, N-000203
def test_N_000202_filter_on_non_array_is_null():
    assert search("obj[?k1]") is None


# spec: N-000204, N-000205
def test_N_000204_projected_nulls_never_stored():
    assert search("people[*].missing") == []


# --- FP-05: constructs, pipe, current value, literals ------------------------

# spec: N-000206, N-000207, N-000208, N-000209, N-000210
def test_N_000206_multiselect_hash_stores_nulls():
    assert search("{x: a.b.c, y: obj.k2}") == {"x": 1, "y": None}
    assert search('{"quoted key": zero}') == {"quoted key": 0}


# spec: N-000211, N-000212
def test_N_000211_multiselect_list_keeps_nulls():
    assert search("[a.b.c, obj.k2, zero]") == [1, None, 0]


# spec: N-000213, N-000214, N-000215, N-000216, N-000217, N-000218
def test_N_000213_multiselect_on_null_current_is_null():
    assert search("nothing.[a, b]") is None
    assert search("nothing.{a: a}") is None
    assert search("people[*].[name, age]") == [["x", 3], ["y", 7], [None, 9]]


# spec: N-000219, N-000220, N-000221, N-000222
def test_N_000219_pipe_sees_whole_left_result():
    assert search("people[*].age | length(@)") == 3
    assert search("people[*].name|[0]") == "x"
    assert search("a.b | c") == 1


# spec: N-000223, N-000224, N-000225, N-000226
def test_N_000223_json_literals():
    assert search("`1`") == 1
    assert search("`  [1, 2] `") == [1, 2]
    assert search("`abc`") == "abc"
    assert search('`"quoted"`') == "quoted"
    assert search("`{\"a\": 1}`.a") == 1


# spec: N-000227, N-000228, N-000229, N-000230, N-000239
def test_N_000227_raw_string_literals():
    assert search("'a b'") == "a b"
    assert search("'it\\'s'") == "it's"
    assert search("'123'") == "123"
    assert search("'\\u00e9'") == "\u00e9"


# spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423
def test_N_000231_expression_reference_bare_is_non_null():
    assert search("&a.b") is not None


# spec: N-000237, N-000240, N-000241
def test_N_000237_literal_and_multiselect_failures():
    # Not JSON, so it is read as string content; an unescaped quote is not readable.
    assert search("`{bad`") == "{bad"
    with pytest.raises(PathSelTokenError):
        search('`a"b`')
    with pytest.raises(PathSelSyntaxError):
        search("a.'raw'")
    with pytest.raises(PathSelError):
        search("{a: 1")
    with pytest.raises(PathSelError):
        search("a |")


# --- FP-06: comparisons and logic --------------------------------------------

# spec: N-000242, N-000243, N-000244
def test_N_000242_equality_is_json_equality():
    assert search("zero == `0`") is True
    assert search("zero == `false`") is False
    assert search("obj == `{\"k1\": 1, \"k2\": null, \"k3\": \"v\"}`") is True
    assert search("arr != `[1, 2]`") is True
    assert search("a.b.c == `1.0`") is True


# spec: N-000245, N-000246
def test_N_000245_ordering_on_numbers_and_strings():
    assert search("a.b.c < `2`") is True
    assert search("s >= `\"hello\"`") is True
    assert search("s < `\"abc\"`") is False


# spec: N-000247, N-000248, N-000249, N-000250
def test_N_000247_logic_returns_operands():
    assert search("zero || `1`") == 0
    assert search("empty || `\"x\"`") == "x"
    assert search("zero && `1`") == 1
    assert search("empty && `1`") == []


# spec: N-000251, N-000252
def test_N_000251_not_treats_zero_as_true():
    assert search("!zero") is False
    assert search("!empty") is True
    assert search("!nothing") is True


# spec: N-000253, N-000254, N-000255, N-000256, N-000257
def test_N_000253_binding_order_and_parentheses():
    assert search("!a.b.c") is None  # (!a).b.c
    assert search("!(a.b.c == `1`)") is False
    assert search("empty || `1` && `2`") == 2  # && binds tighter than ||
    assert search("zero || `1` && `2`") == 0  # zero is a true value, so || returns it
    # Pipe is loosest: the right side sees the whole left result (1), so zero is null there.
    assert search("`1` | zero || `5`") == 5


# spec: N-000258, N-000259
def test_N_000258_filter_predicate_uses_logic_operators():
    assert search("people[?age > `3` && age < `9`].name") == ["y"]


# spec: N-000260
def test_N_000260_lone_equals_is_token_error():
    with pytest.raises(PathSelTokenError):
        search("a = b")


# spec: N-000261
def test_N_000261_lone_ampersand_or_missing_side_refused():
    with pytest.raises(PathSelError):
        search("a && ")
    with pytest.raises(PathSelError):
        search("a || ")


# --- FP-07: built-in functions -------------------------------------------------

# spec: N-000262, N-000263, N-000264, N-000266, N-000267, N-000268
def test_N_000264_call_name_count_type_order():
    with pytest.raises(PathSelUnknownFunctionError):
        search("nosuch(zero)")
    with pytest.raises(PathSelArityError):
        search("abs()")
    with pytest.raises(PathSelTypeError):
        search("abs(`true`)")


# spec: N-000269
def test_N_000269_abs():
    assert search("abs(`-3`)") == 3
    assert search("abs(`-2.5`)") == 2.5


# spec: N-000270, N-000271
def test_N_000270_avg():
    assert search("avg(`[1, 2, 3, 4]`)") == 2.5
    assert search("avg(`[]`)") is None


# spec: N-000272, N-000273
def test_N_000272_ceil_and_floor_return_integers():
    assert search("ceil(`2.1`)") == 3 and isinstance(search("ceil(`2.1`)"), int)
    assert search("floor(`2.9`)") == 2 and isinstance(search("floor(`2.9`)"), int)


# spec: N-000274, N-000275
def test_N_000274_contains():
    assert search("contains(arr, `4`)") is False
    assert search("contains(`[1, [2]]`, `[2]`)") is True
    assert search("contains(s, `\"ell\"`)") is True


# spec: N-000276
def test_N_000276_starts_and_ends_with():
    assert search("starts_with(s, `\"he\"`)") is True
    assert search("ends_with(s, `\"lo\"`)") is True


# spec: N-000277
def test_N_000277_length_counts_characters_and_elements():
    assert search("length(s)") == 5
    assert search("length(`\"h\u00e9\"`)") == 2
    assert search("length(obj)") == 3
    assert search("length(arr)") == 4


# spec: N-000278
def test_N_000278_reverse():
    assert search("reverse(s)") == "olleh"
    assert search("reverse(arr)") == [[4, 5], 3, 2, 1]


# spec: N-000279, N-000280
def test_N_000279_join():
    assert search('join(`", "`, `["a", "b"]`)') == "a, b"
    assert search('join(`"-"`, `[]`)') == ""


# spec: N-000281
def test_N_000281_keys_and_values():
    assert search("keys(obj)") == ["k1", "k2", "k3"]
    assert search("values(obj)") == [1, None, "v"]


# spec: N-000282
def test_N_000282_type_names():
    assert search("type(s)") == "string"
    assert search("type(zero)") == "number"
    assert search("type(`true`)") == "boolean"
    assert search("type(arr)") == "array"
    assert search("type(obj)") == "object"
    assert search("type(nothing)") == "null"


# spec: N-000283
def test_N_000283_to_array():
    assert search("to_array(zero)") == [0]
    assert search("to_array(arr)") == DOC["arr"]


# spec: N-000284, N-000285
def test_N_000284_to_string_compact_json():
    assert search("to_string(`{\"a\": [1, 2]}`)") == '{"a":[1,2]}'
    assert search("to_string(`\"x\"`)") == "x"
    assert search("to_string(`null`)") == "null"
    assert search("to_string(`\"\\u00e9\"`)") == "\u00e9"


# spec: N-000286, N-000287, N-000288, N-000289
def test_N_000286_to_number():
    assert search('to_number(`"42"`)') == 42
    assert search('to_number(`"4.5"`)') == 4.5
    assert search('to_number(`"1e3"`)') == 1000.0
    assert search('to_number(`"abc"`)') is None
    assert search("to_number(`true`)") is None
    assert search("to_number(`7`)") == 7


# spec: N-000290, N-000291, N-000292
def test_N_000290_max_min():
    assert search("max(`[1, 9, 3]`)") == 9
    assert search('min(`["b", "a"]`)') == "a"
    assert search("max(`[]`)") is None
    with pytest.raises(PathSelTypeError):
        search('max(`[1, "a"]`)')


# spec: N-000293
def test_N_000293_sort():
    assert search("sort(`[3, 1, 2]`)") == [1, 2, 3]
    assert search('sort(`["b", "a"]`)') == ["a", "b"]


# spec: N-000294
def test_N_000294_sum():
    assert search("sum(`[1, 2.5]`)") == 3.5
    assert search("sum(`[]`)") == 0


# spec: N-000295, N-000296, N-000297
def test_N_000295_merge_later_key_wins():
    assert search("merge(obj, `{\"k1\": 9}`)") == {"k1": 9, "k2": None, "k3": "v"}
    assert search("merge(`{\"a\": 1}`, `{\"a\": 2}`, `{\"b\": 3}`)") == {"a": 2, "b": 3}


# spec: N-000298, N-000299, N-000300
def test_N_000298_not_null():
    assert search("not_null(nothing, obj.k2, zero, `1`)") == 0
    assert search('not_null(nothing, `""`)') == ""
    assert search("not_null(nothing)") is None


# spec: N-000301, N-000302
def test_N_000301_map_keeps_nulls():
    assert search("map(&name, people)") == ["x", "y", None]


# spec: N-000303, N-000304, N-000305
def test_N_000303_sort_by_is_stable():
    doc = [{"k": 2, "id": 1}, {"k": 1, "id": 2}, {"k": 2, "id": 3}]
    assert [e["id"] for e in search("sort_by(@, &k)", doc)] == [2, 1, 3]
    with pytest.raises(PathSelTypeError):
        search("sort_by(people, &name)")


# spec: N-000306, N-000307, N-000308
def test_N_000306_max_by_min_by_first_on_ties():
    doc = [{"k": 1, "id": "a"}, {"k": 3, "id": "b"}, {"k": 3, "id": "c"}]
    assert search("max_by(@, &k).id", doc) == "b"
    assert search("min_by(@, &k).id", doc) == "a"
    assert search("max_by(`[]`, &k)") is None


# spec: N-000309, N-000310
def test_N_000309_function_as_projection_rhs_and_argument():
    assert search("people[*].abs(age)") == [3, 7, 9]
    assert search("people[0:2].length(name)") == [1, 1]
    assert search("length(people[*].name)") == 2


# spec: N-000311, N-000312, N-000313
def test_N_000311_argument_counts():
    with pytest.raises(PathSelArityError):
        search("length(s, s)")
    with pytest.raises(PathSelArityError):
        search("merge()")
    with pytest.raises(PathSelArityError):
        search("not_null()")


# spec: N-000314, N-000315, N-000316, N-000317, N-000318
def test_N_000314_argument_types():
    with pytest.raises(PathSelTypeError):
        search("join(`1`, `[]`)")
    with pytest.raises(PathSelTypeError):
        search("map(a, arr)")
    with pytest.raises(PathSelTypeError):
        search("sum(nothing)")  # missing field is null, not an array
    with pytest.raises(PathSelTypeError):
        search('sort_by(people, &name)')


# spec: N-000321, N-000322
def test_N_000321_quoted_identifier_cannot_be_function_name():
    with pytest.raises(PathSelSyntaxError):
        search('"abs"(zero)')


# --- FP-08 and pathsel.functions: options, providers -----------------------------

class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["number", "string"]})
    def _func_add_or_cat(self, a, b):
        return a + b if isinstance(b, (int, float)) else str(a) + b

    @signature()
    def _func_zero(self):
        return 0

    @signature({"types": ["array"]})
    def _func_first(self, arr):
        return arr[0] if arr else None


# spec: N-000335, N-000336, N-000337, N-000338, N-000339, N-000340
def test_N_000335_custom_functions_called_after_checks():
    options = SimpleNamespace(custom_functions=Provider())
    assert search("add_or_cat(zero, `2`)", DOC, options) == 2
    assert search('add_or_cat(zero, `"x"`)', DOC, options) == "0x"
    assert search("zero()", DOC, options) == 0
    assert search("abs(`-1`)", DOC, options) == 1  # built-ins unchanged


# spec: N-000344, N-000345, N-000346, N-000347, N-000348, N-000349, N-000350
def test_N_000344_custom_refusals_are_the_same_kinds():
    options = SimpleNamespace(custom_functions=Provider())
    with pytest.raises(PathSelArityError):
        search("add_or_cat(zero)", DOC, options)
    with pytest.raises(PathSelTypeError):
        search("first(zero)", DOC, options)
    with pytest.raises(PathSelTypeError):
        search("add_or_cat(zero, `true`)", DOC, options)
    with pytest.raises(PathSelUnknownFunctionError):
        search("nope()", DOC, options)


# spec: N-000342, N-000343
def test_N_000342_compile_without_provider_succeeds_search_refuses():
    compiled = pathsel.compile("zero()")
    with pytest.raises(PathSelUnknownFunctionError):
        compiled.search(DOC)
    options = SimpleNamespace(custom_functions=Provider())
    assert compiled.search(DOC, options) == search("zero()", DOC, options)


# spec: N-000344
def test_N_000344_name_on_other_provider_is_unknown():
    class Other(Functions):
        pass

    with pytest.raises(PathSelUnknownFunctionError):
        search("zero()", DOC, SimpleNamespace(custom_functions=Other()))


# spec: N-000323, N-000324, N-000325, N-000326, N-000327, N-000328, N-000329, N-000330, N-000331, N-000332, N-000341
def test_N_000328_dict_cls_builds_constructed_hashes():
    options = SimpleNamespace(dict_cls=OrderedDict, custom_functions=None)
    result = search("{x: zero}", DOC, options)
    assert isinstance(result, OrderedDict)
    assert search("keys({x: zero})", DOC, options) == ["x"]
    assert search("length({x: zero, y: zero})", DOC, options) == 2
    # Constructed hashes are objects whatever the supplied type. # spec: N-000330
    assert search("{x: zero}.x", DOC, options) == 0
    # Accepted where a function requires an object (OrderedDict supplied). # spec: N-000333
    assert search("merge({x: zero})", DOC, options) == {"x": 0}
    assert isinstance(search("{x: zero}", DOC), dict)


# spec: N-000334
def test_N_000334_constructed_hash_without_mapping_type_is_plain_dict():
    assert type(search("{x: zero}")) is dict


# spec: N-000389, N-000390, N-000391, N-000392
def test_N_000389_options_are_read_by_attribute():
    options = SimpleNamespace(dict_cls=None, custom_functions=None)
    assert search("a.b.c", DOC, options) == 1


# spec: N-000372, N-000373, N-000374
def test_N_000372_package_root_exports():
    assert callable(pathsel.search)
    assert callable(pathsel.compile)


# spec: N-000367, N-000368
def test_N_000367_is_library_only():
    assert not hasattr(pathsel, "main")


# spec: N-000393, N-000394, N-000400, N-000401, N-000402, N-000403, N-000404
def test_N_000393_functions_module_api():
    from pathsel.functions import Functions as F, signature as S

    assert F is Functions and callable(S)
    with pytest.raises(ValueError):
        S({"types": ["boolean"]})(lambda self: None)


# spec: N-000050, N-000051, N-000052, N-000053, N-000054, N-000055, N-000056, N-000057, N-000058
def test_N_000056_host_values_are_selectable_and_returned():
    class Host:
        pass

    host = Host()
    assert search("h", {"h": host}) is host
    assert search("d", {"d": Decimal("1.5")}) == Decimal("1.5")
    assert search("d > `1`", {"d": Decimal("1.5")}) is True
    # Host decimals are numbers for comparison only; functions refuse them. # spec: N-000056
    with pytest.raises(PathSelTypeError):
        search("abs(d)", {"d": Decimal("1.5")})


# spec: N-000059, N-000060, N-000061, N-000062, N-000063, N-000064, N-000065, N-000066
def test_N_000059_failure_wording_is_free_but_kind_is_required():
    with pytest.raises(PathSelError) as info:
        search("a.")
    assert isinstance(info.value, PathSelSyntaxError)
    assert info.value.lex_position == 2


# spec: N-000038, N-000039, N-000040, N-000049
def test_N_000038_public_entries_are_search_and_compile():
    assert pathsel.search("a.b.c", DOC) == 1
    assert pathsel.compile("a.b.c").search(DOC) == 1


# spec: N-000007
def test_N_000007_both_paths_agree_with_options():
    options = SimpleNamespace(dict_cls=OrderedDict, custom_functions=Provider())
    for text in ["zero()", "{x: zero}", "people[*].name"]:
        assert pathsel.compile(text).search(DOC, options) == search(text, DOC, options)
