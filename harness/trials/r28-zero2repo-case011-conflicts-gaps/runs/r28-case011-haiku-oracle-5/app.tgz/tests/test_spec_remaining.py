"""Tests for spec ids not covered by test_pathsel.py: terms, constraints,
packaging, failure carriers and interface signatures.
"""

import ast
import inspect
import pathlib
import sys
from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import (
    Functions,
    PathSelArityError,
    PathSelEmptyError,
    PathSelError,
    PathSelIncompleteError,
    PathSelSyntaxError,
    PathSelTokenError,
    PathSelTypeError,
    PathSelUnknownFunctionError,
    PathSelZeroStepError,
    signature,
)
from pathsel.values import ExpressionReference

ROOT = pathlib.Path(__file__).resolve().parent.parent
PACKAGE = ROOT / "pathsel"


def search(expr, doc, options=None):
    return pathsel.search(expr, doc, options)


# --- FP-01 entries and public surface -----------------------------------------

# spec: N-000010, N-000011, N-000012, N-000013
def test_N_000010_overview_both_paths_agree_and_absent_path_is_null():
    doc = {"a": {"b": 1}}
    assert search("a.b", doc) == pathsel.compile("a.b").search(doc) == 1
    assert search("a.zz", doc) is None


# spec: N-000073, N-000074, N-000075, N-000076
def test_N_000073_entries_take_text_document_and_options():
    compiled = pathsel.compile("a")
    assert isinstance(compiled, pathsel.ParsedExpression)
    assert compiled.search({"a": 2}) == 2
    assert compiled.search({"a": 3}, None) == 3
    assert search("a", {"a": 4}, None) == 4


# spec: N-000042
def test_N_000042_refused_text_never_succeeds():
    for text in ["", "a.", "a-b"]:
        with pytest.raises(PathSelError):
            pathsel.compile(text)


# spec: N-000043
def test_N_000043_identifiers_and_subexpressions():
    assert search("a.b . c", {"a": {"b": {"c": 5}}}) == 5


# spec: N-000044
def test_N_000044_index_slice_and_flatten():
    assert search("[-1]", [1, 2]) == 2
    assert search("[0:1]", [1, 2]) == [1]
    assert search("[]", [[1], 2]) == [1, 2]


# spec: N-000045
def test_N_000045_projections():
    assert search("[*].a", [{"a": 1}, {"a": 2}]) == [1, 2]
    assert search("[?a > `1`]", [{"a": 1}, {"a": 2}]) == [{"a": 2}]


# spec: N-000046
def test_N_000046_constructs_pipe_literals_and_refs():
    assert search("{x: a}", {"a": 1}) == {"x": 1}
    assert search("a | @", {"a": 1}) == 1
    assert search("`2`", {}) == 2
    assert search("'raw'", {}) == "raw"
    assert isinstance(search("&a", {}), ExpressionReference)


# spec: N-000047
def test_N_000047_compare_and_logic():
    assert search("a == `1` && b != `2`", {"a": 1, "b": 3}) is True


# spec: N-000048
def test_N_000048_builtin_call():
    assert search("length(a)", {"a": "xyz"}) == 3


# --- Non-goals and constraints ------------------------------------------------

# spec: N-000067, N-000068
def test_N_000067_no_json_reader_is_offered():
    public = [name for name in dir(pathsel) if not name.startswith("_")]
    assert not any("json" in name.lower() for name in public)


# spec: N-000069, N-000070
def test_N_000069_input_document_is_not_mutated():
    doc = {"a": [1, {"b": 2}], "c": {"d": 3}}
    before = repr(doc)
    search("a[*]", doc)
    search("[?b == `2`]", doc["a"])
    search("merge(c, `{\"x\": 1}`)", doc)
    search("c.d | @", doc)
    assert repr(doc) == before


# spec: N-000071, N-000072
def test_N_000071_no_dev_tooling_in_public_surface():
    public = {name for name in dir(pathsel) if not name.startswith("_")}
    assert not {"cache", "clear_cache", "main"} & public


# --- Terms (Terminology table) -------------------------------------------------

# spec: N-000014, N-000015
def test_N_000014_expression_is_unicode_text_and_document_nests_types():
    doc = {"été": [1, "two", True, None, {"k": 0.5}]}
    assert search('"été"[4].k', doc) == 0.5
    with pytest.raises(PathSelTokenError):
        search("été", doc)  # unquoted identifiers are ASCII only


# spec: N-000016, N-000017, N-000018
def test_N_000016_search_and_compile_entries_and_parsed_reuse():
    parsed = pathsel.compile("x")
    assert search("x", {"x": 1}) == parsed.search({"x": 1}) == 1
    assert parsed.search({"x": 2}) == 2


# spec: N-000019, N-000020
def test_N_000019_current_value_is_the_element_in_a_projection():
    assert search("[*].[@, @]", [1, 2]) == [[1, 1], [2, 2]]


# spec: N-000021, N-000022
def test_N_000021_null_and_not_null():
    assert search("not_null(a, `\"\"`)", {"a": None}) == ""
    assert search("not_null(a)", {"a": None}) is None


# spec: N-000023, N-000024, N-000025
def test_N_000023_numbers_include_host_decimals_for_comparison():
    from decimal import Decimal

    assert search("d < `2`", {"d": Decimal("1.5")}) is True
    assert search("d == `1.5`", {"d": Decimal("1.5")}) is True
    assert search("to_number(`\"7\"`)", {}) == 7


# spec: N-000026
def test_N_000026_string_length_counts_characters_for_length_function():
    assert search("length(a)", {"a": "éé"}) == 2


# spec: N-000027
def test_N_000027_boolean_is_not_number():
    assert search("a == `1`", {"a": True}) is False
    assert search("a == `0`", {"a": False}) is False


# spec: N-000028
def test_N_000028_expression_reference_value_outside_argument():
    assert isinstance(search("&a", {"a": 1}), ExpressionReference)


# spec: N-000029
def test_N_000029_false_values_for_logic_and_not():
    for value in [False, None, "", [], {}]:
        assert search("!a", {"a": value}) is True
    for value in [0, 0.0, "x", [0], {"k": 1}, True]:
        assert search("!a", {"a": value}) is False


# spec: N-000030, N-000031
def test_N_000030_projection_drops_nulls_and_object_wildcard_on_non_object():
    assert search("a[*].x", {"a": [{"x": 1}, {}]}) == [1]
    assert search("a.*", {"a": 5}) is None


# spec: N-000032
def test_N_000032_evaluation_options_term():
    options = SimpleNamespace(dict_cls=OrderedDict, custom_functions=None)
    assert isinstance(search("{x: a}", {"a": 1}, options), OrderedDict)


# spec: N-000033
def test_N_000033_builtin_function_is_called_by_name_with_parentheses():
    assert search("max(a)", {"a": [1, 3]}) == 3
    with pytest.raises(PathSelSyntaxError):
        search("max a", {"a": [1, 3]})


# spec: N-000034, N-000035, N-000036, N-000037
def test_N_000034_failure_kinds_are_distinct_value_errors():
    kinds = [
        PathSelEmptyError,
        PathSelIncompleteError,
        PathSelSyntaxError,
        PathSelZeroStepError,
        PathSelUnknownFunctionError,
        PathSelArityError,
        PathSelTypeError,
    ]
    for kind in kinds:
        assert issubclass(kind, ValueError)
    assert len(set(kinds)) == len(kinds)


# --- Syntax and token forms ----------------------------------------------------

# spec: N-000097
def test_N_000097_grammar_level_failures_share_one_type():
    with pytest.raises(PathSelSyntaxError) as first:
        search("a.", {})
    with pytest.raises(PathSelSyntaxError) as second:
        search("a b", {})
    assert type(first.value) is type(second.value)


# spec: N-000118, N-000120, N-000122
def test_N_000118_quoted_hyphen_key_selected_unquoted_hyphen_refused():
    assert search('a."with-dash"', {"a": {"with-dash": 1}}) == 1
    with pytest.raises(PathSelTokenError):
        search("a-dash", {"a": {}})


# spec: N-000125
def test_N_000125_missing_field_yields_null_at_any_depth():
    assert search("a.b.c.d.e", {"a": {"b": {}}}) is None


# spec: N-000158
def test_N_000158_projection_forms_are_list_object_filter():
    assert search("a[*].b", {"a": [{"b": 1}]}) == [1]
    assert search("a.*", {"a": {"k": 2}}) == [2]
    assert search("a[?b]", {"a": [{"b": 1}, {}]}) == [{"b": 1}]


# spec: N-000198, N-000199
def test_N_000198_implementer_placements_chosen():
    # A slice written after an index starts a projection (chosen).
    assert search("a[0][0:1]", {"a": [[[1, 2]]]}) == [[1, 2]]
    # Later steps join a right-hand side that begins with a dot and a hash (chosen).
    assert search("a[*].{n: n}.n", {"a": [{"n": 1}, {"n": 2}]}) == [1, 2]


# spec: N-000238
def test_N_000238_literal_after_dot_is_grammar_syntax():
    with pytest.raises(PathSelSyntaxError) as info:
        search("a.`1`", {})
    assert not isinstance(info.value, PathSelTokenError)


# spec: N-000265
def test_N_000265_argument_count_and_types_checked_for_builtins():
    with pytest.raises(PathSelArityError):
        search("abs(a, a)", {"a": 1})
    with pytest.raises(PathSelTypeError):
        search("abs(a)", {"a": "x"})


# spec: N-000319, N-000320
def test_N_000319_keys_of_sort_by_and_max_by_must_be_all_numbers_or_strings():
    with pytest.raises(PathSelTypeError):
        search("sort_by(a, &k)", {"a": [{"k": 1}, {"k": "x"}]})
    with pytest.raises(PathSelTypeError):
        search("max_by(a, &k)", {"a": [{"k": True}]})
    assert search("sort_by(a, &k)", {"a": [{"k": "b"}, {"k": "a"}]}) == [{"k": "a"}, {"k": "b"}]


# --- Packaging and hardware ----------------------------------------------------

def _pathsel_sources():
    return sorted(PACKAGE.glob("*.py"))


def _imported_top_level_modules(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names.add(node.module.split(".")[0])
    return names


# spec: N-000351, N-000352, N-000361, N-000362
def test_N_000351_only_standard_library_imports():
    stdlib = set(sys.stdlib_module_names)
    for path in _pathsel_sources():
        for module in _imported_top_level_modules(path):
            assert module in stdlib, (path.name, module)


# spec: N-000353, N-000360, N-000364
def test_N_000353_python_39_syntax_only():
    for path in _pathsel_sources():
        ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 9))


# spec: N-000354, N-000355, N-000356, N-000357, N-000358, N-000359, N-000363, N-000365, N-000369, N-000370
def test_N_000355_flat_layout_at_repository_root():
    assert (ROOT / "pathsel" / "__init__.py").is_file()
    assert (ROOT / "pyproject.toml").is_file()
    assert pathsel.__file__.startswith(str(ROOT))


# spec: N-000366
def test_N_000366_no_command_line_entry():
    assert not (PACKAGE / "__main__.py").exists()


# spec: N-000371
def test_N_000371_import_performs_no_io_or_processes():
    banned = {"socket", "subprocess", "urllib", "http", "requests"}
    for path in _pathsel_sources():
        assert not (_imported_top_level_modules(path) & banned), path.name
        assert "open(" not in path.read_text(encoding="utf-8"), path.name


# --- Interface contract signatures ---------------------------------------------

# spec: N-000372, N-000373, N-000374
def test_N_000372_root_names_search_and_compile():
    assert inspect.signature(pathsel.search).parameters.keys() >= {"expression", "data", "options"}
    assert list(inspect.signature(pathsel.compile).parameters) == ["expression"]


# spec: N-000375, N-000376, N-000377, N-000378, N-000379, N-000380, N-000381, N-000382
def test_N_000375_search_positional_parameters_and_return():
    assert search("a", {"a": None}) is None
    assert search("a", {"a": 1}, None) == 1


# spec: N-000383, N-000384, N-000385, N-000386, N-000387, N-000388
def test_N_000383_compile_returns_parsed_object_with_search():
    parsed = pathsel.compile("a")
    assert parsed is not None
    assert parsed.search({"a": 9}, None) == 9


# spec: N-000395, N-000396, N-000397, N-000398, N-000399
def test_N_000395_provider_methods_define_functions_and_receive_instance():
    seen = {}

    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_probe(self, x):
            seen["self"] = self
            return x + 1

    provider = Provider()
    options = SimpleNamespace(custom_functions=provider)
    assert search("probe(a)", {"a": 1}, options) == 2
    assert seen["self"] is provider


# --- Failure carriers ----------------------------------------------------------

# spec: N-000406, N-000407, N-000408
def test_N_000406_kind_is_the_exception_type_not_the_message():
    with pytest.raises(PathSelSyntaxError) as first:
        search("a.", {})
    with pytest.raises(PathSelSyntaxError) as second:
        search("a b", {})
    assert type(first.value) is type(second.value)
    assert str(first.value) != str(second.value)


# spec: N-000409, N-000410, N-000413, N-000414
def test_N_000409_empty_incomplete_syntax_are_three_types():
    with pytest.raises(PathSelEmptyError) as empty:
        search("", {})
    with pytest.raises(PathSelIncompleteError) as incomplete:
        search(" ", {})
    with pytest.raises(PathSelSyntaxError) as syntax:
        search("a.", {})
    assert type(empty.value) is not type(incomplete.value) is not type(syntax.value)
    assert not isinstance(syntax.value, (PathSelEmptyError, PathSelIncompleteError))


# spec: N-000411, N-000412
def test_N_000411_token_form_is_subclass_of_syntax_type():
    with pytest.raises(PathSelTokenError) as info:
        search("a-b", {})
    grammar = PathSelSyntaxError("x", 0)
    assert isinstance(info.value, type(grammar))
    assert type(info.value) is not type(grammar)


# spec: N-000416, N-000417, N-000418, N-000419, N-000420
def test_N_000416_function_kinds_are_own_types_and_not_each_other():
    with pytest.raises(PathSelUnknownFunctionError) as unknown:
        search("nope(a)", {"a": 1})
    with pytest.raises(PathSelArityError) as arity:
        search("abs()", {})
    with pytest.raises(PathSelTypeError) as typed:
        search("abs(a)", {"a": "s"})
    kinds = [unknown.value, arity.value, typed.value]
    for value in kinds:
        assert not isinstance(value, (PathSelEmptyError, PathSelIncompleteError, PathSelSyntaxError))
    assert not isinstance(arity.value, PathSelUnknownFunctionError)
    assert not isinstance(typed.value, (PathSelUnknownFunctionError, PathSelArityError))


# spec: N-000421, N-000422
def test_N_000421_syntax_and_incomplete_carry_int_position():
    for text in ["a b", "a.", " "]:
        with pytest.raises(PathSelError) as info:
            search(text, {})
        assert isinstance(info.value.lex_position, int)
        assert 0 <= info.value.lex_position <= len(text)


# spec: N-000084
def test_N_000084_identifier_on_scalar_or_null_is_null_not_failure():
    assert search("a.b", {"a": 5}) is None
    assert search("a.b", {"a": "text"}) is None
    assert search("a.b", {"a": None}) is None
    assert search("a.b", {"a": [1]}) is None
