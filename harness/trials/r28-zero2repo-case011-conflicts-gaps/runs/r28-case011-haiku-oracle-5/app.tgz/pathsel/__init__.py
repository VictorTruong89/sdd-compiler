"""pathsel: evaluate PathSel expressions against ordinary Python data.

Two entries produce the same result for the same expression and document:

* ``search(expression, data, options=None)`` — one shot.
* ``compile(expression)`` — returns a parsed expression whose
  ``.search(value, options=None)`` may be called many times.

Every refusal raises a subclass of ``ValueError`` (see ``pathsel.errors``).

# spec: N-000366, N-000367, N-000368, N-000369, N-000370, N-000371, N-000372, N-000373, N-000374, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380, N-000381, N-000382, N-000383, N-000384, N-000385, N-000386, N-000387, N-000388, N-000073, N-000076
"""

# spec (overview, entries, public surface, product form): N-000001, N-000004, N-000005, N-000006, N-000007, N-000008, N-000009, N-000010, N-000011, N-000012, N-000013, N-000016, N-000017, N-000038, N-000039, N-000040, N-000041, N-000042, N-000043, N-000044, N-000045, N-000046, N-000047, N-000048, N-000049, N-000050, N-000051, N-000052, N-000053, N-000054, N-000055, N-000067, N-000068, N-000069, N-000070, N-000071, N-000072, N-000351, N-000352, N-000353, N-000354, N-000355, N-000356, N-000357, N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364, N-000365
from .errors import (
    PathSelArityError,
    PathSelEmptyError,
    PathSelError,
    PathSelIncompleteError,
    PathSelSyntaxError,
    PathSelTokenError,
    PathSelTypeError,
    PathSelUnknownFunctionError,
    PathSelZeroStepError,
)
from .functions import Functions, signature
from .parser import ParsedExpression, parse as _parse
from .values import ExpressionReference

__all__ = [
    "compile",
    "search",
    "ParsedExpression",
    "Functions",
    "signature",
    "ExpressionReference",
    "PathSelError",
    "PathSelEmptyError",
    "PathSelIncompleteError",
    "PathSelSyntaxError",
    "PathSelTokenError",
    "PathSelZeroStepError",
    "PathSelUnknownFunctionError",
    "PathSelArityError",
    "PathSelTypeError",
]

__version__ = "0.1.0"


def compile(expression):
    """Parse an expression once. Returns a ParsedExpression or raises a PathSelError."""
    return _parse(expression)


def search(expression, data, options=None):
    """Evaluate an expression against data and return the selected value."""
    return _parse(expression).search(data, options)
