"""Value model helpers: truthiness, JSON equality, number and type predicates.

# spec: N-000056, N-000057, N-000058, N-000242, N-000243, N-000244, N-000245, N-000246, N-000251, N-000252
"""

# spec (terms): N-000014, N-000015, N-000019, N-000020, N-000021, N-000022, N-000023, N-000024, N-000025, N-000026, N-000027, N-000028, N-000029, N-000030, N-000031, N-000033
from collections.abc import Mapping
from decimal import Decimal


class ExpressionReference:
    """A deferred subexpression written ``&expr``.

    Searching a bare expression reference yields one of these (a non-None
    value of the implementer's choice). Built-in functions apply ``node`` to
    each element. # spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423
    """

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def __repr__(self):
        return "<ExpressionReference>"


def is_bool(value):
    return isinstance(value, bool)


def is_number(value):
    """A JSON number: an int or float that is not a boolean. Host Decimal is not included."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_comparable_number(value):
    """A number for comparison purposes: JSON numbers plus host decimals. # spec: N-000246"""
    return is_number(value) or isinstance(value, Decimal)


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, Mapping)


def is_string(value):
    return isinstance(value, str)


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object. # spec: N-000022 (Terminology), N-000249, N-000250, N-000251"""
    if value is None:
        return True
    if isinstance(value, bool):
        return not value
    if isinstance(value, (str, list, tuple)):
        return len(value) == 0
    if isinstance(value, Mapping):
        return len(value) == 0
    return False


def json_equal(left, right):
    """JSON value equality: deep for arrays and objects; a number is never equal to a boolean. # spec: N-000242, N-000243, N-000244"""
    if isinstance(left, bool) or isinstance(right, bool):
        return isinstance(left, bool) and isinstance(right, bool) and left == right
    if left is None or right is None:
        return left is None and right is None
    if is_comparable_number(left) and is_comparable_number(right):
        return left == right
    if is_comparable_number(left) or is_comparable_number(right):
        return False
    if isinstance(left, str) or isinstance(right, str):
        return isinstance(left, str) and isinstance(right, str) and left == right
    if is_array(left) and is_array(right):
        if len(left) != len(right):
            return False
        return all(json_equal(a, b) for a, b in zip(left, right))
    if is_object(left) and is_object(right):
        if len(left) != len(right):
            return False
        for key in left:
            if key not in right:
                return False
            if not json_equal(left[key], right[key]):
                return False
        return True
    return left == right
