"""Public provider API for custom language functions.

A caller subclasses :class:`Functions` and adds methods named ``_func_<name>``
decorated with :func:`signature`. The provider instance is attached as the
``custom_functions`` evaluation option.

# spec: N-000393, N-000394, N-000395, N-000396, N-000397, N-000398, N-000399, N-000400
# spec: N-000401, N-000402, N-000403, N-000404, N-000335, N-000336, N-000337, N-000338
# spec: N-000339, N-000340
"""

# spec (provider product form): N-000336
from collections.abc import Mapping

from .values import is_array, is_number, is_object

SIGNATURE_ATTRIBUTE = "__pathsel_signature__"
_TYPE_NAMES = ("number", "string", "array", "object", "null")
_PREFIX = "_func_"


def signature(*arguments):
    """Declare the accepted types of each argument of a custom function.

    Each argument is ``{"types": [<type-name>, ...]}`` where a type name is one
    of ``number``, ``string``, ``array``, ``object`` or ``null``. The decorator
    only records the declaration; it does not call the implementation.
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise ValueError('each signature argument must be {"types": [...]}')
        types = argument["types"]
        if not isinstance(types, (list, tuple)) or not types:
            raise ValueError("signature types must be a non-empty list")
        for name in types:
            if name not in _TYPE_NAMES:
                raise ValueError("unknown signature type %r" % (name,))
        specs.append(tuple(types))
    specs = tuple(specs)

    def decorator(func):
        if not callable(func):
            raise TypeError("signature must decorate a callable")
        setattr(func, SIGNATURE_ATTRIBUTE, specs)
        return func

    return decorator


class Functions:
    """Provider base class. Subclass it and add ``_func_<name>`` methods.

    Built-in names (FP-07) always resolve to the built-in implementation; a
    provider method with a built-in name does not replace it.
    """

    def __init__(self):
        pass


def value_matches_type(value, type_name):
    """Whether a value is in one of the declared signature types. # spec: N-000402, N-000404"""
    if type_name == "number":
        return is_number(value)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "array":
        return is_array(value)
    if type_name == "object":
        return is_object(value)
    if type_name == "null":
        return value is None
    return False


def find_provider_function(provider, name):
    """Return the bound provider method for ``name`` or None. # spec: N-000344"""
    if provider is None:
        return None
    attribute = getattr(provider, _PREFIX + name, None)
    if attribute is None or not hasattr(attribute, SIGNATURE_ATTRIBUTE):
        return None
    return attribute
