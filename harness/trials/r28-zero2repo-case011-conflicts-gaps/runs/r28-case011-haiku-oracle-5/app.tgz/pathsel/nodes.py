"""Expression tree and evaluation.

Every node evaluates against a current value and an evaluation context
``ctx`` (carrying the mapping type and the custom-function provider).

# spec: N-000077, N-000078, N-000079, N-000083, N-000084, N-000085
# spec: N-000126, N-000128, N-000129, N-000130, N-000131, N-000132, N-000133, N-000134
# spec: N-000135, N-000136, N-000137, N-000138, N-000139, N-000140, N-000141, N-000142
# spec: N-000143, N-000144, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151
# spec: N-000159, N-000160, N-000161, N-000162, N-000163, N-000164, N-000165
# spec: N-000166, N-000167, N-000168, N-000169, N-000170, N-000171, N-000172, N-000173
# spec: N-000174, N-000175, N-000176, N-000177, N-000178, N-000179, N-000180, N-000181
# spec: N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190
# spec: N-000191, N-000192, N-000193, N-000194, N-000195, N-000196, N-000197
# spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000211, N-000212, N-000213
# spec: N-000214, N-000215, N-000216, N-000217, N-000218, N-000219, N-000221, N-000222
# spec: N-000223, N-000225, N-000226, N-000231, N-000232, N-000233, N-000234, N-000235, N-000236
# spec: N-000247, N-000248, N-000249, N-000250, N-000251, N-000252, N-000253, N-000254, N-000255, N-000256, N-000257, N-000258, N-000259
# spec: N-000200, N-000201, N-000202, N-000203, N-000204, N-000205
"""

# spec (missing is null, field on non-object, constructed hashes, projection reach): N-000059, N-000060, N-000061, N-000062, N-000063, N-000064, N-000065, N-000066, N-000115, N-000116, N-000158, N-000182, N-000330, N-000018
from . import calls
from .errors import PathSelZeroStepError
from .values import (
    ExpressionReference,
    is_array,
    is_comparable_number,
    is_false,
    is_object,
    json_equal,
)


class Node:
    __slots__ = ()

    def eval(self, cur, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Identity(Node):
    """The current value (``@``)."""

    __slots__ = ()

    def eval(self, cur, ctx):
        return cur


class Literal(Node):
    """A JSON literal or raw string literal."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, cur, ctx):
        return self.value


class Field(Node):
    """An identifier (quoted or unquoted) selecting a key of an object. # spec: N-000002, N-000003"""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, cur, ctx):
        if is_object(cur):
            return cur.get(self.name)
        return None


class Subexpr(Node):
    """``left.right``: evaluate right against the value of left."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Index(Node):
    """``left[n]`` with negative indices counting from the end."""

    __slots__ = ("left", "index")

    def __init__(self, left, index):
        self.left = left
        self.index = index

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not is_array(value):
            return None
        length = len(value)
        i = self.index + length if self.index < 0 else self.index
        if 0 <= i < length:
            return value[i]
        return None


class Pipe(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not is_false(value):
            return value
        return self.right.eval(cur, ctx)


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if is_false(value):
            return value
        return self.right.eval(cur, ctx)


class Not(Node):
    __slots__ = ("child",)

    def __init__(self, child):
        self.child = child

    def eval(self, cur, ctx):
        return is_false(self.child.eval(cur, ctx))


class Compare(Node):
    """``==``, ``!=``, ``<``, ``<=``, ``>``, ``>=``.

    Ordering comparisons on operands that are not both numbers or both strings
    yield null. # spec: N-000245, N-000246 (choice for the unspecified case)
    """

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        a = self.left.eval(cur, ctx)
        b = self.right.eval(cur, ctx)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        numeric = is_comparable_number(a) and is_comparable_number(b)
        textual = isinstance(a, str) and isinstance(b, str)
        if not (numeric or textual):
            return None
        if self.op == "<":
            return a < b
        if self.op == "<=":
            return a <= b
        if self.op == ">":
            return a > b
        return a >= b


class MultiList(Node):
    __slots__ = ("elements",)

    def __init__(self, elements):
        self.elements = elements

    def eval(self, cur, ctx):
        if cur is None:
            return None
        return [e.eval(cur, ctx) for e in self.elements]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, cur, ctx):
        if cur is None:
            return None
        result = ctx.new_mapping()
        for key, value in self.pairs:
            result[key] = value.eval(cur, ctx)
        return result


class ExprRef(Node):
    """``&expr``: a deferred subexpression, not evaluated here."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return ExpressionReference(self.node)


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, cur, ctx):
        return calls.call(self.name, self.args, cur, ctx)


class Slice:
    """Slice parameters (start, stop, step) and the index computation. Not a node."""

    __slots__ = ("start", "stop", "step")

    def __init__(self, start, stop, step):
        if step == 0:
            # Refused at compile time; the search would refuse the same way. # spec: N-000152, N-000153, N-000154
            raise PathSelZeroStepError("slice step of 0 is refused")
        self.start = start
        self.stop = stop
        self.step = 1 if step is None else step

    def indices(self, length):
        step = self.step
        start, stop = self.start, self.stop
        if step > 0:
            s = 0 if start is None else (start + length if start < 0 else start)
            e = length if stop is None else (stop + length if stop < 0 else stop)
            s = min(max(s, 0), length)
            e = min(max(e, 0), length)
        else:
            s = length - 1 if start is None else (start + length if start < 0 else start)
            e = -1 if stop is None else (stop + length if stop < 0 else stop)
            s = min(max(s, -1), length - 1)
            e = min(max(e, -1), length - 1)
        return range(s, e, step)


def project(elements, rhs, ctx):
    """Apply the right-hand side to each element; keep the non-null results."""
    out = []
    for element in elements:
        result = rhs.eval(element, ctx)
        if result is not None:
            out.append(result)
    return out


class Projection(Node):
    """Base for projection-starting forms.

    ``source`` yields the value to project over; ``select`` turns that value
    into the elements (or None if the form does not apply to the value).
    """

    __slots__ = ("source", "rhs")

    def __init__(self, source, rhs):
        self.source = source
        self.rhs = rhs

    def select(self, value, ctx):  # pragma: no cover - abstract
        raise NotImplementedError

    def eval(self, cur, ctx):
        elements = self.select(self.source.eval(cur, ctx), ctx)
        if elements is None:
            return None
        return project(elements, self.rhs, ctx)


class ListProjection(Projection):
    """``[*]``: each element of an array."""

    __slots__ = ()

    def select(self, value, ctx):
        return value if is_array(value) else None


class ObjectProjection(Projection):
    """``*`` / ``<expr>.*``: each value of an object, in iteration order."""

    __slots__ = ()

    def select(self, value, ctx):
        if is_object(value):
            return list(value.values())
        return None


class FlattenProjection(Projection):
    """``[]``: one level of flattening."""

    __slots__ = ()

    def select(self, value, ctx):
        if not is_array(value):
            return None
        flat = []
        for element in value:
            if is_array(element):
                flat.extend(element)
            else:
                flat.append(element)
        return flat


class SliceProjection(Projection):
    __slots__ = ("slice",)

    def __init__(self, source, slc, rhs):
        super().__init__(source, rhs)
        self.slice = slc

    def select(self, value, ctx):
        if not is_array(value):
            return None
        return [value[i] for i in self.slice.indices(len(value))]


class FilterProjection(Projection):
    """``[?predicate]``: keeps elements whose predicate is a true value."""

    __slots__ = ("predicate",)

    def __init__(self, source, predicate, rhs):
        super().__init__(source, rhs)
        self.predicate = predicate

    def select(self, value, ctx):
        if not is_array(value):
            return None
        return [e for e in value if not is_false(self.predicate.eval(e, ctx))]
