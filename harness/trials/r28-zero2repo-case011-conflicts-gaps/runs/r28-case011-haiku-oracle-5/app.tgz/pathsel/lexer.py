"""Lazy tokenizer for the PathSel language.

Tokens are produced on demand so that a token-level failure is only raised
when the parser reaches the offending text. This keeps the reported position
at the first point where the expression stops being well-formed.

# spec: N-000107, N-000108, N-000109, N-000110, N-000111, N-000112, N-000113, N-000114
# spec: N-000117, N-000118, N-000119, N-000120, N-000121, N-000122, N-000124
# spec: N-000227, N-000228, N-000229, N-000230, N-000237, N-000238, N-000239
# spec: N-000260, N-000261
"""

# spec (literal forms): N-000224, N-000225, N-000226, N-000236
import json
import string

from .errors import PathSelTokenError

WHITESPACE = " \t\n\r"
_IDENT_START = frozenset(string.ascii_letters + "_")
_IDENT_CHARS = frozenset(string.ascii_letters + string.digits + "_")
_DIGITS = frozenset(string.digits)
_HEX = frozenset(string.hexdigits)


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.kind, self.value, self.pos)


def _reject_constant(name):
    raise ValueError("non-JSON constant %s" % name)


def _read_json(text):
    """Read text as strict JSON (NaN and Infinity are not JSON)."""
    return json.loads(text, parse_constant=_reject_constant)


class Lexer:
    def __init__(self, text):
        self.text = text
        self.n = len(text)
        self.i = 0

    def _error(self, pos, message):
        return PathSelTokenError(message, pos)

    def next_token(self):
        text = self.text
        n = self.n
        while self.i < n and text[self.i] in WHITESPACE:
            self.i += 1
        start = self.i
        if start >= n:
            return Token("EOF", None, n)
        c = text[start]

        if c in _IDENT_START:
            j = start + 1
            while j < n and text[j] in _IDENT_CHARS:
                j += 1
            self.i = j
            return Token("IDENT", text[start:j], start)

        if c in _DIGITS:
            return self._number(start, start)

        if c == "-":
            if start + 1 < n and text[start + 1] in _DIGITS:
                return self._number(start, start + 1)
            raise self._error(start, "a lone hyphen begins no token")

        if c == '"':
            return self._quoted_identifier(start)

        if c == "'":
            return self._raw_string(start)

        if c == "`":
            return self._json_literal(start)

        if c == "[":
            j = start + 1
            while j < n and text[j] in WHITESPACE:
                j += 1
            if j < n and text[j] == "]":
                self.i = j + 1
                return Token("FLATTEN", "[]", start)
            if j < n and text[j] == "?":
                self.i = j + 1
                return Token("FILTER", "[?", start)
            self.i = start + 1
            return Token("LBRACKET", "[", start)

        simple = {
            ".": "DOT",
            "*": "STAR",
            "]": "RBRACKET",
            "{": "LBRACE",
            "}": "RBRACE",
            "(": "LPAREN",
            ")": "RPAREN",
            ",": "COMMA",
            ":": "COLON",
            "@": "AT",
        }
        if c in simple:
            self.i = start + 1
            return Token(simple[c], c, start)

        if c == "|":
            if start + 1 < n and text[start + 1] == "|":
                self.i = start + 2
                return Token("OR", "||", start)
            self.i = start + 1
            return Token("PIPE", "|", start)

        if c == "&":
            if start + 1 < n and text[start + 1] == "&":
                self.i = start + 2
                return Token("AND", "&&", start)
            self.i = start + 1
            return Token("AMP", "&", start)

        if c == "!":
            if start + 1 < n and text[start + 1] == "=":
                self.i = start + 2
                return Token("NE", "!=", start)
            self.i = start + 1
            return Token("NOT", "!", start)

        if c == "=":
            if start + 1 < n and text[start + 1] == "=":
                self.i = start + 2
                return Token("EQ", "==", start)
            raise self._error(start, "a lone '=' is not an operator; use '=='")

        if c in "<>":
            if start + 1 < n and text[start + 1] == "=":
                self.i = start + 2
                return Token("LE" if c == "<" else "GE", c + "=", start)
            self.i = start + 1
            return Token("LT" if c == "<" else "GT", c, start)

        raise self._error(start, "character %r begins no token" % c)

    def _number(self, start, digits_start):
        text = self.text
        j = digits_start
        while j < self.n and text[j] in _DIGITS:
            j += 1
        self.i = j
        return Token("NUMBER", int(text[start:j]), start)

    def _quoted_identifier(self, start):
        text = self.text
        n = self.n
        j = start + 1
        while True:
            if j >= n:
                raise self._error(start, "unterminated quoted identifier")
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == '"':
                break
            j += 1
        raw = text[start:j + 1]
        try:
            value = _read_json(raw)
        except ValueError:
            raise self._error(start, "quoted identifier is not a legal JSON string")
        self.i = j + 1
        return Token("QIDENT", value, start)

    def _raw_string(self, start):
        text = self.text
        n = self.n
        out = []
        j = start + 1
        while True:
            if j >= n:
                raise self._error(start, "unterminated raw string literal")
            ch = text[j]
            if ch == "'":
                break
            if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                out.append("'")
                j += 2
                continue
            if ch == "\\" and j + 1 < n and text[j + 1] == "u" and _is_hex4(text, j + 2):
                code = int(text[j + 2:j + 6], 16)
                j += 6
                if 0xD800 <= code <= 0xDBFF and text[j:j + 2] == "\\u" and _is_hex4(text, j + 2):
                    low = int(text[j + 2:j + 6], 16)
                    if 0xDC00 <= low <= 0xDFFF:
                        code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        j += 6
                out.append(chr(code))
                continue
            out.append(ch)
            j += 1
        self.i = j + 1
        return Token("RAW", "".join(out), start)

    def _json_literal(self, start):
        text = self.text
        end = text.find("`", start + 1)
        if end < 0:
            raise self._error(start, "unterminated JSON literal")
        content = text[start + 1:end]
        self.i = end + 1
        try:
            value = _read_json(content)
        except ValueError:
            stripped = content.lstrip(WHITESPACE)
            try:
                value = _read_json('"' + stripped + '"')
            except ValueError:
                raise self._error(start, "JSON literal is neither JSON nor JSON string content")
        return Token("JSON", value, start)


def _is_hex4(text, index):
    chunk = text[index:index + 4]
    return len(chunk) == 4 and all(ch in _HEX for ch in chunk)
