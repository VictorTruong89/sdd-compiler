"""Function-call dispatch: name check, then argument count, then argument types.

A call is checked when it is evaluated, not when the expression is compiled.
Arguments are evaluated against the current value before the function runs;
an expression reference argument evaluates to an ExpressionReference and is
applied later by the function that consumes it.

# spec: N-000264, N-000265, N-000266, N-000267, N-000336, N-000337, N-000344, N-000345, N-000346, N-000347, N-000348, N-000349, N-000350
"""

# spec (options: same results one-shot and compiled): N-000342, N-000343
from .builtins import BUILTINS
from .errors import PathSelArityError, PathSelUnknownFunctionError
from .functions import find_provider_function, value_matches_type
from .errors import PathSelTypeError


def _arity_text(min_args, max_args):
    if max_args is None:
        return "at least %d" % min_args
    if min_args == max_args:
        return "exactly %d" % min_args
    return "between %d and %d" % (min_args, max_args)


def call(name, arg_nodes, cur, ctx):
    builtin = BUILTINS.get(name)
    if builtin is not None:
        count = len(arg_nodes)
        if count < builtin.min_args or (builtin.max_args is not None and count > builtin.max_args):
            raise PathSelArityError(
                "%s takes %s argument(s), got %d"
                % (name, _arity_text(builtin.min_args, builtin.max_args), count)
            )
        args = [node.eval(cur, ctx) for node in arg_nodes]
        return builtin.impl(args, ctx)

    provider_function = find_provider_function(ctx.provider, name)
    if provider_function is None:
        raise PathSelUnknownFunctionError("unknown function %r" % name)

    specs = getattr(provider_function, "__pathsel_signature__")
    if len(arg_nodes) != len(specs):
        raise PathSelArityError(
            "%s takes exactly %d argument(s), got %d" % (name, len(specs), len(arg_nodes))
        )
    args = [node.eval(cur, ctx) for node in arg_nodes]
    for index, (value, types) in enumerate(zip(args, specs)):
        if not any(value_matches_type(value, type_name) for type_name in types):
            raise PathSelTypeError(
                "argument %d of %s has the wrong type" % (index + 1, name)
            )
    return provider_function(*args)
