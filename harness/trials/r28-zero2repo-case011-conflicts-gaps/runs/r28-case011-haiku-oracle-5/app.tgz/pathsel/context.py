"""Evaluation context built from the optional evaluation-options object.

The options object is any object carrying ``dict_cls`` (a mapping type or
None) and ``custom_functions`` (a provider instance or None). The library
reads these attributes and does not require a particular class.

# spec: N-000323, N-000324, N-000325, N-000326, N-000327, N-000328, N-000329, N-000331, N-000332, N-000333, N-000334, N-000341, N-000389, N-000390, N-000391, N-000392
"""

# spec (evaluation options terms): N-000032

class EvalContext:
    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    def new_mapping(self):
        """A fresh constructed mapping: the supplied mapping type, or a host dict."""
        if self.dict_cls is None:
            return {}
        return self.dict_cls()


def make_context(options):
    if options is None:
        return EvalContext()
    return EvalContext(
        dict_cls=getattr(options, "dict_cls", None),
        provider=getattr(options, "custom_functions", None),
    )
