"""Pratt parser for PathSel expressions.

Binding powers (higher binds tighter) follow the spec's ranking of steps:

    pipe 1 < or 2 < and 3 < comparators 5 < flatten 9 (rank 1)
      < list/object wildcard and slice 20 (rank 2) < filter 21 (rank 3)
      < dot 40 (rank 4) < bracket index/slice/wildcard 55 (rank 5)

A projection's right-hand side takes the steps that bind tighter than the
projection; everything else ends it, so comparisons, logic, pipes and
commas apply to the whole projected array.

# spec: N-000073, N-000074, N-000075, N-000076, N-000078, N-000079, N-000080, N-000081, N-000082
# spec: N-000086, N-000087, N-000088, N-000089, N-000090, N-000091, N-000092, N-000093
# spec: N-000094, N-000095, N-000096, N-000098, N-000099, N-000100, N-000101, N-000102, N-000103, N-000104, N-000105, N-000106
# spec: N-000123, N-000125, N-000126, N-000127, N-000128, N-000155, N-000156, N-000157
# spec: N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000194, N-000195, N-000196, N-000197
# spec: N-000198, N-000199
# spec: N-000206, N-000211, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218
# spec: N-000219, N-000220, N-000221, N-000222, N-000240, N-000241
# spec: N-000253, N-000254, N-000255, N-000256, N-000257
# spec: N-000260, N-000261, N-000322, N-000321
"""

# spec (parsed expression, compile entry, position): N-000018, N-000014, N-000016, N-000017, N-000122, N-000189
from . import nodes as N
from .errors import (
    PathSelEmptyError,
    PathSelIncompleteError,
    PathSelSyntaxError,
)
from .lexer import Lexer

BP_PIPE = 1
BP_OR = 2
BP_AND = 3
BP_COMPARE = 5
BP_FLATTEN = 9
BP_PROJECTION_STOP = 10
BP_WILDCARD = 20
BP_FILTER = 21
BP_DOT = 40
BP_NOT = 45
BP_BRACKET = 55

_COMPARATORS = {"EQ": "==", "NE": "!=", "LT": "<", "LE": "<=", "GT": ">", "GE": ">="}


class ParsedExpression:
    """The successful result of compile. Searchable any number of times."""

    __slots__ = ("text", "root")

    def __init__(self, text, root):
        self.text = text
        self.root = root

    def search(self, value, options=None):
        from .context import make_context

        return self.root.eval(value, make_context(options))

    def __repr__(self):
        return "<pathsel.ParsedExpression %r>" % (self.text,)


class Parser:
    def __init__(self, text):
        self.text = text
        self.length = len(text)
        self._lexer = Lexer(text)
        self._buf = []

    # --- token stream ------------------------------------------------------

    def _peek(self, k=0):
        while len(self._buf) <= k:
            self._buf.append(self._lexer.next_token())
        return self._buf[k]

    def _advance(self):
        token = self._peek(0)
        del self._buf[0]
        return token

    def _incomplete(self, token):
        return PathSelIncompleteError("expression is incomplete", token.pos)

    def _syntax(self, token):
        return PathSelSyntaxError("unexpected token %s" % token.kind, token.pos)

    def _expect(self, kind):
        token = self._peek()
        if token.kind == kind:
            return self._advance()
        if token.kind == "EOF":
            raise self._incomplete(token)
        raise self._syntax(token)

    # --- entry -------------------------------------------------------------

    def parse(self):
        if self.length == 0:
            raise PathSelEmptyError("expression is empty")
        node = self._expr(0)
        token = self._peek()
        if token.kind != "EOF":
            raise self._syntax(token)
        return node

    # --- Pratt core ---------------------------------------------------------

    @staticmethod
    def _lbp(token):
        kind = token.kind
        if kind == "PIPE":
            return BP_PIPE
        if kind == "OR":
            return BP_OR
        if kind == "AND":
            return BP_AND
        if kind in _COMPARATORS:
            return BP_COMPARE
        if kind == "FLATTEN":
            return BP_FLATTEN
        if kind == "FILTER":
            return BP_FILTER
        if kind == "DOT":
            return BP_DOT
        if kind == "LBRACKET":
            return BP_BRACKET
        return 0

    def _expr(self, rbp):
        token = self._advance()
        left = self._nud(token)
        while rbp < self._lbp(self._peek()):
            token = self._advance()
            left = self._led(token, left)
        return left

    def _nud(self, token):
        kind = token.kind
        if kind == "EOF":
            raise self._incomplete(token)
        if kind == "IDENT":
            if self._peek().kind == "LPAREN":
                self._advance()
                return N.FunctionCall(token.value, self._call_arguments())
            return N.Field(token.value)
        if kind == "QIDENT":
            if self._peek().kind == "LPAREN":
                # A quoted identifier cannot be a function name. # spec: N-000321, N-000322
                raise self._syntax(self._peek())
            return N.Field(token.value)
        if kind == "AT":
            return N.Identity()
        if kind == "JSON" or kind == "RAW":
            return N.Literal(token.value)
        if kind == "STAR":
            return N.ObjectProjection(N.Identity(), self._projection_rhs(BP_WILDCARD))
        if kind == "FLATTEN":
            return N.FlattenProjection(N.Identity(), self._projection_rhs(BP_FLATTEN))
        if kind == "FILTER":
            predicate = self._expr(0)
            self._expect("RBRACKET")
            return N.FilterProjection(N.Identity(), predicate, self._projection_rhs(BP_FILTER))
        if kind == "LBRACKET":
            return self._bracket_nud()
        if kind == "LBRACE":
            return self._multiselect_hash()
        if kind == "LPAREN":
            inner = self._expr(0)
            self._expect("RPAREN")
            return inner
        if kind == "AMP":
            return N.ExprRef(self._expr(0))
        if kind == "NOT":
            return N.Not(self._expr(BP_NOT))
        raise self._syntax(token)

    def _led(self, token, left):
        kind = token.kind
        if kind == "PIPE":
            return N.Pipe(left, self._expr(BP_PIPE))
        if kind == "OR":
            return N.Or(left, self._expr(BP_OR))
        if kind == "AND":
            return N.And(left, self._expr(BP_AND))
        if kind in _COMPARATORS:
            return N.Compare(_COMPARATORS[kind], left, self._expr(BP_COMPARE))
        if kind == "FLATTEN":
            return N.FlattenProjection(left, self._projection_rhs(BP_FLATTEN))
        if kind == "DOT":
            return N.Subexpr(left, self._dot_rhs(BP_DOT))
        if kind == "FILTER":
            predicate = self._expr(0)
            self._expect("RBRACKET")
            return N.FilterProjection(left, predicate, self._projection_rhs(BP_FILTER))
        if kind == "LBRACKET":
            nxt = self._peek()
            if nxt.kind == "STAR" and self._peek(1).kind == "RBRACKET":
                self._advance()
                self._advance()
                return N.ListProjection(left, self._projection_rhs(BP_WILDCARD))
            if nxt.kind in ("NUMBER", "COLON"):
                return self._index_or_slice(left)
            # A multiselect list may only start a projection's right-hand side. # spec: N-000213, N-000214, N-000215, N-000216
            raise self._syntax(token)
        raise self._syntax(token)

    def _bracket_nud(self):
        """A bracket that starts an expression: applies to the current value."""
        nxt = self._peek()
        if nxt.kind == "STAR" and self._peek(1).kind == "RBRACKET":
            self._advance()
            self._advance()
            return N.ListProjection(N.Identity(), self._projection_rhs(BP_WILDCARD))
        if nxt.kind in ("NUMBER", "COLON"):
            return self._index_or_slice(N.Identity())
        return self._multiselect_list()

    # --- brackets and projections -------------------------------------------

    def _index_or_slice(self, left):
        """Parse after ``[`` when the next token is a number or colon."""
        parts = [None]
        is_slice = False
        while True:
            token = self._peek()
            if token.kind == "NUMBER":
                if parts[-1] is not None:
                    raise self._syntax(token)
                parts[-1] = token.value
                self._advance()
            elif token.kind == "COLON":
                is_slice = True
                parts.append(None)
                if len(parts) > 3:
                    raise self._syntax(token)
                self._advance()
            else:
                break
        self._expect("RBRACKET")
        if not is_slice:
            return N.Index(left, parts[0])
        while len(parts) < 3:
            parts.append(None)
        start, stop, step = parts
        slc = N.Slice(start, stop, step)
        return N.SliceProjection(left, slc, self._projection_rhs(BP_WILDCARD))

    def _projection_rhs(self, bp):
        """The right-hand side of a projection, per the step ranking."""
        token = self._peek()
        if self._lbp(token) < BP_PROJECTION_STOP:
            return N.Identity()
        if token.kind in ("LBRACKET", "FILTER"):
            return self._expr(bp)
        if token.kind == "DOT":
            self._advance()
            return self._dot_rhs(bp)
        raise self._syntax(token)

    def _dot_rhs(self, bp):
        """The step after a dot: identifier, wildcard, multiselect list or hash."""
        token = self._peek()
        if token.kind == "EOF":
            # A dot at the end of the text is a grammar-level failure. # spec: N-000123
            raise self._syntax(token)
        if token.kind in ("IDENT", "QIDENT", "STAR", "LBRACE"):
            return self._expr(bp)
        if token.kind == "LBRACKET":
            self._advance()
            return self._multiselect_list()
        raise self._syntax(token)

    # --- constructors --------------------------------------------------------

    def _call_arguments(self):
        """Arguments after ``(`` has been consumed."""
        args = []
        if self._peek().kind == "RPAREN":
            self._advance()
            return args
        while True:
            args.append(self._expr(0))
            token = self._peek()
            if token.kind == "COMMA":
                self._advance()
                continue
            if token.kind == "RPAREN":
                self._advance()
                return args
            if token.kind == "EOF":
                raise self._incomplete(token)
            raise self._syntax(token)

    def _multiselect_list(self):
        """Elements after ``[`` has been consumed."""
        elements = []
        while True:
            elements.append(self._expr(0))
            token = self._peek()
            if token.kind == "COMMA":
                self._advance()
                continue
            if token.kind == "RBRACKET":
                self._advance()
                return N.MultiList(elements)
            if token.kind == "EOF":
                raise self._incomplete(token)
            raise self._syntax(token)

    def _multiselect_hash(self):
        """Key-value pairs after ``{`` has been consumed."""
        pairs = []
        while True:
            key = self._advance()
            if key.kind not in ("IDENT", "QIDENT"):
                if key.kind == "EOF":
                    raise self._incomplete(key)
                raise self._syntax(key)
            self._expect("COLON")
            value = self._expr(0)
            pairs.append((key.value, value))
            token = self._peek()
            if token.kind == "COMMA":
                self._advance()
                continue
            if token.kind == "RBRACE":
                self._advance()
                return N.MultiHash(pairs)
            if token.kind == "EOF":
                raise self._incomplete(token)
            raise self._syntax(token)


def parse(text):
    """Compile expression text into a ParsedExpression. Raises a PathSelError subclass on refusal."""
    if not isinstance(text, str):
        raise TypeError("expression must be a str")
    root = Parser(text).parse()
    return ParsedExpression(text, root)
