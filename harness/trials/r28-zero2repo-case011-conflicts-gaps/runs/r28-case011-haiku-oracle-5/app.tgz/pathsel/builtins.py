"""The finite set of built-in language functions (FP-07).

Each entry declares its name, its accepted argument count (``max_args`` None
means unbounded) and an implementation ``impl(args, ctx)`` that receives the
already-evaluated arguments. Implementations check argument types in order and
raise the matching failure kind.

# spec: N-000262, N-000263, N-000264, N-000265, N-000266, N-000268
# spec: N-000269, N-000270, N-000271, N-000272, N-000273, N-000274, N-000275, N-000276
# spec: N-000277, N-000278, N-000279, N-000280, N-000281, N-000282, N-000283, N-000284, N-000285
# spec: N-000286, N-000287, N-000288, N-000289, N-000290, N-000291, N-000292, N-000293, N-000294
# spec: N-000295, N-000296, N-000297, N-000298, N-000299, N-000300, N-000301, N-000302
# spec: N-000303, N-000304, N-000305, N-000306, N-000307, N-000308, N-000309, N-000310
# spec: N-000311, N-000312, N-000313, N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320
# spec: N-000321, N-000322
"""

# spec (built-in function name set and constraints): N-000033, N-000340, N-000341
import json
import math
import re
from decimal import Decimal

from .errors import PathSelTypeError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    is_object,
    json_equal,
)


class Builtin:
    __slots__ = ("name", "min_args", "max_args", "impl")

    def __init__(self, name, min_args, max_args, impl):
        self.name = name
        self.min_args = min_args
        self.max_args = max_args
        self.impl = impl


BUILTINS = {}


def _register(name, min_args, max_args=None):
    def decorator(func):
        BUILTINS[name] = Builtin(name, min_args, max_args, func)
        return func

    return decorator


def _type_error(message):
    return PathSelTypeError(message)


def _require_number(value, fname):
    if not is_number(value):
        raise _type_error("%s requires a number" % fname)
    return value


def _require_array(value, fname):
    if not is_array(value):
        raise _type_error("%s requires an array" % fname)
    return value


def _require_string(value, fname):
    if not isinstance(value, str):
        raise _type_error("%s requires a string" % fname)
    return value


def _require_object(value, fname):
    if not is_object(value):
        raise _type_error("%s requires an object" % fname)
    return value


def _require_reference(value, fname):
    if not isinstance(value, ExpressionReference):
        raise _type_error("%s requires an expression reference" % fname)
    return value


def _require_all_numbers(array, fname):
    for element in array:
        if not is_number(element):
            raise _type_error("%s requires an array of numbers" % fname)


def _require_all_strings(array, fname):
    for element in array:
        if not isinstance(element, str):
            raise _type_error("%s requires an array of strings" % fname)


def _require_numbers_or_strings(array, fname):
    """Every element a number, or every element a string. # spec: N-000290, N-000293, N-000317"""
    if all(is_number(e) for e in array):
        return
    if all(isinstance(e, str) for e in array):
        return
    raise _type_error("%s requires an array of numbers or an array of strings" % fname)


def _key_values(array, ref, ctx, fname):
    """Keys of each element under the reference, checked as numbers or strings. # spec: N-000303, N-000304, N-000306, N-000319, N-000320"""
    keys = [ref.node.eval(element, ctx) for element in array]
    if not keys:
        return keys
    if all(is_number(k) for k in keys):
        return keys
    if all(isinstance(k, str) for k in keys):
        return keys
    raise _type_error("%s keys must all be numbers or all be strings" % fname)


# --- numbers -----------------------------------------------------------------

@_register("abs", 1, 1)
def _abs(args, ctx):
    return abs(_require_number(args[0], "abs"))


@_register("avg", 1, 1)
def _avg(args, ctx):
    array = _require_array(args[0], "avg")
    _require_all_numbers(array, "avg")
    if not array:
        return None
    return sum(array) / len(array)


def _require_finite(value, fname):
    """Non-finite floats have no integer rounding; refused as invalid type (choice)."""
    _require_number(value, fname)
    if isinstance(value, float) and not math.isfinite(value):
        raise _type_error("%s requires a finite number" % fname)
    return value


@_register("ceil", 1, 1)
def _ceil(args, ctx):
    return math.ceil(_require_finite(args[0], "ceil"))


@_register("floor", 1, 1)
def _floor(args, ctx):
    return math.floor(_require_finite(args[0], "floor"))


@_register("sum", 1, 1)
def _sum(args, ctx):
    array = _require_array(args[0], "sum")
    _require_all_numbers(array, "sum")
    return sum(array)


@_register("max", 1, 1)
def _max(args, ctx):
    array = _require_array(args[0], "max")
    _require_numbers_or_strings(array, "max")
    return max(array) if array else None


@_register("min", 1, 1)
def _min(args, ctx):
    array = _require_array(args[0], "min")
    _require_numbers_or_strings(array, "min")
    return min(array) if array else None


@_register("sort", 1, 1)
def _sort(args, ctx):
    array = _require_array(args[0], "sort")
    _require_numbers_or_strings(array, "sort")
    return sorted(array)


# --- strings and arrays ------------------------------------------------------

@_register("contains", 2, 2)
def _contains(args, ctx):
    subject, needle = args
    if is_array(subject):
        return any(json_equal(element, needle) for element in subject)
    if isinstance(subject, str):
        _require_string(needle, "contains")
        return needle in subject
    raise _type_error("contains requires an array or a string")


@_register("ends_with", 2, 2)
def _ends_with(args, ctx):
    text = _require_string(args[0], "ends_with")
    suffix = _require_string(args[1], "ends_with")
    return text.endswith(suffix)


@_register("starts_with", 2, 2)
def _starts_with(args, ctx):
    text = _require_string(args[0], "starts_with")
    prefix = _require_string(args[1], "starts_with")
    return text.startswith(prefix)


@_register("length", 1, 1)
def _length(args, ctx):
    """Unicode characters of a string, elements of an array, keys of an object. # spec: N-000277 (choice for CF-000035)"""
    value = args[0]
    if isinstance(value, str):
        return len(value)
    if is_array(value) or is_object(value):
        return len(value)
    raise _type_error("length requires a string, an array or an object")


@_register("reverse", 1, 1)
def _reverse(args, ctx):
    value = args[0]
    if isinstance(value, str):
        return value[::-1]
    if is_array(value):
        return list(reversed(value))
    raise _type_error("reverse requires an array or a string")


@_register("join", 2, 2)
def _join(args, ctx):
    separator = _require_string(args[0], "join")
    array = _require_array(args[1], "join")
    _require_all_strings(array, "join")
    return separator.join(array)


@_register("keys", 1, 1)
def _keys(args, ctx):
    return list(_require_object(args[0], "keys").keys())


@_register("values", 1, 1)
def _values(args, ctx):
    return list(_require_object(args[0], "values").values())


@_register("merge", 1, None)
def _merge(args, ctx):
    result = ctx.new_mapping()
    for argument in args:
        _require_object(argument, "merge")
        for key in argument:
            result[key] = argument[key]
    return result


@_register("not_null", 1, None)
def _not_null(args, ctx):
    """The first argument that is not null. An empty string or array is not null. # spec: N-000298, N-000299, N-000300 (choice for CF-000015)"""
    for argument in args:
        if argument is not None:
            return argument
    return None


# --- type and conversion -----------------------------------------------------

@_register("type", 1, 1)
def _type(args, ctx):
    value = args[0]
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float, Decimal)):
        return "number"
    if isinstance(value, str):
        return "string"
    if is_array(value):
        return "array"
    if is_object(value):
        return "object"
    return None


@_register("to_array", 1, 1)
def _to_array(args, ctx):
    value = args[0]
    if is_array(value):
        return value
    return [value]


@_register("to_string", 1, 1)
def _to_string(args, ctx):
    value = args[0]
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, separators=(",", ":"), ensure_ascii=True)
    except (TypeError, ValueError):
        return str(value)


_INTEGER_NUMERAL = re.compile(r"^[+-]?[0-9]+$")
_DECIMAL_NUMERAL = re.compile(r"^[+-]?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?$")
_EXPONENT_NUMERAL = re.compile(r"^[+-]?[0-9]+[eE][+-]?[0-9]+$")


@_register("to_number", 1, 1)
def _to_number(args, ctx):
    """A number unchanged; an integer numeral becomes an int; a decimal or exponent numeral a float; else null. # spec: N-000286, N-000287, N-000288, N-000289 (choice for CF-000057)"""
    value = args[0]
    if is_number(value):
        return value
    if isinstance(value, str):
        if _INTEGER_NUMERAL.match(value):
            return int(value)
        if _DECIMAL_NUMERAL.match(value) or _EXPONENT_NUMERAL.match(value):
            return float(value)
    return None


# --- expression-reference functions ------------------------------------------

@_register("map", 2, 2)
def _map(args, ctx):
    ref = _require_reference(args[0], "map")
    array = _require_array(args[1], "map")
    return [ref.node.eval(element, ctx) for element in array]


@_register("sort_by", 2, 2)
def _sort_by(args, ctx):
    array = _require_array(args[0], "sort_by")
    ref = _require_reference(args[1], "sort_by")
    keys = _key_values(array, ref, ctx, "sort_by")
    order = sorted(range(len(array)), key=lambda i: keys[i])  # stable
    return [array[i] for i in order]


@_register("max_by", 2, 2)
def _max_by(args, ctx):
    array = _require_array(args[0], "max_by")
    ref = _require_reference(args[1], "max_by")
    keys = _key_values(array, ref, ctx, "max_by")
    if not array:
        return None
    best = 0
    for i in range(1, len(array)):
        if keys[i] > keys[best]:
            best = i
    return array[best]


@_register("min_by", 2, 2)
def _min_by(args, ctx):
    array = _require_array(args[0], "min_by")
    ref = _require_reference(args[1], "min_by")
    keys = _key_values(array, ref, ctx, "min_by")
    if not array:
        return None
    best = 0
    for i in range(1, len(array)):
        if keys[i] < keys[best]:
            best = i
    return array[best]

