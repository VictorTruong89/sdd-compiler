"""Failure kinds for pathsel.

Every refusal is a ``ValueError``. The kind of a refusal is carried by the
type of the raised exception (spec: Interface Contract > Failure carriers).
Type names are the implementer's choice; the hierarchy below satisfies the
stated relations:

* ``PathSelEmptyError``, ``PathSelIncompleteError`` and ``PathSelSyntaxError``
  are three different types.
* ``PathSelTokenError`` is a subclass of ``PathSelSyntaxError`` and not the
  same type; it is not an instance of the empty or incomplete types.
* The zero-slice-step, unknown-function, invalid-arity and invalid-type kinds
  each have their own type, and none of them is a syntax type.
"""
# spec (failure carriers and report wording): N-000034, N-000035, N-000036, N-000037, N-000405, N-000406, N-000407, N-000408, N-000409, N-000410, N-000413, N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420


class PathSelError(ValueError):
    """Base class for every refusal raised by pathsel."""


class PathSelEmptyError(PathSelError):
    """The expression text has zero length. # spec: N-000087, N-000088, N-000089"""


class PathSelIncompleteError(PathSelError):
    """Text ends where an operand or a closing token is still required.

    Carries ``lex_position``: the offset of the end of the text. # spec: N-000090, N-000091, N-000092, N-000093, N-000421, N-000422
    """

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure. Carries ``lex_position``. # spec: N-000094, N-000095, N-000097, N-000102, N-000411"""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class PathSelTokenError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind. # spec: N-000098, N-000099, N-000100, N-000101, N-000412"""


class PathSelZeroStepError(PathSelError):
    """A slice whose step is 0. Not a syntax kind. # spec: N-000152, N-000153, N-000154, N-000415"""


class PathSelUnknownFunctionError(PathSelError):
    """A call names neither a built-in nor a provider function. # spec: N-000264, N-000344, N-000416"""


class PathSelArityError(PathSelError):
    """A call has the wrong number of arguments. # spec: N-000265, N-000311, N-000313, N-000345, N-000417"""


class PathSelTypeError(PathSelError):
    """An argument is outside its accepted types. # spec: N-000266, N-000314, N-000316, N-000347, N-000418, N-000419"""
