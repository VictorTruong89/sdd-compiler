"""Root conftest: its presence puts the repository root on sys.path so `import pathsel` works under plain `pytest`."""
