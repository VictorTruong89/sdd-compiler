"""Root conftest: its presence puts this directory on sys.path so `import pathsel` works under pytest."""
