"""Tokenizer for the PathSel language.

Tokens are produced on demand (one at a time), so a token-level failure is
raised only when the parser reaches the bad text. Failures carry the offset
at which the bad token begins.
"""

import json

from .errors import PathSelTokenSyntaxError

_WHITESPACE = " \t\n\r"
_IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT_BODY = _IDENT_START | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_HEX = frozenset("0123456789abcdefABCDEF")

_SINGLE = {
    ".": "dot",
    "*": "star",
    "[": "lbracket",
    "]": "rbracket",
    "?": "filter",
    ",": "comma",
    ":": "colon",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    "@": "at",
}


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.kind, self.value, self.pos)


# spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000110 N-000111 N-000112 N-000113 N-000114 N-000119 N-000120 N-000121 N-000122 N-000124 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230 N-000237 N-000238 N-000239 N-000260
class Lexer:
    def __init__(self, text):
        self.text = text
        self.length = len(text)
        self.i = 0

    def _token_error(self, pos, message):
        return PathSelTokenSyntaxError(message, pos)

    def next(self):
        text = self.text
        n = self.length
        i = self.i
        while i < n and text[i] in _WHITESPACE:
            i += 1
        if i >= n:
            self.i = n
            return Token("eof", None, n)
        start = i
        c = text[i]

        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_BODY:
                j += 1
            self.i = j
            return Token("unquoted", text[i:j], start)

        if c == "-" or c in _DIGITS:
            if c == "-":
                if i + 1 >= n or text[i + 1] not in _DIGITS:
                    raise self._token_error(start, "a hyphen that does not begin a number")
                j = i + 1
            else:
                j = i
            while j < n and text[j] in _DIGITS:
                j += 1
            self.i = j
            return Token("number", int(text[i:j]), start)

        if c == '"':
            j = i + 1
            while True:
                if j >= n:
                    raise self._token_error(start, "unterminated quoted identifier")
                if text[j] == "\\":
                    j += 2
                    continue
                if text[j] == '"':
                    break
                j += 1
            raw = text[i : j + 1]
            try:
                value = json.loads(raw)
            except ValueError:
                raise self._token_error(start, "invalid quoted identifier") from None
            self.i = j + 1
            return Token("quoted", value, start)

        if c == "'":
            j = i + 1
            out = []
            while True:
                if j >= n:
                    raise self._token_error(start, "unterminated raw string literal")
                ch = text[j]
                if ch == "'":
                    break
                if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                    out.append("'")
                    j += 2
                    continue
                if ch == "\\" and j + 5 < n + 0 and text[j + 1] == "u" and all(
                    k < n and text[k] in _HEX for k in range(j + 2, j + 6)
                ):
                    out.append(chr(int(text[j + 2 : j + 6], 16)))
                    j += 6
                    continue
                out.append(ch)
                j += 1
            self.i = j + 1
            return Token("string", "".join(out), start)

        if c == "`":
            j = i + 1
            while True:
                if j >= n:
                    raise self._token_error(start, "unterminated JSON literal")
                if text[j] == "\\" and j + 1 < n and text[j + 1] == "`":
                    j += 2
                    continue
                if text[j] == "`":
                    break
                j += 1
            content = text[i + 1 : j].replace("\\`", "`")
            self.i = j + 1
            return Token("literal", self._literal_value(content, start), start)

        if c == "&":
            if i + 1 < n and text[i + 1] == "&":
                self.i = i + 2
                return Token("and", "&&", start)
            self.i = i + 1
            return Token("amp", "&", start)
        if c == "|":
            if i + 1 < n and text[i + 1] == "|":
                self.i = i + 2
                return Token("or", "||", start)
            self.i = i + 1
            return Token("pipe", "|", start)
        if c == "!":
            if i + 1 < n and text[i + 1] == "=":
                self.i = i + 2
                return Token("ne", "!=", start)
            self.i = i + 1
            return Token("not", "!", start)
        if c == "=":
            if i + 1 < n and text[i + 1] == "=":
                self.i = i + 2
                return Token("eq", "==", start)
            raise self._token_error(start, "a lone '=' is not an operator")
        if c in "<>":
            if i + 1 < n and text[i + 1] == "=":
                self.i = i + 2
                return Token("lte" if c == "<" else "gte", c + "=", start)
            self.i = i + 1
            return Token("lt" if c == "<" else "gt", c, start)

        kind = _SINGLE.get(c)
        if kind is not None:
            self.i = i + 1
            return Token(kind, c, start)

        raise self._token_error(start, "a character that begins no token: %r" % c)

    def _literal_value(self, content, start):
        try:
            return json.loads(content)
        except ValueError:
            pass
        # Not valid JSON: read as the content of a JSON string after
        # removing leading whitespace.
        text = content.lstrip(_WHITESPACE)
        try:
            return json.loads('"' + text + '"')
        except ValueError:
            raise self._token_error(start, "invalid JSON literal") from None
