"""Public entries: the search entry and the compile entry (FP-01)."""

from .errors import EmptyExpressionError, PathSelError
from .nodes import Context
from .parser import Parser


# spec: N-000078 N-000079
class ParsedExpression:
    """A compiled PathSel expression. Searchable any number of times (FP-01)."""

    __slots__ = ("expression", "_root")

    def __init__(self, expression, root):
        self.expression = expression
        self._root = root

    def search(self, value, options=None):
        """Evaluate against ``value``; returns the selected value or raises a refusal."""
        return self._root.eval(value, Context(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


# spec: N-000073 N-000074 N-000075 N-000076 N-000080 N-000081 N-000082 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094 N-000095
def compile(expression):
    """Parse ``expression`` once and return a ParsedExpression.

    Raises a PathSelError subclass (a ValueError) for every refusal that is
    detectable without a document.
    """
    if not isinstance(expression, str):
        raise TypeError("a PathSel expression must be a str")
    if expression == "":
        raise EmptyExpressionError("the expression is empty")
    try:
        root = Parser(expression).parse()
    except RecursionError:
        # Nesting deeper than the interpreter allows is refused as a PathSel failure.
        raise PathSelError("the expression nests too deeply") from None
    return ParsedExpression(expression, root)


# spec: N-000038 N-000040 N-000041 N-000080
def search(expression, data, options=None):
    """One-shot search: compile ``expression`` and evaluate it against ``data``."""
    return compile(expression).search(data, options)
