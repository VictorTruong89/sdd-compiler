"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public names: ``search`` and ``compile``. Failures are raised as subclasses of
ValueError (see ``pathsel.errors``).
"""

from .core import ParsedExpression, compile, search
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    PathSelTokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "PathSelTokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
