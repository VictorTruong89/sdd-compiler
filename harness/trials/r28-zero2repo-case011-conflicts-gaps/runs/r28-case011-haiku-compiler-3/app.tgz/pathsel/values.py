"""Value model shared by the evaluator and the built-in functions.

JSON types: object (Mapping, or the evaluation options' mapping type), array
(list or tuple), string (str), number (int or float, never bool), boolean
(bool) and null (None). Host decimals are numbers for comparison only; they
are not JSON numbers for function arguments (Non-functional constraints).
"""

from collections.abc import Mapping
from decimal import Decimal


class Reference:
    """An expression reference value: a deferred subexpression.

    Built-in functions such as ``map`` apply it to each element with
    :meth:`apply`. Outside a function argument it is returned as is.
    """

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def apply(self, value):
        return self.node.eval(value, self.ctx)

    def __repr__(self):
        return "<pathsel expression reference>"


def is_object(value, ctx=None):
    """True for a mapping, including constructed hashes of the options' type."""
    if isinstance(value, Mapping):
        return True
    dict_cls = getattr(ctx, "dict_cls", None)
    return dict_cls is not None and isinstance(value, dict_cls)


def is_array(value):
    return isinstance(value, (list, tuple))


def is_number(value):
    """A JSON number: int or float, not bool."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_comparable_number(value):
    """A number for comparison: JSON numbers and host decimals."""
    return is_number(value) or isinstance(value, Decimal)


# spec: N-000247 N-000251 N-000252 N-000253 N-000254
def is_false(value, ctx=None):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None or value is False:
        return True
    if isinstance(value, str) or is_array(value):
        return len(value) == 0
    if is_object(value, ctx):
        return len(value) == 0
    return False


# spec: N-000242 N-000243 N-000244 N-000180 N-000181
def json_equal(a, b, ctx=None):
    """JSON value equality: deep for arrays and objects, bool never equals a number."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_comparable_number(a) and is_comparable_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y, ctx) for x, y in zip(a, b))
    if is_object(a, ctx) or is_object(b, ctx):
        if not (is_object(a, ctx) and is_object(b, ctx)) or len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key], ctx):
                return False
        return True
    return a is b or a == b


_TYPE_CHECKS = {
    "any": lambda v, ctx: True,
    "number": lambda v, ctx: is_number(v),
    "string": lambda v, ctx: isinstance(v, str),
    "array": lambda v, ctx: is_array(v),
    "object": lambda v, ctx: is_object(v, ctx),
    "null": lambda v, ctx: v is None,
    "boolean": lambda v, ctx: isinstance(v, bool),
    "expref": lambda v, ctx: isinstance(v, Reference),
}

JSON_TYPE_NAMES = ("number", "string", "array", "object", "null", "boolean")


def type_matches(value, type_name, ctx=None):
    """True if ``value`` is of the named type (see the signature type names)."""
    return _TYPE_CHECKS[type_name](value, ctx)


# spec: N-000245 N-000246
def json_order(a, b):
    """Return -1, 0, 1 for two numbers or two strings, or None if not comparable."""
    if is_comparable_number(a) and is_comparable_number(b):
        pass
    elif isinstance(a, str) and isinstance(b, str):
        pass
    else:
        return None
    if a < b:
        return -1
    if a > b:
        return 1
    return 0
