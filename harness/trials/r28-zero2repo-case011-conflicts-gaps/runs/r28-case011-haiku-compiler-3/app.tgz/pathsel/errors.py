"""Failure carriers for pathsel.

Every refusal is a ValueError. The kind of a refusal is carried by the type
of the raised exception (Interface Contract, "Failure carriers").
"""


# spec: N-000405 N-000406 N-000407 N-000408 N-000413
class PathSelError(ValueError):
    """Base class of every refusal raised by pathsel."""


# spec: N-000087 N-000088 N-000089 N-000405 N-000409
class EmptyExpressionError(PathSelError):
    """Zero-length expression text (FP-01, empty expression)."""


# spec: N-000090 N-000091 N-000092 N-000093 N-000410 N-000421 N-000422
class IncompleteExpressionError(PathSelError):
    """Expression ends where an operand or a closing token is still required.

    ``lex_position`` is the offset at which the failure was detected (the
    end of the text for an end-of-text failure).
    """

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


# spec: N-000094 N-000095 N-000099 N-000101 N-000411 N-000421 N-000422
class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure (FP-01, syntax). Carries ``lex_position``."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


# spec: N-000096 N-000097 N-000098 N-000100 N-000412 N-000413 N-000414
class PathSelTokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind.

    A subclass of PathSelSyntaxError, but not PathSelSyntaxError itself.
    """


# spec: N-000152 N-000153 N-000154 N-000415
class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0 (FP-03)."""


# spec: N-000344 N-000416 N-000417 N-000420
class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor provided (FP-07, FP-08)."""


# spec: N-000345 N-000346 N-000347 N-000348 N-000418 N-000420
class InvalidArityError(PathSelError):
    """Wrong number of arguments to a function (FP-07, FP-08)."""


# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000349 N-000350 N-000419 N-000420
class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types (FP-07, FP-08)."""
