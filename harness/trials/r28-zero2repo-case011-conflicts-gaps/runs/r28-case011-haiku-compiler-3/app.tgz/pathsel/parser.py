"""Pratt parser for PathSel expressions.

Binding powers, loosest to tightest: pipe (1), ``||`` (2), ``&&`` (3),
comparators (5), projection stop (below 10), flatten (9), list wildcard and
slice (20), filter (21), dot and object wildcard (40), ``!`` (45), brace
(50), bracket (55), parenthesis (60). A projection's right-hand side keeps
consuming steps that bind tighter than the projection's own power, which is
the ranking described in FP-04.

Failure kinds (FP-01): a text that ends where an operand or a closing token is
still required is "incomplete"; any other ill-formed text is "syntax"; text
that cannot be split into tokens is a token-level syntax failure.
"""

from .errors import (
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from .lexer import Lexer
from .nodes import (
    And,
    Chain,
    Compare,
    FilterProjection,
    FlattenProjection,
    Field,
    FunctionCall,
    Identity,
    Index,
    ListProjection,
    Literal,
    MultiHash,
    MultiList,
    Not,
    Or,
    Ref,
    SliceProjection,
    ValueProjection,
)

PROJECTION_STOP = 10

BINDING_POWER = {
    "eof": 0,
    "unquoted": 0,
    "quoted": 0,
    "number": 0,
    "string": 0,
    "literal": 0,
    "at": 0,
    "amp": 0,
    "rbracket": 0,
    "rparen": 0,
    "rbrace": 0,
    "comma": 0,
    "colon": 0,
    "pipe": 1,
    "or": 2,
    "and": 3,
    "eq": 5,
    "ne": 5,
    "lt": 5,
    "lte": 5,
    "gt": 5,
    "gte": 5,
    "flatten": 9,
    "star": 20,
    "filter": 21,
    "dot": 40,
    "not": 45,
    "lbrace": 50,
    "lbracket": 55,
    "lparen": 60,
}

_COMPARATORS = frozenset(("eq", "ne", "lt", "lte", "gt", "gte"))
_INDEX_OR_PROJECTION_START = frozenset(("number", "colon", "star", "rbracket", "filter"))


# spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104 N-000090 N-000091 N-000092 N-000093 N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000197 N-000198 N-000199 N-000200 N-000201 N-000206 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222 N-000237 N-000238 N-000240 N-000241 N-000260 N-000261 N-000117 N-000118 N-000123 N-000321 N-000322
class Parser:
    def __init__(self, text):
        self.text = text
        self.lexer = Lexer(text)
        self.cur = self.lexer.next()
        self._peeked = None

    # -- token helpers -----------------------------------------------------

    def advance(self):
        tok = self.cur
        if self._peeked is not None:
            self.cur = self._peeked
            self._peeked = None
        else:
            self.cur = self.lexer.next()
        return tok

    def _peek_kind(self):
        if self._peeked is None:
            self._peeked = self.lexer.next()
        return self._peeked.kind

    def _bp(self):
        """Binding power of the current token.

        A ``[`` written as a later step ranks by its form: flatten ``[]`` is the
        loosest (1), a filter ``[?`` ranks 3, and index, slice and wildcard
        brackets rank 5 (FP-04 ranking).
        """
        tok = self.cur
        if tok.kind == "lbracket":
            nxt = self._peek_kind()
            if nxt == "rbracket":
                return BINDING_POWER["flatten"]
            if nxt == "filter":
                return BINDING_POWER["filter"]
        return BINDING_POWER[tok.kind]

    def _unexpected(self, tok):
        """Raise incomplete at end of text, otherwise a grammar-level syntax failure."""
        if tok.kind == "eof":
            raise IncompleteExpressionError("expression ends too early", tok.pos)
        raise PathSelSyntaxError("unexpected token %s" % tok.kind, tok.pos)

    def _expect(self, kind):
        if self.cur.kind == kind:
            return self.advance()
        self._unexpected(self.cur)

    # -- entry -------------------------------------------------------------

    def parse(self):
        node = self.expr(0)
        if self.cur.kind != "eof":
            raise PathSelSyntaxError("unexpected token after expression", self.cur.pos)
        return node

    def expr(self, bp):
        tok = self.advance()
        left = self.nud(tok)
        return self.loop(left, bp)

    def loop(self, left, bp):
        while bp < self._bp():
            left = self.led(left)
        return left

    # -- prefix position ---------------------------------------------------

    def nud(self, tok):
        kind = tok.kind
        if kind == "unquoted":
            if self.cur.kind == "lparen":
                return self._function_call(tok.value)
            return Field(tok.value)
        if kind == "quoted":
            return Field(tok.value)
        if kind in ("string", "literal"):
            return Literal(tok.value)
        if kind == "at":
            return Identity()
        if kind == "amp":
            return Ref(self.expr(0))
        if kind == "star":
            return ValueProjection(Identity(), self.proj_rhs(20))
        if kind == "not":
            return Not(self.expr(45))
        if kind == "lparen":
            inner = self.expr(0)
            self._expect("rparen")
            return inner
        if kind == "lbrace":
            return self._multi_hash()
        if kind == "lbracket":
            if self.cur.kind in _INDEX_OR_PROJECTION_START:
                return self._bracket(Identity())
            return self._multi_list()
        self._unexpected(tok)

    # -- infix position ----------------------------------------------------

    def led(self, left):
        tok = self.cur
        kind = tok.kind
        if kind == "dot":
            self.advance()
            return self._dot(left)
        if kind == "pipe":
            self.advance()
            return Chain(left, self.expr(1))
        if kind == "or":
            self.advance()
            return Or(left, self.expr(2))
        if kind == "and":
            self.advance()
            return And(left, self.expr(3))
        if kind in _COMPARATORS:
            self.advance()
            return Compare(kind, left, self.expr(5))
        if kind == "lbracket":
            self.advance()
            return self._bracket(left)
        raise PathSelSyntaxError("unexpected token %s" % kind, tok.pos)

    # -- dot ---------------------------------------------------------------

    def _dot(self, left):
        """A dot step after ``left`` (the dot is already consumed)."""
        if self.cur.kind == "star":
            self.advance()
            return ValueProjection(left, self.proj_rhs(40))
        return Chain(left, self._dot_body(40))

    def _dot_body(self, bp):
        """The step after a dot: identifier, multiselect hash or list, or a wildcard."""
        tok = self.cur
        if tok.kind in ("unquoted", "quoted", "lbrace"):
            return self.expr(bp)
        if tok.kind == "lbracket":
            self.advance()
            if self.cur.kind == "eof":
                self._unexpected(self.cur)
            if self.cur.kind in _INDEX_OR_PROJECTION_START:
                raise PathSelSyntaxError("a dot may only precede a multiselect list", tok.pos)
            return self.loop(self._multi_list(), bp)
        if tok.kind == "star":
            self.advance()
            return self.loop(ValueProjection(Identity(), self.proj_rhs(40)), bp)
        raise PathSelSyntaxError("a dot must be followed by an identifier, wildcard or multiselect", tok.pos)

    # -- projections -------------------------------------------------------

    def proj_rhs(self, bp):
        """Right-hand side of a projection; ``bp`` is the projection's own power."""
        tok = self.cur
        if BINDING_POWER[tok.kind] < PROJECTION_STOP:
            return Identity()
        if tok.kind == "dot":
            self.advance()
            return self._dot_body(bp)
        if tok.kind == "lbracket":
            return self.expr(bp)
        raise PathSelSyntaxError("a projection must be followed by a dot, bracket, filter or end", tok.pos)

    def _bracket(self, left):
        """Bracket forms after ``[`` (already consumed) applied to ``left``."""
        tok = self.cur
        if tok.kind in ("number", "colon"):
            return self._index_or_slice(left)
        if tok.kind == "star":
            self.advance()
            self._expect("rbracket")
            return ListProjection(left, self.proj_rhs(20))
        if tok.kind == "rbracket":
            self.advance()
            return FlattenProjection(left, self.proj_rhs(9))
        if tok.kind == "filter":
            self.advance()
            predicate = self.expr(0)
            self._expect("rbracket")
            return FilterProjection(left, predicate, self.proj_rhs(21))
        self._unexpected(tok)

    def _index_or_slice(self, left):
        parts = [None, None, None]
        slot = 0
        saw_colon = False
        while True:
            tok = self.cur
            if tok.kind == "number":
                if parts[slot] is not None:
                    raise PathSelSyntaxError("a slice part must be a single integer", tok.pos)
                parts[slot] = tok.value
                self.advance()
                if self.cur.kind not in ("colon", "rbracket"):
                    self._unexpected(self.cur)
            elif tok.kind == "colon":
                saw_colon = True
                slot += 1
                if slot > 2:
                    raise PathSelSyntaxError("a slice has at most three parts", tok.pos)
                self.advance()
            elif tok.kind == "rbracket":
                self.advance()
                break
            else:
                self._unexpected(tok)
        if not saw_colon:
            return Index(left, parts[0])
        start, stop, step = parts
        if step == 0:
            raise ZeroSliceStepError("slice step must not be zero")
        return SliceProjection(left, start, stop, step, self.proj_rhs(20))

    # -- constructors ------------------------------------------------------

    def _multi_list(self):
        """Multiselect list body; the opening ``[`` is already consumed."""
        items = [self.expr(0)]
        while self.cur.kind == "comma":
            self.advance()
            items.append(self.expr(0))
        self._expect("rbracket")
        return MultiList(items)

    def _multi_hash(self):
        """Multiselect hash body; the opening ``{`` is already consumed."""
        pairs = []
        while True:
            tok = self.cur
            if tok.kind not in ("unquoted", "quoted"):
                self._unexpected(tok)
            self.advance()
            self._expect("colon")
            pairs.append((tok.value, self.expr(0)))
            if self.cur.kind == "comma":
                self.advance()
                continue
            self._expect("rbrace")
            return MultiHash(pairs)

    def _function_call(self, name):
        """Function call; the name is consumed and the current token is ``(``."""
        self.advance()
        args = []
        if self.cur.kind == "rparen":
            self.advance()
            return FunctionCall(name, args)
        while True:
            args.append(self.expr(0))
            if self.cur.kind == "comma":
                self.advance()
                continue
            self._expect("rparen")
            return FunctionCall(name, args)
