"""Built-in functions (FP-07) and the provider interface (Interface Contract).

Built-ins are registered in ``BUILTINS`` with a declared signature. Each
implementation receives the evaluation context first, then the already
evaluated arguments. ``Functions`` exposes the same built-ins as
``_func_<name>`` methods so that a caller can subclass it to add functions.
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError
from .values import (
    JSON_TYPE_NAMES,
    is_array,
    is_number,
    is_object,
    json_equal,
)

# Custom signatures accept the JSON type names only (Interface Contract).
_SIGNATURE_TYPE_NAMES = JSON_TYPE_NAMES


class Builtin:
    __slots__ = ("name", "fn", "types", "variadic")

    def __init__(self, name, fn, types, variadic):
        self.name = name
        self.fn = fn
        self.types = types
        self.variadic = variadic


# spec: N-000263 N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280 N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289 N-000290 N-000291 N-000292 N-000293 N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308
BUILTINS = {}


def _builtin(name, *types, variadic=False):
    """Register a built-in. ``types`` holds one list of accepted type names per parameter."""

    def decorate(fn):
        BUILTINS[name] = Builtin(name, fn, [list(t) for t in types], variadic)
        return fn

    return decorate


# spec: N-000401 N-000402 N-000403 N-000404
def signature(*arguments):
    """Declare the parameter types of a custom function (Interface Contract).

    Each argument is ``{"types": [<type-name>, ...]}``. The decorator returns
    the implementation unchanged apart from its declared signature.
    """
    declared = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise TypeError('each signature argument must be {"types": [...]}')
        names = list(argument["types"])
        for name in names:
            if name not in _SIGNATURE_TYPE_NAMES:
                raise ValueError("unknown type name in signature: %r" % (name,))
        declared.append(names)

    def decorate(implementation):
        implementation._pathsel_types = declared
        implementation._pathsel_variadic = False
        return implementation

    return decorate


def signature_for_custom(fn):
    """Return (types, variadic) for a signed provider callable, or (None, None)."""
    types = getattr(fn, "_pathsel_types", None)
    if types is None:
        return None, None
    return types, bool(getattr(fn, "_pathsel_variadic", False))


# ---------------------------------------------------------------------------
# helpers


def _fail(message):
    raise InvalidTypeError(message)


def _all_numbers(values, what):
    for v in values:
        if not is_number(v):
            _fail("%s must contain only numbers" % what)


def _homogeneous_kind(values, what):
    """Return 'number' or 'string' if all values share that kind; fail otherwise."""
    if not values:
        return None
    if all(is_number(v) for v in values):
        return "number"
    if all(isinstance(v, str) for v in values):
        return "string"
    _fail("%s must be all numbers or all strings" % what)


def _json_ready(value):
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, Mapping):
        return {str(k): _json_ready(v) for k, v in value.items()}
    if is_array(value):
        return [_json_ready(v) for v in value]
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    return str(value)


_INT_NUMERAL = re.compile(r"[+-]?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"[+-]?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


# ---------------------------------------------------------------------------
# built-in implementations: fn(ctx, *args)


@_builtin("abs", ["number"])
def _b_abs(ctx, x):
    return abs(x)


@_builtin("avg", ["array"])
def _b_avg(ctx, values):
    _all_numbers(values, "avg")
    if not values:
        return None
    return sum(values) / len(values)


@_builtin("ceil", ["number"])
def _b_ceil(ctx, x):
    return math.ceil(x)


@_builtin("floor", ["number"])
def _b_floor(ctx, x):
    return math.floor(x)


@_builtin("contains", ["array", "string"], ["any"])
def _b_contains(ctx, container, item):
    if is_array(container):
        return any(json_equal(element, item, ctx) for element in container)
    if not isinstance(item, str):
        _fail("contains on a string needs a string argument")
    return item in container


@_builtin("ends_with", ["string"], ["string"])
def _b_ends_with(ctx, text, suffix):
    return text.endswith(suffix)


@_builtin("starts_with", ["string"], ["string"])
def _b_starts_with(ctx, text, prefix):
    return text.startswith(prefix)


@_builtin("length", ["string", "array", "object"])
# spec: N-000277 N-000314
def _b_length(ctx, value):
    return len(value)


@_builtin("reverse", ["array", "string"])
def _b_reverse(ctx, value):
    if isinstance(value, str):
        return value[::-1]
    return list(reversed(value))


@_builtin("join", ["string"], ["array"])
# spec: N-000279 N-000280 N-000264
def _b_join(ctx, separator, values):
    for v in values:
        if not isinstance(v, str):
            _fail("join needs an array of strings")
    if not values:
        return ""
    return separator.join(values)


@_builtin("keys", ["object"])
def _b_keys(ctx, obj):
    return list(obj.keys())


@_builtin("values", ["object"])
def _b_values(ctx, obj):
    return list(obj.values())


@_builtin("type", ["any"])
# spec: N-000282 N-000315
def _b_type(ctx, value):
    if isinstance(value, bool):
        return "boolean"
    if value is None:
        return "null"
    if isinstance(value, str):
        return "string"
    if is_number(value) or isinstance(value, Decimal):
        return "number"
    if is_array(value):
        return "array"
    if is_object(value, ctx):
        return "object"
    _fail("type of a value that is not a JSON type")


@_builtin("to_array", ["any"])
def _b_to_array(ctx, value):
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


@_builtin("to_string", ["any"])
def _b_to_string(ctx, value):
    if isinstance(value, str):
        return value
    return json.dumps(_json_ready(value), separators=(",", ":"), ensure_ascii=True)


@_builtin("to_number", ["any"])
# spec: N-000286 N-000287 N-000288 N-000289
def _b_to_number(ctx, value):
    if is_number(value):
        return value
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, str):
        if _INT_NUMERAL.fullmatch(value):
            return int(value)
        if _FLOAT_NUMERAL.fullmatch(value):
            return float(value)
    return None


@_builtin("max", ["array"])
def _b_max(ctx, values):
    if _homogeneous_kind(values, "max") is None:
        return None
    return max(values)


@_builtin("min", ["array"])
def _b_min(ctx, values):
    if _homogeneous_kind(values, "min") is None:
        return None
    return min(values)


@_builtin("sort", ["array"])
def _b_sort(ctx, values):
    _homogeneous_kind(values, "sort")
    return sorted(values)


@_builtin("sum", ["array"])
def _b_sum(ctx, values):
    _all_numbers(values, "sum")
    return sum(values)


@_builtin("merge", ["object"], variadic=True)
def _b_merge(ctx, *objects):
    result = {}
    for obj in objects:
        result.update(obj)
    return result


@_builtin("not_null", ["any"], variadic=True)
def _b_not_null(ctx, *values):
    for v in values:
        if v is not None:
            return v
    return None


@_builtin("map", ["expref"], ["array"])
def _b_map(ctx, ref, values):
    return [ref.apply(v) for v in values]


def _keys_for(ref, values):
    keys = [ref.apply(v) for v in values]
    _homogeneous_kind(keys, "sort key")
    return keys


@_builtin("sort_by", ["array"], ["expref"])
# spec: N-000303 N-000304 N-000305 N-000318
def _b_sort_by(ctx, values, ref):
    if not values:
        return []
    keys = _keys_for(ref, values)
    order = sorted(range(len(values)), key=lambda i: keys[i])
    return [values[i] for i in order]


@_builtin("max_by", ["array"], ["expref"])
def _b_max_by(ctx, values, ref):
    if not values:
        return None
    keys = _keys_for(ref, values)
    best = 0
    for i in range(1, len(values)):
        if keys[i] > keys[best]:
            best = i
    return values[best]


@_builtin("min_by", ["array"], ["expref"])
def _b_min_by(ctx, values, ref):
    if not values:
        return None
    keys = _keys_for(ref, values)
    best = 0
    for i in range(1, len(values)):
        if keys[i] < keys[best]:
            best = i
    return values[best]


# ---------------------------------------------------------------------------
# provider class


# spec: N-000393 N-000394 N-000395 N-000396 N-000397 N-000398 N-000399 N-000400 N-000337 N-000339 N-000340
class Functions:
    """The provider of the built-in functions. Subclass it to add functions.

    Add a function by defining ``_func_<name>`` decorated with ``signature``.
    The first parameter of the implementation is the provider instance.
    """

    def __repr__(self):
        return "pathsel.functions.Functions()"


def _make_method(builtin):
    def method(self, *args):
        return builtin.fn(None, *args)

    method.__name__ = "_func_" + builtin.name
    method._pathsel_types = builtin.types
    method._pathsel_variadic = builtin.variadic
    return method


for _builtin_entry in BUILTINS.values():
    setattr(Functions, "_func_" + _builtin_entry.name, _make_method(_builtin_entry))
del _builtin_entry


__all__ = ["Functions", "signature", "BUILTINS"]
