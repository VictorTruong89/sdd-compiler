"""Expression tree and its evaluation.

Every node has ``eval(current, ctx)``. ``current`` is the current value and
``ctx`` is the evaluation context built from the caller's options. Evaluation
never mutates the input document.
"""

from .errors import InvalidTypeError, UnknownFunctionError, InvalidArityError, ZeroSliceStepError
from .functions import BUILTINS, signature_for_custom
from .values import (
    Reference,
    is_array,
    is_false,
    is_object,
    json_equal,
    json_order,
    type_matches,
)


class Context:
    """Per-search evaluation context built from an options object (FP-08)."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None)
        self.provider = getattr(options, "custom_functions", None)

    def resolve_function(self, name):
        """Return (types, variadic, callable) for a function name.

        Built-ins take precedence; otherwise the provider's signed
        ``_func_<name>`` attribute is used. Raises UnknownFunctionError.
        """
        builtin = BUILTINS.get(name)
        if builtin is not None:
            return builtin.types, builtin.variadic, _bind_builtin(builtin, self)
        if self.provider is not None:
            fn = getattr(self.provider, "_func_" + name, None)
            if fn is not None:
                types, variadic = signature_for_custom(fn)
                if types is not None:
                    return types, variadic, fn
        raise UnknownFunctionError("unknown function: %s" % name)


def _bind_builtin(builtin, ctx):
    def call(*args):
        return builtin.fn(ctx, *args)

    return call


def _project(items, rhs, ctx):
    """Evaluate ``rhs`` for each item and collect the non-null results."""
    out = []
    for item in items:
        value = rhs.eval(item, ctx)
        if value is not None:
            out.append(value)
    return out


def _norm_index(value, length, lo, hi):
    if value < 0:
        value += length
    return min(max(value, lo), hi)


# spec: N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141
def slice_indices(length, start, stop, step):
    """Indices selected by a slice over an array of ``length`` elements (FP-03)."""
    if step is None:
        step = 1
    if step == 0:
        raise ZeroSliceStepError("slice step must not be zero")
    if step > 0:
        lo, hi = 0, length
        s = 0 if start is None else _norm_index(start, length, lo, hi)
        e = length if stop is None else _norm_index(stop, length, lo, hi)
    else:
        lo, hi = -1, length - 1
        s = length - 1 if start is None else _norm_index(start, length, lo, hi)
        e = -1 if stop is None else _norm_index(stop, length, lo, hi)
    return [i for i in range(s, e, step) if 0 <= i < length]


class Node:
    def eval(self, cur, ctx):  # pragma: no cover - interface
        raise NotImplementedError


# spec: N-000151
class Identity(Node):
    """The current value itself: ``@``, and the empty right-hand side of a projection."""

    def eval(self, cur, ctx):
        return cur


class Literal(Node):
    """A JSON literal, a raw string literal, or a constant."""

    def __init__(self, value):
        self.value = value

    def eval(self, cur, ctx):
        return self.value


# spec: N-000077 N-000083 N-000084 N-000085 N-000115 N-000116 N-000125
class Field(Node):
    """An identifier: selects a field of an object, otherwise null."""

    def __init__(self, name):
        self.name = name

    def eval(self, cur, ctx):
        if is_object(cur, ctx):
            return cur.get(self.name)
        return None


# spec: N-000126 N-000127 N-000128 N-000129 N-000156 N-000157
class Index(Node):
    """A single array element, zero-based, negative from the end (FP-03)."""

    def __init__(self, left, index):
        self.left = left
        self.index = index

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not is_array(value):
            return None
        i = self.index
        if i < 0:
            i += len(value)
        if 0 <= i < len(value):
            return value[i]
        return None


# spec: N-000108 N-000219 N-000220 N-000221 N-000222
class Chain(Node):
    """Evaluate ``right`` with the result of ``left`` as current value.

    Used for field chains (dot) and for the pipe operator.
    """

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


# spec: N-000251 N-000252 N-000253 N-000256 N-000257
class Not(Node):
    def __init__(self, operand):
        self.operand = operand

    def eval(self, cur, ctx):
        return is_false(self.operand.eval(cur, ctx), ctx)


# spec: N-000247 N-000248 N-000249 N-000250 N-000255
class Or(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not is_false(value, ctx):
            return value
        return self.right.eval(cur, ctx)


# spec: N-000247 N-000248 N-000249 N-000250 N-000254
class And(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if is_false(value, ctx):
            return value
        return self.right.eval(cur, ctx)


# spec: N-000242 N-000243 N-000244 N-000245 N-000246 N-000253 N-000255 N-000256
class Compare(Node):
    """``==``, ``!=``, ``<``, ``<=``, ``>``, ``>=`` (FP-06).

    Ordering of values that are neither two numbers nor two strings yields null.
    """

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        a = self.left.eval(cur, ctx)
        b = self.right.eval(cur, ctx)
        if self.op == "eq":
            return json_equal(a, b, ctx)
        if self.op == "ne":
            return not json_equal(a, b, ctx)
        order = json_order(a, b)
        if order is None:
            return None
        if self.op == "lt":
            return order < 0
        if self.op == "lte":
            return order <= 0
        if self.op == "gt":
            return order > 0
        return order >= 0  # gte


# spec: N-000211 N-000212 N-000213 N-000214 N-000215
class MultiList(Node):
    """``[e1, e2, ...]``: one element per expression, nulls stored (FP-05)."""

    def __init__(self, items):
        self.items = items

    def eval(self, cur, ctx):
        if cur is None:
            return None
        return [item.eval(cur, ctx) for item in self.items]


# spec: N-000206 N-000207 N-000208 N-000209 N-000210 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218
class MultiHash(Node):
    """``{k: e, ...}``: one entry per pair, nulls stored; built as the options' mapping type."""

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, cur, ctx):
        if cur is None:
            return None
        result = ctx.dict_cls() if ctx.dict_cls is not None else {}
        for key, node in self.pairs:
            result[key] = node.eval(cur, ctx)
        return result


# spec: N-000231 N-000232 N-000233 N-000234 N-000235 N-000236 N-000423
class Ref(Node):
    """``&expr``: an expression reference, applied later by a function (FP-05)."""

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return Reference(self.node, ctx)


# spec: N-000263 N-000264 N-000265 N-000266 N-000267 N-000268 N-000309 N-000310 N-000311 N-000312 N-000313 N-000344 N-000345 N-000346 N-000347 N-000348 N-000349 N-000350
class FunctionCall(Node):
    """``name(args...)``: checked name, then count, then each argument's type (FP-07, FP-08)."""

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, cur, ctx):
        types, variadic, fn = ctx.resolve_function(self.name)
        count = len(self.args)
        if variadic:
            if count < 1:
                raise InvalidArityError("%s takes one or more arguments" % self.name)
        elif count != len(types):
            raise InvalidArityError(
                "%s takes %d arguments, got %d" % (self.name, len(types), count)
            )
        values = [arg.eval(cur, ctx) for arg in self.args]
        for i, value in enumerate(values):
            allowed = types[0] if variadic else types[i]
            if not any(type_matches(value, name, ctx) for name in allowed):
                raise InvalidTypeError("argument %d of %s has the wrong type" % (i + 1, self.name))
        return fn(*values)


# spec: N-000159 N-000160 N-000161 N-000162 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190
class ListProjection(Node):
    """``left[*] rhs``: non-null results over the elements of an array."""

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, cur, ctx):
        base = self.left.eval(cur, ctx)
        if not is_array(base):
            return None
        return _project(base, self.rhs, ctx)


# spec: N-000163 N-000164 N-000165 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190
class ValueProjection(Node):
    """``left.* rhs`` / ``*``: non-null results over the values of an object."""

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, cur, ctx):
        base = self.left.eval(cur, ctx)
        if not is_object(base, ctx):
            return None
        return _project(list(base.values()), self.rhs, ctx)


# spec: N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000202 N-000203
class FilterProjection(Node):
    """``left[?predicate] rhs``: keep elements whose predicate is a true value (FP-04)."""

    def __init__(self, left, predicate, rhs):
        self.left = left
        self.predicate = predicate
        self.rhs = rhs

    def eval(self, cur, ctx):
        base = self.left.eval(cur, ctx)
        if not is_array(base):
            return None
        kept = [el for el in base if not is_false(self.predicate.eval(el, ctx), ctx)]
        return _project(kept, self.rhs, ctx)


# spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150
class FlattenProjection(Node):
    """``left[] rhs``: splice one level of nested arrays (FP-03)."""

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, cur, ctx):
        base = self.left.eval(cur, ctx)
        if not is_array(base):
            return None
        flat = []
        for el in base:
            if is_array(el):
                flat.extend(el)
            else:
                flat.append(el)
        return _project(flat, self.rhs, ctx)


# spec: N-000142 N-000143 N-000144
class SliceProjection(Node):
    """``left[start:stop:step] rhs``: selected elements, then a projection (FP-03)."""

    def __init__(self, left, start, stop, step, rhs):
        self.left = left
        self.start = start
        self.stop = stop
        self.step = step
        self.rhs = rhs

    def eval(self, cur, ctx):
        base = self.left.eval(cur, ctx)
        if not is_array(base):
            return None
        picked = [base[i] for i in slice_indices(len(base), self.start, self.stop, self.step)]
        return _project(picked, self.rhs, ctx)


__all__ = [
    "Context",
    "Identity",
    "Literal",
    "Field",
    "Index",
    "Chain",
    "Not",
    "Or",
    "And",
    "Compare",
    "MultiList",
    "MultiHash",
    "Ref",
    "FunctionCall",
    "ListProjection",
    "ValueProjection",
    "FilterProjection",
    "FlattenProjection",
    "SliceProjection",
    "slice_indices",
]
