"""Tests for pathsel, written from the specification in spec/.

Each test names the spec ids it exercises in a comment where the mapping is
direct. Run with: python -m pytest -q tests
"""

import collections
import decimal
import sys
import os

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    PathSelTokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature  # noqa: E402


def opts(dict_cls=None, custom_functions=None):
    class Options:
        pass

    o = Options()
    o.dict_cls = dict_cls
    o.custom_functions = custom_functions
    return o


def s(expr, data, options=None):
    return pathsel.search(expr, data, options)


# --- FP-01: entries, missing is null, failures -------------------------------


def test_dotted_path_returns_nested_value():  # N-000002 N-000003 N-000077
    assert s("a.b", {"a": {"b": 5}}) == 5
    assert s("a.b.c", {"a": {"b": {"c": "x"}}}) == "x"


def test_missing_path_is_null_not_failure():  # N-000003 N-000041 N-000059 N-000083
    assert s("a.b.c", {"a": {}}) is None
    assert s("a.b.c", {"a": {"b": 1}}) is None


def test_identifier_on_array_is_null():  # N-000083 N-000085
    assert s("a.b", {"a": [{"b": 1}]}) is None


def test_compile_then_search_matches_one_shot():  # N-000080 N-000081 N-000078
    expr = "a[*].b | [0]"
    doc = {"a": [{"b": 1}, {"b": 2}]}
    parsed = pathsel.compile(expr)
    assert parsed.search(doc) == s(expr, doc) == 1
    assert parsed.search({"a": []}) is None
    assert parsed.search({"a": [{"b": 7}]}) == 7


def test_compiling_success_even_when_search_null():  # N-000086
    parsed = pathsel.compile("nothing.here")
    assert parsed.search({}) is None


def test_empty_expression_kind():  # N-000087 N-000088 N-000089
    with pytest.raises(EmptyExpressionError) as info:
        pathsel.search("", {})
    assert isinstance(info.value, ValueError)
    with pytest.raises(EmptyExpressionError):
        pathsel.compile("")


def test_whitespace_only_is_incomplete_not_empty():  # N-000090 N-000091 N-000092 N-000093
    for text in [" ", "\t", "\n", "\r\n", "  "]:
        with pytest.raises(IncompleteExpressionError) as info:
            pathsel.compile(text)
        assert not isinstance(info.value, EmptyExpressionError)
        assert info.value.lex_position == len(text)


def test_incomplete_ends():
    for text in ["a.b |", "a ||", "a &&", "[0", "{a:", "(a", "f(", "a ==", "!"]:
        with pytest.raises(IncompleteExpressionError):
            pathsel.compile(text)


def test_dot_at_end_is_syntax_not_incomplete():  # N-000094
    with pytest.raises(PathSelSyntaxError) as info:
        pathsel.compile("a.")
    assert not isinstance(info.value, IncompleteExpressionError)
    assert info.value.lex_position == 2


def test_syntax_kinds_and_positions():  # N-000094 N-000095 N-000102 N-000104
    for text in ["a..b", ".a", "a.1", "a.@", "a b", "a)", "[a,]", "{a}", "a[0]{x:y}", "[0:1:2:3]"]:
        with pytest.raises(PathSelSyntaxError) as info:
            pathsel.compile(text)
        assert 0 <= info.value.lex_position <= len(text)
    with pytest.raises(PathSelSyntaxError) as a:
        pathsel.compile("xyz..a")
    with pytest.raises(PathSelSyntaxError) as b:
        pathsel.compile("x y.z")
    assert a.value.lex_position != b.value.lex_position


def test_token_level_is_subclass_of_syntax_but_not_syntax():  # N-000096 N-000098 N-000100
    for text in ["$", "`1", "'abc", '"abc', "a =", "a-b", '"\\q"']:
        with pytest.raises(PathSelTokenSyntaxError) as info:
            pathsel.compile(text)
        err = info.value
        assert isinstance(err, PathSelSyntaxError)
        assert type(err) is not PathSelSyntaxError
        assert not isinstance(err, (EmptyExpressionError, IncompleteExpressionError))


def test_refusals_are_value_errors():  # N-000405
    for text in ["", " ", "a..b", "[::0]"]:
        with pytest.raises(ValueError):
            pathsel.compile(text)


# --- FP-02: identifiers ------------------------------------------------------


def test_unquoted_identifier_chars():  # N-000107
    assert s("_a1._B_2", {"_a1": {"_B_2": 3}}) == 3
    assert s("_a1", {"_a1": 4}) == 4
    assert s("ab_C9", {"ab_C9": 1}) == 1


def test_whitespace_between_tokens():  # N-000109
    assert s("  a \t . \n b ", {"a": {"b": 2}}) == 2


def test_quoted_identifiers_name_any_key():  # N-000110 N-000111 N-000112 N-000113 N-000114
    doc = {"a b": 1, "x.y": 2, "a-b": 3, "9lives": 4, 'q"uote': 5, "é": 6, "a": {"b": 7}}
    assert s('"a b"', doc) == 1
    assert s('"x.y"', doc) == 2
    assert s('"a-b"', doc) == 3
    assert s('"9lives"', doc) == 4
    assert s('"q\\"uote"', doc) == 5
    assert s('"\\u00e9"', doc) == 6
    assert s('"a".b', doc) == 7


def test_field_on_array_is_null_not_projection():  # N-000115 N-000116
    assert s("a", {"a": [1, 2]}) == [1, 2]
    assert s("a.b", {"a": [{"b": 1}]}) is None


def test_number_after_dot_is_grammar_syntax():  # N-000117 N-000118
    with pytest.raises(PathSelSyntaxError) as info:
        pathsel.compile("a.-1")
    assert not isinstance(info.value, PathSelTokenSyntaxError)


def test_hyphen_rules():  # N-000119 N-000120 N-000121 N-000122
    with pytest.raises(PathSelTokenSyntaxError):
        pathsel.compile("a-b")
    with pytest.raises(PathSelTokenSyntaxError):
        pathsel.compile("-")
    assert s('"a-b"', {"a-b": 3}) == 3


def test_leading_trailing_doubled_dot_syntax():  # N-000123
    for text in [".a", "a.", "a..b"]:
        with pytest.raises(PathSelSyntaxError):
            pathsel.compile(text)


def test_bad_quoted_identifier_token_error():  # N-000124
    for text in ['"abc', '"a\\x"']:
        with pytest.raises(PathSelTokenSyntaxError):
            pathsel.compile(text)


# --- FP-03: index, slice, flatten -------------------------------------------


def test_index_and_negative_index():  # N-000126 N-000127 N-000128
    doc = [10, 20, 30]
    assert s("[0]", doc) == 10
    assert s("[-1]", doc) == 30
    assert s("[3]", doc) is None
    assert s("[-4]", doc) is None


def test_index_on_non_array_is_null():  # N-000129
    assert s("a[0]", {"a": {"0": 1}}) is None
    assert s("a[0]", {"a": "xyz"}) is None


def test_slices():  # N-000130-N-000141
    doc = [0, 1, 2, 3, 4, 5]
    assert s("[1:3]", doc) == [1, 2]
    assert s("[::2]", doc) == [0, 2, 4]
    assert s("[::-1]", doc) == [5, 4, 3, 2, 1, 0]
    assert s("[-2:]", doc) == [4, 5]
    assert s("[:-4]", doc) == [0, 1]
    assert s("[5:1]", doc) == []
    assert s("[10:20]", doc) == []
    assert s("[::-2]", doc) == [5, 3, 1]
    assert s("[1:3]", []) == []


def test_slice_on_non_array_chosen_null():  # N-000142 (CF-000007 resolved)
    assert s("[1:2]", {"a": 1}) is None


def test_zero_slice_step_refuses():  # N-000152 N-000153 N-000154
    with pytest.raises(ZeroSliceStepError):
        pathsel.compile("[::0]")
    with pytest.raises(ValueError):
        s("[1:2:0]", [1, 2])


def test_slice_with_bad_parts_syntax():  # N-000155
    for text in ["[0:1:2:3]", "[a:1]", "[1.5]"]:
        with pytest.raises(PathSelSyntaxError):
            pathsel.compile(text)


def test_slice_is_projection():  # N-000143 N-000144
    doc = [{"a": 1}, {"b": 2}, {"a": 3}]
    assert s("[0:3].a", doc) == [1, 3]


def test_flatten_one_level():  # N-000145 N-000146 N-000147
    assert s("[]", [[1, 2], 3, [4, [5]]]) == [1, 2, 3, 4, [5]]
    assert s("[]", {"a": 1}) is None


def test_flatten_projection():  # N-000148 N-000149 N-000150
    doc = {"a": [[{"b": 1}], [{"b": 2}, {"c": 0}], {"b": 9}]}
    assert s("a[].b", doc) == [1, 2, 9]


def test_index_slice_flatten_as_whole_expression():  # N-000151
    assert s("[0]", [7]) == 7
    assert s("[]", [[1]]) == [1]


# --- FP-04: wildcard and filter projections ----------------------------------


def test_list_wildcard_projection():  # N-000156-ish
    doc = {"a": [{"b": 1}, {"b": None}, {"b": 3}]}
    assert s("a[*].b", doc) == [1, 3]
    assert s("[*]", [1, None, 2]) == [1, 2]
    assert s("a[*]", {"x": 1}) is None


def test_projection_rules_dot_chains_join_rhs():  # N-000108 + FP-04 ranking
    doc = {"a": [{"b": {"c": 1}}, {"b": {"c": 2}}]}
    assert s("a[*].b.c", doc) == [1, 2]
    assert s("a[*].b[0]", {"a": [{"b": [5]}, {"b": [6]}]}) == [5, 6]


def test_comparison_after_projection_compares_whole_array():  # FP-04/FP-06
    assert s("a[*].b == `[1,2]`", {"a": [{"b": 1}, {"b": 2}]}) is True


def test_object_wildcard():  # N-000  FP-04
    doc = {"a": {"x": {"v": 1}, "y": {"v": 2}, "z": {"w": 0}}}
    assert s("a.*.v", doc) == [1, 2]
    assert s("*", {"k": 1, "j": None, "m": 2}) == [1, 2]
    assert s("*", {"k": 1, "j": 2}) == [1, 2]


def test_object_wildcard_on_non_object_is_null():  # CF-000027 resolved -> null
    assert s("a.*", {"a": [1, 2]}) is None
    assert s("a.*", {"a": 1}) is None


def test_filter_projection():  # FP-04 filter
    doc = [{"a": 1, "n": "x"}, {"a": 0, "n": "y"}, {"a": 5, "n": "z"}]
    assert s("[?a].n", doc) == ["x", "y", "z"]
    assert s("[?a == `5`].n", doc) == ["z"]
    assert s("[?a == `0`]", doc) == [{"a": 0, "n": "y"}]


def test_filter_on_non_array_is_null():  # CF-000005 resolved -> null
    assert s("a[?b]", {"a": {"b": 1}}) is None


def test_filter_zero_is_true_value():  # FP-04
    assert s("[?@]", [0, 1, None, False, "", []]) == [0, 1]


def test_filter_with_equality_is_json_equality():  # FP-04
    assert s("[?@ == `1`]", [0, 1, True, 1.0]) == [1, 1.0]


# --- FP-05: constructors, pipe, current value, literals ----------------------


def test_multiselect_list():  # N-000 FP-05
    doc = {"a": 1, "b": None}
    assert s("[a, b, c]", doc) == [1, None, None]
    assert s("a.[b, a]", {"a": {"b": 2}}) == [2, None]


def test_multiselect_hash_stores_null():  # FP-05
    assert s("{x: a, y: b}", {"a": 1}) == {"x": 1, "y": None}
    assert s('{"a b": a}', {"a": 1}) == {"a b": 1}


def test_multiselect_on_null_current_yields_null():  # CF-000011 resolved -> null
    assert s("[a, b]", None) is None
    assert s("{x: a}", None) is None


def test_multiselect_list_projection_rhs():  # FP-05
    doc = {"a": [{"b": 1, "c": 2}, {"b": 3, "c": 4}]}
    assert s("a[*][b, c]", doc) == [[1, 2], [3, 4]]


def test_multiselect_list_directly_after_operand_is_syntax():  # FP-05
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile("a[0,1]")


def test_pipe_stops_projection():  # FP-05
    doc = {"a": [{"b": 1}, {"b": 2}]}
    assert s("a[*].b | [1]", doc) == 2
    assert s("a | length(@)", doc) == 2


def test_pipe_has_loosest_binding():  # FP-05 / FP-06
    assert s("a || b | c", {"a": None, "b": {"c": 9}}) == 9


def test_current_value_token():  # FP-05
    assert s("@", 5) == 5
    assert s("@.a", {"a": 2}) == 2
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile("a[*].@")


def test_json_literals():  # FP-05
    assert s("`1`", None) == 1
    assert s("`{\"a\": [1]}`.a", None) == [1]
    assert s("`abc`", None) == "abc"
    assert s("`\"x\"`", None) == "x"
    assert s("`  true `", None) is True


def test_literal_after_dot_is_syntax():  # FP-05
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile("a.`1`")


def test_raw_string_literal():  # FP-05
    assert s("'12'", None) == "12"
    assert s("'a b  c'", None) == "a b  c"
    assert s("'it\\'s'", None) == "it's"
    assert s("'\\u0041'", None) == "A"


def test_expression_reference_top_level_is_non_null():  # FP-05 / Interface
    assert s("&a", {"a": 1}) is not None


# --- FP-06: comparators and logic --------------------------------------------


def test_equality_is_json_equality():  # FP-06
    assert s("a == b", {"a": 0, "b": False}) is False
    assert s("a == b", {"a": 1, "b": True}) is False
    assert s("a == b", {"a": 1, "b": 1.0}) is True
    assert s("a == b", {"a": [1, {"x": 1}], "b": [1.0, {"x": 1}]}) is True
    assert s("a != b", {"a": "x", "b": "x"}) is False


def test_ordering():  # FP-06
    assert s("a < b", {"a": 1, "b": 2.5}) is True
    assert s("a >= b", {"a": "b", "b": "a"}) is True
    assert s("a <= `1`", {"a": 1}) is True
    assert s("a > `1`", {"a": 1}) is False


def test_or_and_return_operands():  # FP-06
    assert s("a || b", {"a": 0, "b": 2}) == 0
    assert s("a || b", {"a": None, "b": 2}) == 2
    assert s("a && b", {"a": 0, "b": 2}) == 2  # 0 is a true value, so && returns the right operand
    assert s("a && b", {"a": 1, "b": 2}) == 2
    assert s("a && b", {"a": "", "b": 2}) == ""


def test_not_truthiness():  # FP-06
    assert s("!a", {"a": 0}) is False
    assert s("!a", {"a": 0.0}) is False
    assert s("!a", {"a": []}) is True
    assert s("!a", {"a": {}}) is True
    assert s("!a", {"a": ""}) is True
    assert s("!a", {"a": None}) is True
    assert s("!a", {"a": False}) is True
    assert s("!a", {"a": "x"}) is False


def test_not_binding():  # FP-06
    assert s("!a.b", {"a": {"b": None}}) is None  # .b applies to the result of !
    assert s("!(a.b)", {"a": {"b": None}}) is True
    assert s("!a == `false`", {"a": 1}) is True


def test_and_or_missing_side_refuses():  # FP-06
    for text in ["a &&", "a ||"]:
        with pytest.raises(IncompleteExpressionError):
            pathsel.compile(text)
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile("&& a")


def test_lone_ampersand_refuses():  # FP-06
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile("a & b")


def test_parentheses_group():  # FP-06
    assert s("(a || b) && c", {"a": None, "b": 1, "c": 2}) == 2


# --- FP-07: built-in functions ----------------------------------------------


def test_builtin_scalars():  # FP-07
    assert s("abs(a)", {"a": -3}) == 3
    assert s("ceil(a)", {"a": 1.2}) == 2 and isinstance(s("ceil(a)", {"a": 1.2}), int)
    assert s("floor(a)", {"a": 1.8}) == 1


def test_bool_is_not_number_for_functions():  # FP-02/FP-07
    with pytest.raises(InvalidTypeError):
        s("abs(a)", {"a": True})


def test_decimal_is_not_json_number_for_functions():  # Non-functional constraints
    with pytest.raises(InvalidTypeError):
        s("abs(a)", {"a": decimal.Decimal("1.5")})
    assert s("a == `1`", {"a": decimal.Decimal("1")}) is True
    assert s("a < `2`", {"a": decimal.Decimal("1.5")}) is True


def test_avg_sum_max_min_sort():  # FP-07
    assert s("avg(a)", {"a": [1, 2, 3]}) == 2
    assert s("avg(a)", {"a": []}) is None
    assert s("sum(a)", {"a": [1, 2.5]}) == 3.5
    assert s("max(a)", {"a": [1, 3, 2]}) == 3
    assert s("min(a)", {"a": ["b", "a"]}) == "a"
    assert s("max(a)", {"a": []}) is None
    assert s("sort(a)", {"a": [3, 1, 2]}) == [1, 2, 3]
    assert s("sort(a)", {"a": ["b", "B", "a"]}) == ["B", "a", "b"]


def test_mixed_element_types_invalid():  # FP-07
    with pytest.raises(InvalidTypeError):
        s("max(a)", {"a": [1, "x"]})
    with pytest.raises(InvalidTypeError):
        s("sum(a)", {"a": [1, "x"]})


def test_contains_starts_ends():  # FP-07
    assert s("contains(a, `2`)", {"a": [1, 2]}) is True
    assert s("contains(a, `true`)", {"a": [1]}) is False
    assert s("contains(a, 'bc')", {"a": "abcd"}) is True
    assert s("starts_with(a, 'ab')", {"a": "abc"}) is True
    assert s("ends_with(a, 'bc')", {"a": "abc"}) is True
    with pytest.raises(InvalidTypeError):
        s("contains(a, `1`)", {"a": "abc"})


def test_length_counts_characters():  # CF-000035 resolved -> code points
    assert s("length(a)", {"a": "héllo"}) == 5
    assert s("length(a)", {"a": [1, 2]}) == 2
    assert s("length(a)", {"a": {"x": 1}}) == 1
    with pytest.raises(InvalidTypeError):
        s("length(a)", {"a": 1})


def test_reverse_join_keys_values():  # FP-07
    assert s("reverse(a)", {"a": [1, 2]}) == [2, 1]
    assert s("reverse(a)", {"a": "ab"}) == "ba"
    assert s("join(', ', a)", {"a": ["x", "y"]}) == "x, y"
    assert s("join(',', a)", {"a": []}) == ""
    assert s("keys(a)", {"a": {"x": 1, "y": 2}}) == ["x", "y"]
    assert s("values(a)", {"a": {"x": 1, "y": 2}}) == [1, 2]


def test_type_function():  # FP-07
    assert s("type(a)", {"a": "x"}) == "string"
    assert s("type(a)", {"a": 1}) == "number"
    assert s("type(a)", {"a": False}) == "boolean"
    assert s("type(a)", {"a": [1]}) == "array"
    assert s("type(a)", {"a": {}}) == "object"
    assert s("type(a)", {}) == "null"


def test_to_array_to_string_to_number():  # FP-07
    assert s("to_array(a)", {"a": 1}) == [1]
    assert s("to_array(a)", {"a": [1]}) == [1]
    assert s("to_array(a)", {}) == [None]
    assert s("to_string(a)", {"a": "x"}) == "x"
    assert s("to_string(a)", {"a": {"k": [1, True, None]}}) == '{"k":[1,true,null]}'
    assert s("to_string(a)", {"a": 1.5}) == "1.5"
    assert s("to_string(a)", {"a": "é"}) == "é"
    assert s("to_string(a)", {"a": [1, "é"]}) == '[1,"\\u00e9"]'
    assert s("to_number(a)", {"a": "12"}) == 12 and isinstance(s("to_number(a)", {"a": "12"}), int)
    assert s("to_number(a)", {"a": "1.5"}) == 1.5
    assert s("to_number(a)", {"a": "1e2"}) == 100.0
    assert s("to_number(a)", {"a": "x"}) is None
    assert s("to_number(a)", {"a": True}) is None
    assert s("to_number(a)", {"a": [1]}) is None


def test_max_by_min_by_sort_by_map_not_null_merge():  # FP-07
    doc = {"a": [{"k": 2, "n": "x"}, {"k": 5, "n": "y"}, {"k": 5, "n": "z"}]}
    assert s("max_by(a, &k).n", doc) == "y"
    assert s("min_by(a, &k).n", doc) == "x"
    assert s("sort_by(a, &k)[*].n", doc) == ["x", "y", "z"]
    assert s("map(&k, a)", doc) == [2, 5, 5]
    assert s("map(&k, a)", {"a": [{"k": 1}, {}]}) == [1, None]
    assert s("max_by(a, &k)", {"a": []}) is None
    assert s("not_null(a, b, c)", {"b": None, "c": "x"}) == "x"
    assert s("not_null(a, b)", {}) is None
    assert s("not_null(a)", {"a": ""}) == ""
    assert s("merge(a, b)", {"a": {"x": 1}, "b": {"x": 2, "y": 3}}) == {"x": 2, "y": 3}


def test_sort_by_stable_and_key_rules():  # FP-07
    doc = {"a": [{"k": "b", "i": 1}, {"k": "a", "i": 2}, {"k": "b", "i": 3}]}
    assert [x["i"] for x in s("sort_by(a, &k)", doc)] == [2, 1, 3]
    with pytest.raises(InvalidTypeError):
        s("sort_by(a, &k)", {"a": [{"k": 1}, {"k": "x"}]})
    with pytest.raises(InvalidTypeError):
        s("sort_by(a, &k)", {"a": [{"k": None}]})


def test_unknown_function_at_search_not_compile():  # FP-07
    parsed = pathsel.compile("nope(a)")
    with pytest.raises(UnknownFunctionError):
        parsed.search({"a": 1})
    assert isinstance(UnknownFunctionError("x"), ValueError)


def test_arity_and_type_checked_at_search():  # FP-07
    parsed = pathsel.compile("abs(a, b)")
    with pytest.raises(InvalidArityError):
        parsed.search({})
    with pytest.raises(InvalidArityError):
        s("not_null()", {})
    with pytest.raises(InvalidTypeError):
        s("abs(a)", {"a": "x"})
    with pytest.raises(InvalidTypeError):
        s("abs(a)", {})
    with pytest.raises(InvalidTypeError):
        s("length(a)", {"a": None})


def test_quoted_identifier_cannot_be_function():  # FP-07
    with pytest.raises(PathSelSyntaxError):
        pathsel.compile('"abs"(a)')


def test_function_as_projection_rhs():  # FP-07
    assert s("a[*].length(@)", {"a": ["ab", "c"]}) == [2, 1]


# --- FP-08: evaluation options ----------------------------------------------


def test_dict_cls_for_constructed_hash():  # FP-08
    o = opts(dict_cls=collections.OrderedDict)
    result = s("{x: a}", {"a": 1}, o)
    assert type(result) is collections.OrderedDict
    assert s("{x: a}.x", {"a": 1}, o) == 1
    assert s("length(a)", {"a": "ab"}, o) == 2
    assert s("keys({x: a})", {"a": 1}, o) == ["x"]


def test_dict_cls_hash_is_object_for_functions():  # FP-08
    class Plain(dict):
        pass

    o = opts(dict_cls=Plain)
    assert s("keys({x: a})", {"a": 1}, o) == ["x"]
    assert s("type({x: a})", {"a": 1}, o) == "object"


def test_custom_provider_functions():  # FP-08 / Interface Contract
    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["number"]})
        def _func_add(self, x, y):
            return x + y

        @signature({"types": ["string"]})
        def _func_zero(self, x):
            return 0

        def _func_unsigned(self, x):
            return x

    o = opts(custom_functions=Provider())
    assert s("add(a, b)", {"a": 1, "b": 2}, o) == 3
    assert s("zero(a)", {"a": "q"}, o) == 0
    with pytest.raises(InvalidArityError):
        s("add(a)", {"a": 1}, o)
    with pytest.raises(InvalidTypeError):
        s("add(a, b)", {"a": "x", "b": 2}, o)
    with pytest.raises(UnknownFunctionError):
        s("unsigned(a)", {"a": 1}, o)
    with pytest.raises(UnknownFunctionError):
        s("add(a, b)", {"a": 1, "b": 2})


def test_custom_function_compile_succeeds_without_provider():  # FP-08
    parsed = pathsel.compile("add(a, b)")
    with pytest.raises(UnknownFunctionError):
        parsed.search({"a": 1, "b": 2})


def test_custom_function_zero_and_empty_results_are_values():  # FP-08
    class Provider(Functions):
        @signature({"types": ["array"]})
        def _func_empty(self, x):
            return []

    o = opts(custom_functions=Provider())
    assert s("empty(a)", {"a": [1]}, o) == []


def test_custom_function_rejects_host_value():  # FP-08
    class Provider(Functions):
        @signature({"types": ["object"]})
        def _func_takes(self, x):
            return x

    o = opts(custom_functions=Provider())
    with pytest.raises(InvalidTypeError):
        s("takes(a)", {"a": object()}, o)


def test_builtins_remain_with_provider():  # FP-08
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_twice(self, x):
            return x * 2

    o = opts(custom_functions=Provider())
    assert s("abs(a)", {"a": -2}, o) == 2
    assert s("twice(a)", {"a": 2}, o) == 4


def test_options_may_carry_both():  # FP-08
    class Provider(Functions):
        @signature({"types": ["object"]})
        def _func_count(self, obj):
            return len(obj)

    o = opts(dict_cls=collections.OrderedDict, custom_functions=Provider())
    assert s("count({x: a, y: b})", {"a": 1, "b": 2}, o) == 2
    assert type(s("{x: a}", {"a": 1}, o)) is collections.OrderedDict


def test_options_same_for_search_and_compile():  # FP-08
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_inc(self, x):
            return x + 1

    o = opts(custom_functions=Provider())
    assert pathsel.compile("inc(a)").search({"a": 1}, o) == s("inc(a)", {"a": 1}, o) == 2


# --- Non-goals / constraints / layout ---------------------------------------


def test_input_is_not_mutated():  # N-000069 N-000070
    doc = {"a": [{"b": 1}, {"b": 2}], "c": {"d": 3}}
    before = repr(doc)
    s("a[*].b", doc)
    s("{x: c}", doc)
    s("merge(c, c)", doc)
    s("sort(a[*].b)", doc)
    assert repr(doc) == before


def test_host_values_are_selectable():  # Non-functional constraints
    class Host:
        pass

    h = Host()
    assert s("a", {"a": h}) is h


def test_package_surface():  # N-000038 N-000039 Interface Contract "pathsel"
    assert callable(pathsel.search)
    assert callable(pathsel.compile)
    from pathsel.functions import Functions as F, signature as sig

    assert F is Functions and callable(sig)
    assert issubclass(PathSelSyntaxError, ValueError)
    assert issubclass(PathSelTokenSyntaxError, PathSelSyntaxError)
    assert issubclass(UnknownFunctionError, ValueError)


# --- FP-04 ranking and FP-06 binding of `!` --------------------------------

RANK_DOC = {"a": [{"b": [1, 2, 3], "c": "x", "d": {"e": 1}}, {"b": [4], "c": "y", "d": {"e": 2}}]}


def test_flatten_is_loosest_step_after_filter():  # FP-04 ranking (1)
    # `[]` does not join the filter's right-hand side; it flattens the result.
    assert s("a[?c == 'x'].b[]", RANK_DOC) == [1, 2, 3]


def test_flatten_after_list_wildcard_applies_to_whole_result():  # FP-03 flatten
    assert s("a[*].b[]", RANK_DOC) == [1, 2, 3, 4]


def test_bracket_after_object_wildcard_begins_its_rhs():  # FP-04 reach of a projection
    assert s("a[*].d.*[0]", RANK_DOC) == [[], []]


def test_bracket_after_slice_begins_its_rhs():  # FP-03 slice is a projection
    assert s("a[0].b[::-1][0]", RANK_DOC) == []


def test_bracket_after_list_wildcard_begins_its_rhs():  # FP-04
    assert s("a[*].b[*][0]", RANK_DOC) == [[], []]


def test_pipe_after_index_then_field():  # FP-05 pipe
    assert s("a[0] | b", RANK_DOC) == [1, 2, 3]


def test_not_binds_index_but_not_flatten_or_dot():  # FP-06 binding of !
    assert s("!a[0].c", RANK_DOC) is None  # .c applies to the result of !
    assert s("!(a[0].c)", RANK_DOC) is False
    assert s("!a[]", RANK_DOC) is None  # flatten applies to the result of !
    assert s("!a[0]", RANK_DOC) is False
