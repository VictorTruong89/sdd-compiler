# Traceability: spec/CHECKLIST.md ids

Every id in `spec/CHECKLIST.md` ends in one of three states: **tested** (named by a test), **implemented** (cited by a `# spec:` marker or docstring in `pathsel/`), or **not applicable** (informational or non-goal text; the reason is given). No id is left open. The checklist itself is unchanged.

| Id | Status | Where / test / reason |
|---|---|---|
| N-000001 | tested | N_000001_N_000002_N_000004_N_000005_search_and_compile_entries (test_spec_surface.py) |
| N-000002 | tested | N_000001_N_000002_N_000004_N_000005_search_and_compile_entries (test_spec_surface.py) |
| N-000003 | tested | N_000003_N_000041_N_000059_missing_path_is_null_at_any_depth (test_search_fp01_fp05.py) |
| N-000004 | tested | N_000001_N_000002_N_000004_N_000005_search_and_compile_entries (test_spec_surface.py) |
| N-000005 | tested | N_000001_N_000002_N_000004_N_000005_search_and_compile_entries (test_spec_surface.py) |
| N-000006 | tested | N_000006_N_000007_N_000008_N_000009_compiled_and_one_shot_return_equal_values (test_spec_surface.py) |
| N-000007 | tested | N_000006_N_000007_N_000008_N_000009_compiled_and_one_shot_return_equal_values (test_spec_surface.py) |
| N-000008 | tested | N_000006_N_000007_N_000008_N_000009_compiled_and_one_shot_return_equal_values (test_spec_surface.py) |
| N-000009 | tested | N_000006_N_000007_N_000008_N_000009_compiled_and_one_shot_return_equal_values (test_spec_surface.py) |
| N-000010 | tested | N_000010_N_000011_N_000012_N_000013_feature_points_are_ordered_entries (test_spec_surface.py) |
| N-000011 | tested | N_000010_N_000011_N_000012_N_000013_feature_points_are_ordered_entries (test_spec_surface.py) |
| N-000012 | tested | N_000010_N_000011_N_000012_N_000013_feature_points_are_ordered_entries (test_spec_surface.py) |
| N-000013 | tested | N_000010_N_000011_N_000012_N_000013_feature_points_are_ordered_entries (test_spec_surface.py) |
| N-000014 | tested | N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries (test_spec_surface.py) |
| N-000015 | tested | N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries (test_spec_surface.py) |
| N-000016 | tested | N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries (test_spec_surface.py) |
| N-000017 | tested | N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries (test_spec_surface.py) |
| N-000018 | tested | N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries (test_spec_surface.py) |
| N-000019 | tested | N_000019_N_000020_current_value_changes_under_pipe_projection_and_args (test_spec_surface.py) |
| N-000020 | tested | N_000019_N_000020_current_value_changes_under_pipe_projection_and_args (test_spec_surface.py) |
| N-000021 | tested | N_000021_N_000022_null_is_missing_or_wrong_kind_not_failure (test_spec_surface.py) |
| N-000022 | tested | N_000021_N_000022_null_is_missing_or_wrong_kind_not_failure (test_spec_surface.py) |
| N-000023 | implemented | pathsel/functions.py `_func_to_number`: CF-000057 resolved to N-000287 (integer numerals give int; see NOTES.md) |
| N-000024 | implemented | _values.py |
| N-000025 | tested | N_000025_boolean_is_not_a_number (test_spec_surface.py) |
| N-000026 | tested | N_000026_string_length_counts_characters_resolution_of_CF_000035 (test_spec_surface.py) |
| N-000027 | tested | N_000027_boolean_is_not_one_or_zero (test_spec_surface.py) |
| N-000028 | tested | N_000028_bare_expression_reference_is_not_null_resolution_of_CF_000056 (test_spec_surface.py) |
| N-000029 | tested | N_000029_zero_is_a_true_value (test_spec_surface.py) |
| N-000030 | tested | N_000030_projection_drops_null_results (test_spec_surface.py) |
| N-000031 | tested | N_000031_object_wildcard_on_non_object_is_null_resolution_of_CF_000027 (test_spec_surface.py) |
| N-000032 | tested | N_000032_N_000033_options_and_builtins_are_the_two_extension_points (test_spec_surface.py) |
| N-000033 | tested | N_000032_N_000033_options_and_builtins_are_the_two_extension_points (test_spec_surface.py) |
| N-000034 | tested | N_000034_N_000035_N_000036_N_000037_failure_kinds_and_carriers (test_spec_surface.py) |
| N-000035 | tested | N_000034_N_000035_N_000036_N_000037_failure_kinds_and_carriers (test_spec_surface.py) |
| N-000036 | tested | N_000034_N_000035_N_000036_N_000037_failure_kinds_and_carriers (test_spec_surface.py) |
| N-000037 | tested | N_000034_N_000035_N_000036_N_000037_failure_kinds_and_carriers (test_spec_surface.py) |
| N-000038 | implemented | __init__.py |
| N-000039 | implemented | __init__.py |
| N-000040 | implemented | __init__.py |
| N-000041 | tested | N_000003_N_000041_N_000059_missing_path_is_null_at_any_depth (test_search_fp01_fp05.py) |
| N-000042 | implemented | __init__.py |
| N-000043 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000044 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000045 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000046 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000047 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000048 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000049 | tested | N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups (test_spec_surface.py) |
| N-000050 | tested | N_000050_N_000051_N_000052_package_declares_no_runtime_dependencies (test_interface_and_failures.py); N_000050_N_000053_N_000054_N_000055_pure_python_flat_layout_from_source_tree (test_spec_surface.py) |
| N-000051 | tested | N_000050_N_000051_N_000052_package_declares_no_runtime_dependencies (test_interface_and_failures.py) |
| N-000052 | tested | N_000050_N_000051_N_000052_package_declares_no_runtime_dependencies (test_interface_and_failures.py) |
| N-000053 | tested | N_000050_N_000053_N_000054_N_000055_pure_python_flat_layout_from_source_tree (test_spec_surface.py) |
| N-000054 | tested | N_000050_N_000053_N_000054_N_000055_pure_python_flat_layout_from_source_tree (test_spec_surface.py) |
| N-000055 | tested | N_000050_N_000053_N_000054_N_000055_pure_python_flat_layout_from_source_tree (test_spec_surface.py) |
| N-000056 | tested | N_000056_N_000057_host_decimal_compares_as_number (test_interface_and_failures.py) |
| N-000057 | tested | N_000056_N_000057_host_decimal_compares_as_number (test_interface_and_failures.py) |
| N-000058 | tested | N_000058_host_value_selected_and_returned (test_interface_and_failures.py) |
| N-000059 | tested | N_000003_N_000041_N_000059_missing_path_is_null_at_any_depth (test_search_fp01_fp05.py); N_000059_N_000060_missing_path_is_success_null (test_interface_and_failures.py) |
| N-000060 | tested | N_000059_N_000060_missing_path_is_success_null (test_interface_and_failures.py) |
| N-000061 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000062 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000063 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000064 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000065 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000066 | tested | N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract (test_spec_surface.py) |
| N-000067 | tested | N_000067_N_000068_no_json_codec_or_command_line_surface (test_spec_surface.py) |
| N-000068 | tested | N_000067_N_000068_no_json_codec_or_command_line_surface (test_spec_surface.py) |
| N-000069 | tested | N_000069_N_000070_input_document_not_mutated (test_interface_and_failures.py) |
| N-000070 | tested | N_000069_N_000070_input_document_not_mutated (test_interface_and_failures.py) |
| N-000071 | not applicable | Non-goal: development tooling is excluded from the product; no runtime behavior to implement |
| N-000072 | not applicable | Non-goal: no packaging or internal caching is observable through the library entries |
| N-000073 | implemented | __init__.py |
| N-000074 | implemented | __init__.py |
| N-000075 | implemented | __init__.py |
| N-000076 | implemented | __init__.py |
| N-000077 | tested | N_000077_dotted_path_returns_nested_value (test_search_fp01_fp05.py) |
| N-000078 | tested | N_000079_N_000078_parsed_expression_searches_many_documents (test_search_fp01_fp05.py) |
| N-000079 | tested | N_000079_N_000078_parsed_expression_searches_many_documents (test_search_fp01_fp05.py) |
| N-000080 | tested | N_000080_N_000081_N_000342_one_shot_and_compiled_agree (test_search_fp01_fp05.py) |
| N-000081 | tested | N_000080_N_000081_N_000342_one_shot_and_compiled_agree (test_search_fp01_fp05.py) |
| N-000082 | implemented | __init__.py |
| N-000083 | tested | N_000083_identifier_on_array_is_null (test_search_fp01_fp05.py) |
| N-000084 | implemented | _nodes.py |
| N-000085 | tested | N_000085_identifier_on_non_object_is_null (test_search_fp01_fp05.py) |
| N-000086 | tested | N_000086_compiling_well_formed_expression_succeeds_even_if_search_is_null (test_search_fp01_fp05.py) |
| N-000087 | implemented | _parser.py |
| N-000088 | implemented | _parser.py |
| N-000089 | implemented | _parser.py |
| N-000090 | implemented | _parser.py |
| N-000091 | implemented | _parser.py |
| N-000092 | implemented | _parser.py |
| N-000093 | implemented | _parser.py |
| N-000094 | implemented | _parser.py |
| N-000095 | implemented | _parser.py |
| N-000096 | implemented | _lexer.py |
| N-000097 | implemented | _lexer.py |
| N-000098 | implemented | _lexer.py |
| N-000099 | implemented | _lexer.py |
| N-000100 | implemented | _lexer.py |
| N-000101 | implemented | _lexer.py |
| N-000102 | tested | N_000102_N_000103_N_000104_positions_differ_by_offset (test_interface_and_failures.py) |
| N-000103 | tested | N_000102_N_000103_N_000104_positions_differ_by_offset (test_interface_and_failures.py) |
| N-000104 | tested | N_000102_N_000103_N_000104_positions_differ_by_offset (test_interface_and_failures.py) |
| N-000105 | tested | N_000105_N_000106_refusals_yield_no_result_and_differ_from_null (test_interface_and_failures.py) |
| N-000106 | tested | N_000105_N_000106_refusals_yield_no_result_and_differ_from_null (test_interface_and_failures.py) |
| N-000107 | tested | N_000107_unquoted_identifier_selects_field (test_search_fp01_fp05.py) |
| N-000108 | implemented | _lexer.py, _parser.py |
| N-000109 | tested | N_000109_whitespace_between_tokens_is_ignored (test_search_fp01_fp05.py) |
| N-000110 | tested | N_000110_N_000111_N_000112_quoted_identifier_names_any_key (test_search_fp01_fp05.py) |
| N-000111 | tested | N_000110_N_000111_N_000112_quoted_identifier_names_any_key (test_search_fp01_fp05.py) |
| N-000112 | tested | N_000110_N_000111_N_000112_quoted_identifier_names_any_key (test_search_fp01_fp05.py) |
| N-000113 | tested | N_000113_quoted_identifier_decodes_json_escapes (test_search_fp01_fp05.py) |
| N-000114 | implemented | _lexer.py |
| N-000115 | tested | N_000115_N_000116_field_on_array_does_not_project (test_search_fp01_fp05.py) |
| N-000116 | tested | N_000115_N_000116_field_on_array_does_not_project (test_search_fp01_fp05.py) |
| N-000117 | tested | N_000117_dot_then_number_is_syntax (test_search_fp01_fp05.py) |
| N-000118 | implemented | _lexer.py, _parser.py |
| N-000119 | tested | N_000119_N_000121_N_000122_hyphen_is_token_level_syntax (test_search_fp01_fp05.py) |
| N-000120 | implemented | _lexer.py |
| N-000121 | tested | N_000119_N_000121_N_000122_hyphen_is_token_level_syntax (test_search_fp01_fp05.py) |
| N-000122 | tested | N_000119_N_000121_N_000122_hyphen_is_token_level_syntax (test_search_fp01_fp05.py) |
| N-000123 | tested | N_000123_dot_at_start_end_or_doubled_is_syntax (test_search_fp01_fp05.py) |
| N-000124 | tested | N_000124_unterminated_or_illegal_quoted_identifier_is_token_level (test_search_fp01_fp05.py) |
| N-000125 | implemented | _nodes.py |
| N-000126 | tested | N_000126_N_000127_N_000128_index_and_negative_index (test_search_fp01_fp05.py) |
| N-000127 | tested | N_000126_N_000127_N_000128_index_and_negative_index (test_search_fp01_fp05.py) |
| N-000128 | tested | N_000126_N_000127_N_000128_index_and_negative_index (test_search_fp01_fp05.py) |
| N-000129 | tested | N_000129_index_on_non_array_is_null (test_search_fp01_fp05.py) |
| N-000130 | tested | N_000130_N_000134_slice_positive_step_and_negative_bounds (test_spec_surface.py) |
| N-000131 | tested | N_000131_N_000132_N_000133_step_defaults_and_may_be_negative (test_search_fp01_fp05.py) |
| N-000132 | tested | N_000131_N_000132_N_000133_step_defaults_and_may_be_negative (test_search_fp01_fp05.py) |
| N-000133 | tested | N_000131_N_000132_N_000133_step_defaults_and_may_be_negative (test_search_fp01_fp05.py) |
| N-000134 | tested | N_000130_N_000134_slice_positive_step_and_negative_bounds (test_spec_surface.py) |
| N-000135 | tested | N_000135_N_000136_N_000137_positive_slice (test_search_fp01_fp05.py) |
| N-000136 | tested | N_000135_N_000136_N_000137_positive_slice (test_search_fp01_fp05.py) |
| N-000137 | tested | N_000135_N_000136_N_000137_positive_slice (test_search_fp01_fp05.py) |
| N-000138 | tested | N_000138_N_000139_N_000140_negative_step_slice (test_search_fp01_fp05.py) |
| N-000139 | tested | N_000138_N_000139_N_000140_negative_step_slice (test_search_fp01_fp05.py) |
| N-000140 | tested | N_000138_N_000139_N_000140_negative_step_slice (test_search_fp01_fp05.py) |
| N-000141 | tested | N_000141_slice_selecting_nothing_is_empty_array (test_search_fp01_fp05.py) |
| N-000142 | tested | N_000142_slice_on_non_array_is_null (test_search_fp01_fp05.py) |
| N-000143 | implemented | _nodes.py |
| N-000144 | implemented | _nodes.py |
| N-000145 | tested | N_000145_N_000146_N_000147_flatten_one_level (test_search_fp01_fp05.py) |
| N-000146 | tested | N_000145_N_000146_N_000147_flatten_one_level (test_search_fp01_fp05.py) |
| N-000147 | tested | N_000145_N_000146_N_000147_flatten_one_level (test_search_fp01_fp05.py) |
| N-000148 | tested | N_000148_N_000150_flatten_applies_to_whole_left_result (test_search_fp01_fp05.py) |
| N-000149 | tested | N_000149_flatten_of_non_array_is_null (test_search_fp01_fp05.py) |
| N-000150 | tested | N_000148_N_000150_flatten_applies_to_whole_left_result (test_search_fp01_fp05.py) |
| N-000151 | tested | N_000151_index_slice_and_flatten_apply_to_document_itself (test_spec_surface.py) |
| N-000152 | tested | N_000152_N_000154_zero_slice_step_refuses_at_compile (test_search_fp01_fp05.py) |
| N-000153 | implemented | _parser.py |
| N-000154 | tested | N_000152_N_000154_zero_slice_step_refuses_at_compile (test_search_fp01_fp05.py) |
| N-000155 | tested | N_000155_slice_with_four_parts_or_non_integer_is_syntax (test_search_fp01_fp05.py) |
| N-000156 | implemented | _parser.py |
| N-000157 | tested | N_000157_slice_of_non_array_resolution_of_CF_000007_is_null (test_spec_surface.py) |
| N-000158 | tested | N_000158_wildcards_in_one_expression (test_spec_surface.py) |
| N-000159 | tested | N_000159_N_000160_list_wildcard_projects_and_drops_nulls (test_search_fp01_fp05.py) |
| N-000160 | tested | N_000159_N_000160_list_wildcard_projects_and_drops_nulls (test_search_fp01_fp05.py) |
| N-000161 | tested | N_000161_list_wildcard_with_nothing_to_right_collects_non_null (test_search_fp01_fp05.py) |
| N-000162 | tested | N_000162_list_wildcard_on_non_array_is_null (test_search_fp01_fp05.py) |
| N-000163 | tested | N_000163_N_000164_object_wildcard_projects_values (test_search_fp01_fp05.py) |
| N-000164 | tested | N_000163_N_000164_object_wildcard_projects_values (test_search_fp01_fp05.py) |
| N-000165 | tested | N_000165_object_wildcard_on_non_object_is_null (test_search_fp01_fp05.py) |
| N-000166 | tested | N_000166_N_000167_inner_projection_gives_array_per_outer_element (test_search_fp01_fp05.py) |
| N-000167 | tested | N_000166_N_000167_inner_projection_gives_array_per_outer_element (test_search_fp01_fp05.py) |
| N-000168 | tested | N_000168_N_000169_N_000170_N_000172_filter_keeps_true_elements_in_order (test_search_fp01_fp05.py) |
| N-000169 | tested | N_000168_N_000169_N_000170_N_000172_filter_keeps_true_elements_in_order (test_search_fp01_fp05.py) |
| N-000170 | tested | N_000168_N_000169_N_000170_N_000172_filter_keeps_true_elements_in_order (test_search_fp01_fp05.py) |
| N-000171 | implemented | _nodes.py |
| N-000172 | tested | N_000168_N_000169_N_000170_N_000172_filter_keeps_true_elements_in_order (test_search_fp01_fp05.py) |
| N-000173 | tested | N_000173_filter_on_non_array_is_null (test_search_fp01_fp05.py) |
| N-000174 | tested | N_000174_N_000175_filter_truthiness_zero_is_true_null_is_false (test_search_fp01_fp05.py) |
| N-000175 | tested | N_000174_N_000175_filter_truthiness_zero_is_true_null_is_false (test_search_fp01_fp05.py) |
| N-000176 | tested | N_000176_N_000177_N_000178_N_000179_filter_predicate_forms (test_spec_surface.py) |
| N-000177 | tested | N_000176_N_000177_N_000178_N_000179_filter_predicate_forms (test_spec_surface.py) |
| N-000178 | tested | N_000176_N_000177_N_000178_N_000179_filter_predicate_forms (test_spec_surface.py) |
| N-000179 | tested | N_000176_N_000177_N_000178_N_000179_filter_predicate_forms (test_spec_surface.py) |
| N-000180 | tested | N_000180_N_000181_filter_equality_never_equates_zero_with_false (test_search_fp01_fp05.py) |
| N-000181 | tested | N_000180_N_000181_filter_equality_never_equates_zero_with_false (test_search_fp01_fp05.py) |
| N-000182 | implemented | _parser.py |
| N-000183 | tested | N_000183_N_000184_N_000185_projection_rhs_takes_later_tighter_steps (test_search_fp01_fp05.py) |
| N-000184 | tested | N_000183_N_000184_N_000185_projection_rhs_takes_later_tighter_steps (test_search_fp01_fp05.py) |
| N-000185 | tested | N_000183_N_000184_N_000185_projection_rhs_takes_later_tighter_steps (test_search_fp01_fp05.py) |
| N-000186 | implemented | _parser.py |
| N-000187 | implemented | _parser.py |
| N-000188 | implemented | _parser.py |
| N-000189 | implemented | _parser.py |
| N-000190 | implemented | _parser.py |
| N-000191 | implemented | _parser.py |
| N-000192 | implemented | _parser.py |
| N-000193 | implemented | _parser.py |
| N-000194 | implemented | _parser.py |
| N-000195 | tested | N_000195_N_000197_comparison_after_projection_compares_whole_array (test_search_fp01_fp05.py) |
| N-000196 | implemented | _parser.py |
| N-000197 | tested | N_000195_N_000197_comparison_after_projection_compares_whole_array (test_search_fp01_fp05.py) |
| N-000198 | implemented | _parser.py |
| N-000199 | implemented | _parser.py |
| N-000200 | tested | N_000200_N_000201_wildcard_followed_by_identifier_or_star_is_syntax (test_search_fp01_fp05.py) |
| N-000201 | tested | N_000200_N_000201_wildcard_followed_by_identifier_or_star_is_syntax (test_search_fp01_fp05.py) |
| N-000202 | tested | N_000202_filter_with_missing_predicate_does_not_succeed (test_search_fp01_fp05.py) |
| N-000203 | tested | N_000203_ill_formed_or_missing_filter_predicate_does_not_succeed (test_spec_surface.py) |
| N-000204 | tested | N_000204_projected_nulls_are_dropped (test_search_fp01_fp05.py) |
| N-000205 | implemented | _nodes.py |
| N-000206 | tested | N_000206_N_000207_multiselect_hash_stores_nulls (test_search_fp01_fp05.py) |
| N-000207 | tested | N_000206_N_000207_multiselect_hash_stores_nulls (test_search_fp01_fp05.py) |
| N-000208 | implemented | _nodes.py, _parser.py |
| N-000209 | implemented | _nodes.py, _parser.py |
| N-000210 | implemented | _nodes.py, _parser.py |
| N-000211 | tested | N_000211_multiselect_list_stores_nulls (test_search_fp01_fp05.py) |
| N-000212 | implemented | _nodes.py, _parser.py |
| N-000213 | tested | N_000213_N_000214_multiselect_as_projection_rhs_builds_per_element (test_search_fp01_fp05.py) |
| N-000214 | tested | N_000213_N_000214_multiselect_as_projection_rhs_builds_per_element (test_search_fp01_fp05.py) |
| N-000215 | implemented | _nodes.py, _parser.py |
| N-000216 | tested | N_000216_N_000217_multiselect_after_operand_only_as_projection_rhs (test_search_fp01_fp05.py) |
| N-000217 | tested | N_000216_N_000217_multiselect_after_operand_only_as_projection_rhs (test_search_fp01_fp05.py) |
| N-000218 | tested | N_000218_multiselect_on_null_current_value_is_null (test_search_fp01_fp05.py) |
| N-000219 | tested | N_000219_N_000222_pipe_passes_whole_left_result (test_search_fp01_fp05.py) |
| N-000220 | implemented | _parser.py |
| N-000221 | tested | N_000221_pipe_stops_projection (test_search_fp01_fp05.py) |
| N-000222 | tested | N_000219_N_000222_pipe_passes_whole_left_result (test_search_fp01_fp05.py) |
| N-000223 | implemented | _lexer.py, _nodes.py |
| N-000224 | tested | N_000224_N_000225_json_literal_is_value_regardless_of_document (test_search_fp01_fp05.py) |
| N-000225 | tested | N_000224_N_000225_json_literal_is_value_regardless_of_document (test_search_fp01_fp05.py) |
| N-000226 | tested | N_000226_json_literal_invalid_json_is_string_content (test_search_fp01_fp05.py) |
| N-000227 | tested | N_000227_N_000228_raw_string_has_no_json_escapes (test_search_fp01_fp05.py) |
| N-000228 | tested | N_000227_N_000228_raw_string_has_no_json_escapes (test_search_fp01_fp05.py) |
| N-000229 | tested | N_000229_raw_string_of_digits_is_string (test_search_fp01_fp05.py) |
| N-000230 | implemented | _lexer.py |
| N-000231 | tested | N_000231_N_000234_bare_expression_reference_is_non_null (test_search_fp01_fp05.py) |
| N-000232 | implemented | _parser.py, _values.py |
| N-000233 | implemented | _nodes.py, _parser.py, _values.py |
| N-000234 | tested | N_000231_N_000234_bare_expression_reference_is_non_null (test_search_fp01_fp05.py) |
| N-000235 | implemented | _nodes.py, _parser.py, _values.py |
| N-000236 | implemented | _parser.py, _values.py |
| N-000237 | tested | N_000237_unclosed_literals_are_token_level (test_search_fp01_fp05.py) |
| N-000238 | tested | N_000238_literal_after_dot_is_syntax (test_search_fp01_fp05.py) |
| N-000239 | tested | N_000239_raw_string_unicode_escape_is_decoded (test_search_fp01_fp05.py) |
| N-000240 | tested | N_000240_multiselect_missing_bracket_or_trailing_comma_does_not_succeed (test_search_fp01_fp05.py) |
| N-000241 | tested | N_000241_pipe_with_missing_side_does_not_succeed (test_search_fp01_fp05.py) |
| N-000242 | tested | N_000242_N_000243_equality_is_json_value_equality (test_logic_functions_options.py) |
| N-000243 | tested | N_000242_N_000243_equality_is_json_value_equality (test_logic_functions_options.py) |
| N-000244 | tested | N_000244_number_never_equals_boolean (test_logic_functions_options.py) |
| N-000245 | tested | N_000245_N_000246_ordering_numbers_and_strings (test_logic_functions_options.py) |
| N-000246 | tested | N_000245_N_000246_ordering_numbers_and_strings (test_logic_functions_options.py) |
| N-000247 | tested | N_000247_N_000248_or_returns_left_if_true_else_right (test_logic_functions_options.py) |
| N-000248 | tested | N_000247_N_000248_or_returns_left_if_true_else_right (test_logic_functions_options.py) |
| N-000249 | tested | N_000249_N_000250_and_returns_left_if_false_else_right (test_logic_functions_options.py) |
| N-000250 | tested | N_000249_N_000250_and_returns_left_if_false_else_right (test_logic_functions_options.py) |
| N-000251 | tested | N_000251_N_000252_not_uses_false_value_set (test_logic_functions_options.py) |
| N-000252 | tested | N_000251_N_000252_not_uses_false_value_set (test_logic_functions_options.py) |
| N-000253 | tested | N_000253_N_000257_binding_and_negated_paths (test_logic_functions_options.py) |
| N-000254 | implemented | _parser.py |
| N-000255 | implemented | _parser.py |
| N-000256 | implemented | _parser.py |
| N-000257 | tested | N_000253_N_000257_binding_and_negated_paths (test_logic_functions_options.py) |
| N-000258 | tested | N_000258_N_000259_filter_predicate_uses_same_operators (test_logic_functions_options.py) |
| N-000259 | tested | N_000258_N_000259_filter_predicate_uses_same_operators (test_logic_functions_options.py) |
| N-000260 | tested | N_000260_lone_equals_is_token_level (test_logic_functions_options.py) |
| N-000261 | tested | N_000261_lone_ampersand_or_missing_side_does_not_succeed (test_logic_functions_options.py) |
| N-000262 | tested | N_000262_N_000264_N_000266_checks_happen_at_evaluation_not_compile (test_logic_functions_options.py) |
| N-000263 | tested | N_000263_builtin_names_are_exactly_the_26_listed (test_logic_functions_options.py) |
| N-000264 | tested | N_000262_N_000264_N_000266_checks_happen_at_evaluation_not_compile (test_logic_functions_options.py) |
| N-000265 | implemented | _nodes.py |
| N-000266 | tested | N_000262_N_000264_N_000266_checks_happen_at_evaluation_not_compile (test_logic_functions_options.py) |
| N-000267 | implemented | _nodes.py |
| N-000268 | implemented | _nodes.py |
| N-000269 | tested | N_000269_abs (test_logic_functions_options.py) |
| N-000270 | tested | N_000270_N_000271_avg_and_empty (test_logic_functions_options.py) |
| N-000271 | tested | N_000270_N_000271_avg_and_empty (test_logic_functions_options.py) |
| N-000272 | tested | N_000272_N_000273_ceil_and_floor_are_integers (test_logic_functions_options.py) |
| N-000273 | tested | N_000272_N_000273_ceil_and_floor_are_integers (test_logic_functions_options.py) |
| N-000274 | tested | N_000274_N_000275_contains_array_and_string (test_logic_functions_options.py) |
| N-000275 | tested | N_000274_N_000275_contains_array_and_string (test_logic_functions_options.py) |
| N-000276 | tested | N_000276_starts_and_ends_with (test_logic_functions_options.py) |
| N-000277 | tested | N_000277_length_counts_characters_not_bytes (test_logic_functions_options.py) |
| N-000278 | tested | N_000278_reverse_array_and_string (test_logic_functions_options.py) |
| N-000279 | tested | N_000279_N_000280_join_and_empty_join (test_logic_functions_options.py) |
| N-000280 | tested | N_000279_N_000280_join_and_empty_join (test_logic_functions_options.py) |
| N-000281 | tested | N_000281_keys_and_values_in_iteration_order (test_logic_functions_options.py) |
| N-000282 | tested | N_000282_type_names (test_logic_functions_options.py) |
| N-000283 | tested | N_000283_to_array_wraps_non_arrays (test_logic_functions_options.py) |
| N-000284 | tested | N_000284_N_000285_to_string_compact_json_with_ascii_escapes (test_logic_functions_options.py) |
| N-000285 | tested | N_000284_N_000285_to_string_compact_json_with_ascii_escapes (test_logic_functions_options.py) |
| N-000286 | tested | N_000286_N_000287_to_number_integer_and_float_numerals (test_logic_functions_options.py) |
| N-000287 | tested | N_000286_N_000287_to_number_integer_and_float_numerals (test_logic_functions_options.py) |
| N-000288 | tested | N_000288_N_000289_to_number_anything_else_is_null (test_logic_functions_options.py) |
| N-000289 | tested | N_000288_N_000289_to_number_anything_else_is_null (test_logic_functions_options.py) |
| N-000290 | tested | N_000290_N_000291_N_000292_max_min_and_empty (test_logic_functions_options.py) |
| N-000291 | tested | N_000290_N_000291_N_000292_max_min_and_empty (test_logic_functions_options.py) |
| N-000292 | tested | N_000290_N_000291_N_000292_max_min_and_empty (test_logic_functions_options.py) |
| N-000293 | tested | N_000293_sort_numbers_and_strings (test_logic_functions_options.py) |
| N-000294 | tested | N_000294_sum (test_logic_functions_options.py) |
| N-000295 | tested | N_000295_N_000296_N_000297_merge_later_keys_win (test_logic_functions_options.py) |
| N-000296 | tested | N_000295_N_000296_N_000297_merge_later_keys_win (test_logic_functions_options.py) |
| N-000297 | tested | N_000295_N_000296_N_000297_merge_later_keys_win (test_logic_functions_options.py) |
| N-000298 | tested | N_000298_N_000299_N_000300_not_null_first_non_null (test_logic_functions_options.py) |
| N-000299 | tested | N_000298_N_000299_N_000300_not_null_first_non_null (test_logic_functions_options.py) |
| N-000300 | tested | N_000298_N_000299_N_000300_not_null_first_non_null (test_logic_functions_options.py) |
| N-000301 | tested | N_000301_N_000302_map_includes_nulls (test_logic_functions_options.py) |
| N-000302 | tested | N_000301_N_000302_map_includes_nulls (test_logic_functions_options.py) |
| N-000303 | tested | N_000303_N_000304_N_000305_sort_by_stable (test_logic_functions_options.py) |
| N-000304 | tested | N_000303_N_000304_N_000305_sort_by_stable (test_logic_functions_options.py) |
| N-000305 | tested | N_000303_N_000304_N_000305_sort_by_stable (test_logic_functions_options.py) |
| N-000306 | tested | N_000306_N_000307_N_000308_max_by_min_by_first_on_ties (test_logic_functions_options.py) |
| N-000307 | tested | N_000306_N_000307_N_000308_max_by_min_by_first_on_ties (test_logic_functions_options.py) |
| N-000308 | tested | N_000306_N_000307_N_000308_max_by_min_by_first_on_ties (test_logic_functions_options.py) |
| N-000309 | tested | N_000309_N_000310_function_as_projection_rhs_and_projection_as_argument (test_logic_functions_options.py) |
| N-000310 | tested | N_000309_N_000310_function_as_projection_rhs_and_projection_as_argument (test_logic_functions_options.py) |
| N-000311 | tested | N_000311_N_000312_N_000313_arity_is_checked (test_logic_functions_options.py) |
| N-000312 | tested | N_000311_N_000312_N_000313_arity_is_checked (test_logic_functions_options.py) |
| N-000313 | tested | N_000311_N_000312_N_000313_arity_is_checked (test_logic_functions_options.py) |
| N-000314 | tested | N_000314_N_000315_invalid_type_refusals (test_logic_functions_options.py) |
| N-000315 | tested | N_000314_N_000315_invalid_type_refusals (test_logic_functions_options.py) |
| N-000316 | implemented | functions.py |
| N-000317 | tested | N_000317_invalid_type_for_non_reference_argument (test_logic_functions_options.py) |
| N-000318 | implemented | _parser.py, functions.py |
| N-000319 | implemented | functions.py |
| N-000320 | implemented | functions.py |
| N-000321 | tested | N_000321_N_000322_quoted_identifier_cannot_be_function_name (test_logic_functions_options.py) |
| N-000322 | tested | N_000321_N_000322_quoted_identifier_cannot_be_function_name (test_logic_functions_options.py) |
| N-000323 | implemented | __init__.py, _values.py |
| N-000324 | implemented | __init__.py, _values.py |
| N-000325 | implemented | __init__.py, _values.py |
| N-000326 | implemented | __init__.py, _values.py |
| N-000327 | implemented | __init__.py, _values.py |
| N-000328 | tested | N_000328_N_000329_N_000332_mapping_type_applies_to_constructed_hash (test_logic_functions_options.py) |
| N-000329 | tested | N_000328_N_000329_N_000332_mapping_type_applies_to_constructed_hash (test_logic_functions_options.py) |
| N-000330 | tested | N_000330_constructed_hash_of_custom_type_is_object_for_selection (test_logic_functions_options.py) |
| N-000331 | implemented | _values.py |
| N-000332 | tested | N_000328_N_000329_N_000332_mapping_type_applies_to_constructed_hash (test_logic_functions_options.py) |
| N-000333 | tested | N_000333_other_mapping_types_are_accepted_where_objects_are_required (test_spec_surface.py) |
| N-000334 | implemented | _values.py |
| N-000335 | tested | N_000335_N_000336_custom_function_is_called_with_evaluated_args (test_logic_functions_options.py) |
| N-000336 | tested | N_000335_N_000336_custom_function_is_called_with_evaluated_args (test_logic_functions_options.py) |
| N-000337 | tested | N_000337_N_000345_N_000346_custom_function_arity_and_type_checks (test_logic_functions_options.py) |
| N-000338 | tested | N_000338_custom_function_may_return_falsy_values (test_logic_functions_options.py) |
| N-000339 | tested | N_000339_N_000340_builtins_available_on_every_provider (test_interface_and_failures.py); N_000339_N_000340_provider_extends_builtins_and_builtins_stay (test_logic_functions_options.py) |
| N-000340 | tested | N_000339_N_000340_builtins_available_on_every_provider (test_interface_and_failures.py); N_000339_N_000340_provider_extends_builtins_and_builtins_stay (test_logic_functions_options.py) |
| N-000341 | tested | N_000341_options_carry_mapping_type_and_provider_together (test_logic_functions_options.py) |
| N-000342 | tested | N_000080_N_000081_N_000342_one_shot_and_compiled_agree (test_search_fp01_fp05.py); N_000342_N_000343_compile_with_custom_name_succeeds_without_provider (test_logic_functions_options.py) |
| N-000343 | tested | N_000342_N_000343_compile_with_custom_name_succeeds_without_provider (test_logic_functions_options.py) |
| N-000344 | tested | N_000344_custom_name_without_provider_is_unknown (test_logic_functions_options.py) |
| N-000345 | tested | N_000337_N_000345_N_000346_custom_function_arity_and_type_checks (test_logic_functions_options.py) |
| N-000346 | tested | N_000337_N_000345_N_000346_custom_function_arity_and_type_checks (test_logic_functions_options.py) |
| N-000347 | implemented | _nodes.py, _values.py |
| N-000348 | implemented | _nodes.py |
| N-000349 | implemented | _nodes.py |
| N-000350 | tested | N_000350_custom_function_refuses_host_value_that_is_not_json (test_spec_surface.py) |
| N-000351 | implemented | pyproject.toml (`dependencies = []`), pathsel/ (pure Python, no compiled code); verified by inspection only |
| N-000352 | implemented | pyproject.toml `dependencies = []`; test_N_000050 checks the declaration |
| N-000353 | implemented | pyproject.toml `requires-python = ">=3.9"`; code avoids 3.10+ syntax; runs here on CPython 3.13 only |
| N-000354 | implemented | Pure Python with no OS-specific code paths; not executed on Linux x86_64 ARM, macOS or Windows from this environment |
| N-000355 | implemented | Profile `cpu_baseline`: pathsel/ package, pyproject.toml; no GPU or native code |
| N-000356 | implemented | No platform-specific code in pathsel/; only Linux was run here |
| N-000357 | implemented | Linux is the verified platform here (this environment) |
| N-000358 | implemented | pathsel/ at repository root (flat layout); conftest.py puts the root on sys.path for pytest |
| N-000359 | implemented | Evaluates in an ordinary CPython process; no subprocess or socket use |
| N-000360 | implemented | pyproject.toml `requires-python = ">=3.9"`, zero dependencies |
| N-000361 | implemented | pyproject.toml `dependencies = []` |
| N-000362 | implemented | Imports only the standard library (json, re, math, numbers, collections, contextvars) |
| N-000363 | implemented | No native compile step; pyproject.toml build-backend is setuptools with no extensions |
| N-000364 | implemented | Flat layout: pathsel/ at the project root; pyproject.toml `packages = ["pathsel"]` |
| N-000365 | implemented | Editable install or root on sys.path both work; conftest.py relies on the second |
| N-000366 | tested | N_000366_N_000367_N_000368_no_command_line_or_service_entry_points (test_spec_surface.py) |
| N-000367 | tested | N_000366_N_000367_N_000368_no_command_line_or_service_entry_points (test_spec_surface.py) |
| N-000368 | tested | N_000366_N_000367_N_000368_no_command_line_or_service_entry_points (test_spec_surface.py) |
| N-000369 | tested | N_000369_N_000370_N_000371_flat_package_name_and_import_has_no_side_effects (test_spec_surface.py) |
| N-000370 | tested | N_000369_N_000370_N_000371_flat_package_name_and_import_has_no_side_effects (test_spec_surface.py) |
| N-000371 | tested | N_000369_N_000370_N_000371_flat_package_name_and_import_has_no_side_effects (test_spec_surface.py) |
| N-000372 | tested | N_000372_N_000373_N_000374_root_names (test_spec_surface.py); N_000372_N_000373_root_exports_search_and_compile (test_interface_and_failures.py) |
| N-000373 | tested | N_000372_N_000373_N_000374_root_names (test_spec_surface.py); N_000372_N_000373_root_exports_search_and_compile (test_interface_and_failures.py) |
| N-000374 | tested | N_000372_N_000373_N_000374_root_names (test_spec_surface.py) |
| N-000375 | tested | N_000375_N_000376_N_000377_search_positional_arguments (test_interface_and_failures.py) |
| N-000376 | tested | N_000375_N_000376_N_000377_search_positional_arguments (test_interface_and_failures.py) |
| N-000377 | tested | N_000375_N_000376_N_000377_search_positional_arguments (test_interface_and_failures.py) |
| N-000378 | tested | N_000378_N_000379_N_000380_result_is_ordinary_python_data (test_interface_and_failures.py) |
| N-000379 | tested | N_000378_N_000379_N_000380_result_is_ordinary_python_data (test_interface_and_failures.py) |
| N-000380 | tested | N_000378_N_000379_N_000380_result_is_ordinary_python_data (test_interface_and_failures.py) |
| N-000381 | tested | N_000381_N_000382_search_returns_or_raises_never_both (test_spec_surface.py) |
| N-000382 | tested | N_000381_N_000382_search_returns_or_raises_never_both (test_spec_surface.py) |
| N-000383 | tested | N_000383_N_000384_N_000385_compile_returns_non_none_with_search (test_interface_and_failures.py) |
| N-000384 | tested | N_000383_N_000384_N_000385_compile_returns_non_none_with_search (test_interface_and_failures.py) |
| N-000385 | tested | N_000383_N_000384_N_000385_compile_returns_non_none_with_search (test_interface_and_failures.py) |
| N-000386 | implemented | __init__.py |
| N-000387 | implemented | __init__.py |
| N-000388 | implemented | __init__.py |
| N-000389 | tested | N_000389_N_000390_N_000391_N_000392_options_attributes (test_spec_surface.py) |
| N-000390 | tested | N_000389_N_000390_N_000391_N_000392_options_attributes (test_spec_surface.py) |
| N-000391 | tested | N_000389_N_000390_N_000391_N_000392_options_attributes (test_spec_surface.py) |
| N-000392 | tested | N_000389_N_000390_N_000391_N_000392_options_attributes (test_spec_surface.py) |
| N-000393 | tested | N_000393_N_000394_functions_module_names (test_interface_and_failures.py) |
| N-000394 | tested | N_000393_N_000394_functions_module_names (test_interface_and_failures.py) |
| N-000395 | tested | N_000395_Functions_takes_no_arguments (test_interface_and_failures.py) |
| N-000396 | tested | N_000396_N_000397_N_000399_provider_method_receives_provider_first (test_logic_functions_options.py) |
| N-000397 | tested | N_000396_N_000397_N_000399_provider_method_receives_provider_first (test_logic_functions_options.py) |
| N-000398 | implemented | functions.py |
| N-000399 | tested | N_000396_N_000397_N_000399_provider_method_receives_provider_first (test_logic_functions_options.py) |
| N-000400 | implemented | functions.py |
| N-000401 | tested | N_000401_N_000402_N_000403_N_000404_signature_decorator_contract (test_logic_functions_options.py) |
| N-000402 | tested | N_000401_N_000402_N_000403_N_000404_signature_decorator_contract (test_logic_functions_options.py) |
| N-000403 | tested | N_000401_N_000402_N_000403_N_000404_signature_decorator_contract (test_logic_functions_options.py) |
| N-000404 | tested | N_000401_N_000402_N_000403_N_000404_signature_decorator_contract (test_logic_functions_options.py) |
| N-000405 | tested | N_000405_every_refusal_is_a_value_error (test_interface_and_failures.py) |
| N-000406 | tested | N_000406_N_000407_N_000408_failure_type_names_are_implementer_choice (test_spec_surface.py) |
| N-000407 | tested | N_000406_N_000407_N_000408_failure_type_names_are_implementer_choice (test_spec_surface.py) |
| N-000408 | tested | N_000406_N_000407_N_000408_failure_type_names_are_implementer_choice (test_spec_surface.py) |
| N-000409 | tested | N_000409_empty_expression_type (test_interface_and_failures.py) |
| N-000410 | tested | N_000410_incomplete_expression_type_and_position (test_interface_and_failures.py) |
| N-000411 | tested | N_000411_grammar_syntax_type_is_exact_and_shared (test_interface_and_failures.py) |
| N-000412 | tested | N_000412_N_000413_N_000414_token_syntax_is_subclass_not_same_type (test_interface_and_failures.py) |
| N-000413 | tested | N_000412_N_000413_N_000414_token_syntax_is_subclass_not_same_type (test_interface_and_failures.py) |
| N-000414 | tested | N_000412_N_000413_N_000414_token_syntax_is_subclass_not_same_type (test_interface_and_failures.py) |
| N-000415 | tested | N_000415_zero_slice_step_is_not_syntax (test_interface_and_failures.py) |
| N-000416 | tested | N_000416_N_000417_N_000418_function_call_kinds_are_distinct (test_interface_and_failures.py) |
| N-000417 | tested | N_000416_N_000417_N_000418_function_call_kinds_are_distinct (test_interface_and_failures.py) |
| N-000418 | tested | N_000416_N_000417_N_000418_function_call_kinds_are_distinct (test_interface_and_failures.py) |
| N-000419 | tested | N_000419_unknown_arity_and_type_have_their_own_types (test_spec_surface.py) |
| N-000420 | tested | N_000420_no_other_kind_is_a_function_call_kind (test_interface_and_failures.py) |
| N-000421 | tested | N_000421_N_000422_position_is_int_within_length (test_interface_and_failures.py) |
| N-000422 | tested | N_000421_N_000422_position_is_int_within_length (test_interface_and_failures.py) |
| N-000423 | tested | N_000423_bare_expression_reference_search_is_non_none (test_interface_and_failures.py) |
