"""FP-06 (logic), FP-07 (built-in functions), FP-08 (options, custom functions)."""
import collections
import types

import pytest

import pathsel
from pathsel.functions import Functions, signature


def s(expr, data=None, options=None):
    return pathsel.search(expr, {} if data is None else data, options)


# ---- FP-06 -----------------------------------------------------------------

def test_N_000242_N_000243_equality_is_json_value_equality():
    assert s("`[1, {\"a\": [2]}]` == `[1, {\"a\": [2]}]`") is True
    assert s("`1` == `1.0`") is True
    assert s("`\"x\"` != `\"x\"`") is False


def test_N_000244_number_never_equals_boolean():
    assert s("`0` == `false`") is False
    assert s("`1` == `true`") is False


def test_N_000245_N_000246_ordering_numbers_and_strings():
    assert s("`2` < `10`") is True
    assert s("'a' < 'b'") is True
    assert s("'Z' < 'a'") is True  # code point order
    assert s("`2` >= `2`") is True


def test_N_000247_N_000248_or_returns_left_if_true_else_right():
    assert s("`0` || `5`") == 0
    assert s("n || 'b'", {"n": None}) == "b"


def test_N_000249_N_000250_and_returns_left_if_false_else_right():
    assert s("`0` && `5`") == 5
    assert s("n && 'b'", {"n": None}) is None


def test_N_000251_N_000252_not_uses_false_value_set():
    assert s("!`0`") is False
    assert s("!`0.0`") is False
    assert s("!''") is True
    assert s("!`[]`") is True
    assert s("!`{}`") is True


def test_N_000253_N_000257_binding_and_negated_paths():
    data = {"a": [True], "b": {"c": 1}}
    assert s("!a[0]", data) is False          # index binds to the operand
    assert s("!(a[0] && b.c == `1`)", data) is False
    assert s("!a.x", data) is None           # dot applies to the result of !


def test_N_000258_N_000259_filter_predicate_uses_same_operators():
    data = {"xs": [{"v": 1}, {"v": 2}]}
    assert s("xs[?v == `2` || v == `1`]", data) == [{"v": 1}, {"v": 2}]


def test_N_000260_lone_equals_is_token_level():
    with pytest.raises(pathsel.TokenSyntaxError):
        s("a = b")


def test_N_000261_lone_ampersand_or_missing_side_does_not_succeed():
    with pytest.raises(pathsel.PathSelError):
        s("a && ")
    with pytest.raises(pathsel.PathSelError):
        s("a & b")


# ---- FP-07: built-in set ---------------------------------------------------

BUILTIN_NAMES = [
    "abs", "avg", "ceil", "contains", "ends_with", "floor", "join", "keys",
    "length", "map", "max", "max_by", "merge", "min", "min_by", "not_null",
    "reverse", "sort", "sort_by", "starts_with", "sum", "to_array", "to_number",
    "to_string", "type", "values",
]


def test_N_000263_builtin_names_are_exactly_the_26_listed():
    from pathsel.functions import BUILTIN_IMPLS
    assert sorted(BUILTIN_IMPLS) == sorted(BUILTIN_NAMES)
    assert len(BUILTIN_NAMES) == 26


def test_N_000269_abs():
    assert s("abs(`-3.5`)") == 3.5


def test_N_000270_N_000271_avg_and_empty():
    assert s("avg(`[1, 2, 3, 4]`)") == 2.5
    assert s("avg(`[]`)") is None


def test_N_000272_N_000273_ceil_and_floor_are_integers():
    assert s("ceil(`1.2`)") == 2 and isinstance(s("ceil(`1.2`)"), int)
    assert s("floor(`-1.2`)") == -2


def test_N_000274_N_000275_contains_array_and_string():
    assert s("contains(`[1, 2]`, `2`)") is True
    assert s("contains('abc', 'bc')") is True
    assert s("contains(`[\"a\"]`, 'a')") is True
    with pytest.raises(pathsel.InvalidTypeError):
        s("contains('abc', `1`)")


def test_N_000276_starts_and_ends_with():
    assert s("starts_with('hello', 'he')") is True
    assert s("ends_with('hello', 'lo')") is True
    assert s("ends_with('hello', 'he')") is False


def test_N_000277_length_counts_characters_not_bytes():
    assert s("length('héllo')") == 5
    assert s("length(`[1, 2]`)") == 2
    assert s("length(`{\"a\": 1}`)") == 1


def test_N_000278_reverse_array_and_string():
    assert s("reverse('abc')") == "cba"
    assert s("reverse(`[1, 2, 3]`)") == [3, 2, 1]


def test_N_000279_N_000280_join_and_empty_join():
    assert s("join(', ', `[\"a\", \"b\"]`)") == "a, b"
    assert s("join(',', `[]`)") == ""


def test_N_000281_keys_and_values_in_iteration_order():
    data = {"o": {"z": 1, "a": 2}}
    assert s("keys(o)", data) == ["z", "a"]
    assert s("values(o)", data) == [1, 2]


def test_N_000282_type_names():
    assert s("type(`1`)") == "number"
    assert s("type('x')") == "string"
    assert s("type(`true`)") == "boolean"
    assert s("type(`[]`)") == "array"
    assert s("type(`{}`)") == "object"
    assert s("type(zzz)") == "null"


def test_N_000283_to_array_wraps_non_arrays():
    assert s("to_array(`1`)") == [1]
    assert s("to_array(`[1]`)") == [1]
    assert s("to_array(zzz)") == [None]


def test_N_000284_N_000285_to_string_compact_json_with_ascii_escapes():
    assert s("to_string(`{\"a\": [1, 2]}`)") == '{"a":[1,2]}'
    assert s("to_string(`\"é\"`)") == "é"  # a string is returned unchanged
    assert s("to_string(`[\"é\"]`)") == '["\\u00e9"]'
    assert s("to_string(`1.5`)") == "1.5"


def test_N_000286_N_000287_to_number_integer_and_float_numerals():
    assert s("to_number('42')") == 42
    assert s("to_number('4.5')") == 4.5
    assert s("to_number('1e3')") == 1000.0
    assert s("to_number(`7`)") == 7


def test_N_000288_N_000289_to_number_anything_else_is_null():
    assert s("to_number('abc')") is None
    assert s("to_number(`true`)") is None
    assert s("to_number(`null`)") is None
    assert s("to_number(`[1]`)") is None


def test_N_000290_N_000291_N_000292_max_min_and_empty():
    assert s("max(`[1, 5, 3]`)") == 5
    assert s("min(`[\"b\", \"a\"]`)") == "a"
    assert s("max(`[]`)") is None


def test_N_000293_sort_numbers_and_strings():
    assert s("sort(`[3, 1, 2]`)") == [1, 2, 3]
    assert s("sort(`[\"b\", \"B\", \"a\"]`)") == ["B", "a", "b"]


def test_N_000294_sum():
    assert s("sum(`[1, 2, 3.5]`)") == 6.5


def test_N_000295_N_000296_N_000297_merge_later_keys_win():
    assert s("merge(`{\"a\": 1, \"b\": 2}`, `{\"b\": 3}`)") == {"a": 1, "b": 3}


def test_N_000298_N_000299_N_000300_not_null_first_non_null():
    assert s("not_null(zzz, `0`, `1`)") == 0
    assert s("not_null(zzz, zzz)") is None
    assert s("not_null(zzz, '')") == ""  # an empty string is not null
    assert s("not_null(zzz, `[]`)") == []  # an empty array is not null


def test_N_000301_N_000302_map_includes_nulls():
    data = {"xs": [{"a": 1}, {"b": 2}]}
    assert s("map(&a, xs)", data) == [1, None]


def test_N_000303_N_000304_N_000305_sort_by_stable():
    data = {"xs": [{"k": 2, "n": "a"}, {"k": 1, "n": "b"}, {"k": 2, "n": "c"}]}
    assert [e["n"] for e in s("sort_by(xs, &k)", data)] == ["b", "a", "c"]


def test_N_000306_N_000307_N_000308_max_by_min_by_first_on_ties():
    data = {"xs": [{"k": 2, "n": "a"}, {"k": 2, "n": "b"}, {"k": 1, "n": "c"}]}
    assert s("max_by(xs, &k).n", data) == "a"
    assert s("min_by(xs, &k).n", data) == "c"
    assert s("max_by(`[]`, &k)") is None


def test_N_000309_N_000310_function_as_projection_rhs_and_projection_as_argument():
    data = {"xs": [[1, 2], [3]]}
    assert s("xs[*].length(@)", data) == [2, 1]
    assert s("length(xs[*])", data) == 2


def test_N_000311_N_000312_N_000313_arity_is_checked():
    with pytest.raises(pathsel.InvalidArityError):
        s("abs()")
    with pytest.raises(pathsel.InvalidArityError):
        s("contains(`[1]`)")
    with pytest.raises(pathsel.InvalidArityError):
        s("not_null()")


def test_N_000314_N_000315_invalid_type_refusals():
    with pytest.raises(pathsel.InvalidTypeError):
        s("abs(`true`)")
    with pytest.raises(pathsel.InvalidTypeError):
        s("max(`[1, 'a']`)")
    with pytest.raises(pathsel.InvalidTypeError):
        s("sum(zzz)")
    with pytest.raises(pathsel.InvalidTypeError):
        s("map(zzz, `[1]`)")  # a non-reference where a reference is required
    with pytest.raises(pathsel.InvalidTypeError):
        s("sort_by(`[{\"k\": 1}, {\"k\": \"a\"}]`, &k)")


def test_N_000317_invalid_type_for_non_reference_argument():
    with pytest.raises(pathsel.InvalidTypeError):
        s("max_by(`[1]`, `2`)")


def test_N_000321_N_000322_quoted_identifier_cannot_be_function_name():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s('"abs"(`1`)')


def test_N_000262_N_000264_N_000266_checks_happen_at_evaluation_not_compile():
    c = pathsel.compile("nosuch(@)")
    with pytest.raises(pathsel.UnknownFunctionError):
        c.search(1)
    c2 = pathsel.compile("abs()")
    with pytest.raises(pathsel.InvalidArityError):
        c2.search(1)


# ---- FP-08 -----------------------------------------------------------------

def test_N_000328_N_000329_N_000332_mapping_type_applies_to_constructed_hash():
    opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
    out = pathsel.search("{a: `1`, b: `2`}", {}, opts)
    assert isinstance(out, collections.OrderedDict)
    assert list(out) == ["a", "b"]


def test_N_000330_constructed_hash_of_custom_type_is_object_for_selection():
    class Bag(object):
        def __init__(self):
            self._d = {}

        def __setitem__(self, k, v):
            self._d[k] = v

        def __getitem__(self, k):
            return self._d[k]

        def keys(self):
            return self._d.keys()

    opts = types.SimpleNamespace(dict_cls=Bag, custom_functions=None)
    assert pathsel.search("{a: `5`}.a", {}, opts) == 5
    assert pathsel.search("keys({a: `5`})", {}, opts) == ["a"]


def test_N_000335_N_000336_custom_function_is_called_with_evaluated_args():
    class Prov(Functions):
        @signature({"types": ["number"]}, {"types": ["number"]})
        def _func_add(self, a, b):
            return a + b

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("add(`1`, `2`)", None, opts) == 3


def test_N_000337_N_000345_N_000346_custom_function_arity_and_type_checks():
    class Prov(Functions):
        @signature({"types": ["string"]})
        def _func_shout(self, s):
            return s.upper()

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("shout('hi')", None, opts) == "HI"
    with pytest.raises(pathsel.InvalidArityError):
        pathsel.search("shout('a', 'b')", None, opts)
    with pytest.raises(pathsel.InvalidTypeError):
        pathsel.search("shout(`1`)", None, opts)


def test_N_000338_custom_function_may_return_falsy_values():
    class Prov(Functions):
        @signature()
        def _func_zero(self):
            return 0

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("zero()", None, opts) == 0


def test_N_000339_N_000340_provider_extends_builtins_and_builtins_stay():
    class Prov(Functions):
        @signature({"types": ["number"]})
        def _func_double(self, n):
            return n * 2

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("double(`4`)", None, opts) == 8
    assert pathsel.search("abs(`-2`)", None, opts) == 2


def test_N_000344_custom_name_without_provider_is_unknown():
    class Prov(Functions):
        @signature()
        def _func_hello(self):
            return "hi"

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    with pytest.raises(pathsel.UnknownFunctionError):
        pathsel.search("hello()", None, None)
    assert pathsel.search("hello()", None, opts) == "hi"


def test_N_000341_options_carry_mapping_type_and_provider_together():
    class Prov(Functions):
        @signature()
        def _func_one(self):
            return {"x": 1}

    opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=Prov())
    out = pathsel.search("{a: one()}", {}, opts)
    assert isinstance(out["a"], dict)
    assert isinstance(out, collections.OrderedDict)


def test_N_000342_N_000343_compile_with_custom_name_succeeds_without_provider():
    c = pathsel.compile("hello()")
    with pytest.raises(pathsel.UnknownFunctionError):
        c.search(None)


def test_N_000396_N_000397_N_000399_provider_method_receives_provider_first():
    class Prov(Functions):
        def __init__(self):
            self.base = 10

        @signature({"types": ["number"]})
        def _func_plus_base(self, n):
            return self.base + n

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("plus_base(`5`)", None, opts) == 15


def test_N_000401_N_000402_N_000403_N_000404_signature_decorator_contract():
    from pathsel.functions import signature as sig
    with pytest.raises(TypeError):
        sig({"types": ["blob"]})

    def impl(self, x):
        return x

    decorated = sig({"types": ["number", "string"]})(impl)
    assert callable(decorated)
    assert decorated._pathsel_signature == (("number", "string"),)
