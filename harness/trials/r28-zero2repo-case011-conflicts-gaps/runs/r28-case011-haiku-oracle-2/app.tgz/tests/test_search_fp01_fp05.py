"""Behavior of search/compile for FP-01 through FP-05.

Test names carry the spec node id(s) they check (see spec/CHECKLIST.md).
"""
import pytest

import pathsel

DOC = {
    "a": {"b": [1, 2, 3], "c-d": "x", "e.f": "dotted"},
    "people": [
        {"name": "ann", "age": 3},
        {"name": "bob", "age": 9},
        {"name": None, "age": 7},
    ],
    "n": 0,
    "f": False,
    "s": "",
    "empty": [],
}


def s(expr, data=DOC, options=None):
    return pathsel.search(expr, data, options)


# ---- FP-01: entries, missing is null, compile reuse -----------------------

def test_N_000077_dotted_path_returns_nested_value():
    assert s("a.b") == [1, 2, 3]


def test_N_000003_N_000041_N_000059_missing_path_is_null_at_any_depth():
    assert s("a.zzz") is None
    assert s("zzz.yyy.xxx") is None
    assert s("a.b.c") is None


def test_N_000079_N_000078_parsed_expression_searches_many_documents():
    c = pathsel.compile("people[*].name")
    assert c.search({"people": [{"name": "x"}]}) == ["x"]
    assert c.search({"people": [{"name": "y"}, {"name": "z"}]}) == ["y", "z"]


def test_N_000080_N_000081_N_000342_one_shot_and_compiled_agree():
    expr = "people[?age > `5`].name"
    assert s(expr) == pathsel.compile(expr).search(DOC)


def test_N_000086_compiling_well_formed_expression_succeeds_even_if_search_is_null():
    c = pathsel.compile("zzz[0].q")
    assert c.search(DOC) is None


def test_N_000083_identifier_on_array_is_null():
    assert s("a.b.c") is None
    assert s("people.name") is None


def test_N_000085_identifier_on_non_object_is_null():
    assert s("n.x") is None


# ---- FP-02: identifiers and subexpressions ---------------------------------

def test_N_000107_unquoted_identifier_selects_field():
    assert s("n") == 0


def test_N_000109_whitespace_between_tokens_is_ignored():
    assert s("  a  .  b  [ 0 ]  ") == 1


def test_N_000110_N_000111_N_000112_quoted_identifier_names_any_key():
    assert s('a."c-d"') == "x"
    assert s('a."e.f"') == "dotted"  # a dot inside quotes is one key


def test_N_000113_quoted_identifier_decodes_json_escapes():
    data = {"a b": 1, 'q"t': 2, "é": 3, "1x": 4}
    assert s('"a b"', data) == 1
    assert s('"q\\"t"', data) == 2
    assert s('"\\u00e9"', data) == 3
    assert s('"1x"', data) == 4


def test_N_000115_N_000116_field_on_array_does_not_project():
    assert s("a.b.x") is None


def test_N_000117_dot_then_number_is_syntax():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.1")
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.-1")


def test_N_000119_N_000121_N_000122_hyphen_is_token_level_syntax():
    with pytest.raises(pathsel.TokenSyntaxError):
        s("a-b")


def test_N_000123_dot_at_start_end_or_doubled_is_syntax():
    for bad in [".a", "a.", "a..b"]:
        with pytest.raises(pathsel.ExpressionSyntaxError):
            s(bad)


def test_N_000124_unterminated_or_illegal_quoted_identifier_is_token_level():
    with pytest.raises(pathsel.TokenSyntaxError):
        s('"abc')
    with pytest.raises(pathsel.TokenSyntaxError):
        s('"a\\qb"')


# ---- FP-03: index, slice, flatten -----------------------------------------

def test_N_000126_N_000127_N_000128_index_and_negative_index():
    assert s("a.b[0]") == 1
    assert s("a.b[-1]") == 3
    assert s("a.b[3]") is None
    assert s("a.b[-4]") is None


def test_N_000129_index_on_non_array_is_null():
    assert s("a[0]") is None
    assert s("s[0]") is None


def test_N_000135_N_000136_N_000137_positive_slice():
    assert s("a.b[0:2]") == [1, 2]
    assert s("a.b[:2]") == [1, 2]
    assert s("a.b[1:]") == [2, 3]
    assert s("a.b[-2:]") == [2, 3]
    assert s("a.b[5:9]") == []


def test_N_000138_N_000139_N_000140_negative_step_slice():
    assert s("a.b[::-1]") == [3, 2, 1]
    assert s("a.b[2:0:-1]") == [3, 2]


def test_N_000131_N_000132_N_000133_step_defaults_and_may_be_negative():
    assert s("a.b[::2]") == [1, 3]
    assert s("a.b[::-2]") == [3, 1]


def test_N_000141_slice_selecting_nothing_is_empty_array():
    assert s("a.b[2:1]") == []


def test_N_000142_slice_on_non_array_is_null():
    assert s("a[0:1]") is None


def test_N_000145_N_000146_N_000147_flatten_one_level():
    data = {"x": [[1, 2], 3, [[4]]]}
    assert s("x[]", data) == [1, 2, 3, [4]]


def test_N_000149_flatten_of_non_array_is_null():
    assert s("n[]") is None


def test_N_000148_N_000150_flatten_applies_to_whole_left_result():
    data = {"x": [{"y": [1, 2]}, {"y": [3]}]}
    assert s("x[].y", data) == [[1, 2], [3]]          # flatten of objects splices nothing
    assert s("x[*].y[]", data) == [1, 2, 3]            # flatten of a preceding projection


def test_N_000152_N_000154_zero_slice_step_refuses_at_compile():
    with pytest.raises(pathsel.ZeroSliceStepError):
        pathsel.compile("a.b[::0]")


def test_N_000155_slice_with_four_parts_or_non_integer_is_syntax():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.b[1:2:3:4]")
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.b[x:2]")


# ---- FP-04: wildcard and filter projections -------------------------------

def test_N_000159_N_000160_list_wildcard_projects_and_drops_nulls():
    assert s("people[*].name") == ["ann", "bob"]


def test_N_000161_list_wildcard_with_nothing_to_right_collects_non_null():
    assert s("a.b[*]") == [1, 2, 3]


def test_N_000162_list_wildcard_on_non_array_is_null():
    assert s("n[*]") is None
    assert s("zzz[*]") is None


def test_N_000163_N_000164_object_wildcard_projects_values():
    data = {"o": {"k1": {"v": 1}, "k2": {"v": 2}}}
    assert s("o.*.v", data) == [1, 2]
    assert s("o.*", data) == [{"v": 1}, {"v": 2}]


def test_N_000165_object_wildcard_on_non_object_is_null():
    assert s("a.b.*") is None


def test_N_000166_N_000167_inner_projection_gives_array_per_outer_element():
    data = {"x": [{"y": [1, 2]}, {"y": [3]}]}
    assert s("x[*].y[*]", data) == [[1, 2], [3]]


def test_N_000168_N_000169_N_000170_N_000172_filter_keeps_true_elements_in_order():
    assert s("people[?age > `5`].name") == ["bob"]
    assert s("people[?age > `2`].age") == [3, 9, 7]


def test_N_000173_filter_on_non_array_is_null():
    assert s("n[?@]") is None


def test_N_000174_N_000175_filter_truthiness_zero_is_true_null_is_false():
    data = {"xs": [{"v": 0}, {"v": None}, {"v": "a"}]}
    assert s("xs[?v].v", data) == [0, "a"]


def test_N_000180_N_000181_filter_equality_never_equates_zero_with_false():
    data = {"xs": [{"v": 0}, {"v": False}, {"v": 1}]}
    assert s("xs[?v == `false`]", data) == [{"v": False}]
    assert s("xs[?v == `0`]", data) == [{"v": 0}]


def test_N_000200_N_000201_wildcard_followed_by_identifier_or_star_is_syntax():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("people[*]name")
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("people[*]*")


def test_N_000202_filter_with_missing_predicate_does_not_succeed():
    with pytest.raises(pathsel.PathSelError):
        s("people[?]")


def test_N_000204_projected_nulls_are_dropped():
    data = {"xs": [{"a": None}, {"a": 1}]}
    assert s("xs[*].a", data) == [1]


def test_N_000195_N_000197_comparison_after_projection_compares_whole_array():
    assert s("people[*].age == `[3, 9, 7]`") is True


def test_N_000183_N_000184_N_000185_projection_rhs_takes_later_tighter_steps():
    assert s("people[*].age") == [3, 9, 7]
    assert s("people[*].name | length(@)") == 2


# ---- FP-05: constructors, pipe, current value, literals -------------------

def test_N_000206_N_000207_multiselect_hash_stores_nulls():
    assert s("{x: people[0].name, y: zzz}") == {"x": "ann", "y": None}


def test_N_000211_multiselect_list_stores_nulls():
    assert s("[n, zzz, a.b[0]]") == [0, None, 1]


def test_N_000218_multiselect_on_null_current_value_is_null():
    assert s("zzz.[a, n]") is None
    assert s("zzz.{x: n}") is None
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("zzz{x: n}")  # a multiselect hash directly after an operand is not allowed


def test_N_000213_N_000214_multiselect_as_projection_rhs_builds_per_element():
    assert s("people[*].[name, age]") == [["ann", 3], ["bob", 9], [None, 7]]


def test_N_000219_N_000222_pipe_passes_whole_left_result():
    assert s("people[*].name | [0]") == "ann"
    assert s("a.b | length(@)") == 3


def test_N_000221_pipe_stops_projection():
    assert s("people[*].age | length(@)") == 3


def test_N_000224_N_000225_json_literal_is_value_regardless_of_document():
    assert s("`{\"k\": [1, 2]}`.k[1]") == 2
    assert s("`  42 `") == 42


def test_N_000226_json_literal_invalid_json_is_string_content():
    assert s("`foo`") == "foo"


def test_N_000227_N_000228_raw_string_has_no_json_escapes():
    assert s(r"'a\nb'") == "a\\nb"
    assert s(r"'it\'s'") == "it's"
    assert s("'  1 2 '") == "  1 2 "


def test_N_000229_raw_string_of_digits_is_string():
    assert s("'42'") == "42"


def test_N_000239_raw_string_unicode_escape_is_decoded():
    assert s(r"'\u00e9'") == "é"


def test_N_000237_unclosed_literals_are_token_level():
    with pytest.raises(pathsel.TokenSyntaxError):
        s("`abc")
    with pytest.raises(pathsel.TokenSyntaxError):
        s("'abc")


def test_N_000238_literal_after_dot_is_syntax():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.`1`")


def test_N_000240_multiselect_missing_bracket_or_trailing_comma_does_not_succeed():
    for bad in ["[a, b", "{x: a", "[a, ]", "{x: a,}", "{x}", "{x: }"]:
        with pytest.raises(pathsel.PathSelError):
            s(bad)


def test_N_000241_pipe_with_missing_side_does_not_succeed():
    with pytest.raises(pathsel.PathSelError):
        s("a |")
    with pytest.raises(pathsel.PathSelError):
        s("| a")


def test_N_000231_N_000234_bare_expression_reference_is_non_null():
    assert s("&a.b") is not None


def test_N_000216_N_000217_multiselect_after_operand_only_as_projection_rhs():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a.b[0][1, 2]")
    assert s("people[*][name]") == [["ann"], ["bob"], [None]]  # first step of a projection rhs
