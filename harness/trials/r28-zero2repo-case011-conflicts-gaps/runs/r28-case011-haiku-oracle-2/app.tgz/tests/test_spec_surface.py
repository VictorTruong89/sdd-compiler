"""Named checks for spec ids not covered by the feature-point test files."""
import os
import types

import pytest

import pathsel
from pathsel.functions import Functions, signature

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def s(expr, data=None, options=None):
    return pathsel.search(expr, {} if data is None else data, options)


def test_N_000001_N_000002_N_000004_N_000005_search_and_compile_entries():
    assert s("a.b", {"a": {"b": 2}}) == 2
    assert pathsel.compile("a.b").search({"a": {"b": 3}}) == 3


def test_N_000006_N_000007_N_000008_N_000009_compiled_and_one_shot_return_equal_values():
    expr = "a[*].b | length(@)"
    doc = {"a": [{"b": 1}, {"b": 2}]}
    assert pathsel.compile(expr).search(doc) == s(expr, doc)


def test_N_000010_N_000011_N_000012_N_000013_feature_points_are_ordered_entries():
    # Scope statements. Each feature point is reachable through search/compile.
    assert s("a", {"a": 1}) == 1               # FP-01 entry
    assert s("a[0]", {"a": [9]}) == 9          # FP-03 is available after FP-01


def test_N_000014_N_000015_N_000016_N_000017_N_000018_terminology_entries():
    parsed = pathsel.compile("x")              # parsed expression
    assert parsed.search({"x": 5}) == 5        # searched against a document
    assert s("x", {"x": None}) is None         # null is success, not a refusal


def test_N_000019_N_000020_current_value_changes_under_pipe_projection_and_args():
    doc = {"a": [{"b": 1}, {"b": 2}]}
    assert s("a | [1].b", doc) == 2            # pipe
    assert s("a[*].b", doc) == [1, 2]          # projection
    assert s("length(a[*].b)", doc) == 2       # function argument


def test_N_000021_N_000022_null_is_missing_or_wrong_kind_not_failure():
    assert s("a.b", {"a": "x"}) is None
    assert s("a[0]", {"a": {}}) is None


def test_N_000025_boolean_is_not_a_number():
    with pytest.raises(pathsel.InvalidTypeError):
        s("abs(`true`)")


def test_N_000026_string_length_counts_characters_resolution_of_CF_000035():
    # Conflict resolved to the FP-07 definition: characters, not UTF-8 bytes.
    assert s("length('é')") == 1


def test_N_000027_boolean_is_not_one_or_zero():
    assert s("`true` == `1`") is False
    assert s("`false` == `0`") is False


def test_N_000028_bare_expression_reference_is_not_null_resolution_of_CF_000056():
    assert s("&a", {"a": 1}) is not None


def test_N_000029_zero_is_a_true_value():
    assert s("`0` && 'yes'") == "yes"
    assert s("n[?@]", {"n": [0, 0]}) == [0, 0]


def test_N_000030_projection_drops_null_results():
    assert s("xs[*].a", {"xs": [{"a": None}, {"a": 4}]}) == [4]


def test_N_000031_object_wildcard_on_non_object_is_null_resolution_of_CF_000027():
    assert s("a.*", {"a": [1, 2]}) is None


def test_N_000032_N_000033_options_and_builtins_are_the_two_extension_points():
    class Prov(Functions):
        @signature()
        def _func_one(self):
            return 1

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert s("one()", {}, opts) == 1
    assert s("abs(`-1`)") == 1


def test_N_000034_N_000035_N_000036_N_000037_failure_kinds_and_carriers():
    kinds = set()
    for expr in ["", "a.", "a = b", "abs()", "nosuch()", "a[::0]"]:
        try:
            s(expr)
        except ValueError as exc:
            kinds.add(type(exc))
    assert len(kinds) == 6


def test_N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_N_000049_surface_groups():
    doc = {"a": {"b": [1, 2, 3], "c": [{"d": 1}]}}
    assert s("a.b", doc) == [1, 2, 3]                          # FP-02 selection
    assert s("a.b[-1]", doc) == 3                              # FP-03 index
    assert s("a.c[*].d", doc) == [1]                           # FP-04 wildcard
    assert s("{x: a.b[0]}", doc) == {"x": 1}                   # FP-05 constructor
    assert s("a.b[0] == `1` && a.b[1] == `2`", doc) is True    # FP-06 logic
    assert s("max(a.b)", doc) == 3                             # FP-07 function


def test_N_000050_N_000053_N_000054_N_000055_pure_python_flat_layout_from_source_tree():
    assert os.path.isfile(os.path.join(ROOT, "pathsel", "__init__.py"))
    assert os.path.abspath(pathsel.__file__).startswith(ROOT)


def test_N_000061_N_000062_N_000063_N_000064_N_000065_N_000066_failure_contract():
    with pytest.raises(pathsel.PathSelError) as info:
        s("a..b")
    assert isinstance(info.value, ValueError)
    assert isinstance(info.value.lex_position, int)


def test_N_000067_N_000068_no_json_codec_or_command_line_surface():
    assert not hasattr(pathsel, "loads") and not hasattr(pathsel, "dumps")
    assert not os.path.exists(os.path.join(ROOT, "pathsel", "__main__.py"))


def test_N_000130_N_000134_slice_positive_step_and_negative_bounds():
    doc = {"a": [0, 1, 2, 3, 4]}
    assert s("a[::2]", doc) == [0, 2, 4]
    assert s("a[-2:-1]", doc) == [3]
    assert s("a[-100:2]", doc) == [0, 1]


def test_N_000151_index_slice_and_flatten_apply_to_document_itself():
    assert s("[0]", [7, 8]) == 7
    assert s("[1:]", [7, 8]) == [8]
    assert s("[]", [[1], 2]) == [1, 2]


def test_N_000157_slice_of_non_array_resolution_of_CF_000007_is_null():
    assert s("n[0:1]", {"n": 5}) is None


def test_N_000158_wildcards_in_one_expression():
    doc = {"o": {"k": {"v": [1, 2]}}}
    assert s("o.*.v[*]", doc) == [[1, 2]]


def test_N_000176_N_000177_N_000178_N_000179_filter_predicate_forms():
    doc = {"xs": [{"a": 1, "b": 1}, {"a": 2, "b": 3}, {"a": None, "b": 0}]}
    assert s("xs[?a].a", doc) == [1, 2]                     # bare field
    assert s("xs[?a == b].a", doc) == [1]                   # two paths
    assert s("xs[?a == `2` || b == `1`].a", doc) == [1, 2]  # logic


def test_N_000203_ill_formed_or_missing_filter_predicate_does_not_succeed():
    with pytest.raises(pathsel.PathSelError):
        s("xs[?a ==]", {"xs": []})


def test_N_000333_other_mapping_types_are_accepted_where_objects_are_required():
    class Bag(dict):
        pass

    opts = types.SimpleNamespace(dict_cls=Bag, custom_functions=None)
    assert s("keys({a: `1`})", {}, opts) == ["a"]
    assert s("merge({a: `1`}, {b: `2`})", {}, opts) == {"a": 1, "b": 2}


def test_N_000350_custom_function_refuses_host_value_that_is_not_json():
    import decimal

    class Prov(Functions):
        @signature({"types": ["number"]})
        def _func_twice(self, n):
            return n * 2

    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    with pytest.raises(pathsel.InvalidTypeError):
        pathsel.search("twice(a)", {"a": decimal.Decimal("1")}, opts)


def test_N_000366_N_000367_N_000368_no_command_line_or_service_entry_points():
    assert not os.path.exists(os.path.join(ROOT, "pathsel", "__main__.py"))
    assert pathsel.search("a", {"a": 1}) == 1  # returns, does not exit the process


def test_N_000369_N_000370_N_000371_flat_package_name_and_import_has_no_side_effects():
    import pathsel.functions  # noqa: F401  (importing performs no I/O by design)
    assert os.path.isdir(os.path.join(ROOT, "pathsel"))


def test_N_000372_N_000373_N_000374_root_names():
    assert callable(pathsel.search) and callable(pathsel.compile)


def test_N_000381_N_000382_search_returns_or_raises_never_both():
    assert pathsel.search("a", {"a": 0}) == 0
    with pytest.raises(ValueError):
        pathsel.search("", {})


def test_N_000389_N_000390_N_000391_N_000392_options_attributes():
    class Prov(Functions):
        pass

    opts = types.SimpleNamespace(dict_cls=dict, custom_functions=Prov())
    assert s("{a: `1`}", {}, opts) == {"a": 1}


def test_N_000406_N_000407_N_000408_failure_type_names_are_implementer_choice():
    with pytest.raises(pathsel.ExpressionSyntaxError):
        s("a..b")


def test_N_000419_unknown_arity_and_type_have_their_own_types():
    with pytest.raises(pathsel.UnknownFunctionError):
        s("zz()", {})
    with pytest.raises(pathsel.InvalidArityError):
        s("abs(`1`, `2`)", {})
    with pytest.raises(pathsel.InvalidTypeError):
        s("abs('x')", {})
