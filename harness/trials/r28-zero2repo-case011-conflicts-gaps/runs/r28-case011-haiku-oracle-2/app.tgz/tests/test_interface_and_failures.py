"""Interface contract, failure carriers, and data-model constraints."""
import copy
import decimal

import pytest

import pathsel
from pathsel.functions import Functions, signature


def kind_of(expr, data=None):
    try:
        pathsel.search(expr, {} if data is None else data)
    except ValueError as exc:
        return type(exc)
    return None


# ---- Interface contract ----------------------------------------------------

def test_N_000372_N_000373_root_exports_search_and_compile():
    assert callable(pathsel.search)
    assert callable(pathsel.compile)


def test_N_000375_N_000376_N_000377_search_positional_arguments():
    assert pathsel.search("a", {"a": 1}, None) == 1
    assert pathsel.search("a", {"a": 1}) == 1


def test_N_000383_N_000384_N_000385_compile_returns_non_none_with_search():
    parsed = pathsel.compile("a")
    assert parsed is not None
    assert parsed.search({"a": 2}) == 2
    assert parsed.search({"a": 2}, None) == 2


def test_N_000393_N_000394_functions_module_names():
    import pathsel.functions as fmod
    assert isinstance(fmod.Functions, type)
    assert callable(fmod.signature)


def test_N_000395_Functions_takes_no_arguments():
    Functions()


def test_N_000423_bare_expression_reference_search_is_non_none():
    assert pathsel.search("&a", {"a": 1}) is not None


def test_N_000378_N_000379_N_000380_result_is_ordinary_python_data():
    out = pathsel.search("{a: `1`, b: [`2`]}", {})
    assert type(out) is dict
    assert type(out["b"]) is list


# ---- Failure carriers ------------------------------------------------------

def test_N_000405_every_refusal_is_a_value_error():
    for expr in ["", "  ", "a.", "a = b", "abs()", "nosuch()", "a[::0]"]:
        with pytest.raises(ValueError):
            pathsel.search(expr, {})


def test_N_000409_empty_expression_type():
    assert kind_of("") is pathsel.EmptyExpressionError
    assert kind_of("") is kind_of("")


def test_N_000410_incomplete_expression_type_and_position():
    with pytest.raises(pathsel.IncompleteExpressionError) as info:
        pathsel.search("a.b[", {})
    assert isinstance(info.value.lex_position, int)
    assert 0 <= info.value.lex_position <= len("a.b[")
    assert kind_of("  ") is pathsel.IncompleteExpressionError


def test_N_000411_grammar_syntax_type_is_exact_and_shared():
    first = kind_of("a..b")
    second = kind_of("a[*]x")
    assert first is pathsel.ExpressionSyntaxError
    assert second is pathsel.ExpressionSyntaxError


def test_N_000412_N_000413_N_000414_token_syntax_is_subclass_not_same_type():
    tok = kind_of("a-b")
    assert tok is not pathsel.ExpressionSyntaxError
    assert issubclass(tok, pathsel.ExpressionSyntaxError)
    assert not issubclass(tok, pathsel.EmptyExpressionError)
    assert not issubclass(tok, pathsel.IncompleteExpressionError)


def test_N_000415_zero_slice_step_is_not_syntax():
    kind = kind_of("a[::0]")
    assert kind is pathsel.ZeroSliceStepError
    assert not issubclass(kind, pathsel.ExpressionSyntaxError)


def test_N_000416_N_000417_N_000418_function_call_kinds_are_distinct():
    unknown = kind_of("nosuch(@)", 1)
    arity = kind_of("abs()", 1)
    invalid = kind_of("abs('x')", 1)
    assert unknown is pathsel.UnknownFunctionError
    assert arity is pathsel.InvalidArityError
    assert invalid is pathsel.InvalidTypeError
    assert len({unknown, arity, invalid}) == 3


def test_N_000420_no_other_kind_is_a_function_call_kind():
    for expr in ["", "a.", "a-b", "a[::0]"]:
        k = kind_of(expr)
        assert not issubclass(k, (pathsel.UnknownFunctionError,
                                  pathsel.InvalidArityError,
                                  pathsel.InvalidTypeError))


def test_N_000421_N_000422_position_is_int_within_length():
    text = "a.b c"
    with pytest.raises(pathsel.ExpressionSyntaxError) as info:
        pathsel.search(text, {})
    assert isinstance(info.value.lex_position, int)
    assert 0 <= info.value.lex_position <= len(text)


def test_N_000102_N_000103_N_000104_positions_differ_by_offset():
    with pytest.raises(pathsel.ExpressionSyntaxError) as a:
        pathsel.search("a..b", {})
    with pytest.raises(pathsel.ExpressionSyntaxError) as b:
        pathsel.search("a]]", {})
    assert a.value.lex_position != b.value.lex_position


def test_N_000105_N_000106_refusals_yield_no_result_and_differ_from_null():
    assert pathsel.search("zzz", {}) is None
    with pytest.raises(pathsel.PathSelError):
        pathsel.search("a.", {})


# ---- Data model ------------------------------------------------------------

def test_N_000056_N_000057_host_decimal_compares_as_number():
    assert pathsel.search("a > `1`", {"a": decimal.Decimal("2.5")}) is True
    assert pathsel.search("a == `2.5`", {"a": decimal.Decimal("2.5")}) is True


def test_N_000058_host_value_selected_and_returned():
    marker = object()
    assert pathsel.search("a", {"a": marker}) is marker


def test_N_000059_N_000060_missing_path_is_success_null():
    assert pathsel.search("nope", {}) is None


def test_N_000069_N_000070_input_document_not_mutated():
    doc = {"xs": [1, [2, 3]], "o": {"k": [4]}}
    before = copy.deepcopy(doc)
    pathsel.search("xs[]", doc)
    pathsel.search("{a: xs, b: o.k}", doc)
    pathsel.search("merge(o, o)", doc)
    pathsel.search("to_array(xs)", doc)
    assert doc == before


def test_N_000050_N_000051_N_000052_package_declares_no_runtime_dependencies():
    import os
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(root, "pyproject.toml")) as fh:
        text = fh.read()
    assert "dependencies = []" in text or "dependencies" not in text


def test_N_000339_N_000340_builtins_available_on_every_provider():
    class Prov(Functions):
        @signature()
        def _func_hi(self):
            return "hi"

    import types
    opts = types.SimpleNamespace(dict_cls=None, custom_functions=Prov())
    assert pathsel.search("length('ab')", {}, opts) == 2
