# Keeps the repository root on sys.path so `import pathsel` works under pytest
# without an install step (flat layout; spec: Interface Contract > Layout).
