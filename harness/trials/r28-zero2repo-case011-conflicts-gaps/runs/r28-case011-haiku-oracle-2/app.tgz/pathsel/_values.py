"""Value model helpers: classification, truthiness, equality, comparison.

Spec: Terminology (Null, Object, Array, Number, String, Boolean, False value),
FP-06 (equality, ordering, logic), Non-functional constraints (data model).
"""
import numbers
from contextvars import ContextVar

_BOOL = bool


def is_array(v):
    # spec: Array = sequence (JSON array). Tuples are accepted as sequences.
    return isinstance(v, (list, tuple))


# spec: N-000058, N-000328, N-000329, N-000330, N-000331
def is_object(v):
    # spec: Object = mapping. Any mapping qualifies, including the instance
    # type given by evaluation options (dict_cls), which may be a plain class
    # that is only filled by item assignment, so duck typing is used.
    if v is None or isinstance(v, (str, bytes, list, tuple)) or isinstance(v, _BOOL):
        return False
    return hasattr(v, "keys") and hasattr(v, "__getitem__")


# spec: N-000024, N-000056, N-000245, N-000251
def is_number(v):
    # spec: Number is an integer or floating-point value; a boolean is not a
    # number; host decimal values participate as numbers (FP-06, N-000245).
    return isinstance(v, numbers.Number) and not isinstance(v, (_BOOL, complex))


# spec: N-000058, N-000314, N-000347
def is_json_number(v):
    # Function arguments that require a JSON number refuse host values such
    # as Decimal (spec: Non-functional constraints, N-000058).
    return isinstance(v, (int, float)) and not isinstance(v, _BOOL)


def is_true(v):
    """True value: anything except the false values (spec: Terminology)."""
    return not is_false(v)


# spec: N-000019, N-000020, N-000021, N-000022, N-000252
def is_false(v):
    # False value set: false, null, empty string, empty array, empty object.
    # The numbers 0 and 0.0 are NOT false values.
    if v is None or v is False:
        return True
    if isinstance(v, str):
        return v == ""
    if is_array(v):
        return len(v) == 0
    if is_object(v):
        return len(v.keys()) == 0
    return False


# spec: N-000242, N-000243, N-000244
def json_equal(a, b):
    """JSON value equality (spec: FP-06). A number is never equal to a boolean."""
    if isinstance(a, _BOOL) or isinstance(b, _BOOL):
        return isinstance(a, _BOOL) and isinstance(b, _BOOL) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        ka = list(a.keys())
        kb = list(b.keys())
        if len(ka) != len(kb):
            return False
        for k in ka:
            if k not in b or not json_equal(a[k], b[k]):
                return False
        return True
    if is_array(a) or is_array(b) or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


# spec: N-000245, N-000246
def ordered(op, a, b):
    """Ordering comparison. Numbers compare numerically, strings by code point.

    Any other pairing yields null (spec: FP-06 does not define it; see NOTES.md).
    """
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        if op == "<":
            return a < b
        if op == "<=":
            return a <= b
        if op == ">":
            return a > b
        return a >= b
    return None


# spec: N-000323, N-000324, N-000325, N-000326, N-000327, N-000332, N-000334
class Context(object):
    """Per-search settings from the evaluation options (spec: FP-08)."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    def new_object(self):
        if self.dict_cls is not None:
            return self.dict_cls()
        return {}


_CURRENT_CONTEXT = ContextVar("pathsel_context", default=None)


def current_context():
    return _CURRENT_CONTEXT.get()


def set_current_context(ctx):
    return _CURRENT_CONTEXT.set(ctx)


def reset_current_context(token):
    _CURRENT_CONTEXT.reset(token)


# spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423
class ExpressionReference(object):
    """Deferred subexpression written with a leading ampersand (spec: FP-05).

    Searching a bare reference returns this object (spec: Interface Contract,
    N-000423: a non-None value); built-in functions apply it to elements.
    """

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def evaluate(self, value):
        return self.node.evaluate(value, self.ctx)

    def __repr__(self):
        return "<pathsel expression reference>"
