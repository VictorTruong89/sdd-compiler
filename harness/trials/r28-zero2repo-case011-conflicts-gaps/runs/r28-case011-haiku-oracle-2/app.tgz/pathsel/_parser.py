"""Parser: expression text -> expression tree.

A Pratt parser. Binding powers follow the spec's loosest-to-tightest order:
pipe (1) < || (2) < && (3) < comparators (5) < ! operand (45) and the dot
(40) < index and other bracket steps (55). Projection right-hand sides use the
rank of their form: flatten 9, list wildcard / slice / object wildcard 20,
filter 21, dot-form object wildcard 40 (spec: FP-04, "Reach of a projection").

Failure kinds (spec: FP-01, Failure carriers):
  - empty text                         -> EmptyExpressionError
  - text that ends where more is needed -> IncompleteExpressionError
  - other malformed text               -> ExpressionSyntaxError
  - malformed token                    -> TokenSyntaxError
  - slice step 0                       -> ZeroSliceStepError (raised at compile time)
"""
from ._lexer import next_token
from ._nodes import (
    IDENTITY, And, Compare, Expref, Field, FuncCall, Index, Literal, MultiHash,
    MultiList, Not, Or, Pipe, Projection,
)
from .errors import (
    EmptyExpressionError, ExpressionSyntaxError, IncompleteExpressionError,
    ZeroSliceStepError,
)

# spec: N-000219, N-000220, N-000221, N-000222, N-000253, N-000254, N-000255, N-000256, N-000257, N-000258, N-000259, N-000260, N-000261
_BP = {
    "|": 1,
    "||": 2,
    "&&": 3,
    "==": 5, "!=": 5, "<": 5, "<=": 5, ">": 5, ">=": 5,
    ".": 40,
}
_COMPARATORS = frozenset(["==", "!=", "<", "<=", ">", ">="])
_FLATTEN_RANK = 9
_LIST_RANK = 20
_FILTER_RANK = 21
_DOT_RANK = 40
_NOT_BP = 45


class _Parser(object):
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.buf = []

    # ----- token stream -------------------------------------------------
    def peek(self, k=0):
        while len(self.buf) <= k:
            tok, self.pos = next_token(self.text, self.pos)
            self.buf.append(tok)
        return self.buf[k]

    def advance(self):
        tok = self.peek()
        del self.buf[0]
        return tok

    # spec: N-000090, N-000091, N-000092, N-000093, N-000094, N-000095, N-000421
    def fail(self, tok):
        """Refuse at tok: end of text is incomplete, anything else is a syntax failure."""
        if tok.kind == "eof":
            raise IncompleteExpressionError(tok.pos)
        raise ExpressionSyntaxError(tok.pos)

    def expect(self, kind):
        tok = self.peek()
        if tok.kind != kind:
            self.fail(tok)
        return self.advance()

    # ----- binding powers -----------------------------------------------
    def led_bp(self, tok):
        if tok.kind == "[":
            nxt = self.peek(1)
            if nxt.kind == "]":
                return _FLATTEN_RANK
            if nxt.kind == "?":
                return _FILTER_RANK
            if nxt.kind in ("number", ":", "*", "eof"):
                return 55
            return 0  # multiselect after an operand: left over, so a syntax failure
        return _BP.get(tok.kind, 0)

    # ----- Pratt loop ----------------------------------------------------
    def expr(self, bp):
        left = self.nud()
        while True:
            tok = self.peek()
            if self.led_bp(tok) <= bp:
                break
            left = self.led(tok, left)
        return left

    def nud(self):
        tok = self.peek()
        k = tok.kind
        if k == "eof":
            raise IncompleteExpressionError(tok.pos)
        if k == "name":
            self.advance()
            if self.peek().kind == "(":
                return self.funcall(IDENTITY, tok.value)
            return Field(IDENTITY, tok.value)
        if k == "quoted":
            self.advance()
            if self.peek().kind == "(":
                raise ExpressionSyntaxError(self.peek().pos)
            return Field(IDENTITY, tok.value)
        if k == "literal":
            self.advance()
            return Literal(tok.value)
        if k == "*":
            self.advance()
            return Projection(IDENTITY, "object", None, self.projection_rhs(_LIST_RANK))
        if k == "@":
            self.advance()
            return IDENTITY
        # spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236
        if k == "&":
            self.advance()
            return Expref(self.expr(0))
        if k == "(":
            self.advance()
            inner = self.expr(0)
            self.expect(")")
            return inner
        if k == "[":
            return self.bracket(IDENTITY, nud=True)
        if k == "{":
            self.advance()
            return self.multihash(IDENTITY)
        # spec: N-000251, N-000252, N-000253, N-000257
        if k == "!":
            self.advance()
            return Not(self.expr(_NOT_BP))
        raise ExpressionSyntaxError(tok.pos)

    def led(self, tok, left):
        k = tok.kind
        if k == ".":
            self.advance()
            return self.dot(left, _DOT_RANK)
        if k == "[":
            return self.bracket(left, nud=False)
        if k == "|":
            self.advance()
            return Pipe(left, self.expr(1))
        if k == "||":
            self.advance()
            return Or(left, self.expr(2))
        if k == "&&":
            self.advance()
            return And(left, self.expr(3))
        if k in _COMPARATORS:
            self.advance()
            return Compare(k, left, self.expr(5))
        raise ExpressionSyntaxError(tok.pos)  # pragma: no cover - led_bp gates this

    # ----- steps ---------------------------------------------------------
    # spec: N-000108, N-000117, N-000118, N-000123, N-000238, N-000241
    def dot(self, base, bp):
        """Parse the step after a dot (the dot is already consumed); loop on tighter steps."""
        tok = self.peek()
        k = tok.kind
        if k == "name":
            self.advance()
            if self.peek().kind == "(":
                node = self.funcall(base, tok.value)
            else:
                node = Field(base, tok.value)
        elif k == "quoted":
            self.advance()
            if self.peek().kind == "(":
                raise ExpressionSyntaxError(self.peek().pos)
            node = Field(base, tok.value)
        elif k == "*":
            self.advance()
            node = Projection(base, "object", None, self.projection_rhs(_DOT_RANK))
        elif k == "[":
            nxt = self.peek(1)
            if nxt.kind == "eof":
                raise IncompleteExpressionError(nxt.pos)
            if nxt.kind in ("number", ":", "*", "]", "?"):
                raise ExpressionSyntaxError(nxt.pos)
            self.advance()
            node = self.multilist(base)
        elif k == "{":
            self.advance()
            node = self.multihash(base)
        else:
            # Includes end of text: a dot must be followed by a step (spec: N-000094).
            raise ExpressionSyntaxError(tok.pos)
        while self.led_bp(self.peek()) > bp:
            node = self.led(self.peek(), node)
        return node

    def bracket(self, base, nud):
        """Parse a bracket form starting at '[' (not yet consumed)."""
        open_tok = self.advance()
        nxt = self.peek()
        k = nxt.kind
        if k == "eof":
            raise IncompleteExpressionError(nxt.pos)
        if k == "]":
            self.advance()
            return Projection(base, "flatten", None, self.projection_rhs(_FLATTEN_RANK))
        if k == "*":
            self.advance()
            self.expect("]")
            return Projection(base, "list", None, self.projection_rhs(_LIST_RANK))
        if k == "?":
            self.advance()
            pred = self.expr(0)
            self.expect("]")
            return Projection(base, "filter", pred, self.projection_rhs(_FILTER_RANK))
        if k in ("number", ":"):
            return self.index_or_slice(base)
        if nud:
            return self.multilist(base)
        raise ExpressionSyntaxError(open_tok.pos)  # pragma: no cover - led_bp gates this

    # spec: N-000126, N-000127, N-000128, N-000135, N-000136, N-000137, N-000155, N-000156
    def index_or_slice(self, base):
        first = self.opt_int()
        tok = self.peek()
        if tok.kind == "]":
            self.advance()
            return Index(base, first)
        if tok.kind != ":":
            self.fail(tok)
        parts = [first]
        colons = 0
        while self.peek().kind == ":":
            if colons == 2:
                raise ExpressionSyntaxError(self.peek().pos)
            self.advance()
            colons += 1
            parts.append(self.opt_int())
        self.expect("]")
        start = parts[0]
        stop = parts[1]
        step = parts[2] if len(parts) == 3 else None
        # spec: N-000152, N-000153, N-000154
        if step == 0:
            raise ZeroSliceStepError()
        return Projection(base, "slice", (start, stop, step), self.projection_rhs(_LIST_RANK))

    def opt_int(self):
        tok = self.peek()
        if tok.kind == "number":
            self.advance()
            return tok.value
        if tok.kind in (":", "]"):
            return None
        self.fail(tok)

    # spec: N-000181, N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000194, N-000195, N-000196, N-000197, N-000198, N-000199
    def projection_rhs(self, bp):
        """Right-hand side of a projection form whose rank is bp (spec: FP-04).

        The step directly after the form begins the right-hand side when it is
        a dot step, a bracket step (index, slice, wildcard, multiselect, filter),
        but not a flatten. Later steps join only when they rank tighter than bp.
        Anything else leaves the right-hand side empty (identity); a token that
        cannot follow the form is then left over and refused by the caller.
        """
        tok = self.peek()
        if tok.kind == ".":
            self.advance()
            return self.dot(IDENTITY, bp)
        if tok.kind == "[" and self.peek(1).kind != "]":
            return self.expr(bp)
        return IDENTITY

    # spec: N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218, N-000240
    def multilist(self, base):
        """Multiselect list items; the opening '[' is already consumed."""
        items = []
        while True:
            items.append(self.expr(0))
            tok = self.peek()
            if tok.kind == ",":
                self.advance()
                continue
            if tok.kind == "]":
                self.advance()
                return MultiList(base, items)
            self.fail(tok)

    # spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000240
    def multihash(self, base):
        """Multiselect hash pairs; the opening '{' is already consumed."""
        pairs = []
        while True:
            tok = self.peek()
            if tok.kind in ("name", "quoted"):
                self.advance()
                key = tok.value
            else:
                self.fail(tok)
            self.expect(":")
            pairs.append((key, self.expr(0)))
            tok = self.peek()
            if tok.kind == ",":
                self.advance()
                continue
            if tok.kind == "}":
                self.advance()
                return MultiHash(base, pairs)
            self.fail(tok)

    # spec: N-000262, N-000318, N-000321, N-000322
    def funcall(self, base, name):
        """Argument list of a call; the name is consumed, the '(' is next."""
        self.expect("(")
        args = []
        if self.peek().kind == ")":
            self.advance()
            return FuncCall(base, name, args)
        while True:
            args.append(self.expr(0))
            tok = self.peek()
            if tok.kind == ",":
                self.advance()
                continue
            if tok.kind == ")":
                self.advance()
                return FuncCall(base, name, args)
            self.fail(tok)


# spec: N-000087, N-000088, N-000089, N-000102, N-000103, N-000104
def parse(text):
    """Parse expression text into a tree; raises a refusal kind on failure."""
    if text == "":
        raise EmptyExpressionError(0)
    parser = _Parser(text)
    node = parser.expr(0)
    tok = parser.peek()
    if tok.kind != "eof":
        raise ExpressionSyntaxError(tok.pos)
    return node
