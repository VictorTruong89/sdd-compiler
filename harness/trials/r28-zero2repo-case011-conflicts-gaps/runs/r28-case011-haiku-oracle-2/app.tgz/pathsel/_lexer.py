"""Tokenizer for the PathSel expression language.

Tokens are produced on demand (left to right), so a token-level failure is
reported only if the parser actually reaches the bad text. Spec: FP-01
(token-level failures), FP-02 (identifiers, quoted identifiers), FP-05
(literals), FP-06 (operators).
"""
import json
import re

from .errors import TokenSyntaxError

_WS = frozenset(" \t\n\r")
_NAME_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_NAME_CHARS = _NAME_START | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_TWO_CHAR = frozenset(["||", "&&", "==", "!=", "<=", ">="])
_ONE_CHAR = frozenset(".*[]?:,{}()@&|!<>")
_UNICODE_RUN = re.compile(r"(?:\\u[0-9A-Fa-f]{4})+")


class Token(object):
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind    # 'name', 'quoted', 'number', 'literal', 'eof', or the punctuation text
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.kind, self.value, self.pos)


def _token_error(pos, what):
    return TokenSyntaxError(pos, "%s at offset %d" % (what, pos))


def _decode_raw(text):
    # spec: FP-05 raw strings: "\uXXXX" escapes are decoded to their characters.
    return _UNICODE_RUN.sub(lambda m: json.loads('"' + m.group(0) + '"'), text)


def next_token(text, i):
    """Return (token, index_after_token) for the token starting at or after i."""
    n = len(text)
    # spec: N-000109
    while i < n and text[i] in _WS:
        i += 1
    if i >= n:
        return Token("eof", None, n), n
    c = text[i]

    # spec: N-000107, N-000108
    if c in _NAME_START:
        j = i + 1
        while j < n and text[j] in _NAME_CHARS:
            j += 1
        return Token("name", text[i:j], i), j

    # spec: N-000117, N-000118, N-000119, N-000120, N-000121, N-000122
    if c == "-" or c in _DIGITS:
        if c == "-" and not (i + 1 < n and text[i + 1] in _DIGITS):
            raise _token_error(i, "lone hyphen")
        j = i + 1
        while j < n and text[j] in _DIGITS:
            j += 1
        return Token("number", int(text[i:j]), i), j

    # spec: N-000110, N-000111, N-000112, N-000113, N-000114, N-000124
    if c == '"':
        j = i + 1
        while True:
            if j >= n:
                raise _token_error(i, "unterminated quoted identifier")
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == '"':
                break
            j += 1
        try:
            value = json.loads(text[i:j + 1])
        except ValueError:
            raise _token_error(i, "invalid quoted identifier")
        return Token("quoted", value, i), j + 1

    # spec: N-000223, N-000224, N-000225, N-000226, N-000237
    if c == "`":
        j = text.find("`", i + 1)
        if j < 0:
            raise _token_error(i, "unterminated JSON literal")
        raw = text[i + 1:j]
        try:
            value = json.loads(raw)
        except ValueError:
            try:
                value = json.loads('"' + raw.lstrip(" \t\n\r") + '"')
            except ValueError:
                raise _token_error(i, "invalid JSON literal")
        return Token("literal", value, i), j + 1

    # spec: N-000227, N-000228, N-000229, N-000230, N-000239
    if c == "'":
        buf = []
        j = i + 1
        while True:
            if j >= n:
                raise _token_error(i, "unterminated raw string literal")
            ch = text[j]
            if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                buf.append("'")
                j += 2
            elif ch == "'":
                break
            else:
                buf.append(ch)
                j += 1
        return Token("literal", _decode_raw("".join(buf)), i), j + 1

    two = text[i:i + 2]
    if two in _TWO_CHAR:
        return Token(two, two, i), i + 2
    if c in _ONE_CHAR:
        return Token(c, c, i), i + 1
    # spec: N-000260
    if c == "=":
        raise _token_error(i, "lone '='")
    # spec: N-000096, N-000097, N-000098, N-000099, N-000100, N-000101
    raise _token_error(i, "unexpected character %r" % c)
