"""Refusal kinds for pathsel.

Every refusal is a ValueError. The kind of a refusal is carried by the exact
type of the raised exception (spec: Interface Contract > Failure carriers).

    empty expression          -> EmptyExpressionError          # spec: N-000409
    incomplete expression     -> IncompleteExpressionError     # spec: N-000410
    syntax, grammar-level     -> ExpressionSyntaxError        # spec: N-000411
    syntax, token-level       -> TokenSyntaxError (subclass)  # spec: N-000412
    zero slice step           -> ZeroSliceStepError           # spec: N-000415
    unknown function          -> UnknownFunctionError         # spec: N-000416
    invalid arity             -> InvalidArityError            # spec: N-000417
    invalid type              -> InvalidTypeError             # spec: N-000418

Syntax and incomplete refusals carry an int ``lex_position`` (spec: N-000421).
"""


class PathSelError(ValueError):
    """Common base of every refusal. It is never raised by itself."""


class EmptyExpressionError(PathSelError):
    def __init__(self, position=0, message="empty expression"):
        super().__init__(message)
        self.lex_position = position


class IncompleteExpressionError(PathSelError):
    def __init__(self, position, message="incomplete expression"):
        super().__init__(message)
        self.lex_position = position


class ExpressionSyntaxError(PathSelError):
    """Grammar-level syntax failure (text split into valid tokens)."""

    def __init__(self, position, message="syntax error"):
        super().__init__(message)
        self.lex_position = position


class TokenSyntaxError(ExpressionSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    def __init__(self, message="slice step must not be zero"):
        super().__init__(message)


class UnknownFunctionError(PathSelError):
    def __init__(self, name):
        super().__init__("unknown function: %s" % name)


class InvalidArityError(PathSelError):
    def __init__(self, name, given):
        super().__init__("wrong number of arguments to %s: %d" % (name, given))


class InvalidTypeError(PathSelError):
    def __init__(self, message="invalid argument type"):
        super().__init__(message)
