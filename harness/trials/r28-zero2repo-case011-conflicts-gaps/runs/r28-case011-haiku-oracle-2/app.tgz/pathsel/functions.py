"""Built-in language functions and the custom-function provider API.

Spec: FP-07 (built-in set and behavior), FP-08 (custom functions),
Interface Contract > pathsel.functions.

A provider is an instance of a subclass of Functions. Each attribute named
``_func_<name>`` that was passed through ``signature`` defines the language
function ``<name>``; it receives the already-evaluated arguments in order and
its return value is the call's value.
"""
import math
import re
from collections.abc import Mapping

from ._values import (
    ExpressionReference, current_context, is_array, is_json_number, is_number,
    is_object, json_equal,
)
from .errors import InvalidTypeError

_TYPE_NAMES = ("number", "string", "array", "object", "null")
_INT_NUMERAL = re.compile(r"-?[0-9]+\Z")
# Decimal or exponent numeral (integer numerals are matched first by to_number).
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][-+]?[0-9]+)?\Z")


def signature(*arguments):
    # spec: N-000401, N-000402, N-000403, N-000404
    """Declare the argument types of a custom function (spec: pathsel.functions.signature).

    Each argument is a mapping ``{"types": [<type-name>, ...]}`` where a type
    name is one of number, string, array, object, null. Returns a decorator
    that returns the implementation unchanged, marked with its signature.
    """
    specs = []
    for arg in arguments:
        if not isinstance(arg, Mapping) or "types" not in arg:
            raise TypeError('each signature argument must be {"types": [...]}')
        names = tuple(arg["types"])
        if not names or any(t not in _TYPE_NAMES for t in names):
            raise TypeError("unknown or empty type list in signature: %r" % (names,))
        specs.append(names)
    specs = tuple(specs)

    def decorator(fn):
        fn._pathsel_signature = specs
        return fn

    return decorator


def _builtin(lo, hi):
    def decorator(fn):
        fn._pathsel_arity = (lo, hi)
        return fn

    return decorator


def _bad(what):
    return InvalidTypeError("expected %s" % what)


def _number(v):
    # spec: N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320
    if not is_json_number(v):
        raise _bad("a number")
    return v


def _string(v):
    if not isinstance(v, str):
        raise _bad("a string")
    return v


def _array(v):
    if not is_array(v):
        raise _bad("an array")
    return v


def _object(v):
    if not is_object(v):
        raise _bad("an object")
    return v


def _ref(v):
    if not isinstance(v, ExpressionReference):
        raise _bad("an expression reference")
    return v


def _numbers(v):
    items = _array(v)
    for e in items:
        _number(e)
    return items


def _strings(v):
    items = _array(v)
    for e in items:
        _string(e)
    return items


def _same_kind_keys(keys):
    """Return 'number' or 'string' if every key is of that kind; else refuse."""
    if all(is_json_number(k) for k in keys):
        return "number"
    if all(isinstance(k, str) for k in keys):
        return "string"
    raise _bad("keys that are all numbers or all strings")


def _dump(v):
    # spec: N-000284, N-000285
    """Compact JSON text: no spaces, non-ASCII as \\uXXXX, numbers as the host writes them."""
    import json
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return json.dumps(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=True)
    if is_array(v):
        return "[" + ",".join(_dump(e) for e in v) + "]"
    if is_object(v):
        parts = []
        for k in v.keys():
            parts.append(json.dumps(str(k), ensure_ascii=True) + ":" + _dump(v[k]))
        return "{" + ",".join(parts) + "}"
    if is_number(v):
        return str(v)
    return json.dumps(str(v), ensure_ascii=True)


class Functions(object):
    # spec: N-000393, N-000394, N-000395, N-000396, N-000397, N-000398, N-000399, N-000400, N-000263, N-000309, N-000310
    """Provider implementing the built-in functions (spec: FP-07).

    Subclass it and decorate methods named ``_func_<name>`` with ``signature``
    to add custom functions (spec: FP-08).
    """

    def __init__(self):
        pass

    @_builtin(1, 1)
    def _func_abs(self, value):
        # spec: N-000269
        return abs(_number(value))

    @_builtin(1, 1)
    def _func_avg(self, value):
        # spec: N-000270, N-000271
        items = _numbers(value)
        if not items:
            return None
        return sum(items) / float(len(items))

    @_builtin(1, 1)
    def _func_ceil(self, value):
        # spec: N-000272
        return int(math.ceil(_number(value)))

    @_builtin(1, 1)
    def _func_floor(self, value):
        # spec: N-000273
        return int(math.floor(_number(value)))

    @_builtin(2, 2)
    def _func_contains(self, haystack, needle):
        # spec: N-000274, N-000275
        if is_array(haystack):
            return any(json_equal(e, needle) for e in haystack)
        if isinstance(haystack, str):
            return _string(needle) in haystack
        raise _bad("an array or a string")

    @_builtin(2, 2)
    def _func_ends_with(self, text, suffix):
        # spec: N-000276
        return _string(text).endswith(_string(suffix))

    @_builtin(2, 2)
    def _func_starts_with(self, text, prefix):
        # spec: N-000276
        return _string(text).startswith(_string(prefix))

    @_builtin(2, 2)
    def _func_join(self, glue, items):
        # spec: N-000279, N-000280
        g = _string(glue)
        return g.join(_strings(items))

    @_builtin(1, 1)
    def _func_keys(self, value):
        # spec: N-000281
        return list(_object(value).keys())

    @_builtin(1, 1)
    def _func_values(self, value):
        # spec: N-000281
        obj = _object(value)
        return [obj[k] for k in obj.keys()]

    @_builtin(1, 1)
    def _func_length(self, value):
        # spec: N-000277
        if isinstance(value, str):
            return len(value)
        if is_array(value):
            return len(value)
        if is_object(value):
            return len(list(value.keys()))
        raise _bad("a string, an array or an object")

    @_builtin(1, 1)
    def _func_reverse(self, value):
        # spec: N-000278
        if isinstance(value, str):
            return value[::-1]
        return list(_array(value))[::-1]

    @_builtin(1, 1)
    def _func_type(self, value):
        # spec: N-000282
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        return "object"

    @_builtin(1, 1)
    def _func_to_array(self, value):
        # spec: N-000283
        if is_array(value):
            return value
        return [value]

    @_builtin(1, 1)
    def _func_to_string(self, value):
        # spec: N-000284, N-000285
        if isinstance(value, str):
            return value
        return _dump(value)

    @_builtin(1, 1)
    def _func_to_number(self, value):
        # spec: N-000286, N-000287, N-000288, N-000289
        if is_json_number(value):
            return value
        if isinstance(value, str):
            if _INT_NUMERAL.match(value):
                return int(value)
            if _FLOAT_NUMERAL.match(value):
                return float(value)
        return None

    @_builtin(1, 1)
    def _func_max(self, value):
        # spec: N-000290, N-000292
        items = value
        if not is_array(items):
            raise _bad("an array")
        if not items:
            _same_kind_keys([])
            return None
        _same_kind_keys(items)
        return max(items)

    @_builtin(1, 1)
    def _func_min(self, value):
        # spec: N-000291, N-000292
        items = value
        if not is_array(items):
            raise _bad("an array")
        if not items:
            _same_kind_keys([])
            return None
        _same_kind_keys(items)
        return min(items)

    @_builtin(1, 1)
    def _func_sort(self, value):
        # spec: N-000293
        items = value
        if not is_array(items):
            raise _bad("an array")
        _same_kind_keys(items)
        return sorted(items)

    @_builtin(1, 1)
    def _func_sum(self, value):
        # spec: N-000294
        return sum(_numbers(value))

    @_builtin(1, None)
    def _func_merge(self, *objects):
        # spec: N-000295, N-000296, N-000297
        for o in objects:
            _object(o)
        out = current_context().new_object() if current_context() is not None else {}
        for o in objects:
            for k in o.keys():
                out[k] = o[k]
        return out

    @_builtin(1, None)
    def _func_not_null(self, *values):
        # spec: N-000298, N-000299, N-000300
        for v in values:
            if v is not None:
                return v
        return None

    @_builtin(2, 2)
    def _func_map(self, ref, value):
        # spec: N-000301, N-000302
        r = _ref(ref)
        return [r.evaluate(e) for e in _array(value)]

    @_builtin(2, 2)
    def _func_sort_by(self, value, ref):
        # spec: N-000303, N-000304, N-000305
        items = _array(value)
        r = _ref(ref)
        keyed = [(r.evaluate(e), e) for e in items]
        if keyed:
            _same_kind_keys([k for k, _ in keyed])
        keyed.sort(key=lambda pair: pair[0])
        return [e for _, e in keyed]

    @_builtin(2, 2)
    def _func_max_by(self, value, ref):
        # spec: N-000306, N-000307
        return self._extreme_by(value, ref, greater=True)

    @_builtin(2, 2)
    def _func_min_by(self, value, ref):
        # spec: N-000308
        return self._extreme_by(value, ref, greater=False)

    def _extreme_by(self, value, ref, greater):
        items = _array(value)
        r = _ref(ref)
        keyed = [(r.evaluate(e), e) for e in items]
        if not keyed:
            return None
        _same_kind_keys([k for k, _ in keyed])
        best_key, best = keyed[0]
        for k, e in keyed[1:]:
            if (k > best_key) if greater else (k < best_key):
                best_key, best = k, e
        return best


DEFAULT_PROVIDER = Functions()

# Built-in implementations keyed by function name (the 26 names of FP-07).
BUILTIN_IMPLS = {}
for _attr, _fn in list(vars(Functions).items()):
    if _attr.startswith("_func_"):
        BUILTIN_IMPLS[_attr[len("_func_"):]] = _fn
del _attr, _fn
