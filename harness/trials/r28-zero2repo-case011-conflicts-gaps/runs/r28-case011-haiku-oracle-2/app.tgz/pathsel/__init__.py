"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public entries (spec: Interface Contract > pathsel, pathsel.search, pathsel.compile):

    search(expression, data, options=None) -> value
    compile(expression) -> ParsedExpression
    ParsedExpression.search(value, options=None) -> value

Refusals are raised as ValueError subclasses (see pathsel.errors).
"""
from ._nodes import Node  # noqa: F401  (re-exported for typing only)
from ._parser import parse as _parse
from ._values import Context, ExpressionReference, reset_current_context, set_current_context
from .errors import (  # noqa: F401
    EmptyExpressionError, ExpressionSyntaxError, IncompleteExpressionError,
    InvalidArityError, InvalidTypeError, PathSelError, TokenSyntaxError,
    UnknownFunctionError, ZeroSliceStepError,
)

__all__ = [
    "search", "compile", "ParsedExpression", "ExpressionReference",
    "PathSelError", "EmptyExpressionError", "IncompleteExpressionError",
    "ExpressionSyntaxError", "TokenSyntaxError", "ZeroSliceStepError",
    "UnknownFunctionError", "InvalidArityError", "InvalidTypeError",
]


# spec: N-000323, N-000324, N-000325, N-000326, N-000327, N-000389, N-000390, N-000391, N-000392
def _context_from(options):
    """Read the two attributes of an evaluation-options object (spec: Evaluation options)."""
    if options is None:
        return Context(None, None)
    if isinstance(options, dict):
        return Context(options.get("dict_cls"), options.get("custom_functions"))
    return Context(getattr(options, "dict_cls", None), getattr(options, "custom_functions", None))


def _run(node, value, options):
    ctx = _context_from(options)
    token = set_current_context(ctx)
    try:
        return node.evaluate(value, ctx)
    finally:
        reset_current_context(token)


class ParsedExpression(object):
    """A parsed expression that can be searched any number of times (spec: FP-01)."""

    __slots__ = ("_node",)

    def __init__(self, node):
        self._node = node

    def search(self, value, options=None):
        return _run(self._node, value, options)


# spec: N-000073, N-000074, N-000075, N-000383, N-000384, N-000385, N-000386, N-000387, N-000388
def compile(expression):  # noqa: A001 - published name (spec: Interface Contract)
    """Parse an expression once. Raises a refusal kind if it does not succeed."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(_parse(expression))


# spec: N-000038, N-000039, N-000040, N-000041, N-000042, N-000076, N-000078, N-000079, N-000080, N-000081, N-000082, N-000105, N-000106, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380, N-000381, N-000382
def search(expression, data, options=None):
    """Evaluate an expression against data in one shot (spec: FP-01)."""
    return compile(expression).search(data, options)
