"""Expression tree and evaluation.

Every node evaluates against a current value (spec: Terminology, "Current
value") and an evaluation context. Projections evaluate their right-hand side
once per collected element and drop null results (spec: FP-03, FP-04).
"""
import copy

from ._values import (
    ExpressionReference, is_array, is_false, is_json_number, is_object, is_true,
    json_equal, ordered,
)
from .errors import (
    InvalidArityError, InvalidTypeError, UnknownFunctionError,
)
from .functions import BUILTIN_IMPLS, DEFAULT_PROVIDER


class Node(object):
    def evaluate(self, cur, ctx):  # pragma: no cover - interface
        raise NotImplementedError


class Identity(Node):
    """The current value itself (`@`, or the implicit base of a step)."""

    def evaluate(self, cur, ctx):
        return cur


IDENTITY = Identity()


# spec: N-000223, N-000224, N-000225, N-000226, N-000227, N-000228
class Literal(Node):
    """JSON literal or raw string (spec: FP-05). Copied so callers cannot alter it."""

    def __init__(self, value):
        self.value = value

    def evaluate(self, cur, ctx):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


# spec: N-000077, N-000083, N-000084, N-000085, N-000115, N-000116, N-000125
class Field(Node):
    """Field selection by identifier (spec: FP-02). Non-objects yield null."""

    def __init__(self, base, name):
        self.base = base
        self.name = name

    def evaluate(self, cur, ctx):
        v = self.base.evaluate(cur, ctx)
        if not is_object(v):
            return None
        try:
            return v[self.name]
        except KeyError:
            return None


# spec: N-000126, N-000127, N-000128, N-000129
class Index(Node):
    """Single index on an array; negative counts from the end (spec: FP-03)."""

    def __init__(self, base, index):
        self.base = base
        self.index = index

    def evaluate(self, cur, ctx):
        v = self.base.evaluate(cur, ctx)
        if not is_array(v):
            return None
        i = self.index
        if i < 0:
            i += len(v)
        if 0 <= i < len(v):
            return v[i]
        return None


# spec: N-000142, N-000143, N-000144, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000159, N-000160, N-000161, N-000162, N-000163, N-000164, N-000165, N-000166, N-000167, N-000168, N-000169, N-000170, N-000171, N-000172, N-000173, N-000204, N-000205
class Projection(Node):
    """A projection-starting form and its right-hand side (spec: FP-03, FP-04).

    kind: 'list' (`[*]`), 'object' (`*` / `.*`), 'flatten' (`[]`),
          'slice' (`[a:b:c]`, arg = (start, stop, step)), 'filter' (`[?p]`, arg = predicate).
    """

    def __init__(self, base, kind, arg, rhs):
        self.base = base
        self.kind = kind
        self.arg = arg
        self.rhs = rhs

    def evaluate(self, cur, ctx):
        v = self.base.evaluate(cur, ctx)
        kind = self.kind
        if kind == "object":
            if not is_object(v):
                return None
            items = [v[k] for k in v.keys()]
        elif kind == "flatten":
            if not is_array(v):
                return None
            items = []
            for e in v:
                if is_array(e):
                    items.extend(e)
                else:
                    items.append(e)
        else:
            if not is_array(v):
                return None
            if kind == "list":
                items = list(v)
            elif kind == "slice":
                start, stop, step = self.arg
                items = list(v[start:stop:step])
            else:  # filter
                items = [e for e in v if is_true(self.arg.evaluate(e, ctx))]
        out = []
        for e in items:
            r = self.rhs.evaluate(e, ctx)
            if r is not None:
                out.append(r)
        return out


class Pipe(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, cur, ctx):
        return self.right.evaluate(self.left.evaluate(cur, ctx), ctx)


# spec: N-000247, N-000248, N-000249, N-000250, N-000251, N-000252
class Or(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, cur, ctx):
        lv = self.left.evaluate(cur, ctx)
        if is_true(lv):
            return lv
        return self.right.evaluate(cur, ctx)


class And(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, cur, ctx):
        lv = self.left.evaluate(cur, ctx)
        if is_false(lv):
            return lv
        return self.right.evaluate(cur, ctx)


class Not(Node):
    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, cur, ctx):
        return is_false(self.operand.evaluate(cur, ctx))


# spec: N-000242, N-000243, N-000244, N-000245, N-000246, N-000258, N-000259
class Compare(Node):
    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, cur, ctx):
        a = self.left.evaluate(cur, ctx)
        b = self.right.evaluate(cur, ctx)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        return ordered(self.op, a, b)


# spec: N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218
class MultiList(Node):
    """`[e1, e2]` (spec: FP-05). Nulls are stored; a null current value yields null."""

    def __init__(self, base, items):
        self.base = base
        self.items = items

    def evaluate(self, cur, ctx):
        v = self.base.evaluate(cur, ctx)
        if v is None:
            return None
        return [item.evaluate(v, ctx) for item in self.items]


# spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000328, N-000332
class MultiHash(Node):
    """`{k: e}` (spec: FP-05, FP-08). Builds an instance of the options' mapping type."""

    def __init__(self, base, pairs):
        self.base = base
        self.pairs = pairs

    def evaluate(self, cur, ctx):
        v = self.base.evaluate(cur, ctx)
        if v is None:
            return None
        out = ctx.new_object()
        for key, expr in self.pairs:
            out[key] = expr.evaluate(v, ctx)
        return out


# spec: N-000231, N-000233, N-000235, N-000423
class Expref(Node):
    """`&expr`: a reference that is not evaluated here (spec: FP-05)."""

    def __init__(self, node):
        self.node = node

    def evaluate(self, cur, ctx):
        return ExpressionReference(self.node, ctx)


_JSON_TYPE_TESTS = {
    "number": is_json_number,
    "string": lambda v: isinstance(v, str),
    "array": is_array,
    "object": is_object,
    "null": lambda v: v is None,
}


# spec: N-000262, N-000263, N-000335, N-000339, N-000340, N-000344
def _lookup(name, ctx):
    """Resolve a function name: built-ins first, then the attached provider.

    Returns (call(args), min_args, max_args, declared_types_or_None).
    Spec: FP-07 (built-in set), FP-08 (provider extends the built-in set; a
    built-in name keeps its built-in behavior).
    """
    impl = BUILTIN_IMPLS.get(name)
    if impl is not None:
        lo, hi = impl._pathsel_arity

        def call_builtin(args):
            return impl(DEFAULT_PROVIDER, *args)

        return call_builtin, lo, hi, None
    provider = ctx.provider
    if provider is not None:
        attr = getattr(provider, "_func_" + name, None)
        declared = getattr(attr, "_pathsel_signature", None)
        if attr is not None and declared is not None:
            def call_custom(args):
                return attr(*args)

            return call_custom, len(declared), len(declared), declared
    raise UnknownFunctionError(name)


# spec: N-000264, N-000265, N-000266, N-000267, N-000268, N-000311, N-000312, N-000313, N-000314, N-000336, N-000337, N-000345, N-000346, N-000347, N-000348, N-000349
class FuncCall(Node):
    """`name(args)`. Checks name, then argument count, then argument types, at evaluation.

    Spec: FP-07 (order of checks), FP-08 (custom functions).
    """

    def __init__(self, base, name, args):
        self.base = base
        self.name = name
        self.args = args

    def evaluate(self, cur, ctx):
        call, lo, hi, declared = _lookup(self.name, ctx)
        n = len(self.args)
        if n < lo or (hi is not None and n > hi):
            raise InvalidArityError(self.name, n)
        base_value = self.base.evaluate(cur, ctx)
        argv = [a.evaluate(base_value, ctx) for a in self.args]
        if declared is not None:
            for i, names in enumerate(declared):
                if not any(_JSON_TYPE_TESTS[t](argv[i]) for t in names):
                    raise InvalidTypeError(
                        "argument %d of %s has the wrong type" % (i + 1, self.name))
        return call(argv)
