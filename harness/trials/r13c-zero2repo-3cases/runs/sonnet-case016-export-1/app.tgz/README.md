# prosecheck

A local detector for AI-writing patterns, plus an agent plugin. Python standard library only
(3.9+) for `scripts/detect.py`; Node.js for the hooks under `hooks/`. No network, no model.

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]

Plugin commands: `/prosecheck help`.
