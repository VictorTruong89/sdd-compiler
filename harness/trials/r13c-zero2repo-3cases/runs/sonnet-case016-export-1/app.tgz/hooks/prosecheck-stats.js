#!/usr/bin/env node
'use strict';
// Session statistics: token use and own-prose score from a transcript.
const fs = require('fs');
const path = require('path');
const L = require('./prosecheck-lib');

function newestTranscript() {
  const root = path.join(L.configDir(), 'projects');
  let best = null;
  function walk(dir, depth) {
    let names;
    try { names = fs.readdirSync(dir); } catch (e) { return; }
    for (const n of names) {
      const p = path.join(dir, n);
      let st;
      try { st = fs.statSync(p); } catch (e) { continue; }
      if (st.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (n.endsWith('.jsonl') && (!best || st.mtimeMs > best.m)) best = { p, m: st.mtimeMs };
    }
  }
  walk(root, 0);
  return best && best.p;
}

function fmt(n) { return String(n); }

function statsReply(transcriptPath) {
  const level = L.currentLevel();
  const file = transcriptPath || newestTranscript();
  let raw = null;
  if (file) {
    try { if (fs.statSync(file).isFile()) raw = fs.readFileSync(file, 'utf8'); } catch (e) { raw = null; }
  }
  if (raw === null) {
    return 'prosecheck stats: no readable session transcript was found, so there are no token figures to show.\nlevel: ' + level;
  }
  let turns = 0, outTok = 0, cacheTok = 0;
  const seen = new Set();
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const id = m.id;
    const hasId = id !== undefined && id !== null && id !== '';
    if (!hasId || !seen.has(id)) {
      if (hasId) seen.add(id);
      turns += 1;
      const u = m.usage && typeof m.usage === 'object' ? m.usage : {};
      outTok += Number(u.output_tokens) || 0;
      cacheTok += Number(u.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(m.content)) {
      for (const c of m.content) if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
    } else if (typeof m.content === 'string') texts.push(m.content);
  }
  const lines = [
    'prosecheck stats (this session)',
    'level: ' + level,
    'assistant turns: ' + fmt(turns),
    'output tokens: ' + fmt(outTok),
    'cache-read input tokens: ' + fmt(cacheTok),
  ];
  let slice = texts.join('\n\n');
  slice = slice.replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '').replace(/```[\s\S]*$/, '');
  if (slice.length > 40000) slice = slice.slice(slice.length - 40000);
  if (slice.trim().length > 200) {
    const r = L.runDetector([], { input: slice.trim(), timeout: 15000 });
    if (r.kind === 'done') {
      const rep = L.parseReport(r.stdout);
      const sc = rep && rep._metrics && rep._metrics.ai_tell_score;
      if (typeof sc === 'number') lines.push('session prose ai_tell_score: ' + sc);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  L.safeMain(() => {
    const input = L.readStdinJson();
    const tp = typeof input.transcript_path === 'string' && input.transcript_path ? input.transcript_path : null;
    L.out(JSON.stringify({ decision: 'block', reason: statsReply(tp) }));
  });
}
