#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const L = require('./prosecheck-lib');

L.safeMain(() => {
  L.readStdinJson();
  L.pruneLedgers();
  const stored = L.readFlag();
  const level = stored || L.envDefault() || 'full';
  if (level === 'off') return;
  let welcome = false;
  if (!stored && !require('fs').existsSync(L.flagPath())) {
    welcome = L.writeLevel(level);
  }
  L.out((welcome ? L.welcomeText() + '\n' : '') + L.contractFor(level) + '\n');
});
