#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same writing contract, in the subagent envelope.
const L = require('./prosecheck-lib');

L.safeMain(() => {
  L.readStdinJson();
  const level = L.currentLevel();
  if (level === 'off') return;
  L.out(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: L.contractFor(level) },
  }));
});
