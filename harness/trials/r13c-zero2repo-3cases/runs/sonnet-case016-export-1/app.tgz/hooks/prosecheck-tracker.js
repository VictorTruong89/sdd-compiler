#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const L = require('./prosecheck-lib');
const { statsReply } = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const BAD_MARK = '<!-- prosecheck:contract -->';
const END_MARK = '<!-- /prosecheck:contract -->';

function block(reason) {
  L.out(JSON.stringify({ decision: 'block', reason }));
}

function helpReply(level) {
  return [
    'prosecheck is a local detector for AI-writing patterns; current level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables are.',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full - writing contract plus the saved-file guard at a threshold of 40 (default)',
    '/prosecheck strict - guard at a stricter threshold of 20, plus the cleanup scrub',
    '/prosecheck off | on - disable the tool, or re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <path> - score one file and report; never rewrite the file; this is report only',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token use for this session and a score of its own prose',
    '/prosecheck init - export the writing contract to AGENTS.md for other agents',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripArg(arg) {
  let a = (arg || '').trim();
  // a leading @ outside quotes, then one pair of quotes
  if (a.startsWith('@')) a = a.slice(1).trim();
  const m = /^(["'])(.*)\1$/s.exec(a);
  if (m) a = m[2];
  else if (/^["']/.test(a)) {
    const q = a[0];
    const end = a.indexOf(q, 1);
    if (end > 0) a = a.slice(1, end);
  }
  return a;
}

function hasNumberLike(s) { return /(?<![\w.])(?:\d|[1-9]\d|100)(?![\w.])/.test(s); }

function checkReply(arg) {
  let p = stripArg(arg);
  if (!p) {
    return 'prosecheck check needs a file: give a path to a prose file, for example "/prosecheck check notes.md". It reports only; the file is not changed.';
  }
  let abs = path.resolve(process.cwd(), p);
  let st;
  try { st = fs.statSync(abs); } catch (e) {
    // an unquoted path with spaces may carry trailing words; try the first token
    const first = p.split(/\s+/)[0];
    let ok = false;
    if (first !== p) {
      try { st = fs.statSync(path.resolve(process.cwd(), first)); abs = path.resolve(process.cwd(), first); p = first; ok = true; } catch (e2) { ok = false; }
    }
    if (!ok) return 'prosecheck: cannot read ' + p + ' (no such file).';
  }
  const base = path.basename(abs);
  if (!st.isFile()) return 'prosecheck: ' + p + ' is not a file.';
  const ext = path.extname(abs).toLowerCase();
  if (L.BINARY_EXT.indexOf(ext) >= 0) return 'prosecheck: ' + base + ' has no readable text (pdf and rtf are not read).';
  const archive = L.ARCHIVE_EXT.indexOf(ext) >= 0;
  const cap = archive ? L.ARCHIVE_CAP : L.PLAIN_CAP;
  if (st.size > cap) {
    return 'prosecheck: ' + base + ' is over ' + (archive ? L.ARCHIVE_KB : L.PLAIN_KB) + ' KB and was not scored.';
  }
  const r = L.runDetector([abs], { timeout: archive ? 15000 : 8000 });
  if (r.kind === 'nopython' || r.kind === 'nodetector') return 'prosecheck: detector unavailable, so ' + base + ' was not scored.';
  if (r.kind === 'timeout') return 'prosecheck: ' + base + ' failed: the detector timed out.';
  if (r.status !== 0) {
    const e = (r.stderr || '').trim();
    return 'prosecheck: ' + base + ' failed to score' + (e ? ': ' + e : '.');
  }
  if (!r.stdout.trim()) return 'prosecheck: ' + base + ' - no report came back from the detector.';
  const rep = L.parseReport(r.stdout);
  if (!rep || !rep._metrics || typeof rep._metrics.ai_tell_score !== 'number') {
    return 'prosecheck: the detector gave no report.';
  }
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + L.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && typeof m.confidence_reason === 'string' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + L.WINDOW_TXT + ' characters only');
  const f = L.findingsOf(rep).slice(0, 8);
  lines.push('tells: ' + (f.length ? f.map((x) => x.label + ' (x' + x.count + ')').join('; ') : 'none'));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = L.currentLevel();
  const lines = ['prosecheck health check'];
  let allOk = true;
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[off] mode: off - run /prosecheck on to switch it back on');
  const det = L.findDetector();
  if (det) lines.push('[OK] detector: bundled detector found in the plugin tree');
  else { lines.push('[FAIL] detector: bundled detector missing from the plugin tree'); allOk = false; }
  // python
  let pyLine;
  if (!det) {
    pyLine = '[FAIL] python: no bundled script to run, so nothing was scored';
    allOk = false;
  } else {
    const r = L.runDetector([], { input: 'This is a short plain sentence used for the health check of the install.', timeout: 15000 });
    if (r.kind === 'nopython') {
      pyLine = '[FAIL] python not found - saved prose is not re-scored until Python is available; new prose is still shaped by the writing contract';
      allOk = false;
    } else {
      const rep = r.kind === 'done' ? L.parseReport(r.stdout) : null;
      const sc = rep && rep._metrics && rep._metrics.ai_tell_score;
      if (typeof sc === 'number') pyLine = '[OK] python: ran the bundled script and got a numeric score';
      else { pyLine = '[FAIL] python: ran, but the result was not a numeric score'; allOk = false; }
    }
  }
  lines.push(pyLine);
  let writable = false;
  try {
    const dir = L.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    writable = true;
  } catch (e) { writable = false; }
  if (writable) lines.push('[OK] settings: folder is writable');
  else { lines.push('[FAIL] settings: folder is not writable'); allOk = false; }
  if (!allOk) {
    lines.push('Fix the faulty checks above, then run /prosecheck doctor again.');
  } else if (!modeOk) {
    lines.push('The install is healthy, but it is switched off, so saving files triggers no scoring. Run ' + form + ' on to turn it back on; prose is scored again after that.');
  } else {
    lines.push('prosecheck is active: plain text up to 512 KB and archives up to 4 MB are accepted, and the first ' + L.WINDOW_TXT + ' characters are scored. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  }
  return lines.join('\n');
}

function showReply(sessionId) {
  const rows = L.readLedger(sessionId);
  if (!rows.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['prosecheck: files from this session, newest first'];
  const sorted = rows.map((r, i) => [r, i]).sort((a, b) => (b[0].t - a[0].t) || (b[1] - a[1]));
  for (const [r] of sorted) {
    let body;
    if (r.kind === 'scored') {
      body = r.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + L.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = (r.labels || []).slice(0, 5);
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
    } else if (r.kind === 'size') {
      body = 'not scored: larger than the ' + r.limitKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

function initReply(level, form) {
  if (level === 'off') {
    return 'prosecheck is switched off, so init wrote no files. Run ' + form + ' on to allow the export.';
  }
  const cwd = process.cwd();
  const msgs = [];
  const agents = path.join(cwd, 'AGENTS.md');
  const section = BAD_MARK + '\n' + L.contractFor(level, { exported: true }) + '\n' + END_MARK + '\n';
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  if (readFail) {
    msgs.push('cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.indexOf(BAD_MARK) >= 0 || existing.indexOf('# Prose writing contract') >= 0)) {
    msgs.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    try {
      let add = section;
      if (existing !== null && existing.length) add = (existing.endsWith('\n') ? '\n' : '\n\n') + section;
      fs.appendFileSync(agents, add);
      msgs.push('Wrote the ' + level + ' writing contract to AGENTS.md.');
    } catch (e) {
      msgs.push('cannot write AGENTS.md, so the contract was not written.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    msgs.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    try {
      const src = path.join(L.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, data, { flag: 'wx' });
      msgs.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      msgs.push('cannot write the Cursor rule .cursor/rules/prosecheck.mdc.');
    }
  }
  return msgs.join('\n');
}

L.safeMain(() => {
  const input = L.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  L.pruneLedgers();
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    L.writeLevel('off');
    block('prosecheck is now off.');
    return;
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/i.exec(trimmed);
  if (m) {
    const form = m[1].toLowerCase();
    const rest = (m[2] || '').trim();
    const sm = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
    const word = sm ? sm[1].toLowerCase() : 'help';
    const arg = sm && sm[2] ? sm[2] : '';
    const level = L.currentLevel();
    switch (word) {
      case 'lite': case 'full': case 'strict': case 'off':
        L.writeLevel(word);
        block('prosecheck level set to ' + word + '.');
        return;
      case 'on':
        L.writeLevel('full');
        block('prosecheck is on (full).');
        return;
      case 'status':
        block('prosecheck level: ' + level);
        return;
      case 'help':
        block(helpReply(level));
        return;
      case 'show':
        block(showReply(sessionId));
        return;
      case 'check':
        block(checkReply(arg));
        return;
      case 'doctor':
        block(doctorReply(form));
        return;
      case 'stats': {
        const tp = typeof input.transcript_path === 'string' && input.transcript_path ? input.transcript_path : null;
        block(statsReply(tp));
        return;
      }
      case 'init':
        block(initReply(level, form));
        return;
      default:
        block('prosecheck: unknown subcommand "' + sm[1] + '". Valid words: ' + SUBS.join(', ') + '.');
        return;
    }
  }
  const level = L.currentLevel();
  if (level === 'off') return;
  L.out(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }));
});
