#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const L = require('./prosecheck-lib');

const TOOLS = ['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch', 'applypatch'];
const INSTRUCTION = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const MAX_PATCH_FILES = 16;

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && out.indexOf(p) < 0) out.push(p);
    }
  }
  return out.slice(0, MAX_PATCH_FILES);
}

function insidePluginRoot(abs) {
  let root;
  try { root = path.resolve(L.pluginRoot()); } catch (e) { return false; }
  const rel = path.relative(root, abs);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'].indexOf(lower) >= 0) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (INSTRUCTION.indexOf(lower) >= 0) return true;
  if (INSTRUCTION.indexOf(stem) >= 0 && L.PROSE_EXT.indexOf(ext) < 0 && L.BINARY_EXT.indexOf(ext) < 0) return true;
  return false;
}

function shouldSkip(abs) {
  const parts = abs.split(/[\\/]+/);
  for (const p of parts.slice(0, -1)) {
    if (p === 'node_modules' || p === '.git' || p === 'memory') return true;
  }
  if (insidePluginRoot(abs)) return true;
  if (isInstructionFile(path.basename(abs))) return true;
  return false;
}

function processFile(abs, level, sessionId) {
  if (shouldSkip(abs)) return null;
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const isBinary = L.BINARY_EXT.indexOf(ext) >= 0;
  if (L.PROSE_EXT.indexOf(ext) < 0 && !isBinary) return null;
  if (isBinary) {
    L.appendLedger(sessionId, { kind: 'binary', base });
    return null;
  }
  let st;
  try { st = fs.statSync(abs); } catch (e) {
    L.appendLedger(sessionId, { kind: 'failed', base, reason: 'file could not be read (not found)' });
    return null;
  }
  if (!st.isFile()) return null;
  const archive = L.ARCHIVE_EXT.indexOf(ext) >= 0;
  const cap = archive ? L.ARCHIVE_CAP : L.PLAIN_CAP;
  if (st.size > cap) {
    L.appendLedger(sessionId, { kind: 'size', base, limitKB: archive ? L.ARCHIVE_KB : L.PLAIN_KB });
    return null;
  }
  const r = L.runDetector([abs], { timeout: archive ? 15000 : 8000 });
  const fail = (reason) => { L.appendLedger(sessionId, { kind: 'failed', base, reason }); return null; };
  if (r.kind === 'nopython') return fail('python not found, so the file was not scored');
  if (r.kind === 'nodetector') return fail('the bundled detector is missing, so the file was not scored');
  if (r.kind === 'timeout') return fail('the detector timed out');
  if (r.status !== 0 || !r.stdout.trim()) return fail('the detector produced no usable result');
  const rep = L.parseReport(r.stdout);
  if (!rep) return fail('the detector printed text that is not a structured report');
  const m = rep._metrics;
  if (!m || typeof m.ai_tell_score !== 'number') return fail('the report has no numeric score');
  const score = m.ai_tell_score;
  const band = String(m.ai_tell_band);
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold && m.confidence !== 'none';
  const labels = L.findingsOf(rep).map((f) => f.label).slice(0, 5);
  const phrase = L.phraseFor(band);
  L.appendLedger(sessionId, {
    kind: 'scored', base, score, band, phrase, labels, flagged, truncated: !!m.truncated,
  });
  if (!flagged) return null;
  const coverage = m.truncated ? ', first ' + L.WINDOW_TXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + score + ', band ' + band + coverage + '). Flagged: ' +
    (labels.length ? labels.join('; ') : 'pattern findings') +
    '. Please fix the flagged spans, keeping the facts and varying the rhythm.';
}

L.safeMain(() => {
  const input = L.readStdinJson();
  const level = L.currentLevel();
  if (level === 'off' || level === 'lite') return;
  const tool = typeof input.tool_name === 'string' ? input.tool_name.toLowerCase() : '';
  if (TOOLS.indexOf(tool) < 0) return;
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  let paths = [];
  if (tool === 'apply_patch' || tool === 'applypatch') {
    paths = patchPaths(ti.command || ti.patch || ti.input);
  } else if (tool === 'notebookedit') {
    const p = ti.notebook_path || ti.file_path;
    if (typeof p === 'string' && p.trim()) paths = [p.trim()];
  } else if (typeof ti.file_path === 'string' && ti.file_path.trim()) {
    paths = [ti.file_path.trim()];
  }
  if (!paths.length) return;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const lines = [];
  const doneAbs = new Set();
  for (const p of paths) {
    let abs;
    try { abs = path.resolve(cwd, p); } catch (e) { continue; }
    if (doneAbs.has(abs)) continue;
    doneAbs.add(abs);
    try {
      const line = processFile(abs, level, sessionId);
      if (line) lines.push(line);
    } catch (e) { /* keep going */ }
  }
  if (lines.length) {
    L.out(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }));
  }
});
