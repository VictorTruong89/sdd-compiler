'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 524288; // 512 KB
const ARCHIVE_CAP = 4194304; // 4 MB
const PLAIN_KB = 512;
const ARCHIVE_KB = 4096;
const LEVELS = ['lite', 'full', 'strict', 'off'];
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const LEDGER_KEEP = 20;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ARCHIVE_EXT);
const BINARY_EXT = ['.pdf', '.rtf'];

const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};
function phraseFor(band) { return PHRASES[band] || 'reads with some AI tells'; }

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readFlag() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.indexOf(v) >= 0 ? v : null;
  } catch (e) { return null; }
}
function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}
function currentLevel() { return readFlag() || envDefault() || 'full'; }
function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level, { mode: 0o600 });
    return true;
  } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}

// ---------------------------------------------------------------- python
function findOnPath(name) {
  const envPath = process.env.PATH !== undefined ? process.env.PATH : '';
  const exts = process.platform === 'win32' ? ['.exe', '.cmd', '.bat', ''] : [''];
  for (const dir of envPath.split(path.delimiter)) {
    if (!dir) continue;
    for (const ext of exts) {
      const full = path.join(dir, name + ext);
      try {
        const st = fs.statSync(full);
        if (st.isFile()) {
          if (process.platform !== 'win32') fs.accessSync(full, fs.constants.X_OK);
          return full;
        }
      } catch (e) { /* next */ }
    }
  }
  return null;
}
function findDetector() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  if (fs.existsSync(b)) return b;
  return null;
}
// Runs the detector. Returns {kind, ...}:
//  nopython | nodetector | timeout | done {status, stdout, stderr}
function runDetector(args, opts) {
  opts = opts || {};
  const det = findDetector();
  if (!det) return { kind: 'nodetector' };
  const names = ['python3', 'python', 'py'];
  for (const n of names) {
    const exe = findOnPath(n);
    if (!exe) continue;
    const r = cp.spawnSync(exe, [det].concat(args), {
      input: opts.input,
      timeout: opts.timeout || 15000,
      encoding: 'utf8',
      maxBuffer: 256 * 1024 * 1024,
      env: process.env,
    });
    if (r.error) {
      if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout' };
      if (r.error.code === 'ENOENT' || r.error.code === 'EACCES') continue;
      return { kind: 'done', status: 1, stdout: '', stderr: String(r.error.message || '') };
    }
    if (r.signal && r.status === null) return { kind: 'timeout' };
    return { kind: 'done', status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { kind: 'nopython' };
}
function parseReport(stdout) {
  try {
    const v = JSON.parse(stdout);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* not a report */ }
  return null;
}
function findingsOf(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (f && typeof f === 'object' && typeof f.label === 'string') {
      out.push({ label: f.label, count: Number(f.count) || 0 });
    }
  }
  return out;
}

// ---------------------------------------------------------------- ledger
function sanitizeId(id) {
  const s = String(id);
  const clean = s.replace(/[^A-Za-z0-9_.-]/g, '_').replace(/^\.+/, '_').slice(0, 80);
  if (clean === s) return clean;
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return clean + '_' + h.toString(16);
}
function ledgerPath(sessionId) {
  const dir = configDir();
  if (sessionId === undefined || sessionId === null || sessionId === '') return path.join(dir, '.prosecheck-ledger');
  return path.join(dir, '.prosecheck-ledger-' + sanitizeId(sessionId));
}
function pruneLedgers() {
  try {
    const dir = configDir();
    const now = Date.now();
    for (const n of fs.readdirSync(dir)) {
      if (n !== '.prosecheck-ledger' && !n.startsWith('.prosecheck-ledger-')) continue;
      const p = path.join(dir, n);
      try {
        const st = fs.statSync(p);
        if (now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
      } catch (e) { /* ignore */ }
    }
  } catch (e) { /* ignore */ }
}
function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}
function appendLedger(sessionId, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const rows = readLedger(sessionId);
    rec.t = Date.now();
    rows.push(rec);
    const keep = rows.slice(-LEDGER_KEEP);
    const p = ledgerPath(sessionId);
    fs.writeFileSync(p, JSON.stringify(keep), { mode: 0o600 });
    try { fs.chmodSync(p, 0o600); } catch (e) { /* ignore */ }
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------- contract
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function baseContract() {
  return [
    '# Prose writing contract',
    'Applies to prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.',
    'This contract never applies to source code, code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat. It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.',
    'Rules:',
    '- Vary sentence length irregularly: no metronome, no mechanical short-long alternation.',
    '- Banned vocabulary, never use these words: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting ("let\'s dive in"); empty pivots ("it\'s worth noting"); "In conclusion" or "Overall" closers; outcome-speculation tails; self-thoroughness; generic upbeat endings; chatbot phrases ("I hope this helps").',
    '- Em-dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual or encyclopedic content stays neutral third person; first-person or opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    '- End sections on a fact or observation.',
    '- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

// opts.exported: portable text for AGENTS.md (no machine path).
function contractFor(level, opts) {
  opts = opts || {};
  const lines = baseContract();
  if (level === 'full' || level === 'strict') {
    if (opts.exported) {
      lines.push('- Detector: use CLAUDE_PLUGIN_ROOT when that variable is set (scripts/detect.py under it); otherwise locate the prosecheck detector in your installed skills and plugins.');
    } else {
      const det = findDetector();
      if (det) lines.push('- Detector on this machine: python3 "' + det + '" <file>');
    }
    if (level === 'full') {
      lines.push('- After writing a prose file, run the detector on that file and fix the flagged spans (at most two fix passes, keeping rhythm variation) when the band is worse than the target. Target: band clean or light tells (score at most 40).');
    } else {
      lines.push('- After writing a prose file, run the detector on that file and fix the flagged spans (at most two fix passes, keeping rhythm variation) when the band is worse than the target. Target: band clean (score at most 20).');
      lines.push('- Finish by running the detector with --clean on the file and keeping the scrubbed text.');
    }
  }
  return lines.join('\n');
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns; plain text is accepted up to 512 KB and archives up to 4 MB, and the detector scores the first ' + WINDOW_TXT + ' characters.',
    'There is no website and no upload; everything stays on this machine. Commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'This welcome is shown once.',
    '',
  ].join('\n');
}

function out(s) { try { process.stdout.write(s); } catch (e) { /* ignore */ } }
function safeMain(fn) {
  try { fn(); } catch (e) { /* hooks never fail the host */ }
  process.exitCode = 0;
}

module.exports = {
  WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_KB, ARCHIVE_KB, LEVELS, PLAIN_EXT, ARCHIVE_EXT,
  PROSE_EXT, BINARY_EXT, BANNED, phraseFor, configDir, pluginRoot, flagPath, readFlag, envDefault,
  currentLevel, writeLevel, readStdinJson, findOnPath, findDetector, runDetector, parseReport,
  findingsOf, ledgerPath, pruneLedgers, readLedger, appendLedger, contractFor, welcomeText, out, safeMain,
};
