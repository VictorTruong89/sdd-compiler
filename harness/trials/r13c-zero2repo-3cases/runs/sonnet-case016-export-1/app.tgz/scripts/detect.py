#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only scan for AI-writing patterns.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

WINDOW = 262144
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Scores prose for documented AI-writing patterns. Reads FILE, or standard input.\n"
    "  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        end of options; the next argument is the file\n"
    "  -h, --help  print this message\n"
)

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# --------------------------------------------------------------------------
# input decoding and extraction
# --------------------------------------------------------------------------

def decode_bytes(b):
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            return b[2:].decode("utf-16-le", "replace")
    if b"\x00" in b:
        return ""
    if b[:3] == b"\xef\xbb\xbf":
        b = b[3:]
    return b.decode("utf-8", "replace")


def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def natural_key(s):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", s)]


def parse_xml(data):
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def collect_text(el, para_tags, text_tags, tab_tags=(), br_tags=()):
    """Return list of paragraph strings from element tree."""
    paras = []

    def walk_para(p):
        out = []

        def rec(e):
            for c in e:
                t = local(c.tag)
                if t in text_tags:
                    out.append("".join(c.itertext()))
                elif t in tab_tags:
                    out.append("\t")
                elif t in br_tags:
                    out.append("\n")
                elif t in para_tags:
                    continue
                else:
                    rec(c)
        rec(p)
        return "".join(out)

    def top(e):
        for c in e:
            if local(c.tag) in para_tags:
                paras.append(walk_para(c))
            else:
                top(c)
    top(el)
    return paras


def extract_docx(z):
    names = z.namelist()
    if "word/document.xml" not in names:
        return ""
    root = parse_xml(z.read("word/document.xml"))
    if root is None:
        return ""
    paras = collect_text(root, {"p"}, {"t"}, {"tab"}, {"br", "cr"})
    return "\n".join(paras)


def extract_pptx(z):
    slides = [n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    slides.sort(key=natural_key)
    parts = []
    for n in slides:
        root = parse_xml(z.read(n))
        if root is None:
            continue
        paras = collect_text(root, {"p"}, {"t"}, (), {"br"})
        parts.append("\n".join(p for p in paras))
    return "\n".join(parts)


def extract_xlsx(z):
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = parse_xml(z.read("xl/sharedStrings.xml"))
        if root is not None:
            for si in root:
                if local(si.tag) != "si":
                    continue
                txt = []
                for e in si.iter():
                    if local(e.tag) == "t":
                        # skip phonetic runs
                        txt.append(e.text or "")
                shared.append("".join(txt))
    sheets = [n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)]
    sheets.sort(key=natural_key)
    out = []
    for n in sheets:
        root = parse_xml(z.read(n))
        if root is None:
            continue
        for c in root.iter():
            if local(c.tag) != "c":
                continue
            t = c.get("t")
            v = None
            for ch in c:
                if local(ch.tag) == "v":
                    v = ch.text
                if local(ch.tag) == "is":
                    pass
            if t == "s":
                if v is not None and re.match(r"^\d+$", v.strip()):
                    i = int(v.strip())
                    if i < len(shared) and shared[i].strip():
                        out.append(shared[i])
            elif t == "inlineStr":
                for ch in c:
                    if local(ch.tag) == "is":
                        s = "".join(e.text or "" for e in ch.iter() if local(e.tag) == "t")
                        if s.strip():
                            out.append(s)
            elif t == "str":
                if v and v.strip():
                    out.append(v)
    return "\n".join(out)


def extract_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    root = parse_xml(z.read("content.xml"))
    if root is None:
        return ""
    paras = []

    def inline(e, out):
        if e.text:
            out.append(e.text)
        for c in e:
            t = local(c.tag)
            if t == "s":
                n = c.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c") or c.get("c") or "1"
                try:
                    out.append(" " * int(n))
                except Exception:
                    out.append(" ")
            elif t == "tab":
                out.append("\t")
            elif t == "line-break":
                out.append("\n")
            elif t == "annotation":
                pass
            else:
                inline(c, out)
            if c.tail:
                out.append(c.tail)

    def walk(e):
        for c in e:
            t = local(c.tag)
            if t in ("p", "h"):
                out = []
                inline(c, out)
                paras.append("".join(out))
            else:
                walk(c)
    walk(root)
    return "\n".join(paras)


class _Html(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
             "section", "article", "ul", "ol", "table", "pre", "dd", "dt", "figcaption", "hr"}
    SKIP = {"script", "style", "head", "nav", "title"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK and tag not in self.SKIP:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def extract_epub(z):
    names = [n for n in z.namelist() if re.search(r"\.(xhtml|html|htm)$", n, re.I)]
    names.sort(key=natural_key)
    chapters = []
    for n in names:
        base = os.path.basename(n).lower()
        if base.startswith("nav") or base.startswith("toc"):
            continue
        try:
            raw = z.read(n).decode("utf-8", "replace")
        except Exception:
            continue
        p = _Html()
        try:
            p.feed(raw)
            p.close()
        except Exception:
            pass
        text = "".join(p.parts)
        lines = [re.sub(r"[ \t\r\f\v]+", " ", l).strip() for l in text.split("\n")]
        lines = [l for l in lines if l]
        if lines:
            chapters.append("\n".join(lines))
    return "\n".join(chapters)


def extract_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data) or "null")
    except Exception:
        return ""
    if not isinstance(nb, dict) or not isinstance(nb.get("cells"), list):
        return ""
    parts = []
    for c in nb["cells"]:
        if not isinstance(c, dict):
            return ""
        if c.get("cell_type") != "markdown":
            continue
        s = c.get("source", "")
        if isinstance(s, list):
            if not all(isinstance(x, str) for x in s):
                return ""
            s = "".join(s)
        if not isinstance(s, str):
            return ""
        if s.strip():
            parts.append(s)
    return "\n\n".join(parts)


def load_prose(path):
    """Return extracted prose for path (None means stdin)."""
    if path is None:
        data = sys.stdin.buffer.read()
        return decode_bytes(data)
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, "rb") as f:
            data = f.read()
    except Exception as e:
        raise Fail("cannot read input: %s" % (getattr(e, "strerror", None) or e))
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except Exception:
            raise Fail("cannot read input: not a readable zip archive: %s" % path)
        try:
            if ext in (".docx", ".docm"):
                t = extract_docx(z)
            elif ext in (".pptx", ".pptm"):
                t = extract_pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = extract_xlsx(z)
            elif ext == ".epub":
                t = extract_epub(z)
            else:
                t = extract_odf(z)
        except Exception:
            t = ""
        return t.strip()
    if ext in NB_EXT:
        return extract_ipynb(data).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(data)


# --------------------------------------------------------------------------
# character layer
# --------------------------------------------------------------------------

LOOK = {}


def _add(src, dst):
    for i, ch in enumerate(src):
        LOOK[ch] = dst[i]


_add("асԁеһіјոорѕսѵԝхуօ",
     "acdehijnopsuvwxyo")
_add("АВСЕНІЈКМОРЅТХУЗ",
     "ABCEHIJKMOPSTXYZ")
_add("οναρυχι",
     "ovapuxi")
_add("ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ",
     "ABEZHIKMNOPTYX")
_add("ՍՕՆ", "SON")

NONASCII_SPECIAL = re.compile(r"[^\x20-\x7e\t\n\r]")
LOOK_RE = re.compile("[" + "".join(LOOK) + "]")

IGN_RANGES = [(0xE0000, 0xE0FFF), (0xFE00, 0xFE0F), (0xE0100, 0xE01EF), (0x034F, 0x034F),
              (0x115F, 0x1160), (0x17B4, 0x17B5), (0x180B, 0x180D), (0x180F, 0x180F),
              (0x3164, 0x3164), (0xFFA0, 0xFFA0)]
VISIBLE_CF = {0x600, 0x601, 0x602, 0x603, 0x604, 0x605, 0x6DD, 0x70F, 0x8E2, 0x110BD, 0x110CD}
BIDI = set([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
            0x2066, 0x2067, 0x2068, 0x2069])
NOSPACE = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF), (0x31F0, 0x31FF),
           (0xFF66, 0xFF9F), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF)]
JOINING = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF),
           (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF)]
MONGOLIAN = (0x1800, 0x18AF)


def in_rng(o, rngs):
    for a, b in rngs:
        if a <= o <= b:
            return True
    return False


def is_symbolic(ch):
    o = ord(ch)
    if o >= 0x1F000 or 0x2190 <= o <= 0x2BFF or 0x2600 <= o <= 0x27BF:
        return True
    return unicodedata.category(ch) in ("So", "Sk", "Sm", "Sc")


def is_invisible_base(ch):
    o = ord(ch)
    if o in (9, 10, 13):
        return False
    if o < 128:
        return o < 32 or o == 127
    if o in VISIBLE_CF:
        return False
    c = unicodedata.category(ch)
    if c in ("Cc", "Cf"):
        return True
    return in_rng(o, IGN_RANGES)


def space_replacement(ch, prev, nxt):
    """Return None if ch is a standard/kept space, else replacement string."""
    o = ord(ch)
    if ch == " " or o < 128:
        return None
    if o in (0x2028, 0x2029):
        return "\n"
    if unicodedata.category(ch) != "Zs":
        return None
    if o in (0xA0, 0x202F):
        if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
            return None
        if nxt and nxt in ":;!?»›%€":
            return None
        if prev and prev in "«‹":
            return None
    return " "


def scan_chars(text):
    """Return (invisible_positions:set, space_map:dict, fold_map:dict, homoglyph_tokens:list)."""
    invis = set()
    spaces = {}
    cand = [m.start() for m in NONASCII_SPECIAL.finditer(text)]
    if not cand:
        return invis, spaces, {}, []
    has_rtl = False
    for i in cand:
        if in_rng(ord(text[i]), RTL):
            has_rtl = True
            break
    n = len(text)
    # emoji tag sequences
    kept_tags = set()
    for i in cand:
        if text[i] == "\U0001F3F4":
            j = i + 1
            while j < n and 0xE0020 <= ord(text[j]) <= 0xE007E:
                j += 1
            if j > i + 1 and j < n and ord(text[j]) == 0xE007F:
                kept_tags.update(range(i + 1, j + 1))
    for i in cand:
        ch = text[i]
        o = ord(ch)
        prev = text[i - 1] if i > 0 else ""
        nxt = text[i + 1] if i + 1 < n else ""
        if is_invisible_base(ch):
            keep = False
            if i in kept_tags:
                keep = True
            elif o == 0x200B:
                keep = bool((prev and in_rng(ord(prev), NOSPACE)) or (nxt and in_rng(ord(nxt), NOSPACE)))
            elif o == 0xAD:
                keep = bool(prev and nxt and prev.isalpha() and nxt.isalpha())
            elif o in BIDI:
                keep = has_rtl
            elif 0x180B <= o <= 0x180F:
                keep = bool(prev and MONGOLIAN[0] <= ord(prev) <= MONGOLIAN[1])
            elif o in (0x17B4, 0x17B5):
                keep = bool((prev and 0x1780 <= ord(prev) <= 0x17FF) or (nxt and 0x1780 <= ord(nxt) <= 0x17FF))
            elif o in (0x200C, 0x200D):
                keep = False
                for nb in (prev, nxt):
                    if nb and ((in_rng(ord(nb), JOINING) and nb.isalpha()) or is_symbolic(nb)):
                        keep = True
            elif 0xE0100 <= o <= 0xE01EF:
                keep = bool(prev and in_rng(ord(prev), CJK))
            elif 0xFE00 <= o <= 0xFE0F:
                keep = bool(prev and (is_symbolic(prev) or in_rng(ord(prev), CJK))) or \
                    bool(nxt and ord(nxt) == 0x20E3)
            if not keep:
                invis.add(i)
            continue
        rep = space_replacement(ch, prev, nxt)
        if rep is not None:
            spaces[i] = rep
    fold = {}
    toks = []
    last_end = -1
    for m in LOOK_RE.finditer(text):
        p = m.start()
        if p < last_end:
            continue
        a = p
        while a > 0 and not text[a - 1].isspace():
            a -= 1
        b = p
        while b < n and not text[b].isspace():
            b += 1
        last_end = b
        tok = text[a:b]
        res = fold_token(tok)
        if res is not None:
            toks.append(tok)
            for k, v in res.items():
                fold[a + k] = v
    return invis, spaces, fold, toks


def fold_token(tok):
    """If tok meets the homoglyph condition return {offset: ascii}; else None."""
    runs = []
    cur = []
    for k, ch in enumerate(tok):
        if ch.isalpha():
            cur.append(k)
        else:
            if cur:
                runs.append(cur)
            cur = []
    if cur:
        runs.append(cur)
    for k, ch in enumerate(tok):
        if ord(ch) > 127 and ch.isalpha() and ch not in LOOK:
            return None
    res = {}
    for r in runs:
        asc = any(ord(tok[k]) < 128 for k in r)
        looks = [k for k in r if tok[k] in LOOK]
        if asc and looks:
            for k in looks:
                res[k] = LOOK[tok[k]]
    return res or None


def cleanup(text):
    invis, spaces, fold, _ = scan_chars(text)
    out = []
    for i, ch in enumerate(text):
        if i in invis:
            continue
        if i in spaces:
            out.append(spaces[i])
        elif i in fold:
            out.append(fold[i])
        else:
            out.append(ch)
    s = "".join(out)
    ended_lf = text.endswith("\n") or text.endswith(" ") or text.endswith(" ")
    eol = "\r\n" if text.endswith("\r\n") else "\n"
    lines = re.split(r"(\r\n|\n|\r)", s)
    # lines: content, sep, content, sep, ...
    res = []
    for k in range(0, len(lines), 2):
        content = lines[k].rstrip(" \t")
        sep = lines[k + 1] if k + 1 < len(lines) else ""
        res.append((content, sep))
    # drop leading blank lines
    while res and res[0][0].strip() == "" and res[0][1] != "":
        res.pop(0)
    s = "".join(c + sp for c, sp in res)
    s = s.rstrip(" \t\r\n\f\v")
    s = s.rstrip()
    if ended_lf and s:
        s += eol
    return s


# --------------------------------------------------------------------------
# catalogue
# --------------------------------------------------------------------------

TITLES = {
    1: "AI vocabulary", 2: "Model-dialect vocabulary", 3: "Promotional language",
    4: "Hyphenated word-pair overuse", 5: "\"Simple yet X\" cliche", 6: "Stacked adjective chains",
    8: "Synonym cycling", 10: "Significance inflation", 11: "Notability name-dropping",
    12: "Vague attributions", 13: "Article titles as proper nouns",
    14: "Conservation / ecosystem padding", 15: "False ranges", 16: "Superficial -ing tail clauses",
    18: "\"Not X, just Y\" corrections", 19: "Filler phrases", 20: "Empty pivot phrases",
    21: "Outcome speculation tails", 22: "Persuasive authority tropes", 23: "Editorial interjections",
    24: "Self-thoroughness phrases", 25: "Question-answer rhetorical pattern",
    26: "\"Concrete evidence\" defense phrase", 27: "Compulsive intro hooks",
    30: "Diff-anchored writing", 31: "Signposting and announcements", 32: "Cataloguing lead-ins",
    33: "Inline-header vertical lists", 34: "Mid-essay bullet injection", 35: "Fragmented headers",
    36: "Formulaic challenges sections", 37: "Transition cluster overuse",
    38: "Compulsive conclusion phrases", 39: "Generic positive conclusions",
    40: "Sentence-length monotony", 41: "Mechanical sentence-length alternation",
    42: "Opener repetition", 44: "Uniform paragraph length", 46: "Semicolon and parenthesis underuse",
    47: "Chatbot artifacts", 48: "Sycophantic / servile tone", 50: "Knowledge-cutoff disclaimers",
    51: "Copula avoidance", 54: "Excessive hedging", 55: "Contraction absence",
    56: "Boldface overuse", 57: "Emojis", 58: "Em-dash overuse", 59: "Title case in headings",
    60: "Curly quotation marks", 61: "Hyphen-for-en-dash in ranges",
    62: "Invisible / zero-width characters", 63: "Placeholder / Mad-Libs text",
    64: "Chatbot reference-markup leak", 65: "AI tracking params",
    66: "Homoglyph / mixed-script confusables", 67: "Non-standard spaces",
    68: "Trailing / stray whitespace", 69: "Canonical marketing-slop phrases",
    70: "Decorative horizontal rules", 71: "Degenerate repetition",
}
LABEL_17A = "Negative parallelism (it's not just X, it's Y)"
LABEL_17B = "Tailing negation (no X, no Y)"

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, "17p"}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 44}
EARLY = set(range(1, 40)) | set(range(47, 52)) | {69}

WEIGHT = {1: 14, 2: 9, 3: 11, 5: 9, 6: 7, 8: 7, 10: 12, 11: 8, 12: 9, 13: 22, 14: 8, 15: 8, 16: 9,
          17: 8, 18: 9, 20: 9, 21: 8, 23: 8, 24: 8, 25: 7, 26: 7, 27: 10, 30: 7, 31: 9, 32: 7,
          33: 7, 34: 6, 35: 6, 36: 8, 37: 9, 38: 8, 39: 8, 40: 6, 44: 5, 47: 24, 48: 24, 50: 22,
          51: 8, 56: 4, 57: 5, 59: 4, 62: 22, 63: 24, 64: 26, 65: 26, 66: 22, 67: 6, 69: 11,
          70: 5, 71: 14}


def R(p, flags=re.I):
    return re.compile(p, flags)


LEX = []  # (key, num, slug, [compiled])


def lex(num, slug, pats, flags=re.I):
    LEX.append((num, slug, [re.compile(p, flags) for p in pats]))


lex(1, "ai_vocabulary", [
    r"\b(?:additionally|aligns? with|aligned with|aligning with|crucial(?:ly)?|delv(?:e|es|ed|ing)|"
    r"tapestr(?:y|ies)|pivotal(?:ly)?|vibrant|meticulous(?:ly)?|testaments?|underscor(?:e|es|ed|ing)|"
    r"intricate(?:ly)?|intricacies|intricacy|interplay|garner(?:s|ed|ing)?|bolster(?:s|ed|ing)?|"
    r"foster(?:s|ed|ing)?|showcas(?:e|es|ed|ing)|emphasi[sz](?:e|es|ed|ing)|enduring|"
    r"enhanc(?:e|es|ed|ing)|leverag(?:e|es|ed|ing)|utili[sz](?:e|es|ed|ing)|"
    r"facilitat(?:e|es|ed|ing)|encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?|holistic(?:ally)?|"
    r"paradigms?|transformative|unprecedented|myriad|plethora|robust(?:ness)?|seamless(?:ly)?|"
    r"navigat(?:e|es|ed|ing)|embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|landscapes?|journeys?|realms?|"
    r"multifaceted|elevat(?:e|es|ed|ing)|empower(?:s|ed|ing|ment)?|unlock(?:s|ed|ing)?|"
    r"captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic))\b"])
lex(2, "model_dialect", [
    r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly|"
    r"quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)|"
    r"resonates? deeply|game[- ]chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|skyrocket(?:s|ed|ing)?|"
    r"turbocharg(?:e|es|ed|ing)|revolutioni[sz](?:e|es|ed|ing)|doubl(?:e|es|ed|ing) down on|"
    r"div(?:e|es|ed|ing) deep(?:er)? into|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)|"
    r"tak(?:e|es|ing|en) [^.!?\n]{1,30}? to the next level)\b"])
lex(3, "promotional", [
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|"
    r"rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|"
    r"leading (?!to\b|up\b|off\b|the\b|a\b|an\b)|esteemed organi[sz]ation|valuable asset|"
    r"passion for excellence|proven track record|results-oriented|wealth of experience|dynamic team|"
    r"fast-paced environment|deeply passionate|perfectly situated|close-knit team|tight-knit team|"
    r"i am excited to (?:apply|bring)|uniquely positioned to)"])
lex(5, "simple_yet", [r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"])
lex(10, "significance_inflation", [
    r"\b(?:stands?|stood|serv(?:es|ed|e|ing)|standing) as (?:a |an )?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor|highlight)(?:es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects? a broader (?:trend|shift|pattern)\b",
    r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b",
    r"\bsymboli[sz]es\b", r"\bsets? the stage for\b", r"\bleft an indelible mark\b",
    r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b",
    r"\bhas (?:shaped|sparked)\b", r"\bhas come to (?:define|symboli[sz]e)\b"])
lex(12, "vague_attributions", [
    r"\bexperts (?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry (?:reports|observers|analysts)\b", r"\bobservers have (?:cited|noted)\b",
    r"\bsome critics argue\b", r"\bresearchers have found\b", r"\bstudies suggest\b",
    r"\bit is widely believed\b"])
lex(13, "article_title", [
    r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [A-Z][\w'&.-]*(?: [\w'&.-]+){0,8}? (?:is|are) (?:a|an|the)\b"], 0)
lex(14, "conservation_padding", [
    r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b",
    r"\bconservation efforts are (?:underway|ongoing|in place)\b",
    r"\bserves? as an indicator species\b", r"\bcontributes? to biodiversity\b"])
lex(15, "false_ranges", [
    r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b"])
lex(16, "ing_tails", [
    r",\s+(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|fostering|"
    r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|"
    r"reinforcing|leveraging|aligning|embodying|exemplifying|epitomi[sz]ing)\b"])
lex(18, "not_x_just_y", [
    r"\b(?:no|not) \w+, (?:just|only|simply) \w+",
    r"\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely) (?:(?:a|an|the) )?\w+(?:,|\s*[—–-]{1,2})\s*(?:it's|it is|it was|they're|they are|they were|that's|but)\b"])
lex(20, "empty_pivots", [
    r"\bit(?:'s| is) worth (?:noting|mentioning) that\b", r"\bit bears (?:noting|mentioning) that\b",
    r"\bone thing to (?:consider|keep in mind) is\b", r"\bit is interesting to note that\b",
    r"\ba key consideration is\b", r"\ba point to highlight is\b"])
lex(21, "speculation_tails", [
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|"
    r"reshaping our understanding of|paving the way for|signaling a shift toward)\b"])
lex(23, "editorial_interjections", [
    r"\bit(?:'s| is) important to (?:remember|note|understand|recogni[sz]e)\b",
    r"\bone must note that\b", r"\bit is worth pointing out\b", r"\bit cannot be overstated that\b",
    r"\bit must be emphasi[sz]ed that\b"])
lex(24, "self_thoroughness", [
    r"\bthis comprehensive (?:guide|overview|analysis)\b", r"\bthis in-depth (?:analysis|look|examination)\b",
    r"\bthis complete (?:guide|overview)\b", r"\ba thorough examination of\b",
    r"\beverything you need to know about\b"])
lex(26, "concrete_evidence", [
    r"\bwithout concrete evidence\b", r"\bdo you have concrete evidence\b",
    r"\bi (?:would )?need concrete (?:evidence|examples) to\b", r"\babsent concrete proof\b",
    r"\bprovide concrete evidence\b"])
lex(27, "intro_hooks", [
    r"\bin today's (?:[\w-]+ ){0,2}?(?:world|landscape|environment|market)\b", r"\bin a world where\b",
    r"\bin an era of\b", r"\bin recent years,", r"\bmore than ever before\b",
    r"\bwe live in a (?:time|world) when\b", r"\b(?:great|exciting|big) news[!:]",
    r"\bever (?:wanted|wondered|dreamed|wished) to\b[^.!?\n]*\?",
    r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b"])
lex(30, "diff_anchored", [
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
    r"\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b",
    r"\bpreviously\b[^.!?\n]{0,200}?\bnow\b", r"\b(?:wasn't|weren't) there before\b",
    r"\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"])
lex(31, "signposting", [
    r"\blet's (?:dive|delve|explore)\b", r"\blet's break (?:this|it) down\b",
    r"\bhere's what you need to know\b", r"\bwithout further ado\b", r"\bnow let's look at\b",
    r"\bbuckle up\b", r"\bstay with me\b", r"\b(?:are you )?ready to dive in\b"])
lex(32, "cataloguing_lead_ins", [
    r"\b(?:used|uses|using|employs?|employed|relied on|relies on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+",
    r"(?:^|[.!?]\s+)these (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help)s? (?:information|insight|insights|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b"])
lex(36, "formulaic_challenges", [
    r"\bdespite (?:these|its|the) (?:\w+ )?(?:challenges|obstacles)\b",
    r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b", r"\bcontinues to thrive\b",
    r"\btypical of (?:emerging|urban|modern)\b", r"\bfaces (?:several|many|numerous) challenges\b"])
lex(38, "compulsive_conclusions", [
    r"^[ \t>*_#-]*(?:in conclusion|overall|in summary|to summari[sz]e|to conclude|all in all|in essence|ultimately)\b"], re.I | re.M)
lex(39, "positive_conclusions", [
    r"\bthe future looks bright\b", r"\bexciting times lie ahead\b", r"\bjourney toward excellence\b",
    r"\bstep in the right direction\b", r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40}?)? (?:is|looks|remains) bright\b",
    r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b"])
lex(19, "filler_phrases", [
    r"\bin order to\b", r"\bdue to the fact that\b", r"\bat this point in time\b", r"\bin the event that\b",
    r"\bhas the ability to\b", r"\bit is important to note that\b", r"\bit should be mentioned that\b",
    r"\bneedless to say\b"])
lex(22, "authority_tropes", [
    r"\bhere's the thing\b", r"\bmake no mistake\b", r"\bthe truth is\b", r"\blet's be honest\b",
    r"\bthe simple fact is\b", r"\bat its core\b", r"\bwhat really matters\b", r"\bmore than anything\b",
    r"\bat the end of the day\b", r"\bthe bottom line is\b", r"\bin reality\b", r"\bfundamentally,",
    r"\bthe real question is\b", r"\bthe heart of the matter\b", r"\bthe deeper issue\b",
    r"\bwhen you get down to it\b", r"\bwhen all is said and done\b"])
lex(47, "chatbot_artifacts", [
    r"\bi hope this helps\b", r"\b(?:certainly|of course)!", r"\blet me know if you\b",
    r"\bwould you like me to\b", r"\bfeel free to (?:ask|reach out)\b", r"\bhappy to help[.!]",
    r"\b(?:here|below) is (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere (?:are|'s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b",
    r"\bhere(?: is|'s) a draft\b", r"\bdepending on the (?:vibe|tone|style)\b",
    r"\bi hope (?:this email )?finds you well\b",
    r"\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b",
    r"\bto (?:answer|address) your question\b", r"\bin (?:response|answer) to your question\b",
    r"\byour question (?:about|regarding|concerning)\b", r"\bas (?:you )?(?:requested|asked), here\b",
    r"\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b"])
lex(48, "sycophantic", [
    r"\byou(?:'re| are) absolutely right\b", r"\b(?:great question|excellent point)[!.,]",
    r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\b",
    r"\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"])
lex(50, "knowledge_cutoff", [
    r"\bas of my (?:last )?(?:training|knowledge)\b", r"\bup to my (?:last )?(?:training|knowledge)\b",
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b",
    r"\bbased on (?:the )?available information\b", r"\bas of my (?:knowledge )?cutoff\b",
    r"\bmaintains a low profile\b", r"\bkeeps (?:his|her|their) personal life private\b"])
lex(51, "copula_avoidance", [
    r"\b(?:serves?|served|serving|stands?|stood|standing|functions?|functioned|functioning|acts?|acted|acting) as\b",
    r"\b(?:represents|marks) (?:a|the)\b", r"\bboasts?\b",
    r"\bfeatures (?:an?|the|\d+|several|many|numerous|multiple|a number|over|more)\b",
    r"\boffers a\b", r"\brefers to\b"])
lex(69, "marketing_slop", [
    r"\bunlocking (?:its |their |your )?full potential\b", r"\bnavigating the complexities\b",
    r"\ba testament to the (?:power|importance)\b", r"\bstaying ahead of the curve\b",
    r"\bturning challenges into opportunities\b", r"\btaking (?:\w+ ){1,3}to the next level\b",
    r"\bharnessing the power of\b", r"\bpaving the way for\b", r"\bsaying goodbye to\b",
    r"\bimagining a world where\b", r"\bunleash(?:ing)? the (?:power|potential)\b",
    r"\bin the ever-evolving\b", r"\bgame-changing solution\b"])
lex(11, "notability", [
    r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) (?:the )?[A-Z][\w&.'-]*(?: [A-Z][\w&.'-]*)*(?:, (?:and )?| and )(?:the )?[A-Z]",
    r"\b\d[\d,.]*[kKmM]?\+? (?:followers|subscribers)\b",
    r"\b(?:strong|active|robust|significant|notable|growing|solid) (?:online|digital|social[- ]media) presence\b",
    r"\bwidely covered\b", r"\bindependent coverage\b"], 0)
lex(4, "hyphenated_pairs", [
    r"\b(?:cutting-edge|state-of-the-art|best-in-class|world-class|data-driven|results-driven|customer-centric|"
    r"forward-thinking|detail-oriented|results-oriented|fast-paced|game-changing|mission-critical|"
    r"next-generation|end-to-end|high-quality|top-notch|well-rounded|self-starter|team-player|"
    r"win-win|value-added|ground-breaking|groundbreaking|thought-provoking|ever-evolving|ever-changing|"
    r"hands-on|time-tested|tried-and-true|one-of-a-kind|full-service|cross-functional)\b"])

# phrases for 17
P17A = [re.compile(p, re.I) for p in [
    r"\bit's not (?:just|merely) (?:about|an?)\b",
    r"\bnot only\b[^.!?]{0,40}?\bbut\b",
    r"\bdoesn't just\b[^,.]{0,40}?\bit\b"]]
P17B = re.compile(r",\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", re.I)

SYN = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "organisation", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]
SYN_RE = []
for cl in SYN:
    SYN_RE.append([(w, re.compile(r"\b%ss?\b" % re.escape(w) if not w.endswith("y") else
                                  r"\b(?:%sy|%sies)\b" % (w[:-1], w[:-1]), re.I)) for w in cl])
    if cl[0] == "analysis":
        pass

IMPERATIVES = ("install join grab download try discover experience escape transform reclaim unlock "
               "elevate boost say imagine explore meet introducing upgrade claim unleash supercharge "
               "level stop start").split()
IMP_RE = re.compile(r"^(?:%s)\b" % "|".join(IMPERATIVES), re.I)

TRANSITIONS = re.compile(r"(?:^|[.!?][\"')\]]*[ \t]+)(Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b", re.M)

ADJ_SUFFIX = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial",
              "ary", "ory", "ish")
STOCK_ADJ = set("""powerful seamless robust innovative dynamic modern scalable flexible elegant intuitive
comprehensive efficient reliable secure fast rich bold bright vibrant engaging stunning cutting-edge
beautiful simple clean smart rapid versatile sleek lightweight seamless""".split())

WORD_RE = re.compile(r"[^\W_](?:[^\W_]|['’-])*")
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⭐⭕⌚⌛"
                      "⏩-⏳✅❌✨❤]")
CURLY_RE = re.compile("[‘’“”]")


def words_of(s):
    return WORD_RE.findall(s)


# --------------------------------------------------------------------------
# structural masking
# --------------------------------------------------------------------------

def mask_markdown(view):
    """Blank (same length) code, quotes, tables, badges, front matter."""
    lines = view.split("\n")
    n = len(lines)
    mask = [False] * n
    # front matter
    if lines and lines[0].strip() == "---":
        for j in range(1, n):
            if lines[j].strip() in ("---", "..."):
                for k in range(0, j + 1):
                    mask[k] = True
                break
    i = 0
    fence_re = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
    prev_blank = True
    prev_code = False
    while i < n:
        if mask[i]:
            i += 1
            prev_blank = False
            continue
        ln = lines[i]
        m = fence_re.match(ln)
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            ch = m.group(1)[0]
            ln_len = len(m.group(1))
            mask[i] = True
            j = i + 1
            while j < n:
                mask[j] = True
                mc = re.match(r"^ {0,3}(%s{%d,})\s*$" % (re.escape(ch), ln_len), lines[j])
                if mc:
                    break
                j += 1
            i = j + 1
            prev_blank = False
            prev_code = True
            continue
        if ln.strip() == "":
            prev_blank = True
            i += 1
            continue
        if (ln.startswith("    ") or ln.startswith("\t")) and (prev_blank or prev_code):
            # indented code only when it cannot continue a paragraph
            mask[i] = True
            prev_blank = False
            prev_code = True
            i += 1
            continue
        prev_code = False
        prev_blank = False
        i += 1
    # blank lines between code lines stay blank (no effect)
    # blockquote runs
    i = 0
    while i < n:
        if not mask[i] and re.match(r"^ {0,3}>", lines[i]):
            j = i
            while j < n and not mask[j] and re.match(r"^ {0,3}>", lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1
    badge = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
    for i in range(n):
        if mask[i]:
            continue
        s = lines[i].strip()
        if not s:
            continue
        if s.startswith("|") or (s.count("|") >= 2 and s.endswith("|")) or \
                (re.match(r"^[:\-\s|]+$", s) and "|" in s and "-" in s):
            mask[i] = True
        elif badge.match(lines[i]):
            mask[i] = True
    out = [(" " * len(l) if mask[k] else l) for k, l in enumerate(lines)]
    res = "\n".join(out)
    # inline code spans
    def blank(m):
        t = m.group(0)
        if "\n\n" in t:
            return t
        return re.sub(r"[^\n]", " ", t)
    if "`" in res:
        res = re.sub(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", blank, res, flags=re.S)
    return res


# --------------------------------------------------------------------------
# scan
# --------------------------------------------------------------------------

def cv(vals):
    m = sum(vals) / float(len(vals))
    if m == 0:
        return 99.0
    var = sum((v - m) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / m


SENT_SPLIT = re.compile(r"(?<=[.!?…])[\"')\]”’]*\s+")


def split_sentences(par):
    return [s for s in SENT_SPLIT.split(par) if words_of(s)]


LIST_RE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
HEAD_RE = re.compile(r"^\s{0,3}#{1,6}\s+(.*)$")


def paragraphs_of(mview):
    paras = []
    cur = []
    for ln in mview.split("\n"):
        if ln.strip() == "":
            if cur:
                paras.append(cur)
                cur = []
        else:
            cur.append(ln)
    if cur:
        paras.append(cur)
    return paras


class Scan(object):
    pass


def build_view(raw):
    invis, spaces, fold, toks = scan_chars(raw)
    out = []
    idx = []
    n = len(raw)
    i = 0
    while i < n:
        ch = raw[i]
        if i in invis:
            i += 1
            continue
        if ch == "\r":
            if i + 1 < n and raw[i + 1] == "\n":
                i += 1
                continue
            out.append("\n")
            idx.append(i)
            i += 1
            continue
        if i in spaces:
            r = spaces[i]
            out.append(r)
        elif i in fold:
            out.append(fold[i])
        elif ch in (" ", " "):
            out.append(" ")
        else:
            out.append(ch)
        idx.append(i)
        i += 1
    return "".join(out), idx, invis, spaces, toks


def excerpt(raw, idx, vs, ve, width=28):
    a = idx[vs]
    b = idx[min(ve, len(idx)) - 1] + 1
    s = max(0, a - width)
    e = min(len(raw), b + width)
    # stay within the line
    ln = raw.rfind("\n", s, a)
    if ln != -1:
        s = ln + 1
    ln = raw.find("\n", b, e)
    if ln != -1:
        e = ln
    ln = raw.find("\r", b, e)
    if ln != -1:
        e = ln
    pre = "…" if s > 0 else ""
    post = "…" if e < len(raw) else ""
    return pre + raw[s:e] + post


def scan(raw, truncated_flag=False, want_sentences=False):
    """Return dict with findings, words, sentences for a window of text."""
    view, idx, invis, spaces, homo_toks = build_view(raw)
    mview = mask_markdown(view)
    m2 = mview.translate({0x2019: "'", 0x2018: "'", 0x201c: '"', 0x201d: '"'})
    findings = {}  # key -> (num, slug, label, count, samples, moving)

    def add(num, slug, label, count, samples, advice=False, adv_key=None):
        if count <= 0:
            return
        findings[(num, slug)] = [label, count, samples[:3], not advice]

    def run_lex():
        for num, slug, pats in LEX:
            cnt = 0
            samples = []
            for p in pats:
                for m in p.finditer(m2):
                    cnt += 1
                    if len(samples) < 3:
                        if num == 1:
                            samples.append(excerpt(raw, idx, m.start(), m.end()))
                        else:
                            samples.append(m.group(0).strip()[:80])
            if num == 2 and cnt < 2:
                continue
            if num == 3:
                imp = 0
                for p in paragraphs_of(m2):
                    for s in split_sentences(" ".join(p)):
                        if IMP_RE.match(s.strip()):
                            imp += 1
                if imp >= 3:
                    cnt += 1
                    samples.append("marketing imperatives x%d" % imp)
            if cnt:
                add(num, slug, TITLES[num], cnt, samples, advice=(num in ADVICE))
    run_lex()

    # 17
    c = 0
    sm = []
    for p in P17A:
        for m in p.finditer(m2):
            c += 1
            sm.append(m.group(0))
    add(17, "negative_parallelism", LABEL_17A, c, sm, advice=True)
    c = 0
    sm = []
    for m in P17B.finditer(m2):
        c += 1
        sm.append(m.group(0).lstrip(", "))
    add(17, "tailing_negation", LABEL_17B, c, sm)

    paras = paragraphs_of(mview)
    paras2 = paragraphs_of(m2)
    all_words = words_of(mview)
    nwords = len(all_words)

    # 6 stacked adjective chains
    c = 0
    sm = []
    for m in re.finditer(r"\b[a-z][a-z-]{1,30}(?:,\s+(?:and\s+)?[a-z][a-z-]{1,30}){3,}", m2, re.I):
        ws = re.findall(r"[A-Za-z-]+", m.group(0))
        ws = [w.lower() for w in ws if w.lower() != "and"]
        if len(ws) >= 4 and any(w in STOCK_ADJ or w.endswith(ADJ_SUFFIX) for w in ws[:-1]) :
            c += 1
            sm.append(m.group(0))
    add(6, "adjective_chains", TITLES[6], c, sm)

    # 8 synonym cycling
    c = 0
    sm = []
    for cl in SYN_RE:
        used = [w for w, rx in cl if rx.search(m2)]
        if len(used) >= 3:
            c += 1
            sm.append("/".join(used))
    add(8, "synonym_cycling", TITLES[8], c, sm)

    # sentences
    sents_by_par = []
    for p in paras2:
        lines = [l for l in p if not HEAD_RE.match(l)]
        if not lines:
            continue
        if all(LIST_RE.match(l) for l in lines):
            txt_lines = [LIST_RE.sub("", l) for l in lines]
            sents_by_par.append([s for l in txt_lines for s in split_sentences(l)])
            continue
        txt = " ".join(lines)
        sents_by_par.append(split_sentences(txt))
    sentences = [s for ss in sents_by_par for s in ss]
    swc = [len(words_of(s)) for s in sentences]

    # 25 Q&A
    c = 0
    sm = []
    qa = re.compile(r"(?:^|(?<=[.!?\n])\s*)((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|May|Might|Must|Have|Has|Had)\b[^.?!\n]{0,100}\?)[ \t]+(?:yes|no|absolutely|never|maybe|probably|always|definitely|certainly|sometimes|nope|yep)[.!](?=\s|$)", re.I | re.M)
    for m in qa.finditer(m2):
        c += 1
        sm.append(m.group(0).strip())
    add(25, "question_answer", TITLES[25], c, sm)

    # 33 inline-header lists
    c = 0
    sm = []
    for m in re.finditer(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", m2, re.M):
        c += 1
        sm.append(m.group(0).strip())
    add(33, "inline_header_lists", TITLES[33], c, sm)

    # 34 mid-essay bullets
    has_heading = any(HEAD_RE.match(l) for l in m2.split("\n"))
    if not has_heading:
        listp = 0
        prose = 0
        for p in paras2:
            if all(LIST_RE.match(l) for l in p):
                listp += 1
            elif not any(LIST_RE.match(l) for l in p) and len(words_of(" ".join(p))) >= 5:
                prose += 1
        if listp >= 1 and prose >= 2:
            add(34, "bullet_injection", TITLES[34], listp, ["bulleted paragraph between prose paragraphs"])

    # 35 fragmented headers
    c = 0
    sm = []
    ls = m2.split("\n")
    for i, l in enumerate(ls):
        hm = HEAD_RE.match(l)
        if not hm:
            continue
        j = i + 1
        while j < len(ls) and ls[j].strip() == "":
            j += 1
        if j >= len(ls):
            continue
        nx = ls[j].strip()
        if HEAD_RE.match(ls[j]) or LIST_RE.match(ls[j]) or nx.startswith("|") or not nx:
            continue
        nw = words_of(nx)
        if 1 <= len(nw) <= 4:
            hw = set(w.lower() for w in words_of(hm.group(1)) if len(w) > 2)
            if any(w.lower() in hw for w in nw):
                c += 1
                sm.append(l.strip() + " / " + nx)
    add(35, "fragmented_headers", TITLES[35], c, sm)

    # 37 transition clusters
    c = 0
    sm = []
    for p in paras2:
        t = TRANSITIONS.findall("\n".join(p))
        if len(t) >= 2:
            c += 1
            sm.append(", ".join(t[:3]))
    add(37, "transition_clusters", TITLES[37], c, sm)

    # 40 monotony
    if len(swc) >= 3 and cv(swc) < 0.35:
        add(40, "sentence_monotony", TITLES[40], 1, ["%d sentences of near-equal length" % len(swc)])
    # 41 alternation (advice)
    best = 0
    run = 1
    for i in range(1, len(swc) - 1):
        pass
    if len(swc) >= 6:
        diffs = [swc[i + 1] - swc[i] for i in range(len(swc) - 1)]
        good = []
        for i, d in enumerate(diffs):
            big = abs(d) >= max(4, 0.4 * max(swc[i], swc[i + 1]))
            good.append(big)
        run = 0
        for i in range(len(diffs)):
            if good[i] and (i == 0 or (good[i - 1] and (diffs[i] > 0) != (diffs[i - 1] > 0))):
                run += 1
            else:
                run = 1 if good[i] else 0
            best = max(best, run + 1 if run else 0)
        if best >= 6:
            add(41, "sentence_alternation", TITLES[41], 1, ["alternating sentence lengths"], advice=True)
    # 42 opener repetition (advice)
    c = 0
    for ss in sents_by_par:
        if len(ss) >= 3:
            ctr = {}
            for s in ss:
                w = [x.lower() for x in words_of(s)[:2]]
                if len(w) == 2:
                    ctr[tuple(w)] = ctr.get(tuple(w), 0) + 1
            if any(v >= 3 for v in ctr.values()):
                c += 1
    add(42, "opener_repetition", TITLES[42], c, ["repeated sentence openers"], advice=True)
    # 44 uniform paragraphs
    pw = []
    for p in paras2:
        if all(HEAD_RE.match(l) for l in p):
            continue
        pw.append(len(words_of(" ".join(p))))
    if len(pw) >= 4 and cv(pw) < 0.4:
        add(44, "uniform_paragraphs", TITLES[44], 1, ["%d paragraphs of similar length" % len(pw)])

    # 46 semicolons (advice)
    if nwords >= 300 and ";" not in mview and mview.count("(") <= 1:
        add(46, "semicolon_underuse", TITLES[46], 1, ["no semicolons, almost no parentheticals"], advice=True)
    # 54 hedges (advice)
    hedge = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
    c = 0
    for ss in sents_by_par:
        for s in ss:
            if len(hedge.findall(s)) >= 2:
                c += 1
    add(54, "hedge_stacking", TITLES[54], c, ["stacked hedges"], advice=True)
    # 55 contraction absence (advice)
    fp = sum(1 for w in all_words if w.lower() in ("i", "me", "my", "mine", "we", "our", "us", "i'm", "i've", "we're"))
    if nwords and fp / float(nwords) >= 0.02:
        full_forms = len(re.findall(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|can not|will not|would not|should not|could not|have not|has not|had not|it is|that is|there is|i am|we are|they are|you are|i have|we have|i will|we will|i would)\b", m2, re.I))
        contr = len(re.findall(r"\b\w+(?:n't|'re|'ve|'ll|'d|'m|'s)\b", m2, re.I))
        if full_forms >= 3 and full_forms > contr:
            add(55, "contraction_absence", TITLES[55], full_forms, ["written-out forms"], advice=True)

    # 56 boldface
    c = len(re.findall(r"\*\*[^*\n]+?\*\*", m2))
    add(56, "boldface", TITLES[56], c, re.findall(r"\*\*[^*\n]+?\*\*", m2)[:3])
    # 57 emoji
    em = EMOJI_RE.findall(mview)
    add(57, "emojis", TITLES[57], len(em), em[:3])
    # 58 em dash (advice)
    c = 0
    for p in paras:
        if "\n".join(p).count("—") >= 2:
            c += 1
    add(58, "em_dash", TITLES[58], c, ["two or more em dashes in a paragraph"], advice=True)
    # 59 title case headings
    small = set("a an the and or but nor of in on at to for with by from as vs via is are be so yet off up per into over".split())
    c = 0
    sm = []
    for l in ls:
        hm = HEAD_RE.match(l)
        if not hm:
            continue
        t = hm.group(1).strip().strip("#").strip()
        ws = t.split()
        if len(ws) < 3 or not t[:1].isalpha():
            continue
        letters = [ch for ch in t if ch.isalpha()]
        if all(ch.isupper() for ch in letters):
            continue
        major = [w for w in ws if w.lower().strip(".,:;!?") not in small]
        if len(major) >= 2 and all(w[:1].isupper() for w in major if w[:1].isalpha()) and \
                all(w[:1].isalpha() for w in major):
            c += 1
            sm.append(t)
    add(59, "title_case_headings", TITLES[59], c, sm)
    # 60 curly quotes (advice)
    cq = CURLY_RE.findall(mview)
    add(60, "curly_quotes", TITLES[60], len(cq), cq[:3], advice=True)
    # 61 year ranges (advice)
    yr = re.findall(r"\b(?:1[5-9]|20)\d\d-(?:1[5-9]|20)\d\d\b", m2)
    yr = [y for y in yr if int(y[:4]) < int(y[5:])]
    add(61, "year_range_hyphen", TITLES[61], len(yr), yr[:3], advice=True)

    # 62 invisible
    add(62, "invisible_chars", TITLES[62], len(invis),
        ["U+%04X" % ord(raw[i]) for i in sorted(invis)[:3]])
    # 63 placeholders
    c = 0
    sm = []
    for m in re.finditer(r"\[([^\[\]\n]{1,80})\](?![(\[])", m2):
        inner = m.group(1).strip()
        low = inner.lower()
        hit = False
        if re.match(r"(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b", low) or low in ("tbd", "tk", "todo"):
            hit = True
        elif re.search(r"\b(?:name|company|client|city|place|source|person|location|address)\b", low) and len(low.split()) <= 6:
            hit = True
        elif inner.isupper() and re.search(r"[A-Z]", inner):
            lett = re.sub(r"[^A-Z]", "", inner)
            if len(lett) >= 3 or "_" in inner or (" " in inner and len(lett) >= 2):
                hit = True
        if hit:
            c += 1
            sm.append(m.group(0))
    for m in re.finditer(r"\{\{[^{}\n]*\}\}", m2):
        c += 1
        sm.append(m.group(0))
    for m in re.finditer(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])", m2):
        c += 1
        sm.append(m.group(0))
    for m in re.finditer(r"lorem ipsum", m2, re.I):
        c += 1
        sm.append(m.group(0))
    add(63, "placeholder_text", TITLES[63], c, sm)
    # 64 reference markup
    c = 0
    sm = []
    for p in [r"\bcite(?:turn|start|nav)\w*", r"\boai_citation\w*", r"contentReference", r"navlist",
              r"【\d+†[^】\n]*】"]:
        for m in re.finditer(p, m2):
            c += 1
            sm.append(m.group(0))
    add(64, "reference_markup", TITLES[64], c, sm)
    # 65 tracking params
    c = 0
    sm = []
    doms = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
            "copilot.microsoft.com", "poe.com"}
    for m in re.finditer(r"utm_source=([A-Za-z0-9.-]+)", m2):
        host = m.group(1).rstrip(".-").lower()
        if host in doms:
            c += 1
            sm.append(m.group(0))
    add(65, "tracking_params", TITLES[65], c, sm)
    # 66 homoglyph, 67 spaces
    add(66, "homoglyphs", TITLES[66], len(homo_toks), homo_toks[:3])
    nsp = len(spaces)
    add(67, "nonstandard_spaces", TITLES[67], nsp, ["U+%04X" % ord(raw[i]) for i in sorted(spaces)[:3]])
    # 68 trailing whitespace (advice)
    c = 0
    rl = raw.split("\n")
    for k, l in enumerate(rl):
        l = l.rstrip("\r") if k < len(rl) - 1 else l
        if l[-1:] in (" ", "\t"):
            c += 1
    if raw.count("\n", len(raw.rstrip())) >= 2:
        c += 1
    if raw[:1].isspace():
        c += 1
    add(68, "trailing_whitespace", TITLES[68], c, ["trailing or stray whitespace"], advice=True)

    # 70 horizontal rules
    lines2 = view.split("\n")
    mlines = mview.split("\n")
    hr = 0
    hre = re.compile(r"^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$")
    for i, l in enumerate(mlines):
        if hre.match(l) and (i == 0 or mlines[i - 1].strip() == "" or l.strip()[0] != "-"):
            hr += 1
    if hr >= 3 and len(lines2) >= 24:
        add(70, "horizontal_rules", TITLES[70], hr, ["---"])
    # 71 degenerate repetition
    lw = [w.lower() for w in all_words]
    if len(lw) >= 12:
        grams = {}
        for i in range(len(lw) - 5):
            g = tuple(lw[i:i + 6])
            grams[g] = grams.get(g, 0) + 1
        total = len(lw) - 5
        rep = sum(v for v in grams.values() if v > 1)
        if rep and rep / float(total) >= 0.2:
            top = max(grams.items(), key=lambda kv: kv[1])[0]
            add(71, "degenerate_repetition", TITLES[71], rep, [" ".join(top)])

    st = Scan()
    st.findings = findings
    st.nwords = nwords
    st.sentences = sentences
    st.invis = len(invis)
    st.spaces = nsp
    st.homo = len(homo_toks)
    return st


def compute_score(findings, nwords):
    fam = {}
    for (num, slug), (label, count, samples, moving) in findings.items():
        if not moving:
            continue
        fam[num] = fam.get(num, 0) + count
    n = len(fam)
    total = 0.0
    for num, cnt in fam.items():
        w = WEIGHT.get(num, 8)
        if num == 1:
            total += 6 + 3 * min(cnt, 8)
        else:
            total += w * (1 + 0.3 * min(cnt - 1, 4))
    score = int(round(min(100.0, total)))
    # confidence
    if nwords < 40:
        conf, reason = "none", "fewer than 40 words, too little text to judge"
    elif nwords < 120:
        conf, reason = "low", "short text (fewer than 120 words)"
    elif nwords < 300 and n <= 1:
        conf, reason = "low", "under 300 words with at most one pattern family"
    elif nwords < 300:
        conf, reason = "moderate", "under 300 words"
    else:
        conf, reason = "high", ""
    decisive = [k for k in fam if k in DECISIVE]
    if n == 1 and fam and next(iter(fam)) in DECISIVE and conf not in ("none", "low"):
        score = max(score, 45)
    elif n == 1:
        score = min(score, 40)
    if n >= 1 and set(fam) <= RHYTHM:
        score = min(score, 40)
        if set(fam) == {40}:
            score = min(score, 20)
    if len(decisive) >= 2:
        score = max(score, 65)
    if nwords < 120:
        early = len([k for k in fam if k in EARLY])
        if early >= 3:
            score = max(score, 45)
        elif early >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))
    return score, conf, reason, n


def band_of(score):
    if score <= 20:
        return "clean"
    if score <= 40:
        return "light tells"
    if score <= 60:
        return "mixed"
    if score <= 80:
        return "heavy tells"
    return "pervasive tells"


def make_report(prose, ci=False):
    truncated = len(prose) > WINDOW
    raw = prose[:WINDOW]
    st = scan(raw)
    score, conf, reason, nfam = compute_score(st.findings, st.nwords)
    rep = {}
    items = sorted(st.findings.items(), key=lambda kv: (not kv[1][3], -WEIGHT.get(kv[0][0], 0) * kv[1][1] ** 0.3, kv[0][0]))
    for (num, slug), (label, count, samples, moving) in items:
        rep["%d_%s" % (num, slug)] = {"label": label, "count": count, "samples": samples}
    m = {
        "scanned_chars": len(raw),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(rep),
        "invisible_chars": st.invis,
        "nonstandard_spaces": st.spaces,
        "homoglyphs": st.homo,
        "words": st.nwords,
    }
    if ci:
        sents = st.sentences
        if len(sents) >= 4:
            rnd = random.Random(1234)
            reps = 100 if len(raw) < 20000 else 20
            scores = []
            for _ in range(reps):
                pick = [sents[rnd.randrange(len(sents))] for _ in sents]
                txt = " ".join(pick)
                s2 = scan(txt)
                scores.append(compute_score(s2.findings, s2.nwords)[0])
            scores.sort()
            lo = scores[int(0.05 * (len(scores) - 1))]
            hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            m["score_ci"] = [lo, hi]
            m["score_ci_note"] = "90%% interval from %d resamples of sentences" % reps
        else:
            m["score_ci"] = None
            m["score_ci_note"] = "too few sentences (fewer than four) for an interval"
    rep["_metrics"] = m
    return rep


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

def err(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    ci = False
    files = []
    opts_done = False
    for a in argv:
        if opts_done:
            files.append(a)
        elif a == "--":
            opts_done = True
        elif a in ("--help", "-h"):
            out = sys.stdout.buffer
            out.write(USAGE.encode("utf-8"))
            out.flush()
            return 0
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-"):
            return err("unknown option: %s (see --help)" % a, 2)
        else:
            files.append(a)
    path = files[0] if files else None
    if len(files) > 1:
        sys.stderr.write("note: %d files given; only the first was scanned: %s\n" % (len(files), path))
    try:
        prose = load_prose(path)
    except Fail as f:
        return err(f.msg, f.code)
    except Exception as e:
        return err("cannot read input: %s" % e, 1)
    if prose.strip() == "":
        return err("empty input", 1)
    if clean:
        out = cleanup(prose)
        sys.stdout.buffer.write(out.encode("utf-8", "replace"))
        sys.stdout.buffer.flush()
        return 0
    rep = make_report(prose, ci)
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=1) + "\n").encode("utf-8", "replace"))
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    try:
        code = main(sys.argv[1:])
    except Exception as e:  # never a traceback
        code = err("internal error: %s" % e, 1)
    sys.exit(code)
