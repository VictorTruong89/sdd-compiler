# Implementation notes

- `scripts/detect.py` — detector (FP-01..03): extraction for the 20 formats, 62 machine-checked
  patterns (12 + the 17 parallelism form are weight-zero advice), score/band/confidence/floors,
  `--clean`, `--ci`, structured errors (exit 1 / 2).
- `hooks/prosecheck-activate.js` (session start + welcome), `-tracker.js` (prompt submit and the
  `/prosecheck` router: levels, status, show, check, doctor, init, help, stats), `-subagent.js`,
  `-guard.js` (post-tool-use), `-stats.js`, `-lib.js` (shared), `hooks/hooks.json`.
- `commands/prosecheck.md`, `install/prosecheck-command.md` — host menu document forwarding `$ARGUMENTS`.
- `.cursor/rules/prosecheck.mdc` — shipped Cursor rule copied by `init`.
- Free-choice items (hyphenated-pair list, marketing-slop list, weights, resample count/seed) are
  the implementer's choice per the spec; weights are in `WEIGHT` in detect.py.
- Not done: nothing from the checklist is knowingly omitted; the bundled skill, demo, docs checker,
  eval script and status-line helper are explicit non-goals.
