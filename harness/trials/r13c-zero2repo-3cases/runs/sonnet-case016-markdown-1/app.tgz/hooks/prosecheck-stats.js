#!/usr/bin/env node
'use strict';
// Session statistics: token use from the host transcript and the session's own prose score.
const lib = require('./prosecheck-lib');
const fs = lib.fs;
const path = lib.path;

function newestTranscript() {
  const root = path.join(lib.configDir(), 'projects');
  let best = null;
  let bestTime = -1;
  function walk(dir, depth) {
    let names;
    try { names = fs.readdirSync(dir); } catch (e) { return; }
    names.forEach(function (n) {
      const f = path.join(dir, n);
      let st;
      try { st = fs.statSync(f); } catch (e) { return; }
      if (st.isDirectory()) { if (depth < 6) walk(f, depth + 1); }
      else if (st.isFile() && n.toLowerCase().slice(-6) === '.jsonl' && st.mtimeMs > bestTime) {
        best = f; bestTime = st.mtimeMs;
      }
    });
  }
  walk(root, 0);
  return best;
}

function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

function statsReply(transcriptPath) {
  const level = lib.getMode();
  let file = transcriptPath && typeof transcriptPath === 'string' ? transcriptPath : null;
  if (!file) file = newestTranscript();
  if (!file) return 'prosecheck stats: no session transcript found to read.\nlevel: ' + level;
  let raw;
  try {
    if (!fs.statSync(file).isFile()) throw new Error('not a file');
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return 'prosecheck stats: the transcript could not be read.\nlevel: ' + level;
  }
  const seen = {};
  let turns = 0;
  let out = 0;
  let cache = 0;
  const texts = [];
  raw.split('\n').forEach(function (line) {
    line = line.trim();
    if (!line) return;
    let row;
    try { row = JSON.parse(line); } catch (e) { return; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') return;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : null;
    if (id === null || !seen[id]) {
      if (id !== null) seen[id] = true;
      turns += 1;
      const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
      out += Number(u.output_tokens) || 0;
      cache += Number(u.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(msg.content)) {
      msg.content.forEach(function (c) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      });
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  });
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + fmt(turns),
    'output tokens: ' + fmt(out),
    'cache-read input tokens: ' + fmt(cache),
  ];
  let slice = texts.join('\n\n').replace(/```[\s\S]*?(?:```|$)/g, '');
  if (slice.length > 40000) slice = slice.slice(-40000);
  if (slice.trim().length > 200) {
    const r = lib.runDetector([], { input: slice, timeout: 15000 });
    if (r && !r.unavailable && !r.missing && !r.timedOut && r.status === 0) {
      const rep = lib.parseReport(r.stdout);
      if (rep.kind === 'report') lines.push('session prose ai_tell_score: ' + rep.metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const p = lib.readPayload();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(p.transcript_path) }) + '\n');
  } catch (e) { /* never fail the host */ }
  process.exitCode = 0;
}
