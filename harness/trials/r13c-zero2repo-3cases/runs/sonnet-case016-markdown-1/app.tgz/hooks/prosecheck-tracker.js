#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const lib = require('./prosecheck-lib');
const stats = require('./prosecheck-stats');
const fs = lib.fs;
const path = lib.path;

const CMD_RE = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/;

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reason }) + '\n');
}

function helpReply(level) {
  return [
    'prosecheck is running at level ' + level + '. Prose deliverables follow the writing contract.',
    'prose only: code, commits, config, and chat are never touched.',
    '/prosecheck lite     writing contract only, no scoring of saved files',
    '/prosecheck full     contract plus the saved-file guard, threshold ' + lib.FULL_THRESHOLD + ' (default)',
    '/prosecheck strict   stricter guard, threshold ' + lib.STRICT_THRESHOLD + ', plus the --clean scrub',
    '/prosecheck off      disable prosecheck',
    '/prosecheck on       re-enable prosecheck',
    '/prosecheck status   show the current level',
    '/prosecheck show     list files scored in this session',
    '/prosecheck check    score one file and report only, never a rewrite',
    '/prosecheck doctor   health check of the install',
    '/prosecheck stats    session token figures and the score of the session prose',
    '/prosecheck init     export the contract to ./AGENTS.md for other agents',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

// ------------------------------------------------------------ check
function stripPathArg(arg) {
  let s = (arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  const q = s[0];
  if ((q === '"' || q === "'") && s.length > 1) {
    const end = s.indexOf(q, 1);
    if (end > 0) return s.slice(1, end);
    return s.slice(1);
  }
  return s;
}

function checkReply(arg, cwd) {
  let p = stripPathArg(arg);
  if (!p) return 'prosecheck check: give a file path, for example /prosecheck check notes.md. It reports only and never changes the file.';
  const full = path.resolve(cwd || process.cwd(), p);
  let st;
  try { st = fs.statSync(full); } catch (e) {
    // an unquoted path with trailing words: fall back to its first token
    const tok = p.split(/\s+/)[0];
    let ok = false;
    if (tok !== p) {
      try { st = fs.statSync(path.resolve(cwd || process.cwd(), tok)); p = tok; ok = true; } catch (e2) { /* no */ }
    }
    if (!ok) return 'prosecheck check: cannot read ' + p;
  }
  const target = path.resolve(cwd || process.cwd(), p);
  if (!st.isFile()) return 'prosecheck check: not a file: ' + p;
  const base = path.basename(target);
  const ext = lib.extOf(target);
  if (lib.BINARY_EXTS.indexOf(ext) >= 0) return 'prosecheck check: ' + base + ' has no readable text (binary format, not scored).';
  const cap = lib.capFor(ext);
  if (st.size > cap.bytes) return 'prosecheck check: ' + base + ' is over ' + cap.kb + ' KB and was not scored.';
  const timeout = lib.ARCHIVE_EXTS.indexOf(ext) >= 0 ? 15000 : 8000;
  const r = lib.runDetector(['--', target], { timeout: timeout });
  if (r.unavailable || r.missing) return 'prosecheck check: detector unavailable (Python or the bundled script could not be launched).';
  if (r.timedOut) return 'prosecheck check: ' + base + ' failed: the detector timed out.';
  if (r.status !== 0) {
    const err = (r.stderr || '').trim();
    return 'prosecheck check: ' + base + ' failed' + (err ? ': ' + err : ' (the detector reported a failure).');
  }
  if (!r.stdout.trim()) return 'prosecheck check: ' + base + ' - no report (the detector printed nothing).';
  const rep = lib.parseReport(r.stdout);
  if (rep.kind !== 'report') return 'prosecheck check: no report (the detector output was not a report).';
  const m = rep.metrics;
  const lines = [];
  lines.push('prosecheck check: ' + base + ' - ' + lib.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && typeof m.confidence_reason === 'string' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated === true) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  if (rep.findings.length) {
    lines.push('tells: ' + rep.findings.slice(0, 8).map(function (f) { return f.label + ' (x' + f.count + ')'; }).join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ------------------------------------------------------------ doctor
function doctorReply(form) {
  const level = lib.getMode();
  const modeOk = level !== 'off';
  const modeLine = modeOk
    ? '[OK] mode: ' + level
    : '[off] mode: off - turn it back on with /prosecheck on';
  const det = lib.detectorPath();
  const detOk = !!det;
  const detLine = detOk ? '[OK] detector: bundled script found' : '[missing] detector: bundled script not found in the plugin tree';
  let pyOk = false;
  let pyLine;
  if (!det) {
    pyLine = '[fail] python: cannot run the bundled script because it is missing';
  } else {
    const r = lib.runDetector([], { input: 'The committee met on Tuesday and agreed to move the deadline back by two weeks, which gave everyone time to finish the report properly.', timeout: 15000 });
    if (r.unavailable) {
      pyLine = '[fail] python not found - saved files are not re-scored until Python is available; the writing contract still shapes new prose.';
    } else {
      const rep = r.timedOut || r.status !== 0 ? { kind: 'text' } : lib.parseReport(r.stdout);
      if (rep.kind === 'report') {
        pyOk = true;
        pyLine = '[OK] python: ran the bundled script and got a numeric score';
      } else {
        pyLine = '[fail] python: ran, but the result was not a numeric score';
      }
    }
  }
  let setOk = false;
  try {
    const dir = lib.configDir();
    lib.fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.prosecheck-probe-' + process.pid);
    lib.fs.writeFileSync(probe, 'ok');
    lib.fs.unlinkSync(probe);
    setOk = true;
  } catch (e) { setOk = false; }
  const setLine = setOk ? '[OK] settings: folder is writable' : '[fail] settings: folder is not writable';
  const others = detOk && pyOk && setOk;
  let closer;
  if (others && modeOk) {
    closer = 'prosecheck is active. Plain text up to ' + lib.PLAIN_CAP_KB + ' KB and archives up to 4 MB are scored on their first ' + lib.WINDOW_TXT + ' characters. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (others && !modeOk) {
    closer = 'The install is healthy. While it is off, saving files triggers no scoring, so nothing is scored. Run ' + form + ' on to turn it back on.';
  } else {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  }
  return ['prosecheck doctor', modeLine, detLine, pyLine, setLine, closer].join('\n');
}

// ------------------------------------------------------------ show
function showReply(sessionId) {
  const rows = lib.readLedger(sessionId);
  if (!rows.length) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const lines = ['prosecheck show: files handled this session, newest first'];
  rows.slice().reverse().forEach(function (r) {
    let body;
    if (r.kind === 'scored') {
      body = lib.phraseFor(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = (r.labels || []).slice(0, 5);
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
    } else if (r.kind === 'size') {
      body = 'not scored: larger than the ' + r.limitKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    lines.push('  ' + r.base + ' - ' + body);
  });
  return lines.join('\n');
}

// ------------------------------------------------------------ init
function initReply(form, level) {
  if (level === 'off') {
    return 'prosecheck init: prosecheck is switched off, so nothing was written. Run ' + form + ' on first to allow the export.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFailed = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFailed = true; }
  if (readFailed) {
    out.push('prosecheck could not export: cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.indexOf(lib.SECTION_START) >= 0 || existing.indexOf(lib.SECTION_HEADING) >= 0)) {
    out.push('The contract is already present in AGENTS.md; it was left unchanged.');
  } else {
    let text = existing === null ? '' : existing;
    if (text.length && !text.endsWith('\n')) text += '\n';
    if (text.length) text += '\n';
    text += lib.exportSection(level);
    try {
      fs.writeFileSync(agents, text);
      out.push('Wrote the ' + level + ' writing contract to AGENTS.md.');
    } catch (e) {
      out.push('prosecheck could not export: cannot write AGENTS.md, so the contract was not written.');
    }
  }
  const ruleDir = path.join(cwd, '.cursor', 'rules');
  const rule = path.join(ruleDir, 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    out.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    let content;
    try {
      content = fs.readFileSync(path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'));
    } catch (e) { content = Buffer.from(lib.cursorRule()); }
    try {
      fs.mkdirSync(ruleDir, { recursive: true });
      fs.writeFileSync(rule, content);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('prosecheck could not export: cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return 'prosecheck init:\n' + out.join('\n');
}

// ------------------------------------------------------------ router
function route(prompt, payload) {
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    lib.setMode('off');
    block('prosecheck is now off. Re-enable it with /prosecheck on.');
    return true;
  }
  const m = CMD_RE.exec(trimmed);
  if (!m) return false;
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const sub = rest.split(/\s+/)[0] || '';
  const arg = rest.slice(sub.length).trim();
  const word = sub.toLowerCase();
  lib.purgeOldLedgers();
  const level = lib.getMode();
  if (!word || word === 'help') { block(helpReply(level)); return true; }
  switch (word) {
    case 'lite': case 'full': case 'strict':
      lib.setMode(word);
      block('prosecheck level set to ' + word + '.');
      break;
    case 'off':
      lib.setMode('off');
      block('prosecheck is now off. Re-enable it with /prosecheck on.');
      break;
    case 'on':
      lib.setMode('full');
      block('prosecheck is on (level full).');
      break;
    case 'status':
      block('prosecheck level: ' + level);
      break;
    case 'show':
      block(showReply(payload.session_id));
      break;
    case 'check':
      block(checkReply(arg, typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : null));
      break;
    case 'doctor':
      block(doctorReply(form));
      break;
    case 'stats':
      block(stats.statsReply(payload.transcript_path));
      break;
    case 'init':
      block(initReply(form, level));
      break;
    default:
      block('prosecheck: unknown subcommand "' + sub + '". Valid subcommands: ' + lib.SUBCOMMANDS.join(', ') + '.');
  }
  return true;
}

function main() {
  const payload = lib.readPayload();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  if (route(prompt, payload)) return;
  const level = lib.getMode();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
