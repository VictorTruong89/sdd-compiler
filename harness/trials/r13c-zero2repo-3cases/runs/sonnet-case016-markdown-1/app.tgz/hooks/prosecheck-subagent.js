#!/usr/bin/env node
'use strict';
// Subagent-start hook: the writing contract for delegated prose.
const lib = require('./prosecheck-lib');

function main() {
  lib.readPayload();
  const level = lib.getMode();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: lib.contractText(level, { detector: lib.detectorPath() }),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
