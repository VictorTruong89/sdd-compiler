#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const lib = require('./prosecheck-lib');
const fs = lib.fs;
const path = lib.path;

const TOOLS = ['write', 'edit', 'multiedit', 'notebookedit', 'applypatch'];
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const MAX_PATCH_FILES = 16;
const LABEL_CAP = 5;

function patchPaths(cmd) {
  const found = [];
  String(cmd).split(/\r?\n/).forEach(function (line) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && found.indexOf(p) < 0) found.push(p);
    }
  });
  return found.slice(0, MAX_PATCH_FILES);
}

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const tool = String(payload.tool_name || '').toLowerCase().replace(/[^a-z]/g, '');
  if (TOOLS.indexOf(tool) < 0) return [];
  if (tool === 'applypatch') {
    let cmd = ti.command;
    if (Array.isArray(cmd)) cmd = cmd.join('\n');
    if (typeof cmd !== 'string') return [];
    return patchPaths(cmd);
  }
  if (tool === 'notebookedit') {
    if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) return [ti.notebook_path.trim()];
    if (typeof ti.file_path === 'string' && ti.file_path.trim()) return [ti.file_path.trim()];
    return [];
  }
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) return [ti.file_path.trim()];
  return [];
}

function isUnderRoot(file, root) {
  let a = file;
  let b = path.resolve(root);
  try { a = fs.realpathSync(file); } catch (e) { /* keep as is */ }
  try { b = fs.realpathSync(b); } catch (e) { /* keep as is */ }
  const rel = path.relative(b, a);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipFile(file) {
  const parts = file.split(/[\\/]+/);
  const dirs = parts.slice(0, -1);
  if (dirs.some(function (d) { return d === 'node_modules' || d === '.git' || d === 'memory'; })) return true;
  if (isUnderRoot(file, lib.pluginRoot())) return true;
  const base = path.basename(file).toLowerCase();
  if (INSTRUCTION_NAMES.indexOf(base) >= 0) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (INSTRUCTION_STEMS.indexOf(stem) >= 0 && lib.PROSE_EXTS.indexOf(ext) < 0) return true;
  return false;
}

function pickLabels(findings) {
  return findings.slice().sort(function (a, b) { return b.count - a.count; })
    .map(function (f) { return f.label; }).slice(0, LABEL_CAP);
}

function score(file, base, threshold) {
  const ext = lib.extOf(file);
  let st;
  try { st = fs.statSync(file); } catch (e) {
    return { record: { base: base, kind: 'failed', reason: 'the file could not be read' } };
  }
  if (!st.isFile()) return null;
  const cap = lib.capFor(ext);
  if (st.size > cap.bytes) return { record: { base: base, kind: 'size', limitKB: cap.kb } };
  const timeout = lib.ARCHIVE_EXTS.indexOf(ext) >= 0 ? 15000 : 8000;
  const r = lib.runDetector(['--', file], { timeout: timeout });
  const fail = function (why) { return { record: { base: base, kind: 'failed', reason: why } }; };
  if (r.unavailable) return fail('python was not found');
  if (r.missing) return fail('the bundled detector is missing');
  if (r.timedOut) return fail('the detector timed out');
  if (r.status !== 0 || !r.stdout || !r.stdout.trim()) return fail('the detector produced no result');
  const rep = lib.parseReport(r.stdout);
  if (rep.kind === 'text') return fail('the detector output was not a report');
  if (rep.kind === 'noscore') return fail('the report had no numeric score');
  const m = rep.metrics;
  const flagged = m.ai_tell_score > threshold && m.confidence !== 'none';
  const labels = pickLabels(rep.findings);
  const record = {
    base: base, kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band,
    labels: labels, flagged: flagged, truncated: m.truncated === true,
  };
  let line = null;
  if (flagged) {
    line = 'prosecheck: ' + base + ' ' + lib.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
      ', band ' + m.ai_tell_band + (record.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + '). ' +
      'Flagged: ' + (labels.length ? labels.join('; ') : 'none listed') + '. ' +
      'Please fix the flagged spans and keep the meaning, numbers, and names unchanged.';
  }
  return { record: record, line: line };
}

function main() {
  const payload = lib.readPayload();
  const level = lib.getMode();
  if (level !== 'full' && level !== 'strict') return;
  const threshold = level === 'strict' ? lib.STRICT_THRESHOLD : lib.FULL_THRESHOLD;
  const paths = collectPaths(payload);
  if (!paths.length) return;
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const records = [];
  const lines = [];
  paths.forEach(function (p) {
    const file = path.resolve(cwd, p);
    if (skipFile(file)) return;
    const ext = lib.extOf(file);
    const base = path.basename(file);
    if (lib.BINARY_EXTS.indexOf(ext) >= 0) {
      records.push({ base: base, kind: 'binary' });
      return;
    }
    if (lib.PROSE_EXTS.indexOf(ext) < 0) return;
    const res = score(file, base, threshold);
    if (!res) return;
    records.push(res.record);
    if (res.line) lines.push(res.line);
  });
  lib.appendLedger(payload.session_id, records);
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }) + '\n');
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
