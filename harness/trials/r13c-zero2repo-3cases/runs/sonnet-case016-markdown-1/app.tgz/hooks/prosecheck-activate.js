#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const lib = require('./prosecheck-lib');

function main() {
  lib.readPayload();
  lib.purgeOldLedgers();
  let level = lib.storedMode();
  let welcome = false;
  if (!level) {
    let exists = true;
    try { lib.fs.statSync(lib.flagPath()); } catch (e) { exists = false; }
    level = lib.envDefault() || 'full';
    if (!exists) {
      const wrote = lib.setMode(level);
      welcome = wrote;
    } else {
      level = lib.envDefault() || 'full';
    }
  }
  if (level === 'off') return;
  let out = '';
  if (welcome) out += lib.welcomeText() + '\n';
  out += lib.contractText(level, { detector: lib.detectorPath() }) + '\n';
  process.stdout.write(out);
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
