'use strict';
// Shared helpers for the prosecheck plugin hooks. Standard library only; no network.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP_KB = 512;
const ARCHIVE_CAP_KB = 4096;
const PLAIN_CAP = PLAIN_CAP_KB * 1024;
const ARCHIVE_CAP = ARCHIVE_CAP_KB * 1024;
const FULL_THRESHOLD = 40;
const STRICT_THRESHOLD = 20;
const LEDGER_MAX = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const PROSE_EXTS = PLAIN_EXTS.concat(ARCHIVE_EXTS);
const BINARY_EXTS = ['.pdf', '.rtf'];

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};
function phraseFor(band) {
  return PHRASES[band] || 'reads with some AI tells';
}

// ---------------------------------------------------------------- paths
function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR) return process.env.CLAUDE_CONFIG_DIR;
  return path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  try { if (fs.statSync(a).isFile()) return a; } catch (e) { /* fall through */ }
  try { if (fs.statSync(b).isFile()) return b; } catch (e) { /* fall through */ }
  return null;
}

// ---------------------------------------------------------------- input
function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8');
  } catch (e) {
    return '';
  }
}
function readPayload() {
  const raw = readStdin();
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* malformed */ }
  return {};
}

// ---------------------------------------------------------------- mode
const FLAG = '.prosecheck-active';
function flagPath() { return path.join(configDir(), FLAG); }
function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}
function storedMode() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    if (LEVELS.indexOf(v) >= 0) return v;
  } catch (e) { /* none */ }
  return null;
}
function getMode() {
  return storedMode() || envDefault() || 'full';
}
function setMode(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level, { mode: 0o600 });
    return true;
  } catch (e) {
    return false;
  }
}

// ---------------------------------------------------------------- contract
function nl(lines) { return lines.join('\n'); }

function contractCore(level) {
  return [
    'Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.',
    'Never touch source code, code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat.',
    'A chat-compression mode owns chat. A code-simplicity mode owns code. This contract owns deliverable prose.',
    'Rules for prose:',
    '- Vary sentence length irregularly. No metronome rhythm and no mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" and "Overall" closers, outcome-speculation tails, self-thoroughness announcements, generic upbeat endings, and chatbot phrases ("I hope this helps").',
    '- Use an em dash at most once per paragraph.',
    '- No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual and encyclopedic content stays neutral third person. First-person and opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    '- End sections on a fact or observation.',
    '- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

// opts.detector: absolute path of the live detector (live delivery only)
function contractText(level, opts) {
  opts = opts || {};
  const lines = ['Prose writing contract (' + level + ').'].concat(contractCore(level));
  if (level === 'full' || level === 'strict') {
    const where = opts.detector
      ? 'python3 ' + opts.detector
      : 'the bundled detect.py script (python3, with the file as its only operand)';
    if (level === 'full') {
      lines.push('After writing a prose file, run ' + where + ' on that file. When the result is worse than the target (score at most ' + FULL_THRESHOLD + ', band clean or light tells), fix the flagged spans and run it again, at most two fix passes, keeping rhythm variation.');
    } else {
      lines.push('After writing a prose file, run ' + where + ' on that file. When the result is worse than the target (score at most ' + STRICT_THRESHOLD + ', band clean), fix the flagged spans and run it again, at most two fix passes, keeping rhythm variation.');
      lines.push('Then finish through --clean: run the detector with --clean on the plain-text prose file and save the scrubbed output over it. Never do that for .docx, .epub, .odt, or .ipynb files.');
    }
    if (!opts.detector) {
      lines.push('Detector location: use CLAUDE_PLUGIN_ROOT when that variable is set (scripts/detect.py under it); otherwise locate the prosecheck detector in the installed skills and plugins folders.');
    }
  }
  return nl(lines);
}

function welcomeText() {
  return nl([
    'prosecheck is installed and on. It is a local prose-pattern detector: nothing is uploaded, there is no website and no account.',
    'Saved prose is scored against 71 patterns. Plain text is accepted up to ' + PLAIN_CAP_KB + ' KB and archives up to 4 MB. The detector scores the first ' + WINDOW_TXT + ' characters.',
    'Commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'This welcome is shown once.',
    '',
  ]);
}

const SECTION_START = '<!-- prosecheck:contract:start -->';
const SECTION_END = '<!-- prosecheck:contract:end -->';
const SECTION_HEADING = '## Prose writing contract (prosecheck)';

function exportSection(level) {
  return nl([SECTION_START, SECTION_HEADING, '', contractText(level, {}), SECTION_END, '']);
}

function cursorRule() {
  const front = [
    '---',
    'description: Prose writing contract for deliverable prose only',
    'globs:',
  ].concat(['*.md', '*.mdx', '*.markdown', '*.txt', '*.rst', '*.tex', '*.org', '*.adoc'].map(function (g) { return '  - "' + g + '"'; }))
    .concat(['alwaysApply: false', '---']);
  const body = [
    '',
    'Writing contract: prose deliverables only.',
    '',
    contractCore('lite').join('\n'),
    '',
  ];
  return front.concat(body).join('\n');
}

// ---------------------------------------------------------------- python / detector
function pythonCandidates() { return ['python3', 'python', 'py']; }

// Runs the detector; returns {unavailable:true} when no interpreter can be launched.
function runDetector(args, opts) {
  opts = opts || {};
  const det = detectorPath();
  if (!det) return { missing: true };
  let sawLaunch = false;
  for (const py of pythonCandidates()) {
    const r = spawnSync(py, [det].concat(args), {
      input: opts.input,
      encoding: 'utf8',
      timeout: opts.timeout || 8000,
      maxBuffer: 256 * 1024 * 1024,
      env: process.env,
    });
    if (r.error && r.error.code === 'ENOENT') continue;
    sawLaunch = true;
    if (r.error && r.error.code === 'ETIMEDOUT') return { timedOut: true };
    if (r.error && (r.error.code === 'EACCES' || r.error.code === 'EPERM')) { sawLaunch = false; continue; }
    return { status: r.status, signal: r.signal, stdout: r.stdout || '', stderr: r.stderr || '', error: r.error };
  }
  return { unavailable: true };
}

function parseReport(stdout) {
  let v;
  try { v = JSON.parse(stdout); } catch (e) { return { kind: 'text' }; }
  if (!v || typeof v !== 'object' || Array.isArray(v) || !v._metrics || typeof v._metrics !== 'object') return { kind: 'text' };
  const m = v._metrics;
  if (typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) return { kind: 'noscore' };
  const findings = [];
  Object.keys(v).forEach(function (k) {
    if (k === '_metrics') return;
    const f = v[k];
    if (f && typeof f === 'object' && typeof f.label === 'string') {
      findings.push({ key: k, label: f.label, count: Number(f.count) || 0 });
    }
  });
  return { kind: 'report', metrics: m, findings: findings };
}

function extOf(p) { return path.extname(p).toLowerCase(); }
function capFor(ext) {
  return ARCHIVE_EXTS.indexOf(ext) >= 0 ? { bytes: ARCHIVE_CAP, kb: ARCHIVE_CAP_KB } : { bytes: PLAIN_CAP, kb: PLAIN_CAP_KB };
}

// ---------------------------------------------------------------- ledger
function sanitizeId(id) {
  const clean = String(id).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 80);
  if (clean === String(id)) return clean;
  return clean + '-' + crypto.createHash('sha1').update(String(id)).digest('hex').slice(0, 8);
}
function ledgerFile(sessionId) {
  const dir = configDir();
  if (!sessionId || typeof sessionId !== 'string') return path.join(dir, '.prosecheck-ledger');
  return path.join(dir, '.prosecheck-ledger-' + sanitizeId(sessionId));
}
function isLedgerName(n) {
  return n === '.prosecheck-ledger' || n.indexOf('.prosecheck-ledger-') === 0;
}
function purgeOldLedgers() {
  try {
    const dir = configDir();
    const now = Date.now();
    fs.readdirSync(dir).forEach(function (n) {
      if (!isLedgerName(n)) return;
      const f = path.join(dir, n);
      try {
        const st = fs.statSync(f);
        if (st.isFile() && now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(f);
      } catch (e) { /* ignore */ }
    });
  } catch (e) { /* ignore */ }
}
function readLedger(sessionId) {
  purgeOldLedgers();
  try {
    const v = JSON.parse(fs.readFileSync(ledgerFile(sessionId), 'utf8'));
    if (Array.isArray(v)) return v;
  } catch (e) { /* none */ }
  return [];
}
function appendLedger(sessionId, records) {
  if (!records.length) return;
  try {
    const cur = readLedger(sessionId);
    const all = cur.concat(records).slice(-LEDGER_MAX);
    fs.mkdirSync(configDir(), { recursive: true });
    const f = ledgerFile(sessionId);
    fs.writeFileSync(f, JSON.stringify(all), { mode: 0o600 });
    try { fs.chmodSync(f, 0o600); } catch (e) { /* ignore */ }
  } catch (e) { /* ignore */ }
}

module.exports = {
  fs, os, path, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_CAP_KB, ARCHIVE_CAP_KB,
  FULL_THRESHOLD, STRICT_THRESHOLD, LEDGER_MAX, LEVELS, SUBCOMMANDS, PLAIN_EXTS, ARCHIVE_EXTS,
  PROSE_EXTS, BINARY_EXTS, BANNED, phraseFor, configDir, pluginRoot, detectorPath, readStdin,
  readPayload, flagPath, storedMode, envDefault, getMode, setMode, contractText, welcomeText,
  exportSection, cursorRule, SECTION_START, SECTION_END, SECTION_HEADING, runDetector,
  parseReport, extOf, capFor, readLedger, appendLedger, purgeOldLedgers, ledgerFile,
};
