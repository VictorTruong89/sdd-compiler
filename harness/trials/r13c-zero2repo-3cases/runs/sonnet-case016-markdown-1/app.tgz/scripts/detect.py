#!/usr/bin/env python3
"""prosecheck detector: local, standard-library scan for AI-writing patterns.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

WINDOW = 262144

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns. Reads FILE, or standard input when no
FILE is given, and prints one JSON report.

  --clean   print scrubbed text (invisible characters removed, odd spaces
            normalized, lookalike letters folded, whitespace trimmed)
  --ci      add a low/high interval on the score
  --        end of options; the next argument is the FILE
  -h, --help  show this message
"""

PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = '.ipynb'
BINARY_EXTS = {'.pdf', '.rtf'}


class DetectError(Exception):
    def __init__(self, message, code=1):
        Exception.__init__(self, message)
        self.message = message
        self.code = code


# --------------------------------------------------------------------------
# Input and extraction
# --------------------------------------------------------------------------

def decode_bytes(b):
    if b[:2] in (b'\xff\xfe', b'\xfe\xff'):
        try:
            return b.decode('utf-16')
        except UnicodeDecodeError:
            return b.decode('utf-16', 'replace')
    if b[:3] == b'\xef\xbb\xbf':
        b = b[3:]
    if b'\x00' in b:
        return None
    s = b.decode('utf-8', 'replace')
    if s[:1] == '﻿':
        s = s[1:]
    return s


def local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def parse_xml(data):
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def natural_key(name):
    parts = re.split(r'(\d+)', name.lower())
    return [(int(p) if i % 2 else p) for i, p in enumerate(parts)]


MEMBER_LIMIT = 64 * 1024 * 1024


def read_member(zf, name):
    try:
        with zf.open(name) as fh:
            return fh.read(MEMBER_LIMIT)
    except Exception:
        return b''


def docx_text(data):
    root = parse_xml(data)
    if root is None:
        return ''
    paras = []

    def walk(el, out):
        for ch in el:
            ln = local(ch.tag)
            if ln == 't':
                out.append(ch.text or '')
            elif ln == 'tab':
                out.append('\t')
            elif ln in ('br', 'cr'):
                out.append('\n')
            elif ln in ('delText', 'instrText', 'rPr', 'pPr'):
                continue
            else:
                walk(ch, out)

    def collect(el):
        for ch in el:
            if local(ch.tag) == 'p':
                out = []
                walk(ch, out)
                paras.append(''.join(out))
            else:
                collect(ch)

    collect(root)
    return '\n'.join(paras)


def pptx_text(zf):
    names = [n for n in zf.namelist() if re.match(r'^ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=natural_key)
    slides = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        paras = []

        def walk(el, out):
            for ch in el:
                ln = local(ch.tag)
                if ln == 't':
                    out.append(ch.text or '')
                elif ln == 'br':
                    out.append('\n')
                elif ln == 'tab':
                    out.append('\t')
                else:
                    walk(ch, out)

        def collect(el):
            for ch in el:
                if local(ch.tag) == 'p':
                    out = []
                    walk(ch, out)
                    paras.append(''.join(out))
                else:
                    collect(ch)

        collect(root)
        slides.append('\n'.join(paras))
    return '\n'.join(slides)


def xlsx_text(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = parse_xml(read_member(zf, 'xl/sharedStrings.xml'))
        if root is not None:
            for si in root:
                if local(si.tag) != 'si':
                    continue
                parts = []

                def walk(el):
                    for ch in el:
                        ln = local(ch.tag)
                        if ln == 'rPh':
                            continue
                        if ln == 't':
                            parts.append(ch.text or '')
                        else:
                            walk(ch)

                walk(si)
                shared.append(''.join(parts))
    names = [n for n in zf.namelist() if re.match(r'^xl/worksheets/[^/]+\.xml$', n)]
    names.sort(key=natural_key)
    cells = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        for c in root.iter():
            if local(c.tag) != 'c':
                continue
            t = c.get('t')
            if t == 's':
                v = None
                for ch in c:
                    if local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'[0-9]+', v):
                    i = int(v)
                    if i < len(shared):
                        cells.append(shared[i])
            elif t == 'inlineStr':
                parts = []
                for ch in c:
                    if local(ch.tag) == 'is':
                        for t_el in ch.iter():
                            if local(t_el.tag) == 't':
                                parts.append(t_el.text or '')
                cells.append(''.join(parts))
            elif t == 'str':
                for ch in c:
                    if local(ch.tag) == 'v':
                        cells.append(ch.text or '')
    return '\n'.join(x for x in cells if x != '')


def odf_text(data):
    root = parse_xml(data)
    if root is None:
        return ''
    paras = []

    def walk(el, out):
        if el.text:
            out.append(el.text)
        for ch in el:
            ln = local(ch.tag)
            if ln == 's':
                n = 1
                for k, v in ch.attrib.items():
                    if local(k) == 'c':
                        try:
                            n = max(0, min(int(v), 10000))
                        except ValueError:
                            n = 1
                out.append(' ' * n)
            elif ln == 'tab':
                out.append('\t')
            elif ln == 'line-break':
                out.append('\n')
            elif ln in ('annotation', 'note'):
                pass
            else:
                walk(ch, out)
            if ch.tail:
                out.append(ch.tail)

    def collect(el):
        for ch in el:
            ln = local(ch.tag)
            if ln in ('p', 'h'):
                out = []
                walk(ch, out)
                paras.append(''.join(out))
            else:
                collect(ch)

    collect(root)
    return '\n'.join(paras)


class _HTMLText(HTMLParser):
    SKIP = {'script', 'style', 'nav', 'head', 'title'}
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr', 'blockquote',
             'section', 'article', 'pre', 'table', 'ul', 'ol', 'dt', 'dd', 'hr', 'figcaption',
             'caption', 'header', 'footer', 'aside', 'dl', 'body', 'html'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.skip = 0
        self.buf = []
        self.blocks = []

    def flush(self):
        s = re.sub(r'\s+', ' ', ''.join(self.buf)).strip()
        self.buf = []
        if s:
            self.blocks.append(s)

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
            return
        if tag in self.BLOCK:
            self.flush()
        elif tag in ('td', 'th'):
            self.buf.append(' ')

    def handle_startendtag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.BLOCK:
            self.flush()

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            if self.skip > 0:
                self.skip -= 1
            return
        if tag in self.BLOCK:
            self.flush()

    def handle_data(self, data):
        if self.skip == 0:
            self.buf.append(data)

    def result(self):
        self.flush()
        return '\n'.join(self.blocks)


def epub_text(zf):
    names = [n for n in zf.namelist()
             if re.search(r'\.(?:xhtml|html|htm)$', n, re.I) and not n.startswith('META-INF/')]
    names.sort(key=natural_key)
    chapters = []
    for n in names:
        data = read_member(zf, n)
        try:
            html = data.decode('utf-8', 'replace')
        except Exception:
            continue
        p = _HTMLText()
        try:
            p.feed(html)
            p.close()
        except Exception:
            pass
        t = p.result()
        if t:
            chapters.append(t)
    return '\n'.join(chapters)


def notebook_text(data):
    try:
        nb = json.loads(data.decode('utf-8', 'replace'))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            out.append(src)
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            out.append(''.join(src))
    return '\n'.join(out)


def extract(data, ext):
    """Return extracted prose (possibly empty) from file bytes."""
    if ext in BINARY_EXTS:
        return ''
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except Exception as e:
            raise DetectError('cannot read input: not a readable zip archive (%s)' % e.__class__.__name__)
        try:
            if ext in ('.docx', '.docm'):
                text = docx_text(read_member(zf, 'word/document.xml'))
            elif ext in ('.pptx', '.pptm'):
                text = pptx_text(zf)
            elif ext in ('.xlsx', '.xlsm'):
                text = xlsx_text(zf)
            elif ext in ('.odt', '.odp', '.ods'):
                text = odf_text(read_member(zf, 'content.xml'))
            else:
                text = epub_text(zf)
        except DetectError:
            raise
        except Exception:
            text = ''
        return text.strip()
    if ext == NOTEBOOK_EXT:
        return notebook_text(data).strip()
    text = decode_bytes(data)
    return text or ''


# --------------------------------------------------------------------------
# Character layer
# --------------------------------------------------------------------------

CF_VISIBLE = set(range(0x0600, 0x0606)) | {0x06DD, 0x070F, 0x08E2, 0x110BD, 0x110CD}
SPECIAL_RE = re.compile(r'[^\x00-\x7f]|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]|\r')
BIDI_MARKS = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
              0x2066, 0x2067, 0x2068, 0x2069}


def is_invisible(c):
    o = ord(c)
    if o < 0x80:
        return o < 0x20 and c not in '\t\n\r' or o == 0x7f
    cat = unicodedata.category(c)
    if cat == 'Cc':
        return True
    if cat == 'Cf':
        return o not in CF_VISIBLE
    if 0xE0000 <= o <= 0xE0FFF:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0x180B <= o <= 0x180F:
        return True
    if o in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5):
        return True
    return False


def in_ranges(o, ranges):
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


R_NOSPACE = ((0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x19E0, 0x19FF),
             (0x3040, 0x30FF), (0x31F0, 0x31FF), (0xFF66, 0xFF9F), (0x3400, 0x4DBF),
             (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x323AF), (0x2F800, 0x2FA1F))
R_CJK = ((0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x323AF), (0x2F800, 0x2FA1F))
R_JOIN = ((0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF),
          (0x1000, 0x109F), (0x1780, 0x17FF))
R_RTL = ((0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF))
R_MONGOLIAN = ((0x1820, 0x1878), (0x1880, 0x18AA))
R_KHMER = ((0x1780, 0x17FF),)


def is_symbolish(c):
    o = ord(c)
    if o >= 0x1F000 or 0x2190 <= o <= 0x2BFF:
        return True
    return unicodedata.category(c) in ('So', 'Sk')


def classify(t):
    """List of (index, kind) for characters the scrub touches or must look at.

    kinds: inv_rm, inv_keep, sp_norm, sp_keep, nl_norm, cr_drop, cr_nl
    """
    acts = []
    n = len(t)
    idxs = [m.start() for m in SPECIAL_RE.finditer(t)]
    if not idxs:
        return acts
    rtl = False
    for i in idxs:
        if ord(t[i]) >= 0x0590 and in_ranges(ord(t[i]), R_RTL):
            rtl = True
            break
    tag_done = set()
    for i in idxs:
        c = t[i]
        o = ord(c)
        if c == '\r':
            if i + 1 < n and t[i + 1] == '\n':
                acts.append((i, 'cr_drop'))
            else:
                acts.append((i, 'cr_nl'))
            continue
        if is_invisible(c):
            prev = t[i - 1] if i > 0 else ''
            nxt = t[i + 1] if i + 1 < n else ''
            po = ord(prev) if prev else -1
            no = ord(nxt) if nxt else -1
            keep = False
            if 0xE0000 <= o <= 0xE0FFF:
                if i not in tag_done:
                    j = i
                    while j < n and 0xE0000 <= ord(t[j]) <= 0xE0FFF:
                        j += 1
                    run_ok = (j - i >= 2 and ord(t[j - 1]) == 0xE007F and
                              i > 0 and ord(t[i - 1]) == 0x1F3F4)
                    for k in range(i, j):
                        tag_done.add(k)
                        if run_ok:
                            acts.append((k, 'inv_keep'))
                        else:
                            acts.append((k, 'inv_rm'))
                continue
            elif 0xE0100 <= o <= 0xE01EF:
                keep = prev != '' and in_ranges(po, R_CJK)
            elif 0xFE00 <= o <= 0xFE0F:
                keep = (prev != '' and (is_symbolish(prev) or in_ranges(po, R_CJK))) or no == 0x20E3
            elif 0x180B <= o <= 0x180F:
                keep = prev != '' and in_ranges(po, R_MONGOLIAN)
            elif o in (0x17B4, 0x17B5):
                keep = (po >= 0 and in_ranges(po, R_KHMER) and po not in (0x17B4, 0x17B5)) or \
                       (no >= 0 and in_ranges(no, R_KHMER) and no not in (0x17B4, 0x17B5))
            elif o == 0x200B:
                keep = (po >= 0 and in_ranges(po, R_NOSPACE)) or (no >= 0 and in_ranges(no, R_NOSPACE))
            elif o == 0x00AD:
                keep = prev != '' and nxt != '' and prev.isalpha() and nxt.isalpha()
            elif o in BIDI_MARKS:
                keep = rtl
            elif o in (0x200C, 0x200D):
                keep = (prev != '' and (in_ranges(po, R_JOIN) or is_symbolish(prev))) or \
                       (nxt != '' and (in_ranges(no, R_JOIN) or is_symbolish(nxt)))
            acts.append((i, 'inv_keep' if keep else 'inv_rm'))
            continue
        if o in (0x2028, 0x2029):
            acts.append((i, 'nl_norm'))
            continue
        if unicodedata.category(c) == 'Zs':
            if o in (0xA0, 0x202F):
                prev = t[i - 1] if i > 0 else ''
                nxt = t[i + 1] if i + 1 < n else ''
                hold = (prev != '' and unicodedata.category(prev) == 'Nd') or \
                       (nxt != '' and unicodedata.category(nxt) == 'Nd') or \
                       (nxt != '' and nxt in ':;!?»›%€') or \
                       (prev != '' and prev in '«‹')
                if hold:
                    acts.append((i, 'sp_keep'))
                    continue
            acts.append((i, 'sp_norm'))
    return acts


def apply_actions(t, acts, mode):
    """mode 'clean' or 'lex'. Returns (string, index map or None)."""
    if not acts:
        return t, None
    want_map = (mode == 'lex')
    pieces = []
    idx = [] if want_map else None
    last = 0
    acts = sorted(acts)
    for i, kind in acts:
        rep = None
        drop = False
        if kind == 'inv_rm':
            drop = True
        elif kind == 'inv_keep':
            if mode == 'lex':
                drop = True
            else:
                continue
        elif kind == 'sp_norm':
            rep = ' '
        elif kind == 'sp_keep':
            if mode == 'lex':
                rep = ' '
            else:
                continue
        elif kind == 'nl_norm':
            rep = '\n'
        elif kind == 'cr_drop':
            if mode != 'lex':
                continue
            drop = True
        elif kind == 'cr_nl':
            if mode != 'lex':
                continue
            rep = '\n'
        else:
            continue
        pieces.append(t[last:i])
        if want_map:
            idx.extend(range(last, i))
        if rep is not None:
            pieces.append(rep)
            if want_map:
                idx.append(i)
        last = i + 1
    pieces.append(t[last:])
    if want_map:
        idx.extend(range(last, len(t)))
    return ''.join(pieces), idx


def _mk_lookalikes():
    m = {}
    cyr = {
        'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i', 'ј': 'j', 'о': 'o',
        'р': 'p', 'ѕ': 's', 'ԛ': 'q', 'ԝ': 'w', 'х': 'x', 'у': 'y', 'ү': 'y', 'ɡ': 'g',
        'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I', 'Ј': 'J', 'К': 'K',
        'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'Ү': 'Y', 'Ꭺ': 'A',
        'ѵ': 'v', 'ӏ': 'l',
    }
    grk = {
        'ο': 'o', 'ν': 'v', 'ι': 'i', 'ρ': 'p', 'υ': 'u', 'χ': 'x', 'γ': 'y', 'α': 'a',
        'ϲ': 'c', 'ϳ': 'j', 'ε': 'e', 'κ': 'k', 'τ': 't',
        'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M',
        'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X', 'Ϲ': 'C', 'Ϳ': 'J',
        'Ѕ': 'S',
    }
    arm = {'ս': 'u', 'օ': 'o', 'ո': 'n', 'ց': 'g', 'հ': 'h', 'ԑ': 'e', 'ѕ': 's',
           'Ս': 'U', 'Օ': 'O', 'Ա': 'U'}
    arab = {'ﻩ': 'o', 'ﻪ': 'o', 'ﻫ': 'o', 'ﻬ': 'o', 'ه': 'o',
            'ھ': 'o', 'ہ': 'o'}
    for d in (cyr, grk, arm, arab):
        m.update(d)
    return m


LOOKALIKE = _mk_lookalikes()
MIXED_RUN_RE = re.compile(r'[^\W\d_]*[^\x00-\x7f\W\d_][^\W\d_]*')


def fold_homoglyphs(s):
    """Fold mixed-script lookalike letters. Returns (folded, [(start, end)])."""
    if s.isascii():
        return s, []
    runs = []
    out = None
    for m in MIXED_RUN_RE.finditer(s):
        run = m.group(0)
        ascii_n = 0
        look = 0
        other = False
        for ch in run:
            if ord(ch) < 0x80:
                ascii_n += 1
            elif ch in LOOKALIKE:
                look += 1
            else:
                other = True
                break
        if other or ascii_n == 0 or look == 0:
            continue
        if out is None:
            out = list(s)
        for k in range(m.start(), m.end()):
            r = LOOKALIKE.get(s[k])
            if r:
                out[k] = r
        runs.append((m.start(), m.end()))
    if out is None:
        return s, runs
    return ''.join(out), runs


def trailing_ws_count(raw):
    n = 0
    if raw[:1] and raw[0].isspace():
        n += 1
    lines = raw.split('\n')
    for ln in lines:
        body = ln[:-1] if ln.endswith('\r') else ln
        if body and body[-1] in ' \t':
            n += 1
    # two or more newlines at the end of the text
    j = len(raw)
    nl = 0
    while j > 0 and raw[j - 1] in '\r\n':
        if raw[j - 1] == '\n':
            nl += 1
        j -= 1
    if nl >= 2:
        n += 1
    return n


def clean_text(text):
    acts = classify(text)
    s, _ = apply_actions(text, acts, 'clean')
    s, _runs = fold_homoglyphs(s)
    crlf = '\r\n' in s
    ended_lf = text.endswith('\n') or text.endswith(' ') or text.endswith(' ')
    lines = s.split('\n')
    out = []
    for ln in lines:
        if ln.endswith('\r'):
            out.append(ln[:-1].rstrip(' \t') + '\r')
        else:
            out.append(ln.rstrip(' \t'))
    # drop leading blank lines
    k = 0
    while k < len(out) - 1 and out[k].strip(' \t\r') == '':
        k += 1
    out = out[k:]
    body = '\n'.join(out).rstrip()
    if ended_lf and body:
        body += '\r\n' if crlf else '\n'
    return body


# --------------------------------------------------------------------------
# Markup masking (length preserving)
# --------------------------------------------------------------------------

RE_ATX = re.compile(r'^ {0,3}#{1,6}(?:[ \t]|$)')
RE_LIST = re.compile(r'^ {0,3}(?:[-*+]|\d{1,9}[.)])(?:[ \t]+|$)')
RE_FENCE_OPEN = re.compile(r'^([ \t]*)(`{3,}|~{3,})(.*)$')
RE_TABLE_DELIM = re.compile(r'^[ \t]*\|?[ \t]*:?-+:?[ \t]*(?:\|[ \t]*:?-+:?[ \t]*)*\|?[ \t]*$')
RE_BADGE = re.compile(r'^[ \t]*(?:!?\[!?\[[^\]\n]*\]\([^)\n]*\)\]?\([^)\n]*\)?[ \t]*|!\[[^\]\n]*\]\([^)\n]*\)[ \t]*)+$')
RE_BADGE2 = re.compile(r'^[ \t]*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)[ \t]*)+$')
RE_HR = re.compile(r'^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$')
RE_INLINE_CODE = re.compile(r'(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)')


def mask_markup(t):
    lines = t.split('\n')
    n = len(lines)
    mask = [False] * n
    bare = [ln[:-1] if ln.endswith('\r') else ln for ln in lines]

    # YAML front matter
    start = 0
    if n and re.match(r'^---[ \t]*$', bare[0]):
        for j in range(1, n):
            if re.match(r'^(?:---|\.\.\.)[ \t]*$', bare[j]):
                for k in range(0, j + 1):
                    mask[k] = True
                start = j + 1
                break

    in_fence = None
    in_list = False
    prev_kind = 'blank'
    in_icode = False
    for i in range(start, n):
        ln = bare[i]
        blank = ln.strip() == ''
        if in_fence is not None:
            mask[i] = True
            m = re.match(r'^[ \t]*(`{3,}|~{3,})[ \t]*$', ln)
            if m and m.group(1)[0] == in_fence[0] and len(m.group(1)) >= len(in_fence):
                in_fence = None
                prev_kind = 'other'
            continue
        if blank:
            # blank lines inside an indented code block stay part of it
            prev_kind = 'blank' if not in_icode else 'blank_code'
            continue
        indent_ok = in_list or (len(ln) - len(ln.lstrip(' ')) <= 3 and not ln.startswith('\t'))
        m = RE_FENCE_OPEN.match(ln)
        if m and indent_ok and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            in_fence = m.group(2)
            mask[i] = True
            in_icode = False
            prev_kind = 'other'
            continue
        indented4 = ln.startswith('    ') or ln.startswith('\t')
        if indented4:
            if prev_kind in ('para', 'list'):
                continue
            if in_list:
                prev_kind = 'list'
                continue
            if prev_kind in ('blank', 'heading', 'other', 'code', 'blank_code'):
                mask[i] = True
                in_icode = True
                if prev_kind == 'blank_code':
                    # the blank lines between were code too (already blank)
                    pass
                prev_kind = 'code'
                continue
        in_icode = False
        if RE_ATX.match(ln):
            prev_kind = 'heading'
            in_list = False
            continue
        if RE_HR.match(ln):
            prev_kind = 'other'
            continue
        if RE_LIST.match(ln):
            in_list = True
            prev_kind = 'list'
            continue
        if prev_kind in ('blank', 'blank_code', 'heading', 'other', 'code') and not ln.startswith('  '):
            in_list = False
        prev_kind = 'para'

    # blockquote runs of two or more lines
    i = start
    while i < n:
        if re.match(r'^ {0,3}>', bare[i]) and not mask[i]:
            j = i
            while j < n and re.match(r'^ {0,3}>', bare[j]) and not mask[j]:
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1

    # tables
    for i in range(start, n):
        if mask[i]:
            continue
        ln = bare[i]
        if '|' in ln and '-' in ln and RE_TABLE_DELIM.match(ln) and ('|' in ln):
            mask[i] = True
            if i > 0 and '|' in bare[i - 1] and bare[i - 1].strip():
                mask[i - 1] = True
            j = i + 1
            while j < n and bare[j].strip() and '|' in bare[j]:
                mask[j] = True
                j += 1
        elif ln.lstrip().startswith('|') and ln.rstrip().endswith('|') and len(ln.strip()) > 1:
            mask[i] = True
        # badges
        if not mask[i] and ('![' in ln) and (RE_BADGE2.match(ln) or
                                               re.match(r'^[ \t]*(?:!\[[^\]\n]*\]\([^)\n]*\)[ \t]*)+$', ln)):
            mask[i] = True

    out = []
    for i in range(n):
        raw_line = lines[i]
        cr = raw_line.endswith('\r')
        body = bare[i]
        if mask[i]:
            out.append(' ' * len(body) + ('\r' if cr else ''))
        else:
            if '`' in body:
                body = RE_INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), body)
            out.append(body + ('\r' if cr else ''))
    return '\n'.join(out)


# --------------------------------------------------------------------------
# Text structure helpers
# --------------------------------------------------------------------------

QUOTE_TR = {0x2018: "'", 0x2019: "'", 0x02BC: "'", 0x201B: "'", 0x201C: '"', 0x201D: '"', 0x201F: '"'}
RE_WORD = re.compile(r"(?:[^\W_]|['\-])+")
ABBR = re.compile(r'\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|vs|etc|Inc|Ltd|No|approx|fig|Fig|Co|Corp)\.')
RE_SENT_SPLIT = re.compile(r'(?<=[.!?])["\')\]]*\s+(?=["\'(\[]?[A-Z0-9])')


def count_words(s):
    return len(RE_WORD.findall(s))


def line_kind(ln):
    if RE_ATX.match(ln):
        return 'heading'
    if RE_HR.match(ln):
        return 'hr'
    if RE_LIST.match(ln):
        return 'list'
    if ln.lstrip().startswith('|'):
        return 'table'
    return 'text'


def build_flat(P):
    """Join hard-wrapped plain lines with spaces (length preserving)."""
    lines = P.split('\n')
    kinds = [None if not l.strip() else line_kind(l) for l in lines]
    out = []
    for i, l in enumerate(lines):
        out.append(l)
        if i < len(lines) - 1:
            if kinds[i] == 'text' and kinds[i + 1] == 'text':
                out.append(' ')
            else:
                out.append('\n')
    return ''.join(out)


def split_sentences(seg):
    seg = ABBR.sub(lambda m: m.group(1) + '\x00', seg)
    parts = RE_SENT_SPLIT.split(seg)
    res = []
    for p in parts:
        p = p.replace('\x00', '.').strip()
        if p:
            res.append(p)
    return res


def structure(P):
    """Return paragraphs: list of dicts with lines, kinds, sentences."""
    paras = []
    cur = []
    for ln in P.split('\n'):
        if not ln.strip():
            if cur:
                paras.append(cur)
                cur = []
        else:
            cur.append(ln.rstrip('\r'))
    if cur:
        paras.append(cur)
    result = []
    for lines in paras:
        kinds = [line_kind(l) for l in lines]
        segs = []
        buf = []
        for l, k in zip(lines, kinds):
            if k == 'text':
                buf.append(l.strip())
            else:
                if buf:
                    segs.append(' '.join(buf))
                    buf = []
                if k == 'list':
                    segs.append(RE_LIST.sub('', l, count=1).strip())
        if buf:
            segs.append(' '.join(buf))
        sentences = []
        for s in segs:
            sentences.extend(split_sentences(s))
        result.append({'lines': lines, 'kinds': kinds, 'sentences': sentences,
                       'prose': any(k == 'text' for k in kinds)})
    return result


def cv(values):
    if not values:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


# --------------------------------------------------------------------------
# Pattern catalogue
# --------------------------------------------------------------------------

I = re.I
M = re.M


def R(p, flags=I):
    return re.compile(p, flags)


V1 = R(r"\b(?:additionally|align(?:s|ed|ing)? with|crucial(?:ly)?|delv(?:e|es|ed|ing)|tapestr(?:y|ies)|"
       r"pivotal|vibrant|meticulous(?:ly)?|testaments?|underscor(?:e|es|ed|ing)|intricate(?:ly)?|"
       r"intricacies|intricacy|interplay|garner(?:s|ed|ing)?|bolster(?:s|ed|ing)?|foster(?:s|ed|ing)?|"
       r"showcas(?:e|es|ed|ing)|emphasi[sz](?:e|es|ed|ing)|enduring|enhanc(?:e|es|ed|ing)|"
       r"leverag(?:e|es|ed|ing)|utili[sz](?:e|es|ed|ing)|facilitat(?:e|es|ed|ing)|"
       r"encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?|holistic(?:ally)?|paradigms?|transformative|"
       r"unprecedented|myriad|plethora|robust(?:ness)?|seamless(?:ly)?|navigat(?:e|es|ed|ing)|"
       r"embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|landscapes?|journey(?:s|ed|ing)?|journeys|realms?|"
       r"multifaceted|elevat(?:e|es|ed|ing)|empower(?:s|ed|ing|ment)?|unlock(?:s|ed|ing)?|"
       r"captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic))\b")

V2 = R(r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly|"
       r"quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)|"
       r"resonat(?:e|es|ed|ing) deeply|game[- ]chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|"
       r"skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioni[sz](?:e|es|ed|ing)|"
       r"doubl(?:e|es|ed|ing) down on|div(?:e|es|ed|ing) deeper? into|dove deeper? into|"
       r"unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)|"
       r"(?:take|takes|took|taking|taken) [^.!?\n]{1,40}? to the next level)\b")

V3 = R(r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|"
       r"rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|"
       r"leading(?! to\b| up\b| me\b| us\b| them\b| off\b| the way\b)|esteemed organi[sz]ation|"
       r"valuable asset|passion for excellence|proven track record|results-oriented|"
       r"wealth of experience|dynamic team|fast-paced environment|deeply passionate|"
       r"perfectly situated|(?:close|tight)-knit team|i am excited to (?:apply|bring)|"
       r"uniquely positioned to)\b")

PROMO_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
               'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
               'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
               'stop', 'start'}

# generic regex families: number -> (slug, label, regex)
FAMILIES = {}


def fam(num, slug, label, pattern, flags=I):
    FAMILIES[num] = (slug, label, re.compile(pattern, flags))


fam(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse',
    r"\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|detail-oriented|data-driven|"
    r"forward-thinking|customer-centric|mission-critical|game-changing|future-proof|end-to-end|"
    r"well-rounded|cross-functional|next-generation|industry-leading|award-winning|time-tested|"
    r"tried-and-true|top-notch|high-impact|value-added|fast-growing|world-renowned|"
    r"\w+-(?:driven|oriented|centric|focused))\b")
fam(5, 'simple_yet', '"Simple yet X" cliche',
    r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
fam(10, 'significance_inflation', 'Significance inflation',
    r"\b(?:(?:stands?|stood|serves?|served|serving|standing) as (?:an? |the )?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)|"
    r"(?:underscor(?:es|ed|ing)|highlight(?:s|ed|ing)) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)|"
    r"reflect(?:s|ed|ing) a broader (?:trend|shift|pattern)|"
    r"mark(?:s|ed|ing)? an? (?:turning point|milestone|watershed|new chapter|new era)|"
    r"symboli[sz](?:es|ed|ing)|sets? the stage for|setting the stage for|left an indelible mark|"
    r"play(?:s|ed|ing)? an? (?:crucial|pivotal|vital|key|central|significant) role|"
    r"(?:has|have) (?:shaped|sparked)|has come to (?:define|symboli[sz]e))\b")
fam(12, 'vague_attributions', 'Vague attributions',
    r"\b(?:experts (?:argue|believe|say|claim|note|suggest)|industry (?:reports|observers|analysts)|"
    r"observers have (?:cited|noted)|some critics argue|researchers have found|studies suggest|"
    r"it is widely believed|it's widely believed)\b")
fam(13, 'article_title_proper_noun', 'Article title treated as a proper noun',
    r"\bthe (?:list|index|compilation|collection|catalogue|guide|overview) of (?:[\w'&:,-]+ ){1,8}?(?:is|are|was|were) (?:an?|the)\b")
fam(14, 'conservation_padding', 'Conservation / ecosystem padding',
    r"\b(?:plays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem|"
    r"conservation efforts are (?:underway|ongoing|in place)|serves? as an indicator species|"
    r"contribut(?:es|ing) to biodiversity)\b")
fam(15, 'false_ranges', 'False ranges',
    r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?"
    r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
fam(16, 'ing_tails', 'Superficial -ing tail clauses',
    r",\s*(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|"
    r"showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|"
    r"representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|"
    r"epitomizing|epitomising)\b")
fam(18, 'not_x_just_y', '"Not X, just Y" construction',
    r"\b(?:no|not) \w+, (?:just|only|simply) \w+|"
    r"\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely) (?:(?:a|an|the) )?\w+(?:,|\s*[\u2014\u2013-]+)\s*"
    r"(?:it's|it is|it was|they're|they are|they were|that's|but)\b")
fam(19, 'filler_phrases', 'Filler phrases',
    r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to|"
    r"it is important to note that|it should be mentioned that|needless to say)\b")
fam(20, 'empty_pivots', 'Empty pivot phrases',
    r"\b(?:it(?:'s| is) worth (?:noting|mentioning) that|it bears (?:noting|mentioning) that|"
    r"one thing to (?:consider|keep in mind) is|it is interesting to note that|a key consideration is|"
    r"a point to highlight is)\b")
fam(21, 'outcome_tails', 'Outcome-speculation tails',
    r",\s*(?:raising questions about|prompting reflection on|sparking debate about|"
    r"with broader implications for|reshaping our understanding of|paving the way for|"
    r"signaling a shift toward|signalling a shift toward)\b")
fam(22, 'authority_tropes', 'Persuasive authority tropes',
    r"\b(?:here's the thing|make no mistake|the truth is|let's be honest|the simple fact is|at its core|"
    r"what really matters|more than anything|at the end of the day|the bottom line is|in reality|"
    r"the real question is|the heart of the matter|the deeper issue|when you get down to it|"
    r"when all is said and done)\b|\bfundamentally,")
fam(23, 'editorial_interjections', 'Editorial interjections',
    r"\bit(?:'s| is) important to (?:remember|note|understand|recognize|recognise)\b|\bone must note that\b|"
    r"\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasi[sz]ed that\b")
fam(24, 'self_thoroughness', 'Self-thoroughness phrases',
    r"\b(?:this (?:comprehensive (?:guide|overview|analysis)|in-depth (?:analysis|look|examination)|"
    r"complete (?:guide|overview))|a thorough examination of|everything you need to know about)\b")
fam(26, 'concrete_evidence', '"Concrete evidence" defense phrase',
    r"\b(?:without concrete evidence|do you have concrete evidence|i (?:would )?need concrete (?:evidence|examples) to|"
    r"absent concrete proof|provide concrete evidence)\b")
fam(27, 'intro_hooks', 'Compulsive intro hooks',
    r"\bin today's (?:[\w-]+ ){0,2}(?:world|landscape|environment|market)\b|\bin a world where\b|"
    r"\bin an era of\b|\bin recent years,|\bmore than ever before\b|\bwe live in an? (?:time|world)\b|"
    r"\b(?:great|exciting|big) news\s*[!:]|\bever (?:wanted|wondered|dreamed|wished) to\b[^.!?\n]*\?|"
    r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")
fam(30, 'diff_anchored', 'Diff-anchored writing',
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b|"
    r"\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) "
    r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b|"
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b|"
    r"\bpreviously\b[^.!?\n]{0,80}?\bnow\b|\b(?:wasn't|weren't) there before\b|"
    r"\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b")
fam(31, 'signposting', 'Signposting and announcements',
    r"\blet's (?:dive|delve|explore)\b|\blet's break (?:this|it) down\b|\bhere's what you need to know\b|"
    r"\bwithout further ado\b|\bnow let's look at\b|\bbuckle up\b|\bstay with me\b|\b(?:are you )?ready to dive in\b")
fam(32, 'cataloguing_leadins', 'Cataloguing lead-ins',
    r"\b(?:used|uses|employs|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+|"
    r"(?:^|[.!?][\"')\]]*\s+)These (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help)\w*\b[^.!?\n]{0,40}?"
    r"\b(?:information|insights?|understanding|details|data)\b|"
    r"\b(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|"
    r"backbone|bedrock|engine|scaffolding|connective tissue) of\b")
fam(36, 'formulaic_challenges', 'Formulaic challenges sections',
    r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b|"
    r"\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b|\bfaces (?:several|many|numerous) challenges\b")
fam(38, 'compulsive_conclusions', 'Compulsive conclusion phrases',
    r"^[ \t]*(?:[-*>][ \t]*)?(?:in conclusion|overall|in summary|to summarize|to summarise|to conclude|all in all|"
    r"in essence|ultimately)\b", I | M)
fam(39, 'generic_positive_conclusions', 'Generic positive conclusions',
    r"\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b|"
    r"\bstep in the right direction\b|\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40}?)? (?:is|looks|remains) bright\b|"
    r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b")
fam(47, 'chatbot_artifacts', 'Chatbot artifacts',
    r"\bi hope this helps\b|\b(?:certainly|of course)!|\blet me know if you\b|\bwould you like me to\b|"
    r"\bfeel free to (?:ask|reach out)\b|\bhappy to help(?=[ \t]*(?:[.!?]|$))|"
    r"\b(?:here|below) is (?:an? |the )?(?:overview|summary|rundown|recap|brief)\b|"
    r"\bhere(?: are|'s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b|"
    r"\bhere(?: is|'s) a draft\b|\bdepending on the (?:vibe|tone|style)\b|"
    r"\bi hope (?:this email )?finds you well\b|"
    r"\bas an? (?:ai|llm|ai assistant|ai language model|large language model|language model)\b|"
    r"\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b|"
    r"\byour question (?:about|regarding|concerning)\b|\bas (?:you )?(?:requested|asked), here\b|"
    r"\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b", I | M)
fam(48, 'sycophantic_tone', 'Sycophantic tone',
    r"\byou(?:'re| are) absolutely right\b|\b(?:great question|excellent point)\s*[!.,]|"
    r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\s*[!.,]|"
    r"\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\s*[!.,]")
fam(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers',
    r"\bas of my (?:last )?(?:training|knowledge)\b|\bup to my (?:last )?(?:training|knowledge)\b|"
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b|"
    r"\bbased on (?:the )?available information\b|\bas of my (?:knowledge )?cutoff\b|"
    r"\b(?:maintains?|maintained) a low profile\b|\bkeeps? (?:his|her|their) personal life private\b")
fam(51, 'copula_avoidance', 'Copula avoidance',
    r"\b(?:serves|stands|functions|acts) as\b|\brepresents (?:a|the)\b|\bmarks (?:a|the)\b|\bboasts?\b|"
    r"\bfeatures (?:an?|the|\d+|two|three|four|five|six|seven|eight|nine|ten|several|many|numerous|various|"
    r"multiple|some|dozens|a number|a variety)\b|\boffers an?\b|\brefers to\b")
fam(56, 'boldface', 'Boldface overuse', r"\*\*[^*\n]+\*\*")
fam(61, 'year_ranges', 'Hyphen in numeric year ranges',
    r"(?<![\d-])(?:1[5-9]\d\d|20\d\d)-(?:1[5-9]\d\d|20\d\d)(?![\d-])")
fam(63, 'placeholder_text', 'Placeholder text',
    r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])|"
    r"\[(?:the )?(?:[\w'-]+ ){0,3}?(?:name|company|client|city|town|place|location|person|source|recipient|"
    r"employer|organi[sz]ation|contact)s?\](?![(\[])|"
    r"\{\{[^{}\n]*\}\}|(?<![A-Za-z])[xX]{3,}(?![A-Za-z])|\blorem ipsum\b")
fam(64, 'chat_markup_leak', 'Chat reference markup leak',
    "\\bcite[\ue200-\ue206]?(?:turn|start|nav)|\\boai_citation|contentReference|\\bnavlist|\u3010\\d+[^\u3011\\n]*\u2020[^\u3011\\n]*\u3011")
fam(69, 'marketing_slop', 'Canonical marketing-slop phrases',
    r"\bunlock(?:ing)? (?:its |their |your |the )?full potential\b|\bnavigat(?:e|es|ing) the complexities\b|"
    r"\ba testament to the (?:power|importance)\b|\bstay(?:s|ing)? ahead of the curve\b|"
    r"\bturning challenges into opportunities\b|\btak(?:e|es|ing) (?:\w+ ){1,3}to the next level\b|"
    r"\bharness(?:es|ing)? the power of\b|\bpav(?:e|es|ing) the way for\b|\bsaying goodbye to\b|"
    r"\bimagin(?:e|ing) a world where\b|\bin the ever-evolving (?:world|landscape)\b|"
    r"\bin today's fast-paced world\b")

RE_ALL_CAPS_SLOT = re.compile(r"\[[A-Z][A-Z0-9 _/'&-]*\](?![(\[])")
RE_TAIL_NEG = R(r",\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b")
RE_PARALLEL = R(r"\bit's not (?:just|merely) (?:about|an?)\b|\bnot only\b[^.!?\n]{0,40}?\bbut\b|"
                r"\bdoesn't just\b[^,.\n]{0,40}?\bit\b")
RE_UTM = R(r"utm_source=([A-Za-z0-9.\-]+)")
AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
            'copilot.microsoft.com', 'poe.com'}
RE_NOTABLE = re.compile(
    r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+)"
    r"[^.!?\n]*?[A-Z][\w&.'-]*(?:\s+[A-Z][\w&.'-]*)*\s*(?:,\s*(?:(?i:and|or)\s+)?|\s+(?i:and|or)\s+)[A-Z]|"
    r"(?i:\b\d[\d,.]*\s*[km]?\+?\s+(?:followers|subscribers)\b|"
    r"\b(?:strong|active|significant|notable)\s+(?:online|digital|social[- ]media)\s+presence\b|"
    r"\bwidely covered\b|\bindependent coverage\b)")
RE_QA = R(r"(?:^|[.!?][\"')\]]*[ \t]+|\n)(?:is|are|was|were|do|does|did|can|could|will|would|should|shall|may|might|must|has|have|had)\b"
          r"[^.!?\n]{0,100}\?[ \t\n]+(?:yes|no|absolutely|never|maybe|probably|always)[.!]", I)
RE_TRANSITION = re.compile(
    r"(?:^|[.!?][\"')\]]*\s+)(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b", M)
RE_BOLD_HEAD = re.compile(r"^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", M)
RE_EMOJI = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF\u2600-\u27BF\u2B50\u2B55\u2B1B\u2B1C"
                      "\u2934\u2935\u2B05-\u2B07\u231A\u231B\u23E9-\u23F3\u23F8-\u23FA\u25B6\u25C0\u25FB-\u25FE]")
RE_CURLY = re.compile("[\u2018\u2019\u201C\u201D]")
RE_EM = re.compile("\u2014")
STOCK_ADJ = set("""innovative dynamic powerful scalable seamless robust comprehensive modern efficient reliable
secure flexible intuitive engaging compelling rich diverse unique vibrant bold exciting cutting-edge
dedicated passionate talented skilled creative strategic impactful transformative holistic stunning
beautiful essential vital critical key smart simple fast clean elegant sleek thriving lively""".split())
CHAIN_STOP = set("""the a an and or but of in on at to for with by from as is are was were be been it its this
that these those i you he she we they not no so if then than""".split())
ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$")
RE_CHAIN = re.compile(r"\b(?:[a-z][a-z'-]*,\s+){2,}(?:and\s+)?[a-z][a-z'-]*(?:\s+[a-z][a-z'-]*)?", I)
RE_HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|"
                      r"\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind of\b|\bsort of\b")
SYN_CLUSTERS = [
    [r"protagonists?", r"main characters?", r"central figures?", r"heroes|hero", r"heroines?"],
    [r"compan(?:y|ies)", r"firms?", r"organi[sz]ations?", r"enterprises?", r"business(?:es)?"],
    [r"authors?", r"writers?", r"novelists?", r"scribes?"],
    [r"reports?", r"stud(?:y|ies)", r"analys[ie]s", r"investigations?", r"examinations?"],
    [r"technolog(?:y|ies)", r"tools?", r"systems?", r"platforms?", r"solutions?"],
    [r"techniques?", r"methods?", r"approach(?:es)?", r"strateg(?:y|ies)", r"tactics?"],
    [r"challenges?", r"obstacles?", r"difficult(?:y|ies)", r"hurdles?", r"barriers?"],
    [r"benefits?", r"advantages?", r"upsides?", r"strengths?"],
]
SYN_RX = [[re.compile(r"\b(?:%s)\b" % m, I) for m in cl] for cl in SYN_CLUSTERS]
SMALL_WORDS = set("a an the and but or nor for so yet of in on at to by up as with from into over off per via vs is".split())

LABELS = {
    1: ('ai_vocabulary', 'AI vocabulary'),
    2: ('model_dialect', 'Model-dialect vocabulary'),
    3: ('promotional_language', 'Promotional language'),
    6: ('stacked_adjectives', 'Stacked adjective chains'),
    8: ('synonym_cycling', 'Synonym cycling'),
    11: ('notability_name_dropping', 'Notability name-dropping'),
    25: ('question_answer', 'Question-answer rhetorical pattern'),
    33: ('inline_header_lists', 'Inline-header vertical lists'),
    34: ('mid_essay_bullets', 'Mid-essay bullet injection'),
    35: ('fragmented_headers', 'Fragmented headers'),
    37: ('transition_clusters', 'Transition cluster overuse'),
    40: ('sentence_length_monotony', 'Sentence-length monotony'),
    41: ('length_alternation', 'Mechanical sentence-length alternation'),
    42: ('opener_repetition', 'Opener repetition'),
    44: ('uniform_paragraphs', 'Uniform paragraph length'),
    46: ('punctuation_underuse', 'Semicolon and parenthesis underuse'),
    54: ('hedge_stacking', 'Excessive hedging'),
    55: ('contraction_absence', 'Contraction absence'),
    57: ('emojis', 'Emojis'),
    58: ('em_dash_overuse', 'Em-dash overuse'),
    59: ('title_case_headings', 'Title case in headings'),
    60: ('curly_quotes', 'Curly quotation marks'),
    62: ('invisible_characters', 'Invisible / zero-width characters'),
    65: ('ai_tracking_params', 'AI tracking parameters'),
    66: ('homoglyphs', 'Homoglyph / mixed-script confusables'),
    67: ('nonstandard_spaces', 'Non-standard spaces'),
    68: ('trailing_whitespace', 'Trailing / stray whitespace'),
    70: ('decorative_rules', 'Decorative horizontal rules'),
    71: ('degenerate_repetition', 'Degenerate repetition'),
}

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM_SM = {40, 44}
SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
WEIGHTS = {
    1: 14, 2: 8, 3: 12, 5: 8, 6: 8, 8: 6, 10: 12, 11: 10, 12: 10, 13: 20, 14: 8, 15: 8, 16: 12,
    17: 8, 18: 10, 20: 10, 21: 10, 23: 8, 24: 8, 25: 6, 26: 8, 27: 10, 30: 8, 31: 10, 32: 8,
    33: 6, 34: 6, 35: 5, 36: 8, 37: 8, 38: 10, 39: 10, 40: 6, 44: 5, 47: 25, 48: 25, 50: 25,
    51: 6, 56: 5, 57: 6, 59: 4, 62: 25, 63: 25, 64: 30, 65: 30, 66: 25, 67: 6, 69: 12, 70: 4,
    71: 25,
}
BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]


def short(s, n=80):
    s = re.sub(r'\s+', ' ', s).strip()
    if len(s) > n:
        s = s[:n - 1] + '\u2026'
    return s


class Collector(object):
    def __init__(self):
        self.items = []  # (num, slug, label, count, samples)

    def add(self, num, slug, label, count, samples):
        if count > 0:
            self.items.append((num, slug, label, count, [short(x) for x in samples[:3]]))


def excerpt(raw, a, b, idx):
    if idx is not None and idx:
        a = idx[min(a, len(idx) - 1)]
        b = idx[min(max(b - 1, 0), len(idx) - 1)] + 1
    start = max(0, a - 28)
    end = min(len(raw), b + 28)
    s = raw[start:end]
    s = ''.join(' ' if ch in '\r\n' else ch for ch in s)
    if start > 0:
        s = '...' + s
    if end < len(raw):
        s = s + '...'
    return s


def analyze(text, want_samples=True):
    """Return (items, metrics) for the first WINDOW characters of text."""
    raw = text[:WINDOW]
    truncated = len(text) > WINDOW
    acts = classify(raw)
    inv = 0
    nonstd = 0
    inv_codes = []
    for i, kind in acts:
        if kind == 'inv_rm':
            inv += 1
            if len(inv_codes) < 3:
                inv_codes.append('U+%04X' % ord(raw[i]))
        elif kind in ('sp_norm', 'nl_norm'):
            nonstd += 1
    lex, idx = apply_actions(raw, acts, 'lex')
    lex, hg_runs = fold_homoglyphs(lex)
    P = mask_markup(lex)
    Pn = P.translate(QUOTE_TR)
    flat = build_flat(Pn)
    col = Collector()

    # ---- character layer
    if inv:
        col.items.append((62, LABELS[62][0], LABELS[62][1], inv,
                          ['invisible characters: ' + ', '.join(inv_codes)]))
    if hg_runs:
        smp = [lex[a:b] for a, b in hg_runs[:3]]
        col.items.append((66, LABELS[66][0], LABELS[66][1], len(hg_runs), [short(x) for x in smp]))
    if nonstd:
        col.items.append((67, LABELS[67][0], LABELS[67][1], nonstd, ['non-standard space characters']))
    tw = trailing_ws_count(raw)
    if tw:
        col.items.append((68, LABELS[68][0], LABELS[68][1], tw, ['trailing or stray whitespace']))
    cq = len(RE_CURLY.findall(P))
    if cq:
        col.items.append((60, LABELS[60][0], LABELS[60][1], cq, ['curly quotation marks']))

    # ---- regex families
    for num, (slug, label, rx) in sorted(FAMILIES.items()):
        if num in (63,):
            continue
        target = Pn if num in (38, 33, 56, 32, 47) else flat
        if num == 56:
            target = Pn
        ms = list(rx.finditer(target))
        if ms:
            col.add(num, slug, label, len(ms), [m.group(0) for m in ms])
    # placeholders (63)
    ph = [m.group(0) for m in FAMILIES[63][2].finditer(flat)]
    for m in RE_ALL_CAPS_SLOT.finditer(Pn):
        body = m.group(0)[1:-1]
        letters = re.sub(r'[^A-Z]', '', body)
        if len(letters) >= 3:
            ph.append(m.group(0))
    if ph:
        col.add(63, FAMILIES[63][0], FAMILIES[63][1], len(ph), ph)

    # AI vocabulary (1) with raw excerpts
    ms = list(V1.finditer(flat))
    if ms:
        smp = [excerpt(raw, m.start(), m.end(), idx) for m in ms[:3]]
        col.items.append((1, LABELS[1][0], LABELS[1][1], len(ms), smp))
    ms = list(V2.finditer(flat))
    if len(ms) >= 2:
        col.add(2, LABELS[2][0], LABELS[2][1], len(ms), [m.group(0) for m in ms])

    structure_paras = structure(Pn)
    all_sentences = []
    for sp in structure_paras:
        if sp['prose'] or any(k == 'list' for k in sp['kinds']):
            all_sentences.extend(sp['sentences'])

    # promotional (3)
    ms = list(V3.finditer(flat))
    n3 = len(ms)
    smp3 = [m.group(0) for m in ms]
    imp = [s for s in all_sentences
           if (RE_WORD.match(s) and s.split()[0].strip('"\'(,').lower() in PROMO_VERBS)]
    if len(imp) >= 3:
        n3 += len(imp)
        smp3.extend(imp)
    col.add(3, LABELS[3][0], LABELS[3][1], n3, smp3)

    # notability (11)
    ms = list(RE_NOTABLE.finditer(flat))
    col.add(11, LABELS[11][0], LABELS[11][1], len(ms), [m.group(0) for m in ms])

    # 17
    ms = list(RE_PARALLEL.finditer(flat))
    if ms:
        col.items.append((17, 'negative_parallelism', 'Negative parallelism', len(ms),
                          [short(m.group(0)) for m in ms[:3]]))
    ms = list(RE_TAIL_NEG.finditer(flat))
    if ms:
        col.items.append((17, 'tailing_negation', 'Tailing negation', len(ms),
                          [short(m.group(0)) for m in ms[:3]]))

    # 25
    ms = list(RE_QA.finditer(flat))
    col.add(25, LABELS[25][0], LABELS[25][1], len(ms), [m.group(0) for m in ms])

    # 6 stacked adjectives
    chains = []
    for m in RE_CHAIN.finditer(flat):
        s = m.group(0)
        words = re.findall(r"[a-z][a-z'-]*", s.lower())
        if len(words) < 4 or any(w in CHAIN_STOP and w != 'and' for w in words):
            continue
        words = [w for w in words if w != 'and']
        if len(words) < 4:
            continue
        last = words[-1]
        if ADJ_SUFFIX.search(last) or last in STOCK_ADJ:
            continue
        if any((ADJ_SUFFIX.search(w) and len(w) > 4) or w in STOCK_ADJ for w in words[:-1]):
            chains.append(s)
    col.add(6, LABELS[6][0], LABELS[6][1], len(chains), chains)

    # 8 synonym cycling
    syn_hits = 0
    syn_smp = []
    low = flat
    for cl in SYN_RX:
        present = []
        for rx in cl:
            c = len(rx.findall(low))
            if c:
                present.append((rx, c))
        if len(present) >= 3:
            syn_hits += sum(c for _, c in present)
            syn_smp.append(', '.join(rx.search(low).group(0) for rx, _ in present))
    col.add(8, LABELS[8][0], LABELS[8][1], syn_hits, syn_smp)

    # 33 / 34 / 35 / 59 line-structured
    ms = list(RE_BOLD_HEAD.finditer(Pn))
    col.add(33, LABELS[33][0], LABELS[33][1], len(ms), [m.group(0) for m in ms])

    plines = Pn.split('\n')
    has_heading = any(RE_ATX.match(l) for l in plines)
    if not has_heading:
        list_only = 0
        prose_paras = 0
        for sp in structure_paras:
            if all(k == 'list' for k in sp['kinds']):
                list_only += 1
            elif all(k == 'text' for k in sp['kinds']):
                prose_paras += 1
        if list_only >= 1 and prose_paras >= 2:
            col.add(34, LABELS[34][0], LABELS[34][1], list_only, ['bulleted block inside running prose'])

    frag = []
    for i, l in enumerate(plines):
        if RE_ATX.match(l):
            heading = re.sub(r'^\s*#+\s*|\s*#+\s*$', '', l.rstrip('\r'))
            hw = set(w for w in re.findall(r"[a-z0-9]+", heading.lower()) if len(w) >= 3 and w not in SMALL_WORDS)
            j = i + 1
            while j < len(plines) and not plines[j].strip():
                j += 1
            if j < len(plines) and j > i:
                nl = plines[j].rstrip('\r')
                if line_kind(nl) == 'text' and 0 < count_words(nl) <= 5:
                    nw = set(re.findall(r"[a-z0-9]+", nl.lower()))
                    if hw & nw:
                        frag.append(heading)
    col.add(35, LABELS[35][0], LABELS[35][1], len(frag), frag)

    tc = []
    for l in plines:
        m = re.match(r'^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*\r?$', l)
        if not m:
            continue
        h = m.group(1)
        ws = h.split()
        if len(ws) < 3 or not h[0].isalpha():
            continue
        if h == h.upper():
            continue
        major = [w for w in ws if w.strip('*_`"\'(),:;').lower() not in SMALL_WORDS]
        if len(major) >= 2 and all(w.strip('*_`"\'(').lstrip()[:1].isupper() for w in major):
            tc.append(h)
    col.add(59, LABELS[59][0], LABELS[59][1], len(tc), tc)

    # 37 transitions, 42 opener repetition, 58 em dash, 54 hedges
    tr_count = 0
    em_count = 0
    opener = 0
    hedge = 0
    tr_smp = []
    for sp in structure_paras:
        ptxt = '\n'.join(sp['lines'])
        ms = RE_TRANSITION.findall(ptxt)
        if len(ms) >= 2:
            tr_count += len(ms)
            tr_smp.append(ms[0].strip(' .!?\n'))
        ne = ptxt.count('\u2014')
        if ne >= 2:
            em_count += ne
        sents = sp['sentences']
        if len(sents) >= 3:
            c = Counter(' '.join(s.lower().split()[:2]) for s in sents if len(s.split()) >= 2)
            if c and max(c.values()) >= 3:
                opener += 1
        for s in sents:
            if len(RE_HEDGE.findall(s)) >= 2:
                hedge += 1
    col.add(37, LABELS[37][0], LABELS[37][1], tr_count, tr_smp)
    col.add(58, LABELS[58][0], LABELS[58][1], em_count, ['multiple em dashes in one paragraph'])
    col.add(42, LABELS[42][0], LABELS[42][1], opener, ['repeated sentence openers'])
    col.add(54, LABELS[54][0], LABELS[54][1], hedge, ['stacked hedges'])

    # emojis (57)
    ems = RE_EMOJI.findall(P)
    col.add(57, LABELS[57][0], LABELS[57][1], len(ems), ems)

    # rhythm
    sent_lens = [count_words(s) for s in all_sentences]
    sent_lens = [x for x in sent_lens if x > 0]
    if len(sent_lens) >= 3:
        c = cv(sent_lens)
        if c is not None and c < 0.35:
            col.add(40, LABELS[40][0], LABELS[40][1], len(sent_lens), ['sentence lengths barely vary'])
    # alternation
    if len(sent_lens) >= 6:
        run = 1
        best = 1
        prev_sign = 0
        for a, b in zip(sent_lens, sent_lens[1:]):
            d = b - a
            ok = abs(d) >= 5 and max(a, b) >= 1.5 * max(1, min(a, b))
            sign = 1 if d > 0 else -1
            if ok and (prev_sign == 0 or sign == -prev_sign):
                run += 1
                prev_sign = sign
            elif ok:
                run = 2
                prev_sign = sign
            else:
                run = 1
                prev_sign = 0
            best = max(best, run)
        if best >= 6:
            col.add(41, LABELS[41][0], LABELS[41][1], 1, ['short-long alternation'])
    # uniform paragraphs
    plens = []
    for sp in structure_paras:
        if sp['prose']:
            plens.append(count_words(' '.join(l for l, k in zip(sp['lines'], sp['kinds']) if k != 'heading')))
    plens = [x for x in plens if x > 0]
    if len(plens) >= 4:
        c = cv(plens)
        if c is not None and c < 0.4:
            col.add(44, LABELS[44][0], LABELS[44][1], len(plens), ['paragraph lengths barely vary'])

    # words
    words_list = RE_WORD.findall(Pn)
    nwords = len(words_list)

    # 46, 55
    if nwords >= 300 and ';' not in Pn and Pn.count('(') <= 1:
        col.add(46, LABELS[46][0], LABELS[46][1], 1, ['no semicolons, almost no parentheses'])
    fp = len(re.findall(r"\b(?:i|me|my|mine|myself|we|our|ours|ourselves)\b", Pn, I))
    if nwords and fp / float(nwords) >= 0.025:
        contr = len(re.findall(r"\b(?:\w+n't|\w+'(?:re|ve|ll|m|d)|(?:it|that|there|here|he|she|what|let|who)'s)\b", Pn, I))
        full = len(re.findall(r"\b(?:do|does|did|is|are|was|were|have|has|had|would|could|should|will|can|must) not\b|"
                              r"\bcannot\b|\b(?:i am|i have|i will|i would|we are|we have|we will|they are|they have|"
                              r"you are|you will|it is|that is|there is|he is|she is|what is|let us)\b", Pn, I))
        if full >= 3 and full / float(full + contr) >= 0.6:
            col.add(55, LABELS[55][0], LABELS[55][1], full, ['contractions written out in full'])

    # 65 tracking params
    trk = []
    for m in RE_UTM.finditer(Pn):
        host = m.group(1).rstrip('.-').lower()
        if host in AI_HOSTS:
            trk.append(m.group(0))
    col.add(65, LABELS[65][0], LABELS[65][1], len(trk), trk)

    # 70 horizontal rules
    hr = 0
    for i, l in enumerate(plines):
        m = RE_HR.match(l.rstrip('\r'))
        if m:
            if m.group(1) == '-' and i > 0 and plines[i - 1].strip() and not RE_HR.match(plines[i - 1]) \
                    and line_kind(plines[i - 1]) == 'text':
                continue
            hr += 1
    if hr >= 3 and len(plines) >= 24:
        col.add(70, LABELS[70][0], LABELS[70][1], hr, ['decorative horizontal rules'])

    # 71 degenerate repetition
    lw = [w.lower() for w in words_list]
    n6 = len(lw) - 5
    if n6 >= 12:
        grams = Counter(zip(lw, lw[1:], lw[2:], lw[3:], lw[4:], lw[5:]))
        rep = sum(c for c in grams.values() if c > 1)
        if rep / float(n6) >= 0.2:
            col.add(71, LABELS[71][0], LABELS[71][1], rep, ['repeated multi-word spans'])

    # ---- scoring
    score_items = [it for it in col.items if (it[0] not in ADVICE and not (it[0] == 17 and it[1] == 'negative_parallelism'))]
    fams = set(it[0] for it in score_items)
    raw_score = 0.0
    for num, slug, label, count, smp in score_items:
        w = WEIGHTS.get(num, 6)
        raw_score += w * min(1 + 0.35 * (count - 1), 2.4)
    score = int(round(min(raw_score, 100)))
    if len(fams) == 1:
        score = min(score, 40)
    if fams and fams <= RHYTHM_SM:
        score = min(score, 40)
    if fams == {40}:
        score = min(score, 20)

    nf = len(fams)
    if nwords < 40:
        confidence = 'none'
        reason = 'fewer than 40 words, too short to score'
    elif nwords < 120:
        confidence = 'low'
        reason = 'short text (under 120 words)'
    elif nwords < 300:
        if nf == 1:
            confidence = 'low'
            reason = 'under 300 words and only one pattern family fired'
        else:
            confidence = 'moderate'
            reason = 'under 300 words'
    else:
        confidence = 'high'
        reason = ''

    dec = fams & DECISIVE
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and confidence in ('moderate', 'high'):
        score = max(score, 45)
    if nwords < 120:
        k = len(fams & SHORT_SET)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    elif nwords >= 400:
        if nf >= 6:
            score = max(score, 45)
        elif nf >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))

    items = sorted(col.items, key=lambda it: (it[0], it[1]))
    metrics = {
        'scanned_chars': len(raw),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(items),
        'invisible_chars': inv,
        'nonstandard_spaces': nonstd,
        'homoglyphs': len(hg_runs),
        'words': nwords,
        'score_moving_families': nf,
    }
    return items, metrics, all_sentences


def interval(sentences):
    if len(sentences) < 4:
        return None
    rng = random.Random(20240601)
    sample_src = []
    total = 0
    for s in sentences:
        total += len(s) + 1
        sample_src.append(s)
        if total > 20000:
            break
    scores = []
    n = len(sample_src)
    for _ in range(30):
        picks = [sample_src[rng.randrange(n)] for _ in range(n)]
        try:
            _, m, _ = analyze(' '.join(picks))
            scores.append(m['ai_tell_score'])
        except Exception:
            continue
    if not scores:
        return None
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
    return float(min(lo, hi)), float(max(lo, hi))


def build_report(text, ci):
    items, metrics, sentences = analyze(text)
    report = {}
    for num, slug, label, count, smp in items:
        report['%d_%s' % (num, slug)] = {'label': label, 'count': count, 'samples': smp}
    if ci:
        iv = interval(sentences)
        score = metrics['ai_tell_score']
        if iv is None:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (need at least 4)'
        else:
            lo = max(0.0, min(iv[0], float(score)))
            hi = min(100.0, max(iv[1], float(score)))
            metrics['score_ci'] = [lo, hi]
            metrics['score_ci_note'] = 'bootstrap interval over resampled sentences'
    report['_metrics'] = metrics
    return report


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------

def emit_error(msg, code):
    sys.stderr.write(json.dumps({'error': msg}) + '\n')
    sys.stderr.flush()
    return code


def write_out(s):
    data = s.encode('utf-8', 'replace')
    out = sys.stdout.buffer
    out.write(data)
    out.flush()


def main(argv):
    clean = False
    ci = False
    files = []
    opts_done = False
    for a in argv:
        if opts_done:
            files.append(a)
        elif a == '--':
            opts_done = True
        elif a in ('-h', '--help'):
            write_out(USAGE)
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            return emit_error('unknown option: %s (see --help)' % a, 2)
        else:
            files.append(a)
    if len(files) >= 2:
        sys.stderr.write('prosecheck: scanning only the first file: %s (%d other operand(s) ignored)\n'
                         % (files[0], len(files) - 1))
    try:
        if files:
            path = files[0]
            ext = os.path.splitext(path)[1].lower()
            try:
                with open(path, 'rb') as fh:
                    data = fh.read()
            except Exception as e:
                raise DetectError('cannot read input: %s' % (getattr(e, 'strerror', None) or e.__class__.__name__))
        else:
            ext = ''
            data = sys.stdin.buffer.read()
        text = extract(data, ext)
        if not text or not text.strip():
            raise DetectError('empty input')
        if clean:
            write_out(clean_text(text))
            return 0
        report = build_report(text, ci)
        write_out(json.dumps(report, indent=2, ensure_ascii=True) + '\n')
        return 0
    except DetectError as e:
        return emit_error(e.message, e.code)
    except RecursionError:
        return emit_error('cannot read input: document too deeply nested', 1)
    except MemoryError:
        return emit_error('cannot read input: out of memory', 1)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
