import inspect
from functools import update_wrapper

from .core import Argument, Command, Group, Option, Parameter
from .globals import get_current_context
from .utils import echo

_ATTR = "__optlyn_params__"


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError("Managed to invoke callback without a context object of type "
                                   f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _ATTR):
            setattr(f, _ATTR, [])
        getattr(f, _ATTR).append(param)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def command(name=None, cls=None, **attrs):
    func = None
    if callable(name):
        func = name
        name = None
        if cls is not None or attrs:
            raise TypeError("Use 'command(**kwargs)(callable)' to provide arguments.")
    if cls is None:
        cls = Command

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        kw = dict(attrs)
        params = list(kw.pop("params", None) or [])
        decorator_params = getattr(f, _ATTR, None)
        if decorator_params is not None:
            delattr(f, _ATTR)
            params.extend(reversed(decorator_params))
        if kw.get("help") is None:
            kw["help"] = inspect.getdoc(f)
        else:
            kw["help"] = inspect.cleandoc(kw["help"])
        cmd_name = name
        if cmd_name is None:
            cmd_name = f.__name__.lower().replace("_", "-") if False else f.__name__.lower()
            for suffix in ("_command", "_cmd", "_group", "_grp"):
                if cmd_name.endswith(suffix):
                    cmd_name = cmd_name[: -len(suffix)]
                    break
            cmd_name = cmd_name.replace("_", "-")
        cmd = cls(name=cmd_name, callback=f, params=params, **kw)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(cls=cls, **attrs)(name)
    return command(name, cls, **attrs)


def _named(kind, param_decls):
    # Give built-in flags a private destination so a parameter that is merely *named* like the flag
    # (e.g. an argument called "help") does not collide with it.
    if any(isinstance(p, str) and p.isidentifier() for p in param_decls):
        return param_decls
    return (f"_optlyn_{kind}", *param_decls)


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if value and not ctx.resilient_parsing:
            echo(ctx.get_help(), color=ctx.color)
            ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*_named("help", param_decls), **kwargs)


def _detect_package(depth=2):
    frame = inspect.currentframe()
    try:
        for _ in range(depth):
            frame = frame.f_back
        g = frame.f_globals
        pkg = g.get("__name__")
        if pkg == "__main__":
            pkg = g.get("__package__")
        if pkg:
            pkg = pkg.partition(".")[0]
        return pkg
    except Exception:
        return None
    finally:
        del frame


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        package_name = _detect_package()

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name, version
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata as md
            try:
                version = md.version(package_name)
            except md.PackageNotFoundError:
                dists = md.packages_distributions().get(package_name)
                if not dists:
                    raise RuntimeError(f"{package_name!r} is not installed. Try passing 'package_name' "
                                       "instead.") from None
                version = md.version(dists[0])
        if version is None:
            raise RuntimeError("Could not determine the version for "
                               f"{package_name!r} automatically.")
        echo(message % {"prog": prog_name, "package": package_name, "version": version}, color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*_named("version", param_decls), **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*_named("version", param_decls), **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
