"""Optlyn: a command line interface composition kit."""
from . import _compat  # noqa: F401
from .core import Argument, Command, CommandCollection, Context, Group, Option, Parameter, ParameterSource
from .decorators import (argument, command, confirmation_option, custom_version_option, group, help_option,
                         make_pass_decorator, option, pass_context, pass_obj, password_option, version_option)
from .exceptions import (Abort, BadArgumentUsage, BadOptionUsage, BadParameter, ClickException, Exit, FileError,
                         MissingParameter, NoSuchOption, OptlynException, UsageError)
from .formatting import HelpFormatter, wrap_text
from .globals import get_current_context
from .termui import (confirm, echo_via_pager, edit, get_pager_file, getchar, launch, pause, progressbar,
                      prompt, clear)
from .types import (BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime, File, FloatRange, IntRange,
                    ParamType, Path, Tuple)
from .utils import (echo, format_filename, get_app_dir, open_file, secho, style, unstyle)

__version__ = "1.0.0"
