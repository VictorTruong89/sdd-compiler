import contextlib
import inspect
import itertools
import math
import os
import subprocess
import sys
import tempfile
import time

from . import _compat
from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename

__all__ = ["prompt", "confirm", "echo_via_pager", "get_pager_file", "progressbar", "getchar", "pause",
           "edit", "launch", "clear"]


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and hasattr(default, "read") or hasattr(default, "write"):
        n = getattr(default, "name", None)
        if n is not None:
            return n
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = _compat.hidden_prompt_func if hide_input else _compat.visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    full = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(full)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    full = _build_prompt(text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(full.rstrip(" "), nl=False, err=err)
            value = _compat.visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


class _PagerStream:
    """Writable text stream that forwards chunks to a pager process."""

    def __init__(self, proc, strip):
        self.proc = proc
        self.strip = strip

    def write(self, text):
        if self.strip:
            text = _compat.strip_ansi(text)
        try:
            self.proc.stdin.write(text)
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError, ValueError):
            pass
        return len(text)

    def writelines(self, lines):
        for ln in lines:
            self.write(ln)

    def flush(self):
        try:
            self.proc.stdin.flush()
        except Exception:
            pass

    def isatty(self):
        return False


class _StdoutPager:
    def __init__(self, color):
        self.color = color

    def write(self, text):
        sys.stdout.write(self._prep(text))
        return len(text)

    def _prep(self, text):
        if _compat.should_strip_ansi(sys.stdout, self.color):
            return _compat.strip_ansi(text)
        return text

    def writelines(self, lines):
        for ln in lines:
            self.write(ln)

    def flush(self):
        sys.stdout.flush()

    def isatty(self):
        return _compat.isatty(sys.stdout)


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    cmd = os.environ.get("PAGER")
    if not _compat.is_interactive() or not cmd or not cmd.strip():
        s = _StdoutPager(color)
        try:
            yield s
        finally:
            sys.stdout.flush()
        return
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, text=True, encoding="utf-8",
                            errors="replace")
    stream = _PagerStream(proc, strip=not color)
    try:
        yield stream
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        it = [text_or_generator]
    else:
        it = iter(text_or_generator)
    with get_pager_file(color) as f:
        for el in it:
            f.write(el if isinstance(el, str) else str(el))
            f.flush()
        f.write("\n")
        f.flush()


class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False, bar_template=None, info_sep="  "):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        elif length is None:
            try:
                length = len(iterable)
            except TypeError:
                try:
                    length = operator_length_hint(iterable)
                except Exception:
                    length = None
        self.iterable = iterable
        self.length = length
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else (length is not None)
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file
        self.color = color
        self.width = width
        self.hidden = hidden
        self.info_sep = info_sep
        self.pos = 0
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._printed_label = False
        self._last_line = None
        self.finished = False
        self._entered = False

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    def _is_tty(self):
        return _compat.isatty(self._stream())

    def __enter__(self):
        self._entered = True
        self.start = time.time()
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.render_finish()

    def __iter__(self):
        if not self._entered:
            self.start = time.time()
            self.render_progress()
        for item in self.iterable:
            self.current_item = item
            yield item
            self.update(1)
        self.render_finish()

    def __next__(self):
        raise TypeError("use iter()")

    @property
    def pct(self):
        if not self.length:
            return 1.0 if self.finished else 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and self.pos > 0 and self.pos < self.length:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is None or self.pos == 0 or self.pos >= self.length:
            return ""
        t = int(math.ceil(self.eta))
        seconds = t % 60
        t //= 60
        minutes = t % 60
        t //= 60
        hours = t % 24
        t //= 24
        if t > 0:
            return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
        return f"{hours:02}:{minutes:02}:{seconds:02}"

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        else:
            bar = self.empty_char * self.width
        return bar

    def format_progress_line(self):
        info = []
        if self.show_pos:
            info.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_percent:
            info.append(f"{int(self.pct * 100):4}%")
        if self.show_eta and self.length is not None:
            e = self.format_eta()
            if e:
                info.append(e)
        if self.item_show_func is not None and self.current_item is not None:
            s = self.item_show_func(self.current_item)
            if s:
                info.append(s)
        return f"{self.label}  [{self.format_bar()}]  {self.info_sep.join(info)}".rstrip()

    def render_progress(self):
        if self.hidden:
            return
        stream = self._stream()
        if not self._is_tty():
            if not self._printed_label:
                self._printed_label = True
                if self.label:
                    echo(self.label, file=stream, color=self.color)
            return
        line = self.format_progress_line()
        if line != self._last_line:
            self._last_line = line
            echo("\r" + line, file=stream, nl=False, color=self.color)
            stream.flush()

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        self.render_progress()

    def render_finish(self):
        if self.hidden or self._finished_rendered():
            return
        self._done = True
        if self._is_tty():
            self.render_progress()
            echo("", file=self._stream(), color=self.color)

    def _finished_rendered(self):
        return getattr(self, "_done", False)


def operator_length_hint(obj):
    import operator
    return operator.length_hint(obj, 0) or None


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def getchar(echo=False):
    f = _compat.getchar_func
    return f(echo)


def pause(info=None, err=False):
    if not _compat.is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def _get_editor():
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    import shutil
    for ed in ("sensible-editor", "vim", "nano", "vi"):
        if shutil.which(ed):
            return ed
    return "vi"


def _run_editor(editor, filename, env):
    environ = None
    if env:
        environ = os.environ.copy()
        for k, v in env.items():
            if v is None:
                environ.pop(k, None)
            else:
                environ[k] = v
    try:
        c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
        exit_code = c.wait()
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e
    if exit_code != 0:
        raise OptlynException(f"{editor}: Editing failed")


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = _get_editor()
    if filename is not None:
        _run_editor(editor, filename, env)
        return None
    if isinstance(text, bytes):
        data = text
    else:
        text = text or ""
        if text and not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.utime(name, (os.stat(name).st_atime, os.stat(name).st_mtime - 2))
        timestamp = os.path.getmtime(name)
        _run_editor(editor, name, env)
        if require_save and os.path.getmtime(name) == timestamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, bytes):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    url = os.fspath(url) if not isinstance(url, str) else url
    if url.startswith("file://"):
        url = url[7:]
    try:
        if locate:
            url = os.path.dirname(url) or "."
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1


def clear():
    if not _compat.isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)
