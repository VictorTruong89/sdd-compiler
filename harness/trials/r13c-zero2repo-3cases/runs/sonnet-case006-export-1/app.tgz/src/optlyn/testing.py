import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat
from .utils import echo  # noqa: F401


class _KeepOpen(io.BytesIO):
    def close(self):
        pass


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def close(self):
        pass

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, fileno=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode
        self._fileno = fileno

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode

    def fileno(self):
        if self._fileno is None:
            return super().fileno()
        return self._fileno


class _EchoingStdin(io.TextIOWrapper):
    def __init__(self, raw, output, **kw):
        super().__init__(raw, **kw)
        self._out = output

    def _echo(self, s):
        if s:
            self._out.write(s)
        return s

    def read(self, size=-1):
        return self._echo(super().read(size))

    def readline(self, size=-1):
        return self._echo(super().readline(size))

    def readlines(self, hint=-1):
        return [self._echo(x) for x in super().readlines(hint)]

    def __next__(self):
        line = super().__next__()
        self._echo(line)
        return line

    def __iter__(self):
        return self


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception,
                 exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        old = (sys.stdin, sys.stdout, sys.stderr)
        old_hooks = (_compat.visible_prompt_func, _compat.hidden_prompt_func, _compat.getchar_func,
                     _compat.should_strip_ansi)
        output = _KeepOpen()
        bytes_out = BytesIOCopy(output)
        bytes_err = BytesIOCopy(output)
        fd_mode = self.capture == "fd"
        raw_in = io.BytesIO(data)
        if self.echo_stdin:
            stdin = _EchoingStdin(raw_in, None, encoding=self.charset)
        else:
            stdin = _NamedTextIOWrapper(raw_in, name="<stdin>", mode="r", encoding=self.charset)
        stdout = _NamedTextIOWrapper(bytes_out, encoding=self.charset, name="<stdout>", mode="w",
                                     fileno=1 if fd_mode else None)
        stderr = _NamedTextIOWrapper(bytes_err, encoding=self.charset, name="<stderr>", mode="w",
                                     errors="backslashreplace", fileno=2 if fd_mode else None)
        if self.echo_stdin:
            stdin._out = stdout
        stdout.reconfigure(line_buffering=False)

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = sys.stdin.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            if not self.echo_stdin:
                sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = sys.stdin.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo_):
            ch = sys.stdin.read(1)
            if ch == "":
                raise EOFError()
            if echo_:
                sys.stdout.write(ch)
                sys.stdout.flush()
            if ch == "\x03":
                raise KeyboardInterrupt()
            if ch == "\x04":
                raise EOFError()
            return ch

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        _compat.visible_prompt_func = visible_input
        _compat.hidden_prompt_func = hidden_input
        _compat.getchar_func = _getchar
        _compat.should_strip_ansi = should_strip_ansi
        old_env = {}
        saved_fds = None
        tmp_files = None
        try:
            for key, value in self.make_env(env).items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_mode:
                tmp_files = (tempfile.TemporaryFile(), tempfile.TemporaryFile())
                try:
                    old[1].flush()
                    old[2].flush()
                except Exception:
                    pass
                saved_fds = (os.dup(1), os.dup(2))
                os.dup2(tmp_files[0].fileno(), 1)
                os.dup2(tmp_files[1].fileno(), 2)
            yield (bytes_out, bytes_err, output)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                stdout.flush()
                stderr.flush()
            except Exception:
                pass
            if fd_mode:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                for f, target in ((tmp_files[0], bytes_out), (tmp_files[1], bytes_err)):
                    f.seek(0)
                    target.write(f.read())
                    f.close()
            sys.stdin, sys.stdout, sys.stderr = old
            (_compat.visible_prompt_func, _compat.hidden_prompt_func, _compat.getchar_func,
             _compat.should_strip_ansi) = old_hooks

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                try:
                    return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
                except SystemExit as e:
                    exc_info = sys.exc_info()
                    e_code = e.code
                    if e_code is None:
                        e_code = 0
                    if e_code != 0:
                        exception = e
                    if not isinstance(e_code, int):
                        sys.stdout.write(str(e_code))
                        sys.stdout.write("\n")
                        e_code = 1
                    exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        # Captured bytes are complete only after isolation has merged fd output.
        return Result(self, outstreams[0].getvalue(), outstreams[1].getvalue(), outstreams[2].getvalue(),
                      return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
