"""Stream helpers and swappable hooks (the test runner patches these)."""
import io
import os
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def strip_ansi(value):
    return _ansi_re.sub("", value)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


class NonClosingTextIOWrapper(io.TextIOWrapper):
    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _text_stream(name, encoding, errors):
    stream = getattr(sys, name)
    if errors == "strict":
        errors = None
    if encoding is None and errors is None:
        return stream
    enc = getattr(stream, "encoding", None)
    if encoding is not None and enc and enc.lower().replace("_", "-") == encoding.lower().replace("_", "-") and errors is None:
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return NonClosingTextIOWrapper(buf, encoding=encoding or enc or "utf-8", errors=errors or "strict")


def get_text_stdin(encoding=None, errors=None):
    return _text_stream("stdin", encoding, errors)


def get_text_stdout(encoding=None, errors=None):
    return _text_stream("stdout", encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _text_stream("stderr", encoding, errors)


def _binary(name):
    stream = getattr(sys, name)
    return getattr(stream, "buffer", stream)


def get_binary_stdin():
    return _binary("stdin")


def get_binary_stdout():
    return _binary("stdout")


def get_binary_stderr():
    return _binary("stderr")


def is_ascii_encoding(stream):
    import codecs
    enc = getattr(stream, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def _getchar_impl(echo):
    import termios
    import tty
    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        f = None
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if echo and isatty(sys.stdout):
        sys.stdout.write(ch)
        sys.stdout.flush()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def _visible_input(prompt=None):
    return input(prompt or "")


def _hidden_input(prompt=None):
    import getpass
    return getpass.getpass(prompt or "")


# Hooks, replaced by the in-process runner.
getchar_func = _getchar_impl
visible_prompt_func = _visible_input
hidden_prompt_func = _hidden_input
