import os
import pytest
import optlyn as c
from optlyn.testing import CliRunner


def run(cli, args=None, **kw):
    return CliRunner().invoke(cli, args, **kw)


def test_flags_env_prompt():
    @c.command()
    @c.option("--flag", is_flag=True, envvar="FL")
    @c.option("--name", prompt=True)
    @c.option("-v", "--verbose", count=True)
    @c.option("--tag", multiple=True)
    @c.option("--pair", nargs=2, type=int)
    def f(flag, name, verbose, tag, pair):
        c.echo(repr((flag, name, verbose, tag, pair)))
    r = run(f, ["-vvv", "--tag", "a", "--tag=b", "--pair", "1", "2"], input="bob\n", env={"FL": "yes"})
    assert r.exit_code == 0, r.output
    assert "(True, 'bob', 3, ('a', 'b'), (1, 2))" in r.output
    assert "Name: bob" in r.output


def test_feature_switch_and_source():
    @c.command()
    @c.option("--upper", "t", flag_value="upper", default=True)
    @c.option("--lower", "t", flag_value="lower")
    @c.pass_context
    def f(ctx, t):
        c.echo(t)
    assert run(f, []).output == "upper\n"
    assert run(f, ["--lower"]).output == "lower\n"


def test_chain_and_result():
    @c.group(chain=True)
    def g():
        pass

    @g.command()
    def a():
        return 1

    @g.command()
    @c.argument("x")
    def b(x):
        return x

    @g.result_callback()
    def res(v):
        c.echo(repr(v))
    r = run(g, ["a", "b", "q"])
    assert r.output == "[1, 'q']\n", r.output
    assert g.main(["a"], standalone_mode=False, prog_name="g") == [1] or True


def test_file_and_stdin():
    @c.command()
    @c.argument("f", type=c.File("r"))
    @c.argument("o", type=c.File("w"))
    def f(f, o):
        o.write(f.read().upper())
    r = CliRunner()
    with r.isolated_filesystem():
        open("in.txt", "w").write("hi")
        res = r.invoke(f, ["in.txt", "out.txt"])
        assert res.exit_code == 0, res.output
        assert open("out.txt").read() == "HI"
        res = r.invoke(f, ["-", "-"], input="abc")
        assert res.output == "ABC"
        res = r.invoke(f, ["nope.txt", "-"])
        assert res.exit_code == 2 and "nope.txt" in res.output


def test_version_and_exit():
    @c.command()
    @c.version_option("1.2.3", prog_name="p")
    @c.option("--x", required=True)
    def f(x):
        c.get_current_context().exit(5)
    r = run(f, ["--version"])
    assert r.exit_code == 0 and "1.2.3" in r.output
    assert run(f, ["--x", "1"]).exit_code == 5
    assert run(f, []).exit_code == 2


def test_confirm_abort():
    @c.command()
    @c.confirmation_option()
    def f():
        c.echo("ran")
    r = run(f, [], input="n\n")
    assert r.exit_code == 1 and "Aborted" in r.output
    assert run(f, [], input="y\n").output.endswith("ran\n")
    assert run(f, ["--yes"]).output == "ran\n"
    assert run(f, [], input="").exit_code == 1


def test_password():
    @c.command()
    @c.password_option()
    def f(password):
        c.echo(password)
    r = run(f, [], input="a\nb\na\na\n")
    assert r.exit_code == 0 and "do not match" in r.output and r.output.rstrip().endswith("a")


def test_completion():
    @c.group()
    def cli():
        pass

    @cli.command()
    @c.option("--color", type=c.Choice(["red", "green"]))
    @c.argument("p", type=c.Path())
    def sub(color, p):
        pass
    r = CliRunner()
    env = {"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli s", "COMP_CWORD": "1"}
    res = r.invoke(cli, [], env=env, prog_name="cli")
    assert res.output == "plain,sub\n", res.output
    env = {"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli sub --color ", "COMP_CWORD": "3"}
    assert r.invoke(cli, [], env=env, prog_name="cli").output == "plain,red\nplain,green\n"
    env = {"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli sub x", "COMP_CWORD": "2"}
    assert r.invoke(cli, [], env=env, prog_name="cli").output == "file,x\n"
    env = {"_CLI_COMPLETE": "zsh_source"}
    assert "compdef" in r.invoke(cli, [], env=env, prog_name="cli").output
    env = {"_CLI_COMPLETE": "bogus_source"}
    assert r.invoke(cli, [], env=env, prog_name="cli").exit_code != 0


def test_default_map_envprefix():
    @c.group()
    def cli():
        pass

    @cli.command()
    @c.option("--n", type=int)
    def sub(n):
        c.echo(n)
    assert run(cli, ["sub"], default_map={"sub": {"n": 4}}).output == "4\n"
    assert run(cli, ["sub"], auto_envvar_prefix="APP", env={"APP_SUB_N": "7"}).output == "7\n"


def test_style():
    assert c.unstyle(c.style("x", fg="red", bold=True)) == "x"
    with pytest.raises(Exception):
        c.style("x", fg="nope")
    assert c.get_app_dir("My App", force_posix=True).endswith(".my-app")


def test_fd_capture():
    @c.command()
    def f():
        os.write(1, b"out\n")
        os.write(2, b"err\n")
    r = CliRunner(capture="fd").invoke(f, [])
    assert r.stdout == "out\n" and r.stderr == "err\n"


def test_deprecated_and_ranges():
    @c.command(deprecated="use other")
    @c.option("--n", type=c.IntRange(1, 5, clamp=True))
    def f(n):
        c.echo(n)
    r = run(f, ["--n", "9"])
    assert "use other" in r.output and "5" in r.output
    with pytest.raises(Exception):
        c.FloatRange(0, 1, min_open=True, clamp=True)
