# Optlyn build notes

Package: `src/optlyn` (pure Python, no dependencies). Run tests with `PYTHONPATH=src python -m pytest tests`.

Spec coverage (by area): Interface Contract sections 1-9 and FP-01..FP-14 are implemented in
`core.py` (commands, groups, parameters, context), `decorators.py`, `types.py`, `parser.py`,
`formatting.py`, `termui.py`, `utils.py`, `shell_completion.py`, `testing.py`.

Not done: Windows-only expansion of glob/home/env tokens in the process argument list
(N-000048 parenthetical; the supported target is Linux). `launch`/`edit`/`getchar` depend on the host
(`xdg-open`, an editor, a controlling terminal).
