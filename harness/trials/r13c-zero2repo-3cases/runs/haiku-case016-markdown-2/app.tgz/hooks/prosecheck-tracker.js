#!/usr/bin/env node
'use strict';
// Prompt-submit hook: routes /prosecheck commands and adds the writing-contract reminder.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const COMMAND_RX = /^\/prosecheck(:prosecheck)?(?=\s|$)/i;

function block(reason) {
  return { decision: 'block', reason };
}

function num(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : 0;
}

function formOf(match) {
  return match[1] ? '/prosecheck:prosecheck' : '/prosecheck';
}

function helpReply(level) {
  return [
    `prosecheck help. Live level: ${level}.`,
    'Code, commits, config, and chat are always left alone; this never touches them.',
    '/prosecheck lite - writing contract only, no scoring of saved files.',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - contract plus the guard at threshold 20, with the cleanup scrub.',
    '/prosecheck off | on - off turns the tool off (disable); on turns it back on (re-enable) at full.',
    '/prosecheck status - show the stored level in one line.',
    "/prosecheck show - list this session's scored files, newest first.",
    '/prosecheck check <file> - score one file; this is a report only and does not rewrite it.',
    '/prosecheck doctor - health check of the install.',
    "/prosecheck stats - token use for this session and the score of its own prose.",
    '/prosecheck init - writes the writing contract to ./AGENTS.md for agents other than Claude Code.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function showRow(row) {
  if (row.kind === 'scored') {
    const cov = row.truncated ? ', first 262,144 characters only' : '';
    const tail = row.labels && row.labels.length
      ? ` - ${row.flagged ? 'flagged' : 'under'}: ${row.labels.slice(0, 5).join('; ')}`
      : '';
    return `${row.base} - ${row.phrase} (score ${row.score}/${row.band}${cov})${tail}`;
  }
  if (row.kind === 'skip') return `${row.base} - not scored: over ${row.limitKb} KB`;
  if (row.kind === 'binary') return `${row.base} - binary file, not re-scored`;
  return `${row.base} - not scored: ${row.reason}`;
}

function showReply(sessionId) {
  const rows = lib.readLedger(sessionId).slice().reverse();
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  return ['Files saved in this session, newest first:'].concat(rows.map((r) => '  ' + showRow(r))).join('\n');
}

function checkReply(arg) {
  if (!arg) {
    return 'Usage: /prosecheck check <path>. Give the path of one prose file; it is scored and not changed.';
  }
  let typed = arg.trim();
  if (typed.startsWith('@')) typed = typed.slice(1);
  if (typed.length >= 2 && (typed[0] === '"' || typed[0] === "'") && typed[typed.length - 1] === typed[0]) {
    typed = typed.slice(1, -1);
  }
  const abs = path.resolve(process.cwd(), typed);
  const base = path.basename(typed);
  let stat;
  try {
    stat = fs.statSync(abs);
  } catch (err) {
    return `cannot read ${typed}: no such file.`;
  }
  if (!stat.isFile()) return `not a file: ${typed}`;
  const ext = path.extname(abs).toLowerCase();
  if (lib.BINARY_EXTS.has(ext)) return `no readable text in ${base}; ${ext} files are not scored.`;
  if (!lib.PROSE_EXTS.has(ext)) return `not a supported prose format: ${base}`;
  const archive = lib.ZIP_EXTS.includes(ext) || ext === lib.NOTEBOOK_EXT;
  const capKb = (archive ? lib.ARCHIVE_CAP_BYTES : lib.PLAIN_CAP_BYTES) / 1024;
  if (stat.size > capKb * 1024) return `over ${capKb} KB: ${base} is too large to score.`;

  const res = lib.runDetector([abs], { timeout: archive ? lib.ARCHIVE_TIMEOUT_MS : lib.TEXT_TIMEOUT_MS });
  if (res.status === 'nopython') return `detector unavailable: Python was not found, so ${base} was not scored.`;
  if (res.status === 'timeout') return `${base} failed: the detector timed out.`;
  if (res.code !== 0) {
    const msg = lib.errorMessage(res.stderr);
    return `${base} failed${msg ? ': ' + msg : ' (no error text was returned)'}.`;
  }
  if (!res.stdout.trim()) return `${base}: no report from the detector.`;
  const report = lib.parseReport(res.stdout);
  if (!report) return 'no report from the detector.';
  const metrics = report._metrics;
  if (typeof metrics.ai_tell_score !== 'number') return 'no report from the detector.';
  const { band, phrase } = lib.bandFor(metrics.ai_tell_score);
  const lines = [`${base} - ${phrase} (score ${metrics.ai_tell_score}/100, band: ${band})`];
  let confLine = `confidence: ${metrics.confidence}`;
  if (metrics.confidence !== 'high' && metrics.confidence_reason) confLine += ` - ${metrics.confidence_reason}`;
  lines.push(confLine);
  if (metrics.truncated) lines.push(`coverage: first ${lib.WINDOW} characters only`);
  const tells = lib.findingLabels(report).slice(0, 8).map((f) => `${f.label} (x${f.count})`);
  lines.push(tells.length ? `tells: ${tells.join('; ')}` : 'tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.readLevel();
  const modeOk = level !== 'off';
  const modeLine = modeOk
    ? `mode: ${level} [OK]`
    : 'mode: off - the tool is off; run /prosecheck on to turn it on.';

  const det = lib.detectorPath();
  const detOk = Boolean(det);
  const detLine = detOk
    ? `detector: bundled detector found at ${path.relative(lib.pluginRoot(), det)} [OK]`
    : 'detector: bundled detector is missing from the plugin tree.';

  const probe = lib.runDetector([], {
    input: 'This is a short sample sentence for the install check.',
    timeout: lib.TEXT_TIMEOUT_MS,
  });
  let pyOk = false;
  let pyLine;
  if (probe.status === 'nopython') {
    pyLine = 'python: python not found, so the bundled scan was not re-scored. The writing contract still applies to new prose, and saved files will not be scored again until Python is available.';
  } else if (probe.status === 'timeout') {
    pyLine = 'python: the bundled run timed out, so no score was confirmed.';
  } else {
    const report = probe.code === 0 ? lib.parseReport(probe.stdout) : null;
    if (report && typeof report._metrics.ai_tell_score === 'number') {
      pyOk = true;
      pyLine = `python: Python ran the bundled script and returned a score of ${report._metrics.ai_tell_score}. [OK]`;
    } else {
      pyLine = 'python: the run returned no numeric score, so the install is not confirmed.';
    }
  }

  let setOk = false;
  try {
    fs.mkdirSync(lib.configDir(), { recursive: true });
    fs.accessSync(lib.configDir(), fs.constants.W_OK);
    setOk = true;
  } catch (err) {
    setOk = false;
  }
  const setLine = setOk
    ? 'settings: the settings folder is writable [OK]'
    : 'settings: the settings folder is not writable.';

  let closer;
  if (modeOk && detOk && pyOk && setOk) {
    closer = `prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored on the first ${lib.WINDOW} characters. Run ${form} show to see files that were only partly scanned or skipped.`;
  } else if (!modeOk && detOk && pyOk && setOk) {
    closer = `The install is healthy. The tool is off, so saving files is not scored in this mode. Run ${form} on to turn it back on.`;
  } else {
    closer = 'Repair the faulty checks above: fix them, then run /prosecheck doctor again.';
  }
  return ['prosecheck doctor', modeLine, detLine, pyLine, setLine, closer].join('\n');
}

function walkFiles(dir, visit) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (err) {
    return;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkFiles(full, visit);
    } else if (entry.isFile() && entry.name.endsWith('.jsonl')) {
      try {
        visit(full, fs.statSync(full).mtimeMs);
      } catch (err) {
        // skip files that vanish
      }
    }
  }
}

function newestTranscript() {
  let best = null;
  walkFiles(path.join(lib.configDir(), 'projects'), (file, mtime) => {
    if (!best || mtime > best.mtime) best = { file, mtime };
  });
  return best ? best.file : null;
}

function readRows(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
  const rows = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      rows.push(JSON.parse(line));
    } catch (err) {
      // skip damaged lines
    }
  }
  return rows;
}

function statsReply(input) {
  const level = lib.readLevel();
  const file = typeof input.transcript_path === 'string' && input.transcript_path
    ? input.transcript_path
    : newestTranscript();
  const rows = file ? readRows(file) : null;
  if (!rows) {
    return [`No readable transcript${file ? ' at ' + file : ''}.`, `level: ${level}`].join('\n');
  }
  let turns = 0;
  let outTokens = 0;
  let cacheTokens = 0;
  const seen = new Set();
  const texts = [];
  for (const row of rows) {
    if (!row || typeof row !== 'object' || row.type !== 'assistant') continue;
    const msg = row.message && typeof row.message === 'object' ? row.message : {};
    const content = Array.isArray(msg.content) ? msg.content : [];
    for (const part of content) {
      if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
    }
    const id = typeof msg.id === 'string' && msg.id ? msg.id : null;
    if (id) {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outTokens += num(usage.output_tokens);
    cacheTokens += num(usage.cache_read_input_tokens);
  }
  const lines = [
    `assistant turns: ${turns}`,
    `output tokens: ${outTokens}`,
    `cache-read input tokens: ${cacheTokens}`,
    `level: ${level}`,
  ];
  const slice = texts.join('\n').replace(/```[\s\S]*?```/g, '').slice(-40000).trim();
  if (slice.length > 200) {
    const res = lib.runDetector([], { input: slice, timeout: lib.TEXT_TIMEOUT_MS });
    const report = res.status === 'ran' && res.code === 0 ? lib.parseReport(res.stdout) : null;
    if (report && typeof report._metrics.ai_tell_score === 'number') {
      lines.push(`session prose ai_tell_score: ${report._metrics.ai_tell_score}`);
    }
  }
  return lines.join('\n');
}

function initReply(form) {
  const level = lib.readLevel();
  if (level === 'off') {
    return `prosecheck is switched off, so nothing was written. Run ${form} on to allow the export.`;
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (err) {
    readable = err.code === 'ENOENT';
  }
  if (!readable) {
    out.push('cannot read AGENTS.md, so the contract was not written to it.');
  } else if (existing.includes(lib.SECTION_START)) {
    out.push('AGENTS.md already contains the writing contract; it was left unchanged.');
  } else {
    let prefix = existing;
    if (prefix && !prefix.endsWith('\n')) prefix += '\n';
    if (prefix) prefix += '\n';
    const section = [lib.SECTION_START, lib.exportContract(level), lib.SECTION_END].join('\n') + '\n';
    try {
      fs.writeFileSync(agents, prefix + section);
      out.push('Wrote the writing contract to AGENTS.md.');
    } catch (err) {
      out.push('cannot write AGENTS.md; the contract was not written.');
    }
  }
  const ruleSource = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  const ruleDir = path.join(cwd, '.cursor', 'rules');
  const ruleTarget = path.join(ruleDir, 'prosecheck.mdc');
  if (fs.existsSync(ruleTarget)) {
    out.push('prosecheck.mdc already exists in .cursor/rules; it was left unchanged.');
  } else {
    try {
      fs.mkdirSync(ruleDir, { recursive: true });
      fs.copyFileSync(ruleSource, ruleTarget);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (err) {
      out.push('cannot write .cursor/rules/prosecheck.mdc; the rule was not created.');
    }
  }
  return out.join('\n');
}

function route(prompt, input, sessionId) {
  const text = prompt.trim();
  const match = COMMAND_RX.exec(text);
  if (!match) {
    const lower = text.toLowerCase();
    if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
      lib.writeLevel('off');
      return block('prosecheck is off. Saved files are no longer scored. Run /prosecheck on to turn it back on.');
    }
    return null;
  }
  const form = formOf(match);
  const rest = text.slice(match[0].length).trim();
  const word = rest.split(/\s+/)[0] || '';
  const sub = word.toLowerCase();
  const arg = rest.slice(word.length).trim();

  if (sub === '' || sub === 'help') return block(helpReply(lib.readLevel()));
  if (lib.isLevel(sub)) {
    lib.writeLevel(sub);
    if (sub === 'off') {
      return block('prosecheck is off. Saved files are no longer scored. Run /prosecheck on to turn it back on.');
    }
    return block(`prosecheck level set to ${sub}.`);
  }
  if (sub === 'on') {
    lib.writeLevel('full');
    return block('prosecheck is on at full (the default). Saved prose files are scored again.');
  }
  if (sub === 'status') return block(`Current level: ${lib.readLevel()}.`);
  if (sub === 'show') return block(showReply(sessionId));
  if (sub === 'check') return block(checkReply(arg));
  if (sub === 'doctor') return block(doctorReply(form));
  if (sub === 'stats') return block(statsReply(input));
  if (sub === 'init') return block(initReply(form));
  return block(`unknown word "${word}". Valid words: ${lib.SUBCOMMANDS.join(', ')}.`);
}

function main() {
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const reply = route(prompt, input, sessionId);
  if (reply) {
    lib.emitJson(reply);
    return;
  }
  const level = lib.readLevel();
  if (level === 'off') return;
  lib.emitJson({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: `prosecheck is on at level ${level}. Prose deliverables follow the writing contract; code, config, and commits are untouched.`,
    },
  });
}

try {
  main();
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
