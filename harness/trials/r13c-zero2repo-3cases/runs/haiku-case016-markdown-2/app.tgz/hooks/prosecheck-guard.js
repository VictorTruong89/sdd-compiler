#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const SKIP_SEGMENTS = new Set(['node_modules', '.git', 'memory']);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const PATH_LIMIT = 16;

function requestPaths(input) {
  const tool = input.tool_name;
  const ti = input.tool_input;
  if (typeof ti === 'string' && tool === 'apply_patch') {
    return patchPaths(ti);
  }
  const obj = ti && typeof ti === 'object' ? ti : {};
  if (tool === 'Write' || tool === 'Edit' || tool === 'MultiEdit') {
    return typeof obj.file_path === 'string' ? [obj.file_path] : [];
  }
  if (tool === 'NotebookEdit') {
    const p = typeof obj.notebook_path === 'string' ? obj.notebook_path : obj.file_path;
    return typeof p === 'string' ? [p] : [];
  }
  if (tool === 'apply_patch') {
    return patchPaths(typeof obj.command === 'string' ? obj.command : '');
  }
  return [];
}

function patchPaths(body) {
  const out = [];
  const rx = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
  let m;
  while ((m = rx.exec(body)) !== null) {
    const p = m[1].trim();
    if (p) out.push(p);
  }
  return out;
}

function skipPath(abs, root) {
  const segments = abs.split(path.sep);
  if (segments.some((s) => SKIP_SEGMENTS.has(s))) return true;
  if (abs.startsWith(root + path.sep)) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTRUCTION_NAMES.has(base)) return true;
  const ext = path.extname(base);
  const stem = base.slice(0, base.length - ext.length);
  if (INSTRUCTION_STEMS.has(stem) && !lib.PROSE_EXTS.has(ext)) return true;
  return false;
}

function scoreFile(abs, base, ext, sizeLimitKb, level) {
  const archive = lib.ZIP_EXTS.includes(ext) || ext === lib.NOTEBOOK_EXT;
  const timeout = archive ? lib.ARCHIVE_TIMEOUT_MS : lib.TEXT_TIMEOUT_MS;
  const res = lib.runDetector([abs], { timeout });
  if (res.status === 'nopython') return { kind: 'failed', reason: 'Python was not found, so the file was not scored' };
  if (res.status === 'timeout') return { kind: 'failed', reason: 'the detector timed out' };
  const report = res.code === 0 ? lib.parseReport(res.stdout) : null;
  if (res.code === 0 && !report) return { kind: 'failed', reason: 'the detector output was not a structured report' };
  if (res.code !== 0 || !report) return { kind: 'failed', reason: 'the detector produced no usable result' };
  const metrics = report._metrics;
  if (typeof metrics.ai_tell_score !== 'number') {
    return { kind: 'failed', reason: 'the report had no numeric score' };
  }
  const score = metrics.ai_tell_score;
  const { band, phrase } = lib.bandFor(score);
  const labels = lib.findingLabels(report).map((f) => f.label);
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold && metrics.confidence !== 'none';
  return {
    kind: 'scored', score, band, phrase, labels: labels.slice(0, 5), flagged,
    truncated: Boolean(metrics.truncated), limitKb: sizeLimitKb,
  };
}

function main() {
  const input = lib.readStdinJson();
  const level = lib.readLevel();
  if (level === 'off' || level === 'lite') return;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const root = lib.pluginRoot();
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const seen = new Set();
  const lines = [];

  for (const raw of requestPaths(input)) {
    if (seen.size >= PATH_LIMIT) break;
    const abs = path.resolve(cwd, raw.trim());
    if (seen.has(abs)) continue;
    seen.add(abs);
    if (skipPath(abs, root)) continue;
    const base = path.basename(abs);
    const ext = path.extname(abs).toLowerCase();
    let stat = null;
    try {
      stat = fs.statSync(abs);
    } catch (err) {
      stat = null;
    }
    if (lib.BINARY_EXTS.has(ext)) {
      if (!stat) lib.appendLedger(sessionId, { base, kind: 'failed', reason: 'the file could not be read' });
      else if (stat.isFile()) lib.appendLedger(sessionId, { base, kind: 'binary' });
      continue;
    }
    if (!lib.PROSE_EXTS.has(ext)) continue;
    if (!stat) {
      lib.appendLedger(sessionId, { base, kind: 'failed', reason: 'the file could not be read' });
      continue;
    }
    if (!stat.isFile()) continue;
    const archive = lib.ZIP_EXTS.includes(ext) || ext === lib.NOTEBOOK_EXT;
    const capBytes = archive ? lib.ARCHIVE_CAP_BYTES : lib.PLAIN_CAP_BYTES;
    if (stat.size > capBytes) {
      lib.appendLedger(sessionId, { base, kind: 'skip', limitKb: capBytes / 1024 });
      continue;
    }
    const result = scoreFile(abs, base, ext, capBytes / 1024, level);
    if (result.kind === 'failed') {
      lib.appendLedger(sessionId, { base, kind: 'failed', reason: result.reason });
      continue;
    }
    lib.appendLedger(sessionId, {
      base, kind: 'scored', score: result.score, band: result.band, phrase: result.phrase,
      labels: result.labels, flagged: result.flagged, truncated: result.truncated,
    });
    if (result.flagged) {
      const coverage = result.truncated ? `, first ${lib.WINDOW} characters only` : '';
      lines.push(`prosecheck: ${base} ${result.phrase} (score ${result.score}, band ${result.band}${coverage}). ` +
        `Flagged: ${result.labels.join('; ')}. Fix the flagged spans in ${base} and save it again.`);
    }
  }

  if (lines.length) {
    lib.emitJson({
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: lines.join('\n'),
      },
    });
  }
}

try {
  main();
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
