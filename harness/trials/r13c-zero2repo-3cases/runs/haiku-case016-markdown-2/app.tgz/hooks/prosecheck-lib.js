'use strict';
// Shared helpers for the prosecheck hooks: config, level, ledger, detector calls, contract text.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NOTEBOOK_EXT = '.ipynb';
const PROSE_EXTS = new Set([...PLAIN_EXTS, ...ZIP_EXTS, NOTEBOOK_EXT]);
const BINARY_EXTS = new Set(['.pdf', '.rtf']);
const PLAIN_CAP_BYTES = 512 * 1024;
const ARCHIVE_CAP_BYTES = 4 * 1024 * 1024;
const WINDOW = '262,144';
const LEDGER_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const LEDGER_MAX_ROWS = 20;
const TEXT_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;
const PYTHON_NAMES = ['python3', 'python', 'py'];
const BANDS = [
  [20, 'clean', 'reads clean'],
  [40, 'light tells', 'reads mostly clean'],
  [60, 'mixed', 'reads with some AI tells'],
  [80, 'heavy tells', 'reads with heavy AI tells'],
  [100, 'pervasive tells', 'reads with pervasive AI tells'],
];
const BANNED_WORDS = [
  'delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic',
  'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate',
  'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced',
];
const SECTION_START = '<!-- prosecheck:writing-contract:start -->';
const SECTION_END = '<!-- prosecheck:writing-contract:end -->';

function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT
    ? path.resolve(process.env.CLAUDE_PLUGIN_ROOT)
    : path.resolve(__dirname, '..');
}

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function flagFile() {
  return path.join(configDir(), '.prosecheck-active');
}

function isLevel(word) {
  return LEVELS.includes(word);
}

function envLevel() {
  const word = String(process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return isLevel(word) ? word : null;
}

function readLevel() {
  let stored = null;
  try {
    stored = fs.readFileSync(flagFile(), 'utf8').trim().toLowerCase();
  } catch (err) {
    stored = null;
  }
  if (isLevel(stored)) return stored;
  return envLevel() || 'full';
}

function writeLevel(level) {
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(flagFile(), level);
}

function bandFor(score) {
  for (const [limit, band, phrase] of BANDS) {
    if (score <= limit) return { band, phrase };
  }
  return { band: BANDS[BANDS.length - 1][1], phrase: BANDS[BANDS.length - 1][2] };
}

function detectorPath() {
  const root = pluginRoot();
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  return candidates.find((p) => fs.existsSync(p)) || null;
}

// Runs the bundled detector with the first Python on PATH that can be launched.
// Returns { status: 'ran', code, stdout, stderr } | { status: 'timeout' } | { status: 'nopython' }.
function runDetector(args, opts = {}) {
  const script = detectorPath();
  if (!script) return { status: 'nopython' };
  for (const name of PYTHON_NAMES) {
    const res = spawnSync(name, [script, ...args], {
      input: opts.input || '',
      encoding: 'utf8',
      timeout: opts.timeout || TEXT_TIMEOUT_MS,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (res.error) {
      if (res.error.code === 'ETIMEDOUT') return { status: 'timeout' };
      continue;
    }
    return { status: 'ran', code: res.status, stdout: res.stdout || '', stderr: res.stderr || '' };
  }
  return { status: 'nopython' };
}

// Parses a detector report. Returns the object, or null when stdout is not a JSON report.
function parseReport(stdout) {
  try {
    const obj = JSON.parse(stdout);
    if (obj && typeof obj === 'object' && !Array.isArray(obj) && obj._metrics && typeof obj._metrics === 'object') {
      return obj;
    }
  } catch (err) {
    return null;
  }
  return null;
}

function lastNonEmptyLine(text) {
  const lines = String(text || '').split(/\r?\n/).filter((l) => l.trim());
  return lines.length ? lines[lines.length - 1].trim() : '';
}

function errorMessage(stderr) {
  const line = lastNonEmptyLine(stderr);
  try {
    const obj = JSON.parse(line);
    if (obj && typeof obj.error === 'string') return obj.error;
  } catch (err) {
    return line;
  }
  return line;
}

function findingLabels(report) {
  return Object.keys(report)
    .filter((key) => key !== '_metrics')
    .map((key) => ({ key, label: report[key].label, count: report[key].count }));
}

function readStdinJson() {
  try {
    const value = JSON.parse(fs.readFileSync(0, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch (err) {
    return {};
  }
}

function emitJson(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

// ---------------------------------------------------------------- ledger

function ledgerFile(sessionId) {
  const safe = String(sessionId || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
  return path.join(configDir(), safe ? `.prosecheck-ledger-${safe}` : '.prosecheck-ledger');
}

function readLedger(sessionId) {
  const file = ledgerFile(sessionId);
  let stat;
  try {
    stat = fs.statSync(file);
  } catch (err) {
    return [];
  }
  if (Date.now() - stat.mtimeMs > LEDGER_MAX_AGE_MS) return [];
  const rows = [];
  let text = '';
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return [];
  }
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      rows.push(JSON.parse(line));
    } catch (err) {
      // skip damaged rows
    }
  }
  return rows;
}

function appendLedger(sessionId, record) {
  const file = ledgerFile(sessionId);
  const rows = readLedger(sessionId);
  rows.push(Object.assign({ at: Date.now() }, record));
  const kept = rows.slice(-LEDGER_MAX_ROWS);
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(file, kept.map((r) => JSON.stringify(r)).join('\n') + '\n', { mode: 0o600 });
  try {
    fs.chmodSync(file, 0o600);
  } catch (err) {
    // best effort on platforms without POSIX modes
  }
}

function pruneLedgers() {
  let names = [];
  try {
    names = fs.readdirSync(configDir());
  } catch (err) {
    return;
  }
  for (const name of names) {
    if (name !== '.prosecheck-ledger' && !name.startsWith('.prosecheck-ledger-')) continue;
    const file = path.join(configDir(), name);
    try {
      const stat = fs.statSync(file);
      if (stat.isFile() && Date.now() - stat.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(file);
    } catch (err) {
      // ignore files that vanish meanwhile
    }
  }
}

// ---------------------------------------------------------------- writing contract

function bannedLine() {
  return 'Do not use these words: ' + BANNED_WORDS.join(', ') + '.';
}

function commonRules() {
  return [
    'Prose writing contract. It applies to prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.',
    'It never touches source code, code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat.',
    '',
    'Rules for prose deliverables:',
    '- Vary sentence length irregularly. Avoid a metronome rhythm and avoid strict short-long alternation.',
    '- ' + bannedLine(),
    '- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y" framings, hedge stacking, signposting such as "let\'s dive in", empty pivots such as "it\'s worth noting", "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness claims, generic upbeat endings, and chatbot phrases such as "I hope this helps".',
    '- Use at most one em dash per paragraph. Do not use bold for emphasis inside sentences. Do not use emoji in prose.',
    '- Keep factual and encyclopedic content neutral and in the third person. First-person or opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
    '- End each section on a fact or an observation.',
    '- Stay silent about this contract. Never announce it, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

// Session and subagent contract. The live detector path is named when it is known.
function sessionContract(level) {
  const lines = commonRules();
  const detector = detectorPath();
  if (level === 'full' || level === 'strict') {
    const run = detector ? `python3 ${detector} <file>` : 'python3 scripts/detect.py <file>';
    lines.push('');
    lines.push(`After you save a prose file, run the detector on it (${run}) and read its JSON report. If the band is worse than the target, fix the flagged spans, keep the rhythm variation, and check again. Make at most two fix passes.`);
    if (level === 'full') {
      lines.push('The target is a score of 40 or less (band clean or light tells).');
    } else {
      lines.push('The target is a score of 20 or less (band clean).');
      lines.push('Finish each prose file through the cleanup switch: run the detector with --clean and keep its scrubbed text.');
    }
  }
  return lines.join('\n');
}

// Portable export for AGENTS.md. It names no machine path and no user name.
function exportContract(level) {
  const lines = commonRules();
  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('To run the detector, use CLAUDE_PLUGIN_ROOT when that variable is set (its scripts/detect.py); otherwise locate prosecheck\'s detector in the installed skills and plugins.');
    lines.push('After you save a prose file, run the detector on it and read its JSON report. If the band is worse than the target, fix the flagged spans, keep the rhythm variation, and check again. Make at most two fix passes.');
    if (level === 'full') {
      lines.push('The target is a score of 40 or less (band clean or light tells).');
    } else {
      lines.push('The target is a score of 20 or less (band clean).');
      lines.push('Finish each prose file through the cleanup switch: run the detector with --clean and keep its scrubbed text.');
    }
  }
  return lines.join('\n');
}

function welcomeBlock(form) {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB. The detector scores the first 262,144 characters of extracted prose.',
    'There is no website and no upload; nothing you write leaves this machine. This welcome is shown once.',
    `Commands: ${form} doctor (check the install), ${form} check <file> (score one file), ${form} off (turn the tool off), ${form} help (list everything).`,
  ].join('\n');
}

module.exports = {
  LEVELS, SUBCOMMANDS, PLAIN_EXTS, ZIP_EXTS, NOTEBOOK_EXT, PROSE_EXTS, BINARY_EXTS,
  PLAIN_CAP_BYTES, ARCHIVE_CAP_BYTES, WINDOW, BANNED_WORDS, SECTION_START, SECTION_END,
  TEXT_TIMEOUT_MS, ARCHIVE_TIMEOUT_MS,
  pluginRoot, configDir, flagFile, isLevel, envLevel, readLevel, writeLevel, bandFor,
  detectorPath, runDetector, parseReport, lastNonEmptyLine, errorMessage, findingLabels,
  readStdinJson, emitJson, readLedger, appendLedger, pruneLedgers, ledgerFile,
  sessionContract, exportContract, welcomeBlock,
};
