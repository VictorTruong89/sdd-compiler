#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the subagent envelope.
const lib = require('./prosecheck-lib.js');

function main() {
  lib.readStdinJson();
  const level = lib.readLevel();
  if (level === 'off') return;
  lib.emitJson({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: lib.sessionContract(level),
    },
  });
}

try {
  main();
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
