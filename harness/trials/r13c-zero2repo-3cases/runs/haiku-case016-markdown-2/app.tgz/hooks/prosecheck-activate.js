#!/usr/bin/env node
'use strict';
// Session-start hook: writes the writing contract for the stored level.
const fs = require('fs');
const lib = require('./prosecheck-lib.js');

function main() {
  lib.readStdinJson();
  lib.pruneLedgers();
  const flagExists = fs.existsSync(lib.flagFile());
  let level = lib.readLevel();
  let welcome = false;
  if (!flagExists) {
    try {
      lib.writeLevel(level);
      welcome = true;
    } catch (err) {
      welcome = false;
    }
  }
  if (level === 'off') return;
  const parts = [];
  if (welcome) parts.push(lib.welcomeBlock('/prosecheck'));
  parts.push(lib.sessionContract(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
