#!/usr/bin/env python3
"""prosecheck detector: scores prose for AI-writing patterns.

Python standard library only. No network, no model, no random component in
the default scan. Usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import codecs
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from bisect import bisect_left
from collections import Counter, namedtuple
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = '.ipynb'
NO_TEXT_EXTS = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score a prose file, or standard input, for AI-writing patterns.
  --clean     print scrubbed plain text instead of the JSON report
  --ci        add a resampled low/high interval on the score (needs 4+ sentences)
  --          end option parsing so FILE may begin with a dash
  -h, --help  print this usage message
With no FILE the text is read from standard input (UTF-8).
"""

BANDS = [(20, 'clean', 'reads clean'), (40, 'light tells', 'reads mostly clean'),
         (60, 'mixed', 'reads with some AI tells'), (80, 'heavy tells', 'reads with heavy AI tells'),
         (100, 'pervasive tells', 'reads with pervasive AI tells')]

WEIGHT_ZERO = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
DOC_LEVEL = {40, 44, 46, 55, 62, 66, 67, 68, 70}
RHYTHM = {40, 44}
FIRST_GROUP = set(range(1, 40)) | set(range(47, 52)) | {69}

# Lookalike letters of other scripts that are drawn like a Latin letter.
HOMO = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'о': 'o', 'р': 'p', 'ѕ': 's', 'у': 'y', 'х': 'x',
    'ԛ': 'q', 'ԝ': 'w', 'ο': 'o', 'ρ': 'p', 'ν': 'v', 'υ': 'u',
    'ι': 'i', 'օ': 'o', 'ո': 'n', 'ս': 'u',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S',
    'Т': 'T', 'Х': 'X', 'У': 'Y', 'Ү': 'Y', 'Ԁ': 'D',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I',
    'Κ': 'K', 'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T',
    'Υ': 'Y', 'Χ': 'X', 'Ϲ': 'C',
}
NBSP_SET = {'\u00a0', '\u202f'}
BIDI = {0x061C, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
        0x2066, 0x2067, 0x2068, 0x2069}
INVISIBLE_FILLERS = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D,
                     0x180F, 0x3164, 0xFFA0}

WORD_RX = re.compile(r"[^\W_](?:[^\W_]|['’-])*")
CTRL_RX = re.compile(r'[\x00-\x08\x0b-\x1f\x7f]')
Pattern = namedtuple('Pattern', 'num slug label fn moving')


class InputError(Exception):
    def __init__(self, message, code=1):
        Exception.__init__(self, message)
        self.code = code


# ---------------------------------------------------------------- character layer

def _cp(c):
    return ord(c) if c else -1


def _is_cjk(c):
    cp = _cp(c)
    return (0x3040 <= cp <= 0x30FF or 0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF
            or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x2FFFF)


def _is_emoji(c):
    cp = _cp(c)
    return (0x1F000 <= cp <= 0x1FAFF or 0x2600 <= cp <= 0x27BF or 0x2300 <= cp <= 0x23FF
            or 0x2B00 <= cp <= 0x2BFF)


def _is_symbol(c):
    return bool(c) and (unicodedata.category(c).startswith('S') or _is_emoji(c))


def _is_joining(c):
    cp = _cp(c)
    return (0x0590 <= cp <= 0x06FF or 0x0900 <= cp <= 0x0DFF or 0x1000 <= cp <= 0x109F
            or 0x1780 <= cp <= 0x17FF or 0xFB50 <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF)


def _is_rtl(c):
    cp = ord(c)
    return 0x0590 <= cp <= 0x08FF or 0xFB1D <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF


def _is_nospace_script(c):
    cp = _cp(c)
    return 0x0E00 <= cp <= 0x0EFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF or _is_cjk(c)


def _is_invisible(c, cat):
    if c in '\t\n\r':
        return False
    if cat in ('Cc', 'Cf'):
        return True
    cp = ord(c)
    return 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF or cp in INVISIBLE_FILLERS


def _keep_invisible(text, i, has_rtl):
    """Invisible characters that do a job in their position (PRD FP-03)."""
    c = text[i]
    cp = ord(c)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= cp <= 0xE007F:
        j = i - 1
        while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F:
            j -= 1
        return j >= 0 and _is_emoji(text[j])
    if 0xE0100 <= cp <= 0xE01EF:
        return _is_cjk(prev)
    if 0xFE00 <= cp <= 0xFE0F:
        return _is_emoji(prev) or _is_symbol(prev) or _is_cjk(prev) or nxt == '⃣'
    if cp in (0x180B, 0x180C, 0x180D, 0x180F):
        return 0x1800 <= _cp(prev) <= 0x18AF
    if cp in (0x17B4, 0x17B5):
        return 0x1780 <= _cp(prev) <= 0x17FF or 0x1780 <= _cp(nxt) <= 0x17FF
    if cp == 0x200B:
        return _is_nospace_script(prev) or _is_nospace_script(nxt)
    if cp == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if cp in BIDI:
        return has_rtl
    if cp in (0x200C, 0x200D):
        return (_is_joining(prev) or _is_joining(nxt) or _is_symbol(prev) or _is_symbol(nxt)
                or _is_emoji(prev) or _is_emoji(nxt))
    return False


def _keep_nbsp(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev.isdigit() or nxt.isdigit():
        return True
    return bool(nxt) and nxt in ':;!?»›%€' or bool(prev) and prev in '«‹'


def _is_homoglyph_token(tok):
    has_latin = False
    has_look = False
    for ch in tok:
        if ch.isascii():
            if ch.isalpha():
                has_latin = True
        elif ch.isalpha():
            if ch in HOMO:
                has_look = True
            else:
                return False
    return has_latin and has_look


def _fold_homoglyphs(s):
    if s.isascii():
        return s

    def fix(m):
        tok = m.group(0)
        if _is_homoglyph_token(tok):
            return ''.join(HOMO.get(ch, ch) for ch in tok)
        return tok
    return re.sub(r'\S+', fix, s)


def _char_pass(text, scrub):
    """Remove or keep invisible characters and normalize spaces.

    Returns (text, removed_chars, normalized_space_chars). With scrub=True the
    keep rules of FP-03 apply; with scrub=False every invisible is removed.
    """
    if text.isascii() and not CTRL_RX.search(text):
        return text, [], []
    has_rtl = any(_is_rtl(c) for c in text) if scrub else False
    out = []
    removed = []
    nonstd = []
    for i, c in enumerate(text):
        if c in ' \t\n':
            out.append(c)
            continue
        cat = unicodedata.category(c)
        if cat == 'Zs':
            if scrub and c in NBSP_SET and _keep_nbsp(text, i):
                out.append(c)
            else:
                out.append(' ')
                nonstd.append(c)
            continue
        if cat in ('Zl', 'Zp'):
            out.append('\n')
            continue
        if _is_invisible(c, cat):
            if scrub and _keep_invisible(text, i, has_rtl):
                out.append(c)
            else:
                removed.append(c)
            continue
        out.append(c)
    return _fold_homoglyphs(''.join(out)), removed, nonstd


def scrub_document(raw):
    """Cleanup output: scrubbed text with the input's line-ending convention."""
    eol = '\r\n' if '\r\n' in raw else '\n'
    ended = raw.endswith('\n')
    text = raw.replace('\r\n', '\n').replace('\r', '\n')
    text, _, _ = _char_pass(text, scrub=True)
    lines = [ln.rstrip(' \t') for ln in text.split('\n')]
    while lines and not lines[0].strip():
        lines.pop(0)
    body = '\n'.join(lines).rstrip()
    if body and ended:
        body += '\n'
    return body.replace('\n', eol)


# ---------------------------------------------------------------- input and extraction

def decode_text(data):
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode('utf-8', errors='replace')
    if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return data.decode('utf-16', errors='replace')
    if b'\x00' in data:
        return None
    return data.decode('utf-8', errors='replace')


def _ln(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _para_texts(root, pname, run_text):
    out = []

    def walk(el):
        if _ln(el.tag) == pname:
            s = run_text(el).strip()
            if s:
                out.append(s)
            return
        for ch in el:
            walk(ch)
    walk(root)
    return out


def _ooxml_run_text(el):
    parts = []
    for x in el.iter():
        name = _ln(x.tag)
        if name == 't' and x.text:
            parts.append(x.text)
        elif name == 'tab':
            parts.append('\t')
        elif name == 'br':
            parts.append('\n')
    return ''.join(parts)


def _odf_text(el, out):
    name = _ln(el.tag)
    if name == 's':
        count = 1
        for k, v in el.attrib.items():
            if k.endswith('}c') and v.isdigit():
                count = int(v)
        out.append(' ' * count)
    elif name == 'tab':
        out.append('\t')
    elif name == 'line-break':
        out.append('\n')
    else:
        if el.text:
            out.append(el.text)
        for ch in el:
            _odf_text(ch, out)
            if ch.tail:
                out.append(ch.tail)


def _odf_collect(el):
    out = []
    if el.text:
        out.append(el.text)
    for ch in el:
        _odf_text(ch, out)
        if ch.tail:
            out.append(ch.tail)
    return ''.join(out)


def _odf_paras(el, out):
    if _ln(el.tag) in ('p', 'h'):
        s = _odf_collect(el).strip()
        if s:
            out.append(s)
        return
    for ch in el:
        _odf_paras(ch, out)


class _Chapter(HTMLParser):
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr', 'section',
             'blockquote', 'article', 'td', 'th', 'dt', 'dd', 'figcaption', 'header', 'footer'}
    SKIP = {'style', 'script', 'head', 'nav', 'title'}

    def __init__(self):
        HTMLParser.__init__(self)
        self.paras = []
        self.buf = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.flush()

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.flush()

    def handle_data(self, data):
        if self.skip == 0:
            self.buf.append(data)

    def flush(self):
        s = re.sub(r'\s+', ' ', ''.join(self.buf)).strip()
        if s:
            self.paras.append(s)
        self.buf = []


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', name)]


def _extract_zip(data, ext):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception:
        raise InputError('cannot read input: not a readable zip archive')
    try:
        with zf:
            return _extract_members(zf, ext).strip()
    except Exception:
        return ''


def _extract_members(zf, ext):
    names = zf.namelist()
    if ext in ('.docx', '.docm'):
        root = ET.fromstring(zf.read('word/document.xml'))
        return '\n'.join(_para_texts(root, 'p', _ooxml_run_text))
    if ext in ('.pptx', '.pptm'):
        slides = [n for n in names if re.match(r'ppt/slides/slide\d+\.xml$', n)]
        slides.sort(key=_natural_key)
        parts = []
        for name in slides:
            root = ET.fromstring(zf.read(name))
            parts.extend(_para_texts(root, 'p', _ooxml_run_text))
        return '\n'.join(parts)
    if ext in ('.xlsx', '.xlsm'):
        return _extract_xlsx(zf, names)
    if ext in ('.odt', '.odp', '.ods'):
        root = ET.fromstring(zf.read('content.xml'))
        out = []
        _odf_paras(root, out)
        return '\n'.join(out)
    if ext == '.epub':
        chapters = [n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm'))]
        chapters.sort(key=_natural_key)
        paras = []
        for name in chapters:
            parser = _Chapter()
            parser.feed(zf.read(name).decode('utf-8', errors='replace'))
            parser.close()
            parser.flush()
            paras.extend(parser.paras)
        return '\n'.join(paras)
    return ''


def _extract_xlsx(zf, names):
    shared = []
    if 'xl/sharedStrings.xml' in names:
        root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
        for si in root:
            if _ln(si.tag) == 'si':
                shared.append(''.join(t.text or '' for t in si.iter() if _ln(t.tag) == 't'))
    sheets = [n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml$', n)]
    sheets.sort(key=_natural_key)
    lines = []
    for name in sheets:
        root = ET.fromstring(zf.read(name))
        for cell in root.iter():
            if _ln(cell.tag) != 'c':
                continue
            kind = cell.get('t')
            txt = ''
            if kind == 's':
                value = None
                for ch in cell:
                    if _ln(ch.tag) == 'v':
                        value = ch.text
                try:
                    idx = int(value)
                    txt = shared[idx] if 0 <= idx < len(shared) else ''
                except (TypeError, ValueError):
                    txt = ''
            elif kind == 'inlineStr':
                txt = ''.join(x.text or '' for x in cell.iter() if _ln(x.tag) == 't')
            elif kind == 'str':
                for ch in cell:
                    if _ln(ch.tag) == 'v':
                        txt = ch.text or ''
            if txt.strip():
                lines.append(txt)
    return '\n'.join(lines)


def _extract_notebook(data):
    try:
        nb = json.loads(data.decode('utf-8-sig', errors='replace'))
    except ValueError:
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        if src.strip():
            parts.append(src)
    return '\n'.join(parts).strip()


def read_input(path):
    if path is None:
        data = sys.stdin.buffer.read()
        text = decode_text(data)
    else:
        try:
            with open(path, 'rb') as fh:
                data = fh.read()
        except OSError as exc:
            raise InputError('cannot read input: %s: %s' % (path, exc.strerror or exc))
        ext = os.path.splitext(path)[1].lower()
        if ext in NO_TEXT_EXTS:
            text = None
        elif ext in ZIP_EXTS:
            text = _extract_zip(data, ext)
        elif ext == NOTEBOOK_EXT:
            text = _extract_notebook(data)
        else:
            text = decode_text(data)
    if text is None or not text.strip():
        raise InputError('empty input')
    return text


# ---------------------------------------------------------------- markdown masking

FENCE_RX = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
QUOTE_RX = re.compile(r'^\s{0,3}>')
TABLE_RX = re.compile(r'^\s*\|')
BADGE_RX = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')


def _mask_markdown(text):
    """Blank out the parts of the text that generate no findings (PRD FP-01)."""
    lines = text.split('\n')
    out = list(lines)
    n = len(lines)
    start = 0
    if n > 1 and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    out[k] = ''
                start = j + 1
                break
    fence = None
    prev_blank = True
    in_indented = False
    k = start
    while k < n:
        ln = lines[k]
        if fence is not None:
            out[k] = ''
            m = FENCE_RX.match(ln)
            if (m and m.group(1)[0] == fence[0] and len(m.group(1)) >= len(fence)
                    and not m.group(2).strip()):
                fence = None
            k += 1
            continue
        m = FENCE_RX.match(ln)
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            out[k] = ''
            prev_blank = False
            in_indented = False
            k += 1
            continue
        if ln.strip() and (ln.startswith('    ') or ln.startswith('\t')) and (prev_blank or in_indented):
            out[k] = ''
            in_indented = True
            prev_blank = False
            k += 1
            continue
        in_indented = False
        prev_blank = not ln.strip()
        k += 1
    # runs of two or more blockquote lines, table rows, badge lines
    k = start
    while k < n:
        if QUOTE_RX.match(lines[k]):
            j = k
            while j < n and QUOTE_RX.match(lines[j]):
                j += 1
            if j - k >= 2:
                for x in range(k, j):
                    out[x] = ''
            k = j
            continue
        k += 1
    for k in range(start, n):
        if TABLE_RX.match(lines[k]) and lines[k].count('|') >= 2 or BADGE_RX.match(lines[k]):
            out[k] = ''
    joined = '\n'.join(out)
    return re.sub(r'`[^`\n]*`', ' ', joined)


def _blocks(an):
    """Blank-line separated paragraphs as (start, end) spans."""
    out = []
    off = 0
    start = None
    end = 0
    for line in an.split('\n'):
        if line.strip():
            if start is None:
                start = off
            end = off + len(line)
        elif start is not None:
            out.append((start, end))
            start = None
        off += len(line) + 1
    if start is not None:
        out.append((start, end))
    return out


def _sentence_spans(an):
    spans = []
    start = 0
    for m in re.finditer(r'[.!?]+(?=\s)|\n', an):
        end = m.end() if m.group(0) != '\n' else m.start()
        if re.search(r'\w', an[start:end]):
            spans.append((start, end))
        start = m.end()
    if re.search(r'\w', an[start:]):
        spans.append((start, len(an)))
    return spans


def _context(an):
    words = [(m.start(), m.end(), m.group(0).lower()) for m in WORD_RX.finditer(an)]
    wstarts = [w[0] for w in words]
    sents = _sentence_spans(an)
    sent_words = []
    for s, e in sents:
        sent_words.append(bisect_left(wstarts, e) - bisect_left(wstarts, s))
    return {
        'sents': sents,
        'sent_words': sent_words,
        'blocks': _blocks(an),
        'words': words,
        'wstarts': wstarts,
        'lines': an.split('\n'),
    }


# ---------------------------------------------------------------- pattern helpers

def _rx(pattern, flags=re.I, group=0):
    crx = re.compile(pattern, flags)

    def fn(an, ctx):
        return [m.span(group) for m in crx.finditer(an) if m.span(group)[1] > m.span(group)[0]]
    return fn


def _rxs(patterns, flags=re.I):
    return _rx('|'.join('(?:%s)' % p for p in patterns), flags)


def _infl(word):
    if word.endswith('y') and not word.endswith(('ay', 'ey', 'oy', 'uy')):
        stem = word[:-1]
        return [word, stem + 'ies', stem + 'ied']
    if word.endswith('e'):
        return [word, word + 's', word + 'd', word[:-1] + 'ing']
    if word.endswith(('s', 'x', 'z', 'ch', 'sh')):
        return [word, word + 'es', word + 'ed', word + 'ing']
    return [word, word + 's', word + 'es', word + 'ed', word + 'ing']


def _bounded(body, word=None):
    """Wrap a term in word boundaries only where the term starts or ends with a word character."""
    word = word if word is not None else body
    start = r'\b' if word[:1].isalnum() else ''
    end = r'\b' if word[-1:].isalnum() else ''
    return start + body + end


def _words_pattern(items, inflect=True):
    forms = []
    for item in items:
        if ' ' in item:
            body = r'\s+'.join(re.escape(w).replace("'", "['’]") for w in item.split())
        elif inflect:
            body = None
            forms.extend(_bounded(re.escape(f)) for f in _infl(item))
            continue
        else:
            body = re.escape(item)
        forms.append(_bounded(body, item))
    forms = sorted(set(forms), key=len, reverse=True)
    return r'(?:%s)' % '|'.join(forms)


def _vocab(items, inflect=True):
    crx = re.compile(_words_pattern(items, inflect), re.I)

    def fn(an, ctx):
        return [m.span() for m in crx.finditer(an)]
    return fn


def _lit(text):
    return re.escape(text).replace("'", "['’]")


# ---------------------------------------------------------------- catalogue functions

AI_VOCAB = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
            'meticulous', 'testament', 'underscore', 'intricate', 'intricacies', 'interplay',
            'garner', 'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance',
            'leverage', 'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
            'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
            'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
            'elevate', 'empower', 'unlock', 'capture the essence', 'capture the spirit',
            'capture the imagination', 'capture the heart', 'capture the magic']
MODEL_DIALECT_RX = [
    _words_pattern(['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
                    'strikingly', 'compellingly', 'quietly powerful', 'quietly profound',
                    'quietly radical', 'deeply human', 'deeply personal', 'deeply felt',
                    'deeply unsettling', 'resonates deeply', 'supercharge', 'skyrocket',
                    'turbocharge', 'revolutionize', 'double down on', 'dive deep into',
                    'dive deeper into'], inflect=False),
    r'\bgame-chang(?:er|ers|ing)\b',
    r'\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b',
    r'\btake\b[^.!?\n]{1,40}?\bto the next level\b',
]
PROMO_PHRASES = [
    'nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
    'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
    'unparalleled', 'premier', 'esteemed organization', 'valuable asset', 'passion for excellence',
    'proven track record', 'results-oriented', 'wealth of experience', 'dynamic team',
    'fast-paced environment', 'deeply passionate', 'perfectly situated', 'close-knit team',
    'tight-knit team', 'I am excited to apply', 'I am excited to bring', "I'm excited to apply",
    "I'm excited to bring", 'uniquely positioned to',
]
PROMO_IMPERATIVES = ('install|join|grab|download|try|discover|experience|escape|transform|reclaim|'
                     'unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|'
                     'unleash|supercharge|level|stop|start')
PROMO_OPENER_RX = re.compile(r'(?:^|[.!?]\s+|\n[ \t]*)(%s)\b' % PROMO_IMPERATIVES, re.I | re.M)
STOCK_ADJ = {'powerful', 'seamless', 'robust', 'innovative', 'elegant', 'intuitive', 'reliable',
             'scalable', 'secure', 'efficient', 'modern', 'comprehensive', 'vibrant', 'dynamic',
             'flexible', 'versatile', 'cutting-edge', 'fast', 'simple', 'smart', 'sleek',
             'premium', 'bold', 'beautiful', 'stunning', 'high-quality', 'world-class',
             'user-friendly', 'clean', 'stylish'}
ADJ_SUFFIX_RX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$')
STACK_WORD = r"[A-Za-z][A-Za-z'-]*"
STACK_SEP = r"(?:,\s*(?:(?:and|or)\s+)?|\s+(?:and|or)\s+)"
STACK_RX = re.compile(r'\b(%s(?:%s%s){3})\s+([a-z][a-z-]*)\b' % (STACK_WORD, STACK_SEP, STACK_WORD))
STACK_STOP = {'and', 'or', 'the', 'a', 'an', 'of', 'to', 'in', 'for', 'with', 'on', 'at', 'by',
              'from', 'but', 'so', 'as', 'is', 'are', 'it', 'its'}
SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
OUTLETS = (r'(?:The New York Times|New York Times|Forbes|BBC|CNN|Reuters|The Guardian|Bloomberg|'
           r'Wired|The Verge|TechCrunch|The Wall Street Journal|Wall Street Journal|Politico|NPR|'
           r'The Washington Post|Washington Post|Associated Press|The Economist|Fortune|'
           r'Business Insider|Axios|Engadget|Ars Technica|Financial Times|The Atlantic|'
           r'Rolling Stone|Newsweek|Variety)')
TRANSITION_RX = re.compile(r'(?:^|[.!?]\s+)(Additionally|Furthermore|Moreover|However|'
                           r'Nevertheless|Consequently|Subsequently|Notably)\b')
HEDGE_RX = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? to|'
                      r'seems? like|appears? to|somewhat|relatively|fairly|kind of|sort of)\b')
FULL_FORM_RX = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|have not|"
                          r"has not|had not|will not|would not|could not|should not|cannot|it is|"
                          r"I am|I have|I will|I would|we are|we have|we will|that is|there is|"
                          r"they are|you are|let us)\b", re.I)
CONTRACTION_RX = re.compile(r"\b\w+['’](?:t|s|re|ve|ll|m|d)\b", re.I)
FIRST_PERSON_RX = re.compile(r'\b(?:I|me|my|mine|we|our|ours|us)\b')
HR_RX = re.compile(r'^ {0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$', re.M)
HEADING_RX = re.compile(r'^(#{1,6})[ \t]+(.+)$', re.M)
MINOR_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on',
               'at', 'to', 'by', 'up', 'as', 'off', 'via', 'vs', 'per', 'from', 'with', 'into',
               'onto', 'over'}
DASH_BLOCK_RX = re.compile('—')
CURLY_RX = re.compile('[“”‘’]')


def fn_model_dialect(an, ctx):
    spans = []
    for pat in MODEL_DIALECT_RX:
        spans.extend(m.span() for m in re.finditer(pat, an, re.I))
    return spans if len(spans) >= 2 else []


def fn_promotional(an, ctx):
    spans = [m.span() for m in re.finditer(_words_pattern(PROMO_PHRASES, inflect=False), an, re.I)]
    openers = [m.span(1) for m in PROMO_OPENER_RX.finditer(an)]
    if len(openers) >= 3:
        spans.extend(openers)
    return spans


def fn_stacked_adjectives(an, ctx):
    spans = []
    for m in STACK_RX.finditer(an):
        items = re.findall(STACK_WORD, m.group(1))
        lowered = [w.lower() for w in items]
        if any(w in STACK_STOP for w in lowered):
            continue
        if any(w in STOCK_ADJ or ADJ_SUFFIX_RX.search(w) for w in lowered):
            spans.append(m.span())
    return spans


def fn_synonym_cycling(an, ctx):
    spans = []
    for cluster in SYNONYM_CLUSTERS:
        hits = []
        used = 0
        for member in cluster:
            found = [m.span() for m in re.finditer(r'\b' + _lit(member) + r'(?:s|es)?\b', an, re.I)]
            if found:
                used += 1
                hits.extend(found)
        if used >= 3:
            spans.extend(hits)
    return spans


def fn_sentence_length_monotony(an, ctx):
    lens = [n for n in ctx['sent_words'] if n > 0]
    if len(lens) < 3:
        return []
    mean = sum(lens) / float(len(lens))
    if mean <= 0:
        return []
    sd = math.sqrt(sum((x - mean) ** 2 for x in lens) / len(lens))
    return [(0, len(an))] if sd / mean < 0.35 else []


def fn_uniform_paragraphs(an, ctx):
    counts = []
    for s, e in ctx['blocks']:
        counts.append(len(WORD_RX.findall(an[s:e])))
    counts = [c for c in counts if c > 0]
    if len(counts) < 4:
        return []
    mean = sum(counts) / float(len(counts))
    sd = math.sqrt(sum((x - mean) ** 2 for x in counts) / len(counts))
    return [(0, len(an))] if mean > 0 and sd / mean < 0.4 else []


def fn_alternation(an, ctx):
    sents = [(s, e, n) for (s, e), n in zip(ctx['sents'], ctx['sent_words']) if n > 0]
    spans = []
    i = 0
    while i < len(sents):
        k = i
        last = 0
        while k + 1 < len(sents):
            d = sents[k + 1][2] - sents[k][2]
            if abs(d) < 6:
                break
            sign = 1 if d > 0 else -1
            if last and sign == last:
                break
            last = sign
            k += 1
        if k - i + 1 >= 6:
            spans.append((sents[i][0], sents[k][1]))
            i = k + 1
        else:
            i += 1
    return spans


def fn_opener_repetition(an, ctx):
    sents = ctx['sents']
    starts = [s for s, _ in sents]
    spans = []
    for bs, be in ctx['blocks']:
        lo = bisect_left(starts, bs)
        hi = bisect_left(starts, be)
        inside = list(range(lo, hi))
        if len(inside) < 3:
            continue
        openers = {}
        for idx in inside:
            s, e = sents[idx]
            words = WORD_RX.findall(an[s:e])[:2]
            key = ' '.join(w.lower() for w in words)
            openers.setdefault(key, []).append(idx)
        for key, idxs in openers.items():
            if len(idxs) >= 3 and key:
                spans.extend(sents[i] for i in idxs)
    return spans


def fn_semicolon(an, ctx):
    if len(ctx['words']) < 300 or ';' in an:
        return []
    parens = len(re.findall(r'\([^()\n]*\)', an))
    return [(0, len(an))] if parens <= 1 else []


def fn_contraction_absence(an, ctx):
    words = len(ctx['words'])
    first_person = len(FIRST_PERSON_RX.findall(an))
    if words == 0 or first_person < 3 or first_person / float(words) < 0.03:
        return []
    full = len(FULL_FORM_RX.findall(an))
    contractions = len(CONTRACTION_RX.findall(an))
    if full >= 3 and full >= 0.8 * (full + contractions):
        return [(0, len(an))]
    return []


def fn_hedge_stacking(an, ctx):
    spans = []
    for s, e in ctx['sents']:
        if len(HEDGE_RX.findall(an[s:e])) >= 2:
            spans.append((s, e))
    return spans


def fn_bold(an, ctx):
    return [m.span() for m in re.finditer(r'\*\*(?=\S)[^*\n]+?\*\*', an)]


def fn_em_dash(an, ctx):
    spans = []
    for s, e in ctx['blocks']:
        hits = [(s + m.start(), s + m.end()) for m in DASH_BLOCK_RX.finditer(an[s:e])]
        if len(hits) >= 2:
            spans.extend(hits)
    return spans


def fn_curly_quotes(an, ctx):
    return [m.span() for m in CURLY_RX.finditer(an)]


def fn_year_range(an, ctx):
    spans = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', an):
        if int(m.group(1)) < int(m.group(2)):
            spans.append(m.span())
    return spans


def fn_title_case(an, ctx):
    spans = []
    for m in HEADING_RX.finditer(an):
        title = re.sub(r'[ \t]+#+$', '', m.group(2).rstrip(' \t'))
        if not title[:1].isalpha() or title.isupper():
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’-]*", title)
        if len(words) < 3:
            continue
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            spans.append(m.span())
    return spans


def fn_fragmented_headers(an, ctx):
    lines = ctx['lines']
    starts = []
    off = 0
    for ln in lines:
        starts.append(off)
        off += len(ln) + 1
    spans = []
    for i, ln in enumerate(lines):
        m = re.match(r'^#{1,6}\s+(.*\S)', ln)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        cand = lines[j].strip()
        if not cand or cand[0] in '#-*+|>' or re.match(r'\d+[.)]\s', cand):
            continue
        if len(cand.split()) > 4:
            continue
        head_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', m.group(1))}
        cand_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', cand)}
        if head_words & cand_words:
            spans.append((starts[j], starts[j] + len(lines[j])))
    return spans


def fn_mid_essay_bullets(an, ctx):
    if re.search(r'^#{1,6}\s', an, re.M):
        return []
    lists = []
    prose = 0
    for s, e in ctx['blocks']:
        nonblank = [ln for ln in an[s:e].split('\n') if ln.strip()]
        if nonblank and all(re.match(r'^\s*(?:[-*+]|\d+[.)])\s+', ln) for ln in nonblank):
            lists.append((s, e))
        else:
            prose += 1
    return lists if lists and prose >= 2 else []


def fn_transition_cluster(an, ctx):
    spans = []
    for s, e in ctx['blocks']:
        hits = [m.span(1) for m in TRANSITION_RX.finditer(an[s:e])]
        if len(hits) >= 2:
            spans.extend((s + a, s + b) for a, b in hits)
    return spans


def fn_degenerate_repetition(an, ctx):
    words = ctx['words']
    n = 6
    if len(words) < 12:
        return []
    grams = [tuple(w[2] for w in words[i:i + n]) for i in range(len(words) - n + 1)]
    counts = Counter(grams)
    repeated = [i for i, g in enumerate(grams) if counts[g] > 1]
    if len(repeated) >= 0.2 * len(grams):
        return [(words[i][0], words[i + n - 1][1]) for i in repeated]
    return []


def fn_horizontal_rules(an, ctx):
    lines = ctx['lines']
    if len(lines) < 24:
        return []
    spans = []
    offset = 0
    previous = ''
    for line in lines:
        if HR_RX.match(line) and not previous.strip():
            spans.append((offset, offset + len(line)))
        previous = line
        offset += len(line) + 1
    return spans if len(spans) >= 3 else []


PATTERN_TABLE = [
    (1, 'ai_vocabulary', 'AI vocabulary', _vocab(AI_VOCAB), True),
    (2, 'model_dialect_vocabulary', 'Model-dialect vocabulary', fn_model_dialect, True),
    (3, 'promotional_language', 'Promotional language', fn_promotional, True),
    (4, 'hyphenated_pair_overuse', 'Hyphenated word-pair overuse', _rx(
        r'\b(?:cutting-edge|state-of-the-art|best-in-class|next-generation|high-quality|'
        r'user-friendly|data-driven|results-driven|customer-centric|value-driven|time-tested|'
        r'well-rounded|forward-thinking|game-changing|world-class)\b'), True),
    (5, 'simple_yet_cliche', 'Simple-yet cliche', _rx(
        r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'), True),
    (6, 'stacked_adjectives', 'Stacked adjective chains', fn_stacked_adjectives, True),
    (8, 'synonym_cycling', 'Synonym cycling', fn_synonym_cycling, True),
    (10, 'significance_inflation', 'Significance inflation', _rxs([
        r'\b(?:stands?|stood|serves?|served)\s+as\s+(?:an?\s+|the\s+)?(?:testament|reminder|symbol|beacon|'
        r'cornerstone|bridge|gateway|hallmark)\b',
        r'\b(?:underscor(?:es|ed|ing)|highlights?|highlighted|highlighting)\s+(?:its|the|their|his|her)\s+'
        r'(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
        r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)s?\b',
        r'\bmarks?\s+a\s+(?:turning point|milestone|watershed|new chapter|new era)\b',
        r'\bsymbolizes\b', r'\bsets the stage for\b', r'\bleft an indelible mark\b',
        r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
        r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize)\b'])),
    (11, 'notability_name_dropping', 'Notability name-dropping', _rxs([
        r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+'
        r'[^.!?\n]{0,200}?' + OUTLETS + r'[^.!?\n]*?(?:,|and|&)\s*' + OUTLETS,
        r'\b\d[\d,.]*\s*[KkMm]?\+?\s+followers\b',
        r'\b(?:strong|active|robust|significant|growing)\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bwidely (?:covered|reported|cited)\b', r'\bindependent (?:media )?coverage\b'])),
    (12, 'vague_attributions', 'Vague attributions', _rxs([
        r'\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b',
        r'\bindustry (?:reports|observers|analysts)\b', r'\bobservers have (?:cited|noted)\b',
        r'\bsome critics argue\b', r'\bresearchers have found\b', r'\bstudies suggest\b',
        r'\bit is widely believed\b'])),
    (13, 'article_title_proper_noun', 'Article title used as a proper noun', _rx(
        r'\bthe (?:list|index|compilation|collection|catalogue|guide|overview) of [^.!?\n]{1,80}?\s+is\s+(?:a|an|the)\b')),
    (14, 'ecosystem_padding', 'Conservation and ecosystem padding', _rxs([
        r'\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
        r'\bconservation efforts are (?:underway|ongoing|in place)\b',
        r'\bserves as an indicator species\b', r'\bcontributes to biodiversity\b'])),
    (15, 'false_ranges', 'False ranges', _rxs([
        r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?'
        r'\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom (?:the )?humble\b[^.!?\n]{0,200}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b'])),
    (16, 'ing_tail_clauses', 'Superficial -ing tail clause', _rx(
        r',\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
        r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
        r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')),
    (17, 'negative_parallelism', 'Negative parallelism', _rx(
        r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b|"
        r"\bnot only\b(?:(?![.!?\n]).){0,40}?\bbut\b|"
        r"\bdoesn['’]t just\b[^,.!?\n]{0,40}?\bit\b"), False),
    (17, 'tailing_negation', 'Tailing negation', _rx(
        r',\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b')),
    (18, 'not_x_just_y', 'Not X, just Y framing', _rxs([
        r'\b(?:no|not)\s+[\w\'’-]+,\s*(?:just|only|simply)\s+[\w\'’-]+',
        r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+"
        r"(?:(?:a|an|the)\s+)?[\w'’-]+\s*(?:,|—|–|-)\s*(?:it['’]s|it is|it was|"
        r"they['’]re|they are|they were|that['’]s|but)\b"])),
    (19, 'filler_phrases', 'Filler phrases', _vocab([
        'in order to', 'due to the fact that', 'at this point in time', 'in the event that',
        'has the ability to', 'it is important to note that', 'it should be mentioned that',
        'needless to say'], inflect=False), False),
    (20, 'empty_pivot_phrases', 'Empty pivot phrase', _rxs([
        r"\bit['’]s worth (?:noting|mentioning) that\b", r'\bit bears (?:noting|mentioning) that\b',
        r'\bone thing to (?:consider|keep in mind) is\b', r'\bit is interesting to note that\b',
        r'\ba key consideration is\b', r'\ba point to highlight is\b'])),
    (21, 'outcome_speculation_tails', 'Outcome-speculation tail', _rx(
        r',\s*(?:raising questions about|prompting reflection on|sparking debate about|'
        r'with broader implications for|reshaping our understanding of|paving the way for|'
        r'signaling a shift toward)\b')),
    (22, 'persuasive_authority_tropes', 'Persuasive authority trope', _vocab([
        "here's the thing", 'make no mistake', 'the truth is', "let's be honest",
        'the simple fact is', 'at its core', 'what really matters', 'more than anything',
        'at the end of the day', 'the bottom line is', 'in reality', 'fundamentally,',
        'the real question is', 'the heart of the matter', 'the deeper issue',
        'when you get down to it', 'when all is said and done'], inflect=False), False),
    (23, 'editorial_interjections', 'Editorial interjection', _rxs([
        r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize)\b",
        r'\bone must note that\b', r'\bit is worth pointing out\b',
        r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b'])),
    (24, 'self_thoroughness', 'Self-thoroughness phrase', _rxs([
        r'\bthis (?:comprehensive (?:guide|overview|analysis)|in-depth (?:analysis|look|examination)|'
        r'complete (?:guide|overview))\b',
        r'\ba thorough examination of\b', r'\beverything you need to know about\b'])),
    (25, 'question_answer_pattern', 'Question-and-answer rhetorical pattern',
     _rx(r'(?:^|[.!?]\s+|\n[ \t]*)((?:is|are|do|does|did|can|could|will|would|should|has|have|was|were|'
         r'may|might|must)\b[^.!?\n]{1,60}\?)\s*(?:yes|no|absolutely|never|maybe|probably|always)[.!]',
         re.I | re.M, group=1)),
    (26, 'concrete_evidence_defense', 'Concrete-evidence defense phrase', _rxs([
        r'\bwithout concrete (?:evidence|proof)\b', r'\bdo you have concrete (?:evidence|proof)\b',
        r'\bI (?:would )?need concrete (?:evidence|examples|proof) to\b',
        r'\babsent concrete (?:proof|evidence)\b', r'\bprovide concrete (?:evidence|proof)\b'])),
    (27, 'compulsive_intro_hooks', 'Compulsive intro hook', _rxs([
        r"\bin today['’]s(?: \w+){0,2} (?:world|landscape|environment|market)\b",
        r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
        r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b',
        r'\b(?:great|exciting|big) news\s*[!:]',
        r'\bever (?:wanted|wondered|dreamed|wished)\b[^.!?\n]{0,60}\?',
        r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b'])),
    (30, 'diff_anchored_writing', 'Diff-anchored writing', _rxs([
        r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
        r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) '
        r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b',
        r'\bpreviously\b[^.!?\n]{0,200}\bnow\b', r"\bwasn['’]t there before\b|\bweren['’]t there before\b",
        r'\bwe(?:[\'’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b'])),
    (31, 'signposting', 'Signposting and announcements', _rxs([
        r"\blet['’]s (?:dive|delve|explore)\b", r"\blet['’]s break (?:this|it) down\b",
        r"\bhere['’]s what you need to know\b", r'\bwithout further ado\b',
        r"\bnow let['’]s look at\b", r'\bbuckle up\b', r'\bstay with me\b',
        r'\b(?:are you )?ready to dive in\b'])),
    (32, 'cataloguing_lead_ins', 'Cataloguing lead-in', _rxs([
        r'\b(?:used|uses|employs|employed|relied on|utilizes)\s+(?:several|various|a number of|multiple|'
        r'different|many|numerous)\s+\w+',
        r'(?:^|[.!?]\s+)These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+'
        r'(?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|'
        r'heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b'], )),
    (33, 'inline_header_list', 'Inline-header vertical list', _rx(
        r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+:\*\*|^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+\*\*:',
        re.M)),
    (34, 'mid_essay_bullets', 'Mid-essay bullet injection', fn_mid_essay_bullets),
    (35, 'fragmented_header', 'Fragmented header', fn_fragmented_headers),
    (36, 'formulaic_challenges', 'Formulaic challenges section', _rxs([
        r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
        r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b', r'\bcontinues? to thrive\b',
        r'\btypical of (?:emerging|urban|modern)\b', r'\bfaces (?:several|many|numerous) challenges\b'])),
    (37, 'transition_cluster', 'Transition cluster', fn_transition_cluster),
    (38, 'compulsive_conclusion', 'Compulsive conclusion phrase', _rx(
        r'^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|'
        r'ultimately)\b', re.I | re.M)),
    (39, 'generic_positive_conclusion', 'Generic positive conclusion', _rxs([
        r'\bthe future looks bright\b', r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b',
        r'\bstep in the right direction\b',
        r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b",
        r'\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b'])),
    (40, 'sentence_length_monotony', 'Sentence-length monotony', fn_sentence_length_monotony),
    (41, 'mechanical_alternation', 'Mechanical sentence-length alternation', fn_alternation),
    (42, 'opener_repetition', 'Opener repetition', fn_opener_repetition),
    (44, 'uniform_paragraph_length', 'Uniform paragraph length', fn_uniform_paragraphs),
    (46, 'no_semicolons_or_parentheses', 'Semicolon and parenthesis underuse', fn_semicolon),
    (47, 'chatbot_artifacts', 'Chatbot artifact', _rxs([
        r'\bI hope this helps\b', r'\bCertainly!', r'\bOf course!', r'\blet me know if you\b',
        r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b',
        r'\bhappy to help\s*[.!]', r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
        r'\bhere (?:are|[\'’]s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
        r'\bhere (?:is|[\'’]s) a draft\b', r'\bdepending on the (?:vibe|tone|style)\b',
        r'\bI hope (?:this email )?finds you well\b',
        r'\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
        r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
        r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked),? here\b',
        r'\bhere is (?:the )?(?:draft|first pass|revised version (?:of|for your))\b'], re.I)),
    (48, 'sycophantic_tone', 'Sycophantic tone', _rxs([
        r"\byou(?:['’]re| are) absolutely right\b",
        r'\b(?:great|excellent|fantastic|wonderful|thoughtful|brilliant)\s+(?:question|point)\s*[!.,]',
        r'\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\b',
        r"\bthat['’]s an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"])),
    (50, 'knowledge_cutoff_disclaimer', 'Knowledge-cutoff disclaimer', _rxs([
        r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
        r'\bwhile specific details are (?:limited|scarce|not extensively (?:documented)|not widely documented)\b',
        r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
        r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b'])),
    (51, 'copula_avoidance', 'Copula avoidance', _rxs([
        r'\b(?:serves?|stands?|functions?|acts?) as\b', r'\brepresents (?:a|the)\b', r'\bmarks (?:a|the)\b',
        r'\bboasts\b', r'\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various|two|three|four|five)\b',
        r'\boffers an?\b', r'\brefers to\b'])),
    (54, 'hedge_stacking', 'Hedge stacking', fn_hedge_stacking),
    (55, 'contraction_absence', 'Contraction absence', fn_contraction_absence),
    (56, 'boldface_overuse', 'Boldface emphasis', fn_bold),
    (57, 'emoji', 'Emoji', _rx('[\U0001F000-\U0001FAFF☀-➿⭐⭕]', 0)),
    (58, 'em_dash_overuse', 'Em-dash overuse', fn_em_dash),
    (59, 'title_case_heading', 'Title-case heading', fn_title_case),
    (60, 'curly_quotes', 'Curly quotation marks', fn_curly_quotes),
    (61, 'hyphen_for_en_dash', 'Hyphen used for en dash in a year range', fn_year_range),
    (63, 'placeholder_text', 'Placeholder text', _rxs([
        r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])",
        r"\[[^\]\n]*\b(?:name|company|client|place|person|organization|source|address)\b[^\]\n]*\](?![(\[])",
        r'\[[A-Z][A-Z _]{2,}\](?![(\[])', r'\{\{[^{}\n]*\}\}', r'\bx{3,}\b', r'\blorem ipsum\b'], 0)),
    (64, 'chat_reference_markup', 'Chat reference markup', _rxs([
        r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\b', r'\bnavlist\b',
        '【\\d+†[^】\\n]*】'], 0)),
    (65, 'ai_tracking_parameters', 'AI tracking parameter', _rx(
        r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|'
        r'copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9-])(?!\.[A-Za-z0-9-])')),
    (69, 'marketing_slop_phrases', 'Canonical marketing phrase', _rxs([
        r"\bunlock(?:ing)? (?:your |its |their |the )?full potential\b",
        r'\bnavigat(?:e|es|ed|ing) the complexities\b', r'\ba testament to the (?:power|importance) of\b',
        r'\bstay(?:ing|s)? ahead of the curve\b', r'\bturn(?:ing|s)? (?:challenges|obstacles) into opportunities\b',
        r'\btak(?:e|es|ing) (?:something|it|\w+) to the next level\b', r'\bharness(?:ing|es)? the power of\b',
        r'\bpaving the way for\b', r'\bsaying goodbye to\b', r'\bimagining a world where\b'])),
    (70, 'decorative_rules', 'Decorative horizontal rules', fn_horizontal_rules),
    (71, 'degenerate_repetition', 'Degenerate repetition', fn_degenerate_repetition),
]

PATTERNS = []
for _num, _slug, _label, _fn, *_rest in PATTERN_TABLE:
    _moving = _rest[0] if _rest else (_num not in WEIGHT_ZERO)
    PATTERNS.append(Pattern(_num, _slug, _label, _fn, _moving))


# ---------------------------------------------------------------- scoring

def confidence_for(words, families):
    if words < 40:
        return 'none'
    if words < 120:
        return 'low'
    if words < 300:
        return 'low' if families <= 1 else 'moderate'
    return 'high'


def confidence_reason(conf, words):
    if conf == 'none':
        return 'fewer than 40 words'
    if conf == 'low':
        return 'fewer than 300 words or a single pattern family'
    if conf == 'moderate':
        return 'fewer than 300 words'
    return ''


def score_from(fams, words):
    numbers = set(fams)
    count = len(numbers)
    score = min(100, 8 * count + 2 * sum(min(c, 5) for c in fams.values()))
    if count <= 1:
        score = min(score, 40)
    if numbers and numbers <= RHYTHM:
        score = min(score, 20 if numbers == {40} else 40)
    conf = confidence_for(words, count)
    decisive = numbers & DECISIVE
    if len(decisive) >= 2:
        score = max(score, 65)
    elif len(decisive) == 1 and conf in ('moderate', 'high'):
        score = max(score, 45)
    if words < 120:
        first = len(numbers & FIRST_GROUP)
        if first >= 3:
            score = max(score, 45)
        elif first == 2:
            score = max(score, 25)
    if words >= 400:
        if count >= 6:
            score = max(score, 45)
        elif count >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), conf


def band_of(score):
    for limit, name, phrase in BANDS:
        if score <= limit:
            return name, phrase
    return BANDS[-1][1], BANDS[-1][2]


def _excerpt(an, s, e):
    text = an[s:e].replace('\n', ' ').strip()
    if len(text) > 80:
        text = text[:79] + '…'
    return text


def _finding(num, slug, label, count, samples, moving, decisive):
    return {'key': '%d_%s' % (num, slug), 'number': num, 'label': label, 'count': count,
            'samples': samples[:3], 'moving': moving, 'decisive': decisive}


def _interval(sents, sent_words, sent_hits, doc_fams, point):
    n = len(sents)
    rng = random.Random(20240601)
    results = []
    for _ in range(200):
        fams = dict(doc_fams)
        words = 0
        for idx in (rng.randrange(n) for _ in range(n)):
            words += sent_words[idx]
            for num, c in sent_hits[idx].items():
                fams[num] = fams.get(num, 0) + c
        results.append(score_from(fams, words)[0])
    results.sort()
    low = results[int(0.05 * (len(results) - 1))]
    high = results[int(0.95 * (len(results) - 1))]
    return min(low, point), max(high, point)


def build_report(raw, want_ci=False):
    truncated = len(raw) > WINDOW
    window = raw[:WINDOW]
    text = window.replace('\r\n', '\n').replace('\r', '\n')
    _, removed, nonstd = _char_pass(text, scrub=True)
    match_text, _, _ = _char_pass(text, scrub=False)
    an = _mask_markdown(match_text)
    ctx = _context(an)
    words = len(ctx['words'])

    findings = []
    per_sentence = [dict() for _ in ctx['sents']]
    doc_fams = {}
    sent_starts = [s for s, _ in ctx['sents']]
    for pat in PATTERNS:
        if pat.fn is None:
            continue
        spans = pat.fn(an, ctx)
        if not spans:
            continue
        findings.append(_finding(pat.num, pat.slug, pat.label, len(spans),
                                 [_excerpt(an, s, e) for s, e in spans[:3]], pat.moving,
                                 pat.num in DECISIVE))
        if pat.moving:
            for s, e in spans:
                if pat.num in DOC_LEVEL or not sent_starts:
                    doc_fams[pat.num] = doc_fams.get(pat.num, 0) + 1
                else:
                    idx = max(0, min(len(sent_starts) - 1, bisect_left(sent_starts, s + 1) - 1))
                    per_sentence[idx][pat.num] = per_sentence[idx].get(pat.num, 0) + 1

    # character layer, computed on the scan window
    if removed:
        findings.append(_finding(62, 'invisible_characters', 'Invisible or zero-width characters',
                                 len(removed), ['U+%04X' % ord(c) for c in removed[:3]], True, True))
    homo = [tok for tok in re.findall(r'\S+', text) if _is_homoglyph_token(tok)]
    if homo:
        findings.append(_finding(66, 'mixed_script_homoglyphs', 'Mixed-script homoglyphs', len(homo),
                                 [t[:40] for t in homo[:3]], True, True))
    if nonstd:
        findings.append(_finding(67, 'nonstandard_spaces', 'Non-standard spaces', len(nonstd),
                                 ['U+%04X' % ord(c) for c in nonstd[:3]], True, False))
    trailing = [i + 1 for i, ln in enumerate(text.split('\n')) if ln != ln.rstrip(' \t')]
    end_extra = 1 if re.search(r'\n\s*\n\Z', text) else 0
    lead_extra = 1 if text[:1].isspace() else 0
    trail_count = len(trailing) + end_extra + lead_extra
    if trail_count:
        samples = ['line %d ends in spaces' % n for n in trailing[:3]]
        if end_extra:
            samples.append('two or more newlines at the end of the text')
        if lead_extra:
            samples.append('whitespace before the first character')
        findings.append(_finding(68, 'trailing_whitespace', 'Trailing or stray whitespace', trail_count,
                                 samples, False, False))
    for f in findings:
        if f['number'] in (62, 66, 67) and f['moving']:
            doc_fams[f['number']] = f['count']
    findings.sort(key=lambda f: f['number'])

    fams = {}
    for f in findings:
        if f['moving']:
            fams[f['number']] = fams.get(f['number'], 0) + f['count']
    score, conf = score_from(fams, words)
    band, phrase = band_of(score)

    report = {}
    for f in findings:
        report[f['key']] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': confidence_reason(conf, words),
        'patterns_flagged': len(findings),
        'invisible_chars': len(removed),
        'nonstandard_spaces': len(nonstd),
        'homoglyphs': len(homo),
        'words': words,
        'sentences': len(ctx['sents']),
    }
    if want_ci:
        if len(ctx['sents']) >= 4:
            low, high = _interval(ctx['sents'], ctx['sent_words'], per_sentence, doc_fams, score)
            metrics['score_ci'] = [low, high]
            metrics['score_ci_note'] = 'resampled over sentences (200 draws, 5th to 95th percentile)'
        else:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (need at least four)'
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------- command line

def _write_out(text):
    sys.stdout.buffer.write(text.encode('utf-8'))
    sys.stdout.flush()


def _fail(message, code):
    sys.stderr.write(json.dumps({'error': message}) + '\n')
    sys.stderr.flush()
    return code


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    clean = False
    ci = False
    operands = []
    ended = False
    for arg in argv:
        if ended:
            operands.append(arg)
        elif arg == '--':
            ended = True
        elif arg in ('-h', '--help'):
            _write_out(USAGE)
            return 0
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-'):
            return _fail("unknown option '%s' (see --help)" % arg, 2)
        else:
            operands.append(arg)
    if len(operands) > 1:
        sys.stderr.write('prosecheck: scanned only the first file, %s; %d more file(s) ignored\n'
                         % (operands[0], len(operands) - 1))
    try:
        raw = read_input(operands[0] if operands else None)
    except InputError as exc:
        return _fail(str(exc), exc.code)
    if clean:
        _write_out(scrub_document(raw))
        return 0
    report = build_report(raw, want_ci=ci)
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
