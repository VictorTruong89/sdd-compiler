"""Parameters, commands, groups and the invocation flow."""

import inspect
import os
import re
import sys

from . import termui
from .context import Context, ParameterSource
from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoArgsHelpError,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, make_default_short_help
from .paramtypes import BOOL, INT, Tuple, convert_type, infer_type
from .parser import NO_VALUE, OptionParser, is_flag_name
from .utils import echo

_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}
_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


def _prefix_len(name):
    return len(name) - len(re.sub(r"^[^A-Za-z0-9_]+", "", name))


# spec: FP-03, FP-04 — declared parameters and their value sources (Contract §4)
class Parameter:
    """Base class for options and arguments."""

    param_type_name = "parameter"
    allow_from_autoenv = False

    def __init__(self, param_decls=None, type=None, required=False, default=None, callback=None,
                 nargs=None, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, hidden=False):
        self._parse_decls(list(param_decls or ()))
        self.default = default
        self.required = bool(required)
        self.callback = callback
        self.nargs = 1 if nargs is None else nargs
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar) if envvar else None
        self._shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.type = self._build_type(type, default)
        if isinstance(self.type, Tuple):
            self.nargs = len(self.type.types)

    # -- declaration -----------------------------------------------------------

    def _parse_decls(self, decls):
        self.opts = []
        self.secondary_opts = []
        self.name = decls[0] if decls else None

    def _build_type(self, type, default):
        return convert_type(type, default)

    def get_error_hint(self, ctx):
        return None

    def get_help_record(self, ctx):
        return None

    def _is_multivalue(self):
        return self.multiple or self.nargs == -1

    def _arity(self):
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        return self.nargs

    # -- sources ---------------------------------------------------------------

    def _env_names(self, ctx):
        names = list(self.envvar or [])
        if ctx is not None and ctx.auto_envvar_prefix is not None and self.allow_from_autoenv:
            names.append(f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_"))
        return names

    def _env_value(self, ctx):
        for name in self._env_names(ctx):
            text = os.environ.get(name)
            if text:
                return text
        return None

    def _split_raw(self, text):
        """Shape a string from the environment or a default map into raw form."""
        arity = self._arity()
        if arity == 1 and not self.multiple:
            return text
        items = self.type.split_envvar_value(text)
        if arity == -1:
            return items
        if arity == 1:
            return items
        if len(items) % arity:
            raise BadParameter(f"Expected a multiple of {arity} values, got {len(items)}.",
                               ctx=None, param=self)
        units = [tuple(items[i:i + arity]) for i in range(0, len(items), arity)]
        if self.multiple:
            return units
        return units[0] if units else None

    def _coerce_default(self, value, ctx, source):
        """Shape a default (declared or from the default map) into raw form."""
        if value is None:
            return None
        if self.is_flag_like():
            return value
        if isinstance(value, str):
            if self._arity() != 1 or self.nargs == -1 or isinstance(self.type, Tuple):
                return self._split_raw(value)
            if self.multiple:
                raise BadParameter("needs an iterable (sequence) default, not a single string.",
                                   ctx=ctx, param=self)
            return value
        if self.multiple:
            if not isinstance(value, (list, tuple)):
                raise BadParameter("needs an iterable (sequence) default.", ctx=ctx, param=self)
            return list(value)
        return value

    def is_flag_like(self):
        return False

    def get_default(self, ctx, call=True):
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    def _fallback(self, ctx):
        """Default map, then declared default; ``(raw, source)``."""
        found, value = ctx.lookup_default(self.name) if ctx is not None else (False, None)
        if found:
            return self._coerce_default(value, ctx, ParameterSource.DEFAULT_MAP), ParameterSource.DEFAULT_MAP
        value = self.get_default(ctx)
        return self._coerce_default(value, ctx, ParameterSource.DEFAULT), ParameterSource.DEFAULT

    # -- processing ------------------------------------------------------------

    def _is_missing(self, raw):
        if raw is None:
            return True
        return self._is_multivalue() and len(raw) == 0

    def _convert_unit(self, ctx, unit):
        if isinstance(self.type, Tuple) or self.nargs == 1:
            return self.type(unit, self, ctx)
        return tuple(self.type(item, self, ctx) for item in unit)

    def _convert_shape(self, ctx, raw):
        if self.multiple:
            return tuple(self._convert_unit(ctx, unit) for unit in raw)
        return self._convert_unit(ctx, raw)

    def process_value(self, ctx, raw, source):
        if self._is_missing(raw):
            if self.required:
                raise MissingParameter(message="", ctx=ctx, param=self)
            value = () if self._is_multivalue() else None
        else:
            value = self._convert_shape(ctx, raw)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def handle_parse_result(self, ctx, opts):
        """Resolve, convert and check this parameter. Returns ``(value, source)``."""
        occurrences = opts.get(self)
        source = ParameterSource.DEFAULT
        try:
            raw = self._raw_from_occurrences(occurrences)
            raw, source = self.consume_value(ctx, raw)
            if self.deprecated and occurrences is not None and source is ParameterSource.COMMANDLINE:
                note = self.deprecated if isinstance(self.deprecated, str) else ""
                echo(f"DeprecationWarning: The {self.param_type_name} '{self.get_error_hint(ctx)}' "
                     f"is deprecated.{(' ' + note) if note else ''}", err=True)
            value = self.process_value(ctx, raw, source)
        except UsageError:
            if ctx is not None and ctx.resilient_parsing:
                return None, source
            raise
        return value, source

    def _raw_from_occurrences(self, occurrences):
        if occurrences is None:
            return None
        return occurrences[-1]

    def consume_value(self, ctx, raw):
        raise NotImplementedError


# spec: FP-03, FP-07, FP-08 — options: flags, counters, env, defaults, prompts
class Option(Parameter):
    """A named parameter, given as ``--name value``, ``-n value``, or a flag."""

    param_type_name = "option"
    allow_from_autoenv = True

    def __init__(self, param_decls=None, *, show_default=None, prompt=False,
                 confirmation_prompt=False, prompt_required=True, hide_input=False,
                 is_flag=None, flag_value=None, count=False, allow_from_autoenv=True,
                 help=None, show_envvar=False, type=None, default=None, required=False,
                 nargs=None, multiple=False, **attrs):
        decls = list(param_decls or ())
        self._parse_decls(decls)
        if is_flag is None:
            if flag_value is not None:
                is_flag = True
            elif count:
                is_flag = False
            else:
                is_flag = bool(self.secondary_opts)
        if is_flag and count:
            raise DeclarationError("An option cannot be both a flag and a counter.")
        if self.secondary_opts and not is_flag:
            raise DeclarationError("An on/off option pair must be declared as a flag.")
        if nargs is not None and (not isinstance(nargs, int) or nargs < 1):
            raise DeclarationError("nargs must be a positive integer for an option.")
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.is_bool_flag = self.is_flag and (flag_value is None or isinstance(flag_value, bool))
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        self.flag_needs_value = (not self.is_flag and not self.count
                                 and (flag_value is not None or bool(prompt)))
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.confirmation_prompt = confirmation_prompt
        self.hide_input = hide_input
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.help = help
        self._auto_default = False
        if self.is_flag or self.count:
            if default is None:
                if self.count:
                    default = 0
                elif self.is_bool_flag:
                    default = False
                self._auto_default = True
        if self.is_flag or self.count:
            arity = 0
        else:
            arity = 1 if nargs is None else nargs
        if attrs.get("deprecated"):
            if required:
                raise DeclarationError("A deprecated option cannot also be required.")
            if prompt:
                raise DeclarationError("A deprecated option cannot use a prompt.")
        super().__init__(decls, type=type, required=required, default=default, nargs=arity,
                         multiple=multiple, **attrs)

    def is_flag_like(self):
        return self.is_flag or self.count

    def _parse_decls(self, decls):
        self.opts = []
        self.secondary_opts = []
        dest = None
        for decl in decls:
            if is_flag_name(decl):
                # An on/off pair: "--shout/--no-shout", or "/on/off" with a "/" prefix.
                split_at = decl.find("/", 1)
                if split_at > 0 and len(decl) > split_at + 1:
                    first, second = decl[:split_at], decl[split_at + 1:]
                    if not is_flag_name(second):
                        second = decl[0] + second
                    self.opts.append(first)
                    self.secondary_opts.append(second)
                else:
                    self.opts.append(decl)
            else:
                if dest is not None:
                    raise DeclarationError(f"Option has two destinations: {dest!r} and {decl!r}.")
                dest = decl
        if not self.opts and not self.secondary_opts:
            if dest is None:
                raise DeclarationError("An option needs a name or a destination.")
            self.opts = ["--" + dest.replace("_", "-")]
        if dest is None:
            longs = [o for o in self.opts if _prefix_len(o) >= 2]
            chosen = (longs or self.opts)[0]
            dest = re.sub(r"^[^A-Za-z0-9_]+", "", chosen).replace("-", "_")
        self.name = dest

    def _build_type(self, type, default):
        if type is None:
            if self.is_flag:
                return BOOL if self.is_bool_flag else infer_type(self.flag_value)
            if self.count:
                return INT
            return infer_type(default)
        return convert_type(type)

    def get_error_hint(self, ctx):
        names = self.opts + self.secondary_opts
        return " / ".join(f"'{n}'" for n in names)

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        text = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs > 1 and not isinstance(self.type, Tuple):
            text = " ".join([text] * self.nargs)
        return text

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        names = ", ".join(self.opts)
        if self.secondary_opts:
            names = f"{names}/{', '.join(self.secondary_opts)}"
        if not self.is_flag and not self.count:
            metavar = self.make_metavar()
            if metavar:
                names = f"{names} {metavar}"
        parts = []
        help_text = self.help or ""
        if self.deprecated:
            parts.append("(Deprecated)")
        if help_text:
            parts.append(help_text)
        show = self.show_default
        if show is None and ctx is not None:
            show = ctx.show_default
        if show and self.default is not None and not (self.is_bool_flag and self.default is False):
            if isinstance(show, str):
                shown = show
            elif callable(self.default):
                shown = "(dynamic)"
            elif isinstance(self.default, (list, tuple)):
                shown = ", ".join(str(v) for v in self.default)
            else:
                shown = str(self.default)
            parts.append(f"[default: {shown}]")
        if self.show_envvar:
            env_names = self._env_names(ctx)
            if env_names:
                parts.append(f"[env var: {', '.join(env_names)}]")
        return names, " ".join(parts)

    # -- sources ---------------------------------------------------------------

    def _raw_from_occurrences(self, occurrences):
        if occurrences is None:
            return None
        if self.is_flag:
            return occurrences[-1]
        if self.count:
            return len(occurrences)
        if self.multiple:
            return list(occurrences)
        return occurrences[-1]

    def _flag_from_env(self, text):
        """Interpret an environment value for a flag; ``None`` means unset."""
        stripped = text.strip().lower()
        if self.is_bool_flag:
            if stripped == "" or stripped in _FALSE:
                return False
            if stripped in _TRUE:
                return self.flag_value
            raise BadParameter(f"{text!r} is not a valid boolean.", param=self)
        if text == str(self.flag_value):
            return self.flag_value
        if stripped in _TRUE:
            return self.flag_value
        if stripped in _FALSE:
            return False
        return None

    def _prompts_when_omitted(self):
        """Prompt on omission when prompting is on and either required or prompt_required."""
        return bool(self.prompt) and (self.prompt_required or self.required)

    def _default_for_prompt(self, ctx):
        if self.multiple:
            return None
        found, value = ctx.lookup_default(self.name) if ctx is not None else (False, None)
        if found:
            return value
        return self.get_default(ctx)

    def _prompt(self, ctx, default):
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if self.is_flag:
            return termui.confirm(text, default=bool(default))
        value = termui.prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if self.multiple:
            return [value]
        return value

    def _fill_no_value(self, ctx):
        if self.prompt:
            return self._prompt(ctx, self._default_for_prompt(ctx)), ParameterSource.PROMPT
        if self.flag_value is not None:
            return self.flag_value, ParameterSource.COMMANDLINE
        raise BadOptionUsage(f"Option '{self.opts[0]}' requires an argument.", ctx=ctx)

    def consume_value(self, ctx, raw):
        if raw is not None:
            if self.is_flag or self.count:
                return raw, ParameterSource.COMMANDLINE
            if raw is NO_VALUE:
                return self._fill_no_value(ctx)
            if self.multiple and any(item is NO_VALUE for item in raw):
                filled = []
                source = ParameterSource.COMMANDLINE
                for item in raw:
                    if item is NO_VALUE:
                        value, source = self._fill_no_value(ctx)
                        filled.append(value)
                    else:
                        filled.append(item)
                return filled, source
            return raw, ParameterSource.COMMANDLINE

        if self.is_flag:
            text = self._env_value(ctx)
            if text is not None:
                value = self._flag_from_env(text)
                if value is not None:
                    return value, ParameterSource.ENVIRONMENT
            if self._prompts_when_omitted():
                return self._prompt(ctx, self._default_for_prompt(ctx)), ParameterSource.PROMPT
            return self._fallback(ctx)

        text = self._env_value(ctx)
        if text is not None:
            return self._split_raw(text), ParameterSource.ENVIRONMENT
        if self._prompts_when_omitted():
            return self._prompt(ctx, self._default_for_prompt(ctx)), ParameterSource.PROMPT
        return self._fallback(ctx)

    def _convert_shape(self, ctx, raw):
        if self.is_flag or self.count:
            return raw
        return super()._convert_shape(ctx, raw)


# spec: FP-04 — positional arguments
class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(self, param_decls=None, *, required=None, nargs=None, **attrs):
        decls = list(param_decls or ())
        if len(decls) != 1 or is_flag_name(decls[0]):
            raise DeclarationError("An argument takes a single destination name.")
        if nargs is None:
            nargs = 1
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise DeclarationError("nargs must be a positive integer or -1 for an argument.")
        default = attrs.get("default")
        if required is None:
            required = default is None and nargs != -1
        if attrs.get("deprecated") and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        self.help = attrs.pop("help", None)
        super().__init__(decls, required=required, nargs=nargs, **attrs)

    def _parse_decls(self, decls):
        self.opts = []
        self.secondary_opts = []
        self.name = decls[0] if decls else None

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def make_usage_piece(self):
        placeholder = self.metavar or self.name.upper()
        if self.nargs == -1:
            piece = f"{placeholder}..."
        elif self.nargs > 1 and not isinstance(self.type, Tuple):
            piece = " ".join([placeholder] * self.nargs)
        else:
            piece = placeholder
        if not self.required:
            piece = f"[{piece}]"
        return piece

    def get_help_record(self, ctx):
        if self.hidden or not self.help:
            return None
        placeholder = self.metavar or self.name.upper()
        parts = [self.help]
        if self.deprecated:
            parts.insert(0, "(Deprecated)")
        return placeholder, " ".join(parts)

    def _raw_from_occurrences(self, occurrences):
        if not occurrences:
            return None
        return occurrences[0]

    def consume_value(self, ctx, raw):
        if raw is not None:
            return raw, ParameterSource.COMMANDLINE
        text = self._env_value(ctx)
        if text is not None:
            return self._split_raw(text), ParameterSource.ENVIRONMENT
        return self._fallback(ctx)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _sort_key_params(params, order):
    inverted = {id(p): i for i, p in enumerate(order)}
    decl = {id(p): i for i, p in enumerate(params)}

    def key(param):
        return (not param.is_eager, inverted.get(id(param), float("inf")), decl[id(param)])

    return sorted(params, key=key), decl


# spec: FP-01, FP-02, FP-13 — commands, help, invocation and exit statuses
class Command:
    """A leaf command: parses its own options and arguments and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = inspect.cleandoc(callback.__doc__)
        if help:
            help = help.split("\f", 1)[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        if isinstance(deprecated, str):
            self.deprecated = True
            self.deprecation_note = deprecated
        else:
            self.deprecated = bool(deprecated)
            self.deprecation_note = ""
        arguments = [p for p in self.params if isinstance(p, Argument)]
        if sum(1 for a in arguments if a.nargs == -1) > 1:
            raise DeclarationError("Only one variadic argument can be declared on a command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters and help -----------------------------------------------------

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        declared = set()
        for param in self.params:
            declared.update(param.opts)
            declared.update(param.secondary_opts)
        remaining = [n for n in ctx.help_option_names if n not in declared]
        if not remaining:
            return None
        return Option(remaining, is_flag=True, is_eager=True, expose_value=False,
                      callback=_show_help, help="Show this message and exit.")

    def get_params(self, ctx):
        params = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            params.append(help_option)
        return params

    def collect_usage_pieces(self, ctx):
        pieces = []
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for param in self.params:
            if isinstance(param, Argument):
                pieces.append(param.make_usage_piece())
        return pieces

    def get_usage(self, ctx):
        formatter = HelpFormatter(width=ctx.terminal_width, max_width=ctx.max_content_width)
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        return formatter.getvalue().strip("\n")

    def get_help(self, ctx):
        formatter = HelpFormatter(width=ctx.terminal_width, max_width=ctx.max_content_width)
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n") + "\n"

    def get_short_help_str(self, limit=None):
        if self.short_help:
            return self.short_help
        return make_default_short_help(self.help or "", max_length=limit)

    def format_help(self, ctx, formatter):
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        self.format_description(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_description(self, ctx, formatter):
        text = self.help or ""
        if self.deprecated:
            text = f"(Deprecated) {text}".strip()
        if text:
            formatter.write_text(text)

    def format_arguments(self, ctx, formatter):
        rows = []
        for param in self.params:
            record = param.get_help_record(ctx) if isinstance(param, Argument) else None
            if record:
                rows.append(record)
        if rows:
            formatter.write_heading("Positional arguments")
            with formatter.indentation():
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                record = param.get_help_record(ctx)
                if record:
                    rows.append(record)
        if rows:
            formatter.write_heading("Options")
            with formatter.indentation():
                formatter.write_dl(rows)

    def format_commands(self, ctx, formatter):
        return None

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            formatter.write_text(self.epilog)

    # -- parsing ---------------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, list(args))
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsHelpError(ctx)
        rest, parser = self._parse_tokens(ctx, args)
        if rest and not ctx.resilient_parsing:
            if not ctx.allow_extra_args:
                ctx.fail("Got unexpected extra argument(s): "
                         + " ".join(repr(t) for t, _, _ in rest))
            for token, after_dashdash, raw in rest:
                if not after_dashdash and not raw and parser.is_opt_like(token):
                    ctx.fail(f"Got unexpected extra argument ({token}).")
        ctx.args = [token for token, _, _ in rest]
        return ctx.args

    def _parse_tokens(self, ctx, args):
        """Parse options and arguments, run parameter processing, return leftovers."""
        params = self.get_params(ctx)
        parser = OptionParser(ctx, params, interspersed=ctx.allow_interspersed_args,
                              ignore_unknown=ctx.ignore_unknown_options)
        opts, order, positionals = parser.parse(args)
        arguments = [p for p in params if isinstance(p, Argument)]
        rest = self._bind_arguments(arguments, positionals, opts, order)

        processing, decl = _sort_key_params(params, order)
        best = {}
        for param in processing:
            value, source = param.handle_parse_result(ctx, opts)
            key = (_RANK[source],
                   1 if (getattr(param, "_auto_default", False) and source is ParameterSource.DEFAULT) else 0,
                   -decl[id(param)])
            name = param.name
            if name in best and best[name] <= key:
                continue
            best[name] = key
            ctx._parameter_sources[name] = source
            if param.expose_value:
                ctx.params[name] = value
        return rest, parser

    def _bind_arguments(self, arguments, positionals, opts, order):
        tokens = list(positionals)
        pos = 0
        for index, arg in enumerate(arguments):
            later_required = sum(a.nargs for a in arguments[index + 1:] if a.required and a.nargs > 0)
            available = len(tokens) - pos
            if arg.nargs == -1:
                take = available - later_required
                if take <= 0:
                    continue
                raw = [t for t, _, _ in tokens[pos:pos + take]]
                pos += take
            else:
                if available < arg.nargs:
                    continue
                chunk = [t for t, _, _ in tokens[pos:pos + arg.nargs]]
                pos += arg.nargs
                raw = chunk[0] if arg.nargs == 1 else tuple(chunk)
            opts[arg] = [raw]
            order.append(arg)
        return tokens[pos:]

    # -- invocation --------------------------------------------------------------

    def invoke(self, ctx):
        with ctx:
            if self.deprecated:
                note = f" {self.deprecation_note}" if self.deprecation_note else ""
                echo(f"DeprecationWarning: The command '{self.name}' is deprecated.{note}", err=True)
            if self.callback is None:
                return None
            return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        """Run the command as a program (or in-process when standalone mode is off)."""
        if args is None:
            args = sys.argv[1:]
            if os.name == "nt" and windows_expand_args:
                args = _expand_windows_args(args)
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_prog_name() or self.name or "root"
        if complete_var is None:
            complete_var = f"_{prog_name.upper().replace('-', '_')}_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import shell_complete

            sys.exit(shell_complete(self, prog_name, complete_var, instruction))

        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        return None


def _detect_prog_name():
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return None


def _expand_windows_args(args):
    import glob

    out = []
    for arg in args:
        if any(c in arg for c in "*?["):
            matches = sorted(glob.glob(arg))
            out.extend(matches or [arg])
        else:
            out.append(arg)
    return out


# spec: FP-06, FP-10 — nesting, lazy lookup, chaining
class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.allow_interspersed_args = False
        self.allow_extra_args = True
        if commands:
            items = commands.values() if isinstance(commands, dict) else commands
            for cmd in items:
                self.add_command(cmd)

    # -- registration --------------------------------------------------------

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise DeclarationError("A command needs a name before it can be added to a group.")
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        return self._register_child(command_decorator, args, kwargs)

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        return self._register_child(group_decorator, args, kwargs)

    def _register_child(self, make, args, kwargs):
        """Build a child with ``make`` and register it on this group.

        Works both as ``@grp.command(...)`` and bare as ``@grp.command``.
        """
        def register(f, a, k):
            cmd = make(*a, **k)(f)
            self.add_command(cmd)
            return cmd

        if len(args) == 1 and not kwargs and callable(args[0]) and not isinstance(args[0], str):
            return register(args[0], (), {})

        def decorator(f):
            return register(f, args, kwargs)

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    # -- help --------------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = super().collect_usage_pieces(ctx)
        sub = self.subcommand_metavar or "COMMAND"
        if self.chain:
            pieces.append(f"{sub} [ARGS]... [{sub} [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(f"[{sub}] [ARGS]...")
        else:
            pieces.append(f"{sub} [ARGS]...")
        return pieces

    def format_commands(self, ctx, formatter):
        rows = []
        limit = max(formatter.width - 30, 20)
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            text = cmd.get_short_help_str(limit)
            if cmd.deprecated:
                text = f"(Deprecated) {text}".strip()
            rows.append((name, text))
        if rows:
            formatter.write_heading("Commands")
            with formatter.indentation():
                formatter.write_dl(rows)

    # -- parsing -------------------------------------------------------------

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsHelpError(ctx)
        rest, _ = self._parse_tokens(ctx, args)
        tokens = [token for token, _, _ in rest]
        if self.chain:
            ctx.protected_args = tokens
            ctx.args = []
        elif tokens:
            ctx.protected_args, ctx.args = tokens[:1], tokens[1:]
        else:
            ctx.protected_args, ctx.args = [], []
        return ctx.args

    def resolve_command(self, ctx, args):
        original = args[0]
        cmd_name = original
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(original)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    cmd_name = name
                    cmd = self.get_command(ctx, name)
                    break
        if cmd is None:
            if ctx.resilient_parsing:
                return None, None, args[1:]
            ctx.fail(f"No such command {original!r}.")
        return cmd_name, cmd, args[1:]

    def invoke(self, ctx):
        def process_result(value):
            if self._result_callback is not None:
                return ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*"
            super().invoke(ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx, allow_extra_args=True,
                                           allow_interspersed_args=False)
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            process_result(rv)
            return rv


# spec: FP-06 — union of several source groups
class CommandCollection(Group):
    """Presents the subcommands of several source groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
