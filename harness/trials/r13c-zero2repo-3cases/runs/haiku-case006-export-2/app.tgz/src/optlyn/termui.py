"""Interactive terminal helpers: prompts, progress, pager, editor, launch."""

import contextlib
import io
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from .context import get_current_context
from .exceptions import Abort, BadParameter
from .paramtypes import convert_type
from .utils import NonClosingStream, echo, is_interactive, strip_ansi

_YES = {"y", "yes"}
_NO = {"n", "no"}


def _read_line(prompt_text, hide_input=False, err=False):
    """Read one line from stdin, echoing as the terminal would.

    Visible input is echoed into the output stream unless stdin is a terminal
    or already echoes its reads. Hidden input is never echoed.
    """
    out = sys.stderr if err else sys.stdout
    if not _isatty(out):
        prompt_text = strip_ansi(prompt_text)
    out.write(prompt_text)
    out.flush()
    stdin = sys.stdin
    if stdin is None:
        raise EOFError
    if hide_input and hasattr(stdin, "readline_noecho"):
        line = stdin.readline_noecho()
    else:
        line = stdin.readline()
    if line == "":
        out.write("\n")
        out.flush()
        raise EOFError
    line = line.rstrip("\r\n")
    if hide_input:
        out.write("\n")
    elif not _isatty(stdin) and not getattr(stdin, "echo_reads", False):
        out.write(line + "\n")
    out.flush()
    return line


def _isatty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


# spec: FP-08 — prompts and confirmation
def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value until it converts (or input ends, which aborts)."""
    ptype = convert_type(type, default)
    if callable(default):
        default_value = default()
    else:
        default_value = default
    suffix = ""
    if default_value is not None and show_default:
        shown = ", ".join(str(v) for v in default_value) if isinstance(default_value, (list, tuple)) \
            else str(default_value)
        suffix = f" [{shown}]"
    prompt_text = f"{text}{suffix}{prompt_suffix}"
    ctx = get_current_context(silent=True)
    while True:
        try:
            value = _read_line(prompt_text, hide_input, err)
            if value == "" and default_value is not None:
                return default_value
            if confirmation_prompt:
                second = _read_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
                if second != value:
                    echo("Error: The two entered values do not match.", err=True)
                    continue
            if value_proc is not None:
                return value_proc(value)
            return ptype(value, None, ctx)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)
        except EOFError as e:
            raise Abort() from e


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Returns a bool; ends with abort when asked to."""
    if default is True:
        choices = "[Y/n]"
    elif default is False:
        choices = "[y/N]"
    else:
        choices = "[y/n]"
    prompt_text = f"{text} {choices}{prompt_suffix}"
    while True:
        try:
            answer = _read_line(prompt_text, False, err).strip().lower()
        except EOFError as e:
            raise Abort() from e
        if answer == "":
            value = bool(default)
            break
        if answer in _YES:
            value = True
            break
        if answer in _NO:
            value = False
            break
        echo("Error: invalid input", err=True)
    if abort and not value:
        raise Abort()
    return value


def _getchar_from_fd(fd):
    import termios
    import tty

    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        return os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# spec: FP-11 — single-character input
def getchar(echo=False):
    """Read one character from the terminal, not from piped standard input."""
    char = None
    if os.name == "posix":
        try:
            if _isatty(sys.stdin):
                char = _getchar_from_fd(sys.stdin.fileno())
            else:
                fd = os.open("/dev/tty", os.O_RDONLY)
                try:
                    char = _getchar_from_fd(fd)
                finally:
                    os.close(fd)
        except (OSError, ValueError, AttributeError, ImportError):
            char = None
    if char is None:
        char = sys.stdin.read(1)
    if char == "":
        raise EOFError
    if char == "\x03":
        raise KeyboardInterrupt
    if char == "\x04":
        raise EOFError
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info=None, err=False):
    """Wait for a key press when the session is interactive; otherwise do nothing."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


# spec: FP-11 — progress bar
class ProgressBar:
    """A progress indicator wrapping an iterable and/or a known length."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.options = options
        self.file = sys.stdout
        self._tty = (not hidden) and _isatty(self.file)
        self._printed_label = False

    def __enter__(self):
        if not self.hidden and not self._tty and self.label and not self._printed_label:
            echo(self.label, file=self.file)
            self._printed_label = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self._tty:
            self.render()
            echo("", file=self.file)
        return False

    def eta_seconds(self):
        if not self.length or self.pos == 0:
            return None
        elapsed = time.time() - self.start
        return max(elapsed / self.pos * (self.length - self.pos), 0)

    def render(self):
        if self.hidden or not self._tty:
            return
        parts = [self.label] if self.label else []
        if self.length:
            percent = min(self.pos / self.length, 1.0)
            width = 30
            filled = int(width * percent)
            parts.append("[" + "#" * filled + "-" * (width - filled) + "]")
            parts.append(f"{int(percent * 100):3d}%")
            eta = self.eta_seconds()
            if eta is not None:
                parts.append(f"eta {int(eta) // 60:02d}:{int(eta) % 60:02d}")
        else:
            parts.append(f"{self.pos} steps")
        line = " ".join(parts)
        self.file.write("\r" + line)
        self.file.flush()

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        self.render()

    def __iter__(self):
        if self.iterable is None:
            return
        self.render()
        for item in self.iterable:
            yield item
            self.update(1, item)


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a ``ProgressBar``."""
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    with bar:
        yield bar


def _pager_command():
    return os.environ.get("PAGER") or "less"


def _popen_pager():
    command = _pager_command()
    args = shlex.split(command, posix=(os.name == "posix"))
    if not args or shutil.which(args[0]) is None:
        return None
    return subprocess.Popen(args, stdin=subprocess.PIPE, text=False)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream: the pager when interactive, else stdout."""
    if not is_interactive():
        yield NonClosingStream(sys.stdout)
        return
    proc = _popen_pager()
    if proc is None:
        yield NonClosingStream(sys.stdout)
        return
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace", write_through=True)
    try:
        yield _PagerStream(stream, color)
    finally:
        try:
            stream.flush()
            stream.close()
        except (BrokenPipeError, OSError):
            pass
        proc.wait()


class _PagerStream:
    def __init__(self, stream, color):
        self._stream = stream
        self._color = color

    def write(self, text):
        if not self._color:
            text = strip_ansi(text)
        self._stream.write(text)
        self._stream.flush()
        return len(text)

    def flush(self):
        self._stream.flush()


# spec: FP-11 — pager output
def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager when interactive; otherwise to stdout."""
    if callable(text_or_generator):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    with get_pager_file(color=color) as stream:
        for chunk in chunks:
            stream.write(chunk)
            stream.flush()


# spec: FP-11 — editor launch
def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or on a file. Returns the saved text or ``None``."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        editor = "notepad" if os.name == "nt" else "vi"
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    args = shlex.split(editor, posix=(os.name == "posix"))
    if filename is not None:
        subprocess.call([*args, os.fspath(filename)], env=run_env)
        return None
    original = "" if text is None else str(text).replace("\r\n", "\n")
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(original)
        subprocess.call([*args, path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read().replace("\r\n", "\n")
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. Returns a status."""
    if sys.platform == "darwin":
        args = ["open", "-R", url] if locate else ["open", url]
    elif sys.platform == "win32":
        os.startfile(url)  # noqa: S606 - platform default opener
        return 0
    else:
        args = ["xdg-open", url]
    if shutil.which(args[0]) is None:
        return 127
    proc = subprocess.Popen(args)
    if wait:
        return proc.wait()
    return 0


# spec: FP-11 — screen clear
def clear():
    """Clear the terminal screen; does nothing when not on a terminal."""
    if not _isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()
