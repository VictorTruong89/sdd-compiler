"""Text wrapping and help-page layout."""

import contextlib
import shutil
import textwrap

_BACKSPACE = "\b"


# spec: FP-02, FP-11 — help rewrapping and text wrapping
def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Accepts any string.

    Single newlines are not kept as hard breaks. A paragraph whose first line is
    only a backspace character is not rewrapped; the backspace line is removed.
    """
    width = max(int(width), len(initial_indent) + 1, len(subsequent_indent) + 1, 2)
    text = str(text).replace("\r\n", "\n")
    if not preserve_paragraphs:
        paragraphs = [(text, False)]
    else:
        paragraphs = []
        for block in text.split("\n\n"):
            lines = block.split("\n")
            if lines and lines[0].strip() == _BACKSPACE:
                paragraphs.append(("\n".join(lines[1:]), True))
            else:
                paragraphs.append((block, False))

    out = []
    first = True
    for block, verbatim in paragraphs:
        if verbatim:
            lines = [line for line in block.split("\n")]
            rendered = [
                (initial_indent if first and i == 0 else subsequent_indent) + line
                for i, line in enumerate(lines)
            ]
            out.append("\n".join(rendered))
        else:
            wrapper = textwrap.TextWrapper(
                width=width,
                initial_indent=initial_indent if first else subsequent_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=True,
                break_on_hyphens=False,
                replace_whitespace=True,
                drop_whitespace=True,
            )
            words = " ".join(block.split())
            if not words:
                continue
            out.append(wrapper.fill(words))
        first = False
    return ("\n\n" if preserve_paragraphs else "\n").join(out)


def make_default_short_help(text, max_length=None):
    """First sentence of ``text``, ellipsized to ``max_length`` when given."""
    paragraph = text.strip().split("\n\n")[0]
    flat = " ".join(paragraph.split())
    parts = flat.split(". ", 1)
    sentence = parts[0] if len(parts) == 1 else parts[0] + "."
    if max_length is not None and len(sentence) > max_length:
        sentence = textwrap.shorten(sentence, width=max(max_length, 4), placeholder="...")
    return sentence


# spec: FP-02 — help page layout
class HelpFormatter:
    """Collects help-page sections with indentation and column layout."""

    def __init__(self, indent_increment=2, width=None, max_width=None):
        self.indent_increment = indent_increment
        if width is None:
            columns = shutil.get_terminal_size(fallback=(80, 24)).columns
            width = max(min(columns, max_width or 80) - 2, 50)
        self.width = width
        self.current_indent = 0
        self.buffer = []

    def write(self, text):
        self.buffer.append(text)

    @contextlib.contextmanager
    def indentation(self):
        self.current_indent += self.indent_increment
        try:
            yield
        finally:
            self.current_indent -= self.indent_increment

    def write_usage(self, prog, args="", prefix="Usage: "):
        usage_prefix = f"{prefix}{prog} "
        text_width = self.width
        if len(usage_prefix) + len(args) <= text_width:
            self.write(f"{usage_prefix}{args}\n".rstrip() + "\n")
        else:
            wrapped = textwrap.fill(
                args,
                width=max(text_width - len(usage_prefix), 20),
                initial_indent="",
                subsequent_indent=" " * len(usage_prefix),
                break_long_words=False,
                break_on_hyphens=False,
            )
            self.write(f"{usage_prefix}{wrapped}\n")
        self.write("\n")

    def write_text(self, text):
        indent = " " * self.current_indent
        self.write(wrap_text(text, width=self.width - self.current_indent,
                             initial_indent=indent, subsequent_indent=indent,
                             preserve_paragraphs=True))
        self.write("\n\n")

    def write_heading(self, heading):
        self.write(f"{' ' * (self.current_indent)}{heading}:\n")

    def write_dl(self, rows, col_max=30, col_spacing=2):
        """Write ``(first, second)`` rows as an aligned two-column block.

        The second column moves under the first when the first is too long for
        the column or when too little width would remain beside it.
        """
        rows = list(rows)
        if not rows:
            return
        indent = " " * self.current_indent
        first_width = min(max(len(first) for first, _ in rows), col_max)
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}\n")
                continue
            lead = self.current_indent + first_width + col_spacing
            text_width = self.width - lead
            if len(first) <= first_width and text_width >= 20:
                lines = wrap_text(second, width=text_width).split("\n")
                self.write(f"{indent}{first.ljust(first_width)}{' ' * col_spacing}{lines[0]}\n")
                for line in lines[1:]:
                    self.write(" " * lead + line + "\n")
            else:
                self.write(f"{indent}{first}\n")
                sub = " " * (self.current_indent + col_spacing)
                wrapped = wrap_text(second, width=max(self.width - len(sub), 10),
                                    initial_indent=sub, subsequent_indent=sub)
                self.write(wrapped + "\n")
        self.write("\n")

    def getvalue(self):
        return "".join(self.buffer)
