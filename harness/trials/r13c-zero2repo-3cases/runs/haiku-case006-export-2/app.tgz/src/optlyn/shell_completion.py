"""Shell completion: registration scripts and suggestion output.

Completion is selected by the environment variable ``_<PROG>_COMPLETE`` whose
value is ``<shell>_source`` (print the registration script) or
``<shell>_complete`` (print suggestions for the incomplete word).
"""

import os

from .core import Argument, Group, Option
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_PREFIX = "PATH:"


class CompletionItem:
    """A suggestion: a value with optional help, or a path request.

    ``type`` is ``"plain"`` for an ordinary value, ``"file"`` or ``"dir"`` for a
    request that the shell complete with paths.
    """

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _as_item(obj):
    if isinstance(obj, CompletionItem):
        return obj
    return CompletionItem(str(obj))


def _bash_script(prog, var):
    func = "_" + prog.replace("-", "_") + "_completion"
    return f"""{func}() {{
    local response line
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete "$1")
    COMPREPLY=()
    local IFS=$'\\n'
    for line in $response; do
        case "$line" in
            {PATH_PREFIX}dir:*) COMPREPLY+=( $(compgen -d -- "${{line#{PATH_PREFIX}dir:}}") ) ;;
            {PATH_PREFIX}file:*) COMPREPLY+=( $(compgen -f -- "${{line#{PATH_PREFIX}file:}}") ) ;;
            *) COMPREPLY+=( "$line" ) ;;
        esac
    done
    return 0
}}
complete -o default -F {func} {prog}
"""


def _zsh_script(prog, var):
    func = "_" + prog.replace("-", "_") + "_completion"
    return f"""#compdef {prog}
{func}() {{
    local -a lines
    local line value
    lines=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete "${{words[1]}}")}}")
    for line in "${{lines[@]}}"; do
        case "$line" in
            {PATH_PREFIX}dir:*) _path_files -/ ;;
            {PATH_PREFIX}file:*) _files ;;
            *) value="${{line%%$'\\t'*}}"; compadd -- "$value" ;;
        esac
    done
}}
compdef {func} {prog}
"""


def _fish_script(prog, var):
    func = "_" + prog.replace("-", "_") + "_completion"
    return f"""function {func}
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog})
    for completion in $response
        if string match -q '{PATH_PREFIX}dir:*' -- $completion
            __fish_complete_directories (commandline -ct)
        else if string match -q '{PATH_PREFIX}file:*' -- $completion
            __fish_complete_path (commandline -ct)
        else
            echo $completion
        end
    end
end
complete -c {prog} -f -a '({func})'
"""


def _powershell_script(prog, var):
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $Env:COMP_WORDS = $commandAst.ToString()
    $Env:COMP_CWORD = $wordToComplete
    $Env:{var} = 'powershell_complete'
    & '{prog}' | ForEach-Object {{
        $value = $_.Split("`t")[0]
        [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
    }}
    Remove-Item Env:\\{var}
}}
"""


_SCRIPTS = {
    "bash": _bash_script,
    "zsh": _zsh_script,
    "fish": _fish_script,
    "powershell": _powershell_script,
}


# spec: FP-12 — shell completion modes (Contract §8)
def shell_complete(cli, prog_name, complete_var, instruction):
    """Handle a completion instruction. Returns the process exit status."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    if action == "source":
        echo(_SCRIPTS[shell](prog_name, complete_var), nl=False)
        return 0
    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        before = words[1:-1] if words and words[-1] == incomplete else words[1:]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        before = words[1:cword]
        incomplete = words[cword] if cword < len(words) else ""
    items = get_completions(cli, prog_name, before, incomplete)
    lines = []
    for item in items:
        if item.type in ("file", "dir"):
            lines.append(f"{PATH_PREFIX}{item.type}:{incomplete}")
            continue
        text = item.value
        if shell in ("zsh", "fish") and item.help:
            text = f"{text}\t{' '.join(str(item.help).split())}"
        lines.append(text)
    if lines:
        echo("\n".join(lines))
    return 0


def _resolve_context(cli, prog_name, args):
    """Walk the command tree along the completed words."""
    ctx = cli.make_context(prog_name, args, resilient_parsing=True)
    while isinstance(ctx.command, Group) and not ctx.command.chain and ctx.protected_args:
        name, sub, rest = ctx.command.resolve_command(ctx, ctx.protected_args + ctx.args)
        if sub is None:
            break
        ctx = sub.make_context(name, rest, parent=ctx, resilient_parsing=True)
    return ctx


def get_completions(cli, prog_name, before, incomplete):
    """Return the ``CompletionItem`` list for ``incomplete`` after ``before``."""
    try:
        ctx = _resolve_context(cli, prog_name, before)
    except Exception:
        return []
    command = ctx.command
    params = command.get_params(ctx)
    items = []

    if incomplete[:1] in ("-", "+", "/") and incomplete:
        for param in params:
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=param.help))
        return items

    previous = before[-1] if before else None
    if previous is not None:
        for param in params:
            if isinstance(param, Option) and not param.is_flag and not param.count \
                    and previous in param.opts:
                return _param_items(ctx, param, incomplete)

    if isinstance(command, Group) and not ctx.protected_args:
        for name in command.list_commands(ctx):
            sub = command.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str(60)))

    arguments = [p for p in params if isinstance(p, Argument)]
    for arg in arguments:
        if arg.hidden:
            continue
        items.extend(_param_items(ctx, arg, incomplete))
        break
    return items


def _param_items(ctx, param, incomplete):
    if param._shell_complete is not None:
        result = param._shell_complete(ctx, param, incomplete) or []
    else:
        result = param.type.shell_complete(ctx, param, incomplete) or []
    return [_as_item(r) for r in result]
