"""Parameter types: built-in conversions, ranges, files, paths and custom types."""

import datetime as _dt
import enum
import os
import uuid

from .exceptions import BadParameter, DeclarationError, FileError
from .utils import LazyFile, open_file


# spec: FP-05 — parameter types and conversion (Contract §5)
class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement ``convert(value, param, ctx)``, which
    must accept ``param=None, ctx=None`` and must pass through values that are
    already of the converted type.
    """

    name = "text"
    is_composite = False
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)
        return value

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return None

    def split_envvar_value(self, rv):
        if self.envvar_list_splitter:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class FuncParamType(ParamType):
    """Adapter for a conversion function ``f(value) -> value``.

    The function refuses invalid input by raising ``ValueError`` (or
    ``BadParameter``).
    """

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid value.", param, ctx)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, str):
            return value
        if isinstance(value, (bytes, bytearray)):
            return bytes(value).decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            try:
                return int(value.strip())
            except ValueError:
                self.fail(f"{value!r} is not a valid integer.", param, ctx)
        self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return float(value)
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value.strip())
            except ValueError:
                self.fail(f"{value!r} is not a valid floating point value.", param, ctx)
        self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            if value in (0, 1):
                return bool(value)
        if isinstance(value, str):
            lowered = value.strip().lower()
            if lowered in _TRUE:
                return True
            if lowered in _FALSE:
                return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PYTHON_TYPES = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    uuid.UUID: UUID,
}


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.is_enum = isinstance(choices, type) and issubclass(choices, enum.Enum)
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _label(self, choice):
        return choice.name if self.is_enum else str(choice)

    def _normalize(self, text, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            text = ctx.token_normalize_func(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def get_metavar(self, param):
        return "[" + "|".join(self._label(c) for c in self.choices) + "]"

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice or value == choice:
                return choice
        text = value if isinstance(value, str) else str(value)
        wanted = self._normalize(text, ctx)
        for choice in self.choices:
            if self._normalize(self._label(choice), ctx) == wanted:
                return choice
        names = ", ".join(repr(self._label(c)) for c in self.choices)
        self.fail(f"{text!r} is not {'one of ' if len(self.choices) != 1 else ''}{names}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [
            CompletionItem(self._label(c))
            for c in self.choices
            if self._label(c).startswith(incomplete)
        ]


_DEFAULT_DATETIME_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


class _NumberRange(ParamType):
    base = None
    kind = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if clamp and (min_open or max_open):
            raise DeclarationError("Clamping is not supported for open bounds.")
        self.name = self.kind

    def _describe(self):
        if self.min is not None and self.max is not None:
            left = "(" if self.min_open else "["
            right = ")" if self.max_open else "]"
            return f"{left}{self.min}, {self.max}{right}"
        if self.min is not None:
            return f"{'>' if self.min_open else '>='} {self.min}"
        return f"{'<' if self.max_open else '<='} {self.max}"

    def convert(self, value, param, ctx):
        number = self.base.convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and (number < self.min or (self.min_open and number == self.min)):
                number = self.min + 1 if self.min_open and self.base is INT else self.min
            if self.max is not None and (number > self.max or (self.max_open and number == self.max)):
                number = self.max - 1 if self.max_open and self.base is INT else self.max
            return number
        below = self.min is not None and (number < self.min or (self.min_open and number == self.min))
        above = self.max is not None and (number > self.max or (self.max_open and number == self.max))
        if below or above:
            self.fail(f"{number} is not in the range {self._describe()}.", param, ctx)
        return number


class IntRange(_NumberRange):
    base = INT
    kind = "integer range"


class FloatRange(_NumberRange):
    base = FLOAT
    kind = "float range"


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_resolve_type(t) for t in types]
        self.name = "<" + " ".join(t.name.upper() for t in self.types) + ">"

    def get_metavar(self, param):
        return "<" + " ".join(t.name.upper() for t in self.types) + ">"

    def convert(self, value, param, ctx):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a tuple of {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class _PathLike(ParamType):
    envvar_list_splitter = os.pathsep


# spec: FP-09 — file parameter: lazy/atomic/dash rules
class File(_PathLike):
    """An open file object. ``-`` is stdin for read modes, stdout for write modes."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def _is_write(self):
        return any(c in self.mode for c in "wax")

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        filename = os.fspath(value)
        if filename == "-":
            handle = open_file(filename, self.mode, self.encoding, self.errors)
            if ctx is not None:
                ctx.call_on_close(handle.close)
            return handle
        lazy = self.lazy if self.lazy is not None else self._is_write()
        try:
            if lazy:
                handle = LazyFile(filename, self.mode, self.encoding, self.errors, self.atomic)
            else:
                handle = open_file(filename, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except FileError as e:
            self.fail(f"'{filename}': {e.detail}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(handle.close)
        return handle

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


# spec: FP-09 — path checks and dash handling
class Path(_PathLike):
    """A filesystem path (not an open file); see FP-09 for the checks."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _shape(self, value):
        if self.path_type is not None and self.path_type is not str:
            return self.path_type(value)
        return value

    def convert(self, value, param, ctx):
        if self.allow_dash and value == "-":
            return self._shape("-")
        text = os.fspath(value) if not isinstance(value, str) else value
        if self.resolve_path:
            text = os.path.realpath(os.path.abspath(text))
        if not os.path.exists(text):
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
            return self._shape(text)
        if not self.file_okay and os.path.isfile(text):
            self.fail(f"{text!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(text):
            self.fail(f"{text!r} is a directory.", param, ctx)
        if self.readable and not os.access(text, os.R_OK):
            self.fail(f"{text!r} is not readable.", param, ctx)
        if self.writable and not os.access(text, os.W_OK):
            self.fail(f"{text!r} is not writable.", param, ctx)
        if self.executable and not os.access(text, os.X_OK):
            self.fail(f"{text!r} is not executable.", param, ctx)
        return self._shape(text)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


def _resolve_type(value):
    """Turn a user-supplied ``type=`` into a ``ParamType`` (or ``None``)."""
    if value is None:
        return None
    if isinstance(value, ParamType):
        return value
    if isinstance(value, type):
        if issubclass(value, ParamType):
            return value()
        if value in _PYTHON_TYPES:
            return _PYTHON_TYPES[value]
    if callable(value):
        return FuncParamType(value)
    raise TypeError(f"Unsupported parameter type: {value!r}")


def infer_type(default):
    """Infer a built-in type from a default value (UUID is never inferred)."""
    if isinstance(default, (list, tuple)):
        return infer_type(default[0]) if default else STRING
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    return STRING


def convert_type(ty, default=None):
    """Resolve the effective ``ParamType`` for a declared ``type`` and default."""
    if ty is None:
        return infer_type(default)
    return _resolve_type(ty)
