"""Declaration decorators: commands, groups, options, arguments and helpers."""

import functools
import importlib.metadata
import sys

from .context import get_current_context
from .core import Argument, Command, Group, Option, _show_help
from .utils import echo


def _default_command_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _take_params(f):
    """Move declarations attached to ``f`` out of it, in declaration order."""
    params = list(getattr(f, "__optlyn_params__", []))
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    params.reverse()
    return params


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
        return
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


# spec: FP-01 — command declaration (Contract §3)
def command(name=None, cls=None, **attrs):
    """Turn a function into a ``Command``. Used as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    if cls is None:
        cls = Command

    def decorator(f):
        cmd_name = name or _default_command_name(f)
        params = _take_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a ``Group``. Used as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    if cls is None:
        cls = Group

    def decorator(f):
        cmd_name = name or _default_command_name(f)
        params = _take_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


# spec: FP-03 — option declaration (Contract §4)
def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function (or command). Returns a decorator."""
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a function (or command)."""
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        providers = importlib.metadata.packages_distributions().get(package_name, [])
    except Exception:  # pragma: no cover - defensive
        providers = []
    for dist in providers:
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"{package_name!r} is not an installed distribution or import name.")


# spec: FP-02 — eager version flags
def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """An eager flag that prints the version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        frame = sys._getframe(1)
        module = frame.f_globals.get("__name__", "")
        package_name = module.partition(".")[0] or None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ident = version
        if ident is None:
            ident = _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or ""
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ident}
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager flag whose printed identity is exactly ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def on_flag(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = on_flag

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


# spec: FP-08 — hidden, confirmed password option
def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default ``--password``)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


# spec: FP-08 — confirmation flag
def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when the answer is no."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            ctx.abort()
        return value

    kwargs["callback"] = callback

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


# spec: FP-07 — callback decorators (Contract §6)
def pass_context(f):
    """Pass the current ``Context`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator
