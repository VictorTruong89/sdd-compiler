"""Exception classes and exit-status classes for Optlyn.

Exit statuses (standalone mode):
  0  success, intentional help or version, clean stop
  1  abort, or another library-signalled error (``OptlynError``)
  2  usage error (``UsageError`` and subclasses)
"""

import sys


class OptlynError(Exception):
    """Base class for errors that Optlyn reports to the user.

    In standalone mode the error is shown on standard error and the process
    exits with ``exit_code``. Otherwise it propagates to the caller.
    """

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        echo(f"Error: {self.message}", file=file, err=True)


class DeclarationError(TypeError, ValueError):
    """An invalid combination of keywords, refused when declared."""


# spec: FP-13 — usage failures (exit 2)
class UsageError(OptlynError):
    """A usage failure: bad command line, exit status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message, ctx)
        self.show_help = False

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file, err=True)
            hint = self.ctx.help_hint()
            if hint:
                echo(hint, file=file, err=True)
            echo(file=file, err=True)
        if self.message:
            echo(f"Error: {self.message}", file=file, err=True)


class NoArgsHelpError(UsageError):
    """Help page shown because the invocation had no arguments.

    The help page is the whole report; the exit status is the usage class.
    """

    def __init__(self, ctx):
        super().__init__("", ctx)
        self.show_help = True

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)


class BadParameter(UsageError):
    """A value that cannot be accepted for a parameter."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file, err=True)
            hint = self.ctx.help_hint()
            if hint:
                echo(hint, file=file, err=True)
            echo(file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class MissingParameter(BadParameter):
    """A required parameter that was not supplied."""

    def format_message(self):
        hint = self.param.get_error_hint(self.ctx) if self.param is not None else None
        kind = "argument" if self.param is not None and self.param.param_type_name == "argument" else "option"
        if hint is None:
            return self.message
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option token that matches no declared option."""

    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option used incorrectly, for example without its required value."""


class BadArgumentUsage(UsageError):
    """An argument used incorrectly, for example extra tokens."""


# spec: FP-09, FP-13 — general file error (exit 1)
class FileError(OptlynError):
    """A file that could not be opened at first I/O (general error, status 1)."""

    def __init__(self, filename, detail=None):
        message = f"Could not open file '{filename}'"
        if detail:
            message += f": {detail}"
        super().__init__(message + ".")
        self.filename = filename
        self.detail = detail or "unknown error"

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        echo(f"Error: {self.message}", file=file, err=True)


class Abort(RuntimeError):
    """The user or the author aborted the invocation (status 1)."""


class Exit(RuntimeError):
    """An author clean stop with an explicit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
