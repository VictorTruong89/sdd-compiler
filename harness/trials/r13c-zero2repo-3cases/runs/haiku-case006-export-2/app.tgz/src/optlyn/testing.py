"""In-process runner for invoking a command with tokens and capturing results."""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile


class _Capture(io.BytesIO):
    """A byte sink that also records each write into a shared ordered list."""

    def __init__(self, mixed):
        super().__init__()
        self._mixed = mixed

    def write(self, data):
        data = bytes(data)
        self._mixed.append(data)
        return super().write(data)


class _Input(io.TextIOWrapper):
    """Standard input for the runner; can echo what it reads into the output."""

    echo_reads = False
    output_stream = None

    def readline(self, *args):
        line = super().readline(*args)
        if self.echo_reads and line and self.output_stream is not None:
            self.output_stream.write(line)
            self.output_stream.flush()
        return line

    def readline_noecho(self):
        return super().readline()


class Result:
    """The outcome of ``CliRunner.invoke``."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _decode(self, data):
        # Output that could not be encoded in the runner's charset was written as UTF-8.
        try:
            return data.decode(self.runner.charset)
        except UnicodeDecodeError:
            return data.decode("utf-8", "replace")

    @property
    def output(self):
        return self._decode(self.output_bytes)

    @property
    def stdout(self):
        return self._decode(self.stdout_bytes)

    @property
    def stderr(self):
        return self._decode(self.stderr_bytes)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code!r}>"


# spec: FP-14 — in-process runner (Contract §9)
class CliRunner:
    """Invokes a command in-process with argument tokens and captures the output."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the interpreter's standard streams and environment for the run.

        Yields a ``collect()`` callable that returns ``(stdout, stderr, output)``
        bytes once the run has finished.
        """
        data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        stdin = _Input(io.BytesIO(data), encoding=self.charset)
        stdin.echo_reads = self.echo_stdin

        env_overrides = dict(self.env)
        env_overrides.update(env or {})
        saved_env = {}
        for key, value in env_overrides.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        try:
            if self.capture == "fd":
                with self._fd_capture(stdin) as collect:
                    yield collect
            else:
                with self._sys_capture(stdin) as collect:
                    yield collect
        finally:
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    @contextlib.contextmanager
    def _sys_capture(self, stdin):
        mixed = []
        stdout_buf = _Capture(mixed)
        stderr_buf = _Capture(mixed)
        stdout = io.TextIOWrapper(stdout_buf, encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(stderr_buf, encoding=self.charset, write_through=True)
        stdin.output_stream = stdout

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr

        def collect():
            stdout.flush()
            stderr.flush()
            return stdout_buf.getvalue(), stderr_buf.getvalue(), b"".join(mixed)

        try:
            yield collect
        finally:
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = saved

    @contextlib.contextmanager
    def _fd_capture(self, stdin):
        """Capture OS-level writes to descriptors 1 and 2 as well as Python writes."""
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.flush()
            except (AttributeError, ValueError, OSError):
                pass
        saved_fds = (os.dup(1), os.dup(2))
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        stdout_raw = io.FileIO(1, "w", closefd=False)
        stderr_raw = io.FileIO(2, "w", closefd=False)
        stdout = io.TextIOWrapper(io.BufferedWriter(stdout_raw), encoding=self.charset,
                                  write_through=True)
        stderr = io.TextIOWrapper(io.BufferedWriter(stderr_raw), encoding=self.charset,
                                  write_through=True)
        stdin.output_stream = stdout

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr

        def collect():
            stdout.flush()
            stderr.flush()
            out_file.seek(0)
            err_file.seek(0)
            out_bytes, err_bytes = out_file.read(), err_file.read()
            return out_bytes, err_bytes, out_bytes + err_bytes

        try:
            yield collect
        finally:
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = saved
            os.dup2(saved_fds[0], 1)
            os.dup2(saved_fds[1], 2)
            os.close(saved_fds[0])
            os.close(saved_fds[1])
            out_file.close()
            err_file.close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Run ``cli`` with ``args`` (a list of tokens) and return a ``Result``."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        else:
            args = list(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        extra.setdefault("color", color)

        exception = None
        exit_code = 0
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as collect:
            try:
                return_value = cli.main(args=args, prog_name=prog_name, **extra)
            except SystemExit as e:
                exit_code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
                if exit_code != 0:
                    exception = e
                exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            stdout_bytes, stderr_bytes, output_bytes = collect()

        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run the block in a new empty working directory; yield its path."""
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
