"""Optlyn: a composable command line interface toolkit.

The package root exports the declaration API, the classes, the parameter types
and the terminal helpers. ``optlyn.testing`` holds the in-process runner and
``optlyn.formatting`` holds ``wrap_text``.
"""

from .context import Context, ParameterSource, get_current_context
from .core import Argument, Command, CommandCollection, Group, Option, Parameter
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    FileError,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .shell_completion import CompletionItem
from .termui import (
    clear,
    confirm,
    edit,
    echo_via_pager,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
)
from .utils import (
    echo,
    format_filename,
    get_app_dir,
    open_file,
    secho,
    style,
    unstyle,
)

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "ParamType",
    "BadParameter", "Abort", "Argument", "UsageError", "OptlynError", "Exit", "FileError",
    "MissingParameter", "NoSuchOption", "BadOptionUsage", "BadArgumentUsage",
    "DeclarationError", "CompletionItem", "ParameterSource",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
]
