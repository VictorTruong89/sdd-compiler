"""POSIX-style tokenizer for options and positional arguments.

The parser walks the token list once. Option tokens are matched against the
declared flag names and consumed (with their values); every other token is a
positional. Once a positional is seen on a command that does not interleave
arguments (groups and chained commands), the rest of the tokens are passed on
untouched, so a subcommand can parse its own options.
"""

from .exceptions import BadOptionUsage, NoSuchOption

# Marks an option that was given without a value (allowed only for options
# with an optional value: a flag value or a prompt).
NO_VALUE = object()


def is_flag_name(name):
    """A declared name that begins with a prefix character (not a dest name)."""
    return bool(name) and not (name[0].isalnum() or name[0] == "_")


# spec: FP-01, FP-03, FP-04 — option tokens, stacks, `--`, unknown tokens
class OptionParser:
    """Tokenizer for one command's options."""

    def __init__(self, ctx, params, interspersed=True, ignore_unknown=False):
        self.ctx = ctx
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.long = {}
        self.short = {}
        self.prefixes = {"-"}
        from .core import Option

        for param in params:
            if not isinstance(param, Option):
                continue
            for name in param.opts:
                self._register(name, param, primary=True)
            for name in param.secondary_opts:
                self._register(name, param, primary=False)

    def _register(self, name, param, primary):
        self.prefixes.add(name[0])
        if param.count:
            entry = (param, "count", None)
        elif param.is_flag:
            entry = (param, "flag", param.flag_value if primary else False)
        else:
            entry = (param, "value", None)
        if len(name) == 2:
            self.short[name] = entry
        else:
            self.long[name] = entry

    def is_opt_like(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def _is_long(self, token):
        return len(token) > 2 and token[0] in self.prefixes and token[1] in self.prefixes

    def parse(self, args):
        """Return ``(opts, order, positionals)``.

        ``opts`` maps each seen parameter to its list of occurrences, ``order``
        lists the parameters in the order they first appeared, and
        ``positionals`` is a list of ``(token, after_dashdash, raw)`` tuples.
        """
        self.opts = {}
        self.order = []
        positionals = []
        dashdash = False
        seen_positional = False
        i = 0
        while i < len(args):
            token = args[i]
            i += 1
            if not self.interspersed and seen_positional:
                positionals.append((token, dashdash, True))
                continue
            if dashdash:
                positionals.append((token, True, False))
                continue
            if token == "--":
                dashdash = True
                continue
            if not self.is_opt_like(token):
                positionals.append((token, False, False))
                seen_positional = True
                continue
            i = self._handle(token, args, i, positionals)
        return self.opts, self.order, positionals

    def _record(self, param, value):
        if param not in self.opts:
            self.opts[param] = []
            self.order.append(param)
        self.opts[param].append(value)

    def _unknown(self, token, name, positionals):
        if self.ignore_unknown:
            positionals.append((token, False, False))
            return True
        if self.ctx.resilient_parsing:
            return True
        raise NoSuchOption(name, ctx=self.ctx)

    def _lookup_long(self, name):
        if name in self.long:
            return name
        normalize = self.ctx.token_normalize_func
        if normalize is not None:
            wanted = normalize(name)
            for declared in self.long:
                if normalize(declared) == wanted:
                    return declared
        return None

    def _handle(self, token, args, i, positionals):
        name, eq, explicit = token.partition("=")
        declared = self._lookup_long(name)
        if declared is not None:
            name = declared
            param, kind, const = self.long[name]
            if kind == "value":
                value, i = self._take_value(param, args, i, explicit if eq else None)
                self._record(param, value)
            else:
                if eq:
                    raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
                self._record(param, 1 if kind == "count" else const)
            return i
        if self._is_long(token):
            self._unknown(token, name, positionals)
            return i
        prefix = token[0]
        chars = token[1:]
        for j, ch in enumerate(chars):
            short = prefix + ch
            if short not in self.short:
                if self._unknown(prefix + chars[j:], short, positionals):
                    return i
            param, kind, const = self.short[short]
            if kind == "value":
                rest = chars[j + 1:]
                value, i = self._take_value(param, args, i, rest if rest else None)
                self._record(param, value)
                return i
            self._record(param, 1 if kind == "count" else const)
        return i

    def _take_value(self, param, args, i, first):
        need = param.nargs
        values = []
        if first is not None:
            values.append(first)
        while len(values) < need and i < len(args):
            nxt = args[i]
            if param.flag_needs_value and not values and self.is_opt_like(nxt):
                break
            values.append(nxt)
            i += 1
        if len(values) < need:
            if param.flag_needs_value and not values:
                return NO_VALUE, i
            if self.ctx.resilient_parsing:
                return None, i
            name = (param.opts or param.secondary_opts or [param.name])[0]
            raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx=self.ctx)
        if need == 1:
            return values[0], i
        return tuple(values), i
