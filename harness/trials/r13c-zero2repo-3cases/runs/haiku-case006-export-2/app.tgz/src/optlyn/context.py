"""The per-invocation context: parsed values, parent linkage and settings."""

import contextlib
import enum
import threading

_local = threading.local()


# spec: FP-03, FP-07 — the five value sources
class ParameterSource(enum.Enum):
    """Where the value of a parameter came from, most explicit first."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true, in
    which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


_SETTING_KEYS = (
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args",
)
_INHERITED_KEYS = (
    "terminal_width", "max_content_width", "help_option_names",
    "token_normalize_func", "color", "show_default", "ignore_unknown_options",
)


# spec: FP-07 — invocation context (Contract §6)
class Context:
    """State of one command invocation.

    Built by the library. Settings come from ``main(**extra)``, the runner's
    ``invoke(**extra)``, or the command's ``context_settings``.
    """

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 auto_envvar_prefix=None, terminal_width=None, max_content_width=None,
                 help_option_names=None, token_normalize_func=None, color=None,
                 show_default=None, allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, resilient_parsing=False):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.resilient_parsing = resilient_parsing

        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj

        values = {
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
            "ignore_unknown_options": ignore_unknown_options,
        }
        for key in _INHERITED_KEYS:
            if values[key] is None and parent is not None:
                values[key] = getattr(parent, key)
        if values["help_option_names"] is None:
            values["help_option_names"] = ["--help"]
        if values["max_content_width"] is None:
            values["max_content_width"] = 80
        if values["ignore_unknown_options"] is None:
            values["ignore_unknown_options"] = False
        for key, value in values.items():
            setattr(self, key, value)

        if auto_envvar_prefix is None and parent is not None and info_name is not None \
                and parent.auto_envvar_prefix is not None:
            auto_envvar_prefix = "_".join(
                part.replace("-", "_") for part in (parent.auto_envvar_prefix, info_name)
            ).upper()
        self.auto_envvar_prefix = auto_envvar_prefix

        if default_map is None and parent is not None and info_name is not None \
                and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map

        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        self.allow_extra_args = allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_interspersed_args = allow_interspersed_args

        self.params = {}
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self._parameter_sources = {}
        self._depth = 0
        self._exit_stack = contextlib.ExitStack()

    # -- identity and linkage -------------------------------------------------

    @property
    def command_path(self):
        parts = []
        node = self
        while node is not None:
            if node.info_name is not None:
                parts.append(node.info_name)
            node = node.parent
        return " ".join(reversed(parts))

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def lookup_default(self, name):
        """Return ``(True, value)`` when the default map supplies ``name``."""
        if self.default_map is not None and name in self.default_map:
            return True, self.default_map[name]
        return False, None

    def get_parameter_source(self, name):
        """Return the source of a declared parameter's value, or ``None``."""
        return self._parameter_sources.get(name)

    # -- failures and stops ---------------------------------------------------

    def fail(self, message):
        from .exceptions import UsageError

        raise UsageError(message, self)

    def abort(self):
        from .exceptions import Abort

        raise Abort()

    def exit(self, code=0):
        from .exceptions import Exit

        raise Exit(code)

    # -- help -----------------------------------------------------------------

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def help_hint(self):
        if not self.command.add_help_option or not self.help_option_names:
            return None
        return f"Try '{self.command_path} {self.help_option_names[0]}' for help."

    # -- resources and scope --------------------------------------------------

    def call_on_close(self, func):
        self._exit_stack.callback(func)
        return func

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def close(self):
        stack, self._exit_stack = self._exit_stack, contextlib.ExitStack()
        stack.close()

    @contextlib.contextmanager
    def scope(self, cleanup=True):
        """Make this context current; close its resources when ``cleanup``."""
        stack = _stack()
        stack.append(self)
        try:
            yield self
        finally:
            stack.pop()
            if cleanup:
                self.close()

    def __enter__(self):
        self._depth += 1
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        self._depth -= 1
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        else:
            with contextlib.suppress(ValueError):
                stack.remove(self)
        if self._depth == 0:
            self.close()

    # -- invocation from callbacks --------------------------------------------

    def invoke(self, callback, *args, **kwargs):
        """Run a command (its callback) or a plain callable from this context."""
        from .core import Command

        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self)
            sub.params = dict(kwargs)
            with sub:
                if other.callback is None:
                    return None
                return other.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, **kwargs):
        """Invoke ``cmd`` with this context's parameter values plus ``kwargs``."""
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)
