"""Output, styling and file helpers shared by the rest of Optlyn."""

import io
import os
import re
import sys

from .context import get_current_context
from .exceptions import FileError

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[ -/]*[@-~]")

# spec: FP-11 — named colors; "reset" maps to the default color codes.
_FG_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_BG_COLORS = {
    "black": 40, "red": 41, "green": 42, "yellow": 43,
    "blue": 44, "magenta": 45, "cyan": 46, "white": 47,
    "bright_black": 100, "bright_red": 101, "bright_green": 102, "bright_yellow": 103,
    "bright_blue": 104, "bright_magenta": 105, "bright_cyan": 106, "bright_white": 107,
    "reset": 49,
}
_STYLE_CODES = (
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
)


def is_interactive():
    """Return True when stdin or stdout is a terminal (see the PRD)."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _isatty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def strip_ansi(text):
    """Remove ANSI escape sequences, leaving all other text."""
    return _ANSI_RE.sub("", text)


def _color_code(color, base, names, extended):
    if isinstance(color, str):
        if color not in names:
            raise TypeError(f"Unknown color {color!r}.")
        return str(names[color])
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color {color!r} is out of range 0-255.")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        for part in color:
            if not isinstance(part, int) or isinstance(part, bool) or not 0 <= part <= 255:
                raise TypeError(f"Invalid RGB color {color!r}.")
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


# spec: FP-11 — ANSI styling
def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ``TypeError``."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, 38, _FG_COLORS, True))
    if bg is not None:
        bits.append(_color_code(bg, 48, _BG_COLORS, True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on, off in _STYLE_CODES:
        value = switches[name]
        if value is not None:
            bits.append(str(on if value else off))
    if not bits:
        return str(text)
    prefix = "\033[" + ";".join(bits) + "m"
    return prefix + str(text) + ("\033[0m" if reset else "")


def _write(file, text):
    """Write text to a stream, falling back to UTF-8 bytes on encoding failure."""
    try:
        file.write(text)
    except UnicodeEncodeError:
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            raise
        file.flush()
        buffer.write(text.encode("utf-8"))
    file.flush()


# spec: FP-11 — echo, channels, ASCII fallback, color rules
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` (text or bytes) to stdout, stderr or ``file``.

    Styles are kept on a terminal or when color is forced on, and stripped
    otherwise. Without an explicit ``color``, the color flag of the current
    context applies.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        file.flush()
        if buffer is not None:
            buffer.write(data)
            buffer.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
            file.flush()
        return
    text = str(message) + ("\n" if nl else "")
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if color is None:
        keep = _isatty(file)
    else:
        keep = bool(color)
    if not keep:
        text = strip_ansi(text)
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """``echo`` with ``style`` applied to the message in one step."""
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def unstyle(text):
    """Remove ANSI styles from ``text``."""
    return strip_ansi(text)


# spec: FP-09 — printable file names
def format_filename(filename, shorten=False):
    """Return printable text for a path; always encodable as strict UTF-8."""
    if isinstance(filename, (bytes, bytearray)):
        filename = os.fsdecode(bytes(filename))
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    # Surrogate-escaped bytes become \udcxx escapes so distinct names stay distinct.
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


# spec: FP-11 — per-user configuration directory
def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + app_name.lower().replace(" ", "-"))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


class NonClosingStream:
    """Proxy for a standard stream: ``close`` flushes but never closes it."""

    def __init__(self, stream, owned=None):
        self._stream = stream
        self._owned = owned  # wrapper created over the stream's buffer

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    def close(self):
        self._stream.flush()
        if self._owned is not None:
            self._owned.detach()
            self._owned = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class LazyFile:
    """A file that is opened at its first I/O instead of at conversion."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._file = None

    def _open(self):
        if self._file is None:
            try:
                self._file = _open_real(self.name, self.mode, self.encoding, self.errors, self.atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror) from e
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __next__(self):
        return next(self._open())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._file is not None:
            self._file.close()
            self._file = None

    def close_intelligently(self):
        self.close()


class AtomicFile:
    """Writes to a sibling temporary file; the target is replaced on close."""

    def __init__(self, path, mode, encoding=None, errors="strict"):
        self._path = path
        directory = os.path.dirname(os.path.abspath(path))
        import tempfile

        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        self._file = open(self._tmp, mode, encoding=encoding, errors=errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __iter__(self):
        return iter(self._file)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp, self._path)


def _open_real(filename, mode, encoding, errors, atomic):
    binary = "b" in mode
    if binary:
        encoding = errors = None
    if atomic and any(c in mode for c in "wax"):
        return AtomicFile(filename, mode, encoding, errors or "strict")
    return open(filename, mode, encoding=encoding, errors=errors)


def _std_stream(name, mode, encoding, errors):
    stream = sys.stdin if "r" in mode else sys.stdout
    if "b" in mode:
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            return NonClosingStream(stream)
        return NonClosingStream(buffer)
    if encoding is None or getattr(stream, "encoding", None) == encoding:
        return NonClosingStream(stream)
    buffer = getattr(stream, "buffer", None)
    if buffer is None:
        return NonClosingStream(stream)
    stream.flush()
    wrapper = io.TextIOWrapper(buffer, encoding=encoding, errors=errors)
    return NonClosingStream(wrapper, owned=wrapper)


# spec: FP-09, FP-11 — `-` stdin/stdout rule shared with the file type
def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or the standard stream when ``filename`` is ``-``.

    ``-`` is stdin for read modes and stdout for write modes. Standard streams
    are never closed by the returned object.
    """
    if filename == "-":
        return _std_stream("-", mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as e:
        raise FileError(filename, e.strerror) from e


def get_text_stream(name, encoding=None, errors="strict"):
    """Return ``sys.stdin``, ``sys.stdout`` or ``sys.stderr`` by name."""
    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    return NonClosingStream(stream)
