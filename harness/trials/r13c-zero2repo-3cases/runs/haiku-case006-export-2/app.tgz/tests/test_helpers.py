"""Terminal helpers, styling, file utilities, completion and the in-process runner."""

import os
import sys

import pytest

import optlyn as o
from optlyn.formatting import wrap_text
from optlyn.shell_completion import CompletionItem, get_completions
from optlyn.testing import CliRunner


def test_style_and_unstyle_round_trip():
    styled = o.style("hi", fg="red", bold=True)
    assert styled.startswith("\x1b[31;1m") and styled.endswith("\x1b[0m")
    assert o.unstyle(styled) == "hi"


def test_style_accepts_names_ints_and_rgb_and_rejects_others():
    assert o.style("x", fg=200) != o.style("x", fg="red")
    assert o.style("x", bg=(1, 2, 3)) != o.style("x", bg=(1, 2, 4))
    with pytest.raises(TypeError):
        o.style("x", fg="not-a-color")
    with pytest.raises(TypeError):
        o.style("x", fg=(1, 2, 999))


def test_echo_strips_styles_unless_color_forced():
    @o.command()
    def cmd():
        o.echo(o.style("plain", fg="green"))

    runner = CliRunner()
    assert runner.invoke(cmd, []).output == "plain\n"
    assert "\x1b[" in runner.invoke(cmd, [], color=True).output


def test_echo_to_stderr_channel():
    @o.command()
    def cmd():
        o.echo("out")
        o.echo("err", err=True)

    res = CliRunner().invoke(cmd, [])
    assert res.stdout == "out\n"
    assert res.stderr == "err\n"
    assert res.output == "out\nerr\n"


def test_ascii_stream_falls_back_to_utf8_without_failing():
    @o.command()
    def cmd():
        o.echo("héllo ✓")

    res = CliRunner(charset="ascii").invoke(cmd, [])
    assert res.exit_code == 0
    assert res.output == "héllo ✓\n"


def test_wrap_text_accepts_any_string_and_keeps_backspace_paragraphs():
    assert wrap_text("a b " * 30, width=20).count("\n") >= 2
    kept = wrap_text("\b\nline one\nline two\n\nafter", width=12, preserve_paragraphs=True)
    assert "line one\nline two" in kept
    assert "\b" not in kept
    assert wrap_text("", width=10) == ""


def test_format_filename_is_strict_utf8_and_keeps_names_distinct():
    a = o.format_filename("bad\udcffname")
    b = o.format_filename("bad\udcfeName")
    a.encode("utf-8")
    assert a != b
    assert o.format_filename("/x/y.txt", shorten=True) == "y.txt"


def test_get_app_dir_per_platform(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    monkeypatch.setattr(sys, "platform", "linux")
    assert o.get_app_dir("My  App") == str(tmp_path / "xdg" / "my-app")
    assert o.get_app_dir("My App", force_posix=True) == str(tmp_path / ".my-app")
    monkeypatch.setattr(sys, "platform", "darwin")
    assert o.get_app_dir("My App") == os.path.join(str(tmp_path), "Library", "Application Support", "My App")


def test_progressbar_visits_every_item_without_terminal_and_prints_label_once():
    seen = []

    @o.command()
    def cmd():
        with o.progressbar(["a", "b", "c"], label="work") as bar:
            for item in bar:
                seen.append(item)
        with o.progressbar(length=2, label="quiet", hidden=True) as bar:
            bar.update(2)

    res = CliRunner().invoke(cmd, [])
    assert seen == ["a", "b", "c"]
    assert res.output.count("work") == 1
    assert "quiet" not in res.output


def test_pause_and_clear_do_nothing_when_not_interactive():
    @o.command()
    def cmd():
        o.pause()
        o.clear()
        o.echo("done")

    res = CliRunner().invoke(cmd, [], input="")
    assert res.output == "done\n"


def test_prompt_and_confirm_standalone():
    @o.command()
    def cmd():
        number = o.prompt("Number", type=o.INT, default=5)
        yes = o.confirm("Sure?", default=True)
        o.echo(f"{number} {yes}")

    res = CliRunner().invoke(cmd, [], input="abc\n\n\n")
    assert res.exit_code == 0
    assert res.output.endswith("5 True\n")
    assert "not a valid integer" in res.output


def test_open_file_dash_is_not_closed(tmp_path):
    @o.command()
    def cmd():
        with o.open_file("-", "w") as stream:
            stream.write("kept")
        o.echo("after")

    res = CliRunner().invoke(cmd, [])
    assert res.output == "kept" + "after\n"


def test_isolated_filesystem_removes_directory_unless_parent_given(tmp_path):
    runner = CliRunner()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == path
        created = path
    assert not os.path.exists(created)
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        marker = os.path.join(path, "m.txt")
        open(marker, "w").close()
    assert os.path.exists(marker)


def test_environment_override_is_restored_after_invoke():
    @o.command()
    def cmd():
        o.echo(os.environ.get("OPTLYN_TEST_VAR", "unset"))

    assert CliRunner().invoke(cmd, [], env={"OPTLYN_TEST_VAR": "set"}).output == "set\n"
    assert "OPTLYN_TEST_VAR" not in os.environ


def test_echo_stdin_echoes_reads_into_output():
    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        o.echo(f"name={name}")

    res = CliRunner(echo_stdin=True).invoke(cmd, [], input="hello\n")
    assert res.output.count("hello") == 2
    assert res.output.endswith("name=hello\n")


def test_fd_capture_separates_stdout_and_stderr_including_os_writes():
    @o.command()
    def cmd():
        o.echo("to-out")
        os.write(1, b"os-level\n")
        o.echo("to-err", err=True)

    res = CliRunner(capture="fd").invoke(cmd, [])
    assert res.stdout == "to-out\nos-level\n"
    assert res.stderr == "to-err\n"


def test_completion_suggests_choices_options_and_path_requests():
    @o.command()
    @o.option("--ch", type=o.Choice(["alpha", "beta"]))
    @o.option("--pathy", type=o.Path(exists=True))
    @o.option("--dir", type=o.Path(file_okay=False))
    def comp():
        pass

    assert [i.value for i in get_completions(comp, "comp", ["--ch"], "a")] == ["alpha"]
    assert "--help" in [i.value for i in get_completions(comp, "comp", [], "--")]
    assert [(i.value, i.type) for i in get_completions(comp, "comp", ["--pathy"], "x")] == [("x", "file")]
    assert [(i.value, i.type) for i in get_completions(comp, "comp", ["--dir"], "x")] == [("x", "dir")]
    assert get_completions(comp, "comp", [], "zzz") == []


def test_completion_run_emits_suggestions_with_help_for_zsh():
    items = [CompletionItem("alpha", help="first"), CompletionItem("beta")]

    @o.command()
    @o.option("--x", shell_complete=lambda ctx, param, incomplete: items)
    def sc():
        pass

    runner = CliRunner()
    env = {"_SC_COMPLETE": "zsh_complete", "COMP_WORDS": "sc --x ", "COMP_CWORD": "2"}
    res = runner.invoke(sc, [], env=env, prog_name="sc")
    assert res.output == "alpha\tfirst\nbeta\n"
    assert res.exit_code == 0


def test_completion_source_prints_script_without_running_command():
    ran = []

    @o.command()
    def sc():
        ran.append(True)

    res = CliRunner().invoke(sc, [], env={"_SC_COMPLETE": "bash_source"}, prog_name="sc")
    assert res.exit_code == 0
    assert "complete -o default" in res.output
    assert ran == []


def test_unknown_completion_instruction_prints_nothing_and_fails():
    @o.command()
    def sc():
        pass

    res = CliRunner().invoke(sc, [], env={"_SC_COMPLETE": "tcsh_source"}, prog_name="sc")
    assert res.exit_code == 1
    assert res.output == ""


def test_lazy_write_failure_is_general_error_and_names_path():
    @o.command()
    @o.argument("out", type=o.File("w"))
    def cmd(out):
        o.echo("before")
        out.write("x")
        o.echo("never")

    res = CliRunner().invoke(cmd, [os.path.join("no-such-dir", "f.txt")])
    assert res.exit_code == 1
    assert "no-such-dir" in res.output
    assert "never" not in res.output


def test_help_wraps_to_explicit_terminal_width():
    @o.command(context_settings={"terminal_width": 30})
    @o.option("--long-option-name", help="This is a rather long help text that should wrap.")
    def narrow():
        """A description that is long enough to need wrapping."""

    res = CliRunner().invoke(narrow, ["--help"])
    assert max(len(line) for line in res.output.splitlines()) <= 30


def test_help_option_names_from_context():
    @o.command(context_settings={"help_option_names": ["-h", "--assist"]})
    def hx():
        pass

    assert CliRunner().invoke(hx, ["-h"]).exit_code == 0
    assert CliRunner().invoke(hx, ["--help"]).exit_code == 2


def test_version_option_is_eager_and_prints_identity():
    @o.command()
    @o.option("--must", required=True)
    @o.version_option("1.2.3", prog_name="tool")
    def ver(must):
        pass

    res = CliRunner().invoke(ver, ["--version"])
    assert res.exit_code == 0
    assert res.output == "tool, version 1.2.3\n"


def test_custom_version_option_prints_callback_exactly():
    @o.command()
    @o.custom_version_option(lambda ctx: "custom 9")
    def ver2():
        pass

    assert CliRunner().invoke(ver2, ["--version"]).output == "custom 9\n"


def test_password_option_prompts_hidden_and_confirmed():
    @o.command()
    @o.password_option()
    def pw(password):
        o.echo(f"pw={password}")

    res = CliRunner().invoke(pw, [], input="a\na\n")
    assert res.output.endswith("pw=a\n")
    mismatch = CliRunner().invoke(pw, [], input="a\nb\nc\nc\n")
    assert "do not match" in mismatch.output
    assert mismatch.output.endswith("pw=c\n")


def test_result_callback_and_result_when_standalone_off():
    @o.group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @o.argument("n", type=o.INT)
    def inc(n):
        return n + 1

    assert pipe.main(["inc", "1"], standalone_mode=False) == [2]
