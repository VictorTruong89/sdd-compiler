"""Option/argument value sources, defaults, types and prompts."""

import optlyn as o
from optlyn.testing import CliRunner


def test_default_map_fills_option_and_reports_source():
    @o.command()
    @o.option("--num", type=int, default=3)
    def dm(num):
        src = o.get_current_context().get_parameter_source("num")
        o.echo(f"{num} {src.name}")

    assert CliRunner().invoke(dm, [], default_map={"num": 9}).output == "9 DEFAULT_MAP\n"
    assert CliRunner().invoke(dm, ["--num", "1"], default_map={"num": 9}).output == "1 COMMANDLINE\n"


def test_default_map_nests_by_subcommand_name():
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--v", default="d")
    def sub(v):
        o.echo(v)

    res = CliRunner().invoke(cli, ["sub"], default_map={"sub": {"v": "from-map"}})
    assert res.output == "from-map\n"


def test_envvar_fills_option_and_is_converted():
    @o.command()
    @o.option("--n", envvar="MY_N", type=int)
    def cmd(n):
        o.echo(repr(n))

    assert CliRunner().invoke(cmd, [], env={"MY_N": "12"}).output == "12\n"


def test_auto_envvar_prefix_builds_names_from_path():
    @o.group()
    def cli():
        pass

    @cli.command("sub-one")
    @o.option("--level")
    def sub(level):
        o.echo(str(level))

    res = CliRunner().invoke(cli, ["sub-one"], auto_envvar_prefix="APP",
                             env={"APP_SUB_ONE_LEVEL": "deep"})
    assert res.output == "deep\n"


def test_bool_flag_env_values():
    @o.command()
    @o.option("--fast", is_flag=True, envvar="FAST_ON")
    def cmd(fast):
        o.echo(str(fast))

    assert CliRunner().invoke(cmd, [], env={"FAST_ON": " Yes "}).output == "True\n"
    assert CliRunner().invoke(cmd, [], env={"FAST_ON": "off"}).output == "False\n"
    bad = CliRunner().invoke(cmd, [], env={"FAST_ON": "maybe"})
    assert bad.exit_code == 2
    assert "--fast" in bad.output


def test_feature_switch_pair_on_and_off():
    @o.command()
    @o.option("--shout/--no-shout", default=False)
    def cmd(shout):
        o.echo(str(shout))

    assert CliRunner().invoke(cmd, ["--shout"]).output == "True\n"
    assert CliRunner().invoke(cmd, ["--no-shout"]).output == "False\n"


def test_counting_option_and_stacked_short_flags():
    @o.command()
    @o.option("-v", "--verbose", count=True)
    @o.option("-q", is_flag=True)
    def cmd(verbose, q):
        o.echo(f"{verbose} {q}")

    assert CliRunner().invoke(cmd, ["-vvq"]).output == "2 True\n"


def test_multiple_option_collects_in_order_and_empty_is_tuple():
    @o.command()
    @o.option("--tag", multiple=True)
    def cmd(tag):
        o.echo(repr(tag))

    assert CliRunner().invoke(cmd, ["--tag", "a", "--tag", "b"]).output == "('a', 'b')\n"
    assert CliRunner().invoke(cmd, []).output == "()\n"


def test_bare_string_default_on_repeatable_is_usage_error():
    @o.command()
    @o.option("--tag", multiple=True, default="x")
    def cmd(tag):
        pass

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 2
    assert "--tag" in res.output
    assert "iterable" in res.output


def test_multi_value_option_arity_and_tuple_type():
    @o.command()
    @o.option("--pair", nargs=2, type=int)
    @o.option("--xy", type=o.Tuple([str, int]))
    def cmd(pair, xy):
        o.echo(f"{pair} {xy}")

    res = CliRunner().invoke(cmd, ["--pair", "1", "2", "--xy", "a", "3"])
    assert res.output == "(1, 2) ('a', 3)\n"


def test_choice_delivers_original_member_case_insensitively():
    import enum

    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @o.command()
    @o.option("--c", type=o.Choice(Color, case_sensitive=False))
    def cmd(c):
        o.echo(repr(c))

    assert CliRunner().invoke(cmd, ["--c", "red"]).output == "<Color.RED: 1>\n"
    bad = CliRunner().invoke(cmd, ["--c", "green"])
    assert bad.exit_code == 2


def test_int_range_clamp_and_open_bounds():
    @o.command()
    @o.option("--x", type=o.IntRange(0, 10, clamp=True))
    @o.option("--y", type=o.IntRange(0, 10, min_open=True))
    def cmd(x, y):
        o.echo(f"{x} {y}")

    res = CliRunner().invoke(cmd, ["--x", "99", "--y", "5"])
    assert res.output == "10 5\n"
    assert CliRunner().invoke(cmd, ["--y", "0"]).exit_code == 2


def test_float_range_refuses_clamp_with_open_bound():
    import pytest

    with pytest.raises(TypeError):
        o.FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_datetime_default_formats_and_override_replaces():
    dt = o.DateTime()
    assert dt.convert("2020-01-02", None, None).year == 2020
    assert dt.convert("2020-01-02 03:04:05", None, None).hour == 3
    custom = o.DateTime(formats=["%d/%m/%Y"])
    assert custom.convert("02/01/2020", None, None).month == 1


def test_uuid_and_custom_type_passthrough():
    class Upper(o.ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str) and value.isupper():
                return value
            if isinstance(value, str):
                return value.upper()
            self.fail("bad", param, ctx)

    @o.command()
    @o.option("--u", type=Upper())
    @o.option("--id", type=o.UUID)
    def cmd(u, id):
        o.echo(f"{u} {id}")

    res = CliRunner().invoke(cmd, ["--u", "abc", "--id", "12345678-1234-5678-1234-567812345678"])
    assert res.output == "ABC 12345678-1234-5678-1234-567812345678\n"


def test_argument_optional_default_and_required_variadic():
    @o.command()
    @o.argument("first")
    @o.argument("opt", required=False, default="zz")
    @o.argument("more", nargs=-1, required=True)
    def cmd(first, opt, more):
        o.echo(f"{first} {opt} {more}")

    assert CliRunner().invoke(cmd, ["1", "2", "3", "4"]).output == "1 2 ('3', '4')\n"
    assert CliRunner().invoke(cmd, ["1", "2"]).exit_code == 2


def test_extra_args_allowed_and_ignore_unknown_options():
    @o.command(context_settings={"ignore_unknown_options": True})
    @o.argument("rest", nargs=-1)
    def cmd(rest):
        o.echo(repr(rest))

    assert CliRunner().invoke(cmd, ["--zzz", "a", "-q"]).output == "('--zzz', 'a', '-q')\n"


def test_prompt_when_omitted_and_default_on_empty_answer():
    @o.command()
    @o.option("--name", prompt="Your name", default="anon")
    def cmd(name):
        o.echo(name)

    assert CliRunner().invoke(cmd, [], input="\n").output == "Your name [anon]: \nanon\n"
    assert CliRunner().invoke(cmd, [], input="zed\n").output.endswith("zed\n")


def test_hidden_password_is_not_echoed():
    @o.command()
    @o.option("--pw", prompt=True, hide_input=True, confirmation_prompt=True)
    def cmd(pw):
        o.echo(f"got {pw}")

    res = CliRunner().invoke(cmd, [], input="secret\nsecret\n")
    assert res.exit_code == 0
    assert "secret" not in res.output.replace("got secret", "")
    assert res.output.endswith("got secret\n")


def test_confirmation_option_aborts_on_no_and_skips_on_flag():
    @o.command()
    @o.confirmation_option(prompt="Sure?")
    def danger():
        o.echo("did it")

    no = CliRunner().invoke(danger, [], input="n\n")
    assert no.exit_code == 1
    assert "did it" not in no.output
    assert CliRunner().invoke(danger, ["--yes"]).output == "did it\n"


def test_eof_during_prompt_is_abort():
    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        pass

    res = CliRunner().invoke(cmd, [], input="")
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_file_write_is_lazy_and_read_fails_at_conversion():
    import os

    @o.command()
    @o.argument("src", type=o.File("r"))
    @o.argument("dst", type=o.File("w"))
    def copy(src, dst):
        dst.write(src.read().upper())

    runner = CliRunner()
    with runner.isolated_filesystem():
        with open("in.txt", "w") as handle:
            handle.write("hello")
        res = runner.invoke(copy, ["in.txt", "out.txt"])
        assert res.exit_code == 0
        assert open("out.txt").read() == "HELLO"
        missing = runner.invoke(copy, ["missing.txt", "x.txt"])
        assert missing.exit_code == 2
        assert "missing.txt" in missing.output
        assert not os.path.exists("x.txt")


def test_dash_file_reads_stdin_without_closing_it():
    @o.command()
    @o.argument("src", type=o.File("r"))
    def read_it(src):
        o.echo(src.read())

    res = CliRunner().invoke(read_it, ["-"], input="piped")
    assert res.output == "piped\n"


def test_path_checks():
    runner = CliRunner()
    with runner.isolated_filesystem():
        import os

        os.makedirs("sub")

        @o.command()
        @o.argument("p", type=o.Path(exists=True, dir_okay=False))
        def pth(p):
            o.echo(p)

        assert runner.invoke(pth, ["sub"]).exit_code == 2
        assert runner.invoke(pth, ["nope"]).exit_code == 2


def test_required_prompt_without_prompt_required_still_prompts_when_omitted():
    @o.command()
    @o.option("--code", prompt=True, prompt_required=False, required=True)
    def cmd(code):
        o.echo(code)

    assert CliRunner().invoke(cmd, [], input="42\n").output.endswith("42\n")


def test_prompt_not_required_is_skipped_when_omitted_but_used_on_bare_flag():
    @o.command()
    @o.option("--age", prompt=True, prompt_required=False, type=int, default=3)
    def cmd(age):
        o.echo(str(age))

    assert CliRunner().invoke(cmd, [], input="99\n").output == "3\n"
    assert CliRunner().invoke(cmd, ["--age"], input="99\n").output.endswith("99\n")


def test_alternative_prefix_on_off_pair_and_stacking():
    @o.command()
    @o.option("/on/off", default=False)
    @o.option("+p", is_flag=True)
    def cmd(on, p):
        o.echo(f"{on} {p}")

    assert CliRunner().invoke(cmd, ["/on", "+p"]).output == "True True\n"
    assert CliRunner().invoke(cmd, ["/off"]).output == "False False\n"
