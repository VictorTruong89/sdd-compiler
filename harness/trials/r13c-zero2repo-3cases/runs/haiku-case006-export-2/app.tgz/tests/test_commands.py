"""Behavior of commands, groups, options and arguments through the runner."""

import optlyn as o
from optlyn.testing import CliRunner


def make_hello():
    @o.command()
    @o.option("--count", "-c", default=1, type=int, help="How many.")
    @o.option("--name", required=True)
    @o.argument("files", nargs=-1)
    def hello_command(count, name, files):
        """Say hello."""
        for _ in range(count):
            o.echo(f"hello {name} {files}")

    return hello_command


def test_command_name_derived_from_function():
    @o.command()
    def fetch_all_cmd():
        pass

    assert fetch_all_cmd.name == "fetch-all"


def test_explicit_command_name_replaces_derived_name():
    @o.command("go")
    def run_it():
        pass

    assert run_it.name == "go"


def test_options_and_variadic_argument_are_delivered():
    res = CliRunner().invoke(make_hello(), ["--name", "bob", "-c", "2", "a", "b"])
    assert res.exit_code == 0
    assert res.output == "hello bob ('a', 'b')\nhello bob ('a', 'b')\n"


def test_missing_required_option_is_usage_error_naming_option():
    res = CliRunner().invoke(make_hello(), [])
    assert res.exit_code == 2
    assert "--name" in res.output


def test_unknown_option_is_usage_error():
    res = CliRunner().invoke(make_hello(), ["--name", "x", "--bogus"])
    assert res.exit_code == 2
    assert "No such option: --bogus" in res.output


def test_help_prints_page_and_skips_callback():
    ran = []

    @o.command()
    def cmd():
        ran.append(True)

    res = CliRunner().invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert "Usage:" in res.stdout
    assert ran == []


def test_no_args_is_help_on_leaf_is_usage_error():
    @o.command(no_args_is_help=True)
    def cmd():
        """Does things."""

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 2
    assert "Does things." in res.stderr


def test_group_callback_runs_before_child_and_child_help_is_child_help():
    @o.group()
    def cli():
        o.echo("group ran")

    cli.add_command(make_hello(), "hello")
    res = CliRunner().invoke(cli, ["hello", "--help"])
    assert res.exit_code == 0
    assert res.stdout.startswith("group ran\n")
    assert "Usage: cli hello" in res.stdout


def test_group_without_subcommand_is_usage_error_with_help():
    @o.group()
    def cli():
        """Top."""

    @cli.command()
    def sub():
        pass

    res = CliRunner().invoke(cli, [])
    assert res.exit_code == 2
    assert "Commands:" in res.stderr


def test_group_no_subcommand_with_no_args_help_off_reports_missing_command():
    @o.group(no_args_is_help=False)
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    res = CliRunner().invoke(cli, [])
    assert res.exit_code == 2
    assert "Missing command." in res.stderr
    assert "Commands:" not in res.stderr


def test_unknown_subcommand_is_usage_error():
    @o.group()
    def cli():
        pass

    res = CliRunner().invoke(cli, ["nope"])
    assert res.exit_code == 2
    assert "No such command 'nope'." in res.output


def test_invoke_without_command_runs_callback_with_no_subcommand():
    @o.group(invoke_without_command=True)
    @o.pass_context
    def cli(ctx):
        o.echo(f"sub={ctx.invoked_subcommand}")

    res = CliRunner().invoke(cli, [])
    assert res.exit_code == 0
    assert res.output == "sub=None\n"


def test_nested_groups_dispatch_from_outside_in():
    @o.group()
    def outer():
        o.echo("outer")

    @outer.group()
    def middle():
        o.echo("middle")

    @middle.command()
    def leaf():
        o.echo("leaf")

    res = CliRunner().invoke(outer, ["middle", "leaf"])
    assert res.output == "outer\nmiddle\nleaf\n"


def test_skipping_middle_group_is_unknown_command():
    @o.group()
    def outer():
        pass

    @outer.group()
    def middle():
        pass

    @middle.command()
    def leaf():
        pass

    res = CliRunner().invoke(outer, ["leaf"])
    assert res.exit_code == 2
    assert "No such command 'leaf'." in res.output


def test_chaining_group_collects_results_in_order():
    @o.group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    @o.pass_context
    def done(ctx, results, **params):
        o.echo(f"results={results}")

    @pipe.command()
    @o.argument("n", type=o.INT)
    def inc(n):
        return n + 1

    @pipe.command()
    @o.argument("n", type=o.INT)
    def dbl(n):
        return n * 2

    res = CliRunner().invoke(pipe, ["inc", "1", "dbl", "5"])
    assert res.output == "results=[2, 10]\n"


def test_chaining_group_refuses_nested_group():
    import pytest

    @o.group(chain=True)
    def pipe():
        pass

    @o.group()
    def inner():
        pass

    with pytest.raises(TypeError):
        pipe.add_command(inner)


def test_forward_and_invoke_from_callback():
    @o.command()
    @o.option("--a", default=1, type=int)
    def target(a):
        o.echo(f"target a={a}")

    @o.command()
    @o.option("--a", default=5, type=int)
    def caller(a):
        ctx = o.get_current_context()
        ctx.forward(target)
        ctx.invoke(target, a=77)

    res = CliRunner().invoke(caller, [])
    assert res.output == "target a=5\ntarget a=77\n"


def test_deprecated_command_still_runs_with_warning():
    @o.command(deprecated="use new-thing")
    def old():
        o.echo("old ran")

    res = CliRunner().invoke(old, [])
    assert res.exit_code == 0
    assert "DeprecationWarning" in res.stderr
    assert "use new-thing" in res.stderr
    assert "old ran" in res.stdout


def test_hidden_option_is_omitted_from_help_but_accepted():
    @o.command()
    @o.option("--secret", hidden=True)
    @o.option("--shown", help="visible one")
    def hid(secret, shown):
        o.echo(f"secret={secret}")

    help_res = CliRunner().invoke(hid, ["--help"])
    assert "--secret" not in help_res.output
    assert "--shown" in help_res.output
    res = CliRunner().invoke(hid, ["--secret", "s"])
    assert res.output == "secret=s\n"


def test_form_feed_truncates_help_text():
    @o.command(help="visible part\fhidden tail")
    def trunc():
        pass

    res = CliRunner().invoke(trunc, ["--help"])
    assert "visible part" in res.output
    assert "hidden" not in res.output
    assert "\f" not in res.output


def test_standalone_off_propagates_usage_error_and_returns_value():
    import pytest

    @o.command()
    @o.option("--n", type=int)
    def cmd(n):
        return n * 10

    assert cmd.main(["--n", "4"], standalone_mode=False) == 40
    with pytest.raises(o.UsageError):
        cmd.main(["--n", "x"], standalone_mode=False)


def test_abort_in_standalone_writes_aborted_and_exits_one():
    @o.command()
    def cmd():
        o.abort = None
        raise o.Abort()

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_clean_stop_status_from_callback():
    @o.command()
    @o.pass_context
    def cmd(ctx):
        ctx.exit(3)
        o.echo("never")

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 3
    assert "never" not in res.output


def test_callback_refusal_is_usage_error_not_running_command():
    def refuse(ctx, param, value):
        raise o.BadParameter("nope", ctx=ctx, param=param)

    ran = []

    @o.command()
    @o.option("--x", callback=refuse)
    def cmd(x):
        ran.append(x)

    res = CliRunner().invoke(cmd, ["--x", "1"])
    assert res.exit_code == 2
    assert "nope" in res.output
    assert ran == []
