---
name: optlyn-build
description: Status and non-obvious decisions for the Optlyn CLI library built from /app/spec into /app/src/optlyn
metadata:
  node_type: memory
  type: project
  originSessionId: d9bf622b-0bf3-427d-bc84-5423f31987f4
  modified: 2026-10-16T03:36:07.926Z
---

Optlyn (a Click-like CLI composition library) is implemented under `/app/src/optlyn` from the spec in `/app/spec` (packs in `spec/packs/`, FP text in pack 19). Tests live in `/app/tests` (78 passing, run with `PYTHONPATH=src python3 -m pytest tests`).

**Why:** the spec is Click-shaped, so behavior follows Click semantics where the spec is silent. Main decisions:
- Module is `paramtypes.py`, not `types.py`: a file named `types.py` shadows the stdlib when Python runs from inside the package directory.
- `# spec:` markers are per feature point (FP-xx) or contract section, not per checklist node id (1012 nodes). Per-node traceability was not done.
- Exit codes: usage 2, abort/general error 1, help/version/clean stop 0 (or the author's code).
- Feature-switch tie-break: source rank, then explicit-default over auto-default, then last declared.
- Completion scripts are only checked with `bash -n`; zsh/fish/powershell scripts are not executed here.
- Not verifiable here: interactive TTY paths (progress bar redraw, pager, getchar on a real terminal, launch), and Windows argument expansion.

**How to apply:** if asked to extend or verify, start from the FP-xx markers in the source; do not re-derive the design. The hidden tests run with `PYTHONPATH=src` from `/app`, so the package must stay importable from `src`.
