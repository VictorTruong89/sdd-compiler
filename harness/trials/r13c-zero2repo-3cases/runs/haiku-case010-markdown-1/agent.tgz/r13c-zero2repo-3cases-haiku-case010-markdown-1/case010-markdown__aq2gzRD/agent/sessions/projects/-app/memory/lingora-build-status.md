---
name: lingora-build-status
description: Status of the LINGORA library built in /app from spec/; stdlib-only constraint and known gaps
metadata:
  node_type: memory
  type: project
  originSessionId: 3d6a97e5-18c0-4cee-bbff-5bea1fdaec3e
  modified: 2026-10-15T04:07:25.579Z
---

LINGORA (`/app/lingora`, Python 3.13 in this env) was built from `spec/` with the standard library only.
click, NLTK and snowballstemmer are not installed and the judge does not install anything, so do not add third-party imports.

Known gaps (outside the feature points or not implemented):
- Snowball: only `english` (Porter2) and `porter` (original) are implemented. Other listed languages construct but `stem` raises NotImplementedError.
- Lancaster rule table was reconstructed from memory, not copied from the published table; some rules may differ.
- `ne_chunk` checks its resources, then raises NotImplementedError. WordNetLemmatizer checks WordNet, then raises on lemmatize.
- ARLSTem/ARLSTem2 are light stemmers, not the published algorithms.

Verification approach: synthetic Punkt and perceptron model dirs under /tmp (not in /app), with `data.path` pointed at them. Keep test fixtures out of /app.

Why: the spec is the source of truth and hidden tests run against /app with no install step.
How to apply: when extending, keep resource lookups checking `data.path` on every call (caches keyed by resolved path only).
