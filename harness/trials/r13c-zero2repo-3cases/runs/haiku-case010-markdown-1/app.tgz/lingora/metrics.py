"""Evaluation metrics: pure functions of their arguments (PRD FP-07)."""


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    if len(reference) != len(test):
        raise ValueError(
            "accuracy needs lists of equal length, got %d and %d" % (len(reference), len(test))
        )
    if not reference:
        return 0.0
    matches = sum(1 for x, y in zip(reference, test) if x == y)
    return matches / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    if not transpositions:
        return _levenshtein(s1, s2, substitution_cost)
    return _damerau_levenshtein(s1, s2, substitution_cost)


def _levenshtein(s1, s2, substitution_cost):
    previous = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        current = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            current[j] = min(
                previous[j] + 1,
                current[j - 1] + 1,
                previous[j - 1] + cost,
            )
        previous = current
    return previous[len(s2)]


def _damerau_levenshtein(s1, s2, substitution_cost):
    """Unrestricted Damerau-Levenshtein (Lowrance and Wagner, 1975)."""
    len1, len2 = len(s1), len(s2)
    maxdist = len1 + len2
    last_row = {}
    # d[(i, j)] with i, j in -1..len; stored offset by one so index -1 is valid.
    d = [[0] * (len2 + 2) for _ in range(len1 + 2)]
    d[0][0] = maxdist
    for i in range(len1 + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len2 + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len1 + 1):
        last_match_col = 0
        for j in range(1, len2 + 1):
            k = last_row.get(s2[j - 1], 0)
            l = last_match_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        last_row[s1[i - 1]] = i
    return d[len1 + 1][len2 + 1]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over the size of the union."""
    union = label1 | label2
    if not union:
        return 0.0
    return (len(union) - len(label1 & label2)) / len(union)


def _require_sets(*values):
    for value in values:
        if not isinstance(value, (set, frozenset)):
            raise TypeError("expected a set, got %s" % type(value).__name__)


def precision(reference, test):
    """|reference & test| / |test|; None when test is empty."""
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; None when reference is empty."""
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either set is empty."""
    _require_sets(reference, test)
    if not reference or not test:
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
