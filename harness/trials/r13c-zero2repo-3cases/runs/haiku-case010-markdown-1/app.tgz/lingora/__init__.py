"""LINGORA: a Python natural-language processing library.

Submodules are imported on demand: ``lingora.tokenize``, ``lingora.stem``,
``lingora.tag``, ``lingora.chunk``, ``lingora.grammar``, ``lingora.parse``,
``lingora.tree``, ``lingora.classify``, ``lingora.metrics``,
``lingora.translate`` and ``lingora.cli``.
"""

from lingora import data

__version__ = "0.1.0"

__all__ = ["data", "__version__"]
