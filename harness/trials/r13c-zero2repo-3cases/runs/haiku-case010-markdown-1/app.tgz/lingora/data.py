"""Locate packaged resources (Punkt models, taggers, stopwords, WordNet...).

``path`` is a mutable list of directories. Callers may replace its contents
in place; every lookup reads the list at call time.
"""

import os

_default_dirs = []
_env = os.environ.get("LINGORA_DATA", "")
if _env:
    _default_dirs.extend(p for p in _env.split(os.pathsep) if p)
_default_dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))

path = list(_default_dirs)


def find(resource):
    """Return the full path of ``resource`` in the first listed directory, or None."""
    for directory in path:
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    return None


def require(resource):
    """Return the full path of ``resource``; raise LookupError when it is not visible."""
    found = find(resource)
    if found is None:
        raise LookupError(
            "packaged resource %r not found in data.path %r" % (resource, list(path))
        )
    return found


def read_lines(resource):
    """Read a UTF-8 text resource; each line without its terminator is one entry."""
    with open(require(resource), encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]
