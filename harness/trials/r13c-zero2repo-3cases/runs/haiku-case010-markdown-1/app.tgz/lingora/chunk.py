"""Regular-expression chunking with chunk grammars (PRD FP-04)."""

import re

from lingora import data
from lingora.tree import Tree

DEFAULT_ROOT_LABEL = "S"


def _tag_pattern_to_regex(pattern):
    """Translate a tag pattern such as ``<DT>?<JJ.*>*<NN>+`` into a regex over encoded tags.

    Each tag is encoded as ``<tag>`` in the haystack, so an element matches one whole tag.
    """
    text = re.sub(r"\s+", "", pattern)
    parts = []
    position = 0
    element = re.compile(r"<((?:\\.|[^\\<>])*)>(\?|\*|\+|\{\d*,?\d*\})?")
    while position < len(text):
        match = element.match(text, position)
        if match is None:
            raise ValueError("cannot read tag pattern %r at position %d" % (pattern, position))
        body, quantifier = match.group(1), match.group(2) or ""
        if quantifier.startswith("{") and quantifier in ("{}", "{,}"):
            raise ValueError("empty repeat count in tag pattern %r" % pattern)
        parts.append("(?:<(?:%s)>)%s" % (_convert_element_body(body), quantifier))
        position = match.end()
    if not parts:
        raise ValueError("empty tag pattern")
    return re.compile("".join(parts))


def _convert_element_body(body):
    out = []
    index = 0
    while index < len(body):
        ch = body[index]
        if ch == "\\" and index + 1 < len(body):
            out.append(body[index:index + 2])
            index += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        index += 1
    return "".join(out)


def _parse_rule(text):
    text = text.strip()
    if len(text) >= 2 and text[0] == "{" and text[-1] == "}":
        return "chunk", _tag_pattern_to_regex(text[1:-1])
    if len(text) >= 2 and text[0] == "}" and text[-1] == "{":
        return "chink", _tag_pattern_to_regex(text[1:-1])
    raise ValueError("chunk rule must be {pattern} or }pattern{: %r" % text)


class RegexpParser:
    """Chunk parser built from a chunk grammar.

    ``grammar`` is grammar text, or a list of ``(label, rule)`` pairs where
    ``rule`` is ``{pattern}`` or ``}pattern{``. Consecutive pairs with the same
    label form one clause.
    """

    def __init__(self, grammar, root_label=DEFAULT_ROOT_LABEL):
        self._root_label = root_label
        if isinstance(grammar, str):
            self._clauses = _parse_grammar_text(grammar)
        elif isinstance(grammar, list):
            self._clauses = _clauses_from_pairs(grammar)
        else:
            raise TypeError("grammar must be a str or a list of (label, rule) pairs")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        root = []
        for item in tagged:
            if not (isinstance(item, tuple) and len(item) == 2):
                raise TypeError("each tagged token must be a (token, tag) pair")
            root.append(item)
        for label, rules in self._clauses:
            root = _apply_clause(label, rules, root)
        return Tree(self._root_label, root)


def _parse_grammar_text(text):
    pairs = []
    label = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if not raw[0].isspace():
            if ":" not in raw:
                raise ValueError("clause line must be '<LABEL>: <pattern>': %r" % raw)
            label, rest = raw.split(":", 1)
            label = label.strip()
            if not label:
                raise ValueError("clause has no label: %r" % raw)
            if rest.strip():
                pairs.append((label, _parse_rule(rest)))
            continue
        if label is None:
            raise ValueError("pattern line before any clause: %r" % raw)
        pairs.append((label, _parse_rule(raw)))
    if not pairs:
        raise ValueError("chunk grammar has no clauses")
    return _clauses_from_pairs(pairs)


def _clauses_from_pairs(pairs):
    clauses = []
    for label, rule in pairs:
        if isinstance(rule, str):
            rule = _parse_rule(rule)
        if not (isinstance(rule, tuple) and len(rule) == 2 and rule[0] in ("chunk", "chink")):
            raise TypeError("rule must be a (kind, regex) pair or rule text")
        if clauses and clauses[-1][0] == label:
            clauses[-1][1].append(rule)
        else:
            clauses.append((label, [rule]))
    return clauses


def _is_chunk(unit):
    return isinstance(unit, Tree)


def _match_runs(units, pattern, eligible):
    """Find non-overlapping matches of ``pattern`` inside runs of eligible units.

    Returns a list of (start, end) index pairs into ``units``, end exclusive.
    """
    matches = []
    index = 0
    while index < len(units):
        if not eligible(units[index]):
            index += 1
            continue
        run_end = index
        while run_end < len(units) and eligible(units[run_end]):
            run_end += 1
        run = units[index:run_end]
        haystack = []
        starts = {}
        ends = {}
        position = 0
        for offset, unit in enumerate(run):
            tag = unit.label() if _is_chunk(unit) else unit[1]
            encoded = "<%s>" % tag
            starts[position] = offset
            position += len(encoded)
            ends[position] = offset + 1
            haystack.append(encoded)
        text = "".join(haystack)
        for match in pattern.finditer(text):
            if match.end() == match.start():
                continue
            if match.start() not in starts or match.end() not in ends:
                continue
            matches.append((index + starts[match.start()], index + ends[match.end()]))
        index = run_end
    return matches


def _apply_clause(label, rules, root):
    new_chunks = {}  # id -> chunk, for chunks built by this clause (kept alive by the dict)
    for kind, pattern in rules:
        if kind == "chunk":
            root = _apply_chunk_rule(label, pattern, root, new_chunks)
        else:
            root = _apply_chink_rule(pattern, root, new_chunks)
    return root


def _apply_chunk_rule(label, pattern, root, new_chunks):
    eligible = lambda unit: not (_is_chunk(unit) and id(unit) in new_chunks)
    matches = _match_runs(root, pattern, eligible)
    if not matches:
        return root
    result = []
    position = 0
    for start, end in matches:
        result.extend(root[position:start])
        chunk = Tree(label, root[start:end])
        new_chunks[id(chunk)] = chunk
        result.append(chunk)
        position = end
    result.extend(root[position:])
    return result


def _apply_chink_rule(pattern, root, new_chunks):
    result = []
    changed = False
    for unit in root:
        if not (_is_chunk(unit) and id(unit) in new_chunks):
            result.append(unit)
            continue
        children = list(unit)
        matches = _match_runs(children, pattern, lambda c: not _is_chunk(c))
        if not matches:
            result.append(unit)
            continue
        changed = True
        position = 0
        for start, end in matches:
            if start > position:
                piece = Tree(unit.label(), children[position:start])
                new_chunks[id(piece)] = piece
                result.append(piece)
            result.extend(children[start:end])
            position = end
        if position < len(children):
            piece = Tree(unit.label(), children[position:])
            new_chunks[id(piece)] = piece
            result.append(piece)
    if not changed:
        return root
    return result


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Requires the packaged NE model and English wordlist."""
    data.require("chunkers/maxent_ne_chunker_tab/english_ace_multiclass/")
    data.require("corpora/words")
    if not isinstance(tagged_tokens, (list, tuple)) or isinstance(tagged_tokens, str):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    raise NotImplementedError("the named-entity chunker model is not implemented in this build")
