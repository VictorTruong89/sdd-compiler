"""Constituent trees: a label plus an ordered list of children (leaves or trees)."""

import re


class Tree:
    """A labelled ordered tree. Children are leaves (any non-Tree value) or Trees."""

    def __init__(self, label, children):
        if not isinstance(children, list):
            raise TypeError("Tree children must be a list, got %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    # -- structure -------------------------------------------------------
    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    # -- comparison ------------------------------------------------------
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    # -- text forms ------------------------------------------------------
    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    def pformat(self, width=70):
        """Pretty-print: one line when it fits in ``width``, else one child per line."""
        return "\n".join(self._pformat_lines(0, width))

    def _one_line(self):
        parts = [str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._one_line())
            else:
                parts.append(str(child))
        return "(" + " ".join(parts) + ")"

    def _pformat_lines(self, indent, width):
        flat = self._one_line()
        if indent + len(flat) <= width or not self._children:
            return [" " * indent + flat]
        lines = [" " * indent + "(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.extend(child._pformat_lines(indent + 2, width))
            else:
                lines.append(" " * (indent + 2) + str(child))
        lines[-1] += ")"
        return lines

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text such as ``(S (NP I) (VP sleep))``."""
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        if not tokens:
            raise ValueError("empty bracketed tree text")
        stack = []
        root = None
        pos = 0
        while pos < len(tokens):
            tok = tokens[pos]
            pos += 1
            if tok == "(":
                if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                    raise ValueError("missing label after '(' in %r" % s)
                node = cls(tokens[pos], [])
                pos += 1
                if stack:
                    stack[-1]._children.append(node)
                elif root is None:
                    root = node
                else:
                    raise ValueError("more than one top-level node in %r" % s)
                stack.append(node)
            elif tok == ")":
                if not stack:
                    raise ValueError("unbalanced ')' in %r" % s)
                stack.pop()
            else:
                if not stack:
                    raise ValueError("leaf outside any node in %r" % s)
                stack[-1]._children.append(tok)
        if stack or root is None:
            raise ValueError("unbalanced brackets in %r" % s)
        return root
