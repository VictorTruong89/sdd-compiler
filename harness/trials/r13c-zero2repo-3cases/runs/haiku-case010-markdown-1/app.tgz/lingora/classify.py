"""Text classifiers trained on in-memory labeled featuresets (PRD FP-06)."""

import math
from collections import Counter, defaultdict


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes)) or not hasattr(labeled_featuresets, "__iter__"):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    pairs = []
    for item in labeled_featuresets:
        featureset, label = item
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict, got %s" % type(featureset).__name__)
        pairs.append((dict(featureset), label))
    if not pairs:
        raise ValueError("cannot train on an empty list")
    return pairs


class NaiveBayesClassifier:
    """Naive Bayes with expected-likelihood (add-one-half) smoothing."""

    def __init__(self, labels, label_counts, feature_counts, feature_values):
        self._labels = list(labels)
        self._label_counts = dict(label_counts)
        self._feature_counts = feature_counts  # (label, fname) -> Counter of values
        self._feature_values = feature_values  # fname -> set of observed values
        self._total = sum(self._label_counts.values())

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_training(labeled_featuresets)
        labels = []
        label_counts = Counter()
        feature_counts = defaultdict(Counter)
        feature_values = defaultdict(set)
        for featureset, label in pairs:
            if label not in label_counts:
                labels.append(label)
            label_counts[label] += 1
            for fname, fval in featureset.items():
                feature_counts[(label, fname)][fval] += 1
                feature_values[fname].add(fval)
        return cls(labels, label_counts, dict(feature_counts), dict(feature_values))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        n_labels = len(self._labels)
        scores = {}
        for label in self._labels:
            prior = (self._label_counts[label] + 0.5) / (self._total + 0.5 * n_labels)
            log_score = math.log(prior)
            for fname, fval in featureset.items():
                if fname not in self._feature_values:
                    continue
                counts = self._feature_counts.get((label, fname), Counter())
                seen_total = sum(counts.values())
                bins = len(self._feature_values[fname])
                likelihood = (counts.get(fval, 0) + 0.5) / (seen_total + 0.5 * bins)
                log_score += math.log(likelihood)
            scores[label] = log_score
        return scores

    def classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        return max(self._labels, key=lambda label: scores[label])

    def prob_classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        top = max(scores.values())
        weights = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(weights.values())
        return ProbDist({label: weight / total for label, weight in weights.items()})


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Split:
    def __init__(self, feature, children, majority):
        self.feature = feature
        self.children = children
        self.majority = majority


def _entropy(counts, total):
    result = 0.0
    for count in counts.values():
        if count:
            p = count / total
            result -= p * math.log2(p)
    return result


def _majority(examples):
    counts = Counter(label for _, label in examples)
    return counts.most_common(1)[0][0]


def _build_tree(examples, features):
    label_counts = Counter(label for _, label in examples)
    if len(label_counts) == 1:
        return _Leaf(next(iter(label_counts)))
    majority = _majority(examples)
    if not features:
        return _Leaf(majority)

    total = len(examples)
    base = _entropy(label_counts, total)
    best_feature = None
    best_gain = 1e-12
    best_groups = None
    for feature in features:
        groups = defaultdict(list)
        for featureset, label in examples:
            groups[featureset.get(feature)].append((featureset, label))
        if len(groups) < 2:
            continue
        remainder = 0.0
        for members in groups.values():
            member_counts = Counter(label for _, label in members)
            remainder += len(members) / total * _entropy(member_counts, len(members))
        gain = base - remainder
        if gain > best_gain:
            best_feature, best_gain, best_groups = feature, gain, groups

    if best_feature is None:
        return _Leaf(majority)
    remaining = [f for f in features if f != best_feature]
    children = {
        value: _build_tree(members, remaining) for value, members in best_groups.items()
    }
    return _Split(best_feature, children, majority)


class DecisionTreeClassifier:
    """ID3-style decision tree: each node tests the feature with the highest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_training(labeled_featuresets)
        features = sorted({f for featureset, _ in pairs for f in featureset}, key=str)
        return cls(_build_tree(pairs, features))

    def classify(self, featureset):
        node = self._root
        featureset = dict(featureset)
        while isinstance(node, _Split):
            child = node.children.get(featureset.get(node.feature))
            if child is None:
                return node.majority
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    if not gold:
        return 0.0
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
