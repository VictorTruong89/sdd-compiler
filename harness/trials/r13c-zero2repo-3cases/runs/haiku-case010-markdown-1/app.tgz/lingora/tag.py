"""Part-of-speech taggers (PRD FP-03)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data


class _SequentialTagger:
    """Assigns tags token by token; tokens left untagged go to the backoff tagger."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _own_tags(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a string")
        tokens = list(tokens)
        if not tokens:
            return []
        tags = self._own_tags(tokens)
        if self._backoff is not None and any(t is None for t in tags):
            fallback = self._backoff.tag(tokens)
            tags = [t if t is not None else fb[1] for t, fb in zip(tags, fallback)]
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _own_tags(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    """Each word receives the tag it most often had in training; unseen words get no tag."""

    def __init__(self, train=None, model=None, backoff=None):
        super().__init__(backoff)
        if model is not None:
            self._model = dict(model)
        else:
            counts = defaultdict(Counter)
            for sentence in train or []:
                for word, tag in sentence:
                    if tag is not None:
                        counts[word][tag] += 1
            self._model = {word: c.most_common(1)[0][0] for word, c in counts.items()}

    def _own_tags(self, tokens):
        return [self._model.get(token) for token in tokens]


class NgramTagger(_SequentialTagger):
    """Tags a word from its own form and the tags already assigned to the previous n-1 tokens."""

    def __init__(self, n, train=None, backoff=None):
        super().__init__(backoff)
        self._n = n
        counts = defaultdict(Counter)
        for sentence in train or []:
            history = ()
            for word, tag in sentence:
                if tag is not None:
                    counts[(history, word)][tag] += 1
                history = (history + (tag,))[-(n - 1):] if n > 1 else ()
        self._model = {key: c.most_common(1)[0][0] for key, c in counts.items()}

    def _own_tags(self, tokens):
        tags = []
        history = ()
        for token in tokens:
            tag = self._model.get((history, token))
            tags.append(tag)
            if self._n > 1:
                history = (history + (tag,))[-(self._n - 1):]
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train=train, backoff=backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train=train, backoff=backoff)


class AffixTagger(_SequentialTagger):
    """Tags a word by its prefix or suffix of ``affix_length`` characters."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        counts = defaultdict(Counter)
        for sentence in train or []:
            for word, tag in sentence:
                affix = self._affix(word)
                if tag is not None and affix is not None:
                    counts[affix][tag] += 1
        self._model = {affix: c.most_common(1)[0][0] for affix, c in counts.items()}

    def _affix(self, word):
        size = abs(self._affix_length)
        if len(word) < size + self._min_stem_length:
            return None
        return word[-size:] if self._affix_length < 0 else word[:size]

    def _own_tags(self, tokens):
        tags = []
        for token in tokens:
            affix = self._affix(token)
            tags.append(self._model.get(affix) if affix is not None else None)
        return tags


class RegexpTagger(_SequentialTagger):
    """The first rule whose pattern matches at a token's first character gives its tag."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _own_tags(self, tokens):
        tags = []
        for token in tokens:
            tag = None
            for pattern, candidate in self._rules:
                if pattern.match(token):
                    tag = candidate
                    break
            tags.append(tag)
        return tags


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (textblob-aptagger / NLTK feature templates)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_LANGS = ("eng", "rus")
_model_cache = {}
_universal_cache = {}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


class _PerceptronModel:
    def __init__(self, directory, lang):
        prefix = "averaged_perceptron_tagger_%s" % lang
        self.weights = _read_json(os.path.join(directory, prefix + ".weights.json"))
        self.tagdict = _read_json(os.path.join(directory, prefix + ".tagdict.json"))
        self.classes = _read_json(os.path.join(directory, prefix + ".classes.json"))

    def predict(self, features):
        scores = defaultdict(float)
        for feature, value in features.items():
            if value == 0 or feature not in self.weights:
                continue
            for label, weight in self.weights[feature].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        output = []
        for index, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = _features(index + len(_START), word, context, prev, prev2)
                tag = self.predict(features)
            output.append((word, tag))
            prev2, prev = prev, tag
        return output


def _read_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _load_model(lang):
    # Visibility is checked on every call so that changing data.path takes effect.
    directory = os.path.abspath(data.require("taggers/averaged_perceptron_tagger_%s/" % lang))
    if directory not in _model_cache:
        _model_cache[directory] = _PerceptronModel(directory, lang)
    return _model_cache[directory]


def _load_universal_english():
    path = os.path.abspath(data.require("taggers/universal_tagset/en-ptb.map"))
    if path not in _universal_cache:
        mapping = {}
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                parts = line.rstrip("\r\n").split("\t")
                if len(parts) == 2:
                    mapping[parts[0]] = parts[1]
        _universal_cache[path] = mapping
    return _universal_cache[path]


# Russian National Corpus part-of-speech categories -> universal tagset.
_RUSSIAN_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "ADVPRO": "ADV",
    "PRAEDIC": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM",
    "SPRO": "PRON", "APRO": "DET", "INTJ": "X", "PARENTH": "X", "COM": "X",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with LINGORA's recommended tagger for ``lang``."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag needs a list of tokens, not a string")
    tokens = list(tokens)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be str, got %s" % type(token).__name__)
    if lang not in _PERCEPTRON_LANGS:
        raise ValueError("unsupported language for pos_tag: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unknown tagset: %r" % (tagset,))

    model = _load_model(lang)
    tagged = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_universal_english()
            tagged = [(w, mapping.get(t, t)) for w, t in tagged]
        else:
            tagged = [
                (w, _RUSSIAN_TO_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged
            ]
    return tagged
