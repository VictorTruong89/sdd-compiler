"""Context-free grammars read from text (PRD FP-05)."""

import re

_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


class Nonterminal:
    """A grammar nonterminal. ``str()`` is its name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """``lhs -> rhs``: lhs is a Nonterminal; rhs holds Nonterminals and str terminals."""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and self._lhs == other._lhs
            and self._rhs == other._rhs
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "Production(%s)" % self

    def __str__(self):
        parts = []
        for item in self._rhs:
            parts.append(str(item) if isinstance(item, Nonterminal) else '"%s"' % item)
        return "%s -> %s" % (self._lhs, " ".join(parts))


class CFG:
    """A context-free grammar. The start symbol is the LHS of the first production."""

    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(str(start))
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for production in self._productions:
            self._by_lhs.setdefault(production.lhs(), []).append(production)

    @classmethod
    def fromstring(cls, input):
        """Read productions from text, one ``LHS -> RHS`` per line (``|`` separates alternatives)."""
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line:
                continue
            if "->" not in line:
                raise ValueError("production line without '->': %r" % raw)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or re.search(r"[\s'\"|]", lhs_text):
                raise ValueError("bad left-hand side in %r" % raw)
            lhs = Nonterminal(lhs_text)
            for alternative in _split_alternatives(rhs_text, raw):
                productions.append(Production(lhs, alternative))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._by_lhs.get(lhs, []))

    def terminals(self):
        found = set()
        for production in self._productions:
            for item in production.rhs():
                if isinstance(item, str):
                    found.add(item)
        return found

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


def _split_alternatives(rhs_text, raw):
    alternatives = [[]]
    position = 0
    text = rhs_text
    while True:
        match = _TOKEN_RE.match(text, position)
        if not match or match.end() == position:
            if text[position:].strip():
                raise ValueError("cannot read right-hand side of %r" % raw)
            break
        position = match.end()
        single, double, bar, word = match.groups()
        if bar:
            alternatives.append([])
        elif single is not None:
            alternatives[-1].append(single)
        elif double is not None:
            alternatives[-1].append(double)
        else:
            alternatives[-1].append(Nonterminal(word))
    return alternatives
