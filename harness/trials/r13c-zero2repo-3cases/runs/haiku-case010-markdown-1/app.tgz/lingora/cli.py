"""Command line: ``lingora tokenize`` reads lines from stdin and writes token lines."""

import argparse
import sys

from lingora import tokenize


def _use_utf8(*streams):
    """Read and write UTF-8 regardless of the locale."""
    for stream in streams:
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def _tokenize_command(language, delimiter, stdin, stdout, stderr):
    try:
        # Loads the Punkt model up front so a missing model fails before any output.
        tokenize.sent_tokenize("", language=language)
    except LookupError as error:
        stderr.write("lingora: %s\n" % error)
        return 1
    for line in stdin:
        line = line.rstrip("\r\n")
        try:
            tokens = tokenize.word_tokenize(line, language=language)
        except Exception as error:  # report and stop; no token line for this input
            stderr.write("lingora: %s\n" % error)
            return 1
        stdout.write(delimiter.join(tokens) + "\n")
    return 0


class _Group:
    """Command group with a ``main`` entry point."""

    prog = "lingora"

    def _parser(self):
        parser = argparse.ArgumentParser(prog=self.prog, description="LINGORA command line")
        commands = parser.add_subparsers(dest="command", metavar="COMMAND")
        commands.required = True
        tok = commands.add_parser(
            "tokenize",
            help="tokenize each input line with the recommended word tokenizer",
        )
        tok.add_argument("--language", default="english", help="Punkt language (default: english)")
        tok.add_argument("--delimiter", default=" ", help="token delimiter (default: one space)")
        return parser

    def run(self, args, stdin=None, stdout=None, stderr=None):
        """Run the command with ``args``; return the process exit status."""
        if stdin is None and stdout is None and stderr is None:
            _use_utf8(sys.stdin, sys.stdout, sys.stderr)
        stdin = sys.stdin if stdin is None else stdin
        stdout = sys.stdout if stdout is None else stdout
        stderr = sys.stderr if stderr is None else stderr
        parser = self._parser()
        try:
            options = parser.parse_args(list(args))
        except SystemExit as exit_request:
            return exit_request.code if isinstance(exit_request.code, int) else 2
        if options.command == "tokenize":
            return _tokenize_command(options.language, options.delimiter, stdin, stdout, stderr)
        return 2

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        status = self.run(args)
        if standalone_mode:
            sys.exit(status)
        return status


cli = _Group()


def main():
    cli.main()


if __name__ == "__main__":
    main()
