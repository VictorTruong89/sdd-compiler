"""Stemmers (PRD FP-02)."""

import re

from lingora import data

_VOWELS = "aeiou"


# ---------------------------------------------------------------------------
# Porter (default mode: LINGORA extensions; "original" mode: published algorithm)
# ---------------------------------------------------------------------------

def _is_consonant(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_consonant(word, i - 1)
    return True


def _measure(stem):
    measure = 0
    previous_vowel = False
    for i in range(len(stem)):
        vowel = not _is_consonant(stem, i)
        if previous_vowel and not vowel:
            measure += 1
        previous_vowel = vowel
    return measure


def _has_vowel(stem):
    return any(not _is_consonant(stem, i) for i in range(len(stem)))


def _ends_double_consonant(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_consonant(word, len(word) - 1)


def _ends_cvc(word, extended):
    n = len(word)
    if n >= 3 and _is_consonant(word, n - 3) and not _is_consonant(word, n - 2) \
            and _is_consonant(word, n - 1) and word[-1] not in "wxy":
        return True
    if extended and n == 2 and not _is_consonant(word, 0) and _is_consonant(word, 1) \
            and word[-1] not in "wxy":
        return True
    return False


_PORTER_IRREGULAR = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "news": "news",
    "innings": "inning",
    "inning": "inning",
    "outings": "outing",
    "outing": "outing",
    "cannings": "canning",
    "canning": "canning",
}

_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_EXTENDED = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _porter_step1a(word, ext):
    if word.endswith("sses"):
        return word[:-2]
    if word.endswith("ies"):
        if ext and len(word) == 4:
            return word[:-1]
        return word[:-2]
    if word.endswith("ss"):
        return word
    if word.endswith("s"):
        return word[:-1]
    return word


def _porter_cleanup(word, ext):
    if word.endswith(("at", "bl", "iz")):
        return word + "e"
    if _ends_double_consonant(word) and word[-1] not in "lsz":
        return word[:-1]
    if _measure(word) == 1 and _ends_cvc(word, ext):
        return word + "e"
    return word


def _porter_step1b(word, ext):
    if ext and word.endswith("ied"):
        return word[:-3] + ("ie" if len(word) == 4 else "i")
    if word.endswith("eed"):
        if _measure(word[:-3]) > 0:
            return word[:-1]
        return word
    for suffix in ("ed", "ing"):
        if word.endswith(suffix):
            stem = word[:-len(suffix)]
            if _has_vowel(stem):
                return _porter_cleanup(stem, ext)
            return word
    return word


def _porter_step1c(word, ext):
    if word.endswith("y") and len(word) >= 2:
        stem = word[:-1]
        if ext:
            if len(stem) >= 2 and _is_consonant(stem, len(stem) - 1):
                return stem + "i"
        elif _has_vowel(stem):
            return stem + "i"
    return word


def _porter_step2(word, ext):
    if ext and word.endswith("alli") and _measure(word[:-4]) > 0:
        return _porter_step2(word[:-4] + "al", ext)
    if ext and word.endswith("logi") and _measure(word[:-3]) > 0:
        return word[:-1]
    table = _STEP2_EXTENDED if ext else _STEP2_ORIGINAL
    for suffix, replacement in table:
        if word.endswith(suffix):
            stem = word[:-len(suffix)]
            if _measure(stem) > 0:
                return stem + replacement
            return word
    return word


def _porter_step3(word):
    for suffix, replacement in _STEP3:
        if word.endswith(suffix):
            stem = word[:-len(suffix)]
            if _measure(stem) > 0:
                return stem + replacement
            return word
    return word


def _porter_step4(word):
    for suffix in _STEP4:
        if word.endswith(suffix):
            stem = word[:-len(suffix)]
            if suffix == "ion":
                if _measure(stem) > 1 and stem[-1:] in ("s", "t"):
                    return stem
                return word
            if _measure(stem) > 1:
                return stem
            return word
    return word


def _porter_step5(word, ext):
    if word.endswith("e"):
        stem = word[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _ends_cvc(stem, ext)):
            word = stem
    if word.endswith("l") and _measure(word) > 1 and _ends_double_consonant(word):
        word = word[:-1]
    return word


class PorterStemmer:
    """Porter's algorithm. Modes: ``"lingora"`` (default), ``"original"``."""

    def __init__(self, mode="lingora"):
        if mode not in ("lingora", "original"):
            raise ValueError("unknown Porter mode %r" % mode)
        self._mode = mode

    def stem(self, word, to_lowercase=True):
        if to_lowercase:
            word = word.lower()
        ext = self._mode == "lingora"
        if ext and word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        if len(word) <= 2:
            return word
        word = _porter_step1a(word, ext)
        word = _porter_step1b(word, ext)
        word = _porter_step1c(word, ext)
        word = _porter_step2(word, ext)
        word = _porter_step3(word)
        word = _porter_step4(word)
        word = _porter_step5(word, ext)
        return word


# ---------------------------------------------------------------------------
# Snowball English (Porter2)
# ---------------------------------------------------------------------------

_E2_EXCEPTIONS1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_E2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_E2_EXCEPTIONS2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_E2_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "ogi": "og", "fulli": "ful", "lessli": "less", "li": "",
}
_E2_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
    "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_E2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _e2_is_vowel(ch):
    return ch in "aeiouy"


def _e2_region(word, start):
    for i in range(max(start, 1), len(word)):
        if not _e2_is_vowel(word[i]) and _e2_is_vowel(word[i - 1]):
            return i + 1
    return len(word)


def _e2_short_syllable_end(word):
    if len(word) == 2:
        return _e2_is_vowel(word[0]) and not _e2_is_vowel(word[1]) and word[1] not in "wxY"
    if len(word) >= 3:
        return (not _e2_is_vowel(word[-3]) and _e2_is_vowel(word[-2])
                and not _e2_is_vowel(word[-1]) and word[-1] not in "wxY")
    return False


def _e2_longest(word, suffixes):
    best = None
    for suffix in suffixes:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    return best


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _E2_EXCEPTIONS1:
        return _E2_EXCEPTIONS1[word]
    if word in _E2_INVARIANT:
        return word
    if word.startswith("'"):
        word = word[1:]

    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and _e2_is_vowel(chars[i - 1]):
            chars[i] = "Y"
    w = "".join(chars)

    if w.startswith("gener") or w.startswith("arsen"):
        r1 = 5
    elif w.startswith("commun"):
        r1 = 6
    else:
        r1 = _e2_region(w, 0)
    r2 = _e2_region(w, r1)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(_e2_is_vowel(c) for c in w[:-2]):
            w = w[:-1]

    if w in _E2_EXCEPTIONS2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        suffix = _e2_longest(w, ("ed", "edly", "ing", "ingly"))
        if suffix is not None:
            stem = w[:-len(suffix)]
            if any(_e2_is_vowel(c) for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                    w = w[:-1]
                elif _e2_short_syllable_end(w) and r1 >= len(w):
                    w += "e"

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and not _e2_is_vowel(w[-2]):
        w = w[:-1] + "i"

    # Step 2 (within R1)
    suffix = _e2_longest(w, _E2_STEP2)
    if suffix is not None and len(w) - len(suffix) >= r1:
        stem = w[:-len(suffix)]
        allowed = True
        if suffix == "ogi":
            allowed = stem.endswith("l")
        elif suffix == "li":
            allowed = stem[-1:] in ("c", "d", "e", "g", "h", "k", "m", "n", "r", "t")
        if allowed:
            w = stem + _E2_STEP2[suffix]

    # Step 3 (within R1; "ative" within R2)
    suffix = _e2_longest(w, _E2_STEP3)
    if suffix is not None:
        limit = r2 if suffix == "ative" else r1
        if len(w) - len(suffix) >= limit:
            w = w[:-len(suffix)] + _E2_STEP3[suffix]

    # Step 4 (within R2)
    suffix = _e2_longest(w, _E2_STEP4)
    if suffix is not None and len(w) - len(suffix) >= r2:
        if suffix != "ion" or w[-len(suffix) - 1:-len(suffix)] in ("s", "t"):
            w = w[:-len(suffix)]

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _e2_short_syllable_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


# ---------------------------------------------------------------------------
# Snowball
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


class SnowballStemmer:
    """Snowball stemmers. English is Porter2; ``porter`` is the original Porter algorithm.

    The other listed languages are accepted, but their stemming algorithms are
    not implemented here; ``stem`` raises NotImplementedError for them.
    """

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            self._stopwords = set(data.read_lines("corpora/stopwords/%s" % language))

    def stem(self, word):
        lowered = word.lower()
        if self._stopwords is not None and lowered in self._stopwords:
            return lowered
        if self._language == "english":
            return _porter2(lowered)
        if self._language == "porter":
            return PorterStemmer(mode="original").stem(lowered, to_lowercase=False)
        raise NotImplementedError(
            "Snowball algorithm for %r is not implemented in this build" % self._language
        )


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rules: reversed ending, optional '*' (intact words only), digit (letters to
# remove), appended letters, then '.' (stop) or '>' (continue).
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3y.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "luf3y.", "lu2.", "lai3>", "lau3>", "lla1.", "ll1.", "lo2.", "lu1.", "mm1.",
    "mu*2.", "nois4j>", "noix4ct.", "noi3>", "nai3y.", "nado2l>", "nalo3>",
    "nam3>", "ne2>", "nen3>", "nu3>", "na2>", "oi*1.", "o1.", "pi2>", "pe2>",
    "pi1.", "ps1.", "rod2>", "rdi3.", "rso3.", "rs1.", "rgi3.", "rbi3.", "rv1.",
    "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.",
    "tacilp4y.", "ytic3s.", "tnem4.", "tnem4>", "ta2>", "tu2>", "tt1.", "uqi3>",
    "ugo1.", "vis3j>", "vie3>", "vi2>", "vi1.", "vo1.", "yb3..", "yllih3.", "ylba4.", "y1>",
    "ys3>", "yn1.", "ym1.", "yr1.",
]


def _parse_lancaster_rule(rule):
    match = re.match(r"^([a-z]+)(\*?)(\d*)([a-z]*)([.>])$", rule)
    if match is None:
        return None
    pattern, star, digits, append, terminator = match.groups()
    remove = int(digits) if digits else len(pattern)
    return pattern[::-1], bool(star), remove, append, terminator == ">"


_LANCASTER_PARSED = [r for r in (_parse_lancaster_rule(rule) for rule in _LANCASTER_RULES) if r]


def _lancaster_acceptable(word):
    if not word:
        return False
    minimum = 2 if word[0] in "aeiouy" else 3
    return len(word) >= minimum


class LancasterStemmer:
    """Paice/Husk stemmer driven by a rule table."""

    def stem(self, word):
        word = word.lower()
        intact = True
        while True:
            for ending, intact_only, remove, append, proceed in _LANCASTER_PARSED:
                if intact_only and not intact:
                    continue
                if not word.endswith(ending) or remove > len(word):
                    continue
                candidate = word[:len(word) - remove] + append
                if not _lancaster_acceptable(candidate):
                    continue
                word = candidate
                intact = False
                break
            else:
                return word
            if not proceed:
                return word


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer:
    """Removes every match of a caller-supplied pattern from the word."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        return self._regexp.sub("", word)


# ---------------------------------------------------------------------------
# Arabic light stemmers
# ---------------------------------------------------------------------------

_ARABIC_PREFIXES = ("وال", "بال", "كال", "فال", "ال")
_ARABIC_SUFFIXES = ("ها", "ات", "ون", "ين", "يه", "ية", "ة")


class ARLSTem:
    """Light Arabic stemmer: strips one prefix and one suffix."""

    def stem(self, word):
        for prefix in _ARABIC_PREFIXES:
            if word.startswith(prefix) and len(word) - len(prefix) >= 3:
                word = word[len(prefix):]
                break
        for suffix in _ARABIC_SUFFIXES:
            if word.endswith(suffix) and len(word) - len(suffix) >= 3:
                word = word[:-len(suffix)]
                break
        return word


class ARLSTem2(ARLSTem):
    """Second Arabic light stemmer (same light approach, with the 'ة' suffix kept)."""

    def stem(self, word):
        for prefix in _ARABIC_PREFIXES:
            if word.startswith(prefix) and len(word) - len(prefix) >= 3:
                word = word[len(prefix):]
                break
        for suffix in _ARABIC_SUFFIXES:
            if suffix != "ة" and word.endswith(suffix) and len(word) - len(suffix) >= 3:
                word = word[:-len(suffix)]
                break
        return word


# ---------------------------------------------------------------------------
# WordNet lemmatizer
# ---------------------------------------------------------------------------

class WordNetLemmatizer:
    """Requires the packaged WordNet resource; lemmatization itself is not implemented."""

    def __init__(self):
        data.require("corpora/wordnet")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet morphy lemmatization is not implemented in this build")
