"""Word, punctuation and sentence tokenizers (PRD FP-01)."""

import os
import re

from lingora import data

# ---------------------------------------------------------------------------
# Simple tokenizers
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    """Split into maximal runs of word characters and of non-word, non-space characters."""
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer:
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        return [m.span() for m in _WORDPUNCT_RE.finditer(text)]


class WhitespaceTokenizer:
    def tokenize(self, text):
        return text.split()

    def span_tokenize(self, text):
        return [m.span() for m in re.finditer(r"\S+", text)]


_BLANKLINE_RE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Split into segments separated by blank lines; empty segments are dropped."""
    return [piece for piece in _BLANKLINE_RE.split(text) if piece]


class RegexpTokenizer:
    """Tokenize with a caller-supplied regular expression.

    In token mode (default) the tokens are the matches; in gap mode the tokens
    are the pieces between matches.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._pattern = re.compile(pattern)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def tokenize(self, text):
        return [text[start:end] for start, end in self.span_tokenize(text)]

    def span_tokenize(self, text):
        spans = []
        if self._gaps:
            position = 0
            for match in self._pattern.finditer(text):
                spans.append((position, match.start()))
                position = match.end()
            spans.append((position, len(text)))
        else:
            spans = [m.span() for m in self._pattern.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


# ---------------------------------------------------------------------------
# Penn Treebank and recommended word tokenizers
# ---------------------------------------------------------------------------

_STARTING_QUOTE_RE = re.compile(r'(^|[\s(\[{<])"')
_CLITIC_RE = re.compile(r"(?i)([^\s'])(n't|'ll|'re|'ve|'s|'m|'d)(?=\s)")
_BARE_APOSTROPHE_RE = re.compile(r"([^\s'])'(?=\s)")
_PERIOD_END_RE = re.compile(r"([^.])(\.)([\]\)}>\"']*)\s*$")
_BRACKET_RE = re.compile(r"([\]\[\(\)\{\}<>])")
_SPLIT_CHARS_RE = re.compile(r"([;@#$%&?!])")
_COLON_COMMA_RE = re.compile(r"([:,])(?!\d)")
_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)(?=\s)"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(is)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(was)\b"), r"\1 \2"),
]

_TYPOGRAPHIC_QUOTES_RE = re.compile(r"([\u201a\u201b\u201c\u201d\u201e\u201f\u2018\u2019])")
_DASH_STAR_RE = re.compile(r"([\u2012-\u2015*])")
_POINT_RUN_RE = re.compile(r"(\.{2,})")


def _penn_tokenize(text, recommended):
    if recommended:
        text = _TYPOGRAPHIC_QUOTES_RE.sub(r" \1 ", text)
        text = _DASH_STAR_RE.sub(r" \1 ", text)
        text = _POINT_RUN_RE.sub(r" \1 ", text)
        text = text.replace("--", " -- ")

    # Straight double quotes: opening ones become ``, every other one ''.
    text = _STARTING_QUOTE_RE.sub(r"\1 `` ", text)
    text = text.replace('"', " '' ")

    text = " " + text + " "
    text = text.replace("...", " ... ")
    text = _SPLIT_CHARS_RE.sub(r" \1 ", text)
    text = _COLON_COMMA_RE.sub(r" \1 ", text)
    text = _PERIOD_END_RE.sub(r"\1 \2\3 ", text)
    text = _BRACKET_RE.sub(r" \1 ", text)
    text = _CLITIC_RE.sub(r"\1 \2", text)
    text = _BARE_APOSTROPHE_RE.sub(r"\1 '", text)
    for regexp, repl in _FUSED:
        text = regexp.sub(repl, text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer."""

    def tokenize(self, text):
        return _penn_tokenize(text, recommended=False)


# ---------------------------------------------------------------------------
# Punkt sentence tokenizer
# ---------------------------------------------------------------------------

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_NON_WORD = r"(?:[?!)\";}\]\*:@'\({\[])"
_MULTI_CHAR_PUNCT = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_PUNKT_WORD_RE = re.compile(
    "(" + _MULTI_CHAR_PUNCT + "|(?=" + _WORD_START + r")\S+?(?=" + _NON_WORD + r"|\s|$)"
    "|" + _NON_WORD + r"|\S)"
)
_PERIOD_CONTEXT_RE = re.compile(
    r"\S*[.?!](?=(?P<after_tok>" + _NON_WORD + r"|\s+(?P<next_tok>\S+)))"
)
_ELLIPSIS_RE = re.compile(r"^\.\.+$")
_INITIAL_RE = re.compile(r"[^\W\d]\.$")
_NUMBER_TYPE_RE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")

_punkt_cache = {}


class _PunktParams:
    def __init__(self, directory):
        self.abbrev_types = set(_read_entries(directory, "abbrev_types.txt"))
        self.sent_starters = set(_read_entries(directory, "sent_starters.txt"))
        self.collocations = set()
        for line in _read_entries(directory, "collocations.tab"):
            parts = line.split("\t")
            if len(parts) == 2:
                self.collocations.add((parts[0], parts[1]))
        self.ortho_context = {}
        for line in _read_entries(directory, "ortho_context.tab"):
            parts = line.split("\t")
            if len(parts) == 2:
                self.ortho_context[parts[0]] = int(parts[1])


def _read_entries(directory, name):
    with open(os.path.join(directory, name), encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.strip()]


def _load_punkt(language):
    resource = "tokenizers/punkt_tab/%s/" % language
    directory = None
    for base in data.path:
        candidate = os.path.join(base, resource)
        if os.path.isdir(candidate):
            directory = os.path.normpath(candidate)
            break
    if directory is None:
        raise LookupError(
            "Punkt models for %r not found in data.path %r" % (language, list(data.path))
        )
    if directory not in _punkt_cache:
        _punkt_cache[directory] = _PunktParams(directory)
    return _punkt_cache[directory]


class _AugTok:
    """One word token with the flags Punkt's annotation passes set on it."""

    def __init__(self, tok):
        self.tok = tok
        self.type = _NUMBER_TYPE_RE.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = bool(_ELLIPSIS_RE.match(tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_initial(self):
        return bool(_INITIAL_RE.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")


def _tokenize_words_for_punkt(text):
    tokens = []
    for line in text.split("\n"):
        if line.strip():
            tokens.extend(_AugTok(tok) for tok in _PUNKT_WORD_RE.findall(line))
    return tokens


def _ortho_heuristic(params, tok):
    context = params.ortho_context.get(tok.type_no_sentperiod, 0)
    if tok.first_upper and (context & _ORTHO_LC) and not (context & _ORTHO_MID_UC):
        return True
    if tok.first_lower and ((context & _ORTHO_UC) or not (context & _ORTHO_BEG_LC)):
        return False
    return None


def _second_pass(params, tok1, tok2):
    if tok2 is None or not tok1.period_final:
        return
    typ = tok1.type_no_period
    next_typ = tok2.type_no_sentperiod
    is_initial = tok1.is_initial

    # Collocation heuristic (4.1.2).
    if (typ, next_typ) in params.collocations:
        tok1.sentbreak = False
        tok1.abbr = True
        return

    # Token-based reclassification of abbreviations and ellipses (4.2).
    if tok1.abbr or tok1.ellipsis:
        starter = _ortho_heuristic(params, tok2)
        if starter is True:
            tok1.sentbreak = True
            return
        if tok2.first_upper and next_typ in params.sent_starters:
            tok1.sentbreak = True
            return

    # Initials and ordinals (4.3).
    if is_initial or typ == "##number##":
        starter = _ortho_heuristic(params, tok2)
        if starter is False:
            tok1.sentbreak = False
            tok1.abbr = True
            return
        if tok2.first_upper and next_typ in params.sent_starters:
            tok1.sentbreak = True
            return

    # Frequent sentence starter heuristic (4.1.4).
    if tok2.first_upper and next_typ in params.sent_starters:
        tok1.sentbreak = True


def _annotate(params, tokens):
    for tok in tokens:
        if tok.tok in (".", "?", "!"):
            tok.sentbreak = True
        elif tok.ellipsis:
            pass
        elif tok.period_final and not tok.tok.endswith(".."):
            candidate = tok.tok[:-1].lower()
            if candidate in params.abbrev_types or candidate.split("-")[-1] in params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True
    for index, tok in enumerate(tokens):
        following = tokens[index + 1] if index + 1 < len(tokens) else None
        _second_pass(params, tok, following)
    return tokens


def _context_contains_break(params, context):
    tokens = _annotate(params, _tokenize_words_for_punkt(context))
    return any(tok.sentbreak for tok in tokens[:-1])


def _split_sentences(params, text):
    slices = []
    last_break = 0
    for match in _PERIOD_CONTEXT_RE.finditer(text):
        after = match.group("after_tok") or ""
        context = match.group(0) + after
        if _context_contains_break(params, context):
            slices.append((last_break, match.end()))
            if match.group("next_tok"):
                last_break = match.start("next_tok")
            else:
                last_break = match.end()
    slices.append((last_break, len(text)))
    sentences = []
    for start, end in slices:
        piece = text[start:end].strip()
        if piece:
            sentences.append(piece)
    return sentences


def sent_tokenize(text, language="english"):
    """Split text into sentences with the Punkt model of ``language``."""
    params = _load_punkt(language)
    return _split_sentences(params, text)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    if preserve_line:
        return _penn_tokenize(text, recommended=True)
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_penn_tokenize(sentence, recommended=True))
    return tokens


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON_RE = re.compile(
    r"[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]"
    r"|[<>]?[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8]"
    r"|<3|</?3"
)
_TWEET_TOKEN_RE = re.compile(
    "(" + "|".join(
        [
            _EMOTICON_RE.pattern,
            r"(?:https?://|www\.)\S+",
            r"[#]\w+",
            r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])",
            r"\.{2,}",
            r"\w+(?:'\w+)*",
            r"[^\w\s]",
        ]
    ) + ")"
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REPEAT_RE = re.compile(r"(.)\1\1+", re.DOTALL)
_EMOTICON_FULL_RE = re.compile("(?:" + _EMOTICON_RE.pattern + ")")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _REPEAT_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_TOKEN_RE.findall(text)
        if not self._preserve_case:
            tokens = [
                tok if _EMOTICON_FULL_RE.fullmatch(tok) else tok.lower() for tok in tokens
            ]
        return tokens
