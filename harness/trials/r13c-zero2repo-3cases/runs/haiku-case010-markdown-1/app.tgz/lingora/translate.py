"""BLEU (Papineni et al., 2002) over token lists."""

import math
from collections import Counter


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against one or more ``references``.

    ``smoothing_function``, when given, is called with a list of
    (matched_count, total_count) pairs, one per weighted order, and returns the
    list of precisions to use in place of the raw ones.
    """
    references = [list(ref) for ref in references]
    hypothesis = list(hypothesis)
    if not hypothesis or not references:
        return 0.0

    pairs = []
    for order in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, order)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, order).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        matched = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        pairs.append((matched, total))

    if smoothing_function is not None:
        precisions = list(smoothing_function(pairs))
    else:
        precisions = [matched / total if total else 0.0 for matched, total in pairs]
        if any(p == 0 for p in precisions):
            return 0.0

    log_mean = sum(w * math.log(p) for w, p in zip(weights, precisions))

    hyp_len = len(hypothesis)
    ref_len = min((len(ref) for ref in references), key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / hyp_len)
    return brevity * math.exp(log_mean)
