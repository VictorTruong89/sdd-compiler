"""Shared input checks for the parsers."""

from lingora.grammar import CFG


def as_grammar(grammar):
    if isinstance(grammar, str):
        return CFG.fromstring(grammar)
    if not isinstance(grammar, CFG):
        raise TypeError("expected a CFG, got %s" % type(grammar).__name__)
    return grammar


def check_tokens(grammar, tokens):
    """Return ``tokens`` as a list of str; raise when a token no production produces."""
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    tokens = list(tokens)
    known = grammar.terminals()
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be str, got %s" % type(token).__name__)
        if token not in known:
            raise ValueError("no production of the grammar produces token %r" % token)
    return tokens
