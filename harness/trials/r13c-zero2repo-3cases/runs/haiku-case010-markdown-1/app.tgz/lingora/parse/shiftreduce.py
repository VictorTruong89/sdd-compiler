"""Single-pass shift-reduce parser without backtracking."""

from lingora.grammar import Nonterminal
from lingora.parse._common import as_grammar, check_tokens
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = as_grammar(grammar)

    def parse(self, tokens):
        tokens = check_tokens(self._grammar, tokens)
        return iter(_shift_reduce(self._grammar, tokens))


def _shift_reduce(grammar, tokens):
    # Empty productions and empty terminals cannot drive a shift-reduce pass.
    productions = [
        p for p in grammar.productions() if p.rhs() and "" not in p.rhs()
    ]
    stack = []  # (symbol, node): symbol is a token str or a Nonterminal
    position = 0
    budget = 10 * (len(tokens) + 1) * (len(productions) + 1) + 100
    while True:
        reduced = False
        for production in productions:
            rhs = production.rhs()
            k = len(rhs)
            if k > len(stack):
                continue
            top = stack[len(stack) - k:]
            if all(top[x][0] == rhs[x] for x in range(k)):
                children = [node for _, node in top]
                del stack[len(stack) - k:]
                stack.append(
                    (production.lhs(), Tree(str(production.lhs()), children))
                )
                reduced = True
                break
        if reduced:
            budget -= 1
            if budget < 0:
                return []
            continue
        if position < len(tokens):
            stack.append((tokens[position], tokens[position]))
            position += 1
            continue
        break

    if len(stack) == 1:
        symbol, node = stack[0]
        if isinstance(symbol, Nonterminal) and symbol == grammar.start():
            return [node]
    return []
