"""Enumerate the sentences a grammar derives."""

import itertools
import sys

from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield token lists derived from ``start`` (default: the start symbol).

    ``depth`` bounds the derivation depth (None: unbounded); ``n`` bounds the
    number of sentences yielded (None: unbounded).
    """
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    sentences = _generate_all(grammar, [start], depth)
    if n is not None:
        sentences = itertools.islice(sentences, n)
    return sentences


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    for head in _generate_one(grammar, items[0], depth):
        for tail in _generate_all(grammar, items[1:], depth):
            yield head + tail


def _generate_one(grammar, item, depth):
    if isinstance(item, Nonterminal):
        if depth > 0:
            for production in grammar.productions(lhs=item):
                yield from _generate_all(grammar, list(production.rhs()), depth - 1)
    else:
        yield [item]
