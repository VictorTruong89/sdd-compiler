"""Exhaustive chart parser: returns every tree the grammar assigns to a token list."""

from collections import defaultdict

from lingora.parse._common import as_grammar, check_tokens
from lingora.tree import Tree

_MAX_ROUNDS = 200


class ChartParser:
    def __init__(self, grammar):
        self._grammar = as_grammar(grammar)

    def parse(self, tokens):
        tokens = check_tokens(self._grammar, tokens)
        return iter(_all_parses(self._grammar, tokens))


def _all_parses(grammar, tokens):
    n = len(tokens)
    chart = defaultdict(list)
    seen = defaultdict(set)
    productions = grammar.productions()

    def match(rhs, index, pos, end):
        """Yield child lists covering tokens[pos:end] with rhs[index:]."""
        if index == len(rhs):
            if pos == end:
                yield []
            return
        item = rhs[index]
        if isinstance(item, str):
            if item == "":
                yield from match(rhs, index + 1, pos, end)
            elif pos < end and tokens[pos] == item:
                for rest in match(rhs, index + 1, pos + 1, end):
                    yield [item] + rest
        else:
            for stop in range(pos, end + 1):
                for tree in tuple(chart.get((item, pos, stop), ())):
                    for rest in match(rhs, index + 1, stop, end):
                        yield [tree] + rest

    # Fill spans from shortest to longest. Within one span, unit and empty
    # productions can feed each other, so iterate that span to a fixed point.
    for length in range(n + 1):
        for start in range(n - length + 1):
            end = start + length
            for _ in range(_MAX_ROUNDS):
                changed = False
                for production in productions:
                    key = (production.lhs(), start, end)
                    for children in match(production.rhs(), 0, start, end):
                        tree = Tree(str(production.lhs()), children)
                        if tree not in seen[key]:
                            seen[key].add(tree)
                            chart[key].append(tree)
                            changed = True
                if not changed:
                    break

    return list(chart.get((grammar.start(), 0, n), []))
