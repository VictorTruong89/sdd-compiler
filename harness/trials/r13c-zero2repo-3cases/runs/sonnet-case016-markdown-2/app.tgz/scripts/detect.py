#!/usr/bin/env python3
"""prosecheck detector: local, standard-library scan for AI-writing patterns.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import sys
import time
import unicodedata
import zipfile
from collections import Counter

WINDOW = 262144
PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}
NO_TEXT_EXT = {".pdf", ".rtf"}
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Score the prose in FILE (or standard input) against 71 documented AI-writing patterns.\n"
    "  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        stop option parsing so a file name may begin with a dash\n"
    "  FILE      a single file operand; with none, standard input is read\n"
)


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# ----------------------------------------------------------------------------
# Extraction
# ----------------------------------------------------------------------------

def decode_bytes(data):
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            return data.decode("utf-16")
        except Exception:
            return data[2:].decode("utf-16-le", "replace")
    if data[:3] == b"\xef\xbb\xbf":
        data = data[3:]
    if b"\x00" in data:
        return ""
    return data.decode("utf-8", "replace")


def natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", name)]


MEMBER_LIMIT = 64 * 1024 * 1024


def zread(z, name):
    with z.open(name) as f:
        return f.read(MEMBER_LIMIT)


def local(tag):
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1]


def parse_xml(data):
    import xml.etree.ElementTree as ET
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def strip_tags_fallback(data, tag_re):
    import html
    s = data.decode("utf-8", "replace")
    out = []
    for m in re.finditer(tag_re, s, re.S):
        out.append(html.unescape(re.sub(r"<[^>]+>", "", m.group(1))))
    return "\n".join(out)


def extract_docx(z):
    names = ["word/document.xml"]
    if "word/document.xml" not in z.namelist():
        return ""
    data = zread(z, names[0])
    root = parse_xml(data)
    if root is None:
        return strip_tags_fallback(data, r"<w:p[\s>](.*?)</w:p>")
    paras = []

    def para_text(p):
        buf = []
        for el in p.iter():
            t = local(el.tag)
            if t == "t":
                buf.append(el.text or "")
            elif t == "tab":
                buf.append("\t")
            elif t in ("br", "cr"):
                buf.append("\n")
        return "".join(buf)

    for el in root.iter():
        if local(el.tag) == "p":
            paras.append(para_text(el))
    return "\n".join(p for p in paras if p.strip() != "")


def extract_pptx(z):
    slides = [n for n in z.namelist() if re.match(r"ppt/slides/[^/]+\.xml$", n)]
    slides.sort(key=natural_key)
    out = []
    for n in slides:
        data = zread(z, n)
        root = parse_xml(data)
        if root is None:
            out.append(strip_tags_fallback(data, r"<a:p[\s>](.*?)</a:p>"))
            continue
        for p in root.iter():
            if local(p.tag) == "p":
                txt = "".join((e.text or "") for e in p.iter() if local(e.tag) == "t")
                if txt.strip():
                    out.append(txt)
    return "\n".join(out)


def extract_xlsx(z):
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = parse_xml(zread(z, "xl/sharedStrings.xml"))
        if root is not None:
            for si in root:
                if local(si.tag) != "si":
                    continue
                parts = []

                def walk(e):
                    for ch in e:
                        t = local(ch.tag)
                        if t == "t":
                            parts.append(ch.text or "")
                        elif t == "r":
                            walk(ch)
                walk(si)
                shared.append("".join(parts))
    sheets = [n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)]
    sheets.sort(key=natural_key)
    out = []
    for n in sheets:
        root = parse_xml(zread(z, n))
        if root is None:
            continue
        for c in root.iter():
            if local(c.tag) != "c":
                continue
            t = c.get("t")
            if t == "s":
                v = None
                for ch in c:
                    if local(ch.tag) == "v":
                        v = (ch.text or "").strip()
                if v is not None and re.fullmatch(r"[0-9]+", v):
                    i = int(v)
                    if i < len(shared) and shared[i].strip():
                        out.append(shared[i])
            elif t == "inlineStr":
                txt = "".join((e.text or "") for e in c.iter() if local(e.tag) == "t")
                if txt.strip():
                    out.append(txt)
            elif t == "str":
                for ch in c:
                    if local(ch.tag) == "v" and (ch.text or "").strip():
                        out.append(ch.text)
    return "\n".join(out)


def extract_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    root = parse_xml(zread(z, "content.xml"))
    if root is None:
        return ""
    out = []

    def inline(e, buf):
        if e.text:
            buf.append(e.text)
        for ch in e:
            t = local(ch.tag)
            if t == "s":
                try:
                    buf.append(" " * int(ch.get(next((k for k in ch.attrib if local(k) == "c"), ""), "1")))
                except Exception:
                    buf.append(" ")
            elif t == "tab":
                buf.append("\t")
            elif t == "line-break":
                buf.append("\n")
            elif t == "annotation":
                pass
            else:
                inline(ch, buf)
            if ch.tail:
                buf.append(ch.tail)

    def walk(e):
        for ch in e:
            t = local(ch.tag)
            if t in ("p", "h"):
                buf = []
                inline(ch, buf)
                s = "".join(buf)
                if s.strip():
                    out.append(s)
            elif t == "annotation":
                continue
            else:
                walk(ch)
    walk(root)
    return "\n".join(out)


BLOCK_TAGS = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
              "section", "article", "pre", "ul", "ol", "table", "dd", "dt", "hr", "figcaption", "body"}
SKIP_TAGS = {"script", "style", "nav", "head", "title"}


def html_text(data):
    from html.parser import HTMLParser

    class P(HTMLParser):
        def __init__(self):
            HTMLParser.__init__(self, convert_charrefs=True)
            self.buf = []
            self.skip = 0

        def handle_starttag(self, tag, attrs):
            tag = tag.lower().split(":")[-1]
            if tag in SKIP_TAGS:
                self.skip += 1
            elif tag in BLOCK_TAGS:
                self.buf.append("\n")

        def handle_startendtag(self, tag, attrs):
            tag = tag.lower().split(":")[-1]
            if tag in BLOCK_TAGS and tag not in SKIP_TAGS:
                self.buf.append("\n")

        def handle_endtag(self, tag):
            tag = tag.lower().split(":")[-1]
            if tag in SKIP_TAGS:
                self.skip = max(0, self.skip - 1)
            elif tag in BLOCK_TAGS:
                self.buf.append("\n")

        def handle_data(self, d):
            if not self.skip:
                self.buf.append(d)

    p = P()
    try:
        p.feed(data)
        p.close()
    except Exception:
        pass
    lines = []
    for ln in "".join(p.buf).split("\n"):
        ln = re.sub(r"[ \t\r\f\v]+", " ", ln).strip()
        if ln:
            lines.append(ln)
    return "\n".join(lines)


def extract_epub(z):
    names = [n for n in z.namelist() if re.search(r"\.(x?html?)$", n, re.I)]
    names.sort(key=natural_key)
    out = []
    for n in names:
        base = os.path.basename(n).lower()
        data = zread(z, n).decode("utf-8", "replace")
        if re.match(r"(nav|toc)\.x?html?$", base):
            continue
        t = html_text(data)
        if t.strip():
            out.append(t)
    return "\n".join(out)


def extract_ipynb(data):
    try:
        nb = json.loads(data.decode("utf-8-sig", "replace"))
    except Exception:
        return ""
    if not isinstance(nb, dict) or not isinstance(nb.get("cells"), list):
        return ""
    out = []
    for c in nb["cells"]:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, list) and all(isinstance(x, str) for x in src):
            src = "".join(src)
        if not isinstance(src, str):
            continue
        if src.strip():
            out.append(src.strip("\n"))
    return "\n\n".join(out)


def extract_zip(ext, data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        raise Fail("cannot read input: not a readable zip archive (%s)" % e)
    try:
        if ext in (".docx", ".docm"):
            t = extract_docx(z)
        elif ext in (".pptx", ".pptm"):
            t = extract_pptx(z)
        elif ext in (".xlsx", ".xlsm"):
            t = extract_xlsx(z)
        elif ext in (".odt", ".odp", ".ods"):
            t = extract_odf(z)
        else:
            t = extract_epub(z)
    except Fail:
        raise
    except Exception:
        t = ""
    return t.strip()


def load_input(path):
    """Return (text, by_line) where by_line says paragraphs are line separated."""
    if path is None:
        data = sys.stdin.buffer.read()
        return decode_bytes(data), False
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, "rb") as f:
            data = f.read()
    except Exception as e:
        raise Fail("cannot read input: %s" % (getattr(e, "strerror", None) or e))
    if ext in NO_TEXT_EXT:
        return "", False
    if ext in ZIP_EXT:
        return extract_zip(ext, data), True
    if ext in NB_EXT:
        return extract_ipynb(data).strip(), False
    return decode_bytes(data), False


# ----------------------------------------------------------------------------
# Character layer
# ----------------------------------------------------------------------------

INVIS_RANGES = [
    (0x0000, 0x0008), (0x000B, 0x000C), (0x000E, 0x001F), (0x007F, 0x009F),
    (0x00AD, 0x00AD), (0x034F, 0x034F), (0x061C, 0x061C), (0x115F, 0x1160),
    (0x17B4, 0x17B5), (0x180B, 0x180F), (0x200B, 0x200F), (0x202A, 0x202E),
    (0x2060, 0x206F), (0x3164, 0x3164), (0xFE00, 0xFE0F), (0xFEFF, 0xFEFF),
    (0xFFA0, 0xFFA0), (0xFFF0, 0xFFFB), (0x1BCA0, 0x1BCA3), (0x1D173, 0x1D17A),
    (0xE0000, 0xE0FFF),
]
SPACE_CPS = [0x00A0, 0x1680] + list(range(0x2000, 0x200B)) + [0x2028, 0x2029, 0x202F, 0x205F, 0x3000]


def _cls(ranges):
    out = []
    for a, b in ranges:
        if a == b:
            out.append("\\U%08x" % a)
        else:
            out.append("\\U%08x-\\U%08x" % (a, b))
    return "".join(out)


INVIS_RE_CLASS = _cls(INVIS_RANGES)
SPACE_RE_CLASS = "".join("\\U%08x" % c for c in SPACE_CPS)
INVIS_SET_LOOKUP = None


def is_invis(cp):
    for a, b in INVIS_RANGES:
        if a <= cp <= b:
            return True
    return False


# lookalike letters -> ASCII
LOOK = {}
for _s, _t in (
    # Cyrillic lowercase
    ("а", "a"), ("с", "c"), ("е", "e"), ("о", "o"), ("р", "p"), ("х", "x"), ("у", "y"),
    ("і", "i"), ("ј", "j"), ("ѕ", "s"), ("ԁ", "d"), ("һ", "h"), ("ԝ", "w"), ("ԛ", "q"),
    ("ӏ", "l"), ("ν", "v"),
    # Cyrillic uppercase
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"), ("Ј", "J"),
    ("К", "K"), ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"), ("Т", "T"), ("Х", "X"),
    ("У", "Y"),
    # Greek
    ("ο", "o"), ("υ", "u"), ("ι", "i"), ("ρ", "p"), ("α", "a"), ("γ", "y"), ("κ", "k"),
    ("Α", "A"), ("Β", "B"), ("Ε", "E"), ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"),
    ("Μ", "M"), ("Ν", "N"), ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Υ", "Y"), ("Χ", "X"),
    # Armenian
    ("օ", "o"), ("ո", "n"), ("ս", "u"), ("ց", "g"), ("հ", "h"), ("ԑ", "e"), ("Օ", "O"),
    ("Ս", "U"), ("Տ", "S"), ("Ձ", "Z"),
):
    LOOK[_s] = _t
LOOK_RE = re.compile("[" + "".join(LOOK) + "]")
RUN_RE = re.compile(r"[^\W\d_]+")

RTL_RE = re.compile("[֐-ࣿיִ-﷿ﹰ-﻾]")

THAI_LIKE = [(0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x19E0, 0x19FF),
             (0x3040, 0x30FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF),
             (0x20000, 0x2FFFF), (0x31F0, 0x31FF)]
JOINING = [(0x0590, 0x08FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF),
           (0xFB1D, 0xFDFF), (0xFE70, 0xFEFE)]
KHMER = (0x1780, 0x17FF)
MONGOLIAN = (0x1800, 0x18AF)
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF), (0x2E80, 0x2FDF), (0x3005, 0x3007)]


def in_ranges(cp, ranges):
    for a, b in ranges:
        if a <= cp <= b:
            return True
    return False


def is_emoji_or_symbol(ch):
    cp = ord(ch)
    if cp >= 0x1F000 and cp <= 0x1FAFF:
        return True
    if 0x2190 <= cp <= 0x2BFF:
        return True
    if ch in "©®™‼⁉":
        return True
    return unicodedata.category(ch)[0] == "S"


CAND_RE = re.compile("[" + INVIS_RE_CLASS + SPACE_RE_CLASS + "]")
NBSP_BEFORE = set(":;!?»›%€")
NBSP_AFTER = set("«‹")


def char_decisions(text):
    """Return list of (pos, kind, replacement). kind: 'i' invisible removed, 's' space normalised.
    Only characters that are counted/changed are returned."""
    out = []
    n = len(text)
    has_rtl = None
    # emoji tag sequences: base 1F3F4 + tags + E007F
    keep_tags = set()
    for m in re.finditer("\U0001F3F4([\U000E0020-\U000E007E]+)\U000E007F", text):
        for k in range(m.start() + 1, m.end()):
            keep_tags.add(k)
    for m in CAND_RE.finditer(text):
        i = m.start()
        ch = text[i]
        cp = ord(ch)
        if cp in (0x2028, 0x2029):
            out.append((i, "s", "\n"))
            continue
        if not is_invis(cp):
            # space separator
            if cp in (0xA0, 0x202F):
                prv = text[i - 1] if i > 0 else ""
                nxt = text[i + 1] if i + 1 < n else ""
                if (prv.isdigit() or nxt.isdigit() or nxt in NBSP_BEFORE and nxt != ""
                        or prv in NBSP_AFTER and prv != ""):
                    continue
            out.append((i, "s", " "))
            continue
        # invisible
        prv = text[i - 1] if i > 0 else ""
        nxt = text[i + 1] if i + 1 < n else ""
        keep = False
        if 0xE0000 <= cp <= 0xE0FFF:
            keep = i in keep_tags
            if not keep and 0xE0100 <= cp <= 0xE01EF:
                keep = bool(prv) and (in_ranges(ord(prv), CJK) or is_emoji_or_symbol(prv))
        elif 0xFE00 <= cp <= 0xFE0F:
            if nxt == "⃣":
                keep = True
            elif prv and (in_ranges(ord(prv), CJK) or is_emoji_or_symbol(prv)):
                keep = True
        elif cp == 0x200B:
            keep = (prv and in_ranges(ord(prv), THAI_LIKE)) or (nxt and in_ranges(ord(nxt), THAI_LIKE))
            keep = bool(keep)
        elif cp == 0x00AD:
            keep = bool(prv and nxt and prv.isalpha() and nxt.isalpha())
        elif cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
            if has_rtl is None:
                has_rtl = RTL_RE.search(text) is not None
            keep = has_rtl
        elif 0x180B <= cp <= 0x180F:
            keep = bool(prv) and MONGOLIAN[0] <= ord(prv) <= MONGOLIAN[1]
        elif cp in (0x17B4, 0x17B5):
            keep = (prv and KHMER[0] <= ord(prv) <= KHMER[1]) or (nxt and KHMER[0] <= ord(nxt) <= KHMER[1])
            keep = bool(keep)
        elif cp in (0x200C, 0x200D):
            j = i - 1
            while j >= 0 and (0xFE00 <= ord(text[j]) <= 0xFE0F or 0xE0020 <= ord(text[j]) <= 0xE007F):
                j -= 1
            p2 = text[j] if j >= 0 else ""
            k = i + 1
            while k < n and 0xFE00 <= ord(text[k]) <= 0xFE0F:
                k += 1
            n2 = text[k] if k < n else ""
            for c in (p2, n2):
                if not c:
                    continue
                if in_ranges(ord(c), JOINING) and c.isalpha():
                    keep = True
                elif is_emoji_or_symbol(c) and not c.isalpha():
                    keep = True
        if not keep:
            out.append((i, "i", ""))
    return out


def homoglyph_map(text):
    """pos -> ascii replacement for lookalikes inside mixed runs."""
    res = {}
    done = -1
    n = len(text)
    for m in LOOK_RE.finditer(text):
        p = m.start()
        if p < done:
            continue
        s = p
        while s > 0 and not text[s - 1].isspace():
            s -= 1
        e = p
        while e < n and not text[e].isspace():
            e += 1
        done = e
        tok = text[s:e]
        for rm in RUN_RE.finditer(tok):
            run = rm.group()
            has_ascii = False
            has_look = False
            bad = False
            for c in run:
                if c in LOOK:
                    has_look = True
                elif ord(c) < 128:
                    has_ascii = True
                else:
                    bad = True
                    break
            if has_ascii and has_look and not bad:
                for k, c in enumerate(run):
                    if c in LOOK:
                        res[s + rm.start() + k] = LOOK[c]
    return res


def clean_text(text):
    crlf = "\r\n" in text
    if crlf:
        text = text.replace("\r\n", "\n")
    dec = char_decisions(text)
    hm = homoglyph_map(text)
    edits = {}
    for p, k, r in dec:
        edits[p] = r
    for p, r in hm.items():
        if p not in edits:
            edits[p] = r
    if edits:
        parts = []
        last = 0
        for p in sorted(edits):
            parts.append(text[last:p])
            parts.append(edits[p])
            last = p + 1
        parts.append(text[last:])
        text = "".join(parts)
    ended_nl = text.endswith("\n")
    text = "\n".join(ln.rstrip(" \t") for ln in text.split("\n"))
    text = re.sub(r"\A(?:[ \t]*\n)+", "", text)
    text = text.rstrip()
    if ended_nl and text:
        text += "\n"
    if crlf:
        text = text.replace("\n", "\r\n")
    return text


# ----------------------------------------------------------------------------
# Markup masking
# ----------------------------------------------------------------------------

FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
LIST_RE = re.compile(r"^\s*(?:[-*+]|\d{1,9}[.)])\s+")
HEAD_RE = re.compile(r"^ {0,3}#{1,6}(?:\s+|$)")
HR_RE = re.compile(r"^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$")
BADGE_RE = re.compile(r"^\s*(?:\[!\[[^\]\n]*\](?:\([^)\n]*\)|\[[^\]\n]*\])\](?:\([^)\n]*\)|\[[^\]\n]*\])\s*)+$")
TABLE_DELIM_RE = re.compile(r"^\s*\|?\s*:?-{1,}:?\s*(?:\|\s*:?-{1,}:?\s*)+\|?\s*$")


def mask_markup(text):
    """Return text of same length with non-prose regions blanked (newlines kept)."""
    lines = text.split("\n")
    n = len(lines)
    mask = [False] * n
    i = 0
    # YAML front matter
    if lines and lines[0].rstrip() == "---":
        for j in range(1, n):
            if lines[j].rstrip() in ("---", "..."):
                for k in range(0, j + 1):
                    mask[k] = True
                i = j + 1
                break
    in_fence = None
    prev_para = False  # previous line is paragraph text
    prev_blank = True
    in_code_indent = False
    in_list = False
    k = i
    while k < n:
        ln = lines[k]
        stripped = ln.strip()
        if in_fence:
            mask[k] = True
            m = FENCE_RE.match(ln)
            if m and m.group(1)[0] == in_fence[0] and len(m.group(1)) >= in_fence[1] and not m.group(2).strip():
                in_fence = None
                prev_para = False
                prev_blank = True
            k += 1
            continue
        m = FENCE_RE.match(ln)
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            in_fence = (m.group(1)[0], len(m.group(1)))
            mask[k] = True
            in_code_indent = False
            k += 1
            continue
        if not stripped:
            prev_blank = True
            prev_para = False
            k += 1
            continue
        indented = ln.startswith("    ") or ln.startswith("\t")
        if indented and not prev_para and not (in_list and not prev_blank):
            if not in_list or prev_blank is False:
                pass
        if indented and not prev_para and not in_list:
            mask[k] = True
            in_code_indent = True
            prev_blank = False
            k += 1
            continue
        if indented and in_code_indent and prev_blank:
            mask[k] = True
            prev_blank = False
            k += 1
            continue
        in_code_indent = False
        if LIST_RE.match(ln):
            in_list = True
        elif not indented and prev_blank:
            in_list = False
        prev_para = not (HEAD_RE.match(ln) or HR_RE.match(ln))
        prev_blank = False
        k += 1
    # blockquote runs
    k = 0
    while k < n:
        if not mask[k] and re.match(r"^ {0,3}>", lines[k]):
            j = k
            while j < n and not mask[j] and re.match(r"^ {0,3}>", lines[j]):
                j += 1
            if j - k >= 2:
                for t in range(k, j):
                    mask[t] = True
            k = j
        else:
            k += 1
    # tables and badges
    for k in range(n):
        if mask[k]:
            continue
        ln = lines[k]
        if BADGE_RE.match(ln):
            mask[k] = True
        elif re.match(r"^\s*\|", ln) or (TABLE_DELIM_RE.match(ln) and "-" in ln and "|" in ln):
            mask[k] = True
    for k in range(1, n):
        if not mask[k] and TABLE_DELIM_RE.match(lines[k]) and "|" in lines[k]:
            mask[k] = True
    for k in range(1, n):
        if mask[k] and TABLE_DELIM_RE.match(lines[k]) and not mask[k - 1] and "|" in lines[k - 1]:
            mask[k - 1] = True
            j = k + 1
            while j < n and not mask[j] and "|" in lines[j] and lines[j].strip():
                mask[j] = True
                j += 1
    out = []
    for k in range(n):
        out.append(re.sub(r"[^\n]", " ", lines[k]) if mask[k] else lines[k])
    res = "\n".join(out)
    # inline code spans
    if "`" in res:
        runs = [(m.start(), m.end()) for m in re.finditer(r"`+", res)]
        nxt = [None] * len(runs)
        last = {}
        for idx in range(len(runs) - 1, -1, -1):
            ln_ = runs[idx][1] - runs[idx][0]
            nxt[idx] = last.get(ln_)
            last[ln_] = idx
        chars = None
        idx = 0
        while idx < len(runs):
            j = nxt[idx]
            if j is not None and "\n\n" not in res[runs[idx][1]:runs[j][0]]:
                if chars is None:
                    chars = list(res)
                for p in range(runs[idx][0], runs[j][1]):
                    if chars[p] != "\n":
                        chars[p] = " "
                idx = j + 1
            else:
                idx += 1
        if chars is not None:
            res = "".join(chars)
    return res


# ----------------------------------------------------------------------------
# Text helpers
# ----------------------------------------------------------------------------

WORD_RE = re.compile(r"[\w'’-]+")
ABBREV = {"mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "inc", "ltd", "co",
          "e.g", "i.e", "fig", "no", "approx", "cf", "al"}


def count_words(s):
    return sum(1 for w in WORD_RE.findall(s) if any(c.isalnum() for c in w))


def words_of(s):
    return [w for w in WORD_RE.findall(s) if any(c.isalnum() for c in w)]


def md_clean(line):
    line = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", line)
    line = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", line)
    line = re.sub(r"<[^>\n]+>", " ", line)
    line = re.sub(r"^\s*(?:#{1,6}\s+|>+\s*|(?:[-*+]|\d{1,9}[.)])\s+)", "", line)
    line = line.replace("**", "").replace("__", "")
    return line


def split_sentences(s):
    out = []
    start = 0
    n = len(s)
    for m in re.finditer(r"[.!?]+[\"'”’)\]]*(?:\s+|$)", s):
        end = m.end()
        nxt = s[end:end + 1]
        if nxt and not (nxt.isupper() or nxt.isdigit() or nxt in "\"'“‘([*_#"):
            if not m.group().rstrip().endswith(("?", "!")):
                continue
        before = s[start:m.start()]
        last = re.findall(r"[A-Za-z.]+$", before)
        if last and m.group().startswith(".") and last[0].lower().rstrip(".") in ABBREV and nxt:
            continue
        seg = s[start:end].strip()
        if seg:
            out.append(seg)
        start = end
    tail = s[start:].strip()
    if tail:
        out.append(tail)
    return out


class Doc(object):
    """Structural view of masked text."""

    def __init__(self, atext, by_line):
        self.text = atext
        lines = atext.split("\n")
        self.lines = lines
        paras = []
        cur = []
        for ln in lines:
            if ln.strip() == "":
                if cur:
                    paras.append(cur)
                    cur = []
            elif by_line:
                if cur:
                    paras.append(cur)
                cur = [ln]
            else:
                cur.append(ln)
        if cur:
            paras.append(cur)
        self.paras = paras
        self.has_heading = any(HEAD_RE.match(l) for l in lines)
        # prose paragraphs: not all headings
        self.prose = []
        for p in paras:
            body = [l for l in p if not HEAD_RE.match(l) and not HR_RE.match(l)]
            if body:
                self.prose.append(body)
        # sentences per prose paragraph
        self.para_sents = []
        for p in self.prose:
            pieces = []
            cur = []
            for l in p:
                if LIST_RE.match(l):
                    if cur:
                        pieces.append(" ".join(cur))
                        cur = []
                    pieces.append(md_clean(l))
                else:
                    cur.append(md_clean(l).strip())
            if cur:
                pieces.append(" ".join(cur))
            sents = []
            for pc in pieces:
                sents.extend(split_sentences(pc.strip()))
            self.para_sents.append([s for s in sents if count_words(s) > 0])
        self.sentences = [s for ps in self.para_sents for s in ps]


def cv(vals):
    m = sum(vals) / float(len(vals))
    if m == 0:
        return 0.0
    var = sum((v - m) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / m


# ----------------------------------------------------------------------------
# Lexicon
# ----------------------------------------------------------------------------

A = "['’]"


def infl(w):
    if w.endswith("e"):
        return w[:-1] + "(?:e|es|ed|ing)"
    if w.endswith("y") and len(w) > 2 and w[-2] not in "aeiou":
        return w[:-1] + "(?:y|ies|ied|ying)"
    return w + "(?:s|es|ed|ing)?"


AI_VERBS = ["garner", "bolster", "foster", "showcase", "underscore", "emphasize", "enhance",
            "leverage", "utilize", "facilitate", "encompass", "harness", "navigate", "embark",
            "craft", "elevate", "empower", "unlock", "delve", "emphasise", "utilise"]
AI_NOUNS = ["tapestry", "testament", "intricacy", "interplay", "paradigm", "plethora",
            "landscape", "journey", "realm", "myriad", "intricacies"]
AI_ADJS = ["crucial", "pivotal", "vibrant", "meticulous", "intricate", "enduring", "holistic",
           "transformative", "unprecedented", "robust", "seamless", "multifaceted"]


def build_ai_vocab():
    alts = [infl(w) for w in AI_VERBS]
    alts += [infl(w) for w in AI_NOUNS]
    alts += [w + "(?:ly)?" for w in AI_ADJS]
    alts += ["additionally", "align(?:s|ed|ing)?\\s+with",
             "captur(?:e|es|ed|ing)\\s+the\\s+(?:essence|spirit|imagination|heart|magic)"]
    return r"\b(?:" + "|".join(alts) + r")\b"


RX = {}
RX["ai_vocab"] = build_ai_vocab()

DIALECT = [
    r"\bgenuinely\b", r"\bfascinating\b", r"\bnuanced?\b", r"\bthoughtfully\b",
    r"\brefreshingly\b", r"\bstrikingly\b", r"\bcompellingly\b",
    r"\bquietly\s+(?:powerful|profound|radical)\b",
    r"\bdeeply\s+(?:human|personal|felt|unsettling)\b",
    r"\bresonat(?:e|es|ed|ing)\s+deeply\b",
    r"\bgame[- ]chang(?:er|ers|ing)\b",
    r"\bsupercharg(?:e|es|ed|ing)\b", r"\bskyrocket(?:s|ed|ing)?\b",
    r"\bturbocharg(?:e|es|ed|ing)\b", r"\brevoluti[sz](?:e|es|ed|ing)\b",
    r"\bdoubl(?:e|es|ed|ing)\s+down\s+on\b",
    r"\bdiv(?:e|es|ed|ing)\s+deep(?:er)?\s+into\b",
    r"\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b",
    r"\btak(?:e|es|ing)\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level\b",
]

PROMO = [
    r"\bnestled\b", r"\bbreathtaking\b", r"\bmust-visit\b", r"\bstunning\b", r"\bpicturesque\b",
    r"\bcharming\b", r"\bidyllic\b", r"\bvibrant\s+community\b", r"\brich\s+cultural\s+heritage\b",
    r"\bin\s+the\s+heart\s+of\b", r"\bworld-class\b", r"\btop-tier\b", r"\bunparalleled\b",
    r"\bpremier\b", r"\bleading\b", r"\besteemed\s+organi[sz]ation\b", r"\bvaluable\s+asset\b",
    r"\bpassion\s+for\s+excellence\b", r"\bproven\s+track\s+record\b", r"\bresults-oriented\b",
    r"\bwealth\s+of\s+experience\b", r"\bdynamic\s+team\b", r"\bfast-paced\s+environment\b",
    r"\bdeeply\s+passionate\b", r"\bperfectly\s+situated\b", r"\b(?:close|tight)-knit\s+team\b",
    r"\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b", r"\bI" + A + r"m\s+excited\s+to\s+(?:apply|bring)\b",
    r"\buniquely\s+positioned\s+to\b",
]
PROMO_VERBS = {"install", "join", "grab", "download", "try", "discover", "experience", "escape",
               "transform", "reclaim", "unlock", "elevate", "boost", "say", "imagine", "explore",
               "meet", "introducing", "upgrade", "claim", "unleash", "supercharge", "level",
               "stop", "start"}

HYPH_PAIRS = (
    "cutting-edge|state-of-the-art|best-in-class|results-driven|data-driven|forward-thinking|"
    "customer-centric|fast-paced|game-changing|ever-evolving|well-rounded|detail-oriented|"
    "high-quality|award-winning|mission-critical|user-friendly|next-generation|industry-leading|"
    "cross-functional|end-to-end|thought-provoking|ground-breaking|groundbreaking|deeply-rooted|"
    "far-reaching|time-tested|tried-and-true|value-added|results-focused|team-oriented|"
    "self-motivated|highly-motivated|big-picture|full-service|top-notch|fast-growing|"
    "rapidly-evolving|future-proof|world-renowned|hard-working|results-oriented|people-first|"
    "mission-driven|solution-oriented|client-focused|best-of-breed|game-changer|one-stop|"
    "cutting-edge|decision-making|problem-solving|team-player"
)

SYN = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "organisation", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]


def plural_rx(w):
    if w.endswith("y") and w[-2] not in "aeiou":
        return w[:-1] + "(?:y|ies)"
    if w.endswith(("s", "x", "ch", "sh")):
        return w + "(?:es)?"
    if w == "analysis":
        return "analys[ie]s"
    return w + "s?"


SYN_RX = [[re.compile(r"\b" + plural_rx(w).replace(" ", r"\s+") + r"\b", re.I) for w in cl] for cl in SYN]

PLACE_WORDS = (r"(?:the\s+)?(?:person|company|client|place|source|name|full\s+name|first\s+name|last\s+name|"
               r"recipient|hiring\s+manager|employer|organi[sz]ation|city|location|address|position|job\s+title|"
               r"business|customer|contact|country|state|website|url|link)")

# (key, num, label, weight, [patterns], flags)
LEX = []


def lex(key, num, label, weight, pats, flags=re.I, min_hits=1):
    if isinstance(pats, str):
        pats = [pats]
    LEX.append((key, num, label, weight, [re.compile(p, flags) for p in pats], min_hits))


lex("ai_vocabulary", 1, "AI vocabulary", 12, RX["ai_vocab"])
lex("model_dialect", 2, "Model-dialect vocabulary", 10, DIALECT, re.I, 2)
lex("promotional_language", 3, "Promotional language", 10, PROMO)
lex("hyphenated_pairs", 4, "Hyphenated word-pair overuse", 0, r"\b(?:" + HYPH_PAIRS + r")\b")
lex("simple_yet", 5, "\"Simple yet X\" cliche", 8,
    r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
lex("significance_inflation", 10, "Significance inflation", 12, [
    r"\b(?:stand|stands|stood|standing|serve|serves|served|serving)\s+as\s+(?:a|an|the)\s+(?:\w+\s+){0,2}?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor|highlight)(?:e|es|ed|ing|s)\s+(?:its|the|their|his|her)\s+(?:\w+\s+)?(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymboli[sz](?:es|ed|ing)\b",
    r"\bset(?:s|ting)?\s+the\s+stage\s+for\b",
    r"\bleft\s+an\s+indelible\s+mark\b",
    r"\bplay(?:s|ed|ing)?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\bhave?\s+(?:shaped|sparked)\b",
    r"\bhas\s+come\s+to\s+(?:define|symbolize|symbolise)\b",
])
lex("vague_attributions", 12, "Vague attributions", 10, [
    r"\b(?:industry\s+)?experts\s+(?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry\s+(?:reports|observers|analysts)\b",
    r"\bobservers\s+have\s+(?:cited|noted)\b",
    r"\bsome\s+critics\s+argue\b", r"\bresearchers\s+have\s+found\b", r"\bstudies\s+suggest\b",
    r"\bit\s+is\s+widely\s+believed\b",
])
lex("article_title_proper_noun", 13, "Article title as proper noun", 12,
    r"\b[Tt]he (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of (?:[^\s.!?]+\s+){1,10}?(?:is|are) (?:a|an|the)\b", 0)
lex("ecosystem_padding", 14, "Conservation / ecosystem padding", 10, [
    r"\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves\s+as\s+an\s+indicator\s+species\b", r"\bcontributes?\s+to\s+biodiversity\b",
])
lex("false_ranges", 15, "False ranges", 10,
    r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
lex("ing_tails", 16, "Superficial -ing tail clauses", 10,
    r",\s+(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomi[sz]ing)\b")
lex("negative_parallelism", 17, "Negative parallelism", 0, [
    r"\bit" + A + r"s\s+not\s+(?:just|merely)\s+(?:about|a|an)\b",
    r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn" + A + r"t\s+just\b[^,.]{0,40}?\bit\b",
])
lex("tailing_negation", 17, "Tailing negation", 10,
    r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")
lex("not_x_just_y", 18, "\"Not X, just Y\" construction", 10, [
    r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+",
    r"\b(?:not|isn" + A + r"t|aren" + A + r"t|wasn" + A + r"t|weren" + A + r"t)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+(?:,|\s*[—–]|\s+-{1,2})\s*(?:it" + A + r"s|it\s+is|it\s+was|they" + A + r"re|they\s+are|they\s+were|that" + A + r"s|but)\b",
])
lex("filler_phrases", 19, "Filler phrases", 0,
    r"\b(?:in\s+order\s+to|due\s+to\s+the\s+fact\s+that|at\s+this\s+point\s+in\s+time|in\s+the\s+event\s+that|has\s+the\s+ability\s+to|it\s+is\s+important\s+to\s+note\s+that|it\s+should\s+be\s+mentioned\s+that|needless\s+to\s+say)\b")
lex("empty_pivots", 20, "Empty pivot phrases", 10, [
    r"\bit(?:" + A + r"s|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b",
    r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b",
    r"\bit\s+is\s+interesting\s+to\s+note\s+that\b", r"\ba\s+key\s+consideration\s+is\b",
    r"\ba\s+point\s+to\s+highlight\s+is\b",
])
lex("outcome_speculation", 21, "Outcome-speculation tails", 10,
    r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b")
lex("authority_tropes", 22, "Persuasive authority tropes", 0, [
    r"\bhere" + A + r"s\s+the\s+thing\b", r"\bmake\s+no\s+mistake\b", r"\bthe\s+truth\s+is\b",
    r"\blet" + A + r"s\s+be\s+honest\b", r"\bthe\s+simple\s+fact\s+is\b", r"\bat\s+its\s+core\b",
    r"\bwhat\s+really\s+matters\b", r"\bmore\s+than\s+anything\b", r"\bat\s+the\s+end\s+of\s+the\s+day\b",
    r"\bthe\s+bottom\s+line\s+is\b", r"\bin\s+reality\b", r"\bfundamentally,",
    r"\bthe\s+real\s+question\s+is\b", r"\bthe\s+heart\s+of\s+the\s+matter\b",
    r"\bthe\s+deeper\s+issue\b", r"\bwhen\s+you\s+get\s+down\s+to\s+it\b",
    r"\bwhen\s+all\s+is\s+said\s+and\s+done\b",
])
lex("editorial_interjections", 23, "Editorial interjections", 8, [
    r"\bit(?:" + A + r"s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b",
    r"\bone\s+must\s+note\s+that\b", r"\bit\s+is\s+worth\s+pointing\s+out\b",
    r"\bit\s+cannot\s+be\s+overstated\s+that\b", r"\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b",
])
lex("self_thoroughness", 24, "Self-thoroughness phrases", 8, [
    r"\bthis\s+(?:comprehensive|in-depth|complete|thorough)\s+(?:guide|overview|analysis|look|examination)\b",
    r"\ba\s+thorough\s+examination\s+of\b", r"\beverything\s+you\s+need\s+to\s+know\s+about\b",
])
lex("concrete_evidence", 26, "\"Concrete evidence\" defense phrase", 8, [
    r"\bwithout\s+concrete\s+evidence\b", r"\bdo\s+you\s+have\s+concrete\s+evidence\b",
    r"\bI\s+(?:would\s+|" + A + r"d\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b",
    r"\babsent\s+concrete\s+proof\b", r"\bprovide\s+concrete\s+evidence\b",
])
lex("intro_hooks", 27, "Compulsive intro hooks", 10, [
    r"\bin\s+today" + A + r"s\s+(?:[\w-]+\s+){0,2}?(?:world|landscape|environment|market)\b",
    r"\bin\s+a\s+world\s+where\b", r"\bin\s+an\s+era\s+of\b", r"\bin\s+recent\s+years,",
    r"\bmore\s+than\s+ever\s+before\b", r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b",
    r"\b(?:great|exciting|big)\s+news\s*[!:]",
    r"\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]{0,100}\?",
    r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b",
])
lex("diff_anchored", 30, "Diff-anchored writing", 8, [
    r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b",
    r"\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b",
    r"\bpreviously\b[^.!?\n]{0,120}?\bnow\b",
    r"\b(?:wasn" + A + r"t|weren" + A + r"t)\s+there\s+before\b",
    r"\b(?:we" + A + r"ve|we\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
])
lex("signposting", 31, "Signposting and announcements", 10, [
    r"\blet" + A + r"s\s+(?:dive|delve|explore)\b", r"\blet" + A + r"s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere" + A + r"s\s+what\s+you\s+need\s+to\s+know\b", r"\bwithout\s+further\s+ado\b",
    r"\bnow\s+let" + A + r"s\s+look\s+at\b", r"\bbuckle\s+up\b", r"\bstay\s+with\s+me\b",
    r"\bready\s+to\s+dive\s+in\b",
])
lex("cataloguing_leadins", 32, "Cataloguing lead-ins", 8, [
    r"\b(?:used|uses|employs|employed|relied\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+",
    r"(?:^|[.!?]\s+)These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insights?|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains?|becomes?)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b",
], re.I | re.M)
lex("inline_header_lists", 33, "Inline-header vertical lists", 6,
    r"^[ \t]*(?:(?:[-*+]|\d{1,9}[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", re.M)
lex("formulaic_challenges", 36, "Formulaic challenges sections", 10, [
    r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b",
    r"\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b",
    r"\bcontinues\s+to\s+thrive\b", r"\btypical\s+of\s+(?:emerging|urban|modern)\b",
    r"\bfaces\s+(?:several|many|numerous)\s+challenges\b",
])
lex("compulsive_conclusions", 38, "Compulsive conclusion phrases", 10,
    r"^[ \t>*_#-]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+summarise|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b",
    re.I | re.M)
lex("generic_positive_conclusions", 39, "Generic positive conclusions", 10, [
    r"\bthe\s+future\s+looks\s+bright\b", r"\bexciting\s+times\s+lie\s+ahead\b",
    r"\bjourney\s+toward\s+excellence\b", r"\bstep\s+in\s+the\s+right\s+direction\b",
    r"\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b",
    r"\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b",
])
lex("chatbot_artifacts", 47, "Chatbot artifacts", 14, [
    r"\bI\s+hope\s+this\s+helps\b", r"\bCertainly!", r"\bOf\s+course!", r"\blet\s+me\s+know\s+if\s+you\b",
    r"\bwould\s+you\s+like\s+me\s+to\b", r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b",
    r"\bhappy\s+to\s+help\s*(?:[.!?]|$)",
    r"\b(?:here|below)\s+(?:is|are)\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere(?:" + A + r"s|\s+are)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
    r"\bhere\s+(?:is|" + A + r"s)\s+a\s+draft\b", r"\bhere" + A + r"s\s+a\s+draft\b",
    r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r"\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b",
    r"\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b",
    r"\bto\s+(?:answer|address)\s+your\s+question\b", r"\bin\s+(?:response|answer)\s+to\s+your\s+question\b",
    r"\byour\s+question\s+(?:about|regarding|concerning)\b",
    r"\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b",
    r"\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b",
])
lex("sycophantic_tone", 48, "Sycophantic tone", 14, [
    r"\byou(?:" + A + r"re|\s+are)\s+absolutely\s+right\b",
    r"\b(?:great\s+question|excellent\s+point)\s*[!.,]",
    r"\bwhat\s+an?\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b",
    r"\bthat" + A + r"s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b",
])
lex("knowledge_cutoff", 50, "Knowledge-cutoff disclaimers", 14, [
    r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b", r"\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b",
    r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b",
    r"\bbased\s+on\s+(?:the\s+)?available\s+information\b", r"\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b",
    r"\bmaintains\s+a\s+low\s+profile\b", r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b",
])
lex("copula_avoidance", 51, "Copula avoidance", 10, [
    r"\b(?:serve|serves|served|serving|stand|stands|stood|standing|function|functions|functioned|functioning|act|acts|acted|acting)\s+as\b",
    r"\brepresents?\s+(?:a|the)\b", r"\bmarks\s+(?:a|the)\b", r"\bboasts\b",
    r"\bfeatures\s+(?:a|an|the|\d[\d,]*|several|many|numerous|multiple|various|some|two|three|four|five|six|seven|eight|nine|ten|dozens|hundreds)\b",
    r"\boffers\s+a\b", r"\brefers\s+to\b",
])
lex("canonical_marketing_slop", 69, "Canonical marketing-slop phrases", 12, [
    r"\bunlock(?:s|ed|ing)?\s+(?:its|their|your|the|our)?\s*full\s+potential\b",
    r"\bnavigat(?:e|es|ed|ing)\s+the\s+complexit(?:y|ies)\b",
    r"\ba\s+testament\s+to\s+the\s+(?:power|importance)\b",
    r"\bstay(?:s|ed|ing)?\s+ahead\s+of\s+the\s+curve\b",
    r"\bturn(?:s|ed|ing)?\s+challenges\s+into\s+opportunities\b",
    r"\btak(?:e|es|ing)\s+(?:it|them|this|your\s+\w+|their\s+\w+)\s+to\s+the\s+next\s+level\b",
    r"\bharness(?:es|ed|ing)?\s+the\s+power\s+of\b", r"\bpav(?:e|es|ed|ing)\s+the\s+way\s+for\b",
    r"\bsaying\s+goodbye\s+to\b", r"\bimagin(?:e|ing)\s+a\s+world\s+where\b",
    r"\bin\s+the\s+ever-evolving\b", r"\bat\s+the\s+forefront\s+of\b",
    r"\bunleash(?:es|ed|ing)?\s+the\s+(?:power|potential)\b",
    r"\byour\s+one-stop\s+(?:shop|solution)\b", r"\bbridg(?:e|es|ing)\s+the\s+gap\b",
    r"\bwhether\s+you" + A + r"re\s+a\b[^.!?\n]{0,60}?\bor\s+a\b",
])
lex("placeholder_text", 63, "Placeholder / Mad-Libs text", 14, [
    r"\{\{[^{}\n]{1,80}\}\}", r"(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])", r"\blorem\s+ipsum\b",
])
lex("chat_markup_leak", 64, "Chatbot reference-markup leak", 14, [
    r"\bcite(?:turn|start|nav)\w*", r"\boai_citation\w*", r"contentReference", r"\bnavlist\b",
    r"【\d+†[^】\n]*】",
])
lex("notability_name_dropping", 11, "Notability name-dropping", 8, [
    r"\b(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*(?:\s*,\s*(?:(?i:and|or)\s+)?|\s+(?i:and|or)\s+)[A-Z][\w&.'’-]*",
    r"\b\d[\d,.]*[kKmM]?\+?\s+(?:followers|subscribers)\b",
    r"\b(?:strong|active|robust|growing|significant)\s+(?:online|digital|social[- ]media)\s+presence\b",
    r"\b(?:widely\s+covered|covered\s+widely|independent\s+coverage)\b",
], 0)
lex("decorative_rules_dummy", 0, "", 0, [r"(?!x)x"])
LEX = [e for e in LEX if e[1] != 0]

AI_UTM_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai",
                "gemini.google.com", "copilot.microsoft.com", "poe.com"}

DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
TRANSITIONS = r"(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)"
TRANS_RE = re.compile(r"(?:^|[.!?][\"')”]*[ \t\n]+)(" + TRANSITIONS + r")\b", re.M)
HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")
QA_RE = re.compile(r"(?:^|[.!?][\"')”]*[ \t\n]+)((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|Has|Have|Had|May|Might|Must)\b[^.!?\n]{0,80}\?)[ \t]+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Sometimes|Rarely|Nope|Yep|Certainly)[.!](?=\s|$)", re.M)
BRACKET_RE = re.compile(r"\[([^\[\]\n]{1,80})\](?![(\[])")
PLACE_START_RE = re.compile(r"^\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b", re.I)
PLACE_NAMES_RE = re.compile(r"^\s*" + PLACE_WORDS + r"(?:\s+\w+){0,2}\s*$", re.I)
CAPS_SLOT_RE = re.compile(r"^[A-Z][A-Z0-9 _/'-]{2,}$")
EMOJI_RE = re.compile("[\U0001F000-\U0001F2FF\U0001F300-\U0001FAFF☀-➿⭐⭕⬛⬜⤴⤵⬅-⬇〰〽㊗㊙]")
CURLY_RE = re.compile("[‘’“”]")
YEAR_RANGE_RE = re.compile(r"(?<![\w-])(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})(?![\w-])")
BOLD_RE = re.compile(r"\*\*[^*\n]+?\*\*")
FIRST_PERSON = {"i", "me", "my", "mine", "myself", "we", "our", "ours", "us", "ourselves"}
STOP_HEAD = set("a an the and or but nor so yet for of in on at to by up as via per vs off out with from into over onto upon about after before between through under within without among across against around than is are be if".split())


STOCK_ADJ = set("""innovative powerful robust seamless scalable secure reliable flexible efficient modern dynamic
comprehensive intuitive stunning beautiful elegant vibrant rich bold smart fast simple clean strong sleek
lightweight versatile cutting-edge high-quality user-friendly world-class best-in-class engaging impactful
exciting amazing incredible remarkable exceptional outstanding unique seamless holistic transformative
effective valuable meaningful practical thoughtful polished compelling captivating immersive""".split())
ADJ_SUFFIX = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial", "ary", "ory", "ish")
CHAIN_STOP = set("and or the a an is are was were to of in on for with by at as it its that this these those be been not but if so".split())
_W = r"[A-Za-z][A-Za-z-]*"
CHAIN_RE = re.compile(
    r"\b(" + _W + r"), (" + _W + r"), (" + _W + r"), (" + _W + r") (" + _W + r")\b"
    r"|\b(" + _W + r"), (" + _W + r"), (" + _W + r"),? and (" + _W + r")\b"
    r"|\b(" + _W + r"), (" + _W + r"), (" + _W + r") (" + _W + r")\b")


def is_adj(w):
    w = w.lower()
    return w in STOCK_ADJ or (len(w) >= 5 and w.endswith(ADJ_SUFFIX))


def stacked_adjectives(text):
    hits = []
    for m in CHAIN_RE.finditer(text):
        g = [x for x in m.groups() if x is not None]
        if any(x.lower() in CHAIN_STOP for x in g):
            continue
        chained = g[:-1]
        last = g[-1]
        if last.lower() in CHAIN_STOP:
            continue
        if any(is_adj(x) for x in chained):
            hits.append(m.group())
    return hits


class Hit(object):
    __slots__ = ("count", "samples")

    def __init__(self):
        self.count = 0
        self.samples = []

    def add(self, sample, n=1):
        self.count += n
        s = re.sub(r"\s+", " ", sample).strip()
        if len(s) > 100:
            s = s[:97] + "..."
        if s and s not in self.samples and len(self.samples) < 3:
            self.samples.append(s)


# ----------------------------------------------------------------------------
# Analysis
# ----------------------------------------------------------------------------

def excerpt(raw, omap, s, e, pad=40):
    if omap is not None:
        os_ = omap[s]
        oe = omap[e - 1] + 1 if e > s else omap[s]
    else:
        os_, oe = s, e
    a = max(0, os_ - pad)
    b = min(len(raw), oe + pad)
    t = raw[a:b].replace("\r", " ").replace("\n", " ")
    return ("..." if a > 0 else "") + t + ("..." if b < len(raw) else "")


def analyze(raw, by_line=False, ci=False, want_samples=True):
    """raw: window text with \\n newlines. Returns report dict (without cleaned fields)."""
    # char layer on raw
    dec = char_decisions(raw)
    inv_count = sum(1 for d in dec if d[1] == "i")
    sp_count = sum(1 for d in dec if d[1] == "s")
    hm = homoglyph_map(raw)
    findings = {}  # key -> (num, label, weight, Hit)

    def add_finding(key, num, label, weight):
        if key not in findings:
            findings[key] = (num, label, weight, Hit())
        return findings[key][3]

    if inv_count:
        h = add_finding("62_invisible_chars", 62, "Invisible / zero-width characters", 14)
        cnt = Counter("U+%04X" % ord(raw[p]) for p, k, r in dec if k == "i")
        h.count = inv_count
        for cpn, c in cnt.most_common(3):
            h.samples.append("%s x%d" % (cpn, c))
    if sp_count:
        h = add_finding("67_nonstandard_spaces", 67, "Non-standard spaces", 8)
        cnt = Counter("U+%04X" % ord(raw[p]) for p, k, r in dec if k == "s")
        h.count = sp_count
        for cpn, c in cnt.most_common(3):
            h.samples.append("%s x%d" % (cpn, c))
    if hm:
        h = add_finding("66_homoglyphs", 66, "Homoglyph / mixed-script confusables", 14)
        h.count = len(hm)
        covered = -1
        for p in sorted(hm):
            if p < covered:
                continue
            if len(h.samples) >= 3:
                break
            s = p
            while s > 0 and not raw[s - 1].isspace() and p - s < 60:
                s -= 1
            e = p
            while e < len(raw) and not raw[e].isspace() and e - p < 60:
                e += 1
            covered = e
            h.samples.append(raw[s:e][:60])

    # analysis text: invisibles removed, lookalikes folded, spaces normalised
    edits = {}
    for p, k, r in dec:
        edits[p] = r
    for p, r in hm.items():
        edits.setdefault(p, r)
    omap = None
    if edits:
        chars = []
        omap = []
        last = 0
        for p in sorted(edits):
            seg = raw[last:p]
            chars.append(seg)
            omap.extend(range(last, p))
            r = edits[p]
            if r:
                chars.append(r)
                omap.append(p)
            last = p + 1
        chars.append(raw[last:])
        omap.extend(range(last, len(raw)))
        omap.append(len(raw))
        atext0 = "".join(chars)
    else:
        atext0 = raw
    atext = mask_markup(atext0)
    doc = Doc(atext, by_line)
    words = words_of(atext)
    nwords = len(words)

    def lexical_sample(s, e):
        return atext[s:e]

    # lexical families
    for key, num, label, weight, pats, min_hits in LEX:
        tmp = Hit()
        for rx in pats:
            for m in rx.finditer(atext):
                if num == 1 and want_samples:
                    tmp.add(excerpt(raw if omap is not None else atext0, omap, m.start(), m.end()))
                else:
                    tmp.add(m.group())
        if tmp.count >= min_hits:
            if num == 38:
                pass
            findings["%d_%s" % (num, key)] = (num, label, weight, tmp)

    sa = stacked_adjectives(atext)
    if sa:
        h = add_finding("6_stacked_adjectives", 6, "Stacked adjective chains", 8)
        for x in sa:
            h.add(x)

    # promotional imperative openers
    imp = [s for s in doc.sentences if re.match(r"[\W_]*([A-Za-z]+)", s) and re.match(r"[\W_]*([A-Za-z]+)", s).group(1).lower() in PROMO_VERBS]
    if len(imp) >= 3:
        h = add_finding("3_promotional_language", 3, "Promotional language", 10)
        for s in imp:
            h.add(" ".join(s.split()[:4]))

    # synonym cycling
    for cl in SYN_RX:
        present = [rxs for rxs in cl if rxs.search(atext)]
        if len(present) >= 3:
            h = add_finding("8_synonym_cycling", 8, "Synonym cycling", 8)
            h.add(", ".join(sorted(m.search(atext).group().lower() for m in present)))

    # transition clusters
    tcount = 0
    tsamp = []
    for p in doc.prose:
        ms = TRANS_RE.findall("\n".join(p))
        if len(ms) >= 2:
            tcount += len(ms)
            tsamp.extend(ms)
    if tcount:
        h = add_finding("37_transition_clusters", 37, "Transition cluster overuse", 8)
        h.count = tcount
        h.samples = list(dict.fromkeys(tsamp))[:3]

    # hedge stacking
    hs = 0
    for s in doc.sentences:
        if len(HEDGE_RE.findall(s)) >= 2:
            hs += 1
            if hs <= 3:
                pass
    if hs:
        h = add_finding("54_hedge_stacking", 54, "Excessive hedging", 0)
        h.count = hs
        for s in doc.sentences:
            if len(HEDGE_RE.findall(s)) >= 2:
                h.add(s[:80])
                if len(h.samples) >= 3:
                    break

    # question-answer
    qa = QA_RE.findall(atext)
    if qa:
        h = add_finding("25_question_answer", 25, "Question-answer rhetorical pattern", 8)
        for q in qa:
            h.add(q)

    # mid-essay bullets
    if not doc.has_heading:
        list_paras = 0
        prose_paras = 0
        for p in doc.paras:
            if all(LIST_RE.match(l) for l in p):
                list_paras += 1
            elif not all(HEAD_RE.match(l) or HR_RE.match(l) for l in p):
                prose_paras += 1
        if list_paras >= 1 and prose_paras >= 2:
            h = add_finding("34_mid_essay_bullets", 34, "Mid-essay bullet injection", 8)
            h.add("%d list paragraph(s)" % list_paras, list_paras)

    # fragmented headers
    lines = doc.lines
    fh = 0
    for i, l in enumerate(lines):
        if HEAD_RE.match(l):
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines):
                nl = lines[j]
                if HEAD_RE.match(nl) or LIST_RE.match(nl) or nl.strip().startswith("|") or HR_RE.match(nl):
                    continue
                nw = [w.lower() for w in words_of(md_clean(nl))]
                hw = set(w.lower() for w in words_of(md_clean(l)) if len(w) > 2 and w.lower() not in STOP_HEAD)
                if 0 < len(nw) <= 4 and any(w in hw for w in nw if len(w) > 2):
                    fh += 1
    if fh:
        h = add_finding("35_fragmented_headers", 35, "Fragmented headers", 8)
        h.add("heading followed by short repeating line", fh)

    # rhythm
    sent_lens = [count_words(s) for s in doc.sentences]
    if len(sent_lens) >= 3 and cv(sent_lens) < 0.35:
        h = add_finding("40_sentence_monotony", 40, "Sentence-length monotony", 8)
        h.add("%d sentences, length variation %.2f" % (len(sent_lens), cv(sent_lens)))
    # alternation (advice)
    alt = 0
    L = sent_lens
    i = 0
    while i + 6 <= len(L):
        w = L[i:i + 6]
        d = [w[k + 1] - w[k] for k in range(5)]
        ok = all(d[k] * d[k + 1] < 0 for k in range(4)) and all(abs(x) >= max(3, 0.4 * max(w[k], w[k + 1])) for k, x in enumerate(d))
        if ok:
            alt += 1
            i += 6
        else:
            i += 1
    if alt:
        h = add_finding("41_mechanical_alternation", 41, "Mechanical sentence-length alternation", 0)
        h.add("alternating sentence lengths", alt)
    # opener repetition (advice)
    op = 0
    for ps in doc.para_sents:
        if len(ps) >= 3:
            c = Counter(" ".join(w.lower() for w in words_of(s)[:2]) for s in ps)
            for k, v in c.items():
                if v >= 3 and k and len(k.split()) == 2:
                    op += 1
                    break
    if op:
        h = add_finding("42_opener_repetition", 42, "Opener repetition", 0)
        h.add("repeated sentence openers", op)
    # uniform paragraphs
    plens = []
    for p in doc.prose:
        plens.append(count_words(" ".join(p)))
    plens = [x for x in plens if x > 0]
    if len(plens) >= 4 and cv(plens) < 0.4:
        h = add_finding("44_uniform_paragraphs", 44, "Uniform paragraph length", 8)
        h.add("%d paragraphs, length variation %.2f" % (len(plens), cv(plens)))
    # semicolon / paren underuse (advice)
    if nwords >= 300 and ";" not in atext and atext.count("(") <= 1:
        h = add_finding("46_semicolon_paren_underuse", 46, "Semicolon and parenthesis underuse", 0)
        h.add("no semicolons, almost no parentheses")
    # contraction absence (advice)
    lw = [w.lower() for w in words]
    fp = sum(1 for w in lw if w in FIRST_PERSON or w in ("i'm", "i've", "i'll", "i'd", "i’m", "i’ve", "i’ll", "i’d"))
    if nwords and fp >= 3 and fp / float(nwords) >= 0.015:
        full = len(re.findall(r"\b(?:do|does|did|is|are|was|were|have|has|had|will|would|should|could|can) not\b|\bcannot\b|\b(?:it|that|there|he|she|they|we|you) (?:is|are|have|will|would)\b|\bI (?:am|have|will|would)\b|\blet us\b", atext, re.I))
        contr = len(re.findall(r"\b\w+n[’']t\b|\b(?:I|you|we|they|he|she|it|that|there|who)[’'](?:m|re|ve|ll|d|s)\b", atext, re.I))
        if full >= 3 and full / float(full + contr) >= 0.7:
            h = add_finding("55_contraction_absence", 55, "Contraction absence", 0)
            h.add("%d uncontracted forms, %d contractions" % (full, contr), full)

    # boldface
    nb = len(BOLD_RE.findall(atext))
    if nb:
        h = add_finding("56_boldface", 56, "Boldface overuse", 5)
        for m in BOLD_RE.finditer(atext):
            h.add(m.group())
            if len(h.samples) >= 3:
                break
        h.count = nb
    # emojis
    em = [m.group() for m in EMOJI_RE.finditer(atext)]
    if em:
        h = add_finding("57_emojis", 57, "Emojis", 6)
        h.count = len(em)
        h.samples = list(dict.fromkeys(em))[:3]
    # em dash
    ed = 0
    for p in doc.prose:
        c = "\n".join(p).count("—")
        if c >= 2:
            ed += c
    if ed:
        h = add_finding("58_em_dash_overuse", 58, "Em-dash overuse", 0)
        h.add("two or more em dashes in a paragraph", ed)
    # title case headings
    tc = 0
    tsamples = []
    for l in lines:
        m = re.match(r"^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$", l)
        if not m:
            continue
        title = m.group(1).replace("**", "").replace("__", "").strip()
        toks = title.split()
        if len(toks) < 3 or not title[0].isalpha() or title == title.upper():
            continue
        major = [t for t in toks if t[:1].isalpha() and re.sub(r"[^\w]", "", t).lower() not in STOP_HEAD]
        if len(major) >= 2 and all(t[0].isupper() for t in major):
            tc += 1
            tsamples.append(title)
    if tc:
        h = add_finding("59_title_case_headings", 59, "Title case in headings", 5)
        h.count = tc
        h.samples = tsamples[:3]
    # curly quotes
    cq = CURLY_RE.findall(atext0 if omap is None else raw)
    if cq:
        h = add_finding("60_curly_quotes", 60, "Curly quotation marks", 0)
        h.count = len(cq)
        h.samples = list(dict.fromkeys(cq))[:3]
    # year ranges
    yr = [m.group() for m in YEAR_RANGE_RE.finditer(atext) if int(m.group(2)) > int(m.group(1))]
    if yr:
        h = add_finding("61_hyphen_year_ranges", 61, "Hyphen-for-en-dash in numeric ranges", 0)
        h.count = len(yr)
        h.samples = yr[:3]
    # AI utm
    for m in re.finditer(r"utm_source=([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*)", atext, re.I):
        if m.group(1).lower() in AI_UTM_HOSTS:
            add_finding("65_ai_tracking_params", 65, "AI tracking parameters", 14).add(m.group())
    # placeholder brackets
    for m in BRACKET_RE.finditer(atext):
        c = m.group(1)
        hit = False
        if PLACE_START_RE.match(c) or PLACE_NAMES_RE.match(c):
            hit = True
        elif CAPS_SLOT_RE.match(c) and sum(ch.isalpha() for ch in c) >= 3 and not re.match(r"^[A-Z]{1,3}\d+$", c.strip()):
            hit = True
        if hit:
            findings.setdefault("63_placeholder_text", (63, "Placeholder / Mad-Libs text", 14, Hit()))[3].add(m.group())
    # trailing whitespace (advice) - raw window
    tw = sum(1 for ln in raw.split("\n")[:-1] if ln[-1:] in (" ", "\t"))
    if re.search(r"[ \t]\Z", raw):
        tw += 1
    if re.search(r"\n{2,}\Z", raw):
        tw += 1
    if re.match(r"\s", raw):
        tw += 1
    if tw:
        h = add_finding("68_trailing_whitespace", 68, "Trailing / stray whitespace", 0)
        h.add("trailing or leading whitespace", tw)
    # horizontal rules
    rl = [l for i, l in enumerate(lines) if HR_RE.match(l) and (i == 0 or not lines[i - 1].strip())
          and atext.split("\n")[i].strip()]
    if len(rl) >= 3 and len(lines) >= 24:
        h = add_finding("70_decorative_rules", 70, "Decorative horizontal rules", 6)
        h.add("%d horizontal rules" % len(rl), len(rl))
    # degenerate repetition
    if len(lw) >= 12:
        toks = re.findall(r"[a-z0-9'’]+", atext.lower())
        if len(toks) >= 12:
            grams = [" ".join(toks[i:i + 6]) for i in range(len(toks) - 5)]
            c = Counter(grams)
            dup = sum(v for v in c.values() if v > 1)
            if len(grams) >= 10 and dup > 0 and dup / float(len(grams)) >= 0.2:
                h = add_finding("71_degenerate_repetition", 71, "Degenerate repetition", 15)
                h.count = dup
                for g, v in c.most_common(3):
                    if v > 1:
                        h.add(g)

    # --- scoring ---
    moving = {}
    for key, (num, label, weight, h) in findings.items():
        if weight > 0:
            moving.setdefault(num, []).append((weight, h.count))
    nfam = len(moving)
    if nwords < 40:
        conf = "none"
        reason = "only %d words; too short for a meaningful score" % nwords
    elif nwords < 120:
        conf = "low"
        reason = "only %d words; short text gives a weak signal" % nwords
    elif nwords < 300 and nfam == 1:
        conf = "low"
        reason = "%d words with a single pattern family; weak signal" % nwords
    elif nwords < 300:
        conf = "moderate"
        reason = "%d words; fewer than 300 words limits confidence" % nwords
    else:
        conf = "high"
        reason = ""
    total = 0.0
    for num, lst in moving.items():
        for weight, hits in lst:
            c = weight * (0.8 + 0.25 * min(hits, 5))
            if nwords > 300:
                c *= min(1.0, 0.5 + hits * 300.0 / nwords)
            total += c
    score = int(round(min(100.0, total)))
    nums = set(moving)
    if nfam == 0:
        score = 0
    if nfam == 1:
        score = min(score, 40)
    if nums and nums <= {40, 44}:
        score = min(score, 40)
        if nums == {40}:
            score = min(score, 20)
    dec_n = len(nums & DECISIVE)
    if dec_n >= 2:
        score = max(score, 65)
    elif dec_n == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    if nwords < 120:
        early = [n for n in nums if n <= 39 or 47 <= n <= 51 or n == 69]
        if len(early) >= 3:
            score = max(score, 45)
        elif len(early) == 2:
            score = max(score, 25)
    if nwords >= 400:
        if nfam >= 6:
            score = max(score, 45)
        elif nfam >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))
    return {
        "findings": findings, "score": score, "conf": conf, "reason": reason,
        "inv": inv_count, "sp": sp_count, "hm": len(hm), "doc": doc, "nwords": nwords,
    }


def band_of(score):
    if score <= 20:
        return "clean"
    if score <= 40:
        return "light tells"
    if score <= 60:
        return "mixed"
    if score <= 80:
        return "heavy tells"
    return "pervasive tells"


def build_report(text, by_line, ci):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    scanned = len(window)
    raw = window.replace("\r\n", "\n").replace("\r", "\n")
    res = analyze(raw, by_line)
    rep = {}
    for key in sorted(res["findings"], key=lambda k: (int(k.split("_", 1)[0]), k)):
        num, label, weight, h = res["findings"][key]
        if h.count <= 0:
            continue
        rep[key] = {"label": label, "count": int(h.count), "samples": list(h.samples)[:3]}
    score = res["score"]
    metrics = {
        "scanned_chars": scanned,
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": res["conf"],
        "confidence_reason": res["reason"],
        "patterns_flagged": len(rep),
        "invisible_chars": res["inv"],
        "nonstandard_spaces": res["sp"],
        "homoglyphs": res["hm"],
        "words": res["nwords"],
        "score_moving": [k for k in rep if res["findings"][k][2] > 0],
    }
    if ci:
        sents = res["doc"].sentences
        if len(sents) >= 4:
            rng = random.Random(1729)
            vals = []
            t0 = time.time()
            n_iter = 30
            for _ in range(n_iter):
                pick = [sents[rng.randrange(len(sents))] for _ in sents]
                r2 = analyze(" ".join(pick), False, want_samples=False)
                vals.append(r2["score"])
                if time.time() - t0 > 3.0 and len(vals) >= 8:
                    break
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics["score_ci"] = [max(0, lo), min(100, hi)]
            metrics["score_ci_note"] = "resampled over sentences (%d resamples); point score unchanged" % len(vals)
        else:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences (need at least 4) for an interval"
    rep["_metrics"] = metrics
    return rep


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def err(obj_msg, code):
    sys.stderr.write(json.dumps({"error": obj_msg}, ensure_ascii=False) + "\n")
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    ci = False
    files = []
    i = 0
    opts_done = False
    while i < len(argv):
        a = argv[i]
        i += 1
        if opts_done:
            files.append(a)
        elif a == "--":
            opts_done = True
        elif a in ("--help", "-h"):
            sys.stdout.buffer.write(USAGE.encode("utf-8"))
            sys.stdout.flush()
            return 0
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-") and a != "":
            return err("unknown option: %s (see --help)" % a, 2)
        else:
            files.append(a)
    if len(files) > 1:
        sys.stderr.write("prosecheck: only the first file was scanned: %s\n" % files[0])
    path = files[0] if files else None
    try:
        text, by_line = load_input(path)
        if text.strip() == "":
            return err("empty input", 1)
        if clean:
            out = clean_text(text)
            sys.stdout.buffer.write(out.encode("utf-8", "replace"))
            sys.stdout.flush()
            return 0
        rep = build_report(text, by_line, ci)
    except Fail as f:
        return err(f.msg, f.code)
    except MemoryError:
        return err("cannot read input: out of memory", 1)
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=2) + "\n").encode("utf-8", "replace"))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    try:
        code = main(sys.argv[1:])
    except BrokenPipeError:
        code = 0
    sys.exit(code)
