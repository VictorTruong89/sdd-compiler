# prosecheck

Local detector for AI-writing patterns: `scripts/detect.py` (Python 3.9+, standard library only) plus Node.js plugin hooks under `hooks/`.

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]

Nothing is uploaded; there is no network client and no telemetry. See `spec/` for the full requirements.
