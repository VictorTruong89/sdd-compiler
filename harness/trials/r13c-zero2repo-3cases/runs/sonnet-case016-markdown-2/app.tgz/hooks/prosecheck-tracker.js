#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router and the per-prompt contract reminder.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const CMD_RE = /^\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/;

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function setLevel(level, form) {
  const ok = lib.writeMode(level);
  const note = ok ? '' : ' (the settings folder is not writable, so this could not be stored)';
  return { ok, note };
}

const LEVEL_TEXT = {
  lite: 'the writing contract is on; saved files are not scored.',
  full: 'the writing contract and the saved-file guard are on (flags a file scoring above 40).',
  strict: 'the writing contract and a stricter saved-file guard are on (flags a file scoring above 20, with a --clean scrub).',
};

function helpReply(mode) {
  return [
    'prosecheck level: ' + mode,
    '',
    'Commands:',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus the saved-file guard, flags files scoring above 40 (default)',
    '/prosecheck strict - stricter guard, flags files scoring above 20, and adds a --clean scrub',
    '/prosecheck off | on - disable prosecheck / re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file and report; it does not rewrite the file',
    '/prosecheck doctor - install health check',
    '/prosecheck stats - session token use and the score of this session\'s prose',
    '/prosecheck init - export the writing contract to ./AGENTS.md for agents other than Claude Code',
    '',
    'Code, commits, config, and chat are never touched; only prose deliverables are.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

// ---------------------------------------------------------------- check
function cleanPathArg(arg) {
  let s = arg.trim();
  const strip = () => {
    if (s.length >= 2 && ((s[0] === '"' && s[s.length - 1] === '"') || (s[0] === "'" && s[s.length - 1] === "'"))) {
      s = s.slice(1, -1);
      return true;
    }
    return false;
  };
  const cands = [];
  let t = s;
  if (t[0] === '@') t = t.slice(1);
  s = t;
  strip();
  cands.push(s);
  if (s[0] === '@') cands.push(s.slice(1));
  for (const c of cands) if (fs.existsSync(c)) return c;
  return cands[0];
}

function checkReply(arg) {
  if (!arg || !arg.trim()) {
    return 'prosecheck check needs a file path, for example: /prosecheck check notes.md. It reports on the file and never changes it.';
  }
  const typed = cleanPathArg(arg);
  const abs = path.resolve(typed);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'prosecheck: cannot read ' + typed; }
  if (!st.isFile()) return 'prosecheck: ' + typed + ' is not a file.';
  const ext = lib.fileExt(abs);
  if (lib.BINARY_EXT.indexOf(ext) >= 0) return 'prosecheck: ' + base + ' has no readable text for the detector (PDF and RTF are not scored).';
  const archive = lib.ARCHIVE_EXT.indexOf(ext) >= 0;
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    return 'prosecheck: ' + base + ' is over ' + (cap / 1024) + ' KB, so it was not scored.';
  }
  const r = lib.runDetector([abs], { timeout: 15000 });
  if (r.missing || r.noDetector) return 'prosecheck: detector unavailable here (the bundled detector could not be run), so no score was produced.';
  if (r.timedOut) return 'prosecheck: ' + base + ' check failed: the detector timed out.';
  const out = (r.stdout || '').trim();
  const errText = (r.stderr || '').trim();
  if (r.status !== 0) {
    return 'prosecheck: ' + base + ' check failed' + (errText ? ': ' + errText.slice(0, 1000) : ' (the detector exited with a failure and printed nothing).');
  }
  if (!out) return 'prosecheck: ' + base + ' - no report came back from the detector.';
  let rep;
  try { rep = JSON.parse(out); } catch (e) { rep = null; }
  if (!rep || typeof rep !== 'object' || !rep._metrics || typeof rep._metrics.ai_tell_score !== 'number') {
    return 'prosecheck: the detector printed text that is not a report, so there is no report to show.';
  }
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + lib.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let c = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) c += ' - ' + m.confidence_reason;
  lines.push(c);
  if (m.truncated === true) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  const items = lib.sortedLabels(rep).slice(0, 8);
  if (items.length) lines.push('tells: ' + items.map((x) => x.label + ' (x' + x.count + ')').join('; '));
  else lines.push('tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ---------------------------------------------------------------- doctor
function settingsWritable() {
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const p = path.join(dir, '.prosecheck-doctor-' + process.pid);
    fs.writeFileSync(p, 'ok');
    fs.unlinkSync(p);
    return true;
  } catch (e) { return false; }
}

function doctorReply(form) {
  const mode = lib.currentMode();
  const lines = ['prosecheck doctor'];
  const det = lib.detectorPath();
  let bad = false;
  if (mode === 'off') lines.push('[--] mode: off - prosecheck is switched off; turn it back on with /prosecheck on');
  else lines.push('[OK] mode: ' + mode);
  if (det) lines.push('[OK] detector: the bundled detector is present');
  else { lines.push('[FAIL] detector: the bundled detector is missing from the plugin tree'); bad = true; }
  if (!det) {
    lines.push('[FAIL] python: the bundled detector could not be run because it is missing');
    bad = true;
  } else {
    const r = lib.runDetector([], { input: 'This is a short sample sentence used to check the install.\n', timeout: 15000, detector: det });
    if (r.missing) {
      lines.push('[FAIL] python not found - prose is still shaped by the writing contract, but saved files are not re-scored until Python is available');
      bad = true;
    } else {
      let ok = false;
      try {
        const rep = JSON.parse(r.stdout);
        ok = !!(rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number');
      } catch (e) { ok = false; }
      if (ok) lines.push('[OK] python: ran the bundled detector and got a numeric score');
      else { lines.push('[FAIL] python: ran, but the detector result was not a numeric score'); bad = true; }
    }
  }
  if (settingsWritable()) lines.push('[OK] settings: the settings folder is writable');
  else { lines.push('[FAIL] settings: the settings folder is not writable'); bad = true; }
  if (bad) {
    lines.push('Please fix the faulty checks above, then run /prosecheck doctor again.');
  } else if (mode === 'off') {
    lines.push('The install is healthy, but prosecheck is switched off, so saving files triggers no scoring; no file is scored until you run ' + form + ' on.');
  } else {
    lines.push('prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, and only the first 262,144 characters are read. See files that were only partly scanned or skipped with ' + form + ' show.');
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- show
function showReply(sessionId) {
  const list = lib.readLedger(sessionId);
  if (!list.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const rows = list.map((r, i) => ({ r, i })).sort((a, b) => ((b.r.ts || 0) - (a.r.ts || 0)) || (b.i - a.i)).map((x) => x.r);
  const out = ['Files checked in this session, newest first:'];
  for (const r of rows) {
    const base = String(r.base || '');
    let body;
    if (r.kind === 'scored') {
      body = lib.hookPhrase(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, 5) : [];
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
    } else if (r.kind === 'skipped') {
      body = 'not scored: the file is over the ' + r.capKb + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    out.push('  ' + base + ' - ' + body);
  }
  return out.join('\n');
}

// ---------------------------------------------------------------- init
function initReply(form) {
  const mode = lib.currentMode();
  if (mode === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Turn it on with ' + form + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  if (readFail) {
    lines.push('prosecheck: cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing !== null && (existing.indexOf(lib.SECTION_START) >= 0 || existing.indexOf(lib.SECTION_TITLE) >= 0)) {
    lines.push('AGENTS.md already contains the prosecheck contract; it was left unchanged.');
  } else {
    let text = lib.exportContract(mode);
    let next;
    if (existing === null || existing === '') next = text;
    else next = existing + (existing.endsWith('\n') ? '' : '\n') + '\n' + text;
    try {
      fs.writeFileSync(agents, next);
      lines.push('Wrote the writing contract to AGENTS.md (' + mode + ').');
    } catch (e) {
      lines.push('prosecheck: cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    lines.push('.cursor/rules/prosecheck.mdc is already there; it was not overwritten.');
  } else {
    try {
      let content;
      const shipped = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      try { content = fs.readFileSync(shipped, 'utf8'); } catch (e) { content = lib.cursorRule(); }
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, content);
      lines.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('prosecheck: cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- router
function command(prompt, payload, rest) {
  const form = prompt.indexOf('/prosecheck:prosecheck') === 0 ? '/prosecheck:prosecheck' : '/prosecheck';
  rest = rest.trim();
  const m = /^(\S+)\s*([\s\S]*)$/.exec(rest);
  const typed = m ? m[1] : '';
  const arg = m ? m[2].trim() : '';
  const sub = typed.toLowerCase();
  if (!typed || sub === 'help') return helpReply(lib.currentMode());
  switch (sub) {
    case 'lite': case 'full': case 'strict': {
      const r = setLevel(sub, form);
      return 'prosecheck level set to ' + sub + ': ' + LEVEL_TEXT[sub] + r.note;
    }
    case 'off': {
      const r = setLevel('off', form);
      return 'prosecheck is now off. Turn it back on with /prosecheck on.' + r.note;
    }
    case 'on': {
      const r = setLevel('full', form);
      return 'prosecheck is on again (level full): ' + LEVEL_TEXT.full + r.note;
    }
    case 'status':
      return 'prosecheck level: ' + lib.currentMode();
    case 'show':
      return showReply(typeof payload.session_id === 'string' ? payload.session_id : '');
    case 'check':
      return checkReply(arg);
    case 'doctor':
      return doctorReply(form);
    case 'stats':
      return require('./prosecheck-stats').statsReply(payload);
    case 'init':
      return initReply(form);
    default:
      return 'prosecheck: unknown subcommand "' + typed + '". Valid subcommands: ' + lib.SUBCOMMANDS.join(', ') + '.';
  }
}

function main() {
  const payload = lib.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt.trim() : '';
  lib.pruneLedgers();
  const cm = CMD_RE.exec(prompt);
  if (cm) { block(command(prompt, payload, cm[1])); return; }
  const low = prompt.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    lib.writeMode('off');
    block('prosecheck is now off. Turn it back on with /prosecheck on.');
    return;
  }
  const mode = lib.currentMode();
  if (mode === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level ' + mode + ': prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
