#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same contract, inside the SubagentStart envelope.
const lib = require('./lib');

function main() {
  lib.readStdinJson();
  const mode = lib.currentMode();
  if (mode === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.liveContract(mode) },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
