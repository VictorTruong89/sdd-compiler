'use strict';
// Shared helpers for the prosecheck plugin hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const BINARY_EXT = ['.pdf', '.rtf'];
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const LEDGER_KEEP = 20;
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* malformed */ }
  return {};
}

function configDir() {
  const e = process.env.CLAUDE_CONFIG_DIR;
  if (e) return e;
  return path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  const e = process.env.CLAUDE_PLUGIN_ROOT;
  if (e) return e;
  return path.resolve(__dirname, '..');
}

function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function storedMode() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    if (LEVELS.indexOf(v) >= 0) return v;
  } catch (e) { /* none */ }
  return null;
}

function envMode() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}

function currentMode() {
  return storedMode() || envMode() || 'full';
}

function writeMode(mode) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), mode, { mode: 0o600 });
    return true;
  } catch (e) { return false; }
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

// Run the detector with the host Python. Returns {missing:true} if Python cannot be launched.
function runDetector(args, opts) {
  opts = opts || {};
  const det = opts.detector || detectorPath();
  if (!det) return { noDetector: true };
  const names = ['python3', 'python', 'py'];
  for (const name of names) {
    const r = cp.spawnSync(name, [det].concat(args), {
      input: opts.input,
      encoding: 'utf8',
      timeout: opts.timeout || 15000,
      killSignal: 'SIGKILL',
      maxBuffer: 64 * 1024 * 1024,
      env: process.env,
    });
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES' || r.error.code === 'ENOTDIR')) continue;
    if (r.error && r.error.code === 'ETIMEDOUT') return { timedOut: true };
    if (r.error && r.status === null && !r.signal) continue;
    return { status: r.status, signal: r.signal, stdout: r.stdout || '', stderr: r.stderr || '', error: r.error };
  }
  return { missing: true };
}

function hookPhrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    case 'pervasive tells': return 'reads with pervasive AI tells';
    default: return 'reads clean';
  }
}

function sortedLabels(report) {
  const moving = Array.isArray(report && report._metrics && report._metrics.score_moving) ? report._metrics.score_moving : null;
  const items = [];
  for (const k of Object.keys(report || {})) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (!f || typeof f !== 'object') continue;
    items.push({ key: k, label: String(f.label || k), count: Number(f.count) || 0, mv: moving ? moving.indexOf(k) >= 0 : true });
  }
  items.sort((a, b) => (b.mv - a.mv) || (b.count - a.count));
  return items;
}

// ---------------------------------------------------------------- ledger
function sanitizeSession(id) {
  if (typeof id !== 'string' || id === '') return '';
  return id.replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
}

function ledgerPath(sessionId) {
  const s = sanitizeSession(sessionId);
  return path.join(configDir(), s ? '.prosecheck-ledger-' + s : '.prosecheck-ledger');
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(dir, f);
        try {
          const st = fs.statSync(p);
          if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}

function appendLedger(sessionId, rec) {
  try {
    pruneLedgers();
    const list = readLedger(sessionId);
    rec.ts = Date.now();
    list.push(rec);
    const keep = list.slice(-LEDGER_KEEP);
    const p = ledgerPath(sessionId);
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(keep), { mode: 0o600 });
    try { fs.chmodSync(p, 0o600); } catch (e) { /* ignore */ }
    return true;
  } catch (e) { return false; }
}

// ---------------------------------------------------------------- contract
function contractLines(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.');
  L.push('This contract never touches code, code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.');
  L.push('Vary sentence length irregularly: mix short and long sentences, with no metronome and no mechanical short-long alternation.');
  L.push('Banned vocabulary (never use these words in prose): ' + BANNED.join(', ') + '. Use the plain word instead; "landscape" and "journey" are banned in the abstract sense.');
  L.push('Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting such as "let\'s dive in"; empty pivots such as "it\'s worth noting"; "In conclusion" and "Overall" closers; outcome-speculation tails; self-thoroughness claims; generic upbeat endings; chatbot phrases such as "I hope this helps".');
  L.push('Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('Factual or encyclopedic content stays in neutral third person; first-person or opinion writing may use contractions.');
  L.push('Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('End sections on a fact or observation.');
  L.push('Stay silent about all of this: never announce the contract, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    const strict = level === 'strict';
    const target = strict ? 'the clean band (score at most 20)' : 'the clean or light tells band (score at most 40)';
    if (opts.portable) {
      L.push('Resolve the detector first: use scripts/detect.py under CLAUDE_PLUGIN_ROOT when that variable is set, otherwise locate prosecheck\'s detector among installed skills or plugins.');
      L.push('After writing a prose file, run the detector on that file, read ai_tell_score in the _metrics object, and when the band is worse than ' + target + ', fix the flagged spans (at most two fix passes, keeping rhythm variation).');
    } else {
      const d = opts.detector;
      const cmd = d ? 'python3 "' + d + '" <file>' : 'the prosecheck detector on <file>';
      L.push('After writing a prose file, run ' + cmd + ', read ai_tell_score in the _metrics object, and when the band is worse than ' + target + ', fix the flagged spans (at most two fix passes, keeping rhythm variation).');
    }
    if (strict) {
      if (opts.portable) {
        L.push('Finish by running the detector with --clean on the plain-text file and saving its output over the file.');
      } else {
        const d = opts.detector;
        L.push('Finish by running ' + (d ? 'python3 "' + d + '" --clean <file>' : 'the detector with --clean on <file>') + ' on the plain-text file and saving its output over the file.');
      }
    }
  }
  return L;
}

function liveContract(level) {
  const lines = contractLines(level, { detector: detectorPath() });
  return 'prosecheck writing contract (level: ' + level + ')\n\n' + lines.map((l) => '- ' + l).join('\n') + '\n';
}

const SECTION_START = '<!-- prosecheck:prose-contract:start -->';
const SECTION_END = '<!-- prosecheck:prose-contract:end -->';
const SECTION_TITLE = '## Prose contract (prosecheck)';

function exportContract(level) {
  const lines = contractLines(level, { portable: true });
  return SECTION_START + '\n' + SECTION_TITLE + '\n\n' + lines.map((l) => '- ' + l).join('\n') + '\n' + SECTION_END + '\n';
}

function cursorRule() {
  const L = contractLines('lite', { portable: true });
  return '---\n' +
    'description: Writing contract for prose deliverables only\n' +
    'globs: *.md, *.mdx, *.markdown, *.txt, *.rst, *.tex, *.org, *.adoc\n' +
    'alwaysApply: false\n' +
    '---\n\n' +
    '# Writing contract\n\n' +
    L.map((l) => '- ' + l).join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on.',
    'Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and no upload: everything runs on this machine.',
    'Useful commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'This welcome is shown once.',
    '',
    '',
  ].join('\n');
}

function fileExt(p) { return path.extname(p).toLowerCase(); }

module.exports = {
  LEVELS, SUBCOMMANDS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ARCHIVE_EXT, BINARY_EXT,
  BANNED, readStdinJson, configDir, pluginRoot, flagPath, storedMode, envMode, currentMode, writeMode,
  detectorPath, runDetector, hookPhrase, sortedLabels, ledgerPath, pruneLedgers, readLedger, appendLedger,
  liveContract, exportContract, cursorRule, welcomeText, fileExt, SECTION_START, SECTION_END, SECTION_TITLE,
  LEDGER_MAX_AGE_MS,
};
