#!/usr/bin/env node
'use strict';
// Session statistics: token figures from the transcript and the score of the session's own prose.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

function newestTranscript() {
  const root = path.join(lib.configDir(), 'projects');
  let best = null;
  let bestT = -1;
  const walk = (dir, depth) => {
    let ents;
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); } else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestT) { bestT = t; best = p; }
        } catch (err) { /* ignore */ }
      }
    }
  };
  walk(root, 0);
  return best;
}

function stripFences(text) {
  const out = [];
  let fence = null;
  for (const line of text.split('\n')) {
    const m = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
    if (fence) {
      if (m && m[1][0] === fence[0] && m[1].length >= fence.length && !m[2].trim()) fence = null;
      continue;
    }
    if (m) { fence = m[1]; continue; }
    out.push(line);
  }
  return out.join('\n');
}

function readTranscript(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { return null; }
  let turns = 0;
  let outTok = 0;
  let cacheTok = 0;
  const seen = {};
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const id = typeof m.id === 'string' && m.id ? m.id : null;
    if (id === null || !seen[id]) {
      if (id !== null) seen[id] = true;
      turns += 1;
      const u = m.usage && typeof m.usage === 'object' ? m.usage : {};
      if (typeof u.output_tokens === 'number') outTok += u.output_tokens;
      if (typeof u.cache_read_input_tokens === 'number') cacheTok += u.cache_read_input_tokens;
    }
    if (typeof m.content === 'string') texts.push(m.content);
    else if (Array.isArray(m.content)) {
      for (const c of m.content) if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
    }
  }
  return { turns, outTok, cacheTok, texts };
}

function statsReply(payload) {
  const mode = lib.currentMode();
  let file = typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null;
  if (!file) file = newestTranscript();
  const t = file ? readTranscript(file) : null;
  if (!t) {
    return 'prosecheck stats: no readable session transcript was found, so there are no token figures to report.\nlevel: ' + mode;
  }
  const lines = ['prosecheck stats', 'level: ' + mode,
    'assistant turns: ' + t.turns, 'output tokens: ' + t.outTok, 'cache-read input tokens: ' + t.cacheTok];
  let prose = stripFences(t.texts.join('\n\n'));
  if (prose.length > 40000) prose = prose.slice(prose.length - 40000);
  if (prose.trim().length > 200) {
    const r = lib.runDetector([], { input: prose, timeout: 15000 });
    if (r && !r.missing && !r.noDetector && !r.timedOut) {
      try {
        const rep = JSON.parse(r.stdout);
        if (rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number') {
          lines.push('session prose ai_tell_score: ' + rep._metrics.ai_tell_score);
        }
      } catch (e) { /* no score */ }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const reply = statsReply(lib.readStdinJson());
    process.stdout.write(reply + '\n');
  } catch (e) { /* never fail */ }
  process.exitCode = 0;
}
