#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const lib = require('./lib');

function main() {
  lib.readStdinJson();
  lib.pruneLedgers();
  let welcome = false;
  let mode;
  const fs = require('fs');
  if (!fs.existsSync(lib.flagPath())) {
    mode = lib.envMode() || 'full';
    welcome = lib.writeMode(mode);
  } else {
    mode = lib.currentMode();
  }
  if (mode === 'off') return;
  let out = '';
  if (welcome) out += lib.welcomeText();
  out += lib.liveContract(mode);
  process.stdout.write(out);
}

try { main(); } catch (e) { /* never fail the host session */ }
process.exitCode = 0;
