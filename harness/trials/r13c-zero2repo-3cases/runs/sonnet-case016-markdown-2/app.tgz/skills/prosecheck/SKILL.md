---
name: prosecheck
description: Rewrite flagged prose so it no longer reads with AI-writing tells. Use when the user says "prosecheck this" or "humanize this", or when the saved-file guard names flagged spans.
---

# prosecheck

prosecheck is a local detector for AI-writing patterns. It scores prose, never code, and never names an author.

To check a file: run `python3 scripts/detect.py FILE` from the plugin root and read `_metrics.ai_tell_score` and the fired findings.

To rewrite: fix the flagged spans only, keep numbers, units, dates, proper nouns, citations, quotes, and technical terms exactly, never invent facts, vary sentence length, and do not announce the pass. Re-run the detector after at most two passes.
