---
description: prosecheck - local AI-writing pattern detector (lite, full, strict, off, on, status, show, check, doctor, stats, init, help)
argument-hint: [subcommand] [argument]
---
/prosecheck $ARGUMENTS
