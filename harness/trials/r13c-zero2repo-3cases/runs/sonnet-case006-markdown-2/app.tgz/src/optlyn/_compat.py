"""Stream and platform helpers shared by the rest of the package."""
import codecs
import io
import os
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_ascii_encoding(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return isatty(sys.stdin) or isatty(sys.stdout)


class NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _wrap_text_stream(stream, encoding, errors, writing):
    """Return a text stream over the binary buffer of ``stream`` using the
    requested encoding, leaving the original stream open."""
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return NonClosingTextIOWrapper(
        buf,
        encoding=encoding or getattr(stream, "encoding", None) or "utf-8",
        errors=errors or "strict",
        write_through=writing,
        line_buffering=False,
    )


def get_text_stdout(encoding=None, errors=None):
    if encoding is None and errors is None:
        return sys.stdout
    return _wrap_text_stream(sys.stdout, encoding, errors, True)


def get_text_stderr(encoding=None, errors=None):
    if encoding is None and errors is None:
        return sys.stderr
    return _wrap_text_stream(sys.stderr, encoding, errors, True)


def get_text_stdin(encoding=None, errors=None):
    if encoding is None and errors is None:
        return sys.stdin
    return _wrap_text_stream(sys.stdin, encoding, errors, False)


def _binary(stream, name):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        try:
            stream.flush()
        except Exception:
            pass
        return buf
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    raise RuntimeError(f"Was not able to determine binary stream for {name}")


def get_binary_stdin():
    return _binary(sys.stdin, "stdin")


def get_binary_stdout():
    return _binary(sys.stdout, "stdout")


def get_binary_stderr():
    return _binary(sys.stderr, "stderr")


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode("utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


class KeepOpenFile:
    """Wrapper that never closes the underlying (standard) stream."""

    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *rest):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    """Open ``filename``; ``-`` is a standard stream. Returns (file, should_close)."""
    if isinstance(filename, (str, bytes)) and filename in ("-", b"-"):
        if any(m in mode for m in "wax"):
            if "b" in mode:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if "b" in mode:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding if "b" not in mode else None,
                    errors=errors if "b" not in mode else None), True
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "r" in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import tempfile

    real = os.path.realpath(filename)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(real) or ".", prefix=".__atomic-write", suffix=".tmp")
    os.close(fd)
    try:
        f = open(tmp, mode, encoding=encoding if "b" not in mode else None,
                 errors=errors if "b" not in mode else None)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return _AtomicFile(f, tmp, real), True
