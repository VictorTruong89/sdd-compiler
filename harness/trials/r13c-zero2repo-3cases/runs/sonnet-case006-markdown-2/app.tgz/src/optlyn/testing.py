import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import _compat, formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = getattr(input, "buffer", input)
        if isinstance(rv, (io.RawIOBase, io.BufferedIOBase)) or hasattr(rv, "readline"):
            data = rv.read()
            if isinstance(data, str):
                data = data.encode(charset)
            return io.BytesIO(data)
        raise TypeError("Could not find binary reader for input stream.")
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _decode(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._decode(self.output_bytes)

    @property
    def stdout(self):
        return self._decode(self.stdout_bytes)

    @property
    def stderr(self):
        return self._decode(self.stderr_bytes)

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class _FdCapture:
    """Redirects descriptors 1 and 2 into pipes drained by reader threads."""

    def __init__(self, mixed):
        self.mixed = mixed
        self.lock = threading.Condition()
        self.buffers = {1: bytearray(), 2: bytearray()}
        self.written = {1: 0, 2: 0}
        self.read = {1: 0, 2: 0}
        self.saved = {}
        self.threads = []
        self.wfds = {}

    def start(self):
        for fd in (1, 2):
            try:
                (sys.stdout if fd == 1 else sys.stderr).flush()
            except Exception:
                pass
            self.saved[fd] = os.dup(fd)
            r, w = os.pipe()
            os.dup2(w, fd)
            os.close(w)
            t = threading.Thread(target=self._drain, args=(fd, r), daemon=True)
            t.start()
            self.threads.append(t)

    def _drain(self, fd, r):
        while True:
            try:
                chunk = os.read(r, 65536)
            except OSError:
                break
            if not chunk:
                break
            with self.lock:
                self.buffers[fd] += chunk
                self.mixed.write(chunk)
                self.read[fd] += len(chunk)
                self.lock.notify_all()
        os.close(r)

    def write(self, fd, data):
        view = memoryview(data)
        total = 0
        while total < len(view):
            total += os.write(fd, view[total:])
        with self.lock:
            self.written[fd] += len(data)
            self.lock.wait_for(lambda: self.read[fd] >= self.written[fd], timeout=2)
        return len(data)

    def stop(self):
        if self.saved is None:
            return
        for fd in (1, 2):
            os.dup2(self.saved[fd], fd)
            os.close(self.saved[fd])
        self.saved = None
        for t in self.threads:
            t.join(timeout=5)


class _FdBuffer(io.BufferedIOBase):
    def __init__(self, cap, fd):
        self._cap = cap
        self._fd = fd

    def writable(self):
        return True

    def write(self, b):
        return self._cap.write(self._fd, bytes(b))

    def fileno(self):
        return self._fd

    def flush(self):
        pass

    def isatty(self):
        return False


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        bytes_mixed = io.BytesIO()
        bytes_output = BytesIOCopy(bytes_mixed)
        bytes_error = BytesIOCopy(bytes_mixed)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_mixed)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        cap = None
        if self.capture == "fd":
            cap = _FdCapture(bytes_mixed)
            cap.start()
            sys.stdout = _NamedTextIOWrapper(_FdBuffer(cap, 1), encoding=self.charset,
                                             name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(_FdBuffer(cap, 2), encoding=self.charset,
                                             name="<stderr>", mode="w", write_through=True)
        else:
            sys.stdout = _NamedTextIOWrapper(bytes_output, encoding=self.charset,
                                             name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(bytes_error, encoding=self.charset,
                                             name="<stderr>", mode="w", write_through=True,
                                             errors="backslashreplace")

        @_make_input
        def visible_input(prompt=None):
            if echo_input is not None:
                echo_input._paused = True
            try:
                sys.stdout.write(prompt or "")
                val = _readline(text_input)
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
            finally:
                if echo_input is not None:
                    echo_input._paused = False
            return val

        @_make_input
        def hidden_input(prompt=None):
            if echo_input is not None:
                echo_input._paused = True
            try:
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                return _readline(text_input)
            finally:
                if echo_input is not None:
                    echo_input._paused = False

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui.getchar
        old_strip = _compat.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui.getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if cap is not None:
                yield (_Live(cap, 1), _Live(cap, 2), bytes_mixed)
            else:
                yield (bytes_output, bytes_error, bytes_mixed)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui.getchar = old_getchar
            _compat.should_strip_ansi = old_strip
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if cap is not None:
                cap.stop()
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if self.capture == "fd":
                    # let reader threads catch up before collecting
                    outstreams[0].settle()
                stdout = outstreams[0].getvalue()
                stderr = outstreams[1].getvalue()
                output = outstreams[2].getvalue()
        if self.capture == "fd":
            pass
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr,
                      output_bytes=output, return_value=return_value, exit_code=exit_code,
                      exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _make_input(f):
    return f


def _readline(text_input):
    line = text_input.readline()
    if not line:
        raise EOFError()
    return line.rstrip("\r\n")


class _Live:
    """Reads captured bytes of one descriptor once the pipes have drained."""

    def __init__(self, cap, fd):
        self.cap = cap
        self.fd = fd

    def settle(self):
        self.cap.stop()

    def getvalue(self):
        with self.cap.lock:
            return bytes(self.cap.buffers[self.fd])
