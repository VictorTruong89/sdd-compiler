"""Output helpers: echo, style, file helpers and misc utilities."""
import os
import sys

from . import _compat
from ._compat import (
    KeepOpenFile,
    format_filename,
    is_ascii_encoding,
    open_stream,
    strip_ansi,
)
from .globals import resolve_color_default

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError):
    pass


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Color {color!r} out of range")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise ColorError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for value, on, off in (
        (bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
        (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29),
    ):
        if value is not None:
            bits.append(f"\033[{on if value else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _write_text(file, text):
    enc = getattr(file, "encoding", None)
    buf = getattr(file, "buffer", None)
    if enc and buf is not None and is_ascii_encoding(enc):
        file.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        if buf is not None:
            file.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()
        else:
            file.write(text.encode("ascii", "replace").decode("ascii"))
    try:
        file.flush()
    except Exception:
        pass


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        buf = getattr(file, "buffer", None)
        try:
            file.flush()
        except Exception:
            pass
        if buf is not None:
            buf.write(bytes(out))
            buf.flush()
            return
        file.write(bytes(out).decode("utf-8", "replace"))
        return
    color = resolve_color_default(color)
    if _compat.should_strip_ansi(file, color):
        out = strip_ansi(out)
    _write_text(file, out)


def get_binary_stream(name):
    return {"stdin": _compat.get_binary_stdin, "stdout": _compat.get_binary_stdout,
            "stderr": _compat.get_binary_stderr}[name]()


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": _compat.get_text_stdin, "stdout": _compat.get_text_stdout,
            "stderr": _compat.get_text_stderr}[name](encoding, errors)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
            if not self.should_close:
                self._f = KeepOpenFile(self._f)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
        _posixify(app_name),
    )


def split_arg_string(string):
    import shlex

    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.append(lex.token)
    return out
