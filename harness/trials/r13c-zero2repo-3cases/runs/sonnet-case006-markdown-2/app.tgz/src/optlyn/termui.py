"""Interactive terminal helpers."""
import contextlib
import getpass
import inspect
import itertools
import math
import os
import shlex
import subprocess
import sys
import tempfile
import time

from . import _compat
from ._compat import isatty, strip_ansi
from .exceptions import Abort, UsageError, OptlynException
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename

visible_prompt_func = input
hidden_prompt_func = getpass.getpass


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type._names()))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and hasattr(default, "mode") and isinstance(
            getattr(default, "name", None), str):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---------------------------------------------------------------- pager


class _PagerStream:
    def __init__(self, write, flush, strip):
        self._write = write
        self._flush = flush
        self._strip = strip

    def write(self, text):
        if isinstance(text, (bytes, bytearray)):
            text = bytes(text).decode("utf-8", "replace")
        if self._strip:
            text = strip_ansi(text)
        self._write(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        self._flush()

    def isatty(self):
        return False

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    if not _compat.is_interactive():
        color = resolve_color_default(color)
        strip = _compat.should_strip_ansi(stdout, color)

        def w(t):
            stdout.write(t)

        yield _PagerStream(w, lambda: stdout.flush(), strip)
        stdout.flush()
        return
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not pager_cmd:
        for cand in ("less", "more"):
            import shutil

            if shutil.which(cand):
                pager_cmd = cand
                break
    if not pager_cmd:
        color = resolve_color_default(color)
        strip = _compat.should_strip_ansi(stdout, color)
        yield _PagerStream(lambda t: stdout.write(t), lambda: stdout.flush(), strip)
        stdout.flush()
        return
    color = resolve_color_default(color)
    env = dict(os.environ)
    base = os.path.basename(shlex.split(pager_cmd)[0]) if pager_cmd.split() else ""
    if color is None and base == "less":
        env.setdefault("LESS", "-R")
        color = True
    strip = not color
    try:
        stdout.flush()
    except Exception:
        pass
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env)
    broken = False

    def w(t):
        nonlocal broken
        if broken:
            return
        try:
            proc.stdin.write(t.encode("utf-8", "replace"))
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            broken = True

    def fl():
        nonlocal broken
        if broken:
            return
        try:
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            broken = True

    try:
        yield _PagerStream(w, fl, strip)
    finally:
        try:
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    gen = (c if isinstance(c, str) else str(c) for c in chunks)
    with get_pager_file(color=color) as f:
        for chunk in itertools.chain(gen, ["\n"]):
            f.write(chunk)
            f.flush()


# ---------------------------------------------------------------- progress


def _format_eta(seconds):
    seconds = int(seconds)
    t = seconds
    days, t = divmod(t, 86400)
    hours, t = divmod(t, 3600)
    minutes, secs = divmod(t, 60)
    if days:
        return f"{days}d {hours:02}:{minutes:02}:{secs:02}"
    return f"{hours:02}:{minutes:02}:{secs:02}"


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                 empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 width=36, file=None, color=None, update_min_steps=1):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        elif length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.iter = iter(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else (length is not None)
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.width = width
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.update_min_steps = update_min_steps
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._completed_intervals = 0
        self.entered = False
        self.is_atty = isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *exc):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def generator(self):
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True

    def update(self, n_steps, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self.make_step(n_steps)
        self.render_progress()

    def finish(self):
        self.finished = True

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        else:
            bar = self.empty_char * self.width
        return bar

    def format_progress_line(self):
        info = []
        if self.length is not None:
            if self.show_pos:
                info.append(f"{self.pos}/{self.length}")
            if self.show_percent:
                info.append(f"{int(self.pct * 100):4}%")
            if self.show_eta and not self.finished:
                info.append(_format_eta(self.eta))
        elif self.show_pos:
            info.append(str(self.pos))
        if self.item_show_func is not None:
            item = self.item_show_func(self.current_item)
            if item:
                info.append(item)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                      "info": self.info_sep.join(info)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not self.is_atty:
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=self.file, nl=False, color=self.color)
        self.file.flush()

    def render_finish(self):
        if self.hidden or not self.is_atty:
            return
        self.file.write("\n")
        self.file.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- input


def getchar(echo=False):
    import select
    import termios
    import tty

    if isatty(sys.stdin):
        try:
            fd = sys.stdin.fileno()
            close_fd = False
        except Exception:
            fd = os.open("/dev/tty", os.O_RDONLY)
            close_fd = True
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        close_fd = True
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 1)
            if data:
                b = data[0]
                extra = 0
                if b == 0x1B:
                    while select.select([fd], [], [], 0.02)[0] and len(data) < 32:
                        data += os.read(fd, 1)
                elif b >= 0xF0:
                    extra = 3
                elif b >= 0xE0:
                    extra = 2
                elif b >= 0xC0:
                    extra = 1
                for _ in range(extra):
                    data += os.read(fd, 1)
            ch = data.decode("utf-8", "replace")
            if echo and isatty(sys.stdout):
                sys.stdout.write(ch)
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if close_fd:
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if not _compat.is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError, OSError):
            pass
    finally:
        if info:
            echo(err=err)


# ---------------------------------------------------------------- editor / launch


def _get_editor():
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    import shutil

    for cand in ("editor", "vim", "nano", "vi"):
        if shutil.which(cand):
            return cand
    return "vi"


def _run_editor(editor, filename, env):
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    try:
        c = subprocess.Popen(f"{editor} {shlex.quote(filename)}", env=environ, shell=True)
        exit_code = c.wait()
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e
    if exit_code != 0:
        raise OptlynException(f"{editor}: Editing failed")


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = _get_editor()
    if filename is not None:
        _run_editor(editor, filename, env)
        return None
    if text is None:
        text = ""
    if isinstance(text, bytes):
        text = text.decode("utf-8", "replace")
    if text and not text.endswith("\n"):
        text += "\n"
    if not extension.startswith("."):
        extension = "." + extension
    fd, name = tempfile.mkstemp(prefix="edit-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(text.replace("\n", os.linesep).encode("utf-8"))
        st = os.stat(name)
        before = (st.st_mtime_ns, st.st_size, st.st_ino)
        _run_editor(editor, name, env)
        st = os.stat(name)
        if require_save and before == (st.st_mtime_ns, st.st_size, st.st_ino):
            return None
        with open(name, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig", "replace").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    if locate:
        path = os.fspath(url) if not isinstance(url, str) else url
        if os.path.exists(path):
            url = os.path.dirname(os.path.abspath(path)) if not os.path.isdir(path) else path
    args = ["xdg-open", url]
    try:
        if wait:
            return subprocess.Popen(args).wait()
        c = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            return c.wait(timeout=2)
        except subprocess.TimeoutExpired:
            return 0
    except OSError:
        return 127
