"""Locating packaged resources."""
import os

path = []
for _p in (os.environ.get("LINGORA_DATA"), "~/lingora_data", "~/nltk_data",
           "/usr/share/nltk_data", "/usr/local/share/nltk_data",
           "/usr/lib/nltk_data", "/usr/local/lib/nltk_data"):
    if _p:
        path.append(os.path.expanduser(_p))


def find(resource):
    """Return the filesystem path of a resource, or raise LookupError."""
    for d in list(path):
        p = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))


def open_text(resource, fname=None):
    p = find(resource)
    if fname:
        p = os.path.join(p, fname)
    if not os.path.exists(p):
        raise LookupError("Resource file %r not found" % p)
    return open(p, encoding="utf-8", newline="")


def read_lines(resource, fname=None):
    """Lines without their line terminator."""
    with open_text(resource, fname) as f:
        return f.read().splitlines()
