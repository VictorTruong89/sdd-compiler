from lingora import data
from lingora.tag.sequential import (
    AffixTagger, BigramTagger, DefaultTagger, NgramTagger, RegexpTagger,
    SequentialBackoffTagger, TaggerI, TrigramTagger, UnigramTagger)
from lingora.tag.perceptron import PerceptronTagger

__all__ = ["AffixTagger", "BigramTagger", "DefaultTagger", "NgramTagger", "RegexpTagger",
           "TrigramTagger", "UnigramTagger", "PerceptronTagger", "pos_tag", "map_tag"]

_RU_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "NUM": "NUM",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "PARENTH": "PRT", "PRAEDIC": "PRT",
    "S-PRO": "PRON", "A-PRO": "PRON", "ADV-PRO": "PRON", "PRAEDIC-PRO": "PRON",
    "INTJ": "X", "COM": "X", "NONLEX": ".", "SENT": ".",
}


def _universal_map_en():
    lines = data.read_lines("taggers/universal_tagset", "en-ptb.map")
    m = {}
    for line in lines:
        parts = line.split("\t")
        if len(parts) >= 2:
            m[parts[0]] = parts[1]
    return m


def map_tag(source, target, tag):
    if target != "universal":
        raise ValueError("unsupported target tagset %r" % (target,))
    if source == "en-ptb":
        return _universal_map_en().get(tag, "X")
    if source == "ru-rnc":
        return _RU_UNIVERSAL.get(tag.split("=")[0], "X")
    raise ValueError("unsupported source tagset %r" % (source,))


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens: expected a list of strings, got %s" % type(tokens).__name__)
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, LINGORA pos_tag only supports English and Russian "
                                  "(i.e. lang='eng' or lang='rus')")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger.load(lang)
    tokens = list(tokens)
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("tokens must be strings")
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        src = "en-ptb" if lang == "eng" else "ru-rnc"
        if lang == "eng":
            table = _universal_map_en()
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, map_tag(src, "universal", t)) for w, t in tagged]
    return tagged
