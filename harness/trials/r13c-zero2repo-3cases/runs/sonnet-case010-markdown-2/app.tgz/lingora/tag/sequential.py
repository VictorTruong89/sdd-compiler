"""Trainable sequential taggers."""
import re
from collections import Counter, defaultdict


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self] + (backoff._taggers if backoff is not None else [])
        self.backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not str")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), tag) for rx, tag in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = context_to_tag if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        return self._context_to_tag.get(self.context(tokens, index, history))

    def size(self):
        return len(self._context_to_tag)


class NgramTagger(ContextTagger):
    _n = 1

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._cutoff = cutoff
        if train is not None and model is None:
            self._train(train)

    def context(self, tokens, index, history):
        tag_ctx = tuple(history[max(0, index - self._n + 1):index])
        return tag_ctx, tokens[index]

    def _train(self, tagged_corpus):
        fd = defaultdict(Counter)
        for sent in tagged_corpus:
            tokens = [w for w, _ in sent]
            tags = [t for _, t in sent]
            for i in range(len(sent)):
                fd[self.context(tokens, i, tags)][tags[i]] += 1
        for ctx, counter in fd.items():
            tag, count = counter.most_common(1)[0]
            if count > self._cutoff:
                self._context_to_tag[ctx] = tag


class UnigramTagger(NgramTagger):
    _n = 1

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(NgramTagger):
    _n = 2


class TrigramTagger(NgramTagger):
    _n = 3


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2,
                 backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            fd = defaultdict(Counter)
            for sent in train:
                tokens = [w for w, _ in sent]
                for i, (w, t) in enumerate(sent):
                    ctx = self.context(tokens, i, None)
                    if ctx is not None:
                        fd[ctx][t] += 1
            for ctx, c in fd.items():
                tag, n = c.most_common(1)[0]
                if n > cutoff:
                    self._context_to_tag[ctx] = tag

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]
