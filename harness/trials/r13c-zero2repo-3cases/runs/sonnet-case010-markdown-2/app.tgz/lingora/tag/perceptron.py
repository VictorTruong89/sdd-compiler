"""Averaged perceptron tagger (after textblob-aptagger), reading packaged JSON models."""
import json
import os
from collections import defaultdict

from lingora import data

START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]

_cache = {}


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        paths = [os.path.join(d, "averaged_perceptron_tagger_%s.%s.json" % (lang, k))
                 for k in ("weights", "tagdict", "classes")]
        sig = []
        for p in paths:
            if not os.path.isfile(p):
                raise LookupError("tagger model file missing: %s" % p)
            st = os.stat(p)
            sig.append((p, st.st_mtime_ns, st.st_size))
        sig = tuple(sig)
        if sig not in _cache:
            objs = []
            for p in paths:
                with open(p, encoding="utf-8") as f:
                    objs.append(json.load(f))
            _cache.clear()
            _cache[sig] = cls(*objs)
        return _cache[sig]

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = START
        output = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output
