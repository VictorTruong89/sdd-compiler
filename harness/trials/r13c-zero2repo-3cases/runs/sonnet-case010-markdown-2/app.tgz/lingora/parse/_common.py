from lingora.grammar import CFG


def check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not str")
    known = grammar.terminals()
    for t in tokens:
        if t not in known:
            raise ValueError("Grammar does not cover some of the input words: %r" % (t,))


def check_grammar(grammar):
    if isinstance(grammar, str):
        return CFG.fromstring(grammar)
    return grammar
