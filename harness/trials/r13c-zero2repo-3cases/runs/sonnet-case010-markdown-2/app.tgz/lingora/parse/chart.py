"""Exhaustive chart-style parser (memoised top-down over spans)."""
from lingora.grammar import Nonterminal
from lingora.parse._common import check_grammar, check_tokens
from lingora.tree import Tree


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = check_grammar(grammar)

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = list(tokens)
        check_tokens(self._grammar, tokens)
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()

        def nt_trees(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            out = []
            for prod in g.productions(sym):
                for kids in seq(prod.rhs(), 0, i, j):
                    out.append(tree_class(sym.symbol(), kids))
            active.discard(key)
            memo[key] = out
            return out

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            s = rhs[k]
            rest_min = 0
            if isinstance(s, str):
                if i < j and tokens[i] == s:
                    for tail in seq(rhs, k + 1, i + 1, j):
                        yield [s] + tail
                elif s == "" :
                    for tail in seq(rhs, k + 1, i, j):
                        yield [s] + tail
                return
            for m in range(i, j + 1):
                ts = nt_trees(s, i, m)
                if not ts:
                    continue
                for tail in seq(rhs, k + 1, m, j):
                    for t in ts:
                        yield [t] + tail

        return iter(nt_trees(g.start(), 0, n))
