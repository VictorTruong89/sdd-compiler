from lingora.parse.chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Finds all parses (same results as the exhaustive chart parser)."""
