"""Shift-reduce parser: one left-to-right pass, no backtracking."""
from lingora.grammar import Nonterminal
from lingora.parse._common import check_grammar, check_tokens
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = check_grammar(grammar)

    def grammar(self):
        return self._grammar

    def _match(self, stack, rhs):
        k = len(rhs)
        if k == 0 or len(stack) < k:
            return False
        for s, r in zip(stack[len(stack) - k:], rhs):
            if isinstance(r, Nonterminal):
                if not (isinstance(s, Tree) and s.label() == r.symbol()):
                    return False
            else:
                if isinstance(s, Tree) or s != r:
                    return False
        return True

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            if self._match(stack, prod.rhs()):
                k = len(prod.rhs())
                children = stack[len(stack) - k:]
                del stack[len(stack) - k:]
                stack.append(Tree(prod.lhs().symbol(), children))
                return True
        return False

    def parse(self, tokens):
        tokens = list(tokens)
        check_tokens(self._grammar, tokens)
        stack = []
        for tok in tokens:
            stack.append(tok)
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and \
                stack[0].label() == self._grammar.start().symbol():
            return iter([stack[0]])
        return iter([])
