from lingora.tokenize.regexp import (
    BlanklineTokenizer, RegexpTokenizer, WhitespaceTokenizer, WordPunctTokenizer,
    blankline_tokenize, wordpunct_tokenize)
from lingora.tokenize.treebank import NLTKWordTokenizer, TreebankWordTokenizer, _treebank
from lingora.tokenize.tweet import TweetTokenizer
from lingora.tokenize.punkt import PunktSentenceTokenizer

__all__ = [
    "BlanklineTokenizer", "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
    "WhitespaceTokenizer", "WordPunctTokenizer", "NLTKWordTokenizer", "PunktSentenceTokenizer",
    "blankline_tokenize", "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
]


def sent_tokenize(text, language="english"):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return PunktSentenceTokenizer(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _treebank.tokenize(sent)]
