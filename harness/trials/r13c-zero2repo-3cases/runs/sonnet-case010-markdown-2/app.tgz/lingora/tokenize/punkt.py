"""Punkt sentence boundary detection (Kiss & Strunk 2006), using packaged parameters."""
import os
import re
from collections import defaultdict

from lingora import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

_RE_NON_PUNCT = re.compile(r"[^\W\d]", re.UNICODE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"^\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"^[^\W\d]+$", re.UNICODE)

_SENT_END_CHARS = (".", "?", "!")
_RE_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_RE_NON_WORD_CHARS = r"(?:[?!)\";}\]\*:@\'\({\[])"
_RE_MULTI_CHAR_PUNCT = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_TOKENIZE_FMT = r"""(
    %(MultiChar)s
    |
    (?=%(WordStart)s)\S+?
    (?=
        \s|
        $|
        %(NonWord)s|%(MultiChar)s|
        ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
    )
    |
    \S
)"""
_PERIOD_CONTEXT_FMT = r"""
    %(SentEndChars)s
    (?=(?P<after_tok>
        %(NonWord)s
        |
        \s+(?P<next_tok>\S+)
    ))"""
_WORD_RE = re.compile(_WORD_TOKENIZE_FMT % {
    "NonWord": _RE_NON_WORD_CHARS, "MultiChar": _RE_MULTI_CHAR_PUNCT, "WordStart": _RE_WORD_START},
    re.UNICODE | re.VERBOSE)
_PERIOD_RE = re.compile(_PERIOD_CONTEXT_FMT % {
    "NonWord": _RE_NON_WORD_CHARS, "SentEndChars": r"[%s]" % re.escape("".join(_SENT_END_CHARS))},
    re.UNICODE | re.VERBOSE)
_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)


class _Token:
    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = defaultdict(int)


_cache = {}


def _load(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    files = ["abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"]
    sig = [d]
    for f in files:
        p = os.path.join(d, f)
        if not os.path.isfile(p):
            raise LookupError("Punkt model file missing: %s" % p)
        st = os.stat(p)
        sig.append((st.st_mtime_ns, st.st_size))
    sig = tuple(sig)
    if sig in _cache:
        return _cache[sig]

    def lines(f):
        with open(os.path.join(d, f), encoding="utf-8", newline="") as fh:
            return [l for l in fh.read().splitlines()]

    p = PunktParameters()
    p.abbrev_types = {l for l in lines(files[0]) if l != ""}
    p.sent_starters = {l for l in lines(files[1]) if l != ""}
    for l in lines(files[2]):
        if l.strip() == "":
            continue
        parts = l.split("\t")
        if len(parts) >= 2:
            p.collocations.add((parts[0], parts[1]))
    for l in lines(files[3]):
        if l.strip() == "":
            continue
        parts = l.split("\t")
        if len(parts) >= 2:
            p.ortho_context[parts[0]] = int(parts[1])
    _cache.clear()
    _cache[sig] = p
    return p


class PunktSentenceTokenizer:
    def __init__(self, language="english", params=None):
        self._params = params if params is not None else _load(language)

    # --- tokenization
    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                toks = _WORD_RE.findall(line)
                if not toks:
                    continue
                yield _Token(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for t in toks[1:]:
                    yield _Token(t)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in _SENT_END_CHARS:
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            low = t[:-1].lower()
            if low in self._params.abbrev_types or low.split("-")[-1] in self._params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho_heuristic(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context[tok.type_no_sentperiod]
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None:
            return
        if not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho_heuristic(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            r = self._ortho_heuristic(t2)
            if r is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (r == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context[next_typ] & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _text_contains_sentbreak(self, text):
        found = False
        for tok in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws_index(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i].isspace():
                return i
        return 0

    def _match_potential_end_contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _PERIOD_RE.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = self._last_ws_index(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            pw = (idx, match.start())
            if prev_match and prev_slice[1] <= pw[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = pw
        if prev_match:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices_from_text(self, text):
        last_break = 0
        for match, context in self._match_potential_end_contexts(text):
            if self._text_contains_sentbreak(context):
                yield (last_break, match.end())
                if match.group("next_tok"):
                    last_break = match.start("next_tok")
                else:
                    last_break = match.end()
        yield (last_break, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _REALIGN.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text, realign_boundaries=True):
        slices = self._slices_from_text(text)
        if realign_boundaries:
            slices = self._realign(text, slices)
        return list(slices)

    def tokenize(self, text, realign_boundaries=True):
        return [text[s:e] for s, e in self.span_tokenize(text, realign_boundaries)]
