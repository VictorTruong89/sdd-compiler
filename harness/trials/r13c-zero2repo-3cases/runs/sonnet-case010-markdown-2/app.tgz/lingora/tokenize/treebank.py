import re


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text, convert_parentheses=False, return_str=False):
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        r, s = self.PARENS_BRACKETS
        text = r.sub(s, text)
        r, s = self.DOUBLE_DASHES
        text = r.sub(s, text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 ", text)
        return text if return_str else text.split()

    def tokenize_sents(self, strings):
        return [self.tokenize(s) for s in strings]


class NLTKWordTokenizer(TreebankWordTokenizer):
    """Improved Penn Treebank tokenizer (the recommended word tokenizer)."""

    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$"), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])"), r" \1 "),
    ] + TreebankWordTokenizer.ENDING_QUOTES


_treebank = NLTKWordTokenizer()
