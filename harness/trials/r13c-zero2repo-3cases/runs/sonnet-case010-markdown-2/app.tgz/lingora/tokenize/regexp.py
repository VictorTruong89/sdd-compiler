import re

_FLAGS = re.UNICODE | re.MULTILINE | re.DOTALL


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=_FLAGS):
        pattern = getattr(pattern, "pattern", pattern)
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            toks = self._regexp.split(text)
            if self._discard_empty:
                toks = [t for t in toks if t]
            return toks
        toks = [m.group(0) for m in self._regexp.finditer(text)]
        if self._discard_empty:
            toks = [t for t in toks if t]
        return toks

    def span_tokenize(self, text):
        if self._gaps:
            spans = []
            last = 0
            for m in self._regexp.finditer(text):
                if m.end() == m.start() and (m.start() == 0 or m.start() == len(text)):
                    continue
                spans.append((last, m.start()))
                last = m.end()
            spans.append((last, len(text)))
        else:
            spans = [m.span() for m in self._regexp.finditer(text)]
        for s, e in spans:
            if self._discard_empty and s == e:
                continue
            yield (s, e)

    def tokenize_sents(self, strings):
        return [self.tokenize(s) for s in strings]

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)
