"""Sentence-level BLEU."""
import math
from collections import Counter


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _closest_ref_len(references, hyp_len):
    lens = [len(r) for r in references]
    return min(lens, key=lambda l: (abs(l - hyp_len), l))


def _brevity_penalty(closest, hyp_len):
    if hyp_len > closest:
        return 1.0
    if hyp_len == 0:
        return 0.0
    return math.exp(1 - closest / hyp_len)


class SmoothingFunction:
    """Subset of smoothing methods; each takes (p_n list of (num, den), hyp_len)."""

    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon, self.alpha, self.k = epsilon, alpha, k

    def method0(self, p_n, hyp_len=None):
        return p_n

    def method1(self, p_n, hyp_len=None):
        return [(n + self.epsilon, d) if n == 0 else (n, d) for n, d in p_n]

    def method2(self, p_n, hyp_len=None):
        return [(n + 1, d + 1) if i != 0 else (n, d) for i, (n, d) in enumerate(p_n)]

    def method3(self, p_n, hyp_len=None):
        out = []
        incvnt = 1
        for n, d in p_n:
            if n == 0:
                incvnt *= 2
                out.append((1.0 / (incvnt * d if d else incvnt), 1))
            else:
                out.append((n, d))
        return out

    def method4(self, p_n, hyp_len=None):
        return self.method1(p_n, hyp_len)

    __call__ = method1


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(references, tuple):
        references = list(references)
    if not references:
        raise ValueError("references must not be empty")
    weights = list(weights)
    hyp_len = len(hypothesis)
    p_n = []
    for i in range(1, len(weights) + 1):
        hc = _ngrams(hypothesis, i)
        mx = Counter()
        for ref in references:
            for g, c in _ngrams(ref, i).items():
                if c > mx[g]:
                    mx[g] = c
        num = sum(min(c, mx[g]) for g, c in hc.items())
        den = max(1, sum(hc.values()))
        p_n.append((num, den))
    if p_n[0][0] == 0:
        return 0
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, hyp_len) if _takes_two(smoothing_function) else smoothing_function(p_n)
    bp = _brevity_penalty(_closest_ref_len(references, hyp_len), hyp_len)
    s = 0.0
    for w, (n, d) in zip(weights, p_n):
        if n == 0:
            if w == 0:
                continue
            return 0
        s += w * math.log(n / d)
    return bp * math.exp(s)


def _takes_two(f):
    import inspect
    try:
        params = inspect.signature(f).parameters
    except (TypeError, ValueError):
        return False
    return len(params) >= 2 or any(p.kind == p.VAR_POSITIONAL for p in params.values())


sentence_bleu = bleu
