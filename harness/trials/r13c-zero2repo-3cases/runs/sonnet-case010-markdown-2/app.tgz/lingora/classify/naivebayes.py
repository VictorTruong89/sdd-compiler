"""Naive Bayes classifier with expected-likelihood-estimate smoothing."""
import math
from collections import defaultdict

from lingora.classify.api import ClassifierI


class DictionaryProbDist:
    def __init__(self, prob_dict, log=False, normalize=False):
        self._prob = dict(prob_dict)
        if normalize:
            if log:
                vals = list(self._prob.values())
                m = max(vals)
                total = m + math.log(sum(math.exp(v - m) for v in vals))
                self._prob = {k: math.exp(v - total) for k, v in self._prob.items()}
            else:
                total = sum(self._prob.values())
                self._prob = {k: v / total for k, v in self._prob.items()}
        elif log:
            self._prob = {k: math.exp(v) for k, v in self._prob.items()}

    def prob(self, sample):
        return float(self._prob.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._prob.keys())

    def max(self):
        best = None
        for k, v in self._prob.items():
            if best is None or v > self._prob[best]:
                best = k
        return best


class NaiveBayesClassifier(ClassifierI):
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist  # {label: p}
        self._feature_probdist = feature_probdist  # {(label, fname): (counts dict, bins)}
        self._labels = list(label_probdist)

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def prob_classify(self, featureset):
        featureset = {f: v for f, v in featureset.items()
                      if any((l, f) in self._feature_probdist for l in self._labels)}
        logprob = {}
        for label in self._labels:
            logprob[label] = math.log(self._label_probdist[label])
        for label in self._labels:
            for fname, fval in featureset.items():
                counts, n, bins = self._feature_probdist[(label, fname)]
                try:
                    c = counts.get(fval, 0)
                except TypeError:
                    c = 0
                logprob[label] += math.log((c + 0.5) / (n + 0.5 * bins))
        return DictionaryProbDist(logprob, normalize=True, log=True)

    @classmethod
    def train(cls, labeled_featuresets):
        label_counts = {}
        feature_counts = defaultdict(dict)
        feature_values = defaultdict(set)
        fnames = set()
        for featureset, label in labeled_featuresets:
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, fval in featureset.items():
                d = feature_counts[(label, fname)]
                d[fval] = d.get(fval, 0) + 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label, num in label_counts.items():
            for fname in fnames:
                d = feature_counts[(label, fname)]
                count = sum(d.values())
                if num - count > 0:
                    d[None] = d.get(None, 0) + num - count
                    feature_values[fname].add(None)
        total = sum(label_counts.values())
        nl = len(label_counts)
        label_prob = {l: (c + 0.5) / (total + 0.5 * nl) for l, c in label_counts.items()}
        fp = {}
        for key, d in feature_counts.items():
            fp[key] = (d, sum(d.values()), len(feature_values[key[1]]))
        return cls(label_prob, fp)
