def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    results = classifier.classify_many([fs for fs, _ in gold])
    correct = [l == r for (_, l), r in zip(gold, results)]
    return sum(correct) / len(correct)
