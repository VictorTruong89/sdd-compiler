class ClassifierI:
    def labels(self):
        raise NotImplementedError

    def classify(self, featureset):
        raise NotImplementedError

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]
