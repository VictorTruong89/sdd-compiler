"""Decision tree classifier (stump-based, after the classic recursive refinement)."""
import math
from collections import Counter, defaultdict

from lingora.classify.api import ClassifierI


def _majority(counter):
    best, bc = None, -1
    for k, c in counter.items():
        if c > bc:
            best, bc = k, c
    return best


def _entropy(counter):
    n = sum(counter.values())
    if n == 0:
        return 0.0
    return -sum((c / n) * math.log2(c / n) for c in counter.values() if c)


class DecisionTreeClassifier(ClassifierI):
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        labels = [self._label]
        if self._decisions:
            for d in self._decisions.values():
                labels.extend(d.labels())
        if self._default is not None:
            labels.extend(self._default.labels())
        return list(set(labels))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        try:
            if fval in self._decisions:
                return self._decisions[fval].classify(featureset)
        except TypeError:
            pass
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = 0
        for fs, label in labeled_featuresets:
            if self.classify(fs) != label:
                errors += 1
        return errors / len(labeled_featuresets)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("no training data")
        feature_names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    feature_names.append(f)
        tree = DecisionTreeClassifier.best_stump(feature_names, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree

    @staticmethod
    def leaf(labeled_featuresets):
        return DecisionTreeClassifier(_majority(Counter(l for _, l in labeled_featuresets)))

    @staticmethod
    def stump(feature_name, labeled_featuresets):
        label = _majority(Counter(l for _, l in labeled_featuresets))
        by_val = defaultdict(Counter)
        for fs, l in labeled_featuresets:
            by_val[fs.get(feature_name)][l] += 1
        decisions = {v: DecisionTreeClassifier(_majority(c)) for v, c in by_val.items()}
        return DecisionTreeClassifier(label, feature_name, decisions)

    @staticmethod
    def best_stump(feature_names, labeled_featuresets):
        best = DecisionTreeClassifier.leaf(labeled_featuresets)
        best_err = best.error(labeled_featuresets)
        for fname in feature_names:
            st = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = st.error(labeled_featuresets)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, labeled_featuresets, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled_featuresets) <= support_cutoff:
            return
        if self._fname is None:
            return
        if depth_cutoff <= 1:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) == fval]
            if _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled_featuresets
                   if fs.get(self._fname) not in self._decisions]
            if _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
