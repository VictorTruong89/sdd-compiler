"""Regular-expression chunk parser."""
import re

from lingora.tree import Tree

IN_CHUNK = r"(?=[^\{]*\})"
IN_CHINK = r"(?=[^\}]*(\{|$))"


def tag_pattern2re_pattern(tag_pattern):
    tag_pattern = re.sub(r"\s", "", tag_pattern)
    tag_pattern = re.sub(r"<", "(<(", tag_pattern)
    tag_pattern = re.sub(r">", ")>)", tag_pattern)
    tag_pattern = re.sub(r"([^\\])\.", r"\1[^\{\}<>]", tag_pattern)
    tag_pattern = re.sub(r"^\.", r"[^\{\}<>]", tag_pattern)
    try:
        re.compile(tag_pattern)
    except re.error as e:
        raise ValueError("Bad tag pattern: %r (%s)" % (tag_pattern, e))
    return tag_pattern


class _Rule:
    def __init__(self, tag_pattern, kind):
        self._kind = kind
        pat = tag_pattern2re_pattern(tag_pattern)
        if kind == "chunk":
            self._regexp = re.compile(r"(?P<chunk>%s)%s" % (pat, IN_CHINK))
            self._repl = r"{\g<chunk>}"
        else:
            self._regexp = re.compile(r"(?P<chink>%s)%s" % (pat, IN_CHUNK))
            self._repl = r"}\g<chink>{"

    @staticmethod
    def fromstring(s):
        m = re.match(r"(?P<rule>(\\.|[^#])*)(?P<comment>#.*)?", s)
        rule = m.group("rule").strip()
        if not rule:
            raise ValueError("Empty chunk pattern")
        if rule[0] == "{" and rule[-1] == "}":
            return _Rule(rule[1:-1], "chunk")
        if rule[0] == "}" and rule[-1] == "{":
            return _Rule(rule[1:-1], "chink")
        raise ValueError("Illegal chunk pattern: %s" % rule)

    def apply(self, s):
        s = self._regexp.sub(self._repl, s)
        return s.replace("{}", "")


class RegexpChunkParser:
    def __init__(self, rules, chunk_label="NP", root_label="S"):
        self._rules = list(rules)
        self._chunk_label = chunk_label
        self._root_label = root_label

    def parse(self, chunk_struct):
        if isinstance(chunk_struct, str):
            raise TypeError("expected a list of tagged tokens")
        pieces = list(chunk_struct)
        tags = []
        for p in pieces:
            if isinstance(p, Tree):
                tags.append(p.label())
            elif isinstance(p, (tuple, list)) and len(p) >= 2:
                tags.append(p[1])
            else:
                raise ValueError("expected (token, tag) pairs")
        s = "".join("<%s>" % ("" if t is None else t) for t in tags)
        for rule in self._rules:
            s = rule.apply(s)
        tree = Tree(self._root_label, [])
        index = 0
        for i, piece in enumerate(re.split(r"[{}]", s)):
            length = piece.count("<")
            sub = pieces[index:index + length]
            if i % 2 == 0:
                tree.extend(sub)
            else:
                tree.append(Tree(self._chunk_label, sub))
            index += length
        return tree


class RegexpParser:
    def __init__(self, grammar, root_label="S", loop=1):
        self._stages = []
        self._grammar = grammar
        self._loop = loop
        if isinstance(grammar, str):
            self._read_grammar(grammar, root_label)
        elif isinstance(grammar, (list, tuple)) and all(hasattr(g, "parse") for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("the grammar must be a string or a list of chunk parsers")

    def _read_grammar(self, grammar, root_label):
        rules = []
        lhs = None
        for line in grammar.split("\n"):
            line = line.strip()
            m = re.match(r"(?P<nonterminal>(\\.|[^:])*)(:(?P<rule>.*))", line)
            if m:
                if lhs is not None or rules:
                    self._add_stage(rules, lhs, root_label)
                lhs = m.group("nonterminal").strip()
                rules = []
                line = m.group("rule").strip()
            if line == "" or line.startswith("#"):
                continue
            rules.append(_Rule.fromstring(line))
        if lhs is not None or rules:
            self._add_stage(rules, lhs, root_label)

    def _add_stage(self, rules, lhs, root_label):
        if rules or lhs is not None:
            self._stages.append(RegexpChunkParser(rules, chunk_label=lhs, root_label=root_label))

    def parse(self, chunk_struct):
        if isinstance(chunk_struct, str):
            raise TypeError("expected a list of tagged tokens")
        chunk_struct = list(chunk_struct) if not isinstance(chunk_struct, Tree) else chunk_struct
        for _ in range(self._loop):
            for stage in self._stages:
                chunk_struct = stage.parse(chunk_struct)
        if not isinstance(chunk_struct, Tree):
            chunk_struct = Tree("S", list(chunk_struct))
        return chunk_struct
