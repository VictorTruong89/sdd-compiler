"""Named-entity chunker (resource gated)."""
from lingora import data
from lingora.tree import Tree

_MODEL = "chunkers/maxent_ne_chunker_tab/english_ace_multiclass"
_WORDS = "corpora/words"


def ne_chunk(tagged_tokens, binary=False):
    data.find(_MODEL)
    data.find(_WORDS)
    if isinstance(tagged_tokens, str):
        raise TypeError("expected a list of tagged tokens")
    return Tree("S", list(tagged_tokens))
