"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(self._symbol)

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


def is_nonterminal(x):
    return isinstance(x, Nonterminal)


def is_terminal(x):
    return not isinstance(x, Nonterminal)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_nonlexical(self):
        return all(is_nonterminal(s) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return list(self._lhs_index.get(lhs, []))

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    out.add(s)
        return out

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    %s" % p for p in self._productions)

    __repr__ = __str__

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            lines = list(input)
        else:
            lines = input.splitlines()
        productions = []
        start = None
        cur_lhs = None
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\S+?)\s*(?:->|=>)\s*(.*)$", line)
            if m:
                cur_lhs = Nonterminal(m.group(1))
                rest = m.group(2)
            elif line.startswith("|") and cur_lhs is not None:
                rest = line
            else:
                raise ValueError("Unable to parse line: %r" % raw)
            if start is None:
                start = cur_lhs
            rest = rest.strip()
            toks = _TOKEN.findall(rest)
            if "".join(toks).replace("|", "") == "" and not toks:
                pass
            alts = [[]]
            for t in toks:
                if t == "|":
                    alts.append([])
                elif len(t) >= 2 and t[0] in "'\"" and t[-1] == t[0]:
                    alts[-1].append(t[1:-1])
                else:
                    alts[-1].append(Nonterminal(t))
            if m is None and alts and not toks[0:1] == ["|"]:
                pass
            if rest.startswith("|") and m is None:
                alts = alts[1:]
            for a in alts:
                productions.append(Production(cur_lhs, a))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, productions)


def nonterminals_of(grammar):
    return {p.lhs() for p in grammar.productions()}
