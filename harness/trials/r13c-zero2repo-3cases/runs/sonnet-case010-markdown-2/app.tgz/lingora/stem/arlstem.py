"""Arabic light stemmers (ARLSTem family)."""
import re

_DIAC = re.compile("[ً-ْـ]")
_PREFIXES = ("وال", "بال", "كال", "فال", "ولل", "ال", "لل", "وب", "ول", "فب", "فل", "و", "ب", "ل", "ف")
_SUFFIXES = ("ات", "ان", "ين", "ون", "ها", "هم", "كم", "نا", "تم", "ية", "وا", "تي", "ة", "ه", "ي", "ا")


class ARLSTem:
    def __init__(self):
        self.re_hamza = re.compile("[ءؤئ]")
        self.re_alef = re.compile("[آأإ]")

    def norm(self, word):
        word = _DIAC.sub("", word)
        word = self.re_hamza.sub("ء", word)
        return self.re_alef.sub("ا", word)

    def stem(self, word):
        word = self.norm(word)
        for p in _PREFIXES:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in _SUFFIXES:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[:-len(s)]
                break
        return word
