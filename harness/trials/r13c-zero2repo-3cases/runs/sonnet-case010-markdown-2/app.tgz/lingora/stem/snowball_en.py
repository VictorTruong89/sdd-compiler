"""Snowball English (Porter2) stemmer."""
from lingora.stem._sb import longest

V = "aeiouy"
SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
EXC2 = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")
STEP2 = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
         "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
         "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
         "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
         "ogi": "og", "fulli": "ful", "lessli": "less", "li": ""}
STEP3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
         "ical": "ic", "ful": "", "ness": "", "ative": ""}
STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
         "ism", "ate", "iti", "ous", "ive", "ize", "ion")


def _regions(word):
    p1 = len(word)
    if word.startswith(("gener", "arsen")):
        p1 = 5
    elif word.startswith("commun"):
        p1 = 6
    else:
        for i in range(1, len(word)):
            if word[i] not in V and word[i - 1] in V:
                p1 = i + 1
                break
    p2 = len(word)
    for i in range(p1 + 1, len(word)):
        if word[i] not in V and word[i - 1] in V:
            p2 = i + 1
            break
    return p1, p2


def _short_syllable(w):
    if len(w) == 2:
        return w[0] in V and w[1] not in V
    if len(w) >= 3:
        return (w[-1] not in V and w[-1] not in "wxY" and w[-2] in V and w[-3] not in V)
    return False


def stem(word):
    word = word.lower()
    if word in SPECIAL:
        return SPECIAL[word]
    word = word.replace("’", "'").replace("‘", "'").replace("‛", "'")
    if len(word) <= 2:
        return word
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    for i in range(1, len(word)):
        if word[i - 1] in V and word[i] == "y":
            word = word[:i] + "Y" + word[i + 1:]
    p1, p2 = _regions(word)

    # step 0
    for s in ("'s'", "'s", "'"):
        if word.endswith(s):
            word = word[:-len(s)]
            break
    # step 1a
    s = longest(word, ("sses", "ied", "ies", "us", "ss", "s"))
    if s == "sses":
        word = word[:-2]
    elif s in ("ied", "ies"):
        word = word[:-2] if len(word) - len(s) > 1 else word[:-1]
    elif s == "s":
        if any(c in V for c in word[:-2]):
            word = word[:-1]
    if word in EXC2:
        return word
    # step 1b
    s = longest(word, ("eedly", "ingly", "edly", "eed", "ing", "ed"))
    if s in ("eed", "eedly"):
        if len(word) - len(s) >= p1:
            word = word[:-len(s)] + "ee"
    elif s:
        stem_ = word[:-len(s)]
        if any(c in V for c in stem_):
            word = stem_
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                word = word[:-1]
            elif len(word) == p1 and _short_syllable(word):
                word += "e"
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in V:
        word = word[:-1] + "i"
    # step 2
    s = longest(word, STEP2)
    if s and len(word) - len(s) >= p1:
        base = word[:-len(s)]
        if s == "ogi":
            if base.endswith("l"):
                word = base + "og"
        elif s == "li":
            if base and base[-1] in "cdeghkmnrt":
                word = base
        else:
            word = base + STEP2[s]
    # step 3
    s = longest(word, STEP3)
    if s and len(word) - len(s) >= p1:
        if s == "ative":
            if len(word) - len(s) >= p2:
                word = word[:-len(s)]
        else:
            word = word[:-len(s)] + STEP3[s]
    # step 4
    s = longest(word, STEP4)
    if s and len(word) - len(s) >= p2:
        base = word[:-len(s)]
        if s == "ion":
            if base.endswith(("s", "t")):
                word = base
        else:
            word = base
    # step 5
    if word.endswith("e"):
        pos = len(word) - 1
        if pos >= p2 or (pos >= p1 and not _short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if len(word) - 1 >= p2 and word[:-1].endswith("l"):
            word = word[:-1]
    return word.replace("Y", "y")
