"""Helpers shared by the Snowball stemmers."""


def longest(word, suffixes, limit=0):
    best = ""
    for s in suffixes:
        if len(s) > len(best) and word.endswith(s) and len(word) - len(s) >= limit:
            best = s
    return best


def region_after_nonvowel(word, vowels, start=0):
    """Index after the first non-vowel that follows a vowel, searching from start."""
    for i in range(start + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            return i + 1
    return len(word)


def r1r2(word, vowels):
    r1 = region_after_nonvowel(word, vowels, 0)
    r2 = region_after_nonvowel(word, vowels, r1) if r1 < len(word) else len(word)
    return r1, r2


def rv_romance(word, vowels):
    """RV as used by Spanish / Italian / Portuguese."""
    n = len(word)
    if n < 2:
        return n
    if word[0] not in vowels:
        if word[1] in vowels:
            # consonant-vowel start: region after the third letter
            return 3 if n >= 3 else n
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    for i in range(2, n):
        if word[i] not in vowels:
            return i + 1
    return n
