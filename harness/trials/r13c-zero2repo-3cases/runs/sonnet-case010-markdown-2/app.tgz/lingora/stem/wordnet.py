"""WordNet lemmatizer reading the packaged WordNet database files."""
import os

from lingora import data

_SUBST = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    def __init__(self):
        self._root = data.find("corpora/wordnet")
        if not os.path.isdir(self._root):
            raise LookupError("WordNet is not available as a directory: %s" % self._root)
        self._lemmas = {}
        self._exc = {}
        for pos, name in _FILES.items():
            idx = os.path.join(self._root, "index." + name)
            if not os.path.isfile(idx):
                raise LookupError("WordNet file missing: %s" % idx)
            s = set()
            with open(idx, encoding="utf-8") as f:
                for line in f:
                    if line.startswith(" ") or not line.strip():
                        continue
                    s.add(line.split(" ", 1)[0])
            self._lemmas[pos] = s
            exc = {}
            p = os.path.join(self._root, name + ".exc")
            if os.path.isfile(p):
                with open(p, encoding="utf-8") as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 2:
                            exc[parts[0]] = parts[1:]
            self._exc[pos] = exc

    def _morphy(self, form, pos):
        if pos == "s":
            pos = "a"
        if pos not in _FILES:
            return []
        exceptions = self._exc[pos]
        subs = _SUBST[pos]
        known = self._lemmas[pos]

        def apply(forms):
            return [f[:-len(old)] + new for f in forms for old, new in subs if f.endswith(old)]

        def filt(forms):
            out, seen = [], set()
            for f in forms:
                if f in known and f not in seen:
                    out.append(f)
                    seen.add(f)
            return out

        if form in exceptions:
            return filt([form] + exceptions[form])
        forms = apply([form])
        res = filt([form] + forms)
        if res:
            return res
        while forms:
            forms = apply(forms)
            res = filt(forms)
            if res:
                return res
        return []

    def lemmatize(self, word, pos="n"):
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word
