from lingora.stem.arlstem import ARLSTem


class ARLSTem2(ARLSTem):
    def stem(self, word):
        word = ARLSTem.stem(self, word)
        if len(word) > 3 and word[0] in "تنيا" and len(word) >= 5:
            word = word[1:]
        return word
