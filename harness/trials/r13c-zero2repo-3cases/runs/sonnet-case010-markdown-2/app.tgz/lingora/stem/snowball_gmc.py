"""Snowball: German, Dutch, Swedish, Norwegian, Danish."""
from lingora.stem._sb import longest, r1r2, region_after_nonvowel


# ---------------------------------------------------------------- German
def german(word):
    V = "aeiouyäöü"
    word = word.lower().replace("ß", "ss")
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i] in "uy" and word[i - 1] in V and word[i + 1] in V:
            chars[i] = chars[i].upper()
    word = "".join(chars)
    V2 = V
    p1, p2 = r1r2(word, V2)
    p1 = max(p1, 3)
    p2 = max(p2, p1)

    # step 1
    s = longest(word, ("ern", "em", "er", "en", "es", "e", "s"))
    if s in ("ern", "em", "er") and len(word) - len(s) >= p1:
        word = word[:-len(s)]
    elif s in ("en", "es", "e") and len(word) - len(s) >= p1:
        word = word[:-len(s)]
        if word.endswith("niss"):
            word = word[:-1]
    elif s == "s" and len(word) - 1 >= p1 and len(word) >= 2 and word[-2] in "bdfghklmnrt":
        word = word[:-1]
    # step 2
    s = longest(word, ("en", "er", "est", "st"))
    if s in ("en", "er", "est") and len(word) - len(s) >= p1:
        word = word[:-len(s)]
    elif s == "st" and len(word) - 2 >= p1 and len(word) >= 6 and word[-3] in "bdfghklmnt":
        word = word[:-2]
    # step 3
    s = longest(word, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
    if s in ("end", "ung"):
        if len(word) - len(s) >= p2:
            word = word[:-len(s)]
            if word.endswith("ig") and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
                word = word[:-2]
    elif s in ("ig", "ik", "isch"):
        if len(word) - len(s) >= p2 and not word[:-len(s)].endswith("e"):
            word = word[:-len(s)]
    elif s in ("lich", "heit"):
        if len(word) - len(s) >= p2:
            word = word[:-len(s)]
            for e in ("er", "en"):
                if word.endswith(e) and len(word) - 2 >= p1:
                    word = word[:-2]
                    break
    elif s == "keit":
        if len(word) - 4 >= p2:
            word = word[:-4]
            for e in ("lich", "ig"):
                if word.endswith(e) and len(word) - len(e) >= p2:
                    word = word[:-len(e)]
                    break
    word = word.replace("U", "u").replace("Y", "y")
    return word.replace("ä", "a").replace("ö", "o").replace("ü", "u")


# ---------------------------------------------------------------- Dutch
def _dutch_undouble(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


def dutch(word):
    V = "aeiouyè"
    word = word.lower()
    for a, b in (("ä", "a"), ("ë", "e"), ("ï", "i"), ("ö", "o"), ("ü", "u"),
                 ("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        word = word.replace(a, b)
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(word)):
        if word[i] == "y" and word[i - 1] in V:
            chars[i] = "Y"
    word = "".join(chars)
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i] == "i" and word[i - 1] in V and word[i + 1] in V:
            chars[i] = "I"
    word = "".join(chars)
    p1, p2 = r1r2(word, V)
    p1 = max(p1, 3)
    p2 = max(p2, p1)

    def nonv(w, i):  # char at index i is a non-vowel
        return 0 <= i < len(w) and w[i] not in V

    # step 1
    s = longest(word, ("heden", "ene", "en", "se", "s"))
    if s == "heden" and len(word) - 5 >= p1:
        word = word[:-5] + "heid"
    elif s in ("en", "ene") and len(word) - len(s) >= p1:
        base = word[:-len(s)]
        if base and nonv(base, len(base) - 1) and not base.endswith("gem"):
            word = _dutch_undouble(base)
    elif s in ("s", "se") and len(word) - len(s) >= p1:
        base = word[:-len(s)]
        if base and nonv(base, len(base) - 1) and base[-1] != "j":
            word = base
    # step 2
    e_found = False
    if word.endswith("e") and len(word) - 1 >= p1 and nonv(word, len(word) - 2):
        word = _dutch_undouble(word[:-1])
        e_found = True
    # step 3a
    if word.endswith("heid") and len(word) - 4 >= p2 and not word[:-4].endswith("c"):
        word = word[:-4]
        if word.endswith("en") and len(word) - 2 >= p1:
            base = word[:-2]
            if base and nonv(base, len(base) - 1) and not base.endswith("gem"):
                word = _dutch_undouble(base)
    # step 3b
    s = longest(word, ("end", "ing", "ig", "lijk", "baar", "bar"))
    if s in ("end", "ing") and len(word) - 3 >= p2:
        word = word[:-3]
        if word.endswith("ig") and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
            word = word[:-2]
        else:
            word = _dutch_undouble(word)
    elif s == "ig" and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
        word = word[:-2]
    elif s == "lijk" and len(word) - 4 >= p2:
        word = word[:-4]
        if word.endswith("e") and len(word) - 1 >= p1 and nonv(word, len(word) - 2):
            word = _dutch_undouble(word[:-1])
    elif s == "baar" and len(word) - 4 >= p2:
        word = word[:-4]
    elif s == "bar" and len(word) - 3 >= p2 and e_found:
        word = word[:-3]
    # step 4
    if (len(word) >= 4 and word[-1] not in V and word[-1] != "I" and word[-4] not in V
            and word[-3:-1] in ("aa", "ee", "oo", "uu")):
        word = word[:-2] + word[-1]
    return word.replace("I", "i").replace("Y", "y")


# ---------------------------------------------------------------- Swedish
def swedish(word):
    V = "aeiouyäåö"
    word = word.lower()
    p1, _ = r1r2(word, V)
    p1 = max(p1, 3)
    suf1 = ("a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are",
            "aste", "en", "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as",
            "arnas", "ernas", "ornas", "es", "ades", "andes", "ens", "arens", "hetens", "erns",
            "at", "andet", "het", "ast")
    s = longest(word, suf1 + ("s",), p1)
    if s == "s":
        if len(word) >= 2 and word[-2] in "bcdfghjklmnoprtvy":
            word = word[:-1]
    elif s:
        word = word[:-len(s)]
    for pair in ("dd", "gd", "nn", "dt", "gt", "kt", "tt"):
        if word.endswith(pair) and len(word) - 2 >= p1:
            word = word[:-1]
            break
    s = longest(word, ("lig", "ig", "els", "löst", "fullt"), p1)
    if s in ("lig", "ig", "els"):
        word = word[:-len(s)]
    elif s == "löst":
        word = word[:-4] + "lös"
    elif s == "fullt":
        word = word[:-5] + "full"
    return word


# ---------------------------------------------------------------- Norwegian
def norwegian(word):
    V = "aeiouyæåø"
    word = word.lower()
    p1, _ = r1r2(word, V)
    p1 = max(p1, 3)
    suf = ("a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er",
           "heter", "as", "es", "edes", "endes", "enes", "hetenes", "ens", "hetens", "ers", "ets",
           "et", "het", "ast", "s", "erte", "ert")
    s = longest(word, suf, p1)
    if s == "s":
        if len(word) >= 2 and (word[-2] in "bcdfghjlmnoprtvyz"
                               or (word[-2] == "k" and len(word) >= 3 and word[-3] not in V)):
            word = word[:-1]
    elif s in ("erte", "ert"):
        word = word[:-len(s)] + "er"
    elif s:
        word = word[:-len(s)]
    if word.endswith(("dt", "vt")) and len(word) - 2 >= p1:
        word = word[:-1]
    s = longest(word, ("leg", "elig", "eleg", "ig", "eig", "lig", "els", "lov", "elov", "slov",
                       "hetslov"), p1)
    if s:
        word = word[:-len(s)]
    return word


# ---------------------------------------------------------------- Danish
def danish(word):
    V = "aeiouyæåø"
    word = word.lower()
    p1, _ = r1r2(word, V)
    p1 = max(p1, 3)
    suf = ("hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en",
           "heden", "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes",
           "ernes", "eres", "ens", "hedens", "erens", "ers", "ets", "erets", "et", "eret", "s")
    s = longest(word, suf, p1)
    if s == "s":
        if len(word) >= 2 and word[-2] in "abcdfghjklmnoprtvyzå":
            word = word[:-1]
    elif s:
        word = word[:-len(s)]

    def consonant_pair(w):
        for pair in ("gd", "dt", "gt", "kt"):
            if w.endswith(pair) and len(w) - 2 >= p1:
                return w[:-1]
        return w

    word = consonant_pair(word)
    if word.endswith("igst"):
        word = word[:-2]
    s = longest(word, ("elig", "lig", "ig", "els", "løst"), p1)
    if s in ("elig", "lig", "ig", "els"):
        word = consonant_pair(word[:-len(s)])
    elif s == "løst":
        word = word[:-1]
    if len(word) >= 2 and len(word) - 1 >= p1 and word[-1] == word[-2] and word[-1] not in V:
        word = word[:-1]
    return word
