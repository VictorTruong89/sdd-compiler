"""Snowball stemmer front end."""
import os

from lingora import data
from lingora.stem import snowball_en, snowball_gmc, snowball_other, snowball_romance
from lingora.stem.porter import PorterStemmer

_LANGS = {
    "arabic": snowball_other.arabic,
    "danish": snowball_gmc.danish,
    "dutch": snowball_gmc.dutch,
    "english": snowball_en.stem,
    "finnish": snowball_other.finnish,
    "french": snowball_romance.french,
    "german": snowball_gmc.german,
    "hungarian": snowball_other.hungarian,
    "italian": snowball_romance.italian,
    "norwegian": snowball_gmc.norwegian,
    "portuguese": snowball_romance.portuguese,
    "romanian": snowball_other.romanian,
    "russian": snowball_other.russian,
    "spanish": snowball_romance.spanish,
    "swedish": snowball_gmc.swedish,
}


class SnowballStemmer:
    languages = tuple(sorted(list(_LANGS) + ["porter"]))

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            try:
                lines = data.read_lines("corpora/stopwords/%s" % language)
            except LookupError as e:
                raise ValueError("stopwords for language %r are not available: %s" % (language, e))
            self.stopwords = {l.strip() for l in lines if l.strip()}
        if language == "porter":
            self._porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
            self._fn = self._porter.stem
        else:
            self._fn = _LANGS[language]

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self._fn(word)
