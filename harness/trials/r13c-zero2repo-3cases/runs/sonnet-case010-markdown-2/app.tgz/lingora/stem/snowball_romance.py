"""Snowball: Spanish, Portuguese, Italian, French."""
from lingora.stem._sb import longest, r1r2, rv_romance


# ---------------------------------------------------------------- Spanish
def spanish(word):
    V = "aeiouáéíóúü"
    word = word.lower()
    pv = rv_romance(word, V)
    p1, p2 = r1r2(word, V)

    # step 0: attached pronoun
    pron = longest(word, ("me", "se", "sela", "selo", "selas", "selos", "la", "le", "lo", "las",
                          "les", "los", "nos"))
    if pron:
        rest = word[:-len(pron)]
        form = longest(rest, ("iéndo", "ándo", "ár", "ér", "ír", "ando", "iendo", "ar", "er", "ir",
                              "yendo"))
        if form and len(rest) - len(form) >= pv:
            if form in ("iéndo", "ándo", "ár", "ér", "ír"):
                word = rest[:-len(form)] + {"iéndo": "iendo", "ándo": "ando", "ár": "ar",
                                            "ér": "er", "ír": "ir"}[form]
            elif form == "yendo":
                if rest[:-len(form)].endswith("u"):
                    word = rest
            else:
                word = rest
    # step 1
    done = False
    s = longest(word, (
        "anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible",
        "ibles", "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos", "imiento",
        "imientos", "adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes",
        "ancia", "ancias", "logía", "logías", "ución", "uciones", "encia", "encias", "amente",
        "mente", "idad", "idades", "iva", "ivo", "ivas", "ivos"))
    idx = len(word) - len(s)
    if s:
        base = word[:idx]
        if s in ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables",
                 "ible", "ibles", "ista", "istas", "oso", "osa", "osos", "osas", "amiento",
                 "amientos", "imiento", "imientos"):
            if idx >= p2:
                word, done = base, True
        elif s in ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes",
                   "ancia", "ancias"):
            if idx >= p2:
                word, done = base, True
                if word.endswith("ic") and len(word) - 2 >= p2:
                    word = word[:-2]
        elif s in ("logía", "logías"):
            if idx >= p2:
                word, done = base + "log", True
        elif s in ("ución", "uciones"):
            if idx >= p2:
                word, done = base + "u", True
        elif s in ("encia", "encias"):
            if idx >= p2:
                word, done = base + "ente", True
        elif s == "amente":
            if idx >= p1:
                word, done = base, True
                if word.endswith("iv") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("at") and len(word) - 2 >= p2:
                        word = word[:-2]
                else:
                    for e in ("os", "ic", "ad"):
                        if word.endswith(e):
                            if len(word) - 2 >= p2:
                                word = word[:-2]
                            break
        elif s == "mente":
            if idx >= p2:
                word, done = base, True
                for e in ("ante", "able", "ible"):
                    if word.endswith(e):
                        if len(word) - 4 >= p2:
                            word = word[:-4]
                        break
        elif s in ("idad", "idades"):
            if idx >= p2:
                word, done = base, True
                for e in ("abil", "ic", "iv"):
                    if word.endswith(e):
                        if len(word) - len(e) >= p2:
                            word = word[:-len(e)]
                        break
        elif s in ("iva", "ivo", "ivas", "ivos"):
            if idx >= p2:
                word, done = base, True
                if word.endswith("at") and len(word) - 2 >= p2:
                    word = word[:-2]
    if not done:
        # step 2a
        s = longest(word, ("ya", "ye", "yan", "yen", "yeron", "yendo", "yo", "yó", "yas", "yes",
                           "yais", "yamos"), pv)
        if s and word[:-len(s)].endswith("u"):
            word = word[:-len(s)]
        else:
            s = longest(word, (
                "en", "es", "éis", "emos", "arían", "arías", "arán", "arás", "aríais", "aría",
                "aréis", "aríamos", "aremos", "ará", "aré", "erían", "erías", "erán", "erás",
                "eríais", "ería", "eréis", "eríamos", "eremos", "erá", "eré", "irían", "irías",
                "irán", "irás", "iríais", "iría", "iréis", "iríamos", "iremos", "irá", "iré", "aba",
                "ada", "ida", "ía", "ara", "iera", "ad", "ed", "id", "ase", "iese", "aste", "iste",
                "an", "aban", "ían", "aran", "ieran", "asen", "iesen", "aron", "ieron", "ado",
                "ido", "ando", "iendo", "ió", "ar", "er", "ir", "as", "abas", "adas", "idas", "ías",
                "aras", "ieras", "ases", "ieses", "ís", "áis", "abais", "íais", "arais", "ierais",
                "aseis", "ieseis", "asteis", "isteis", "ados", "idos", "amos", "ábamos", "íamos",
                "imos", "áramos", "iéramos", "iésemos", "ásemos"), pv)
            if s:
                word = word[:-len(s)]
                if s in ("en", "es", "éis", "emos") and word.endswith("gu"):
                    word = word[:-1]
    # step 3: residual suffix
    s = longest(word, ("os", "a", "o", "á", "í", "ó", "e", "é"), pv)
    if s in ("e", "é"):
        word = word[:-1]
        if word.endswith("gu") and len(word) - 1 >= pv:
            word = word[:-1]
    elif s:
        word = word[:-len(s)]
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        word = word.replace(a, b)
    return word


# ---------------------------------------------------------------- Portuguese
def portuguese(word):
    V = "aeiouáéíóúâêô"
    word = word.lower().replace("ã", "a~").replace("õ", "o~")
    pv = rv_romance(word, V)
    p1, p2 = r1r2(word, V)

    done = False
    s = longest(word, (
        "eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista",
        "istas", "oso", "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "adora",
        "ador", "aça~o", "adoras", "adores", "aço~es", "ante", "antes", "ância", "logia", "logias",
        "ução", "uções", "ência", "ências", "amente", "mente", "idade", "idades", "iva", "ivo",
        "ivas", "ivos", "ira", "iras"))
    s = s.replace("ução", "uc~ao") if False else s
    idx = len(word) - len(s)
    base = word[:idx] if s else word
    if s:
        if s in ("eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível",
                 "ista", "istas", "oso", "osa", "osos", "osas", "amento", "amentos", "imento",
                 "imentos", "adora", "ador", "aça~o", "adoras", "adores", "aço~es", "ante",
                 "antes", "ância"):
            if idx >= p2:
                word, done = base, True
        elif s in ("logia", "logias"):
            if idx >= p2:
                word, done = base + "log", True
        elif s in ("ução", "uções"):
            if idx >= p2:
                word, done = base + "u", True
        elif s in ("ência", "ências"):
            if idx >= p2:
                word, done = base + "ente", True
        elif s == "amente":
            if idx >= p1:
                word, done = base, True
                if word.endswith("iv") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("at") and len(word) - 2 >= p2:
                        word = word[:-2]
                else:
                    for e in ("os", "ic", "ad"):
                        if word.endswith(e):
                            if len(word) - 2 >= p2:
                                word = word[:-2]
                            break
        elif s == "mente":
            if idx >= p2:
                word, done = base, True
                for e in ("ante", "avel", "ível"):
                    if word.endswith(e):
                        if len(word) - len(e) >= p2:
                            word = word[:-len(e)]
                        break
        elif s in ("idade", "idades"):
            if idx >= p2:
                word, done = base, True
                for e in ("abil", "ic", "iv"):
                    if word.endswith(e):
                        if len(word) - len(e) >= p2:
                            word = word[:-len(e)]
                        break
        elif s in ("iva", "ivo", "ivas", "ivos"):
            if idx >= p2:
                word, done = base, True
                if word.endswith("at") and len(word) - 2 >= p2:
                    word = word[:-2]
        elif s in ("ira", "iras"):
            if idx >= pv and base.endswith("e"):
                word, done = base + "ir", True
    if not done:
        s = longest(word, (
            "ada", "ida", "ia", "aria", "eria", "iria", "ará", "ara", "erá", "era", "irá", "ava",
            "asse", "esse", "isse", "aste", "este", "iste", "ei", "arei", "erei", "irei", "am",
            "iam", "ariam", "eriam", "iriam", "aram", "eram", "iram", "avam", "em", "arem", "erem",
            "irem", "assem", "essem", "issem", "ado", "ido", "ando", "endo", "indo", "ara~o",
            "era~o", "ira~o", "ar", "er", "ir", "as", "adas", "idas", "ias", "arias", "erias",
            "irias", "arás", "aras", "erás", "eras", "irás", "avas", "es", "ardes", "erdes",
            "irdes", "ares", "eres", "ires", "asses", "esses", "isses", "astes", "estes", "istes",
            "is", "ais", "eis", "íeis", "aríeis", "eríeis", "iríeis", "áreis", "areis", "éreis",
            "ereis", "íreis", "ireis", "ásseis", "ésseis", "ísseis", "áveis", "ados", "idos",
            "ámos", "amos", "íamos", "aríamos", "eríamos", "iríamos", "áramos", "éramos",
            "íramos", "ávamos", "emos", "aremos", "eremos", "iremos", "ássemos", "êssemos",
            "íssemos", "imos", "armos", "ermos", "irmos", "eu", "iu", "ou", "ira", "iras"), pv)
        if s:
            word, done = word[:-len(s)], True
    if done:
        if word.endswith("ci") and len(word) - 1 >= pv:
            word = word[:-1]
    else:
        s = longest(word, ("os", "a", "i", "o", "á", "í", "ó"), pv)
        if s:
            word = word[:-len(s)]
    s = longest(word, ("e", "é", "ê", "ç"), pv if False else 0)
    if s == "ç":
        word = word[:-1] + "c"
    elif s and len(word) - 1 >= pv:
        word = word[:-1]
        if word.endswith("gu") and len(word) - 1 >= pv:
            word = word[:-1]
        elif word.endswith("ci") and len(word) - 1 >= pv:
            word = word[:-1]
    return word.replace("a~", "ã").replace("o~", "õ")


# ---------------------------------------------------------------- Italian
def italian(word):
    V = "aeiouàèìòù"
    word = word.lower()
    for a, b in (("á", "à"), ("é", "è"), ("í", "ì"), ("ó", "ò"), ("ú", "ù")):
        word = word.replace(a, b)
    word = word.replace("qu", "qU")
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i] in "ui" and word[i - 1] in V and word[i + 1] in V:
            chars[i] = word[i].upper()
    word = "".join(chars)
    pv = rv_romance(word, V)
    p1, p2 = r1r2(word, V)

    # step 0
    pron = longest(word, ("ci", "gli", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi",
                          "sene", "gliela", "gliele", "glieli", "glielo", "gliene", "mela", "mele",
                          "meli", "melo", "mene", "tela", "tele", "teli", "telo", "tene", "cela",
                          "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo", "vene"))
    if pron:
        rest = word[:-len(pron)]
        form = longest(rest, ("ando", "endo", "ar", "er", "ir"))
        if form and len(rest) - len(form) >= pv:
            if form in ("ando", "endo"):
                word = rest
            else:
                word = rest + "e"
    # step 1
    done = False
    s = longest(word, (
        "anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi", "abile",
        "abili", "ibile", "ibili", "ista", "iste", "isti", "ità", "istà", "istè", "istì", "oso",
        "osi", "osa", "ose", "mente", "atrice", "atrici", "ante", "anti", "azione", "azioni",
        "atore", "atori", "logia", "logie", "uzione", "uzioni", "usione", "usioni", "enza",
        "enze", "amento", "amenti", "imento", "imenti", "amente", "ivo", "ivi", "iva", "ive"))
    # 'ità' is handled separately below (idx uses unicode-normalised form)
    if s:
        idx = len(word) - len(s)
        base = word[:idx]
        if s in ("anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi",
                 "abile", "abili", "ibile", "ibili", "ista", "iste", "isti", "istà", "istè", "istì",
                 "oso", "osi", "osa", "ose", "mente", "atrice", "atrici", "ante", "anti"):
            if idx >= p2:
                word, done = base, True
        elif s in ("azione", "azioni", "atore", "atori"):
            if idx >= p2:
                word, done = base, True
                if word.endswith("ic") and len(word) - 2 >= p2:
                    word = word[:-2]
        elif s in ("logia", "logie"):
            if idx >= p2:
                word, done = base + "log", True
        elif s in ("uzione", "uzioni", "usione", "usioni"):
            if idx >= p2:
                word, done = base + "u", True
        elif s in ("enza", "enze"):
            if idx >= p2:
                word, done = base + "ente", True
        elif s in ("amento", "amenti", "imento", "imenti"):
            if idx >= pv:
                word, done = base, True
        elif s == "amente":
            if idx >= p1:
                word, done = base, True
                if word.endswith("iv") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("at") and len(word) - 2 >= p2:
                        word = word[:-2]
                else:
                    for e in ("os", "ic", "abil"):
                        if word.endswith(e):
                            if len(word) - len(e) >= p2:
                                word = word[:-len(e)]
                            break
        elif s in ("ivo", "ivi", "iva", "ive"):
            if idx >= p2:
                word, done = base, True
                if word.endswith("at") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("ic") and len(word) - 2 >= p2:
                        word = word[:-2]
    if not done and word.endswith("ità"):
        idx = len(word) - 3
        if idx >= p2:
            word, done = word[:-3], True
            for e in ("abil", "ic", "iv"):
                if word.endswith(e):
                    if len(word) - len(e) >= p2:
                        word = word[:-len(e)]
                    break
    if not done:
        s = longest(word, (
            "ammo", "ando", "ano", "are", "arono", "asse", "assero", "assi", "assimo", "ata", "ate",
            "ati", "ato", "ava", "avamo", "avano", "avate", "avi", "avo", "emmo", "enda", "ende",
            "endi", "endo", "erà", "erai", "eranno", "ere", "erebbe", "erebbero", "erei", "eremmo",
            "eremo", "ereste", "eresti", "erete", "erò", "erono", "essero", "ete", "eva", "evamo",
            "evano", "evate", "evi", "evo", "Yamo", "iamo", "immo", "irà", "irai", "iranno", "ire",
            "irebbe", "irebbero", "irei", "iremmo", "iremo", "ireste", "iresti", "irete", "irò",
            "irono", "isca", "iscano", "isci", "isco", "iscono", "issero", "ita", "ite", "iti",
            "ito", "iva", "ivamo", "ivano", "ivate", "ivi", "ivo", "ono", "uta", "ute", "uti", "uto",
            "ar", "ir"), pv)
        if s:
            word = word[:-len(s)]
    # vowel suffix
    if word and word[-1] in "aeioàèìò" and len(word) - 1 >= pv:
        word = word[:-1]
        if word.endswith("i") and len(word) - 1 >= pv:
            word = word[:-1]
    if word.endswith(("ch", "gh")) and len(word) - 1 >= pv:
        word = word[:-1]
    return word.replace("I", "i").replace("U", "u")


# ---------------------------------------------------------------- French
def french(word):
    V = "aeiouyâàëéêèïîôûù"
    word = word.lower()
    word = word.replace("ë", "He").replace("ï", "Hi")
    chars = list(word)
    for i in range(len(word)):
        c = word[i]
        prev = word[i - 1] if i > 0 else ""
        nxt = word[i + 1] if i + 1 < len(word) else ""
        if c in "ui" and prev and nxt and prev in V and nxt in V:
            chars[i] = c.upper()
        elif c == "y" and ((prev and prev in V) or (nxt and nxt in V)):
            chars[i] = "Y"
        elif c == "u" and prev == "q":
            chars[i] = "U"
    word = "".join(chars)
    V2 = V
    # RV
    if word.startswith(("par", "col", "tap")):
        pv = 3
    elif len(word) >= 2 and word[0] in V and word[1] in V:
        pv = 3
    else:
        pv = len(word)
        for i in range(1, len(word)):
            if word[i] in V:
                pv = i + 1
                break
    p1, p2 = r1r2(word, V2)

    def inr(w, suffix_len, p):
        return len(w) - suffix_len >= p

    step1 = False
    rv_ending = False
    s = longest(word, (
        "ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes", "ables",
        "istes", "atrice", "ateur", "ation", "atrices", "ateurs", "ations", "logie", "logies",
        "usion", "ution", "usions", "utions", "ence", "ences", "ement", "ements", "ité", "ités",
        "if", "ive", "ifs", "ives", "eaux", "aux", "euse", "euses", "issement", "issements",
        "amment", "emment", "ment", "ments"))
    if s:
        idx = len(word) - len(s)
        base = word[:idx]
        if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes",
                 "ables", "istes"):
            if idx >= p2:
                word, step1 = base, True
        elif s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
            if idx >= p2:
                word, step1 = base, True
                if word.endswith("ic"):
                    if len(word) - 2 >= p2:
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
        elif s in ("logie", "logies"):
            if idx >= p2:
                word, step1 = base + "log", True
        elif s in ("usion", "ution", "usions", "utions"):
            if idx >= p2:
                word, step1 = base + "u", True
        elif s in ("ence", "ences"):
            if idx >= p2:
                word, step1 = base + "ent", True
        elif s in ("ement", "ements"):
            if idx >= pv:
                word, step1 = base, True
                if word.endswith("iv"):
                    if len(word) - 2 >= p2:
                        word = word[:-2]
                        if word.endswith("at") and len(word) - 2 >= p2:
                            word = word[:-2]
                elif word.endswith("eus"):
                    if len(word) - 3 >= p2:
                        word = word[:-3]
                    elif len(word) - 3 >= p1:
                        word = word[:-3] + "eux"
                elif word.endswith(("abl", "iqU")):
                    if len(word) - 3 >= p2:
                        word = word[:-3]
                elif word.endswith(("ièr", "Ièr")):
                    if len(word) - 3 >= pv:
                        word = word[:-3] + "i"
        elif s in ("ité", "ités"):
            if idx >= p2:
                word, step1 = base, True
                if word.endswith("abil"):
                    if len(word) - 4 >= p2:
                        word = word[:-4]
                    else:
                        word = word[:-4] + "abl"
                elif word.endswith("ic"):
                    if len(word) - 2 >= p2:
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
                elif word.endswith("iv"):
                    if len(word) - 2 >= p2:
                        word = word[:-2]
        elif s in ("if", "ive", "ifs", "ives"):
            if idx >= p2:
                word, step1 = base, True
                if word.endswith("at") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("ic"):
                        if len(word) - 2 >= p2:
                            word = word[:-2]
                        else:
                            word = word[:-2] + "iqU"
        elif s == "eaux":
            word, step1 = base + "eau", True
        elif s == "aux":
            if idx >= p1:
                word, step1 = base + "al", True
        elif s in ("euse", "euses"):
            if idx >= p2:
                word, step1 = base, True
            elif idx >= p1:
                word, step1 = base + "eux", True
        elif s in ("issement", "issements"):
            if idx >= p1 and base and base[-1] not in V:
                word, step1 = base, True
        elif s == "amment":
            if idx >= pv:
                word, step1, rv_ending = base + "ant", True, True
        elif s == "emment":
            if idx >= pv:
                word, step1, rv_ending = base + "ent", True, True
        elif s in ("ment", "ments"):
            if idx >= pv and base and base[-1] in V and idx - 1 >= pv:
                word, step1, rv_ending = base, True, True
    step2a = step2b = False
    if not step1 or rv_ending:
        s = longest(word, (
            "îmes", "ît", "îtes", "i", "ie", "Ie", "ies", "ir", "ira", "irai", "irais", "irait",
            "irent", "irez", "iraIent", "irions", "irons", "iront", "is", "issaIent", "issais",
            "issait", "issant", "issante", "issantes", "issants", "isse", "issent", "isses",
            "issez", "issiez", "issions", "issons", "it"), pv)
        if s:
            base = word[:-len(s)]
            if base and base[-1] not in V and base[-1] != "H":
                word, step2a = base, True
        if not step2a:
            s = longest(word, (
                "ions", "é", "ée", "ées", "és", "èrent", "er", "era", "erai", "eraIent", "erais",
                "erait", "erez", "eriez", "erions", "erons", "eront", "ez", "iez", "âmes", "ât",
                "âtes", "a", "ai", "aIent", "ais", "ait", "ant", "ante", "antes", "ants", "as",
                "asse", "assent", "asses", "assiez", "assions"), pv)
            if s:
                idx = len(word) - len(s)
                if s == "ions":
                    if idx >= p2:
                        word, step2b = word[:-4], True
                elif s in ("é", "ée", "ées", "és", "èrent", "er", "era", "erai", "eraIent", "erais",
                           "erait", "erez", "eriez", "erions", "erons", "eront", "ez", "iez"):
                    word, step2b = word[:-len(s)], True
                else:
                    word, step2b = word[:-len(s)], True
                    if word.endswith("e") and len(word) - 1 >= pv:
                        word = word[:-1]
    if step1 or step2a or step2b:
        if word.endswith("Y"):
            word = word[:-1] + "i"
        elif word.endswith("ç"):
            word = word[:-1] + "c"
    else:
        # residual suffix
        if word.endswith("s") and len(word) >= 2 and word[-2] not in "aiouès":
            word = word[:-1]
        s = longest(word, ("ion", "ier", "ière", "Ier", "Ière", "e", "ë"), pv)
        if s == "ion":
            if len(word) - 3 >= p2 and word[:-3].endswith(("s", "t")):
                word = word[:-3]
        elif s in ("ier", "ière", "Ier", "Ière"):
            word = word[:-len(s)] + "i"
        elif s == "e":
            word = word[:-1]
        elif s == "ë":
            pass
        if word.endswith("guë") and len(word) - 1 >= pv:
            word = word[:-1]
    # undouble
    for e in ("enn", "onn", "ett", "ell", "eill"):
        if word.endswith(e):
            word = word[:-1]
            break
    # unaccent
    for i in range(len(word) - 1, -1, -1):
        c = word[i]
        if c in V and c not in "éè":
            break
        if c in "éè":
            if i < len(word) - 1 and all(ch not in V for ch in word[i + 1:]):
                word = word[:i] + "e" + word[i + 1:]
            break
    return word.replace("I", "i").replace("U", "u").replace("Y", "y").replace(
        "He", "ë").replace("Hi", "ï")
