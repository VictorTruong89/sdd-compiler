"""Snowball: Russian, Romanian, Finnish, Hungarian, Arabic."""
from lingora.stem._sb import longest, r1r2, region_after_nonvowel, rv_romance


# ---------------------------------------------------------------- Russian
_RV = "аеиоуыэюя"
_PG1 = ("вшись", "вши", "в")
_PG2 = ("ившись", "ывшись", "ивши", "ывши", "ив", "ыв")
_ADJ = ("ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий", "ый", "ой",
        "ем", "им", "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
_PART1 = ("ем", "нн", "вш", "ющ", "щ")
_PART2 = ("ивш", "ывш", "ующ")
_VERB1 = ("ете", "йте", "нно", "ешь", "ла", "на", "ли", "ем", "ло", "но", "ет", "ют", "ны", "ть",
          "й", "л", "н")
_VERB2 = ("ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено", "ует",
          "уют", "ены", "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым", "ен", "ят", "ит",
          "ыт", "ую", "ю")
_NOUN = ("иями", "ями", "ами", "иях", "ией", "иям", "ием", "ев", "ов", "ие", "ье", "еи", "ии",
         "ей", "ой", "ий", "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия", "ья", "а", "е",
         "и", "й", "о", "у", "ы", "ь", "ю", "я")


def russian(word):
    word = word.lower()
    # RV: region after first vowel
    pv = len(word)
    for i, c in enumerate(word):
        if c in _RV:
            pv = i + 1
            break
    r1, r2 = r1r2(word, _RV)
    head, rv = word[:pv], word[pv:]

    def grp(w, g1, g2):
        s = longest(w, g1 + g2)
        if not s:
            return None
        if s in g1:
            base = w[:-len(s)]
            if base.endswith(("а", "я")):
                return base
            return None
        return w[:-len(s)]

    def perfective(w):
        return grp(w, _PG1, _PG2)

    def adjectival(w):
        s = longest(w, _ADJ)
        if not s:
            return None
        w = w[:-len(s)]
        p = grp(w, _PART1, _PART2)
        return p if p is not None else w

    def verb(w):
        return grp(w, _VERB1, _VERB2)

    def noun(w):
        s = longest(w, _NOUN)
        return w[:-len(s)] if s else None

    r = perfective(rv)
    if r is not None:
        rv = r
    else:
        for refl in ("ся", "сь"):
            if rv.endswith(refl):
                rv = rv[:-2]
                break
        for f in (adjectival, verb, noun):
            r = f(rv)
            if r is not None:
                rv = r
                break
    if rv.endswith("и"):
        rv = rv[:-1]
    word = head + rv
    s = longest(word, ("ость", "ост"))
    if s and len(word) - len(s) >= r2:
        word = word[:-len(s)]
    if len(word) >= pv:
        if word.endswith(("ейше", "ейш")) and len(word) - 3 >= pv:
            word = word[:-4] if word.endswith("ейше") else word[:-3]
            if word.endswith("нн"):
                word = word[:-1]
        elif word.endswith("нн") and len(word) - 2 >= pv:
            word = word[:-1]
        elif word.endswith("ь") and len(word) - 1 >= pv:
            word = word[:-1]
    return word


# ---------------------------------------------------------------- Romanian
def romanian(word):
    V = "aeiouăâî"
    word = word.lower().replace("ş", "ș").replace("ţ", "ț")
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i] in "iu" and word[i - 1] in V and word[i + 1] in V:
            chars[i] = word[i].upper()
    word = "".join(chars)
    pv = rv_romance(word, V)
    p1, p2 = r1r2(word, V)

    # step 0
    s = longest(word, ("ul", "ului", "aua", "ea", "ele", "elor", "ii", "iua", "iei", "iile",
                       "iilor", "ilor", "ile", "atei", "ația", "ație"))
    if s:
        idx = len(word) - len(s)
        if idx >= p1:
            base = word[:idx]
            if s in ("ul", "ului"):
                word = base
            elif s == "aua":
                word = base + "a"
            elif s in ("ea", "ele", "elor"):
                word = base + "e"
            elif s in ("ii", "iua", "iei", "iile", "iilor", "ilor"):
                word = base + "i"
            elif s == "ile":
                if not base.endswith("ab"):
                    word = base + "i"
            elif s == "atei":
                word = base + "at"
            elif s in ("ația", "ație"):
                word = base + "ați"
    # step 1: combining suffixes
    combos = {
        "abilitate": "abil", "abilitati": "abil", "abilități": "abil", "ibilitate": "ibil",
        "ivitate": "iv", "ivitati": "iv", "ivități": "iv",
        "icitate": "ic", "icitati": "ic", "icități": "ic", "icator": "ic", "icatori": "ic",
        "iciv": "ic", "iciva": "ic", "icive": "ic", "icivi": "ic", "icivă": "ic",
        "ativ": "at", "ativa": "at", "ative": "at", "ativi": "at", "ativă": "at",
        "ațiune": "at", "atoare": "at", "ator": "at", "atori": "at", "ătoare": "at",
        "ător": "at", "ători": "at",
        "itiv": "it", "itiva": "it", "itive": "it", "itivi": "it", "itivă": "it",
        "ițiune": "it", "itoare": "it", "itor": "it", "itori": "it"}
    removed = False
    changed = True
    while changed:
        changed = False
        s = longest(word, combos)
        if s and len(word) - len(s) >= p1:
            word = word[:-len(s)] + combos[s]
            changed = removed = True
    # step 2: standard suffixes
    std = ("at", "ata", "ată", "ati", "ate", "ut", "uta", "ută", "uti", "ute", "it", "ita", "ită",
           "iti", "ite", "ic", "ica", "ice", "ici", "ică", "abil", "abila", "abile", "abili",
           "abilă", "ibil", "ibila", "ibile", "ibili", "ibilă", "oasa", "oasă", "oase", "os",
           "osi", "oși", "ant", "anta", "ante", "anti", "antă", "ator", "atori", "itate", "itati",
           "ități", "iv", "iva", "ive", "ivi", "ivă")
    ist = ("ism", "isme", "ist", "ista", "iste", "isti", "istă", "iști")
    s = longest(word, std + ist + ("iune", "iuni"))
    if s and len(word) - len(s) >= p2:
        base = word[:-len(s)]
        if s in ist:
            word, removed = base + "ist", True
        elif s in ("iune", "iuni"):
            if base.endswith("ț"):
                word, removed = base[:-1] + "t", True
        else:
            word, removed = base, True
    # step 3: verb suffixes
    if not removed:
        g1 = ("are", "ere", "ire", "âre", "ind", "ând", "indu", "ându", "eze", "ezi", "esc",
              "ești", "ește", "ăsc", "ăști", "ăște", "ară", "ără", "ar", "ur", "ir", "ez", "ează",
              "ezi", "eam", "ea", "ia", "iam", "ai", "ași", "asem")
        g2 = ("seși", "ase", "sese", "seră", "ește", "sem", "setă", "ați", "ăm", "eți", "im",
              "ez", "esc", "am", "ai", "ei", "ui", "ași", "arăm", "arăți", "aseră", "aserăm",
              "aserăți", "iseră", "iserăm", "iserăți", "ăseră", "ăserăm", "ăserăți", "useră",
              "userăm", "userăți", "eră", "ură", "iră", "ără", "ând", "ire", "uie", "ui")
        s = longest(word, g1 + g2, pv)
        if s:
            base = word[:-len(s)]
            if s in g2 and s not in g1:
                word = base
            elif base and (base[-1] not in V or base[-1] == "u"):
                word = base
    # step 4: final vowels
    s = longest(word, ("ie", "a", "e", "i", "ă"), pv)
    if s:
        word = word[:-len(s)]
    return word.replace("I", "i").replace("U", "u")


# ---------------------------------------------------------------- Finnish
def finnish(word):
    V = "aeiouyäö"
    word = word.lower()
    p1, p2 = r1r2(word, V)
    LV = ("aa", "ee", "ii", "oo", "uu", "ää", "öö")

    # step 1: particles
    s = longest(word, ("kin", "kaan", "kään", "ko", "kö", "han", "hän", "pa", "pä", "sti"), p1)
    if s == "sti":
        if len(word) - 3 >= p2:
            word = word[:-3]
    elif s:
        base = word[:-len(s)]
        if base and (base[-1] in "nt" or base[-1] in V):
            word = base
    # step 2: possessives
    s = longest(word, ("si", "ni", "nsa", "nsä", "mme", "nne", "an", "än", "en"), p1)
    if s == "si":
        if not word[:-2].endswith("k"):
            word = word[:-2]
    elif s == "ni":
        word = word[:-2]
        if word.endswith("kse"):
            word = word[:-3] + "ksi"
    elif s in ("nsa", "nsä", "mme", "nne"):
        word = word[:-3]
    elif s == "an":
        if word[:-2].endswith(("ta", "ssa", "sta", "lla", "lta", "na")):
            word = word[:-2]
    elif s == "än":
        if word[:-2].endswith(("tä", "ssä", "stä", "llä", "ltä", "nä")):
            word = word[:-2]
    elif s == "en":
        if word[:-2].endswith(("lle", "ine")):
            word = word[:-2]
    # step 3: cases
    case_removed = False
    s = longest(word, ("han", "hen", "hin", "hon", "hän", "hön", "siin", "den", "tten", "seen",
                       "a", "ä", "tta", "ttä", "ta", "tä", "ssa", "ssä", "sta", "stä", "lla",
                       "llä", "lta", "ltä", "lle", "na", "nä", "ksi", "ine"), p1)
    if s:
        base = word[:-len(s)]
        ok = False
        if s in ("han", "hen", "hin", "hon", "hän", "hön"):
            ok = base.endswith(s[1])
        elif s in ("siin", "den", "tten"):
            ok = len(base) >= 2 and base[-1] == "i" and base[-2] in V
        elif s == "seen":
            ok = base[-2:] in LV or (len(base) >= 1 and base[-1] in V and
                                      len(base) >= 2 and base[-2] == base[-1])
        elif s in ("a", "ä"):
            ok = len(base) >= 2 and base[-1] in V and base[-2] not in V
        elif s in ("tta", "ttä"):
            ok = base.endswith("e")
        else:
            ok = True
        if ok:
            word, case_removed = base, True
    # step 4: other endings
    s = longest(word, ("mpi", "mpa", "mpä", "mmi", "mma", "mmä", "impi", "impa", "impä", "immi",
                       "imma", "immä", "eimpi", "eimpa", "eimpä"), p2)
    if s:
        base = word[:-len(s)]
        if s in ("mpi", "mpa", "mpä", "mmi", "mma", "mmä"):
            if not base.endswith("mm"):
                word = base
        else:
            word = base
    # step 5: plurals
    if case_removed:
        if len(word) - 1 >= p1 and word[-1] in "ij":
            word = word[:-1]
    else:
        if len(word) - 1 >= p1 and word.endswith("t") and len(word) >= 2 and word[-2] in V:
            word = word[:-1]
            s = longest(word, ("imma", "mma"), p1)
            if s == "mma" and not word[:-3].endswith("po"):
                word = word[:-3]
            elif s == "imma":
                word = word[:-4]
    # step 6: tidy up
    if len(word) - 2 >= p1 and word[-2:] in LV:
        word = word[:-1]
    elif len(word) - 2 >= p1 and word[-1] in "aäei" and word[-2] not in V:
        word = word[:-1]
    if len(word) - 2 >= p1 and word.endswith(("oj", "uj")):
        word = word[:-1]
    if len(word) - 2 >= p1 and word.endswith("jo"):
        word = word[:-1]
    if len(word) >= 2 and len(word) - 1 >= p1 and word[-1] == word[-2] and word[-1] not in V:
        word = word[:-1]
    return word


# ---------------------------------------------------------------- Hungarian
def hungarian(word):
    V = "aáeéiíoóöőuúüű"
    word = word.lower()
    # R1: after first vowel-consonant (or after first consonant cluster when starting with consonant)
    if word and word[0] in V:
        p1 = len(word)
        for i in range(1, len(word)):
            if word[i] not in V:
                p1 = i + 1
                break
    else:
        p1 = len(word)
        for i in range(1, len(word)):
            if word[i] in V:
                p1 = i + 1
                break

    def undouble(w):
        if len(w) >= 2 and w[-1] == w[-2] and w[-1] not in V:
            return w[:-1]
        return w

    def v_ending(w):
        if w.endswith("á"):
            return w[:-1] + "a"
        if w.endswith("é"):
            return w[:-1] + "e"
        return w

    def c_ending(w):
        return w

    def r(w, sufs):
        s = longest(w, sufs, p1)
        return s

    # instrumental
    s = r(word, ("al", "el"))
    if s and len(word) - 2 >= 1 and word[:-2] and word[:-2][-1] not in V and word[:-3].endswith(
            word[-3:-2]) if False else False:
        pass
    if s and len(word) - 2 >= p1 and len(word) >= 4 and word[-3] not in V and word[-3] == word[-4]:
        word = undouble(word[:-2])
    # case endings
    case = ("ban", "ben", "ba", "be", "ra", "re", "nak", "nek", "val", "vel", "tól", "től", "ról",
            "ről", "ból", "ből", "hoz", "hez", "höz", "nál", "nél", "ig", "at", "et", "ot", "öt",
            "ért", "képp", "képpen", "kor", "ul", "ül", "vá", "vé", "onként", "enként", "anként",
            "en", "on", "an", "ön", "n", "t")
    s = r(word, case)
    if s:
        word = word[:-len(s)]
        word = v_ending(word)
        if s in ("ig",):
            pass
        word = undouble(word) if s in ("val", "vel") else word
    # possessive / plural
    s = r(word, ("ák", "ék", "ak", "ek", "ok", "ök", "k", "ja", "je", "ai", "ei", "i", "m", "d"))
    if s:
        word = v_ending(word[:-len(s)])
    # final vowel cleanup
    word = v_ending(word)
    return word


# ---------------------------------------------------------------- Arabic
_DIAC = dict.fromkeys(map(ord, "ًٌٍَُِّْـ"), None)


def arabic(word):
    word = word.translate(_DIAC)
    for a in "أإآ":
        word = word.replace(a, "ا")
    word = word.replace("ؤ", "ء").replace("ئ", "ء")
    for p in ("وال", "بال", "كال", "فال", "ولل", "ال", "لل", "وب", "ول", "فب", "فل"):
        if word.startswith(p) and len(word) - len(p) >= 3:
            word = word[len(p):]
            break
    for s in ("ات", "ان", "ين", "ون", "ها", "هم", "كم", "نا", "تم", "ية", "وا", "ة", "ه", "ي", "ا"):
        if word.endswith(s) and len(word) - len(s) >= 3:
            word = word[:-len(s)]
            break
    return word
