"""Command line group."""
import sys

try:  # pragma: no cover - exercised only when click is installed
    import click
except ImportError:  # pragma: no cover
    click = None


def _run_tokenize(language, delimiter, encoding, stream_in, stream_out):
    from lingora.tokenize import word_tokenize
    from lingora.tokenize.punkt import _load
    _load(language)  # fail early, before any output, when the model is missing
    for line in stream_in:
        line = line.strip()
        stream_out.write(delimiter.join(word_tokenize(line, language)) + "\n")


if click is not None:
    @click.group()
    def cli():
        """Lingora command line tools."""

    @cli.command("tokenize")
    @click.option("--language", "-l", default="en", help="The language for the Punkt sentence tokenization.")
    @click.option("--preserve-line", "-l2", is_flag=True, default=False, hidden=True)
    @click.option("--delimiter", "-d", default=" ", help="One or more characters used to separate tokens.")
    @click.option("--encoding", "-e", default="utf8", help="The encoding of the input.")
    def tokenize_file(language, preserve_line, delimiter, encoding):
        """Tokenize text read from standard input."""
        lang = {"en": "english"}.get(language, language)
        stdin = click.get_text_stream("stdin", encoding=encoding)
        stdout = click.get_text_stream("stdout")
        try:
            _run_tokenize(lang, delimiter, encoding, stdin, stdout)
        except Exception as e:
            raise click.ClickException(str(e))
else:
    class _Group:
        def __init__(self):
            self.commands = {"tokenize": self._tokenize}

        def _tokenize(self, args):
            opts = {"language": "en", "delimiter": " ", "encoding": "utf8"}
            names = {"--language": "language", "-l": "language", "--delimiter": "delimiter",
                     "-d": "delimiter", "--encoding": "encoding", "-e": "encoding"}
            i = 0
            while i < len(args):
                a = args[i]
                if "=" in a and a.startswith("--"):
                    k, v = a.split("=", 1)
                    if k in names:
                        opts[names[k]] = v
                        i += 1
                        continue
                if a in names and i + 1 < len(args):
                    opts[names[a]] = args[i + 1]
                    i += 2
                    continue
                raise _Usage("No such option: %s" % a)
            lang = {"en": "english"}.get(opts["language"], opts["language"])
            stdin = sys.stdin
            if hasattr(stdin, "buffer"):
                import io
                stdin = io.TextIOWrapper(stdin.buffer, encoding=opts["encoding"])
            _run_tokenize(lang, opts["delimiter"], opts["encoding"], stdin, sys.stdout)

        def main(self, args=None, prog_name="lingora", standalone_mode=True, **extra):
            if args is None:
                args = sys.argv[1:]
            args = list(args)
            code = 0
            try:
                if not args or args[0] in ("--help", "-h"):
                    sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\n"
                                     "Commands:\n  tokenize  Tokenize text from standard input.\n")
                elif args[0] not in self.commands:
                    raise _Usage("No such command '%s'." % args[0])
                else:
                    self.commands[args[0]](args[1:])
            except _Usage as e:
                code = 2
                err = e
            except Exception as e:
                code = 1
                err = e
            if code:
                if not standalone_mode:
                    raise err
                sys.stderr.write("Error: %s\n" % err)
                sys.exit(code)
            if standalone_mode:
                sys.exit(0)
            return None

        __call__ = main

    class _Usage(Exception):
        pass

    cli = _Group()
