"""Constituent trees."""


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, str):
            raise TypeError("children should be a list, not a string")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def children(self):
        return list(self)

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees(filter)

    def productions(self):
        from lingora.grammar import Production, Nonterminal
        prods = [Production(Nonterminal(self._label),
                            [Nonterminal(c._label) if isinstance(c, Tree) else c for c in self])]
        for c in self:
            if isinstance(c, Tree):
                prods.extend(c.productions())
        return prods

    def pos(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.pos())
            else:
                out.append((c, self._label))
        return out

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        import re
        tokens = re.findall(r"\%s|\%s|[^\s\%s\%s]+" % (open_b, close_b, open_b, close_b), s)
        if not tokens:
            raise ValueError("empty tree string")
        pos = 0

        def parse_node():
            nonlocal pos
            if tokens[pos] != open_b:
                raise ValueError("expected %r" % open_b)
            pos += 1
            label = ""
            if pos < len(tokens) and tokens[pos] not in (open_b, close_b):
                label = tokens[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced brackets")
                t = tokens[pos]
                if t == close_b:
                    pos += 1
                    return cls(label, children)
                if t == open_b:
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos += 1

        if tokens[0] != open_b:
            # allow bare token? require brackets
            raise ValueError("tree string must start with %r" % open_b)
        tree = parse_node()
        if pos != len(tokens):
            raise ValueError("extra text after tree")
        return tree

    def pformat(self, margin=70, indent=0, nodesep="", parens="()", quotes=False):
        s = self._pformat_flat(nodesep, parens)
        if len(s) + indent < margin:
            return s
        s = "%s%s%s" % (parens[0], self._label, nodesep)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2, nodesep, parens)
            elif isinstance(c, tuple):
                s += "\n" + " " * (indent + 2) + "/".join(map(str, c))
            else:
                s += "\n" + " " * (indent + 2) + str(c)
        return s + parens[1]

    def _pformat_flat(self, nodesep, parens):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._pformat_flat(nodesep, parens))
            elif isinstance(c, tuple):
                parts.append("/".join(map(str, c)))
            else:
                parts.append(str(c))
        return "%s%s%s %s%s" % (parens[0], self._label, nodesep, " ".join(parts), parens[1])

    def pprint(self, **kw):
        print(self.pformat(**kw))

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()
