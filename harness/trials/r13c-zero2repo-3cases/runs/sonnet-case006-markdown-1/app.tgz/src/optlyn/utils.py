from __future__ import annotations

import codecs
import io
import os
import re
import sys
from functools import update_wrapper

from .formatting import strip_ansi
from .globals import resolve_color_default

_ansi_colors = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color out of range: {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise ValueError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    try:
        return str(_ansi_colors[color] + offset)
    except (KeyError, TypeError):
        raise ValueError(f"Unknown color {color!r}") from None


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in (
        (bold, 1, 22),
        (dim, 2, 22),
        (underline, 4, 24),
        (overline, 53, 55),
        (italic, 3, 23),
        (blink, 5, 25),
        (reverse, 7, 27),
        (strikethrough, 9, 29),
    ):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def _is_ascii_encoding(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except Exception:
        return False


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and hasattr(buf, "write"):
        return buf
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out)
            binary_file.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    elif message:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if isinstance(out, str) and enc and _is_ascii_encoding(enc):
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out.encode("utf-8"))
            binary_file.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary_file = _find_binary_writer(file)
        if binary_file is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            binary_file.write(out.encode("utf-8"))
            binary_file.flush()
            return
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    else:
        try:
            raw = filename.encode("utf-8", "surrogateescape")
        except UnicodeEncodeError:
            raw = filename.encode("utf-8", "backslashreplace")
        filename = raw.decode("utf-8", "backslashreplace")
    return filename


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _get_text_stream(stream, encoding, errors):
    if encoding is None and errors in (None, "strict"):
        return stream
    cur = getattr(stream, "encoding", None)
    same = False
    if encoding is not None and cur is not None:
        try:
            same = codecs.lookup(cur).name == codecs.lookup(encoding).name
        except LookupError:
            same = False
    if (encoding is None or same) and errors in (None, "strict"):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(
        buf, encoding=encoding or cur or "utf-8", errors=errors or "strict", line_buffering=True
    )


def get_text_stdin(encoding=None, errors=None):
    stream = sys.stdin
    if encoding is None and errors in (None, "strict"):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    return _NonClosingTextIOWrapper(buf, encoding=encoding or stream.encoding, errors=errors or "strict")


def get_text_stdout(encoding=None, errors=None):
    return _get_text_stream(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _get_text_stream(sys.stderr, encoding, errors)


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", sys.stdin)


def get_binary_stdout():
    try:
        sys.stdout.flush()
    except Exception:
        pass
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_binary_stderr():
    try:
        sys.stderr.flush()
    except Exception:
        pass
    return getattr(sys.stderr, "buffer", sys.stderr)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        if delete:
            pass
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in ["w", "a", "x"]):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "r" in mode:
        raise ValueError("Cannot use the atomic flag with read mode.")
    import random

    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    while True:
        tmp_filename = os.path.join(
            os.path.dirname(filename),
            f".__atomic-write{random.randrange(1 << 32):08x}",
        )
        try:
            fd = os.open(tmp_filename, flags, 0o666 if not os.path.exists(filename) else os.stat(filename).st_mode & 0o7777)
            break
        except OSError as e:
            import errno

            if e.errno == errno.EEXIST:
                continue
            raise
    real_filename = os.path.realpath(filename)
    if "a" in mode and os.path.exists(real_filename):
        import shutil

        with open(real_filename, "rb") as src, os.fdopen(os.dup(fd), "wb") as dst:
            shutil.copyfileobj(src, dst)
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp_filename, real_filename), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(
                self.name, self.mode, self.encoding, self.errors, atomic=self.atomic
            )
        except OSError as e:
            from .exceptions import FileError

            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)

    def write(self, *a, **k):
        return self.open().write(*a, **k)

    def read(self, *a, **k):
        return self.open().read(*a, **k)

    def flush(self):
        if self._f is not None:
            self._f.flush()


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    plat = sys.platform
    if plat.startswith("win") and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if plat == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
        _posixify(app_name),
    )
