from __future__ import annotations

import enum
import os
import stat
import sys
import uuid
from datetime import datetime

from .exceptions import BadParameter
from .utils import LazyFile, format_filename, open_stream


class ParamType:
    is_composite = False
    arity = 1
    name = ""
    envvar_list_splitter = None

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param=None, ctx=None):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)
        return None


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "custom")
        self.func = func

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            msg = str(e)
            if not msg:
                try:
                    msg = str(value)
                except UnicodeError:
                    msg = str(value, "utf-8", "replace")
            self.fail(msg, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            enc = sys.getfilesystemencoding() or "utf-8"
            try:
                return value.decode(enc)
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class _GuessedType(StringParamType):
    """Type guessed from an unusual default: non-text values pass through."""

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (str, bytes)):
            return super().convert(value, param, ctx)
        return value


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            choices = list(choices)
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _normalize(self, choice, ctx):
        normed = choice.name if isinstance(choice, enum.Enum) else str(choice)
        if ctx is not None and ctx.token_normalize_func is not None:
            normed = ctx.token_normalize_func(normed)
        if not self.case_sensitive:
            normed = normed.casefold()
        return normed

    def _choice_strs(self):
        return [c.name if isinstance(c, enum.Enum) else str(c) for c in self.choices]

    def get_metavar(self, param):
        choices_str = "|".join(self._choice_strs())
        if param is not None and getattr(param, "param_type_name", None) == "argument" and param.required:
            return f"{{{choices_str}}}"
        return f"[{choices_str}]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._choice_strs())

    def convert(self, value, param=None, ctx=None):
        normed_value = self._normalize(value, ctx)
        for original in self.choices:
            if self._normalize(original, ctx) == normed_value:
                return original
        choices_str = ", ".join(map(repr, self._choice_strs()))
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def __repr__(self):
        return f"Choice({self.choices!r})"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        str_choices = self._choice_strs()
        if self.case_sensitive:
            matched = [c for c in str_choices if c.startswith(incomplete)]
        else:
            incomplete = incomplete.lower()
            matched = [c for c in str_choices if c.lower().startswith(incomplete)]
        return [CompletionItem(c) for c in matched]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
        ]

    def get_metavar(self, param):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        formats_str = ", ".join(map(repr, self.formats))
        self.fail(f"{value!r} does not match the formats {formats_str}.", param, ctx)

    def __repr__(self):
        return "DateTime"


class _NumberParamTypeBase(ParamType):
    _number_class = int

    def convert(self, value, param=None, ctx=None):
        try:
            if isinstance(value, bool):
                raise ValueError
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        import operator

        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _clamp(self, bound, dir, open):
        raise NotImplementedError

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"


class IntRange(_NumberRangeBase):
    name = "integer range"
    _number_class = int

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        return bound + dir


class FloatRange(_NumberRangeBase):
    name = "float range"
    _number_class = float

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if (min_open or max_open) and clamp:
            raise TypeError("Clamping is not supported for open bounds.")

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        raise RuntimeError("Clamping is not supported for open bounds.")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if value in {False, True} and isinstance(value, bool):
            return bool(value)
        norm = str(value).strip().lower()
        if norm in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if norm in {"0", "false", "f", "no", "n", "off"}:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


def _is_file_like(value):
    return hasattr(value, "read") or hasattr(value, "write")


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param=None, ctx=None):
        if _is_file_like(value):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(f.close)
                else:
                    ctx.call_on_close(f.flush)
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} does not exist.", param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} is not writable.", param, ctx)
            if self.executable and not os.access(value, os.X_OK):
                self.fail(f"{self.name.capitalize()} {format_filename(value)!r} is not executable.", param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        type = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=type)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return "<{}>".format(" ".join(ty.name for ty in self.types))

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed_type:
        return _GUESSED
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
_GUESSED = _GuessedType()
