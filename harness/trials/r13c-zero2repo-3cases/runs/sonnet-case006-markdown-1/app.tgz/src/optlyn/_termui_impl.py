from __future__ import annotations

import contextlib
import math
import os
import shlex
import shutil
import subprocess
import sys
import time

from .exceptions import OptlynException
from .formatting import strip_ansi, term_len
from .globals import resolve_color_default
from .utils import echo, isatty, is_interactive, should_strip_ansi

BEFORE_BAR = "\r"
AFTER_BAR = "\n"


class ProgressBar:
    def __init__(
        self,
        iterable,
        length=None,
        fill_char="#",
        empty_char="-",
        bar_template="%(bar)s",
        info_sep="  ",
        hidden=False,
        show_eta=True,
        show_percent=None,
        show_pos=False,
        item_show_func=None,
        label=None,
        file=None,
        color=None,
        update_min_steps=1,
        width=30,
    ):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._is_atty = isatty(self.file)
        self._last_line = None

    @property
    def is_hidden(self):
        return self.hidden or not self._is_atty

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.is_hidden:
            return
        self.file.write(AFTER_BAR)
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        return min(self.pos / (float(self.length or 1) or 1), 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (
            self.bar_template
            % {
                "label": self.label,
                "bar": self.format_bar(),
                "info": self.info_sep.join(info_bits),
            }
        ).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not self._is_atty:
            if self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        buf = []
        clear_width = self.width
        if self.max_width is not None:
            clear_width = self.max_width
        buf.append(BEFORE_BAR)
        line = self.format_progress_line()
        line_len = term_len(line)
        if self.max_width is None or self.max_width < line_len:
            self.max_width = line_len
        buf.append(line)
        buf.append(" " * (clear_width - line_len))
        line = "".join(buf)
        if line != self._last_line:
            self._last_line = line
            echo(line, file=self.file, color=self.color, nl=False)
            self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        self._completed_intervals += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        if self.is_hidden:
            yield from self.iter
        else:
            for rv in self.iter:
                self.current_item = rv
                if self._completed_intervals == 0:
                    self.render_progress()
                yield rv
                self.update(1)
            self.finish()
            self.render_progress()


class _PagerWriter:
    def __init__(self, write, flush, close):
        self._write = write
        self._flush = flush
        self._close = close

    def write(self, text):
        self._write(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        self._flush()

    def isatty(self):
        return False

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    if stdout is None:
        import io

        stdout = io.StringIO()
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not is_interactive():
        pager_cmd = ""
    elif not pager_cmd:
        if os.environ.get("TERM") in ("dumb", "unknown"):
            pager_cmd = ""
        elif shutil.which("less"):
            pager_cmd = "less"
        elif shutil.which("more"):
            pager_cmd = "more"
    if not pager_cmd:
        strip = should_strip_ansi(stdout, color)

        def w(text):
            stdout.write(strip_ansi(text) if strip else text)

        def fl():
            stdout.flush()

        yield _PagerWriter(w, fl, lambda: None)
        fl()
        return

    env = dict(os.environ)
    cmd_detail = pager_cmd.rsplit("/", 1)[-1].split()
    if color is None and cmd_detail[0] == "less":
        less_flags = f"{os.environ.get('LESS', '')}{' '.join(cmd_detail[1:])}"
        if not less_flags:
            env["LESS"] = "-R"
            color = True
        elif "r" in less_flags or "R" in less_flags:
            color = True
    try:
        sys.stdout.flush()
    except Exception:
        pass
    c = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env, errors="replace", text=True)
    assert c.stdin is not None
    broken = False

    def w(text):
        nonlocal broken
        if broken:
            return
        if not color:
            text = strip_ansi(text)
        try:
            c.stdin.write(text)
            c.stdin.flush()
        except (BrokenPipeError, OSError):
            broken = True

    def fl():
        try:
            c.stdin.flush()
        except (BrokenPipeError, OSError):
            pass

    try:
        yield _PagerWriter(w, fl, lambda: None)
    except BaseException:
        try:
            c.stdin.close()
        except Exception:
            pass
        c.terminate()
        raise
    else:
        try:
            c.stdin.close()
        except (BrokenPipeError, OSError):
            pass
    finally:
        while True:
            try:
                c.wait()
            except KeyboardInterrupt:
                pass
            else:
                break


def pager(generator, color=None):
    with get_pager_file(color) as f:
        for text in generator:
            f.write(text)


class Editor:
    def __init__(self, editor=None, env=None, require_save=True, extension=".txt"):
        self.editor = editor
        self.env = env
        self.require_save = require_save
        self.extension = extension

    def get_editor(self):
        if self.editor is not None:
            return self.editor
        for key in "VISUAL", "EDITOR":
            rv = os.environ.get(key)
            if rv:
                return rv
        for editor in "sensible-editor", "vim", "nano":
            if shutil.which(editor):
                return editor
        return "vi"

    def edit_files(self, filenames):
        editor = self.get_editor()
        environ = None
        if self.env:
            environ = os.environ.copy()
            environ.update(self.env)
        files = " ".join(shlex.quote(os.fspath(f)) for f in filenames)
        try:
            c = subprocess.Popen(f"{editor} {files}", env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{editor}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e

    def edit(self, text):
        import tempfile

        if not text:
            data = b""
        elif isinstance(text, (bytes, bytearray)):
            data = bytes(text)
        else:
            if text and not text.endswith("\n"):
                text += "\n"
            data = text.encode("utf-8")
        fd, name = tempfile.mkstemp(prefix="editor-", suffix=self.extension)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            timestamp = os.path.getmtime(name)
            os.utime(name, (timestamp - 2, timestamp - 2))
            timestamp = os.path.getmtime(name)
            self.edit_files((name,))
            if self.require_save and os.path.getmtime(name) == timestamp:
                return None
            with open(name, "rb") as f:
                rv = f.read()
            if isinstance(text, (bytes, bytearray)):
                return rv
            return rv.decode("utf-8-sig").replace("\r\n", "\n")
        finally:
            os.unlink(name)


def open_url(url, wait=False, locate=False):
    if locate:
        url = os.path.dirname(url) or "."
    try:
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        try:
            return c.wait(timeout=5)
        except subprocess.TimeoutExpired:
            return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser

            webbrowser.open(url)
            return 0
        return 1


def getchar(echo_):
    import termios
    import tty

    if isatty(sys.stdin):
        f = None
        fd = sys.stdin.fileno()
    else:
        try:
            f = open("/dev/tty")
            fd = f.fileno()
        except OSError:
            f = None
            fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    if echo_ and isatty(sys.stdout):
        sys.stdout.write(ch)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch
