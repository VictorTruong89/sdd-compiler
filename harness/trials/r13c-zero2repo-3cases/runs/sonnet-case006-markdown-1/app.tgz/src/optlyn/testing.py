from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils
from .utils import _find_binary_writer


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


def _pause_echo(stream):
    @contextlib.contextmanager
    def cm():
        if stream is not None:
            stream._paused = True
        try:
            yield
        finally:
            if stream is not None:
                stream._paused = False

    return cm()


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = _find_binary_reader(input)
        if rv is not None:
            return rv
        raise TypeError("Could not find binary reader for input stream.")
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


def _find_binary_reader(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    return getattr(stream, "buffer", None)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _FdRaw(io.RawIOBase):
    def __init__(self, fd, copy_to):
        self._fd = fd
        self._copy_to = copy_to
        self.written = 0

    def writable(self):
        return True

    def fileno(self):
        return self._fd

    def write(self, b):
        b = bytes(b)
        os.write(self._fd, b)
        self._copy_to.write(b)
        self.written += len(b)
        return len(b)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None

        old_stdin = sys.stdin
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80

        env = self.make_env(env)

        output = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            for s in (old_stdout, old_stderr):
                try:
                    s.flush()
                except Exception:
                    pass
            saved1, saved2 = os.dup(1), os.dup(2)
            out_tmp = tempfile.TemporaryFile()
            err_tmp = tempfile.TemporaryFile()
            os.dup2(out_tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            raw_out = _FdRaw(1, io.BytesIO())
            raw_err = _FdRaw(2, io.BytesIO())
            raw_out._copy_to = _Both(output)
            raw_err._copy_to = _Both(output)
            fd_state = (saved1, saved2, out_tmp, err_tmp, raw_out, raw_err)
            bytes_output = io.BufferedWriter(raw_out, buffer_size=1)
            bytes_error = io.BufferedWriter(raw_err, buffer_size=1)
        else:
            bytes_output = BytesIOCopy(output)
            bytes_error = BytesIOCopy(output)

        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_output)

        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = _NamedTextIOWrapper(bytes_output, encoding=self.charset, name="<stdout>", mode="w")
        sys.stderr = _NamedTextIOWrapper(bytes_error, encoding=self.charset, name="<stderr>", mode="w", errors="backslashreplace")

        def _read_line():
            line = text_input.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def visible_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(prompt or "")
                val = _read_line()
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
                return val

        def hidden_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                return _read_line()

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible_prompt_func = termui.visible_prompt_func
        old_hidden_prompt_func = termui.hidden_prompt_func
        old__getchar_func = termui._getchar
        old_should_strip_ansi = utils.should_strip_ansi
        old_env_pager = None
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (bytes_output, bytes_error, fd_state)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            sys.stdin = old_stdin
            termui.visible_prompt_func = old_visible_prompt_func
            termui.hidden_prompt_func = old_hidden_prompt_func
            termui._getchar = old__getchar_func
            utils.should_strip_ansi = old_should_strip_ansi
            formatting.FORCED_WIDTH = old_forced_width
            self._output_cache = output

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        exc_info = None
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as streams:
            bytes_output, bytes_error, fd_state = streams
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    if fd_state is not None:
                        self._finish_fd(fd_state)
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if fd_state is not None:
                    stdout, stderr, combined = self._finish_fd(fd_state)
                    fd_state = None
                else:
                    stdout = bytes_output.getvalue()
                    stderr = bytes_error.getvalue()
                    combined = self._output_cache_value(bytes_output, bytes_error)
        return Result(
            runner=self,
            stdout_bytes=stdout,
            stderr_bytes=stderr,
            output_bytes=combined,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    def _output_cache_value(self, bytes_output, bytes_error):
        return bytes_output.copy_to.getvalue()

    def _finish_fd(self, fd_state):
        saved1, saved2, out_tmp, err_tmp, raw_out, raw_err = fd_state
        for s in (sys.stdout, sys.stderr):
            try:
                s.flush()
            except Exception:
                pass
        os.dup2(saved1, 1)
        os.dup2(saved2, 2)
        os.close(saved1)
        os.close(saved2)
        out_tmp.seek(0)
        err_tmp.seek(0)
        stdout = out_tmp.read()
        stderr = err_tmp.read()
        out_tmp.close()
        err_tmp.close()
        if len(stdout) == raw_out.written and len(stderr) == raw_err.written:
            combined = raw_out._copy_to.buf.getvalue()
        else:
            combined = stdout + stderr
        return stdout, stderr, combined

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


class _Both:
    def __init__(self, buf):
        self.buf = buf

    def write(self, b):
        return self.buf.write(b)
