# lingora

A pure-Python natural-language processing library (standard library only, no build step).

- Package: `lingora/` at the repository root (flat layout). Import with `import lingora` from this directory, or
  install editably with `pip install -e .`.
- Specification: `spec/` (left unchanged). Per-id status for every checklist item: `SPEC_COVERAGE.md`.
- Packaged resources (Punkt models, averaged-perceptron taggers, WordNet, stopword lists, and so on) are not shipped.
  They are looked up in `lingora.data.path`, which starts from the directories in the `LINGORA_DATA` environment
  variable (`os.pathsep`-separated) and can be replaced by the caller.

## Tests

    python3 -m pytest tests

The tests build small synthetic resources under `tmp_path`; they do not need the real models.

## Known gaps (details in `SPEC_COVERAGE.md`)

- Snowball stemmers exist for `english` (Porter2) and `porter` (an approximation via the original Porter mode).
  The other Snowball languages raise `NotImplementedError`.
- `ne_chunk` checks its resources and raises `LookupError` when they are missing; with the resources present it
  raises `NotImplementedError` (the model file format is not in the specification).
- `ARLSTem`/`ARLSTem2` are approximate light stemmers. ISRI, Cistem and RSLP are not built.
- The recommended English and Russian taggers and the Punkt sentence splitter follow the published algorithms as
  reconstructed here. They were verified only against synthetic models; the real packaged models were not available.
