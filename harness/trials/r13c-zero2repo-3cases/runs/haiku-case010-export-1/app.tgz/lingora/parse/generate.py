"""Sentence generation from a grammar: ``from lingora.parse.generate import generate``."""

import itertools
import sys

from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Enumerate sentences (lists of terminal tokens) derived from ``start``, lazily."""
    # spec: N-000263 N-000264 N-000265 N-000266 N-000267 — productions in written order, bounded by depth and count.
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    # spec: N-000458 — depth is an int or None: the derivation depth bound.
    limit = sys.maxsize if depth is None else depth
    sentences = _generate_all(grammar, [start], limit)
    # spec: N-000457 — n is an int or None: the maximum number of sentences.
    if n is not None:
        sentences = itertools.islice(sentences, n)
    return sentences


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    for first in _generate_one(grammar, items[0], depth):
        for rest in _generate_all(grammar, items[1:], depth):
            yield first + rest


def _generate_one(grammar, item, depth):
    if isinstance(item, Nonterminal):
        if depth > 0:
            for production in grammar.productions(lhs=item):
                yield from _generate_all(grammar, list(production.rhs()), depth - 1)
    elif item == "":
        # spec: N-000266 — a quoted empty string contributes an empty-string token.
        yield [""]
    else:
        yield [item]
