"""Parsers over a context-free grammar: ``from lingora.parse import ChartParser, ShiftReduceParser``.

spec: N-000442 — the parser names are exported from this package.
"""

from lingora.grammar import Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(tokens, grammar):
    # spec: N-000452 — tokens is a list of str.
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    if not all(isinstance(token, str) for token in tokens):
        raise TypeError("every token must be a str")
    # spec: N-000455 N-000278 N-000279 — a token that no production produces makes parsing raise.
    known = grammar.terminals()
    for token in tokens:
        if token not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % (token,))
    return list(tokens)


class ChartParser:
    """Exhaustive chart parser: every tree the grammar assigns to the token list."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        # spec: N-000253 N-000254 N-000255 N-000256 N-000257 N-000258 — all parse trees, root = start symbol.
        tokens = _check_tokens(tokens, self._grammar)
        grammar = self._grammar
        memo = {}
        active = set()

        def spans(symbol, start, end):
            key = (symbol, start, end)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            found = []
            for production in grammar.productions(lhs=symbol):
                for children in sequences(production.rhs(), 0, start, end):
                    found.append(Tree(str(symbol), children))
            active.discard(key)
            memo[key] = found
            return found

        def sequences(rhs, index, position, end):
            if index == len(rhs):
                if position == end:
                    yield []
                return
            symbol = rhs[index]
            if isinstance(symbol, Nonterminal):
                for split in range(position, end + 1):
                    for subtree in spans(symbol, position, split):
                        for rest in sequences(rhs, index + 1, split, end):
                            yield [subtree] + rest
            elif symbol == "":
                yield from sequences(rhs, index + 1, position, end)
            elif position < end and tokens[position] == symbol:
                for rest in sequences(rhs, index + 1, position + 1, end):
                    yield [symbol] + rest

        return iter(spans(grammar.start(), 0, len(tokens)))


class ShiftReduceParser:
    """A single left-to-right shift-reduce pass without backtracking."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        # spec: N-000259 N-000260 N-000261 N-000262 — reduce whenever the stack top matches a right-hand side.
        tokens = _check_tokens(tokens, self._grammar)
        grammar = self._grammar
        productions = [
            production
            for production in grammar.productions()
            if production.rhs() and production.rhs() != (production.lhs(),)
        ]
        stack = []
        position = 0
        steps = 0
        limit = 100 + 50 * (len(tokens) + 1) * (len(productions) + 1)
        while steps < limit:
            steps += 1
            reduced = False
            for production in productions:
                rhs = production.rhs()
                size = len(rhs)
                if size > len(stack):
                    continue
                if all(stack[len(stack) - size + offset][0] == rhs[offset] for offset in range(size)):
                    children = [stack[len(stack) - size + offset][1] for offset in range(size)]
                    del stack[len(stack) - size :]
                    stack.append((production.lhs(), Tree(str(production.lhs()), children)))
                    reduced = True
                    break
            if reduced:
                continue
            if position < len(tokens):
                stack.append((tokens[position], tokens[position]))
                position += 1
                continue
            break
        if position == len(tokens) and len(stack) == 1 and stack[0][0] == grammar.start():
            return iter([stack[0][1]])
        return iter([])
