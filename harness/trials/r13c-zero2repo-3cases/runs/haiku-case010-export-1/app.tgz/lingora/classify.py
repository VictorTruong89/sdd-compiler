"""Classifiers: ``from lingora.classify import NaiveBayesClassifier, DecisionTreeClassifier, accuracy`` (FP-06).

spec: N-000472 N-000473 — the names are in this module; the submodule is also lingora.classify.
spec: N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 — in-memory training on labeled featuresets,
no corpus; labels are classified, Naive Bayes gives a distribution, and accuracy compares labels to gold.
"""

import math
from collections import Counter, OrderedDict, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


def _check_labeled(labeled_featuresets):
    # spec: N-000474 — a list of (featureset, label) pairs; a featureset is a dict.
    if isinstance(labeled_featuresets, (str, bytes)) or not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    if not labeled_featuresets:
        raise ValueError("training needs at least one labeled featureset")
    for featureset, _ in labeled_featuresets:
        if not isinstance(featureset, dict):
            raise TypeError("a featureset is a dict from feature names to values")
    return list(labeled_featuresets)


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probabilities):
        self._probabilities = OrderedDict(probabilities)

    def prob(self, label):
        # spec: N-000476 — the probability of a label, as a float.
        return float(self._probabilities.get(label, 0.0))

    def samples(self):
        # spec: N-000477 — the labels.
        return list(self._probabilities)

    def max(self):
        return max(self._probabilities, key=lambda label: self._probabilities[label])

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probabilities)


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing over the feature values seen in training."""

    def __init__(self, label_counts, value_counts, value_bins, total):
        self._label_counts = label_counts
        self._value_counts = value_counts
        self._value_bins = value_bins
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        # spec: N-000288 N-000289 N-000295 — label priors and smoothed per-label feature-value estimates.
        examples = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        value_counts = defaultdict(Counter)
        value_bins = defaultdict(set)
        for featureset, label in examples:
            label_counts[label] += 1
            for name, value in featureset.items():
                value_counts[(label, name)][value] += 1
                value_bins[name].add(value)
        return cls(label_counts, value_counts, {name: len(values) for name, values in value_bins.items()}, len(examples))

    def labels(self):
        # spec: N-000295 — exactly the labels seen in training.
        return list(self._label_counts)

    def _log_scores(self, featureset):
        scores = {}
        for label, count in self._label_counts.items():
            score = math.log(count / self._total)
            for name, value in featureset.items():
                # spec: N-000290 N-000291 — only features that occurred in training are used.
                if name not in self._value_bins:
                    continue
                numerator = self._value_counts[(label, name)][value] + 1
                denominator = count + self._value_bins[name]
                score += math.log(numerator / denominator)
            scores[label] = score
        return scores

    def classify(self, featureset):
        # spec: N-000292 — the label with the highest posterior probability.
        scores = self._log_scores(featureset)
        return max(self.labels(), key=lambda label: scores[label])

    def prob_classify(self, featureset):
        # spec: N-000293 N-000294 — a posterior distribution: real numbers summing to one.
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(weights.values())
        return ProbDist([(label, weights[label] / total) for label in self.labels()])


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Node:
    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(labels):
    counts = Counter(labels)
    total = len(labels)
    return -sum((count / total) * math.log2(count / total) for count in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for label in labels:
        if counts[label] == best:
            return label


class DecisionTreeClassifier:
    """A decision tree that splits on the feature with the largest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        # spec: N-000296 N-000297 N-000298 N-000299 N-000300 — tests on feature values; majority leaves.
        examples = _check_labeled(labeled_featuresets)
        features = []
        for featureset, _ in examples:
            for name in featureset:
                if name not in features:
                    features.append(name)
        return cls(cls._build(examples, features))

    @classmethod
    def _build(cls, examples, features):
        labels = [label for _, label in examples]
        majority = _majority(labels)
        if len(set(labels)) == 1:
            return _Leaf(majority)
        base = _entropy(labels)
        best_feature, best_gain, best_groups = None, 1e-12, None
        for name in features:
            groups = defaultdict(list)
            for featureset, label in examples:
                # a feature absent from a featureset counts as having no value
                groups[featureset.get(name)].append((featureset, label))
            if len(groups) < 2:
                continue
            remainder = sum(
                (len(group) / len(examples)) * _entropy([label for _, label in group]) for group in groups.values()
            )
            gain = base - remainder
            if gain > best_gain:
                best_feature, best_gain, best_groups = name, gain, groups
        if best_feature is None:
            return _Leaf(majority)
        remaining = [name for name in features if name != best_feature]
        children = {
            value: cls._build(group, remaining) for value, group in best_groups.items()
        }
        return _Node(best_feature, children, majority)

    def classify(self, featureset):
        # spec: N-000301 N-000302 N-000303 — a featureset with no known feature still gets a trained label.
        node = self._root
        while isinstance(node, _Node):
            child = node.children.get(featureset.get(node.feature))
            if child is None:
                return node.default
            node = child
        return node.label

    def labels(self):
        found = []

        def walk(node):
            if isinstance(node, _Leaf):
                if node.label not in found:
                    found.append(node.label)
            else:
                if node.default not in found:
                    found.append(node.default)
                for child in node.children.values():
                    walk(child)

        walk(self._root)
        return found


def accuracy(classifier, gold):
    """The fraction of gold (featureset, label) pairs the classifier labels correctly."""
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
