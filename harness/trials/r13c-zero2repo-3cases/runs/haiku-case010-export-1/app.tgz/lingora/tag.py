"""Taggers: ``from lingora.tag import ...`` (FP-03).

spec: N-000413 N-000414 — DefaultTagger, RegexpTagger, UnigramTagger, pos_tag; the submodule is also lingora.tag.
spec: N-000182 N-000183 N-000184 — default, unigram, bigram, trigram, affix and regular-expression taggers, with backoff.
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = ["AffixTagger", "BigramTagger", "DefaultTagger", "RegexpTagger", "TrigramTagger", "UnigramTagger", "pos_tag"]

# spec: N-000415 — tokens is a list of str; a str is refused.
def _as_token_list(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)
    return list(tokens)


class _SequentialTagger:
    """Assigns a tag to some tokens; tokens left without a tag go to the backoff tagger."""

    def __init__(self, backoff=None):
        # spec: N-000419 — backoff is another tagger, or None.
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self.backoff = backoff

    def _assign(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _as_token_list(tokens)
        tags = self._assign(tokens)
        # spec: N-000023 — the backoff tagger is consulted only for tokens the primary tagger left without a tag.
        # spec: N-000200 N-000201 — the backoff tagger is consulted only for tokens left without a tag.
        if self.backoff is not None:
            missing = [index for index, tag in enumerate(tags) if tag is None]
            if missing:
                for index, (_, tag) in zip(missing, self.backoff.tag([tokens[i] for i in missing])):
                    tags[index] = tag
        # spec: N-000191 N-000424 N-000425 — one (token, tag) per input token, in order; tag is None if unassigned.
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    def __init__(self, tag):
        super().__init__()
        self._tag = tag

    def _assign(self, tokens):
        # spec: N-000193 — one configured tag for every token.
        return [self._tag for _ in tokens]


class UnigramTagger(_SequentialTagger):
    # spec: N-000416 N-000417 — train is a list of sentences, each a list of (token, tag) pairs.
    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                counts[token][tag] += 1
        # spec: N-000194 N-000195 — each word takes the tag it was most often seen with; ties by tag text.
        self._model = {
            word: min(tag_counts.items(), key=lambda item: (-item[1], str(item[0])))[0]
            for word, tag_counts in counts.items()
        }

    def _assign(self, tokens):
        # spec: N-000196 — a word never seen in training receives no tag.
        return [self._model.get(token) for token in tokens]


def _most_common_tags(counts):
    # spec: N-000195 — ties are broken by tag text, which is the implementer's choice.
    return {
        key: min(tag_counts.items(), key=lambda item: (-item[1], str(item[0])))[0]
        for key, tag_counts in counts.items()
    }


class NgramTagger(_SequentialTagger):
    """Tags a token from its word and the tags already assigned to the previous ``n - 1`` tokens."""

    def __init__(self, n, train=None, backoff=None):
        super().__init__(backoff)
        self._n = n
        counts = defaultdict(Counter)
        for sentence in train or []:
            history = []
            for token, tag in sentence:
                counts[(tuple(history[-(n - 1) :]) if n > 1 else (), token)][tag] += 1
                history.append(tag)
        self._model = _most_common_tags(counts)

    def _assign(self, tokens):
        tags = []
        history = []
        for token in tokens:
            key = (tuple(history[-(self._n - 1) :]) if self._n > 1 else (), token)
            tag = self._model.get(key)
            tags.append(tag)
            history.append(tag)
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_SequentialTagger):
    """Tags a word from its affix (a prefix when ``affix_length`` is positive, a suffix when negative)."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                affix = self._affix(token)
                if affix is not None:
                    counts[affix][tag] += 1
        self._model = _most_common_tags(counts)

    def _affix(self, word):
        if len(word) < self._min_word_length:
            return None
        return word[: self._affix_length] if self._affix_length > 0 else word[self._affix_length :]

    def _assign(self, tokens):
        tags = []
        for token in tokens:
            affix = self._affix(token)
            tags.append(None if affix is None else self._model.get(affix))
        return tags


class RegexpTagger(_SequentialTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        # spec: N-000418 — regexps is a list of (pattern, tag) pairs.
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _assign(self, tokens):
        # spec: N-000197 N-000198 N-000199 — the first rule whose pattern matches at the token's first character.
        tags = []
        for token in tokens:
            for pattern, tag in self._rules:
                if pattern.match(token):
                    tags.append(tag)
                    break
            else:
                tags.append(None)
        return tags


# --- averaged perceptron (the recommended English and Russian taggers) ----------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_perceptron_cache = {}
_ptb_map_cache = {}

# spec: N-000211 N-000213 — the Russian National Corpus tagset is mapped by the part of speech before any '='.
# The exact table is the implementer's choice.
_RNC_TO_UNIVERSAL = {
    "S": "NOUN",
    "V": "VERB",
    "A": "ADJ",
    "ANUM": "ADJ",
    "ADV": "ADV",
    "PR": "ADP",
    "CONJ": "CONJ",
    "SPRO": "PRON",
    "APRO": "DET",
    "NUM": "NUM",
    "PART": "PRT",
    "INTJ": "X",
    "PRAEDIC": "ADV",
    "PARENTH": "X",
    "COM": "ADJ",
}


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes


def _load_model(lang):
    """Load the packaged averaged perceptron tagger for ``lang`` ('eng' or 'rus')."""
    # spec: N-000373 N-000374 N-000383 — the packaged English and Russian tagger resources.
    directory = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    if directory is None or not os.path.isdir(directory):
        raise LookupError(
            "averaged perceptron tagger for %r is not installed (taggers/averaged_perceptron_tagger_%s not found)"
            % (lang, lang)
        )
    key = os.path.abspath(directory)
    if key not in _perceptron_cache:
        base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
        with open(base + ".weights.json", encoding="utf-8") as handle:
            weights = json.load(handle)
        with open(base + ".tagdict.json", encoding="utf-8") as handle:
            tagdict = json.load(handle)
        with open(base + ".classes.json", encoding="utf-8") as handle:
            classes = json.load(handle)
        _perceptron_cache[key] = _PerceptronModel(weights, tagdict, sorted(classes))
    return _perceptron_cache[key]


def _load_ptb_map():
    # spec: N-000375 N-000210 — the universal tagset tables for mapping English tags.
    directory = data.find("taggers/universal_tagset")
    if directory is None or not os.path.isdir(directory):
        raise LookupError("universal tagset tables are not installed (taggers/universal_tagset not found)")
    key = os.path.abspath(directory)
    if key not in _ptb_map_cache:
        mapping = {}
        for line in data.read_lines(os.path.join(directory, "en-ptb.map")):
            parts = line.split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
        _ptb_map_cache[key] = mapping
    return _ptb_map_cache[key]


def _normalize(word):
    # spec: N-000203 — the tagger's word normalisation.
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(index, word, context, prev, prev2):
    # spec: N-000203 N-000204 — the averaged perceptron feature templates.
    index += len(_START)
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[index])
    add("i-1 tag+i word", prev, context[index])
    add("i-1 word", context[index - 1])
    add("i-1 suffix", context[index - 1][-3:])
    add("i-2 word", context[index - 2])
    add("i+1 word", context[index + 1])
    add("i+1 suffix", context[index + 1][-3:])
    add("i+2 word", context[index + 2])
    return features


def _predict(model, features):
    scores = defaultdict(float)
    for feature, value in features.items():
        if feature not in model.weights or value == 0:
            continue
        for label, weight in model.weights[feature].items():
            scores[label] += value * weight
    return max(model.classes, key=lambda label: (scores[label], label))


def _perceptron_tag(model, tokens):
    prev, prev2 = _START
    context = _START + [_normalize(token) for token in tokens] + _END
    tags = []
    for index, word in enumerate(tokens):
        tag = model.tagdict.get(word)
        if not tag:
            tag = _predict(model, _features(index, word, context, prev, prev2))
        tags.append(tag)
        prev2 = prev
        prev = tag
    return tags


def pos_tag(tokens, tagset=None, lang="eng"):
    """LINGORA's recommended tagger: averaged perceptron tags for English ('eng') or Russian ('rus')."""
    # spec: N-000422 N-000214 N-000215 N-000216 — the list of tokens is required; a str is refused.
    tokens = _as_token_list(tokens)
    # spec: N-000217 N-000218 N-000423 — other languages are refused.
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for the recommended tagger: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unknown tagset: %r" % (tagset,))
    model = _load_model(lang)
    mapping = None
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_ptb_map()
    tags = _perceptron_tag(model, tokens)
    if tagset == "universal":
        if lang == "eng":
            tags = [mapping.get(tag, "X") for tag in tags]
        else:
            tags = [_RNC_TO_UNIVERSAL.get(tag.split("=")[0], "X") for tag in tags]
    return list(zip(tokens, tags))
