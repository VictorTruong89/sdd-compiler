"""Constituent trees: ``from lingora.tree import Tree`` (FP-05)."""

import re


class Tree:
    """A labelled node with an ordered list of children; a child is a leaf or another Tree."""

    def __init__(self, label, children):
        # spec: N-000466 N-000467 N-000274 N-000275 N-000276 N-000277 — children must be a list; a str or an omitted
        # list is refused; an empty list is a valid tree with no children.
        if isinstance(children, str) or not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of leaves or trees, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    # spec: N-000463 N-000464 N-000268 N-000269 N-000270 — iteration, len() and indexing give the immediate children.
    def __len__(self):
        return len(self._children)

    def __iter__(self):
        return iter(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def label(self):
        # spec: N-000463 — the node label.
        return self._label

    def leaves(self):
        """The leaves under this node, left to right."""
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __eq__(self, other):
        # spec: N-000465 N-000271 — equal labels and pairwise-equal children, recursively.
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    @classmethod
    def fromstring(cls, text):
        """Build a tree from bracketed tree text: ``(<label> <child> ...)``."""
        # spec: N-000469 N-000272 — bracketed tree text; read back equal to the tree built from the same parts.
        if not isinstance(text, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", text)
        if not tokens or tokens[0] != "(":
            raise ValueError("bracketed tree text must start with '(': %r" % (text,))
        tree, position = _parse_bracketed(tokens, 0)
        if position != len(tokens):
            raise ValueError("trailing text after the tree: %r" % (text,))
        return tree

    def _flat(self):
        parts = []
        for child in self._children:
            parts.append(child._flat() if isinstance(child, Tree) else _leaf_text(child))
        return "(%s%s)" % (self._label, "".join(" " + part for part in parts))

    def pformat(self, margin=70, indent=0):
        """The pretty-printed text; a node that does not fit the margin is broken across lines."""
        # spec: N-000470 N-000471 N-000273 — every label and leaf, in pre-order; layout is the implementer's choice.
        flat = self._flat()
        if indent + len(flat) <= margin or not any(isinstance(child, Tree) for child in self._children):
            return flat
        lines = ["(%s" % self._label]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(" " * (indent + 2) + child.pformat(margin, indent + 2))
            else:
                lines.append(" " * (indent + 2) + _leaf_text(child))
        return "\n".join(lines) + ")"


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


def _parse_bracketed(tokens, position):
    if position + 1 >= len(tokens) or tokens[position] != "(" or tokens[position + 1] in ("(", ")"):
        raise ValueError("expected '(' and a label at token %d" % position)
    label = tokens[position + 1]
    position += 2
    children = []
    while True:
        if position >= len(tokens):
            raise ValueError("missing ')' for node %r" % label)
        token = tokens[position]
        if token == ")":
            return Tree(label, children), position + 1
        if token == "(":
            child, position = _parse_bracketed(tokens, position)
            children.append(child)
        else:
            children.append(token)
            position += 1
