"""Command line: ``from lingora.cli import cli`` with ``cli.main(args=[...], standalone_mode=True)``."""

import argparse
import sys

from lingora.tokenize import word_tokenize

# spec: N-000397 N-000398 N-000399 — 'tokenize' reads UTF-8 lines from standard input and writes one token line each.
# spec: N-000003 N-000004 — the convenience applies the same recommended word tokenizer the library exposes.


class _Group:
    """A command group. Its only command is ``tokenize``."""

    prog = "lingora"

    def _parser(self):
        parser = argparse.ArgumentParser(prog=self.prog, description="LINGORA command line.")
        commands = parser.add_subparsers(dest="command", required=True)
        tokenize = commands.add_parser("tokenize", help="Tokenize each line of standard input.")
        # spec: N-000403 — language and delimiter are the implementer's choice.
        tokenize.add_argument("--language", default="english", help="Punkt language for sentence splitting.")
        tokenize.add_argument("--delimiter", default=" ", help="Separator between tokens (default: one space).")
        return parser

    def main(self, args=None, standalone_mode=True):
        args = sys.argv[1:] if args is None else list(args)
        try:
            options = self._parser().parse_args(args)
            status = self._tokenize(options.language, options.delimiter)
        except Exception as error:
            if not standalone_mode:
                raise
            # spec: N-000401 — on failure no token line is written for the failed input.
            sys.stderr.write("lingora: %s\n" % error)
            status = 1
        if standalone_mode:
            # spec: N-000400 — standalone mode ends the process: 0 on success, non-zero on failure.
            sys.exit(status)
        return status

    def _tokenize(self, language, delimiter):
        output = sys.stdout
        for raw in sys.stdin:
            line = raw.rstrip("\r\n")
            # spec: N-000129 N-000130 N-000134 — sentence splitting with the recommended word tokenizer.
            tokens = word_tokenize(line, language=language)
            output.write(delimiter.join(tokens) + "\n")
            output.flush()
        return 0


cli = _Group()
