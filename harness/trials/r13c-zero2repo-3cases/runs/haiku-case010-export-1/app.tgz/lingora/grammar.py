"""Context-free grammars: ``from lingora.grammar import CFG`` (FP-05)."""

import re


class Nonterminal:
    """A nonterminal symbol; ``str()`` is its name."""
    # spec: N-000446 N-000447 N-000448 — a nonterminal is a symbol whose str() is its name (the implementer's choice).

    def __init__(self, symbol):
        self._symbol = symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        # spec: N-000449 N-000450 N-000451 — a terminal is its text (a str); a nonterminal is a Nonterminal.
        return self._rhs

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(_symbol_text(symbol) for symbol in self._rhs) or "''")


def _symbol_text(symbol):
    return str(symbol) if isinstance(symbol, Nonterminal) else repr(symbol)


_SYMBOL_RE = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s'"|]+""")


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, text):
        """Read one production per line, written ``LHS -> RHS``; ``|`` separates alternatives."""
        # spec: N-000444 N-000445 N-000441 — one production per line; blank lines ignored.
        if not isinstance(text, str):
            raise TypeError("a grammar is read from a str")
        productions = []
        for number, raw in enumerate(text.splitlines(), start=1):
            line = raw.strip()
            if not line:
                continue
            if "->" not in line:
                raise ValueError("line %d is not a production 'LHS -> RHS': %r" % (number, raw))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or re.search(r"\s|['\"|]", lhs_text):
                raise ValueError("line %d has a bad left-hand side: %r" % (number, raw))
            lhs = Nonterminal(lhs_text)
            alternatives = [[]]
            for piece in _SYMBOL_RE.findall(rhs_text):
                if piece == "|":
                    alternatives.append([])
                elif piece[0] in "'\"":
                    alternatives[-1].append(piece[1:-1])
                else:
                    alternatives[-1].append(Nonterminal(piece))
            # spec: N-000251 — each alternative separated by '|' is a production of its own.
            for rhs in alternatives:
                productions.append(Production(lhs, rhs))
        if not productions:
            raise ValueError("a grammar needs at least one production")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        # spec: N-000451 — one Production per alternative.
        if lhs is None:
            return list(self._productions)
        return [production for production in self._productions if production.lhs() == lhs]

    def terminals(self):
        return {symbol for production in self._productions for symbol in production.rhs() if isinstance(symbol, str)}

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
