"""Tokenizers: ``from lingora.tokenize import ...`` (FP-01)."""

import re

from lingora import punkt

# spec: N-000386 N-000387 — the public names of this module are listed in __all__.
__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text):
    # spec: N-000388 N-000063 — text is a str of Unicode text.
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


# --- word/punctuation tokenizer -------------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    """Maximal runs of word characters, and maximal runs of other non-whitespace characters."""
    # spec: N-000086 N-000087 N-000088 — word characters and punctuation runs; whitespace is never a token.
    _check_text(text)
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer:
    # spec: N-000131 — the empty and whitespace-only strings yield no tokens.
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        """Yield one (start, end) pair per token."""
        # spec: N-000395 N-000121 N-000123 — spans are int offsets, in token order, non-overlapping.
        _check_text(text)
        for match in _WORDPUNCT_RE.finditer(text):
            yield match.span()


# --- whitespace and blank-line tokenizers ---------------------------------------------------------------------

_NONSPACE_RE = re.compile(r"\S+")
_BLANKLINE_SEP_RE = re.compile(r"\s*\n\s*\n\s*")


class WhitespaceTokenizer:
    def tokenize(self, text):
        # spec: N-000108 — maximal runs of non-whitespace characters.
        _check_text(text)
        return _NONSPACE_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _NONSPACE_RE.finditer(text):
            yield match.span()


def blankline_tokenize(text):
    """Split ``text`` into segments at blank lines; single newlines inside a segment are kept."""
    # spec: N-000109 N-000110 N-000394 — segments are the non-empty pieces between blank-line separators.
    _check_text(text)
    return [piece for piece in _BLANKLINE_SEP_RE.split(text) if piece]


# --- regular-expression tokenizer -----------------------------------------------------------------------------


class RegexpTokenizer:
    """Tokens are the matches of ``pattern`` (token mode), or the pieces between matches (gap mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=True):
        # spec: N-000389 — pattern is a Python regular expression string.
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = re.compile(pattern)
        # spec: N-000390 — gaps and discard_empty are bool.
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _segments(self, text):
        _check_text(text)
        if self._gaps:
            segments = []
            position = 0
            for match in self._pattern.finditer(text):
                # spec: N-000112 — gap mode: the pieces between successive matches.
                segments.append((position, match.start()))
                position = match.end()
            segments.append((position, len(text)))
        else:
            # spec: N-000111 — token mode: successive non-overlapping matches, left to right.
            segments = [match.span() for match in self._pattern.finditer(text)]
        if self._discard_empty:
            # spec: N-000113 — empty pieces are dropped unless the caller turns that off.
            segments = [(start, end) for start, end in segments if end > start]
        return segments

    def tokenize(self, text):
        return [text[start:end] for start, end in self._segments(text)]

    def span_tokenize(self, text):
        yield from self._segments(text)


# --- Penn Treebank and recommended word tokenizers ------------------------------------------------------------

_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r"([ (\[{<])(\"|'{2})"), r"\1 `` "),
]
_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]
_PARENS_BRACKETS = [
    (re.compile(r"[\]\[\(\)\{\}<>]"), r" \g<0> "),
    (re.compile(r"--"), r" -- "),
]
_ENDING_QUOTES = [
    (re.compile(r"''"), " '' "),
    (re.compile(r'"'), " '' "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]
_CONTRACTIONS2 = [
    re.compile(pattern)
    for pattern in (
        r"(?i)\b(can)(?#X)(not)\b",
        r"(?i)\b(d)(?#X)('ye)\b",
        r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b",
        r"(?i)\b(got)(?#X)(ta)\b",
        r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b",
        r"(?i)\b(wan)(?#X)(na)(?=\s)",
    )
]
_CONTRACTIONS3 = [re.compile(pattern) for pattern in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

# spec: N-000101 N-000102 N-000103 N-000104 N-000105 — extra rules of the recommended tokenizer.
_TYPOGRAPHIC_QUOTES_RE = re.compile(r"(?<!\w)[‘’]|[‘’](?!\w)|[«»“”„]")
_DASHES_AND_ASTERISKS_RE = re.compile(r"[\u2012-\u2015*]")
_RUN_OF_POINTS_RE = re.compile(r"\.{2,}")


def _treebank_pipeline(text):
    for pattern, replacement in _STARTING_QUOTES:
        text = pattern.sub(replacement, text)
    for pattern, replacement in _PUNCTUATION:
        text = pattern.sub(replacement, text)
    for pattern, replacement in _PARENS_BRACKETS:
        text = pattern.sub(replacement, text)
    # spec: N-000098 — the clitics are split off; a word-final apostrophe is padded for the rules below.
    text = " " + text + " "
    for pattern, replacement in _ENDING_QUOTES:
        text = pattern.sub(replacement, text)
    for pattern in _CONTRACTIONS2:
        text = pattern.sub(r" \1 \2 ", text)
    for pattern in _CONTRACTIONS3:
        text = pattern.sub(r" \1 \2 ", text)
    return text.split()


class TreebankWordTokenizer:
    # spec: N-000089 — the Penn Treebank word tokenizer.
    def tokenize(self, text):
        _check_text(text)
        return _treebank_pipeline(text)


def _recommended_line(text):
    """The recommended word tokenizer applied to one already-delimited line."""
    text = _TYPOGRAPHIC_QUOTES_RE.sub(lambda match: " %s " % match.group(0), text)
    text = _DASHES_AND_ASTERISKS_RE.sub(lambda match: " %s " % match.group(0), text)
    text = _RUN_OF_POINTS_RE.sub(lambda match: " %s " % match.group(0), text)
    return _treebank_pipeline(text)


def sent_tokenize(text, language="english"):
    """The recommended sentence tokenizer (Punkt)."""
    # spec: N-000084 — the default language is English.
    # spec: N-000124 — Punkt sentence-boundary detection for the requested language.
    _check_text(text)
    return punkt.sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    # spec: N-000106 N-000107 N-000080 — unless preserve_line, split into sentences first, then tokenize each.
    _check_text(text)
    if preserve_line:
        # spec: N-000392 — preserve_line=True treats text as one already-delimited line, with no sentence splitting.
        return _recommended_line(text)
    tokens = []
    # spec: N-000393 — preserve_line=False splits sentences first.
    for sentence in sent_tokenize(text, language):
        tokens.extend(_recommended_line(sentence))
    return tokens


# --- tweet tokenizer ------------------------------------------------------------------------------------------

_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
    |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
    |
      <3
    )"""
_URLS = r"""(?:https?://(?:[-a-zA-Z0-9._~!$&'()*+,;=:@/?#\[\]%]|%[0-9a-fA-F]{2})+|www\.(?:[-a-zA-Z0-9._~!$&'()*+,;=:@/?#\[\]%]|%[0-9a-fA-F]{2})+)"""
_TWEET_PARTS = [
    _URLS,
    _EMOTICONS,
    r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w'_\-]*[\w_]*)",
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"(?:\.(?:\s*\.)+)",
    r"(?:\S)",
]
_TWEET_RE = re.compile("|".join(_TWEET_PARTS), re.VERBOSE | re.IGNORECASE | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.IGNORECASE)
# spec: N-000118 — an @-handle does not continue a preceding word; 1 to 15 ASCII letters, digits or underscores.
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
# spec: N-000119 — a run of three or more of the same character is shortened to three.
_HANG_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        # spec: N-000390 — the flags are bool.
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        # spec: N-000114 N-000115 N-000116 N-000117 — contractions, diacritics, emoticons, URLs, hashtags, handles.
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _HANG_RE.sub(lambda match: match.group(1) * 3, text)
        words = [match.group(0) for match in _TWEET_RE.finditer(text)]
        if not self._preserve_case:
            # spec: N-000120 — lowercase, except emoticons.
            words = [word if _EMOTICON_RE.fullmatch(word) else word.lower() for word in words]
        return words
