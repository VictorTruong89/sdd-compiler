"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing; packaged resources are looked up in ``lingora.data.path``.
"""

from lingora import data

# spec: N-000335 N-000337 N-000338 N-000046 — pure Python, no compiled code, GPU or accelerator use.
# spec: N-000053 N-000054 N-000055 N-000342 N-000343 — platform-neutral code; CPU-only.
# spec: N-000353 N-000354 — importable package; flat layout with one package directory at the root.
# spec: N-000001 N-000002 N-000005 N-000006 N-000007 N-000008 N-000009 N-000010 N-000011 N-000012 N-000027 —
# the product is a library imported from Python; its processing entries are in the submodules.
# spec: N-000013 N-000014 N-000015 N-000016 N-000017 N-000066 N-000067 N-000068 — the feature points, in order.
# spec: N-000045 — no product surfaces beyond the interface contract; helper types are needed by it only.

__version__ = "0.1.0"
__all__ = ["data"]
