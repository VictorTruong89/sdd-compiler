"""Evaluation metrics: ``from lingora.metrics import accuracy, edit_distance, jaccard_distance, precision, recall, f_measure``.

spec: N-000478 N-000479 — the names are in this module; the submodule is also lingora.metrics.
spec: N-000305 N-000306 N-000307 — pure functions of their arguments; no corpus or trained model.
"""

__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]


def _require_lists(reference, test):
    # spec: N-000481 — reference and test are lists.
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")


def accuracy(reference, test):
    """The fraction of positions at which two equal-length lists hold equal values."""
    _require_lists(reference, test)
    # spec: N-000482 N-000326 — lists of different lengths make the call raise.
    if len(reference) != len(test):
        raise ValueError("lists of different lengths: %d and %d" % (len(reference), len(test)))
    return sum(1 for ref, hyp in zip(reference, test) if ref == hyp) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    # spec: N-000483 N-000484 N-000485 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313 — the edit costs.
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    previous = [index for index in range(len(s2) + 1)]
    for i, char1 in enumerate(s1, start=1):
        current = [i]
        for j, char2 in enumerate(s2, start=1):
            cost = 0 if char1 == char2 else substitution_cost
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost))
        previous = current
    return previous[-1]


def _damerau_levenshtein(a, b, substitution_cost):
    maximum = len(a) + len(b)
    last_row = {}
    matrix = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    matrix[0][0] = maximum
    for i in range(len(a) + 1):
        matrix[i + 1][0] = maximum
        matrix[i + 1][1] = i
    for j in range(len(b) + 1):
        matrix[0][j + 1] = maximum
        matrix[1][j + 1] = j
    for i in range(1, len(a) + 1):
        last_match_column = 0
        for j in range(1, len(b) + 1):
            last_row_of_b = last_row.get(b[j - 1], 0)
            last_col_of_a = last_match_column
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_column = j
            else:
                cost = substitution_cost
            matrix[i + 1][j + 1] = min(
                matrix[i][j] + cost,
                matrix[i + 1][j] + 1,
                matrix[i][j + 1] + 1,
                matrix[last_row_of_b][last_col_of_a] + (i - last_row_of_b - 1) + 1 + (j - last_col_of_a - 1),
            )
        last_row[a[i - 1]] = i
    return matrix[len(a) + 1][len(b) + 1]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union."""
    # spec: N-000486 — label1 and label2 are sets.
    set1, set2 = set(label1), set(label2)
    union = set1 | set2
    if not union:
        return 0.0
    return len(set1 ^ set2) / len(union)


def _require_sets(reference, test):
    # spec: N-000487 N-000488 — reference and test are sets (or frozensets); other collections are refused.
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets or frozensets")


def precision(reference, test):
    """|reference & test| / |test|, or None when the test set is empty."""
    _require_sets(reference, test)
    # spec: N-000327 N-000489 — no number results for an empty test set.
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|, or None when the reference set is empty."""
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """The weighted harmonic mean of precision and recall; None when either set is empty."""
    _require_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    # spec: N-000328 N-000329 N-000316 N-000317 — None (not 0) for an empty set; 0 when precision or recall is 0.
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
