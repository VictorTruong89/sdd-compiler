"""Chunking: ``from lingora.chunk import RegexpParser, ne_chunk`` (FP-04).

spec: N-000426 N-000427 — the names are in this module; the submodule is also lingora.chunk.
"""

import os
import re

from lingora import data
from lingora.tree import Tree

__all__ = ["ChunkStage", "RegexpParser", "ne_chunk"]

# spec: N-000436 — the root label of the chunk structure is the default sentence label.
SENTENCE_LABEL = "S"


def _tag_regex(pattern):
    """Translate a tag pattern (elements ``<...>`` with quantifiers) into a regex over ``<tag>`` units."""
    # spec: N-000226 N-000227 N-000228 N-000229 N-000025 — angle-bracketed elements, quantifiers, whitespace ignored.
    parts = []
    index = 0
    while index < len(pattern):
        char = pattern[index]
        if char.isspace():
            index += 1
        elif char == "<":
            close = pattern.find(">", index)
            if close < 0:
                raise ValueError("unclosed '<' in tag pattern %r" % (pattern,))
            content = re.sub(r"\s", "", pattern[index + 1 : close])
            if not content:
                raise ValueError("empty tag element in tag pattern %r" % (pattern,))
            parts.append("(?:<(?:%s)>)" % _element_regex(content))
            index = close + 1
            if index < len(pattern) and pattern[index] in "?*+":
                parts.append(pattern[index])
                index += 1
            elif index < len(pattern) and pattern[index] == "{":
                close_brace = pattern.find("}", index)
                if close_brace < 0:
                    raise ValueError("unclosed '{' in tag pattern %r" % (pattern,))
                quantifier = pattern[index : close_brace + 1]
                if not re.fullmatch(r"\{\d*(,\d*)?\}", quantifier):
                    raise ValueError("bad quantifier %r in tag pattern %r" % (quantifier, pattern))
                parts.append(quantifier)
                index = close_brace + 1
        else:
            raise ValueError("unexpected %r in tag pattern %r" % (char, pattern))
    return re.compile("".join(parts))


def _element_regex(content):
    """A tag element's content: '.' matches one character of a tag; the rest is regular expression."""
    out = []
    index = 0
    while index < len(content):
        char = content[index]
        if char == "\\" and index + 1 < len(content):
            out.append(content[index : index + 2])
            index += 2
            continue
        out.append("[^<>]" if char == "." else char)
        index += 1
    return "".join(out)


class ChunkStage:
    """One clause of a chunk grammar: a label and its patterns, applied in written order."""
    # spec: N-000430 — the stage objects are the implementer's choice; this build uses ChunkStage.

    def __init__(self, label, patterns):
        if not isinstance(label, str) or not label:
            raise ValueError("a clause needs a non-empty label")
        self.label = label
        self.rules = []
        for pattern in patterns:
            text = pattern.strip()
            if text.startswith("{") and text.endswith("}") and len(text) >= 2:
                self.rules.append(("chunk", _tag_regex(text[1:-1])))
            elif text.startswith("}") and text.endswith("{") and len(text) >= 2:
                self.rules.append(("chink", _tag_regex(text[1:-1])))
            else:
                raise ValueError("a pattern is {<tag pattern>} (chunk) or }<tag pattern>{ (chink): %r" % (pattern,))
        if not self.rules:
            raise ValueError("clause %r has no patterns" % (label,))


def _parse_grammar(text):
    """Read clauses: ``<LABEL>: <pattern>`` lines, with further patterns on indented lines."""
    # spec: N-000433 N-000434 — a clause begins with '<LABEL>: <pattern>'; more patterns are indented.
    clauses = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0].isspace():
            if not clauses:
                raise ValueError("pattern line before any clause: %r" % (raw,))
            clauses[-1][1].append(raw.strip())
            continue
        match = re.fullmatch(r"([^\s:]+)\s*:(.*)", raw.strip())
        if match is None:
            raise ValueError("a clause must begin with '<LABEL>: <pattern>': %r" % (raw,))
        label, rest = match.group(1), match.group(2).strip()
        clauses.append((label, [rest] if rest else []))
    if not clauses:
        raise ValueError("a chunk grammar needs one or more clauses")
    return [ChunkStage(label, patterns) for label, patterns in clauses]


def _runs(pieces):
    """Maximal runs of pieces that are free units (not yet in a chunk of this clause)."""
    run = []
    for piece in pieces:
        if piece[0] == "unit":
            run.append(piece)
        else:
            if run:
                yield run
                run = []
            yield piece
    if run:
        yield run


def _apply_chunk_rule(pieces, regex, label):
    out = []
    for run in _runs(pieces):
        if isinstance(run, tuple):
            out.append(run)
            continue
        units = run
        tags = [unit[1] for unit in units]
        text = "".join("<%s>" % tag for tag in tags)
        starts = {}
        ends = {}
        position = 0
        for index, tag in enumerate(tags):
            starts[position] = index
            position += len(tag) + 2
            ends[position] = index + 1
        cursor = 0
        for match in regex.finditer(text):
            begin, finish = match.span()
            if begin == finish or begin not in starts or finish not in ends:
                continue
            first, last = starts[begin], ends[finish]
            if first < cursor:
                continue
            out.extend(units[cursor:first])
            # spec: N-000230 N-000231 N-000232 — every match becomes one chunk carrying the clause's label.
            out.append(("chunk", label, [unit[2] for unit in units[first:last]]))
            cursor = last
        out.extend(units[cursor:])
    return out


def _chink_indexes(children, regex):
    """Indexes of the (token, tag) children that a chink pattern matches, within runs of such children."""
    removed = set()

    def scan(run):
        tags = [children[index][1] for index in run]
        text = "".join("<%s>" % tag for tag in tags)
        starts = {}
        ends = {}
        position = 0
        for offset, tag in enumerate(tags):
            starts[position] = offset
            position += len(tag) + 2
            ends[position] = offset + 1
        for match in regex.finditer(text):
            begin, finish = match.span()
            if begin == finish or begin not in starts or finish not in ends:
                continue
            removed.update(run[starts[begin] : ends[finish]])

    run = []
    for index, child in enumerate(children):
        if isinstance(child, tuple):
            run.append(index)
        else:
            if run:
                scan(run)
                run = []
    if run:
        scan(run)
    return removed


def _apply_chink_rule(pieces, regex):
    out = []
    for piece in pieces:
        if piece[0] != "chunk":
            out.append(piece)
            continue
        _, label, children = piece
        # spec: N-000234 N-000235 N-000236 — chinked tokens leave the chunk and become root children; the chunk splits.
        removed = _chink_indexes(children, regex)
        group = []
        for index, child in enumerate(children):
            if index in removed:
                if group:
                    out.append(("chunk", label, group))
                    group = []
                out.append(("unit", child[1], child))
            else:
                group.append(child)
        if group:
            out.append(("chunk", label, group))
    return out


class RegexpParser:
    """A chunk parser for a chunk grammar (text) or a list of ``ChunkStage`` objects."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(stage, ChunkStage) for stage in grammar):
            self._stages = list(grammar)
        else:
            # spec: N-000429 N-000431 N-000244 N-000245 N-000246 — any other value is refused.
            raise TypeError("a chunk grammar is a str or a list of ChunkStage objects")

    def parse(self, tagged):
        """The chunk structure of a list of (token, tag) pairs."""
        # spec: N-000435 N-000438 N-000439 N-000440 N-000233 — a Tree whose children are the (token, tag) pairs in
        # no chunk and one chunk Tree per chunk; a chunk's label is its clause's label.
        # spec: N-000428 N-000241 N-000242 — tagged is a list of (token, tag) pairs; leaves are kept exactly.
        if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        pieces = [("unit", pair[1], tuple(pair)) for pair in tagged]
        for stage in self._stages:
            for kind, rule in stage.rules:
                if kind == "chunk":
                    pieces = _apply_chunk_rule(pieces, rule, stage.label)
                else:
                    pieces = _apply_chink_rule(pieces, rule)
            # spec: N-000237 N-000238 — a later clause sees earlier chunks as units tagged with their label.
            pieces = [
                ("unit", piece[1], Tree(piece[1], piece[2])) if piece[0] == "chunk" else piece for piece in pieces
            ]
        children = [piece[2] for piece in pieces]
        # spec: N-000243 N-000437 — an empty tagged list gives a sentence root with no children; the root spelling is 'S'.
        return Tree(SENTENCE_LABEL, children)


def ne_chunk(tagged_tokens):
    """The named-entity chunker; it needs its packaged model and the English wordlist."""
    # spec: N-000432 N-000247 — raises unless the named-entity model and the English wordlist are visible.
    if isinstance(tagged_tokens, (str, bytes)) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    for relpath in ("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", "corpora/words"):
        found = data.find(relpath)
        if found is None or not os.path.exists(found):
            raise LookupError("named-entity chunker resource is not installed (%s not found)" % relpath)
    raise NotImplementedError(
        "the named-entity model format is not part of this specification; ne_chunk is not implemented"
    )
