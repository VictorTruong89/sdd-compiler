"""Punkt sentence-boundary detection (Kiss and Strunk, 2006) driven by packaged Punkt parameters."""

import os
import re

from lingora import data

# spec: N-000385 — orthographic context bits, as published in ortho_context.tab.
_BEG_UC, _MID_UC, _UNK_UC = 2, 4, 8
_BEG_LC, _MID_LC, _UNK_LC = 16, 32, 64
_LC = _BEG_LC | _MID_LC | _UNK_LC

_TOKEN_RE = re.compile(r"\S+")
_NUMERIC_RE = re.compile(r"[-+]?[\d.,:/]*\d[\d.,:/]*")
_CLOSERS = "\"')]}>”’»"

_cache = {}


class _Parameters:
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


def _read_optional(filepath):
    if not os.path.isfile(filepath):
        return []
    return data.read_lines(filepath)


def load_parameters(language):
    """Load the Punkt parameters packaged for ``language`` (a directory name such as ``english``)."""
    # spec: N-000391 — language is a Punkt language directory name.
    if not isinstance(language, str) or not language or language in (".", "..") or "/" in language or "\\" in language:
        raise ValueError("not a Punkt language name: %r" % (language,))
    directory = data.find("tokenizers/punkt_tab/%s" % language)
    # spec: N-000372 — the packaged Punkt model for the language.
    if directory is None or not os.path.isdir(directory):
        raise LookupError(
            "Punkt sentence models for %r are not installed (tokenizers/punkt_tab/%s not found in data.path)"
            % (language, language)
        )
    key = os.path.abspath(directory)
    if key in _cache:
        return _cache[key]
    # spec: N-000382 — file layouts of the Punkt model.
    abbrev_types = {line.strip() for line in _read_optional(os.path.join(directory, "abbrev_types.txt")) if line.strip()}
    sent_starters = {line.strip() for line in _read_optional(os.path.join(directory, "sent_starters.txt")) if line.strip()}
    collocations = set()
    for line in _read_optional(os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    ortho_context = {}
    for line in _read_optional(os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            ortho_context[parts[0]] = int(parts[1])
    parameters = _Parameters(abbrev_types, collocations, sent_starters, ortho_context)
    _cache[key] = parameters
    return parameters


def _describe(word):
    """Classify one whitespace-delimited token for the Punkt decisions."""
    stripped = word.rstrip(_CLOSERS)
    if stripped.endswith("?") or stripped.endswith("!"):
        end = stripped[-1]
    elif stripped.endswith("."):
        end = "."
    else:
        end = None
    base = stripped.rstrip(".!?")
    typ = base.lower()
    if _NUMERIC_RE.fullmatch(base):
        typ = "##number##"
    first_upper = base[:1].isupper()
    return {
        "end": end,
        "typ": typ,
        "base": base,
        "first_upper": first_upper,
        "first_lower": base[:1].islower(),
        "ellipsis": end == "." and stripped.endswith(".."),
        "initial": len(base) == 1 and base.isalpha() and first_upper,
    }


def _ortho_says_starter(info, parameters):
    """True when the orthographic context says a token with this type starts a sentence."""
    # spec: N-000385 — the orthographic heuristic of Punkt.
    context = parameters.ortho_context.get(info["typ"], 0)
    return bool(info["first_upper"] and (context & _LC) and not (context & _MID_UC))


def sentences(text, language="english"):
    """Split ``text`` into sentences, each the original text of that sentence."""
    # spec: N-000124 N-000125 — Punkt algorithm with the packaged parameters for the language.
    parameters = load_parameters(language)
    spans = [(m.start(), m.end()) for m in _TOKEN_RE.finditer(text)]
    if not spans:
        return []
    infos = [_describe(text[start:end]) for start, end in spans]
    last = len(spans) - 1
    result = []
    sentence_start = spans[0][0]
    for index in range(last + 1):
        ends_sentence = False
        info = infos[index]
        if index == last:
            ends_sentence = True
        elif info["end"] in ("?", "!"):
            # spec: N-000126 — ? and ! always end a sentence.
            ends_sentence = True
        elif info["end"] == ".":
            following = infos[index + 1]
            if (info["typ"], following["typ"]) in parameters.collocations:
                ends_sentence = False
            elif info["ellipsis"] or info["typ"] in parameters.abbrev_types or info["initial"]:
                # An abbreviation or ellipsis ends a sentence only before a likely sentence starter.
                ends_sentence = (following["first_upper"] and following["typ"] in parameters.sent_starters) or (
                    _ortho_says_starter(following, parameters)
                )
            else:
                ends_sentence = True
        if ends_sentence:
            result.append(text[sentence_start:spans[index][1]])
            if index < last:
                sentence_start = spans[index + 1][0]
    return result
