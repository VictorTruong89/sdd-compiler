"""Stemmers: ``from lingora.stem import ...`` (FP-02).

spec: N-000404 — ARLSTem, ARLSTem2, LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer, WordNetLemmatizer.
spec: N-000135 N-000136 N-000138 — the stemmer families: Porter, Lancaster, Snowball, regular-expression, and the
WordNet lemmatizer. ISRI, Cistem and RSLP are not part of the interface contract and are not implemented here.
"""

import os
import re

from lingora import data

_VOWELS = "aeiou"

# spec: N-000142 — the Snowball language names.
SNOWBALL_LANGUAGES = (
    "arabic",
    "danish",
    "dutch",
    "english",
    "finnish",
    "french",
    "german",
    "hungarian",
    "italian",
    "norwegian",
    "porter",
    "portuguese",
    "romanian",
    "russian",
    "spanish",
    "swedish",
)


def _check_word(word):
    # spec: N-000405 — word is a str, treated as one token.
    # spec: N-000405 N-000147 — word is a str, and is treated as one token; spaces are not split.
    if not isinstance(word, str):
        raise TypeError("word must be a str, not %s" % type(word).__name__)


# --- Porter ---------------------------------------------------------------------------------------------------

# spec: N-000150 — the small built-in table of irregular forms (its entries are outside the specification).
_PORTER_IRREGULAR = {
    "sky": "sky",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "news": "news",
    "inning": "inning",
    "innings": "inning",
    "outing": "outing",
    "outings": "outing",
    "canning": "canning",
    "cannings": "canning",
    "howe": "howe",
    "proceed": "proceed",
    "exceed": "exceed",
    "succeed": "succeed",
}

_STEP2_ORIGINAL = [
    ("ational", "ate"),
    ("tional", "tion"),
    ("enci", "ence"),
    ("anci", "ance"),
    ("izer", "ize"),
    ("abli", "able"),
    ("alli", "al"),
    ("entli", "ent"),
    ("eli", "e"),
    ("ousli", "ous"),
    ("ization", "ize"),
    ("ation", "ate"),
    ("ator", "ate"),
    ("alism", "al"),
    ("iveness", "ive"),
    ("fulness", "ful"),
    ("ousness", "ous"),
    ("aliti", "al"),
    ("iviti", "ive"),
    ("biliti", "ble"),
]
_STEP2_MARTIN = [rule for rule in _STEP2_ORIGINAL if rule[0] != "abli"] + [("bli", "ble"), ("logi", "log")]
_STEP2_NLTK = [rule for rule in _STEP2_ORIGINAL if rule[0] not in ("abli", "alli")] + [
    ("bli", "ble"),
    ("fulli", "ful"),
    ("logi", "log"),
]
_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = [
    "al",
    "ance",
    "ence",
    "er",
    "ic",
    "able",
    "ible",
    "ant",
    "ement",
    "ment",
    "ent",
    "ion",
    "ou",
    "ism",
    "ate",
    "iti",
    "ous",
    "ive",
    "ize",
]


def _longest_suffix(word, suffixes):
    best = None
    for suffix in suffixes:
        name = suffix[0] if isinstance(suffix, tuple) else suffix
        if word.endswith(name) and (best is None or len(name) > len(best)):
            best = name
    return best


class PorterStemmer:
    """Porter's algorithm in three modes; the default is the LINGORA extensions."""

    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"

    def __init__(self, mode=NLTK_EXTENSIONS):
        # spec: N-000144 N-000145 — exactly three modes; the default is the LINGORA extensions.
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.NLTK_EXTENSIONS):
            raise ValueError("unknown Porter mode: %r" % (mode,))
        self.mode = mode

    def _is_consonant(self, word, index):
        char = word[index]
        if char in _VOWELS:
            return False
        if char == "y":
            return index == 0 or not self._is_consonant(word, index - 1)
        return True

    def _measure(self, stem):
        pattern = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return re.sub(r"(.)\1+", r"\1", pattern).count("vc")

    def _has_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _cvc(self, word):
        # spec: N-000156 — the *o condition also holds for a two-letter stem of vowel then consonant.
        if self.mode == self.NLTK_EXTENSIONS and len(word) == 2:
            return not self._is_consonant(word, 0) and self._is_consonant(word, 1) and word[-1] not in "wxy"
        if len(word) < 3:
            return False
        return (
            self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in "wxy"
        )

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        # spec: N-000148 N-000149 — the word is lowercased first, unless the caller turns that off.
        if to_lowercase:
            word = word.lower()
        if self.mode == self.NLTK_EXTENSIONS:
            # spec: N-000150 — irregular-form lookup, then the one- and two-letter rule.
            if word in _PORTER_IRREGULAR:
                return _PORTER_IRREGULAR[word]
        # spec: N-000151 N-000152 — words of one or two characters are never stemmed.
        if len(word) <= 2:
            return word
        word = self._step1a(word)
        word = self._step1b(word)
        word = self._step1c(word)
        word = self._step2(word)
        word = self._step3(word)
        word = self._step4(word)
        word = self._step5a(word)
        word = self._step5b(word)
        return word

    def _step1a(self, word):
        if word.endswith("sses"):
            return word[:-2]
        if word.endswith("ies"):
            # spec: N-000153 — a four-letter word ending in -ies becomes -ie.
            if self.mode == self.NLTK_EXTENSIONS and len(word) == 4:
                return word[:-1]
            return word[:-2]
        if word.endswith("ss"):
            return word
        if word.endswith("s"):
            return word[:-1]
        return word

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("ied"):
            # spec: N-000154 N-000155 — -ied becomes -ie (four letters) or -i, and the rest of Step 1b is skipped.
            return word[:-1] if len(word) == 4 else word[:-2]
        if word.endswith("eed"):
            if self._measure(word[:-3]) > 0:
                return word[:-1]
            return word
        stripped = None
        if word.endswith("ed") and self._has_vowel(word[:-2]):
            stripped = word[:-2]
        elif word.endswith("ing") and self._has_vowel(word[:-3]):
            stripped = word[:-3]
        if stripped is None:
            return word
        if stripped.endswith(("at", "bl", "iz")):
            return stripped + "e"
        if self._double_consonant(stripped) and stripped[-1] not in "lsz":
            return stripped[:-1]
        if self._measure(stripped) == 1 and self._cvc(stripped):
            return stripped + "e"
        return stripped

    def _step1c(self, word):
        if not word.endswith("y"):
            return word
        if self.mode == self.NLTK_EXTENSIONS:
            # spec: N-000157 — y becomes i only after a consonant that is not the first letter of the stem.
            if len(word) > 2 and self._is_consonant(word, len(word) - 2):
                return word[:-1] + "i"
            return word
        if self._has_vowel(word[:-1]):
            return word[:-1] + "i"
        return word

    def _step2(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("alli") and self._measure(word[:-4]) > 0:
            # spec: N-000158 — -alli becomes -al first, and the result goes through Step 2 again.
            return self._step2(word[:-2])
        rules = {
            self.ORIGINAL_ALGORITHM: _STEP2_ORIGINAL,
            self.MARTIN_EXTENSIONS: _STEP2_MARTIN,
            self.NLTK_EXTENSIONS: _STEP2_NLTK,
        }[self.mode]
        suffix = _longest_suffix(word, rules)
        if suffix is None:
            return word
        replacement = dict(rules)[suffix]
        stem = word[: -len(suffix)]
        if self._measure(stem) > 0:
            if suffix == "logi" and self.mode == self.NLTK_EXTENSIONS and self._measure(word[:-3]) <= 0:
                return word
            return stem + replacement
        return word

    def _step3(self, word):
        suffix = _longest_suffix(word, _STEP3)
        if suffix is None:
            return word
        stem = word[: -len(suffix)]
        if self._measure(stem) > 0:
            return stem + dict(_STEP3)[suffix]
        return word

    def _step4(self, word):
        suffix = _longest_suffix(word, _STEP4)
        if suffix is None:
            return word
        stem = word[: -len(suffix)]
        if suffix == "ion" and not stem.endswith(("s", "t")):
            return word
        if self._measure(stem) > 1:
            return stem
        return word

    def _step5a(self, word):
        if not word.endswith("e"):
            return word
        stem = word[:-1]
        measure = self._measure(stem)
        if measure > 1 or (measure == 1 and not self._cvc(stem)):
            return stem
        return word

    def _step5b(self, word):
        if self._measure(word) > 1 and self._double_consonant(word) and word.endswith("l"):
            return word[:-1]
        return word


# --- Lancaster ------------------------------------------------------------------------------------------------

# spec: N-000166 — the Paice/Husk rule table published with the algorithm (C. D. Paice, 1990).
_LANCASTER_RULES_TEXT = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>.", "cn1t>.", "dd1.", "dei3y>.", "deec2ss.", "dee1.",
    "de2>.", "dooh4>.", "e1>.", "feil1v.", "fi2>.", "gni3>.", "gai3y.", "ga2>.", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>.", "i*1.", "i1y>.", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.",
    "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>.", "lc1.", "lufi4y.",
    "luf3y.", "lu2.", "lai3y>.", "la2>.", "ll1.", "mui3y.", "mu*2.", "msi3>.", "mm1.", "nois4j>.",
    "noix4ct.", "noi3>.", "nai3>.", "na2>.", "nee0.", "ne2>.", "nn1.", "pihs4>.", "pp1.", "re2>.",
    "rae0.", "ra2.", "ro2>.", "ru2>.", "rr1.", "rt1>.", "rei3y>.", "sei3y>.", "sis2.", "si2>.",
    "ssen4>.", "ss0.", "suo3>.", "su*2.", "s*1>.", "s0.", "tacilp4y.", "ta2>.", "tnem4>.", "tne3>.",
    "tna3>.", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>.",
    "tt1.", "uqi3.", "ugo1.", "vis3j>.", "vie0.", "vi2>.", "ylb1>.", "yli3y>.", "ylp0.", "yl2>.",
    "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>.", "yte3>.", "ytl2.", "yrtsi5.", "yra3>.", "yro3>.",
    "yfi3.", "ycn2t.", "yca3>.", "zi2>.", "zy1s.",
]


def _parse_lancaster_rule(rule):
    match = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)(>?)\.", rule)
    ending, intact, remove, append, cont = match.groups()
    return ending[::-1], bool(intact), int(remove), append, cont == ">"


_LANCASTER_RULES = [_parse_lancaster_rule(rule) for rule in _LANCASTER_RULES_TEXT]


def _lancaster_acceptable(stem):
    if not stem:
        return False
    if stem[0] in _VOWELS:
        return len(stem) >= 2
    return len(stem) >= 3 and any(char in "aeiouy" for char in stem)


class LancasterStemmer:
    # spec: N-000165 — Paice/Husk stemmer; the word is lowercased and no prefix is stripped.
    def stem(self, word):
        _check_word(word)
        word = word.lower()
        if not word.isalpha():
            return word
        intact = True
        while True:
            continued = False
            for ending, needs_intact, remove, append, cont in _LANCASTER_RULES:
                if needs_intact and not intact:
                    continue
                if not word.endswith(ending) or len(word) <= remove:
                    continue
                candidate = word[:-remove] + append
                if not _lancaster_acceptable(candidate):
                    continue
                if cont and len(candidate) >= len(word):
                    continue
                word = candidate
                intact = False
                if cont:
                    continued = True
                    break
                return word
            if not continued:
                return word


# --- Snowball (English Porter2 and the original Porter rendering) ---------------------------------------------

_PORTER2_EXC1 = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "idly": "idl",
    "gently": "gentl",
    "ugly": "ugli",
    "early": "earli",
    "only": "onli",
    "singly": "singl",
    "sky": "sky",
    "news": "news",
    "howe": "howe",
    "atlas": "atlas",
    "cosmos": "cosmos",
    "bias": "bias",
    "andes": "andes",
}
_PORTER2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_PORTER2_STEP2 = [
    ("tional", "tion"),
    ("enci", "ence"),
    ("anci", "ance"),
    ("abli", "able"),
    ("entli", "ent"),
    ("izer", "ize"),
    ("ization", "ize"),
    ("ational", "ate"),
    ("ation", "ate"),
    ("ator", "ate"),
    ("alism", "al"),
    ("aliti", "al"),
    ("alli", "al"),
    ("fulness", "ful"),
    ("ousli", "ous"),
    ("ousness", "ous"),
    ("iveness", "ive"),
    ("iviti", "ive"),
    ("biliti", "ble"),
    ("bli", "ble"),
    ("ogi", "og"),
    ("fulli", "ful"),
    ("lessli", "less"),
    ("li", ""),
]
_PORTER2_STEP3 = [
    ("tional", "tion"),
    ("ational", "ate"),
    ("alize", "al"),
    ("icate", "ic"),
    ("iciti", "ic"),
    ("ical", "ic"),
    ("ful", ""),
    ("ness", ""),
    ("ative", ""),
]
_PORTER2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _porter2_region(word, start):
    """The region after the first non-vowel that follows a vowel, searching from ``start``."""
    for index in range(max(start, 1), len(word)):
        if word[index] not in "aeiouy" and word[index - 1] in "aeiouy":
            return index + 1
    return len(word)


def _porter2_r1(word):
    if word.startswith(("gener", "arsen")):
        return 5
    if word.startswith("commun"):
        return 6
    return _porter2_region(word, 0)


def _porter2_short_syllable_at_end(word):
    return bool(re.search(r"[^aeiouy][aeiouy][^aeiouywxY]$", word)) or bool(re.fullmatch(r"[aeiouy][^aeiouy]", word))


def _porter2_match(word, rules):
    """The longest suffix of ``word`` named in ``rules`` as (suffix, replacement) pairs, or None."""
    best = None
    for name, target in rules:
        if word.endswith(name) and (best is None or len(name) > len(best[0])):
            best = (name, target)
    return best


def _porter2(word):
    if word in _PORTER2_EXC1:
        return _PORTER2_EXC1[word]
    if len(word) <= 2:
        return word
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars[0] == "y":
        chars[0] = "Y"
    for index in range(1, len(chars)):
        if chars[index] == "y" and chars[index - 1] in "aeiouy":
            chars[index] = "Y"
    word = "".join(chars)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if word.endswith(suffix):
            word = word[: -len(suffix)]
            break

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-3] + ("i" if len(word) - 3 > 1 else "ie")
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        if any(char in "aeiouy" for char in word[:-2]):
            word = word[:-1]
    if word in _PORTER2_EXC2:
        return word.replace("Y", "y")

    # Step 1b
    r1 = _porter2_r1(word)
    if word.endswith(("eedly", "eed")):
        suffix = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suffix) >= r1:
            word = word[: -len(suffix)] + "ee"
    else:
        suffix = None
        for candidate in ("ingly", "edly", "ing", "ed"):
            if word.endswith(candidate):
                suffix = candidate
                break
        if suffix is not None and any(char in "aeiouy" for char in word[: -len(suffix)]):
            word = word[: -len(suffix)]
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif word[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                word = word[:-1]
            elif _porter2_r1(word) >= len(word) and _porter2_short_syllable_at_end(word):
                word += "e"

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in "aeiouy":
        word = word[:-1] + "i"

    # Step 2 (in R1)
    r1 = _porter2_r1(word)
    match = _porter2_match(word, _PORTER2_STEP2)
    if match is not None and len(word) - len(match[0]) >= r1:
        name, target = match
        if name == "ogi":
            if word[: -len(name)].endswith("l"):
                word = word[: -len(name)] + target
        elif name == "li":
            if len(word) > 2 and word[-3] in "cdeghkmnrt":
                word = word[: -len(name)]
        else:
            word = word[: -len(name)] + target

    # Step 3
    r1 = _porter2_r1(word)
    r2 = _porter2_region(word, r1)
    match = _porter2_match(word, _PORTER2_STEP3)
    if match is not None:
        name, target = match
        if name == "ative":
            if len(word) - len(name) >= r2:
                word = word[: -len(name)]
        elif len(word) - len(name) >= r1:
            word = word[: -len(name)] + target

    # Step 4 (in R2)
    match = _porter2_match(word, [(name, "") for name in _PORTER2_STEP4])
    if match is not None:
        name, _ = match
        if len(word) - len(name) >= r2:
            if name != "ion" or word[: -len(name)].endswith(("s", "t")):
                word = word[: -len(name)]

    # Step 5
    if word.endswith("e"):
        stem = word[:-1]
        if len(stem) >= r2 or (len(stem) >= r1 and not _porter2_short_syllable_at_end(stem)):
            word = stem
    elif word.endswith("ll") and len(word) - 1 >= r2:
        word = word[:-1]

    return word.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmer for a language name from ``SNOWBALL_LANGUAGES``."""

    def __init__(self, language, ignore_stopwords=False):
        # spec: N-000408 N-000409 N-000410 N-000176 N-000177 — the language must be a listed name; the error names it.
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in ("english", "porter"):
            # The other Snowball algorithms are not implemented in this build.
            raise NotImplementedError("the Snowball %r stemmer is not implemented in this build" % (language,))
        self.language = language
        self._ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = frozenset()
        if self._ignore_stopwords:
            # spec: N-000411 N-000143 N-000178 N-000179 — the stopwords list for that language must be visible.
            relpath = "corpora/stopwords/%s" % language
            found = data.find(relpath)
            if found is None or not os.path.isfile(found):
                raise LookupError("stopwords list for %r is not installed (%s not found)" % (language, relpath))
            self._stopwords = frozenset(line.strip() for line in data.read_lines(found) if line.strip())
        self._porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        _check_word(word)
        # spec: N-000171 — the word is lowercased first.
        word = word.lower()
        if self._ignore_stopwords and word in self._stopwords:
            # spec: N-000172 — a stopword is returned unchanged, lowercased.
            return word
        # spec: N-000170 — 'porter' is a Snowball rendering of the original Porter algorithm. This build uses the
        # original-algorithm mode of PorterStemmer for it, which is an approximation, not Snowball's own code.
        if self.language == "porter":
            return self._porter.stem(word, to_lowercase=False)
        # spec: N-000169 — 'english' is the Porter2 (English) algorithm.
        return _porter2(word)


# --- regular-expression stemmer -------------------------------------------------------------------------------


class RegexpStemmer:
    def __init__(self, regexp):
        # spec: N-000407 N-000406 — regexp is a Python regular-expression string.
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        # spec: N-000173 N-000174 N-000175 — removes every match and changes nothing else.
        return self._regexp.sub("", word)


# --- Arabic light stemmers ------------------------------------------------------------------------------------
# spec: N-000135 N-000139 — ARLSTem and ARLSTem2 exist. Their stemming results are outside this specification; the
# versions below are approximate light stemmers, not the published algorithms.
# spec: N-000146 — the Porter modes other than the default are outside this specification.

_ARABIC_PREFIXES = ("وال", "بال", "كال", "فال", "ولل", "لل", "ال")
_ARABIC_SUFFIXES = ("ات", "ون", "ين", "ها", "ية", "ه", "ة")
_ARABIC_SUFFIXES_2 = _ARABIC_SUFFIXES + ("ي", "ت", "ن")


def _light_stem(word, suffixes):
    for prefix in _ARABIC_PREFIXES:
        if word.startswith(prefix) and len(word) - len(prefix) >= 3:
            word = word[len(prefix):]
            break
    for suffix in sorted(suffixes, key=len, reverse=True):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[: -len(suffix)]
    return word


class ARLSTem:
    def stem(self, word):
        _check_word(word)
        return _light_stem(word, _ARABIC_SUFFIXES)


class ARLSTem2:
    def stem(self, word):
        _check_word(word)
        return _light_stem(word, _ARABIC_SUFFIXES_2)


# --- WordNet lemmatizer ---------------------------------------------------------------------------------------

_MORPHY_RULES = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_WORDNET_INDEX_FILES = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "r": "index.adv"}


class WordNetLemmatizer:
    def __init__(self):
        # spec: N-000412 N-000180 N-000181 — the WordNet resource must be visible.
        directory = data.find("corpora/wordnet")
        if directory is None or not os.path.isdir(directory):
            raise LookupError("WordNet is not installed (corpora/wordnet not found in data.path)")
        self._lemmas = {}
        for pos, filename in _WORDNET_INDEX_FILES.items():
            lemmas = set()
            index_path = os.path.join(directory, filename)
            if os.path.isfile(index_path):
                for line in data.read_lines(index_path):
                    if line and not line.startswith(" "):
                        lemmas.add(line.split(" ", 1)[0])
            self._lemmas[pos] = lemmas

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        if pos not in _MORPHY_RULES:
            raise ValueError("unknown part of speech: %r" % (pos,))
        word = word.lower()
        if word in self._lemmas[pos]:
            return word
        for suffix, replacement in _MORPHY_RULES[pos]:
            if word.endswith(suffix):
                candidate = word[: -len(suffix)] + replacement
                if candidate in self._lemmas[pos]:
                    return candidate
        return word
