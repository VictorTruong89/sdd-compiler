"""BLEU: ``from lingora.translate import bleu`` (FP-07).

spec: N-000480 — bleu is in this module.
"""

import math
from collections import Counter


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1))


def _closest_reference_length(references, candidate_length):
    # spec: N-000322 — the reference length closest to the candidate length; the shorter one on a tie.
    return min((len(reference) for reference in references), key=lambda length: (abs(length - candidate_length), length))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """Sentence-level BLEU (Papineni et al., 2002) of ``hypothesis`` against ``references``.

    ``smoothing_function``, if given, is called with a list of (numerator, denominator) pairs, one per n-gram
    order, and returns the list of precisions to combine instead.
    """
    # spec: N-000490 N-000491 N-000492 N-000493 — token lists; caller weights; unsmoothed unless a function is given.
    if not isinstance(references, list) or not all(isinstance(reference, list) for reference in references):
        raise TypeError("references must be a list of token lists")
    if not isinstance(hypothesis, list):
        raise TypeError("hypothesis must be a token list")
    weights = list(weights)
    if not weights:
        raise ValueError("at least one weight is needed")
    # spec: N-000323 — tokens are compared exactly as given.
    pairs = []
    for n in range(1, len(weights) + 1):
        candidate = _ngrams(hypothesis, n)
        total = max(len(hypothesis) - n + 1, 0)
        clipped = 0
        for gram, count in candidate.items():
            # spec: N-000318 N-000319 — counts are clipped by the maximum count in any one reference.
            max_reference = max((_ngrams(reference, n)[gram] for reference in references), default=0)
            clipped += min(count, max_reference)
        pairs.append((clipped, total))
    if smoothing_function is not None:
        precisions = list(smoothing_function(pairs))
    else:
        precisions = [clipped / total if total else 0.0 for clipped, total in pairs]
        # spec: N-000324 N-000325 — without smoothing, a zero precision in a weighted order makes the score 0.
        if any(p == 0 for p, weight in zip(precisions, weights) if weight > 0):
            return 0.0
    if not hypothesis:
        return 0.0
    log_mean = sum(weight * math.log(p) for weight, p in zip(weights, precisions) if weight > 0)
    # spec: N-000322 — the brevity penalty.
    reference_length = _closest_reference_length(references, len(hypothesis))
    if len(hypothesis) > reference_length:
        penalty = 1.0
    else:
        penalty = math.exp(1 - reference_length / len(hypothesis))
    return penalty * math.exp(log_mean)
