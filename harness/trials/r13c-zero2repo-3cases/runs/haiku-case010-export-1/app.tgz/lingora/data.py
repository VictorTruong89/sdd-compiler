"""Packaged-resource finder: ``from lingora import data``."""

import os

# spec: N-000368 N-000371 — the initial contents are the implementer's choice. This build starts from the
# os.pathsep-separated directories in LINGORA_DATA, and from nothing otherwise.
# spec: N-000370 — an empty list means no packaged resource is visible.
path = [directory for directory in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if directory]


def find(relpath):
    """Return the first existing ``relpath`` under a directory in ``path``, or None."""
    # spec: N-000057 N-000060 N-000061 N-000062 — packaged models live outside the source tree and are found here.
    # spec: N-000369 — resources are found only in the listed directories.
    for directory in list(path):
        candidate = os.path.join(directory, relpath)
        if os.path.exists(candidate):
            return candidate
    return None


def read_lines(filepath):
    """Read a UTF-8 text file; each line without its terminator is one entry."""
    # spec: N-000381 — the model files are UTF-8 text, read as shipped.
    with open(filepath, encoding="utf-8") as handle:
        text = handle.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [line.rstrip("\r") for line in lines]
