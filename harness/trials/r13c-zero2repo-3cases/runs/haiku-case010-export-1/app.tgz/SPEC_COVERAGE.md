# Spec coverage (checklist)

Generated from `spec/CHECKLIST.md`. Every id ends **tested**, **implemented**, **partial** (with the missing part given), or **not done** (with a reason).

- tested: referenced by a test (`tests/`) and implemented in `lingora/`.
- implemented: referenced in `lingora/` (code marker), not directly named in a test.
- partial / not done: the reason is in the Notes column.

Counts: implemented 94, not done 10, partial 16, tested 374 (total 494)

| Id | Kind | Status | Where | Notes | Checklist text |
|---|---|---|---|---|---|
| N-000335 | constraint | tested | __init__.py, test_spec_surface.py |  | This is a pure-Python natural-language processing library with no compiled exten… |
| N-000336 | requirement | tested | test_spec_surface.py |  | The documented interpreter floor is Python 3.10 or newer. |
| N-000337 | requirement | implemented | __init__.py |  | Any standard x86_64 or arm64 Linux, macOS, or Windows host with a supported inte… |
| N-000338 | constraint | implemented | __init__.py |  | they are not required for the mandatory CPU profile. |
| N-000339 | requirement | tested | test_spec_surface.py |  | loading the library from this repository's source tree |
| N-000340 | requirement | tested | test_spec_surface.py |  | running one real word/punctuation tokenization with no downloaded corpus or mode… |
| N-000341 | requirement | not done | — | Profile label only (cpu_baseline). The library has no runtime profile switch, so nothing is built for it. | Profile id:** cpu_baseline |
| N-000342 | requirement | implemented | __init__.py |  | Platforms:** linux, darwin, windows |
| N-000343 | requirement | implemented | __init__.py |  | Required on:** linux |
| N-000344 | requirement | tested | test_spec_surface.py |  | the library loads from this repository's source tree (not a separately published… |
| N-000345 | requirement | tested | test_spec_surface.py |  | its word/punctuation tokenizer runs with no downloaded corpus or model |
| N-000346 | requirement | tested | test_spec_surface.py |  | Python 3.10 or newer. |
| N-000347 | constraint | tested | test_spec_surface.py |  | Runtime dependencies are a small set of pure-Python packages. |
| N-000348 | constraint | tested | test_spec_surface.py |  | Corpus downloads are not required for this profile. |
| N-000349 | constraint | tested | test_spec_surface.py |  | No extra system libraries beyond a normal interpreter. |
| N-000350 | requirement | tested | test_spec_surface.py |  | No native compile step. |
| N-000351 | requirement | tested | test_spec_surface.py |  | The package is a flat layout built with the standard Python packaging backend. |
| N-000352 | requirement | tested | test_spec_surface.py |  | An editable install from the project root, or putting the project root on the im… |
| N-000353 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | The product is an **importable Python library |
| N-000354 | requirement | tested | __init__.py, test_spec_surface.py |  | with a flat package layout: one importable package directory lingora at the re… |
| N-000355 | requirement | tested | test_spec_surface.py |  | The installable distribution and the import package are both named lingora. |
| N-000356 | requirement | tested | test_spec_surface.py |  | Python 3.10 or newer. |
| N-000357 | constraint | tested | test_spec_surface.py |  | It is not a network service and not a wire protocol |
| N-000358 | constraint | tested | test_grammar_trees_classify_metrics.py |  | it has no product-owned configuration file |
| N-000359 | constraint | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | Importing the package downloads nothing. |
| N-000360 | requirement | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | Every entry is a Python callable. |
| N-000361 | requirement | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | A call that succeeds returns the value described for that entry. |
| N-000362 | requirement | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | A call that does not succeed raises an exception. |
| N-000363 | constraint | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | A refusal never shows as a returned empty list, empty string, 0 or None, unl… |
| N-000364 | constraint | tested | test_spec_surface.py |  | Exception classes and message wording are the implementer's choice, except where… |
| N-000365 | constraint | tested | test_spec_surface.py |  | Parameters not shown are the implementer's choice, as long as callers that pass … |
| N-000366 | requirement | tested | test_spec_surface.py |  | every shown parameter may also be passed by keyword. |
| N-000367 | constraint | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | A score or distance is a real number: an int or a float, never a bool. |
| N-000368 | requirement | tested | data.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | A caller may replace its contents in place after importing the package and befor… |
| N-000369 | requirement | tested | data.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | Such calls then find resources only in the listed directories. |
| N-000370 | constraint | tested | data.py, conftest.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | An empty list means no packaged resource is visible. |
| N-000371 | constraint | tested | data.py, test_spec_surface.py |  | The list's initial contents are the implementer's choice. |
| N-000372 | requirement | tested | punkt.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | / Punkt sentence model for <language> / tokenizers/punkt_tab/<language>/ (En… |
| N-000373 | requirement | tested | tag.py, test_spec_surface.py |  | / English averaged perceptron tagger / taggers/averaged_perceptron_tagger_eng/… |
| N-000374 | requirement | tested | tag.py, test_spec_surface.py |  | / Russian averaged perceptron tagger / taggers/averaged_perceptron_tagger_rus/… |
| N-000375 | requirement | tested | tag.py, test_spec_surface.py |  | / Universal tagset tables / taggers/universal_tagset/ / |
| N-000376 | requirement | tested | test_spec_surface.py |  | / Named-entity chunker model / chunkers/maxent_ne_chunker_tab/english_ace_multi… |
| N-000377 | requirement | tested | test_spec_surface.py |  | / English wordlist / corpora/words / |
| N-000378 | requirement | tested | test_spec_surface.py |  | / Stopwords list for <language> / corpora/stopwords/<language>: a UTF-8 text… |
| N-000379 | requirement | tested | test_spec_surface.py |  | / WordNet / corpora/wordnet / |
| N-000380 | requirement | tested | test_spec_surface.py |  | Each model directory holds the files of the packaged resource of that name, in t… |
| N-000381 | requirement | tested | data.py, test_spec_surface.py |  | The model files the library reads, all UTF-8 text, are read as shipped. |
| N-000382 | requirement | tested | punkt.py, test_spec_surface.py |  | / Punkt sentence model / abbrev_types.txt: one <type> per line. sent_starte… |
| N-000383 | requirement | tested | tag.py, test_spec_surface.py |  | / Averaged perceptron tagger (<lang> is eng or rus) / averaged_perceptron… |
| N-000384 | requirement | tested | test_spec_surface.py |  | / Universal tagset tables / en-ptb.map: one <Penn Treebank tag> TAB <univer… |
| N-000385 | requirement | tested | punkt.py, test_spec_surface.py |  | A type absent from the file has no observation. |
| N-000386 | requirement | implemented | tokenize.py |  | from lingora.tokenize import RegexpTokenizer, TreebankWordTokenizer, TweetTokeni… |
| N-000387 | requirement | implemented | tokenize.py |  | the submodule is also from lingora import tokenize |
| N-000388 | constraint | implemented | tokenize.py |  | text and pattern are str. |
| N-000389 | constraint | implemented | tokenize.py |  | pattern is a Python regular expression. |
| N-000390 | constraint | implemented | tokenize.py |  | gaps, discard_empty, preserve_line, preserve_case, reduce_len and stri… |
| N-000391 | constraint | tested | punkt.py, test_spec_surface.py |  | language is a Punkt language directory name, such as english. |
| N-000392 | requirement | tested | tokenize.py, test_spec_surface.py |  | preserve_line=True treats text as one already-delimited line, with no sentenc… |
| N-000393 | requirement | tested | tokenize.py, test_spec_surface.py |  | preserve_line=False splits sentences first. |
| N-000394 | requirement | tested | tokenize.py, test_tokenize.py |  | Each element of a returned list is one token: a sentence string for sent_tokeni… |
| N-000395 | requirement | tested | tokenize.py, test_spec_surface.py, test_tokenize.py |  | span_tokenize yields one (start, end) pair of int character offsets per tok… |
| N-000396 | requirement | tested | test_tokenize.py |  | When the Punkt model is not visible, sent_tokenize and word_tokenize(..., pre… |
| N-000397 | requirement | tested | cli.py, test_tokenize.py |  | args=['tokenize'] runs the tokenize command. |
| N-000398 | requirement | tested | cli.py, test_tokenize.py |  | It reads UTF-8 text from standard input. |
| N-000399 | requirement | tested | cli.py, test_tokenize.py |  | For every input line it writes one line to standard output: the line's tokens jo… |
| N-000400 | requirement | tested | cli.py, test_spec_surface.py, test_tokenize.py |  | With standalone_mode=True, main ends the process: exit status 0 on success a… |
| N-000401 | requirement | tested | cli.py, test_spec_surface.py, test_tokenize.py |  | On failure no token line is written for the failed input. |
| N-000402 | decision | tested | test_spec_surface.py |  | The exact non-zero status, any standard-error text, and any progress display on … |
| N-000403 | decision | tested | cli.py, test_spec_surface.py, test_tokenize.py |  | Further options of the command (language, delimiter, encoding) are the implement… |
| N-000404 | requirement | implemented | stem.py |  | from lingora.stem import ARLSTem, ARLSTem2, LancasterStemmer, PorterStemmer, Reg… |
| N-000405 | requirement | implemented | stem.py |  | word is a str and is treated as one token. |
| N-000406 | requirement | implemented | stem.py |  | to_lowercase and ignore_stopwords are bool. |
| N-000407 | requirement | implemented | stem.py |  | regexp is a Python regular-expression string. |
| N-000408 | requirement | implemented | stem.py |  | language is one of the names arabic, danish, dutch, english, finnish,… |
| N-000409 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | An unsupported language makes the SnowballStemmer constructor raise |
| N-000410 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | the exception message contains the requested name. |
| N-000411 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | When ignore_stopwords=True and that language's stopwords list is not visible, … |
| N-000412 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | When WordNet is not visible, WordNetLemmatizer raises, either at construction … |
| N-000413 | requirement | implemented | tag.py |  | from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag |
| N-000414 | requirement | implemented | tag.py |  | (the submodule is also from lingora import tag). |
| N-000415 | requirement | implemented | tag.py |  | tokens is a list of str. |
| N-000416 | requirement | implemented | tag.py |  | train is a list of sentences. |
| N-000417 | requirement | implemented | tag.py |  | Each sentence is a list of (token, tag) pairs. |
| N-000418 | requirement | implemented | tag.py |  | regexps is a list of (<pattern>, <tag>) pairs, each a regular-expression st… |
| N-000419 | requirement | implemented | tag.py |  | backoff is another tagger, or None. |
| N-000420 | requirement | tested | test_stem_tag_chunk.py |  | lang is 'eng' (the default) or 'rus'. |
| N-000421 | requirement | tested | test_stem_tag_chunk.py |  | tagset is None (the default: native tags) or 'universal'. |
| N-000422 | requirement | implemented | tag.py |  | A str passed as tokens is refused by raising. |
| N-000423 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | Any other lang, and a missing model for the requested lang, also make the ca… |
| N-000424 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | The result holds one (token, tag) tuple per input token, in order. |
| N-000425 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | tag is a str, or None when no tag is assigned. |
| N-000426 | requirement | tested | chunk.py, test_spec_surface.py |  | from lingora.chunk import RegexpParser, ne_chunk |
| N-000427 | requirement | tested | chunk.py, test_spec_surface.py |  | the submodule is also from lingora import chunk |
| N-000428 | requirement | implemented | chunk.py |  | tagged and tagged_tokens are lists of (token, tag) pairs. |
| N-000429 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | grammar is a str, or a list of chunk-parser stages |
| N-000430 | decision | implemented | chunk.py |  | the stage objects are the implementer's choice |
| N-000431 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | Any other value makes the constructor raise. |
| N-000432 | requirement | tested | chunk.py, test_spec_surface.py, test_stem_tag_chunk.py |  | ne_chunk raises when the named-entity model or the English wordlist is not visi… |
| N-000433 | constraint | tested | chunk.py, test_stem_tag_chunk.py |  | A clause begins with a line <LABEL>: <pattern>. |
| N-000434 | constraint | tested | chunk.py, test_stem_tag_chunk.py |  | Further patterns of the same clause follow on indented lines. |
| N-000435 | requirement | implemented | chunk.py |  | The result is a Tree |
| N-000436 | requirement | implemented | chunk.py |  | The root's label is the default sentence label. |
| N-000437 | decision | implemented | chunk.py |  | Its spelling is the implementer's choice. |
| N-000438 | requirement | implemented | chunk.py |  | Its children are, in order, the input (token, tag) pairs that are in no chunk,… |
| N-000439 | requirement | implemented | chunk.py |  | A chunk's label is its clause's <LABEL> |
| N-000440 | requirement | implemented | chunk.py |  | its children are its (token, tag) pairs |
| N-000441 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | from lingora.grammar import CFG |
| N-000442 | requirement | tested | __init__.py, test_spec_surface.py |  | from lingora.parse import ChartParser, ShiftReduceParser |
| N-000443 | requirement | tested | test_spec_surface.py |  | from lingora.parse.generate import generate |
| N-000444 | constraint | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | The text has one production per line, written <LHS> -> <RHS>. |
| N-000445 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | Blank lines are ignored. |
| N-000446 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | A nonterminal is returned as a symbol |
| N-000447 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | a str, or an object whose str() is the nonterminal's name |
| N-000448 | decision | implemented | grammar.py |  | Which of the two is the implementer's choice. |
| N-000449 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | In rhs(), a terminal appears as a str equal to the quoted text, without the … |
| N-000450 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | A nonterminal appears as a symbol that is not a str. |
| N-000451 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | productions() holds one Production per alternative. |
| N-000452 | constraint | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | tokens is a list of str. |
| N-000453 | requirement | tested | test_grammar_trees_classify_metrics.py |  | parse returns zero or more trees. |
| N-000454 | requirement | tested | test_grammar_trees_classify_metrics.py |  | A token list the grammar does not derive gives an empty iterator. |
| N-000455 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | A token that no production produces makes parse raise. |
| N-000456 | requirement | tested | test_grammar_trees_classify_metrics.py |  | The exception is raised by the call or by the first iteration of its result. |
| N-000457 | constraint | tested | generate.py, test_grammar_trees_classify_metrics.py |  | n is an int or None: the maximum number of sentences, or no limit. |
| N-000458 | constraint | tested | generate.py, test_grammar_trees_classify_metrics.py |  | depth is an int or None: the derivation depth bound. |
| N-000459 | constraint | tested | test_grammar_trees_classify_metrics.py |  | start is a symbol, or None for the grammar's start symbol. |
| N-000460 | requirement | tested | test_grammar_trees_classify_metrics.py |  | Each sentence is a list of str tokens. |
| N-000461 | requirement | tested | test_spec_surface.py |  | from lingora.tree import Tree |
| N-000462 | requirement | tested | test_spec_surface.py |  | from lingora import tree |
| N-000463 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | Iterating a tree, len(tree) and tree[i] give its immediate children |
| N-000464 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | which are str leaves or trees |
| N-000465 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | == compares two trees. |
| N-000466 | constraint | implemented | tree.py |  | children must be a list of children. |
| N-000467 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | A str given as children, or omitting children, makes Tree raise. |
| N-000468 | requirement | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | Tree(label, []) is a tree with no children. |
| N-000469 | constraint | tested | tree.py, test_grammar_trees_classify_metrics.py |  | s is bracketed tree text: (<label> <child> …), where a child is a nested brac… |
| N-000470 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | pformat() returns the pretty-printed text as a str. |
| N-000471 | decision | tested | tree.py, test_spec_surface.py |  | Its layout is the implementer's choice. |
| N-000472 | requirement | tested | classify.py, test_spec_surface.py |  | from lingora.classify import NaiveBayesClassifier, DecisionTreeClassifier, accur… |
| N-000473 | requirement | tested | classify.py, test_spec_surface.py |  | from lingora import classify |
| N-000474 | constraint | tested | classify.py, test_grammar_trees_classify_metrics.py |  | labeled_featuresets and gold are lists of (featureset, label) pairs. |
| N-000475 | constraint | tested | test_grammar_trees_classify_metrics.py |  | A label is any hashable value. |
| N-000476 | requirement | implemented | classify.py |  | A ProbDist has prob(<label>), which returns that label's probability as a f… |
| N-000477 | requirement | implemented | classify.py |  | samples(), which returns the labels. |
| N-000478 | requirement | tested | metrics.py, test_spec_surface.py |  | from lingora.metrics import accuracy, edit_distance, jaccard_distance, precision… |
| N-000479 | requirement | tested | metrics.py, test_spec_surface.py |  | the submodule is also from lingora import metrics |
| N-000480 | requirement | tested | translate.py, test_spec_surface.py |  | from lingora.translate import bleu |
| N-000481 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | reference and test are lists. |
| N-000482 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | Lists of different lengths make it raise. |
| N-000483 | requirement | implemented | metrics.py |  | s1 and s2 are str. |
| N-000484 | requirement | implemented | metrics.py |  | substitution_cost is a number. |
| N-000485 | requirement | implemented | metrics.py |  | transpositions is a bool. |
| N-000486 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | label1 and label2 are sets. |
| N-000487 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | reference and test are sets (or frozensets). |
| N-000488 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | A non-set argument makes the call raise. |
| N-000489 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | When the PRD says no number results, the call returns None. |
| N-000490 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | references is a list of reference token lists |
| N-000491 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | hypothesis is a token list. |
| N-000492 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | weights is a sequence of numbers, one per n-gram order starting from unigrams. |
| N-000493 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | The call is unsmoothed unless a smoothing function is passed. |
| N-000494 | decision | tested | test_grammar_trees_classify_metrics.py, test_spec_surface.py |  | The name and form of that argument are the implementer's choice. |
| N-000001 | requirement | implemented | __init__.py |  | An integrator imports it and calls its published processing entries |
| N-000002 | constraint | implemented | __init__.py |  | it is not a single end-user application |
| N-000003 | requirement | tested | cli.py, test_spec_traceability.py |  | A command-line convenience can tokenize a text stream with the same recommended … |
| N-000004 | constraint | tested | cli.py, test_spec_traceability.py |  | that convenience is the same capability, not a second product |
| N-000005 | requirement | implemented | __init__.py |  | split text into tokens |
| N-000006 | requirement | implemented | __init__.py |  | reduce words to stems |
| N-000007 | requirement | implemented | __init__.py |  | assign part-of-speech tags |
| N-000008 | requirement | implemented | __init__.py |  | group tagged tokens into shallow chunks |
| N-000009 | requirement | implemented | __init__.py |  | parse a sentence against a caller-supplied grammar |
| N-000010 | requirement | implemented | __init__.py |  | work with constituent trees |
| N-000011 | requirement | implemented | __init__.py |  | train a text classifier |
| N-000012 | requirement | implemented | __init__.py |  | score outputs with the built-in evaluation metrics |
| N-000013 | constraint | implemented | __init__.py |  | This document specifies **user- and integrator-observable behavior only**. |
| N-000014 | constraint | implemented | __init__.py |  | Exact published symbol names, import paths, call signatures and output forms bel… |
| N-000015 | requirement | implemented | __init__.py |  | Every feature point below corresponds to behavior that exists in the finished LI… |
| N-000016 | decision | implemented | __init__.py |  | Feature points are ordered so foundational capabilities come first |
| N-000017 | constraint | implemented | __init__.py |  | a later feature point may depend on an earlier one, never the reverse |
| N-000018 | constraint | not done | test_spec_traceability.py | Outside this specification: packaged corpora, WordNet browsers, and similar surfaces are not feature points; not built. | They are **not** feature points of this specification. |
| N-000019 | requirement | tested | test_spec_traceability.py |  | that prerequisite is stated on that path |
| N-000020 | requirement | tested | test_spec_traceability.py |  | a missing model makes that path fail |
| N-000021 | requirement | tested | test_spec_traceability.py |  | Slicing the original string at a span must recover the corresponding token. |
| N-000022 | constraint | tested | test_spec_traceability.py |  | A stem is not required to be a dictionary word. |
| N-000023 | requirement | implemented | tag.py |  | consulted only when the primary tagger does not assign a tag |
| N-000024 | requirement | tested | test_spec_traceability.py |  | A pattern in braces chunks matching tag sequences … later clauses may cascade |
| N-000025 | requirement | implemented | chunk.py |  | Whitespace in a tag pattern is ignored. |
| N-000026 | requirement | tested | test_spec_traceability.py |  | The recommended sentence tokenizer, and the recommended word tokenizer when it f… |
| N-000027 | requirement | implemented | __init__.py |  | LINGORA is imported and used from Python. |
| N-000028 | requirement | tested | test_spec_traceability.py |  | Tokenizing a string into words, punctuation, sentences, or spans, including the … |
| N-000029 | constraint | not done | test_spec_traceability.py | An s-expression tokenizer is outside this specification; not built. | An s-expression tokenizer also exists; it is outside this specification. |
| N-000030 | requirement | tested | test_spec_traceability.py |  | A command-line tokenize command applies the recommended word tokenizer to each l… |
| N-000031 | requirement | tested | test_spec_traceability.py |  | so it requires the Punkt models for the requested language. |
| N-000032 | requirement | tested | test_spec_traceability.py |  | Stemming a word with Porter, Lancaster, Snowball, a caller-supplied suffix patte… |
| N-000033 | requirement | tested | test_spec_traceability.py |  | Tagging a token list: sequential taggers the caller trains (default, unigram, bi… |
| N-000034 | requirement | tested | test_spec_traceability.py |  | LINGORA’s recommended English or Russian tagger when the corresponding averaged … |
| N-000035 | requirement | tested | test_spec_traceability.py |  | Chunking a tagged token list with a chunk grammar. |
| N-000036 | requirement | partial | test_spec_traceability.py | ne_chunk checks for its model and wordlist (LookupError when absent) but raises NotImplementedError when they are present; the model file format is not in the specification. | A named-entity chunker exists when its packaged model is installed |
| N-000037 | constraint | tested | test_spec_traceability.py |  | it is not the primary way to satisfy chunking. |
| N-000038 | requirement | tested | test_spec_traceability.py |  | Building a context-free grammar from productions |
| N-000039 | requirement | tested | test_spec_traceability.py |  | parsing a token list with a recursive-descent, shift-reduce, or chart parser |
| N-000040 | requirement | tested | test_spec_traceability.py |  | generating strings from a grammar |
| N-000041 | requirement | tested | test_spec_traceability.py |  | building, comparing, and pretty-printing constituent trees from bracketed tree t… |
| N-000042 | requirement | tested | test_spec_traceability.py |  | Training and applying a Naive Bayes classifier or a decision tree classifier on … |
| N-000043 | requirement | tested | test_spec_traceability.py |  | including a probability distribution over labels for Naive Bayes. |
| N-000044 | requirement | tested | test_spec_traceability.py |  | Scoring: Levenshtein edit distance (optional transpositions), Jaccard distance, … |
| N-000045 | constraint | implemented | __init__.py |  | They do not invent additional product surfaces. |
| N-000046 | constraint | tested | __init__.py, test_spec_surface.py |  | A pure-Python library with no compiled extensions, native code, or GPU/accelerat… |
| N-000047 | constraint | tested | test_spec_surface.py |  | Packaging uses a flat package layout. |
| N-000048 | requirement | tested | test_spec_surface.py |  | An editable install from this repository’s source tree is sufficient. |
| N-000049 | constraint | tested | test_spec_surface.py |  | Python 3.10 or newer, through the latest 3.14. |
| N-000050 | constraint | tested | test_spec_surface.py |  | Runtime dependencies are limited to pure-Python packages. |
| N-000051 | constraint | tested | test_spec_surface.py |  | Optional extra groups add scientific-computing libraries for some classifiers an… |
| N-000052 | constraint | tested | test_spec_surface.py |  | they are not required for the CPU profile. |
| N-000053 | constraint | implemented | __init__.py |  | Windows, Mac OS X, and Linux. |
| N-000054 | constraint | implemented | __init__.py |  | The product must run on Linux with a supported interpreter. |
| N-000055 | constraint | implemented | __init__.py |  | CPU-only. |
| N-000056 | constraint | tested | test_spec_surface.py |  | Importing the package from this repository and running a word/punctuation tokeni… |
| N-000057 | constraint | implemented | data.py |  | Many advertised resources (Punkt, the averaged perceptron tagger, WordNet, Treeb… |
| N-000058 | constraint | not done | — | Package downloader is outside this specification (N-000331); not implemented. | Full-suite corpus download is documented via the package downloader. |
| N-000059 | constraint | tested | test_spec_surface.py |  | It is **not** required for the baseline word/punctuation tokenizer, for trainabl… |
| N-000060 | requirement | tested | data.py, test_spec_traceability.py |  | When a feature point names a packaged model as a prerequisite, absence of that m… |
| N-000061 | requirement | implemented | data.py |  | The finder searches a list of directories that the caller may set |
| N-000062 | requirement | implemented | data.py |  | a path that needs a packaged model finds it only in those directories. |
| N-000063 | constraint | implemented | tokenize.py |  | Input and output are Unicode text. |
| N-000064 | requirement | tested | test_spec_traceability.py |  | Accented letters in a tweet-style tokenizer remain intact inside their tokens. |
| N-000065 | assumption | tested | test_spec_traceability.py |  | The library is used in-process. |
| N-000066 | requirement | implemented | __init__.py |  | Every feature point below is a core capability of the real library |
| N-000067 | requirement | tested | __init__.py, test_spec_surface.py, test_spec_traceability.py |  | the outcomes come from the library implementing the stated rules on the caller’s… |
| N-000068 | requirement | tested | __init__.py, test_spec_traceability.py |  | When the package cannot be imported, none of its entries can be called. |
| N-000069 | constraint | tested | test_spec_surface.py |  | Being a general-purpose regular-expression engine, machine-learning framework, o… |
| N-000070 | constraint | tested | test_spec_surface.py, test_spec_traceability.py |  | Shipping WordNet, Treebank, or other corpora inside the source tree. |
| N-000071 | constraint | partial | test_spec_traceability.py | The data finder is implemented; the downloader is outside this specification and not built. | The data finder and downloader exist so callers can install them; they are not f… |
| N-000072 | constraint | tested | test_spec_surface.py, test_spec_traceability.py |  | Graphical applications (chart parser, chunk parser, WordNet browser, concordance… |
| N-000073 | constraint | tested | test_spec_surface.py, test_spec_traceability.py |  | Chat bots, Twitter clients, Hugging Face dataset helpers, and Toolbox readers. |
| N-000074 | constraint | tested | test_spec_surface.py, test_spec_traceability.py |  | Wrappers that require an external binary or service (Stanford, Senna, Hunpos, Ma… |
| N-000075 | constraint | tested | test_spec_surface.py |  | Combinatory categorial grammar, discourse representation, first-order inference … |
| N-000076 | constraint | tested | test_spec_surface.py |  | N-gram language-model training as a separate product. |
| N-000077 | constraint | implemented | — | Non-goal: no throughput is guaranteed; nothing to build. | Guaranteeing a particular tokens-per-second throughput. |
| N-000078 | requirement | tested | test_spec_traceability.py, test_tokenize.py |  | LINGORA’s tokenizer entries: the word/punctuation tokenizer; the Penn Treebank w… |
| N-000079 | constraint | not done | test_spec_traceability.py | An s-expression tokenizer is outside this specification; not built. | An s-expression tokenizer also exists; it is outside this specification. |
| N-000080 | requirement | tested | tokenize.py, test_tokenize.py |  | applies the recommended word tokenizer to each line of a text stream, including … |
| N-000081 | requirement | tested | test_spec_traceability.py |  | writes the tokens joined by a delimiter (one space by default). |
| N-000082 | requirement | tested | test_tokenize.py |  | Because that path splits sentences first, it requires the **Punkt** models for t… |
| N-000083 | requirement | tested | test_tokenize.py |  | The recommended sentence tokenizer, and the recommended word tokenizer when it i… |
| N-000084 | requirement | tested | tokenize.py, test_spec_traceability.py |  | the default language is English. |
| N-000085 | requirement | tested | test_tokenize.py |  | The word/punctuation tokenizer, the Penn Treebank word tokenizer, the recommende… |
| N-000086 | requirement | tested | tokenize.py, test_spec_traceability.py, test_tokenize.py |  | The tokens are, left to right, the maximal runs of word characters (Unicode lett… |
| N-000087 | requirement | tested | tokenize.py, test_tokenize.py |  | the maximal runs of characters that are neither word characters nor whitespace. |
| N-000088 | requirement | tested | tokenize.py, test_tokenize.py |  | Whitespace is never part of a token. |
| N-000089 | requirement | tested | tokenize.py, test_tokenize.py |  | It follows the Penn Treebank tokenization conventions |
| N-000090 | requirement | tested | test_tokenize.py |  | The text is split at whitespace, and punctuation is then split off as follows. |
| N-000091 | requirement | tested | test_tokenize.py |  | A straight double quote at the start of the text, or after a space or an opening… |
| N-000092 | requirement | tested | test_tokenize.py |  | Every other straight double quote becomes the closing-quote token made of two ap… |
| N-000093 | requirement | tested | test_spec_traceability.py |  | A straight double quote is never a token of its own. |
| N-000094 | requirement | tested | test_spec_traceability.py |  | Each of the characters ;, @, #, $, %, &, ?, ! and each bracket i… |
| N-000095 | requirement | tested | test_spec_traceability.py |  | So is an ellipsis of three points. |
| N-000096 | requirement | tested | test_tokenize.py |  | A comma or colon is split off unless a digit follows it. |
| N-000097 | requirement | tested | test_spec_traceability.py |  | A point is split off only when it ends the text, optionally followed by closing … |
| N-000098 | requirement | tested | tokenize.py, test_tokenize.py |  | The clitics 's, 'm, 'd, 'll, 're, 've and n't (in either letter ca… |
| N-000099 | requirement | tested | test_tokenize.py |  | The fused forms *cannot*, *d'ye*, *gimme*, *gonna*, *gotta*, *lemme*, *more'n*, … |
| N-000100 | requirement | tested | test_tokenize.py |  | An apostrophe that does not begin one of those clitics stays inside its word. |
| N-000101 | requirement | tested | tokenize.py, test_tokenize.py |  | It applies the same Penn Treebank conventions, with these improvements |
| N-000102 | requirement | tested | tokenize.py, test_tokenize.py |  | Typographic quotation marks are split off as tokens of their own. |
| N-000103 | requirement | tested | tokenize.py, test_tokenize.py |  | Dashes in the range U+2012–U+2015 and asterisks are split off. |
| N-000104 | requirement | tested | tokenize.py, test_tokenize.py |  | Any run of two or more points is a token. |
| N-000105 | requirement | tested | tokenize.py, test_tokenize.py |  | A double hyphen is a token. |
| N-000106 | requirement | tested | tokenize.py, test_spec_surface.py, test_tokenize.py |  | Unless the caller says the input is one already-delimited line, it first splits … |
| N-000107 | requirement | tested | tokenize.py, test_tokenize.py |  | then tokenizes each sentence and concatenates the tokens in order |
| N-000108 | requirement | tested | tokenize.py, test_tokenize.py |  | The tokens are the maximal runs of non-whitespace characters (whitespace is spac… |
| N-000109 | requirement | tested | tokenize.py, test_tokenize.py |  | The segments are the pieces of text between separators, in order, with empty pie… |
| N-000110 | requirement | tested | tokenize.py, test_tokenize.py |  | Single newlines inside a segment are kept. |
| N-000111 | requirement | tested | tokenize.py, test_tokenize.py |  | In token mode (the default), the tokens are the successive non-overlapping match… |
| N-000112 | requirement | tested | tokenize.py, test_tokenize.py |  | In gap mode, the pattern matches separators, and the tokens are the pieces of te… |
| N-000113 | requirement | tested | tokenize.py, test_tokenize.py |  | Empty pieces are dropped unless the caller turns empty-discarding off (it is on … |
| N-000114 | requirement | tested | tokenize.py, test_tokenize.py |  | Words containing an internal apostrophe (contractions) stay one token. |
| N-000115 | requirement | tested | tokenize.py, test_spec_traceability.py, test_tokenize.py |  | Letters with diacritics are word characters, so accented words stay whole. |
| N-000116 | requirement | tested | tokenize.py, test_tokenize.py |  | Emoticons, URLs, hashtags and @-handles are single tokens |
| N-000117 | requirement | tested | tokenize.py, test_tokenize.py |  | other punctuation marks are tokens of their own |
| N-000118 | requirement | tested | tokenize.py, test_tokenize.py |  | With handle stripping on (off by default), every @-handle is removed before toke… |
| N-000119 | requirement | tested | tokenize.py, test_tokenize.py |  | With length reduction on (off by default), every run of three or more consecutiv… |
| N-000120 | requirement | tested | tokenize.py, test_tokenize.py |  | With case preservation off (it is on by default), tokens are lowercased, except … |
| N-000121 | requirement | tested | tokenize.py, test_tokenize.py |  | A tokenizer that reports spans returns one pair of character offsets per token, … |
| N-000122 | requirement | tested | test_spec_traceability.py, test_tokenize.py |  | Slicing the input at each pair gives the corresponding token. |
| N-000123 | requirement | tested | tokenize.py, test_tokenize.py |  | Each pair starts at or after the end of the previous one. |
| N-000124 | requirement | tested | punkt.py, tokenize.py, test_tokenize.py |  | It implements the Punkt unsupervised sentence-boundary detection algorithm (Kiss… |
| N-000125 | requirement | tested | punkt.py, test_tokenize.py |  | It uses the packaged Punkt parameters for the requested language: abbreviation t… |
| N-000126 | requirement | tested | punkt.py, test_tokenize.py |  | It returns the sentences of the text in their original order. |
| N-000127 | requirement | tested | test_tokenize.py |  | Each sentence is the original text of that sentence, without the whitespace that… |
| N-000128 | requirement | tested | test_tokenize.py |  | A text that is a single sentence yields that one sentence. |
| N-000129 | requirement | tested | cli.py, test_tokenize.py |  | The tokenize command reads standard input line by line. |
| N-000130 | requirement | tested | cli.py, test_tokenize.py |  | For each input line it writes one output line: that line's recommended-word-toke… |
| N-000131 | requirement | tested | tokenize.py, test_tokenize.py |  | An empty string, and a string made only of whitespace, yield an empty token list… |
| N-000132 | requirement | tested | test_tokenize.py |  | When sentence splitting is requested and the Punkt models for the requested lang… |
| N-000133 | requirement | tested | test_spec_surface.py, test_tokenize.py |  | The failure is distinguishable from a successful empty token list. |
| N-000134 | requirement | tested | cli.py, test_tokenize.py |  | The command-line tokenize command does **not** succeed when the Punkt models for… |
| N-000135 | requirement | partial | stem.py, test_stem_tag_chunk.py | Porter, Lancaster, Snowball (english, porter only), regular-expression and WordNet lemmatizer are implemented. ISRI, Cistem and RSLP are not in the interface contract and are not built; ARLSTem/ARLSTem2 are approximate. | The built-in stemmer families are exactly: **Porter** (English), **Lancaster** (… |
| N-000136 | requirement | implemented | stem.py |  | A WordNet lemmatizer also lives in this family |
| N-000137 | requirement | tested | test_spec_traceability.py, test_stem_tag_chunk.py |  | it requires the WordNet resource |
| N-000138 | requirement | partial | stem.py | Porter, Lancaster, Snowball (english, porter only) and regular-expression stemmers are implemented; the other Snowball languages raise NotImplementedError. | The stemmer families specified here are Porter in its default mode, Lancaster, S… |
| N-000139 | constraint | partial | stem.py, test_spec_surface.py | ARLSTem/ARLSTem2 are approximate light stemmers; ISRI, Cistem, RSLP not built. Results are outside the specification. | their stemming results are outside this specification. |
| N-000140 | requirement | tested | test_spec_traceability.py, test_stem_tag_chunk.py |  | RSLP and the WordNet lemmatizer require packaged data |
| N-000141 | requirement | tested | test_spec_surface.py, test_spec_traceability.py |  | the specified families do not require WordNet |
| N-000142 | requirement | tested | stem.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | The Snowball language names are exactly: arabic, danish, dutch, english, finnish… |
| N-000143 | requirement | implemented | stem.py |  | Enabling Snowball stopword skipping requires the packaged stopwords list for tha… |
| N-000144 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The Porter stemmer has exactly three modes: the original published algorithm, th… |
| N-000145 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The default mode is the LINGORA extensions. |
| N-000146 | constraint | partial | stem.py | Porter modes ORIGINAL_ALGORITHM and MARTIN_EXTENSIONS exist; their results are outside the specification. | their results are outside this specification. |
| N-000147 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | Every stemmer treats its whole input string as one token. … A string containing … |
| N-000148 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The stemmer implements M. F. Porter's algorithm (“An algorithm for suffix stripp… |
| N-000149 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The word is lowercased first, unless the caller turns lowercasing off. |
| N-000150 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The lowercased word is first looked up in a small built-in table of irregular fo… |
| N-000151 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | A word of one or two characters is returned as it stands after the lowercasing s… |
| N-000152 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | It is never stemmed and never refused. |
| N-000153 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | In Step 1a, a four-letter word ending in *-ies* becomes *-ie* rather than *-i*. |
| N-000154 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | At the start of Step 1b, a word ending in *-ied* becomes *-ie* if it has four le… |
| N-000155 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | In that case the rest of Step 1b is skipped. |
| N-000156 | requirement | tested | stem.py, test_spec_surface.py |  | The *\*o* condition (the stem ends consonant–vowel–consonant and the final conso… |
| N-000157 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | In Step 1c, a final *y* becomes *i* only when it follows a consonant that is not… |
| N-000158 | requirement | tested | stem.py, test_spec_surface.py |  | -alli* → *-al* is tried first, when the remaining stem has positive measure. |
| N-000159 | requirement | tested | test_spec_surface.py |  | If it applies, the result goes through Step 2 again. |
| N-000160 | requirement | tested | test_spec_surface.py |  | -bli* → *-ble* replaces the original *-abli* → *-able*. |
| N-000161 | requirement | tested | test_spec_surface.py |  | The rules *-fulli* → *-ful* and *-logi* → *-log* are added. |
| N-000162 | requirement | tested | test_spec_surface.py |  | The *-logi* rule applies when the part of the word before *-ogi* has positive me… |
| N-000163 | requirement | tested | test_stem_tag_chunk.py |  | Every other step and condition is the published algorithm's. |
| N-000164 | requirement | tested | test_spec_surface.py, test_stem_tag_chunk.py |  | Every word is stemmed without refusal, including a word whose stem reduces to a … |
| N-000165 | requirement | tested | stem.py, test_spec_surface.py, test_stem_tag_chunk.py |  | The stemmer implements the Paice/Husk algorithm (C. D. Paice, “Another Stemmer”,… |
| N-000166 | requirement | tested | stem.py, test_spec_surface.py, test_stem_tag_chunk.py |  | The word is lowercased first, and no prefix is stripped. |
| N-000167 | requirement | partial | test_stem_tag_chunk.py | Snowball algorithm implemented for english (Porter2) only; porter is an approximation (see N-000170). Other languages raise NotImplementedError. | The stemmer for a language implements the Snowball stemming algorithm for that l… |
| N-000168 | requirement | not done | test_spec_traceability.py | Snowball Dutch algorithm is not implemented in this build; the Dutch stemmer raises NotImplementedError. | For Dutch, this is the original Dutch algorithm, which later Snowball releases k… |
| N-000169 | requirement | tested | stem.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | The language named *english* is the Porter2 (English) algorithm. |
| N-000170 | requirement | partial | stem.py, test_spec_traceability.py | Approximation: the porter language uses PorterStemmer in ORIGINAL_ALGORITHM mode, not Snowball's own porter rendering. | The language named *porter* is Snowball's rendering of the original Porter algor… |
| N-000171 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | The word is lowercased first. |
| N-000172 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | With stopword skipping on (off by default), a lowercased word that appears in th… |
| N-000173 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | It removes every match of the caller's pattern from the word and changes nothing… |
| N-000174 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | no suffix rewriting is applied |
| N-000175 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | A word the pattern does not match is returned unchanged. |
| N-000176 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | Asking Snowball for a language that is not in the list above does not produce a … |
| N-000177 | requirement | tested | stem.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | The failure names the requested language. |
| N-000178 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | When Snowball stopword skipping is requested and the packaged stopwords list for… |
| N-000179 | requirement | tested | stem.py, test_stem_tag_chunk.py |  | A list installed only for another language does not satisfy it. |
| N-000180 | requirement | tested | stem.py, test_spec_surface.py, test_stem_tag_chunk.py |  | The WordNet lemmatizer does not succeed when WordNet is not installed. |
| N-000181 | requirement | tested | stem.py, test_spec_surface.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | Porter, Lancaster and Snowball do not require WordNet. |
| N-000182 | requirement | tested | tag.py, test_spec_surface.py |  | The sequential taggers a caller can train without a downloaded model are exactly… |
| N-000183 | requirement | tested | tag.py, test_spec_surface.py |  | Any of these may name another sequential tagger as backoff. |
| N-000184 | requirement | tested | tag.py, test_spec_surface.py |  | Bigram, trigram, and affix taggers exist and follow the same train-then-tag prot… |
| N-000185 | requirement | tested | test_spec_surface.py |  | LINGORA’s **recommended** tagger for English and for Russian is a separately pac… |
| N-000186 | requirement | tested | test_spec_surface.py |  | The recommended English tagger uses the Penn Treebank tagset |
| N-000187 | requirement | tested | test_spec_surface.py |  | the recommended Russian tagger uses the Russian National Corpus tagset |
| N-000188 | requirement | tested | test_spec_surface.py |  | The caller may ask the recommended tagger to map tags into the **universal** tag… |
| N-000189 | requirement | tested | test_spec_surface.py |  | Mapping English tags into that tagset also requires the packaged universal tagse… |
| N-000190 | requirement | tested | test_spec_surface.py |  | mapping Russian tags does not |
| N-000191 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | A tagger returns one tagged token per input token, in input order, each pairing … |
| N-000192 | requirement | tested | test_stem_tag_chunk.py |  | Tagging an empty token list yields an empty list. |
| N-000193 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | It assigns its one configured tag to every token. |
| N-000194 | requirement | tested | tag.py, test_spec_surface.py, test_stem_tag_chunk.py |  | Each word seen in training receives the tag it was seen with most often in train… |
| N-000195 | decision | tested | tag.py, test_stem_tag_chunk.py |  | Ties are broken in the implementer's choice of way. |
| N-000196 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | A word never seen in training receives no tag. |
| N-000197 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | Rules are tried in the caller's order. |
| N-000198 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | A token receives the tag of the first rule whose pattern matches the token start… |
| N-000199 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | A token no rule matches receives no tag. |
| N-000200 | requirement | tested | tag.py, test_spec_surface.py, test_stem_tag_chunk.py |  | A backoff tagger is consulted only for tokens the primary tagger leaves without … |
| N-000201 | requirement | tested | tag.py, test_spec_surface.py, test_stem_tag_chunk.py |  | Tokens the primary tagger tagged keep their tags. |
| N-000202 | requirement | partial | test_spec_surface.py, test_stem_tag_chunk.py | Recommended English tagger implemented from the published feature templates as reconstructed here; verified only against a synthetic model (no packaged model available). | It is the greedy averaged perceptron part-of-speech tagger published as *textblo… |
| N-000203 | requirement | partial | tag.py, test_spec_surface.py | As N-000202: feature templates reconstructed; verified only against a synthetic model. | with that tagger's feature templates, word normalisation and sentence-boundary c… |
| N-000204 | requirement | partial | tag.py, test_spec_surface.py | As N-000202: feature templates reconstructed; verified only against a synthetic model. | It reads its weights, tag dictionary and classes from the packaged English resou… |
| N-000205 | requirement | partial | test_stem_tag_chunk.py | As N-000202: verified only against a synthetic model. | returns the Penn Treebank tags that the packaged model assigns |
| N-000206 | requirement | partial | test_stem_tag_chunk.py | As N-000202: verified only against a synthetic model. | The whole token list is tagged as one sentence, from left to right |
| N-000207 | requirement | partial | test_spec_surface.py | As N-000202: verified only against a synthetic model. | the tags already assigned to earlier tokens are context for later ones |
| N-000208 | requirement | partial | test_stem_tag_chunk.py | Russian tagger: same algorithm, verified only against a synthetic model. | It is the same algorithm reading the packaged Russian resource |
| N-000209 | requirement | partial | test_stem_tag_chunk.py | Russian tagger: same algorithm, verified only against a synthetic model. | returns the model's Russian National Corpus tags |
| N-000210 | requirement | tested | tag.py, test_spec_surface.py, test_stem_tag_chunk.py |  | English tags are mapped with the packaged English Penn Treebank → universal tabl… |
| N-000211 | requirement | tested | tag.py, test_spec_surface.py |  | Russian tags are mapped by the part before any = |
| N-000212 | requirement | tested | test_spec_surface.py |  | each Russian National Corpus part-of-speech category is mapped to the universal … |
| N-000213 | decision | implemented | tag.py |  | The exact table is the implementer's choice. |
| N-000214 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | The recommended tagger accepts a **list of tokens**, not a raw string. |
| N-000215 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | Passing an untokenized string does not succeed |
| N-000216 | requirement | tested | tag.py, test_spec_surface.py, test_stem_tag_chunk.py |  | the failure is distinguishable from a successful tagging |
| N-000217 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | The recommended tagger supports only English and Russian. |
| N-000218 | requirement | tested | tag.py, test_stem_tag_chunk.py |  | Asking it to tag with any other language does not succeed. |
| N-000219 | requirement | tested | test_stem_tag_chunk.py |  | When the averaged perceptron tagger resource for the requested language is not i… |
| N-000220 | requirement | tested | test_stem_tag_chunk.py |  | The resource of the other language does not satisfy it. |
| N-000221 | requirement | tested | test_stem_tag_chunk.py |  | When the caller asks the recommended English tagger for the universal tagset and… |
| N-000222 | requirement | tested | test_stem_tag_chunk.py |  | Russian mapping does not need those tables. |
| N-000223 | requirement | tested | test_stem_tag_chunk.py |  | The root label of the resulting chunk structure defaults to a sentence label |
| N-000224 | requirement | tested | test_stem_tag_chunk.py |  | that is the same for every parser and differs from clause labels |
| N-000225 | constraint | tested | test_spec_surface.py |  | It requires its trained model and tagged input. |
| N-000226 | requirement | tested | chunk.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | A tag pattern is matched against the sequence of tags of the tokens. |
| N-000227 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | Each angle-bracketed element matches one token whose whole tag matches the eleme… |
| N-000228 | requirement | implemented | chunk.py |  | Quantifiers after an element (?, *, +, and a brace count such as at least … |
| N-000229 | requirement | implemented | chunk.py |  | Whitespace in a pattern is ignored. |
| N-000230 | requirement | tested | chunk.py, test_spec_traceability.py, test_stem_tag_chunk.py |  | Every match of the pattern among tokens not yet in a chunk becomes one chunk car… |
| N-000231 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | Matches are found left to right, each as long as possible, without overlap. |
| N-000232 | requirement | implemented | chunk.py |  | Two matches that touch are two separate chunks. |
| N-000233 | requirement | implemented | chunk.py |  | Tokens no rule chunks stay direct children of the root. |
| N-000234 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | It removes the matching tokens from the chunks built earlier in the same clause. |
| N-000235 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | A chunk whose interior is removed is split into the parts on either side |
| N-000236 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | chinked tokens become direct children of the root |
| N-000237 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | The rules of a clause apply in their written order. |
| N-000238 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | Clauses apply in their written order. |
| N-000239 | requirement | tested | test_stem_tag_chunk.py |  | A later clause sees every chunk built by an earlier clause as a single unit whos… |
| N-000240 | requirement | tested | test_stem_tag_chunk.py |  | it can chunk the remaining tokens but cannot chink inside an earlier clause's ch… |
| N-000241 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | The chunk structure's leaves, in order, are exactly the input tagged tokens. |
| N-000242 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | Chunking groups tokens; it never drops, reorders, or retags them. |
| N-000243 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | An empty tagged-token list yields a chunk structure with a sentence root and no … |
| N-000244 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | is refused |
| N-000245 | constraint | tested | chunk.py, test_stem_tag_chunk.py |  | A chunk grammar that is not text and not a list of chunk-parser stages |
| N-000246 | requirement | tested | chunk.py, test_stem_tag_chunk.py |  | The operation does not succeed and does not return a chunk structure. |
| N-000247 | requirement | tested | chunk.py, test_spec_surface.py, test_stem_tag_chunk.py |  | When the named-entity chunker resource is not installed, the named-entity path d… |
| N-000248 | requirement | tested | test_spec_surface.py |  | the chart parser, which is exhaustive |
| N-000249 | constraint | tested | test_spec_surface.py |  | This feature point depends on tokens (FP-01) only as a list of terminals the cal… |
| N-000250 | constraint | tested | test_spec_surface.py |  | It does not require Punkt, a tagger, or a corpus. |
| N-000251 | requirement | tested | grammar.py, test_grammar_trees_classify_metrics.py |  | Each alternative separated by / is a production of its own |
| N-000252 | requirement | tested | test_grammar_trees_classify_metrics.py |  | Production lines appended to a grammar text add their productions |
| N-000253 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | It returns every parse tree the grammar assigns to the token list |
| N-000254 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | none for a token list the grammar does not derive |
| N-000255 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | several for an ambiguous one |
| N-000256 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | Each tree's root is the start symbol |
| N-000257 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | its leaves in order are the input tokens |
| N-000258 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | it has one internal node per production used |
| N-000259 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | It parses by a single left-to-right shift-reduce pass without backtracking |
| N-000260 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | whenever the top of the stack matches the right-hand side of a production, it re… |
| N-000261 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | It returns the parse that pass completes, or none |
| N-000262 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | On an unambiguous sentence that the pass completes, the tree is the same as the … |
| N-000263 | requirement | tested | generate.py, test_grammar_trees_classify_metrics.py |  | It enumerates the sentences the grammar derives from the start symbol, each as a… |
| N-000264 | requirement | implemented | generate.py |  | expanding productions in their written order |
| N-000265 | requirement | tested | generate.py, test_grammar_trees_classify_metrics.py |  | up to an optional count and an optional depth bound |
| N-000266 | requirement | tested | generate.py, test_grammar_trees_classify_metrics.py |  | A quoted empty string contributes an empty-string token |
| N-000267 | requirement | tested | generate.py, test_grammar_trees_classify_metrics.py |  | An empty production contributes no token |
| N-000268 | requirement | implemented | tree.py |  | A tree has a label and an ordered list of immediate children |
| N-000269 | requirement | implemented | tree.py |  | Its length is the number of immediate children |
| N-000270 | requirement | implemented | tree.py |  | its children can be read by position |
| N-000271 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | Two trees are equal exactly when their labels are equal and their children are e… |
| N-000272 | requirement | tested | tree.py, test_grammar_trees_classify_metrics.py |  | A tree read from bracketed tree text equals the tree built from the same labels … |
| N-000273 | requirement | implemented | tree.py |  | The pretty-printed form shows every label and leaf in left-to-right (pre-order) … |
| N-000274 | requirement | implemented | tree.py |  | Building a tree from a label and a **string** as the child list (instead of a li… |
| N-000275 | requirement | implemented | tree.py |  | Building a tree from a label with no child list is refused |
| N-000276 | requirement | implemented | tree.py |  | A tree with an empty child list is a valid tree with no children |
| N-000277 | requirement | implemented | tree.py |  | distinguishable from both refusals |
| N-000278 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | A parser given a token list that contains a token no production of the grammar p… |
| N-000279 | requirement | tested | __init__.py, test_grammar_trees_classify_metrics.py |  | That failure is distinguishable from a successful empty set of parses |
| N-000280 | requirement | tested | test_grammar_trees_classify_metrics.py |  | which is the outcome for a list of covered tokens that the grammar does not deri… |
| N-000281 | requirement | implemented | classify.py |  | LINGORA’s Naive Bayes classifier and decision tree classifier |
| N-000282 | requirement | implemented | classify.py |  | The caller supplies a training list of labeled featuresets |
| N-000283 | requirement | implemented | classify.py |  | After training, the caller asks for a label |
| N-000284 | requirement | implemented | classify.py |  | (for Naive Bayes) for a probability distribution over labels |
| N-000285 | requirement | implemented | classify.py |  | An accuracy helper compares a classifier’s labels on a test list to the gold lab… |
| N-000286 | constraint | implemented | classify.py |  | This feature point does not require a downloaded corpus |
| N-000287 | requirement | implemented | classify.py |  | The caller builds featuresets in memory, with any feature names and labels |
| N-000288 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | Training estimates label prior probabilities and, per label, the probability of … |
| N-000289 | requirement | implemented | classify.py |  | The estimates are smoothed so that no feature value seen with some label gets pr… |
| N-000290 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | Classifying uses only the features of the queried featureset that occurred in tr… |
| N-000291 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | A feature name never seen in training is ignored. |
| N-000292 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | The returned label is the label with the highest posterior probability. |
| N-000293 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | The probability distribution assigns each trained label its posterior probabilit… |
| N-000294 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | The probabilities are real numbers summing to one. |
| N-000295 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | The classifier lists exactly the labels seen in training. |
| N-000296 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | It learns tests on feature values from the labeled featuresets |
| N-000297 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | a feature absent from a featureset counts as having no value |
| N-000298 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | It chooses at each node the feature whose test classifies the training examples … |
| N-000299 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | A leaf returns the majority training label of the examples that reach it. |
| N-000300 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | When a single feature's values separate the training labels, each training featu… |
| N-000301 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | A featureset that shares no feature with the training data still receives one of… |
| N-000302 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | It is never refused |
| N-000303 | requirement | tested | classify.py, test_grammar_trees_classify_metrics.py |  | it never receives a label that did not occur in training |
| N-000304 | requirement | tested | test_grammar_trees_classify_metrics.py |  | Two-list accuracy (FP-07) on lists of different lengths does not succeed. |
| N-000305 | requirement | implemented | metrics.py |  | LINGORA’s scoring entries for **Levenshtein edit distance** (with an optional tr… |
| N-000306 | requirement | implemented | metrics.py |  | These metrics are pure functions of the arguments the caller supplies. |
| N-000307 | requirement | implemented | metrics.py |  | They do not require a downloaded corpus or a trained model. |
| N-000308 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | Insertion and deletion of one character cost 1 each. |
| N-000309 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | Substitution of one character by a different one costs the caller's substitution… |
| N-000310 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | which defaults to 1 |
| N-000311 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | With transpositions on (off by default), the distance is the unrestricted Damera… |
| N-000312 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | A transposition of two adjacent characters costs 1 |
| N-000313 | requirement | implemented | metrics.py |  | characters may also be inserted between, or deleted from between, the two transp… |
| N-000314 | requirement | tested | test_grammar_trees_classify_metrics.py |  | The distance of a string to itself is 0 |
| N-000315 | requirement | tested | test_grammar_trees_classify_metrics.py |  | the distance is symmetric |
| N-000316 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | The f-measure is the weighted harmonic mean 1 / (α / precision + (1 − α) / recal… |
| N-000317 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | It is 0 when precision or recall is 0. |
| N-000318 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | Each n-gram order has a modified precision |
| N-000319 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | candidate n-gram counts are clipped by the maximum count of that n-gram in any o… |
| N-000320 | requirement | tested | test_grammar_trees_classify_metrics.py |  | The precisions are combined as a geometric mean weighted by the caller's weights… |
| N-000321 | requirement | tested | test_grammar_trees_classify_metrics.py |  | The default is equal weights on unigrams through 4-grams. |
| N-000322 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | The result is multiplied by the brevity penalty, computed from the reference len… |
| N-000323 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | Tokens are compared exactly as given. |
| N-000324 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | Without a smoothing function, the score is 0 when the candidate has no unigram m… |
| N-000325 | requirement | tested | translate.py, test_grammar_trees_classify_metrics.py |  | When any other weighted order has no match, the score is 0 or negligibly close t… |
| N-000326 | requirement | implemented | metrics.py |  | Accuracy on two lists of different lengths does not succeed. |
| N-000327 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | Precision and recall require sets. … Lists, tuples and other non-set collections… |
| N-000328 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | Precision with an empty test set, recall with an empty reference set, and f-meas… |
| N-000329 | requirement | tested | metrics.py, test_grammar_trees_classify_metrics.py |  | That absence is distinguishable from the number 0. |
| N-000330 | requirement | tested | test_grammar_trees_classify_metrics.py |  | Edit distance of two empty strings is 0. |
| N-000331 | constraint | not done | test_spec_traceability.py | Packaged corpora, WordNet, downloader and graphical surfaces are outside this specification; not built. | Packaged corpora, WordNet, the data finder, and the downloader (including the do… |
| N-000332 | constraint | not done | test_spec_traceability.py | Graphical applications and tree/table drawing are outside this specification; not built. | Graphical applications and tree/table drawing. |
| N-000333 | constraint | not done | test_spec_traceability.py | Chat, Twitter, Hugging Face and Toolbox helpers are outside this specification; not built. | Chat, Twitter, Hugging Face, and Toolbox helpers. |
| N-000334 | constraint | not done | test_spec_traceability.py | External-binary wrappers are outside this specification; not built. | External-binary wrappers (Stanford, Senna, Hunpos, Malt, Bllip, CoreNLP, Weka, M… |
