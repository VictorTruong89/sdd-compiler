"""Checks for checklist ids not covered by the other test modules, and absence checks for out-of-scope surfaces."""

import importlib.util
import io

import pytest

from lingora import data
from lingora.chunk import RegexpParser
from lingora.stem import PorterStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger
from lingora.tokenize import TweetTokenizer, TreebankWordTokenizer, WordPunctTokenizer, word_tokenize, wordpunct_tokenize
from lingora.tree import Tree


def test_N_000018_N_000331_N_000332_N_000333_N_000334_outside_surfaces_are_not_implemented():
    # spec: N-000018 N-000331 N-000332 N-000333 N-000334 N-000071 N-000070 N-000072 N-000073 N-000074
    for module in ("lingora.downloader", "lingora.corpus", "lingora.draw", "lingora.chat", "lingora.wrappers"):
        assert importlib.util.find_spec(module) is None, module


def test_N_000019_N_000020_packaged_model_prerequisite_is_stated_and_fails_without_model():
    # spec: N-000019 N-000020 N-000060 N-000026 N-000031 N-000036
    with pytest.raises(LookupError):
        word_tokenize("A sentence. Another one.")


def test_N_000021_span_slices_recover_tokens():
    # spec: N-000021 N-000122
    text = "Hello,  world!"
    for start, end in WordPunctTokenizer().span_tokenize(text):
        assert text[start:end] in wordpunct_tokenize(text)


def test_N_000022_stems_need_not_be_dictionary_words():
    # spec: N-000022
    assert PorterStemmer().stem("generously") == "gener"


def test_N_000024_chunk_rule_pattern_and_cascade_with_braces():
    # spec: N-000024 N-000226 N-000230
    tagged = [("the", "DT"), ("cat", "NN")]
    assert RegexpParser("NP: {<DT><NN>}").parse(tagged) == Tree("S", [Tree("NP", tagged)])


def test_N_000028_tokenizer_entries_exist():
    # spec: N-000028 N-000078 N-000086
    from lingora import tokenize as tk

    for name in ("WordPunctTokenizer", "TreebankWordTokenizer", "WhitespaceTokenizer", "RegexpTokenizer", "TweetTokenizer"):
        assert hasattr(tk, name)
    assert hasattr(tk, "blankline_tokenize") and hasattr(tk, "sent_tokenize") and hasattr(tk, "word_tokenize")


def test_N_000029_N_000079_s_expression_tokenizer_is_outside_this_specification():
    # spec: N-000029 N-000079
    from lingora import tokenize as tk

    assert not hasattr(tk, "SExprTokenizer")


def test_N_000030_N_000031_N_000081_N_000084_cli_uses_recommended_tokenizer_and_space_delimiter(punkt_root, monkeypatch, capsys):
    # spec: N-000030 N-000031 N-000081 N-000084 N-000003 N-000004
    from lingora.cli import cli

    monkeypatch.setattr("sys.stdin", io.StringIO("Dr. Smith went home. Yes.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "Dr. Smith went home . Yes .\n"


def test_N_000032_N_000044_feature_families_are_exposed_and_work():
    # spec: N-000032 N-000033 N-000034 N-000035 N-000036 N-000037 N-000038 N-000039 N-000040 N-000041 N-000042 N-000043 N-000044
    from lingora.classify import NaiveBayesClassifier
    from lingora.grammar import CFG
    from lingora.metrics import edit_distance
    from lingora.parse import ChartParser
    from lingora.translate import bleu

    assert PorterStemmer().stem("cats") == "cat"
    assert DefaultTagger("NN").tag(["x"]) == [("x", "NN")]
    assert RegexpTagger([("x", "NN")]).tag(["x"]) == [("x", "NN")]
    assert UnigramTagger([]).tag(["x"]) == [("x", None)]
    assert list(ChartParser(CFG.fromstring("S -> 'x'")).parse(["x"]))
    assert Tree.fromstring("(S x)").leaves() == ["x"]
    assert NaiveBayesClassifier.train([({"f": 1}, "A")]).prob_classify({"f": 1}).prob("A") == pytest.approx(1.0)
    assert edit_distance("a", "a") == 0
    # with the default 4-gram weights a one-token candidate has no bigrams, so the unsmoothed score is 0
    assert bleu([["a"]], ["a"]) == 0.0
    assert bleu([["a"]], ["a"], weights=(1.0,)) == pytest.approx(1.0)


def test_N_000064_accented_letters_stay_whole_in_tweets():
    # spec: N-000064 N-000115
    assert TweetTokenizer().tokenize("déjà vu") == ["déjà", "vu"]


def test_N_000065_library_is_used_in_process():
    # spec: N-000065 N-000067 N-000068
    import lingora

    assert lingora.__name__ == "lingora"


def test_N_000093_N_000094_N_000095_N_000097_punctuation_rules():
    # spec: N-000093 N-000094 N-000095 N-000097
    tok = TreebankWordTokenizer()
    assert '"' not in tok.tokenize('He said "hi" to me')
    for mark in ";@#$%&?!":
        assert mark in tok.tokenize("a%sb" % mark) or mark in tok.tokenize("a %s b" % mark)
    assert tok.tokenize("(x)") == ["(", "x", ")"]
    assert tok.tokenize("wait...") == ["wait", "..."]
    assert tok.tokenize("U.S. policy") == ["U.S.", "policy"]
    assert tok.tokenize("end.") == ["end", "."]


def test_N_000168_dutch_snowball_is_not_implemented():
    # spec: N-000168 N-000142 N-000177
    with pytest.raises(NotImplementedError):
        SnowballStemmer("dutch")


def test_N_000170_porter_snowball_rendering_is_available():
    # spec: N-000170 N-000169
    assert SnowballStemmer("porter").stem("generously") in {"gener", "generous"}


def test_N_000137_wordnet_lemmatizer_requires_resource_and_others_do_not(tmp_path, monkeypatch):
    # spec: N-000137 N-000140 N-000141 N-000181
    from lingora.stem import LancasterStemmer, WordNetLemmatizer

    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        WordNetLemmatizer()
    assert LancasterStemmer().stem("running") == "run"
    assert SnowballStemmer("english").stem("running") == "run"
