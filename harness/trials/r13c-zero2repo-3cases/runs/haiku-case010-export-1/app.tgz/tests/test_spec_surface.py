"""Build, surface, and non-functional checks; plus remaining rules of FP-02, FP-03, FP-04: spec ids N-000335 … N-000494."""

import ast
import os
import subprocess
import sys
import tomllib

import pytest

from lingora import data

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PACKAGE = os.path.join(REPO, "lingora")


def _package_sources():
    for root, _dirs, files in os.walk(PACKAGE):
        for name in files:
            if name.endswith(".py"):
                yield os.path.join(root, name)


def _imported_top_level_names():
    names = set()
    for path in _package_sources():
        with open(path, encoding="utf-8") as handle:
            tree = ast.parse(handle.read(), path)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names.add(node.module.split(".")[0])
    return names


def _pyproject():
    with open(os.path.join(REPO, "pyproject.toml"), "rb") as handle:
        return tomllib.load(handle)


# --- build and packaging --------------------------------------------------------------------------------------


def test_N_000336_N_000346_N_000356_python_floor_is_3_10():
    # spec: N-000336 N-000346 N-000356 N-000049 N-000051
    assert _pyproject()["project"]["requires-python"] == ">=3.10"
    assert sys.version_info >= (3, 10)


def test_N_000347_N_000050_runtime_dependencies_are_none_or_pure_python():
    # spec: N-000347 N-000050 N-000052
    assert _pyproject()["project"]["dependencies"] == []


def test_N_000349_N_000357_only_standard_library_and_no_network_modules():
    # spec: N-000349 N-000357 N-000067 N-000072 N-000073 N-000074 N-000075 N-000076 N-000069 N-000070
    imported = _imported_top_level_names()
    stdlib = set(sys.stdlib_module_names)
    assert imported - stdlib - {"lingora"} == set()
    forbidden = {"socket", "http", "urllib", "subprocess", "tkinter", "ftplib", "requests"}
    assert imported & forbidden == set()


def test_N_000350_N_000351_N_000354_N_000355_flat_pure_python_layout():
    # spec: N-000350 N-000351 N-000354 N-000355 N-000335 N-000046 N-000047
    assert _pyproject()["project"]["name"] == "lingora"
    assert "ext-modules" not in _pyproject().get("tool", {}).get("setuptools", {})
    assert os.path.isfile(os.path.join(PACKAGE, "__init__.py"))
    assert not os.path.exists(os.path.join(REPO, "src"))
    assert not any(name.endswith((".so", ".pyd", ".c")) for _r, _d, files in os.walk(PACKAGE) for name in files)


def test_N_000339_N_000340_N_000344_N_000345_N_000348_N_000352_N_000056_cpu_baseline_from_source_tree(tmp_path):
    # spec: N-000339 N-000340 N-000344 N-000345 N-000348 N-000352 N-000056 N-000059 N-000048
    code = (
        "import socket, sys\n"
        "def _blocked(*args, **kwargs):\n"
        "    raise RuntimeError('network disabled')\n"
        "socket.socket = _blocked\n"
        "sys.path.insert(0, %r)\n"
        "from lingora.tokenize import wordpunct_tokenize\n"
        "print(wordpunct_tokenize('Hello, world.'))\n"
    ) % REPO
    env = dict(os.environ)
    env.pop("LINGORA_DATA", None)
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd=str(tmp_path), env=env)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "['Hello', ',', 'world', '.']"


def test_N_000359_importing_downloads_nothing(tmp_path):
    # spec: N-000359 N-000361
    code = (
        "import socket, sys\n"
        "def _blocked(*args, **kwargs):\n"
        "    raise RuntimeError('network disabled')\n"
        "socket.socket = _blocked\n"
        "sys.path.insert(0, %r)\n"
        "import lingora, lingora.tokenize, lingora.stem, lingora.tag, lingora.chunk, lingora.parse, lingora.cli\n"
        "print('ok')\n"
    ) % REPO
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd=str(tmp_path))
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "ok"


def test_N_000353_N_000360_N_000367_public_entries_are_callable():
    # spec: N-000353 N-000360 N-000468 N-000471
    from lingora import tokenize, stem, tag, chunk, grammar, tree, classify, metrics, translate, cli

    for module, names in (
        (tokenize, ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize", "sent_tokenize", "word_tokenize", "wordpunct_tokenize"]),
        (stem, ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer", "SnowballStemmer", "WordNetLemmatizer"]),
        (tag, ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]),
        (chunk, ["RegexpParser", "ne_chunk"]),
        (grammar, ["CFG"]),
        (tree, ["Tree"]),
        (classify, ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy"]),
        (metrics, ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]),
        (translate, ["bleu"]),
    ):
        for name in names:
            assert callable(getattr(module, name)), name
    assert callable(cli.cli.main)


def test_N_000426_N_000427_N_000442_N_000443_N_000461_N_000462_N_000472_N_000473_N_000478_N_000479_N_000480_import_paths():
    # spec: N-000426 N-000427 N-000441 N-000442 N-000443 N-000461 N-000462 N-000472 N-000473 N-000478 N-000479 N-000480
    from lingora.chunk import RegexpParser, ne_chunk
    from lingora.classify import NaiveBayesClassifier, DecisionTreeClassifier, accuracy
    from lingora.grammar import CFG
    from lingora.metrics import accuracy as _a, edit_distance, jaccard_distance, precision, recall, f_measure
    from lingora.parse import ChartParser, ShiftReduceParser
    from lingora.parse.generate import generate
    from lingora.stem import ARLSTem, ARLSTem2, LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer, WordNetLemmatizer
    from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
    from lingora.translate import bleu
    from lingora.tree import Tree
    from lingora import chunk, classify, metrics, tag, tree, tokenize, stem  # noqa: F401

    assert all([RegexpParser, ne_chunk, CFG, ChartParser, ShiftReduceParser, generate, Tree])


def test_N_000366_keyword_calls_work():
    # spec: N-000366 N-000365 N-000364
    from lingora.tokenize import RegexpTokenizer, word_tokenize, TweetTokenizer
    from lingora.metrics import edit_distance

    assert RegexpTokenizer(pattern=r"\d+", gaps=False).tokenize("a1b22") == ["1", "22"]
    assert edit_distance(s1="ab", s2="ac", substitution_cost=2) == 2
    assert TweetTokenizer(preserve_case=False).tokenize("LOL") == ["lol"]
    assert word_tokenize("Hi there.", preserve_line=True) == ["Hi", "there", "."]


def test_N_000360_N_000363_failures_are_exceptions_not_empty_results():
    # spec: N-000362 N-000363 N-000133 N-000216
    from lingora.stem import WordNetLemmatizer
    from lingora.tag import pos_tag

    with pytest.raises(TypeError):
        pos_tag("a str, not a list")
    with pytest.raises(LookupError):
        WordNetLemmatizer()


def test_N_000368_N_000369_N_000370_data_path_is_replaceable_in_place(tmp_path, monkeypatch):
    # spec: N-000368 N-000369 N-000370 N-000371
    from lingora.tokenize import sent_tokenize

    assert isinstance(data.path, list)
    data.path[:] = [str(tmp_path)]
    with pytest.raises(LookupError):
        sent_tokenize("Hi.")
    data.path[:] = []
    with pytest.raises(LookupError):
        sent_tokenize("Hi.")


def test_N_000372_N_000373_N_000374_N_000375_N_000376_N_000377_N_000378_N_000379_resource_names(tmp_path, monkeypatch):
    # spec: N-000372 N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379 N-000380 N-000381
    from lingora.chunk import ne_chunk
    from lingora.stem import SnowballStemmer, WordNetLemmatizer
    from lingora.tag import pos_tag

    # the resource names are looked up relative to data.path; a file placed under each name is found.
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    assert data.find("tokenizers/punkt_tab/english") is None
    (tmp_path / "taggers" / "averaged_perceptron_tagger_eng").mkdir(parents=True)
    assert data.find("taggers/averaged_perceptron_tagger_eng") == str(tmp_path / "taggers" / "averaged_perceptron_tagger_eng")
    (tmp_path / "chunkers" / "maxent_ne_chunker_tab" / "english_ace_multiclass").mkdir(parents=True)
    (tmp_path / "corpora").mkdir()
    (tmp_path / "corpora" / "words").write_text("cat\n", encoding="utf-8")
    # the NE model and wordlist are present now, so ne_chunk gets past the resource check
    with pytest.raises(NotImplementedError):
        ne_chunk([("cat", "NN")])
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)
    with pytest.raises(LookupError):
        WordNetLemmatizer()
    with pytest.raises(LookupError):
        pos_tag(["cat"], lang="rus")


def test_N_000382_N_000383_N_000384_punkt_and_tagger_file_layouts(punkt_root, tagger_root):
    # spec: N-000382 N-000383 N-000384 N-000385 N-000372 N-000373 N-000375
    from lingora.punkt import load_parameters
    from lingora.tag import pos_tag

    params = load_parameters("english")
    assert "dr" in params.abbrev_types
    assert "the" in params.sent_starters
    assert params.ortho_context["smith"] == 4
    assert pos_tag(["the"], tagset="universal") == [("the", "DET")]


def test_N_000385_ortho_context_bits_and_absent_types():
    # spec: N-000385 N-000372
    from lingora.punkt import _LC, _MID_UC, _ortho_says_starter, _describe, _Parameters

    params = _Parameters(set(), set(), set(), {"smith": 2 | 16})
    assert _ortho_says_starter(_describe("Smith"), params) is True
    assert _ortho_says_starter(_describe("Zed"), params) is False
    assert _LC == 16 | 32 | 64 and _MID_UC == 4


def test_N_000391_N_000395_language_name_must_be_a_directory_name():
    # spec: N-000391 N-000392 N-000393
    from lingora.punkt import load_parameters

    with pytest.raises(ValueError):
        load_parameters("../etc")
    with pytest.raises(ValueError):
        load_parameters("")


def test_N_000392_N_000393_preserve_line_switches_sentence_splitting(punkt_root):
    # spec: N-000392 N-000393 N-000106
    from lingora.tokenize import word_tokenize

    # one line, no sentence splitting: only the final period is split off
    assert word_tokenize("Dr. Smith went home. Yes.", preserve_line=True) == ["Dr.", "Smith", "went", "home.", "Yes", "."]
    split = word_tokenize("Dr. Smith went home. Yes.")
    assert split == ["Dr.", "Smith", "went", "home", ".", "Yes", "."]


def test_N_000166_lancaster_no_prefix_strip_and_lowercase():
    # spec: N-000165 N-000166
    from lingora.stem import LancasterStemmer

    assert LancasterStemmer().stem("UNHAPPY") == LancasterStemmer().stem("unhappy")


def test_N_000158_N_000162_porter_nltk_extension_rules():
    # spec: N-000158 N-000159 N-000160 N-000161 N-000162 N-000164
    from lingora.stem import PorterStemmer

    stemmer = PorterStemmer()
    assert stemmer.stem("hopefulli") == "hope"  # -fulli -> -ful, then Step 3 and Step 5
    assert stemmer.stem("apologi") == "apolog"  # -logi -> -log, the part before -ogi has positive measure
    assert stemmer.stem("rationalli") == "ration"  # -alli -> -al first, then Step 2 again; Step 4 drops -al
    assert stemmer.stem("probabli") == "probabl"  # -bli -> -ble


def test_N_000156_two_letter_star_o_condition():
    # spec: N-000156
    from lingora.stem import PorterStemmer

    assert PorterStemmer()._cvc("ab") is True
    assert PorterStemmer()._cvc("aw") is False


def test_N_000139_N_000141_families_do_not_need_wordnet():
    # spec: N-000141 N-000180 N-000181 N-000139
    from lingora.stem import LancasterStemmer, PorterStemmer, SnowballStemmer

    assert PorterStemmer().stem("running") == "run"
    assert LancasterStemmer().stem("running") == "run"
    assert SnowballStemmer("english").stem("running") == "run"


def test_N_000182_N_000184_trainable_taggers_and_backoff():
    # spec: N-000182 N-000183 N-000184 N-000194 N-000200 N-000201
    from lingora.tag import AffixTagger, BigramTagger, DefaultTagger, TrigramTagger, UnigramTagger

    train = [[("the", "DT"), ("dog", "NN"), ("runs", "VBZ")], [("the", "DT"), ("cat", "NN"), ("sleeps", "VBZ")]]
    assert BigramTagger(train).tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]
    assert TrigramTagger(train, backoff=DefaultTagger("X")).tag(["the", "dog", "runs", "zz"])[-1] == ("zz", "X")
    assert AffixTagger(train, affix_length=-1, min_stem_length=1).tag(["dogs", "xs"]) == [("dogs", "VBZ"), ("xs", "VBZ")]
    primary = UnigramTagger([[("a", "DT")]])
    assert primary.tag(["a", "b"]) == [("a", "DT"), ("b", None)]


def test_N_000186_N_000187_N_000210_N_000211_russian_and_english_universal_mapping(tagger_root):
    # spec: N-000185 N-000186 N-000187 N-000188 N-000189 N-000190 N-000211 N-000212
    from lingora.tag import pos_tag

    # the Russian tag 'S' (a noun) maps to the universal NOUN by its part of speech
    assert pos_tag(["the"], lang="rus", tagset="universal") == [("the", "NOUN")]
    assert pos_tag(["the"], lang="rus")[0][1] == "S"


def test_N_000207_context_of_earlier_tags_for_later_tokens(tagger_root):
    # spec: N-000207 N-000202 N-000203 N-000204
    from lingora.tag import _perceptron_tag, _load_model

    model = _load_model("eng")
    model.weights["i-1 tag"] = {"NN": 5.0}
    tags = _perceptron_tag(model, ["the", "zebra"])
    assert tags == ["DT", "NN"]


def test_N_000225_N_000247_named_entity_chunker_needs_resources(tmp_path, monkeypatch):
    # spec: N-000225 N-000247 N-000432
    from lingora.chunk import ne_chunk

    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        ne_chunk([("Mary", "NNP")])


def test_N_000248_N_000249_N_000250_parsing_needs_no_model():
    # spec: N-000248 N-000249 N-000250
    from lingora.grammar import CFG
    from lingora.parse import ChartParser

    assert list(ChartParser(CFG.fromstring("S -> 'a'")).parse(["a"])) != []


def test_N_000402_N_000403_cli_failure_status_and_options(tmp_path, monkeypatch, capsys):
    # spec: N-000402 N-000403 N-000400 N-000401
    import io

    from lingora.cli import cli

    monkeypatch.setattr("sys.stdin", io.StringIO("x\n"))
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize", "--language", "english"], standalone_mode=True)
    assert info.value.code == 1
    assert "not installed" in capsys.readouterr().err
