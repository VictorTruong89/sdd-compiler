"""Tokenizers (FP-01): spec ids N-000078 … N-000134."""

import io

import pytest

from lingora import tokenize as tk
from lingora.cli import cli


def test_N_000086_wordpunct_splits_word_and_punctuation_runs():
    # spec: N-000086 N-000087 N-000088
    assert tk.wordpunct_tokenize("Hello, world!! 3.14 don't") == ["Hello", ",", "world", "!!", "3", ".", "14", "don", "'", "t"]


def test_N_000395_wordpunct_span_tokenize_slices_back_to_tokens():
    # spec: N-000121 N-000122 N-000123 N-000395
    text = "a, bb c"
    spans = list(tk.WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == tk.WordPunctTokenizer().tokenize(text)
    assert all(isinstance(s, int) and isinstance(e, int) for s, e in spans)
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_N_000131_empty_and_blank_strings_give_no_tokens():
    # spec: N-000131
    for tokenizer in (tk.WhitespaceTokenizer(), tk.WordPunctTokenizer(), tk.TreebankWordTokenizer(), tk.TweetTokenizer()):
        assert tokenizer.tokenize("") == []
        assert tokenizer.tokenize("   \n\t ") == []
    assert tk.wordpunct_tokenize("  ") == []
    assert tk.word_tokenize("", preserve_line=True) == []


def test_N_000089_N_000099_treebank_conventions():
    # spec: N-000089 N-000090 N-000091 N-000092 N-000096 N-000098 N-000099 N-000100
    tok = tk.TreebankWordTokenizer()
    assert tok.tokenize('"Yes," she said.') == ["``", "Yes", ",", "''", "she", "said", "."]
    assert tok.tokenize("They can't go") == ["They", "ca", "n't", "go"]
    assert tok.tokenize("gonna") == ["gon", "na"]
    assert tok.tokenize("cannot") == ["can", "not"]
    assert tok.tokenize("costs 3,000 or 2:30") == ["costs", "3,000", "or", "2:30"]
    assert tok.tokenize("a ... b") == ["a", "...", "b"]
    assert tok.tokenize("Mr. Jones") == ["Mr.", "Jones"]
    assert tok.tokenize("end of it.") == ["end", "of", "it", "."]
    assert tok.tokenize("user's car") == ["user", "'s", "car"]


def test_N_000101_N_000105_recommended_word_tokenizer_extras():
    # spec: N-000101 N-000102 N-000103 N-000104 N-000105
    line = "He said “hi” — really** ... ok--yes"
    tokens = tk.word_tokenize(line, preserve_line=True)
    assert "“" in tokens and "”" in tokens
    assert "—" in tokens and "*" in tokens
    assert "..." in tokens
    assert "--" in tokens


def test_N_000109_N_000110_blankline_tokenize_keeps_single_newlines():
    # spec: N-000109 N-000110 N-000394
    text = "first line\nstill first\n\n\n second\n   \n third"
    assert tk.blankline_tokenize(text) == ["first line\nstill first", "second", "third"]


def test_N_000108_whitespace_tokenizer():
    # spec: N-000108
    assert tk.WhitespaceTokenizer().tokenize(" a\tb\nc  d ") == ["a", "b", "c", "d"]


def test_N_000111_N_000113_regexp_token_and_gap_modes():
    # spec: N-000111 N-000112 N-000113
    assert tk.RegexpTokenizer(r"\d+").tokenize("ab12cd345") == ["12", "345"]
    assert tk.RegexpTokenizer(r"\s*,\s*", gaps=True).tokenize("a , b,,c") == ["a", "b", "c"]
    assert tk.RegexpTokenizer(r"\s*,\s*", gaps=True, discard_empty=False).tokenize("a,,b") == ["a", "", "b"]


def test_N_000114_N_000120_tweet_tokenizer():
    # spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120
    tweet = tk.TweetTokenizer()
    assert tweet.tokenize("I can't wait :) #Yay http://x.org/a @bob") == [
        "I", "can't", "wait", ":)", "#Yay", "http://x.org/a", "@bob",
    ]
    assert tk.TweetTokenizer().tokenize("naïve café") == ["naïve", "café"]
    assert tk.TweetTokenizer(strip_handles=True).tokenize("hey @bob there") == ["hey", "there"]
    assert tk.TweetTokenizer(reduce_len=True).tokenize("nooooo!!!!") == ["nooo", "!", "!", "!"]
    assert tk.TweetTokenizer(preserve_case=False).tokenize("LOUD :D") == ["loud", ":D"]
    assert tk.TweetTokenizer().tokenize("LOUD") == ["LOUD"]


def test_N_000118_handles_inside_words_are_not_stripped():
    # spec: N-000118
    assert tk.TweetTokenizer(strip_handles=True).tokenize("mail a@b.c") != []
    assert "a" in tk.TweetTokenizer(strip_handles=True).tokenize("a@b")


def test_N_000124_N_000128_sent_tokenize_requires_punkt_and_splits(punkt_root):
    # spec: N-000124 N-000125 N-000126 N-000127 N-000128
    text = "Dr. Smith went home. He was tired! Was he? Yes."
    assert tk.sent_tokenize(text) == ["Dr. Smith went home.", "He was tired!", "Was he?", "Yes."]
    assert tk.sent_tokenize("One sentence only") == ["One sentence only"]


def test_N_000132_N_000133_missing_punkt_fails_distinguishably():
    # spec: N-000132 N-000133 N-000396
    with pytest.raises(LookupError):
        tk.sent_tokenize("Hi there.")
    with pytest.raises(LookupError):
        tk.word_tokenize("Hi there.")
    with pytest.raises(LookupError):
        tk.sent_tokenize("")  # a model is needed even for an empty text


def test_N_000082_N_000083_N_000085_word_tokenize_with_punkt(punkt_root):
    # spec: N-000082 N-000083 N-000085 N-000106 N-000107 N-000080
    assert tk.word_tokenize("He can't. Yes!") == ["He", "ca", "n't", ".", "Yes", "!"]
    assert tk.word_tokenize("Dr. Smith went home.") == ["Dr.", "Smith", "went", "home", "."]


def test_N_000396_word_tokenize_preserve_line_needs_no_model():
    # spec: N-000085 N-000396
    assert tk.word_tokenize("Hello there.", preserve_line=True) == ["Hello", "there", "."]


def test_N_000134_cli_tokenize_fails_without_punkt_and_writes_no_line(monkeypatch, capsys):
    # spec: N-000134 N-000400 N-000401 N-000129 N-000130
    monkeypatch.setattr("sys.stdin", io.StringIO("Hi there.\n"))
    with pytest.raises(SystemExit) as exit_info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exit_info.value.code != 0
    assert capsys.readouterr().out == ""


def test_N_000397_N_000399_cli_tokenize_with_punkt(punkt_root, monkeypatch, capsys):
    # spec: N-000397 N-000398 N-000399 N-000129 N-000130
    monkeypatch.setattr("sys.stdin", io.StringIO("Dr. Smith went home. Yes.\n\nHe said no.\n"))
    with pytest.raises(SystemExit) as exit_info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exit_info.value.code == 0
    assert capsys.readouterr().out == "Dr. Smith went home . Yes .\n\nHe said no .\n"


def test_N_000403_cli_delimiter_option(punkt_root, monkeypatch, capsys):
    # spec: N-000403
    monkeypatch.setattr("sys.stdin", io.StringIO("Yes.\n"))
    assert cli.main(args=["tokenize", "--delimiter", "|"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "Yes|.\n"
