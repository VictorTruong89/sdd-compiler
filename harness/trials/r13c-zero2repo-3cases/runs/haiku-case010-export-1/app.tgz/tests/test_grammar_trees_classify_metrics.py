"""Grammars and parsers (FP-05), classifiers (FP-06), metrics (FP-07), and the public surface: spec ids N-000441 … N-000494."""

import pytest

from lingora import data
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.grammar import CFG
from lingora.metrics import accuracy as metric_accuracy
from lingora.metrics import edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import bleu
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'a' N
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'saw' | 'ran'
"""


# --- surface ----------------------------------------------------------------------------------------------------


def test_N_000353_N_000359_import_downloads_nothing_and_needs_no_config(monkeypatch):
    # spec: N-000353 N-000358 N-000359 N-000368 N-000370
    import lingora

    assert lingora.__name__ == "lingora"
    assert data.path == []


def test_N_000360_N_000362_callable_entries_raise_on_failure():
    # spec: N-000360 N-000361 N-000362 N-000363
    with pytest.raises(TypeError):
        CFG.fromstring(None)


def test_N_000367_scores_are_real_numbers_not_bool():
    # spec: N-000367
    assert isinstance(edit_distance("a", "b"), int)
    assert not isinstance(edit_distance("a", "a"), bool)


def test_N_000369_data_path_is_the_only_search_list(tmp_path, monkeypatch):
    # spec: N-000369 N-000372
    from lingora.punkt import load_parameters

    root = tmp_path / "x"
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        load_parameters("english")
    monkeypatch.setattr(data, "path", [str(root)])
    with pytest.raises(LookupError):
        load_parameters("english")


def test_N_000468_N_000469_tree_fromstring_and_equality():
    # spec: N-000463 N-000464 N-000465 N-000467 N-000468 N-000469 N-000470 N-000271 N-000272
    tree = Tree.fromstring("(S (NP the dog) (VP ran))")
    assert tree.label() == "S"
    assert len(tree) == 2 and tree[1] == Tree("VP", ["ran"])
    assert tree.leaves() == ["the", "dog", "ran"]
    assert tree == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["ran"])])
    assert tree != Tree("S", [])
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")
    assert Tree("S", []).leaves() == []
    text = tree.pformat()
    for word in ("S", "NP", "VP", "the", "dog", "ran"):
        assert word in text


# --- grammars and parsers -------------------------------------------------------------------------------------


def test_N_000444_N_000451_grammar_reader():
    # spec: N-000444 N-000445 N-000446 N-000447 N-000449 N-000450 N-000451 N-000251 N-000252
    grammar = CFG.fromstring(GRAMMAR)
    assert str(grammar.start()) == "S"
    assert len(grammar.productions()) == 9
    assert all(isinstance(p.rhs(), tuple) for p in grammar.productions())
    rhs = grammar.productions(lhs=grammar.start())[0].rhs()
    assert [str(x) for x in rhs] == ["NP", "VP"]
    assert not isinstance(rhs[0], str)
    terminal_rhs = grammar.productions()[1].rhs()
    assert terminal_rhs[0] == "the" and isinstance(terminal_rhs[0], str)
    with pytest.raises(ValueError):
        CFG.fromstring("this is not a production")


def test_N_000452_N_000454_chart_parser_all_trees_and_empty_result():
    # spec: N-000452 N-000453 N-000454 N-000253 N-000254 N-000255 N-000256 N-000257 N-000258
    grammar = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(grammar).parse(["the", "dog", "ran"]))
    assert trees == [Tree("S", [Tree("NP", ["the", Tree("N", ["dog"])]), Tree("VP", [Tree("V", ["ran"])])])]
    assert list(ChartParser(grammar).parse(["the", "dog", "ran", "ran"])) == []
    ambiguous = CFG.fromstring("E -> E '+' E | 'x'")
    assert len(list(ChartParser(ambiguous).parse(["x", "+", "x", "+", "x"]))) == 2


def test_N_000455_N_000456_N_000278_N_000279_unknown_token_raises():
    # spec: N-000455 N-000456 N-000278 N-000279 N-000280
    grammar = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        ChartParser(grammar).parse(["the", "zebra"])
    with pytest.raises(ValueError):
        ShiftReduceParser(grammar).parse(["zebra"])


def test_N_000259_N_000262_shift_reduce_matches_chart_on_unambiguous_input():
    # spec: N-000259 N-000260 N-000261 N-000262
    grammar = CFG.fromstring("S -> 'a' 'b' | 'c' S")
    chart = list(ChartParser(grammar).parse(["c", "a", "b"]))
    assert list(ShiftReduceParser(grammar).parse(["c", "a", "b"])) == chart
    assert list(ShiftReduceParser(grammar).parse(["a", "c"])) == []


def test_N_000263_N_000267_generate_order_count_depth_and_empty_terminals():
    # spec: N-000263 N-000265 N-000266 N-000457 N-000458 N-000459 N-000460
    grammar = CFG.fromstring(GRAMMAR)
    assert list(generate(grammar, n=2)) == [["the", "dog", "saw", "the", "dog"], ["the", "dog", "saw", "the", "cat"]]
    shallow = list(generate(grammar, depth=3))
    assert ["the", "dog", "saw"] in shallow and ["the", "dog", "saw", "a"] not in shallow
    assert list(generate(grammar, start="N", n=1)) == [["dog"]]
    empty = CFG.fromstring("S -> 'x' ''\n")
    assert list(generate(empty)) == [["x", ""]]


# --- classifiers ----------------------------------------------------------------------------------------------

TRAIN = [
    ({"w": "good", "len": "short"}, "pos"),
    ({"w": "bad", "len": "long"}, "neg"),
    ({"w": "good", "len": "long"}, "pos"),
    ({"w": "bad", "len": "short"}, "neg"),
]


def test_N_000288_N_000295_naive_bayes_labels_and_probabilities():
    # spec: N-000288 N-000290 N-000291 N-000292 N-000293 N-000294 N-000295
    nb = NaiveBayesClassifier.train(TRAIN)
    assert sorted(nb.labels()) == ["neg", "pos"]
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"w": "bad"}) == "neg"
    assert nb.classify({"never_seen": 1}) in ("pos", "neg")
    dist = nb.prob_classify({"w": "good"})
    assert isinstance(dist.prob("pos"), float)
    assert abs(sum(dist.prob(label) for label in dist.samples()) - 1.0) < 1e-9
    assert dist.prob("pos") > dist.prob("neg")


def test_N_000296_N_000303_decision_tree():
    # spec: N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303
    tree = DecisionTreeClassifier.train(TRAIN)
    for featureset, label in TRAIN:
        assert tree.classify(featureset) == label
    assert tree.classify({"other": 1}) in ("pos", "neg")
    single = DecisionTreeClassifier.train([({"f": 1}, "A"), ({"f": 2}, "B")])
    assert single.classify({"f": 1}) == "A" and single.classify({"f": 2}) == "B"


def test_N_000474_N_000475_N_000304_accuracy_helper():
    # spec: N-000474 N-000475 N-000303 N-000304
    nb = NaiveBayesClassifier.train(TRAIN)
    assert accuracy(nb, TRAIN) == 1.0
    with pytest.raises(TypeError):
        NaiveBayesClassifier.train("bad")


# --- metrics --------------------------------------------------------------------------------------------------


def test_N_000308_N_000315_edit_distance():
    # spec: N-000308 N-000309 N-000310 N-000311 N-000312 N-000314 N-000315 N-000330
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("a", "b", substitution_cost=2) == 2
    assert edit_distance("", "") == 0
    assert edit_distance("same", "same") == 0
    assert edit_distance("abc", "xyz") == edit_distance("xyz", "abc")


def test_N_000486_jaccard_and_accuracy():
    # spec: N-000486 N-000481 N-000482
    assert jaccard_distance({1, 2, 3}, {2, 3, 4}) == pytest.approx(0.5)
    assert metric_accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        metric_accuracy([1], [1, 2])


def test_N_000316_N_000329_precision_recall_fmeasure():
    # spec: N-000316 N-000317 N-000327 N-000328 N-000329 N-000487 N-000488 N-000489
    assert precision({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert recall({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, set()) is None
    assert f_measure({1}, {2}) == 0.0
    with pytest.raises(TypeError):
        precision([1], {1})


def test_N_000318_N_000325_bleu():
    # spec: N-000318 N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325 N-000490 N-000491 N-000492 N-000493
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) == 0.0
    assert bleu(ref, ["the"]) == 0.0
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"], weights=(0.5, 0.5)) == pytest.approx(1.0)
    assert bleu(ref, []) == 0.0
    assert bleu(ref, ["the", "cat"], smoothing_function=lambda pairs: [0.5] * len(pairs)) > 0
