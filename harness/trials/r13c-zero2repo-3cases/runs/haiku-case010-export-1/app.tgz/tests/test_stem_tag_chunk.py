"""Stemmers (FP-02), taggers (FP-03), chunking (FP-04): spec ids N-000135 … N-000247."""

import pytest

from lingora.chunk import ChunkStage, RegexpParser, ne_chunk
from lingora.stem import (
    ARLSTem,
    ARLSTem2,
    LancasterStemmer,
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
    WordNetLemmatizer,
)
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree


# --- stemmers -------------------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "word, stem",
    [("caresses", "caress"), ("ponies", "poni"), ("agreed", "agre"), ("running", "run"), ("relational", "relat"), ("generously", "gener")],
)
def test_N_000148_N_000164_porter_default_mode(word, stem):
    # spec: N-000148 N-000149 N-000163 N-000164
    assert PorterStemmer().stem(word) == stem


def test_N_000150_N_000152_porter_irregular_and_short_words():
    # spec: N-000150 N-000151 N-000152
    stemmer = PorterStemmer()
    assert stemmer.stem("Dying") == "die"
    assert stemmer.stem("As") == "as"
    assert stemmer.stem("I") == "i"


def test_N_000153_N_000155_porter_ies_ied_rules():
    # spec: N-000153 N-000154 N-000155
    stemmer = PorterStemmer()
    assert stemmer.stem("dies") == "die"
    assert stemmer.stem("cried") == "cri"
    assert stemmer.stem("died") == "die"


def test_N_000157_porter_y_rule_needs_consonant_not_first_letter():
    # spec: N-000157
    assert PorterStemmer().stem("happy") == "happi"
    assert PorterStemmer().stem("yay") == "yay"


def test_N_000144_porter_three_modes_and_default():
    # spec: N-000144 N-000145
    assert PorterStemmer().mode == PorterStemmer.NLTK_EXTENSIONS
    for mode in (PorterStemmer.ORIGINAL_ALGORITHM, PorterStemmer.MARTIN_EXTENSIONS):
        PorterStemmer(mode).stem("running")
    with pytest.raises(ValueError):
        PorterStemmer("UNKNOWN")


def test_N_000166_lancaster_rule_table():
    # spec: N-000165 N-000166
    stemmer = LancasterStemmer()
    assert stemmer.stem("maximum") == "maxim"
    assert stemmer.stem("presumably") == "presum"
    assert stemmer.stem("Running") == "run"


def test_N_000142_N_000177_snowball_english_and_unsupported_language():
    # spec: N-000142 N-000167 N-000169 N-000171 N-000176 N-000177 N-000409 N-000410
    stemmer = SnowballStemmer("english")
    assert stemmer.stem("generously") == "generous"
    assert stemmer.stem("Running") == "run"
    assert stemmer.stem("skies") == "sky"
    with pytest.raises(ValueError) as error:
        SnowballStemmer("klingon")
    assert "klingon" in str(error.value)


def test_N_000172_N_000178_N_000411_snowball_stopwords(stopword_root):
    # spec: N-000172 N-000411
    stemmer = SnowballStemmer("english", ignore_stopwords=True)
    assert stemmer.stem("The") == "the"
    assert stemmer.stem("running") == "run"


def test_N_000178_N_000179_snowball_stopwords_need_the_language_list(tmp_path, monkeypatch):
    # spec: N-000178 N-000179 N-000411
    from lingora import data

    other = tmp_path / "corpora" / "stopwords"
    other.mkdir(parents=True)
    (other / "dutch").write_text("de\n", encoding="utf-8")
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N_000173_N_000175_regexp_stemmer():
    # spec: N-000173 N-000174 N-000175
    stemmer = RegexpStemmer(r"ing$")
    assert stemmer.stem("running") == "runn"
    assert stemmer.stem("dog") == "dog"
    assert RegexpStemmer("s$").stem("cats") == "cat"


def test_N_000147_stemmers_do_not_split_on_spaces():
    # spec: N-000147
    assert RegexpStemmer(r"xx").stem("a xx b") == "a  b"


def test_N_000180_N_000181_N_000412_wordnet_lemmatizer(wordnet_root):
    # spec: N-000180 N-000412 N-000137 N-000140
    lemmatizer = WordNetLemmatizer()
    assert lemmatizer.lemmatize("dogs") == "dog"
    assert lemmatizer.lemmatize("cat") == "cat"
    assert lemmatizer.lemmatize("runs", pos="v") == "run"


def test_N_000412_wordnet_lemmatizer_needs_wordnet():
    # spec: N-000412 N-000180
    with pytest.raises(LookupError):
        WordNetLemmatizer()


def test_N_000135_arabic_light_stemmers_exist():
    # spec: N-000135
    assert isinstance(ARLSTem().stem("كتاب"), str)
    assert isinstance(ARLSTem2().stem("كتاب"), str)


# --- taggers --------------------------------------------------------------------------------------------------

TRAIN = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("cat", "NN")], [("a", "DT")]]


def test_N_000191_N_000193_default_tagger():
    # spec: N-000191 N-000192 N-000193 N-000424 N-000425
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


def test_N_000194_N_000196_unigram_tagger_and_backoff():
    # spec: N-000194 N-000195 N-000196 N-000200 N-000201
    tagger = UnigramTagger(TRAIN)
    assert tagger.tag(["the", "zebra"]) == [("the", "DT"), ("zebra", None)]
    tagger = UnigramTagger(TRAIN, backoff=DefaultTagger("NN"))
    assert tagger.tag(["the", "zebra"]) == [("the", "DT"), ("zebra", "NN")]


def test_N_000197_N_000199_regexp_tagger_first_rule_wins():
    # spec: N-000197 N-000198 N-000199
    tagger = RegexpTagger([(r"\d+$", "CD"), (r".*s$", "NNS")])
    assert tagger.tag(["12", "cats", "run"]) == [("12", "CD"), ("cats", "NNS"), ("run", None)]


def test_N_000215_N_000216_pos_tag_refuses_strings_and_unknown_languages(tagger_root):
    # spec: N-000214 N-000215 N-000217 N-000218
    with pytest.raises(TypeError):
        pos_tag("the dog")
    with pytest.raises(ValueError):
        pos_tag(["the"], lang="deu")


def test_N_000202_N_000209_recommended_taggers(tagger_root):
    # spec: N-000202 N-000205 N-000206 N-000208 N-000209 N-000420 N-000424
    assert pos_tag(["the", "zebra"]) == [("the", "DT"), ("zebra", "NN")]
    assert pos_tag([]) == []
    assert pos_tag(["the"], lang="rus") == [("the", "S")]


def test_N_000219_N_000220_missing_tagger_resource_fails(tmp_path, monkeypatch):
    # spec: N-000219 N-000220 N-000423
    from lingora import data

    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        pos_tag(["the"])


def test_N_000210_N_000221_universal_tagset(tagger_root):
    # spec: N-000210 N-000221 N-000421
    assert pos_tag(["the", "zebra"], tagset="universal") == [("the", "DET"), ("zebra", "NOUN")]


def test_N_000221_universal_tagset_needs_tables(tagger_root):
    # spec: N-000221 N-000222
    import shutil

    shutil.rmtree(str(tagger_root / "taggers" / "universal_tagset"))
    with pytest.raises(LookupError):
        pos_tag(["the"], tagset="universal")


# --- chunking -------------------------------------------------------------------------------------------------

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("at", "IN"), ("a", "DT"), ("cat", "NN")]


def test_N_000223_N_000240_chunk_rule_and_cascade():
    # spec: N-000224 N-000226 N-000227 N-000230 N-000231 N-000237 N-000238
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}\nVP: {<VBD>}").parse(TAGGED)
    assert tree.label() == "S"
    assert tree[0] == Tree("NP", [("the", "DT"), ("big", "JJ"), ("dog", "NN")])
    assert tree[1] == Tree("VP", [("barked", "VBD")])
    assert tree.leaves() == TAGGED


def test_N_000234_N_000236_chink_rule_splits_chunk():
    # spec: N-000234 N-000235 N-000236
    tree = RegexpParser("NP: {<.*>+}\n  }<VBD>{").parse(TAGGED)
    assert tree[0] == Tree("NP", [("the", "DT"), ("big", "JJ"), ("dog", "NN")])
    assert tree[1] == ("barked", "VBD")
    assert tree[2] == Tree("NP", [("at", "IN"), ("a", "DT"), ("cat", "NN")])


def test_N_000240_later_clause_cannot_chink_earlier_chunks():
    # spec: N-000240 N-000239
    tree = RegexpParser("NP: {<DT><JJ>*<NN>}\nX: }<NP>{").parse(TAGGED)
    assert tree[0] == Tree("NP", [("the", "DT"), ("big", "JJ"), ("dog", "NN")])


def test_N_000243_N_000241_empty_input_and_leaves_preserved():
    # spec: N-000243 N-000241 N-000242
    assert RegexpParser("NP: {<NN>}").parse([]) == Tree("S", [])
    assert RegexpParser("NP: {<NN>}").parse(TAGGED).leaves() == TAGGED


def test_N_000429_N_000431_N_000244_N_000246_grammar_refusals():
    # spec: N-000429 N-000431 N-000244 N-000245 N-000246
    with pytest.raises(TypeError):
        RegexpParser(42)
    with pytest.raises(TypeError):
        RegexpParser(["not a stage"])
    parser = RegexpParser([ChunkStage("NP", ["{<DT>?<NN>}"])])
    assert Tree("NP", [("dog", "NN")]) in list(parser.parse(TAGGED))
    with pytest.raises(ValueError):
        RegexpParser("NP: <DT>")


def test_N_000433_N_000434_grammar_clause_format():
    # spec: N-000433 N-000434
    tree = RegexpParser("NP: {<DT>}\n  {<NN>}\n\n# comment\nVP: {<VBD>}").parse(TAGGED)
    assert tree[0] == Tree("NP", [("the", "DT")])
    assert tree[2] == Tree("NP", [("dog", "NN")])
    assert tree[3] == Tree("VP", [("barked", "VBD")])
    with pytest.raises(ValueError):
        RegexpParser("{<DT>}")


def test_N_000246_ne_chunk_resources(tmp_path, monkeypatch):
    # spec: N-000432 N-000247
    from lingora import data

    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        ne_chunk(TAGGED)
