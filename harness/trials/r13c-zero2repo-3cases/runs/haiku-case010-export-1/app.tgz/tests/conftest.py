"""Shared fixtures: synthetic packaged-resource directories built under pytest's tmp_path.

The resources here are tiny stand-ins written in the published file layouts; they are not the real models.
"""

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from lingora import data  # noqa: E402


@pytest.fixture(autouse=True)
def _no_resources_by_default(monkeypatch):
    # spec: N-000370 — by default no packaged resource is visible.
    monkeypatch.setattr(data, "path", [])


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture
def punkt_root(tmp_path, monkeypatch):
    """A resource root holding an English Punkt model."""
    root = tmp_path / "res"
    english = root / "tokenizers" / "punkt_tab" / "english"
    _write(str(english / "abbrev_types.txt"), "dr\nmr\ne.g\n")
    _write(str(english / "sent_starters.txt"), "the\nhe\nyes\n")
    _write(str(english / "collocations.tab"), "")
    _write(str(english / "ortho_context.tab"), "smith\t4\nwent\t32\n")
    monkeypatch.setattr(data, "path", [str(root)])
    return root


@pytest.fixture
def tagger_root(tmp_path, monkeypatch):
    """A resource root holding averaged-perceptron English and Russian models plus the universal map."""
    root = tmp_path / "res"
    for lang, tags in (("eng", ["DT", "NN", "VBD"]), ("rus", ["S", "V"])):
        base = root / "taggers" / ("averaged_perceptron_tagger_%s" % lang)
        name = "averaged_perceptron_tagger_%s" % lang
        weights = {"bias": {tags[1]: 1.0}, "i word": {}}
        _write(str(base / (name + ".weights.json")), json.dumps(weights))
        _write(str(base / (name + ".tagdict.json")), json.dumps({"the": tags[0]}))
        _write(str(base / (name + ".classes.json")), json.dumps(tags))
    _write(str(root / "taggers" / "universal_tagset" / "en-ptb.map"), "DT\tDET\nNN\tNOUN\nVBD\tVERB\n")
    monkeypatch.setattr(data, "path", [str(root)])
    return root


@pytest.fixture
def stopword_root(tmp_path, monkeypatch):
    root = tmp_path / "res"
    _write(str(root / "corpora" / "stopwords" / "english"), "the\na\nis\n")
    monkeypatch.setattr(data, "path", [str(root)])
    return root


@pytest.fixture
def wordnet_root(tmp_path, monkeypatch):
    root = tmp_path / "res"
    _write(
        str(root / "corpora" / "wordnet" / "index.noun"),
        "  This is a license header line.\ndog n 1 0 1 0 1 0 1 0\ncat n 1 0 1 0 1 0 1 0\n",
    )
    _write(str(root / "corpora" / "wordnet" / "index.verb"), "run v 1 0 1 0 1 0 1 0\n")
    monkeypatch.setattr(data, "path", [str(root)])
    return root
