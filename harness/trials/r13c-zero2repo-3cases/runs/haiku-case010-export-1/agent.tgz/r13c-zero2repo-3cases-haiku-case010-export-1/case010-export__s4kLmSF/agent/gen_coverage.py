import re, glob, os
ck = open('/app/spec/CHECKLIST.md', encoding='utf-8').read()
items = re.findall(r'^- \[ \] (N-\d{6}) · (\S+) · (.*?) · (.*?) · (.*?) · (.*)$', ck, re.M)

where = {}
for f in glob.glob('/app/lingora/**/*.py', recursive=True):
    rel = os.path.relpath(f, '/app')
    for i in set(re.findall(r'N-\d{6}', open(f, encoding='utf-8').read())):
        where.setdefault(i, set()).add(rel)
tests = {}
for f in glob.glob('/app/tests/*.py'):
    rel = os.path.relpath(f, '/app')
    t = open(f, encoding='utf-8').read()
    ids = set(re.findall(r'N-\d{6}', t)) | {'N-' + m for m in re.findall(r'N_(\d{6})', t)}
    for i in ids:
        tests.setdefault(i, set()).add(rel)

NOT_DONE = {
    'N-000341': 'Profile label only (cpu_baseline). The library has no runtime profile switch, so nothing is built for it.',
    'N-000058': 'Package downloader is outside this specification (N-000331); not implemented.',
    'N-000168': 'Snowball Dutch algorithm is not implemented in this build; the Dutch stemmer raises NotImplementedError.',
    'N-000018': 'Outside this specification: packaged corpora, WordNet browsers, and similar surfaces are not feature points; not built.',
    'N-000029': 'An s-expression tokenizer is outside this specification; not built.',
    'N-000079': 'An s-expression tokenizer is outside this specification; not built.',
    'N-000331': 'Packaged corpora, WordNet, downloader and graphical surfaces are outside this specification; not built.',
    'N-000332': 'Graphical applications and tree/table drawing are outside this specification; not built.',
    'N-000333': 'Chat, Twitter, Hugging Face and Toolbox helpers are outside this specification; not built.',
    'N-000334': 'External-binary wrappers are outside this specification; not built.',
}
PARTIAL = {
    'N-000036': 'ne_chunk checks for its model and wordlist (LookupError when absent) but raises NotImplementedError when they are present; the model file format is not in the specification.',
    'N-000135': 'Porter, Lancaster, Snowball (english, porter only), regular-expression and WordNet lemmatizer are implemented. ISRI, Cistem and RSLP are not in the interface contract and are not built; ARLSTem/ARLSTem2 are approximate.',
    'N-000138': 'Porter, Lancaster, Snowball (english, porter only) and regular-expression stemmers are implemented; the other Snowball languages raise NotImplementedError.',
    'N-000167': 'Snowball algorithm implemented for english (Porter2) only; porter is an approximation (see N-000170). Other languages raise NotImplementedError.',
    'N-000170': 'Approximation: the porter language uses PorterStemmer in ORIGINAL_ALGORITHM mode, not Snowball\'s own porter rendering.',
    'N-000139': 'ARLSTem/ARLSTem2 are approximate light stemmers; ISRI, Cistem, RSLP not built. Results are outside the specification.',
    'N-000146': 'Porter modes ORIGINAL_ALGORITHM and MARTIN_EXTENSIONS exist; their results are outside the specification.',
    'N-000202': 'Recommended English tagger implemented from the published feature templates as reconstructed here; verified only against a synthetic model (no packaged model available).',
    'N-000203': 'As N-000202: feature templates reconstructed; verified only against a synthetic model.',
    'N-000204': 'As N-000202: feature templates reconstructed; verified only against a synthetic model.',
    'N-000205': 'As N-000202: verified only against a synthetic model.',
    'N-000206': 'As N-000202: verified only against a synthetic model.',
    'N-000207': 'As N-000202: verified only against a synthetic model.',
    'N-000208': 'Russian tagger: same algorithm, verified only against a synthetic model.',
    'N-000209': 'Russian tagger: same algorithm, verified only against a synthetic model.',
    'N-000071': 'The data finder is implemented; the downloader is outside this specification and not built.',
}
DESCRIPTIVE_NON_GOAL = {
    'N-000077': 'Non-goal: no throughput is guaranteed; nothing to build.',
}

def status(i):
    if i in NOT_DONE:
        return 'not done', NOT_DONE[i]
    if i in PARTIAL:
        return 'partial', PARTIAL[i]
    if i in DESCRIPTIVE_NON_GOAL:
        return 'implemented', DESCRIPTIVE_NON_GOAL[i]
    if i in tests:
        return 'tested', ''
    if i in where:
        return 'implemented', ''
    return 'UNCOVERED', ''

counts = {}
rows = []
for i, kind, level, decision, _, text in items:
    st, note = status(i)
    counts[st] = counts.get(st, 0) + 1
    files = sorted(where.get(i, set()) | tests.get(i, set()))
    short = text.replace('|', '/').replace('`', '')
    if len(short) > 110:
        short = short[:107] + '...'
    rows.append((i, kind, st, note, ', '.join(os.path.basename(x) for x in files), short))

out = []
out.append('# Spec coverage (checklist)\n')
out.append('Generated from `spec/CHECKLIST.md`. Every id ends **tested**, **implemented**, **partial** (with the missing part given), or **not done** (with a reason).\n')
out.append('- tested: referenced by a test (`tests/`) and implemented in `lingora/`.')
out.append('- implemented: referenced in `lingora/` (code marker), not directly named in a test.')
out.append('- partial / not done: the reason is in the Notes column.\n')
out.append('Counts: ' + ', '.join('%s %d' % (k, v) for k, v in sorted(counts.items())) + ' (total %d)\n' % len(rows))
out.append('| Id | Kind | Status | Where | Notes | Checklist text |')
out.append('|---|---|---|---|---|---|')
for i, kind, st, note, files, short in rows:
    out.append('| %s | %s | %s | %s | %s | %s |' % (i, kind, st, files or '—', note or '', short))
open('/app/SPEC_COVERAGE.md', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print(counts, len(rows))
