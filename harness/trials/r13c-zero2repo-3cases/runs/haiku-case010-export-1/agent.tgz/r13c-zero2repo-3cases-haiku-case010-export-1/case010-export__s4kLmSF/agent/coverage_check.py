import re, glob, sys
sys.path.insert(0, '/app')
ck = open('/app/spec/CHECKLIST.md', encoding='utf-8').read()
items = re.findall(r'^- \[ \] (N-\d{6}) · (\S+) · (.*?) · (.*?) · (.*?) · (.*)$', ck, re.M)
code_ids=set(); test_ids=set()
for f in glob.glob('/app/lingora/**/*.py', recursive=True):
    code_ids |= set(re.findall(r'N-\d{6}', open(f,encoding='utf-8').read()))
for f in glob.glob('/app/tests/*.py'):
    t=open(f,encoding='utf-8').read()
    test_ids |= set(re.findall(r'N-\d{6}', t))
    test_ids |= {'N-'+m for m in re.findall(r'N_(\d{6})', t)}
missing=[i for i,*_ in items if i not in code_ids and i not in test_ids]
print('total', len(items), 'unreferenced', len(missing))
print(' '.join(m[2:] for m in missing))
print('code-only', len([i for i,*_ in items if i in code_ids and i not in test_ids]))
