"""Locate packaged resources (Punkt models, taggers, corpora) on ``data.path``.

Callers may replace the contents of ``path`` in place; every lookup reads it
afresh, so a change takes effect on the next call that needs a resource.
"""

import os


def _initial_path():
    dirs = [d for d in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if d]
    dirs.append(os.path.expanduser(os.path.join("~", "lingora_data")))
    return dirs


path = _initial_path()


def find(resource):
    """Return the location of ``resource`` inside the first directory of ``path`` that holds it.

    ``resource`` is a relative name such as ``tokenizers/punkt_tab/english``.
    Raises ``LookupError`` naming the resource when no listed directory holds it.
    """
    for directory in path:
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "Resource %r not found in data.path %r; install it or add its parent directory to lingora.data.path"
        % (resource, list(path))
    )
