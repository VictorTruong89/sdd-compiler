"""Part-of-speech taggers: sequential taggers the caller trains, and the recommended averaged perceptron tagger."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "RegexpTagger",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]


class _TaggerBase:
    """Shared tagging protocol: ``tag`` returns one ``(token, tag-or-None)`` pair per token."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, _TaggerBase):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose_tags(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a str")
        tokens = list(tokens)
        tags = self._choose_tags(tokens)
        if self._backoff is not None and tokens:
            fallback = self._backoff.tag(tokens)
            tags = [t if t is not None else fb[1] for t, fb in zip(tags, fallback)]
        return list(zip(tokens, tags))


class DefaultTagger(_TaggerBase):
    def __init__(self, tag):
        super().__init__()
        self._tag = tag

    def _choose_tags(self, tokens):
        return [self._tag] * len(tokens)


def _most_common_tag(counter):
    return sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]


def _sentences_as_pairs(train):
    if train is None:
        return []
    return [[(tok, tag) for tok, tag in sentence] for sentence in train]


class UnigramTagger(_TaggerBase):
    """Assigns each word the tag it most often had in training; unseen words get no tag."""

    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in _sentences_as_pairs(train):
            for word, tag in sentence:
                counts[word][tag] += 1
        self._model = {word: _most_common_tag(c) for word, c in counts.items()}

    def _choose_tags(self, tokens):
        return [self._model.get(token) for token in tokens]


class _NgramTagger(_TaggerBase):
    """Tags each word from its own form and the tags already assigned to the preceding words."""

    _order = 2

    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(lambda: defaultdict(Counter))
        for sentence in _sentences_as_pairs(train):
            history = ()
            for word, tag in sentence:
                counts[history][word][tag] += 1
                history = self._push(history, tag)
        self._model = {h: {w: _most_common_tag(c) for w, c in words.items()} for h, words in counts.items()}

    def _push(self, history, tag):
        return (history + (tag,))[-(self._order - 1):]

    def _choose_tags(self, tokens):
        tags = []
        history = ()
        for token in tokens:
            tag = self._model.get(history, {}).get(token)
            tags.append(tag)
            history = self._push(history, tag)
        return tags


class BigramTagger(_NgramTagger):
    _order = 2


class TrigramTagger(_NgramTagger):
    _order = 3


class AffixTagger(_TaggerBase):
    """Tags each word from its prefix or suffix of ``affix_length`` characters."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        counts = defaultdict(Counter)
        for sentence in _sentences_as_pairs(train):
            for word, tag in sentence:
                affix = self._affix(word)
                if affix is not None:
                    counts[affix][tag] += 1
        self._model = {affix: _most_common_tag(c) for affix, c in counts.items()}

    def _affix(self, word):
        if len(word) < self._min_stem_length + abs(self._affix_length):
            return None
        return word[self._affix_length:] if self._affix_length < 0 else word[: self._affix_length]

    def _choose_tags(self, tokens):
        tags = []
        for token in tokens:
            affix = self._affix(token)
            tags.append(None if affix is None else self._model.get(affix))
        return tags


class RegexpTagger(_TaggerBase):
    """The first rule whose pattern matches at the start of the token gives its tag."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _choose_tags(self, tokens):
        tags = []
        for token in tokens:
            tag = None
            for pattern, rule_tag in self._rules:
                if pattern.match(token):
                    tag = rule_tag
                    break
            tags.append(tag)
        return tags


# Averaged perceptron (recommended tagger) ----------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_CACHE = {}
_UNIVERSAL_CACHE = {}

# Russian National Corpus part-of-speech categories mapped to the universal tagset.
_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "ANUM": "ADJ", "V": "VERB", "ADV": "ADV", "PRAEDIC": "ADV",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM", "INTJ": "X", "SPRO": "PRON",
    "APRO": "DET", "PARENTH": "X",
}


def _normalize(word):
    if "-" in word and word[:1] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feature, value in features.items():
            if value == 0 or feature not in self.weights:
                continue
            for label, weight in self.weights[feature].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        context = _START + [_normalize(w) for w in tokens] + _END
        prev, prev2 = _START[0], _START[1]
        output = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(_features(i, word, context, prev, prev2))
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


def _load_perceptron(lang):
    directory = data.find(os.path.join("taggers", "averaged_perceptron_tagger_" + lang))
    if directory in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[directory]
    base = os.path.join(directory, "averaged_perceptron_tagger_" + lang)

    def load(suffix):
        filename = base + "." + suffix + ".json"
        if not os.path.isfile(filename):
            raise LookupError("Averaged perceptron tagger file %r is missing" % filename)
        with open(filename, encoding="utf-8") as handle:
            return json.load(handle)

    model = _PerceptronModel(load("weights"), load("tagdict"), load("classes"))
    _PERCEPTRON_CACHE[directory] = model
    return model


def _load_universal_map():
    directory = data.find(os.path.join("taggers", "universal_tagset"))
    if directory not in _UNIVERSAL_CACHE:
        mapping = {}
        filename = os.path.join(directory, "en-ptb.map")
        if not os.path.isfile(filename):
            raise LookupError("Universal tagset table en-ptb.map is missing")
        with open(filename, encoding="utf-8") as handle:
            for line in handle:
                parts = line.rstrip("\r\n").split("\t")
                if len(parts) == 2:
                    mapping[parts[0]] = parts[1]
        _UNIVERSAL_CACHE[directory] = mapping
    return _UNIVERSAL_CACHE[directory]


def _rnc_universal(tag):
    if tag is None:
        return None
    category = tag.split("=", 1)[0].split(",", 1)[0]
    return _RNC_TO_UNIVERSAL.get(category, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the packaged averaged perceptron tagger for ``lang`` (``eng`` or ``rus``)."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag needs a list of tokens, not a str")
    tokens = list(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    tagged = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_universal_map()
            tagged = [(w, mapping.get(t, t)) for w, t in tagged]
        else:
            tagged = [(w, _rnc_universal(t)) for w, t in tagged]
    return tagged
