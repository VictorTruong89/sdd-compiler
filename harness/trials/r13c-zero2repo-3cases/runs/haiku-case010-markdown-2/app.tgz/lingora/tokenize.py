"""Tokenizers: word/punctuation, Penn Treebank, recommended word and sentence, whitespace, regexp, tweet."""

import os
import re

from lingora import data

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space characters."""

    _pattern = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        for m in self._pattern.finditer(text):
            yield m.span()


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# Penn Treebank conventions -------------------------------------------------

_OPEN_QUOTE = re.compile(r'(^|[\s(\[{<])"')
_TYPOGRAPHIC_OPEN = re.compile("[«“‘„]")
_TYPOGRAPHIC_CLOSE = re.compile("[»”’]")
_DASHES = re.compile("[‒-―*]")
_PUNCT = re.compile(r"[;@#$%&?!]")
_BRACKETS = re.compile(r"[\[\](){}<>]")
_COMMA_COLON = re.compile(r"([:,])(?!\d)")
_FINAL_POINT = re.compile(r"([^.])\.([\]\)}>\"']*)\s*\Z")
_CLITIC = re.compile(r"(?i)(\w)('(?:s|m|d|ll|re|ve))\b")
_NOT = re.compile(r"(?i)(\w)(n't)\b")
_BARE_APOSTROPHE = re.compile(r"(\w)'(?=\s|\Z)")
_FUSED = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)\b"),
    re.compile(r"(?i)(?<!\w)('t)(is|was)\b"),
]


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer.

    With ``improved=True`` it is LINGORA's recommended variant: typographic quotes,
    U+2012-U+2015 dashes and asterisks are split off, runs of two or more points and
    double hyphens are tokens.
    """

    def __init__(self, improved=False):
        self._improved = improved

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        s = _OPEN_QUOTE.sub(r"\1 `` ", text)
        s = re.sub(r"``", " `` ", s)
        if self._improved:
            s = _TYPOGRAPHIC_OPEN.sub(lambda m: " %s " % m.group(), s)
        s = re.sub(r"`+", lambda m: " %s " % m.group(), s)
        if self._improved:
            s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(), s)
            s = re.sub(r"--", " -- ", s)
            s = _DASHES.sub(lambda m: " %s " % m.group(), s)
        else:
            s = re.sub(r"\.\.\.", " ... ", s)
        s = _PUNCT.sub(lambda m: " %s " % m.group(), s)
        s = _BRACKETS.sub(lambda m: " %s " % m.group(), s)
        s = _COMMA_COLON.sub(r" \1 ", s)
        s = _FINAL_POINT.sub(r"\1 .\2 ", s)
        s = s.replace("''", " '' ")
        s = s.replace('"', " '' ")
        if self._improved:
            s = _TYPOGRAPHIC_CLOSE.sub(lambda m: " %s " % m.group(), s)
        s = _NOT.sub(r"\1 \2", s)
        s = _CLITIC.sub(r"\1 \2", s)
        s = _BARE_APOSTROPHE.sub(r"\1 '", s)
        for pattern in _FUSED:
            s = pattern.sub(r"\1 \2", s)
        return s.split()


_RECOMMENDED = TreebankWordTokenizer(improved=True)


# Sentence tokenization (Punkt) ---------------------------------------------

_OPENERS = "\"'([{<«“‘„¿¡"
_CLOSERS = "\"')]}>»”’"
_TOKEN = re.compile(r"\S+")
_NUMBER_TYPE = re.compile(r"-?[.,]?\d[\d,.-]*")
_INITIAL = re.compile(r"[^\W\d_]")
_ORTHO_UC = 2 | 4 | 8
_ORTHO_MID_UC = 4
_ORTHO_LC = 16 | 32 | 64
_PUNKT_CACHE = {}


def _read_lines(filename):
    if not os.path.isfile(filename):
        return []
    with open(filename, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.rstrip("\r\n")]


class _PunktParams:
    """Packaged Punkt parameters for one language directory."""

    def __init__(self, directory):
        self.abbrev_types = {w.lower() for w in _read_lines(os.path.join(directory, "abbrev_types.txt"))}
        self.sent_starters = {w.lower() for w in _read_lines(os.path.join(directory, "sent_starters.txt"))}
        self.collocations = set()
        for line in _read_lines(os.path.join(directory, "collocations.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                self.collocations.add((parts[0].lower(), parts[1].lower()))
        self.ortho_context = {}
        for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
            parts = line.split("\t")
            if len(parts) == 2 and parts[1].strip().isdigit():
                self.ortho_context[parts[0].lower()] = int(parts[1])


def _load_punkt(language):
    directory = data.find(os.path.join("tokenizers", "punkt_tab", language))
    if directory not in _PUNKT_CACHE:
        _PUNKT_CACHE[directory] = _PunktParams(directory)
    return _PUNKT_CACHE[directory]


class _PunktToken:
    def __init__(self, raw, start, end):
        self.start = start
        self.end = end
        body = raw.lstrip(_OPENERS)
        core = body.rstrip(_CLOSERS)
        self.first_upper = bool(body) and body[0].isupper()
        self.first_lower = bool(body) and body[0].islower()
        self.end_mark = core.endswith(("?", "!"))
        self.period = core.endswith(".")
        word = core[:-1] if self.period else core
        self.ellipsis = core.endswith("..")
        self.typ = word.lower()
        if _NUMBER_TYPE.fullmatch(self.typ):
            self.typ = "##number##"
        self.is_initial = bool(_INITIAL.fullmatch(word))
        self.abbr = False


def _ortho(tok, params):
    """Orthographic heuristic: True if the token looks like a sentence start, False if not, else None."""
    context = params.ortho_context.get(tok.typ, 0)
    if tok.first_upper and (context & _ORTHO_LC) and not (context & _ORTHO_MID_UC):
        return True
    if tok.first_lower and ((context & _ORTHO_UC) or not (context & _ORTHO_LC)):
        return False
    return None


def _period_is_break(tok, nxt, params):
    if tok.abbr:
        if (tok.typ, nxt.typ) in params.collocations:
            return False
        if nxt.first_upper and nxt.typ in params.sent_starters:
            return True
        if tok.is_initial:
            return False
        return nxt.first_upper and _ortho(nxt, params) is True
    return not nxt.first_lower


def _sentence_spans(text, params):
    tokens = [_PunktToken(m.group(), m.start(), m.end()) for m in _TOKEN.finditer(text)]
    for tok in tokens:
        tok.abbr = tok.period and (tok.typ in params.abbrev_types or tok.is_initial or tok.typ == "##number##")
    spans = []
    start = 0
    for i, tok in enumerate(tokens):
        last = i == len(tokens) - 1
        if last:
            is_break = True
        elif tok.end_mark:
            is_break = True
        elif tok.period:
            is_break = _period_is_break(tok, tokens[i + 1], params)
        else:
            is_break = False
        if is_break:
            spans.append((tokens[start].start, tok.end))
            start = i + 1
    return spans


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model for ``language``."""
    params = _load_punkt(language)
    if not text:
        return []
    return [text[s:e] for s, e in _sentence_spans(text, params)]


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (improved Penn Treebank, with sentence splitting first)."""
    sentences = [text] if preserve_line else sent_tokenize(text, language=language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_RECOMMENDED.tokenize(sentence))
    return tokens


# Other tokenizers ------------------------------------------------------------

class WhitespaceTokenizer:
    def tokenize(self, text):
        return text.split()

    def span_tokenize(self, text):
        for m in re.finditer(r"\S+", text):
            yield m.span()


_BLANK_LINE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    return [segment for segment in _BLANK_LINE.split(text) if segment]


class RegexpTokenizer:
    """Tokens are the matches of ``pattern`` (token mode), or the pieces between matches (gap mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = re.compile(pattern, flags)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def span_tokenize(self, text):
        if self._gaps:
            spans = []
            prev = 0
            for m in self._pattern.finditer(text):
                spans.append((prev, m.start()))
                prev = m.end()
            spans.append((prev, len(text)))
        else:
            spans = [m.span() for m in self._pattern.finditer(text)]
        for start, end in spans:
            if self._discard_empty and start == end:
                continue
            yield start, end

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text)]


_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[\)\]\(\[dDpP/:\}\{@|\\]"
    r"|[\)\]\(\[dDpP/:\}\{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3)"
)
_URL = r"(?:https?://|www\.)[^\s<>\"]*[^\s<>\"'.,!?;:)\]]"
_TWEET_TOKEN = re.compile(
    "|".join(
        [
            _URL,
            r"<[^>\s]+>",
            r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]+",
            r"#\w+",
            _EMOTICON,
            r"[+-]?\d+(?:[.,]\d+)+(?!\w)",
            r"\w+(?:'\w+)*",
            r"[^\w\s]",
        ]
    )
)
_HANDLE = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        if self._strip_handles:
            text = _HANDLE.sub(" ", text)
        if self._reduce_len:
            text = re.sub(r"(.)\1{2,}", lambda m: m.group(1) * 3, text, flags=re.DOTALL)
        tokens = []
        for m in _TWEET_TOKEN.finditer(text):
            token = m.group()
            if not self._preserve_case and not re.fullmatch(_EMOTICON, token):
                token = token.lower()
            tokens.append(token)
        return tokens
