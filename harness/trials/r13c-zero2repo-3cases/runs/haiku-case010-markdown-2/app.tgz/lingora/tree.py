"""Constituent trees: a label plus an ordered list of children (leaves or subtrees)."""

import re


class Tree:
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed text such as ``(S (NP I) (VP walk))``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        pos = 0

        def node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text %r" % s)
            pos += 1
            if pos >= len(tokens) or tokens[pos] in "()":
                raise ValueError("missing label in bracketed tree text %r" % s)
            label = tokens[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced brackets in %r" % s)
                if tokens[pos] == ")":
                    pos += 1
                    return cls(label, children)
                if tokens[pos] == "(":
                    children.append(node())
                else:
                    children.append(tokens[pos])
                    pos += 1

        tree = node()
        if pos != len(tokens):
            raise ValueError("trailing text after tree in %r" % s)
        return tree

    def label(self):
        return self._label

    def leaves(self):
        result = []
        for child in self._children:
            if isinstance(child, Tree):
                result.extend(child.leaves())
            else:
                result.append(child)
        return result

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    __hash__ = None

    def _flat(self):
        parts = [_leaf_text(child) if not isinstance(child, Tree) else child._flat() for child in self._children]
        return "(" + str(self._label) + "".join(" " + p for p in parts) + ")"

    def _pformat(self, indent, margin):
        flat = self._flat()
        if indent + len(flat) <= margin or not any(isinstance(c, Tree) for c in self._children):
            return flat
        pad = "\n" + " " * (indent + 2)
        lines = ["(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child._pformat(indent + 2, margin))
            else:
                lines.append(_leaf_text(child))
        return pad.join(lines) + ")"

    def pformat(self, margin=70):
        """Pretty-printed text: labels and leaves appear in left-to-right pre-order."""
        return self._pformat(0, margin)

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)


def _leaf_text(leaf):
    if isinstance(leaf, tuple):
        return "/".join(str(part) for part in leaf)
    return str(leaf)
