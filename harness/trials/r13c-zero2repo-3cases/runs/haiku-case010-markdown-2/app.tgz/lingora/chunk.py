"""Regular-expression chunk parser over tagged tokens, driven by a chunk grammar."""

import os
import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "SENTENCE"

_CLAUSE_LABEL = re.compile(r"([^\s:{}<>]+)\s*:(.*)")
_RULE = re.compile(r"\{((?:\{\d*,?\d*\}|[^{}])*)\}|\}((?:\{\d*,?\d*\}|[^{}])*)\{")
_ELEMENT = re.compile(r"<((?:\\.|[^<>\\])*)>|([?*+]|\{\d*,?\d*\})|\s+")


def _element_regex(content):
    """Regex for one tag element: ``.`` matches any character of a single tag."""
    out = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^<>]" if c == "." else c)
        i += 1
    return "".join(out)


def _compile_tag_pattern(pattern):
    """Compile a tag pattern to a regex over the encoding ``<tag1><tag2>...``."""
    parts = []
    pos = 0
    text = re.sub(r"\s+", "", pattern)
    while pos < len(text):
        m = _ELEMENT.match(text, pos)
        if not m:
            raise ValueError("bad tag pattern %r" % pattern)
        pos = m.end()
        if m.group(1) is not None:
            parts.append("(?:<(?:%s)>)" % _element_regex(m.group(1)))
        elif parts:
            parts[-1] += m.group(2)
        else:
            raise ValueError("quantifier without an element in tag pattern %r" % pattern)
    return re.compile("".join(parts))


def _parse_grammar(text):
    clauses = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        m = None if line[0].isspace() else _CLAUSE_LABEL.match(line)
        if m:
            clauses.append((m.group(1), [m.group(2)]))
        elif clauses:
            clauses[-1][1].append(line)
        else:
            raise ValueError("expected a clause 'LABEL: pattern', got %r" % raw)
    stages = []
    for label, body_lines in clauses:
        rules = []
        for body in body_lines:
            pos = 0
            body = body.split(" #")[0]
            for m in _RULE.finditer(body):
                if body[pos:m.start()].strip():
                    raise ValueError("bad chunk grammar near %r" % body[pos:m.start()])
                pos = m.end()
                if m.group(1) is not None:
                    rules.append(("chunk", _compile_tag_pattern(m.group(1))))
                else:
                    rules.append(("chink", _compile_tag_pattern(m.group(2))))
            if body[pos:].strip():
                raise ValueError("bad chunk grammar near %r" % body[pos:])
        stages.append((label, rules))
    return stages


def _item_tag(item):
    if isinstance(item, Tree):
        return item.label()
    return item[1] if item[1] is not None else ""


def _encode(items):
    """Return the tag encoding of ``items`` and the maps from character offsets to item indexes."""
    encoded = []
    starts = {}
    ends = {}
    offset = 0
    for index, item in enumerate(items):
        tag = _item_tag(item)
        starts[offset] = index
        piece = "<%s>" % tag
        offset += len(piece)
        ends[offset] = index + 1
        encoded.append(piece)
    return "".join(encoded), starts, ends


def _apply_chunk(items, pattern, label, own):
    encoded, starts, ends = _encode(items)
    result = []
    cursor = 0
    for m in pattern.finditer(encoded):
        if m.start() == m.end():
            continue
        i = starts[m.start()]
        j = ends[m.end()]
        result.extend(items[cursor:i])
        chunk = Tree(label, items[i:j])
        own.add(id(chunk))
        result.append(chunk)
        cursor = j
    result.extend(items[cursor:])
    return result


def _add_chunk(result, label, children, own):
    chunk = Tree(label, children)
    own.add(id(chunk))
    result.append(chunk)


def _apply_chink(items, pattern, own):
    result = []
    for item in items:
        if not (isinstance(item, Tree) and id(item) in own):
            result.append(item)
            continue
        children = list(item)
        encoded, starts, ends = _encode(children)
        cursor = 0
        for m in pattern.finditer(encoded):
            if m.start() == m.end():
                continue
            i = starts[m.start()]
            j = ends[m.end()]
            if i > cursor:
                _add_chunk(result, item.label(), children[cursor:i], own)
            result.extend(children[i:j])
            cursor = j
        if cursor == 0:
            result.append(item)
        elif cursor < len(children):
            _add_chunk(result, item.label(), children[cursor:], own)
    return result


class RegexpParser:
    """Chunk parser for a chunk grammar given as text (or a list of grammar fragments)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            text = grammar
        elif isinstance(grammar, list) and all(isinstance(g, str) for g in grammar):
            text = "\n".join(grammar)
        else:
            raise TypeError("chunk grammar must be a str or a list of chunk-parser stages")
        self._stages = _parse_grammar(text)

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        items = [tuple(pair) for pair in tagged]
        for label, rules in self._stages:
            own = set()
            for kind, pattern in rules:
                if kind == "chunk":
                    items = _apply_chunk(items, pattern, label, own)
                else:
                    items = _apply_chink(items, pattern, own)
        return Tree(ROOT_LABEL, items)


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Requires the packaged ACE model and English wordlist."""
    data.find(os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"))
    data.find(os.path.join("corpora", "words"))
    raise NotImplementedError("the packaged named-entity model format is not supported by this build")
