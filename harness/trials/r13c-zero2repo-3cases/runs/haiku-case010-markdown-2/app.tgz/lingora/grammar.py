"""Context-free grammars read from text: one production per alternative, quoted terminals, bare nonterminals."""

import re


class Nonterminal:
    """A grammar nonterminal. Its ``str()`` is its name; it is not itself a ``str``."""

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(repr(s) if isinstance(s, str) else str(s) for s in self._rhs))


_RHS_TOKEN = re.compile(r"'[^']*'|\"[^\"]*\"|\||[^\s|'\"]+")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("line %d of the grammar has no '->': %r" % (lineno, raw))
            left, right = line.split("->", 1)
            lhs_name = left.strip()
            if not re.fullmatch(r"\w+", lhs_name):
                raise ValueError("bad left-hand side on line %d: %r" % (lineno, lhs_name))
            lhs = Nonterminal(lhs_name)
            if start is None:
                start = lhs
            alternatives = [[]]
            for token in _RHS_TOKEN.findall(right):
                if token == "|":
                    alternatives.append([])
                elif token[0] in "'\"" and len(token) >= 2 and token[-1] == token[0]:
                    alternatives[-1].append(token[1:-1])
                else:
                    alternatives[-1].append(Nonterminal(token))
            for alternative in alternatives:
                productions.append(Production(lhs, alternative))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        name = lhs.symbol() if isinstance(lhs, Nonterminal) else str(lhs)
        return [p for p in self._productions if p.lhs().symbol() == name]

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str) and s != ""}

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
