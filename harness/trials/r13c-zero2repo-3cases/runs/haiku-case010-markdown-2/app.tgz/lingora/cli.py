"""Command line: ``lingora tokenize`` applies the recommended word tokenizer to each stdin line."""

import sys

from lingora.tokenize import word_tokenize

_USAGE = "usage: lingora tokenize [--language LANG] [--delimiter DELIM]"


class _Group:
    """Minimal command group with a click-like ``main(args, standalone_mode)`` entry."""

    def __init__(self, commands):
        self._commands = commands

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            raise SystemExit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stderr.write(_USAGE + "\n")
            return 0 if args else 2
        command = self._commands.get(args[0])
        if command is None:
            sys.stderr.write("lingora: no such command %r\n" % args[0])
            return 2
        return command(args[1:])


def _parse_options(args, options):
    values = dict(options)
    i = 0
    while i < len(args):
        name = args[i]
        if name not in values or i + 1 >= len(args):
            raise ValueError("unknown or incomplete option %r" % name)
        values[name] = args[i + 1]
        i += 2
    return values


def _tokenize(args):
    try:
        options = _parse_options(args, {"--language": "english", "--delimiter": " "})
    except ValueError as exc:
        sys.stderr.write("%s\n%s\n" % (exc, _USAGE))
        return 2
    language = options["--language"]
    delimiter = options["--delimiter"]
    for line in sys.stdin:
        line = line.rstrip("\r\n")
        try:
            tokens = word_tokenize(line, language=language, preserve_line=False)
        except LookupError as exc:
            sys.stderr.write("lingora: %s\n" % exc)
            return 1
        sys.stdout.write(delimiter.join(tokens) + "\n")
    sys.stdout.flush()
    return 0


cli = _Group({"tokenize": _tokenize})
