"""Evaluation metrics: edit distance, Jaccard distance, accuracy, precision, recall and f-measure."""

__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d and %d)" % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy of empty lists is undefined")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance needs two str arguments")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    previous = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        current = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            current[j] = min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost)
        previous = current
    return previous[len(s2)]


def _damerau(s1, s2, substitution_cost):
    len1, len2 = len(s1), len(s2)
    maxdist = len1 + len2
    d = [[0] * (len2 + 2) for _ in range(len1 + 2)]
    d[0][0] = maxdist
    for i in range(len1 + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len2 + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, len1 + 1):
        last_match_col = 0
        for j in range(1, len2 + 1):
            i1 = last_row.get(s2[j - 1], 0)
            j1 = last_match_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[s1[i - 1]] = i
    return d[len1 + 1][len2 + 1]


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure need sets")


def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance needs sets")
    union = label1 | label2
    if not union:
        return 0.0
    return (len(union) - len(label1 & label2)) / len(union)


def precision(reference, test):
    """|reference ∩ test| / |test|, or None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|, or None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either set is empty."""
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
