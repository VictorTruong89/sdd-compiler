"""Enumerate the sentences a grammar derives."""

import itertools
import sys

from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal strings) derived from ``start``, in production order.

    ``depth`` bounds the derivation depth (``None`` means unbounded); ``n`` caps the number of
    sentences (``None`` means no cap).
    """
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(str(start))
    if not depth:
        depth = sys.maxsize
    sentences = _generate_all(grammar, [start], depth)
    if n is not None:
        sentences = itertools.islice(sentences, n)
    return sentences


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    try:
        for first in _generate_one(grammar, items[0], depth):
            for rest in _generate_all(grammar, items[1:], depth):
                yield first + rest
    except RecursionError:
        return


def _generate_one(grammar, item, depth):
    if depth > 0:
        if isinstance(item, Nonterminal):
            for production in grammar.productions(lhs=item):
                yield from _generate_all(grammar, production.rhs(), depth - 1)
        else:
            yield [item]
