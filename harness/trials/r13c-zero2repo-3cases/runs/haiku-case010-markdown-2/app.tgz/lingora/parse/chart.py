"""Exhaustive chart parser: every tree the grammar assigns to the token list."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree


def _check_tokens(grammar, tokens):
    tokens = list(tokens)
    known = grammar.terminals()
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be str, not %s" % type(token).__name__)
        if token not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % token)
    return tokens


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        grammar = self._grammar
        memo = {}
        active = set()

        def trees(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            results = []
            for production in grammar.productions(lhs=name):
                for children in sequences(production.rhs(), i, j):
                    results.append(Tree(name, children))
            active.discard(key)
            memo[key] = results
            return results

        def sequences(rhs, i, j):
            if not rhs:
                if i == j:
                    yield []
                return
            head, rest = rhs[0], rhs[1:]
            if isinstance(head, Nonterminal):
                for k in range(i, j + 1):
                    for sub in trees(head.symbol(), i, k):
                        for tail in sequences(rest, k, j):
                            yield [sub] + tail
            elif head == "":
                yield from sequences(rest, i, j)
            elif i < j and tokens[i] == head:
                for tail in sequences(rest, i + 1, j):
                    yield [head] + tail

        return trees(grammar.start().symbol(), 0, len(tokens))
