"""Shift-reduce parser: one left-to-right pass, reducing whenever a production's right-hand side is on top."""

from lingora.grammar import Nonterminal
from lingora.parse.chart import _check_tokens
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._run(tokens))

    def _run(self, tokens):
        grammar = self._grammar
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        start = grammar.start().symbol()
        # Each stack entry is (is_tree, value, node): value is the token or the nonterminal name.
        stack = []
        pos = 0
        seen = set()
        while True:
            reduced = False
            for production in productions:
                rhs = production.rhs()
                n = len(rhs)
                if len(stack) < n or not self._matches(stack[-n:], rhs):
                    continue
                name = production.lhs().symbol()
                signature = (pos, tuple(entry[1] for entry in stack[:-n]), name)
                if signature in seen:
                    continue
                seen.add(signature)
                node = Tree(name, [entry[2] for entry in stack[-n:]])
                stack[-n:] = [(True, name, node)]
                reduced = True
                break
            if reduced:
                continue
            if pos >= len(tokens):
                break
            stack.append((False, tokens[pos], tokens[pos]))
            pos += 1
        if pos == len(tokens) and len(stack) == 1 and stack[0][0] and stack[0][1] == start:
            return [stack[0][2]]
        return []

    @staticmethod
    def _matches(entries, rhs):
        for (is_tree, value, _), symbol in zip(entries, rhs):
            if isinstance(symbol, Nonterminal):
                if not (is_tree and value == symbol.symbol()):
                    return False
            elif is_tree or value != symbol:
                return False
        return True
