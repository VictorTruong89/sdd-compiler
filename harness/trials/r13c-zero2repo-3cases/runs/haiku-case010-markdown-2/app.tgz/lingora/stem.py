"""Stemmers: Porter, Lancaster, Snowball, regular-expression, Arabic light stemmers and WordNet lemmatizer."""

import os
import re

from lingora import data

_VOWELS = "aeiou"


# Porter ----------------------------------------------------------------------

def _is_consonant(word, i):
    if word[i] in _VOWELS:
        return False
    if word[i] == "y":
        return i == 0 or not _is_consonant(word, i - 1)
    return True


def _measure(stem):
    """Number of VC sequences in ``stem``."""
    m = 0
    seen_vowel = False
    for i in range(len(stem)):
        if _is_consonant(stem, i):
            if seen_vowel:
                m += 1
                seen_vowel = False
        else:
            seen_vowel = True
    return m


def _contains_vowel(stem):
    return any(not _is_consonant(stem, i) for i in range(len(stem)))


def _ends_double_consonant(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_consonant(word, len(word) - 1)


def _ends_cvc(word, lingora=False):
    if len(word) >= 3 and _is_consonant(word, len(word) - 3) and not _is_consonant(word, len(word) - 2) \
            and _is_consonant(word, len(word) - 1) and word[-1] not in "wxy":
        return True
    return lingora and len(word) == 2 and not _is_consonant(word, 0) and _is_consonant(word, 1)


_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}

_STEP2_RULES = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("izer", "ize"),
    ("ization", "ize"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("iveness", "ive"),
    ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
    ("entli", "ent"), ("alli", "al"), ("eli", "e"), ("ousli", "ous"),
]
_STEP3_RULES = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4_SUFFIXES = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ion", "ou", "ism",
                   "ate", "iti", "ous", "ive", "ize"]


class PorterStemmer:
    """Porter's suffix-stripping stemmer.

    ``mode`` selects ``LINGORA_EXTENSIONS`` (the default), ``MARTIN_EXTENSIONS`` or
    ``ORIGINAL_ALGORITHM``.
    """

    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    LINGORA_EXTENSIONS = "LINGORA_EXTENSIONS"

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.LINGORA_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    @property
    def _lingora(self):
        return self.mode == self.LINGORA_EXTENSIONS

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        stem = word.lower() if to_lowercase else word
        if self._lingora and stem in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[stem]
        if len(stem) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem

    def _step1a(self, word):
        if self._lingora and word.endswith("ies") and len(word) == 4:
            return word[:-1]
        if word.endswith("sses"):
            return word[:-2]
        if word.endswith("ies"):
            return word[:-2]
        if word.endswith("ss"):
            return word
        if word.endswith("s"):
            return word[:-1]
        return word

    def _step1b(self, word):
        if word.endswith("ied"):
            if self._lingora:
                return word[:-1] if len(word) == 4 else word[:-2]
            return self._step1b_rest(word)
        if word.endswith("eed"):
            return word[:-1] if _measure(word[:-3]) > 0 else word
        return self._step1b_rest(word)

    def _step1b_rest(self, word):
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                if _contains_vowel(stem):
                    return self._step1b_fixup(stem)
                return word
        return word

    def _step1b_fixup(self, stem):
        if stem.endswith(("at", "bl", "iz")):
            return stem + "e"
        if _ends_double_consonant(stem) and stem[-1] not in "lsz":
            return stem[:-1]
        if _measure(stem) == 1 and _ends_cvc(stem, self._lingora):
            return stem + "e"
        return stem

    def _step1c(self, word):
        if not word.endswith("y"):
            return word
        if self._lingora:
            if len(word) >= 3 and _is_consonant(word, len(word) - 2):
                return word[:-1] + "i"
            return word
        if _contains_vowel(word[:-1]):
            return word[:-1] + "i"
        return word

    def _step2(self, word):
        if self._lingora and word.endswith("alli") and _measure(word[:-4]) > 0:
            return self._step2(word[:-4] + "al")
        if self._lingora and word.endswith("logi"):
            return word[:-1] if _measure(word[:-3]) > 0 else word
        if self._lingora and word.endswith("fulli"):
            return word[:-1] if _measure(word[:-5]) > 0 else word
        rules = list(_STEP2_RULES)
        rules.append(("bli", "ble") if self._lingora else ("abli", "able"))
        for suffix, repl in rules:
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return word
        return word

    def _step3(self, word):
        for suffix, repl in _STEP3_RULES:
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                return stem + repl if _measure(stem) > 0 else word
        return word

    def _step4(self, word):
        for suffix in _STEP4_SUFFIXES:
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                if suffix == "ion" and not stem.endswith(("s", "t")):
                    return word
                return stem if _measure(stem) > 1 else word
        return word

    def _step5a(self, word):
        if word.endswith("e"):
            stem = word[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _ends_cvc(stem, self._lingora)):
                return stem
        return word

    def _step5b(self, word):
        if _measure(word) > 1 and _ends_double_consonant(word) and word.endswith("l"):
            return word[:-1]
        return word


# Lancaster -------------------------------------------------------------------

# Paice/Husk rules. Each rule: reversed ending, optional '*' (intact only), digit (letters removed),
# optional replacement letters, and '.' (stop) or '>' (continue).
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.",
    "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>", "lc1.",
    "lufi4y.", "luf3y.", "lu2.", "lai3y>", "lau3.", "la2.", "ll1.", "mui3.", "mu*2.", "msi3>",
    "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2+", "nn1.", "pihs4>",
    "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.",
    "si2.", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.", "ytic2s.",
    "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b>", "tcud1.", "tpm1.", "tl2>", "tt1.", "ta2>",
    "tu1.", "uq3.", "ue2>", "ue1.", "u*1.", "uy1.", "va1.", "vi2>", "vi1.", "vu3.", "wbsn3>",
    "xx1.", "ycn2t>", "yla2>", "yr1.", "yc1.", "zi2>", "zy1s.",
)
# NOTE: this table was reproduced from memory of the published Paice/Husk rules and has not been
# verified against the original rule file; treat its tail entries as provisional.


def _lancaster_rule_table():
    table = {}
    for index, text in enumerate(_LANCASTER_RULES):
        m = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>+]?)", text)
        if not m:
            raise ValueError("bad Lancaster rule %r" % text)
        ending, intact, remove, append, stop = m.groups()
        table.setdefault(ending[0], []).append((index, ending, bool(intact), int(remove), append, stop != ">"))
    return table


_LANCASTER_TABLE = _lancaster_rule_table()


def _lancaster_acceptable(stem):
    if not stem:
        return False
    if stem[0] in "aeiouy":
        return len(stem) >= 2
    return len(stem) >= 3 and any(c in "aeiouy" for c in stem)


class LancasterStemmer:
    """Paice/Husk stemmer."""

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        while True:
            applied = False
            for _, ending, needs_intact, remove, append, stop in sorted(
                _LANCASTER_TABLE.get(word[-1:], []), key=lambda rule: rule[0]
            ):
                reversed_ending = ending[::-1]
                if not word.endswith(reversed_ending):
                    continue
                if needs_intact and not intact:
                    continue
                candidate = word[: len(word) - remove] + append if remove <= len(word) else None
                if candidate is None or not _lancaster_acceptable(word[: len(word) - remove]):
                    continue
                word = candidate
                if stop:
                    return word
                intact = False
                applied = True
                break
            if not applied:
                return word


# Snowball --------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian", "italian",
    "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)

_P2_EXCEPTIONAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
    "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "only", "singly": "singl",
    "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_P2_EXCEPTIONAL_AFTER_STEP1A = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def _p2_vowel(c):
    return c in "aeiouy"


def _p2_region_after(word, start):
    """Index just past the first non-vowel, at or after ``start``, that follows a vowel."""
    for i in range(max(start, 1), len(word)):
        if _p2_vowel(word[i - 1]) and not _p2_vowel(word[i]):
            return i + 1
    return len(word)


def _p2_regions(word):
    r1 = None
    for prefix in ("gener", "commun", "arsen"):
        if word.startswith(prefix):
            r1 = len(prefix)
            break
    if r1 is None:
        r1 = _p2_region_after(word, 1)
    r2 = _p2_region_after(word, r1 + 1) if r1 < len(word) else len(word)
    return r1, r2


def _p2_short_syllable(word):
    if len(word) == 2:
        return _p2_vowel(word[0]) and not _p2_vowel(word[1])
    if len(word) >= 3:
        return (not _p2_vowel(word[-3]) and _p2_vowel(word[-2]) and not _p2_vowel(word[-1])
                and word[-1] not in "wxY")
    return False


def _p2_longest(word, suffixes):
    best = None
    for suffix in suffixes:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    return best


def _porter2(word):
    if word in _P2_EXCEPTIONAL:
        return _P2_EXCEPTIONAL[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and _p2_vowel(chars[i - 1]):
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[: -len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        stem = w[:-3]
        w = stem + ("i" if len(stem) > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        stem = w[:-1]
        if any(_p2_vowel(c) for c in stem[:-1]):
            w = stem
    if w in _P2_EXCEPTIONAL_AFTER_STEP1A:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if any(_p2_vowel(c) for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt":
                        w = w[:-1]
                    elif r1 >= len(w) and _p2_short_syllable(w):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and not _p2_vowel(w[-2]):
        w = w[:-1] + "i"

    # Step 2
    step2 = {
        "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent", "izer": "ize",
        "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al",
        "alli": "al", "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive",
        "iviti": "ive", "biliti": "ble", "bli": "ble", "ogi": "og", "fulli": "ful", "lessli": "less",
        "li": "",
    }
    suffix = _p2_longest(w, step2)
    if suffix is not None and len(w) - len(suffix) >= r1:
        if suffix == "ogi":
            if w[-4:-3] == "l":
                w = w[:-3] + "og"
        elif suffix == "li":
            if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                w = w[:-2]
        else:
            w = w[: -len(suffix)] + step2[suffix]

    # Step 3
    step3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic", "ical": "ic",
             "ful": "", "ness": "", "ative": ""}
    suffix = _p2_longest(w, step3)
    if suffix is not None:
        if suffix == "ative":
            if len(w) - len(suffix) >= r2:
                w = w[: -len(suffix)]
        elif len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + step3[suffix]

    # Step 4
    step4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ism", "ate",
             "iti", "ous", "ive", "ize", "ion")
    suffix = _p2_longest(w, step4)
    if suffix is not None and len(w) - len(suffix) >= r2:
        if suffix != "ion" or (len(w) > 3 and w[-4] in "st"):
            w = w[: -len(suffix)]

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


# Light stemmers for the other Snowball languages (suffix stripping only).
_LIGHT_SUFFIXES = {
    "danish": ("erne", "ene", "ens", "ets", "er", "en", "et", "es", "e", "s"),
    "dutch": ("heden", "en", "ene", "er", "s", "e"),
    "finnish": ("ssa", "ssä", "sta", "stä", "lla", "llä", "ta", "tä", "na", "nä", "a", "ä"),
    "french": ("issements", "ements", "ement", "ations", "ation", "ables", "able", "ées", "és", "es", "s", "e"),
    "german": ("ern", "em", "er", "en", "es", "e", "s"),
    "hungarian": ("ok", "ek", "ök", "ban", "ben", "on", "en", "ön", "k"),
    "italian": ("amento", "azione", "atrice", "menti", "mente", "i", "e", "a", "o"),
    "norwegian": ("heten", "ene", "ers", "ets", "er", "en", "et", "es", "e", "s"),
    "portuguese": ("amentos", "amento", "ações", "ação", "mente", "ões", "ão", "es", "s", "e", "a", "o"),
    "romanian": ("ilor", "elor", "ului", "ile", "le", "ul", "ă", "i", "e", "a"),
    "spanish": ("amientos", "imientos", "amiento", "imiento", "aciones", "ación", "mente", "es", "s", "a", "o", "e"),
    "swedish": ("heterna", "ornas", "orna", "erna", "arna", "ande", "ens", "ens", "ar", "er", "or", "en", "et", "a", "e"),
    "russian": ("иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими", "ой", "ей", "ий", "ый", "ую", "ью", "ах", "ях", "ов", "ев", "ам", "ям", "ом", "ем", "ы", "и", "а", "я", "у", "ю", "о", "е", "ь"),
    "arabic": ("ات", "ون", "ين", "ها", "ة"),
}


def _light_stem(language, word):
    for suffix in _LIGHT_SUFFIXES.get(language, ()):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[: -len(suffix)]
    return word


class SnowballStemmer:
    """Snowball stemmer for the languages in ``SNOWBALL_LANGUAGES``.

    ``english`` is Porter2 and ``porter`` is the original Porter algorithm. The other
    languages use a light suffix-stripping approximation rather than the full Snowball
    rules; see the module notes.
    """

    languages = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("Language %r is not supported by the Snowball stemmer" % (language,))
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            location = data.find(os.path.join("corpora", "stopwords", language))
            with open(location, encoding="utf-8") as handle:
                self._stopwords = {line.strip().lower() for line in handle if line.strip()}

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self._language == "english":
            return _porter2(word)
        if self._language == "porter":
            return PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM).stem(word)
        return _light_stem(self._language, word)


# Regular expression ----------------------------------------------------------

class RegexpStemmer:
    """Removes every match of ``regexp`` from the word and changes nothing else."""

    def __init__(self, regexp):
        self._regexp = re.compile(regexp)

    def stem(self, word):
        return self._regexp.sub("", word)


# Arabic light stemmers ---------------------------------------------------------

_ARABIC_PREFIXES = ("وال", "بال", "كال", "فال", "ال", "و")
_ARABIC_SUFFIXES = ("ها", "ات", "ون", "ين", "ان", "ه", "ة", "ي")


class ARLSTem:
    """Light Arabic stemmer: strips one common prefix and one common suffix (simplified)."""

    def stem(self, word):
        for prefix in _ARABIC_PREFIXES:
            if word.startswith(prefix) and len(word) - len(prefix) >= 3:
                word = word[len(prefix):]
                break
        for suffix in _ARABIC_SUFFIXES:
            if word.endswith(suffix) and len(word) - len(suffix) >= 3:
                return word[: -len(suffix)]
        return word


class ARLSTem2(ARLSTem):
    """Second light Arabic stemmer (simplified; shares ARLSTem's affix lists)."""


# WordNet lemmatizer ------------------------------------------------------------

_MORPHY = {
    "n": [("s", ""), ("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_WORDNET_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    """Lemmatizer backed by the packaged WordNet index files."""

    def __init__(self):
        self._root = data.find(os.path.join("corpora", "wordnet"))
        self._index = {}

    def _lemmas(self, pos):
        if pos not in self._index:
            lemmas = set()
            filename = os.path.join(self._root, "index." + _WORDNET_FILES[pos])
            if os.path.isfile(filename):
                with open(filename, encoding="utf-8", errors="replace") as handle:
                    for line in handle:
                        if line and not line.startswith(" "):
                            lemmas.add(line.split(" ", 1)[0])
            self._index[pos] = lemmas
        return self._index[pos]

    def lemmatize(self, word, pos="n"):
        if pos not in _WORDNET_FILES:
            raise ValueError("unknown WordNet part of speech %r" % (pos,))
        lemmas = self._lemmas(pos)
        if word in lemmas:
            return word
        for suffix, repl in _MORPHY[pos]:
            if word.endswith(suffix):
                candidate = word[: len(word) - len(suffix)] + repl
                if candidate in lemmas:
                    return candidate
        return word
