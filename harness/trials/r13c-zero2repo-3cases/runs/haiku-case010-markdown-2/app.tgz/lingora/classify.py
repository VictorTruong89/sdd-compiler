"""Text classifiers over labeled featuresets: Naive Bayes and decision tree, plus accuracy."""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_MISSING = object()


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes, dict)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    pairs = [(dict(featureset), label) for featureset, label in labeled_featuresets]
    return pairs


class NaiveBayesClassifier:
    """Naive Bayes with Lidstone-style smoothing (0.5 per value) over the observed values of each feature."""

    _SMOOTHING = 0.5

    def __init__(self, label_counts, feature_counts, value_bins, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts
        self._value_bins = value_bins
        self._total = total
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_training(labeled_featuresets)
        if not pairs:
            raise ValueError("cannot train a Naive Bayes classifier on no examples")
        label_counts = Counter()
        feature_counts = defaultdict(Counter)  # (label, name) -> Counter of values
        values = defaultdict(set)
        for featureset, label in pairs:
            label_counts[label] += 1
            for name, value in featureset.items():
                feature_counts[(label, name)][value] += 1
                values[name].add(value)
        bins = {name: len(vals) + 1 for name, vals in values.items()}
        return cls(label_counts, feature_counts, bins, len(pairs))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            log_prob = math.log(self._label_counts[label] / self._total)
            for name, value in featureset.items():
                if name not in self._value_bins:
                    continue
                counts = self._feature_counts.get((label, name), Counter())
                seen = sum(counts.values())
                numerator = counts.get(value, 0) + self._SMOOTHING
                denominator = seen + self._SMOOTHING * self._value_bins[name]
                log_prob += math.log(numerator / denominator)
            scores[label] = log_prob
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        top = max(scores.values())
        weights = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(weights.values())
        return ProbDist({label: weight / total for label, weight in weights.items()})

    def classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        return max(self._labels, key=lambda label: scores[label])


def _entropy(labels):
    counts = Counter(labels)
    total = len(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


class _Leaf:
    def __init__(self, label):
        self.label = label

    def classify(self, featureset):
        return self.label


class _Split:
    def __init__(self, name, children, default):
        self.name = name
        self.children = children
        self.default = default

    def classify(self, featureset):
        value = featureset.get(self.name, _MISSING)
        node = self.children.get(value)
        if node is None:
            return self.default.classify(featureset)
        return node.classify(featureset)


def _build(pairs, names):
    labels = [label for _, label in pairs]
    majority = Counter(labels).most_common(1)[0][0]
    if len(set(labels)) == 1:
        return _Leaf(majority)
    best_name = None
    best_gain = 0.0
    base = _entropy(labels)
    for name in names:
        groups = defaultdict(list)
        for featureset, label in pairs:
            groups[featureset.get(name, _MISSING)].append(label)
        remainder = sum(len(g) / len(labels) * _entropy(g) for g in groups.values())
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_gain = gain
            best_name = name
    if best_name is None:
        return _Leaf(majority)
    groups = defaultdict(list)
    for featureset, label in pairs:
        groups[featureset.get(best_name, _MISSING)].append((featureset, label))
    children = {value: _build(group, names) for value, group in groups.items() if value is not _MISSING}
    return _Split(best_name, children, _Leaf(majority))


class DecisionTreeClassifier:
    """Decision tree that splits on the feature test with the highest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_training(labeled_featuresets)
        if not pairs:
            raise ValueError("cannot train a decision tree on no examples")
        names = []
        for featureset, _ in pairs:
            for name in featureset:
                if name not in names:
                    names.append(name)
        return cls(_build(pairs, names))

    def classify(self, featureset):
        return self._root.classify(dict(featureset))


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` that ``classifier`` labels correctly."""
    gold = list(gold)
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
