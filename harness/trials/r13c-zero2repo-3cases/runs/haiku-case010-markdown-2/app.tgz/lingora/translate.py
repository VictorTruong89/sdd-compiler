"""BLEU: sentence-level bilingual evaluation understudy over token lists (Papineni et al., 2002)."""

import math
from collections import Counter

__all__ = ["SmoothingFunction", "bleu"]


class SmoothingFunction:
    """Smoothing applied to zero n-gram matches. Pass an instance (or its methods) as ``smoothing_function``."""

    def method0(self, numerators, denominators):
        """No smoothing: returns the precisions unchanged."""
        return [n / d if d else 0.0 for n, d in zip(numerators, denominators)]

    def method1(self, numerators, denominators, epsilon=0.1):
        """Replaces zero numerators (and orders the candidate is too short for) by ``epsilon``."""
        return [n / d if n > 0 and d else epsilon / max(d, 1) for n, d in zip(numerators, denominators)]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` (a token list) against ``references`` (token lists)."""
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    weights = [float(w) for w in weights]
    if not references or not weights:
        raise ValueError("bleu needs at least one reference and one weight")
    if not hypothesis:
        return 0.0

    numerators = []
    denominators = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                max_ref[gram] = max(max_ref[gram], count)
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        numerators.append(clipped)
        denominators.append(max(len(hypothesis) - n + 1, 0))

    if smoothing_function is None:
        precisions = [num / den if den else 0.0 for num, den in zip(numerators, denominators)]
    else:
        precisions = smoothing_function.method1(numerators, denominators) if isinstance(
            smoothing_function, SmoothingFunction) else smoothing_function(numerators, denominators)

    for w, p in zip(weights, precisions):
        if w > 0 and p <= 0:
            return 0.0

    hyp_len = len(hypothesis)
    ref_len = min((abs(len(r) - hyp_len), len(r)) for r in references)[1]
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / hyp_len)

    total_weight = sum(weights)
    log_mean = sum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0) / total_weight
    return brevity * math.exp(log_mean)
