"""Shell completion: registration scripts and suggestion output.

Instruction values are ``<shell>_source`` (print the registration script) and
``<shell>_complete`` (print suggestions for COMP_WORDS / COMP_CWORD).
"""

import os
import sys

from .core import Group
from .context import Context
from .exceptions import NoSuchOption, OptlynError
from .params import Option
from .types import CompletionItem, Choice, File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_DIR = "@dir"
PATH_ANY = "@path"


def _var(prog):
    return "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def _source_script(shell, prog, complete_var):
    if shell == "bash":
        func = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"{func}() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" "
            f"COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete {prog} ) )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F {func} {prog}\n"
        )
    if shell == "zsh":
        func = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"{func}() {{\n"
            f"    local -a completions\n"
            f"    completions=( ${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog})\"}} )\n"
            f"    _describe '{prog}' completions\n"
            f"}}\n"
            f"compdef {func} {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files -c {prog} -a "
            f"'(env {complete_var}=fish_complete COMP_WORDS=(commandline -cp) "
            f"COMP_CWORD=(commandline -ct) {prog})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{complete_var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        f"    Remove-Item Env:{complete_var}\n"
        f"}}\n"
    )


def _items_from(result):
    out = []
    for item in result or []:
        if isinstance(item, CompletionItem):
            out.append(item)
        else:
            out.append(CompletionItem(str(item)))
    return out


def _walk(root, ctx, words):
    """Walk completed words through groups. Returns (command, ctx, pending_option)."""
    cmd = root
    current = ctx
    i = 0
    pending = None
    while i < len(words):
        word = words[i]
        if word.startswith("-"):
            opts = {n: p for p in cmd.get_params(current) if isinstance(p, Option) for n in p.all_names}
            p = opts.get(word.partition("=")[0])
            if p is not None and not p.is_flag and "=" not in word:
                pending = p
                i += 1
                continue
            i += 1
            continue
        pending = None
        if isinstance(cmd, Group) and not cmd.chain:
            name, sub = cmd.resolve_command(current, word)
            if sub is not None:
                cmd = sub
                current = Context(sub, parent=current, info_name=name)
        i += 1
    return cmd, current, pending


def _param_suggestions(p, ctx, incomplete):
    if p is None:
        return []
    if p.shell_complete is not None:
        return _items_from(p.shell_complete(ctx, p, incomplete))
    if isinstance(p.type, (Choice,)):
        return _items_from(p.type.shell_complete(ctx, p, incomplete))
    if isinstance(p.type, (File, Path)):
        return _items_from(p.type.shell_complete(ctx, p, incomplete))
    return _items_from(p.type.shell_complete(ctx, p, incomplete))


def suggest(root, prog, words, cword):
    """Return CompletionItems for the word at ``cword`` of ``words`` (words[0] is the program)."""
    incomplete = words[cword] if cword < len(words) else ""
    completed = words[1:cword] if cword > 1 else []
    ctx = Context(root, info_name=prog)
    cmd, cctx, pending = _walk(root, ctx, completed)
    if pending is not None:
        return _param_suggestions(pending, cctx, incomplete)
    if incomplete.startswith("-"):
        out = []
        for p in cmd.get_params(cctx):
            if not isinstance(p, Option) or p.hidden:
                continue
            for name in p.all_names:
                if name.startswith(incomplete):
                    out.append(CompletionItem(name, help=p.help))
        return out
    out = []
    if isinstance(cmd, Group) and not cmd.chain:
        for name in cmd.list_commands(cctx):
            sub = cmd.get_command(cctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            out.append(CompletionItem(name, help=sub.short_help or sub.help))
    for arg in cmd.get_arguments():
        out.extend(_param_suggestions(arg, cctx, incomplete))
        break
    return out


def _render(items, shell):
    lines = []
    for item in items:
        if item.type == "dir":
            lines.append(f"{PATH_DIR} {item.value}")
        elif item.type == "file":
            lines.append(f"{PATH_ANY} {item.value}")
        elif shell in ("zsh", "fish") and item.help:
            lines.append(f"{item.value}\t{item.help}")
        else:
            lines.append(item.value)
    return "\n".join(lines) + ("\n" if lines else "")


# spec: N-000983, N-000985, N-000989, N-000990, N-000991, N-000702, N-000703
def run_completion(root, prog, instruction, args):
    """Handle a completion instruction. Returns the process exit status."""
    from .termui import echo

    if "_" not in instruction:
        return 1
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    complete_var = _var(prog)
    if action == "source":
        echo(_source_script(shell, prog, complete_var), nl=False)
        return 0
    raw_words = os.environ.get("COMP_WORDS", "")
    words = raw_words.split(" ") if raw_words else [prog]
    if shell == "fish":
        # For fish, COMP_CWORD is the incomplete token itself, possibly empty.
        incomplete = os.environ.get("COMP_CWORD", "")
        if words and words[-1] == incomplete and len(words) > 1:
            cword = len(words) - 1
        else:
            words.append(incomplete)
            cword = len(words) - 1
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
    try:
        items = suggest(root, prog, words, cword)
    except (OptlynError, NoSuchOption):
        items = []
    sys.stdout.write(_render(items, shell))
    sys.stdout.flush()
    return 0
