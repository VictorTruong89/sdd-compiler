"""Exception classes raised by Optlyn.

Exit statuses (standalone mode): usage errors exit 2, aborts and other
library-signalled errors exit 1, and author clean stops exit with the given code.
"""


class OptlynError(Exception):
    """Base class for errors Optlyn signals to the caller."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message


class UsageError(OptlynError):
    """Incorrect command-line usage. Exits with status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None, param=None):
        super().__init__(message)
        self.ctx = ctx
        self.param = param

    def format_message(self):
        return f"Error: {self.message}"


class BadParameter(UsageError):
    """A value was refused by a type, callback, or conversion function.

    The message is reported together with the parameter's identity.
    """

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx=ctx, param=param)
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class NoSuchOption(UsageError):
    """An option token that is not declared on the command."""


class MissingParameter(UsageError):
    """A required parameter was not supplied from any source."""


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error class (status 1)."""

    def __init__(self, filename, message):
        super().__init__(f"Could not open file {filename}: {message}")
        self.filename = filename


class Abort(OptlynError):
    """User declined, end-of-file on a prompt, interrupt, or author abort."""

    exit_code = 1

    def format_message(self):
        return "Aborted!"


class Exit(RuntimeError):
    """Author clean stop with a status code."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
