"""Parameter types and conversion."""

import datetime as _dt
import enum
import os
import uuid as _uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`. Override
    :meth:`shell_complete` to offer completion suggestions.
    """

    name = "text"
    envvar_list_splitter = None  # None means whitespace split
    is_composite = False

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def get_metavar(self, param=None):
        return None

    def get_missing_message(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def split_envvar_value(self, rv):
        if self.envvar_list_splitter is None:
            return rv.split()
        return rv.split(self.envvar_list_splitter)

    def __repr__(self):
        return self.name.upper()


class _FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that raises ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid", param, ctx)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum_type = choices
            self.choices = list(choices.__members__.values())
            self._keys = list(choices.__members__.keys())
        else:
            self.enum_type = None
            self.choices = list(choices)
            self._keys = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(self._keys) + "]"

    def _normalize(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        if value is None:
            self.fail("None is not a valid choice.", param, ctx)
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        text = str(value)
        norm = self._normalize(text)
        for key, choice in zip(self._keys, self.choices):
            if self._normalize(key) == norm:
                return choice
        expected = ", ".join(repr(k) for k in self._keys)
        self.fail(f"{value!r} is not {expected}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for key in self._keys:
            if key.startswith(incomplete):
                out.append(CompletionItem(key))
        return out


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        choices = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {choices}.", param, ctx)


class _RangeBase(ParamType):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _check(self, value, param, ctx):
        lo, hi = self.min, self.max
        if lo is not None:
            if self.min_open and value <= lo:
                if self.clamp:
                    return lo + self._step()
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
            if value < lo:
                if self.clamp:
                    return lo
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
        if hi is not None:
            if self.max_open and value >= hi:
                if self.clamp:
                    return hi - self._step()
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
            if value > hi:
                if self.clamp:
                    return hi
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
        return value

    def _desc(self):
        lo = "" if self.min is None else (">" if self.min_open else ">=") + f" {self.min}"
        hi = "" if self.max is None else ("<" if self.max_open else "<=") + f" {self.max}"
        return " and ".join(p for p in (lo, hi) if p)

    def _step(self):
        return 1


class IntRange(_RangeBase):
    name = "integer range"

    def convert(self, value, param=None, ctx=None):
        as_int = IntParamType().convert(value, param, ctx)
        return self._check(as_int, param, ctx)


class FloatRange(_RangeBase):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        super().__init__(min, max, min_open, max_open, clamp)

    def convert(self, value, param=None, ctx=None):
        as_float = FloatParamType().convert(value, param, ctx)
        return self._check(as_float, param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        from .exceptions import FileError
        from .fileio import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except (OSError, FileError) as exc:
            self.fail(f"'{value}': {getattr(exc, 'message', exc)}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(getattr(f, "close_intelligently", f.close))
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        rv = os.fsdecode(value) if isinstance(value, bytes) else str(value)
        if self.allow_dash and rv == "-":
            return self._out(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{rv!r} does not exist.", param, ctx)
            return self._out(rv)
        if not self.file_okay and not os.path.isdir(rv):
            self.fail(f"{rv!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{rv!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{rv!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{rv!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{rv!r} is not executable.", param, ctx)
        return self._out(rv)

    def _out(self, rv):
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is os.PathLike or getattr(self.path_type, "__name__", "") == "Path":
            import pathlib

            return pathlib.Path(rv)
        return self.path_type(rv)

    def shell_complete(self, ctx, param, incomplete):
        if self.file_okay and not self.dir_okay:
            kind = "dir"
        else:
            kind = "file"
        return [CompletionItem(incomplete, type=kind)]


class CompletionItem:
    """A suggestion with an optional help text and a type (``plain`` for values)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r})"


def convert_type(ty, default=None):
    """Turn a declared type (instance, class, function, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        if default is not None and not callable(default):
            return infer_type(default)
        return STRING
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if callable(ty):
        return _FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")


def infer_type(value):
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, (tuple, list)) and value:
        return infer_type(value[0])
    return STRING


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()
