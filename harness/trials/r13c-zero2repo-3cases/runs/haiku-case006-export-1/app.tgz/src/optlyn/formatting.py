"""Text wrapping helpers."""

import textwrap


def wrap_text(text, width=78, indent=0, preserve_paragraphs=False):
    """Wrap ``text`` to ``width`` columns and return the wrapped string.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace character is kept with its line breaks and
    the backspace line is stripped.
    """
    if text is None:
        return ""
    text = str(text)
    prefix = " " * indent
    width = max(width, 10)
    out = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [ln for ln in lines[1:]]
            out.extend(prefix + ln for ln in kept)
            out.append("")
            continue
        body = " ".join(ln.strip() for ln in lines if ln.strip())
        if not body:
            continue
        out.append(
            textwrap.fill(
                body,
                width=width,
                initial_indent=prefix,
                subsequent_indent=prefix,
            )
        )
        out.append("")
    if out and out[-1] == "":
        out.pop()
    return "\n\n".join(out) if preserve_paragraphs else "\n".join(out)


__all__ = ["wrap_text"]
