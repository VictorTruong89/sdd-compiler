"""Commands, groups, parsing, value resolution, dispatch, and standalone main()."""

import os
import sys

from .context import Context, ParameterSource, source_rank
from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .params import Argument, Option
from .types import Tuple as TupleType

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}
_OPTION_KINDS = ("flag", "on", "off", "count")
_CHAIN_SENTINEL = object()


class Command:
    """A leaf command: parses a slice of the command line and runs a callback."""

    def __init__(
        self,
        name=None,
        callback=None,
        params=None,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        context_settings=None,
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
        **extra,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help if help is not None else self._doc_help(callback)
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra

    @staticmethod
    def _doc_help(callback):
        doc = getattr(callback, "__doc__", None)
        if not doc:
            return None
        # A form feed truncates the help text; the form feed itself is not shown.
        doc = doc.split("\f", 1)[0].strip()
        return doc or None

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # --- program entry ----------------------------------------------------------

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run the command. ``args`` None means ``sys.argv[1:]``."""
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else self.name
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        if complete_var in os.environ:
            from .completion import run_completion

            code = run_completion(self, prog_name, os.environ[complete_var], list(args))
            if standalone_mode:
                sys.exit(code)
            return None
        settings = dict(self.context_settings)
        settings.update(extra)
        # spec: N-000842, N-000843, N-000844, N-000845, N-000846, N-000848
        ctx = Context(self, info_name=prog_name, **settings)
        try:
            rv = self._run_root(ctx, list(args))
        # spec: N-000792, N-000793, N-000794, N-000795, N-000704, N-000711, N-000714
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return None
        except Abort as exc:
            if not standalone_mode:
                raise
            _echo_err(exc.format_message())
            sys.exit(1)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            _report(exc)
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            _echo_err("Aborted!")
            sys.exit(1)
        finally:
            ctx.close()
        if standalone_mode:
            sys.exit(0)
        return rv

    def _run_root(self, ctx, args):
        with ctx:
            self._parse_into(ctx, args)
            return self.invoke(ctx)

    # --- context creation -------------------------------------------------------

    def make_context(self, info_name, args, parent=None, _defer_parse=False, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        if not _defer_parse:
            self._parse_into(ctx, list(args))
        return ctx

    def _parse_into(self, ctx, args):
        if not args and self.no_args_is_help:
            _echo_err(self.get_help(ctx))
            raise UsageError("", ctx=ctx)
        with ctx:
            ctx.args = self.parse_args(ctx, args)

    # --- invocation -------------------------------------------------------------

    def invoke(self, ctx):
        """Run after parsing: deprecation notice, then the callback."""
        if self.deprecated:
            _warn(f"The command '{self.name}' is deprecated.", self.deprecated)
        return self.run_callback(ctx)

    def run_callback(self, ctx):
        if self.callback is None:
            return None
        return self.callback(**self._callback_kwargs(ctx))

    def _callback_kwargs(self, ctx):
        return {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}

    # --- parameters -------------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            help_param = _auto_help_option(ctx, self.params)
            if help_param is not None:
                params.append(help_param)
        return params

    def get_arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    def get_help(self, ctx):
        from .help import format_command_help

        return format_command_help(self, ctx)

    # --- parsing ----------------------------------------------------------------

    def parse_args(self, ctx, args):
        """Parse ``args`` into ``ctx.params``; return the tokens left for a subcommand or extras."""
        params = self.get_params(ctx)
        opt_map = _option_map(ctx, params)
        occurrences, positional, rest = _tokenize(self, ctx, args, opt_map, is_group=False)
        eager_done = _run_eager(ctx, occurrences)
        leftover = _resolve_all(ctx, params, occurrences, positional, eager_done)
        if leftover and not ctx.allow_extra_args:
            raise UsageError(
                "Got unexpected extra argument" + ("s" if len(leftover) > 1 else "")
                + f" ({' '.join(leftover)})",
                ctx=ctx,
            )
        return leftover or rest


class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)

    # --- subcommand registry ----------------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Attaching a group beneath a chaining group is not allowed.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_deco

        def decorator(f):
            cmd = command_deco(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_deco

        def decorator(f):
            cmd = group_deco(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Return a decorator registering the group's result callback."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name):
        """Return (exported_name, command) for ``name``, or (None, None)."""
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return name, cmd
        normalize = ctx.token_normalize_func if ctx is not None else None
        if normalize is not None:
            wanted = normalize(name)
            for candidate in self.list_commands(ctx):
                if normalize(candidate) == wanted:
                    found = self.get_command(ctx, candidate)
                    if found is not None:
                        return candidate, found
        return None, None

    # --- parsing and dispatch ---------------------------------------------------

    def parse_args(self, ctx, args):
        params = self.get_params(ctx)
        opt_map = _option_map(ctx, params)
        occurrences, positional, rest = _tokenize(self, ctx, args, opt_map, is_group=True)
        eager_done = _run_eager(ctx, occurrences)
        leftover = _resolve_all(ctx, params, occurrences, positional, eager_done)
        if leftover and not ctx.allow_extra_args:
            raise UsageError(
                "Got unexpected extra argument" + ("s" if len(leftover) > 1 else "")
                + f" ({' '.join(leftover)})",
                ctx=ctx,
            )
        return rest

    def invoke(self, ctx):
        if self.deprecated:
            _warn(f"The command '{self.name}' is deprecated.", self.deprecated)
        if self.chain:
            return self._invoke_chain(ctx)
        rest = list(ctx.args)
        if rest:
            name, sub = self.resolve_command(ctx, rest[0])
            if sub is None:
                raise UsageError(f"No such command '{rest[0]}'.", ctx=ctx)
            ctx.invoked_subcommand = name
            self.run_callback(ctx)
            sub_ctx = sub.make_context(name, rest[1:], parent=ctx)
            with sub_ctx:
                sub_rv = sub.invoke(sub_ctx)
            if self._result_callback is not None:
                return self._result_callback(sub_rv, **ctx.params)
            return sub_rv
        ctx.invoked_subcommand = None
        if self.invoke_without_command:
            rv = self.run_callback(ctx)
            if self._result_callback is not None:
                return self._result_callback(rv, **ctx.params)
            return rv
        raise UsageError("Missing command.", ctx=ctx)

    def _invoke_chain(self, ctx):
        segments = []
        for tok in ctx.args:
            name, sub = self.resolve_command(ctx, tok)
            if sub is not None:
                segments.append((name, sub, []))
            elif segments:
                segments[-1][2].append(tok)
            else:
                raise UsageError(f"No such command '{tok}'.", ctx=ctx)
        ctx.invoked_subcommand = _CHAIN_SENTINEL
        self.run_callback(ctx)
        results = []
        for name, sub, seg_args in segments:
            sub_ctx = sub.make_context(name, seg_args, parent=ctx)
            with sub_ctx:
                results.append(sub.invoke(sub_ctx))
        if self._result_callback is not None:
            return self._result_callback(results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = []
        for source in self.sources:
            for n in source.list_commands(ctx):
                if n not in names:
                    names.append(n)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return self.commands.get(cmd_name)


# --- parsing helpers ------------------------------------------------------------


def _option_map(ctx, params):
    """Map each accepted token (flag names, on/off names) to (param, kind)."""
    mapping = {}

    def norm(name):
        return ctx.token_normalize_func(name) if ctx.token_normalize_func else name

    for p in params:
        if not isinstance(p, Option):
            continue
        if p.is_flag:
            on_kind = "on" if p.secondary_opts else "flag"
            for name in p.opts:
                mapping[norm(name)] = (p, on_kind)
            for name in p.secondary_opts:
                mapping[norm(name)] = (p, "off")
        else:
            kind = "count" if p.count else "value"
            for name in p.opts:
                mapping[norm(name)] = (p, kind)
    return mapping


def _tokenize(command, ctx, args, opt_map, is_group):
    """Split tokens into option occurrences, positional tokens, and group leftovers.

    Each occurrence is (param, kind, value, order). For a group, the first
    positional token after the group's own arguments is the subcommand name, and
    it and everything after are returned as the rest.
    """

    def norm(name):
        return ctx.token_normalize_func(name) if ctx.token_normalize_func else name

    prefixes = {"-"} | {key[0] for key in opt_map if key}
    occurrences = []
    positional = []
    interspersed = ctx.allow_interspersed_args and not is_group
    slots = sum(a.nargs for a in command.get_arguments() if a.nargs != -1)
    stop = False
    counter = 0
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        if not stop and tok == "--":
            stop = True
            continue
        option_shaped = (
            not stop and len(tok) > 1 and tok[0] in prefixes and (interspersed or not positional)
        )
        if not option_shaped:
            if is_group and not stop and len(positional) >= slots:
                return occurrences, positional, [tok] + args[i:]
            positional.append(tok)
            continue
        key, eq, inline = tok.partition("=")
        if tok.startswith("--") or norm(tok) in opt_map or (eq and norm(key) in opt_map):
            found = opt_map.get(norm(key))
            if found is None:
                if ctx.ignore_unknown_options:
                    positional.append(tok)
                    continue
                raise NoSuchOption(f"No such option: {key}", ctx=ctx)
            p, kind = found
            if kind in _OPTION_KINDS:
                if eq:
                    raise UsageError(f"Option '{key}' does not take a value.", ctx=ctx)
                occurrences.append((p, kind, None, counter))
            else:
                if eq:
                    value, ok = inline, True
                else:
                    value, i, ok = _take_value(args, i, p)
                occurrences.append((p, "value" if ok else "prompt", value if ok else None, counter))
            counter += 1
            continue
        # A stack of single-character flags, possibly ending in a value option.
        j = 1
        while j < len(tok):
            short = tok[0] + tok[j]
            found = opt_map.get(norm(short))
            if found is None:
                if ctx.ignore_unknown_options:
                    positional.append(tok[0] + tok[j:])
                    break
                raise NoSuchOption(f"No such option: {short}", ctx=ctx)
            p, kind = found
            if kind in _OPTION_KINDS:
                occurrences.append((p, kind, None, counter))
                counter += 1
                j += 1
                continue
            remainder = tok[j + 1 :]
            if remainder:
                occurrences.append((p, "value", remainder, counter))
            else:
                value, i, ok = _take_value(args, i, p)
                occurrences.append((p, "value" if ok else "prompt", value if ok else None, counter))
            counter += 1
            break
    return occurrences, positional, []


def _take_value(args, i, p):
    n = p.nargs if p.nargs != -1 else 1
    if i + n > len(args):
        return None, i, False
    taken = args[i : i + n]
    return (taken[0] if n == 1 else tuple(taken)), i + n, True


def _run_eager(ctx, occurrences):
    """Run eager flags that were typed, in the order typed. Returns the done set."""
    done = set()
    for p, kind, value, _order in sorted(occurrences, key=lambda o: o[3]):
        if p.is_eager and id(p) not in done:
            done.add(id(p))
            ctx.set_parameter_source(p.name, ParameterSource.COMMANDLINE)
            p.process_value(ctx, p.flag_value if p.is_flag else value)
    return done


def _resolve_all(ctx, params, occurrences, positional, eager_done):
    """Bind positional tokens, then resolve every parameter. Returns extra tokens."""
    arg_values, leftover = _bind_arguments(params, positional, ctx)
    ordered = sorted(params, key=lambda p: 0 if p.is_eager else 1)
    for p in ordered:
        if id(p) in eager_done:
            continue
        _resolve_one(ctx, p, occurrences, arg_values)
    return leftover


def _bind_arguments(params, positional, ctx):
    """Map argument id -> tokens (or None when missing); return (map, leftover)."""
    arguments = [p for p in params if isinstance(p, Argument)]
    values = {}
    idx = 0
    for k, arg in enumerate(arguments):
        if arg.nargs == -1:
            later = sum(a.nargs for a in arguments[k + 1 :] if a.nargs != -1)
            take = max(len(positional) - idx - later, 0)
            values[id(arg)] = positional[idx : idx + take]
            idx += take
            continue
        n = arg.nargs
        if len(positional) - idx >= n:
            tokens = positional[idx : idx + n]
            idx += n
            values[id(arg)] = tokens[0] if n == 1 else tuple(tokens)
        else:
            values[id(arg)] = None
            idx = len(positional)
    return values, positional[idx:]


def _resolve_one(ctx, p, occurrences, arg_values):
    """Find the value of ``p`` from its sources, run conversion and callbacks."""
    if isinstance(p, Argument):
        raw, source = _argument_raw(p, arg_values)
        prompt_needed = False
    else:
        raw, source, prompt_needed = _option_cmdline(p, occurrences)
        prompt_needed = prompt_needed or _prompt_flag(occurrences, p)
    if source is None and not prompt_needed:
        raw, source = _envvar_raw(ctx, p)
        if source is None:
            raw, source = _default_map_raw(ctx, p)
        if source is None:
            raw = p.get_default_value(ctx)
            source = ParameterSource.DEFAULT if raw is not None or p.is_flag or p.count else None
    if source is None and (p.multiple or p.nargs == -1) and not p.required:
        raw = ()

    if isinstance(p, Option) and p.prompt and (prompt_needed or (p.required and source is None)):
        raw = _prompt_for(p, raw)
        source = ParameterSource.PROMPT

    if source is None and p.required:
        if isinstance(p, Argument):
            raise MissingParameter(f"Missing argument '{p.name.upper()}'.", ctx=ctx, param=p)
        raise MissingParameter(f"Missing option '{p.opts[0]}'.", ctx=ctx, param=p)

    if p.deprecated and source == ParameterSource.COMMANDLINE:
        kind = "option" if isinstance(p, Option) else "argument"
        label = p.opts[0] if isinstance(p, Option) else p.name.upper()
        _warn(f"The {kind} '{label}' is deprecated.", p.deprecated)

    try:
        if p.is_flag or p.count:
            value = raw
            if p.callback is not None:
                value = p.callback(ctx, p, value)
        else:
            value = p.process_value(ctx, raw)
    except BadParameter as exc:
        if exc.param is None:
            exc.param = p
        if exc.ctx is None:
            exc.ctx = ctx
        raise

    if p.expose_value:
        prev = ctx.get_parameter_source(p.name)
        if prev is None or source_rank(source) >= source_rank(prev) or p.name not in ctx.params:
            ctx.params[p.name] = value
            ctx.set_parameter_source(p.name, source)
    return value


def _argument_raw(p, arg_values):
    tokens = arg_values.get(id(p))
    if tokens is None:
        return None, None
    if p.nargs == -1:
        return tuple(tokens), ParameterSource.COMMANDLINE
    return tokens, ParameterSource.COMMANDLINE


def _prompt_flag(occurrences, p):
    return any(kind == "prompt" for q, kind, _v, _o in occurrences if q is p)


def _option_cmdline(p, occurrences):
    mine = [(kind, value) for q, kind, value, _o in occurrences if q is p]
    if not mine:
        return None, None, False
    if p.is_flag:
        flags = [kind for kind, _v in mine if kind in ("flag", "on", "off")]
        if not flags:
            return None, None, False
        raw = False if flags[-1] == "off" else p.flag_value
        return raw, ParameterSource.COMMANDLINE, False
    if p.count:
        return sum(1 for kind, _v in mine if kind == "count"), ParameterSource.COMMANDLINE, False
    values = [v for kind, v in mine if kind == "value"]
    if not values:
        return None, None, False
    if p.multiple or p.nargs == -1:
        return tuple(values), ParameterSource.COMMANDLINE, False
    return values[-1], ParameterSource.COMMANDLINE, False


def _envvar_raw(ctx, p):
    if not (p.envvars or p.allow_from_autoenv):
        return None, None
    for name in p.get_envvar_names(ctx):
        value = os.environ.get(name)
        if not value:
            continue
        if p.is_flag and not p.count:
            parsed = _parse_flag_env(p, value, ctx)
            if parsed is None:
                continue
            return (p.flag_value if parsed else False), ParameterSource.ENVIRONMENT
        if p.multiple or p.nargs != 1:
            return tuple(p.split_envvar(value)), ParameterSource.ENVIRONMENT
        return value, ParameterSource.ENVIRONMENT
    return None, None


def _parse_flag_env(p, value, ctx):
    text = value.strip().lower()
    if text == "":
        return False
    if text in _TRUE:
        return True
    if text in _FALSE:
        return False
    if isinstance(p.flag_value, bool):
        raise BadParameter(f"{value!r} is not a valid boolean.", ctx=ctx, param=p)
    if text == str(p.flag_value).lower():
        return True
    return None


def _default_map_raw(ctx, p):
    dm = ctx.default_map
    if not isinstance(dm, dict) or p.name not in dm:
        return None, None
    value = dm[p.name]
    if isinstance(value, str):
        if p.nargs != 1 or isinstance(p.type, TupleType):
            return tuple(value.split()), ParameterSource.DEFAULT_MAP
        if p.multiple:
            raise BadParameter(
                f"{p.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx=ctx, param=p
            )
    return value, ParameterSource.DEFAULT_MAP


def _prompt_for(p, default):
    from .termui import prompt

    text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").title()
    return prompt(
        text,
        default=default,
        hide_input=p.hide_input,
        confirmation_prompt=p.confirmation_prompt,
        type=p.type,
    )


def _auto_help_option(ctx, author_params):
    """The automatic help option, minus any names an author option already uses."""
    from .decorators import _help_callback

    taken = set()
    for p in author_params:
        if isinstance(p, Option):
            taken.update(p.all_names)
    names = [n for n in ctx.help_option_names if n not in taken]
    if not names:
        return None
    return Option(
        names,
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_help_callback,
    )


# --- messages ---------------------------------------------------------------------


def _echo_err(message):
    from .termui import echo

    echo(message, err=True)


def _warn(message, note):
    text = f"DeprecationWarning: {message}"
    if isinstance(note, str):
        text += f" {note}"
    _echo_err(text)


# spec: N-000800, N-000801, N-000802, N-000707, N-000708, N-000723
def _report(exc):
    """Standalone error report: usage errors show the usage hint, then the message."""
    if isinstance(exc, UsageError):
        ctx = exc.ctx
        if ctx is not None:
            prog = ctx.command_path()
            _echo_err(f"Usage: {prog} {ctx.command.options_metavar}")
            _echo_err(f"Try '{prog} --help' for help.")
        if exc.message:
            _echo_err("")
            _echo_err(exc.format_message())
        return
    _echo_err(exc.format_message())
