"""File and standard-stream opening with the dash-as-stdin/stdout rule."""

import os
import sys
import tempfile


class _StdStream:
    """Wraps a standard stream so closing it does not close the real stream."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        pass

    def close_intelligently(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class LazyFile:
    """Opens the real file on first I/O (used for lazy write mode)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None

    def _open(self):
        if self._f is not None:
            return self._f
        try:
            if self.atomic:
                directory = os.path.dirname(os.path.abspath(self.name))
                fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-")
                os.close(fd)
                target = self._tmp
            else:
                target = self.name
            self._f = open(target, self.mode, **self._kwargs())
        except OSError as exc:
            from .exceptions import FileError

            raise FileError(self.name, exc.strerror or str(exc)) from exc
        return self._f

    def _kwargs(self):
        if "b" in self.mode:
            return {}
        return {"encoding": self.encoding, "errors": self.errors}

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._f is None:
            return
        self._f.close()
        if self.atomic and self._tmp is not None:
            os.replace(self._tmp, self.name)

    def close_intelligently(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


# spec: N-000522, N-000524, N-000527, N-000529, N-000536, N-000537, N-000580
def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` is stdin for reading and stdout for writing.

    Read-mode files open immediately. Write-mode files open on first I/O when
    ``lazy`` is true, otherwise they are opened (and truncated) now.
    """
    filename = os.fspath(filename) if not isinstance(filename, (str, bytes)) else filename
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if filename == "-":
        stream = sys.stdin if "r" in mode else sys.stdout
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return _StdStream(stream)
    if lazy and "w" in mode:
        return LazyFile(filename, mode, encoding, errors, atomic)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    if atomic and "w" in mode:
        f = LazyFile(filename, mode, encoding, errors, atomic)
        f._open()
        return f
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    try:
        return open(filename, mode, **kwargs)
    except OSError as exc:
        from .exceptions import FileError

        raise FileError(filename, exc.strerror or str(exc)) from exc


__all__ = ["open_file", "LazyFile"]
