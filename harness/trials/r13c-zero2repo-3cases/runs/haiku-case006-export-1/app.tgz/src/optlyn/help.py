"""Help page generation: usage line, description, arguments, options, subcommands, epilog."""

import shutil
import textwrap

from .params import Argument, Option
from .types import Choice


def _wrap_width(ctx):
    if ctx.terminal_width:
        return max(int(ctx.terminal_width), 20)
    auto = shutil.get_terminal_size(fallback=(80, 24)).columns
    return max(min(auto, ctx.max_content_width), 20)


def _first_sentence(text):
    if not text:
        return ""
    text = " ".join(text.split())
    end = text.find(". ")
    return text[: end + 1] if end != -1 else text


def _usage_tail(cmd):
    parts = []
    if cmd.options_metavar:
        parts.append(cmd.options_metavar)
    for arg in cmd.get_arguments():
        label = arg.get_display_metavar()
        if arg.nargs == -1:
            token = f"{label}..."
            parts.append(token if arg.required else f"[{token}]")
        elif arg.nargs > 1:
            parts.append(" ".join([label] * arg.nargs))
        else:
            parts.append(label if arg.required else f"[{label}]")
    if hasattr(cmd, "commands"):
        if cmd.chain:
            parts.append("[COMMAND [ARGS]...]...")
        elif cmd.invoke_without_command:
            parts.append("[COMMAND] [ARGS]...")
        else:
            parts.append("COMMAND [ARGS]...")
    return " ".join(parts)


def _option_extras(p, ctx):
    extras = []
    show = p.show_default if p.show_default is not None else ctx.show_default
    if show and p.has_default():
        if isinstance(p.show_default, str):
            extras.append(f"[default: {p.show_default}]")
        else:
            value = p.get_default_value(ctx)
            if not (p.is_flag and value is False) and value is not None:
                extras.append(f"[default: {value}]")
    if p.show_envvar and p.envvars:
        extras.append(f"[env var: {', '.join(p.envvars)}]")
    if isinstance(p.type, Choice):
        extras.append("[choices: " + "|".join(p.type._keys) + "]")
    if p.deprecated:
        extras.append("(deprecated)")
    return extras


def _entry(label, text, width, indent=2, gap=2):
    """One aligned help entry: a label column followed by wrapped text."""
    if not text:
        return " " * indent + label
    label_pad = min(max(len(label) + gap, 1), 30)
    body_width = max(width - indent - label_pad, 20)
    wrapped = textwrap.wrap(text, width=body_width) or [""]
    first = " " * indent + label.ljust(label_pad) + wrapped[0]
    rest = [" " * (indent + label_pad) + line for line in wrapped[1:]]
    return "\n".join([first] + rest)


def _section(title, entries):
    if not entries:
        return []
    return [title + ":"] + entries + [""]


# spec: N-000812, N-000813, N-000816, N-000820, N-000822, N-000827, N-000828
def format_command_help(cmd, ctx):
    """Return the help page for ``cmd`` as one string."""
    width = _wrap_width(ctx)
    lines = []
    lines.append("Usage: " + " ".join(s for s in [ctx.command_path(), _usage_tail(cmd)] if s))
    lines.append("")
    description = cmd.help or ""
    if cmd.deprecated:
        note = cmd.deprecated if isinstance(cmd.deprecated, str) else ""
        description = (description + "\n\n" if description else "") + "(Deprecated)" + (f" {note}" if note else "")
    if description:
        for para in description.split("\n\n"):
            body = " ".join(para.split())
            if body:
                lines.append(textwrap.fill(body, width=width))
                lines.append("")

    params = cmd.get_params(ctx)
    arg_entries = []
    for arg in cmd.get_arguments():
        if arg.help and not arg.hidden:
            arg_entries.append(_entry(arg.get_display_metavar(), arg.help, width))
    lines.extend(_section("Positional arguments", arg_entries))

    opt_entries = []
    for p in params:
        if not isinstance(p, Option) or p.hidden:
            continue
        label = p.get_help_names()
        metavar = p.get_help_metavar()
        if metavar:
            label = f"{label} {metavar}"
        text = " ".join(part for part in [p.help or "", *_option_extras(p, ctx)] if part)
        opt_entries.append(_entry(label, text, width))
    lines.extend(_section("Options", opt_entries))

    if hasattr(cmd, "commands"):
        cmd_entries = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            short = sub.short_help or _first_sentence(sub.help)
            cmd_entries.append(_entry(name, short, width))
        lines.extend(_section("Commands", cmd_entries))

    if cmd.epilog:
        lines.append(textwrap.fill(" ".join(cmd.epilog.split()), width=width))
        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


__all__ = ["format_command_help", "Argument"]
