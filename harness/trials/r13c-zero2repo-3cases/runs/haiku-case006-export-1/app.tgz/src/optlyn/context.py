"""Invocation context, value sources, and the thread-local current-context stack."""

import enum
import threading

from .exceptions import Abort, Exit

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Ordered from most to least explicit."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


def source_rank(source):
    return _SOURCE_RANK.get(source, 0)


class Context:
    """Per-invocation state. Built by the library, one per command run."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        auto_envvar_prefix=None,
        **extra,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self.extra = extra
        self._sources = {}
        self._close_callbacks = []
        self._resources = []
        self._depth_stack = []

        def inherit(value, attr, default=None):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return default

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        if self.default_map is None and parent is not None and parent.default_map is not None:
            self.default_map = self._child_map(parent.default_map, info_name)
        self.terminal_width = inherit(terminal_width, "terminal_width")
        self.max_content_width = inherit(max_content_width, "max_content_width", 80)
        self.help_option_names = inherit(help_option_names, "help_option_names", ["--help"])
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func")
        self.color = inherit(color, "color")
        self.show_default = inherit(show_default, "show_default", False)
        self.allow_extra_args = inherit(allow_extra_args, "allow_extra_args", False)
        self.ignore_unknown_options = inherit(
            ignore_unknown_options, "ignore_unknown_options", False
        )
        self.allow_interspersed_args = inherit(
            allow_interspersed_args, "allow_interspersed_args", True
        )
        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix")

    @staticmethod
    def _child_map(parent_map, name):
        if not isinstance(parent_map, dict) or name is None:
            return None
        value = parent_map.get(name)
        return value if isinstance(value, dict) else None

    def command_path(self):
        """Program name followed by subcommand names down to this context."""
        names = []
        node = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def envvar_path_names(self):
        """Subcommand names on the path below the top-level command (top excluded)."""
        names = []
        node = self
        while node is not None and node.parent is not None:
            names.append(node.info_name)
            node = node.parent
        return list(reversed(names))

    # --- resolution helpers -------------------------------------------------

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if type(node.obj) is object_type:
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

# spec: N-000951, N-000453
    def get_parameter_source(self, name):
        """Return the ParameterSource for ``name``, or None when it is not declared."""
        return self._sources.get(name)

    def set_parameter_source(self, name, source):
        self._sources[name] = source

    # --- callbacks and cleanup ----------------------------------------------

    def call_on_close(self, func):
        self._close_callbacks.append(func)
        return func

    def with_resource(self, cm):
        """Enter the context manager ``cm``, keep it open until close(), return its value."""
        value = cm.__enter__()
        self._resources.append(cm)
        return value

    def close(self):
        """Run every registered cleanup, last registered first."""
        while self._resources:
            self._resources.pop().__exit__(None, None, None)
        while self._close_callbacks:
            self._close_callbacks.pop()()

    # --- invocation from callbacks -------------------------------------------

    def invoke(self, other, **values):
        """Run ``other`` with exactly the caller's values; unspecified params use defaults."""
        return _run_command_with_values(self, other, values)

    def forward(self, other, **values):
        """Run ``other`` with this command's values, overridden by ``values``."""
        merged = dict(self.params)
        merged.update(values)
        return _run_command_with_values(self, other, merged)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort("Aborted!")

    # --- current-context protocol --------------------------------------------

    def __enter__(self):
        stack = _stack()
        stack.append(self)
        self._depth_stack.append(len(stack))
        return self

    def __exit__(self, exc_type, exc, tb):
        stack = _stack()
        depth = self._depth_stack.pop()
        del stack[depth - 1 :]
        return False


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread; raise or return None when none."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def _run_command_with_values(caller, other, values):
    sub = other.make_context(other.name, [], parent=caller, _defer_parse=True)
    sub.obj = caller.obj
    for param in other.params:
        if param.name in values:
            sub.params[param.name] = values[param.name]
        else:
            sub.params[param.name] = param.get_default_value(sub)
        sub.set_parameter_source(param.name, None)
    with sub:
        return other.run_callback(sub)


def pass_context(f):
    """Decorator: pass the current Context as the first positional argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return _wraps(f, new_func)


def pass_obj(f):
    """Decorator: pass the current context's ``obj`` as the first positional argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return _wraps(f, new_func)


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator passing the nearest object of ``object_type``."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
                if obj is None:
                    raise RuntimeError(
                        f"Managed to invoke callback without a context object of type "
                        f"{object_type.__name__!r} existing."
                    )
            return f(obj, *args, **kwargs)

        return _wraps(f, new_func)

    return decorator


def _wraps(original, wrapper):
    wrapper.__name__ = getattr(original, "__name__", "wrapper")
    wrapper.__doc__ = getattr(original, "__doc__", None)
    wrapper.__wrapped__ = original
    return wrapper
