"""Parameter objects: options and arguments."""

from .exceptions import BadParameter
from .types import BOOL, FLOAT, INT, STRING, Tuple, convert_type, infer_type

PREFIX_CHARS = ("-",)


class Parameter:
    """Base class for options and arguments.

    ``name`` is the destination; ``metavar`` is the author string or None.
    """

    param_type_name = "parameter"
    is_flag = False
    count = False
    prompt = False
    opts = ()
    secondary_opts = ()

    def __init__(
        self,
        param_decls=None,
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=None,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
        allow_from_autoenv=True,
    ):
        self.param_decls = list(param_decls or [])
        self.name = None
        self.metavar = metavar
        self.help = help
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.deprecated = deprecated
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.shell_complete = shell_complete
        self.multiple = multiple
        self.required = required
        self._default = default
        self._type_arg = type
        if envvar is None:
            self.envvars = []
        elif isinstance(envvar, str):
            self.envvars = [envvar]
        else:
            self.envvars = list(envvar)
        self._nargs_arg = nargs
        self.nargs = 1 if nargs is None else nargs

        if self.deprecated and self.required:
            raise TypeError(f"{self.__class__.__name__} cannot be deprecated and required.")

    # --- declared shape -----------------------------------------------------

    def _finalize_type(self):
        """Resolve ``type`` to a ParamType, inferring it from the default when needed."""
        if self._type_arg is None and self._default is not None and not callable(self._default):
            self.type = infer_type(self._default)
        else:
            self.type = convert_type(self._type_arg)
        if isinstance(self.type, Tuple):
            self.nargs = len(self.type.types)

    @property
    def takes_repeated_values(self):
        return self.multiple or self.nargs == -1

    def has_default(self):
        return self._default is not None

    def get_default_value(self, ctx):
        """Raw declared default: callables are invoked; the value is not converted."""
        default = self._default
        if callable(default):
            default = default()
        return default

    def get_error_hint(self, ctx=None):
        return f"'{self.name}'"

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        metavar = self.type.get_metavar(self)
        if metavar is None:
            metavar = self.type.name.upper()
        return metavar

    # --- conversion ---------------------------------------------------------

    def _convert_occurrence(self, value, ctx):
        """Convert one occurrence: a scalar, a fixed-arity tuple, or a Tuple-typed value."""
        if isinstance(self.type, Tuple):
            return self.type.convert(tuple(value), self, ctx)
        if self.nargs != 1:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    f"{self.get_error_hint(ctx)} needs {self.nargs} values.", ctx=ctx, param=self
                )
            return tuple(self.type.convert(v, self, ctx) for v in value)
        return self.type.convert(value, self, ctx)

    def convert_value(self, value, ctx):
        """Convert the raw value: a single occurrence, or a sequence of occurrences."""
        if value is None:
            return None
        if self.multiple or self.nargs == -1:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.",
                    ctx=ctx,
                    param=self,
                )
            if self.nargs == -1:
                return tuple(self.type.convert(v, self, ctx) for v in value)
            return tuple(self._convert_occurrence(v, ctx) for v in value)
        return self._convert_occurrence(value, ctx)

    def process_value(self, ctx, value):
        """Run the parameter callback; the callback may replace or refuse the value."""
        value = self.convert_value(value, ctx)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def split_envvar(self, raw):
        if self.multiple or self.nargs != 1 or self.nargs == -1:
            return self.type.split_envvar_value(raw)
        return raw

    def get_envvar_names(self, ctx):
        names = list(self.envvars)
        # Only options take the automatic prefix; arguments need explicit names.
        if (
            self.param_type_name == "option"
            and self.allow_from_autoenv
            and ctx is not None
            and ctx.auto_envvar_prefix is not None
        ):
            parts = [ctx.auto_envvar_prefix] + ctx.envvar_path_names() + [self.name]
            auto = "_".join(str(p).replace("-", "_").upper() for p in parts if p)
            names.append(auto)
        return names

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls=None,
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        required=False,
        **attrs,
    ):
        super().__init__(param_decls, required=required, **attrs)
        self.opts = []
        self.secondary_opts = []
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.count = count
        self.flag_value_arg = flag_value
        self.is_flag_arg = is_flag
        self._parse_decls()
        self._resolve_flag_shape()
        self._finalize_type()
        if self.count:
            self.type = INT
        if self.is_flag and self.type is not BOOL and self.flag_value_arg is None and not self.count:
            self.type = BOOL
        self.flag_value = self._compute_flag_value()
        if self.count and self._default is None:
            self._default = 0
        if self.is_flag and self._default is None and not self.count:
            self._default = False
        if self.count and self.is_flag:
            raise TypeError("Counting options cannot be flags.")
        if self.deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.nargs != -1 and self.nargs < 1:
            raise TypeError("Option nargs must be a positive integer.")
        if self.name is None:
            raise TypeError("Option needs a destination name or at least one flag name.")

    # --- declaration parsing --------------------------------------------------

    def _parse_decls(self):
        dest = None
        for decl in self.param_decls:
            if decl and decl[0] in PREFIX_CHARS + ("/", "+"):
                if "/" in decl[1:] and decl[0] != "/":
                    on, off = decl.split("/", 1)
                    self.opts.append(on)
                    self.secondary_opts.append(off)
                else:
                    self.opts.append(decl)
            elif dest is None:
                dest = decl
        if not self.opts:
            raise TypeError("Option needs at least one flag name.")
        if dest is None:
            dest = self._infer_dest()
        self.name = dest.replace("-", "_")

    def _infer_dest(self):
        """Destination from the flag names: the first long name, otherwise the first short."""
        names = self.opts + self.secondary_opts
        longs = [n for n in names if n.startswith("--")]
        pick = (longs or names)[0]
        return pick.lstrip("-+/").replace("-", "_")

    def _resolve_flag_shape(self):
        if self.count:
            self.is_flag = False
        elif self.is_flag_arg is None:
            self.is_flag = bool(
                self.secondary_opts
                or self.flag_value_arg is not None
                or self._type_arg is BOOL
                or isinstance(self._default, bool)
            )
        else:
            self.is_flag = bool(self.is_flag_arg)
        if self.secondary_opts and not self.is_flag:
            self.is_flag = True
        if self.is_flag:
            self.secondary_flag = bool(self.secondary_opts)
        else:
            self.secondary_flag = False

    def _compute_flag_value(self):
        if self.flag_value_arg is not None:
            return self.flag_value_arg
        if self.is_flag:
            return True
        return None

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    @property
    def is_bool_flag(self):
        return self.is_flag and self.flag_value_arg is None

    @property
    def is_multi(self):
        return self.multiple or self.nargs != 1

    def get_error_hint(self, ctx=None):
        return f"'{self.opts[0] if self.opts else self.name}'"

    def get_help_names(self):
        return ", ".join(self.opts + self.secondary_opts)

    def get_help_metavar(self):
        if self.is_flag or self.count:
            return None
        return self.get_metavar()


class Argument(Parameter):
    """A positional parameter bound in declaration order."""

    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, nargs=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1 or not decls[0] or decls[0][0] in PREFIX_CHARS:
            raise TypeError("An argument takes a single destination name.")
        if nargs is not None and nargs != -1 and nargs < 1:
            raise TypeError("Argument nargs must be a positive integer or -1.")
        default = attrs.get("default")
        if required is None:
            required = default is None and not attrs.get("optional", False)
        attrs.pop("optional", None)
        super().__init__(decls, required=required, nargs=nargs, **attrs)
        self.name = decls[0].replace("-", "_")
        if self.nargs == -1 and self.multiple:
            raise TypeError("A variadic argument cannot be repeatable.")
        self._finalize_type()
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")
        if self.required and self._default is not None:
            raise TypeError("A required argument cannot have a default.")

    def get_error_hint(self, ctx=None):
        return self.name.upper()

    def get_metavar_default(self):
        return self.name.upper()

    def get_display_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()


__all__ = [
    "Parameter",
    "Option",
    "Argument",
    "STRING",
    "FLOAT",
    "INT",
]
