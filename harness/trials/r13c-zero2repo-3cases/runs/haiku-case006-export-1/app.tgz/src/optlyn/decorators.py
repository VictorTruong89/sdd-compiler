"""Declaration decorators and ready-made options."""

import importlib.metadata
import re

from .core import Command, CommandCollection, Group
from .exceptions import Exit
from .params import Argument, Option
from .termui import confirm, echo

_SUFFIX_RE = re.compile(r"_(command|cmd|group|grp)$")


def _derive_name(func):
    name = func.__name__
    name = _SUFFIX_RE.sub("", name)
    return name.lower().replace("_", "-")


def _take_params(f):
    """Declarations attached to ``f``; moved onto the command and removed from ``f``."""
    pending = getattr(f, "__optlyn_params__", [])
    params = list(reversed(pending))
    f.__optlyn_params__ = []
    return params


def _make_command(cls, name, attrs):
    def decorator(f):
        if not callable(f) or isinstance(f, Command):
            raise TypeError("command/group decorators apply to a function.")
        params = _take_params(f)
        cmd_name = name if name is not None else _derive_name(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def command(name=None, cls=None, **attrs):
    """Decorator turning a function into a Command (or an instance of ``cls``)."""
    if callable(name) and cls is None and not attrs:
        return _make_command(Command, None, {})(name)
    return _make_command(cls or Command, name, attrs)


def group(name=None, cls=None, **attrs):
    """Decorator turning a function into a Group (or an instance of ``cls``)."""
    if callable(name) and cls is None and not attrs:
        return _make_command(Group, None, {})(name)
    chosen = cls or Group
    return _make_command(chosen, name, attrs)


def _attach(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)
    return f


def option(*param_decls, cls=None, **attrs):
    """Decorator attaching an option to the function or command it decorates."""
    option_cls = cls or Option

    def decorator(f):
        return _attach(f, option_cls(list(param_decls), **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Decorator attaching a positional argument."""
    arg_cls = cls or Argument

    def decorator(f):
        return _attach(f, arg_cls(list(param_decls), **attrs))

    return decorator


# --- ready-made options -------------------------------------------------------


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.command.get_help(ctx))
    raise Exit(0)


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints the help page and exits."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


def _distribution_version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        pass
    mapping = importlib.metadata.packages_distributions()
    for dist in mapping.get(name, []):
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager version flag. ``version`` None means detect it from ``package_name``."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        ver = version
        if ver is None and package_name:
            ver = _distribution_version(package_name)
        if ver is None:
            ver = "unknown"
        prog = prog_name or ctx.find_root().info_name or ""
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ver})
        raise Exit(0)

    kwargs["callback"] = callback

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose printed identity is exactly ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")

    def option_callback(ctx, param, value):
        if not value:
            return
        echo(callback(ctx))
        raise Exit(0)

    kwargs["callback"] = option_callback

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default flag ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("required", True)

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes flag (default ``--yes``). Omitted, it asks; a no aborts; the value is not passed."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, abort=True)
        return True

    kwargs["callback"] = callback
    kwargs["prompt"] = question

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


__all__ = [
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "CommandCollection",
    "_help_callback",
]
