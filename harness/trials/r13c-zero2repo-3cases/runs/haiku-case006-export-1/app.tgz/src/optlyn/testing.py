"""In-process runner: invoke a command with tokens and capture its output."""

import contextlib
import io
import os
import shutil
import sys
import tempfile

from . import termui


class _Combined:
    """Shared, ordered log of text written to stdout and stderr."""

    def __init__(self):
        self.parts = []


class _CaptureStream(io.TextIOBase):
    def __init__(self, combined, label, charset):
        super().__init__()
        self._combined = combined
        self._label = label
        self._text = io.StringIO()
        self._bytes = io.BytesIO()
        self.buffer = self._BufferProxy(self)
        self._charset = charset

    class _BufferProxy:
        def __init__(self, owner):
            self._owner = owner

        def write(self, data):
            self._owner._bytes.write(data)
            self._owner._combined.parts.append(data.decode(self._owner._charset, "replace"))
            return len(data)

        def flush(self):
            pass

    def writable(self):
        return True

    def write(self, s):
        if isinstance(s, bytes):
            return self.buffer.write(s)
        self._text.write(s)
        self._bytes.write(s.encode(self._charset, "replace"))
        self._combined.parts.append(s)
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    @property
    def encoding(self):
        return self._charset

    def getvalue(self):
        return self._text.getvalue()

    def getbytes(self):
        return self._bytes.getvalue()


class _Stdin(io.StringIO):
    """Input stream that can echo the lines it actually hands out."""

    def __init__(self, data, echo_to=None):
        super().__init__(data)
        self._echo_to = echo_to

    def readline(self, *args):
        line = super().readline(*args)
        if self._echo_to is not None and line:
            self._echo_to.write(line)
        return line

    def read(self, *args):
        data = super().read(*args)
        if self._echo_to is not None and data:
            self._echo_to.write(data)
        return data


class Result:
    """Outcome of CliRunner.invoke."""

    def __init__(self, runner_output, stdout, stderr, exit_code, exception, return_value=None):
        self._combined = runner_output
        self._stdout = stdout
        self._stderr = stderr
        self.exit_code = exit_code
        self.exception = exception
        self.return_value = return_value

    @property
    def output(self):
        return "".join(self._combined.parts)

    @property
    def stdout(self):
        return self._stdout.getvalue()

    @property
    def stderr(self):
        return self._stderr.getvalue()

    @property
    def stdout_bytes(self):
        return self._stdout.getbytes()

    @property
    def stderr_bytes(self):
        return self._stderr.getbytes()

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _FdCapture:
    """Bytes captured from a real file descriptor."""

    def __init__(self):
        self._data = b""
        self._charset = "utf-8"

    def getvalue(self):
        return self._data.decode("utf-8", "replace")

    def getbytes(self):
        return self._data


def out_stream(capture):
    return io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding="utf-8", errors="replace", write_through=True)


def err_stream(capture):
    return io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding="utf-8", errors="replace", write_through=True)


class CliRunner:
    """Runs a command in-process and captures standard output and error."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        combined = _Combined()
        data = input.decode(self.charset) if isinstance(input, bytes) else (input or "")
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        saved_echo = termui._runner_echo
        if self.capture == "fd":
            out, err, restore = self._fd_streams(combined)
            stdin = _Stdin(data, echo_to=sys.stdout if self.echo_stdin else None)
            sys.stdin, sys.stdout, sys.stderr = stdin, out_stream(out), err_stream(err)
        else:
            out = _CaptureStream(combined, "stdout", self.charset)
            err = _CaptureStream(combined, "stderr", self.charset)
            restore = None
            stdin = _Stdin(data, echo_to=out if self.echo_stdin else None)
            sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        termui._runner_echo = True
        try:
            yield combined, out, err
        finally:
            termui._runner_echo = saved_echo
            if restore is not None:
                restore()
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

# spec: N-000737, N-000740, N-000741
    def _fd_streams(self, combined):
        """Redirect OS descriptors 1 and 2 to temp files; return capture objects and restore()."""
        out = _FdCapture()
        err = _FdCapture()
        sys.stdout.flush()
        sys.stderr.flush()
        fd_out = tempfile.TemporaryFile()
        fd_err = tempfile.TemporaryFile()
        saved = (os.dup(1), os.dup(2))
        os.dup2(fd_out.fileno(), 1)
        os.dup2(fd_err.fileno(), 2)

        def restore():
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(saved[0], 1)
            os.dup2(saved[1], 2)
            os.close(saved[0])
            os.close(saved[1])
            fd_out.seek(0)
            fd_err.seek(0)
            out._data = fd_out.read()
            err._data = fd_err.read()
            fd_out.close()
            fd_err.close()
            combined.parts = [out._data.decode(self.charset, "replace"), err._data.decode(self.charset, "replace")]

        return out, err, restore


    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with ``args`` (a list of tokens) and return a Result."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()
        extra.setdefault("prog_name", getattr(cli, "name", None) or "root")
        extra.setdefault("color", color)
        standalone = extra.pop("standalone_mode", True)
        exit_code = 0
        exception = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (combined, out, err):
            try:
                return_value = cli.main(
                    args=list(args), standalone_mode=standalone, **extra
                )
            except SystemExit as exc:
                exit_code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
                if exc.code not in (None, 0) and not isinstance(exc.code, int):
                    exception = exc
            except Exception as exc:  # noqa: BLE001 - report to caller through Result
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
        return Result(combined, out, err, exit_code, exception, return_value)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Chdir into a new empty directory; yields its path."""
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            cleanup = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            cleanup = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if cleanup:
                shutil.rmtree(path, ignore_errors=True)
