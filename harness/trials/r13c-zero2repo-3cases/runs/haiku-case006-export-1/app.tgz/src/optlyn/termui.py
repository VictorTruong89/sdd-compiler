"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch."""

import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort, BadParameter
from .types import convert_type

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[A-Za-z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
    "reset": 39,
}

_SWITCHES = [
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("underline", 4, 24),
    ("overline", 53, 55),
    ("italic", 3, 23),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
]

# Set by the in-process runner; prompts echo visible input when it is on.
_runner_echo = False


def _is_tty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def _current_color_setting():
    from .context import get_current_context

    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _strip_if_needed(text, stream, color):
    if color is None:
        color = _current_color_setting()
    if color is True:
        return text
    if color is False:
        return unstyle(text)
    return text if _is_tty(stream) else unstyle(text)


def _write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        data = text.encode("utf-8")
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(data)
        else:
            stream.write(data.decode("ascii", "replace"))
    stream.flush()


# spec: N-000609, N-000612, N-000613, N-000670, N-000671, N-000672
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` (str or bytes) to stdout, stderr (``err``), or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        return
    text = str(message)
    text = _strip_if_needed(text, file, color)
    if nl:
        text += "\n"
    _write(file, text)


_FG_BG_CODES = _COLORS


def _color_code(color, base):
    if color is None:
        return None
    if isinstance(color, str):
        if color not in _COLORS:
            raise ValueError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        return str(code + (10 if base == "bg" and code not in (39,) else 0))
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Invalid color {color!r}.")
        return ("48;5;" if base == "bg" else "38;5;") + str(color)
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ValueError(f"Invalid color {color!r}.")
        prefix = "48;2;" if base == "bg" else "38;2;"
        return prefix + ";".join(str(c) for c in color)
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    bits = []
    fg_code = _color_code(fg, "fg")
    bg_code = _color_code(bg, "bg")
    if fg_code is not None:
        bits.append(fg_code)
    if bg_code is not None:
        bits.append(bg_code)
    flags = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on_code, _off in _SWITCHES:
        if flags.get(name):
            bits.append(str(on_code))
    if not bits:
        return text
    prefix = f"\033[{';'.join(bits)}m"
    suffix = "\033[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo styled text: ``style`` keywords are applied before echo."""
    if message is not None:
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def echo_via_pager(text_or_generator, color=None):
    """Write text through ``PAGER`` when interactive, otherwise to stdout."""
    if callable(text_or_generator):
        chunks = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if _interactive():
        pager = os.environ.get("PAGER", "less")
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
        try:
            for chunk in chunks:
                proc.stdin.write(str(chunk).encode("utf-8"))
                proc.stdin.flush()
        finally:
            proc.stdin.close()
            proc.wait()
        return
    for chunk in chunks:
        echo(str(chunk), nl=False, color=color)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager when interactive."""
    if _interactive():
        pager = os.environ.get("PAGER", "less")
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
        try:
            yield proc.stdin
        finally:
            proc.stdin.close()
            proc.wait()
    else:
        yield sys.stdout


def _interactive():
    return _is_tty(sys.stdin) and _is_tty(sys.stdout)


class ProgressBar:
    """A progress bar that wraps an iterable and/or tracks explicit updates."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self._tty = (not hidden) and _is_tty(sys.stdout)
        if label and not hidden and not self._tty:
            echo(label)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if self._tty:
            sys.stdout.write("\n")
            sys.stdout.flush()
        return False

    def update(self, n_steps):
        self.pos += n_steps
        if self._tty and self.length:
            done = min(int(self.pos * 40 / self.length), 40)
            elapsed = time.time() - self.start
            eta = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            bar = "#" * done + "-" * (40 - done)
            sys.stdout.write(
                f"\r{self.label or ''} [{bar}] {self.pos}/{self.length} eta {int(eta)}s"
            )
            sys.stdout.flush()

    def __iter__(self):
        for item in self.iterable:
            yield item
            self.update(1)


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a ProgressBar."""
    bar = ProgressBar(iterable, length, label, hidden, **options)
    with bar:
        yield bar


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
):
    """Ask for a value until it converts. Returns the converted value."""
    ptype = convert_type(type, default)
    while True:
        value = _ask(text, default, hide_input, show_default, prompt_suffix, err)
        if value == "" and default is not None:
            value = default
        if confirmation_prompt:
            again = _ask("Repeat for confirmation", None, hide_input, False, prompt_suffix, err)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return ptype.convert(value, None, None)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def _ask(text, default, hide_input, show_default, suffix, err):
    shown = text
    if default is not None and show_default and not callable(default):
        shown = f"{text} [{default}]"
    stream = sys.stderr if err else sys.stdout
    _write(stream, f"{shown}{suffix}")
    line = sys.stdin.readline() if hasattr(sys.stdin, "readline") else ""
    if not line:
        raise Abort("Aborted!")
    line = line.rstrip("\r\n")
    if not hide_input:
        if _runner_echo and not _is_tty(sys.stdin):
            _write(stream, line + "\n")
    else:
        _write(stream, "\n")
    return line


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question; return a bool. ``abort`` raises Abort on a no."""
    suffix = " [y/N]" if default is False else " [Y/n]"
    if not show_default:
        suffix = ""
    stream = sys.stderr if err else sys.stdout
    while True:
        _write(stream, f"{text}{suffix}{prompt_suffix}")
        line = sys.stdin.readline() if hasattr(sys.stdin, "readline") else ""
        if not line:
            raise Abort("Aborted!")
        line = line.strip().lower()
        if _runner_echo and not _is_tty(sys.stdin):
            _write(stream, line + "\n")
        if line == "":
            value = default
            break
        if line in ("y", "yes"):
            value = True
            break
        if line in ("n", "no"):
            value = False
            break
    if not value and abort:
        raise Abort("Aborted!")
    return value


def getchar(echo=False):
    """Read one character from the terminal (falls back to stdin)."""
    try:
        with open("/dev/tty", "rb", buffering=0) as tty:
            ch = tty.read(1).decode("utf-8", "replace")
    except OSError:
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        echo_text = ch
        _write(sys.stdout, echo_text)
    return ch


def pause(info=None, err=False):
    """Print ``info`` and wait for a key, only when interactive."""
    if not _interactive():
        return
    stream = sys.stderr if err else sys.stdout
    _write(stream, (info or "Press any key to continue...") + "")
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    _write(stream, "\n")


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or on a file. Returns saved text or None."""
    cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    argv = shlex.split(cmd)
    if filename is not None:
        subprocess.run(argv + [str(filename)], env=env, check=False)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text or "")
        before = os.path.getmtime(path)
        subprocess.run(argv + [path], env=env, check=False)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == before and result == (text or ""):
            return None
        return result
    finally:
        os.remove(path)


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application; returns a status."""
    if sys.platform == "darwin":
        argv = ["open"]
    elif os.name == "nt":
        argv = ["cmd", "/c", "start", ""]
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    try:
        proc = subprocess.Popen(argv + [str(url)])
    except OSError:
        return 1
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the terminal; does nothing when stdout is not a terminal."""
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[1;1H")
        sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user config directory for ``app_name``."""
    home = os.path.expanduser("~")
    if os.name == "nt" and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    """Return a printable text form of ``filename`` (str, bytes or path-like)."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "replace").decode("utf-8")


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file or standard stream (``-``) with the shared dash rule."""
    from .fileio import open_file as _open

    return _open(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)
