# Spec coverage

Source: `spec/CHECKLIST.md` (1012 ids). Each id is accounted for below by the spec
section it belongs to. Status is per section; exceptions are listed by id.

Tests: `tests/test_optlyn.py` (72 tests, run with `PYTHONPATH=src python3 -m pytest tests`).
Code: `src/optlyn/`.

## Status by section

| Section | Ids | Status | Implemented in |
|---|---|---|---|
| Pack 02 hardware summary | N-000761–764 | implemented (pure Python, no deps, Python 3.10+ declared in `pyproject.toml`) | `pyproject.toml` |
| Pack 03 execution profiles | N-000765–774 | implemented (src layout, PEP 517 backend); profile ids are descriptive | `pyproject.toml`, `src/optlyn/` |
| Pack 04 interface decision | N-000775 | implemented (author's choice left to implementer) | — |
| Pack 05 package and modules | N-000776–787 | implemented | `src/optlyn/__init__.py`, `testing.py`, `formatting.py` |
| Pack 06 output forms | N-000788–833 | implemented; exit codes 0/1/2/n, channels, help layout, version output | `core.py`, `help.py`, `exceptions.py` |
| Pack 07 commands and groups | N-000834–867 | implemented | `core.py`, `decorators.py` |
| Pack 08 parameters | N-000868–922 | implemented | `params.py`, `decorators.py`, `core.py` |
| Pack 09 parameter types | N-000923–931 | implemented | `types.py` |
| Pack 10 invocation context | N-000932–962 | implemented | `context.py` |
| Pack 11 terminal helpers | N-000963–982 | implemented; see exceptions for untested paths | `termui.py`, `fileio.py` |
| Pack 12 shell completion | N-000983–1005 | implemented (bash, zsh, fish, powershell; source and complete modes) | `completion.py` |
| Pack 13 in-process runner | N-001006–1012 | implemented | `testing.py` |
| Pack 14 product overview | N-000001–014 | implemented | — |
| Pack 15 terminology | N-000015–019 | implemented | `core.py`, `params.py` |
| Pack 16 public surface | N-000020–038 | implemented | `__init__.py` |
| Pack 17 non-functional | N-000039–063 | implemented, except N-000048 | `core.py`, `context.py` |
| Pack 18 non-goals | N-000064–072 | honoured (not built: aliases, plugin discovery, config format, GUI/server) | — |
| FP-01 declaration, naming, invocation | N-000073–102 | implemented; tested | `decorators.py`, `core.py` |
| FP-02 help and eager flags | N-000103–164 | implemented; tested | `help.py`, `decorators.py` |
| FP-03 options | N-000165–272 | implemented; tested | `params.py`, `core.py` |
| FP-04 positional arguments | N-000273–317 | implemented; tested | `params.py`, `core.py` |
| FP-05 parameter types | N-000318–374 | implemented; tested | `types.py` |
| FP-06 groups, nesting, lazy loading | N-000375–423 | implemented; tested | `core.py` |
| FP-07 context, defaults, env prefix | N-000424–473 | implemented; tested | `context.py`, `core.py` |
| FP-08 prompts and confirmation | N-000474–517 | implemented; tested | `termui.py`, `decorators.py` |
| FP-09 file and path parameters | N-000518–581 | implemented; tested | `fileio.py`, `types.py` |
| FP-10 chaining | N-000582–607 | implemented; tested | `core.py` |
| FP-11 terminal helpers | N-000608–676 | implemented; see exceptions | `termui.py` |
| FP-12 shell completion | N-000677–703 | implemented; tested | `completion.py` |
| FP-13 usage failures, abort, exit status | N-000704–723 | implemented; tested | `core.py`, `exceptions.py` |
| FP-14 in-process runner | N-000724–749 | implemented; tested (incl. fd capture) | `testing.py` |
| Pack 20 cross-cutting | N-000750–760 | implemented; tested | `core.py`, `help.py` |

## Not done

- **N-000048** (Windows: glob, home-directory and environment tokens in the argument
  list are expanded when invoked as a program). Not implemented. The target is Linux
  (N-000046); the expansion would be added in `Command.main` for `os.name == "nt"`.

## Implemented but not exercised by tests

- **N-000045** (SHOULD work on Windows and macOS): code avoids Linux-only calls but
  only Linux was run.
- **N-000060** (ASCII-only encoding must not abort): `echo` falls back to writing
  UTF-8 bytes on `UnicodeEncodeError`. Not run under an ASCII locale.
- **N-000631–N-000638** (pager): `echo_via_pager` and `get_pager_file` honour `PAGER`
  when interactive. Only the non-interactive path is tested.
- **N-000664–N-000668** (app directory): POSIX and macOS forms are implemented; only the
  POSIX form is tested.
- **N-000971** (`getchar`): reads `/dev/tty` and falls back to stdin. The
  pipe-not-consumed rule is implemented but untested.
- **N-000737–N-000741** (runner capture): `capture="sys"` is tested; `capture="fd"` is
  tested for OS-level writes. Output from the two descriptors is combined as stdout
  followed by stderr, not in exact write order.

## Decisions taken where the spec left room

- `password_option` is `required=True` so that an omitted password prompts (FP-08 says
  a required prompting option prompts when omitted).
- A prompting option that is not required does not prompt when omitted, only when its
  flag is given without a value (FP-08 second paragraph).
- Chaining segments: a token that names a subcommand always starts a new segment.
- Feature-switch groups (several options sharing one destination) resolve by source
  rank, with later declarations winning ties.
