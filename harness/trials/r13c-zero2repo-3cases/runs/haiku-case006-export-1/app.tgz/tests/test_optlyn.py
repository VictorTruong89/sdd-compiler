"""Behavioural tests for Optlyn, named after the acceptance areas they cover."""

import os
import pathlib

import pytest

from optlyn import (
    BadParameter,
    Choice,
    Command,
    CommandCollection,
    Group,
    IntRange,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    password_option,
    secho,
    style,
    unstyle,
    version_option,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


# --- FP-01 / declaration ---------------------------------------------------------


def test_AC_fp01_name_derivation_strips_suffix():
    @command()
    def make_thing_cmd():
        pass

    assert make_thing_cmd.name == "make-thing"


def test_AC_fp01_explicit_name_replaces_derived_name():
    @command("other")
    def foo():
        pass

    assert foo.name == "other"


def test_AC_fp01_runs_once_and_exit_zero():
    calls = []

    @command()
    def run():
        calls.append(1)
        echo("done")

    r = CliRunner().invoke(run, [])
    assert r.exit_code == 0
    assert calls == [1]
    assert r.output == "done\n"


def test_AC_fp01_deprecated_still_runs_and_warns_on_stderr():
    @command(deprecated="use other")
    def old():
        echo("ran")

    r = CliRunner().invoke(old, [])
    assert r.exit_code == 0
    assert "ran" in r.stdout
    assert "DeprecationWarning" in r.stderr and "use other" in r.stderr


def test_AC_fp01_unknown_option_is_usage_error_and_no_callback():
    ran = []

    @command()
    def cmd():
        ran.append(1)

    r = CliRunner().invoke(cmd, ["--nope"])
    assert r.exit_code == 2
    assert ran == []
    assert "--nope" in r.stderr


def test_AC_fp01_standalone_off_propagates_and_returns_value():
    @command()
    def cmd():
        return 42

    assert cmd.main([], standalone_mode=False) == 42


def test_AC_fp01_standalone_off_raises_usage_error():
    @command()
    def cmd():
        pass

    with pytest.raises(Exception):
        cmd.main(["--bogus"], standalone_mode=False)


# --- FP-02 help --------------------------------------------------------------------


def test_AC_fp02_help_exit_zero_and_skips_callback():
    ran = []

    @command()
    @option("--x", help="the x")
    def cmd(x):
        """Describe it.

        More.
        """
        ran.append(1)

    r = CliRunner().invoke(cmd, ["--help"])
    assert r.exit_code == 0
    assert ran == []
    assert "Usage:" in r.stdout
    assert "Describe it." in r.stdout
    assert "--x" in r.stdout and "the x" in r.stdout


def test_AC_fp02_formfeed_truncates_docstring():
    @command()
    def cmd():
        """Visible.\f hidden part"""

    r = CliRunner().invoke(cmd, ["--help"])
    assert "Visible." in r.stdout
    assert "hidden part" not in r.stdout
    assert "\f" not in r.stdout


def test_AC_fp02_hidden_option_omitted_from_help_but_still_parsed():
    @command()
    @option("--secret", hidden=True)
    def cmd(secret):
        echo(str(secret))

    assert "--secret" not in CliRunner().invoke(cmd, ["--help"]).stdout
    assert CliRunner().invoke(cmd, ["--secret", "s"]).stdout == "s\n"


def test_AC_fp02_custom_help_names_via_context_settings():
    @command(context_settings={"help_option_names": ["-h"]})
    def cmd():
        pass

    assert CliRunner().invoke(cmd, ["-h"]).exit_code == 0
    assert CliRunner().invoke(cmd, ["--help"]).exit_code == 2


def test_AC_fp02_version_option_prints_and_exits():
    @command()
    @version_option("1.2.3", prog_name="tool")
    def cmd():
        echo("body")

    r = CliRunner().invoke(cmd, ["--version"])
    assert r.exit_code == 0
    assert "1.2.3" in r.stdout
    assert "body" not in r.stdout


def test_AC_fp02_custom_version_option_prints_exact_string():
    @command()
    @custom_version_option(lambda ctx: "custom-id")
    def cmd():
        pass

    r = CliRunner().invoke(cmd, ["--version"])
    assert r.stdout == "custom-id\n"


def test_AC_fp02_first_eager_flag_wins():
    @command()
    @version_option("9", prog_name="t")
    def cmd():
        pass

    @command()
    @version_option("9", prog_name="t")
    @help_option()
    def cmd2():
        """Help text."""

    r = CliRunner().invoke(cmd2, ["--version", "--help"])
    assert "9" in r.stdout and "Help text." not in r.stdout
    r = CliRunner().invoke(cmd2, ["--help", "--version"])
    assert "Help text." in r.stdout


# --- FP-03 options --------------------------------------------------------------


def test_AC_fp03_short_stacking_and_counting():
    @command()
    @option("-v", count=True)
    @option("-q", "--quiet", is_flag=True)
    def cmd(v, quiet):
        echo(f"{v} {quiet}")

    assert CliRunner().invoke(cmd, ["-vvq"]).stdout == "2 True\n"


def test_AC_fp03_on_off_pair():
    @command()
    @option("--shout/--whisper", default=False)
    def cmd(shout):
        echo(str(shout))

    assert CliRunner().invoke(cmd, ["--shout"]).stdout == "True\n"
    assert CliRunner().invoke(cmd, ["--whisper"]).stdout == "False\n"


def test_AC_fp03_repeatable_and_double_dash():
    @command()
    @option("--tag", multiple=True)
    @argument("rest", nargs=-1)
    def cmd(tag, rest):
        echo(repr((tag, rest)))

    r = CliRunner().invoke(cmd, ["--tag", "a", "--tag=b", "--", "--tag"])
    assert r.stdout == "(('a', 'b'), ('--tag',))\n"


def test_AC_fp03_missing_required_option_is_usage_error():
    @command()
    @option("--need", required=True)
    def cmd(need):
        echo("ran")

    r = CliRunner().invoke(cmd, [])
    assert r.exit_code == 2
    assert "ran" not in r.stdout


def test_AC_fp03_env_value_and_command_line_precedence():
    @command()
    @option("--color", envvar="OPTLYN_TEST_COLOR")
    def cmd(color):
        echo(str(color))

    r = CliRunner().invoke(cmd, [], env={"OPTLYN_TEST_COLOR": "blue"})
    assert r.stdout == "blue\n"
    r = CliRunner().invoke(cmd, ["--color", "red"], env={"OPTLYN_TEST_COLOR": "blue"})
    assert r.stdout == "red\n"


def test_AC_fp03_empty_env_is_unset():
    @command()
    @option("--x", envvar="OPTLYN_TEST_EMPTY", default="dflt")
    def cmd(x):
        echo(x)

    assert CliRunner().invoke(cmd, [], env={"OPTLYN_TEST_EMPTY": ""}).stdout == "dflt\n"


def test_AC_fp03_default_map_fills_value():
    @command()
    @option("--n", type=int, default=1)
    def cmd(n):
        echo(str(n))

    assert CliRunner().invoke(cmd, [], default_map={"n": 7}).stdout == "7\n"
    assert CliRunner().invoke(cmd, ["--n", "3"], default_map={"n": 7}).stdout == "3\n"


def test_AC_fp03_callback_can_refuse_value():
    def check(ctx, param, value):
        if value < 0:
            raise BadParameter("must be non-negative")
        return value

    @command()
    @option("--n", type=int, callback=check)
    def cmd(n):
        echo("ran")

    r = CliRunner().invoke(cmd, ["--n", "-1"])
    assert r.exit_code == 2
    assert "ran" not in r.stdout
    assert "--n" in r.stderr or "'--n'" in r.stderr


def test_AC_fp03_source_reporting():
    seen = {}

    @command()
    @option("--a", default="x")
    @option("--b")
    def cmd(a, b):
        ctx = get_current_context()
        seen["a"] = ctx.get_parameter_source("a")
        seen["b"] = ctx.get_parameter_source("b")
        seen["zz"] = ctx.get_parameter_source("zz")

    CliRunner().invoke(cmd, ["--b", "1"])
    assert seen["a"] != seen["b"]
    assert seen["zz"] is None


# --- FP-04 arguments ----------------------------------------------------------------


def test_AC_fp04_missing_required_argument_names_it():
    @command()
    @argument("src")
    def cmd(src):
        echo("ran")

    r = CliRunner().invoke(cmd, [])
    assert r.exit_code == 2
    assert "SRC" in r.stderr
    assert "ran" not in r.stdout


def test_AC_fp04_variadic_and_fixed_arity():
    @command()
    @argument("pair", nargs=2)
    @argument("rest", nargs=-1)
    def cmd(pair, rest):
        echo(repr((pair, rest)))

    assert CliRunner().invoke(cmd, ["a", "b", "c", "d"]).stdout == "(('a', 'b'), ('c', 'd'))\n"


def test_AC_fp04_extra_tokens_are_usage_error_unless_allowed():
    @command()
    @argument("one")
    def cmd(one):
        echo(one)

    assert CliRunner().invoke(cmd, ["a", "b"]).exit_code == 2
    r = CliRunner().invoke(cmd, ["a", "b"], allow_extra_args=True)
    assert r.exit_code == 0 and r.stdout == "a\n"


# --- FP-05 types -------------------------------------------------------------------


def test_AC_fp05_int_conversion_failure_names_parameter():
    @command()
    @option("--num", type=int)
    def cmd(num):
        echo(str(num))

    r = CliRunner().invoke(cmd, ["--num", "abc"])
    assert r.exit_code == 2
    assert "--num" in r.stderr


def test_AC_fp05_choice_returns_original_member():
    import enum

    class Color(enum.Enum):
        RED = 1

    @command()
    @option("--c", type=Choice(Color))
    def cmd(c):
        echo(repr(c))

    assert CliRunner().invoke(cmd, ["--c", "RED"]).stdout == "<Color.RED: 1>\n"


def test_AC_fp05_int_range_clamp():
    rng = IntRange(min=0, max=10, clamp=True)
    assert rng.convert(50) == 10
    assert rng.convert(-5) == 0


def test_AC_fp05_bool_default_inferred():
    @command()
    @option("--flag", default=False)
    def cmd(flag):
        echo(str(flag))

    assert CliRunner().invoke(cmd, ["--flag"]).stdout == "True\n"


# --- FP-06 groups ---------------------------------------------------------------


def _app():
    @group()
    @option("--verbose", is_flag=True)
    def app(verbose):
        echo(f"group {verbose}")

    @app.command()
    @option("--name")
    def hello(name):
        echo(f"hello {name}")

    @app.group()
    def inner():
        echo("inner")

    @inner.command("deep")
    def deep():
        echo("deep")

    return app


def test_AC_fp06_subcommand_dispatch_runs_group_then_child():
    app = _app()
    r = CliRunner().invoke(app, ["--verbose", "hello", "--name", "x"])
    assert r.exit_code == 0
    assert r.stdout == "group True\nhello x\n"


def test_AC_fp06_nested_groups():
    app = _app()
    r = CliRunner().invoke(app, ["inner", "deep"])
    assert r.stdout == "group False\ninner\ndeep\n"


def test_AC_fp06_no_args_is_usage_failure_with_help_on_stderr():
    app = _app()
    r = CliRunner().invoke(app, [])
    assert r.exit_code == 2
    assert "Usage:" in r.stderr
    assert "group" not in r.stdout


def test_AC_fp06_unknown_subcommand_does_not_run_group_callback():
    app = _app()
    r = CliRunner().invoke(app, ["nope"])
    assert r.exit_code == 2
    assert "group" not in r.output


def test_AC_fp06_invoke_without_command_runs_callback():
    @group(invoke_without_command=True)
    def app():
        echo("only")

    r = CliRunner().invoke(app, [])
    assert r.exit_code == 0 and r.stdout == "only\n"


def test_AC_fp06_lazy_subcommand_loading():
    class Lazy(Group):
        def get_command(self, ctx, name):
            if name == "lazy":
                @command()
                def lazy():
                    echo("lazy!")

                return lazy
            return None

        def list_commands(self, ctx):
            return ["lazy"]

    app = Lazy(name="app", no_args_is_help=False, callback=lambda: None)
    assert CliRunner().invoke(app, ["lazy"]).stdout == "lazy!\n"


def test_AC_fp06_command_collection_union():
    a = Group(name="a", commands=[Command("one", callback=lambda: echo("one"))])
    b = Group(name="b", commands=[Command("two", callback=lambda: echo("two"))])
    coll = CommandCollection(name="all", sources=[a, b])
    assert coll.list_commands(None) == ["one", "two"]
    assert CliRunner().invoke(coll, ["two"]).stdout == "two\n"


# --- FP-10 chaining -------------------------------------------------------------


def test_AC_fp10_chain_result_callback_gets_list():
    @group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        echo(repr(results))

    @pipe.command()
    def one():
        return 1

    @pipe.command()
    def two():
        return 2

    assert CliRunner().invoke(pipe, ["one", "two"]).stdout == "[1, 2]\n"


def test_AC_fp10_group_cannot_attach_under_chain():
    chain = Group(chain=True)
    with pytest.raises(TypeError):
        chain.add_command(Group(name="g"))


# --- FP-07 context ---------------------------------------------------------


def test_AC_fp07_pass_obj_and_ensure_object():
    class Settings:
        def __init__(self):
            self.v = 5

    @group()
    @pass_context
    def app(ctx):
        ctx.obj = Settings()

    @app.command()
    @make_pass_decorator(Settings)
    def show(settings):
        echo(str(settings.v))

    assert CliRunner().invoke(app, ["show"]).stdout == "5\n"


def test_AC_fp07_invoke_another_command():
    @command()
    @option("--x", default="0")
    def other(x):
        echo("other " + x)

    @command()
    @pass_context
    def main_cmd(ctx):
        ctx.invoke(other, x="7")

    assert CliRunner().invoke(main_cmd, []).stdout == "other 7\n"


def test_AC_fp07_get_current_context_silent_none():
    assert get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        get_current_context()


# --- FP-08 prompts ----------------------------------------------------------


def test_AC_fp08_prompt_reads_stdin_when_required_and_missing():
    @command()
    @option("--name", prompt=True, required=True)
    def cmd(name):
        echo(f"got {name}")

    r = CliRunner().invoke(cmd, [], input="bob\n")
    assert "got bob" in r.stdout


def test_AC_fp08_confirmation_option_aborts_on_no():
    @command()
    @confirmation_option(prompt="Sure?")
    def cmd():
        echo("ran")

    r = CliRunner().invoke(cmd, [], input="n\n")
    assert r.exit_code == 1
    assert "ran" not in r.stdout
    assert "Aborted!" in r.stderr


def test_AC_fp08_confirmation_flag_skips_question():
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    r = CliRunner().invoke(cmd, ["--yes"], input="")
    assert r.stdout == "ran\n"


def test_AC_fp08_eof_during_prompt_is_abort():
    @command()
    @password_option()
    def cmd(password):
        echo("ran")

    r = CliRunner().invoke(cmd, [], input="")
    assert r.exit_code == 1
    assert "ran" not in r.stdout


# --- FP-09 files -----------------------------------------------------------


def test_AC_fp09_file_write_and_read_roundtrip(tmp_path):
    from optlyn import File

    target = tmp_path / "out.txt"

    @command()
    @argument("dest", type=File("w"))
    def write(dest):
        dest.write("hello")

    @command()
    @argument("src", type=File("r"))
    def read(src):
        echo(src.read())

    CliRunner().invoke(write, [str(target)])
    assert target.read_text() == "hello"
    assert CliRunner().invoke(read, [str(target)]).stdout == "hello\n"


def test_AC_fp09_missing_read_file_is_usage_error_naming_path(tmp_path):
    from optlyn import File

    @command()
    @argument("src", type=File("r"))
    def read(src):
        pass

    missing = str(tmp_path / "nope.txt")
    r = CliRunner().invoke(read, [missing])
    assert r.exit_code == 2
    assert missing in r.stderr


def test_AC_fp09_path_checks(tmp_path):
    from optlyn import Path

    @command()
    @argument("p", type=Path(exists=True))
    def cmd(p):
        echo(p)

    r = CliRunner().invoke(cmd, [str(tmp_path / "missing")])
    assert r.exit_code == 2


# --- FP-11 terminal helpers -------------------------------------------------------


def test_AC_fp11_style_and_unstyle_roundtrip():
    text = style("hi", fg="red", bold=True)
    assert text != "hi"
    assert unstyle(text) == "hi"


def test_AC_fp11_invalid_color_raises():
    with pytest.raises(ValueError):
        style("x", fg="not-a-color")


def test_AC_fp11_echo_strips_styles_when_not_a_terminal():
    @command()
    def cmd():
        secho("colored", fg="green")

    assert CliRunner().invoke(cmd, []).stdout == "colored\n"


def test_AC_fp11_wrap_text_accepts_any_string():
    assert wrap_text("a " * 200, width=20)
    assert wrap_text("", width=20) == ""


def test_AC_fp11_get_app_dir_posix(tmp_path, monkeypatch):
    from optlyn import get_app_dir

    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    if os.name != "nt":
        assert get_app_dir("My App") == str(tmp_path / "my-app")


# --- FP-12 completion -----------------------------------------------------------


def test_AC_fp12_source_script_and_suggestions(monkeypatch):
    @group()
    def tool():
        pass

    @tool.command()
    def build():
        pass

    @tool.command()
    def test_it():
        pass

    r = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": "bash_source"})
    assert "complete" in r.stdout and "tool" in r.stdout
    assert "build" not in r.stdout  # source mode does not run the command

    monkeypatch.setenv("COMP_WORDS", "tool b")
    monkeypatch.setenv("COMP_CWORD", "1")
    r = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": "bash_complete"})
    assert r.stdout.split() == ["build"]


def test_AC_fp12_unknown_instruction_prints_nothing(monkeypatch):
    @command()
    def tool():
        echo("ran")

    r = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": "bogus_thing"})
    assert "ran" not in r.stdout


def test_AC_fp12_hidden_commands_never_suggested(monkeypatch):
    @group()
    def tool():
        pass

    @tool.command(hidden=True)
    def secretcmd():
        pass

    monkeypatch.setenv("COMP_WORDS", "tool s")
    monkeypatch.setenv("COMP_CWORD", "1")
    r = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": "bash_complete"})
    assert "secretcmd" not in r.stdout


# --- FP-13 exit status ----------------------------------------------------------


def test_AC_fp13_author_exit_code():
    @command()
    @pass_context
    def cmd(ctx):
        ctx.exit(5)

    assert CliRunner().invoke(cmd, []).exit_code == 5


def test_AC_fp13_author_abort_is_exit_one():
    @command()
    @pass_context
    def cmd(ctx):
        ctx.abort()

    r = CliRunner().invoke(cmd, [])
    assert r.exit_code == 1
    assert "Aborted!" in r.stderr


# --- FP-14 runner ----------------------------------------------------------


def test_AC_fp14_result_fields_and_exception_capture():
    @command()
    def boom():
        raise ValueError("bad")

    r = CliRunner().invoke(boom, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, ValueError)

    with pytest.raises(ValueError):
        CliRunner(catch_exceptions=False).invoke(boom, [])


def test_AC_fp14_isolated_filesystem_creates_and_cleans(tmp_path):
    runner = CliRunner()
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
        pathlib.Path("f.txt").write_text("x")
    assert not os.path.exists(path)


def test_AC_fp14_standalone_off_exception_inspectable():
    @command()
    def boom():
        raise RuntimeError("nope")

    r = CliRunner().invoke(boom, [], standalone_mode=False)
    assert isinstance(r.exception, RuntimeError)


# --- contexts and the public surface ------------------------------------------------


def test_surface_exports_exist():
    import optlyn

    for name in [
        "command", "group", "option", "argument", "help_option", "version_option",
        "custom_version_option", "password_option", "confirmation_option", "pass_context",
        "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection", "Context",
        "Option", "Parameter", "ParamType", "BadParameter", "Abort", "STRING", "INT", "FLOAT",
        "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
        "File", "Path", "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
        "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
        "get_app_dir", "get_current_context", "format_filename", "open_file",
    ]:
        assert hasattr(optlyn, name), name


# --- additional behaviour checks ----------------------------------------------------


def test_AC_fp03_auto_envvar_prefix_for_options_only():
    @command()
    @option("--port", type=int, default=1)
    @argument("host", required=False)
    def cmd(port, host):
        echo(f"{port} {host}")

    r = CliRunner().invoke(cmd, [], env={"MYAPP_PORT": "9"}, auto_envvar_prefix="MYAPP")
    assert r.stdout == "9 None\n"
    r = CliRunner().invoke(cmd, [], env={"MYAPP_HOST": "h"}, auto_envvar_prefix="MYAPP")
    assert r.stdout == "1 None\n"


def test_AC_fp07_forward_uses_current_values():
    @command()
    @option("--x", default="0")
    def other(x):
        echo("other " + x)

    @command()
    @option("--x", default="d")
    @pass_context
    def outer(ctx, x):
        ctx.forward(other)

    assert CliRunner().invoke(outer, ["--x", "5"]).stdout == "other 5\n"


def test_AC_fp03_deprecated_option_warns_only_when_supplied():
    @command()
    @option("--old", deprecated="gone soon")
    def cmd(old):
        echo("ran")

    r = CliRunner().invoke(cmd, [])
    assert "DeprecationWarning" not in r.stderr
    r = CliRunner().invoke(cmd, ["--old", "x"])
    assert "DeprecationWarning" in r.stderr and "gone soon" in r.stderr
    assert "ran" in r.stdout


def test_AC_fp11_echo_keeps_styles_when_color_forced():
    @command()
    def cmd():
        secho("x", fg="red")

    r = CliRunner().invoke(cmd, [], color=True)
    assert "\x1b[" in r.stdout


def test_AC_fp12_fish_complete_empty_incomplete(monkeypatch):
    @group()
    def tool():
        pass

    @tool.command()
    def alpha():
        pass

    monkeypatch.setenv("COMP_WORDS", "tool")
    monkeypatch.setenv("COMP_CWORD", "")
    r = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": "fish_complete"})
    assert "alpha" in r.stdout.split()


def test_AC_fp12_choice_suggestions_match_prefix(monkeypatch):
    @command()
    @option("--mode", type=Choice(["fast", "fine", "slow"]))
    def cmd(mode):
        pass

    monkeypatch.setenv("COMP_WORDS", "cmd --mode f")
    monkeypatch.setenv("COMP_CWORD", "2")
    r = CliRunner().invoke(cmd, [], env={"_CMD_COMPLETE": "bash_complete"})
    assert sorted(r.stdout.split()) == ["fast", "fine"]


def test_AC_fp02_group_help_lists_visible_children():
    @group()
    def app():
        pass

    @app.command()
    def shown():
        """Shows things. More."""

    @app.command(hidden=True)
    def secret():
        pass

    r = CliRunner().invoke(app, ["--help"])
    assert "shown" in r.stdout and "Shows things." in r.stdout
    assert "secret" not in r.stdout
    assert "[OPTIONS] COMMAND [ARGS]..." in r.stdout


def test_AC_fp14_fd_capture_records_os_level_writes():
    import os as _os

    @command()
    def cmd():
        echo("one")
        _os.write(1, b"raw\n")
        echo("err", err=True)

    r = CliRunner(capture="fd").invoke(cmd, [])
    assert r.stdout == "one\nraw\n"
    assert r.stderr == "err\n"


def test_AC_fp14_default_capture_ignores_os_level_writes():
    import os as _os

    @command()
    def cmd():
        _os.write(1, b"raw\n")

    assert CliRunner().invoke(cmd, []).stdout == ""
