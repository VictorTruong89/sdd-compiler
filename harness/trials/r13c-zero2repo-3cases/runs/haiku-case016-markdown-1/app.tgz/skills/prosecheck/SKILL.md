---
name: prosecheck
description: Rewrite flagged prose when the user asks to "prosecheck this" or "humanize this". Use after prosecheck reports flagged spans in a prose file.
---

# Rewriting flagged prose

This skill is for a deep rewrite that the user requests in plain language ("prosecheck this" or "humanize this").

1. Read the file and the flagged spans reported by the detector. Leave code, configuration, commits, and chat untouched.
2. Rewrite only the flagged sentences. Keep numbers, units, dates, proper nouns, citations, quotes, and technical terms exactly as written.
3. Vary sentence length. Remove banned vocabulary and banned moves from the writing contract.
4. Do not invent facts. Do not add a summary of what changed. Do not mention the detector or its score in the prose.
5. Run the detector on the file again and make at most two more fix passes.
