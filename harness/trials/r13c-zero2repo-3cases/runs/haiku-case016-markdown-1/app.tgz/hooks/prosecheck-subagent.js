#!/usr/bin/env node
'use strict';
// subagent-start hook: hands the same writing contract to a delegated agent.
// Always exits 0; malformed input is treated as an empty object.

const common = require('./lib/common');

function main() {
  common.readStdinJson();
  const level = common.currentLevel();
  if (level === 'off') return;
  common.emitJson({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: common.contractText({ level, detectorPath: common.detectorScript() }),
    },
  });
}

try {
  main();
} catch (err) {
  // a hook must never fail the host session
}
process.exitCode = 0;
