#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract (and, once, the welcome) in context.
// Always exits 0; malformed input is treated as an empty object.

const common = require('./lib/common');

function main() {
  common.readStdinJson();
  common.pruneLedgers();

  // A fresh install (no flag yet) stores the effective level and welcomes once.
  const existed = common.flagExists();
  const level = common.currentLevel();
  if (level === 'off') return;

  let welcome = false;
  if (!existed) {
    try {
      common.writeLevel(level);
      welcome = true;
    } catch (err) {
      welcome = false;
    }
  }

  const parts = [];
  if (welcome) parts.push(common.welcomeText());
  parts.push(common.contractText({ level, detectorPath: common.detectorScript() }));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (err) {
  // a hook must never fail the host session
}
process.exitCode = 0;
