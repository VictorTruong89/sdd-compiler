#!/usr/bin/env node
'use strict';
// stats helper: prints the /prosecheck stats reply for a host JSON payload on standard input.
// It is on demand (node hooks/prosecheck-stats.js < payload.json); the router answers stats too.
// Always exits 0; malformed input is treated as an empty object.

const common = require('./lib/common');
const commands = require('./lib/commands');

try {
  const input = common.readStdinJson();
  const transcript = typeof input.transcript_path === 'string' ? input.transcript_path : undefined;
  process.stdout.write(commands.statsText(transcript) + '\n');
} catch (err) {
  // a hook must never fail the host session
}
process.exitCode = 0;
