#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
// Covers Write, Edit, MultiEdit, NotebookEdit, and apply_patch. Always exits 0.

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const SUPPORTED_TOOLS = new Set(['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch']);
const PATCH_LINE = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/;
const PATCH_LIMIT = 16;

function patchPaths(command) {
  const found = [];
  for (const line of String(command).split(/\r?\n/)) {
    const m = PATCH_LINE.exec(line);
    if (m && m[1].trim()) found.push(m[1].trim());
  }
  return [...new Set(found)].slice(0, PATCH_LIMIT);
}

function pathsFor(toolName, toolInput) {
  const tool = toolName.toLowerCase();
  if (tool === 'apply_patch') {
    const command = typeof toolInput === 'string' ? toolInput : toolInput.command;
    return typeof command === 'string' ? patchPaths(command) : [];
  }
  if (typeof toolInput !== 'object' || toolInput === null) return [];
  if (tool === 'notebookedit') {
    const p = toolInput.notebook_path || toolInput.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  const p = toolInput.file_path;
  return typeof p === 'string' && p.trim() ? [p.trim()] : [];
}

function isSkipped(abs, root) {
  const segments = abs.split(/[\\/]+/);
  if (segments.some((s) => s === 'node_modules' || s === '.git' || s === 'memory')) return true;
  if (abs === root || abs.startsWith(root + path.sep)) return true;
  const base = path.basename(abs).toLowerCase();
  if (common.INSTRUCTION_NAMES.has(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  return common.INSTRUCTION_STEMS.has(stem) && !common.PROSE_EXTS.has(ext);
}

function statOrNull(file) {
  try {
    return fs.statSync(file);
  } catch (err) {
    return null;
  }
}

// Scores one saved file and records the attempt. Returns a nudge line or null.
function handleFile(abs, sessionId, level) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const eligible = common.PROSE_EXTS.has(ext);
  const binary = common.BINARY_EXTS.has(ext);
  if (!eligible && !binary) return null;

  const st = statOrNull(abs);
  if (!st) {
    common.appendLedger(sessionId, { base, time: Date.now(), kind: 'failed', reason: 'file could not be read' });
    return null;
  }
  if (!st.isFile()) return null;

  if (binary) {
    common.appendLedger(sessionId, { base, time: Date.now(), kind: 'binary' });
    return null;
  }

  const archive = common.ARCHIVE_EXTS.has(ext);
  const capBytes = archive ? common.ARCHIVE_CAP_BYTES : common.PLAIN_CAP_BYTES;
  const capKb = archive ? common.ARCHIVE_CAP_KB : common.PLAIN_CAP_KB;
  if (st.size > capBytes) {
    common.appendLedger(sessionId, { base, time: Date.now(), kind: 'skipped', capKb });
    return null;
  }

  const timeout = archive ? common.ARCHIVE_TIMEOUT_MS : common.PLAIN_TIMEOUT_MS;
  const res = common.detect({ file: abs, timeout });
  const failure = (reason) => {
    common.appendLedger(sessionId, { base, time: Date.now(), kind: 'failed', reason });
    return null;
  };
  switch (res.kind) {
    case 'ok':
      break;
    case 'nopython':
      return failure('Python not found');
    case 'nodetector':
      return failure('bundled detector not found');
    case 'timeout':
      return failure('detector timed out');
    case 'notreport':
      return failure('detector output is not a report');
    default:
      return failure(res.errorText && res.errorText.startsWith('cannot read')
        ? 'file could not be read'
        : 'detector produced no usable result');
  }

  const s = common.scoreOf(res.report);
  const labels = common.findingsOf(res.report).filter((f) => !f.advice).map((f) => f.label);
  const threshold = level === 'strict' ? common.STRICT_THRESHOLD : common.FULL_THRESHOLD;
  const flagged = s.score > threshold && s.confidence !== 'none';
  const phrase = common.HOOK_PHRASES[s.band] || common.HOOK_PHRASES.clean;
  const shownLabels = labels.slice(0, common.GUARD_LABEL_LIMIT);
  common.appendLedger(sessionId, {
    base, time: Date.now(), kind: 'scored', phrase, score: s.score, band: s.band,
    truncated: s.truncated, labels: shownLabels, flagged,
  });
  if (!flagged) return null;

  const coverage = s.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  const listed = shownLabels.length ? shownLabels.join('; ') : 'none listed';
  return `prosecheck: ${base} ${phrase} (score ${s.score}, band ${s.band}${coverage}). Flagged: ${listed}. ` +
    'Fix the flagged spans, keeping sentence-length variation.';
}

function main() {
  const input = common.readStdinJson();
  const toolName = typeof input.tool_name === 'string' ? input.tool_name : '';
  if (!SUPPORTED_TOOLS.has(toolName.toLowerCase())) return;

  const level = common.currentLevel();
  if (level === 'off' || level === 'lite') return;

  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sessionId = typeof input.session_id === 'string' ? input.session_id : undefined;
  const root = path.resolve(common.pluginRoot());
  const raw = pathsFor(toolName, input.tool_input);

  const nudges = [];
  for (const p of raw) {
    const abs = path.resolve(cwd, p);
    if (isSkipped(abs, root)) continue;
    const line = handleFile(abs, sessionId, level);
    if (line) nudges.push(line);
  }
  if (!nudges.length) return;
  common.emitJson({
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: nudges.join('\n'),
    },
  });
}

try {
  main();
} catch (err) {
  // a hook must never fail the host session
}
process.exitCode = 0;
