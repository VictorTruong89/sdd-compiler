#!/usr/bin/env node
'use strict';
// prompt-submit hook: routes /prosecheck commands, stop phrases, and the live reminder.
// Always exits 0; malformed input is treated as an empty object.

const common = require('./lib/common');
const commands = require('./lib/commands');

function main() {
  const input = common.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();

  const parsed = commands.parseCommand(trimmed);
  if (parsed) {
    const reason = commands.route(parsed, {
      sessionId: typeof input.session_id === 'string' ? input.session_id : undefined,
      transcriptPath: typeof input.transcript_path === 'string' ? input.transcript_path : undefined,
    });
    common.emitJson({ decision: 'block', reason });
    return;
  }

  if (commands.isStopPhrase(trimmed)) {
    common.writeLevel('off');
    common.emitJson({
      decision: 'block',
      reason: 'prosecheck is off. Nothing is placed in context and saved files are not scored. Use /prosecheck on to switch it back on.',
    });
    return;
  }

  const level = common.currentLevel();
  if (level === 'off') return;
  common.emitJson({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: `prosecheck level ${level}: prose deliverables follow the writing contract; code, config, and commits are untouched.`,
    },
  });
}

try {
  main();
} catch (err) {
  // a hook must never fail the host session
}
process.exitCode = 0;
