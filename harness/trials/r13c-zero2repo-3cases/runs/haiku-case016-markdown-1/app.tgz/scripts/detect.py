#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage: detect.py [--clean] [--ci] [--] [FILE]
       detect.py --help | -h

With no FILE, standard input is read. Output is a JSON report (findings and
metrics), or scrubbed text with --clean. Failures print {"error": ...} as the
last stderr line and exit 1 (empty input, unreadable path) or 2 (bad option).
"""
import json
import math
import random
import re
import sys
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
NO_TEXT_EXTS = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan prose for AI-writing patterns. Local only; standard library only.

  --clean     print scrubbed text instead of the report (removes invisible
              characters, normalizes non-standard spaces, folds lookalike
              letters, trims trailing whitespace)
  --ci        add a low/high interval on the score when the text has enough
              sentences
  --          end option parsing; the next argument may begin with a dash
  FILE        one prose file (.md, .txt, .docx, .ipynb, ...). With no FILE,
              standard input is read.
  -h, --help  print this message
"""


# ---------------------------------------------------------------- characters

_DEFAULT_IGNORABLE = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x2065, 0x3164, 0xFFA0}
_VISIBLE_CF = set(range(0x0600, 0x0606)) | {0x06DD, 0x070F, 0x08E2}
_BIDI = {0x061C, 0x200E, 0x200F} | set(range(0x202A, 0x202F)) | set(range(0x2066, 0x206A))

# Mixed-script lookalikes of Latin letters (Cyrillic, Greek, Armenian).
_LOOKALIKE_PAIRS = {
    'a': 'а', 'c': 'сϲ', 'd': 'ԁ', 'e': 'е', 'h': 'һ',
    'i': 'і', 'j': 'ј', 'n': 'ո', 'o': 'оοօ', 'p': 'рρ',
    's': 'ѕ', 'u': 'υս', 'v': 'νѵ', 'w': 'ԝ', 'x': 'хχ',
    'y': 'у',
    'A': 'АΑ', 'B': 'ВΒ', 'C': 'СϹ', 'E': 'ЕΕ',
    'H': 'НΗ', 'I': 'ІΙ', 'J': 'Ј', 'K': 'КΚ',
    'M': 'МΜ', 'N': 'Ν', 'O': 'ОΟՕ', 'P': 'РΡ',
    'S': 'Ѕ', 'T': 'ТΤ', 'X': 'ХΧ', 'Y': 'УΥ',
    'Z': 'Ζ', 'U': 'Ս',
}
LOOKALIKE = {}
for _latin, _others in _LOOKALIKE_PAIRS.items():
    for _ch in _others:
        LOOKALIKE[_ch] = _latin


def _in(c, lo, hi):
    return bool(c) and lo <= ord(c) <= hi


def _is_symbol_or_cjk(c):
    if not c:
        return False
    o = ord(c)
    return (unicodedata.category(c).startswith('S') or o >= 0x1F000
            or 0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0xF900 <= o <= 0xFAFF
            or 0x20000 <= o <= 0x2FFFF)


def _joins(c):
    return bool(c) and (_in(c, 0x0590, 0x08FF) or _in(c, 0x0900, 0x0DFF) or _in(c, 0x1000, 0x109F)
                        or _in(c, 0x1780, 0x17FF) or _in(c, 0xFB1D, 0xFDFF) or _in(c, 0xFE70, 0xFEFF))


def _cjk_like(c):
    return bool(c) and (_in(c, 0x0E00, 0x0EFF) or _in(c, 0x1000, 0x109F) or _in(c, 0x1780, 0x17FF)
                        or _in(c, 0x3000, 0x30FF) or _is_symbol_or_cjk(c) and not unicodedata.category(c).startswith('S'))


def _is_invisible(c):
    if c in '\t\n\r':
        return False
    o = ord(c)
    if o < 0x20 or 0x7F <= o <= 0x9F:
        return True
    if o in _VISIBLE_CF:
        return False
    if o in _DEFAULT_IGNORABLE or 0xE0000 <= o <= 0xE007F or 0xFE00 <= o <= 0xFE0F:
        return True
    if 0xE0100 <= o <= 0xE01EF or 0x180B <= o <= 0x180F:
        return True
    return unicodedata.category(c) == 'Cf'


def _kept(raw, i, has_rtl):
    """True when an invisible character does a job in its position (FP-03)."""
    c = raw[i]
    o = ord(c)
    prev = raw[i - 1] if i > 0 else ''
    nxt = raw[i + 1] if i + 1 < len(raw) else ''
    if 0xE0000 <= o <= 0xE007F:
        j = i - 1
        while j >= 0 and 0xE0000 <= ord(raw[j]) <= 0xE007F:
            j -= 1
        return j >= 0 and (ord(raw[j]) >= 0x1F000 or unicodedata.category(raw[j]).startswith('S'))
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return _is_symbol_or_cjk(prev) or nxt == '⃣'
    if o in (0x180B, 0x180C, 0x180D, 0x180F):
        return _in(prev, 0x1800, 0x18AF)
    if o in (0x200C, 0x200D):
        return (_joins(prev) or _joins(nxt) or _is_symbol_or_cjk(prev) and unicodedata.category(prev).startswith('S')
                or _is_symbol_or_cjk(nxt) and unicodedata.category(nxt).startswith('S')
                or ord(prev or '\0') >= 0x1F000 or ord(nxt or '\0') >= 0x1F000)
    if o == 0x200B:
        return _cjk_like(prev) or _cjk_like(nxt)
    if o == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if o in _BIDI:
        return has_rtl
    if o in (0x17B4, 0x17B5):
        return _in(prev, 0x1780, 0x17FF) or _in(nxt, 0x1780, 0x17FF)
    return False


def _has_rtl(text):
    return any(_in(c, 0x0590, 0x06FF) or _in(c, 0x0750, 0x08FF) or _in(c, 0xFB1D, 0xFDFF) for c in text)


def _nbsp_kept(seq, j):
    prev = seq[j - 1] if j > 0 else ''
    nxt = seq[j + 1] if j + 1 < len(seq) else ''
    return ((prev.isdigit() or nxt.isdigit()) or nxt in ':;!?»›%€' or prev in '«‹')


def _fold_lookalikes(text):
    """Fold lookalike letters inside mixed Latin runs (catalogue 66). Returns (text, count)."""
    out = []
    count = 0
    for token in re.split(r'(\s+)', text):
        if not token or token.isspace():
            out.append(token)
            continue
        pieces = []
        last = 0
        for m in re.finditer(r'[^\W\d_]+', token):
            run = m.group(0)
            non_ascii = [c for c in run if ord(c) > 127]
            has_ascii = any(c.isascii() and c.isalpha() for c in run)
            if has_ascii and non_ascii and all(c in LOOKALIKE for c in non_ascii):
                pieces.append(token[last:m.start()])
                pieces.append(''.join(LOOKALIKE.get(c, c) for c in run))
                count += len(non_ascii)
                last = m.end()
        pieces.append(token[last:])
        out.append(''.join(pieces))
    return ''.join(out), count


def char_layer(raw):
    """Character-layer analysis of the scan window.

    Returns a dict with the counts used as metrics and findings, plus the two
    texts derived from raw: `clean` (what --clean keeps) and `match` (every
    invisible character removed, used for pattern matching).
    """
    has_rtl = _has_rtl(raw)
    inv = {i for i, c in enumerate(raw) if _is_invisible(c)}
    removed = {i for i in inv if not _kept(raw, i, has_rtl)}

    clean_seq = [c for i, c in enumerate(raw) if i not in removed]
    match_seq = [c for i, c in enumerate(raw) if i not in inv]

    nonstd = 0

    def normalize(seq, count):
        nonlocal nonstd
        out = []
        for j, c in enumerate(seq):
            if c == ' ':
                out.append(c)
            elif c in '  ':
                out.append('\n')
            elif unicodedata.category(c) == 'Zs':
                if c in '  ' and _nbsp_kept(seq, j):
                    out.append(c)
                else:
                    out.append(' ')
                    if count:
                        nonstd += 1
            else:
                out.append(c)
        return ''.join(out)

    clean_text = normalize(clean_seq, True)
    match_text = normalize(match_seq, False)
    clean_text, homoglyphs = _fold_lookalikes(clean_text)
    match_text, _ = _fold_lookalikes(match_text)

    return {
        'invisible': len(removed),
        'invisible_samples': ['U+%04X' % ord(raw[i]) for i in sorted(removed)[:3]],
        'nonstandard': nonstd,
        'homoglyph': homoglyphs,
        'trailing': _trailing_count(raw),
        'clean': clean_text,
        'match': match_text,
    }


def _trailing_count(raw):
    count = 0
    for line in raw.split('\n'):
        body = line.rstrip('\r')
        if body and body != body.rstrip(' \t'):
            count += 1
    if raw[:1].isspace():
        count += 1
    tail = raw[len(raw.rstrip()):]
    if tail.count('\n') >= 2:
        count += 1
    return count


# ------------------------------------------------------------------- masking

_FENCE_RE = re.compile(r'^ {0,3}(`{3,}|~{3,})')
_BQ_RE = re.compile(r'^ {0,3}>')
_LIST_RE = re.compile(r'^ {0,3}(?:[-*+]|\d{1,9}[.)])\s')
_BADGE_RE = re.compile(r'^\s*(?:\[!\[[^\]\n]{0,200}\]\([^)\n]{0,300}\)\]\([^)\n]{0,300}\)\s*)+$')
_INLINE_CODE_RE = re.compile(r'(`+)(.{1,300}?)\1')


def mask_markdown(text):
    """Blank out code, blockquote runs, table rows, badges, and front matter.

    The result keeps the line structure (masked lines become spaces), so
    paragraph and sentence rules see the same breaks the author wrote.
    """
    lines = text.split('\n')
    n = len(lines)
    masked = [False] * n
    start = 0
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(0, j + 1):
                    masked[k] = True
                start = j + 1
                break
    i = start
    state = 'blank'
    in_list = False
    while i < n:
        line = lines[i]
        fence = _FENCE_RE.match(line)
        if fence:
            marker = fence.group(1)
            close = re.compile(r'^ {0,3}' + re.escape(marker[0]) + '{' + str(len(marker)) + r',}\s*$')
            j = i + 1
            while j < n and not close.match(lines[j]):
                j += 1
            last = min(j, n - 1)
            for k in range(i, last + 1):
                masked[k] = True
            i = last + 1
            state, in_list = 'code', False
            continue
        if not line.strip():
            state = 'blank'
            i += 1
            continue
        if _BQ_RE.match(line):
            j = i
            while j < n and _BQ_RE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
                i = j
                state = 'code'
                continue
        if (line.startswith('\t') or line.startswith('    ')) and state in ('blank', 'code') and not in_list:
            masked[i] = True
            state = 'code'
            i += 1
            continue
        stripped = line.strip()
        if stripped.startswith('|') or (stripped.endswith('|') and stripped.count('|') >= 2):
            masked[i] = True
            state = 'table'
            i += 1
            continue
        if stripped and set(stripped) <= set('|-: ') and '-' in stripped and '|' in stripped:
            masked[i] = True
            state = 'table'
            i += 1
            continue
        if _BADGE_RE.match(line):
            masked[i] = True
            state = 'code'
            i += 1
            continue
        if _LIST_RE.match(line):
            in_list = True
        elif not line.startswith((' ', '\t')):
            in_list = False
        state = 'para'
        i += 1

    out = []
    for idx, line in enumerate(lines):
        if masked[idx]:
            out.append(' ' * len(line))
        else:
            out.append(_INLINE_CODE_RE.sub(lambda m: ' ' * len(m.group(0)), line))
    return '\n'.join(out)


# ------------------------------------------------------------------ features

WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")
SENT_SPLIT = re.compile(r'(?<=[.!?])\s+')
PARA_SPLIT = re.compile(r'\n\s*\n')


def _has_alnum(s):
    return any(c.isalnum() for c in s)


def split_sentences(text):
    out = []
    for line in text.split('\n'):
        for seg in SENT_SPLIT.split(line):
            seg = seg.strip()
            if seg and _has_alnum(seg):
                out.append(seg)
    return out


def _cv(values):
    if not values:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


class Context(object):
    def __init__(self, chars, masked, truncated):
        self.chars = chars
        self.masked = masked
        self.truncated = truncated
        self.words = [t for t in WORD_RE.findall(masked) if _has_alnum(t)]
        self.sentences = split_sentences(masked)
        self.paragraphs = [p.strip() for p in PARA_SPLIT.split(masked) if _has_alnum(p)]
        self.lines = masked.split('\n')


# -------------------------------------------------------------------- rules

RULES = []


class Rule(object):
    def __init__(self, num, slug, label, moving, fn):
        self.num = num
        self.slug = slug
        self.label = label
        self.moving = moving
        self.fn = fn


def rule(num, slug, label, moving=True):
    def deco(fn):
        RULES.append(Rule(num, slug, label, moving, fn))
        return fn
    return deco


def _rx(pattern, flags=re.I):
    return re.compile(pattern, flags)


def _all(patterns, text):
    out = []
    for p in patterns:
        out.extend(m.group(0) for m in p.finditer(text))
    return out


def _infl(phrase):
    """Regex for a phrase; the first word takes common inflections (delve -> delves/delved/delving)."""
    words = phrase.split(' ')
    first = words[0]
    stem = first[:-1] if first.endswith('e') else first
    parts = [re.escape(stem) + r'(?:e|es|ed|ing|s|ly)?']
    parts.extend(re.escape(w) for w in words[1:])
    return r'\b' + r'\s+'.join(parts) + r'\b'


def _alt(phrases):
    return _rx('(?:' + '|'.join(_infl(p) for p in phrases) + ')')


AI_VOCAB = [
    'additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
    'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster', 'foster',
    'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass',
    'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad', 'plethora', 'robust',
    'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate',
    'empower', 'unlock',
]
AI_VOCAB_RX = [_alt(AI_VOCAB), _rx(r'\bcapture the (?:essence|spirit|imagination|heart|magic)\b')]


@rule(1, 'ai_vocabulary', 'AI vocabulary')
def r01(ctx):
    return _all(AI_VOCAB_RX, ctx.masked)


DIALECT_RX = [
    _rx(r'\bgenuinely\b'), _rx(r'\bfascinating\b'), _rx(r'\bnuanced\b'), _rx(r'\bthoughtfully\b'),
    _rx(r'\brefreshingly\b'), _rx(r'\bstrikingly\b'), _rx(r'\bcompellingly\b'),
    _rx(r'\bquietly (?:powerful|profound|radical)\b'), _rx(r'\bdeeply (?:human|personal|felt|unsettling)\b'),
    _rx(r'\bresonates deeply\b'), _rx(r'\bgame[- ]changer(?:s)?\b'), _rx(r'\bgame[- ]changing\b'),
    _rx(r'\bsupercharg(?:e|es|ed|ing)\b'), _rx(r'\bskyrocket(?:s|ed|ing)?\b'),
    _rx(r'\bturbocharg(?:e|es|ed|ing)\b'), _rx(r'\brevolutioniz(?:e|es|ed|ing)\b'),
    _rx(r'\bdouble down on\b'), _rx(r'\bdive deep(?:er)? into\b'),
    _rx(r'\bunlock (?:the )?(?:power|potential|value)\b'), _rx(r'\btake\b[^.!?\n]{0,40}?\bto the next level\b'),
]


@rule(2, 'model_dialect', 'model-dialect vocabulary')
def r02(ctx):
    hits = _all(DIALECT_RX, ctx.masked)
    return hits if len(hits) >= 2 else []


PROMO_RX = _rx(
    r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community'
    r'|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|leading'
    r'|esteemed organization|valuable asset|passion for excellence|proven track record|results-oriented'
    r'|wealth of experience|dynamic team|fast-paced environment|deeply passionate|perfectly situated'
    r'|(?:close|tight)[- ]knit team|I am excited to (?:apply|bring)|uniquely positioned to)\b',
    0)
IMPERATIVE_OPEN = _rx(
    r'^\W*(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate'
    r'|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b')


@rule(3, 'promotional_language', 'promotional language')
def r03(ctx):
    hits = [m.group(0) for m in PROMO_RX.finditer(ctx.masked)]
    openers = [s for s in ctx.sentences if IMPERATIVE_OPEN.match(s)]
    if len(openers) >= 3:
        hits.extend(openers)
    return hits


@rule(4, 'hyphenated_pairs', 'hyphenated word-pair overuse', moving=False)
def r04(ctx):
    return _all([_rx(r'\b(?:cutting-edge|state-of-the-art|best-in-class|next-generation|results-driven'
                     r'|customer-centric|data-driven|top-notch|time-tested|value-driven)\b')], ctx.masked)


@rule(5, 'simple_yet', '“simple yet X” cliché')
def r05(ctx):
    return _all([_rx(r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated'
                     r'|beautiful)\b')], ctx.masked)


CHAIN_A = _rx(r"\b(?:[A-Za-z][\w'-]*,\s+){3,}(?:and\s+)?[A-Za-z][\w'-]*\s+[A-Za-z][\w'-]*", 0)
CHAIN_B = _rx(r"\b(?:[A-Za-z][\w'-]*,\s+){2}and\s+[A-Za-z][\w'-]*\s+[A-Za-z][\w'-]*", 0)
ADJ_SUFFIX = _rx(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$")
STOCK_EVAL = {'robust', 'seamless', 'powerful', 'innovative', 'cutting-edge', 'elegant', 'sleek',
              'vibrant', 'reliable', 'intuitive', 'comprehensive', 'efficient', 'scalable', 'modern',
              'dynamic', 'bold', 'rich', 'fresh', 'premier', 'stunning', 'exceptional'}


@rule(6, 'adjective_chains', 'stacked adjective chains')
def r06(ctx):
    hits = []
    for sent in ctx.sentences:
        s = sent[:2000]
        for pat in (CHAIN_A, CHAIN_B):
            for m in pat.finditer(s):
                toks = re.findall(r"[A-Za-z][\w'-]*", m.group(0))
                items = [t for t in toks[:-1] if t.lower() != 'and']
                if any(t.lower() in STOCK_EVAL or ADJ_SUFFIX.search(t) for t in items):
                    hits.append(m.group(0))
    return hits


CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
CLUSTER_RX = [[(w, _rx(r'\b' + re.escape(w).replace(r'\ ', r'\s+') + r'(?:s|es)?\b')) for w in c]
              for c in CLUSTERS]


@rule(8, 'synonym_cycling', 'synonym cycling')
def r08(ctx):
    hits = []
    for cluster in CLUSTER_RX:
        present = [(w, p) for w, p in cluster if p.search(ctx.masked)]
        if len(present) >= 3:
            for _, p in present:
                hits.extend(m.group(0) for m in p.finditer(ctx.masked))
    return hits


@rule(10, 'significance_inflation', 'significance inflation')
def r10(ctx):
    return _all([
        _rx(r'\b(?:stands?|serves?|stood|served) as (?:an?\s+)?(?:testament|reminder|symbol|beacon|cornerstone'
            r'|bridge|gateway|hallmark)\b'),
        _rx(r'\b(?:underscor|highlight)(?:es|ed|ing)? (?:its|the|their|his|her) (?:importance|significance'
            r'|enduring|central|vital|crucial|pivotal|key)\b'),
        _rx(r'\breflects a (?:broader|wider) (?:trend|shift|pattern)\b'),
        _rx(r'\bmarks a (?:turning point|milestone|watershed|new chapter|new era)\b'),
        _rx(r'\bsymboli[sz]es\b'),
        _rx(r'\bsets? the stage for\b'),
        _rx(r'\bleft an indelible mark\b'),
        _rx(r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b'),
        _rx(r'\b(?:has|have) (?:shaped|sparked)\b'),
        _rx(r'\b(?:has|have) come to (?:define|symbolize)\b'),
    ], ctx.masked)


@rule(11, 'notability', 'notability name-dropping')
def r11(ctx):
    hits = []
    outlet = re.compile(r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+'
                        r'[A-Z][\w&.\'-]*(?:\s+[A-Z][\w&.\'-]*){0,4}(?:,\s*|\s+and\s+)[A-Z][\w&.\'-]*')
    hits.extend(m.group(0) for m in outlet.finditer(ctx.masked))
    hits.extend(_all([
        _rx(r'\b\d[\d,.]*\s*(?:[km]\s+)?(?:followers|subscribers)\b'),
        _rx(r'\b(?:strong|active|significant|robust|growing) (?:online|digital|social[- ]media) presence\b'),
        _rx(r'\bwidely covered\b'),
        _rx(r'\bindependent coverage\b'),
    ], ctx.masked))
    return hits


@rule(12, 'vague_attribution', 'vague attributions')
def r12(ctx):
    return _all([_rx(r'\bexperts (?:argue|believe|say|claim|note|suggest)\b'),
                 _rx(r'\bindustry (?:reports|observers|analysts)\b'),
                 _rx(r'\bobservers (?:have )?(?:cited|noted)\b'),
                 _rx(r'\bsome critics argue\b'),
                 _rx(r'\bresearchers have found\b'),
                 _rx(r'\bstudies suggest\b'),
                 _rx(r'\bit is widely believed\b')], ctx.masked)


@rule(13, 'article_title_noun', 'article title used as a proper noun')
def r13(ctx):
    pat = re.compile(r'The (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of '
                     r"(?:[A-Z][\w'’:-]*|of|the|and|for|in)(?:\s+(?:[A-Z][\w'’:-]*|of|the|and|for|in))*"
                     r' (?:is|are|was|were) (?:a|an|the)\b')
    return [m.group(0) for m in pat.finditer(ctx.masked)]


@rule(14, 'ecosystem_padding', 'conservation / ecosystem padding')
def r14(ctx):
    return _all([_rx(r'\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b'),
                 _rx(r'\bconservation efforts (?:are|is) (?:underway|ongoing|in place)\b'),
                 _rx(r'\bserves as an indicator species\b'),
                 _rx(r'\bcontributes to biodiversity\b')], ctx.masked)


@rule(15, 'false_ranges', 'false ranges')
def r15(ctx):
    return _all([
        _rx(r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?'
            r'\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b'),
        _rx(r'\bfrom (?:the )?humble\b[^.!?\n]{0,200}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b'),
    ], ctx.masked)


@rule(16, 'ing_tails', 'superficial -ing tail clauses')
def r16(ctx):
    return _all([_rx(r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing'
                     r'|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing'
                     r'|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying'
                     r'|epitomizing)\b')], ctx.masked)


@rule(17, 'negative_parallelism', 'negative parallelisms', moving=False)
def r17_parallel(ctx):
    return _all([
        _rx(r"\bit['’]s not (?:just|merely) (?:about|an?)\b"),
        _rx(r'\bnot only[^.!?\n]{0,40}?\bbut\b'),
        _rx(r"\bdoesn['’]t just[^,.\n]{0,40}\bit\b"),
    ], ctx.masked)


@rule(17, 'tailing_negation', 'tailing negation')
def r17_tail(ctx):
    return _all([_rx(r',\s+no\s+(?:guessing|wasted motion|waste|hassle|fluff|stress|jargon)\b')], ctx.masked)


@rule(18, 'not_x_just_y', '“Not X, just Y” framing')
def r18(ctx):
    return _all([
        _rx(r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+'),
        _rx(r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+"
            r"(?:(?:a|an|the)\s+)?\w+\s*(?:,|—|–|-)\s*(?:it['’]s|it is|it was|they['’]re"
            r"|they are|they were|that['’]s|but)\b"),
    ], ctx.masked)


@rule(19, 'filler_phrases', 'filler phrases', moving=False)
def r19(ctx):
    return _all([_rx(r'\b(?:in order to|due to the fact that|at this point in time|in the event that'
                     r'|has the ability to|it is important to note that|it should be mentioned that'
                     r'|needless to say)\b')], ctx.masked)


@rule(20, 'empty_pivots', 'empty pivot phrases')
def r20(ctx):
    return _all([_rx(r"\bit['’]s worth (?:noting|mentioning) that\b"),
                 _rx(r'\bit bears (?:noting|mentioning) that\b'),
                 _rx(r'\bone thing to (?:consider|keep in mind) is\b'),
                 _rx(r'\bit is interesting to note that\b'),
                 _rx(r'\ba key consideration is\b'),
                 _rx(r'\ba point to highlight is\b')], ctx.masked)


@rule(21, 'outcome_tails', 'outcome-speculation tails')
def r21(ctx):
    return _all([_rx(r',\s+(?:raising questions about|prompting reflection on|sparking debate about'
                     r'|with broader implications for|reshaping our understanding of|paving the way for'
                     r'|signaling a shift toward)\b')], ctx.masked)


@rule(22, 'authority_tropes', 'persuasive authority tropes', moving=False)
def r22(ctx):
    return _all([_rx(r"\bhere['’]s the thing\b|\bmake no mistake\b|\bthe truth is\b"
                     r"|\blet['’]s be honest\b|\bthe simple fact is\b|\bat its core\b"
                     r"|\bwhat really matters\b|\bmore than anything\b|\bat the end of the day\b"
                     r"|\bthe bottom line is\b|\bin reality\b|\bfundamentally,"
                     r"|\bthe real question is\b|\bthe heart of the matter\b|\bthe deeper issue\b"
                     r"|\bwhen you get down to it\b|\bwhen all is said and done\b")], ctx.masked)


@rule(23, 'editorial_interjections', 'editorial interjections')
def r23(ctx):
    return _all([_rx(r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize)\b"),
                 _rx(r'\bone must note that\b'),
                 _rx(r'\bit is worth pointing out\b'),
                 _rx(r'\bit cannot be overstated that\b'),
                 _rx(r'\bit must be emphasized that\b')], ctx.masked)


@rule(24, 'self_thoroughness', 'self-thoroughness phrases')
def r24(ctx):
    return _all([_rx(r'\bthis comprehensive (?:guide|overview|analysis)\b'),
                 _rx(r'\bthis in-depth (?:analysis|look|examination)\b'),
                 _rx(r'\bthis complete (?:guide|overview)\b'),
                 _rx(r'\ba thorough examination of\b'),
                 _rx(r'\beverything you need to know about\b')], ctx.masked)


QA_RX = _rx(r'(?:^|(?<=[.!?])\s+|\n\s*)((?:is|are|am|was|were|do|does|did|can|could|will|would|should'
            r'|has|have|had|may|might|must|shall)\s[^.?!\n]{1,80}?\?)\s*(?:yes|no|absolutely|never|maybe'
            r'|probably|always)[.!]', re.I | re.M)


@rule(25, 'qa_rhetorical', 'question-answer rhetorical pattern')
def r25(ctx):
    return [m.group(0).strip() for m in QA_RX.finditer(ctx.masked)]


@rule(26, 'concrete_evidence', '“concrete evidence” defense phrase')
def r26(ctx):
    return _all([_rx(r'\bwithout concrete (?:evidence|proof)\b'),
                 _rx(r'\bdo you have concrete evidence\b'),
                 _rx(r'\bI (?:would )?need concrete (?:evidence|examples) to\b'),
                 _rx(r'\babsent concrete proof\b'),
                 _rx(r'\bprovide concrete evidence\b')], ctx.masked)


@rule(27, 'intro_hooks', 'compulsive intro hooks')
def r27(ctx):
    return _all([
        _rx(r"\bin today['’]s(?:\s+\w+){0,2}\s+(?:world|landscape|environment|market)\b"),
        _rx(r'\bin a world where\b'),
        _rx(r'\bin an era of\b'),
        _rx(r'\bin recent years,'),
        _rx(r'\bmore than ever before\b'),
        _rx(r'\bwe live in a (?:time|world) when\b'),
        _rx(r'\b(?:great|exciting|big) news\s*[!:]'),
        _rx(r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,200}\?'),
        _rx(r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b'),
    ], ctx.masked)


@rule(30, 'diff_anchored', 'diff-anchored writing')
def r30(ctx):
    return _all([
        _rx(r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b'),
        _rx(r'\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) '
            r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b'),
        _rx(r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b'),
        _rx(r'\bpreviously\b[^.!?\n]{0,200}?\bnow\b'),
        _rx(r"\b(?:wasn['’]t|weren['’]t) there before\b"),
        _rx(r'\bwe(?:[’\']ve| have)(?: now)? (?:added|removed|replaced|refactored|migrated)\b'),
    ], ctx.masked)


@rule(31, 'signposting', 'signposting and announcements')
def r31(ctx):
    return _all([
        _rx(r"\blet['’]s (?:dive|delve|explore)\b"),
        _rx(r"\blet['’]s break (?:this|it) down\b"),
        _rx(r"\bhere['’]s what you need to know\b"),
        _rx(r'\bwithout further ado\b'),
        _rx(r"\bnow let['’]s look at\b"),
        _rx(r'\bbuckle up\b'),
        _rx(r'\bstay with me\b'),
        _rx(r'\b(?:are you )?ready to dive in\b'),
    ], ctx.masked)


@rule(32, 'cataloguing', 'cataloguing lead-ins')
def r32(ctx):
    hits = _all([
        _rx(r'\b(?:used|uses|employs?|employed|relied on|utilizes)\s+(?:several|various|a number of|multiple'
            r'|different|many|numerous)\s+\w+'),
        _rx(r'\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat'
            r'|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b', 0),
    ], ctx.masked)
    for s in ctx.sentences:
        if re.match(r'These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+'
                    r'(?:information|insight|understanding|details|data)\b', s):
            hits.append(s[:120])
    return hits


@rule(33, 'inline_header_lists', 'inline-header vertical lists')
def r33(ctx):
    return _all([
        re.compile(r'^\s*(?:(?:[-*+]|\d+[.)])\s+)?\*\*[^*\n]{1,200}?:\s*\*\*', re.M),
        re.compile(r'^\s*(?:(?:[-*+]|\d+[.)])\s+)?\*\*[^*\n]{1,200}?\*\*:', re.M),
    ], ctx.masked)


@rule(34, 'bullet_injection', 'mid-essay bullet injection')
def r34(ctx):
    if re.search(r'^#{1,6}\s', ctx.masked, re.M):
        return []
    blocks = [b for b in PARA_SPLIT.split(ctx.masked) if _has_alnum(b)]
    list_blocks = []
    prose = 0
    for b in blocks:
        lines = [ln for ln in b.split('\n') if ln.strip()]
        if lines and all(_LIST_RE.match(ln) for ln in lines):
            list_blocks.append(b.strip()[:120])
        else:
            prose += 1
    return list_blocks if list_blocks and prose >= 2 else []


@rule(35, 'fragmented_headers', 'fragmented headers')
def r35(ctx):
    hits = []
    lines = ctx.lines
    for i, line in enumerate(lines):
        m = re.match(r'^#{1,6}\s+(.+?)\s*#*\s*$', line)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or re.match(r'^(?:#|[-*+|>]|\d+[.)]\s)', nxt):
            continue
        words = nxt.split()
        if len(words) > 4:
            continue
        head = {w.lower().strip('.,:;!?') for w in m.group(1).split() if len(w) >= 3}
        if any(w.lower().strip('.,:;!?') in head for w in words if len(w) >= 3):
            hits.append(nxt[:120])
    return hits


@rule(36, 'formulaic_challenges', 'formulaic challenges sections')
def r36(ctx):
    return _all([
        _rx(r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b'),
        _rx(r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b'),
        _rx(r'\bcontinues to thrive\b'),
        _rx(r'\btypical of (?:emerging|urban|modern)\b'),
        _rx(r'\bfaces (?:several|many|numerous) challenges\b'),
    ], ctx.masked)


TRANSITIONS = ('Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless', 'Consequently',
               'Subsequently', 'Notably')


@rule(37, 'transition_clusters', 'transition cluster overuse')
def r37(ctx):
    hits = []
    for para in ctx.paragraphs:
        opened = [s for s in split_sentences(para) if s.startswith(TRANSITIONS)
                  and re.match(r'(?:%s)\b' % '|'.join(TRANSITIONS), s)]
        if len(opened) >= 2:
            hits.extend(s[:60] for s in opened)
    return hits


@rule(38, 'compulsive_conclusions', 'compulsive conclusion phrases')
def r38(ctx):
    return _all([_rx(r'^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all'
                     r'|in essence|ultimately)\b', re.I | re.M)], ctx.masked)


@rule(39, 'generic_conclusions', 'generic positive conclusions')
def r39(ctx):
    return _all([
        _rx(r'\bthe future looks bright\b'),
        _rx(r'\bexciting times (?:lie|lies) ahead\b'),
        _rx(r'\bjourney toward excellence\b'),
        _rx(r'\bstep in the right direction\b'),
        _rx(r'\b(?:the )?(?:outlook|future)(?: for [^,.!?\n]{1,60})? (?:is|looks|remains) bright\b'),
        _rx(r'\bwell[- ]positioned (?:for (?:whatever comes next|the future|the road ahead))\b'),
    ], ctx.masked)


def _sentence_lengths(ctx):
    return [len(WORD_RE.findall(s)) for s in ctx.sentences]


@rule(40, 'sentence_monotony', 'sentence-length monotony')
def r40(ctx):
    lens = _sentence_lengths(ctx)
    if len(lens) < 3:
        return []
    cv = _cv(lens)
    if cv is not None and cv < 0.35:
        return ['%d sentences, length CV %.2f' % (len(lens), cv)]
    return []


@rule(41, 'mechanical_alternation', 'mechanical sentence-length alternation', moving=False)
def r41(ctx):
    lens = _sentence_lengths(ctx)
    hits = []
    run = 1
    last = 0
    for k in range(len(lens) - 1):
        d = lens[k + 1] - lens[k]
        s = (d > 0) - (d < 0) if abs(d) >= 6 else 0
        if s and last and s == -last:
            run += 1
        elif s:
            run = 2
        else:
            run = 1
        last = s
        if run == 6:
            hits.append('alternating lengths around sentence %d' % (k + 1))
    return hits


@rule(42, 'opener_repetition', 'opener repetition', moving=False)
def r42(ctx):
    hits = []
    for para in ctx.paragraphs:
        sents = split_sentences(para)
        if len(sents) < 3:
            continue
        openers = Counter(' '.join(re.findall(r"[A-Za-z']+", s)[:2]).lower() for s in sents)
        top, n = openers.most_common(1)[0]
        if top and n >= 3:
            hits.append(top)
    return hits


@rule(44, 'paragraph_uniformity', 'uniform paragraph length')
def r44(ctx):
    counts = [len(WORD_RE.findall(p)) for p in ctx.paragraphs]
    if len(counts) < 4:
        return []
    cv = _cv(counts)
    if cv is not None and cv < 0.4:
        return ['%d paragraphs, length CV %.2f' % (len(counts), cv)]
    return []


@rule(46, 'semicolon_underuse', 'semicolon and parenthesis underuse', moving=False)
def r46(ctx):
    if len(ctx.words) < 300 or ';' in ctx.masked or ctx.masked.count('(') > 1:
        return []
    return ['no semicolons in %d words' % len(ctx.words)]


@rule(47, 'chatbot_artifacts', 'chatbot artifacts')
def r47(ctx):
    return _all([
        _rx(r'\bI hope this helps\b'),
        _rx(r'\b(?:Certainly|Of course)!'),
        _rx(r'\blet me know if you\b'),
        _rx(r'\bwould you like me to\b'),
        _rx(r'\bfeel free to (?:ask|reach out)\b'),
        _rx(r'\bhappy to help(?=[.!]|\s*$)', re.I | re.M),
        _rx(r'\b(?:here|below) is (?:an?|the)?\s*(?:overview|summary|rundown|recap|brief)\b'),
        _rx(r"\bhere (?:are|['’]s (?:a few|some|two|three)) (?:options|drafts|versions|variations)\b"),
        _rx(r"\bhere (?:is|['’]s) (?:a )?draft\b"),
        _rx(r'\bdepending on the (?:vibe|tone|style)\b'),
        _rx(r'\bI hope (?:this email )?finds you well\b'),
        _rx(r'\bas an (?:AI|LLM)(?: assistant| language model)?\b|\bas an? (?:large language model|language model)\b'),
        _rx(r'\bto (?:answer|address) your question\b'),
        _rx(r'\bin (?:response|answer) to your question\b'),
        _rx(r'\byour question (?:about|regarding|concerning)\b'),
        _rx(r'\bas (?:you )?(?:requested|asked),? here\b'),
        _rx(r"\bhere (?:is|['’]s) (?:the )?(?:first pass|revised version of|for your)\b"),
    ], ctx.masked)


@rule(48, 'sycophancy', 'sycophantic tone')
def r48(ctx):
    return _all([
        _rx(r"\byou(?:['’]re| are) absolutely right\b"),
        _rx(r'\b(?:great|excellent|good|fantastic|wonderful|brilliant|thoughtful|insightful) (?:question|point)\s*[!.,]'),
        _rx(r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b'),
        _rx(r"\bthat['’]s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"),
    ], ctx.masked)


@rule(50, 'knowledge_cutoff', 'knowledge-cutoff disclaimers')
def r50(ctx):
    return _all([
        _rx(r'\bas of my (?:last )?(?:training|knowledge)\b'),
        _rx(r'\bup to my (?:last )?(?:training|knowledge)\b'),
        _rx(r'\bwhile specific details are (?:limited|scarce|not (?:extensively |widely )?documented)\b'),
        _rx(r'\bbased on (?:the )?available information\b'),
        _rx(r'\bas of my (?:knowledge )?cutoff\b'),
        _rx(r'\bmaintains a low profile\b'),
        _rx(r'\bkeeps (?:his|her|their) personal life private\b'),
    ], ctx.masked)


@rule(51, 'copula_avoidance', 'copula avoidance')
def r51(ctx):
    return _all([
        _rx(r'\bserves as (?:an?|the)\b'),
        _rx(r'\bstands as\b'),
        _rx(r'\bfunctions as\b'),
        _rx(r'\bacts as\b'),
        _rx(r'\brepresents (?:an?|the)\b'),
        _rx(r'\bmarks (?:an?|the)\b'),
        _rx(r'\bboasts\b'),
        _rx(r'\bfeatures (?:an?|the|\d[\d,]*|several|many|numerous|multiple|various|dozens|hundreds|thousands)\b'),
        _rx(r'\boffers an?\b'),
        _rx(r'\brefers to\b'),
    ], ctx.masked)


HEDGE_RX = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively"
                      r"|fairly)\b|\bseems? (?:to|like)\b|\bappears? to\b|\bkind of\b|\bsort of\b")


@rule(54, 'hedge_stacking', 'hedge stacking', moving=False)
def r54(ctx):
    hits = []
    for s in ctx.sentences:
        found = HEDGE_RX.findall(s)
        if len(found) >= 2:
            hits.append(s[:120])
    return hits


@rule(55, 'contraction_absence', 'contraction absence', moving=False)
def r55(ctx):
    words = ctx.words
    if len(words) < 60:
        return []
    first = len(re.findall(r'\b(?:I|me|my|we|our|us)\b', ctx.masked))
    if first / float(len(words)) < 0.02:
        return []
    full = len(re.findall(r'\b(?:I am|I have|I will|I would|I do not|I did not|I cannot|do not|does not'
                          r'|did not|it is|that is|we are|we have|they are|you are|is not|are not'
                          r'|cannot|will not|there is|we will)\b', ctx.masked, re.I))
    contr = len(re.findall(r"n['’]t\b|['’](?:s|re|ve|ll|m|d)\b", ctx.masked, re.I))
    if full >= 3 and full / float(full + contr) >= 0.8:
        return ['%d full forms, %d contractions' % (full, contr)]
    return []


@rule(56, 'boldface_overuse', 'boldface overuse')
def r56(ctx):
    body = '\n'.join(ln for ln in ctx.lines if not ln.lstrip().startswith('#'))
    hits = re.findall(r'\*\*[^*\n]{1,200}\*\*', body)
    return hits if len(hits) >= 2 else []


@rule(57, 'emojis', 'emojis')
def r57(ctx):
    return [c for c in ctx.masked if 0x1F000 <= ord(c) <= 0x1FAFF or 0x2600 <= ord(c) <= 0x27BF]


@rule(58, 'em_dash_overuse', 'em-dash overuse', moving=False)
def r58(ctx):
    hits = []
    for para in ctx.paragraphs:
        n = para.count('—')
        if n >= 2:
            hits.append('%d em dashes in one paragraph' % n)
    return hits


@rule(59, 'title_case_headings', 'title case in headings')
def r59(ctx):
    small = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with', 'from', 'into', 'onto',
             'as', 'and', 'or', 'but', 'nor', 'so', 'yet', 'up', 'off', 'via', 'per', 'vs'}
    hits = []
    for line in ctx.lines:
        m = re.match(r'^#{1,6}\s+(.+?)\s*#*\s*$', line)
        if not m:
            continue
        text = m.group(1)
        words = text.split()
        if len(words) < 3 or text.upper() == text or not text[0].isalpha():
            continue
        major = [w.strip('.,:;!?()"\'') for w in words if w.lower().strip('.,:;!?()"\'') not in small]
        major = [w for w in major if w and w[0].isalpha()]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            hits.append(text[:120])
    return hits


@rule(60, 'curly_quotes', 'curly quotation marks', moving=False)
def r60(ctx):
    return [c for c in ctx.masked if c in '‘’“”']


@rule(61, 'year_range_hyphen', 'hyphen-for-en-dash in numeric ranges', moving=False)
def r61(ctx):
    hits = []
    for m in re.finditer(r'(?<!\d)(1\d{3}|20\d{2})-(1\d{3}|20\d{2})(?!\d)', ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            hits.append(m.group(0))
    return hits


@rule(62, 'invisible_characters', 'invisible / zero-width characters')
def r62(ctx):
    n = ctx.chars['invisible']
    return ['invisible character'] * n if n else []


PLACEHOLDER_BRACKET = re.compile(r'\[([^\[\]\n]{1,200})\](?![(\[])')


@rule(63, 'placeholders', 'placeholder text')
def r63(ctx):
    hits = []
    for m in PLACEHOLDER_BRACKET.finditer(ctx.masked):
        body = m.group(1)
        if re.match(r'\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b', body, re.I):
            hits.append(m.group(0))
        elif re.search(r'\b(?:name|company|client|place|source|person)\b', body, re.I) and len(body.split()) <= 4:
            hits.append(m.group(0))
        elif re.fullmatch(r'\s*[A-Z][A-Z _]{2,}\s*', body) and sum(ch.isalpha() for ch in body) >= 3:
            hits.append(m.group(0))
    hits.extend(_all([_rx(r'\{\{[^}\n]*\}\}', 0), _rx(r'(?<![A-Za-z])x{3,}(?![A-Za-z])', 0),
                      _rx(r'lorem ipsum')], ctx.masked))
    return hits


@rule(64, 'chat_reference_markup', 'chat reference-markup leak')
def r64(ctx):
    return _all([_rx(r'\bcite(?:turn|start|nav)\w*'), _rx(r'\boai_citation\w*'),
                 _rx(r'contentReference', 0), _rx(r'\bnavlist\b'),
                 _rx(r'【\d+†[^】\n]*】', 0)], ctx.masked)


@rule(65, 'ai_tracking_params', 'AI tracking parameters')
def r65(ctx):
    return _all([_rx(r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai'
                     r'|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9-]|\.[A-Za-z0-9-])')],
                 ctx.masked)


@rule(66, 'homoglyphs', 'homoglyph / mixed-script confusables')
def r66(ctx):
    n = ctx.chars['homoglyph']
    return ['mixed-script lookalike'] * n if n else []


@rule(67, 'nonstandard_spaces', 'non-standard spaces')
def r67(ctx):
    n = ctx.chars['nonstandard']
    return ['non-standard space'] * n if n else []


@rule(68, 'trailing_whitespace', 'trailing / stray whitespace', moving=False)
def r68(ctx):
    n = ctx.chars['trailing']
    return ['trailing whitespace'] * n if n else []


MARKETING_SLOP = _alt_plain = _rx(
    r"\bunlocking (?:its |the |your )?full potential\b|\bnavigating the complexities\b"
    r"|\ba testament to the (?:power|importance) of\b|\bstaying ahead of the curve\b"
    r"|\bturning challenges into opportunities\b|\btaking (?:\w+ )?to the next level\b"
    r"|\bharnessing the power of\b|\bpaving the way for\b|\bsaying goodbye to\b"
    r"|\bimagining a world where\b|\bin today['’]s fast-paced world\b")


@rule(69, 'marketing_slop', 'canonical marketing-slop phrases')
def r69(ctx):
    return _all([MARKETING_SLOP], ctx.masked)


@rule(70, 'horizontal_rules', 'decorative horizontal rules')
def r70(ctx):
    if len(ctx.lines) < 24:
        return []
    rules = [ln for ln in ctx.lines if re.match(r'^\s*(?:-{3,}|\*{3,}|_{3,})\s*$', ln)]
    return rules if len(rules) >= 3 else []


@rule(71, 'degenerate_repetition', 'degenerate repetition')
def r71(ctx):
    toks = [t.lower() for t in re.findall(r'\w+', ctx.masked)]
    if len(toks) < 12:
        return []
    grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
    counts = Counter(grams)
    repeated = sum(1 for g in grams if counts[g] > 1)
    if repeated and repeated / float(len(grams)) >= 0.2:
        top = counts.most_common(1)[0][0]
        return [' '.join(top)] * repeated
    return []


DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
FLOOR_SHORT = set(range(1, 40)) | set(range(47, 52)) | {69}


# ------------------------------------------------------------------ scoring

class Finding(object):
    def __init__(self, rl, hits):
        self.num = rl.num
        self.key = '%d_%s' % (rl.num, rl.slug)
        self.label = rl.label
        self.moving = rl.moving
        self.hits = hits


def band_for(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def score_document(ctx, findings):
    words = len(ctx.words)
    moving = {}
    for f in findings:
        if f.moving:
            moving[f.num] = moving.get(f.num, 0) + len(f.hits)
    families = set(moving)

    density = 300.0 / max(words, 300)
    raw = 0.0
    for num, hits in moving.items():
        eff = hits * density
        raw += 12 + 3 * min(max(eff - 1, 0), 5)

    cap = 100
    if len(families) == 1:
        cap = 40
    if families and families <= {40, 44}:
        cap = 40
    if families and families <= {40}:
        cap = 20
    if not families:
        cap = 0
    score = min(raw, cap)

    if words < 40:
        confidence = 'none'
        reason = 'fewer than 40 words; too short to score'
    elif words < 120:
        confidence = 'low'
        reason = 'short text (%d words)' % words
    elif words < 300:
        if len(families) == 1:
            confidence = 'low'
            reason = 'only one pattern family fired in a text under 300 words'
        else:
            confidence = 'moderate'
            reason = 'text under 300 words'
    else:
        confidence = 'high'
        reason = ''

    floor = 0
    decisive = families & DECISIVE
    if len(decisive) >= 2:
        floor = max(floor, 65)
    elif len(decisive) == 1 and confidence in ('moderate', 'high'):
        floor = max(floor, 45)
    if words < 120:
        n = len(families & FLOOR_SHORT)
        if n >= 3:
            floor = max(floor, 45)
        elif n >= 2:
            floor = max(floor, 25)
    if words >= 400:
        n = len(families)
        if n >= 6:
            floor = max(floor, 45)
        elif n >= 5:
            floor = max(floor, 25)

    final = int(round(min(100, max(score, floor))))
    return final, confidence, reason


def interval_for(ctx, score):
    sents = ctx.sentences
    if len(sents) < 4:
        return None, 'too few sentences (%d) for an interval' % len(sents)
    rng = random.Random(20260)
    reps = 20 if len(ctx.masked) <= 60000 else 8
    k = max(2, (len(sents) * 3) // 4)
    draws = []
    for _ in range(reps):
        idx = sorted(rng.sample(range(len(sents)), k))
        text = '\n'.join(sents[i] for i in idx)
        sub = Context(char_layer(''), text, False)
        findings = [Finding(rl, rl.fn(sub)) for rl in RULES]
        findings = [f for f in findings if f.hits]
        draws.append(score_document(sub, findings)[0])
    draws.sort()
    low = draws[int(0.1 * (len(draws) - 1))]
    high = draws[int(0.9 * (len(draws) - 1))]
    low = min(low, score)
    high = max(high, score)
    return [low, high], ('bootstrap over %d resamples of %d sentences (seed 20260); interval includes the point score'
                         % (reps, k))


def _sample(text):
    s = re.sub(r'\s+', ' ', text).strip()
    return s if len(s) <= 120 else s[:117] + '...'


def analyze(prose, ci=False):
    truncated = len(prose) > WINDOW
    raw = prose[:WINDOW]
    chars = char_layer(raw)
    masked = mask_markdown(chars['match'].replace('\r\n', '\n').replace('\r', '\n'))
    ctx = Context(chars, masked, truncated)

    findings = []
    for rl in RULES:
        hits = rl.fn(ctx)
        if hits:
            findings.append(Finding(rl, hits))

    score, confidence, reason = score_document(ctx, findings)
    report = {}
    for f in sorted(findings, key=lambda x: (x.num, x.key)):
        report[f.key] = {
            'label': f.label,
            'count': len(f.hits),
            'samples': [_sample(h) for h in f.hits[:3]],
        }
    metrics = {
        'scanned_chars': len(raw),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_for(score),
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': chars['invisible'],
        'nonstandard_spaces': chars['nonstandard'],
        'homoglyphs': chars['homoglyph'],
        'word_count': len(ctx.words),
    }
    if ci:
        interval, note = interval_for(ctx, score)
        metrics['score_ci'] = interval
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# --------------------------------------------------------------- extraction

def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _gather(el, names):
    parts = []
    for node in el.iter():
        name = _local(node.tag)
        if name in names and node.text:
            parts.append(node.text)
        elif name == 'tab':
            parts.append('\t')
        elif name == 'br' and 'br' in names:
            parts.append('\n')
    return ''.join(parts)


def _natural_key(name):
    return [(0, int(t)) if t.isdigit() else (1, t.lower()) for t in re.split(r'(\d+)', name)]


def _xml(data):
    return ET.fromstring(data)


def _docx_text(z):
    root = _xml(z.read('word/document.xml'))
    paras = [_gather(p, {'t'}) for p in root.iter() if _local(p.tag) == 'p']
    return '\n'.join(paras)


def _pptx_text(z):
    slides = []
    for name in z.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', name)
        if m:
            slides.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(slides):
        try:
            root = _xml(z.read(name))
        except ET.ParseError:
            continue
        paras = [_gather(p, {'t'}) for p in root.iter() if _local(p.tag) == 'p']
        out.append('\n'.join(p for p in paras if p))
    return '\n'.join(out)


def _xlsx_text(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = _xml(z.read('xl/sharedStrings.xml'))
        for si in root:
            if _local(si.tag) == 'si':
                shared.append(''.join(t.text or '' for t in si.iter() if _local(t.tag) == 't'))
    sheets = []
    if 'xl/workbook.xml' in z.namelist():
        rels = {}
        if 'xl/_rels/workbook.xml.rels' in z.namelist():
            rroot = _xml(z.read('xl/_rels/workbook.xml.rels'))
            for rel in rroot:
                if _local(rel.tag) == 'Relationship':
                    target = rel.get('Target', '')
                    target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
                    rels[rel.get('Id')] = target
        wroot = _xml(z.read('xl/workbook.xml'))
        for el in wroot.iter():
            if _local(el.tag) == 'sheet':
                rid = None
                for k, v in el.attrib.items():
                    if _local(k) == 'id':
                        rid = v
                if rid in rels and rels[rid] in z.namelist():
                    sheets.append(rels[rid])
    if not sheets:
        sheets = sorted((n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n)),
                        key=_natural_key)
    out = []
    for name in sheets:
        root = _xml(z.read(name))
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            text = None
            if kind == 's':
                v = next((x.text for x in c if _local(x.tag) == 'v'), None)
                if v is not None and re.fullmatch(r'\d+', v.strip()) and int(v) < len(shared):
                    text = shared[int(v)]
            elif kind == 'inlineStr':
                text = ''.join(t.text or '' for t in c.iter() if _local(t.tag) == 't')
            elif kind == 'str':
                text = next((x.text for x in c if _local(x.tag) == 'v'), None)
            if text:
                cells.append(text)
        out.append('\n'.join(cells))
    return '\n'.join(out)


def _odf_inline(el):
    parts = []

    def walk(e):
        for ch in e:
            name = _local(ch.tag)
            if name in ('annotation', 'notes', 'annotation-end'):
                pass
            elif name == 's':
                count = 1
                for k, v in ch.attrib.items():
                    if _local(k) == 'c' and v.isdigit():
                        count = int(v)
                parts.append(' ' * count)
            elif name == 'tab':
                parts.append('\t')
            elif name == 'line-break':
                parts.append('\n')
            else:
                if ch.text:
                    parts.append(ch.text)
                walk(ch)
            if ch.tail:
                parts.append(ch.tail)

    if el.text:
        parts.append(el.text)
    walk(el)
    return ''.join(parts)


def _odf_paragraphs(el, out):
    for ch in el:
        name = _local(ch.tag)
        if name in ('p', 'h'):
            out.append(_odf_inline(ch))
        elif name in ('annotation', 'notes'):
            continue
        else:
            _odf_paragraphs(ch, out)


def _odf_text(z):
    root = _xml(z.read('content.xml'))
    body = next((el for el in root.iter() if _local(el.tag) == 'body'), root)
    out = []
    _odf_paragraphs(body, out)
    return '\n'.join(out)


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section', 'article',
             'blockquote', 'ul', 'ol', 'table', 'header', 'footer', 'dt', 'dd', 'pre', 'figure', 'hr'}
    SKIP = {'script', 'style', 'nav', 'head', 'title'}

    def __init__(self):
        HTMLParser.__init__(self)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_to_text(data):
    parser = _HTMLText()
    parser.feed(data)
    parser.close()
    lines = []
    for line in ''.join(parser.parts).split('\n'):
        flat = ' '.join(line.split())
        if flat:
            lines.append(flat)
    return '\n'.join(lines)


def _epub_text(z):
    chapters = []
    for name in z.namelist():
        low = name.lower()
        if not low.endswith(('.xhtml', '.html', '.htm')) or low.startswith('meta-inf/'):
            continue
        base = low.rsplit('/', 1)[-1]
        if re.search(r'(^|[/_.\-])nav([/_.\-]|$)', low) or base.startswith('toc'):
            continue
        chapters.append(name)
    chapters.sort(key=_natural_key)
    texts = []
    for name in chapters:
        raw = z.read(name).decode('utf-8', errors='replace')
        texts.append(_html_to_text(raw))
    return '\n'.join(t for t in texts if t)


def _ipynb_text(data):
    try:
        nb = json.loads(data.decode('utf-8-sig'))
    except (ValueError, UnicodeDecodeError):
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = ''.join(src)
        if not isinstance(src, str):
            return ''
        out.append(src)
    return '\n'.join(out)


def decode_text(data):
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        try:
            return data.decode('utf-16')
        except UnicodeDecodeError:
            return ''
    if b'\x00' in data:
        return ''
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    return data.decode('utf-8', errors='replace')


class ReadError(Exception):
    pass


def extract_path(path):
    lower = path.lower()
    ext = lower[lower.rfind('.'):] if '.' in lower.rsplit('/', 1)[-1] else ''
    if ext in NO_TEXT_EXTS:
        return ''
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except (OSError, IOError) as exc:
        raise ReadError(str(exc))
    if ext in ZIP_EXTS:
        return _extract_zip(data, ext)
    if ext in NOTEBOOK_EXTS:
        return _ipynb_text(data).strip()
    return decode_text(data)


def _extract_zip(data, ext):
    import io
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ReadError('not a readable archive')
    with z:
        try:
            if ext in ('.docx', '.docm'):
                text = _docx_text(z)
            elif ext in ('.pptx', '.pptm'):
                text = _pptx_text(z)
            elif ext in ('.xlsx', '.xlsm'):
                text = _xlsx_text(z)
            elif ext in ('.odt', '.odp', '.ods'):
                text = _odf_text(z)
            elif ext == '.epub':
                text = _epub_text(z)
            else:
                text = ''
        except (ET.ParseError, KeyError, ValueError):
            text = ''
    return text.strip()


# --------------------------------------------------------------------- cleanup

def scrub(text):
    """Scrubbed text for --clean: invisible characters removed, spaces normalized,
    lookalikes folded, trailing whitespace trimmed, one final line ending kept."""
    cleaned = char_layer(text)['clean']
    crlf = '\r\n' in cleaned
    nl = '\r\n' if crlf else '\n'
    lines = []
    for ln in cleaned.split('\n'):
        body = ln[:-1] if ln.endswith('\r') else ln
        lines.append(body.rstrip(' \t'))
    while lines and not lines[0].strip():
        lines.pop(0)
    body = nl.join(lines).rstrip()
    if body and text.endswith('\n'):
        body += nl
    return body


# ------------------------------------------------------------------------ CLI

def _fail(message, code):
    sys.stderr.write(json.dumps({'error': message}) + '\n')
    return code


def _write_stdout(text):
    sys.stdout.buffer.write(text.encode('utf-8'))
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    end_of_options = False
    files = []
    for arg in argv:
        if end_of_options:
            files.append(arg)
        elif arg == '--':
            end_of_options = True
        elif arg in ('-h', '--help'):
            _write_stdout(USAGE)
            return 0
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-'):
            return _fail('unknown option %s; see --help' % arg, 2)
        else:
            files.append(arg)

    if len(files) > 1:
        sys.stderr.write('note: only the first file was scanned: %s\n' % files[0])

    try:
        if files:
            text = extract_path(files[0])
        else:
            text = decode_text(sys.stdin.buffer.read())
    except ReadError as exc:
        return _fail('cannot read input: %s' % exc, 1)

    if not text.strip():
        return _fail('empty input', 1)

    if clean:
        _write_stdout(scrub(text))
        return 0

    report = analyze(text, ci=ci)
    _write_stdout(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
