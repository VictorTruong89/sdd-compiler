# prosecheck 0.9.3

A local detector for AI-writing patterns in prose, with a Claude Code plugin around it.
Python 3.9+ standard library for the detector; Node.js for the plugin hooks. No network, no model, no accounts.

## Detector

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]

With no FILE, standard input is read. The default output is a JSON report of findings and metrics
(score 0-100, band, confidence). `--clean` prints scrubbed text instead. `--ci` adds a score interval.
The first 262,144 characters of extracted prose are scanned. Supported formats: plain text
(`.md`, `.txt`, `.rst`, `.tex`, `.org`, `.adoc`, ...), zip-based documents (`.docx`, `.pptx`, `.xlsx`,
`.odt`, `.epub`, ...), and `.ipynb` notebooks.

## Plugin

- `hooks/prosecheck-activate.js` - session start: writing contract (and a one-time welcome)
- `hooks/prosecheck-tracker.js` - prompt submit: `/prosecheck` commands, stop phrases, live reminder
- `hooks/prosecheck-subagent.js` - subagent start: the same contract for delegated work
- `hooks/prosecheck-guard.js` - post tool use: scores saved prose files after Write, Edit, MultiEdit, NotebookEdit, apply_patch
- `hooks/prosecheck-stats.js` - on-demand token and prose-score report for a transcript
- `commands/prosecheck.md` - the `/prosecheck` menu entry
- `.cursor/rules/prosecheck.mdc` - the shipped Cursor rule that `/prosecheck init` copies

The specification is in `spec/`. Code, commits, configuration, and chat are never touched.
