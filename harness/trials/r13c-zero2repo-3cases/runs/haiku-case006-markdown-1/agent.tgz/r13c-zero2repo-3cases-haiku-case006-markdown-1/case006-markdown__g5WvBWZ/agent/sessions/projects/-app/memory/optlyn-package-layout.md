---
name: optlyn-package-layout
description: Where the Optlyn implementation lives in /app and the module-naming gotcha that bit during the build
metadata:
  node_type: memory
  type: project
  originSessionId: 952f8771-e013-4c83-b7b0-9ba089d3bd92
  modified: 2026-10-15T04:41:15.719Z
---

Optlyn (a Click-style CLI library) is implemented under `/app/src/optlyn/` as a src-layout package.
Modules: `core.py` (Parameter/Option/Argument, option parser, Context, Command/Group/CommandCollection, help),
`paramtypes.py` (ParamType classes), `utils.py` (echo, style, prompt, confirm, file helpers, pager, editor),
`decorators.py`, `shell_completion.py`, `testing.py` (CliRunner), `formatting.py` (wrap_text), `exceptions.py`.
A `pyproject.toml` at `/app` declares the setuptools src layout. The spec lives in `/app/spec/` and must stay untouched.

**Why:** the first build named a module `types.py`, which shadowed the stdlib `types` whenever Python ran from
inside `src/optlyn` (stdlib `enum`/`pathlib` import it). It was renamed to `paramtypes.py`.

**How to apply:** never name package modules after stdlib modules (`types`, `io`, `enum`, `json`, ...).
When running ad-hoc scripts, use `PYTHONPATH=/app/src` and do not `cd` into the package directory.
