"""Text wrapping and aligned two-column layout for help pages."""

import re
import textwrap


def wrap_text(
    text,
    width=78,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap ``text`` to ``width`` columns.

    With ``preserve_paragraphs``, blank lines separate paragraphs. A paragraph whose
    first line is only a backspace is kept line-for-line (the backspace is removed).
    """
    if not text:
        return ""
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        )
    out = []
    for paragraph in re.split(r"\n\s*\n", text.strip("\n")):
        lines = paragraph.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [line for line in lines[1:]]
            out.append("\n".join(subsequent_indent + line for line in kept))
            continue
        out.append(
            textwrap.fill(
                " ".join(paragraph.split()),
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
            )
        )
    return "\n\n".join(out)


def format_rows(rows, width, indent=2, max_first=30, ellipsize=False):
    """Lay out ``(first, second)`` pairs in two aligned columns.

    The first column is padded to the longest first entry (capped at ``max_first``).
    Second-column text is wrapped to the remaining width; with ``ellipsize`` it is
    cut to one line instead.
    """
    if not rows:
        return ""
    first_width = min(max(len(first) for first, _ in rows), max_first)
    column = indent + first_width + 2
    avail = max(width - column, 10)
    lines = []
    for first, second in rows:
        if not second:
            lines.append(" " * indent + first)
            continue
        if ellipsize and len(second) > avail:
            wrapped = [second[: max(avail - 3, 0)].rstrip() + "..."]
        else:
            wrapped = textwrap.wrap(second, avail) or [""]
        if len(first) <= first_width:
            lines.append(" " * indent + first.ljust(first_width) + "  " + wrapped[0])
        else:
            lines.append(" " * indent + first)
            lines.append(" " * column + wrapped[0])
        for extra in wrapped[1:]:
            lines.append(" " * column + extra)
    return "\n".join(lines)
