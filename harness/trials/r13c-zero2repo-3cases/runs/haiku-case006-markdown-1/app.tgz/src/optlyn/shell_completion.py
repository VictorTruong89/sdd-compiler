"""Shell completion: registration scripts and suggestion output."""

import os
import re
import sys

from .core import Context, Group, Option
from .paramtypes import Choice, File, Path
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")

# Lines starting with this byte are path requests, never plain suggestions.
PATH_MARKER = "\x01"


def _func_id(prog_name):
    return re.sub(r"\W", "_", prog_name)


def get_script(prog_name, shell, complete_var):
    """Return the registration script for ``shell``."""
    ident = _func_id(prog_name)
    if shell == "bash":
        return (
            f"_{ident}_completion() {{\n"
            f"    local words=\"${{COMP_WORDS[*]}}\"\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"$words\" COMP_CWORD=$COMP_CWORD "
            f"{complete_var}=bash_complete \"$1\" | grep -v $'^\\x01') )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F _{ident}_completion {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"_{ident}_completion() {{\n"
            f"    local -a lines values\n"
            f"    lines=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog_name})}}\")\n"
            f"    local line\n"
            f"    for line in $lines; do\n"
            f"        [[ $line == $'\\x01'* ]] && continue\n"
            f"        values+=(\"${{line//:/\\\\:}}\")\n"
            f"    done\n"
            f"    compadd -- $values\n"
            f"}}\n"
            f"compdef _{ident}_completion {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"function _{ident}_completion\n"
            f"    set -l words (commandline -opc)\n"
            f"    set -l current (commandline -ct)\n"
            f"    env COMP_WORDS=(string join ' ' -- $words $current) "
            f"COMP_CWORD=$current {complete_var}=fish_complete {prog_name} "
            f"| grep -v '^\\x01'\n"
            f"end\n"
            f"complete -c {prog_name} -f -a '(_{ident}_completion)'\n"
        )
    if shell == "powershell":
        return (
            f"Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{\n"
            f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
            f"    $env:COMP_WORDS = $commandAst.ToString()\n"
            f"    $env:COMP_CWORD = $wordToComplete\n"
            f"    $env:{complete_var} = 'powershell_complete'\n"
            f"    & '{prog_name}' | ForEach-Object {{\n"
            f"        if ($_.StartsWith([string][char]1)) {{ return }}\n"
            f"        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)\n"
            f"    }}\n"
            f"    Remove-Item Env:\\{complete_var} -ErrorAction SilentlyContinue\n"
            f"}}\n"
        )
    raise ValueError(f"Unknown shell {shell!r}")


def _read_words(shell):
    line = os.environ.get("COMP_WORDS", "")
    raw_index = os.environ.get("COMP_CWORD", "")
    words = line.split(" ")
    if shell == "fish":
        incomplete = raw_index
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        index = int(raw_index)
    except ValueError:
        index = len(words) - 1
    incomplete = words[index] if 0 <= index < len(words) else ""
    args = words[1:index] if index > 1 else []
    return args, incomplete


def _path_request(param):
    if isinstance(param.type, File):
        return "file"
    if isinstance(param.type, Path) and param.type.dir_okay and not param.type.file_okay:
        return "dir"
    return "file"


def _suggestions(ctx, param, incomplete):
    """Return ``(value, help)`` pairs or path-request kinds for a parameter's value."""
    if param.shell_complete_func is not None or isinstance(param.type, Choice):
        items = param.shell_complete(ctx, incomplete)
        rv = []
        for item in items:
            if isinstance(item, str):
                rv.append((item, None))
            else:
                rv.append((item.value, getattr(item, "help", None)))
        return rv
    if isinstance(param.type, (File, Path)):
        return [(PATH_MARKER + _path_request(param), incomplete)]
    return []


def _format(entries, shell):
    lines = []
    for value, help_text in entries:
        if value.startswith(PATH_MARKER):
            lines.append(f"{value}\t{help_text or ''}")
        elif help_text and shell in ("zsh", "fish"):
            lines.append(f"{value}\t{help_text}")
        else:
            lines.append(value)
    return lines


def _visible_options(cmd, ctx):
    names = []
    for param in cmd.get_params(ctx):
        if not isinstance(param, Option) or param.hidden:
            continue
        names.extend(param.opts + param.secondary_opts)
    return names


def complete(cli, prog_name, shell):
    """Return the suggestion lines for the current completion request."""
    args, incomplete = _read_words(shell)
    ctx = Context(cli, info_name=prog_name)
    node = cli
    pending = None
    i = 0
    while i < len(args):
        token = args[i]
        i += 1
        if token.startswith("-") and len(token) > 1:
            found = None
            for param in node.get_params(ctx):
                if isinstance(param, Option) and token in param.opts + param.secondary_opts:
                    found = param
                    break
            if found is not None and found.takes_value:
                if i < len(args):
                    i += 1
                elif i == len(args):
                    pending = found
            continue
        if isinstance(node, Group):
            child = node.get_command(ctx, token)
            if child is not None:
                node = child
                ctx = Context(child, info_name=token, parent=ctx)
                pending = None

    if pending is not None:
        return _format(_suggestions(ctx, pending, incomplete), shell)
    if incomplete.startswith("-"):
        names = [n for n in _visible_options(node, ctx) if n.startswith(incomplete)]
        return _format([(name, None) for name in names], shell)
    if isinstance(node, Group):
        entries = []
        for name in node.list_commands(ctx):
            cmd = node.get_command(ctx, name)
            if cmd is None or cmd.hidden or not name.startswith(incomplete):
                continue
            entries.append((name, cmd.get_short_help_str() or None))
        return _format(entries, shell)
    for param in node.params:
        if param.is_argument:
            return _format(_suggestions(ctx, param, incomplete), shell)
    return []


def run_completion(cli, prog_name, instruction, standalone_mode):
    """Handle a ``<shell>_source`` or ``<shell>_complete`` instruction."""
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        if standalone_mode:
            sys.exit(1)
        return None
    complete_var = f"_{_func_id(prog_name).upper()}_COMPLETE"
    if mode == "source":
        echo(get_script(prog_name, shell, complete_var))
    else:
        lines = complete(cli, prog_name, shell)
        if lines:
            echo("\n".join(lines))
    if standalone_mode:
        sys.exit(0)
    return None
