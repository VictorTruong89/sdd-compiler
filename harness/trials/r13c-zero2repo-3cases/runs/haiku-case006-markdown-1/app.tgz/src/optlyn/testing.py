"""In-process runner for invoking commands and capturing their output."""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Recorder:
    """Keeps captured bytes per stream plus the interleaved order of all writes."""

    def __init__(self):
        self.buffers = {"stdout": bytearray(), "stderr": bytearray()}
        self.combined = bytearray()


class _CaptureSink(io.BufferedIOBase):
    def __init__(self, recorder, name):
        self._recorder = recorder
        self._name = name

    def writable(self):
        return True

    def write(self, data):
        data = bytes(data)
        self._recorder.buffers[self._name].extend(data)
        self._recorder.combined.extend(data)
        return len(data)

    def flush(self):
        pass


class _RunnerInput(io.StringIO):
    """Standard input for a run. Reads echo into captured output when asked to."""

    def __init__(self, data, output, echo_stdin=False, echo_prompts=True):
        super().__init__(data)
        self._output = output
        self._echo_stdin = echo_stdin
        self._echo_prompts = echo_prompts

    def readline(self, size=-1):
        line = super().readline(size)
        if line and self._echo_stdin:
            self._output.write(line)
            self._output.flush()
        return line

    def prompt_readline(self, hidden=False):
        line = super().readline()
        if line and not hidden and self._echo_prompts and not self._echo_stdin:
            self._output.write(line)
            self._output.flush()
        return line

    def read_char(self):
        ch = super().read(1)
        if ch == "":
            raise EOFError()
        if self._echo_stdin:
            self._output.write(ch)
            self._output.flush()
        return ch

    def isatty(self):
        return False


class Result:
    """The outcome of one runner invocation."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, combined_bytes, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = bytes(stdout_bytes)
        self.stderr_bytes = bytes(stderr_bytes)
        self.output_bytes = bytes(combined_bytes)
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command with a list of tokens and captures output and exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def _environment(self, env):
        merged = dict(self.env)
        merged.update(env or {})
        saved = {}
        for key, value in merged.items():
            saved[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        try:
            yield
        finally:
            for key, value in saved.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    @contextlib.contextmanager
    def isolation(self, input=None, env=None):
        """Swap the standard streams for capturing streams. Yields the recorder."""
        recorder = _Recorder()
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        if self.capture == "fd":
            with self._fd_capture(recorder, input, env):
                yield recorder
            return
        if isinstance(input, str):
            data = input
        elif isinstance(input, bytes):
            data = input.decode(self.charset, "replace")
        else:
            data = ""
        out_stream = io.TextIOWrapper(
            _CaptureSink(recorder, "stdout"), encoding=self.charset, newline="\n", write_through=True
        )
        err_stream = io.TextIOWrapper(
            _CaptureSink(recorder, "stderr"), encoding=self.charset, newline="\n", write_through=True
        )
        in_stream = _RunnerInput(data, out_stream, echo_stdin=self.echo_stdin)
        sys.stdin, sys.stdout, sys.stderr = in_stream, out_stream, err_stream
        try:
            with self._environment(env):
                yield recorder
        finally:
            out_stream.flush()
            err_stream.flush()
            sys.stdin, sys.stdout, sys.stderr = old_streams

    @contextlib.contextmanager
    def _fd_capture(self, recorder, input, env):
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        with tempfile.TemporaryFile() as out_file, tempfile.TemporaryFile() as err_file:
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            data = input if isinstance(input, str) else (input or b"").decode(self.charset, "replace")
            out_stream = io.TextIOWrapper(
                os.fdopen(os.dup(1), "wb", buffering=0), encoding=self.charset, newline="\n", write_through=True
            )
            err_stream = io.TextIOWrapper(
                os.fdopen(os.dup(2), "wb", buffering=0), encoding=self.charset, newline="\n", write_through=True
            )
            in_stream = _RunnerInput(data, out_stream, echo_stdin=self.echo_stdin)
            sys.stdin, sys.stdout, sys.stderr = in_stream, out_stream, err_stream
            try:
                with self._environment(env):
                    yield recorder
            finally:
                out_stream.flush()
                err_stream.flush()
                sys.stdin, sys.stdout, sys.stderr = old_streams
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                out_stream.close()
                err_stream.close()
                out_file.seek(0)
                err_file.seek(0)
                recorder.buffers["stdout"].extend(out_file.read())
                recorder.buffers["stderr"].extend(err_file.read())
                recorder.combined.extend(recorder.buffers["stdout"])
                recorder.combined.extend(recorder.buffers["stderr"])

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the given tokens. Returns a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()
        if color is not None:
            extra.setdefault("color", color)
        extra.setdefault("standalone_mode", True)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode")

        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env) as recorder:
            try:
                cli.main(
                    args=list(args),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(f"{code}\n")
                    exit_code = 1
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exc_info = sys.exc_info()
                exit_code = 1
        return Result(
            self,
            recorder.buffers["stdout"],
            recorder.buffers["stderr"],
            recorder.combined,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory, which is removed on exit unless ``temp_dir`` is given."""
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


__all__ = ["CliRunner", "Result"]
