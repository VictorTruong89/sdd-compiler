"""Parameters, invocation contexts, commands, groups, parsing, and help pages."""

import contextlib
import inspect
import os
import re
import sys

from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import format_rows, wrap_text
from .paramtypes import BOOL, INT, Choice, File, Path, Tuple, convert_type
from .utils import _prompt_loop, confirm as _confirm, echo, pop_context, push_context

TRUE_STRINGS = ("1", "true", "t", "yes", "y", "on")
FALSE_STRINGS = ("0", "false", "f", "no", "n", "off")

_PREFIX_CHARS = "-/+"
_PROMPT_REQUEST = object()
_CHAIN = object()


class ParameterSource:
    """Where a parameter value came from. Compare with ``is`` or ``==``."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


def _is_short_opt(name):
    return len(name) == 2 and name[1] != name[0]


def _infer_dest(opts):
    longs = [opt for opt in opts if not _is_short_opt(opt)]
    chosen = longs[0] if longs else opts[0]
    return chosen.lstrip(_PREFIX_CHARS).replace("-", "_")


def _clean_help(text):
    if text is None:
        return None
    text = text.split("\f", 1)[0]
    return inspect.cleandoc(text)


def _default_prog_name():
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "optlyn"


def _complete_var_name(prog_name):
    return "_%s_COMPLETE" % prog_name.upper().replace("-", "_")


def _deprecation_warning(text, note):
    message = f"DeprecationWarning: {text}"
    if note:
        message += f" {note}"
    echo(message, err=True)


# ---------------------------------------------------------------- parameters


class Parameter:
    """Common state of options and arguments."""

    is_argument = False
    is_flag = False
    count = False
    is_optional_value = False
    prompt = False
    prompt_required = False
    show_default = None
    show_envvar = False

    def __init__(
        self,
        name,
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
    ):
        self.name = name
        self.type = convert_type(type, default)
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.help = help
        self.hidden = hidden

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def get_error_hint(self, ctx):
        return f"'{self.name}'"

    def get_default(self, ctx):
        value = self.default
        if callable(value):
            value = value()
        return value

    def process_value(self, ctx, value):
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def envvar_names(self, ctx):
        if self.envvar is None:
            return []
        if isinstance(self.envvar, str):
            return [self.envvar]
        return list(self.envvar)

    def _split(self, text):
        separator = os.pathsep if isinstance(self.type, (File, Path)) else None
        parts = text.split(separator) if separator else text.split()
        if self.nargs > 1:
            if self.multiple:
                return [
                    tuple(parts[i : i + self.nargs]) for i in range(0, len(parts), self.nargs)
                ]
            return [tuple(parts)]
        return parts

    def env_occurrences(self, text):
        if self.multiple or self.nargs != 1:
            return self._split(text)
        return [text]

    def env_raws(self, ctx):
        for name in self.envvar_names(ctx):
            value = os.environ.get(name)
            if value:
                occurrences = self.env_occurrences(value)
                if occurrences:
                    return occurrences
        return None

    def default_map_raws(self, ctx):
        default_map = ctx.default_map if ctx is not None else None
        if not default_map or self.name not in default_map:
            return None
        value = default_map[self.name]
        if value is None:
            return None
        if isinstance(value, str):
            if self.multiple and self.nargs == 1:
                self._not_iterable()
            if self.nargs != 1:
                return self.env_occurrences(value)
            return [value]
        if self.multiple:
            if not isinstance(value, (list, tuple)):
                self._not_iterable()
            return list(value)
        return [value]

    def default_raws(self, ctx):
        value = self.get_default(ctx)
        if self.multiple:
            if value is None:
                return []
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                self._not_iterable()
            return list(value)
        if value is None:
            return []
        return [value]

    def _not_iterable(self):
        raise BadParameter(
            "the default needs an iterable (sequence) of values, not a single value.",
            param=self,
        )

    def convert_raw(self, ctx, raw):
        if isinstance(self.type, Tuple):
            return self.type.convert(raw, self, ctx)
        if self.nargs > 1:
            if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple)):
                raise BadParameter(f"{raw!r} does not match {self.nargs} values.", param=self)
            return tuple(self.type.convert(item, self, ctx) for item in raw)
        return self.type.convert(raw, self, ctx)

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    def __init__(
        self,
        param_decls=None,
        *,
        type=None,
        default=None,
        required=False,
        is_flag=None,
        flag_value=None,
        count=False,
        multiple=False,
        nargs=None,
        envvar=None,
        allow_from_autoenv=True,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        callback=None,
        is_eager=False,
        expose_value=True,
        hidden=False,
        deprecated=False,
        help=None,
        metavar=None,
        show_default=None,
        show_envvar=False,
        shell_complete=None,
    ):
        opts, secondary, name = [], [], None
        for decl in list(param_decls or ()):
            if decl and decl[0] in _PREFIX_CHARS:
                split = decl.find("/", 1)
                if split > 0 and decl[split + 1 : split + 2] in tuple(_PREFIX_CHARS):
                    opts.append(decl[:split])
                    secondary.append(decl[split + 1 :])
                else:
                    opts.append(decl)
            else:
                if name is not None:
                    raise TypeError("An option takes only one destination name.")
                name = decl
        if name is None:
            if not opts:
                raise TypeError("An option needs at least one flag name or a destination name.")
            name = _infer_dest(opts)

        if count and is_flag:
            raise TypeError("A counting option cannot also be a flag.")
        if count:
            is_flag = False
        if is_flag is None:
            is_flag = flag_value is None and bool(secondary)
        if count and default is None:
            default = 0
        if is_flag:
            if flag_value is None:
                flag_value = (not default) if isinstance(default, bool) else True
            if default is None:
                default = False
            if type is None:
                type = BOOL
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.is_optional_value = not self.is_flag and not self.count and flag_value is not None
        self.flag_value = flag_value

        if count and type is None:
            type = INT
        resolved = convert_type(type, default)
        if nargs is None:
            nargs = len(resolved.types) if isinstance(resolved, Tuple) else 1
        if nargs < 1:
            raise TypeError("nargs must be a positive integer.")
        if self.is_optional_value and nargs != 1:
            raise TypeError("An option with an optional value takes exactly one token.")
        if deprecated and (required or prompt):
            raise ValueError("A deprecated option cannot be required or prompt.")

        self.opts = opts
        self.secondary_opts = secondary
        self.allow_from_autoenv = allow_from_autoenv
        self.prompt = bool(prompt)
        self.prompt_required = prompt_required
        if isinstance(prompt, str) and prompt:
            self.prompt_text = prompt
        else:
            self.prompt_text = name.replace("_", " ").capitalize()
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        super().__init__(
            name,
            type=resolved,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
        )

    @property
    def takes_value(self):
        return not (self.is_flag or self.count)

    def get_error_hint(self, ctx):
        return "'" + "/".join(self.opts + self.secondary_opts) + "'"

    def get_metavar_display(self, ctx):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self)

    def envvar_names(self, ctx):
        names = super().envvar_names(ctx)
        prefix = getattr(ctx, "auto_envvar_prefix", None) if ctx is not None else None
        if self.allow_from_autoenv and prefix:
            names.append("_".join([prefix, self.name]).upper().replace("-", "_"))
        return names

    def env_occurrences(self, text):
        if self.is_flag:
            value = self._flag_from_env(text)
            return None if value is None else [value]
        return super().env_occurrences(text)

    def _flag_from_env(self, text):
        token = text.strip().lower()
        if not isinstance(self.flag_value, bool) and text == str(self.flag_value):
            return self.flag_value
        if token in TRUE_STRINGS:
            return True
        if token in FALSE_STRINGS:
            return False
        if token == "":
            return False if isinstance(self.flag_value, bool) else None
        if isinstance(self.flag_value, bool):
            raise BadParameter(f"{text!r} is not a valid boolean.", param=self)
        return None

    def prompt_value(self, ctx, default):
        if self.is_flag:
            return _confirm(self.prompt_text, default=bool(default))
        return _prompt_loop(
            self.prompt_text,
            default,
            self.hide_input,
            self.confirmation_prompt,
            lambda value: self.type.convert(value, self, ctx),
            ": ",
            True,
            False,
        )


class Argument(Parameter):
    """A positional parameter bound in declaration order."""

    is_argument = True

    def __init__(
        self,
        param_decls=None,
        *,
        required=None,
        default=None,
        type=None,
        nargs=None,
        envvar=None,
        deprecated=False,
        help=None,
        metavar=None,
        callback=None,
        expose_value=True,
        is_eager=False,
        hidden=False,
        shell_complete=None,
    ):
        decls = list(param_decls or ())
        if len(decls) != 1 or not decls[0] or decls[0][0] in _PREFIX_CHARS:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0].replace("-", "_")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        variadic = nargs == -1
        if required is None:
            required = default is None and not variadic
        if deprecated and required:
            raise ValueError("A deprecated argument cannot be required.")
        resolved = convert_type(type, default)
        if nargs == 1 and isinstance(resolved, Tuple):
            nargs = len(resolved.types)
        self.variadic = variadic
        self.arity = nargs
        super().__init__(
            name,
            type=resolved,
            default=default,
            required=required,
            callback=callback,
            nargs=1 if variadic else nargs,
            multiple=variadic,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
        )
        self.min_tokens = self.arity if (required and not variadic) else 0

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def placeholder(self):
        return self.metavar or self.name.upper()


def _resolve_raws(ctx, param, occurrences):
    """Pick the first source that supplies a value: command line, env, default map, default."""
    forced = False
    if occurrences:
        raws = [raw for _, raw in occurrences]
        if any(raw is _PROMPT_REQUEST for raw in raws):
            forced = True
            raws = [raw for raw in raws if raw is not _PROMPT_REQUEST]
        if raws:
            return raws, ParameterSource.COMMANDLINE, forced
    raws = param.env_raws(ctx)
    if raws is not None:
        return raws, ParameterSource.ENVIRONMENT, forced
    raws = param.default_map_raws(ctx)
    if raws is not None:
        return raws, ParameterSource.DEFAULT_MAP, forced
    return param.default_raws(ctx), ParameterSource.DEFAULT, forced


def _winners(params, occurrences):
    """For parameters sharing a destination, pick the one whose source is most explicit."""
    winners = {}
    for param in params:
        current = winners.get(param.name)
        if current is None or _last_seq(occurrences, param) >= _last_seq(occurrences, current):
            winners[param.name] = param
    return winners


def _last_seq(occurrences, param):
    seqs = [seq for seq, _ in occurrences.get(param, [])]
    return max(seqs) if seqs else 0


# ------------------------------------------------------------------ parsing


class _OptionParser:
    """Splits an argument list into option occurrences and positional tokens."""

    def __init__(self, ctx, params):
        self.ctx = ctx
        self.opts = {}
        for param in params:
            if isinstance(param, Option):
                for opt in param.opts:
                    self.opts.setdefault(opt, (param, False))
                for opt in param.secondary_opts:
                    self.opts.setdefault(opt, (param, True))
        self.prefixes = {"-"} | {opt[0] for opt in self.opts}
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        self.normalize = ctx.token_normalize_func
        self.occurrences = {}
        self.positional = []
        self._seq = 0

    def _lookup(self, name):
        if name in self.opts:
            return name, self.opts[name]
        if self.normalize is not None:
            wanted = self.normalize(name)
            for key, value in self.opts.items():
                if self.normalize(key) == wanted:
                    return key, value
        return None

    def _record(self, param, raw):
        self._seq += 1
        self.occurrences.setdefault(param, []).append((self._seq, raw))

    def _is_option_like(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args):
        i = 0
        while i < len(args):
            token = args[i]
            i += 1
            if token == "--":
                self.positional.extend(args[i:])
                return
            if not self._is_option_like(token):
                self.positional.append(token)
                if not self.interspersed:
                    self.positional.extend(args[i:])
                    return
                continue
            i = self._parse_token(token, args, i)

    def _parse_token(self, token, args, i):
        found = self._lookup(token)
        if found is not None:
            return self._take(found, None, args, i, token)
        name, eq, value = token.partition("=")
        if eq:
            found = self._lookup(name)
            if found is not None:
                return self._take(found, value, args, i, name)
        if token[1] == token[0] or eq:
            if self.ignore_unknown:
                self.positional.append(token)
                return i
            raise NoSuchOption(name if eq else token, ctx=self.ctx)
        j = 1
        while j < len(token):
            short = token[0] + token[j]
            found = self._lookup(short)
            if found is None:
                if self.ignore_unknown:
                    self.positional.append(token[0] + token[j:])
                    return i
                raise NoSuchOption(short, ctx=self.ctx)
            param = found[1][0]
            if not param.takes_value:
                i = self._take(found, None, args, i, short)
                j += 1
                continue
            attached = token[j + 1 :]
            return self._take(found, attached or None, args, i, short)
        return i

    def _take(self, found, attached, args, i, name):
        param, secondary = found[1]
        if not param.takes_value:
            if attached:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
            if param.count:
                self._record(param, 1)
            elif secondary:
                self._record(param, not param.flag_value)
            else:
                self._record(param, param.flag_value)
            return i
        if param.is_optional_value:
            if attached is not None:
                self._record(param, attached)
                return i
            if i < len(args) and not self._is_option_like(args[i]):
                self._record(param, args[i])
                return i + 1
            self._record(param, param.flag_value)
            return i
        need = param.nargs
        tokens = [] if attached is None else [attached]
        while len(tokens) < need and i < len(args):
            tokens.append(args[i])
            i += 1
        if len(tokens) < need:
            if param.prompt:
                self._record(param, _PROMPT_REQUEST)
                return i
            raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx=self.ctx)
        self._record(param, tokens[0] if need == 1 else tuple(tokens))
        return i


# ------------------------------------------------------------------ context


class Context:
    """Per-invocation state: parsed values, parent link, settings, and resources."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        resilient_parsing=False,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self._parameter_source = {}
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self._exit_stack = contextlib.ExitStack()

        if parent is not None:
            if obj is None:
                obj = parent.obj
            if default_map is None and parent.default_map is not None:
                default_map = parent.default_map.get(info_name)
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if ignore_unknown_options is None:
                ignore_unknown_options = parent.ignore_unknown_options
            if auto_envvar_prefix is None and parent.auto_envvar_prefix is not None:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"

        self.obj = obj
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width
        self.help_option_names = (
            list(help_option_names) if help_option_names is not None else ["--help"]
        )
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = show_default
        self.auto_envvar_prefix = auto_envvar_prefix
        self.ignore_unknown_options = bool(ignore_unknown_options)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args
            if allow_interspersed_args is None
            else allow_interspersed_args
        )

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            rv = f"{self.parent.command_path} {rv}"
        return rv.lstrip()

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()

    def close(self):
        self._exit_stack.close()

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, func):
        self._exit_stack.callback(func)
        return func

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def lookup_default(self, name):
        if self.default_map is None:
            return None
        return self.default_map.get(name)

    def get_parameter_source(self, name):
        if name not in {param.name for param in self.command.params}:
            return None
        return self._parameter_source.get(name)

    def find_object(self, object_type):
        node = self
        while node is not None:
            if type(node.obj) is object_type:
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def get_wrap_width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        columns = _terminal_columns()
        limit = self.max_content_width if self.max_content_width is not None else 80
        return max(min(columns, limit) - 2, 10)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def invoke(self, callback, *args, **kwargs):
        """Call a callback, or run another command with values filled in from ``kwargs``."""
        if isinstance(callback, Command):
            other = callback
            callback = other.callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    value = param.get_default(ctx)
                    if value is None and param.multiple:
                        value = ()
                    kwargs[param.name] = value
            ctx.params.update(kwargs)
        else:
            ctx = self
        if callback is None:
            return None
        with ctx:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)


def _terminal_columns():
    import shutil

    return shutil.get_terminal_size().columns


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def make_help_option(names):
    """Build the eager help flag for the given names."""
    return Option(
        list(names),
        is_flag=True,
        expose_value=False,
        is_eager=True,
        callback=_help_callback,
        help="Show this message and exit.",
    )


def _first_sentence(text):
    paragraph = text.strip().split("\n\n")[0]
    flat = " ".join(paragraph.split())
    match = re.search(r"[.!?](\s|$)", flat)
    return flat[: match.start() + 1] if match else flat


def _format_default(value):
    if isinstance(value, (list, tuple)):
        return ", ".join(str(item) for item in value)
    return str(value)


# ----------------------------------------------------------------- commands


class Command:
    """A callable unit that parses its slice of the command line and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None:
            help = callback.__doc__
        self.help = _clean_help(help)
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # parameters ----------------------------------------------------------

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        used = {
            opt
            for param in self.params
            if isinstance(param, Option)
            for opt in param.opts + param.secondary_opts
        }
        free = [name for name in ctx.help_option_names if name not in used]
        if not free:
            return None
        return make_help_option(free)

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    # parsing -------------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, params)
        parser.parse(args)
        occurrences = parser.occurrences

        done = set()
        eager = sorted(
            (param for param in params if param.is_eager and param in occurrences),
            key=lambda param: occurrences[param][0][0],
        )
        for param in eager:
            self._process_param(ctx, param, occurrences)
            done.add(param)

        leftover = self._bind_arguments(params, occurrences, parser.positional)
        if leftover and not ctx.allow_extra_args and not ctx.resilient_parsing:
            plural = "s" if len(leftover) > 1 else ""
            raise UsageError(
                f"Got unexpected extra argument{plural} ({' '.join(leftover)})", ctx
            )

        winners = _winners(params, occurrences)
        for param in params:
            if param in done or winners.get(param.name) is not param:
                continue
            self._process_param(ctx, param, occurrences)
        ctx.args = leftover
        return leftover

    def _bind_arguments(self, params, occurrences, positional):
        arguments = [param for param in params if param.is_argument]
        remaining = list(positional)
        for index, argument in enumerate(arguments):
            if argument.variadic:
                later = sum(item.min_tokens for item in arguments[index + 1 :])
                take = max(len(remaining) - later, 0)
                tokens = remaining[:take]
                remaining = remaining[take:]
                if tokens:
                    occurrences[argument] = [(0, token) for token in tokens]
                continue
            if len(remaining) >= argument.arity:
                tokens = remaining[: argument.arity]
                remaining = remaining[argument.arity :]
                raw = tokens[0] if argument.arity == 1 else tuple(tokens)
                occurrences[argument] = [(0, raw)]
        return remaining

    def _process_param(self, ctx, param, occurrences):
        occs = occurrences.get(param, [])
        converted = False
        try:
            raws, source, forced = _resolve_raws(ctx, param, occs)
            if param.prompt and (
                forced
                or (
                    source in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP)
                    and param.prompt_required
                )
            ):
                default = raws[0] if raws and not param.multiple else None
                value = param.prompt_value(ctx, default)
                raws = [value]
                source = ParameterSource.PROMPT
                converted = True

            if param.count:
                if source is ParameterSource.COMMANDLINE:
                    value = len(raws)
                else:
                    value = raws[0] if raws else 0
            elif converted:
                value = tuple(raws) if param.multiple else raws[0]
            elif param.multiple:
                value = tuple(param.convert_raw(ctx, raw) for raw in raws)
            else:
                value = param.convert_raw(ctx, raws[0]) if raws else None

            if param.required and not raws:
                raise MissingParameter(ctx=ctx, param=param)
            if source is ParameterSource.COMMANDLINE and param.deprecated:
                if param.is_argument:
                    text = f"The argument '{param.name}' is deprecated."
                else:
                    text = f"The option '{'/'.join(param.opts)}' is deprecated."
                _deprecation_warning(text, param.deprecation_note)
            value = param.process_value(ctx, value)
        except BadParameter as exc:
            if exc.ctx is None:
                exc.ctx = ctx
            if exc.param is None:
                exc.param = param
            raise

        ctx._parameter_source[param.name] = source
        if param.expose_value:
            ctx.params[param.name] = value
        return value

    # invocation ----------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecation_note
            _deprecation_warning(f"The command '{self.name}' is deprecated.", note)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        windows_expand_args=True,
        **extra,
    ):
        args = sys.argv[1:] if args is None else list(args)
        if prog_name is None:
            prog_name = _default_prog_name()
        if complete_var is None:
            complete_var = _complete_var_name(prog_name)
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            return run_completion(self, prog_name, instruction, standalone_mode)

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if standalone_mode:
                    sys.exit(0)
                return rv
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return exc.exit_code
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (EOFError, KeyboardInterrupt) as exc:
            if not standalone_mode:
                raise Abort() from exc
            echo(file=sys.stderr)
            echo("Aborted!", err=True)
            sys.exit(1)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)

    # help ----------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = [self.options_metavar]
        for param in self.params:
            if param.is_argument and not param.hidden:
                placeholder = param.placeholder()
                if param.variadic:
                    placeholder += "..."
                pieces.append(placeholder if param.required else f"[{placeholder}]")
        return pieces

    def get_usage(self, ctx):
        pieces = self.collect_usage_pieces(ctx)
        line = f"Usage: {ctx.command_path}"
        if pieces:
            line += " " + " ".join(pieces)
        return line

    def get_short_help_str(self):
        if self.short_help:
            text = self.short_help
        elif self.help:
            text = _first_sentence(self.help)
        else:
            text = ""
        if self.deprecated:
            text = "(Deprecated) " + text
        return " ".join(text.split())

    def _option_row(self, ctx, param):
        first = ", ".join(param.opts)
        if param.secondary_opts:
            first += "/" + ", ".join(param.secondary_opts)
        metavar = param.get_metavar_display(ctx)
        if metavar:
            first += " " + metavar
        extras = []
        show = param.show_default if param.show_default is not None else ctx.show_default
        if show:
            if isinstance(param.show_default, str):
                extras.append(f"[default: {param.show_default}]")
            elif callable(param.default):
                pass
            elif param.default is not None and not (
                param.is_flag and not param.default and not param.secondary_opts
            ):
                extras.append(f"[default: {_format_default(param.default)}]")
        if param.show_envvar:
            names = param.envvar_names(ctx)
            if names:
                extras.append(f"[env var: {', '.join(names)}]")
        if isinstance(param.type, Choice):
            extras.append("[choices: " + ", ".join(param.type._tokens) + "]")
        if param.deprecated:
            extras.append("(deprecated)")
        text = " ".join(part for part in [param.help or ""] + extras if part)
        return first, text

    def format_extra_sections(self, ctx, width):
        return []

    def format_help(self, ctx):
        width = ctx.get_wrap_width()
        sections = [self.get_usage(ctx)]
        description = self.help
        if self.deprecated:
            mark = "(Deprecated)"
            if self.deprecation_note:
                mark += f" {self.deprecation_note}"
            description = mark if not description else mark + "\n\n" + description
        if description:
            sections.append(wrap_text(description, width, preserve_paragraphs=True))

        arg_rows = []
        for param in self.params:
            if param.is_argument and not param.hidden and param.help:
                arg_rows.append((param.placeholder(), param.help))
        if arg_rows:
            sections.append("Positional arguments:\n" + format_rows(arg_rows, width))

        opt_rows = []
        for param in self.get_params(ctx):
            if param.is_argument or param.hidden:
                continue
            opt_rows.append(self._option_row(ctx, param))
        if opt_rows:
            sections.append("Options:\n" + format_rows(opt_rows, width))

        sections.extend(self.format_extra_sections(ctx, width))

        if self.epilog:
            sections.append(wrap_text(self.epilog, width, preserve_paragraphs=True))
        return "\n\n".join(sections)

    def get_help(self, ctx):
        return self.format_help(ctx)


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        self.invoke_without_command = bool(invoke_without_command)
        if no_args_is_help is None:
            no_args_is_help = not self.invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback
        self.commands = {}
        if commands:
            if isinstance(commands, dict):
                for cmd_name, cmd in commands.items():
                    self.add_command(cmd, cmd_name)
            else:
                for cmd in commands:
                    self.add_command(cmd)

    # registration --------------------------------------------------------

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be registered.")
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(func):
            cmd = command_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(func):
            cmd = group_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(func):
            self._result_callback = func
            return func

        return decorator

    # lookup --------------------------------------------------------------

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        cmd = self.commands.get(cmd_name)
        if cmd is None and ctx is not None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for key, value in self.commands.items():
                if ctx.token_normalize_func(key) == wanted:
                    return value
        return cmd

    def _canonical_name(self, ctx, name):
        if name in self.commands:
            return name
        if ctx is not None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(name)
            for key in self.commands:
                if ctx.token_normalize_func(key) == wanted:
                    return key
        return name

    # parsing and invocation ----------------------------------------------

    def parse_args(self, ctx, args):
        rest = super().parse_args(ctx, args)
        ctx.protected_args = rest[:1]
        ctx.args = rest[1:]
        if not ctx.protected_args and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        return ctx.args

    def _finish(self, ctx, rv):
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, rv, **ctx.params)
        return rv

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            ctx.invoked_subcommand = None
            rv = super().invoke(ctx)
            return self._finish(ctx, rv)

        name = ctx.protected_args[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        ctx.invoked_subcommand = self._canonical_name(ctx, name)
        super().invoke(ctx)
        sub_ctx = cmd.make_context(name, ctx.args, parent=ctx)
        try:
            with sub_ctx:
                rv = cmd.invoke(sub_ctx)
        finally:
            sub_ctx.close()
        return self._finish(ctx, rv)

    def _invoke_chain(self, ctx):
        if ctx.protected_args and self.get_command(ctx, ctx.protected_args[0]) is None:
            raise UsageError(f"No such command {ctx.protected_args[0]!r}.", ctx)
        ctx.invoked_subcommand = _CHAIN
        super().invoke(ctx)
        results = []
        pending = list(ctx.protected_args) + list(ctx.args)
        while pending:
            name = pending[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx)
            sub_ctx = cmd.make_context(
                name,
                pending[1:],
                parent=ctx,
                allow_extra_args=True,
                allow_interspersed_args=False,
            )
            try:
                with sub_ctx:
                    results.append(cmd.invoke(sub_ctx))
            finally:
                sub_ctx.close()
            pending = sub_ctx.args
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, results, **ctx.params)
        return results

    # help ----------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = super().collect_usage_pieces(ctx)
        if self.chain:
            pieces.append(self.subcommand_metavar or "COMMAND [ARGS]...")
            pieces.append("[COMMAND [ARGS]...]...")
        else:
            pieces.append(
                self.subcommand_metavar
                or ("[COMMAND]" if self.invoke_without_command else "COMMAND")
            )
            pieces.append("[ARGS]...")
        return pieces

    def format_extra_sections(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str()))
        if not rows:
            return []
        return ["Commands:\n" + format_rows(rows, width, ellipsize=True)]


class CommandCollection(Group):
    """A group that presents the subcommands of several source groups as one."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None

