"""Parameter types: conversion of command-line tokens into Python values."""

import datetime
import enum
import os
import pathlib
import stat
import uuid

from .exceptions import BadParameter, FileError

TRUE_STRINGS = ("1", "true", "t", "yes", "y", "on")
FALSE_STRINGS = ("0", "false", "f", "no", "n", "off")


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return self.name.upper()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return os.fsdecode(value)
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid float.", param, ctx)


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_STRINGS:
            return True
        if text in FALSE_STRINGS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class FuncParamType(ParamType):
    """Wraps a conversion function that refuses input by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._tokens = [member.name for member in choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(self._tokens) + "]"

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if choice is value:
                return choice
        text = value if isinstance(value, str) else str(value)
        norm = text if self.case_sensitive else text.lower()
        for token, choice in zip(self._tokens, self.choices):
            candidate = token if self.case_sensitive else token.lower()
            if candidate == norm:
                return choice
        allowed = ", ".join(repr(token) for token in self._tokens)
        self.fail(f"{value!r} is not {allowed}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        result = []
        for token in self._tokens:
            if self.case_sensitive:
                matches = token.startswith(incomplete)
            else:
                matches = token.lower().startswith(incomplete.lower())
            if matches:
                result.append(token)
        return result


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    """Parses text into a datetime using the first matching format."""

    name = "datetime"

    def __init__(self, formats=None):
        if formats is None:
            self.formats = list(DEFAULT_DATETIME_FORMATS)
        else:
            self.formats = list(formats)

    def convert(self, value, param, ctx):
        if isinstance(value, datetime.datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param,
            ctx,
        )


class _RangeMixin:
    """Shared bound checks for IntRange and FloatRange."""

    def _range_text(self):
        low = "-inf" if self.min is None else str(self.min)
        high = "inf" if self.max is None else str(self.max)
        left = "(" if self.min_open else "["
        right = ")" if self.max_open else "]"
        return f"{left}{low}, {high}{right}"

    def _check(self, value, param, ctx):
        below = self.min is not None and (
            value <= self.min if self.min_open else value < self.min
        )
        above = self.max is not None and (
            value >= self.max if self.max_open else value > self.max
        )
        if not (below or above):
            return value
        if self.clamp:
            if below:
                if self.min_open:
                    return self.min + self._step
                return self.min
            if self.max_open:
                return self.max - self._step
            return self.max
        self.fail(f"{value} is not in the range {self._range_text()}.", param, ctx)


class IntRange(_RangeMixin, _IntType):
    """An integer that must lie in an optional range."""

    name = "integer range"
    _step = 1

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        number = _IntType.convert(self, value, param, ctx)
        return self._check(number, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    """A float that must lie in an optional range."""

    name = "float range"
    _step = 0.0

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        number = _FloatType.convert(self, value, param, ctx)
        return self._check(number, param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def name(self):
        return " ".join(t.name for t in self.types)

    def get_metavar(self, param):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, (str, bytes)) or len(value) != len(self.types):
            self.fail(f"{value!r} does not match {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


def _is_stream(value):
    return hasattr(value, "read") or hasattr(value, "write")


class File(ParamType):
    """Opens a file and delivers the open file object."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if _is_stream(value):
            return value
        from .utils import open_file

        lazy = self.lazy if self.lazy is not None else ("r" not in self.mode)
        try:
            return open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except (OSError, FileError) as exc:
            reason = getattr(exc, "strerror", None) or getattr(exc, "ext_hint", None) or str(exc)
            self.fail(f"'{value}': {reason}", param, ctx)


class Path(ParamType):
    """Validates a filesystem path and returns it (not an open file)."""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _output(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        if self.path_type is str or self.path_type is None:
            return rv
        return self.path_type(rv)

    def convert(self, value, param, ctx):
        if isinstance(value, os.PathLike):
            value = os.fspath(value)
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if self.allow_dash and value == "-":
            return self._output(value)
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._output(rv)
            self.fail(f"{value!r} does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._output(rv)

    def shell_complete(self, ctx, param, incomplete):
        return []


def _infer_type(default):
    """Return the built-in type that matches a default value."""
    if default is None:
        return STRING
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, uuid.UUID):
        return UUID
    if isinstance(default, (list, tuple)):
        return _infer_type(default[0]) if default else STRING
    return STRING


def convert_type(ty, default=None):
    """Turn a declared type (instance, Python type, function, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        return _infer_type(default)
    if isinstance(ty, (list, tuple)):
        return Tuple(ty)
    mapping = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}
    if ty in mapping:
        return mapping[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
