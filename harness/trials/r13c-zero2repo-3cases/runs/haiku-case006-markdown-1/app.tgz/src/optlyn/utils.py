"""Terminal helpers: echo, styling, prompts, files, pager, editor, and friends."""

import contextlib
import getpass
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import threading
import time
import uuid

from .exceptions import Abort, BadParameter, FileError

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLOR_NAMES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
    "bright_black": 8,
    "bright_red": 9,
    "bright_green": 10,
    "bright_yellow": 11,
    "bright_blue": 12,
    "bright_magenta": 13,
    "bright_cyan": 14,
    "bright_white": 15,
}

_STYLE_SWITCHES = (
    ("bold", 1),
    ("dim", 2),
    ("italic", 3),
    ("underline", 4),
    ("blink", 5),
    ("reverse", 7),
    ("strikethrough", 9),
    ("overline", 53),
)

_local = threading.local()


def _context_stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _context_stack().append(ctx)


def pop_context():
    stack = _context_stack()
    if stack:
        stack.pop()


def get_current_context(silent=False):
    """Return the context that is current on this thread."""
    stack = _context_stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def _isatty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def _is_interactive():
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _keep_ansi(file, color):
    if color is None:
        ctx = get_current_context(silent=True)
        color = getattr(ctx, "color", None) if ctx is not None else None
    if color is None:
        return _isatty(file)
    return bool(color)


def _write_text(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        data = text.encode("utf-8")
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(data)
        else:
            file.write(data.decode(getattr(file, "encoding", None) or "ascii", "replace"))


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to standard output (or standard error).

    Styles are removed unless the destination is a terminal or color is forced on.
    Text that the stream cannot encode is written as UTF-8.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        file.flush()
        getattr(file, "buffer", file).write(data)
        file.flush()
        return
    if not isinstance(message, str):
        message = str(message)
    if not _keep_ansi(file, color):
        message = unstyle(message)
    _write_text(file, message + ("\n" if nl else ""))
    file.flush()


def _color_code(color, background):
    if isinstance(color, str):
        key = color.lower()
        if key == "reset":
            return "49" if background else "39"
        if key not in _COLOR_NAMES:
            raise ValueError(f"Unknown color {color!r}.")
        index = _COLOR_NAMES[key]
        if index < 8:
            return str((40 if background else 30) + index)
        return str((100 if background else 90) + index - 8)
    if isinstance(color, int) and not isinstance(color, bool):
        if 0 <= color <= 255:
            return f"{48 if background else 38};5;{color}"
    elif isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            return f"{48 if background else 38};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences for colors and style switches."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, background=False))
    if bg is not None:
        bits.append(_color_code(bg, background=True))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, code in _STYLE_SWITCHES:
        if switches[name]:
            bits.append(str(code))
    if not bits:
        return text
    rv = f"\x1b[{';'.join(bits)}m{text}"
    if reset:
        rv += "\x1b[0m"
    return rv


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """``echo`` with styling applied first."""
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# --------------------------------------------------------------------------- input


def _read_line(hidden=False):
    """Read one line from standard input; end of input aborts."""
    stream = sys.stdin
    try:
        reader = getattr(stream, "prompt_readline", None)
        if reader is not None:
            line = reader(hidden)
        elif hidden and _isatty(stream):
            return getpass.getpass("", stream=sys.stdout)
        else:
            line = stream.readline()
    except EOFError as exc:
        raise Abort() from exc
    if line == "":
        raise Abort()
    return line.rstrip("\r\n")


def _ask(text, hidden, err):
    echo(text, nl=False, err=err)
    return _read_line(hidden)


def _prompt_loop(text, default, hide_input, confirm_pair, convert, suffix, show_default, err):
    shown = None
    if default is not None and show_default and not hide_input:
        shown = str(default)
    prompt_text = text + (f" [{shown}]" if shown is not None else "") + suffix
    while True:
        value = _ask(prompt_text, hide_input, err)
        if value == "" and default is not None:
            value = default
        if confirm_pair:
            again = _ask("Repeat for confirmation" + suffix, hide_input, err)
            if again != (value if isinstance(value, str) else str(value)):
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return convert(value)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    value_proc=None,
):
    """Ask for a value, convert it, and re-ask until it converts."""
    from .paramtypes import convert_type

    ptype = convert_type(type, default)
    return _prompt_loop(
        text,
        default,
        hide_input,
        confirmation_prompt,
        lambda value: ptype.convert(value, None, None),
        prompt_suffix,
        show_default,
        err,
    )


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a boolean."""
    if default is True:
        hint = " [Y/n]"
    elif default is False:
        hint = " [y/N]"
    else:
        hint = " [y/n]"
    question = text + (hint if show_default else "") + prompt_suffix
    while True:
        echo(question, nl=False, err=err)
        answer = _read_line().strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "" and default is not None:
            result = bool(default)
            break
    if not result and abort:
        raise Abort()
    return result


def _read_tty_char():
    try:
        fd = sys.stdin.fileno()
    except (AttributeError, OSError, ValueError):
        fd = None
    if fd is not None and os.isatty(fd):
        import termios
        import tty

        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return data.decode("utf-8", "replace")
    ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    return ch


def getchar(echo=False):
    """Read a single character without waiting for a line end."""
    reader = getattr(sys.stdin, "read_char", None)
    try:
        ch = reader() if reader is not None else _read_tty_char()
    except EOFError as exc:
        raise EOFError() from exc
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        _write_text(sys.stdout, ch)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    """Wait for a key press in an interactive session; do nothing otherwise."""
    if not _is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


# ---------------------------------------------------------------------- output extras


def clear():
    """Clear the terminal when standard output is one."""
    if not _isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    if not _is_interactive():
        yield sys.stdout
        return
    command = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Show long text through the pager when the session is interactive."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    with get_pager_file(color) as stream:
        for chunk in chunks:
            if stream is sys.stdout and not _keep_ansi(stream, color):
                chunk = unstyle(chunk)
            stream.write(chunk)
            stream.flush()


class ProgressBar:
    """Wraps an iterable and shows progress on a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.finished = False
        self._rendered = False

    def _shows_bar(self):
        return not self.hidden and _isatty(sys.stdout)

    def __enter__(self):
        if not self.hidden and not _isatty(sys.stdout) and self.label:
            echo(self.label)
        return self

    def __exit__(self, exc_type, exc, tb):
        self.render_finish()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        self.render_finish()

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        if self._shows_bar():
            self.render_progress()

    def _eta(self):
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" ETA {int(remaining) // 60:02d}:{int(remaining) % 60:02d}"

    def render_progress(self):
        if self.length:
            done = min(int(self.width * self.pos / self.length), self.width)
            bar = "#" * done + "-" * (self.width - done)
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length}{self._eta()}"
        else:
            text = f"\r{self.label} {self.pos}"
        sys.stdout.write(text)
        sys.stdout.flush()
        self._rendered = True

    def render_finish(self):
        if self.finished:
            return
        self.finished = True
        if self._shows_bar() and self._rendered:
            sys.stdout.write("\n")
            sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Create a progress bar (use as a context manager or iterate it directly)."""
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# ----------------------------------------------------------------- editor / launch


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open a text editor. Returns the saved text, or None."""
    command = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not command:
        command = "notepad" if sys.platform.startswith("win") else "vi"
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(command) + [os.fspath(filename)], env=run_env)
        return None
    fd, path = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    original = (text or "").replace("\r\n", "\n")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(original)
        subprocess.call(shlex.split(command) + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read().replace("\r\n", "\n")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. Returns a status value."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - Windows only
        return 0
    if sys.platform == "darwin":
        command = ["open"] + (["-R"] if locate else []) + [url]
    else:
        command = ["xdg-open", url]
    try:
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA")
        if not base:
            base = os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    """Return a printable text form of a file name (never fails to encode as UTF-8)."""
    if not isinstance(filename, str):
        filename = os.fspath(filename)
        if isinstance(filename, bytes):
            filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    out = []
    for ch in filename:
        code = ord(ch)
        if ch == "\\":
            out.append("\\\\")
        elif 0xDC80 <= code <= 0xDCFF:
            out.append("\\x%02x" % (code - 0xDC00))
        else:
            out.append(ch)
    return "".join(out)


# -------------------------------------------------------------------- file helpers


class _NoCloseStream:
    """Wraps a standard stream: closing it flushes but leaves the process stream open."""

    def __init__(self, stream, owned_wrapper=None):
        self._stream = stream
        self._owned_wrapper = owned_wrapper

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass
        if self._owned_wrapper is not None:
            self._owned_wrapper.detach()
            self._owned_wrapper = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class LazyFile:
    """Opens its file on first I/O instead of when created."""

    def __init__(self, opener, filename):
        self._opener = opener
        self._filename = filename
        self._file = None

    def _open(self):
        if self._file is None:
            try:
                self._file = self._opener()
            except OSError as exc:
                raise FileError(self._filename, exc.strerror or str(exc)) from exc
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class AtomicFile:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self._target = os.path.abspath(filename)
        directory, base = os.path.split(self._target)
        self._tmp = os.path.join(directory, f".{base}.{uuid.uuid4().hex}.tmp")
        if "b" in mode:
            self._handle = open(self._tmp, mode)
        else:
            self._handle = open(self._tmp, mode, encoding=encoding, errors=errors)

    def __getattr__(self, name):
        return getattr(self._handle, name)

    def close(self):
        if self._handle.closed:
            return
        self._handle.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def _standard_stream(mode, encoding, errors):
    raw = sys.stdin if "r" in mode else sys.stdout
    if "b" in mode:
        return _NoCloseStream(getattr(raw, "buffer", raw))
    if encoding:
        buffer = getattr(raw, "buffer", None)
        if buffer is not None:
            wrapper = io.TextIOWrapper(buffer, encoding=encoding, errors=errors)
            return _NoCloseStream(wrapper, owned_wrapper=wrapper)
    return _NoCloseStream(raw)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    if filename == "-":
        return _standard_stream(mode, encoding, errors)

    def opener():
        if atomic:
            return AtomicFile(filename, mode, encoding, errors)
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)

    if lazy:
        return LazyFile(opener, filename)
    try:
        return opener()
    except OSError as exc:
        raise FileError(filename, exc.strerror or str(exc)) from exc
