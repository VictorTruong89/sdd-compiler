"""Decorators that declare commands, groups, options, arguments, and ready-made flags."""

import functools

from .core import Argument, Command, Group, Option, _help_callback
from .utils import echo, get_current_context

_COMMAND_SUFFIXES = ("_command", "_cmd")
_GROUP_SUFFIXES = ("_group", "_grp")


def _default_name(func_name, suffixes):
    name = func_name.lower()
    for suffix in suffixes:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _param_memo(func, param):
    if isinstance(func, Command):
        func.params.append(param)
        return
    if not hasattr(func, "__optlyn_params__"):
        func.__optlyn_params__ = []
    func.__optlyn_params__.append(param)


def _pop_params(func):
    params = func.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _make_command_decorator(name, cls, default_suffixes, attrs):
    def decorator(func):
        cmd_name = name if name is not None else _default_name(func.__name__, default_suffixes)
        params = _pop_params(func)
        return cls(name=cmd_name, callback=func, params=params, **attrs)

    return decorator


def command(name=None, cls=None, **attrs):
    """Turn a function into a command. Use as ``@command()`` or ``@command``."""
    if cls is None:
        cls = Command
    if name is not None and callable(name) and not isinstance(name, str):
        return _make_command_decorator(None, cls, _COMMAND_SUFFIXES, attrs)(name)
    return _make_command_decorator(name, cls, _COMMAND_SUFFIXES, attrs)


def group(name=None, cls=None, **attrs):
    """Turn a function into a group. Use as ``@group()`` or ``@group``."""
    if cls is None:
        cls = Group
    if name is not None and callable(name) and not isinstance(name, str):
        return _make_command_decorator(None, cls, _GROUP_SUFFIXES, attrs)(name)
    return _make_command_decorator(name, cls, _GROUP_SUFFIXES, attrs)


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function (or command) it decorates."""
    if cls is None:
        cls = Option

    def decorator(func):
        _param_memo(func, cls(list(param_decls), **attrs))
        return func

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function (or command) it decorates."""
    if cls is None:
        cls = Argument

    def decorator(func):
        _param_memo(func, cls(list(param_decls), **attrs))
        return func

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag. The default name is ``--help``."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _help_callback)
    kwargs.setdefault("help", "Show this message and exit.")
    return option(*decls, **kwargs)


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        providers = metadata.packages_distributions().get(package_name)
        if providers:
            return metadata.version(providers[0])
        raise RuntimeError(f"{package_name!r} is not an installed distribution or import.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Attach an eager ``--version`` flag that prints the version and exits."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        if version is not None:
            ver = version
        elif package_name is not None:
            ver = _detect_version(package_name)
        else:
            raise RuntimeError("version_option needs a version or a package_name.")
        prog = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """Attach an eager version flag whose identity is ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]

    def flag_callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = flag_callback
    return option(*decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A hidden, confirmed prompt option (default name ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when declined (default ``--yes``)."""
    decls = list(param_decls) or ["--yes"]

    def callback(ctx, param, value):
        if not value:
            ctx.abort()
        return value

    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def pass_context(func):
    """Pass the current context as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(func):
    """Pass the current context's author object as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(func):
        @functools.wraps(func)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return func(obj, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "argument",
    "command",
    "confirmation_option",
    "custom_version_option",
    "group",
    "help_option",
    "make_pass_decorator",
    "option",
    "pass_context",
    "pass_obj",
    "password_option",
    "version_option",
]
