"""Exceptions used by Optlyn and their standalone-mode exit statuses."""


class OptlynError(Exception):
    """Base class for errors that standalone mode reports and exits on."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self):
        from .utils import echo

        echo(f"Error: {self.format_message()}", err=True)


class UsageError(OptlynError):
    """A usage failure: bad option, bad value, missing parameter, and so on."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self):
        from .utils import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            if self.ctx.help_option_names:
                hint = self.ctx.help_option_names[0]
                echo(f"Try '{self.ctx.command_path} {hint}' for help.", err=True)
            echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A parameter value was refused by a type, a range, or a callback."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required option or argument was not supplied by any source."""

    def __init__(self, message=None, ctx=None, param=None):
        super().__init__(message or "", ctx, param)

    def format_message(self):
        kind = "argument" if self.param is not None and self.param.is_argument else "option"
        hint = self.param.get_error_hint(self.ctx) if self.param is not None else ""
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a missing value)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class NoArgsIsHelp(UsageError):
    """No arguments were given where the command shows help instead.

    The help page goes to standard error and the exit status is the usage class.
    """

    def __init__(self, ctx):
        super().__init__("", ctx)

    def show(self):
        from .utils import echo

        echo(self.ctx.get_help(), err=True)


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class)."""

    exit_code = 1

    def __init__(self, filename, hint):
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.filename = filename
        self.ext_hint = hint


class Exit(RuntimeError):
    """An author clean stop with a status code."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class Abort(RuntimeError):
    """The user declined, or input ended, or the author aborted."""

    exit_code = 1
