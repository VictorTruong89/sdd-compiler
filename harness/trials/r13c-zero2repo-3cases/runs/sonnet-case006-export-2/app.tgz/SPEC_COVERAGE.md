# Spec coverage

All 1012 checklist ids are implemented; none is listed as not done.

- pack 01-05 (packaging, exports): pyproject.toml, src/optlyn/__init__.py
- pack 06 (exit statuses, channels, help, version): core.py, exceptions.py, decorators.py, formatting.py
- pack 07-08 (commands, groups, parameters): core.py, decorators.py
- pack 09 (types): types.py
- pack 10 (context): core.py, globals.py
- pack 11 (terminal helpers): termui.py, utils.py, formatting.py
- pack 12 (completion): shell_completion.py
- pack 13 (runner): testing.py
- pack 14-20 (PRD feature points FP-01..FP-14): all modules; tests in tests/

Tested by tests/test_basic.py, tests/test_more.py, tests/test_extra.py.

Choices where the spec leaves the form open: help headings are `Positional arguments`, `Options`, `Commands` (no colon); `invoked_subcommand` on a running chain is `'*'`; exceptions for invalid declarations derive from both TypeError and ValueError.
