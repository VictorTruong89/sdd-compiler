import os, subprocess, sys, textwrap
import pytest
import optlyn
from optlyn import *
from optlyn.testing import CliRunner

r = CliRunner()


def test_eager_first_wins():
    @command()
    @version_option("9.9", prog_name="p")
    def c(): pass
    out1 = r.invoke(c, ["--help", "--version"]).output
    out2 = r.invoke(c, ["--version", "--help"]).output
    assert "Usage" in out1 and "9.9" not in out1
    assert "9.9" in out2 and "Usage" not in out2


def test_version_package():
    @command()
    @version_option(package_name="pytest")
    def c(): pass
    import importlib.metadata as m
    assert m.version("pytest") in r.invoke(c, ["--version"]).output


def test_collection_and_lazy():
    loaded = []
    class Lazy(Group):
        def list_commands(self, ctx): return ["a", "b"]
        def get_command(self, ctx, name):
            loaded.append(name)
            if name == "a":
                @command("a")
                def a(): echo("A!")
                return a
            return None
    lz = Lazy(name="lz")
    res = r.invoke(lz, ["a"])
    assert res.output == "A!\n" and loaded == ["a"]
    loaded.clear()
    res = r.invoke(lz, ["zzz"])
    assert res.exit_code == 2 and loaded == ["zzz"]

    @group()
    def g1(): pass
    @g1.command()
    def x(): echo("x")
    @group()
    def g2(): pass
    @g2.command()
    def y(): echo("y")
    @group(cls=CommandCollection, sources=[g1, g2])
    def coll(): echo("coll")
    assert r.invoke(coll, ["y"]).output == "coll\ny\n"
    out = r.invoke(coll, ["--help"]).output
    assert "x" in out and "y" in out


def test_ascii_env():
    code = textwrap.dedent('''
        import optlyn
        @optlyn.command()
        def c():
            optlyn.echo("caf\\u00e9")
        c()
    ''')
    env = dict(os.environ, PYTHONPATH="src", PYTHONIOENCODING="ascii", PYTHONUTF8="0", LC_ALL="C")
    p = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout == "café\n".encode("utf-8")


def test_file_encoding_dash():
    @command()
    @argument("f", type=File("w", encoding="utf-16"))
    def c(f): f.write("hi")
    res = r.invoke(c, ["-"])
    assert res.stdout_bytes.decode("utf-16") == "hi"
    @command()
    @argument("f", type=File("rb"))
    def d(f): echo(f.read())
    assert r.invoke(d, ["-"], input=b"\x00\x01").exit_code == 0


def test_chain_non_last_variadic():
    @group(chain=True)
    def g(): pass
    @g.command()
    @argument("x", nargs=-1)
    def a(x): echo(repr(x))
    @g.command()
    def b(): echo("b")
    assert r.invoke(g, ["a", "1", "b"]).output.strip() == "('1', 'b')"


def test_chain_invoked_subcommand_marker():
    seen = []
    @group(chain=True, invoke_without_command=True)
    @pass_context
    def g(ctx): seen.append(ctx.invoked_subcommand)
    @g.command()
    def a(): pass
    r.invoke(g, ["a"]); r.invoke(g, [])
    assert seen[0] not in (None, "a") and seen[1] is None


def test_sub_invoked_subcommand():
    seen = []
    @group(invoke_without_command=True)
    @pass_context
    def g(ctx): seen.append(ctx.invoked_subcommand)
    @g.command()
    def a(): pass
    r.invoke(g, ["a"]); r.invoke(g, [])
    assert seen == ["a", None]


def test_group_help_via_sub_runs_group_callback():
    seen = []
    @group()
    def g(): seen.append("g")
    @g.command()
    def a(): seen.append("a")
    res = r.invoke(g, ["a", "--help"])
    assert res.exit_code == 0 and seen == ["g"]
    seen.clear()
    r.invoke(g, ["--help", "a"])
    assert seen == []


def test_help_short_help():
    @group()
    def g(): pass
    @g.command()
    def a():
        """First sentence here. Second sentence."""
    @g.command(short_help="custom")
    def b():
        """Long doc."""
    out = r.invoke(g, ["--help"]).output
    assert "First sentence here." in out and "Second" not in out and "custom" in out


def test_auto_prefix_optout():
    @command()
    @option("--x", allow_from_autoenv=False, envvar="MYX")
    def c(x): echo(str(x))
    res = r.invoke(c, [], auto_envvar_prefix="P", env={"P_X": "no"})
    assert res.output.strip() == "None"


def test_bool_env_pair_and_ws():
    @command()
    @option("--f/--no-f", envvar="F")
    def c(f): echo(str(f))
    assert r.invoke(c, [], env={"F": "  "}).output.strip() == "False"
    assert r.invoke(c, [], env={"F": "ON"}).output.strip() == "True"
    assert r.invoke(c, [], env={"F": ""}).output.strip() == "False"


def test_callbacks():
    order = []
    def cb(ctx, param, value):
        order.append((param.name, value))
        if value == "bad": raise BadParameter("nope")
        return value
    @command()
    @option("--a", callback=cb)
    @option("--b", callback=cb, multiple=True)
    def c(a, b): echo("ran")
    res = r.invoke(c, ["--b", "1", "--b", "2"])
    assert ("b", ("1", "2")) in order and order.count(("a", None)) == 1
    res = r.invoke(c, ["--a", "bad"])
    assert res.exit_code == 2 and "ran" not in res.output and "--a" in res.output
