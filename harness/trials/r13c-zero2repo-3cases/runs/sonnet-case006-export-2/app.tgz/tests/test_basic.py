import os, sys, io, uuid, datetime, enum
import pytest
import optlyn
from optlyn import *
from optlyn.testing import CliRunner

r = CliRunner()


def run(cmd, args=None, **kw):
    return r.invoke(cmd, args, **kw)


def test_naming_and_suffix():
    @command()
    def foo_bar_command(): pass
    assert foo_bar_command.name == "foo-bar"
    @command("x")
    def y(): pass
    assert y.name == "x"


def test_flags_and_counts_multiple():
    @command()
    @option("-v", "--verbose", count=True)
    @option("--flag", is_flag=True)
    @option("--on/--off", default=True)
    @option("-t", "--tag", multiple=True)
    @option("--pair", nargs=2, type=int)
    @option("--tup", type=Tuple([str, int]))
    def c(verbose, flag, on, tag, pair, tup):
        echo(repr((verbose, flag, on, tag, pair, tup)))
    res = run(c, ["-vvv", "--flag", "--off", "-t", "a", "-tb", "--pair", "1", "2", "--tup", "x", "3"])
    assert res.output.strip() == "(3, True, False, ('a', 'b'), (1, 2), ('x', 3))", res.output
    res = run(c, [])
    assert res.output.strip() == "(0, False, True, (), None, None)"


def test_stack_value():
    @command()
    @option("-a", is_flag=True)
    @option("-b")
    def c(a, b): echo(f"{a} {b}")
    assert run(c, ["-abfoo"]).output.strip() == "True foo"
    assert run(c, ["-ab", "foo"]).output.strip() == "True foo"


def test_env_and_defaultmap():
    @command()
    @option("--name", envvar="NM", required=True)
    @option("--lst", envvar="LST", multiple=True)
    @option("--flag", envvar="FL", is_flag=True)
    def c(name, lst, flag): echo(f"{name} {lst} {flag}")
    res = run(c, [], env={"NM": "bob", "LST": "a b c", "FL": "yes"})
    assert res.output.strip() == "bob ('a', 'b', 'c') True", res.output
    res = run(c, [], env={"NM": "bob", "FL": "maybe"})
    assert res.exit_code == 2 and "--flag" in res.output
    res = run(c, [], default_map={"name": "dm"})
    assert "dm" in res.output
    res = run(c, [])
    assert res.exit_code == 2 and "--name" in res.output


def test_auto_prefix():
    @group()
    def g(): pass
    @g.command()
    @option("--user-name")
    def sub(user_name): echo(user_name)
    res = run(g, ["sub"], auto_envvar_prefix="my-app", env={"MY_APP_SUB_USER_NAME": "zed"})
    assert res.output.strip() == "zed", res.output


def test_parameter_source():
    seen = {}
    @command()
    @option("--a", default=1)
    @option("--b", envvar="BB")
    @option("--c")
    @option("--d")
    @pass_context
    def c(ctx, a, b, c, d):
        for n in "abcd": seen[n] = ctx.get_parameter_source(n)
        seen["x"] = ctx.get_parameter_source("x")
    run(c, ["--c", "1"], env={"BB": "x"}, default_map={"d": "q"})
    P = optlyn.ParameterSource
    assert seen == {"a": P.DEFAULT, "b": P.ENVIRONMENT, "c": P.COMMANDLINE, "d": P.DEFAULT_MAP, "x": None}


def test_types():
    class Color(enum.Enum):
        RED = 1
        BLUE = 2
    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    @option("--u", type=UUID)
    @option("--d", type=DateTime())
    @option("--i", type=IntRange(1, 5, clamp=True))
    @option("--f", type=FloatRange(0, 1))
    def c(c, u, d, i, f): echo(repr((c, u, d, i, f)))
    u = str(uuid.uuid4())
    res = run(c, ["--c", "red", "--u", u, "--d", "2020-01-02T03:04:05", "--i", "10", "--f", "0.5"])
    assert res.output.strip() == repr((Color.RED, uuid.UUID(u), datetime.datetime(2020,1,2,3,4,5), 5, 0.5)), res.output
    res = run(c, ["--f", "2"])
    assert res.exit_code == 2 and "--f" in res.output
    with pytest.raises(Exception):
        FloatRange(0, 1, min_open=True, clamp=True)
    assert IntRange(0, 5, max_open=True, clamp=True).convert("9", None, None) == 4


def test_group_flow():
    calls = []
    @group()
    @option("--x")
    def g(x): calls.append(("g", x))
    @g.command()
    def a(): calls.append("a")
    @g.group()
    def inner(): calls.append("inner")
    @inner.command()
    def leaf(): calls.append("leaf")
    run(g, ["--x", "1", "a"])
    run(g, ["inner", "leaf"])
    assert calls == [("g", "1"), "a", ("g", None), "inner", "leaf"]
    calls.clear()
    res = run(g, ["inner"])
    assert res.exit_code == 2 and calls == [("g", None)]
    assert "leaf" in res.stderr or "leaf" in res.output
    res = run(g, [])
    assert res.exit_code == 2
    res = run(g, ["--x", "1"])
    assert res.exit_code == 2 and "Missing command" in res.output


def test_chain():
    @group(chain=True, invoke_without_command=True)
    def g(): pass
    @g.result_callback()
    def done(results): echo(repr(results))
    @g.command()
    def a(): return 1
    @g.command()
    @argument("x", nargs=-1)
    def b(x): return x
    res = run(g, ["a", "b", "p", "q"])
    assert res.output.strip() == "[1, ('p', 'q')]"
    assert run(g, []).output.strip() == "[]"
    assert g.main(["a", "a"], standalone_mode=False) == [1, 1]
    with pytest.raises(RuntimeError):
        @g.group()
        def sub(): pass


def test_standalone_off():
    @command()
    def c():
        return 42
    assert c.main([], standalone_mode=False) == 42
    @command()
    @option("--x", required=True)
    def d(x): pass
    with pytest.raises(UsageError):
        d.main([], standalone_mode=False)
    @command()
    def e(): raise Abort()
    res = run(e)
    assert res.exit_code == 1 and "Aborted" in res.output


def test_exit():
    @command()
    @pass_context
    def c(ctx):
        echo("a")
        ctx.exit(7)
        echo("b")
    res = run(c)
    assert res.exit_code == 7 and res.output == "a\n"


def test_prompt_and_confirm():
    @command()
    @option("--name", prompt=True)
    @password_option()
    @confirmation_option()
    def c(name, password): echo(f"{name}:{password}")
    res = run(c, [], input="bob\npw\npw\ny\n")
    assert "bob:pw" in res.output, res.output
    assert "pw\n" not in res.output.replace("bob:pw", "")
    res = run(c, ["--yes", "--name=x", "--password=p"])
    assert res.output.strip() == "x:p"
    res = run(c, ["--name=x", "--password=p"], input="n\n")
    assert res.exit_code == 1 and "Aborted" in res.output
    res = run(c, [], input="")
    assert res.exit_code == 1


def test_files(tmp_path):
    @command()
    @argument("src", type=File("r"))
    @argument("dst", type=File("w"))
    def c(src, dst): dst.write(src.read().upper())
    with r.isolated_filesystem():
        open("a.txt", "w").write("hello")
        assert run(c, ["a.txt", "b.txt"]).exit_code == 0
        assert open("b.txt").read() == "HELLO"
        res = run(c, ["missing", "b.txt"])
        assert res.exit_code == 2 and "missing" in res.output
        res = run(c, ["-", "-"], input="xyz")
        assert res.output == "XYZ"


def test_path():
    p = Path(exists=True, file_okay=False)
    with pytest.raises(BadParameter): p.convert("/nonexistent", None, None)
    assert Path(allow_dash=True).convert("-", None, None) == "-"


def test_help_variants():
    @command(epilog="THE END", options_metavar="<opts>")
    @option("--n", help="num", show_envvar=True, envvar="NN", type=int)
    @argument("files", nargs=-1)
    def c(n, files):
        """Doc here.\f hidden"""
    out = run(c, ["--help"]).output
    assert "hidden" not in out and "<opts>" in out and "[FILES]..." in out and out.rstrip().endswith("THE END")
    assert "NN" in out
    @command(deprecated="use other")
    def d(): pass
    res = run(d)
    assert res.exit_code == 0 and "use other" in res.output
    assert "DEPRECATED" in run(d, ["--help"]).output


def test_version():
    @command()
    @version_option("1.2.3", prog_name="p")
    @option("--req", required=True)
    def c(req): pass
    res = run(c, ["--version"])
    assert res.exit_code == 0 and "1.2.3" in res.output
    @command()
    @custom_version_option(lambda ctx: "custom!")
    def d(): pass
    assert run(d, ["--version"]).output == "custom!\n"


def test_invalid_decl():
    with pytest.raises(Exception):
        option("--x", deprecated=True, required=True)(lambda: 0)
    with pytest.raises(Exception):
        argument("x", deprecated=True)(lambda: 0)
    with pytest.raises(Exception):
        option("--x", count=True, is_flag=True)(lambda: 0)


def test_multiple_default_str():
    @command()
    @option("--x", multiple=True, default="abc")
    def c(x): pass
    res = run(c)
    assert res.exit_code == 2 and "--x" in res.output and "iterable" in res.output


def test_style():
    assert unstyle(style("hi", fg="red", bold=True)) == "hi"
    assert style("a", fg="red") != style("a", bg="red")
    with pytest.raises(Exception): style("a", fg="nope")
    with pytest.raises(Exception): style("a", fg=(1, 2))
    assert style("a", fg=(1, 2, 3)) != style("a", fg=5)


def test_app_dir(monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", "/x")
    assert get_app_dir("My App") == "/x/my-app"
    assert get_app_dir("My App", force_posix=True).endswith("/.my-app")


def test_context_obj_and_pass():
    class Cfg: pass
    @group()
    @pass_context
    def g(ctx): ctx.obj = Cfg()
    @g.command()
    @make_pass_decorator(Cfg)
    def c(cfg): echo(type(cfg).__name__)
    assert run(g, ["c"]).output.strip() == "Cfg"


def test_completion(monkeypatch):
    @group()
    def cli(): pass
    @cli.command()
    @option("--name")
    @option("--secret", hidden=True)
    @argument("f", type=File())
    def sub(name, secret, f): pass
    @cli.command(hidden=True)
    def hid(): pass
    @cli.command()
    def sub2(): pass
    def comp(words, cword, shell="bash"):
        res = r.invoke(cli, [], prog_name="cli", env={"_CLI_COMPLETE": f"{shell}_complete", "COMP_WORDS": words, "COMP_CWORD": cword})
        return res
    res = comp("cli su", "1")
    assert res.exit_code == 0 and "plain,sub" in res.output and "hid" not in res.output
    res = comp("cli sub --", "2")
    assert "--name" in res.output and "--help" in res.output and "--secret" not in res.output
    res = comp("cli sub ", "2")
    assert "file," in res.output
    res = comp("cli sub", "1", "zsh")
    assert res.output.startswith("plain\nsub")
    res = r.invoke(cli, [], prog_name="cli", env={"_CLI_COMPLETE": "bash_source"})
    assert "complete" in res.output
    res = r.invoke(cli, [], prog_name="cli", env={"_CLI_COMPLETE": "bogus"})
    assert res.exit_code != 0 and res.output == ""
