import os, sys, io, threading, stat
import pytest
import optlyn
from optlyn import *
from optlyn.testing import CliRunner
from optlyn.formatting import wrap_text

r = CliRunner()


def run(cmd, args=None, **kw):
    return r.invoke(cmd, args, **kw)


def test_feature_switch():
    @command()
    @option("--upper", "t", flag_value="upper", default=True)
    @option("--lower", "t", flag_value="lower")
    def c(t): echo(str(t))
    assert run(c, []).output.strip() == "upper"
    assert run(c, ["--lower"]).output.strip() == "lower"
    assert run(c, ["--lower", "--upper"]).output.strip() == "upper"
    @command()
    @option("--a", "t", flag_value="a")
    @option("--b", "t", flag_value="b")
    def d(t): echo(str(t))
    assert run(d, []).output.strip() == "None"


def test_optional_value():
    @command()
    @option("--x", is_flag=False, flag_value="FV", default="D")
    def c(x): echo(x)
    assert run(c, []).output.strip() == "D"
    assert run(c, ["--x"]).output.strip() == "FV"
    assert run(c, ["--x", "v"]).output.strip() == "v"


def test_prompt_not_required():
    @command()
    @option("--x", prompt=True, prompt_required=False, default="D")
    def c(x): echo(x)
    assert run(c, []).output.strip() == "D"
    res = run(c, ["--x"], input="typed\n")
    assert "typed" in res.output
    @command()
    @option("--y", prompt=True, default="DD")
    def d(y): echo(f"got {y}")
    assert "got DD" in run(d, [], input="\n").output
    assert "got z" in run(d, ["--y", "z"]).output
    assert "got EE" in run(d, [], env={}, input="EE\n").output


def test_hidden_and_help_names():
    @command(context_settings={"help_option_names": ["-h", "--help"]})
    @option("--sec", hidden=True)
    def c(sec): echo(str(sec))
    out = run(c, ["-h"]).output
    assert "--sec" not in out
    assert run(c, ["--sec", "1"]).output.strip() == "1"
    @command(context_settings={"help_option_names": ["-h"]})
    def d(): pass
    assert run(d, ["--help"]).exit_code == 2
    @command()
    @argument("help")
    def e(help): echo(help)
    assert run(e, ["x"]).output.strip() == "x"
    assert "Usage" in run(e, ["--help"]).output
    @command(add_help_option=False)
    def f(): pass
    assert run(f, ["--help"]).exit_code == 2
    @command(add_help_option=False)
    @help_option("--help")
    def g(): pass
    assert run(g, ["--help"]).exit_code == 0


def test_token_normalize():
    @group(context_settings={"token_normalize_func": lambda s: s.lower()})
    def g(): pass
    @g.command()
    @option("--Name")
    @option("--ch", type=Choice(["a", "b"]))
    def sub(name, ch): echo(f"{name} {ch}")
    assert run(g, ["SUB", "--NAME", "x", "--ch", "A"]).output.strip() == "x a"


def test_lazy_and_atomic(tmp_path):
    p = tmp_path / "o.txt"
    p.write_text("orig")
    @command()
    @argument("f", type=File("w"))
    def c(f): pass
    assert run(c, [str(p)]).exit_code == 0
    assert p.read_text() == "orig"
    @command()
    @argument("f", type=File("w", lazy=False))
    def d(f): pass
    run(d, [str(p)])
    assert p.read_text() == ""
    @command()
    @argument("f", type=File("w", atomic=True))
    def e(f):
        f.write("new")
        f.flush()
        echo(p.read_text() or "EMPTY")
    p.write_text("orig")
    res = run(e, [str(p)])
    assert res.output.strip() == "orig" and p.read_text() == "new"
    @command()
    @argument("f", type=File("w"))
    def h(f):
        echo("before")
        f.write("x")
        echo("after")
    res = run(h, ["/nonexistent_dir/x"])
    assert res.exit_code == 1 and "before" in res.output and "after" not in res.output and "nonexistent_dir" in res.output


def test_echo_ascii_stream(monkeypatch):
    buf = io.BytesIO()
    w = io.TextIOWrapper(buf, encoding="ascii", errors="strict")
    monkeypatch.setattr(sys, "stdout", w)
    echo("héllo")
    sys.stdout.flush()
    assert buf.getvalue() == "héllo\n".encode("utf-8")


def test_echo_color():
    @command()
    def c(): echo(style("x", fg="red"))
    assert run(c).output == "x\n"
    assert run(c, color=True).output.startswith("\x1b[")
    @command(context_settings={"color": True})
    def d(): echo(style("x", fg="red"))
    assert run(d).output.startswith("\x1b[")


def test_progressbar():
    with progressbar([1, 2, 3], label="Working") as bar:
        items = list(bar)
    assert items == [1, 2, 3]
    @command()
    def c():
        with progressbar(range(3), label="LBL") as b:
            assert list(b) == [0, 1, 2]
        with progressbar(range(3), label="HID", hidden=True) as b:
            assert list(b) == [0, 1, 2]
    out = run(c).output
    assert out.count("LBL") == 1 and "HID" not in out

    class TTY(io.StringIO):
        def isatty(self): return True
    f = TTY()
    with progressbar(length=100, file=f, label="x") as b:
        b.update(30)
    assert "30%" in f.getvalue()


def test_pager_noninteractive():
    @command()
    def c():
        echo_via_pager("abc")
        echo_via_pager(iter(["a", "b\n"]))
        echo_via_pager(lambda: ["z\n"])
        with get_pager_file() as f:
            f.write("w\n")
    assert run(c).output == "abc" + "ab\n" + "z\n" + "w\n"


def test_pause_clear_noninteractive():
    pause(); clear()


def test_wrap():
    assert wrap_text("a b c", 3) == "a b\nc"
    assert wrap_text("") == ""
    assert wrap_text("\b\nline1\nline2", 40, preserve_paragraphs=True) == "line1\nline2"


def test_help_nowrap_and_formfeed():
    @command()
    def c():
        """\b
        Line one
        Line two

        Para two wrapped
        text."""
    out = run(c, ["--help"]).output
    assert "Line one\n" in out and "Line two" in out and "\b" not in out


def test_invoke_forward():
    @command()
    @option("--x", default=1)
    def other(x): echo(f"other {x}")
    @command()
    @option("--x", default=5)
    @pass_context
    def main_(ctx, x):
        ctx.forward(other)
        ctx.invoke(other, x=9)
        ctx.invoke(other)
    assert run(main_, ["--x", "3"]).output == "other 3\nother 9\nother 1\n"


def test_default_map_nested():
    @group()
    def g(): pass
    @g.command()
    @option("--a")
    @argument("b", required=False)
    def sub(a, b): echo(f"{a} {b}")
    res = run(g, ["sub"], default_map={"sub": {"a": "A", "b": "B"}})
    assert res.output.strip() == "A B"
    res = run(g, ["sub"], default_map={"other": {"a": "A"}})
    assert res.output.strip() == "None None"
    @command(context_settings={"default_map": {"a": "q"}})
    @option("--a")
    def leaf(a): echo(a)
    assert run(leaf).output.strip() == "q"


def test_thread_context():
    seen = []
    @command()
    @pass_context
    def c(ctx):
        t = threading.Thread(target=lambda: seen.append(get_current_context(silent=True)))
        t.start(); t.join()
        def inner():
            with ctx:
                seen.append(get_current_context())
        t = threading.Thread(target=inner); t.start(); t.join()
        seen.append(get_current_context() is ctx)
    run(c)
    assert seen[0] is None and seen[2] is True and seen[1] is not None
    with pytest.raises(RuntimeError): get_current_context()


def test_resources_closed():
    log = []
    class CM:
        def __enter__(self): log.append("open"); return 1
        def __exit__(self, *a): log.append("close")
    @group()
    @pass_context
    def g(ctx): ctx.with_resource(CM())
    @g.command()
    @option("--x", type=int)
    def sub(x): log.append("sub")
    run(g, ["sub", "--x", "bad"])
    assert log == ["open", "close"]


def test_extra_args_and_unknown():
    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def c(a): echo(a)
    assert run(c, ["1", "2"]).exit_code == 0
    assert run(c, ["1", "--zz"]).exit_code == 2
    @command(context_settings={"ignore_unknown_options": True})
    @argument("a", nargs=-1)
    def d(a): echo(repr(a))
    assert run(d, ["--zz", "-q", "x"]).output.strip() == "('--zz', '-q', 'x')"
    @command()
    @argument("a", nargs=-1)
    def e(a): echo(repr(a))
    assert run(e, ["--", "--zz"]).output.strip() == "('--zz',)"


def test_prefixes():
    @command()
    @option("+w", "/q", is_flag=True)
    @option("/v", is_flag=True)
    def c(w, v): echo(f"{w} {v}")
    assert run(c, ["+w", "/v"]).output.strip() == "True True"


def test_group_mixing():
    @group(context_settings={"allow_interspersed_args": True})
    @option("--g")
    def g(g): echo(f"g={g}")
    @g.command()
    def s(): echo("s")
    res = run(g, ["s", "--g", "1"])
    assert res.output == "g=1\ns\n"
    @group()
    @option("--g")
    def h(g): pass
    @h.command()
    def t(): pass
    assert run(h, ["t", "--g", "1"]).exit_code == 2


def test_fd_capture():
    @command()
    def c():
        os.write(1, b"raw-out\n")
        os.write(2, b"raw-err\n")
        echo("py")
        assert sys.stdout.fileno() == 1
    rr = CliRunner(capture="fd")
    res = rr.invoke(c)
    assert res.stdout == "raw-out\npy\n" and res.stderr == "raw-err\n", (res.stdout, res.stderr)
    res = CliRunner().invoke(c)
    assert isinstance(res.exception, Exception)


def test_echo_stdin():
    @command()
    def c():
        a = sys.stdin.readline()
    res = CliRunner(echo_stdin=True).invoke(c, input="one\ntwo\n")
    assert res.output == "one\n"


def test_env_isolation():
    rr = CliRunner(env={"AA": "1"})
    @command()
    def c(): echo(os.environ.get("AA", "none") + os.environ.get("BB", "none"))
    assert rr.invoke(c, env={"BB": "2"}).output.strip() == "12"
    assert rr.invoke(c, env={"AA": None}).output.strip() == "nonenone"
    assert "BB" not in os.environ


def test_launch_edit(tmp_path, monkeypatch):
    script = tmp_path / "xdg-open"
    out = tmp_path / "out.txt"
    script.write_text(f"#!/bin/sh\necho \"$1\" > {out}\n")
    script.chmod(0o755)
    monkeypatch.setenv("PATH", f"{tmp_path}:{os.environ['PATH']}")
    launch("http://example.com")
    assert out.read_text().strip() == "http://example.com"
    ed = tmp_path / "ed.sh"
    ed.write_text("#!/bin/sh\necho edited >> \"$1\"\n")
    ed.chmod(0o755)
    assert edit("start\n", editor=str(ed)) == "start\nedited\n"
    noop = tmp_path / "noop.sh"
    noop.write_text("#!/bin/sh\ntrue\n"); noop.chmod(0o755)
    assert edit("x", editor=str(noop)) is None


def test_format_filename():
    assert format_filename(b"a\xffb") != format_filename(b"a\xfeb")
    assert format_filename("a\udcffb").encode("utf-8")
    assert format_filename("/x/y.txt", shorten=True) == "y.txt"


def test_arg_env_and_required():
    @command()
    @argument("a", envvar="AAA")
    @argument("b", nargs=-1, envvar="BBB")
    def c(a, b): echo(f"{a} {b}")
    assert run(c, [], env={"AAA": "x y", "BBB": "p q"}).output.strip() == "x y ('p', 'q')"
    assert run(c, ["z"], env={"AAA": "x y"}).output.strip() == "z ()"
    assert run(c, []).exit_code == 2


def test_confirm_func():
    @command()
    def c():
        echo(str(confirm("Sure?")))
        echo(str(confirm("Sure?", default=True)))
        echo(str(prompt("n", type=int)))
    res = run(c, input="maybe\ny\n\n42x\n7\n")
    assert res.output.split("\n")[-4:-1] == ["True", "True", "7"] or "7" in res.output
    assert "Error: invalid input" in res.output


def test_option_default_types():
    @command()
    @option("--n", default=3)
    @option("--f", default=1.5)
    @option("--b", default=True, type=bool)
    def c(n, f, b): echo(repr((n, f, b)))
    assert run(c, ["--n", "4"]).output.strip() == "(4, 1.5, True)"
    assert run(c, ["--n", "x"]).exit_code == 2
