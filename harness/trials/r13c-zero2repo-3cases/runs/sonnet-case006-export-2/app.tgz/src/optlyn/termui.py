"""Terminal interaction helpers."""
import contextlib
import inspect
import io
import itertools
import math
import os
import shlex
import shutil
import subprocess
import sys
import time

from .exceptions import Abort, InvalidColor, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import (
    echo,
    format_filename,
    isatty,
    strip_ansi,
)

visible_prompt_func = input


def hidden_prompt_func(prompt):
    import getpass

    return getpass.getpass(prompt)


def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


# --- styling ---------------------------------------------------------------

_ansi_colors = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise InvalidColor(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise InvalidColor(f"Color {color!r} out of range 0-255")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise InvalidColor(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    try:
        items = tuple(color)
    except TypeError:
        raise InvalidColor(f"Unknown color {color!r}") from None
    if len(items) != 3 or any(
        isinstance(c, bool) or not isinstance(c, int) or not 0 <= c <= 255 for c in items
    ):
        raise InvalidColor(f"Unknown color {color!r}")
    r, g, b = items
    return f"{38 + offset};2;{r:d};{g:d};{b:d}"


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for flag, on, off in (
        (bold, 1, 22),
        (dim, 2, 22),
        (underline, 4, 24),
        (overline, 53, 55),
        (italic, 3, 23),
        (blink, 5, 25),
        (reverse, 7, 27),
        (strikethrough, 9, 29),
    ):
        if flag is not None:
            bits.append(f"\033[{on if flag else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# --- prompts ---------------------------------------------------------------


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += " ({})".format(", ".join(map(str, type._names())))
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and isinstance(getattr(default, "name"), str) and (
        hasattr(default, "read") or hasattr(default, "write")
    ):
        return default.name
    return default


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_text = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_text)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(
        text,
        prompt_suffix,
        show_default,
        "y/n" if default is None else ("Y/n" if default else "y/N"),
    )
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# --- pager -----------------------------------------------------------------


def _chunks(text_or_generator):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        text_or_generator = [text_or_generator]
    for chunk in text_or_generator:
        if isinstance(chunk, bytes):
            chunk = chunk.decode("utf-8", "replace")
        yield chunk if isinstance(chunk, str) else str(chunk)


class _PagerStream:
    def __init__(self, proc, color):
        self._proc = proc
        self._color = color
        self.encoding = "utf-8"
        self.errors = "replace"

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if not self._color:
            text = strip_ansi(text)
        try:
            self._proc.stdin.write(text.encode("utf-8", "replace"))
            self._proc.stdin.flush()
        except (OSError, ValueError):
            pass
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            self._proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def isatty(self):
        return False


class _PlainPagerStream:
    def __init__(self, color):
        self._color = color

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        echo(text, nl=False, color=self._color)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            sys.stdout.flush()
        except Exception:
            pass

    def isatty(self):
        return isatty(sys.stdout)


def _pager_command():
    cmd = (os.environ.get("PAGER") or "").strip()
    if cmd:
        return cmd
    for candidate in ("less", "more"):
        if shutil.which(candidate):
            return candidate
    return None


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    cmd = _pager_command() if _interactive() else None
    if not cmd:
        yield _PlainPagerStream(color)
        return
    env = dict(os.environ)
    if "LESS" not in env:
        env["LESS"] = "-R"
    sys.stdout.flush()
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    # Keep styles unless the caller forced colors off.
    stream = _PagerStream(proc, color is not False)
    try:
        yield stream
    finally:
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    with get_pager_file(color=color) as f:
        for chunk in _chunks(text_or_generator):
            f.write(chunk)
            f.flush()


# --- progress bar ----------------------------------------------------------

BEFORE_BAR = "\r\033[?25l"
AFTER_BAR = "\033[?25h\n"


def _format_eta(seconds):
    seconds = int(seconds)
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if d:
        return f"{d}d {h:02}:{m:02}:{s:02}"
    return f"{h}:{m:02}:{s:02}"


class ProgressBar:
    def __init__(
        self,
        iterable=None,
        length=None,
        fill_char="#",
        empty_char="-",
        bar_template="%(label)s  [%(bar)s]  %(info)s",
        info_sep="  ",
        show_eta=True,
        show_percent=None,
        show_pos=False,
        item_show_func=None,
        label=None,
        file=None,
        color=None,
        update_min_steps=1,
        width=36,
        hidden=False,
    ):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.hidden = hidden
        self._is_atty = isatty(file)
        self._last_line = None
        self.iter = None
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._label_printed = False

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is not None and self.pos > 0:
            return _format_eta(self.eta)
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[
                    int(
                        (math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5)
                        * self.width
                    )
                    % len(chars)
                ] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and not self.finished and self.format_eta():
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (
            self.bar_template
            % {
                "label": self.label,
                "bar": self.format_bar(),
                "info": self.info_sep.join(info_bits),
            }
        ).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not self._is_atty:
            if self._last_line != self.label:
                self._last_line = self.label
                if self.label:
                    echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        buf = BEFORE_BAR
        if self._last_line is not None and len(self._last_line) > len(line):
            buf += " " * len(self._last_line) + "\r"
        self._last_line = line
        echo(buf + line, file=self.file, nl=False, color=self.color)

    def render_finish(self):
        if self.hidden or not self._is_atty:
            return
        self.render_progress()
        echo(AFTER_BAR, file=self.file, nl=False, color=self.color)

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps=1, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self._completed_intervals += n_steps
        self.make_step(n_steps)
        if self._completed_intervals >= self.update_min_steps:
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        if not self._is_atty and not self.hidden:
            self.render_progress()
        try:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.update(1)
        finally:
            self.finish()
            self.render_progress()


def progressbar(
    iterable=None,
    length=None,
    label=None,
    hidden=False,
    show_eta=True,
    show_percent=None,
    show_pos=False,
    item_show_func=None,
    fill_char="#",
    empty_char="-",
    bar_template="%(label)s  [%(bar)s]  %(info)s",
    info_sep="  ",
    width=36,
    file=None,
    color=None,
    update_min_steps=1,
):
    return ProgressBar(
        iterable=iterable,
        length=length,
        show_eta=show_eta,
        show_percent=show_percent,
        show_pos=show_pos,
        item_show_func=item_show_func,
        fill_char=fill_char,
        empty_char=empty_char,
        bar_template=bar_template,
        info_sep=info_sep,
        file=file,
        label=label,
        width=width,
        color=color,
        update_min_steps=update_min_steps,
        hidden=hidden,
    )


# --- single-key input ------------------------------------------------------


def _getchar(echo_flag):
    import termios
    import tty

    f = None
    if isatty(sys.stdin):
        fd = sys.stdin.fileno()
    else:
        f = open("/dev/tty")
        fd = f.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(
                getattr(sys.stdin, "encoding", None) or "utf-8", "replace"
            )
            if echo_flag and isatty(sys.stdout):
                sys.stdout.write(ch)
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def getchar(echo=False):
    return _getchar(echo)


def pause(info=None, err=False):
    if not _interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


# --- editor / launcher / clear --------------------------------------------


def _editor_command(editor, env):
    if editor is not None:
        return editor
    environ = env if env is not None else os.environ
    for key in ("VISUAL", "EDITOR"):
        rv = environ.get(key) if hasattr(environ, "get") else os.environ.get(key)
        if rv:
            return rv
    for name in ("vim", "nano", "vi"):
        if shutil.which(name):
            return name
    return "vi"


def _run_editor(editor, filename, env):
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    cmd = f'{editor} "{filename}"'
    try:
        c = subprocess.Popen(cmd, env=full_env, shell=True)
        exit_code = c.wait()
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e
    if exit_code != 0:
        raise OptlynException(f"{editor}: Editing failed")


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = _editor_command(editor, env)
    if filename is not None:
        _run_editor(editor, filename, env)
        return None
    import tempfile

    fd, name = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            if text:
                f.write(text.replace("\r\n", "\n").encode("utf-8"))
        os.utime(name, (1, 1))
        before = os.path.getmtime(name)
        _run_editor(editor, name, env)
        if require_save and os.path.getmtime(name) == before:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    if locate:
        url = os.path.dirname(os.fspath(url)) or "."
    try:
        proc = subprocess.Popen(["xdg-open", os.fspath(url)])
    except OSError:
        return 127
    return proc.wait()


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)
