"""Stream helpers, echo, lazy / atomic files and misc utilities."""
import codecs
import contextlib
import io
import os
import re
import sys

from .globals import resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    """Text wrapper that never closes the wrapped binary stream."""

    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def strip_ansi(value):
    return _ansi_re.sub("", value)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _is_ascii(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


def _same_encoding(a, b):
    try:
        return codecs.lookup(a or "ascii").name == codecs.lookup(b).name
    except LookupError:
        return False


def _wrap_stream(stream, encoding, errors):
    if stream is None:
        return None
    buffer = getattr(stream, "buffer", None)
    current = getattr(stream, "encoding", None)
    if encoding is None and errors is None:
        if buffer is None or not _is_ascii(current or "ascii"):
            return stream
        encoding, errors = "utf-8", "replace"
    else:
        if encoding is None or _same_encoding(current, encoding):
            if errors is None or errors == getattr(stream, "errors", None):
                return stream
        if buffer is None:
            return stream
        encoding = encoding or current or "utf-8"
        errors = errors or "strict"
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(buffer, encoding, errors, line_buffering=True)


def get_text_stdout(encoding=None, errors=None):
    return _wrap_stream(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _wrap_stream(sys.stderr, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    return _wrap_stream(sys.stdin, encoding, errors)


def _find_binary(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def get_binary_stdin():
    r = _find_binary(sys.stdin)
    if r is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdin.")
    return r


def get_binary_stdout():
    r = _find_binary(sys.stdout)
    if r is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdout.")
    return r


def get_binary_stderr():
    r = _find_binary(sys.stderr)
    if r is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stderr.")
    return r


def get_binary_stream(name):
    return {"stdin": get_binary_stdin, "stdout": get_binary_stdout,
            "stderr": get_binary_stderr}[name]()


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": get_text_stdin, "stdout": get_text_stdout,
            "stderr": get_text_stderr}[name](encoding, errors)


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes, stripping ANSI styles when not a terminal."""
    if file is None:
        file = get_text_stderr() if err else get_text_stdout()
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    elif message:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    file.write(out)
    try:
        file.flush()
    except Exception:
        pass


def format_filename(filename, shorten=False):
    """Make a filename printable (and strictly UTF-8 encodable)."""
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding(), "backslashreplace")
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~/.{}".format(_posixify(app_name))))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
        _posixify(app_name),
    )


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.remove(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    """Open a file or `-`; return (stream, should_close)."""
    if isinstance(filename, bytes) and filename == b"-":
        filename = "-"
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if "b" in mode:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if "b" in mode:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "a" in mode or "+" in mode:
        raise ValueError("Appending to an existing file is not supported with atomic.")
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import tempfile

    fd, tmp = tempfile.mkstemp(
        dir=os.path.dirname(os.path.abspath(filename)), prefix=".__atomic-write"
    )
    umask = os.umask(0)
    os.umask(umask)
    try:
        os.chmod(tmp, 0o666 & ~umask)
    except OSError:
        pass
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    """A file opened on first I/O; failure then raises FileError."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            # Open immediately so a missing file is detected early.
            self.open()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        from .exceptions import FileError

        try:
            rv, self.should_close = open_stream(
                self.name, self.mode, self.encoding, self.errors, atomic=self.atomic
            )
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f
