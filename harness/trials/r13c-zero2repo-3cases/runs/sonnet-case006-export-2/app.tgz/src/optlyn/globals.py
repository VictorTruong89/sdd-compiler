"""Per-thread stack of invocation contexts."""
import threading

_local = threading.local()


def push_context(ctx):
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context():
    _local.stack.pop()


def get_current_context(silent=False):
    """Return the context current on this thread (raise or None if absent)."""
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError) as e:
        if not silent:
            raise RuntimeError("There is no active context.") from e
        return None


def resolve_color_default(color=None):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None
