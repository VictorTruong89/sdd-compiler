"""Exception classes."""
from .utils import echo, format_filename


class DeclarationError(TypeError, ValueError):
    """An invalid declaration (raised when the decorator is applied)."""


class ChainDeclarationError(RuntimeError, TypeError, ValueError):
    """An invalid chain-group declaration."""


class InvalidColor(TypeError, ValueError):
    """A color accepted by neither name, int nor RGB triple."""


def _join_param_hints(param_hint):
    if param_hint is not None and not isinstance(param_hint, str):
        return " / ".join(repr(x) for x in param_hint)
    return param_hint


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        echo(f"Error: {self.format_message()}", file=file, err=file is None)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        color = None
        hint = ""
        if (
            self.ctx is not None
            and self.ctx.command.get_help_option(self.ctx) is not None
        ):
            hint = (
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}'"
                " for help.\n"
            )
        if self.ctx is not None:
            color = self.ctx.color
            echo(f"{self.ctx.get_usage()}\n{hint}", file=file, err=file is None, color=color)
        echo(
            f"Error: {self.format_message()}",
            file=file,
            err=file is None,
            color=color,
        )


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        self.ctx_arg = ctx
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        echo(self.format_message(), file=file, err=file is None, color=self.ctx.color)


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {_join_param_hints(param_hint)}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(
        self, message=None, ctx=None, param=None, param_hint=None, param_type=None
    ):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        else:
            param_hint = None
        param_hint = _join_param_hints(param_hint)
        param_hint = f" {param_hint}" if param_hint else ""
        param_type = self.param_type
        if param_type is None and self.param is not None:
            param_type = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = f"{msg}. {extra}" if msg else extra
        msg = f" {msg}" if msg else ""
        return f"Missing {param_type or 'parameter'}{param_hint}.{msg}"


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        possibility_str = ", ".join(sorted(self.possibilities))
        return f"{self.message} Did you mean {possibility_str}?"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = format_filename(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


class Abort(RuntimeError):
    """Raised to abort the program (exit status 1)."""


class Exit(RuntimeError):
    """Raised for a clean stop with a status."""

    __slots__ = ("exit_code",)

    def __init__(self, code=0):
        self.exit_code = code
