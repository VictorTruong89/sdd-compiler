"""In-process test runner."""
import codecs
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import formatting, termui, utils
from .core import Command


class _MixedBuffer(io.BytesIO):
    """A BytesIO that mirrors every write into a shared ordered buffer."""

    def __init__(self, output, lock):
        super().__init__()
        self._output = output
        self._lock = lock

    def write(self, b):
        with self._lock:
            n = super().write(b)
            self._output.write(bytes(b))
        return n

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def close(self):
        # Keep captured bytes readable after the text wrapper is dropped.
        pass


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _EchoingInput(io.TextIOBase):
    """Text input that echoes exactly what was read into an output buffer."""

    def __init__(self, data, charset, output):
        super().__init__()
        self.buffer = io.BytesIO(data)
        self._charset = charset
        self._output = output
        self.paused = False
        self._decoder = codecs.getincrementaldecoder(charset)("replace")

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "replace"

    def readable(self):
        return True

    def isatty(self):
        return False

    def _echo(self, text):
        if not self.paused and text:
            self._output.write(text.encode(self._charset, "replace"))
        return text

    def readline(self, size=-1):
        raw = self.buffer.readline(size if size and size > 0 else -1)
        return self._echo(raw.decode(self._charset, "replace"))

    def read(self, size=-1):
        if size is None or size < 0:
            return self._echo(self.buffer.read().decode(self._charset, "replace"))
        out = ""
        while len(out) < size:
            b = self.buffer.read(1)
            if not b:
                break
            out += self._decoder.decode(b)
        return self._echo(out)

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line

    def readlines(self, hint=-1):
        return list(iter(self))


class Result:
    def __init__(
        self,
        runner,
        stdout_bytes,
        stderr_bytes,
        output_bytes,
        return_value,
        exit_code,
        exception,
        exc_info=None,
    ):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _text(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._text(self.output_bytes)

    @property
    def stdout(self):
        return self._text(self.stdout_bytes)

    @property
    def stderr(self):
        return self._text(self.stderr_bytes)

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(
        self,
        charset="utf-8",
        env=None,
        echo_stdin=False,
        catch_exceptions=True,
        capture="sys",
    ):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        env = self.make_env(env)

        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi
        formatting.FORCED_WIDTH = 80

        lock = threading.RLock()
        output = io.BytesIO()
        out_buf = _MixedBuffer(output, lock)
        err_buf = _MixedBuffer(output, lock)

        fd_state = None
        if self.capture == "fd":
            fd_state = self._start_fd_capture(output, out_buf, err_buf, lock)
            new_stdout, new_stderr = fd_state["stdout"], fd_state["stderr"]
        else:
            new_stdout = _NamedTextIOWrapper(
                out_buf,
                name="<stdout>",
                mode="w",
                encoding=self.charset,
                errors="backslashreplace",
                write_through=True,
            )
            new_stderr = _NamedTextIOWrapper(
                err_buf,
                name="<stderr>",
                mode="w",
                encoding=self.charset,
                errors="backslashreplace",
                write_through=True,
            )

        if self.echo_stdin:
            text_input = _EchoingInput(data, self.charset, out_buf)
            echo_ref = text_input
        else:
            text_input = _NamedTextIOWrapper(
                io.BytesIO(data), name="<stdin>", mode="r", encoding=self.charset
            )
            echo_ref = None

        def visible_input(prompt=None):
            if echo_ref is not None:
                echo_ref.paused = True
            try:
                sys.stdout.write(prompt or "")
                val = text_input.readline()
                if val == "":
                    raise EOFError()
                val = val.rstrip("\r\n")
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
                return val
            finally:
                if echo_ref is not None:
                    echo_ref.paused = False

        def hidden_input(prompt=None):
            if echo_ref is not None:
                echo_ref.paused = True
            try:
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                val = text_input.readline()
                if val == "":
                    raise EOFError()
                return val.rstrip("\r\n")
            finally:
                if echo_ref is not None:
                    echo_ref.paused = False

        def _getchar(echo):
            char = text_input.read(1)
            if char == "":
                raise EOFError()
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        sys.stdin = text_input
        sys.stdout = new_stdout
        sys.stderr = new_stderr
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        # Other modules imported the name directly.
        saved_rebinds = []
        for mod in (termui,):
            if hasattr(mod, "should_strip_ansi"):
                saved_rebinds.append((mod, "should_strip_ansi", mod.should_strip_ansi))
                mod.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_buf, err_buf, output)
        finally:
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                self._stop_fd_capture(fd_state)
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            for mod, name, val in saved_rebinds:
                setattr(mod, name, val)
            formatting.FORCED_WIDTH = old_forced_width

    # -- file descriptor capture --------------------------------------------

    def _start_fd_capture(self, output, out_buf, err_buf, lock):
        sys.stdout.flush()
        sys.stderr.flush()
        saved1, saved2 = os.dup(1), os.dup(2)
        r1, w1 = os.pipe()
        r2, w2 = os.pipe()
        os.dup2(w1, 1)
        os.dup2(w2, 2)
        os.close(w1)
        os.close(w2)

        def pump(rfd, buf):
            while True:
                try:
                    chunk = os.read(rfd, 65536)
                except OSError:
                    break
                if not chunk:
                    break
                buf.write(chunk)
            os.close(rfd)

        t1 = threading.Thread(target=pump, args=(r1, out_buf), daemon=True)
        t2 = threading.Thread(target=pump, args=(r2, err_buf), daemon=True)
        t1.start()
        t2.start()

        def mk(fd, name):
            raw = io.FileIO(fd, "w", closefd=False)
            return _NamedTextIOWrapper(
                io.BufferedWriter(raw),
                name=name,
                mode="w",
                encoding=self.charset,
                errors="backslashreplace",
                write_through=True,
            )

        return {
            "saved": (saved1, saved2),
            "threads": (t1, t2),
            "stdout": mk(1, "<stdout>"),
            "stderr": mk(2, "<stderr>"),
        }

    def _stop_fd_capture(self, state):
        for s in (state["stdout"], state["stderr"]):
            try:
                s.flush()
            except Exception:
                pass
        saved1, saved2 = state["saved"]
        os.dup2(saved1, 1)
        os.dup2(saved2, 2)
        os.close(saved1)
        os.close(saved2)
        for t in state["threads"]:
            t.join(timeout=5)

    # -----------------------------------------------------------------------

    def invoke(
        self,
        cli,
        args=None,
        input=None,
        env=None,
        catch_exceptions=None,
        color=False,
        **extra,
    ):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if self.capture == "fd":
                    # Let the reader threads drain pending descriptor writes.
                    import time

                    time.sleep(0.05)
        out_buf, err_buf, output = streams
        return Result(
            runner=self,
            stdout_bytes=out_buf.getvalue(),
            stderr_bytes=err_buf.getvalue(),
            output_bytes=output.getvalue(),
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
