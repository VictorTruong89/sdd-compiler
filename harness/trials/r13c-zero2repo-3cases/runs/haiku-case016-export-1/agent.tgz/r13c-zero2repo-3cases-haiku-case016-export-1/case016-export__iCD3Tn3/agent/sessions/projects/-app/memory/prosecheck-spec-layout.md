---
name: prosecheck-spec-layout
description: Where prosecheck spec lives, build layout decided, and spec-reading shortcut (verbatim text extract)
metadata:
  type: project
---

Task: build prosecheck from /app/spec (compiled export, 35 packs, 1097 checklist ids). Spec must stay untouched.

Layout decided: scripts/detect.py (stdlib detector), hooks/*.js (activate, tracker, subagent, guard, stats) + hooks/lib/*.js, hooks/hooks.json, commands/prosecheck.md, install/prosecheck-command.md, .cursor/rules/prosecheck.mdc (plugin-root shipped rule), tests/.

Shortcut: packs' verbatim text (no claims/ids) was extracted to /tmp/specread (may be gone in a new session); the full text lives in spec/packs/*.md. Pack 34 (feature points) is the only big one (~63 KB verbatim text).

Why: reading the raw packs costs ~575 KB; claims sections are duplicate noise. Strip "## Claims to implement" through the next "## Acceptance criteria".

Status: built end to end. 32 tests in tests/test_prosecheck.py pass (run with PYTHONDONTWRITEBYTECODE=1). Known deviations and approximations are listed in /app/SPEC_COVERAGE.md. Guard skips files under the plugin root, which is /app in this repo, per the spec's rule.
