"""Tests for the prosecheck detector and hooks. Run from /app: python3 -m unittest discover -s tests -v"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DETECT = os.path.join(ROOT, "scripts", "detect.py")
HOOKS = os.path.join(ROOT, "hooks")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import detect  # noqa: E402


def run_detect(args, stdin=b""):
    return subprocess.run([sys.executable, DETECT] + args, input=stdin, capture_output=True)


def run_hook(name, payload, env_extra=None, cwd=None):
    env = dict(os.environ)
    env.update(env_extra or {})
    data = payload if isinstance(payload, str) else json.dumps(payload)
    proc = subprocess.run(["node", os.path.join(HOOKS, name)], input=data.encode("utf-8"),
                          capture_output=True, env=env, cwd=cwd or ROOT)
    return proc


def read_text(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def read_bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def block_reason(proc):
    out = proc.stdout.decode("utf-8").strip()
    return json.loads(out)["reason"]


class DetectorTests(unittest.TestCase):
    def test_N_000292_rescan_after_cleanup_has_no_invisible_hits(self):
        raw = "Zero​width and soft­hyphen‍ and tag\U000E0041 text.\n".encode("utf-8")
        cleaned = run_detect(["--clean"], raw)
        self.assertEqual(cleaned.returncode, 0)
        rescan = run_detect([], cleaned.stdout)
        report = json.loads(rescan.stdout)
        self.assertEqual(report["_metrics"]["invisible_chars"], 0)

    def test_N_000296_rescan_after_cleanup_has_no_nonstandard_spaces(self):
        raw = "Odd spaces　here and a line separator.\n".encode("utf-8")
        cleaned = run_detect(["--clean"], raw)
        report = json.loads(run_detect([], cleaned.stdout).stdout)
        self.assertEqual(report["_metrics"]["nonstandard_spaces"], 0)

    def test_help_first_line_is_exact_usage(self):
        proc = run_detect(["--help"])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout.decode().splitlines()[0], "usage: detect.py [--clean] [--ci] [--] [FILE]")

    def test_unknown_option_exits_2_with_json_error(self):
        proc = run_detect(["--nope"])
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(proc.stdout, b"")
        err = json.loads(proc.stderr.decode().strip().splitlines()[-1])
        self.assertIn("unknown option", err["error"])
        self.assertIn("--nope", err["error"])
        self.assertIn("--help", err["error"])

    def test_empty_stdin_is_empty_input(self):
        proc = run_detect([], b"   \n")
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(json.loads(proc.stderr.decode().strip())["error"], "empty input")

    def test_pdf_has_no_extracted_prose(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "doc.pdf")
            with open(path, "wb") as fh:
                fh.write(b"%PDF-1.4 text")
            proc = run_detect([path])
            self.assertEqual(proc.returncode, 1)

    def test_report_members_and_metrics(self):
        text = ("Delve into the tapestry. It is crucial to leverage robust, seamless tools. "
                "In conclusion, the future looks bright.").encode("utf-8")
        report = json.loads(run_detect([], text).stdout)
        metrics = report["_metrics"]
        for key in ("scanned_chars", "truncated", "ai_tell_score", "ai_tell_band", "confidence",
                    "confidence_reason", "patterns_flagged", "invisible_chars", "nonstandard_spaces", "homoglyphs"):
            self.assertIn(key, metrics)
        self.assertIn("1_ai_vocabulary", report)
        self.assertIn(metrics["ai_tell_band"], ["clean", "light tells", "mixed", "heavy tells", "pervasive tells"])

    def test_code_blocks_generate_no_findings(self):
        text = "Plain intro.\n\n```\ndelve tapestry crucial leverage robust seamless\n```\n\nClosing words."
        report = detect.analyze(text)
        self.assertNotIn("1_ai_vocabulary", report)

    def test_two_decisive_families_floor_at_65(self):
        text = ("Some ordinary prose that is long enough to count as a real sample of writing here. "
                "A hidden​ character sits in this sentence. [insert client name] belongs in it too.")
        report = detect.analyze(text)
        self.assertGreaterEqual(report["_metrics"]["ai_tell_score"], 65)

    def test_single_family_caps_at_40(self):
        import random
        rng = random.Random(0)
        filler = ["alpha", "bravo", "cedar", "delta", "ember", "forge", "gravel", "harbor", "island", "jumper",
                  "kettle", "lantern", "meadow", "nickel", "orchard", "pebble", "quarry", "rivet", "signal", "timber"]
        words = []
        for i in range(400):
            words.append("robust" if i % 20 == 0 else rng.choice(filler))
        report = detect.analyze(" ".join(words))
        self.assertIn("1_ai_vocabulary", report)
        self.assertNotIn("39_generic_positive_conclusion", report)
        self.assertLessEqual(report["_metrics"]["ai_tell_score"], 40)

    def test_extraction_formats_docx_and_cleanup_leaves_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "a.docx")
            with zipfile.ZipFile(path, "w") as zf:
                zf.writestr("word/document.xml",
                            '<w:document xmlns:w="urn:w"><w:body><w:p><w:r><w:t>Alpha.</w:t></w:r></w:p>'
                            '<w:p><w:r><w:t>Beta &amp; gamma.</w:t></w:r></w:p></w:body></w:document>')
            before = read_bytes(path)
            proc = run_detect(["--clean", path])
            self.assertEqual(proc.stdout.decode(), "Alpha.\nBeta & gamma.")
            self.assertEqual(before, read_bytes(path))

    def test_bad_zip_is_cannot_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "bad.docx")
            with open(path, "w") as fh:
                fh.write("not a zip")
            proc = run_detect([path])
            self.assertEqual(proc.returncode, 1)
            self.assertTrue(json.loads(proc.stderr.decode().strip())["error"].startswith("cannot read input:"))

    def test_window_metrics_for_long_text(self):
        text = ("word " * 60000)
        report = detect.analyze(text)
        self.assertTrue(report["_metrics"]["truncated"])
        self.assertEqual(report["_metrics"]["scanned_chars"], detect.WINDOW)

    def test_ci_interval_is_null_with_too_few_sentences(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "short.md")
            with open(path, "w") as fh:
                fh.write("One sentence only.")
            report = json.loads(run_detect(["--ci", path]).stdout)
            self.assertIsNone(report["_metrics"]["score_ci"])
            self.assertIn("score_ci_note", report["_metrics"])


class ContractTests(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0, os.path.join(HOOKS, "lib"))

    def contract(self, level):
        # Read the contract through the hook, so the test sees exactly what a session gets.
        env_dir = tempfile.mkdtemp()
        try:
            with open(os.path.join(env_dir, ".prosecheck-active"), "w") as fh:
                fh.write(level)
            proc = run_hook("prosecheck-subagent.js", {}, {"CLAUDE_CONFIG_DIR": env_dir})
            return json.loads(proc.stdout.decode())["hookSpecificOutput"]["additionalContext"]
        finally:
            shutil.rmtree(env_dir, ignore_errors=True)

    def test_lite_has_no_full_target_integer_or_light_tells(self):
        text = self.contract("lite")
        self.assertIsNone(re.search(r"\b40\b", text))
        self.assertNotIn("light tells", text)
        self.assertNotIn("--clean", text)

    def test_full_has_target_and_no_clean_switch(self):
        text = self.contract("full")
        self.assertIsNotNone(re.search(r"\b40\b", text))
        self.assertTrue("clean" in text or "light tells" in text)
        self.assertNotIn("--clean", text)

    def test_strict_has_target_and_clean_switch(self):
        text = self.contract("strict")
        self.assertIsNotNone(re.search(r"\b20\b", text))
        self.assertIn("--clean", text)
        self.assertIn("clean", text.replace("--clean", ""))

    def test_banned_words_appear_as_standalone_words(self):
        text = self.contract("full")
        for word in ["delve", "tapestry", "pivotal", "crucial", "leverage", "robust", "seamless", "foster",
                     "underscore", "showcase", "landscape", "journey", "realm", "multifaceted", "holistic",
                     "testament", "vibrant", "comprehensive", "plethora", "myriad", "boast", "elevate",
                     "empower", "unlock", "game-changer", "supercharge", "genuinely", "fascinating", "nuanced"]:
            self.assertIsNotNone(re.search(r"(?<![\w-])" + re.escape(word) + r"(?![\w-])", text), word)

    def test_source_code_sentences_have_never_or_not_before(self):
        text = self.contract("full")
        for sentence in re.split(r"[.!?]\s|\n", text):
            if re.search(r"source[ -]code", sentence, re.I):
                before = re.split(r"source[ -]code", sentence, flags=re.I)[0]
                self.assertTrue(re.search(r"\b(never|not)\b", before, re.I), sentence)


class HookTests(unittest.TestCase):
    def setUp(self):
        self.cfg = tempfile.mkdtemp()
        self.env = {"CLAUDE_CONFIG_DIR": self.cfg}
        self.work = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.cfg, ignore_errors=True)
        shutil.rmtree(self.work, ignore_errors=True)

    def command(self, prompt, extra=None):
        payload = {"prompt": prompt, "session_id": "t-session"}
        payload.update(extra or {})
        return run_hook("prosecheck-tracker.js", payload, self.env, cwd=self.work)

    def test_first_start_welcome_then_plain_contract(self):
        first = run_hook("prosecheck-activate.js", {}, self.env, cwd=self.work).stdout.decode()
        self.assertIn("/prosecheck doctor", first)
        self.assertIn("262,144", first)
        self.assertIn("512 KB", first)
        second = run_hook("prosecheck-activate.js", {}, self.env, cwd=self.work).stdout.decode()
        self.assertNotIn("/prosecheck doctor", second)
        self.assertIn("Writing contract", second)

    def test_status_names_only_the_stored_level(self):
        self.command("/prosecheck lite")
        reason = block_reason(self.command("/prosecheck status"))
        self.assertEqual(reason.count("lite") + reason.count("full") + reason.count("strict") + reason.count("off"), 1)
        self.assertIn("lite", reason)

    def test_namespaced_and_plain_spellings_share_state(self):
        self.command("/prosecheck:prosecheck strict")
        self.assertIn("strict", block_reason(self.command("/prosecheck status")))

    def test_stop_phrase_stores_off_and_blocks(self):
        reason = block_reason(self.command("Stop Prosecheck"))
        self.assertRegex(reason, r"\boff\b")
        self.assertEqual(read_text(os.path.join(self.cfg, ".prosecheck-active")), "off")

    def test_off_silences_prompt_and_activation(self):
        self.command("/prosecheck off")
        self.assertEqual(self.command("hello there").stdout.decode().strip(), "")
        self.assertEqual(run_hook("prosecheck-activate.js", {}, self.env, cwd=self.work).stdout.decode().strip(), "")

    def test_unknown_word_lists_all_subcommands_and_keeps_level(self):
        self.command("/prosecheck full")
        reason = block_reason(self.command("/prosecheck wibble"))
        self.assertIn("unknown", reason)
        self.assertIn("wibble", reason)
        for word in ["lite", "full", "strict", "off", "on", "status", "show", "check", "doctor", "stats", "init", "help"]:
            self.assertIsNotNone(re.search(r"\b" + word + r"\b", reason), word)
        self.assertIn("full", block_reason(self.command("/prosecheck status")))

    def test_doctor_has_four_check_lines_and_a_closer(self):
        self.command("/prosecheck full")
        lines = [l for l in block_reason(self.command("/prosecheck doctor")).split("\n") if l.strip()]
        self.assertEqual(len(lines), 6)
        self.assertIn("[OK] mode", lines[1])
        self.assertIn("detector", lines[2])
        self.assertIn("python", lines[3].lower())
        self.assertIn("settings", lines[4])
        self.assertIn("/prosecheck show", lines[5])

    def test_init_writes_once_and_keeps_existing_text(self):
        with open(os.path.join(self.work, "AGENTS.md"), "w") as fh:
            fh.write("# Project notes\n\nKeep this.\n")
        self.command("/prosecheck full")
        first = block_reason(self.command("/prosecheck init"))
        self.assertIn("AGENTS.md", first)
        text = read_text(os.path.join(self.work, "AGENTS.md"))
        self.assertTrue(text.startswith("# Project notes\n\nKeep this.\n"))
        again = block_reason(self.command("/prosecheck init"))
        self.assertIn("already", again)
        self.assertEqual(text.count("prosecheck:writing-contract -->"), 2)
        self.assertTrue(os.path.exists(os.path.join(self.work, ".cursor", "rules", "prosecheck.mdc")))

    def test_init_when_off_writes_nothing(self):
        self.command("/prosecheck off")
        reason = block_reason(self.command("/prosecheck:prosecheck init"))
        self.assertIn("switched off", reason)
        self.assertIn("/prosecheck:prosecheck on", reason)
        self.assertFalse(os.path.exists(os.path.join(self.work, "AGENTS.md")))

    def test_guard_nudges_flagged_file_and_records_ledger(self):
        self.command("/prosecheck full")
        path = os.path.join(self.work, "essay.md")
        with open(path, "w") as fh:
            fh.write(("Delve into the rich tapestry of this vibrant landscape. It is crucial to leverage robust, "
                      "seamless solutions that foster growth. Moreover, these holistic strategies underscore a pivotal "
                      "shift. Additionally, the journey is multifaceted. In conclusion, the future looks bright. "
                      "Let's dive in! I hope this helps. Certainly! Here is a summary of what we did. ") * 3)
        proc = run_hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": path},
                                                 "session_id": "t-session", "cwd": self.work}, self.env)
        out = json.loads(proc.stdout.decode())
        ctx = out["hookSpecificOutput"]["additionalContext"]
        self.assertIn("essay.md", ctx)
        self.assertIn("Fix", ctx.replace("fix", "Fix"))
        shown = block_reason(self.command("/prosecheck show"))
        self.assertIn("essay.md", shown)
        self.assertNotIn(self.work, shown)

    def test_guard_ignores_lite_and_source_files(self):
        self.command("/prosecheck lite")
        path = os.path.join(self.work, "essay.md")
        with open(path, "w") as fh:
            fh.write("delve " * 200)
        proc = run_hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": path}}, self.env)
        self.assertEqual(proc.stdout.decode().strip(), "")
        self.command("/prosecheck full")
        py = os.path.join(self.work, "x.py")
        with open(py, "w") as fh:
            fh.write("delve " * 200)
        proc = run_hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": py}}, self.env)
        self.assertEqual(proc.stdout.decode().strip(), "")

    def test_show_with_empty_ledger(self):
        reason = block_reason(self.command("/prosecheck show"))
        self.assertIn("nothing scored yet", reason)
        self.assertIn(".docx", reason)
        self.assertIn(".pdf", reason)

    def test_check_reports_without_rewriting(self):
        path = os.path.join(self.work, "note.md")
        body = "Delve into the rich tapestry of this vibrant landscape, and leverage robust, seamless tools.\n"
        with open(path, "w") as fh:
            fh.write(body)
        reason = block_reason(self.command("/prosecheck check @note.md"))
        self.assertIn("note.md - ", reason)
        self.assertIn("report only", reason)
        self.assertEqual(read_text(path), body)


if __name__ == "__main__":
    unittest.main()
