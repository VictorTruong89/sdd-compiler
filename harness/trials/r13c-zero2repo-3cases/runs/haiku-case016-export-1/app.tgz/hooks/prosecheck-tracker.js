#!/usr/bin/env node
'use strict';
// spec: FP-04 (prompt reminder), FP-06 (router)
// prompt-submit hook and /prosecheck command router. Commands block the prompt and reply with the reason.
// Ordinary prompts get the writing-contract reminder while the level is not off.

const common = require('./lib/common');
const commands = require('./lib/commands');
const stats = require('./prosecheck-stats');

const COMMAND = /^\s*\/prosecheck(:prosecheck)?(?=\s|$)\s*([\s\S]*)$/i;

function block(reason) {
  common.emit({ decision: 'block', reason });
}

function route(input, cfg) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = process.cwd();
  const trimmed = prompt.trim().toLowerCase();

  // Stop phrases: the entire prompt, letter case ignored.
  if (trimmed === 'stop prosecheck' || trimmed === 'prosecheck off') {
    common.writeLevel('off', cfg);
    return block(commands.stopReply());
  }

  const match = COMMAND.exec(prompt);
  if (!match) {
    const level = common.effectiveLevel(cfg);
    if (level === 'off') return undefined;
    common.emit({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; '
          + 'code, config, and commits are untouched.',
      },
    });
    return undefined;
  }

  // The reply keeps the spelling the user typed for follow-ups that echo the command.
  const prefix = match[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = match[2].trim();
  const space = rest.search(/\s/);
  const sub = (space === -1 ? rest : rest.slice(0, space)).toLowerCase();
  const arg = space === -1 ? '' : rest.slice(space + 1).trim();
  const level = common.effectiveLevel(cfg);

  if (sub === '') return block(commands.helpReply(prefix, level));
  if (sub === 'help') return block(commands.helpReply(prefix, level));
  if (sub === 'lite' || sub === 'full' || sub === 'strict' || sub === 'off') {
    common.writeLevel(sub, cfg);
    return block(commands.setReply(sub));
  }
  if (sub === 'on') {
    common.writeLevel('full', cfg);
    return block(commands.onReply());
  }
  if (sub === 'status') return block(commands.statusReply(common.effectiveLevel(cfg)));
  if (sub === 'show') return block(commands.showReply(sessionId, cfg));
  if (sub === 'check') return block(commands.checkReply(prefix, arg));
  if (sub === 'doctor') return block(commands.doctorReply(prefix, level, cfg));
  if (sub === 'stats') {
    return block(stats.statsReply(level, input.transcript_path, cfg));
  }
  if (sub === 'init') return block(commands.initReply(prefix, level, cwd));
  return block(commands.unknownReply(sub));
}

try {
  const input = common.readStdinJson();
  route(input, common.configDir());
} catch (err) {
  // a failing hook must not fail the host session
}
process.exitCode = 0;
