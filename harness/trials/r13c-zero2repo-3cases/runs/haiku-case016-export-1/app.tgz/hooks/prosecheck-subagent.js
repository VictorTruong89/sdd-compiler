#!/usr/bin/env node
'use strict';
// spec: FP-04 (subagent start)
// subagent-start hook: gives a delegated agent the same writing contract, inside the JSON envelope
// the host keeps for a subagent-start event. Prints nothing when the level is off.

const common = require('./lib/common');
const contract = require('./lib/contract');

try {
  common.readStdinJson();
  const level = common.effectiveLevel(common.configDir());
  if (level !== 'off') {
    common.emit({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: contract.writingContract(level),
      },
    });
  }
} catch (err) {
  // a failing hook must not fail the host session
}
process.exitCode = 0;
