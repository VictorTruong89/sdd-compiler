#!/usr/bin/env node
'use strict';
// spec: FP-06 (stats)
// stats: session token use from the transcript, and the score of the session's own prose.
// Run directly, it reads the host JSON on stdin and prints the block decision. The router requires it too.

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

// The newest .jsonl transcript (by modification time) under the config folder's projects folder.
function newestTranscript(cfg) {
  const root = path.join(cfg, 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (err) {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full, depth + 1);
      } else if (entry.isFile() && entry.name.endsWith('.jsonl')) {
        const mtime = fs.statSync(full).mtimeMs;
        if (!best || mtime > best.mtime) best = { file: full, mtime };
      }
    }
  };
  walk(root, 0);
  return best ? best.file : null;
}

// Prose slice: assistant text with fenced code removed, last 40,000 characters.
function proseSlice(texts) {
  const joined = texts.join('\n\n').replace(/```[\s\S]*?```/g, '\n');
  return joined.slice(-40000);
}

function statsReply(level, transcriptPath, cfg) {
  const file = transcriptPath ? path.resolve(process.cwd(), transcriptPath) : newestTranscript(cfg);
  if (!file) {
    return 'no transcript found for this session. Level: ' + level + '.';
  }
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return 'cannot read transcript ' + path.basename(file) + '. Level: ' + level + '.';
  }
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const seen = new Set();
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let entry;
    try {
      entry = JSON.parse(line);
    } catch (err) {
      continue;
    }
    if (!entry || entry.type !== 'assistant' || !entry.message || typeof entry.message !== 'object') continue;
    const msg = entry.message;
    const id = msg.id;
    if (!id || !seen.has(id)) {
      if (id) seen.add(id);
      turns += 1;
      const usage = msg.usage || {};
      outputTokens += Number(usage.output_tokens) || 0;
      cacheRead += Number(usage.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  const lines = [
    'assistant turns: ' + turns,
    'output tokens: ' + outputTokens,
    'cache-read input tokens: ' + cacheRead,
    'level: ' + level,
  ];
  const slice = proseSlice(texts).trim();
  if (slice.length > 200) {
    const run = common.runDetector(['--'], slice, 15000);
    const report = run.state === 'done' && run.code === 0 ? common.parseReport(run.stdout) : null;
    if (report && typeof report._metrics.ai_tell_score === 'number') {
      lines.push('session prose ai_tell_score: ' + report._metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply, newestTranscript, proseSlice };

if (require.main === module) {
  try {
    const input = common.readStdinJson();
    const cfg = common.configDir();
    const level = common.effectiveLevel(cfg);
    common.emit({ decision: 'block', reason: statsReply(level, input.transcript_path, cfg) });
  } catch (err) {
    // a failing hook must not fail the host session
  }
  process.exitCode = 0;
}
