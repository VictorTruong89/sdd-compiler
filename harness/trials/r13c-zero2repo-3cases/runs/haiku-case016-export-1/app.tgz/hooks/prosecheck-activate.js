#!/usr/bin/env node
'use strict';
// spec: FP-04 (session start)
// session-start hook: prints the writing contract as plain text (or nothing when the level is off).
// On the first start of an install whose mode flag can be written, the welcome block comes first.

const fs = require('fs');
const common = require('./lib/common');
const contract = require('./lib/contract');

function main() {
  common.readStdinJson();
  const cfg = common.configDir();
  common.pruneLedgers(cfg);
  const firstStart = !fs.existsSync(common.flagPath(cfg));
  const level = common.effectiveLevel(cfg);
  let welcome = false;
  if (firstStart && common.writeLevel(level, cfg)) welcome = true;
  if (level === 'off') return;
  const parts = [];
  if (welcome) parts.push(contract.welcomeBlock());
  parts.push(contract.writingContract(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (err) {
  // a failing hook must not fail the host session
}
process.exitCode = 0;
