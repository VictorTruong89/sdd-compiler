#!/usr/bin/env node
'use strict';
// spec: FP-05 (saved-file guard)
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged (FP-05).
// Always exits 0. Prints nothing unless a file is flagged.

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const MAX_PATHS = 16;
const SKIP_DIRS = ['node_modules', '.git', 'memory'];
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const PATCH_LINE = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;

// Paths the saved-file tool named: a patch body for apply_patch, else file_path or notebook_path.
function namedPaths(input) {
  const tool = input.tool_name;
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const found = [];
  if (tool === 'apply_patch' || (typeof ti.command === 'string' && /^\*\*\* /m.test(ti.command))) {
    const body = typeof ti.command === 'string' ? ti.command : '';
    let m;
    PATCH_LINE.lastIndex = 0;
    while ((m = PATCH_LINE.exec(body)) !== null) found.push(m[1].trim());
  } else if (tool === 'NotebookEdit') {
    found.push(ti.notebook_path || ti.file_path);
  } else {
    found.push(ti.file_path);
  }
  const distinct = [];
  for (const p of found) {
    if (typeof p === 'string' && p.trim() && !distinct.includes(p.trim())) distinct.push(p.trim());
  }
  return distinct.slice(0, MAX_PATHS);
}

function skipForLocation(abs) {
  const segments = abs.split(/[\\/]/);
  if (segments.some((s) => SKIP_DIRS.includes(s))) return true;
  const root = common.PLUGIN_ROOT + path.sep;
  return abs.startsWith(root);
}

function skipInstruction(base, ext) {
  const lower = base.toLowerCase();
  if (INSTRUCTION_NAMES.includes(lower)) return true;
  const stem = lower.slice(0, lower.length - ext.length);
  return INSTRUCTION_STEMS.includes(stem) && !common.PROSE_EXT.includes(ext);
}

function record(sessionId, cfg, rec) {
  common.appendLedger(sessionId, rec, cfg);
}

// Scores one file. Returns the nudge text when it is flagged, else null.
function scoreFile(abs, level, sessionId, cfg) {
  const base = path.basename(abs);
  const ext = path.extname(base).toLowerCase();
  if (skipForLocation(abs)) return null;
  if (skipInstruction(base, ext)) return null;
  const binary = common.BINARY_EXT.includes(ext);
  if (!binary && !common.PROSE_EXT.includes(ext)) return null;

  let stat;
  try {
    stat = fs.statSync(abs);
  } catch (err) {
    record(sessionId, cfg, { kind: 'failed', base, reason: 'cannot read the file' });
    return null;
  }
  if (!stat.isFile()) return null;
  if (binary) {
    record(sessionId, cfg, { kind: 'binary', base });
    return null;
  }

  const archive = common.ZIP_EXT.includes(ext);
  const capBytes = archive ? common.ARCHIVE_CAP_MB * 1024 * 1024 : common.PLAIN_CAP_KB * 1024;
  if (stat.size > capBytes) {
    record(sessionId, cfg, { kind: 'skipped', base, capKb: archive ? common.ARCHIVE_CAP_MB * 1024 : common.PLAIN_CAP_KB });
    return null;
  }

  const run = common.runDetector(['--', abs], '', archive ? 15000 : 8000);
  let reason = null;
  if (run.state === 'no-detector') reason = 'the bundled detector is missing';
  else if (run.state === 'no-python') reason = 'Python cannot be found';
  else if (run.state === 'timeout') reason = 'the detector timed out';
  else if (run.code !== 0) reason = 'the detector failed: ' + (common.errorText(run.stderr) || 'no error text');
  else if (!run.stdout.trim()) reason = 'the detector produced no output';
  const report = reason ? null : common.parseReport(run.stdout);
  if (!reason && !report) reason = 'the detector output is not a structured report';
  if (!reason && typeof report._metrics.ai_tell_score !== 'number') reason = 'the report has no numeric score';
  if (reason) {
    record(sessionId, cfg, { kind: 'failed', base, reason });
    return null;
  }

  const m = report._metrics;
  const threshold = common.thresholdFor(level);
  const flagged = m.ai_tell_score > threshold && m.confidence !== 'none';
  const labels = common.firedFindings(report).map((f) => f.label).slice(0, 5);
  record(sessionId, cfg, {
    kind: 'scored',
    base,
    score: m.ai_tell_score,
    band: m.ai_tell_band,
    labels,
    flagged,
    truncated: !!m.truncated,
  });
  if (!flagged) return null;
  const phrase = common.phraseFor(m.ai_tell_band);
  const coverage = m.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  const flaggedLabels = labels.length ? labels.join('; ') : 'no single pattern';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band
    + coverage + '). Flagged: ' + flaggedLabels + '. Fix the flagged spans, keeping the sentence-length variation.';
}

function main() {
  const input = common.readStdinJson();
  const cfg = common.configDir();
  const level = common.effectiveLevel(cfg);
  if (level === 'off' || level === 'lite') return;
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const nudges = [];
  for (const raw of namedPaths(input)) {
    const abs = path.resolve(cwd, raw);
    const nudge = scoreFile(abs, level, sessionId, cfg);
    if (nudge) nudges.push(nudge);
  }
  if (nudges.length) {
    common.emit({ hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: nudges.join('\n') } });
  }
}

try {
  main();
} catch (err) {
  // a failing hook must not fail the host session
}
process.exitCode = 0;
