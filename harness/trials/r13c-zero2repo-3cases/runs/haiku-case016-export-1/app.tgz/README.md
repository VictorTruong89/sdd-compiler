# prosecheck

A local detector for AI-writing patterns in prose deliverables, with companion Node.js plugin hooks.
Python standard library only, no network, no telemetry, no model.

## Layout

| Path | What it is |
| --- | --- |
| `scripts/detect.py` | The detector command: `python3 scripts/detect.py [--clean] [--ci] [--] [FILE]` |
| `hooks/prosecheck-activate.js` | session-start: writing contract (welcome on first start) |
| `hooks/prosecheck-tracker.js` | prompt-submit: `/prosecheck` command router and the reminder |
| `hooks/prosecheck-subagent.js` | subagent-start: the same contract for delegated agents |
| `hooks/prosecheck-guard.js` | post-tool-use: scores a saved prose file and nudges when flagged |
| `hooks/prosecheck-stats.js` | `stats`: token figures and the session's own prose score |
| `hooks/lib/` | shared helpers: config folder, mode flag, ledger, detector bridge, contract text, command replies |
| `hooks/hooks.json` | hook registration for the plugin |
| `commands/prosecheck.md`, `install/prosecheck-command.md` | `/` menu documents (`$ARGUMENTS` forwards to the router) |
| `.cursor/rules/prosecheck.mdc` | shipped Cursor rule, copied by `init` |
| `tests/test_prosecheck.py` | unit and hook tests |

## Use

```sh
python3 scripts/detect.py essay.md          # JSON report: findings, then _metrics
python3 scripts/detect.py --clean essay.md  # scrubbed text (invisible characters, odd spaces, lookalikes)
python3 -m unittest discover -s tests -v    # tests (run from the repository root)
```

Levels are stored as one word in `$CLAUDE_CONFIG_DIR/.prosecheck-active` (default `~/.claude`):
`lite`, `full` (default), `strict`, or `off`. Session ledgers sit beside it and are kept for seven days.

## Scope

Prose only. The score is a triage heuristic on the writing in front of it, not an authorship classifier,
and it never names a person or a model as the author. See `spec/` for the full specification.
