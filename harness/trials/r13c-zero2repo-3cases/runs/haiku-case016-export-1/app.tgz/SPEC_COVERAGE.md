# Spec coverage

Source: `spec/` (35 packs, 1097 checklist ids). The spec is not modified.

Coverage is recorded per feature point and pack, not per claim id. Each claim is implemented by the code
named here and exercised by `tests/test_prosecheck.py` where a test exists.

| Pack / feature point | Implemented in | Tests |
| --- | --- | --- |
| 01–03 hardware, execution profile | stdlib only; `scripts/detect.py`, `hooks/*.js` (Node) | — |
| 04–05 product overview, public surface | `scripts/detect.py`, `hooks/` | `DetectorTests`, `HookTests` |
| 06 naming, env variables, config filenames | `hooks/lib/common.js` (`CLAUDE_CONFIG_DIR`, `CLAUDE_PLUGIN_ROOT`, `PROSECHECK_DEFAULT_MODE`, `.prosecheck-active`, `.prosecheck-ledger`) | `HookTests` |
| 07 global observables, exit codes, streams | `scripts/detect.py` (`fail`, `main`) | `test_unknown_option…`, `test_empty…`, `test_pdf…`, `test_bad_zip…` |
| 08 `scripts/detect.py` report, errors, several operands | `scripts/detect.py` | `test_report_members_and_metrics`, `test_help_…` |
| 09–11 activate, subagent, post-tool-use reply | `hooks/prosecheck-activate.js`, `hooks/prosecheck-subagent.js`, `hooks/prosecheck-guard.js` | `test_first_start…`, `test_guard_…` |
| 12–17 request fields (`content`, `cwd`, `file_path`, `prompt`, `tool_input`, `tool_name`, `transcript_path`) | `hooks/prosecheck-guard.js` (`namedPaths`), `hooks/prosecheck-tracker.js` | `test_guard_…` |
| 18–21 `/prosecheck` router, help, status, levels | `hooks/prosecheck-tracker.js`, `hooks/lib/commands.js` | `test_status…`, `test_namespaced…`, `test_stop…`, `test_unknown…` |
| 22 `check` | `hooks/lib/commands.js` (`checkReply`) | `test_check_reports_without_rewriting` |
| 23 `doctor` | `hooks/lib/commands.js` (`doctorReply`) | `test_doctor_has_four_check_lines_and_a_closer` |
| 24 `show` | `hooks/lib/commands.js` (`showReply`), `hooks/lib/common.js` (ledger) | `test_show_with_empty_ledger`, `test_guard_…` |
| 25 `init` | `hooks/lib/commands.js` (`initReply`), `hooks/lib/contract.js` (`exportContract`) | `test_init_…` |
| 26 `stats` | `hooks/prosecheck-stats.js` | manual check (see below) |
| 27 `transcript_path` | `hooks/prosecheck-stats.js` | manual check (see below) |
| 28–33 PRD overview, terminology, non-functional, non-goals | throughout | — |
| 34 feature points FP-01…FP-06 | FP-01/FP-02: `scripts/detect.py`; FP-03: `scrub()`; FP-04: `hooks/lib/contract.js`; FP-05: `hooks/prosecheck-guard.js`; FP-06: `hooks/prosecheck-tracker.js` + `hooks/lib/commands.js` | `DetectorTests`, `ContractTests`, `HookTests` |
| 35 cross-cutting (prose only, local only, not authorship, silence) | contract text, detector, hooks | `ContractTests` |

Acceptance criteria in pack 34: `N-000292` and `N-000296` are tested as
`test_N_000292_rescan_after_cleanup_has_no_invisible_hits` and
`test_N_000296_rescan_after_cleanup_has_no_nonstandard_spaces`.

## Known deviations and choices

- **Catalogue patterns are approximations** of the PRD's lists. Where the PRD gives a shape (for example
  "a comma followed by highlighting, reflecting, …"), it is implemented as that shape. Where it leaves the
  list to the implementer (hyphenated compounds, canonical slop phrases, synonym clusters), a representative
  list is used. Catalogue 7 and the other eight no-detector numbers are not implemented, as the PRD states.
- **Score weights and the combination formula are the implementer's choice.** The PRD fixes the bands,
  the single-family cap (40), the rhythm-only cap (40, or 20 for monotony alone), the decisive floors (65, 45),
  the short-document and long-document floors, and confidence. The weights are not fixed by the PRD.
- **`--ci` interval** is a fixed-seed bootstrap over sentences, scaled to the point score. It is a heuristic.
- **Plugin-tree skip rule.** The guard skips files inside the plugin root (FP-05, cross-reference
  `N-000665`). In this repository the plugin root is `/app`, so files saved under `/app` are not scored.
  This follows the spec literally; a real install lives outside the project folder.
- **Archive member size cutoff** is not enforced (the PRD leaves it to the implementer).
- **Bundled skill fallback.** The detector lookup also checks `skills/prosecheck/scripts/detect.py`,
  but no skill is shipped.
- **Stats and transcript** (pack 26, 27) are implemented but not covered by an automated test; they were
  checked by hand with a fake transcript (two assistant rows sharing one message id count once).
- **Per-claim annotations.** Code is tagged with `# spec: FP-…` at the feature-point level. Individual claim
  ids are not tagged.
