#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scan of prose for AI-writing patterns.

Usage: python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import os
import random
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from html.parser import HTMLParser

# spec: FP-01, FP-02, FP-03 (constants from the PRD)
WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]
  FILE          scan this file; with no FILE, read standard input (UTF-8)
  --clean       print the scrubbed text (invisible characters, odd spaces,
                lookalike letters, trailing whitespace) instead of the report
  --ci          add a low/high interval on the score when there are enough sentences
  --            end option parsing, so FILE may begin with a dash
  -h, --help    print this usage message and exit"""

ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXT = {".ipynb"}
NO_TEXT_EXT = {".pdf", ".rtf"}

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]

# Catalogue numbers with no detector (PRD FP-01).
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
# Writing advice: reported, weight zero (PRD FP-01).
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
SMALL_WORDS = {"a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "at", "by", "in",
               "of", "on", "to", "up", "as", "from", "with", "into", "via", "vs"}

# Lookalike letters from other scripts -> the ASCII letter they imitate (catalogue 66).
_LOOKALIKE_PAIRS = [
    (0x0430, "a"), (0x0441, "c"), (0x0435, "e"), (0x043E, "o"), (0x0440, "p"), (0x0445, "x"),
    (0x0443, "y"), (0x0456, "i"), (0x0458, "j"), (0x0455, "s"), (0x04BB, "h"), (0x0501, "d"),
    (0x051B, "q"), (0x051D, "w"),
    (0x0410, "A"), (0x0412, "B"), (0x0421, "C"), (0x0415, "E"), (0x041D, "H"), (0x0406, "I"),
    (0x0408, "J"), (0x041A, "K"), (0x041C, "M"), (0x041E, "O"), (0x0420, "P"), (0x0405, "S"),
    (0x0422, "T"), (0x0425, "X"), (0x0423, "Y"), (0x0500, "D"), (0x051A, "Q"), (0x051C, "W"),
    (0x0391, "A"), (0x0392, "B"), (0x0395, "E"), (0x0396, "Z"), (0x0397, "H"), (0x0399, "I"),
    (0x039A, "K"), (0x039C, "M"), (0x039D, "N"), (0x039F, "O"), (0x03A1, "P"), (0x03A4, "T"),
    (0x03A5, "Y"), (0x03A7, "X"), (0x03BF, "o"), (0x03BD, "v"), (0x03B9, "i"),
    (0x0578, "n"), (0x0585, "o"), (0x057D, "u"),
]
LOOK = {chr(code): ascii_letter for code, ascii_letter in _LOOKALIKE_PAIRS}
LETTER_RUN = re.compile(r"[^\W\d_]+")
RTL_RX = re.compile(r"[֐-ࣿיִ-﷿ﹰ-﻿]")
WORD_RX = re.compile(r"[^\W_](?:[^\W_]|['’-])*")
SENT_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
PARA_SPLIT = re.compile(r"\n[ \t]*\n\s*")
LIST_LINE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
HEADING_LINE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")
FENCE = re.compile(r"^ {0,3}(`{3,}|~{3,})")
FENCE_CLOSE = re.compile(r"^ {0,3}(`{3,}|~{3,})\s*$")
BADGE = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
CURLY = re.compile("[“”‘’]")
EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿⭐⭕\U0001F1E6-\U0001F1FF]")


def fail(message, code=1):
    sys.stderr.write(json.dumps({"error": message}, ensure_ascii=False) + "\n")
    sys.exit(code)


def words_of(text):
    return WORD_RX.findall(text)


def split_sentences(text):
    return [s for s in (p.strip() for p in SENT_SPLIT.split(text)) if words_of(s)]


def split_paragraphs(text):
    return [p.strip() for p in PARA_SPLIT.split(text) if p.strip()]


def coefficient_of_variation(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return (var ** 0.5) / mean


def excerpt(text, start, end):
    a = max(0, start - 40)
    b = min(len(text), end + 40)
    s = re.sub(r"\s+", " ", text[a:b]).strip()
    if a > 0:
        s = "..." + s
    if b < len(text):
        s = s + "..."
    return s[:200]


# ------------------------------------------------------------------ extraction

class _HtmlProse(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "section",
             "blockquote", "figure", "article", "header", "footer", "ul", "ol", "table"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(re.sub(r"\s+", " ", data))


def _local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _xml(zf, name):
    try:
        return ET.fromstring(zf.read(name))
    except (KeyError, ET.ParseError, ValueError):
        return None


def _text_of(el, leaf):
    return "".join((e.text or "") for e in el.iter() if _local(e.tag) == leaf)


def _docx(zf):
    root = _xml(zf, "word/document.xml")
    if root is None:
        return ""
    return "\n".join(_text_of(p, "t") for p in root.iter() if _local(p.tag) == "p")


def _numbered(names, pattern):
    matched = [n for n in names if re.match(pattern, n)]
    matched.sort(key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    return matched


def _pptx(zf):
    chunks = []
    for name in _numbered(zf.namelist(), r"ppt/slides/slide\d+\.xml$"):
        root = _xml(zf, name)
        if root is None:
            continue
        paras = [_text_of(p, "t") for p in root.iter() if _local(p.tag) == "p"]
        chunks.append("\n".join(p for p in paras if p))
    return "\n".join(c for c in chunks if c)


def _xlsx(zf):
    shared = []
    sroot = _xml(zf, "xl/sharedStrings.xml")
    if sroot is not None:
        shared = [_text_of(si, "t") for si in sroot.iter() if _local(si.tag) == "si"]
    chunks = []
    for name in _numbered(zf.namelist(), r"xl/worksheets/sheet\d+\.xml$"):
        root = _xml(zf, name)
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            kind = c.get("t")
            value = ""
            for child in c:
                if _local(child.tag) == "v":
                    value = child.text or ""
            text = ""
            if kind == "s":
                try:
                    idx = int(value)
                    text = shared[idx] if 0 <= idx < len(shared) else ""
                except ValueError:
                    text = ""
            elif kind == "inlineStr":
                text = "".join(_text_of(i, "t") for i in c if _local(i.tag) == "is")
            elif kind == "str":
                text = value
            if text:
                cells.append(text)
        chunks.append("\n".join(cells))
    return "\n".join(c for c in chunks if c)


def _odf_walk(el, out):
    tag = _local(el.tag)
    if tag in ("automatic-styles", "font-face-decls", "scripts", "styles"):
        if el.tail:
            out.append(el.tail)
        return
    if tag == "s":
        count = 1
        for key, val in el.attrib.items():
            if _local(key) == "c":
                try:
                    count = int(val)
                except ValueError:
                    count = 1
        out.append(" " * count)
    elif tag == "tab":
        out.append("\t")
    elif tag == "line-break":
        out.append("\n")
    else:
        if el.text:
            out.append(el.text)
        for child in el:
            _odf_walk(child, out)
        if tag in ("p", "h"):
            out.append("\n")
    if el.tail:
        out.append(el.tail)


def _odf(zf):
    root = _xml(zf, "content.xml")
    if root is None:
        return ""
    out = []
    _odf_walk(root, out)
    return "".join(out)


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", name)]


def _epub(zf):
    names = [n for n in zf.namelist() if n.lower().endswith((".xhtml", ".html", ".htm"))]
    chunks = []
    for name in sorted(names, key=_natural_key):
        raw = zf.read(name).decode("utf-8", "replace")
        parser = _HtmlProse()
        try:
            parser.feed(raw)
            parser.close()
        except Exception:  # malformed markup: keep the text read so far
            pass
        text = re.sub(r"[ \t]*\n[ \t\n]*", "\n", "".join(parser.out)).strip()
        if text:
            chunks.append(text)
    return "\n".join(chunks)


def _notebook(data):
    try:
        nb = json.loads(data.decode("utf-8-sig"))
    except (ValueError, UnicodeDecodeError):
        return ""
    cells = nb.get("cells") if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ""
    chunks = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ""
        if cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = "".join(src)
        if not isinstance(src, str):
            return ""
        chunks.append(src)
    return "\n".join(chunks).strip()


def decode_text(data):
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", "replace")
    if b"\x00" in data:
        return ""
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    return data.decode("utf-8", "replace")


def extract(path, data):
    """Return the extracted prose of the input (FP-02). Empty string means no prose."""
    ext = os.path.splitext(path)[1].lower() if path else ""
    if ext in NO_TEXT_EXT:
        return ""
    if ext in NOTEBOOK_EXT:
        return _notebook(data)
    if ext in ZIP_EXT:
        if not zipfile.is_zipfile(io.BytesIO(data)):
            fail("cannot read input: %s is not a readable zip archive" % os.path.basename(path), 1)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            if ext in (".docx", ".docm"):
                text = _docx(zf)
            elif ext in (".pptx", ".pptm"):
                text = _pptx(zf)
            elif ext in (".xlsx", ".xlsm"):
                text = _xlsx(zf)
            elif ext == ".epub":
                text = _epub(zf)
            else:
                text = _odf(zf)
        return text.strip()
    text = decode_text(data)
    if text.startswith("﻿"):
        text = text[1:]
    return text


# ------------------------------------------------------------ character layer

def _is_invisible(ch):
    if ch in "\t\n\r":
        return False
    o = ord(ch)
    if 0xE0000 <= o <= 0xE0FFF:
        return True
    if o in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0):
        return True
    if 0x180B <= o <= 0x180F or 0xFE00 <= o <= 0xFE0F:
        return True
    return unicodedata.category(ch) in ("Cf", "Cc")


def _pict(c):
    if not c:
        return False
    o = ord(c)
    return 0x1F000 <= o <= 0x1FAFF or 0x2600 <= o <= 0x27BF or unicodedata.category(c) == "So"


def _cjk(c):
    if not c:
        return False
    o = ord(c)
    return 0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF


def _in(c, lo, hi):
    return bool(c) and lo <= ord(c) <= hi


def _tag_kept(text, i):
    j = i - 1
    while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F:
        j -= 1
    return j >= 0 and text[j] == "\U0001F3F4"


def _invisible_kept(text, i, rtl):
    """A character that does a job in its position is kept by cleanup, so it is not counted (FP-03)."""
    o = ord(text[i])
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if o == 0xAD:
        return prev.isalpha() and nxt.isalpha()
    if o in (0x200C, 0x200D):
        return any(_in(c, 0x0590, 0x08FF) or _in(c, 0x0900, 0x0DFF) or _in(c, 0x1000, 0x109F)
                   or _in(c, 0x1780, 0x17FF) or _pict(c) for c in (prev, nxt))
    if o == 0x200B:
        return any(_in(c, 0x0E00, 0x0EFF) or _in(c, 0x1000, 0x109F) or _in(c, 0x1780, 0x17FF)
                   or _in(c, 0x3000, 0x30FF) or _cjk(c) for c in (prev, nxt))
    if o in (0xFE0E, 0xFE0F):
        return _pict(prev) or _cjk(prev) or nxt == "⃣"
    if 0xE0100 <= o <= 0xE01EF:
        return _cjk(prev)
    if 0x180B <= o <= 0x180F:
        return _in(prev, 0x1800, 0x18AF)
    if o in (0x17B4, 0x17B5):
        return _in(prev, 0x1780, 0x17FF) or _in(nxt, 0x1780, 0x17FF)
    if o in (0x200E, 0x200F) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return rtl
    if 0xE0020 <= o <= 0xE007F:
        return _tag_kept(text, i)
    return False


def invisible_positions(text, rtl):
    return [i for i, ch in enumerate(text) if _is_invisible(ch) and not _invisible_kept(text, i, rtl)]


def _nonstd_kept(text, i):
    if text[i] not in (" ", " "):
        return False
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    return prev.isdigit() or nxt.isdigit() or (bool(nxt) and nxt in ":;!?»›%€") \
        or (bool(prev) and prev in "«‹")


def nonstandard_positions(text):
    out = []
    for i, ch in enumerate(text):
        if ch == " ":
            continue
        if ch in (" ", " ") or unicodedata.category(ch) == "Zs":
            if not _nonstd_kept(text, i):
                out.append(i)
    return out


def homoglyph_runs(text):
    out = []
    for m in LETTER_RUN.finditer(text):
        run = m.group(0)
        has_ascii = any(c.isascii() and c.isalpha() for c in run)
        look = any(c in LOOK for c in run)
        others = any((not c.isascii()) and c not in LOOK for c in run)
        if has_ascii and look and not others:
            out.append((m.start(), m.end()))
    return out


def trailing_whitespace_count(text):
    n = len(re.findall(r"[ \t]+(?=\r?\n)", text))
    if re.search(r"[ \t]\Z", text):
        n += 1
    if re.search(r"\n\s*\n\Z", text):
        n += 1
    if text[:1].isspace():
        n += 1
    return n


def scrub(text):
    """Cleanup (FP-03): the scrubbed text, keeping the input's line-ending convention."""
    rtl = bool(RTL_RX.search(text))
    drop = set(invisible_positions(text, rtl))
    nonstd = set(nonstandard_positions(text))
    fold = {}
    for start, end in homoglyph_runs(text):
        for k in range(start, end):
            if text[k] in LOOK:
                fold[k] = LOOK[text[k]]
    out = []
    for i, ch in enumerate(text):
        if i in drop:
            continue
        if i in nonstd:
            out.append("\n" if ch in (" ", " ") else " ")
        elif i in fold:
            out.append(fold[i])
        else:
            out.append(ch)
    s = "".join(out)
    s = re.sub(r"[ \t]+(?=\r?\n)", "", s)
    s = re.sub(r"[ \t]+\Z", "", s)
    s = re.sub(r"\A(?:[ \t]*\r?\n)+", "", s)
    body = s.rstrip()
    if text.endswith("\n") and body:
        body += "\r\n" if "\r\n" in text else "\n"
    return body


# --------------------------------------------------------------------- masking

def mask_text(text):
    """Blank the spans that generate no findings: front matter, code, quotes, tables, badges."""
    lines = text.split("\n")
    keep = [True] * len(lines)
    if lines and lines[0].strip() == "---":
        for j in range(1, len(lines)):
            if lines[j].strip() == "---":
                for k in range(0, j + 1):
                    keep[k] = False
                break
    i = 0
    while i < len(lines):
        m = FENCE.match(lines[i])
        if m:
            marker = m.group(1)
            j = i + 1
            while j < len(lines):
                close = FENCE_CLOSE.match(lines[j])
                if close and close.group(1)[0] == marker[0] and len(close.group(1)) >= len(marker):
                    break
                j += 1
            for k in range(i, min(j + 1, len(lines))):
                keep[k] = False
            i = j + 1
            continue
        i += 1
    prev_blank_or_code = True
    for i, line in enumerate(lines):
        if not keep[i]:
            prev_blank_or_code = True
            continue
        is_code = bool(line.strip()) and (line.startswith("    ") or line.startswith("\t")) \
            and prev_blank_or_code and not LIST_LINE.match(line)
        if is_code:
            keep[i] = False
        prev_blank_or_code = (not line.strip()) or is_code
    for i, line in enumerate(lines):
        if not keep[i]:
            continue
        quoted = line.lstrip().startswith(">")
        if quoted and ((i + 1 < len(lines) and lines[i + 1].lstrip().startswith(">"))
                       or (i > 0 and lines[i - 1].lstrip().startswith(">"))):
            keep[i] = False
        if re.match(r"^\s*\|.*\|\s*$", line) or BADGE.match(line):
            keep[i] = False
    out = []
    for i, line in enumerate(lines):
        if keep[i]:
            out.append(re.sub(r"`[^`\n]*`", lambda m: " " * len(m.group(0)), line))
        else:
            out.append("")
    return "\n".join(out)


# -------------------------------------------------------------------- families

def _collect(reg, text):
    count = 0
    samples = []
    for m in reg.finditer(text):
        count += 1
        if len(samples) < 3:
            samples.append(excerpt(text, m.start(), m.end()))
    return count, samples


def rx_matcher(patterns, flags=re.I, min_total=1):
    regs = [re.compile(p, flags) for p in patterns]

    def fn(text):
        count = 0
        samples = []
        for reg in regs:
            c, s = _collect(reg, text)
            count += c
            samples.extend(s)
        if count < min_total:
            return 0, []
        return count, samples[:3]
    return fn


AI_VOCAB = [
    r"\b(?:additionally|align(?:s|ed|ing)? with|crucial|delv(?:e|es|ed|ing)|tapestry|tapestries|pivotal"
    r"|vibrant|meticulous(?:ly)?|testament|underscor(?:e|es|ed|ing)|intricacy|intricacies|intricate"
    r"|interplay|garner(?:s|ed|ing)?|bolster(?:s|ed|ing)?|foster(?:s|ed|ing)?|showcas(?:e|es|ed|ing)"
    r"|emphasi[sz](?:e|es|ed|ing)|enduring|enhance[sd]?|enhancing|leverag(?:e|es|ed|ing)"
    r"|utiliz(?:e|es|ed|ing)|facilitat(?:e|es|ed|ing)|encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?"
    r"|holistic|paradigms?|transformative|unprecedented|myriad|plethora|robust(?:ness)?"
    r"|seamless(?:ly)?|navigat(?:e|es|ed|ing)|embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|landscapes?"
    r"|journeys?|realms?|multifaceted|elevat(?:e|es|ed|ing)|empower(?:s|ed|ing)?|unlock(?:s|ed|ing)?"
    r"|capture the (?:essence|spirit|imagination|heart|magic))\b"]

MODEL_DIALECT = [
    r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b",
    r"\bquietly (?:powerful|profound|radical)\b",
    r"\bdeeply (?:human|personal|felt|unsettling)\b",
    r"\bresonates deeply\b",
    r"\bgame[- ]chang(?:er|ers|ing)\b",
    r"\bsupercharg(?:e|es|ed|ing)\b|\bskyrocket(?:s|ed|ing)?\b|\bturbocharg(?:e|es|ed|ing)\b",
    r"\brevolutioni[sz](?:e|es|ed|ing)\b",
    r"\bdouble down on\b",
    r"\bdive deep(?:er)? into\b",
    r"\bunlock (?:the )?(?:power|potential|value)\b",
    r"\btake\b[^.!?\n]{1,60}\bto the next level\b",
]

PROMO = [
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community"
    r"|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|leading"
    r"|esteemed organi[sz]ation|valuable asset|passion for excellence|proven track record"
    r"|results-oriented|wealth of experience|dynamic team|fast-paced environment|deeply passionate"
    r"|perfectly situated|close-knit team|tight-knit team|uniquely positioned to)\b",
    r"\bI(?:'m| am) excited to (?:apply|bring)\b",
]
IMPERATIVE_OPEN = re.compile(
    r"^(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate"
    r"|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b",
    re.I)

STOCK_ADJ = {"innovative", "robust", "comprehensive", "seamless", "powerful", "elegant", "vibrant",
             "dynamic", "intuitive", "scalable", "reliable", "secure", "efficient", "modern", "bold",
             "rich", "lush", "fresh", "meaningful", "impactful", "strategic", "holistic", "sleek",
             "compelling", "clean", "simple", "bright", "sustainable", "cutting-edge", "thoughtful"}
ADJ_SUFFIX = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial",
              "ary", "ory", "ish")
_CONJ = r"(?:,\s+|,?\s+and\s+|,?\s+or\s+)"
CHAIN4 = re.compile(r"\b([A-Za-z][A-Za-z-]*)" + _CONJ + r"([A-Za-z][A-Za-z-]*)" + _CONJ
                    + r"([A-Za-z][A-Za-z-]*)" + _CONJ + r"([A-Za-z][A-Za-z-]*)\b")

SYNONYM_CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]

RHETORIC_QA = re.compile(r"(?:^|(?<=[.!?\n]))\s*(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should"
                         r"|Has|Have|May|Might)\b[^.?!\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe"
                         r"|Probably|Always)[.!]", re.I | re.M)
HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively"
                   r"|fairly|seems? to|seems? like|appears? to|kind of|sort of)\b")
TRANSITION = re.compile(r"(?:^|(?<=[.!?])\s+|\n)(Additionally|Furthermore|Moreover|However|Nevertheless"
                        r"|Consequently|Subsequently|Notably)\b", re.M)
OUTLETS = re.compile(r"\b(?:The New York Times|New York Times|Forbes|BBC|CNN|Reuters|Bloomberg"
                     r"|The Guardian|Wall Street Journal|Washington Post|NPR|TechCrunch|Associated Press)\b")
CREDIT = re.compile(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\b", re.I)
PRESENCE = re.compile(r"\b\d[\d,.]*\s*(?:k|m|million|thousand)?\s+followers\b"
                      r"|\bstrong (?:online|digital|social media) presence\b"
                      r"|\bwidely covered\b|\bindependent coverage\b", re.I)
PARALLEL = [re.compile(r"\bit[’']s not (?:just|merely) (?:about|an?)\b", re.I),
            re.compile(r"\bnot only\b[^.!?\n]{0,40}?\bbut\b", re.I),
            re.compile(r"\bdoesn[’']t just\b[^,.\n]{0,40}?\bit\b", re.I)]
NOT_X_JUST_Y = [re.compile(r"\b(?:no|not) \w+,\s+(?:just|only|simply) \w+", re.I),
                re.compile(r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t) (?:just|merely)"
                           r" (?:an? |the )?\w+\s*(?:,|—|–|-)\s*(?:it[’']s|it is|it was"
                           r"|they[’']re|they are|they were|that[’']s|but)\b", re.I)]
TAIL_NEG = re.compile(r"[^,.!?\n]{3,},\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", re.I)
INLINE_HEADER = re.compile(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+:\*\*"
                           r"|^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+\*\*:", re.M)
BOLD = re.compile(r"\*\*[^*\n]+\*\*")
CONCLUSION = re.compile(r"^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all"
                        r"|in essence|ultimately)\b", re.I | re.M)
CHAT_MARKUP = re.compile(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b"
                         r"|\bnavlist\b|【\d+†[^】\n]*】")
TRACKING = re.compile(r"utm_source=([A-Za-z0-9.-]+)")
TRACK_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
               "copilot.microsoft.com", "poe.com"}
YEAR_RANGE = re.compile(r"\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b")
HR_LINE = re.compile(r"^\s*(?:-{3,}|\*{3,}|_{3,})\s*$")


def f_adjective_chain(text):
    count = 0
    samples = []
    for m in CHAIN4.finditer(text):
        w = [m.group(i).lower() for i in range(1, 5)]
        if any(_is_adj(x) for x in w[:3]) and not _is_adj(w[3]):
            count += 1
            if len(samples) < 3:
                samples.append(excerpt(text, m.start(), m.end()))
    return count, samples


def _is_adj(word):
    w = word.lower()
    return w in STOCK_ADJ or (len(w) > 4 and w.endswith(ADJ_SUFFIX))


def f_synonym_cycling(text):
    count = 0
    fired = []
    for cluster in SYNONYM_CLUSTERS:
        reg = re.compile(r"\b(?:" + "|".join(re.escape(t) + "s?" for t in cluster) + r")\b", re.I)
        found = [m.group(0).lower() for m in reg.finditer(text)]
        present = {t for t in cluster if any(f == t or f == t + "s" for f in found)}
        if len(present) >= 3:
            count += len(found)
            fired.append("/".join(sorted(present)))
    return count, fired[:3]


def _promo(text):
    count, samples = rx_matcher(PROMO)(text)
    starts = [s for s in split_sentences(text) if IMPERATIVE_OPEN.match(s)]
    if len(starts) >= 3:
        count += len(starts)
        samples = (samples + [starts[0][:120]])[:3]
    return count, samples


def f_parallelism(text):
    count = 0
    samples = []
    for reg in PARALLEL:
        c, s = _collect(reg, text)
        count += c
        samples.extend(s)
    return count, samples[:3]


def f_neg_contrast(text):
    count = 0
    samples = []
    for reg in NOT_X_JUST_Y:
        c, s = _collect(reg, text)
        count += c
        samples.extend(s)
    return count, samples[:3]


def f_monotony(text):
    lens = [len(words_of(s)) for s in split_sentences(text)]
    if len(lens) < 3:
        return 0, []
    cv = coefficient_of_variation(lens)
    if cv is not None and cv < 0.35:
        return 1, ["%d sentences, length variation %.2f" % (len(lens), cv)]
    return 0, []


def f_uniform_paragraphs(text):
    paras = split_paragraphs(text)
    if len(paras) < 4:
        return 0, []
    cv = coefficient_of_variation([len(words_of(p)) for p in paras])
    if cv is not None and cv < 0.4:
        return 1, ["%d paragraphs, length variation %.2f" % (len(paras), cv)]
    return 0, []


def f_alternation(text):
    lens = [len(words_of(s)) for s in split_sentences(text)]
    n = len(lens)
    runs = 0
    i = 0
    while i < n - 1:
        j = i
        while j + 1 < n and abs(lens[j + 1] - lens[j]) >= 4 and \
                (j == i or (lens[j + 1] - lens[j]) * (lens[j] - lens[j - 1]) < 0):
            j += 1
        if j - i + 1 >= 6:
            runs += 1
            i = j + 1
        else:
            i += 1
    return runs, (["%d alternating runs of sentence lengths" % runs] if runs else [])


def f_opener_repetition(text):
    count = 0
    for para in split_paragraphs(text):
        sents = split_sentences(para)
        if len(sents) < 3:
            continue
        openers = Counter(" ".join(words_of(s)[:2]).lower() for s in sents)
        if openers.most_common(1)[0][1] >= 3:
            count += 1
    return count, []


def f_semicolon(text):
    if len(words_of(text)) >= 300 and ";" not in text and text.count("(") < 2:
        return 1, ["no semicolons, almost no parentheses"]
    return 0, []


def f_contraction(text):
    n = len(words_of(text))
    if n < 50:
        return 0, []
    first_person = len(re.findall(r"\b(?:I|we|my|our|me|us)\b", text))
    if first_person / float(n) < 0.03:
        return 0, []
    full = len(re.findall(r"\b(?:I am|I will|I have|I would|we are|we will|we have|we would|do not"
                          r"|does not|did not|is not|are not|cannot|it is|that is|you are|they are"
                          r"|will not|would not|have not|has not)\b", text, re.I))
    contracted = len(re.findall(r"[’'](?:re|ve|ll|m|d|s|t)\b", text))
    if full >= 4 and contracted * 4 <= full:
        return 1, ["%d expanded forms, %d contractions" % (full, contracted)]
    return 0, []


def f_hedge_stacking(text):
    count = 0
    samples = []
    for sent in split_sentences(text):
        if len(HEDGE.findall(sent)) >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(sent[:160])
    return count, samples


def f_transitions(text):
    count = 0
    for para in split_paragraphs(text):
        n = len(TRANSITION.findall(para))
        if n >= 2:
            count += n
    return count, []


def f_fragmented_headers(text):
    lines = text.split("\n")
    count = 0
    samples = []
    for i, line in enumerate(lines):
        m = HEADING_LINE.match(line)
        if not m:
            continue
        heading_words = {w.lower() for w in words_of(m.group(2)) if len(w) > 3}
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if HEADING_LINE.match(nxt) or LIST_LINE.match(nxt) or nxt.startswith("|"):
            continue
        nw = words_of(nxt)
        if nw and len(nw) <= 4 and heading_words & {w.lower() for w in nw}:
            count += 1
            if len(samples) < 3:
                samples.append(nxt[:120])
    return count, samples


def f_title_case(text):
    count = 0
    samples = []
    for line in text.split("\n"):
        m = HEADING_LINE.match(line)
        if not m:
            continue
        title = m.group(2)
        ws = title.split()
        if len(ws) < 3 or not title[:1].isalpha() or title.upper() == title:
            continue
        major = [w for w in ws if w.lower().strip(".,:;!?") not in SMALL_WORDS and w[:1].isalpha()]
        if len(major) >= 2 and all(w[:1].isupper() for w in major):
            count += 1
            if len(samples) < 3:
                samples.append(title[:120])
    return count, samples


def f_bullet_injection(text):
    if re.search(r"^#{1,6}\s", text, re.M):
        return 0, []
    paras = split_paragraphs(text)
    lists = [p for p in paras if all(LIST_LINE.match(l) for l in p.split("\n") if l.strip())]
    prose = [p for p in paras if p not in lists]
    if lists and len(prose) >= 2:
        return len(lists), [lists[0][:120]]
    return 0, []


def f_em_dash(text):
    count = 0
    for para in split_paragraphs(text):
        if para.count("—") >= 2:
            count += 1
    return count, []


def f_years(text):
    count = 0
    samples = []
    for m in YEAR_RANGE.finditer(text):
        if int(m.group(1)) < int(m.group(2)):
            count += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return count, samples


def f_curly_quotes(text):
    return len(CURLY.findall(text)), []


def f_horizontal_rules(text):
    lines = text.split("\n")
    rules = [l for l in lines if HR_LINE.match(l)]
    if len(lines) >= 24 and len(rules) >= 3:
        return len(rules), []
    return 0, []


def f_degenerate(text):
    ws = [w.lower() for w in words_of(text)]
    if len(ws) < 12:
        return 0, []
    shingles = [" ".join(ws[i:i + 6]) for i in range(len(ws) - 5)]
    counts = Counter(shingles)
    repeated = sum(1 for s in shingles if counts[s] > 1)
    if repeated and repeated / float(len(shingles)) >= 0.2:
        top = counts.most_common(1)[0][0]
        return repeated, [top[:120]]
    return 0, []


def f_names(text):
    count = 0
    samples = []
    for sent in split_sentences(text):
        if CREDIT.search(sent) and len(OUTLETS.findall(sent)) >= 2:
            count += 1
            samples.append(sent[:120])
    for m in PRESENCE.finditer(text):
        count += 1
        if len(samples) < 3:
            samples.append(excerpt(text, m.start(), m.end()))
    return count, samples[:3]


def f_question_answer(text):
    return _collect(RHETORIC_QA, text)


def f_tracking(text):
    count = 0
    samples = []
    for m in TRACKING.finditer(text):
        if m.group(1).rstrip(".").lower() in TRACK_HOSTS:
            count += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return count, samples


def f_chat_markup(text):
    return _collect(CHAT_MARKUP, text)


def f_inline_header(text):
    return _collect(INLINE_HEADER, text)


def f_bold(text):
    return _collect(BOLD, text)


def f_emoji(text):
    return len(EMOJI.findall(text)), []


def f_conclusions(text):
    return _collect(CONCLUSION, text)


def f_hyphen_stock(text):
    return rx_matcher([r"\b(?:cutting-edge|state-of-the-art|best-in-class|next-generation|next-gen"
                       r"|game-changing|results-driven|data-driven|user-centric|customer-centric"
                       r"|forward-thinking|high-performing|top-notch|fast-paced|out-of-the-box"
                       r"|mission-critical|value-driven)\b"])(text)


PATTERNS = []


def _p(num, slug, label, fn, weight=12.0):
    PATTERNS.append({"n": num, "slug": slug, "label": label, "fn": fn, "weight": weight})


_p(1, "ai_vocabulary", "AI vocabulary", rx_matcher(AI_VOCAB), 14.0)
_p(2, "model_dialect_vocabulary", "model-dialect vocabulary", rx_matcher(MODEL_DIALECT, min_total=2), 10.0)
_p(3, "promotional_language", "promotional language", _promo, 10.0)
_p(4, "hyphenated_word_pairs", "hyphenated word-pair overuse", f_hyphen_stock, 0.0)
_p(5, "simple_yet", "'simple yet X' cliche", rx_matcher([
    r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"]), 10.0)
_p(6, "stacked_adjectives", "stacked adjective chain", f_adjective_chain, 10.0)
_p(8, "synonym_cycling", "synonym cycling", f_synonym_cycling, 10.0)
_p(10, "significance_inflation", "significance inflation", rx_matcher([
    r"\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor(?:es|ed|ing)|highlight(?:s|ed|ing)?) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects? a broader (?:trend|shift|pattern)\b",
    r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b",
    r"\bsymboli[sz]es\b", r"\bsets? the stage for\b", r"\bleft an? indelible mark\b",
    r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b",
    r"\b(?:has|have) (?:shaped|sparked)\b", r"\b(?:has|have) come to (?:define|symboli[sz]e)\b"]), 10.0)
_p(11, "notability_name_dropping", "notability name-dropping", f_names, 10.0)
_p(12, "vague_attributions", "vague attribution", rx_matcher([
    r"\bexperts (?:argue|believe|say|claim|note|suggest)\b", r"\bindustry (?:reports|observers|analysts)\b",
    r"\bobservers have (?:cited|noted)\b", r"\bsome critics argue\b", r"\bresearchers have found\b",
    r"\bstudies suggest\b", r"\bit is widely believed\b"]), 10.0)
_p(13, "article_title_proper_noun", "article title used as proper noun", rx_matcher([
    r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [A-Za-z][\w' -]{1,60}? (?:is|are) (?:a|an|the)\b"],
    flags=0), 25.0)
_p(14, "conservation_padding", "conservation padding", rx_matcher([
    r"\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b",
    r"\bconservation efforts are (?:underway|ongoing|in place)\b", r"\bserves as an indicator species\b",
    r"\bcontributes to biodiversity\b"]), 10.0)
_p(15, "false_ranges", "false range", rx_matcher([
    r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
    r"\bfrom (?:the )?humble\b[^.!?\n]*\bto (?:the )?(?:mighty|towering|grand|sprawling)\b"]), 10.0)
_p(16, "ing_tail", "superficial -ing tail clause", rx_matcher([
    r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating"
    r"|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing"
    r"|leveraging|aligning|embodying|exemplifying|epitomizing)\b"]), 10.0)
_p(17, "negative_parallelism", "negative parallelism", f_parallelism, 0.0)
_p(17, "tailing_negation", "tailing negation", lambda t: _collect(TAIL_NEG, t), 10.0)
_p(18, "not_x_just_y", "'not X, just Y' framing", f_neg_contrast, 10.0)
_p(19, "filler_phrases", "filler phrase", rx_matcher([
    r"\bin order to\b", r"\bdue to the fact that\b", r"\bat this point in time\b", r"\bin the event that\b",
    r"\bhas the ability to\b", r"\bit is important to note that\b", r"\bit should be mentioned that\b",
    r"\bneedless to say\b"]), 0.0)
_p(20, "empty_pivot", "empty pivot phrase", rx_matcher([
    r"\bit[’']s worth (?:noting|mentioning) that\b", r"\bit bears (?:noting|mentioning) that\b",
    r"\bone thing to (?:consider|keep in mind) is\b", r"\bit is interesting to note that\b",
    r"\ba key consideration is\b", r"\ba point to highlight is\b"]), 10.0)
_p(21, "outcome_speculation", "outcome-speculation tail", rx_matcher([
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for"
    r"|reshaping our understanding of|paving the way for|signaling a shift toward)\b"]), 10.0)
_p(22, "persuasive_authority", "persuasive authority trope", rx_matcher([
    r"(?<!\w)(?:here[’']s the thing|make no mistake|the truth is|let[’']s be honest|the simple fact is"
    r"|at its core|what really matters|more than anything|at the end of the day|the bottom line is|in reality"
    r"|fundamentally,|the real question is|the heart of the matter|the deeper issue|when you get down to it"
    r"|when all is said and done)(?!\w)"]), 0.0)
_p(23, "editorial_interjection", "editorial interjection", rx_matcher([
    r"\bit(?:[’']s| is) important to (?:remember|note|understand|recognize)\b",
    r"\bone must note that\b", r"\bit is worth pointing out\b", r"\bit cannot be overstated that\b",
    r"\bit must be emphasi[sz]ed that\b"]), 10.0)
_p(24, "self_thoroughness", "self-thoroughness phrase", rx_matcher([
    r"\bthis comprehensive (?:guide|overview|analysis)\b", r"\bthis in-depth (?:analysis|look|examination)\b",
    r"\bthis complete (?:guide|overview)\b", r"\ba thorough examination of\b",
    r"\beverything you need to know about\b"]), 10.0)
_p(25, "question_answer", "question-answer rhetorical pattern", f_question_answer, 10.0)
_p(26, "concrete_evidence", "'concrete evidence' defense", rx_matcher([
    r"\bwithout concrete (?:evidence|proof)\b", r"\bdo you have concrete (?:evidence|proof)\b",
    r"\bI (?:would )?need concrete (?:evidence|examples) to\b", r"\babsent concrete proof\b",
    r"\bprovide concrete (?:evidence|proof)\b"]), 10.0)
_p(27, "compulsive_intro_hook", "compulsive intro hook", rx_matcher([
    r"\bin today[’']s(?: \w+){0,2} (?:world|landscape|environment|market)\b", r"\bin a world where\b",
    r"\bin an era of\b", r"\bin recent years,", r"\bmore than ever before\b",
    r"\bwe live in a (?:time|world) when\b", r"\b(?:great|exciting|big) news\b(?=\s*[!:])",
    r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?",
    r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b"]), 10.0)
_p(30, "diff_anchored", "diff-anchored writing", rx_matcher([
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
    r"\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b",
    r"\bpreviously\b[^.!?\n]*\bnow\b", r"\b(?:wasn[’']t|weren[’']t) there before\b",
    r"\bwe(?:[’']ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"]), 10.0)
_p(31, "signposting", "signposting announcement", rx_matcher([
    r"\blet[’']s (?:dive|delve|explore)\b", r"\blet[’']s break (?:this|it) down\b",
    r"\bhere[’']s what you need to know\b", r"\bwithout further ado\b", r"\bnow let[’']s look at\b",
    r"\bbuckle up\b", r"\bstay with me\b", r"\bready to dive in\b"]), 10.0)
_p(32, "cataloguing_lead_in", "cataloguing lead-in", rx_matcher([
    r"\b(?:used|uses|employs?|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+",
    r"(?:^|[.!?]\s+)These (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b"],
    flags=re.I | re.M), 10.0)
_p(33, "inline_header_list", "inline-header vertical list", f_inline_header, 10.0)
_p(34, "mid_essay_bullets", "mid-essay bullet list", f_bullet_injection, 10.0)
_p(35, "fragmented_header", "fragmented header", f_fragmented_headers, 10.0)
_p(36, "formulaic_challenges", "formulaic challenges section", rx_matcher([
    r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b", r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b",
    r"\bcontinues to thrive\b", r"\btypical of (?:emerging|urban|modern)\b",
    r"\bfaces (?:several|many|numerous) challenges\b"]), 10.0)
_p(37, "transition_cluster", "transition cluster", f_transitions, 10.0)
_p(38, "compulsive_conclusion", "compulsive conclusion phrase", f_conclusions, 10.0)
_p(39, "generic_positive_conclusion", "generic positive conclusion", rx_matcher([
    r"\bexciting times lie ahead\b", r"\bjourney toward excellence\b",
    r"\bstep in the right direction\b",
    r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b",
    r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b"]), 10.0)
_p(40, "sentence_length_monotony", "sentence-length monotony", f_monotony, 10.0)
_p(41, "mechanical_alternation", "mechanical sentence-length alternation", f_alternation, 0.0)
_p(42, "opener_repetition", "opener repetition", f_opener_repetition, 0.0)
_p(44, "uniform_paragraphs", "uniform paragraph length", f_uniform_paragraphs, 10.0)
_p(46, "semicolon_underuse", "semicolon and parenthesis underuse", f_semicolon, 0.0)
_p(47, "chatbot_artifact", "chatbot artifact", rx_matcher([
    r"\bI hope this helps\b", r"\b(?:Certainly|Of course)!", r"\blet me know if you\b",
    r"\bwould you like me to\b", r"\bfeel free to (?:ask|reach out)\b", r"\bhappy to help[.!]",
    r"\b(?:here|below) is (?:an?|the) (?:overview|summary|rundown|recap|brief)\b",
    r"\bhere (?:are|[’']s a few|[’']s some|are some) (?:options|drafts|versions|variations)\b",
    r"\bhere (?:are|[’']s|is) (?:two|three) (?:options|drafts|versions|variations)\b",
    r"\bhere (?:is|[’']s) (?:a|the) (?:draft|first pass|revised version)\b",
    r"\bdepending on the (?:vibe|tone|style)\b", r"\bI hope (?:this email )?finds you well\b",
    r"\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b",
    r"\bto (?:answer|address) your question\b", r"\bin (?:response|answer) to your question\b",
    r"\byour question (?:about|regarding|concerning)\b", r"\bas (?:you )?(?:requested|asked),? here\b"]), 14.0)
_p(48, "sycophantic_tone", "sycophantic tone", rx_matcher([
    r"\byou(?:[’']re| are) absolutely right\b",
    r"\b(?:great|excellent|good|fantastic|wonderful|brilliant|thoughtful) (?:question|point)(?=[!.,])",
    r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b",
    r"\bthat[’']s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"]), 14.0)
_p(50, "knowledge_cutoff", "knowledge-cutoff disclaimer", rx_matcher([
    r"\bas of my (?:last )?(?:training|knowledge)\b", r"\bup to my (?:last )?(?:training|knowledge)\b",
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively |widely )?documented)\b",
    r"\bbased on (?:the )?available information\b", r"\bas of my (?:knowledge )?cutoff\b",
    r"\bmaintains a low profile\b", r"\bkeeps (?:his|her|their) personal life private\b"]), 14.0)
_p(51, "copula_avoidance", "copula avoidance", rx_matcher([
    r"\b(?:serves|stands|functions|acts) as\b", r"\b(?:represents|marks) (?:a|the)\b", r"\bboasts\b",
    r"\bfeatures (?:an?|the|\d+|one|two|three|several|many|numerous)\b", r"\boffers an?\b", r"\brefers to\b"]), 10.0)
_p(54, "hedge_stacking", "hedge stacking", f_hedge_stacking, 0.0)
_p(55, "contraction_absence", "contraction absence", f_contraction, 0.0)
_p(56, "boldface_overuse", "boldface overuse", f_bold, 6.0)
_p(57, "emoji", "emoji", f_emoji, 10.0)
_p(58, "em_dash_overuse", "em-dash overuse", f_em_dash, 0.0)
_p(59, "title_case_heading", "title case in heading", f_title_case, 6.0)
_p(60, "curly_quotes", "curly quotation marks", f_curly_quotes, 0.0)
_p(61, "hyphen_for_en_dash", "hyphen for en dash in year range", f_years, 0.0)
_p(63, "placeholder_text", "placeholder text", rx_matcher([
    r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])",
    r"\[(?:name|company|client|place|source|person|organi[sz]ation|city|date)\](?![\(\[])",
    r"\[[A-Z][A-Z \-_]{2,}\](?![\(\[])", r"\{\{[^}\n]*\}\}", r"(?<![A-Za-z])x{3,}(?![A-Za-z])",
    r"\blorem ipsum\b"]), 25.0)
_p(64, "chat_reference_markup", "chat reference markup", f_chat_markup, 25.0)
_p(65, "tracking_parameter", "AI tracking parameter", f_tracking, 25.0)
_p(69, "stock_marketing_phrase", "stock marketing phrase", rx_matcher([
    r"\bunlocking (?:\w+ ){0,2}potential\b", r"\bnavigating the complexities\b",
    r"\ba testament to the (?:power|importance) of\b", r"\bstaying ahead of the curve\b",
    r"\bturning challenges into opportunities\b", r"\btaking \w+ to the next level\b",
    r"\bharnessing the power of\b", r"\bpaving the way for\b", r"\bsaying goodbye to\b",
    r"\bimagining a world where\b"]), 10.0)
_p(70, "decorative_rules", "decorative horizontal rules", f_horizontal_rules, 6.0)
_p(71, "degenerate_repetition", "degenerate repetition", f_degenerate, 14.0)


# ---------------------------------------------------------------- scoring

def char_findings(win, rtl):
    """Findings 62, 66, 67, 68 are computed on the scan window (FP-01, FP-02)."""
    found = []
    inv = invisible_positions(win, rtl)
    if inv:
        found.append((62, "invisible_characters", "invisible characters", len(inv),
                      ["U+%04X at character %d" % (ord(win[i]), i + 1) for i in inv[:3]]))
    hg = homoglyph_runs(win)
    if hg:
        found.append((66, "homoglyphs", "mixed-script homoglyphs", len(hg),
                      [win[s:e][:40] for s, e in hg[:3]]))
    ns = nonstandard_positions(win)
    if ns:
        found.append((67, "nonstandard_spaces", "non-standard spaces", len(ns),
                      ["U+%04X" % ord(win[i]) for i in ns[:3]]))
    tw = trailing_whitespace_count(win)
    if tw:
        found.append((68, "trailing_whitespace", "trailing or stray whitespace", tw, []))
    return found, len(inv), len(ns), len(hg)


def band_of(score):
    for limit, name in BANDS:
        if score <= limit:
            return name
    return BANDS[-1][1]


def confidence_of(words, fams):
    if words < 40:
        return "none", "fewer than 40 words were scanned"
    if words < 120:
        return "low", "only %d words were scanned" % words
    if words < 300 and len(fams) == 1:
        return "low", "only %d words and one pattern family" % words
    if words < 300:
        return "moderate", "fewer than 300 words were scanned"
    return "high", ""


def score_report(findings, words):
    """Score the findings (FP-01). Returns (score, band, families, confidence, reason)."""
    sat = max(1.0, words / 150.0)
    base = 0.0
    fams = set()
    decisive = set()
    for info in findings.values():
        if info["weight"] <= 0:
            continue
        fams.add(info["n"])
        if info["n"] in DECISIVE:
            decisive.add(info["n"])
        base += info["weight"] * min(4.0, info["count"] / sat)
    confidence, reason = confidence_of(words, fams)
    score = min(100.0, base)
    # Rhythm-only documents: at most 40; sentence-length monotony alone: at most 20.
    if fams and fams <= {40, 44}:
        score = min(score, 20.0 if fams == {40} else 40.0)
    # A single score-moving family caps at 40, unless one decisive family lifts it (below).
    single_decisive_floor = len(decisive) == 1 and confidence in ("moderate", "high")
    if len(fams) == 1 and not single_decisive_floor:
        score = min(score, 40.0)
    if len(decisive) >= 2:
        score = max(score, 65.0)
    elif single_decisive_floor:
        score = max(score, 45.0)
    if words < 120:
        short = fams & (set(range(1, 40)) | set(range(47, 52)) | {69})
        if len(short) >= 3:
            score = max(score, 45.0)
        elif len(short) == 2:
            score = max(score, 25.0)
    if words >= 400:
        if len(fams) >= 6:
            score = max(score, 45.0)
        elif len(fams) >= 5:
            score = max(score, 25.0)
    score = int(round(min(100.0, max(0.0, score))))
    return score, band_of(score), fams, confidence, reason


def _interval(sent_hits, sent_words, score):
    """Heuristic low/high interval from a fixed-seed bootstrap over sentences (--ci)."""
    n = len(sent_hits)
    if n < 4:
        return None, "too few sentences for an interval (need at least 4)"
    full_rate = sum(sent_hits) / float(max(1, sum(sent_words)))
    if full_rate <= 0:
        return [0, 0], "resampled sentences; no pattern hits, so the interval is zero"
    rng = random.Random(20240601)
    rates = []
    for _ in range(200):
        idx = [rng.randrange(n) for _ in range(n)]
        hits = sum(sent_hits[i] for i in idx)
        wds = sum(sent_words[i] for i in idx)
        rates.append(hits / float(max(1, wds)))
    rates.sort()
    scale = score / full_rate
    low = int(round(rates[int(0.025 * len(rates))] * scale))
    high = int(round(rates[min(len(rates) - 1, int(0.975 * len(rates)))] * scale))
    low = max(0, min(low, score))
    high = min(100, max(high, score))
    return [low, high], "resampled sentences (200 draws, fixed seed); a heuristic interval"


def analyze(text, want_ci=False):
    total = len(text)
    win = text[:WINDOW]
    rtl = bool(RTL_RX.search(win))
    masked = mask_text(win)
    words = len(words_of(masked))
    findings = {}
    char_found, n_inv, n_ns, n_hg = char_findings(win, rtl)
    for num, slug, label, count, samples in char_found:
        weight = 0.0 if num in ADVICE else (10.0 if num == 67 else 25.0)
        findings["%d_%s" % (num, slug)] = {"n": num, "label": label, "count": count,
                                           "samples": samples, "weight": weight}
    for pat in PATTERNS:
        count, samples = pat["fn"](masked)
        if not count:
            continue
        weight = 0.0 if pat["n"] in ADVICE or pat["slug"] == "negative_parallelism" else pat["weight"]
        findings["%d_%s" % (pat["n"], pat["slug"])] = {
            "n": pat["n"], "label": pat["label"], "count": int(count),
            "samples": [s[:200] for s in samples][:3], "weight": weight}
    score, band, fams, confidence, reason = score_report(findings, words)
    report = {}
    for key in sorted(findings, key=lambda k: (int(k.split("_", 1)[0]), k)):
        info = findings[key]
        report[key] = {"label": info["label"], "count": info["count"], "samples": info["samples"]}
    metrics = {
        "scanned_chars": len(win),
        "truncated": total > WINDOW,
        "ai_tell_score": score,
        "ai_tell_band": band,
        "confidence": confidence,
        "confidence_reason": reason,
        "patterns_flagged": len(findings),
        "invisible_chars": n_inv,
        "nonstandard_spaces": n_ns,
        "homoglyphs": n_hg,
        "word_count": words,
    }
    report["_metrics"] = metrics
    if want_ci:
        sents = split_sentences(masked)
        hits = []
        sent_words = []
        for sent in sents:
            hits.append(sum(p["fn"](sent)[0] for p in PATTERNS if p["weight"] > 0))
            sent_words.append(len(words_of(sent)))
        metrics["score_ci"], metrics["score_ci_note"] = _interval(hits, sent_words, score)
    return report


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    clean = ci = want_help = False
    operands = []
    end_of_options = False
    for arg in args:
        if end_of_options:
            operands.append(arg)
        elif arg == "--":
            end_of_options = True
        elif arg in ("-h", "--help"):
            want_help = True
        elif arg == "--clean":
            clean = True
        elif arg == "--ci":
            ci = True
        elif arg == "-":
            operands.append(arg)
        elif arg.startswith("-"):
            fail("unknown option '%s'; see --help" % arg, 2)
        else:
            operands.append(arg)
    if want_help:
        sys.stdout.write(USAGE + "\n")
        return 0
    path = operands[0] if operands and operands[0] != "-" else None
    if len(operands) > 1:
        sys.stderr.write("prosecheck: scanned only the first file, %s; %d more operand(s) ignored\n"
                         % (operands[0], len(operands) - 1))
    if path is None:
        data = sys.stdin.buffer.read()
    else:
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError as exc:
            fail("cannot read input: %s" % (exc.strerror or "unreadable path"), 1)
    text = extract(path, data)
    if not text.strip():
        fail("empty input", 1)
    if clean:
        sys.stdout.buffer.write(scrub(text).encode("utf-8"))
        return 0
    report = analyze(text, want_ci=ci)
    sys.stdout.buffer.write((json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
