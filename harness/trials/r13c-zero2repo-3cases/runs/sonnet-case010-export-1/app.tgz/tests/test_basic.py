import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from lingora import data
from lingora.chunk import RegexpParser
from lingora.classify import NaiveBayesClassifier
from lingora.grammar import CFG
from lingora.metrics import accuracy, edit_distance, f_measure, precision
from lingora.parse import ChartParser
from lingora.parse.generate import generate
from lingora.stem import PorterStemmer, SnowballStemmer
from lingora.tokenize import wordpunct_tokenize, word_tokenize, sent_tokenize
from lingora.tree import Tree
from lingora.translate import bleu


def test_wordpunct():  # spec: N-000086
    assert wordpunct_tokenize("Hi, there_x!") == ["Hi", ",", "there_x", "!"]


def test_missing_punkt_raises():  # spec: N-000396
    saved = list(data.path)
    data.path[:] = []
    try:
        with pytest.raises(Exception):
            sent_tokenize("x.")
        assert word_tokenize("a b.", preserve_line=True) == ["a", "b", "."]
    finally:
        data.path[:] = saved


def test_porter():
    assert PorterStemmer().stem("ponies") == "poni"
    assert SnowballStemmer("english").stem("generously") == "generous"
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_chunk_and_tree():
    t = RegexpParser("NP: {<DT>?<NN>}").parse([("the", "DT"), ("dog", "NN")])
    assert t.label() == "S" and t[0].label() == "NP"
    assert Tree.fromstring("(S (A x))") == Tree("S", [Tree("A", ["x"])])
    with pytest.raises(TypeError):
        Tree("S", "abc")


def test_parsers():
    g = CFG.fromstring("S -> A B\nA -> 'a'\nB -> 'b' | 'c'")
    assert len(list(ChartParser(g).parse(["a", "b"]))) == 1
    assert list(ChartParser(g).parse(["b", "a"])) == []
    with pytest.raises(ValueError):
        list(ChartParser(g).parse(["zzz"]))
    assert list(generate(g)) == [["a", "b"], ["a", "c"]]


def test_metrics():
    assert edit_distance("abc", "acb", transpositions=True) == 1
    assert precision({1, 2}, set()) is None
    assert f_measure({1}, {1}) == 1.0
    with pytest.raises(ValueError):
        accuracy([1], [1, 2])
    assert bleu([["a", "b", "c", "d"]], ["a", "b", "c", "d"]) == 1.0


def test_nb():
    nb = NaiveBayesClassifier.train([({"a": 1}, "x"), ({"a": 0}, "y")])
    assert nb.classify({"a": 1}) == "x"
    assert abs(sum(nb.prob_classify({"a": 1}).prob(l) for l in nb.labels()) - 1) < 1e-9
