# lingora — implementation notes

Flat package `lingora/` (pure Python, no dependencies). Spec ids are marked `# spec: N-…` where a single
line satisfies them; modules map to the contract packs:

| Pack | Module |
|---|---|
| 05–06 | `lingora/data.py` (`data.path`, `find`, `read_lines`) |
| 07 / FP-01 | `lingora/tokenize.py` (Regexp/WordPunct/Whitespace/BlankLine/Treebank/Tweet, Punkt `sent_tokenize`, `word_tokenize`) |
| 08 | `lingora/cli.py` (`cli.main(args=['tokenize'])`, `python -m lingora tokenize`) |
| 09 / FP-02 | `lingora/stem/` (Porter, Lancaster, Snowball, Regexp, Cistem, ARLSTem, WordNetLemmatizer, RSLP) |
| 10 / FP-03 | `lingora/tag.py` |
| 11 / FP-04 | `lingora/chunk.py` |
| 12–13 / FP-05 | `lingora/grammar.py`, `lingora/parse/`, `lingora/tree.py` |
| 14 / FP-06 | `lingora/classify.py` |
| 15 / FP-07 | `lingora/metrics.py`, `lingora/translate/` |

Not done / approximate (all outside the specified behaviour or unverifiable without data):
- Snowball Finnish, Hungarian, Romanian and Arabic are condensed approximations of the published algorithms;
  English, German, French, Spanish, Italian, Portuguese, Dutch, Swedish, Norwegian, Danish, Russian follow them.
  `porter` delegates to the Porter stemmer in its default mode.
- ISRI, ARLSTem, ARLSTem2, RSLP: simple implementations (results are outside the specification).
- `ne_chunk` checks that the model and wordlist are visible, then returns the tokens unchunked
  (results with the resource present are outside the specification).
- The Tweet tokenizer uses a simplified URL pattern.
