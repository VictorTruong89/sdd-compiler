"""Shift-reduce parser. spec: N-000453 N-000455"""
from ..grammar import Nonterminal
from ..tree import Tree
from .chart import _check_tokens


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            k = len(rhs)
            if k == 0 or k > len(stack):
                continue
            if all(self._match(r, s) for r, s in zip(rhs, stack[-k:])):
                stack[-k:] = [Tree(str(prod.lhs()), stack[-k:])]
                return True
        return False

    @staticmethod
    def _match(r, s):
        if isinstance(r, str):
            return isinstance(s, str) and s == r
        return isinstance(s, Tree) and s.label() == str(r)

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while True:
            while self._reduce(stack):
                pass
            if not remaining:
                break
            stack.append(remaining.pop(0))
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return [stack[0]]
        return []
