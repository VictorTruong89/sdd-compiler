from .chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Exhaustive top-down parser (results share the chart parser's implementation)."""
