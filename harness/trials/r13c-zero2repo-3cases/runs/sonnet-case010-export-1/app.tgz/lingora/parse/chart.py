"""Exhaustive parser. spec: N-000452 N-000453 N-000454 N-000455 N-000456"""
from ..grammar import Nonterminal
from ..tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str")
    tokens = list(tokens)
    terms = grammar.terminals()
    unknown = [t for t in tokens if t not in terms]
    if unknown:  # spec: N-000455
        raise ValueError("Grammar does not cover some of the input words: %r." % unknown)
    return tokens


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parses(tokens))

    def parse_all(self, tokens):
        return list(self.parse(tokens))

    def _parses(self, tokens):
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()

        def sym_trees(sym, i, j):
            """Return (list of trees, cut) for symbol over tokens[i:j]."""
            if isinstance(sym, str):
                return ([tokens[i]] if j == i + 1 and tokens[i] == sym else []), False
            key = (sym, i, j)
            if key in memo:
                return memo[key], False
            if key in active:
                return [], True
            active.add(key)
            result = []
            cut = False
            for prod in g.productions(sym):
                seqs, c = seq_trees(prod.rhs(), 0, i, j)
                cut = cut or c
                for kids in seqs:
                    result.append(Tree(str(sym), kids))
            active.discard(key)
            if not cut:
                memo[key] = result
            return result, cut

        def seq_trees(rhs, k, i, j):
            if k == len(rhs):
                return ([[]] if i == j else []), False
            out = []
            cut = False
            last = k == len(rhs) - 1
            ends = [j] if last else range(i, j + 1)
            for m in ends:
                if isinstance(rhs[k], str) and m != i + 1:
                    continue
                first, c1 = sym_trees(rhs[k], i, m)
                cut = cut or c1
                if not first:
                    continue
                rest, c2 = seq_trees(rhs, k + 1, m, j)
                cut = cut or c2
                for a in first:
                    for b in rest:
                        out.append([a] + b)
            return out, cut

        trees, _ = sym_trees(g.start(), 0, n)
        return trees
