"""Context-free grammars. spec: N-000441 N-000444 N-000445 N-000446"""
import re


class Nonterminal:
    # spec: N-000447 N-000448 (a symbol object whose str() is its name; not a str)
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


def nonterminals(symbols):
    return [Nonterminal(s) for s in re.split(r"[\s,]+", symbols.strip()) if s]


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)
        self._hash = hash((lhs, self._rhs))

    def lhs(self):
        return self._lhs

    def rhs(self):  # spec: N-000449 N-000450
        return self._rhs

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return self._hash

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "<Production: %s>" % self


_TOKEN = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


def _parse_rhs(text):
    """Split an RHS text into alternatives, each a list of Nonterminal / str."""
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("Unterminated quote or bad token in grammar: %r" % text[pos:])
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None, empty=False):
        if lhs is not None and not isinstance(lhs, Nonterminal):
            lhs = Nonterminal(lhs)
        prods = self._productions if lhs is None else self._lhs_index.get(lhs, [])
        if rhs is not None:
            prods = [p for p in prods if p.rhs() and p.rhs()[0] == rhs]
        return list(prods)

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        prods = []
        lines = input.split("\n")
        logical = []
        for line in lines:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("|") and logical:
                logical[-1] += " " + s
            else:
                logical.append(s)
        for s in logical:
            m = re.match(r"^(\S+?)\s*(?:->|→)(.*)$", s)
            if not m:
                raise ValueError("Unable to parse production: %r" % s)
            lhs = Nonterminal(m.group(1))
            for alt in _parse_rhs(m.group(2)):
                prods.append(Production(lhs, alt))
        if not prods:
            raise ValueError("No productions found")
        return cls(prods[0].lhs(), prods)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + "\n".join(
            "    %s" % p for p in self._productions)

    __repr__ = __str__
