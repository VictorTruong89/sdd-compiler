"""Packaged resource lookup. spec: N-000368 N-000369 N-000370 N-000371"""
import os

# spec: N-000371 (initial contents are the implementer's choice)
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "lingora_data"))


def find(resource):
    """Return the path of `resource` in the first directory of `path` holding it.

    Only the directories currently listed in `path` are searched.  # spec: N-000369
    Raises LookupError when the resource is not visible.  # spec: N-000370
    """
    parts = [p for p in str(resource).split("/") if p]
    for d in list(path):
        cand = os.path.join(str(d), *parts)
        if os.path.exists(cand):
            return cand
    raise LookupError("resource %r not found in data.path" % (resource,))


def read_lines(filename):
    """Entries of a UTF-8 text file: each line without its line terminator. spec: N-000381"""
    with open(filename, encoding="utf-8", newline="") as f:
        text = f.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [ln[:-1] if ln.endswith("\r") else ln for ln in lines]
