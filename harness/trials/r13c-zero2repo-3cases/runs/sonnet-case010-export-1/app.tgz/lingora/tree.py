"""Constituent trees. spec: N-000461 N-000462"""
import re


class Tree(list):
    # spec: N-000466 N-000467 N-000468
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("children should be a list of children, not a string")
        if not isinstance(children, (list, tuple)) and not hasattr(children, "__iter__"):
            raise TypeError("children should be a list")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __getitem__(self, i):
        if isinstance(i, (int, slice)):
            return list.__getitem__(self, i)
        if isinstance(i, (list, tuple)):
            node = self
            for k in i:
                node = node[k]
            return node
        raise TypeError("index must be int, slice or sequence of ints")

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for child in self:
            if isinstance(child, Tree):
                yield from child.subtrees(filter)

    def height(self):
        h = 0
        for child in self:
            h = max(h, child.height() if isinstance(child, Tree) else 1)
        return h + 1

    def pos(self):
        return [(w, self._label) for w in self if not isinstance(w, Tree)] if False else self._pos()

    def _pos(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child._pos())
            else:
                out.append((child, self._label))
        return out

    def copy(self, deep=False):
        import copy as _c
        return _c.deepcopy(self) if deep else Tree(self._label, list(self))

    def flatten(self):
        return Tree(self._label, self.leaves())

    @classmethod
    def fromstring(cls, s):
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def node():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' in tree text")
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in "()":
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced brackets in tree text")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(node())
                else:
                    children.append(t)
                    pos += 1

        t = node()
        if pos != len(toks):
            raise ValueError("unexpected text after tree")
        return t

    @staticmethod
    def _leafstr(x):
        if isinstance(x, tuple) and len(x) == 2:
            return "%s/%s" % (x[0], x[1])
        return str(x)

    def pformat(self, margin=70, indent=0):
        # spec: N-000470 (layout is implementer's choice)
        flat = self._flat()
        if len(flat) + indent <= margin:
            return flat
        parts = ["(%s" % self._label]
        for child in self:
            if isinstance(child, Tree):
                parts.append("\n" + " " * (indent + 2) + child.pformat(margin, indent + 2))
            else:
                parts.append("\n" + " " * (indent + 2) + self._leafstr(child))
        return "".join(parts) + ")"

    def _flat(self):
        bits = [str(self._label)]
        for child in self:
            bits.append(child._flat() if isinstance(child, Tree) else self._leafstr(child))
        return "(" + " ".join(bits) + ")"

    def productions(self):
        from .grammar import Production, Nonterminal
        rhs = [Nonterminal(c.label()) if isinstance(c, Tree) else c for c in self]
        out = [Production(Nonterminal(self._label), rhs)]
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __deepcopy__(self, memo):
        import copy as _c
        return Tree(self._label, [_c.deepcopy(c, memo) for c in self])
