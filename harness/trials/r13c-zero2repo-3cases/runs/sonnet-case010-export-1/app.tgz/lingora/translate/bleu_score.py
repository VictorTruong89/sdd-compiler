"""Sentence-level BLEU (Papineni et al., 2002). spec: N-000480"""
import math
import sys
from collections import Counter
from collections import namedtuple



class Fraction(namedtuple('Fraction', 'numerator denominator')):
    def __float__(self):
        return self.numerator / self.denominator


def _ngrams(seq, n):
    return zip(*[seq[i:] for i in range(n)])


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for reference in references:
        rc = Counter(_ngrams(reference, n)) if len(reference) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts[ng]) for ng, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())))


def closest_ref_length(references, hyp_len):
    return min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))


def brevity_penalty(closest_ref_len, hyp_len):
    if hyp_len > closest_ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest_ref_len / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon, self.alpha, self.k = epsilon, alpha, k

    def method0(self, p_n, *args, **kw):
        out = []
        for p in p_n:
            out.append(p if p.numerator != 0 else sys.float_info.min)
        return out

    def method1(self, p_n, *args, **kw):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, *args, **kw):
        return [Fraction(p.numerator + 1, p.denominator + 1) for p in p_n]

    def method3(self, p_n, *args, **kw):
        incvnt = 1
        out = []
        for p in p_n:
            if p.numerator == 0:
                incvnt *= 2
                out.append(1 / (incvnt * p.denominator))
            else:
                out.append(p)
        return out


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("references and hypothesis must be token lists")
    if not references:
        raise ValueError("at least one reference is required")
    weights = tuple(weights)
    p_n = [modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    if not p_n or p_n[0].numerator == 0:
        return 0
    hyp_len = len(hypothesis)
    bp = brevity_penalty(closest_ref_length(references, hyp_len), hyp_len)
    smooth = smoothing_function or SmoothingFunction().method0
    p_n = smooth(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    s = (w * math.log(float(p)) for w, p in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))


sentence_bleu = bleu
