"""Classifiers. spec: N-000472 N-000473"""
import math
from collections import defaultdict


class DictionaryProbDist:
    # spec: N-000476 N-000477
    def __init__(self, prob_dict, log=False, normalize=False):
        self._prob = {}
        if log:
            vals = list(prob_dict.values())
            m = max(vals)
            tot = m + math.log(sum(math.exp(v - m) for v in vals)) if m != -math.inf else -math.inf
            for k, v in prob_dict.items():
                self._prob[k] = math.exp(v - tot) if normalize else math.exp(v)
        else:
            tot = sum(prob_dict.values())
            for k, v in prob_dict.items():
                self._prob[k] = (v / tot) if normalize and tot else v

    def prob(self, sample):
        return float(self._prob.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else -math.inf

    def samples(self):
        return list(self._prob.keys())

    def max(self):
        return max(self._prob, key=self._prob.get)

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._prob)


class ClassifierI:
    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


class NaiveBayesClassifier(ClassifierI):
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist.keys())

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def prob_classify(self, featureset):
        fs = {}
        for fname, fval in featureset.items():
            if any((label, fname) in self._feature_probdist for label in self._labels):
                fs[fname] = fval
        logprob = {label: math.log(self._label_probdist[label]) for label in self._labels}
        for label in self._labels:
            for fname, fval in fs.items():
                pd = self._feature_probdist.get((label, fname))
                if pd is not None:
                    counts, total, bins = pd
                    logprob[label] += math.log((counts.get(fval, 0) + 0.5) / (total + 0.5 * bins))
        return DictionaryProbDist(logprob, normalize=True, log=True)

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = {}
        feature_freq = defaultdict(dict)
        feature_values = defaultdict(set)
        fnames = []
        seen = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] = label_freq.get(label, 0) + 1
            for fname, fval in featureset.items():
                d = feature_freq[(label, fname)]
                d[fval] = d.get(fval, 0) + 1
                feature_values[fname].add(fval)
                if fname not in seen:
                    seen.add(fname)
                    fnames.append(fname)
        for label, num in label_freq.items():
            for fname in fnames:
                d = feature_freq[(label, fname)]
                count = sum(d.values())
                if num - count > 0:
                    d[None] = d.get(None, 0) + num - count
                    feature_values[fname].add(None)
        total = sum(label_freq.values())
        nl = len(label_freq)
        label_probdist = {l: (c + 0.5) / (total + 0.5 * nl) for l, c in label_freq.items()}
        feature_probdist = {}
        for (label, fname), d in feature_freq.items():
            feature_probdist[(label, fname)] = (d, sum(d.values()), len(feature_values[fname]))
        return cls(label_probdist, feature_probdist)


def _majority(labels):
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    best = None
    for l, c in counts.items():
        if best is None or c > counts[best]:
            best = l
    return best, counts


def _entropy(labels):
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    n = len(labels)
    return -sum((c / n) * math.log(c / n, 2) for c in counts.values()) if n else 0.0


class DecisionTreeClassifier(ClassifierI):
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        labels = {self._label}
        if self._decisions:
            for d in self._decisions.values():
                labels.update(d.labels())
        if self._default is not None:
            labels.update(self._default.labels())
        return list(labels)

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = sum(1 for fs, l in labeled_featuresets if self.classify(fs) != l)
        return errors / len(labeled_featuresets)

    @staticmethod
    def stump(fname, labeled_featuresets):
        label, _ = _majority([l for _, l in labeled_featuresets])
        freqs = {}
        for fs, l in labeled_featuresets:
            freqs.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_majority(ls)[0]) for v, ls in freqs.items()}
        return DecisionTreeClassifier(label, fname, decisions, DecisionTreeClassifier(label))

    @staticmethod
    def best_stump(feature_names, labeled_featuresets):
        label, _ = _majority([l for _, l in labeled_featuresets])
        best = DecisionTreeClassifier(label)
        best_error = best.error(labeled_featuresets)
        for fname in feature_names:
            st = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = st.error(labeled_featuresets)
            if err < best_error:
                best, best_error = st, err
        return best

    def refine(self, labeled_featuresets, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled_featuresets) <= support_cutoff:
            return
        if self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) == fval]
            if _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) not in self._decisions]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    names.append(f)
        tree = cls.best_stump(names, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        raise ValueError("gold must not be empty")
    correct = sum(1 for fs, l in gold if classifier.classify(fs) == l)
    return correct / len(gold)
