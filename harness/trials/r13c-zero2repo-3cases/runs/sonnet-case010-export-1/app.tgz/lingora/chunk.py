"""Chunking. spec: N-000426 N-000427"""
import os
import re

from . import data
from .tree import Tree

_SENTENCE = "S"  # spec: N-000436 N-000437


def _tag_pattern_to_re(pat):
    pat = re.sub(r"\s", "", pat)
    pat = pat.replace("<", "(?:<(?:").replace(">", ")>)")
    pat = re.sub(r"(?<!\\)\.", r"[^{}<>]", pat)
    return pat


_IN_STRIP = r"(?=[^\}]*(\{|$))"
_IN_CHUNK = r"(?=[^\{]*\})"


class _Rule:
    def __init__(self, kind, tag_pattern):
        self.kind = kind
        core = _tag_pattern_to_re(tag_pattern)
        if kind == "chunk":
            self._re = re.compile("(?P<x>" + core + ")" + _IN_STRIP)
            self._repl = r"{\g<x>}"
        else:
            self._re = re.compile("(?P<x>" + core + ")" + _IN_CHUNK)
            self._repl = r"}\g<x>{"

    def apply(self, s):
        s = self._re.sub(self._repl, s)
        return s.replace("{}", "")

    @classmethod
    def fromstring(cls, text):
        text = re.match(r"(?P<rule>(\\.|[^#])*)", text).group("rule").strip()
        if text.startswith("{") and text.endswith("}") and len(text) >= 2:
            return cls("chunk", text[1:-1])
        if text.startswith("}") and text.endswith("{") and len(text) >= 2:
            return cls("chink", text[1:-1])
        raise ValueError("Illegal chunk pattern: %s" % text)


class _Stage:
    def __init__(self, rules, label):
        self.rules = rules
        self.label = label

    def parse(self, tree, root_label):
        pieces = list(tree)
        if not pieces:
            return Tree(root_label, [])
        tags = []
        for tok in pieces:
            tags.append(tok.label() if isinstance(tok, Tree) else tok[1])
        s = "<" + "><".join(str(t) for t in tags) + ">"
        for rule in self.rules:
            s = rule.apply(s)
        out = []
        index = 0
        in_chunk = False
        for piece in re.split("[{}]", s):
            length = piece.count("<")
            sub = pieces[index:index + length]
            if in_chunk:
                if sub:
                    out.append(Tree(self.label, sub))
            else:
                out.extend(sub)
            index += length
            in_chunk = not in_chunk
        return Tree(root_label, out)


class RegexpParser:
    def __init__(self, grammar, root_label=_SENTENCE):
        # spec: N-000429 N-000431
        self._root = root_label
        if isinstance(grammar, str):
            self._stages = self._read(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, _Stage) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    @staticmethod
    def _read(grammar):
        stages = []
        label = None
        rules = []
        for line in grammar.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"(?P<label>(\\.|[^:])*)(:(?P<rule>.*))", line)
            if m and not line.startswith(("{", "}")):
                if label is not None:
                    stages.append(_Stage(rules, label))
                label = m.group("label").strip()
                rules = []
                rest = m.group("rule").strip()
                if rest:
                    rules.append(_Rule.fromstring(rest))
            else:
                if label is None:
                    raise ValueError("Illegal chunk grammar: rule without a label: %r" % line)
                rules.append(_Rule.fromstring(line))
        if label is not None:
            stages.append(_Stage(rules, label))
        if not stages:
            raise ValueError("Illegal chunk grammar: no clauses")
        return stages

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        tree = Tree(self._root, list(tagged))
        for stage in self._stages:
            tree = stage.parse(tree, self._root)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    """Named-entity chunker; needs the packaged model and the English wordlist. spec: N-000432"""
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    if isinstance(tagged_tokens, str):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    # Results with the model present are outside the specification: tokens stay unchunked.
    return Tree(_SENTENCE, list(tagged_tokens))
