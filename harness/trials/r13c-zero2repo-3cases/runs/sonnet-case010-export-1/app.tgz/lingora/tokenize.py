"""Tokenizers. spec: N-000386 N-000387"""
import os
import re

from . import data

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
    "WordPunctTokenizer", "BlankLineTokenizer", "blankline_tokenize", "sent_tokenize",
    "word_tokenize", "wordpunct_tokenize", "PunktSentenceTokenizer",
]


class RegexpTokenizer:
    # spec: N-000111 N-000112 N-000113
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        if self._gaps:
            out = [text[a:b] for a, b in self._gap_spans(text)]
            return [t for t in out if t] if self._discard_empty else out
        return [m.group() for m in self._regexp.finditer(text)]

    def _gap_spans(self, text):
        last = 0
        for m in self._regexp.finditer(text):
            if m.end() == m.start() and m.start() in (0, len(text)):
                continue
            yield last, m.start()
            last = m.end()
        yield last, len(text)

    def span_tokenize(self, text):  # spec: N-000121 N-000395
        if self._gaps:
            for a, b in self._gap_spans(text):
                if not (self._discard_empty and a == b):
                    yield a, b
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            self.__class__.__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlankLineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_wordpunct = WordPunctTokenizer()
_blankline = BlankLineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# ---------------------------------------------------------------- Treebank

class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedTreebankTokenizer(TreebankWordTokenizer):
    # spec: N-000101 N-000102 N-000103 N-000104 N-000105
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$"), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"\s+"), " "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_improved = _ImprovedTreebankTokenizer()


# ---------------------------------------------------------------- Tweet

_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
    (?:
      (?:https?://|www\.)
      [^\s<>"]*[^\s<>".,;:!?'\)\]\}]
    )"""
_REGEXPS = (
    _URLS,
    r"[\-]+>|<[\-]+",
    r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[\w.%+-]+@[\w.-]+\.[a-zA-Z]{2,}",
    _EMOTICONS,
    r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
    """,
)
_WORD_RE = re.compile("(%s)" % "|".join(_REGEXPS), re.VERBOSE | re.IGNORECASE | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.IGNORECASE | re.UNICODE)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(1) for m in _WORD_RE.finditer(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words


# ---------------------------------------------------------------- Punkt

_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_UC = 14
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_LC = 112

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTICHAR = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_TOK_RE = re.compile(
    r"""(%(MultiChar)s|(?=%(WordStart)s)\S+?(?=\s|$|%(NonWord)s|%(MultiChar)s|,(?=$|\s|%(NonWord)s|%(MultiChar)s))|\S)"""
    % {"MultiChar": _MULTICHAR, "WordStart": _WORD_START, "NonWord": _NONWORD}, re.UNICODE)
_PERIOD_CONTEXT_RE = re.compile(
    r"""[.?!](?=(?P<after_tok>%(NonWord)s|\s+(?P<next_tok>\S+)))""" % {"NonWord": _NONWORD}, re.UNICODE)
_REALIGN_RE = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)
_RE_NON_PUNCT = re.compile(r"[^\W\d]", re.UNICODE)
_WHITESPACE = " \t\n\r\x0b\x0c"


class _Token:
    __slots__ = ("tok", "type", "parastart", "linestart", "sentbreak", "abbr", "ellipsis",
                 "period_final", "type_no_period", "type_no_sentperiod_cache")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.period_final = tok.endswith(".")
        self.type_no_period = self.type[:-1] if len(self.type) > 1 and self.type[-1] == "." else self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def _load_punkt(language):
    # spec: N-000125 N-000382 N-000385
    d = data.find("tokenizers/punkt_tab/%s" % language)
    if not os.path.isdir(d):
        raise LookupError("Punkt model for %r not found" % (language,))
    params = PunktParameters()
    found = False
    f = os.path.join(d, "abbrev_types.txt")
    if os.path.isfile(f):
        found = True
        params.abbrev_types = {l for l in data.read_lines(f) if l}
    f = os.path.join(d, "sent_starters.txt")
    if os.path.isfile(f):
        found = True
        params.sent_starters = {l for l in data.read_lines(f) if l}
    f = os.path.join(d, "collocations.tab")
    if os.path.isfile(f):
        found = True
        for l in data.read_lines(f):
            parts = l.split("\t")
            if len(parts) >= 2:
                params.collocations.add((parts[0], parts[1]))
    f = os.path.join(d, "ortho_context.tab")
    if os.path.isfile(f):
        found = True
        for l in data.read_lines(f):
            parts = l.split("\t")
            if len(parts) >= 2:
                params.ortho_context[parts[0]] = int(parts[1])
    if not found:
        raise LookupError("Punkt model for %r is empty" % (language,))
    return params


class PunktSentenceTokenizer:
    def __init__(self, params=None, language="english"):
        self._params = params if params is not None else _load_punkt(language)

    # -- tokenisation
    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                toks = _WORD_TOK_RE.findall(line)
                if not toks:
                    continue
                yield _Token(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for tok in toks[1:]:
                    yield _Token(tok)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in ("?", "!", "."):
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            if t[:-1].lower() in self._params.abbrev_types or \
                    t[:-1].lower().split("-")[-1] in self._params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho_heuristic(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        ctx = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        is_initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not is_initial:
            h = self._ortho_heuristic(t2)
            if h is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if is_initial or typ == "##number##":
            h = self._ortho_heuristic(t2)
            if h is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            elif h == "unknown" and is_initial and t2.first_upper and \
                    not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC):
                t1.sentbreak = False
                t1.abbr = True

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for tok in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws_index(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in _WHITESPACE:
                return i
        return 0

    def _potential_end_contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _PERIOD_CONTEXT_RE.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = self._last_ws_index(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur_slice = (idx, match.start())
            if prev_match and prev_slice[1] <= cur_slice[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur_slice
        if prev_match:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last_break = 0
        for match, context in self._potential_end_contexts(text):
            if self._contains_sentbreak(context):
                yield (last_break, match.end())
                if match.group("next_tok"):
                    last_break = match.start("next_tok")
                else:
                    last_break = match.end()
        yield (last_break, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, (s1, e1) in enumerate(slices):
            s1 += realign
            if i + 1 >= len(slices):
                if text[s1:e1]:
                    yield (s1, e1)
                continue
            s2, e2 = slices[i + 1]
            m = _REALIGN_RE.match(text[s2:e2])
            if m:
                yield (s1, s2 + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1:e1]:
                    yield (s1, e1)

    def span_tokenize(self, text):
        yield from self._realign(text, self._slices(text))

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]


_punkt_cache = {}


def sent_tokenize(text, language="english"):
    # spec: N-000132 N-000396 (a missing model raises)
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    tok = PunktSentenceTokenizer(language=language)
    return tok.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    out = []
    for sent in sentences:
        out.extend(_improved.tokenize(sent))
    return out
