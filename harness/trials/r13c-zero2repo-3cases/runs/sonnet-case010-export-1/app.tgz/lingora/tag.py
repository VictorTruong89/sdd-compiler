"""Part-of-speech taggers. spec: N-000413 N-000414"""
import json
import os
import re
from collections import defaultdict

from . import data


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        self._taggers = [self] + (backoff._taggers if backoff is not None else [])
        self.backoff = backoff

    def tag(self, tokens):
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(r), t) for r, t in regexps]

    def choose_tag(self, tokens, index, history):
        for regexp, tag in self._regexps:
            if regexp.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = context_to_tag if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        return self._context_to_tag.get(self.context(tokens, index, history))

    def size(self):
        return len(self._context_to_tag)

    def _train(self, tagged_corpus, cutoff=0):
        counts = defaultdict(dict)
        useful = []
        useful_set = set()
        for sentence in tagged_corpus:
            tokens, tags = [w for w, _ in sentence], [t for _, t in sentence]
            for index, (token, tag) in enumerate(sentence):
                ctx = self.context(tokens, index, tags[:index])
                if ctx is None:
                    continue
                d = counts[ctx]
                d[tag] = d.get(tag, 0) + 1
                if self.backoff is None or tag != self.backoff.tag_one(tokens, index, tags[:index]):
                    if ctx not in useful_set:
                        useful_set.add(ctx)
                        useful.append(ctx)
        for ctx in useful:
            d = counts[ctx]
            best = None
            for t, c in d.items():
                if best is None or c > d[best]:
                    best = t
            if d[best] > cutoff:
                self._context_to_tag[ctx] = best


class NgramTagger(ContextTagger):
    def __init__(self, n, train=None, model=None, backoff=None, cutoff=0):
        self._n = n
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        if self._n == 1:
            return tokens[index]
        hist = tuple(history[-self._n + 1:])
        return hist + (tokens[index],)


class UnigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 1, train, model, backoff, cutoff)


class BigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 2, train, model, backoff, cutoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 3, train, model, backoff, cutoff)


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]


# ---- averaged perceptron tagger (textblob-aptagger) ----
START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = set(classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = START
        output = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_cache = {}


def _load_perceptron(lang):
    d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
    files = [base + ".weights.json", base + ".tagdict.json", base + ".classes.json"]
    key = tuple((f, os.stat(f).st_mtime_ns, os.stat(f).st_size) for f in files)
    if key in _cache:
        return _cache[key]
    loaded = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            loaded.append(json.load(fh))
    tagger = PerceptronTagger(*loaded)
    _cache.clear()
    _cache[key] = tagger
    return tagger


_RNC_TO_UNIVERSAL = {
    "A": "ADJ", "ADV": "ADV", "ADVPRO": "ADV", "ANUM": "ADJ", "APRO": "DET", "COM": "ADJ",
    "CONJ": "CONJ", "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PART": "PRT", "PR": "ADP",
    "S": "NOUN", "SPRO": "PRON", "V": "VERB",
}


def _load_ptb_map():
    d = data.find("taggers/universal_tagset")
    table = {}
    for line in data.read_lines(os.path.join(d, "en-ptb.map")):
        parts = line.split("\t")
        if len(parts) >= 2:
            table[parts[0]] = parts[1]
    return table


def pos_tag(tokens, tagset=None, lang="eng"):
    # spec: N-000420 N-000421 N-000422 N-000423
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, LINGORA pos_tag only supports English and Russian (i.e. lang='eng' or lang='rus')")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    tagger = _load_perceptron(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            table = _load_ptb_map()
            tagged = [(w, table.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _RNC_TO_UNIVERSAL.get(t.partition("=")[0], "X")) for w, t in tagged]
    return tagged
