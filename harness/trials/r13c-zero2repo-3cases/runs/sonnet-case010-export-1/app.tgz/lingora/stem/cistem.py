import re


class Cistem:
    """CISTEM German stemmer."""

    def __init__(self, case_insensitive=False):
        self._case_insensitive = case_insensitive

    def stem(self, word):
        if len(word) == 0:
            return word
        upper = word[0].isupper()
        word = word.lower()
        for a, b in (("ü", "u"), ("ö", "o"), ("ä", "a"), ("ß", "ss")):
            word = word.replace(a, b)
        word = re.sub(r"^ge(.{4,})", r"\1", word)
        word = word.replace("sch", "$").replace("ei", "%").replace("ie", "&")
        word = re.sub(r"(.)\1", r"\1*", word)
        while len(word) > 3:
            if len(word) > 5:
                word, n = re.subn(r"e[mr]$", "", word)
                if n:
                    continue
                word, n = re.subn(r"nd$", "", word)
                if n:
                    continue
            if not upper or self._case_insensitive:
                word, n = re.subn(r"t$", "", word)
                if n:
                    continue
            word, n = re.subn(r"[esn]$", "", word)
            if n:
                continue
            break
        word = re.sub(r"(.)\*", r"\1\1", word)
        return word.replace("%", "ei").replace("&", "ie").replace("$", "sch")
