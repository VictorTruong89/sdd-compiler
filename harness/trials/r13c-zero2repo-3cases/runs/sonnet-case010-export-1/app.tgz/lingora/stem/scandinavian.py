"""Snowball Swedish, Norwegian and Danish stemmers."""
from ._util import regions, longest


def _r1(w, vowels):
    r1, _ = regions(w, vowels)
    return min(max(r1, 3), len(w))


class SwedishStemmer:
    V = "aeiouyäåö"
    S_END = "bcdfghjklmnoprtvy"
    S1 = ("a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are", "aste", "en",
          "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as", "arnas", "ernas", "ornas",
          "es", "ades", "andes", "ens", "arens", "hetens", "erns", "at", "andet", "het", "ast")

    def stem(self, word):
        w = word.lower()
        r1 = _r1(w, self.V)
        s = longest(w, self.S1 + ("s",))
        if s and len(w) - len(s) >= r1:
            if s == "s":
                if w[-2:-1] and w[-2] in self.S_END:
                    w = w[:-1]
            else:
                w = w[:-len(s)]
        r1 = min(r1, len(w))
        if len(w) - 2 >= r1 and w.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")):
            w = w[:-1]
        s = longest(w, ("lig", "ig", "els", "löst", "fullt"))
        if s and len(w) - len(s) >= r1:
            if s in ("lig", "ig", "els"):
                w = w[:-len(s)]
            elif s == "löst":
                w = w[:-1]
            elif s == "fullt":
                w = w[:-1]
        return w


class NorwegianStemmer:
    V = "aeiouyæåø"
    S_END = "bcdfghjlmnoprtvyz"
    S1 = ("a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er", "heter", "as",
          "es", "edes", "endes", "enes", "hetenes", "ens", "hetens", "ers", "ets", "et", "het", "ast")

    def stem(self, word):
        w = word.lower()
        r1 = _r1(w, self.V)
        s = longest(w, self.S1 + ("s", "erte", "ert"))
        if s and len(w) - len(s) >= r1:
            if s == "s":
                if (w[-2:-1] and w[-2] in self.S_END) or (w[-2:-1] == "k" and w[-3:-2] and w[-3] not in self.V):
                    w = w[:-1]
            elif s in ("erte", "ert"):
                w = w[:-len(s)] + "er"
            else:
                w = w[:-len(s)]
        r1 = min(r1, len(w))
        if len(w) - 2 >= r1 and w.endswith(("dt", "vt")):
            w = w[:-1]
        s = longest(w, ("leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov", "elov", "slov", "hetslov"))
        if s and len(w) - len(s) >= r1:
            w = w[:-len(s)]
        return w


class DanishStemmer:
    V = "aeiouyæåø"
    S_END = "abcdfghjklmnoprtvyzå"
    S1 = ("hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en", "heden",
          "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes", "ernes", "eres", "ens",
          "hedens", "erens", "ers", "ets", "erets", "et", "eret")

    def _step2(self, w, r1):
        if len(w) - 2 >= r1 and w.endswith(("gd", "dt", "gt", "kt")):
            return w[:-1]
        return w

    def stem(self, word):
        w = word.lower()
        r1 = _r1(w, self.V)
        s = longest(w, self.S1 + ("s",))
        if s and len(w) - len(s) >= r1:
            if s == "s":
                if w[-2:-1] and w[-2] in self.S_END:
                    w = w[:-1]
            else:
                w = w[:-len(s)]
        r1 = min(r1, len(w))
        w = self._step2(w, r1)
        # step 3
        if w.endswith("igst") and len(w) - 4 >= r1:
            w = w[:-2]
        s = longest(w, ("ig", "lig", "elig", "els", "løst"))
        if s and len(w) - len(s) >= r1:
            if s == "løst":
                w = w[:-1]
            else:
                w = w[:-len(s)]
                w2 = self._step2(w, min(r1, len(w)))
                w = w2
        # step 4: undouble
        r1 = min(r1, len(w))
        if len(w) - 1 >= r1 and len(w) >= 2 and w[-1] == w[-2] and w[-1] not in self.V:
            w = w[:-1]
        return w
