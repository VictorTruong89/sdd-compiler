"""SnowballStemmer. spec: N-000167 N-000408"""
import os

from .. import data
from .arabic_snowball import ArabicStemmer
from .dutch import DutchStemmer
from .english import EnglishStemmer
from .finnish import FinnishStemmer
from .french import FrenchStemmer
from .german import GermanStemmer
from .hungarian import HungarianStemmer
from .italian import ItalianStemmer
from .porter import PorterStemmer as _Porter
from .portuguese import PortugueseStemmer
from .romanian import RomanianStemmer
from .russian import RussianStemmer
from .scandinavian import DanishStemmer, NorwegianStemmer, SwedishStemmer
from .spanish import SpanishStemmer


class _PorterStemmer:
    def __init__(self):
        self._p = _Porter()

    def stem(self, word):
        return self._p.stem(word)


class SnowballStemmer:
    languages = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                 "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish")

    _classes = {
        "arabic": ArabicStemmer, "danish": DanishStemmer, "dutch": DutchStemmer, "english": EnglishStemmer,
        "finnish": FinnishStemmer, "french": FrenchStemmer, "german": GermanStemmer,
        "hungarian": HungarianStemmer, "italian": ItalianStemmer, "norwegian": NorwegianStemmer,
        "porter": _PorterStemmer, "portuguese": PortugueseStemmer, "romanian": RomanianStemmer,
        "russian": RussianStemmer, "spanish": SpanishStemmer, "swedish": SwedishStemmer,
    }

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            # spec: N-000176 N-000177 N-000409 N-000410
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            # spec: N-000178 N-000179 N-000411 (a missing list makes construction fail)
            f = data.find("corpora/stopwords/%s" % language)
            self.stopwords = {l.strip() for l in data.read_lines(f) if l.strip()}
        self.stemmer = self._classes[language]()

    def stem(self, word):
        if self.language != "porter":
            word = word.lower()
        if self.stopwords and word.lower() in self.stopwords:
            return word.lower()
        return self.stemmer.stem(word)

    def __repr__(self):
        return "<SnowballStemmer(%s)>" % self.language
