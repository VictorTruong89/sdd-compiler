"""Shared helpers for the Snowball stemmers."""


def regions(word, vowels, start=0):
    """Standard R1/R2 start indices (R1: after first non-vowel following a vowel)."""
    n = len(word)
    r1 = n
    for i in range(max(start, 1), n):
        if word[i] not in vowels and word[i - 1] in vowels:
            r1 = i + 1
            break
    r2 = n
    for i in range(r1 + 1, n):
        if word[i] not in vowels and word[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def rv_spanish(word, vowels):
    """RV for Spanish, Italian, Portuguese."""
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
        return n
    return min(3, n)


def longest(word, suffixes, end=None):
    """Longest suffix of word[:end] taken from `suffixes`, or None."""
    w = word if end is None else word[:end]
    best = None
    for s in suffixes:
        if w.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best
