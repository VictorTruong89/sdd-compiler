import re


class RegexpStemmer:
    """Removes every match of the pattern from the word. spec: N-000173 N-000174 N-000175"""

    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            if not isinstance(regexp, str):
                raise TypeError("regexp must be a str")
            regexp = re.compile(regexp)
        self._regexp = regexp
        self.min = min

    def stem(self, word):
        if len(word) < self.min:
            return word
        return self._regexp.sub("", word)
