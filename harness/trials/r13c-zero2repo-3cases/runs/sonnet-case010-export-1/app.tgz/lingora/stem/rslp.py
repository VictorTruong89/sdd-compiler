"""RSLP Portuguese stemmer; needs packaged rules (results outside the specification)."""
import os

from .. import data


class RSLPStemmer:
    def __init__(self):
        self._dir = data.find("stemmers/rslp")
        self._steps = []
        for name in ("step0", "step1", "step2", "step3", "step4", "step5", "step6"):
            f = os.path.join(self._dir, name + ".pt")
            if not os.path.isfile(f):
                continue
            rules = []
            for line in data.read_lines(f):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    parts = line.split(",")
                    suffix = parts[0].strip().strip('"')
                    minstem = int(parts[1])
                    repl = parts[2].strip().strip('"')
                except (IndexError, ValueError):
                    continue
                rules.append((suffix, minstem, repl))
            self._steps.append(rules)

    def stem(self, word):
        word = word.lower()
        for rules in self._steps:
            for suffix, minstem, repl in rules:
                if word.endswith(suffix) and len(word) - len(suffix) >= minstem:
                    word = word[:len(word) - len(suffix)] + repl
                    break
        return word
