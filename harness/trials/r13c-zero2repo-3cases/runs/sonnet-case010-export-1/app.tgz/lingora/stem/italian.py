"""Snowball Italian stemmer."""
from ._util import regions, rv_spanish, longest

V = "aeiouàèìòù"
PRON = ("ci", "gli", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi", "sela", "selo", "gliela", "gliele",
        "glieli", "glielo", "gliene", "mela", "mele", "meli", "melo", "mene", "tela", "tele", "teli", "telo",
        "tene", "cela", "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo", "vene")
S1 = ("anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi", "abile", "abili", "ibile",
      "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso", "osi", "osa", "ose", "mente", "atrice",
      "atrici", "ante", "anti", "azione", "azioni", "atore", "atori", "logia", "logie", "uzione", "uzioni",
      "usione", "usioni", "enza", "enze", "amento", "amenti", "imento", "imenti", "amente", "ità", "ivo",
      "ivi", "iva", "ive")
S2 = ("ammo", "ando", "ano", "are", "arono", "asse", "assero", "assi", "assimo", "ata", "ate", "ati", "ato",
      "ante", "anti", "emmo", "enda", "ende", "endi", "endo", "erà", "erai", "eranno", "ere", "erebbe",
      "erebbero", "erei", "eremmo", "eremo", "ereste", "eresti", "erete", "erò", "erono", "essero", "ete",
      "eva", "evano", "evi", "evo", "Yamo", "iamo", "immo", "irà", "irai", "iranno", "ire", "irebbe",
      "irebbero", "irei", "iremmo", "iremo", "ireste", "iresti", "irete", "irò", "irono", "isca", "iscano",
      "isce", "isci", "isco", "iscono", "issero", "ita", "ite", "iti", "ito", "iva", "ivano", "ivi", "ivo",
      "ono", "uta", "ute", "uti", "uto", "ar", "ir")


class ItalianStemmer:
    def stem(self, word):
        w = word.lower()
        for a, b in (("á", "à"), ("é", "è"), ("í", "ì"), ("ó", "ò"), ("ú", "ù")):
            w = w.replace(a, b)
        c = list(w.replace("qu", "qU"))
        for i in range(1, len(c) - 1):
            if c[i] in "ui" and c[i - 1] in V and c[i + 1] in V:
                c[i] = c[i].upper()
        w = "".join(c)
        r1, r2 = regions(w, V + "")
        rv = rv_spanish(w, V)
        # step 0
        s = longest(w, PRON)
        if s and len(w) - len(s) >= rv:
            base = w[:-len(s)]
            if base.endswith(("ando", "endo")):
                w = base
            elif base.endswith(("ar", "er", "ir")):
                w = base + "e"
        n = len(w)
        r1, r2, rv = min(r1, n), min(r2, n), min(rv, n)
        # step 1
        done = False
        s = longest(w, S1)
        if s:
            pos = len(w) - len(s)
            base = w[:pos]
            if s in ("anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi", "abile",
                     "abili", "ibile", "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso",
                     "osi", "osa", "ose", "mente", "atrice", "atrici", "ante", "anti"):
                if pos >= r2:
                    w, done = base, True
            elif s in ("azione", "azioni", "atore", "atori"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logia", "logie"):
                if pos >= r2:
                    w, done = base + "log", True
            elif s in ("uzione", "uzioni", "usione", "usioni"):
                if pos >= r2:
                    w, done = base + "u", True
            elif s in ("enza", "enze"):
                if pos >= r2:
                    w, done = base + "ente", True
            elif s in ("amento", "amenti", "imento", "imenti"):
                if pos >= rv:
                    w, done = base, True
            elif s == "amente":
                if pos >= r1:
                    w, done = base, True
                    if w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
                    elif w.endswith(("os", "ic")) and len(w) - 2 >= r2:
                        w = w[:-2]
                    elif w.endswith("abil") and len(w) - 4 >= r2:
                        w = w[:-4]
            elif s == "ità":
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("abil") and len(w) - 4 >= r2:
                        w = w[:-4]
                    elif w.endswith(("ic", "iv")) and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("ivo", "ivi", "iva", "ive"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("ic") and len(w) - 2 >= r2:
                            w = w[:-2]
        if not done:
            s = longest(w, S2)
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
        # step 3a
        rv = min(rv, len(w))
        if w and w[-1] in "aeio" + "àèìò" and len(w) - 1 >= rv:
            w = w[:-1]
            if w.endswith("i") and len(w) - 1 >= rv:
                w = w[:-1]
        # step 3b
        if w.endswith(("ch", "gh")) and len(w) - 1 >= rv:
            w = w[:-1]
        return w.replace("I", "i").replace("U", "u")
