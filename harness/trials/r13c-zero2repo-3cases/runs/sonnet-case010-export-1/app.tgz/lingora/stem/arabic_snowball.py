"""Snowball Arabic stemmer (condensed)."""
import re

_DIAC = re.compile("[ً-ْـ]")
_PREFIX = ("وال", "بال", "كال", "فال", "ولل", "لل", "ال", "وب", "وك", "ول", "فب", "فل", "و", "ف", "ب", "ك", "ل", "س")
_SUFFIX = ("ويه", "كما", "تين", "تان", "ون", "ات", "ان", "ين", "نا", "ها", "هم", "هن", "كم", "وا", "ية", "ته",
           "تم", "ة", "ه", "ي", "ا", "ت", "ك", "ن")


class ArabicStemmer:
    def stem(self, word):
        w = _DIAC.sub("", word)
        for a in "أإآٱ":
            w = w.replace(a, "ا")
        w = w.replace("ى", "ي")
        for p in _PREFIX:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in _SUFFIX:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[:-len(s)]
                break
        return w
