"""WordNet lemmatizer; needs the packaged WordNet resource. spec: N-000180 N-000412"""
import os

from .. import data

_MORPHY = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv", "s": "adj"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = data.find("corpora/wordnet")
        if not os.path.isdir(self._dir):
            raise LookupError("WordNet is not installed")
        self._index = {}
        self._exc = {}

    def _load(self, pos):
        pos = "a" if pos == "s" else pos
        if pos in self._index:
            return
        names = set()
        idx = os.path.join(self._dir, "index." + _FILES[pos])
        if os.path.isfile(idx):
            for line in data.read_lines(idx):
                if line and not line.startswith(" "):
                    names.add(line.split(" ", 1)[0])
        exc = {}
        ef = os.path.join(self._dir, _FILES[pos] + ".exc")
        if os.path.isfile(ef):
            for line in data.read_lines(ef):
                parts = line.split()
                if len(parts) >= 2:
                    exc.setdefault(parts[0], []).extend(parts[1:])
        self._index[pos] = names
        self._exc[pos] = exc

    def _morphy(self, form, pos):
        pos = "a" if pos == "s" else pos
        self._load(pos)
        names, exc = self._index[pos], self._exc[pos]
        if form in exc:
            return [form] * (form in names) + exc[form]
        forms = [form]
        for old, new in _MORPHY[pos]:
            if form.endswith(old):
                forms.append(form[:len(form) - len(old)] + new)
        return [f for f in forms if f in names]

    def lemmatize(self, word, pos="n"):
        if pos not in _FILES:
            raise KeyError(pos)
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word
