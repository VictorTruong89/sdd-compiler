"""Snowball English (Porter2) stemmer."""
from ._util import longest

VOWELS = "aeiouy"
DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
LI_ENDING = "cdeghkmnrt"
SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
    "inning": "inning", "innings": "inning", "outing": "outing", "outings": "outing",
    "canning": "canning", "cannings": "canning", "herring": "herring", "herrings": "herring",
    "earring": "earring", "earrings": "earring", "proceed": "proceed", "proceeds": "proceed",
    "proceeded": "proceed", "proceeding": "proceed", "exceed": "exceed", "exceeds": "exceed",
    "exceeded": "exceed", "exceeding": "exceed", "succeed": "succeed", "succeeds": "succeed",
    "succeeded": "succeed", "succeeding": "succeed",
}
STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent", "izer": "ize",
    "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al",
    "alli": "al", "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive",
    "iviti": "ive", "biliti": "ble", "bli": "ble", "fulli": "ful", "lessli": "less",
}
STEP3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
         "ical": "ic", "ful": "", "ness": ""}
STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ism",
         "ate", "iti", "ous", "ive", "ize")


class EnglishStemmer:
    @staticmethod
    def _regions(w):
        n = len(w)
        if w.startswith(("gener", "arsen")):
            r1 = 5
        elif w.startswith("commun"):
            r1 = 6
        else:
            r1 = n
            for i in range(1, n):
                if w[i] not in VOWELS and w[i - 1] in VOWELS:
                    r1 = i + 1
                    break
        r2 = n
        for i in range(r1 + 1, n):
            if w[i] not in VOWELS and w[i - 1] in VOWELS:
                r2 = i + 1
                break
        return min(r1, n), min(r2, n)

    @staticmethod
    def _short_syllable(w):
        n = len(w)
        if n == 2:
            return w[0] in VOWELS and w[1] not in VOWELS
        if n >= 3:
            return w[-2] in VOWELS and w[-1] not in VOWELS and w[-1] not in "wxY" and w[-3] not in VOWELS
        return False

    def stem(self, word):
        word = word.lower().replace("’", "'").replace("‘", "'")
        if word in SPECIAL:
            return SPECIAL[word]
        if len(word) <= 2:
            return word
        if word.startswith("'"):
            word = word[1:]
        w = list(word)
        if w and w[0] == "y":
            w[0] = "Y"
        for i in range(1, len(w)):
            if w[i] == "y" and w[i - 1] in VOWELS:
                w[i] = "Y"
        w = "".join(w)
        r1, r2 = self._regions(w)
        # step 0
        s = longest(w, ("'s'", "'s", "'"))
        if s:
            w = w[:-len(s)]
        # step 1a
        s = longest(w, ("sses", "ied", "ies", "us", "ss", "s"))
        if s == "sses":
            w = w[:-2]
        elif s in ("ied", "ies"):
            w = w[:-2] if len(w) - 3 > 1 else w[:-1]
        elif s == "s":
            if any(c in VOWELS for c in w[:-2]):
                w = w[:-1]
        if w in ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"):
            return w
        r1, r2 = min(r1, len(w)), min(r2, len(w))
        # step 1b
        s = longest(w, ("eedly", "ingly", "edly", "eed", "ing", "ed"))
        if s in ("eed", "eedly"):
            if len(w) - len(s) >= r1:
                w = w[:-len(s)] + "ee"
        elif s:
            stem = w[:-len(s)]
            if any(c in VOWELS for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(DOUBLES):
                    w = w[:-1]
                elif r1 >= len(w) and self._short_syllable(w):
                    w += "e"
        r1, r2 = min(r1, len(w)), min(r2, len(w))
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in VOWELS:
            w = w[:-1] + "i"
        # step 2
        s = longest(w, tuple(STEP2) + ("ogi", "li"))
        if s and len(w) - len(s) >= r1:
            if s in STEP2:
                w = w[:-len(s)] + STEP2[s]
            elif s == "ogi" and w[-4:-3] == "l":
                w = w[:-1]
            elif s == "li" and w[-3:-2] and w[-3] in LI_ENDING:
                w = w[:-2]
        r1, r2 = min(r1, len(w)), min(r2, len(w))
        # step 3
        s = longest(w, tuple(STEP3) + ("ative",))
        if s and len(w) - len(s) >= r1:
            if s == "ative":
                if len(w) - len(s) >= r2:
                    w = w[:-5]
            else:
                w = w[:-len(s)] + STEP3[s]
        r1, r2 = min(r1, len(w)), min(r2, len(w))
        # step 4
        s = longest(w, STEP4 + ("ion",))
        if s and len(w) - len(s) >= r2:
            if s == "ion":
                if w[-4:-3] in ("s", "t"):
                    w = w[:-3]
            else:
                w = w[:-len(s)]
        r1, r2 = min(r1, len(w)), min(r2, len(w))
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2:
                w = w[:-1]
            elif len(w) - 1 >= r1 and not self._short_syllable(w[:-1]):
                w = w[:-1]
        elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
            w = w[:-1]
        return w.replace("Y", "y")
