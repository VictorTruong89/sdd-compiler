"""Snowball French stemmer."""
from ._util import longest

V = "aeiouyâàëéêèïîôûù"


def _is_v(w, i):
    return 0 <= i < len(w) and w[i] in V


class FrenchStemmer:
    def stem(self, word):
        w = word.lower()
        # prelude
        c = list(w)
        for i in range(len(c)):
            ch = c[i]
            if ch in "ui" and _is_v(c, i - 1) and _is_v(c, i + 1):
                c[i] = ch.upper()
            elif ch == "y" and (_is_v(c, i - 1) or _is_v(c, i + 1)):
                c[i] = "Y"
            elif ch == "u" and i > 0 and c[i - 1] == "q":
                c[i] = "U"
        w = "".join(c).replace("ë", "He").replace("ï", "Hi")
        n = len(w)
        # regions
        if n >= 2 and _is_v(w, 0) and _is_v(w, 1):
            rv = 3
        elif w[:3] in ("par", "col", "tap"):
            rv = 3
        else:
            rv = n
            for i in range(1, n):
                if _is_v(w, i):
                    rv = i + 1
                    break
        rv = min(rv, n)
        r1 = n
        for i in range(1, n):
            if not _is_v(w, i) and _is_v(w, i - 1):
                r1 = i + 1
                break
        r2 = n
        for i in range(r1 + 1, n):
            if not _is_v(w, i) and _is_v(w, i - 1):
                r2 = i + 1
                break

        def inr(word_, suffix, r):
            return len(word_) - len(suffix) >= r

        changed = False
        step2a_again = False
        # step 1
        new, ok, again = self._step1(w, rv, r1, r2)
        if ok:
            w = new
            changed = True
            step2a_again = again
        done = False
        if (not ok) or step2a_again:
            s = longest(w, ("îmes", "ît", "îtes", "ie", "ies", "ir", "ira", "irai", "iraIent", "irais",
                            "irait", "iras", "irent", "irez", "iriez", "irions", "irons", "iront", "is",
                            "issaIent", "issais", "issait", "issant", "issante", "issantes", "issants",
                            "isse", "issent", "isses", "issez", "issiez", "issions", "issons", "it", "i"))
            if s and len(w) - len(s) >= rv and len(w) > len(s) and not _is_v(w, len(w) - len(s) - 1):
                w = w[:-len(s)]
                changed = done = True
            if not done:
                s = longest(w, ("ions", "é", "ée", "ées", "és", "èrent", "er", "era", "erai", "eraIent",
                                "erais", "erait", "eras", "erez", "eriez", "erions", "erons", "eront",
                                "ez", "iez", "âmes", "ât", "âtes", "a", "ai", "aIent", "ais", "ait", "ant",
                                "ante", "antes", "ants", "as", "asse", "assent", "asses", "assiez", "assions"))
                if s and len(w) - len(s) >= (r2 if s == "ions" else rv):
                    w = w[:-len(s)]
                    changed = True
                    if s in ("âmes", "ât", "âtes", "a", "ai", "aIent", "ais", "ait", "ant", "ante", "antes",
                             "ants", "as", "asse", "assent", "asses", "assiez", "assions"):
                        if w.endswith("e") and len(w) - 1 >= rv:
                            w = w[:-1]
        if changed:
            if w.endswith("Y"):
                w = w[:-1] + "i"
            elif w.endswith("ç"):
                w = w[:-1] + "c"
        else:
            # residual suffix
            if w.endswith("s") and len(w) >= 2 and w[-2] not in V + "s" and w[-2] not in "aiouès":
                w = w[:-1]
            s = longest(w, ("ion", "ier", "ière", "Ier", "Ière", "e", "ë"))
            if s and len(w) - len(s) >= rv:
                if s == "ion":
                    if len(w) - 3 >= r2 and w[-4:-3] in ("s", "t"):
                        w = w[:-3]
                elif s in ("ier", "ière", "Ier", "Ière"):
                    w = w[:-len(s)] + "i"
                elif s == "e":
                    w = w[:-1]
            elif w.endswith("He") and False:
                pass
            if w.endswith("gu") is False and w.endswith("guë") is False:
                pass
        # undouble
        for e in ("eill", "enn", "onn", "ett", "ell"):
            if w.endswith(e):
                w = w[:-1]
                break
        # unaccent
        i = len(w)
        while i > 0 and not _is_v(w, i - 1):
            i -= 1
        if i < len(w) and i > 0 and w[i - 1] in "éè":
            w = w[:i - 1] + "e" + w[i:]
        return w.replace("I", "i").replace("U", "u").replace("Y", "y").replace("He", "ë").replace("Hi", "ï")

    def _step1(self, w, rv, r1, r2):
        """Return (word, removed?, needs-step-2a-again?)."""
        n = len(w)
        suf = ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes", "ables", "istes",
               "atrice", "ateur", "ation", "atrices", "ateurs", "ations", "logie", "logies", "usion",
               "ution", "usions", "utions", "ence", "ences", "ement", "ements", "ité", "ités", "if",
               "ive", "ifs", "ives", "eaux", "aux", "euse", "euses", "issement", "issements", "amment",
               "emment", "ment", "ments")
        s = longest(w, suf)
        if not s:
            return w, False, False
        base = w[:-len(s)]
        pos = n - len(s)  # start index of suffix

        def in_(p, r):
            return p >= r

        if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes", "ables", "istes"):
            if in_(pos, r2):
                return base, True, False
            return w, False, False
        if s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
            if not in_(pos, r2):
                return w, False, False
            if base.endswith("ic"):
                if in_(len(base) - 2, r2):
                    base = base[:-2]
                else:
                    base = base[:-2] + "iqU"
            return base, True, False
        if s in ("logie", "logies"):
            return (base + "log", True, False) if in_(pos, r2) else (w, False, False)
        if s in ("usion", "ution", "usions", "utions"):
            return (base + "u", True, False) if in_(pos, r2) else (w, False, False)
        if s in ("ence", "ences"):
            return (base + "ent", True, False) if in_(pos, r2) else (w, False, False)
        if s in ("ement", "ements"):
            if not in_(pos, rv):
                return w, False, False
            p = len(base)
            if base.endswith("iv") and in_(p - 2, r2):
                base = base[:-2]
                if base.endswith("at") and in_(len(base) - 2, r2):
                    base = base[:-2]
            elif base.endswith("eus"):
                if in_(p - 3, r2):
                    base = base[:-3]
                elif in_(p - 3, r1):
                    base = base[:-3] + "eux"
            elif base.endswith(("abl", "iqU")) and in_(p - 3, r2):
                base = base[:-3]
            elif base.endswith(("ièr", "Ièr")) and in_(p - 3, rv):
                base = base[:-3] + "i"
            return base, True, False
        if s in ("ité", "ités"):
            if not in_(pos, r2):
                return w, False, False
            p = len(base)
            if base.endswith("abil"):
                base = base[:-4] if in_(p - 4, r2) else base[:-4] + "abl"
            elif base.endswith("ic"):
                base = base[:-2] if in_(p - 2, r2) else base[:-2] + "iqU"
            elif base.endswith("iv") and in_(p - 2, r2):
                base = base[:-2]
            return base, True, False
        if s in ("if", "ive", "ifs", "ives"):
            if not in_(pos, r2):
                return w, False, False
            p = len(base)
            if base.endswith("at") and in_(p - 2, r2):
                base = base[:-2]
                p -= 2
                if base.endswith("ic"):
                    base = base[:-2] if in_(p - 2, r2) else base[:-2] + "iqU"
            return base, True, False
        if s == "eaux":
            return base + "eau", True, False
        if s == "aux":
            return (base + "al", True, False) if in_(pos, r1) else (w, False, False)
        if s in ("euse", "euses"):
            if in_(pos, r2):
                return base, True, False
            if in_(pos, r1):
                return base + "eux", True, False
            return w, False, False
        if s in ("issement", "issements"):
            if in_(pos, r1) and base and base[-1] not in V:
                return base, True, False
            return w, False, False
        if s == "amment":
            return (base + "ant", True, True) if in_(pos, rv) else (w, False, False)
        if s == "emment":
            return (base + "ent", True, True) if in_(pos, rv) else (w, False, False)
        if s in ("ment", "ments"):
            if in_(pos - 1, rv) and base and base[-1] in V:
                return base, True, True
            return w, False, False
        return w, False, False
