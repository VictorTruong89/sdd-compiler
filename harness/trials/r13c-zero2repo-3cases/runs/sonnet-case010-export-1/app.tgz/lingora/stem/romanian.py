"""Snowball Romanian stemmer (condensed)."""
from ._util import regions, longest

V = "aăâeiîou"
COMBINING = (
    ("abilitate", "abilitati", "abilități", "abilităţi", "abilitǎţi", "abilitǎți"), "abil",
    ("ibilitate", "ibilități", "ibilităţi"), "ibil",
    ("ivitate", "ivitati", "ivități", "ivităţi"), "iv",
    ("icitate", "icitati", "icități", "icităţi", "icator", "icatori", "iciv", "iciva", "icive", "icivi",
     "icivă", "ical", "icala", "icale", "icali", "icală"), "ic",
    ("ativ", "ativa", "ative", "ativi", "ativă", "ațiune", "atoare", "ator", "atori", "ătoare", "ător",
     "ători"), "at",
    ("itiv", "itiva", "itive", "itivi", "itivă", "ițiune", "itoare", "itor", "itori"), "it",
)
STD = ("at", "ata", "ată", "ati", "ate", "ut", "uta", "ută", "uti", "ute", "it", "ita", "ită", "iti", "ite",
       "ic", "ica", "ice", "ici", "ică", "abil", "abila", "abile", "abili", "abilă", "ibil", "ibila", "ibile",
       "ibili", "ibilă", "oasa", "oasă", "oase", "os", "osi", "oși", "ant", "anta", "ante", "anti", "antă",
       "ator", "atori", "itate", "itati", "ități", "itor", "itori", "iv", "iva", "ive", "ivi", "ivă")
IST = ("ism", "isme", "ist", "ista", "iste", "isti", "istă", "iști")
VERB = ("are", "ere", "ire", "âre", "ind", "ând", "indu", "ându", "eze", "ezi", "ează", "esc", "ești",
        "ește", "ăsc", "ăști", "ăște", "am", "ai", "au", "eam", "eai", "ea", "eați", "eau", "iam", "iai",
        "ia", "iați", "iau", "ui", "ași", "arăm", "arăți", "ară", "uși", "urăm", "urăți", "ură", "irăm",
        "irăți", "iră", "âi", "âși", "ârăm", "ârăți", "âră", "asem", "aseși", "ase", "aserăm", "aserăți",
        "aseră", "isem", "iseși", "ise", "iserăm", "iserăți", "iseră", "âsem", "âseși", "âse", "âserăm",
        "âserăți", "âseră", "usem", "useși", "use", "userăm", "userăți", "useră", "ăm", "ați", "em", "eți",
        "im", "iți", "âm", "âți", "seși", "serăm", "serăți", "seră", "sei", "se", "sesem", "sesei")


class RomanianStemmer:
    def stem(self, word):
        w = word.lower().replace("ş", "ș").replace("ţ", "ț")
        c = list(w)
        for i in range(1, len(c) - 1):
            if c[i] in "ui" and c[i - 1] in V and c[i + 1] in V:
                c[i] = c[i].upper()
        w = "".join(c)
        n = len(w)
        r1, r2 = regions(w, V)
        # RV
        rv = n
        if n >= 2:
            if w[1] not in V:
                for i in range(2, n):
                    if w[i] in V:
                        rv = i + 1
                        break
            elif w[0] in V and w[1] in V:
                for i in range(2, n):
                    if w[i] not in V:
                        rv = i + 1
                        break
            else:
                rv = min(3, n)
        # step 0
        s = longest(w, ("ul", "ului", "aua", "ea", "ele", "elor", "ii", "iua", "iei", "iile", "iilor", "ilor",
                        "ile", "atei", "ație", "ația"))
        if s:
            pos = len(w) - len(s)
            if s in ("ul", "ului"):
                if pos >= r1:
                    w = w[:pos]
            elif s == "aua":
                w = w[:pos] + "a"
            elif s in ("ea", "ele", "elor"):
                w = w[:pos] + "e"
            elif s in ("ii", "iua", "iei", "iile", "iilor", "ilor"):
                w = w[:pos] + "i"
            elif s == "ile":
                if not w[:pos].endswith("ab"):
                    w = w[:pos] + "i"
            elif s == "atei":
                w = w[:pos] + "at"
            else:
                w = w[:pos] + "ați"
        # step 1
        step1 = False
        changed = True
        while changed:
            changed = False
            for k in range(0, len(COMBINING), 2):
                sufs, rep = COMBINING[k], COMBINING[k + 1]
                s = longest(w, sufs)
                if s and len(w) - len(s) >= r1:
                    w = w[:-len(s)] + rep
                    changed = step1 = True
                    break
        # step 2
        step2 = False
        s = longest(w, STD + IST + ("iune", "iuni", "ațiune"))
        if s and len(w) - len(s) >= r2:
            base = w[:-len(s)]
            if s in IST:
                w = base + "ist"
                step2 = True
            elif s in ("iune", "iuni"):
                if base.endswith("ț"):
                    w = base[:-1] + "t"
                    step2 = True
            else:
                w = base
                step2 = True
        # step 3
        if not step1 and not step2:
            s = longest(w, VERB)
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
        # step 4
        rv = min(rv, len(w))
        s = longest(w, ("ie", "a", "e", "i", "ă"))
        if s and len(w) - len(s) >= rv:
            w = w[:-len(s)]
        return w.replace("I", "i").replace("U", "u")
