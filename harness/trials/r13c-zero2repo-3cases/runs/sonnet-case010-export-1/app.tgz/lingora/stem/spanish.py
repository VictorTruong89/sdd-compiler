"""Snowball Spanish stemmer."""
from ._util import regions, rv_spanish, longest

V = "aeiouáéíóúü"
PRON = ("me", "se", "sela", "selo", "selas", "selos", "la", "le", "lo", "las", "les", "los", "nos")
PRE = ("iéndo", "ándo", "ár", "ér", "ír", "ando", "iendo", "ar", "er", "ir", "yendo")
ACC = {"iéndo": "iendo", "ándo": "ando", "ár": "ar", "ér": "er", "ír": "ir"}
S1_R2 = ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible", "ibles",
         "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos", "imiento", "imientos")
S1_IC = ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias")
S2A = ("ya", "ye", "yan", "yen", "yeron", "yendo", "yo", "yó", "yas", "yes", "yamos")
S2B_A = ("en", "es", "éis", "emos")
S2B_B = ("arían", "arías", "arán", "arás", "aríais", "aría", "aréis", "aríamos", "aremos", "ará", "aré",
         "erían", "erías", "erán", "erás", "eríais", "ería", "eréis", "eríamos", "eremos", "erá", "eré",
         "irían", "irías", "irán", "irás", "iríais", "iría", "iréis", "iríamos", "iremos", "irá", "iré",
         "aba", "ada", "ida", "ía", "ara", "iera", "ad", "ed", "id", "ase", "iese", "aste", "iste", "an",
         "aban", "ían", "aran", "ieran", "asen", "iesen", "aron", "ieron", "ado", "ido", "ando", "iendo",
         "ió", "ar", "er", "ir", "as", "abas", "adas", "idas", "ías", "aras", "ieras", "ases", "ieses",
         "ís", "áis", "abais", "íais", "arais", "ierais", "aseis", "ieseis", "asteis", "isteis", "ados",
         "idos", "amos", "ábamos", "íamos", "imos", "áramos", "iéramos", "iésemos", "ásemos")
ALL = (S1_R2 + S1_IC + ("logía", "logías", "ución", "uciones", "encia", "encias", "amente", "mente",
                         "idad", "idades", "iva", "ivo", "ivos", "ivas"))


class SpanishStemmer:
    def stem(self, word):
        w = word.lower()
        r1, r2 = regions(w, V)
        rv = rv_spanish(w, V)
        # step 0
        s = longest(w, PRON)
        if s and len(w) - len(s) >= rv:
            base = w[:-len(s)]
            p = longest(base, PRE)
            if p and len(base) - len(p) >= rv:
                if p in ACC:
                    w = base[:-len(p)] + ACC[p]
                elif p == "yendo":
                    if base[:-5].endswith("u"):
                        w = base
                else:
                    w = base
        n = len(w)
        r1, r2, rv = min(r1, n), min(r2, n), min(rv, n)
        # step 1
        done = False
        s = longest(w, ALL)
        if s:
            pos = len(w) - len(s)
            base = w[:pos]
            if s in S1_R2:
                if pos >= r2:
                    w, done = base, True
            elif s in S1_IC:
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logía", "logías"):
                if pos >= r2:
                    w, done = base + "log", True
            elif s in ("ución", "uciones"):
                if pos >= r2:
                    w, done = base + "u", True
            elif s in ("encia", "encias"):
                if pos >= r2:
                    w, done = base + "ente", True
            elif s == "amente":
                if pos >= r1:
                    w, done = base, True
                    if w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
                    elif w.endswith(("os", "ic", "ad")) and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s == "mente":
                if pos >= r2:
                    w, done = base, True
                    t = longest(w, ("ante", "able", "ible"))
                    if t and len(w) - 4 >= r2:
                        w = w[:-4]
            elif s in ("idad", "idades"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("abil") and len(w) - 4 >= r2:
                        w = w[:-4]
                    elif w.endswith(("ic", "iv")) and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("iva", "ivo", "ivos", "ivas"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        if not done:
            s = longest(w, S2A)
            if s and len(w) - len(s) >= rv and w[:-len(s)].endswith("u"):
                w, done = w[:-len(s)], True
            elif s:
                pass
            if not done:
                cand = [x for x in S2B_A + S2B_B if w.endswith(x)]
                s = max(cand, key=len) if cand else None
                # y-verb suffix failure falls through to verb suffixes
                if s and len(w) - len(s) >= rv:
                    base = w[:-len(s)]
                    if s in S2B_A:
                        w = base
                        if w.endswith("gu") and len(w) - 1 >= rv:
                            w = w[:-1]
                    else:
                        w = base
        # residual
        rv = min(rv, len(w))
        s = longest(w, ("os", "a", "o", "á", "í", "ó", "e", "é"))
        if s and len(w) - len(s) >= rv:
            if s in ("e", "é"):
                w = w[:-1]
                if w.endswith("gu") and len(w) - 1 >= rv:
                    w = w[:-1]
            else:
                w = w[:-len(s)]
        return w.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
