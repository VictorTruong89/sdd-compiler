"""Snowball Dutch stemmer (original Dutch algorithm)."""
from ._util import regions, longest

V = "aeiouyè"


def _undouble(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


class DutchStemmer:
    def stem(self, word):
        w = word.lower()
        for a, b in (("ä", "a"), ("ë", "e"), ("ï", "i"), ("ö", "o"), ("ü", "u"),
                     ("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
            w = w.replace(a, b)
        c = list(w)
        if c and c[0] == "y":
            c[0] = "Y"
        for i in range(1, len(c)):
            if c[i] == "y" and c[i - 1] in V:
                c[i] = "Y"
        for i in range(1, len(c) - 1):
            if c[i] == "i" and c[i - 1] in V and c[i + 1] in V:
                c[i] = "I"
        w = "".join(c)
        r1, r2 = regions(w, V)
        r1 = min(max(r1, 3), len(w))
        r2 = max(r2, r1)

        def en_ending(x):
            if len(x) - 3 >= r1 and x[-4:-3] and x[-4] not in V and not x[:-3].endswith("gem"):
                return _undouble(x[:-3]), True
            return x, False

        # step 1
        s = longest(w, ("heden", "ene", "en", "se", "s"))
        if s == "heden":
            if len(w) - 5 >= r1:
                w = w[:-5] + "heid"
        elif s == "ene":
            if len(w) - 3 >= r1 and w[-4:-3] and w[-4] not in V and not w[:-3].endswith("gem"):
                w = _undouble(w[:-3])
        elif s == "en":
            if len(w) - 2 >= r1 and w[-3:-2] and w[-3] not in V and not w[:-2].endswith("gem"):
                w = _undouble(w[:-2])
        elif s == "se":
            if len(w) - 2 >= r1 and w[-3:-2] and w[-3] not in V + "j":
                w = w[:-2]
        elif s == "s":
            if len(w) - 1 >= r1 and w[-2:-1] and w[-2] not in V + "j":
                w = w[:-1]
        # step 2
        e_found = False
        if w.endswith("e") and len(w) - 1 >= r1 and w[-2:-1] and w[-2] not in V:
            w = _undouble(w[:-1])
            e_found = True
        # step 3a
        if w.endswith("heid") and len(w) - 4 >= r2 and w[-5:-4] != "c":
            w = w[:-4]
            if w.endswith("en") and len(w) - 2 >= r1 and w[-3:-2] and w[-3] not in V and not w[:-2].endswith("gem"):
                w = _undouble(w[:-2])
        # step 3b
        s = longest(w, ("end", "ing", "ig", "lijk", "baar", "bar"))
        if s in ("end", "ing"):
            if len(w) - 3 >= r2:
                w = w[:-3]
                if w.endswith("ig") and len(w) - 2 >= r2 and w[-3:-2] != "e":
                    w = w[:-2]
                else:
                    w = _undouble(w)
        elif s == "ig":
            if len(w) - 2 >= r2 and w[-3:-2] != "e":
                w = w[:-2]
        elif s == "lijk":
            if len(w) - 4 >= r2:
                w = w[:-4]
                if w.endswith("e") and len(w) - 1 >= r1 and w[-2:-1] and w[-2] not in V:
                    w = _undouble(w[:-1])
        elif s == "baar":
            if len(w) - 4 >= r2:
                w = w[:-4]
        elif s == "bar":
            if len(w) - 3 >= r2 and e_found:
                w = w[:-3]
        # step 4
        if len(w) >= 4 and w[-1] not in V + "I" and w[-2] in "aeou" and w[-3] == w[-2] and w[-4] not in V:
            w = w[:-2] + w[-1]
        return w.replace("Y", "y").replace("I", "i")
