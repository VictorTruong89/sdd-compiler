"""Light Arabic stemmers (results outside the specification)."""
import re

_DIACRITICS = re.compile("[ً-ْـ]")
_PREFIXES = ["وال", "بال", "كال", "فال", "لل", "ال", "و", "ف", "ب", "ك", "ل"]
_SUFFIXES = ["ات", "ان", "ون", "ين", "ها", "هم", "ية", "ة", "ه", "ي", "ا"]


class ARLSTem:
    def _normalize(self, word):
        word = _DIACRITICS.sub("", word)
        for a in "أإآ":
            word = word.replace(a, "ا")
        return word

    def stem(self, word):
        word = self._normalize(word)
        for p in _PREFIXES:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in _SUFFIXES:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[:-len(s)]
                break
        return word


class ARLSTem2(ARLSTem):
    def stem(self, word):
        word = ARLSTem.stem(self, word)
        if word.startswith("م") and len(word) >= 5:
            word = word[1:]
        return word


class ISRIStemmer(ARLSTem):
    pass
