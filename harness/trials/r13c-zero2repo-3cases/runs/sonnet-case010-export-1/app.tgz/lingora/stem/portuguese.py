"""Snowball Portuguese stemmer."""
from ._util import regions, rv_spanish, longest

V = "aeiouáéíóúâêô"
S1_R2 = ("eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista", "istas", "oso",
         "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "adora", "ador", "ação", "adoras",
         "adores", "ações", "ante", "antes", "ância")
S2 = ("ada", "ida", "ia", "aria", "eria", "iria", "ará", "ara", "erá", "era", "irá", "ava", "asse", "esse",
      "isse", "aste", "este", "iste", "ei", "arei", "erei", "irei", "am", "iam", "ariam", "eriam", "iriam",
      "aram", "eram", "iram", "avam", "em", "arem", "erem", "irem", "assem", "essem", "issem", "ado", "ido",
      "ando", "endo", "indo", "ara~o", "era~o", "ira~o", "ar", "er", "ir", "as", "adas", "idas", "ias",
      "arias", "erias", "irias", "arás", "eras", "irás", "avas", "es", "ardes", "erdes", "irdes", "ares",
      "eres", "ires", "asses", "esses", "isses", "astes", "estes", "istes", "is", "ais", "eis", "íeis",
      "aríeis", "eríeis", "iríeis", "áreis", "areis", "éreis", "ereis", "íreis", "ireis", "ásseis",
      "ésseis", "ísseis", "áveis", "ados", "idos", "ámos", "amos", "íamos", "aríamos", "eríamos",
      "iríamos", "áramos", "éramos", "íramos", "ávamos", "emos", "aremos", "eremos", "iremos", "ássemos",
      "êssemos", "íssemos", "imos", "armos", "ermos", "irmos", "eu", "iu", "ou", "ira", "iras")
S1_OTHER = ("logia", "logias", "ução", "uções", "ência", "ências", "amente", "mente", "idade", "idades",
            "iva", "ivo", "ivas", "ivos")


class PortugueseStemmer:
    def stem(self, word):
        w = word.lower().replace("ã", "a~").replace("õ", "o~")
        r1, r2 = regions(w, V)
        rv = rv_spanish(w, V)
        n = len(w)
        r1, r2, rv = min(r1, n), min(r2, n), min(rv, n)
        done = False
        s = longest(w, S1_R2 + S1_OTHER)
        if s:
            pos = len(w) - len(s)
            base = w[:pos]
            if s in S1_R2:
                if pos >= r2:
                    w, done = base, True
                    if s in ("adora", "ador", "ação", "adoras", "adores", "ações", "ante", "antes", "ância") \
                            and w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logia", "logias"):
                if pos >= r2:
                    w, done = base + "log", True
            elif s in ("ução", "uções"):
                if pos >= r2:
                    w, done = base + "u", True
            elif s in ("ência", "ências"):
                if pos >= r2:
                    w, done = base + "ente", True
            elif s == "amente":
                if pos >= r1:
                    w, done = base, True
                    if w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
                    elif w.endswith(("os", "ic", "ad")) and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s == "mente":
                if pos >= r2:
                    w, done = base, True
                    for t in ("ante", "avel", "ível"):
                        if w.endswith(t) and len(w) - 4 >= r2:
                            w = w[:-4]
                            break
            elif s in ("idade", "idades"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("abil") and len(w) - 4 >= r2:
                        w = w[:-4]
                    elif w.endswith(("ic", "iv")) and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("iva", "ivo", "ivas", "ivos"):
                if pos >= r2:
                    w, done = base, True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        if not done:
            s = longest(w, S2)
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
                done = True
        rv = min(rv, len(w))
        if done:
            if w.endswith("ci") and len(w) - 1 >= rv:
                w = w[:-1]
        else:
            s = longest(w, ("os", "a", "i", "o", "á", "í", "ó"))
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
        rv = min(rv, len(w))
        s = longest(w, ("e", "é", "ê"))
        if s and len(w) - 1 >= rv:
            w = w[:-1]
            if w.endswith(("gu", "ci")) and len(w) - 1 >= rv:
                w = w[:-1]
        elif w.endswith("ç"):
            w = w[:-1] + "c"
        return w.replace("a~", "ã").replace("o~", "õ")
