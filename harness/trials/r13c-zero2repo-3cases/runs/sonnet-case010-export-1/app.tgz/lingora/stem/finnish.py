"""Snowball Finnish stemmer (condensed)."""
from ._util import regions, longest

V = "aeiouyäö"
CONS_NOT = "aeiouyäö"


class FinnishStemmer:
    def stem(self, word):
        w = word.lower()
        r1, r2 = regions(w, V)
        # step 1: particles
        s = longest(w, ("kin", "kaan", "kään", "ko", "kö", "han", "hän", "pa", "pä", "sti"))
        if s and len(w) - len(s) >= r1:
            if s == "sti":
                if len(w) - 3 >= r2:
                    w = w[:-3]
            elif w[-len(s) - 1:-len(s)] in ("n", "t"):
                w = w[:-len(s)]
        # step 2: possessives
        s = longest(w, ("si", "ni", "nsa", "nsä", "mme", "nne", "an", "än", "en"))
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s == "si":
                if not base.endswith("k"):
                    w = base
            elif s == "ni":
                w = base[:-3] + "ksi" if base.endswith("kse") else base
            elif s in ("nsa", "nsä", "mme", "nne"):
                w = base
            elif s == "an" and base.endswith(("ta", "ssa", "sta", "lla", "lta", "na")):
                w = base
            elif s == "än" and base.endswith(("tä", "ssä", "stä", "llä", "ltä", "nä")):
                w = base
            elif s == "en" and base.endswith(("lle", "ine")):
                w = base
        # step 3: cases
        s = longest(w, ("hAn", "siin", "den", "tten", "seen", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta",
                        "ltä", "lle", "ina", "inä", "ksi", "ta", "tä", "na", "nä", "a", "ä", "n", "han", "hän",
                        "hon", "hön", "hen", "hin", "hun", "hyn"))
        step3 = False
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s in ("han", "hän", "hon", "hön", "hen", "hin", "hun", "hyn"):
                if base and base[-1] == s[1]:
                    w, step3 = base, True
            elif s in ("siin", "den", "tten"):
                if base.endswith("i"):
                    w, step3 = base, True
            elif s == "seen":
                if base and base[-1] in V and len(base) >= 2 and base[-2] == base[-1]:
                    w, step3 = base, True
            elif s in ("a", "ä"):
                if len(base) >= 2 and base[-1] not in V and base[-2] in V:
                    w, step3 = base, True
            elif s == "n":
                w, step3 = base, True
                if w.endswith(("ie", "uo", "yö")) is False and len(w) >= 2 and w[-1] == w[-2] and w[-1] in V:
                    w = w[:-1]
            elif s in ("ta", "tä"):
                if base and base[-1] in "ln rs".replace(" ", "") + "":
                    w, step3 = base, True
            elif s != "hAn":
                w, step3 = base, True
        # step 4: other endings
        s = longest(w, ("mpi", "mpa", "mpä", "mmi", "mma", "mmä", "impi", "impa", "impä", "immi", "imma",
                        "immä", "eja", "ejä"))
        if s and len(w) - len(s) >= r2 and not (w[-len(s) - 2:-len(s)] == "po" and s.startswith("m")):
            w = w[:-len(s)]
        # step 5: plurals
        if step3:
            r1 = min(r1, len(w))
            if w.endswith("i") and len(w) - 1 >= r1:
                w = w[:-1]
            elif w.endswith("j") and len(w) - 1 >= r1:
                w = w[:-1]
        else:
            if w.endswith("t") and len(w) - 1 >= r1:
                w = w[:-1]
                if w.endswith("poi") and len(w) - 3 >= r2:
                    w = w[:-3]
        # step 6: tidying
        r1 = min(r1, len(w))
        if len(w) >= 2 and len(w) - 1 >= r1 and w[-1] in "aäei" and w[-2] in "aäe" and False:
            pass
        if len(w) >= 2 and len(w) - 1 >= r1 and w[-1] == w[-2] and w[-1] in V:
            w = w[:-1]
        if len(w) >= 2 and len(w) - 1 >= r1 and w[-1] in "aäei" and len(w) >= 2 and w[-2] in "aäe" and w[-2] != w[-1] and False:
            w = w[:-1]
        if len(w) >= 2 and w[-1] in "aäei" and w[-2] not in V and len(w) - 1 >= r1:
            w = w[:-1]
        if w.endswith("oj") and len(w) - 2 >= r1 or w.endswith("uj") and len(w) - 2 >= r1:
            w = w[:-1]
        if len(w) >= 2 and len(w) - 1 >= r1 and w[-1] == w[-2] and w[-1] not in V:
            w = w[:-1]
        return w
