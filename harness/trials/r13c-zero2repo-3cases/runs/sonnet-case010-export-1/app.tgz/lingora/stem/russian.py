"""Snowball Russian stemmer."""
import re

V = "аеиоуыэюя"
PERF1 = ("вшись", "вши", "в")
PERF2 = ("ившись", "ивши", "ив", "ывшись", "ывши", "ыв")
REFL = ("ся", "сь")
ADJ = ("ее", "ие", "ые", "ое", "ими", "ыми", "ей", "ий", "ый", "ой", "ем", "им", "ым", "ом", "его", "ого",
       "ему", "ому", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
PART1 = ("ем", "нн", "вш", "ющ", "щ")
PART2 = ("ивш", "ывш", "ующ")
VERB1 = ("ла", "на", "ете", "йте", "ли", "й", "л", "ем", "н", "ло", "но", "ет", "ют", "ны", "ть", "ешь", "нно")
VERB2 = ("ила", "ыла", "ена", "ейте", "уйте", "ите", "или", "ыли", "ей", "уй", "ил", "ыл", "им", "ым", "ен",
         "ило", "ыло", "ено", "ят", "ует", "уют", "ит", "ыт", "ены", "ить", "ыть", "ишь", "ую", "ю")
NOUN = ("а", "ев", "ов", "ие", "ье", "е", "иями", "ями", "ами", "еи", "ии", "и", "ией", "ей", "ой", "ий", "й",
        "иям", "ям", "ием", "ем", "ам", "ом", "о", "у", "ах", "иях", "ях", "ы", "ь", "ию", "ью", "ю", "ия",
        "ья", "я")
SUPER = ("ейше", "ейш")
DERIV = ("ость", "ост")


def _longest(w, sufs, rv):
    best = None
    for s in sufs:
        if w.endswith(s) and len(w) - len(s) >= rv and (best is None or len(s) > len(best)):
            best = s
    return best


def _longest_a(w, sufs, rv):
    """Suffix preceded by а or я (the preceding letter lies in RV or not)."""
    best = None
    for s in sufs:
        if w.endswith(s) and len(w) - len(s) - 1 >= rv and w[len(w) - len(s) - 1] in "ая" \
                and (best is None or len(s) > len(best)):
            best = s
    return best


class RussianStemmer:
    def stem(self, word):
        w = word.lower().replace("ё", "е")
        rv = len(w)
        for i, ch in enumerate(w):
            if ch in V:
                rv = i + 1
                break
        r1 = len(w)
        for i in range(1, len(w)):
            if w[i] not in V and w[i - 1] in V:
                r1 = i + 1
                break
        r2 = len(w)
        for i in range(r1 + 1, len(w)):
            if w[i] not in V and w[i - 1] in V:
                r2 = i + 1
                break
        # step 1
        def perfective(x):
            s = _longest_a(x, PERF1, rv)
            s2 = _longest(x, PERF2, rv)
            if s2 and (not s or len(s2) >= len(s)):
                return x[:-len(s2)]
            if s:
                return x[:-len(s)]
            return None

        def adjectival(x):
            s = _longest(x, ADJ, rv)
            if not s:
                return None
            base = x[:-len(s)]
            p2 = _longest(base, PART2, rv)
            if p2:
                return base[:-len(p2)]
            p1 = _longest_a(base, PART1, rv)
            if p1:
                return base[:-len(p1)]
            return base

        r = perfective(w)
        if r is not None:
            w = r
        else:
            s = _longest(w, REFL, rv)
            if s:
                w = w[:-len(s)]
            r = adjectival(w)
            if r is not None:
                w = r
            else:
                s2 = _longest(w, VERB2, rv)
                s1 = _longest_a(w, VERB1, rv)
                if s2 and (not s1 or len(s2) >= len(s1)):
                    w = w[:-len(s2)]
                elif s1:
                    w = w[:-len(s1)]
                else:
                    s = _longest(w, NOUN, rv)
                    if s:
                        w = w[:-len(s)]
        # step 2
        if w.endswith("и") and len(w) - 1 >= rv:
            w = w[:-1]
        # step 3
        s = _longest(w, DERIV, r2)
        if s:
            w = w[:-len(s)]
        # step 4
        s = _longest(w, SUPER, rv)
        if s:
            w = w[:-len(s)]
            if w.endswith("нн"):
                w = w[:-1]
        elif w.endswith("нн") and len(w) - 2 >= rv:
            w = w[:-1]
        elif w.endswith("ь") and len(w) - 1 >= rv:
            w = w[:-1]
        return w
