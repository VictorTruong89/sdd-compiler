"""Snowball German stemmer."""
from ._util import regions, longest

VOWELS = "aeiouyäöü"
S_END = "bdfghklmnrt"
ST_END = "bdfghklmnt"


class GermanStemmer:
    def stem(self, word):
        word = word.lower().replace("ß", "ss")
        w = list(word)
        for i in range(1, len(w) - 1):
            if word[i - 1] in VOWELS and word[i + 1] in VOWELS:
                if w[i] == "u":
                    w[i] = "U"
                elif w[i] == "y":
                    w[i] = "Y"
        w = "".join(w)
        r1, r2 = regions(w, VOWELS)
        r1 = max(r1, 3) if len(w) >= 3 else len(w)
        r1 = min(r1, len(w))
        r2 = max(r2, r1)
        # step 1
        s = longest(w, ("em", "ern", "er", "e", "en", "es", "s"))
        if s and s != "s" and len(w) - len(s) >= r1:
            w = w[:-len(s)]
            if s in ("e", "en", "es") and w.endswith("niss"):
                w = w[:-1]
        elif s == "s" and len(w) - 1 >= r1 and w[-2:-1] and w[-2] in S_END:
            w = w[:-1]
        # step 2
        s = longest(w, ("en", "er", "est", "st"))
        if s in ("en", "er", "est") and len(w) - len(s) >= r1:
            w = w[:-len(s)]
        elif s == "st" and len(w) - 2 >= r1 and len(w) - 2 >= 4 and w[-3] in ST_END:
            w = w[:-2]
        # step 3
        r2 = min(r2, len(w))
        s = longest(w, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
        if s and len(w) - len(s) >= r2:
            if s in ("end", "ung"):
                w = w[:-len(s)]
                if w.endswith("ig") and len(w) - 2 >= r2 and w[-3:-2] != "e":
                    w = w[:-2]
            elif s in ("ig", "ik", "isch"):
                if w[-len(s) - 1:-len(s)] != "e":
                    w = w[:-len(s)]
            elif s in ("lich", "heit"):
                w = w[:-len(s)]
                t = longest(w, ("er", "en"))
                if t and len(w) - len(t) >= r1:
                    w = w[:-len(t)]
            elif s == "keit":
                w = w[:-4]
                t = longest(w, ("lich", "ig"))
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
        return w.replace("ä", "a").replace("ö", "o").replace("ü", "u").replace("U", "u").replace("Y", "y")
