"""Snowball Hungarian stemmer (condensed)."""
V = "aáeéiíoóöőuúüű"

_CASES = ("kként", "képpen", "képp", "ban", "ben", "ba", "be", "ra", "re", "nak", "nek", "val", "vel", "tól",
          "től", "ról", "ről", "ból", "ből", "hoz", "hez", "höz", "nál", "nél", "ig", "ért", "át", "ét",
          "ként", "on", "en", "ön", "ott", "ett", "ött", "ul", "ül", "ban", "ben")
_PLURAL = ("ak", "ek", "ok", "ök", "k")
_POSS = ("unk", "ünk", "nk", "juk", "jük", "uk", "ük", "m", "d", "ja", "je", "a", "e")


class HungarianStemmer:
    def stem(self, word):
        w = word.lower()
        n = len(w)
        r1 = n
        if n and w[0] in V:
            for i in range(1, n):
                if w[i] not in V:
                    r1 = i + 1
                    break
        else:
            for i in range(1, n):
                if w[i] in V:
                    r1 = i + 1
                    break
        r1 = min(max(r1, 0), n)
        r1 = max(r1, 1) if n > 1 else n

        def strip(x, sufs):
            best = None
            for s in sufs:
                if x.endswith(s) and len(x) - len(s) >= r1 and (best is None or len(s) > len(best)):
                    best = s
            return x[:-len(best)] if best else x

        w = strip(w, ("stul", "estül", "stül", "astul", "estul"))
        w = strip(w, _CASES)
        w = strip(w, _POSS)
        w = strip(w, _PLURAL)
        if len(w) - 1 >= r1 and w[-1] in "áé":
            w = w[:-1] + {"á": "a", "é": "e"}[w[-1]]
        return w
