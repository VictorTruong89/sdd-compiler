"""Command line: `cli.main(args=['tokenize'], standalone_mode=True)`. spec: N-000397"""
import io
import sys

from .tokenize import word_tokenize


class UsageError(Exception):
    pass


def _tokenize_command(argv):
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    i = 0
    while i < len(argv):
        a = argv[i]
        opt, eq, val = a.partition("=")
        if opt in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if not eq:
                i += 1
                if i >= len(argv):
                    raise UsageError("option %s requires an argument" % opt)
                val = argv[i]
            if opt in ("-l", "--language"):
                language = val
            elif opt in ("-d", "--delimiter"):
                delimiter = val
            else:
                encoding = val
        else:
            raise UsageError("unexpected argument %r" % a)
        i += 1
    stdin = sys.stdin
    if hasattr(stdin, "buffer"):
        stream = io.TextIOWrapper(stdin.buffer, encoding=encoding, newline="")
    else:
        stream = stdin
    # spec: N-000401 failures write no token line for the failed input
    for line in stream:
        line = line.rstrip("\r\n") if not line.endswith("\n") else line[:-1]
        if line.endswith("\r"):
            line = line[:-1]
        sys.stdout.write(delimiter.join(word_tokenize(line, language=language)) + "\n")  # spec: N-000399
    sys.stdout.flush()
    if stream is not stdin:
        stream.detach()
    return 0


class Group:
    def __init__(self):
        self.commands = {"tokenize": _tokenize_command}

    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            if not args or args[0] not in self.commands:
                raise UsageError("expected a command: %s" % ", ".join(self.commands))
            self.commands[args[0]](args[1:])
        except SystemExit:
            raise
        except BaseException as e:  # spec: N-000400
            if not standalone_mode:
                raise
            if isinstance(e, KeyboardInterrupt):
                sys.exit(130)
            sys.stderr.write("Error: %s\n" % (e,))
            sys.exit(2 if isinstance(e, UsageError) else 1)
        if standalone_mode:
            sys.exit(0)
        return 0

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)


cli = Group()

if __name__ == "__main__":
    cli.main()
