"""lingora: a pure-Python natural-language processing library. Importing downloads nothing."""
from . import data

__all__ = ["data"]
