"""Evaluation metrics. spec: N-000478 N-000479"""
from collections.abc import Set


def accuracy(reference, test):
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy requires two lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")  # spec: N-000482
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance requires two strings")
    n, m = len(s1), len(s2)
    lev = [[0] * (m + 2) for _ in range(n + 2)]
    # lev[i+1][j+1] holds the distance of prefixes s1[:i], s2[:j]
    for i in range(n + 1):
        lev[i + 1][1] = i
    for j in range(m + 1):
        lev[1][j + 1] = j
    da = {}
    for i in range(1, n + 1):
        last_col = 0
        for j in range(1, m + 1):
            c1, c2 = s1[i - 1], s2[j - 1]
            k = da.get(c2, 0)
            l = last_col
            if c1 == c2:
                cost = 0
                last_col = j
            else:
                cost = substitution_cost
            best = min(lev[i][j + 1] + 1, lev[i + 1][j] + 1, lev[i][j] + cost)
            if transpositions and k > 0 and l > 0:
                best = min(best, lev[k][l] + (i - k - 1) + (j - l - 1) + 1)
            lev[i + 1][j + 1] = best
        da[s1[i - 1]] = i
    return lev[n + 1][m + 1]


def jaccard_distance(label1, label2):
    union = len(label1.union(label2))
    return (union - len(label1.intersection(label2))) / union


def _check_sets(reference, test):
    for x in (reference, test):
        if not isinstance(x, Set):  # spec: N-000488
            raise TypeError("reference and test must be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None  # spec: N-000489
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
