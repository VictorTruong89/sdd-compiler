# Specification coverage

Every id in `spec/CHECKLIST.md` is listed below. Status values:

Counts: implemented 482, partial 8, not done 4 (494 ids).
- **implemented**: a `# spec:` marker in the code cites the id (see the file list), or the id is covered by the behaviour of its pack (no per-id marker).
- **partial** / **not done**: the reason is given.

| id | pack | kind | status | where / reason |
|---|---|---|---|---|
| N-000335 | 02 | constraint | implemented | pack 02 behaviour (no per-id marker) |
| N-000336 | 02 | requirement | implemented | pack 02 behaviour (no per-id marker) |
| N-000337 | 02 | requirement | implemented | pack 02 behaviour (no per-id marker) |
| N-000338 | 02 | constraint | implemented | pack 02 behaviour (no per-id marker) |
| N-000339 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000340 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000341 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000342 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000343 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000344 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000345 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000346 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000347 | 03 | constraint | implemented | pack 03 behaviour (no per-id marker) |
| N-000348 | 03 | constraint | implemented | pack 03 behaviour (no per-id marker) |
| N-000349 | 03 | constraint | implemented | pack 03 behaviour (no per-id marker) |
| N-000350 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000351 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000352 | 03 | requirement | implemented | pack 03 behaviour (no per-id marker) |
| N-000353 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000354 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000355 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000356 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000357 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000358 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000359 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000360 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000361 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000362 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000363 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000364 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000365 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000366 | 05 | requirement | implemented | pack 05 behaviour (no per-id marker) |
| N-000367 | 05 | constraint | implemented | pack 05 behaviour (no per-id marker) |
| N-000368 | 06 | requirement | implemented | lingora/data.py |
| N-000369 | 06 | requirement | implemented | lingora/data.py |
| N-000370 | 06 | constraint | implemented | lingora/data.py |
| N-000371 | 06 | constraint | implemented | lingora/data.py |
| N-000372 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000373 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000374 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000375 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000376 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000377 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000378 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000379 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000380 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000381 | 06 | requirement | implemented | lingora/data.py |
| N-000382 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000383 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000384 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000385 | 06 | requirement | implemented | pack 06 behaviour (no per-id marker) |
| N-000386 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000387 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000388 | 07 | constraint | implemented | pack 07 behaviour (no per-id marker) |
| N-000389 | 07 | constraint | implemented | pack 07 behaviour (no per-id marker) |
| N-000390 | 07 | constraint | implemented | pack 07 behaviour (no per-id marker) |
| N-000391 | 07 | constraint | implemented | pack 07 behaviour (no per-id marker) |
| N-000392 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000393 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000394 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000395 | 07 | requirement | implemented | pack 07 behaviour (no per-id marker) |
| N-000396 | 07 | requirement | implemented | tests/test_tokenize.py |
| N-000397 | 08 | requirement | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000398 | 08 | requirement | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000399 | 08 | requirement | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000400 | 08 | requirement | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000401 | 08 | requirement | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000402 | 08 | decision | implemented | lingora/cli.py |
| N-000403 | 08 | decision | implemented | lingora/cli.py, tests/test_grammar_classify_metrics_cli.py |
| N-000404 | 09 | requirement | implemented | lingora/stem.py |
| N-000405 | 09 | requirement | implemented | pack 09 behaviour (no per-id marker) |
| N-000406 | 09 | requirement | implemented | pack 09 behaviour (no per-id marker) |
| N-000407 | 09 | requirement | implemented | pack 09 behaviour (no per-id marker) |
| N-000408 | 09 | requirement | implemented | lingora/stem.py |
| N-000409 | 09 | requirement | implemented | tests/test_stem.py |
| N-000410 | 09 | requirement | implemented | tests/test_stem.py |
| N-000411 | 09 | requirement | implemented | tests/test_stem.py |
| N-000412 | 09 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000413 | 10 | requirement | implemented | lingora/tag.py |
| N-000414 | 10 | requirement | implemented | lingora/tag.py |
| N-000415 | 10 | requirement | implemented | lingora/tag.py |
| N-000416 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000417 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000418 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000419 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000420 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000421 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000422 | 10 | requirement | implemented | lingora/tag.py |
| N-000423 | 10 | requirement | implemented | pack 10 behaviour (no per-id marker) |
| N-000424 | 10 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000425 | 10 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000426 | 11 | requirement | implemented | lingora/chunk.py |
| N-000427 | 11 | requirement | implemented | lingora/chunk.py |
| N-000428 | 11 | requirement | implemented | lingora/chunk.py |
| N-000429 | 11 | requirement | implemented | lingora/chunk.py |
| N-000430 | 11 | decision | implemented | pack 11 behaviour (no per-id marker) |
| N-000431 | 11 | requirement | implemented | lingora/chunk.py |
| N-000432 | 11 | requirement | implemented | lingora/chunk.py, tests/test_tag_chunk_tree.py |
| N-000433 | 11 | constraint | implemented | lingora/chunk.py |
| N-000434 | 11 | constraint | implemented | lingora/chunk.py |
| N-000435 | 11 | requirement | implemented | lingora/chunk.py |
| N-000436 | 11 | requirement | implemented | lingora/chunk.py |
| N-000437 | 11 | decision | implemented | pack 11 behaviour (no per-id marker) |
| N-000438 | 11 | requirement | implemented | lingora/chunk.py |
| N-000439 | 11 | requirement | implemented | lingora/chunk.py |
| N-000440 | 11 | requirement | implemented | lingora/chunk.py |
| N-000441 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000442 | 12 | requirement | implemented | pack 12 behaviour (no per-id marker) |
| N-000443 | 12 | requirement | implemented | pack 12 behaviour (no per-id marker) |
| N-000444 | 12 | constraint | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000445 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000446 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000447 | 12 | requirement | implemented | lingora/grammar.py |
| N-000448 | 12 | decision | implemented | lingora/grammar.py |
| N-000449 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000450 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000451 | 12 | requirement | implemented | lingora/grammar.py, tests/test_grammar_classify_metrics_cli.py |
| N-000452 | 12 | constraint | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000453 | 12 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000454 | 12 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000455 | 12 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000456 | 12 | requirement | implemented | lingora/parse/__init__.py |
| N-000457 | 12 | constraint | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000458 | 12 | constraint | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000459 | 12 | constraint | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000460 | 12 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000461 | 13 | requirement | implemented | pack 13 behaviour (no per-id marker) |
| N-000462 | 13 | requirement | implemented | pack 13 behaviour (no per-id marker) |
| N-000463 | 13 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000464 | 13 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000465 | 13 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000466 | 13 | constraint | implemented | pack 13 behaviour (no per-id marker) |
| N-000467 | 13 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000468 | 13 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000469 | 13 | constraint | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000470 | 13 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000471 | 13 | decision | implemented | lingora/tree.py |
| N-000472 | 14 | requirement | implemented | pack 14 behaviour (no per-id marker) |
| N-000473 | 14 | requirement | implemented | pack 14 behaviour (no per-id marker) |
| N-000474 | 14 | constraint | implemented | pack 14 behaviour (no per-id marker) |
| N-000475 | 14 | constraint | implemented | pack 14 behaviour (no per-id marker) |
| N-000476 | 14 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000477 | 14 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000478 | 15 | requirement | implemented | lingora/translate.py |
| N-000479 | 15 | requirement | implemented | pack 15 behaviour (no per-id marker) |
| N-000480 | 15 | requirement | implemented | pack 15 behaviour (no per-id marker) |
| N-000481 | 15 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000482 | 15 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000483 | 15 | requirement | implemented | lingora/metrics.py |
| N-000484 | 15 | requirement | implemented | lingora/metrics.py |
| N-000485 | 15 | requirement | implemented | lingora/metrics.py |
| N-000486 | 15 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000487 | 15 | requirement | implemented | lingora/metrics.py |
| N-000488 | 15 | requirement | implemented | lingora/metrics.py |
| N-000489 | 15 | requirement | implemented | lingora/metrics.py |
| N-000490 | 15 | requirement | implemented | lingora/translate.py |
| N-000491 | 15 | requirement | implemented | lingora/translate.py |
| N-000492 | 15 | requirement | implemented | lingora/translate.py |
| N-000493 | 15 | requirement | implemented | lingora/translate.py |
| N-000494 | 15 | decision | implemented | lingora/translate.py |
| N-000001 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000002 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000003 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000004 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000005 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000006 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000007 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000008 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000009 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000010 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000011 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000012 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000013 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000014 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000015 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000016 | 16 | decision | implemented | pack 16 behaviour (no per-id marker) |
| N-000017 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000018 | 16 | constraint | implemented | pack 16 behaviour (no per-id marker) |
| N-000019 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000020 | 16 | requirement | implemented | pack 16 behaviour (no per-id marker) |
| N-000021 | 17 | requirement | implemented | pack 17 behaviour (no per-id marker) |
| N-000022 | 17 | constraint | implemented | pack 17 behaviour (no per-id marker) |
| N-000023 | 17 | requirement | implemented | pack 17 behaviour (no per-id marker) |
| N-000024 | 17 | requirement | implemented | pack 17 behaviour (no per-id marker) |
| N-000025 | 17 | requirement | implemented | pack 17 behaviour (no per-id marker) |
| N-000026 | 17 | requirement | implemented | pack 17 behaviour (no per-id marker) |
| N-000027 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000028 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000029 | 18 | constraint | implemented | pack 18 behaviour (no per-id marker) |
| N-000030 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000031 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000032 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000033 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000034 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000035 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000036 | 18 | requirement | partial | named-entity chunker: results outside this specification; ne_chunk checks its resources, then raises NotImplementedError |
| N-000037 | 18 | constraint | implemented | pack 18 behaviour (no per-id marker) |
| N-000038 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000039 | 18 | requirement | not done | recursive-descent parser not implemented (results outside this specification) |
| N-000040 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000041 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000042 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000043 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000044 | 18 | requirement | implemented | pack 18 behaviour (no per-id marker) |
| N-000045 | 18 | constraint | implemented | pack 18 behaviour (no per-id marker) |
| N-000046 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000047 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000048 | 19 | requirement | implemented | pack 19 behaviour (no per-id marker) |
| N-000049 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000050 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000051 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000052 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000053 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000054 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000055 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000056 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000057 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000058 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000059 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000060 | 19 | requirement | implemented | pack 19 behaviour (no per-id marker) |
| N-000061 | 19 | requirement | implemented | pack 19 behaviour (no per-id marker) |
| N-000062 | 19 | requirement | implemented | pack 19 behaviour (no per-id marker) |
| N-000063 | 19 | constraint | implemented | pack 19 behaviour (no per-id marker) |
| N-000064 | 19 | requirement | implemented | pack 19 behaviour (no per-id marker) |
| N-000065 | 19 | assumption | implemented | pack 19 behaviour (no per-id marker) |
| N-000066 | 20 | requirement | implemented | pack 20 behaviour (no per-id marker) |
| N-000067 | 20 | requirement | implemented | pack 20 behaviour (no per-id marker) |
| N-000068 | 20 | requirement | implemented | pack 20 behaviour (no per-id marker) |
| N-000069 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000070 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000071 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000072 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000073 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000074 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000075 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000076 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000077 | 21 | constraint | implemented | pack 21 behaviour (no per-id marker) |
| N-000078 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000079 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000080 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000081 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000082 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000083 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000084 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000085 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000086 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000087 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000088 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000089 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000090 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000091 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000092 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000093 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000094 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000095 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000096 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000097 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000098 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000099 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000100 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000101 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000102 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000103 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000104 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000105 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000106 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000107 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000108 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000109 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000110 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000111 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000112 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000113 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000114 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000115 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000116 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000117 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000118 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000119 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000120 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000121 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000122 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000123 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000124 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000125 | 22 | requirement | implemented | lingora/tokenize.py |
| N-000126 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000127 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000128 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000129 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000130 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000131 | 22 | requirement | implemented | lingora/tokenize.py, tests/test_tokenize.py |
| N-000132 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000133 | 22 | requirement | implemented | tests/test_tokenize.py |
| N-000134 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py, tests/test_tokenize.py |
| N-000135 | 22 | requirement | partial | ISRI, Cistem and RSLP not implemented (results outside this specification); ARLSTem and ARLSTem2 raise NotImplementedError |
| N-000136 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000137 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000138 | 22 | requirement | partial | ISRI, Cistem and RSLP not implemented (results outside this specification) |
| N-000139 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000140 | 22 | requirement | not done | RSLP not implemented (results outside this specification) |
| N-000141 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000142 | 22 | requirement | partial | Snowball implemented for english and porter only; other listed languages raise NotImplementedError at construction |
| N-000143 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000144 | 22 | requirement | partial | partial: Porter modes accepted; MARTIN_EXTENSIONS behaves as the original algorithm (its results are outside this specification) |
| N-000145 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000146 | 22 | constraint | implemented | lingora/stem.py |
| N-000147 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000148 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000149 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000150 | 22 | requirement | implemented | lingora/stem.py |
| N-000151 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000152 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000153 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000154 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000155 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000156 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000157 | 22 | requirement | implemented | lingora/stem.py |
| N-000158 | 22 | requirement | implemented | lingora/stem.py |
| N-000159 | 22 | requirement | implemented | lingora/stem.py |
| N-000160 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000161 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000162 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000163 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000164 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000165 | 22 | requirement | partial | partial: Lancaster rule table reconstructed from memory, not checked against Paice's published table |
| N-000166 | 22 | requirement | partial | partial: Lancaster rule table reconstructed from memory, not checked against Paice's published table |
| N-000167 | 22 | requirement | partial | Snowball implemented for english and porter only |
| N-000168 | 22 | requirement | not done | Dutch Snowball algorithm not implemented |
| N-000169 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000170 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000171 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000172 | 22 | requirement | implemented | lingora/stem.py |
| N-000173 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000174 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000175 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000176 | 22 | requirement | implemented | tests/test_stem.py |
| N-000177 | 22 | requirement | implemented | tests/test_stem.py |
| N-000178 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000179 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000180 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000181 | 22 | requirement | implemented | lingora/stem.py, tests/test_stem.py |
| N-000182 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000183 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000184 | 22 | requirement | not done | bigram, trigram and affix taggers not implemented (results outside this specification) |
| N-000185 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000186 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000187 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000188 | 22 | requirement | implemented | universal mapping implemented for English (needs tables) and Russian (category table is the implementer's choice) |
| N-000189 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000190 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000191 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000192 | 22 | requirement | implemented | lingora/tag.py |
| N-000193 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000194 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000195 | 22 | decision | implemented | lingora/tag.py |
| N-000196 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000197 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000198 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000199 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000200 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000201 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000202 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000203 | 22 | requirement | implemented | lingora/tag.py |
| N-000204 | 22 | requirement | implemented | lingora/tag.py |
| N-000205 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000206 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000207 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000208 | 22 | requirement | implemented | lingora/tag.py |
| N-000209 | 22 | requirement | implemented | lingora/tag.py |
| N-000210 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000211 | 22 | requirement | implemented | lingora/tag.py |
| N-000212 | 22 | requirement | implemented | lingora/tag.py |
| N-000213 | 22 | decision | implemented | lingora/tag.py |
| N-000214 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000215 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000216 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000217 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000218 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000219 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000220 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000221 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000222 | 22 | requirement | implemented | lingora/tag.py, tests/test_tag_chunk_tree.py |
| N-000223 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000224 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000225 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000226 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000227 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000228 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000229 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000230 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000231 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000232 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000233 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000234 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000235 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000236 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000237 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000238 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000239 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000240 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000241 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000242 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000243 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000244 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000245 | 22 | constraint | implemented | tests/test_tag_chunk_tree.py |
| N-000246 | 22 | requirement | implemented | tests/test_tag_chunk_tree.py |
| N-000247 | 22 | requirement | implemented | lingora/chunk.py, tests/test_tag_chunk_tree.py |
| N-000248 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000249 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000250 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000251 | 22 | requirement | implemented | lingora/grammar.py |
| N-000252 | 22 | requirement | implemented | lingora/grammar.py |
| N-000253 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000254 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000255 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000256 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000257 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000258 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000259 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000260 | 22 | requirement | implemented | lingora/parse/__init__.py |
| N-000261 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000262 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000263 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000264 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000265 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000266 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000267 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000268 | 22 | requirement | implemented | lingora/tree.py |
| N-000269 | 22 | requirement | implemented | lingora/tree.py |
| N-000270 | 22 | requirement | implemented | lingora/tree.py |
| N-000271 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000272 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000273 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000274 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000275 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000276 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000277 | 22 | requirement | implemented | lingora/tree.py, tests/test_tag_chunk_tree.py |
| N-000278 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000279 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000280 | 22 | requirement | implemented | lingora/parse/__init__.py, tests/test_grammar_classify_metrics_cli.py |
| N-000281 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000282 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000283 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000284 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000285 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000286 | 22 | constraint | implemented | pack 22 behaviour (no per-id marker) |
| N-000287 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000288 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000289 | 22 | requirement | implemented | lingora/classify.py |
| N-000290 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000291 | 22 | requirement | implemented | lingora/classify.py |
| N-000292 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000293 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000294 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000295 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000296 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000297 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000298 | 22 | requirement | implemented | lingora/classify.py |
| N-000299 | 22 | requirement | implemented | lingora/classify.py |
| N-000300 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000301 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000302 | 22 | requirement | implemented | lingora/classify.py |
| N-000303 | 22 | requirement | implemented | lingora/classify.py |
| N-000304 | 22 | requirement | implemented | lingora/classify.py, tests/test_grammar_classify_metrics_cli.py |
| N-000305 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000306 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000307 | 22 | requirement | implemented | pack 22 behaviour (no per-id marker) |
| N-000308 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000309 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000310 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000311 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000312 | 22 | requirement | implemented | lingora/metrics.py |
| N-000313 | 22 | requirement | implemented | lingora/metrics.py |
| N-000314 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000315 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000316 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000317 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000318 | 22 | requirement | implemented | lingora/translate.py, tests/test_grammar_classify_metrics_cli.py |
| N-000319 | 22 | requirement | implemented | lingora/translate.py |
| N-000320 | 22 | requirement | implemented | lingora/translate.py, tests/test_grammar_classify_metrics_cli.py |
| N-000321 | 22 | requirement | implemented | lingora/translate.py |
| N-000322 | 22 | requirement | implemented | lingora/translate.py, tests/test_grammar_classify_metrics_cli.py |
| N-000323 | 22 | requirement | implemented | lingora/translate.py, tests/test_grammar_classify_metrics_cli.py |
| N-000324 | 22 | requirement | implemented | lingora/translate.py, tests/test_grammar_classify_metrics_cli.py |
| N-000325 | 22 | requirement | implemented | lingora/translate.py |
| N-000326 | 22 | requirement | implemented | tests/test_grammar_classify_metrics_cli.py |
| N-000327 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000328 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000329 | 22 | requirement | implemented | lingora/metrics.py, tests/test_grammar_classify_metrics_cli.py |
| N-000330 | 22 | requirement | implemented | lingora/metrics.py |
| N-000331 | 23 | constraint | implemented | pack 23 behaviour (no per-id marker) |
| N-000332 | 23 | constraint | implemented | pack 23 behaviour (no per-id marker) |
| N-000333 | 23 | constraint | implemented | pack 23 behaviour (no per-id marker) |
| N-000334 | 23 | constraint | implemented | pack 23 behaviour (no per-id marker) |
