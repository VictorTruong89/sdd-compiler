import io
import sys

import pytest

from lingora import metrics
from lingora.cli import cli, main
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import bleu

GRAMMAR = """
S -> NP VP
NP -> DT N | 'john'
VP -> V NP | VP PP
PP -> P NP
DT -> 'the' | 'a'
N -> 'man' | 'park'
V -> 'saw'
P -> 'in'
"""


# spec: N-000441 N-000444 N-000445 N-000446 N-000449 N-000450 N-000451
def test_N_000444_grammar_reader_productions():
    grammar = CFG.fromstring(GRAMMAR)
    assert str(grammar.start()) == "S"
    assert len(grammar.productions()) == 12
    vp_first = grammar.productions("VP")[0]
    assert [str(s) for s in vp_first.rhs()] == ["V", "NP"]
    assert grammar.productions("V")[0].rhs() == ("saw",)


# spec: N-000453 N-000454 N-000455 N-000278 N-000279 N-000280
def test_N_000453_chart_parser_all_trees_and_errors():
    grammar = CFG.fromstring(GRAMMAR)
    tokens = "john saw the man in the park".split()
    trees = list(ChartParser(grammar).parse(tokens))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == tokens
    assert list(ChartParser(grammar).parse("john the".split())) == []
    with pytest.raises(ValueError):
        ChartParser(grammar).parse(["zebra"])


# spec: N-000259 N-000261 N-000262
def test_N_000259_shift_reduce_matches_chart_on_unambiguous_sentence():
    grammar = CFG.fromstring("S -> NP VP\nNP -> 'john'\nVP -> 'runs'")
    tokens = ["john", "runs"]
    chart = list(ChartParser(grammar).parse(tokens))
    shift = list(ShiftReduceParser(grammar).parse(tokens))
    assert chart == shift and len(shift) == 1


# spec: N-000263 N-000265 N-000266 N-000267 N-000457 N-000458 N-000459 N-000460
def test_N_000263_generate_respects_bounds():
    grammar = CFG.fromstring('S -> "a" S | "b"')
    sentences = list(generate(grammar, depth=3, n=5))
    assert sentences == [["a", "a", "b"], ["a", "b"], ["b"]]
    assert list(generate(grammar, depth=1)) == [["b"]]
    assert list(generate(CFG.fromstring('S -> "a" | "b" "c"'))) == [["a"], ["b", "c"]]


# spec: N-000452
def test_N_000452_generator_handles_empty_terminal():
    grammar = CFG.fromstring('S -> "" "x"')
    assert list(generate(grammar)) == [["", "x"]]


# spec: N-000288 N-000290 N-000292 N-000293 N-000294 N-000295 N-000476 N-000477
def test_N_000288_naive_bayes():
    train = [({"w": "free", "x": 1}, "spam"), ({"w": "meeting", "x": 0}, "ham"),
             ({"w": "free", "x": 0}, "spam"), ({"w": "lunch", "x": 0}, "ham")]
    classifier = NaiveBayesClassifier.train(train)
    assert classifier.classify({"w": "free"}) == "spam"
    assert classifier.classify({"never": 1}) in {"spam", "ham"}
    assert classifier.labels() == ["spam", "ham"]
    dist = classifier.prob_classify({"w": "free"})
    assert abs(sum(dist.prob(label) for label in dist.samples()) - 1) < 1e-9
    assert isinstance(dist.prob("spam"), float)


# spec: N-000296 N-000297 N-000300 N-000301
def test_N_000296_decision_tree():
    train = [({"w": "free"}, "spam"), ({"w": "meeting"}, "ham"),
             ({"w": "free", "x": 1}, "spam"), ({"w": "lunch"}, "ham")]
    tree = DecisionTreeClassifier.train(train)
    assert [tree.classify(f) for f, _ in train] == ["spam", "ham", "spam", "ham"]
    assert tree.classify({"unknown": 1}) in {"spam", "ham"}


# spec: N-000304 N-000326
def test_N_000304_accuracy_helper():
    train = [({"w": "a"}, "x"), ({"w": "b"}, "y")]
    classifier = NaiveBayesClassifier.train(train)
    assert accuracy(classifier, train) == 1.0


# spec: N-000308 N-000309 N-000310 N-000311 N-000314 N-000315
def test_N_000308_edit_distance():
    assert metrics.edit_distance("rain", "shine") == 3
    assert metrics.edit_distance("ab", "ba") == 2
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("", "") == 0
    assert metrics.edit_distance("kitten", "sitting") == metrics.edit_distance("sitting", "kitten")
    assert metrics.edit_distance("a", "b", substitution_cost=2) == 2


# spec: N-000316 N-000317 N-000327 N-000328 N-000329
def test_N_000316_precision_recall_f_measure():
    assert metrics.precision({1, 2}, {2, 3}) == 0.5
    assert metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.f_measure({1, 2}, {2, 3}) == 0.5
    assert metrics.precision({1}, set()) is None
    assert metrics.recall(set(), {1}) is None
    assert metrics.f_measure({1}, set()) is None
    assert metrics.f_measure({1}, {2}) == 0.0
    with pytest.raises(TypeError):
        metrics.precision([1], {1})


# spec: N-000486 N-000481 N-000482
def test_N_000486_jaccard_and_accuracy():
    assert metrics.jaccard_distance({"a", "b"}, {"b", "c"}) == pytest.approx(2 / 3)
    assert metrics.accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        metrics.accuracy([1], [1, 2])


# spec: N-000318 N-000320 N-000322 N-000323 N-000324
def test_N_000318_bleu():
    reference = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(reference, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(reference, ["zzz", "qqq"]) == 0.0
    assert 0 < bleu([["a", "b", "c", "d", "e"]], ["a", "b"], weights=(1,)) < 1


# spec: N-000397 N-000398 N-000399 N-000400 N-000401
def test_N_000397_cli_tokenize_reads_stdin(monkeypatch, capsys, model_dir):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there. Bye!\n\n"))
    with pytest.raises(SystemExit) as exit_info:
        main(args=["tokenize"])
    assert exit_info.value.code == 0
    assert capsys.readouterr().out == "Hi there . Bye !\n\n"


# spec: N-000400 N-000401 N-000134
def test_N_000400_cli_fails_without_punkt_and_writes_nothing(monkeypatch, capsys, no_data):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n"))
    with pytest.raises(SystemExit) as exit_info:
        cli.main(args=["tokenize"])
    assert exit_info.value.code != 0
    assert capsys.readouterr().out == ""


# spec: N-000403
def test_N_000403_cli_delimiter_option(monkeypatch, capsys, model_dir):
    monkeypatch.setattr(sys, "stdin", io.StringIO("a,b c\n"))
    with pytest.raises(SystemExit):
        cli.main(args=["tokenize", "--delimiter", "|"])
    assert capsys.readouterr().out == "a|,|b|c\n"
