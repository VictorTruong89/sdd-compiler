import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lingora import data  # noqa: E402


@pytest.fixture
def no_data(monkeypatch):
    """No packaged resource is visible."""
    monkeypatch.setattr(data, "path", [])
    return data.path


@pytest.fixture
def model_dir(tmp_path, monkeypatch):
    """A small fake packaged-data tree: Punkt (English), a perceptron tagger,
    the universal tagset map, and an English stopword list."""
    root = tmp_path / "lingora-data"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("mr\ndr\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\nhe\nshe\nit\nwas\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("mr\tsmith\n", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("he\t2\nwas\t16\n", encoding="utf-8")

    tagger = root / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        '{"bias": {"NN": 1.0}, "i word the": {"DT": 5.0},'
        ' "i word dog": {"NN": 3.0}, "i word ran": {"VBD": 3.0}}',
        encoding="utf-8",
    )
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        '{"the": "DT", "dog": "NN", "ran": "VBD"}', encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        '["DT", "NN", "VBD"]', encoding="utf-8")

    universal = root / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\nVBD\tVERB\n", encoding="utf-8")

    stopwords = root / "corpora" / "stopwords"
    stopwords.mkdir(parents=True)
    (stopwords / "english").write_text("the\nand\nof\n", encoding="utf-8")

    monkeypatch.setattr(data, "path", [str(root)])
    return root
