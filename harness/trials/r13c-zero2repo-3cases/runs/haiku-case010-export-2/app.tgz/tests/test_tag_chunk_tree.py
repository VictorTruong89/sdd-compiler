import pytest

from lingora import data
from lingora.chunk import RegexpParser, ne_chunk
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree

TAGGED = [("the", "DT"), ("little", "JJ"), ("yellow", "JJ"), ("dog", "NN"),
          ("barked", "VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN")]


# spec: N-000191 N-000193 N-000424 N-000425
def test_N_000193_default_tagger_tags_every_token():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


# spec: N-000194 N-000196 N-000200 N-000201
def test_N_000194_unigram_tagger_with_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("dog", "VB")],
             [("dog", "NN")]]
    tagger = UnigramTagger(train=train, backoff=DefaultTagger("XX"))
    assert tagger.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", "XX")]
    assert UnigramTagger(train=train).tag(["zebra"]) == [("zebra", None)]


# spec: N-000197 N-000198 N-000199
def test_N_000197_regexp_tagger_first_matching_rule_wins():
    tagger = RegexpTagger([(r".*ing$", "VBG"), (r".*s$", "NNS"), (r"\d+$", "CD")])
    assert tagger.tag(["running", "cats", "42", "table"]) == [
        ("running", "VBG"), ("cats", "NNS"), ("42", "CD"), ("table", None)]


# spec: N-000214 N-000215 N-000216
def test_N_000214_pos_tag_refuses_raw_string(model_dir):
    with pytest.raises(TypeError):
        pos_tag("the dog ran")


# spec: N-000217 N-000218
def test_N_000217_pos_tag_rejects_other_languages(model_dir):
    with pytest.raises(ValueError):
        pos_tag(["the"], lang="fra")


# spec: N-000202 N-000205 N-000206 N-000207
def test_N_000202_pos_tag_english_perceptron(model_dir):
    assert pos_tag(["the", "dog", "ran"]) == [("the", "DT"), ("dog", "NN"), ("ran", "VBD")]


# spec: N-000210 N-000221 N-000222
def test_N_000210_universal_mapping_needs_tables(no_data, model_dir):
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]
    data.path[:] = []
    with pytest.raises(data.ResourceNotFound):
        pos_tag(["the"], tagset="universal")


# spec: N-000219 N-000220
def test_N_000219_missing_tagger_resource_fails(no_data):
    with pytest.raises(data.ResourceNotFound):
        pos_tag(["the"])


# spec: N-000226 N-000230 N-000231 N-000232 N-000233
def test_N_000230_chunk_rule_is_longest_match():
    parser = RegexpParser("NP: {<DT>?<JJ>*<NN>}")
    tree = parser.parse(TAGGED)
    assert [child.label() for child in tree if isinstance(child, Tree)] == ["NP", "NP"]
    assert tree.leaves() == TAGGED


# spec: N-000234 N-000235 N-000236
def test_N_000234_chink_splits_chunk():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}\n}<JJ>{").parse(TAGGED)
    first = tree[0]
    assert first.label() == "NP" and list(first) == [("the", "DT")]
    assert tree[1] == ("little", "JJ")
    assert tree.leaves() == TAGGED


# spec: N-000237 N-000238 N-000241
def test_N_000237_later_clause_cascades_over_chunks():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}\nPP: {<IN><NP>}").parse(TAGGED)
    labels = [child.label() for child in tree if isinstance(child, Tree)]
    assert labels == ["NP", "PP"]
    assert tree.leaves() == TAGGED


# spec: N-000243
def test_N_000243_empty_input_gives_empty_sentence_tree():
    tree = RegexpParser("NP: {<NN>}").parse([])
    assert len(tree) == 0 and tree.label() == "S"


# spec: N-000244 N-000245 N-000246
def test_N_000244_refuses_non_grammar_values():
    with pytest.raises(TypeError):
        RegexpParser(42)


# spec: N-000247 N-000432
def test_N_000247_ne_chunk_needs_resources(no_data):
    with pytest.raises(data.ResourceNotFound):
        ne_chunk(TAGGED)


# spec: N-000274 N-000275 N-000276 N-000277 N-000467 N-000468
def test_N_000274_tree_construction_rules():
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")
    assert len(Tree("S", [])) == 0


# spec: N-000463 N-000464 N-000465 N-000272 N-000469
def test_N_000463_tree_from_string_and_equality():
    tree = Tree.fromstring("(S (NP (DT the) (NN dog)) (VP (VBD ran)))")
    expected = Tree("S", [Tree("NP", [Tree("DT", ["the"]), Tree("NN", ["dog"])]),
                          Tree("VP", [Tree("VBD", ["ran"])])])
    assert tree == expected
    assert tree.leaves() == ["the", "dog", "ran"]
    assert tree[0].label() == "NP"


# spec: N-000273 N-000470
def test_N_000273_pformat_keeps_preorder():
    text = Tree.fromstring("(S (NP (DT the) (NN dog)) (VP (VBD ran)))").pformat()
    order = [tok for tok in ["S", "NP", "DT", "the", "NN", "dog", "VP", "VBD", "ran"]]
    positions = [text.index(tok) for tok in order]
    assert positions == sorted(positions)
