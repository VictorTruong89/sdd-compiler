import pytest

from lingora import data
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


# spec: N-000086 N-000087 N-000088
def test_N_000086_wordpunct_splits_words_and_punctuation():
    assert wordpunct_tokenize("Hello, world! 3.5") == ["Hello", ",", "world", "!", "3", ".", "5"]


# spec: N-000121 N-000122 N-000123
def test_N_000121_wordpunct_spans_recover_tokens():
    text = "ab, cd"
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == ["ab", ",", "cd"]
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


# spec: N-000131
def test_N_000131_empty_and_blank_text_give_no_tokens():
    assert wordpunct_tokenize("") == []
    assert WhitespaceTokenizer().tokenize("  \n\t") == []
    assert blankline_tokenize("   ") == []


# spec: N-000089 N-000091 N-000092 N-000093 N-000094 N-000096 N-000097 N-000098 N-000099
def test_N_000089_treebank_conventions():
    tokens = TreebankWordTokenizer().tokenize('He said "hi" and didn\'t go, cannot stop.')
    assert tokens == ["He", "said", "``", "hi", "''", "and", "did", "n't", "go", ",",
                      "can", "not", "stop", "."]


# spec: N-000101 N-000102 N-000103 N-000104 N-000105
def test_N_000101_recommended_word_tokenizer_on_one_line(no_data):
    assert word_tokenize("wanna go“ now” -- ok", preserve_line=True) == [
        "wan", "na", "go", "“", "now", "”", "--", "ok"]


# spec: N-000108
def test_N_000108_whitespace_tokenizer():
    assert WhitespaceTokenizer().tokenize(" a  b\tc\n") == ["a", "b", "c"]


# spec: N-000109 N-000110
def test_N_000109_blankline_segments_keep_single_newlines():
    assert blankline_tokenize("a\nb\n\n  \n c") == ["a\nb", "c"]


# spec: N-000111 N-000112 N-000113
def test_N_000111_regexp_token_and_gap_modes():
    assert RegexpTokenizer(r"\d+").tokenize("a1b22c") == ["1", "22"]
    assert RegexpTokenizer(r"\d+", gaps=True).tokenize("a1b22c") == ["a", "b", "c"]
    assert RegexpTokenizer(r"\d+", gaps=True, discard_empty=False).tokenize("1a") == ["", "a"]


# spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120
def test_N_000114_tweet_tokenizer_options():
    tokenizer = TweetTokenizer()
    assert tokenizer.tokenize("don't stop @bob #wow café :)") == [
        "don't", "stop", "@bob", "#wow", "café", ":)"]
    # "hi@x" is not a handle (the @ continues a word), so it is not stripped.
    assert TweetTokenizer(strip_handles=True).tokenize("hi@x @bob ok") == [
        "hi", "@", "x", "ok"]
    assert TweetTokenizer(reduce_len=True).tokenize("nooooo") == ["nooo"]
    assert TweetTokenizer(preserve_case=False).tokenize("GREAT :D") == ["great", ":D"]


# spec: N-000124 N-000126 N-000127 N-000128
def test_N_000124_sent_tokenize_uses_packaged_punkt(model_dir):
    sentences = sent_tokenize("Mr. Smith went home. He was tired! Was he? Yes.")
    assert sentences == ["Mr. Smith went home.", "He was tired!", "Was he?", "Yes."]


# spec: N-000132 N-000133 N-000134 N-000396
def test_N_000132_sentence_splitting_fails_without_model(no_data):
    with pytest.raises(data.ResourceNotFound):
        sent_tokenize("A sentence. Another one.")
    with pytest.raises(data.ResourceNotFound):
        word_tokenize("A sentence. Another one.")


# spec: N-000082 N-000083 N-000106 N-000107
def test_N_000106_word_tokenize_splits_sentences_first(model_dir):
    assert word_tokenize("He was tired. Mr. Smith ran.") == [
        "He", "was", "tired", ".", "Mr.", "Smith", "ran", "."]
