import pytest

from lingora import data
from lingora.stem import (
    LancasterStemmer,
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
    WordNetLemmatizer,
    ORIGINAL_ALGORITHM,
)


# spec: N-000149 N-000151 N-000152 N-000153 N-000154 N-000155
def test_N_000149_porter_default_mode_extensions():
    stemmer = PorterStemmer()
    assert stemmer.stem("ties") == "tie"
    assert stemmer.stem("cries") == "cri"
    assert stemmer.stem("tied") == "tie"
    assert stemmer.stem("is") == "is"
    assert stemmer.stem("ABC") == "abc"
    assert stemmer.stem("Caresses", to_lowercase=False) == "Caress"


# spec: N-000144 N-000145 N-000148
def test_N_000148_porter_original_algorithm_mode():
    stemmer = PorterStemmer(ORIGINAL_ALGORITHM)
    assert stemmer.stem("caresses") == "caress"
    assert stemmer.stem("relational") == "relat"
    assert stemmer.stem("conditional") == "condit"
    assert stemmer.stem("rational") == "ration"


# spec: N-000164 N-000160 N-000161 N-000162
def test_N_000164_porter_lingora_step2_extensions():
    stemmer = PorterStemmer()
    assert stemmer.stem("conformabli") == "conform"
    assert stemmer.stem("radicalli") == "radic"
    assert stemmer.stem("analogousli") == "analog"


# spec: N-000165 N-000166
def test_N_000165_lancaster_stems_common_words():
    stemmer = LancasterStemmer()
    assert stemmer.stem("maximum") == "maxim"
    assert stemmer.stem("running") == "run"
    assert stemmer.stem("jumps") == "jump"


# spec: N-000167 N-000168 N-000169 N-000170 N-000171
def test_N_000167_snowball_english_and_porter(no_data):
    english = SnowballStemmer("english")
    assert english.stem("generously") == "generous"
    assert english.stem("consistency") == "consist"
    assert english.stem("Skies") == "sky"
    assert SnowballStemmer("porter").stem("generously") == "gener"


# spec: N-000176 N-000177 N-000409 N-000410
def test_N_000176_unsupported_snowball_language_names_request():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


# spec: N-000178 N-000179 N-000411
def test_N_000178_snowball_stopwords_need_packaged_list(model_dir):
    saved = list(data.path)
    data.path[:] = []
    with pytest.raises(data.ResourceNotFound):
        SnowballStemmer("english", ignore_stopwords=True)
    data.path[:] = saved
    stemmer = SnowballStemmer("english", ignore_stopwords=True)
    assert stemmer.stem("The") == "the"


# spec: N-000173 N-000174 N-000175
def test_N_000173_regexp_stemmer_removes_matches_only():
    stemmer = RegexpStemmer(r"ing$|s$")
    assert stemmer.stem("running") == "runn"
    assert stemmer.stem("cats") == "cat"
    assert stemmer.stem("tree") == "tree"


# spec: N-000180 N-000181 N-000412
def test_N_000180_wordnet_lemmatizer_needs_wordnet(no_data):
    with pytest.raises(data.ResourceNotFound):
        WordNetLemmatizer()
