"""LINGORA: a Python natural-language processing library.

Importing the package downloads nothing and reads no resource.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: E402
from lingora import tokenize  # noqa: E402
from lingora import stem  # noqa: E402
from lingora import tag  # noqa: E402
from lingora import tree  # noqa: E402
from lingora import chunk  # noqa: E402
from lingora import grammar  # noqa: E402
from lingora import parse  # noqa: E402
from lingora import classify  # noqa: E402
from lingora import metrics  # noqa: E402
from lingora import translate  # noqa: E402
from lingora import cli  # noqa: E402

__all__ = [
    "data", "tokenize", "stem", "tag", "tree", "chunk", "grammar", "parse",
    "classify", "metrics", "translate", "cli",
]
