"""Context-free grammars (FP-05)."""

import re
from collections import defaultdict

_IDENT = re.compile(r"[^\s'\"|]+")
_RHS_TOKEN = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([^\s'"|]+))""")


class Nonterminal:
    """A nonterminal symbol. Compares equal to a ``str`` of the same name."""

    # spec: N-000446 N-000447 N-000448
    def __init__(self, symbol):
        self.symbol = symbol

    def __str__(self):
        return self.symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self.symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self.symbol == other.symbol
        if isinstance(other, str):
            return self.symbol == other
        return NotImplemented

    def __hash__(self):
        return hash(self.symbol)


class Production:
    """``lhs -> rhs``. ``rhs`` is a tuple of terminals (``str``) and
    nonterminals (``Nonterminal``)."""

    # spec: N-000449 N-000450 N-000451
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __eq__(self, other):
        if not isinstance(other, Production):
            return NotImplemented
        return self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        body = " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs
        )
        return "%s -> %s" % (self._lhs, body)


def _parse_rhs(text):
    """Alternatives of one right-hand side, each a list of symbols."""
    alternatives = [[]]
    position = 0
    while position < len(text):
        if not text[position:].strip():
            break
        match = _RHS_TOKEN.match(text, position)
        if not match or match.end() == position:
            raise ValueError("cannot read production right-hand side: %r" % text)
        quoted_double, quoted_single, bar, ident = match.groups()
        if bar:
            alternatives.append([])
        elif quoted_double is not None:
            alternatives[-1].append(quoted_double)
        elif quoted_single is not None:
            alternatives[-1].append(quoted_single)
        else:
            alternatives[-1].append(Nonterminal(ident))
        position = match.end()
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the
    first production."""

    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(str(start))
        self._start = start
        self._productions = list(productions)

    # spec: N-000441 N-000444 N-000445 N-000251 N-000252
    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for line in input.splitlines():
            if not line.strip():
                continue
            lhs_text, arrow, rhs_text = line.partition("->")
            if not arrow:
                raise ValueError("production has no '->': %r" % line)
            lhs_text = lhs_text.strip()
            if not _IDENT.fullmatch(lhs_text):
                raise ValueError("bad left-hand side: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alternative in _parse_rhs(rhs_text):
                productions.append(Production(lhs, alternative))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def nonterminals(self):
        return {str(p.lhs()) for p in self._productions}

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


def _nonterminal_index(grammar):
    index = defaultdict(list)
    for production in grammar.productions():
        index[str(production.lhs())].append(production)
    return index
