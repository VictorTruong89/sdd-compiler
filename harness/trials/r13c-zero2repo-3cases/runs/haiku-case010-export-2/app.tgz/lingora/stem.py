"""Stemmers and the WordNet lemmatizer (FP-02)."""

import os
import re

from lingora import data

# spec: N-000408
SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_VOWELS = "aeiou"


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str, not %s" % type(word).__name__)


# ---------------------------------------------------------------------------
# Porter (original algorithm, plus LINGORA extensions as the default mode)
# ---------------------------------------------------------------------------

ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
LINGORA_EXTENSIONS = "LINGORA_EXTENSIONS"

# Built-in table of irregular forms (entries are the implementer's choice).
_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atla", "cosmos": "cosmo",
    "bias": "bia", "andes": "ande",
}


def _is_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    """Porter's m: the number of VC sequences in the stem."""
    n = len(stem)
    i = 0
    while i < n and _is_cons(stem, i):
        i += 1
    m = 0
    while i < n:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_cvc(stem, extended=False):
    n = len(stem)
    if n >= 3 and _is_cons(stem, n - 3) and not _is_cons(stem, n - 2) \
            and _is_cons(stem, n - 1) and stem[-1] not in "wxy":
        return True
    if extended and n == 2 and not _is_cons(stem, 0) and _is_cons(stem, 1) \
            and stem[-1] not in "wxy":
        return True
    return False


def _ends_double_cons(stem):
    return len(stem) >= 2 and stem[-1] == stem[-2] and _is_cons(stem, len(stem) - 1)


def _replace_first(word, rules):
    """Apply the first suffix rule that matches (needs measure > 0); a match
    whose condition fails stops the step without further rules."""
    for suffix, repl in rules:
        if word.endswith(suffix):
            stem = word[:-len(suffix)]
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


class PorterStemmer:
    """Porter's suffix-stripping stemmer."""

    # spec: N-000135 N-000144 N-000145 N-000146 N-000148 N-000151 N-000152
    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, LINGORA_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        if not isinstance(to_lowercase, bool):
            raise TypeError("to_lowercase must be bool")
        # spec: N-000149
        if to_lowercase:
            word = word.lower()
        if self.mode != LINGORA_EXTENSIONS:
            return self._original(word)
        # spec: N-000151 N-000152 N-000164
        if len(word) <= 2:
            return word
        # spec: N-000150
        if word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        return self._lingora(word)

    # -- LINGORA extensions --------------------------------------------------

    def _lingora(self, word):
        # spec: N-000153 Step 1a, -ies after a four-letter word becomes -ie
        if word.endswith("sses"):
            word = word[:-2]
        elif word.endswith("ies"):
            word = word[:-3] + ("ie" if len(word) == 4 else "i")
        elif word.endswith("ss"):
            pass
        elif word.endswith("s"):
            word = word[:-1]
        # spec: N-000154 N-000155 Step 1b, -ied handling
        if word.endswith("ied"):
            word = word[:-3] + ("ie" if len(word) == 4 else "i")
        else:
            word = self._step1b(word, extended=True)
        word = self._step1c(word)
        word = self._step2(word, extended=True)
        word = self._step3(word)
        word = self._step4(word)
        return self._step5(word, extended=True)

    @staticmethod
    def _step1b(word, extended):
        if word.endswith("eed"):
            if _measure(word[:-3]) > 0:
                word = word[:-1]
            return word
        for suffix in ("ed", "ing"):
            if word.endswith(suffix) and _has_vowel(word[:-len(suffix)]):
                word = word[:-len(suffix)]
                if word.endswith(("at", "bl", "iz")):
                    word += "e"
                elif _ends_double_cons(word) and word[-1] not in "lsz":
                    word = word[:-1]
                elif _measure(word) == 1 and _ends_cvc(word, extended=extended):
                    word += "e"
                return word
        return word

    @staticmethod
    def _step1c(word):
        # spec: N-000157 y becomes i after a consonant that is not the first letter
        if word.endswith("y") and len(word) >= 3 and _is_cons(word, len(word) - 2):
            word = word[:-1] + "i"
        return word

    def _step2(self, word, extended):
        # spec: N-000158 N-000159 -alli is tried first, then step 2 is repeated
        if extended:
            if word.endswith("alli") and _measure(word[:-4]) > 0:
                return self._step2(word[:-2], extended)
            # spec: N-000160 N-000161 N-000162 LINGORA's -bli, -logi and -fulli
            if word.endswith("bli") and _measure(word[:-3]) > 0:
                return word[:-3] + "ble"
            if word.endswith("logi") and _measure(word[:-3]) > 0:
                return word[:-1]
            if word.endswith("fulli") and _measure(word[:-5]) > 0:
                return word[:-2]
            # The original -abli -> -able rule is replaced by -bli -> -ble.
            rules = [
                ("ational", "ate"), ("tional", "tion"), ("enci", "ence"),
                ("anci", "ance"), ("izer", "ize"), ("entli", "ent"),
                ("eli", "e"), ("ousli", "ous"), ("ization", "ize"),
                ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
                ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
                ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
            ]
            return _replace_first(word, rules)
        rules = [
            ("ational", "ate"), ("tional", "tion"), ("enci", "ence"),
            ("anci", "ance"), ("abli", "able"), ("izer", "ize"),
            ("alli", "al"), ("entli", "ent"), ("eli", "e"), ("ousli", "ous"),
            ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
            ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
            ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"),
            ("biliti", "ble"),
        ]
        return _replace_first(word, rules)

    @staticmethod
    def _step3(word):
        rules = [
            ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
            ("ical", "ic"), ("ful", ""), ("ness", ""),
        ]
        return _replace_first(word, rules)

    def _step4(self, word):
        suffixes = [
            "al", "ance", "ence", "er", "ic", "able", "ible", "ant",
            "ement", "ment", "ent", "ion", "ou", "ism", "ate", "iti",
            "ous", "ive", "ize",
        ]
        for suffix in suffixes:
            if word.endswith(suffix):
                stem = word[:-len(suffix)]
                if suffix == "ion" and not stem.endswith(("s", "t")):
                    return word
                if _measure(stem) > 1:
                    return stem
                return word
        return word

    @staticmethod
    def _step5(word, extended):
        if word.endswith("e"):
            stem = word[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _ends_cvc(stem, extended=extended)):
                word = stem
        if word.endswith("ll") and _measure(word) > 1:
            word = word[:-1]
        return word

    # -- original algorithm --------------------------------------------------

    def _original(self, word):
        if len(word) <= 2:
            return word
        word = self._orig_step1a(word)
        word = self._orig_step1b(word)
        if word.endswith("y") and _has_vowel(word[:-1]):
            word = word[:-1] + "i"
        word = self._step2(word, extended=False)
        word = self._step3(word)
        word = self._step4(word)
        return self._step5(word, extended=False)

    @staticmethod
    def _orig_step1a(word):
        if word.endswith("sses"):
            return word[:-2]
        if word.endswith("ies"):
            return word[:-2]
        if word.endswith("ss"):
            return word
        if word.endswith("s"):
            return word[:-1]
        return word

    def _orig_step1b(self, word):
        return self._step1b(word, extended=False)


# ---------------------------------------------------------------------------
# Porter2 (Snowball "english")
# ---------------------------------------------------------------------------

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "only", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
            "exceed", "succeed"}
_P2_VOWELS = "aeiouy"
_P2_STEP2 = sorted([
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
    ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
    ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
    ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("fulli", "ful"), ("lessli", "less"), ("ogi", "og"), ("li", ""),
], key=lambda pair: -len(pair[0]))
_P2_STEP3 = sorted([
    ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
    ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""),
    ("ative", ""),
], key=lambda pair: -len(pair[0]))
_P2_STEP4 = sorted([
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
], key=len, reverse=True)


def _p2_regions(word):
    r1 = len(word)
    for prefix in ("gener", "commun", "arsen"):
        if word.startswith(prefix):
            r1 = len(prefix)
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _p2_short_syllable_at_end(word):
    n = len(word)
    if n == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if n >= 3:
        return (word[-3] not in _P2_VOWELS and word[-2] in _P2_VOWELS
                and word[-1] not in _P2_VOWELS and word[-1] not in "wxY")
    return False


def _p2_suffix(word, suffixes):
    for suffix in suffixes:
        if word.endswith(suffix):
            return suffix
    return None


def _porter2(word):
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if len(word) <= 2:
        return word
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith("s") and not w.endswith(("us", "ss")):
        if any(c in _P2_VOWELS for c in w[:-2]):
            w = w[:-1]

    if w in _P2_EXC2:
        return w.lower()

    r1, r2 = _p2_regions(w)

    # Step 1b
    suffix = _p2_suffix(w, ("eedly", "eed"))
    if suffix:
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        suffix = _p2_suffix(w, ("ingly", "edly", "ing", "ed"))
        if suffix and any(c in _P2_VOWELS for c in w[:-len(suffix)]):
            w = w[:-len(suffix)]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                w = w[:-1]
            else:
                r1_now, _ = _p2_regions(w)
                if r1_now == len(w) and _p2_short_syllable_at_end(w):
                    w += "e"

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    # Step 2
    r1, r2 = _p2_regions(w)
    for suffix, repl in _P2_STEP2:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                if suffix == "li":
                    if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                        w = w[:-2]
                elif suffix == "ogi":
                    if len(w) >= 4 and w[-4] == "l":
                        w = w[:-3] + "og"
                else:
                    w = w[:-len(suffix)] + repl
            break

    # Step 3
    r1, r2 = _p2_regions(w)
    for suffix, repl in _P2_STEP3:
        if w.endswith(suffix):
            if suffix == "ative":
                if len(w) - len(suffix) >= r2:
                    w = w[:-len(suffix)]
            elif len(w) - len(suffix) >= r1:
                w = w[:-len(suffix)] + repl
            break

    # Step 4
    r1, r2 = _p2_regions(w)
    for suffix in _P2_STEP4:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix == "ion":
                    if len(w) > 3 and w[-4] in "st":
                        w = w[:-3]
                else:
                    w = w[:-len(suffix)]
            break

    # Step 5
    r1, r2 = _p2_regions(w)
    if w.endswith("e"):
        if len(w) - 1 >= r2:
            w = w[:-1]
        elif len(w) - 1 >= r1 and not _p2_short_syllable_at_end(w[:-1]):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w.endswith("ll"):
        w = w[:-1]

    return w.replace("Y", "y")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rules are written as in Paice's table: the reversed suffix, an optional
# "*" (applies only while the word is intact), a digit giving the number of
# letters removed, the letters appended, then "." (stop) or ">" (continue).
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3y.", "lu2.", "lai3y>", "la2>", "ll1.", "mui3.",
    "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3y>",
    "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.",
    "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.",
    "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ytic3s.", "tec2ss.", "tu1>", "ta2>", "tnam4.", "tne3.", "tcab2s.",
    "tnap3.", "uo2>", "vei3y>", "vis3j>", "vi2>", "vy1.", "yc1.", "ymo3.",
    "yr1.", "yt1.", "yy1.", "zi2>", "zy1s.",
)


def _parse_lancaster_rule(text):
    stop = text[-1] == "."
    body = text[:-1]
    match = re.match(r"([a-z]*)(\*?)(\d)([a-z]*)$", body)
    if not match:
        raise ValueError("bad Lancaster rule %r" % text)
    letters, star, count, append = match.groups()
    return {
        "suffix": letters[::-1],
        "intact": bool(star),
        "remove": int(count),
        "append": append,
        "stop": stop,
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(rule) for rule in _LANCASTER_RULES]


class LancasterStemmer:
    """Paice/Husk Lancaster stemmer."""

    # spec: N-000165 N-000166
    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        while True:
            rule = self._find_rule(word, intact)
            if rule is None:
                return word
            word = word[:len(word) - rule["remove"]] + rule["append"]
            intact = False
            if rule["stop"]:
                return word

    @staticmethod
    def _find_rule(word, intact):
        for rule in _LANCASTER_PARSED:
            if not word.endswith(rule["suffix"]):
                continue
            if rule["intact"] and not intact:
                continue
            stem = word[:len(word) - rule["remove"]]
            if LancasterStemmer._acceptable(stem):
                return rule
        return None

    @staticmethod
    def _acceptable(stem):
        if not stem:
            return False
        minimum = 2 if stem[0] in _VOWELS else 3
        return len(stem) >= minimum


# ---------------------------------------------------------------------------
# Snowball
# ---------------------------------------------------------------------------

_SNOWBALL_IMPLEMENTED = {"english", "porter"}


class SnowballStemmer:
    """Snowball stemmer for the languages named in FP-02."""

    # spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language %r; supported: %s"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        if not isinstance(ignore_stopwords, bool):
            raise TypeError("ignore_stopwords must be bool")
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError(
                "the Snowball %r stemmer is not implemented in this build" % language
            )
        self.language = language
        self.ignore_stopwords = ignore_stopwords
        self._stopwords = frozenset()
        if ignore_stopwords:
            # spec: N-000178 N-000179 a list for another language does not count
            self._stopwords = frozenset(
                data.read_lines("corpora/stopwords/%s" % language)
            )

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        word = word.lower()
        if self.ignore_stopwords and word in self._stopwords:
            return word
        if self.language == "porter":
            return PorterStemmer(ORIGINAL_ALGORITHM).stem(word, to_lowercase=False)
        return _porter2(word)


class ARLSTem:
    """ARLSTem (Arabic). Named in the public surface; results are outside
    this specification."""

    def stem(self, word):
        _check_word(word)
        raise NotImplementedError("ARLSTem stemming is outside this specification")


class ARLSTem2(ARLSTem):
    """ARLSTem2 (Arabic). Results are outside this specification."""


class RegexpStemmer:
    """Removes every match of ``regexp`` from the word."""

    # spec: N-000173 N-000174 N-000175
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regex = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regex.sub("", word)


class WordNetLemmatizer:
    """Lemmatizer backed by the packaged WordNet noun index."""

    _NOUN_RULES = (
        ("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
        ("shes", "sh"), ("men", "man"), ("ies", "y"), ("s", ""),
    )

    # spec: N-000180 N-000181 N-000412
    def __init__(self):
        directory = data.find("corpora/wordnet")
        index_path = os.path.join(directory, "index.noun")
        if not os.path.exists(index_path):
            raise data.ResourceNotFound("WordNet noun index not found in %s" % directory)
        self._nouns = set()
        with open(index_path, encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if line.startswith(" ") or not line.strip():
                    continue
                self._nouns.add(line.split(" ", 1)[0])

    def lemmatize(self, word):
        _check_word(word)
        if word in self._nouns:
            return word
        for suffix, repl in self._NOUN_RULES:
            if word.endswith(suffix):
                candidate = word[:-len(suffix)] + repl
                if candidate in self._nouns:
                    return candidate
        return word
