"""Parsers over a context-free grammar (FP-05)."""

from lingora.grammar import CFG
from lingora.tree import Tree


def _check_grammar(grammar):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG, not %s" % type(grammar).__name__)


def _check_tokens(tokens, grammar):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    terminals = grammar.terminals()
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("every token must be a str")
        if token not in terminals:
            raise ValueError("no production of the grammar produces token %r" % token)


class ChartParser:
    """Exhaustive parser: returns every parse tree of the token list."""

    # spec: N-000253 N-000254 N-000255 N-000256 N-000257 N-000258
    # spec: N-000278 N-000279 N-000280 N-000452 N-000453 N-000454 N-000455 N-000456
    def __init__(self, grammar):
        _check_grammar(grammar)
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(tokens, self._grammar)
        return iter(_ChartRun(self._grammar, list(tokens)).trees())


class _ChartRun:
    """Span sets are computed to a fixpoint, then trees are enumerated from them.
    Cycles of unit productions are cut, so the result is finite."""

    def __init__(self, grammar, tokens):
        self.grammar = grammar
        self.tokens = tokens
        self.n = len(tokens)
        self.by_lhs = {}
        for production in grammar.productions():
            self.by_lhs.setdefault(str(production.lhs()), []).append(production)
        self.spans = {name: set() for name in self.by_lhs}
        self._fixpoint()

    def _rhs_spans(self, rhs):
        reach = {(i, i) for i in range(self.n + 1)}
        for symbol in rhs:
            following = set()
            if isinstance(symbol, str):
                for start, k in reach:
                    if k < self.n and self.tokens[k] == symbol:
                        following.add((start, k + 1))
            else:
                known = self.spans.get(str(symbol), set())
                for start, k in reach:
                    for a, b in known:
                        if a == k:
                            following.add((start, b))
            reach = following
            if not reach:
                break
        return reach

    def _fixpoint(self):
        changed = True
        while changed:
            changed = False
            for name, productions in self.by_lhs.items():
                for production in productions:
                    found = self._rhs_spans(production.rhs())
                    new = found - self.spans[name]
                    if new:
                        self.spans[name] |= new
                        changed = True

    def trees(self):
        return self._trees(str(self.grammar.start()), 0, self.n, set())

    def _trees(self, name, i, j, active):
        key = (name, i, j)
        if key in active or (i, j) not in self.spans.get(name, ()):
            return []
        active.add(key)
        results = []
        for production in self.by_lhs.get(name, []):
            for children in self._expand(production.rhs(), i, j, active):
                results.append(Tree(name, children))
        active.discard(key)
        return results

    def _expand(self, rhs, i, j, active):
        if not rhs:
            if i == j:
                yield []
            return
        first, rest = rhs[0], rhs[1:]
        if isinstance(first, str):
            if i < j and self.tokens[i] == first:
                for tail in self._expand(rest, i + 1, j, active):
                    yield [first] + tail
            return
        for m in range(i, j + 1):
            for sub in self._trees(str(first), i, m, active):
                for tail in self._expand(rest, m, j, active):
                    yield [sub] + tail


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    # spec: N-000259 N-000260 N-000261 N-000262
    def __init__(self, grammar):
        _check_grammar(grammar)
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(tokens, self._grammar)
        productions = [p for p in self._grammar.productions() if p.rhs()]
        start = str(self._grammar.start())
        stack = []   # entries: ("leaf", token) or ("tree", Tree)
        buffer = list(tokens)
        while True:
            if self._reduce(stack, productions):
                continue
            if not buffer:
                break
            stack.append(("leaf", buffer.pop(0)))
        if len(stack) == 1 and stack[0][0] == "tree" and stack[0][1].label() == start:
            return iter([stack[0][1]])
        return iter([])

    @staticmethod
    def _reduce(stack, productions):
        for production in productions:
            rhs = production.rhs()
            k = len(rhs)
            if len(stack) < k:
                continue
            window = stack[-k:]
            matches = True
            for entry, symbol in zip(window, rhs):
                if isinstance(symbol, str):
                    if entry != ("leaf", symbol):
                        matches = False
                        break
                elif entry[0] != "tree" or entry[1].label() != str(symbol):
                    matches = False
                    break
            if matches:
                children = [entry[1] for entry in window]
                del stack[-k:]
                stack.append(("tree", Tree(str(production.lhs()), children)))
                return True
        return False
