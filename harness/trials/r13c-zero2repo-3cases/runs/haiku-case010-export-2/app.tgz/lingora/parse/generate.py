"""Sentence generation from a context-free grammar (FP-05)."""

from lingora.grammar import CFG, _nonterminal_index

_STOP_AFTER_EMPTY_LEVELS = 3


def generate(grammar, start=None, depth=None, n=None):
    """Yield the sentences ``grammar`` derives from ``start``, as lists of
    terminal strings.

    ``depth`` bounds the derivation depth (number of nonterminal expansions
    along the longest branch); ``n`` bounds how many sentences are yielded.
    With neither bound on a finite language, generation stops once several
    successive depths add nothing new.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    for name, value in (("depth", depth), ("n", n)):
        if value is not None and (not isinstance(value, int) or isinstance(value, bool)):
            raise TypeError("%s must be an int or None" % name)
    if start is None:
        start_name = str(grammar.start())
    else:
        start_name = str(start)
        if start_name not in grammar.nonterminals():
            raise ValueError("%r is not a nonterminal of the grammar" % start_name)
    return _generate(grammar, start_name, depth, n)


def _generate(grammar, start_name, depth, n):
    index = _nonterminal_index(grammar)

    def gen_symbol(name, budget):
        if budget < 1:
            return
        for production in index.get(name, []):
            for tokens, used in gen_sequence(production.rhs(), budget - 1):
                yield tokens, used + 1

    def gen_sequence(rhs, budget):
        if not rhs:
            yield [], 0
            return
        first, rest = rhs[0], rhs[1:]
        if isinstance(first, str):
            for tokens, used in gen_sequence(rest, budget):
                yield [first] + tokens, used
            return
        for head, head_used in gen_symbol(str(first), budget):
            for tail, tail_used in gen_sequence(rest, budget):
                yield head + tail, max(head_used, tail_used)

    produced = 0
    if depth is not None:
        for tokens, _used in gen_symbol(start_name, depth):
            if n is not None and produced >= n:
                return
            produced += 1
            yield tokens
        return

    level = 1
    empty_levels = 0
    while True:
        new_at_level = 0
        for tokens, used in gen_symbol(start_name, level):
            if used != level:
                continue
            if n is not None and produced >= n:
                return
            produced += 1
            new_at_level += 1
            yield tokens
        empty_levels = 0 if new_at_level else empty_levels + 1
        if empty_levels >= _STOP_AFTER_EMPTY_LEVELS:
            return
        level += 1
