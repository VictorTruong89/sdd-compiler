"""Naive Bayes and decision tree classifiers (FP-06)."""

import math
from collections import Counter, defaultdict


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, str) or not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    if not labeled_featuresets:
        raise ValueError("cannot train a classifier on an empty list")
    examples = []
    for pair in labeled_featuresets:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise TypeError("each example must be a (featureset, label) pair")
        featureset, label = pair
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        examples.append((dict(featureset), label))
    return examples


def _check_featureset(featureset):
    if not isinstance(featureset, dict):
        raise TypeError("a featureset must be a dict")


class ProbDist:
    """A probability distribution over labels."""

    # spec: N-000476 N-000477
    def __init__(self, probabilities):
        self._probabilities = dict(probabilities)

    def prob(self, label):
        return float(self._probabilities.get(label, 0.0))

    def samples(self):
        return list(self._probabilities)

    def max(self):
        return max(self._probabilities, key=lambda label: self._probabilities[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probabilities)


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing per feature."""

    # spec: N-000288 N-000289 N-000290 N-000291 N-000292 N-000293 N-000294 N-000295
    def __init__(self, priors, value_counts, label_totals, feature_values):
        self._priors = priors
        self._value_counts = value_counts
        self._label_totals = label_totals
        self._feature_values = feature_values
        self._labels = list(label_totals)

    @classmethod
    def train(cls, labeled_featuresets):
        examples = _check_training(labeled_featuresets)
        label_totals = Counter()
        value_counts = Counter()
        feature_values = defaultdict(set)
        for featureset, label in examples:
            label_totals[label] += 1
            for name, value in featureset.items():
                value_counts[(name, value, label)] += 1
                feature_values[name].add(value)
        total = sum(label_totals.values())
        priors = {label: count / total for label, count in label_totals.items()}
        return cls(priors, value_counts, label_totals, feature_values)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            score = math.log(self._priors[label])
            for name, value in featureset.items():
                if name not in self._feature_values:
                    continue
                count = self._value_counts.get((name, value, label), 0)
                vocabulary = len(self._feature_values[name]) + 1
                probability = (count + 1) / (self._label_totals[label] + vocabulary)
                score += math.log(probability)
            scores[label] = score
        return scores

    # spec: N-000292
    def classify(self, featureset):
        _check_featureset(featureset)
        scores = self._log_scores(featureset)
        return max(self._labels, key=lambda label: scores[label])

    # spec: N-000293 N-000294
    def prob_classify(self, featureset):
        _check_featureset(featureset)
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(weights.values())
        return ProbDist({label: weight / total for label, weight in weights.items()})


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Split:
    def __init__(self, feature, children, majority):
        self.feature = feature
        self.children = children
        self.majority = majority


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for label in labels:
        if counts[label] == best:
            return label


def _build_tree(examples, features):
    labels = [label for _, label in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1:
        return _Leaf(majority)
    best_feature = None
    best_gain = 0.0
    best_groups = None
    base = _entropy(labels)
    for feature in features:
        groups = defaultdict(list)
        for pair in examples:
            groups[pair[0].get(feature)].append(pair)
        if len(groups) < 2:
            continue
        remainder = sum(
            len(group) / len(examples) * _entropy([label for _, label in group])
            for group in groups.values()
        )
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_feature, best_gain, best_groups = feature, gain, groups
    if best_feature is None:
        return _Leaf(majority)
    remaining = [f for f in features if f != best_feature]
    children = {
        value: _build_tree(group, remaining) for value, group in best_groups.items()
    }
    return _Split(best_feature, children, majority)


class DecisionTreeClassifier:
    """Decision tree that splits on the feature with the largest information gain."""

    # spec: N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303
    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        examples = _check_training(labeled_featuresets)
        features = sorted({name for featureset, _ in examples for name in featureset},
                          key=str)
        return cls(_build_tree(examples, features))

    def classify(self, featureset):
        _check_featureset(featureset)
        node = self._root
        while isinstance(node, _Split):
            child = node.children.get(featureset.get(node.feature))
            if child is None:
                return node.majority
            node = child
        return node.label


# spec: N-000304
def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs classified correctly."""
    if isinstance(gold, str) or not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
