"""Packaged resource lookup.

Resources are searched in the directories listed in ``path``. The list is
mutable: a caller may replace its contents in place. An empty list means no
packaged resource is visible. Importing this package downloads nothing.
"""

import os

# spec: N-000371 (initial contents are the implementer's choice: the
# directories in LINGORA_DATA, separated by os.pathsep, if that is set)
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


class ResourceNotFound(LookupError):
    """A packaged resource a path needs is not visible on ``path``."""


def find(relpath):
    """Return the absolute path of ``relpath`` in the first directory of
    ``path`` that holds it. Raise ``ResourceNotFound`` when none does.
    """
    # spec: N-000369 N-000368 N-000370
    for directory in list(path):
        candidate = os.path.join(directory, relpath)
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    raise ResourceNotFound(
        "packaged resource %r is not installed (searched: %s)"
        % (relpath, ", ".join(path) or "no directories")
    )


def is_visible(relpath):
    """True when ``relpath`` can be found on ``path``."""
    try:
        find(relpath)
    except ResourceNotFound:
        return False
    return True


def read_lines(relpath):
    """Read a UTF-8 text resource, one entry per line, without terminators."""
    # spec: N-000381
    with open(find(relpath), encoding="utf-8") as handle:
        return handle.read().splitlines()
