"""BLEU for translation evaluation (FP-07)."""

import math
from collections import Counter

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _check_tokens(tokens, what):
    if not isinstance(tokens, list) or not all(isinstance(t, str) for t in tokens):
        raise TypeError("%s must be a list of str" % what)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _closest_reference_length(references, hypothesis_length):
    # The closest reference length; the shorter one wins a tie.
    return min((len(r) for r in references),
               key=lambda length: (abs(length - hypothesis_length), length))


# spec: N-000478 N-000490 N-000491 N-000492 N-000493 N-000494 N-000318
# spec: N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325
def bleu(references, hypothesis, weights=_DEFAULT_WEIGHTS, smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against ``references``.

    ``weights`` gives one weight per n-gram order, starting from unigrams.
    ``smoothing_function``, when given, is called with the list of
    ``(clipped_count, total_count)`` pairs per order and returns the list of
    precisions to use in their place.
    """
    if not isinstance(references, list) or not references:
        raise TypeError("references must be a non-empty list of token lists")
    for reference in references:
        _check_tokens(reference, "each reference")
    _check_tokens(hypothesis, "hypothesis")
    weights = list(weights)
    if not weights or not all(isinstance(w, (int, float)) and not isinstance(w, bool)
                              for w in weights):
        raise TypeError("weights must be a non-empty sequence of numbers")
    if not hypothesis:
        return 0.0

    counts = []
    for order in range(1, len(weights) + 1):
        candidate = _ngrams(hypothesis, order)
        total = sum(candidate.values())
        max_reference = Counter()
        for reference in references:
            for gram, count in _ngrams(reference, order).items():
                max_reference[gram] = max(max_reference[gram], count)
        clipped = sum(min(count, max_reference[gram]) for gram, count in candidate.items())
        counts.append((clipped, total))

    if smoothing_function is not None:
        precisions = list(smoothing_function(counts))
    else:
        precisions = [clipped / total if total else 0.0 for clipped, total in counts]

    # An order with no match scores 0, unless it carries no weight.
    if any(p <= 0 for w, p in zip(weights, precisions) if w > 0):
        return 0.0
    log_mean = sum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0)

    reference_length = _closest_reference_length(references, len(hypothesis))
    if len(hypothesis) > reference_length:
        penalty = 1.0
    else:
        penalty = math.exp(1 - reference_length / len(hypothesis))
    return penalty * math.exp(log_mean)
