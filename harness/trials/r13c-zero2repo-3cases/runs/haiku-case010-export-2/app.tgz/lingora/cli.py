"""Command line: ``lingora tokenize`` (FP-01).

``cli.main(args=[...], standalone_mode=True)`` runs a command. In standalone
mode it ends the process with status 0 on success and 1 on failure (2 for a
usage error). Otherwise it returns 0, or raises the failure.
"""

import sys

from lingora.tokenize import word_tokenize

USAGE = (
    "usage: lingora tokenize [--language LANG] [--delimiter TEXT]\n"
    "Reads UTF-8 text from standard input and writes one line of tokens per input line."
)


class UsageError(Exception):
    """The command line could not be understood."""


def _parse_tokenize_options(args):
    options = {"language": "english", "delimiter": " "}
    names = {"--language": "language", "-l": "language",
             "--delimiter": "delimiter", "-d": "delimiter"}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-h", "--help"):
            raise UsageError(USAGE)
        name, eq, inline = arg.partition("=")
        if name not in names:
            raise UsageError("unknown option %r\n%s" % (arg, USAGE))
        if eq:
            value = inline
        else:
            if i + 1 >= len(args):
                raise UsageError("option %r needs a value" % arg)
            value = args[i + 1]
            i += 1
        options[names[name]] = value
        i += 1
    return options


def _tokenize(args):
    options = _parse_tokenize_options(args)
    for line in sys.stdin:
        line = line.rstrip("\r\n")
        # Failure raises before anything is written for this line.
        tokens = word_tokenize(line, language=options["language"])
        sys.stdout.write(options["delimiter"].join(tokens) + "\n")
    return 0


_COMMANDS = {"tokenize": _tokenize}


def _run(args):
    if not args:
        raise UsageError(USAGE)
    command = _COMMANDS.get(args[0])
    if command is None:
        raise UsageError("no such command %r\n%s" % (args[0], USAGE))
    return command(args[1:])


# spec: N-000397 N-000398 N-000399 N-000400 N-000401 N-000402 N-000403
def main(args=None, standalone_mode=True):
    if args is None:
        args = sys.argv[1:]
    args = list(args)
    failure = None
    try:
        status = _run(args)
    except UsageError as error:
        sys.stderr.write("%s\n" % error)
        status, failure = 2, error
    except Exception as error:  # a failed tokenization, e.g. missing Punkt model
        sys.stderr.write("lingora: %s\n" % error)
        status, failure = 1, error
    if standalone_mode:
        sys.exit(status)
    if failure is not None:
        raise failure
    return status


class _Group:
    """The ``cli`` object: a command group with a ``main`` entry."""

    name = "lingora"
    commands = _COMMANDS

    def main(self, args=None, standalone_mode=True):
        return main(args=args, standalone_mode=standalone_mode)


cli = _Group()
