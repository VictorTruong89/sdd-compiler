"""Evaluation metrics (FP-07)."""


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _check_lists(reference, test):
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")


def _check_sets(*values):
    for value in values:
        if not isinstance(value, (set, frozenset)):
            raise TypeError("arguments must be sets, not %s" % type(value).__name__)


# spec: N-000481 N-000482
def accuracy(reference, test):
    """Fraction of positions at which the two lists hold equal values."""
    _check_lists(reference, test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy needs at least one position")
    matches = sum(1 for a, b in zip(reference, test) if a == b)
    return matches / len(reference)


# spec: N-000483 N-000484 N-000485 N-000308 N-000309 N-000310 N-000311
# spec: N-000312 N-000313 N-000314 N-000315 N-000330
def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance, or unrestricted Damerau-Levenshtein distance
    (Lowrance and Wagner) when ``transpositions`` is true."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    if not _is_number(substitution_cost):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be bool")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    previous = [float(j) if isinstance(substitution_cost, float) else j
                for j in range(len(s2) + 1)]
    for i, a in enumerate(s1, start=1):
        current = [i]
        for j, b in enumerate(s2, start=1):
            cost = 0 if a == b else substitution_cost
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost))
        previous = current
    return previous[-1]


def _damerau(a, b, substitution_cost):
    maxdist = len(a) + len(b)
    last_row = {}
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = maxdist
    for i in range(len(a) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            last_match_row = last_row.get(b[j - 1], 0)
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[last_match_row][last_match_col]
                + (i - last_match_row - 1) + 1 + (j - last_match_col - 1),
            )
        last_row[a[i - 1]] = i
    return d[len(a) + 1][len(b) + 1]


# spec: N-000486
def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union."""
    _check_sets(label1, label2)
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


# spec: N-000487 N-000488 N-000489 N-000327 N-000328
def precision(reference, test):
    """|reference & test| / |test|, or None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|, or None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


# spec: N-000316 N-000317 N-000329
def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either
    set is empty."""
    _check_sets(reference, test)
    if not _is_number(alpha) or not 0 <= alpha <= 1:
        raise ValueError("alpha must be a number between 0 and 1")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
