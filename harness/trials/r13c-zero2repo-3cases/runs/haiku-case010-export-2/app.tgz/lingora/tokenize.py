"""Word, punctuation and sentence tokenizers (FP-01)."""

import os
import re
from dataclasses import dataclass, field

from lingora import data

# ---------------------------------------------------------------------------
# Word/punctuation and whitespace tokenizers (no model needed)
# ---------------------------------------------------------------------------

# spec: N-000086 N-000087 N-000088
_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


def _spans_to_tokens(text, spans):
    return [text[start:end] for start, end in spans]


class WordPunctTokenizer:
    """Splits on the boundary between word and non-word characters."""

    # spec: N-000086 N-000087 N-000088 N-000131
    def tokenize(self, text):
        _check_text(text)
        return [m.group(0) for m in _WORDPUNCT.finditer(text)]

    def span_tokenize(self, text):
        _check_text(text)
        for m in _WORDPUNCT.finditer(text):
            yield (m.start(), m.end())


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Tokens are maximal runs of non-whitespace characters."""

    # spec: N-000108
    _pattern = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        for m in self._pattern.finditer(text):
            yield (m.start(), m.end())


def blankline_tokenize(text):
    """Segments of ``text`` separated by blank lines."""
    # spec: N-000109 N-000110
    _check_text(text)
    pieces = re.split(r"\s*\n\s*\n\s*", text)
    return [piece for piece in pieces if piece.strip()]


class RegexpTokenizer:
    """Tokens are the matches of ``pattern`` (token mode), or the pieces
    between matches (gap mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        if not isinstance(gaps, bool) or not isinstance(discard_empty, bool):
            raise TypeError("gaps and discard_empty must be bool")
        self._regex = re.compile(pattern)
        self.pattern = pattern
        self.gaps = gaps
        self.discard_empty = discard_empty

    # spec: N-000111 N-000112 N-000113
    def span_tokenize(self, text):
        _check_text(text)
        if self.gaps:
            spans = []
            pos = 0
            for m in self._regex.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regex.finditer(text)]
        for start, end in spans:
            if self.discard_empty and start >= end:
                continue
            yield (start, end)

    def tokenize(self, text):
        _check_text(text)
        if self.gaps:
            return [text[s:e] for s, e in self.span_tokenize(text)]
        return [m.group(0) for m in self._regex.finditer(text)
                if not (self.discard_empty and m.group(0) == "")]


# ---------------------------------------------------------------------------
# Penn Treebank and LINGORA's recommended word tokenizer
# ---------------------------------------------------------------------------

_OPEN_QUOTE = re.compile(r'(^|[\s(\[{<])"')
_TYPO_QUOTES = re.compile("([“”„‟‘’‚‛])")
_DASHES_STARS = re.compile("([‒–—―*])")
_SPECIALS = re.compile(r"([;@#$%&?!()\[\]{}])")
_ELLIPSIS = re.compile(r"\.\.\.")
_POINT_RUN = re.compile(r"\.{2,}")
_DOUBLE_HYPHEN = re.compile(r"--")
_COMMA_COLON = re.compile(r"([:,])(?!\d)")
_FINAL_POINT = re.compile(r"\.(['\")\]}]*\s*)$")
_NT = re.compile(r"(?i)(\S)(n't)\b")
_CLITIC = re.compile(r"(?i)(\w)('s|'m|'d|'ll|'re|'ve)\b")
_BARE_APOS = re.compile(r"(\w)'(?=\s|$)")
# Fused forms and the number of characters of the word kept in the first part.
_FUSED = [
    (re.compile(r"(?i)\bcannot\b"), 3),
    (re.compile(r"(?i)\bd'ye\b"), 2),
    (re.compile(r"(?i)\bgimme\b"), 3),
    (re.compile(r"(?i)\bgonna\b"), 3),
    (re.compile(r"(?i)\bgotta\b"), 3),
    (re.compile(r"(?i)\blemme\b"), 3),
    (re.compile(r"(?i)\bmore'n\b"), 4),
    (re.compile(r"(?i)\bwanna\b"), 3),
    (re.compile(r"(?i)'tis\b"), 2),
    (re.compile(r"(?i)'twas\b"), 2),
]


def _treebank_prepare(text, recommended):
    # Straight double quotes: opening after start, space or opening bracket.
    text = _OPEN_QUOTE.sub(lambda m: m.group(1) + " `` ", text)
    text = text.replace('"', " '' ")
    if recommended:
        # spec: N-000102 N-000103
        text = _TYPO_QUOTES.sub(r" \1 ", text)
        text = _DASHES_STARS.sub(r" \1 ", text)
    # spec: N-000094 N-000095
    text = _SPECIALS.sub(r" \1 ", text)
    if recommended:
        # spec: N-000104 N-000105
        text = _POINT_RUN.sub(lambda m: " %s " % m.group(0), text)
        text = _DOUBLE_HYPHEN.sub(lambda m: " %s " % m.group(0), text)
    else:
        text = _ELLIPSIS.sub(" ... ", text)
    # spec: N-000096
    text = _COMMA_COLON.sub(r" \1 ", text)
    # spec: N-000097
    text = _FINAL_POINT.sub(lambda m: " ." + m.group(1), text)
    # spec: N-000098 N-000100
    text = _NT.sub(r"\1 \2", text)
    text = _CLITIC.sub(r"\1 \2", text)
    text = _BARE_APOS.sub(r"\1 '", text)
    # spec: N-000099 (after the clitics, so "d'ye" splits into "d'" and "ye")
    for pattern, split_at in _FUSED:
        text = pattern.sub(
            lambda m, k=split_at: "%s %s" % (m.group(0)[:k], m.group(0)[k:]), text)
    return text


def _align_tokens(text, tokens):
    """Character spans of ``tokens`` found in order in ``text``."""
    spans = []
    pos = 0
    for token in tokens:
        candidates = ['"'] if token in ("``", "''") else [token]
        found = None
        for candidate in candidates:
            index = text.find(candidate, pos)
            if index != -1 and (found is None or index < found[0]):
                found = (index, index + len(candidate))
        if found is None:
            raise ValueError("token %r cannot be aligned with the text" % token)
        spans.append(found)
        pos = found[1]
    return spans


class TreebankWordTokenizer:
    """The Penn Treebank word tokenizer."""

    _recommended = False

    # spec: N-000089 N-000090 N-000091 N-000092 N-000093
    def tokenize(self, text):
        _check_text(text)
        return _treebank_prepare(text, self._recommended).split()

    def span_tokenize(self, text):
        _check_text(text)
        for start, end in _align_tokens(text, self.tokenize(text)):
            yield (start, end)


class _RecommendedWordTokenizer(TreebankWordTokenizer):
    """Treebank conventions plus LINGORA's improvements (N-000101..N-000105)."""

    _recommended = True


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]"
    r"|[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3|</3)"
)
_URL = r"(?:https?://|www\.)\S+"
_HASHTAG = r"#\w+"
_HANDLE = r"(?<!\w)@[A-Za-z0-9_]+"
_WORD = r"\w+(?:['’]\w+)*"
_TWEET_RE = re.compile(
    "|".join([_EMOTICON, _URL, _HASHTAG, _HANDLE, _WORD, r"\.{2,}", r"\S"]),
    re.IGNORECASE,
)
_EMOTICON_RE = re.compile(_EMOTICON + r"\Z", re.IGNORECASE)
_HANDLE_STRIP = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")


class TweetTokenizer:
    """Tokenizer for short social-media text."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        for value in (preserve_case, reduce_len, strip_handles):
            if not isinstance(value, bool):
                raise TypeError("tweet tokenizer options must be bool")
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    # spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120
    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self.reduce_len:
            text = re.sub(r"(.)\1{3,}", r"\1\1\1", text, flags=re.DOTALL)
        tokens = []
        for match in _TWEET_RE.finditer(text):
            token = match.group(0)
            if not self.preserve_case and not _EMOTICON_RE.match(token):
                token = token.lower()
            tokens.append(token)
        return tokens


# ---------------------------------------------------------------------------
# Punkt sentence tokenizer
# ---------------------------------------------------------------------------

_PUNKT_CACHE = {}
_CLOSERS = "\"')]}”’»"
_ORTHO_UPPER_START = 2
_ORTHO_LOWER_INSIDE = 32
_ORTHO_UPPER_INSIDE = 4


@dataclass
class PunktParameters:
    abbrev_types: set = field(default_factory=set)
    sent_starters: set = field(default_factory=set)
    collocations: set = field(default_factory=set)
    ortho_context: dict = field(default_factory=dict)


def _load_punkt(language):
    """Packaged Punkt parameters for ``language``. Raises if the model is not
    visible."""
    # spec: N-000124 N-000125
    if not isinstance(language, str) or not re.fullmatch(r"[A-Za-z_\-]+", language):
        raise ValueError("invalid language name %r" % (language,))
    directory = data.find("tokenizers/punkt_tab/%s" % language)
    if directory in _PUNKT_CACHE:
        return _PUNKT_CACHE[directory]

    def lines(name):
        # A missing file in a visible model directory counts as empty.
        try:
            with open(os.path.join(directory, name), encoding="utf-8") as handle:
                return handle.read().splitlines()
        except FileNotFoundError:
            return []

    params = PunktParameters()
    params.abbrev_types = {line.strip() for line in lines("abbrev_types.txt") if line.strip()}
    params.sent_starters = {line.strip() for line in lines("sent_starters.txt") if line.strip()}
    for line in lines("collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            params.collocations.add((parts[0], parts[1]))
    for line in lines("ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().isdigit():
            params.ortho_context[parts[0]] = int(parts[1])
    _PUNKT_CACHE[directory] = params
    return params


def _punkt_type(word):
    """Lowercased type of a token with its final period removed."""
    core = word.rstrip(_CLOSERS).lstrip("(['\"[{")
    if core.endswith("."):
        core = core[:-1]
    if re.fullmatch(r"[-+]?[\d.,]+", core):
        return "##number##"
    return core.lower()


def _first_alpha(word):
    core = word.lstrip("(['\"[{`")
    return core[:1]


def _is_period_end(word):
    core = word.rstrip(_CLOSERS)
    return core.endswith(".") and not core.endswith("..")


def _is_hard_end(word):
    return word.rstrip(_CLOSERS).endswith(("?", "!"))


def _sentence_spans(text, params):
    tokens = [(m.start(), m.end(), m.group(0)) for m in re.finditer(r"\S+", text)]
    spans = []
    if not tokens:
        return spans
    sent_start = tokens[0][0]
    for i, (start, end, word) in enumerate(tokens):
        last = i == len(tokens) - 1
        boundary = False
        if last:
            boundary = True
        elif _is_hard_end(word):
            boundary = True
        elif _is_period_end(word):
            boundary = _period_is_boundary(tokens[i + 1][2], _punkt_type(word), params)
        if boundary:
            spans.append((sent_start, end))
            if not last:
                sent_start = tokens[i + 1][0]
    return spans


def _period_is_boundary(next_word, typ, params):
    next_type = _punkt_type(next_word)
    first = _first_alpha(next_word)
    is_abbrev = typ in params.abbrev_types or (len(typ) == 1 and typ.isalpha())
    if typ != "##number##" and (typ, next_type) in params.collocations:
        return False
    if is_abbrev:
        return bool(first) and first.isupper() and next_type in params.sent_starters
    if first and first.islower():
        return False
    if first and first.isupper() and next_type not in params.sent_starters:
        flags = params.ortho_context.get(next_type, 0)
        if flags & _ORTHO_LOWER_INSIDE and not flags & _ORTHO_UPPER_START:
            return False
    return True


# spec: N-000124 N-000126 N-000127 N-000128
def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model."""
    _check_text(text)
    params = _load_punkt(language)
    return [text[start:end] for start, end in _sentence_spans(text, params)]


# ---------------------------------------------------------------------------
# Recommended word tokenizer and module-level helpers
# ---------------------------------------------------------------------------

def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    # spec: N-000106 N-000107 N-000083 N-000084 N-000085
    _check_text(text)
    tokenizer = _RecommendedWordTokenizer()
    if preserve_line:
        return tokenizer.tokenize(text)
    tokens = []
    for sentence in sent_tokenize(text, language):
        tokens.extend(tokenizer.tokenize(sentence))
    return tokens
