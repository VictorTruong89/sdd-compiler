import sys

from lingora.cli import main

if __name__ == "__main__":
    main(sys.argv[1:])
