"""Chunking with chunk grammars (FP-04)."""

import re

from lingora import data
from lingora.tree import Tree

SENTENCE_LABEL = "S"

# A rule's braces: "{...}" chunks, "}...{" chinks. A brace pair that is part
# of a quantifier ({2}, {1,3}) is allowed inside a pattern.
_PATTERN = re.compile(r"\s*(\{(?:[^{}]|\{[\d,\s]*\})*\}|\}(?:[^{}]|\{[\d,\s]*\})*\{)")
_HEADER = re.compile(r"^([^\s{}<>:]+)\s*:(.*)$")
_QUANTIFIER = r"(?:\?|\*|\+|\{\d*,?\d*\})?"


def _tag_regex(pattern):
    """Translate a tag pattern (elements ``<...>`` with quantifiers) into a
    regular expression over the encoded tag string, one ``<tag>`` per token."""
    text = re.sub(r"\s+", "", pattern)
    pieces = []
    i = 0
    while i < len(text):
        if text[i] != "<":
            raise ValueError("tag pattern element must start with '<': %r" % pattern)
        end = text.find(">", i)
        if end == -1:
            raise ValueError("unclosed '<' in tag pattern %r" % pattern)
        content = text[i + 1:end]
        # "." matches one character of a tag and never crosses a tag boundary.
        content = re.sub(r"(?<!\\)\.", r"[^<>]", content)
        element = "<(?:%s)>" % content
        i = end + 1
        match = re.match(_QUANTIFIER, text[i:])
        quantifier = match.group(0) if match else ""
        i += len(quantifier)
        pieces.append("(?:%s)%s" % (element, quantifier) if quantifier else element)
    return re.compile("".join(pieces))


class ChunkRule:
    """A chunk rule: every match becomes one chunk of the clause's label."""

    def __init__(self, pattern):
        self.pattern = pattern
        self.regex = _tag_regex(pattern)


class ChinkRule:
    """A chink rule: matching tokens are removed from the clause's chunks."""

    def __init__(self, pattern):
        self.pattern = pattern
        self.regex = _tag_regex(pattern)


class Clause:
    """A chunk label and its ordered chunk and chink rules."""

    def __init__(self, label, rules=None):
        self.label = label
        self.rules = list(rules or [])


def _parse_grammar(text):
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        header = None if raw[:1].isspace() else _HEADER.match(raw.strip())
        if header:
            current = Clause(header.group(1))
            clauses.append(current)
            body = header.group(2)
        else:
            if current is None:
                raise ValueError("chunk grammar line has no clause label: %r" % raw)
            body = raw
        position = 0
        while True:
            match = _PATTERN.match(body, position)
            if not match:
                break
            pattern = match.group(1)
            if pattern.startswith("{"):
                current.rules.append(ChunkRule(pattern[1:-1].strip()))
            else:
                current.rules.append(ChinkRule(pattern[1:-1].strip()))
            position = match.end()
        if body[position:].strip():
            raise ValueError("cannot read chunk grammar text: %r" % body[position:])
    return clauses


def _tag_of(item):
    if isinstance(item, Tree):
        return item.label()
    tag = item[1]
    return "" if tag is None else str(tag)


def _encode(items):
    """Encoded tag string and the character offset of each item boundary."""
    offsets = [0]
    parts = []
    for item in items:
        part = "<%s>" % _tag_of(item)
        parts.append(part)
        offsets.append(offsets[-1] + len(part))
    return "".join(parts), offsets


def _apply_chunk(items, rule, label, created):
    encoded, offsets = _encode(items)
    result = []
    i = 0
    while i < len(items):
        end = None
        # Longest match first, so that matches are as long as possible.
        for j in range(len(items), i, -1):
            if rule.regex.fullmatch(encoded, offsets[i], offsets[j]):
                end = j
                break
        if end is None:
            result.append(items[i])
            i += 1
        else:
            chunk = Tree(label, items[i:end])
            created.append(chunk)
            result.append(chunk)
            i = end
    return result


def _apply_chink(items, rule, label, created):
    result = []
    for item in items:
        if not (isinstance(item, Tree) and any(item is c for c in created)):
            result.append(item)
            continue
        children = list(item)
        encoded, offsets = _encode(children)
        pieces = []
        i = 0
        while i < len(children):
            end = None
            for j in range(len(children), i, -1):
                if rule.regex.fullmatch(encoded, offsets[i], offsets[j]):
                    end = j
                    break
            if end is None:
                pieces.append(("keep", children[i]))
                i += 1
            else:
                pieces.extend(("chinked", child) for child in children[i:end])
                i = end
        group = []
        for kind, child in pieces + [("chinked", None)]:
            if kind == "keep":
                group.append(child)
                continue
            if group:
                chunk = Tree(item.label(), group)
                created.append(chunk)
                result.append(chunk)
                group = []
            if child is not None:
                result.append(child)
    return result


# spec: N-000426 N-000427 N-000428 N-000429 N-000431 N-000433 N-000434
# spec: N-000435 N-000436 N-000438 N-000439 N-000440
class RegexpParser:
    """Chunk parser for a chunk grammar (text, or a list of ``Clause``)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(c, Clause) for c in grammar):
            self._clauses = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not isinstance(pair, (list, tuple)) or len(pair) != 2:
                raise TypeError("each tagged token must be a (token, tag) pair")
            items.append(tuple(pair))
        created = []
        for clause in self._clauses:
            clause_created = []
            for rule in clause.rules:
                if isinstance(rule, ChunkRule):
                    items = _apply_chunk(items, rule, clause.label, clause_created)
                else:
                    items = _apply_chink(items, rule, clause.label, clause_created)
            created.extend(clause_created)
        label = SENTENCE_LABEL
        if any(clause.label == label for clause in self._clauses):
            label = "SENT"
        return Tree(label, items)


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Needs the packaged chunker model and English
    wordlist; their results are outside this specification."""
    # spec: N-000432 N-000247
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError(
        "named-entity chunking results are outside this specification"
    )
