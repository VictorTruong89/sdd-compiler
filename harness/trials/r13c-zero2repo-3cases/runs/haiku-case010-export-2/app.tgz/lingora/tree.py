"""Constituent trees (FP-05)."""

import re


class Tree:
    """A labelled ordered tree. Children are leaves (strings, or other leaf
    objects such as (token, tag) pairs) or ``Tree`` nodes."""

    # spec: N-000268 N-000269 N-000270 N-000274 N-000275 N-000276 N-000277
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, list):
            raise TypeError("children must be a list of children, not %s"
                            % type(children).__name__)
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text: ``(label child ...)``."""
        # spec: N-000272 N-000469
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        position = 0

        def parse():
            nonlocal position
            if position >= len(tokens) or tokens[position] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            position += 1
            if position >= len(tokens) or tokens[position] in "()":
                raise ValueError("missing label in bracketed tree text")
            label = tokens[position]
            position += 1
            children = []
            while position < len(tokens) and tokens[position] != ")":
                if tokens[position] == "(":
                    children.append(parse())
                else:
                    children.append(tokens[position])
                    position += 1
            if position >= len(tokens):
                raise ValueError("unbalanced brackets in tree text")
            position += 1
            return cls(label, children)

        tree = parse()
        if position != len(tokens):
            raise ValueError("trailing text after tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        result = []
        for child in self._children:
            if isinstance(child, Tree):
                result.extend(child.leaves())
            else:
                result.append(child)
        return result

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    # spec: N-000465
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        parts = [str(self._label)]
        parts.extend(repr(child) for child in self._children)
        return "(%s)" % " ".join(parts)

    def _leaf_text(self, leaf):
        if isinstance(leaf, tuple) and len(leaf) == 2:
            return "%s/%s" % leaf
        return str(leaf)

    def _flat(self):
        parts = [str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(self._leaf_text(child))
        return "(%s)" % " ".join(parts)

    # spec: N-000470 N-000471 N-000273
    def pformat(self, margin=70, indent=0):
        flat = self._flat()
        if indent + len(flat) <= margin or not self._children:
            return " " * indent + flat
        lines = ["%s(%s" % (" " * indent, self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child.pformat(margin, indent + 2))
            else:
                lines.append(" " * (indent + 2) + self._leaf_text(child))
        lines[-1] += ")"
        return "\n".join(lines)
