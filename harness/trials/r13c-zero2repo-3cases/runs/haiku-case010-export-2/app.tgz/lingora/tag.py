"""Part-of-speech taggers (FP-03)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_CACHE = {}
_LANGUAGES = ("eng", "rus")

# spec: N-000413 N-000414 N-000415 N-000422
def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("every token must be a str, not %s" % type(token).__name__)


def _check_backoff(backoff):
    if backoff is not None and not hasattr(backoff, "tag"):
        raise TypeError("backoff must be a tagger or None")


class _SequentialTagger:
    """Base class: primary tags, then the backoff tagger fills the gaps."""

    backoff = None

    def _tag_primary(self, tokens):
        raise NotImplementedError

    # spec: N-000191 N-000192 N-000200 N-000201
    def tag(self, tokens):
        _check_tokens(tokens)
        primary = self._tag_primary(tokens)
        if self.backoff is None or all(tag is not None for _, tag in primary):
            return primary
        fallback = self.backoff.tag(list(tokens))
        return [
            (token, tag if tag is not None else fallback[i][1])
            for i, (token, tag) in enumerate(primary)
        ]


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    # spec: N-000193
    def __init__(self, tag):
        self._tag = tag

    def _tag_primary(self, tokens):
        return [(token, self._tag) for token in tokens]


class UnigramTagger(_SequentialTagger):
    """Assigns each trained word its most frequent training tag."""

    # spec: N-000194 N-000195 N-000196
    def __init__(self, train=None, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            for pair in sentence:
                token, tag = pair
                counts[token][tag] += 1
        # Ties go to the alphabetically first tag, so training is deterministic.
        self._model = {
            token: min(tag_counts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0]
            for token, tag_counts in counts.items()
        }

    def _tag_primary(self, tokens):
        return [(token, self._model.get(token)) for token in tokens]


class RegexpTagger(_SequentialTagger):
    """The first rule whose pattern matches a token at its start gives the tag."""

    # spec: N-000197 N-000198 N-000199
    def __init__(self, regexps, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def _tag_primary(self, tokens):
        tagged = []
        for token in tokens:
            tag = None
            for regex, rule_tag in self._rules:
                if regex.match(token):
                    tag = rule_tag
                    break
            tagged.append((token, tag))
        return tagged


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended English and Russian tagger)
# ---------------------------------------------------------------------------

def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            for label, weight in self.weights.get(feat, {}).items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        tagged = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(_features(i, word, context, prev, prev2))
            tagged.append((word, tag))
            prev2 = prev
            prev = tag
        return tagged


def _load_perceptron(lang):
    # Visibility is checked on every call: the cache is keyed by the
    # resolved directory, so removing the model from data.path still fails.
    directory = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    if directory in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[directory]
    stem = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
    with open(stem + ".weights.json", encoding="utf-8") as handle:
        weights = json.load(handle)
    with open(stem + ".tagdict.json", encoding="utf-8") as handle:
        tagdict = json.load(handle)
    with open(stem + ".classes.json", encoding="utf-8") as handle:
        classes = json.load(handle)
    model = _Perceptron(weights, tagdict, classes)
    _PERCEPTRON_CACHE[directory] = model
    return model


def _load_universal_english():
    mapping = {}
    for line in data.read_lines("taggers/universal_tagset/en-ptb.map"):
        parts = line.split("\t")
        if len(parts) == 2:
            mapping[parts[0]] = parts[1]
    return mapping


# Russian National Corpus part-of-speech categories -> universal tagset.
_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "COM": "ADJ",
    "ADV": "ADV", "ADVPRO": "ADV", "PRAEDIC": "ADV", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM", "SPRO": "PRON",
    "PRAEDIC_PRO": "PRON", "APRO": "DET", "INTJ": "X", "PARENTH": "X",
}


def _rnc_universal(tag):
    category = tag.split("=")[0].split(",")[0]
    return _RNC_TO_UNIVERSAL.get(category, "X")


# spec: N-000202 N-000203 N-000204 N-000205 N-000206 N-000207 N-000208
# spec: N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000215
# spec: N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222
def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the averaged perceptron tagger for ``lang``."""
    _check_tokens(tokens)
    if lang not in _LANGUAGES:
        raise ValueError("pos_tag supports only %s, not %r" % (", ".join(_LANGUAGES), lang))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    model = _load_perceptron(lang)
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_universal_english()
            tagged = [(token, mapping.get(tag)) for token, tag in tagged]
        else:
            tagged = [(token, _rnc_universal(tag)) for token, tag in tagged]
    return tagged
