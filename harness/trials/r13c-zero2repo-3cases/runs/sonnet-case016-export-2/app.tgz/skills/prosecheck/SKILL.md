---
name: prosecheck
description: Score prose for AI-writing patterns with scripts/detect.py and fix flagged spans.
---
Run `python3 scripts/detect.py <file>` from the plugin root to score a prose file, or `--clean` to print scrubbed text.
Rewrites are done by the host agent; the detector only reports.
