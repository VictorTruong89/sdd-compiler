# prosecheck

Local, standard-library detector for AI-writing patterns plus Node.js plugin hooks. No build step.

- `python3 scripts/detect.py [--clean] [--ci] [--] [FILE]`
- Hooks under `hooks/`: session start, prompt submit (`/prosecheck` router), subagent start, post-tool-use guard, stats.
