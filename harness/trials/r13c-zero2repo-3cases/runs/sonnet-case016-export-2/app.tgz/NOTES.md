# Implementation notes

- `scripts/detect.py`: detector (FP-01..03). `hooks/*.js`: FP-04..06 (`prosecheck-common.js` and `prosecheck-contract.js` are shared helpers).
- Scoring weights, the hyphenated-cliché list, the marketing-phrase list, the resampling count/seed, and failure/ledger wording are implementer choices left open by the spec.
- Not done: a Windows-specific launcher (`py` is tried after `python3` and `python`); no PDF/RTF extraction by design.
