import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, "scripts", "detect.py")


def detect(text, *args):
    return subprocess.run([sys.executable, DETECT, *args], input=text.encode(), capture_output=True)


class DetectorTests(unittest.TestCase):
    def test_N_000608_usage_first_line(self):
        p = detect("", "--help")
        self.assertEqual(p.stdout.decode().splitlines()[0], "usage: detect.py [--clean] [--ci] [--] [FILE]")

    def test_N_000672_empty_input(self):
        p = detect("  \n")
        self.assertEqual(p.returncode, 1)
        self.assertEqual(json.loads(p.stderr.decode().strip().splitlines()[-1]), {"error": "empty input"})

    def test_N_000292_cleanup_rescan_zero_invisible(self):
        out = detect("a​b  c dеlve  \n", "--clean").stdout.decode()
        m = json.loads(detect(out).stdout)["_metrics"]
        self.assertEqual((m["invisible_chars"], m["nonstandard_spaces"], m["homoglyphs"]), (0, 0, 0))

    def test_report_shape(self):
        r = json.loads(detect("We delve into a rich tapestry, showcasing a robust landscape.").stdout)
        self.assertIn("1_ai_vocabulary", r)
        self.assertEqual(r["_metrics"]["patterns_flagged"], len([k for k in r if k != "_metrics"]))

    def test_unknown_option(self):
        p = detect("x", "--nope")
        self.assertEqual(p.returncode, 2)


class HookTests(unittest.TestCase):
    def run_tracker(self, prompt, cfg):
        env = dict(os.environ, CLAUDE_CONFIG_DIR=cfg)
        p = subprocess.run(["node", os.path.join(ROOT, "hooks", "prosecheck-tracker.js")],
                           input=json.dumps({"prompt": prompt}).encode(), capture_output=True, env=env)
        return p.stdout.decode()

    def test_level_roundtrip(self):
        with tempfile.TemporaryDirectory() as cfg:
            self.run_tracker("/prosecheck strict", cfg)
            self.assertIn("strict", json.loads(self.run_tracker("/prosecheck status", cfg))["reason"])
            self.run_tracker("stop prosecheck", cfg)
            self.assertEqual(self.run_tracker("hello", cfg), "")


if __name__ == "__main__":
    unittest.main()
