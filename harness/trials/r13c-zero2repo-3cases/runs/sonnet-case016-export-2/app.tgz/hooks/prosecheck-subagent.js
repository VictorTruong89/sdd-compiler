'use strict';
// subagent-start hook: the same contract inside the SubagentStart envelope.
const C = require('./prosecheck-common');
const { contract } = require('./prosecheck-contract');

function main() {
  C.readStdinJson();
  const level = C.getLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: contract(level) },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
