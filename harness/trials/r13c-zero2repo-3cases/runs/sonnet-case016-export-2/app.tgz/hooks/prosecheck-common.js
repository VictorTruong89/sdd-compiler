'use strict';
// Shared helpers for the prosecheck hooks. Standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_KB = 512;
const ARCHIVE_KB = 4096;
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const BINARY_EXTS = ['.pdf', '.rtf'];
const THRESHOLDS = { full: 40, strict: 20 };
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (isFile(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (isFile(b)) return b;
  return null;
}

function isFile(p) {
  try { return fs.statSync(p).isFile(); } catch (e) { return false; }
}

function readStdinJson() {
  try {
    const raw = fs.readFileSync(0, 'utf8');
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readFlag() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.indexOf(v) >= 0 ? v : null;
  } catch (e) {
    return null;
  }
}

function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}

function getLevel() {
  return readFlag() || envDefault() || 'full';
}

function writeFlag(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level, { mode: 0o600 });
    return true;
  } catch (e) {
    return false;
  }
}

// ---- ledger
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;

function ledgerPath(sessionId) {
  let name = '.prosecheck-ledger';
  if (sessionId && typeof sessionId === 'string') {
    name += '-' + sessionId.replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
  }
  return path.join(configDir(), name);
}

function purgeLedgers() {
  try {
    const dir = configDir();
    const now = Date.now();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.indexOf('.prosecheck-ledger-') === 0) {
        try {
          const st = fs.statSync(path.join(dir, f));
          if (now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(path.join(dir, f));
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

function readLedger(sessionId) {
  try {
    const p = ledgerPath(sessionId);
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) return [];
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) {
    return [];
  }
}

function addLedger(sessionId, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const rows = readLedger(sessionId);
    rec.t = Date.now();
    rows.push(rec);
    const keep = rows.slice(-20);
    const p = ledgerPath(sessionId);
    fs.writeFileSync(p, JSON.stringify(keep), { mode: 0o600 });
    try { fs.chmodSync(p, 0o600); } catch (e) { /* ignore */ }
  } catch (e) { /* ignore */ }
}

// ---- detector
function runDetector(args, opts) {
  const det = opts.detector || detectorPath();
  if (!det) return { status: 'nodetector' };
  let launched = false;
  let last = null;
  for (const name of ['python3', 'python', 'py']) {
    const r = cp.spawnSync(name, [det].concat(args), {
      input: opts.input, timeout: opts.timeout || 8000, encoding: 'utf8', env: process.env,
      maxBuffer: 64 * 1024 * 1024, cwd: opts.cwd || undefined,
    });
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES')) continue;
    launched = true;
    last = r;
    if (r.error && r.error.code === 'ETIMEDOUT') return { status: 'timeout' };
    if (r.error) continue;
    return { status: 'ran', code: r.status, signal: r.signal, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  if (!launched) return { status: 'nopython' };
  if (last && last.error && last.error.code === 'ETIMEDOUT') return { status: 'timeout' };
  return { status: 'ran', code: last ? last.status : null, signal: last ? last.signal : null, stdout: '', stderr: '' };
}

function parseReport(out) {
  try {
    const v = JSON.parse(out);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* not a report */ }
  return null;
}

function phraseFor(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

function fileKind(file) {
  const ext = path.extname(file).toLowerCase();
  if (PLAIN_EXTS.indexOf(ext) >= 0) return 'plain';
  if (ARCHIVE_EXTS.indexOf(ext) >= 0) return 'archive';
  if (BINARY_EXTS.indexOf(ext) >= 0) return 'binary';
  return 'other';
}

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const v = report[k];
    if (v && typeof v === 'object' && typeof v.label === 'string') out.push({ label: v.label, count: Number(v.count) || 0 });
  }
  return out;
}

module.exports = {
  LEVELS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_KB, ARCHIVE_KB, PLAIN_EXTS, ARCHIVE_EXTS, BINARY_EXTS,
  THRESHOLDS, BANNED, configDir, pluginRoot, detectorPath, isFile, readStdinJson, readFlag, envDefault, getLevel,
  writeFlag, flagPath, ledgerPath, purgeLedgers, readLedger, addLedger, runDetector, parseReport, phraseFor, fileKind,
  findings,
};
