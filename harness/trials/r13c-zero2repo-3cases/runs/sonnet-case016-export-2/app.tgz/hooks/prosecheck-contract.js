'use strict';
// The writing contract, per level. `portable` builds the exported form (no machine paths).
const path = require('path');
const C = require('./prosecheck-common');

function contract(level, opts) {
  opts = opts || {};
  const portable = !!opts.portable;
  const L = [];
  L.push('Writing contract for prose deliverables.');
  L.push('Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.');
  L.push('Never apply it to source code, code comments, commit messages, JSON, YAML, or other configuration, CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.');
  L.push('Vary sentence length irregularly: no metronome, no mechanical short-long alternation.');
  L.push('Banned vocabulary: ' + C.BANNED.join(', ') + '.');
  L.push('Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting ("let\'s dive in"); empty pivots ("it\'s worth noting"); "In conclusion" and "Overall" closers; outcome-speculation tails; self-thoroughness; generic upbeat endings; chatbot phrases ("I hope this helps").');
  L.push('Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('Factual and encyclopedic content stays neutral third person; first-person and opinion content may use contractions.');
  L.push('Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts. End sections on a fact or observation.');
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict'
      ? 'Target: the clean band (score at most ' + C.THRESHOLDS.strict + ').'
      : 'Target: the clean or light tells band (score at most ' + C.THRESHOLDS.full + ').';
    if (portable) {
      L.push('After writing a prose file, run the detector on that file, and fix the flagged spans when the band is worse than the target (at most two fix passes, keeping rhythm variation).');
      L.push('Resolving the detector: use $CLAUDE_PLUGIN_ROOT/scripts/detect.py when CLAUDE_PLUGIN_ROOT is set; otherwise locate prosecheck\'s detector in installed skills and plugins.');
    } else {
      const det = C.detectorPath() || path.join(C.pluginRoot(), 'scripts', 'detect.py');
      L.push('After writing a prose file, run the detector on that file: python3 "' + det + '" <file>. When the band is worse than the target, fix the flagged spans (at most two fix passes, keeping rhythm variation).');
    }
    L.push(target);
    if (level === 'strict') {
      L.push('Finish with a scrub of the saved file through --clean (python3 detect.py --clean <file>, writing the result to a new file, then replacing the original).');
    }
  }
  L.push('Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  return L.join('\n');
}

module.exports = { contract };
