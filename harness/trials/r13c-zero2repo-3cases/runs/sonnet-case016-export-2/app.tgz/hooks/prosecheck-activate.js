'use strict';
// session-start hook: prints the writing contract (plus a one-time welcome on a fresh install).
const fs = require('fs');
const C = require('./prosecheck-common');
const { contract } = require('./prosecheck-contract');

function welcome() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented patterns.',
    'Plain text is accepted up to ' + C.PLAIN_KB + ' KB and archives up to 4 MB; the detector scores the first ' + C.WINDOW_TXT + ' characters.',
    'There is no website and no upload; everything stays on this machine.',
    'Commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'This note is shown once.',
    '',
  ].join('\n');
}

function main() {
  C.readStdinJson();
  C.purgeLedgers();
  let fresh = false;
  let level = C.readFlag();
  if (!level) {
    level = C.envDefault() || 'full';
    let exists = false;
    try { fs.statSync(C.flagPath()); exists = true; } catch (e) { exists = false; }
    const wrote = C.writeFlag(level);
    fresh = wrote && !exists;
  }
  if (level === 'off') return;
  let out = '';
  if (fresh) out += welcome() + '\n';
  out += contract(level) + '\n';
  process.stdout.write(out);
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
