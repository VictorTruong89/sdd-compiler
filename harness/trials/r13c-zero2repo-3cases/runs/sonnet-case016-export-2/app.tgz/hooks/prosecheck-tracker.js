'use strict';
// prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common');
const { contract } = require('./prosecheck-contract');
const { statsReply } = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function setLevel(level) {
  C.writeFlag(level);
}

// ---- help
function helpReply(level) {
  return [
    'prosecheck is active at level: ' + level + '.',
    'It never touches code, commits, config, or chat; only prose deliverables.',
    '',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus saved-file guard, threshold ' + C.THRESHOLDS.full + ' (default)',
    '/prosecheck strict - contract plus guard at threshold ' + C.THRESHOLDS.strict + ', with a scrub through the cleanup switch',
    '/prosecheck off - disable prosecheck',
    '/prosecheck on - re-enable prosecheck',
    '/prosecheck status - show the current level',
    '/prosecheck show - list files scored in this session',
    '/prosecheck check - score one file and report only, no rewrite',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the score of this session\'s prose',
    '/prosecheck init - export the contract to AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

// ---- check
function parsePath(arg) {
  let a = (arg || '').trim();
  if (a.startsWith('@')) a = a.slice(1).trim();
  if (a.length >= 2 && (a[0] === '"' || a[0] === "'") && a[a.length - 1] === a[0]) a = a.slice(1, -1);
  return a;
}

function checkReply(arg) {
  const p = parsePath(arg);
  if (!p) return 'Give a file path to score, for example: /prosecheck check notes.md (report only; nothing is rewritten).';
  const abs = path.resolve(p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + p; }
  if (!st.isFile()) return p + ' is not a file';
  const kind = C.fileKind(abs);
  if (kind === 'binary') return base + ' has no readable text for prosecheck.';
  const cap = kind === 'archive' ? C.ARCHIVE_CAP : C.PLAIN_CAP;
  if (st.size > cap) return base + ' is over ' + (cap / 1024) + ' KB and was not scored.';
  const r = C.runDetector([abs], { timeout: kind === 'archive' ? 15000 : 8000 });
  if (r.status === 'nopython' || r.status === 'nodetector') return 'detector unavailable: python or the bundled script could not be run, so ' + base + ' was not scored.';
  if (r.status === 'timeout') return base + ' failed: the detector timed out.';
  if (r.code !== 0) {
    const e = (r.stderr || '').trim();
    return base + ' failed' + (e ? ': ' + e : ' (the detector exited with an error)');
  }
  const out = (r.stdout || '').trim();
  if (!out) return base + ' - the detector produced no report.';
  const rep = C.parseReport(out);
  if (!rep || !rep._metrics || typeof rep._metrics.ai_tell_score !== 'number') return 'The detector gave no report (its output was not a report).';
  const m = rep._metrics;
  const score = Math.round(m.ai_tell_score);
  const lines = [];
  lines.push(base + ' - ' + C.phraseFor(m.ai_tell_band) + ' (score ' + score + '/100, band: ' + m.ai_tell_band + ')');
  lines.push('confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated === true) lines.push('coverage: first ' + C.WINDOW_TXT + ' characters only');
  const f = C.findings(rep).slice(0, 8);
  lines.push(f.length ? 'tells: ' + f.map((x) => x.label + ' (x' + x.count + ')').join('; ') : 'tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ---- doctor
function doctorReply(form) {
  const level = C.getLevel();
  const lines = [];
  lines.push('prosecheck health check');
  let okMode = level !== 'off';
  lines.push(okMode ? '[OK] mode: ' + level : '[--] mode: off - turned off; run /prosecheck on to switch it back on');
  const det = C.detectorPath();
  const okDet = !!det;
  lines.push(okDet ? '[OK] detector: bundled script found in the plugin tree' : '[!!] detector: bundled script missing from the plugin tree');
  let okPy = false;
  if (!det) {
    lines.push('[!!] python: not run, because the bundled detector is missing');
  } else {
    const sample = 'This is a short sample of plain prose used to check that the install works. It has a few ordinary sentences, nothing more.';
    const r = C.runDetector([], { input: sample, timeout: 15000 });
    if (r.status === 'nopython') {
      lines.push('[!!] python not found: saved files are not re-scored until Python is available; prose is still shaped by the contract.');
    } else if (r.status === 'ran' && r.code === 0) {
      const rep = C.parseReport((r.stdout || '').trim());
      if (rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number') {
        okPy = true;
        lines.push('[OK] python: ran the bundled detector and got a numeric score');
      } else {
        lines.push('[!!] python: ran the detector but the result was not a numeric score');
      }
    } else {
      lines.push('[!!] python: the detector run failed or timed out and gave no numeric score');
    }
  }
  let okSet = false;
  try {
    const dir = C.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const t = path.join(dir, '.prosecheck-doctor-' + process.pid);
    fs.writeFileSync(t, 'x');
    fs.unlinkSync(t);
    okSet = true;
  } catch (e) { okSet = false; }
  lines.push(okSet ? '[OK] settings: folder is writable' : '[!!] settings: folder is not writable');
  const others = okDet && okPy && okSet;
  let closer;
  if (others && okMode) {
    closer = 'prosecheck is active. Saved plain text up to ' + C.PLAIN_KB + ' KB and archives up to 4 MB are scored, on the first ' + C.WINDOW_TXT +
      ' characters. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (others && !okMode) {
    closer = 'The install is healthy, but while it is off, saving files triggers no scoring. Run ' + form + ' on to have saved files scored again.';
  } else {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  }
  lines.push(closer);
  return lines.join('\n');
}

// ---- show
function showReply(sid) {
  purgeSafe();
  const rows = C.readLedger(sid).map((r, i) => ({ r, i })).sort((a, b) => (b.r.t - a.r.t) || (b.i - a.i)).map((x) => x.r);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Files checked in this session, newest first:'];
  for (const r of rows) {
    let body;
    if (r.kind === 'scored') {
      body = (r.phrase || C.phraseFor(r.band)) + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + C.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = (r.labels || []).slice(0, 5);
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + labels.join('; ');
    } else if (r.kind === 'skipped') {
      body = 'not scored: larger than the ' + r.kb + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary format, not re-scored';
    } else {
      body = 'not scored: ' + String(r.reason || 'the check failed').replace(/\b\d+\b/g, '');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

function purgeSafe() { try { C.purgeLedgers(); } catch (e) { /* ignore */ } }

// ---- init
const MARK_BEGIN = '<!-- prosecheck:begin -->';
const MARK_END = '<!-- prosecheck:end -->';

function initReply(form) {
  const level = C.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  const section = MARK_BEGIN + '\n## Prose contract (prosecheck)\n\n' + contract(level, { portable: true }) + '\n' + MARK_END + '\n';
  let existing = null;
  let readErr = false;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readErr = true;
  }
  if (readErr) {
    lines.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing !== null && (existing.indexOf(MARK_BEGIN) >= 0 || existing.indexOf('Banned vocabulary: delve, tapestry') >= 0)) {
    lines.push('The contract is already present in AGENTS.md; it was not changed.');
  } else {
    let next;
    if (existing === null || existing === '') next = section;
    else next = existing + (existing.endsWith('\n') ? '' : '\n') + '\n' + section;
    try {
      fs.writeFileSync(agents, next);
      lines.push('Wrote the writing contract (' + level + ') into AGENTS.md.');
    } catch (e) {
      lines.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const rel = path.join('.cursor', 'rules', 'prosecheck.mdc');
  const dest = path.join(cwd, rel);
  if (C.isFile(dest)) {
    lines.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    const src = path.join(C.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    try {
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data, { flag: 'wx' });
      lines.push('Copied the Cursor rule to ' + rel.split(path.sep).join('/') + '.');
    } catch (e) {
      lines.push('cannot write the Cursor rule ' + rel.split(path.sep).join('/') + '.');
    }
  }
  return lines.join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand: ' + word + '. Valid subcommands: ' + SUBS.join(', ') + '.';
}

function main() {
  const ev = C.readStdinJson();
  const prompt = typeof ev.prompt === 'string' ? ev.prompt : '';
  const sid = typeof ev.session_id === 'string' ? ev.session_id : '';
  const trimmed = prompt.trim();
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/.exec(trimmed);
  if (m) {
    const form = m[1];
    const rest = (m[2] || '').trim();
    const sp = rest.match(/^(\S+)\s*([\s\S]*)$/);
    const word = sp ? sp[1].toLowerCase() : 'help';
    const arg = sp ? sp[2].trim() : '';
    const level = C.getLevel();
    switch (word) {
      case 'help': return block(helpReply(level));
      case 'lite': case 'full': case 'strict':
        setLevel(word);
        return block('prosecheck level set to ' + word + '.');
      case 'off':
        setLevel('off');
        return block('prosecheck is now off.');
      case 'on':
        setLevel('full');
        return block('prosecheck is turned on, at level full.');
      case 'status': return block('prosecheck level: ' + level);
      case 'show': return block(showReply(sid));
      case 'check': return block(checkReply(arg));
      case 'doctor': return block(doctorReply(form));
      case 'stats': return block(statsReply(level, ev.transcript_path));
      case 'init': return block(initReply(form));
      default: return block(unknownReply(sp ? sp[1] : word));
    }
  }
  if (/^(stop prosecheck|prosecheck off)$/i.test(trimmed)) {
    setLevel('off');
    return block('prosecheck is now off.');
  }
  const level = C.getLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'Prose deliverables follow the writing contract at level ' + level + '; code, config, and commits are untouched.',
    },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
