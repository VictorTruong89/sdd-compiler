'use strict';
// stats: session token use and an own-prose score from the transcript.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common');

function newestTranscript() {
  const base = path.join(C.configDir(), 'projects');
  let best = null;
  let bestT = -1;
  function walk(dir, depth) {
    let ents;
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestT) { bestT = t; best = p; }
        } catch (err) { /* ignore */ }
      }
    }
  }
  walk(base, 0);
  return best;
}

function textOf(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  const out = [];
  for (const c of content) {
    if (c && typeof c === 'object' && c.type === 'text' && typeof c.text === 'string') out.push(c.text);
    else if (typeof c === 'string') out.push(c);
  }
  return out.join('\n');
}

function stripFences(text) {
  const out = [];
  let fence = null;
  for (const ln of text.split('\n')) {
    if (fence) {
      const m = /^ {0,3}(`{3,}|~{3,})[ \t]*$/.exec(ln);
      if (m && m[1][0] === fence.ch && m[1].length >= fence.len) fence = null;
      continue;
    }
    const o = /^ {0,3}(`{3,}|~{3,})/.exec(ln);
    if (o) { fence = { ch: o[1][0], len: o[1].length }; continue; }
    out.push(ln);
  }
  return out.join('\n');
}

function analyzeTranscript(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { return null; }
  const seen = new Set();
  let turns = 0;
  let outTok = 0;
  let cacheTok = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const t = textOf(msg.content);
    if (t) texts.push(t);
    const id = msg.id;
    if (id !== undefined && id !== null && id !== '') {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outTok += Number(u.output_tokens) || 0;
    cacheTok += Number(u.cache_read_input_tokens) || 0;
  }
  let prose = stripFences(texts.join('\n'));
  prose = prose.slice(-40000);
  return { turns, outTok, cacheTok, prose };
}

function statsReply(level, transcriptPath) {
  let file = typeof transcriptPath === 'string' && transcriptPath ? transcriptPath : newestTranscript();
  const info = file ? analyzeTranscript(file) : null;
  if (!info) {
    return 'prosecheck stats: no readable transcript was found, so there are no session figures to show.';
  }
  const lines = [];
  lines.push('prosecheck session stats');
  lines.push('level: ' + level);
  lines.push('assistant turns: ' + info.turns);
  lines.push('output tokens: ' + info.outTok);
  lines.push('cache-read input tokens: ' + info.cacheTok);
  const trimmed = info.prose.trim();
  if (trimmed.length > 200) {
    const r = C.runDetector([], { input: trimmed, timeout: 15000 });
    if (r.status === 'ran') {
      const rep = C.parseReport((r.stdout || '').trim());
      if (rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number') {
        lines.push('session prose ai_tell_score: ' + Math.round(rep._metrics.ai_tell_score));
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply, analyzeTranscript, newestTranscript };

if (require.main === module) {
  try {
    const ev = C.readStdinJson();
    process.stdout.write(statsReply(C.getLevel(), ev.transcript_path) + '\n');
  } catch (e) { /* never fail the host */ }
  process.exitCode = 0;
}
