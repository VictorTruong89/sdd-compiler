'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common');

const INSTR_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const TOOLS = ['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch', 'applypatch'];

function patchPaths(body) {
  const out = [];
  const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/;
  for (const line of String(body).split(/\r?\n/)) {
    const m = re.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && out.indexOf(p) < 0) out.push(p);
    }
  }
  return out;
}

function extractPaths(ev) {
  const ti = ev.tool_input && typeof ev.tool_input === 'object' ? ev.tool_input : {};
  const tool = String(ev.tool_name || '').toLowerCase();
  if (TOOLS.indexOf(tool) < 0) return [];
  if (tool === 'apply_patch' || tool === 'applypatch') {
    let body = ti.command;
    if (Array.isArray(body)) body = body.join('\n');
    if (typeof body !== 'string') body = typeof ti.input === 'string' ? ti.input : (typeof ti.patch === 'string' ? ti.patch : '');
    return patchPaths(body).slice(0, 16);
  }
  const cand = tool === 'notebookedit' ? (ti.notebook_path || ti.file_path) : ti.file_path;
  return typeof cand === 'string' && cand.trim() ? [cand] : [];
}

function isSkipped(abs) {
  const parts = abs.split(/[\\/]+/);
  const dirs = parts.slice(0, -1);
  for (const d of dirs) if (d === 'node_modules' || d === '.git' || d === 'memory') return true;
  const root = path.resolve(C.pluginRoot());
  const rel = path.relative(root, abs);
  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTR_NAMES.indexOf(base) >= 0) return true;
  const ext = path.extname(base);
  if (INSTR_STEMS.indexOf(base) >= 0) return true;
  if (ext && INSTR_STEMS.indexOf(base.slice(0, -ext.length)) >= 0 && ['other', 'binary'].indexOf(C.fileKind(base)) >= 0) return true;
  return false;
}

function failure(reason) { return { kind: 'failed', reason }; }

function score(abs, kind) {
  const r = C.runDetector([abs], { timeout: kind === 'plain' ? 8000 : 15000 });
  if (r.status === 'nodetector') return failure('detector not found');
  if (r.status === 'nopython') return failure('python not found');
  if (r.status === 'timeout') return failure('detector timed out');
  if (r.signal && !r.stdout) return failure('detector timed out');
  const out = (r.stdout || '').trim();
  if (!out) return failure('detector produced no output or no usable result');
  const rep = C.parseReport(out);
  if (!rep) return failure('detector printed text that is not a structured report');
  const m = rep._metrics;
  if (!m || typeof m.ai_tell_score !== 'number') return failure('report has no numeric score');
  return { kind: 'ok', report: rep, metrics: m };
}

function handle(abs, level, sid, lines) {
  if (isSkipped(abs)) return;
  const kind = C.fileKind(abs);
  if (kind === 'other') return;
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) {
    C.addLedger(sid, { base, kind: 'failed', reason: 'file could not be read (unreadable or missing)' });
    return;
  }
  if (!st.isFile()) return;
  if (kind === 'binary') {
    C.addLedger(sid, { base, kind: 'binary' });
    return;
  }
  const cap = kind === 'plain' ? C.PLAIN_CAP : C.ARCHIVE_CAP;
  if (st.size > cap) {
    C.addLedger(sid, { base, kind: 'skipped', kb: cap / 1024 });
    return;
  }
  const res = score(abs, kind);
  if (res.kind === 'failed') {
    C.addLedger(sid, { base, kind: 'failed', reason: res.reason });
    return;
  }
  const m = res.metrics;
  const score_ = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const threshold = C.THRESHOLDS[level];
  const flagged = score_ > threshold && m.confidence !== 'none';
  const fl = C.findings(res.report).sort((a, b) => b.count - a.count);
  const labels = fl.map((f) => f.label).filter((l) => l.indexOf(';') < 0 && l.indexOf(':') < 0).slice(0, 5);
  const truncated = m.truncated === true;
  C.addLedger(sid, { base, kind: 'scored', score: score_, band, phrase: C.phraseFor(band), labels, flagged, truncated });
  if (flagged) {
    const cov = truncated ? ', first ' + C.WINDOW_TXT + ' characters only' : '';
    const lab = labels.length ? labels.join('; ') : 'patterns';
    lines.push('prosecheck: ' + base + ' ' + C.phraseFor(band) + ' (score ' + score_ + ', band ' + band + cov + '). Flagged: ' +
      lab + '. Please fix the flagged spans, keeping sentence-length variation.');
  }
}

function main() {
  const ev = C.readStdinJson();
  C.purgeLedgers();
  const level = C.getLevel();
  if (level !== 'full' && level !== 'strict') return;
  const sid = typeof ev.session_id === 'string' ? ev.session_id : '';
  const cwd = typeof ev.cwd === 'string' && ev.cwd ? ev.cwd : process.cwd();
  const seen = new Set();
  const lines = [];
  for (const p of extractPaths(ev).slice(0, 16)) {
    const abs = path.resolve(cwd, p);
    if (seen.has(abs)) continue;
    seen.add(abs);
    try { handle(abs, level, sid, lines); } catch (e) { /* ignore one file */ }
  }
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }));
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
