#!/usr/bin/env python3
"""prosecheck detector: local, standard-library prose-pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import sys
import time
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Scores prose for AI-writing patterns (0-100) and prints a JSON report.\n"
    "  --clean   print scrubbed text instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        end of options\n"
    "  FILE      one file path; with no FILE, standard input is read\n"
)

WINDOW = 262144
PLAIN_EXTS = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXTS = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXTS = {".ipynb"}
NO_PROSE_EXTS = {".pdf", ".rtf"}
MEMBER_LIMIT = 64 * 1024 * 1024

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]


def band_of(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return BANDS[-1][1]


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# ---------------------------------------------------------------- decoding

def decode_bytes(data):
    # spec: N-000601 N-000602 N-000603
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", "replace")
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        try:
            return data.decode("utf-16")
        except UnicodeDecodeError:
            return data[2:].decode("utf-16-le" if data[:2] == b"\xff\xfe" else "utf-16-be", "replace")
    if b"\x00" in data:
        return ""
    return data.decode("utf-8", "replace")


# ---------------------------------------------------------------- extraction

def lname(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def natkey(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def read_member(zf, info):
    if info.file_size > MEMBER_LIMIT:
        return None
    return zf.read(info)


def parse_xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def gather(el, skip, special=None):
    out = []
    if el.text:
        out.append(el.text)
    for ch in el:
        n = lname(ch.tag)
        if n in skip:
            pass
        elif special and n in special:
            out.append(special[n](ch))
        else:
            out.append(gather(ch, skip, special))
        if ch.tail:
            out.append(ch.tail)
    return "".join(out)


def ooxml_paras(root):
    paras = []
    for el in root.iter():
        if lname(el.tag) != "p":
            continue
        buf = []

        def walk(e):
            for ch in e:
                n = lname(ch.tag)
                if n == "p":
                    continue
                if n == "t":
                    buf.append(ch.text or "")
                elif n == "tab":
                    buf.append("\t")
                elif n in ("br", "cr"):
                    buf.append("\n")
                elif n in ("delText", "instrText"):
                    continue
                else:
                    walk(ch)
        walk(el)
        t = "".join(buf).strip("\n")
        if t.strip():
            paras.append(t)
    return paras


def extract_docx(zf):
    out = []
    root = parse_xml(read_member(zf, zf.getinfo("word/document.xml"))) if "word/document.xml" in zf.namelist() else None
    if root is not None:
        out = ooxml_paras(root)
    return "\n".join(out)


def extract_pptx(zf):
    names = sorted([n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)], key=natkey)
    out = []
    for n in names:
        root = parse_xml(read_member(zf, zf.getinfo(n)))
        if root is not None:
            out.extend(ooxml_paras(root))
    return "\n".join(out)


def extract_xlsx(zf):
    names = zf.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = parse_xml(read_member(zf, zf.getinfo("xl/sharedStrings.xml")))
        if root is not None:
            for si in root:
                if lname(si.tag) != "si":
                    continue
                parts = []
                for e in si.iter():
                    if lname(e.tag) == "t":
                        # skip phonetic runs
                        parts.append(e.text or "")
                # remove phonetic text
                ph = []
                for rph in si.iter():
                    if lname(rph.tag) == "rPh":
                        for t in rph.iter():
                            if lname(t.tag) == "t":
                                ph.append(t.text or "")
                txt = "".join(parts)
                phs = "".join(ph)
                if phs and txt.endswith(phs):
                    txt = txt[: len(txt) - len(phs)]
                shared.append(txt)
    sheets = sorted([n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)], key=natkey)
    out = []
    for n in sheets:
        root = parse_xml(read_member(zf, zf.getinfo(n)))
        if root is None:
            continue
        for c in root.iter():
            if lname(c.tag) != "c":
                continue
            t = c.get("t")
            val = None
            if t == "s":
                v = None
                for ch in c:
                    if lname(ch.tag) == "v":
                        v = (ch.text or "").strip()
                if v is not None and re.fullmatch(r"\d+", v) and int(v) < len(shared):
                    val = shared[int(v)]
            elif t == "inlineStr":
                val = "".join((e.text or "") for e in c.iter() if lname(e.tag) == "t")
            elif t == "str":
                for ch in c:
                    if lname(ch.tag) == "v":
                        val = ch.text or ""
            if val is not None and val.strip():
                out.append(val.strip())
    return "\n".join(out)


def extract_odf(zf):
    if "content.xml" not in zf.namelist():
        return ""
    root = parse_xml(read_member(zf, zf.getinfo("content.xml")))
    if root is None:
        return ""

    def sp(e):
        try:
            n = int(e.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c", "1"))
        except ValueError:
            n = 1
        return " " * max(n, 1)

    special = {"s": sp, "tab": lambda e: "\t", "line-break": lambda e: "\n", "annotation": lambda e: ""}
    out = []
    for el in root.iter():
        if lname(el.tag) in ("p", "h"):
            t = gather(el, {"p", "h"}, special)
            if t.strip():
                out.append(t.strip("\n"))
    return "\n".join(out)


class _Html(HTMLParser):
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "section",
             "article", "pre", "ul", "ol", "table", "dt", "dd", "figcaption", "hr"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_startendtag(self, tag, attrs):
        if tag in self.BLOCK and tag not in self.SKIP:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def extract_epub(zf):
    names = sorted([n for n in zf.namelist() if re.search(r"\.(x?html?)$", n, re.I)], key=natkey)
    out = []
    for n in names:
        base = n.rsplit("/", 1)[-1].lower()
        if base in ("nav.xhtml", "nav.html", "toc.xhtml", "toc.html"):
            continue
        data = read_member(zf, zf.getinfo(n))
        if data is None:
            continue
        p = _Html()
        try:
            p.feed(data.decode("utf-8", "replace"))
            p.close()
        except Exception:
            pass
        text = "".join(p.parts)
        lines = [re.sub(r"[ \t\r\f\v]+", " ", ln).strip() for ln in text.split("\n")]
        lines = [ln for ln in lines if ln]
        if lines:
            out.append("\n".join(lines))
    return "\n".join(out)


def extract_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ""
    if not isinstance(nb, dict):
        return ""
    cells = nb.get("cells")
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict):
            return ""
        if c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, str):
            t = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            t = "".join(src)
        else:
            return ""
        if t.strip():
            out.append(t.strip())
    return "\n".join(out)


def extract_file(path):
    """Return (text, line_paras)."""
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except (OSError, ValueError) as e:
        raise Fail("cannot read input: %s" % (getattr(e, "strerror", None) or e))
    if ext in NO_PROSE_EXTS:
        return "", False
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError, ValueError, EOFError) as e:
            raise Fail("cannot read input: not a readable zip archive (%s)" % e)
        try:
            if ext in (".docx", ".docm"):
                t = extract_docx(zf)
            elif ext in (".pptx", ".pptm"):
                t = extract_pptx(zf)
            elif ext in (".xlsx", ".xlsm"):
                t = extract_xlsx(zf)
            elif ext == ".epub":
                t = extract_epub(zf)
            else:
                t = extract_odf(zf)
        except (zipfile.BadZipFile, OSError, KeyError, EOFError, RuntimeError, NotImplementedError, ValueError):
            raise Fail("cannot read input: archive could not be read")
        return t.strip(), True
    if ext in NOTEBOOK_EXTS:
        return extract_ipynb(data).strip(), False
    return decode_bytes(data), False


# ---------------------------------------------------------------- character layer

TAG_RE = re.compile("\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F")


def _rng(*pairs):
    return tuple(pairs)


def in_ranges(c, ranges):
    o = ord(c)
    for lo, hi in ranges:
        if lo <= o <= hi:
            return True
    return False


CJK = ((0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0x20000, 0x2FFFF), (0xF900, 0xFAFF), (0x3005, 0x3007), (0x3021, 0x3029), (0x3038, 0x303B))
NOSPACE = ((0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x19E0, 0x19FF), (0x3040, 0x30FF)) + CJK
RTL = ((0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF))
JOINING = ((0x0590, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFE),
           (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF))
EMOJI = ((0x1F000, 0x1FAFF), (0x2600, 0x27BF), (0x2B00, 0x2BFF), (0x2190, 0x21FF), (0x2300, 0x23FF),
         (0x25A0, 0x25FF), (0x2900, 0x297F), (0x203C, 0x203C), (0x2049, 0x2049), (0x2122, 0x2122),
         (0x2139, 0x2139), (0x3030, 0x3030), (0x303D, 0x303D), (0x3297, 0x3299), (0x00A9, 0x00A9), (0x00AE, 0x00AE),
         (0x1F1E6, 0x1F1FF))
MONGOLIAN = ((0x1820, 0x18AA),)
KHMER = ((0x1780, 0x17FF),)
BIDI = set("‎‏؜‪‫‬‭‮⁦⁧⁨⁩")
FILLERS = set("ᅟᅠㅤﾠ͏឴឵᠋᠌᠍᠎᠏﻿")


def is_invisible_candidate(c):
    o = ord(c)
    if o < 0x20:
        return c not in "\t\n\r"
    if o == 0x7F or 0x80 <= o <= 0x9F:
        return True
    if o < 0xA0:
        return False
    if 0xE0000 <= o <= 0xE0FFF:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return True
    if c in FILLERS:
        return True
    if 0x2060 <= o <= 0x206F:
        return True
    if 0xFFF9 <= o <= 0xFFFB:
        return True
    if o in (0x00AD, 0x061C, 0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E):
        return True
    cat = unicodedata.category(c)
    if cat == "Cf":
        return True
    return False


def kept(text, i, c, has_rtl, tagkeep):
    """Is the invisible candidate at i doing a job in its position?"""
    o = ord(c)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if 0xE0000 <= o <= 0xE0FFF and not (0xE0100 <= o <= 0xE01EF):
        return i in tagkeep
    if 0xE0100 <= o <= 0xE01EF:
        return bool(prev) and in_ranges(prev, CJK)
    if c == "​":
        return (bool(prev) and in_ranges(prev, NOSPACE)) or (bool(nxt) and in_ranges(nxt, NOSPACE))
    if c == "­":
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if c in BIDI:
        return has_rtl
    if o in (0x180B, 0x180C, 0x180D, 0x180F, 0x180E):
        return bool(prev) and in_ranges(prev, MONGOLIAN)
    if o in (0x17B4, 0x17B5):
        return (bool(prev) and in_ranges(prev, KHMER)) or (bool(nxt) and in_ranges(nxt, KHMER))
    if c in "‌‍":
        for nb in (prev, nxt):
            if nb and (in_ranges(nb, JOINING) or in_ranges(nb, EMOJI) or unicodedata.category(nb) in ("So", "Sk")):
                return True
        return False
    if 0xFE00 <= o <= 0xFE0F:
        if nxt == "⃣":
            return True
        if prev and (in_ranges(prev, CJK) or in_ranges(prev, EMOJI) or unicodedata.category(prev) in ("So", "Sk", "Sm")):
            return True
        return False
    return False


NONASCII_SCAN = re.compile(r"[^\x20-\x7e\t\n\r]")
SPACE_CHARS = set("               　")
LINE_SEPS = set("  ")


def nbsp_kept(text, i, c):
    if c not in "  ":
        return False
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


# lookalike letters -> ASCII
LOOKALIKE = {}
for _a, _b in [
    ("а", "a"), ("с", "c"), ("е", "e"), ("о", "o"), ("р", "p"), ("х", "x"), ("у", "y"), ("і", "i"), ("ј", "j"),
    ("ѕ", "s"), ("һ", "h"), ("ԁ", "d"), ("ԝ", "w"), ("ɡ", "g"), ("ո", "n"), ("ս", "u"), ("օ", "o"), ("գ", "g"),
    ("ց", "g"), ("հ", "h"), ("ν", "v"), ("ο", "o"), ("ρ", "p"), ("υ", "u"), ("ι", "i"), ("α", "a"), ("χ", "x"),
    ("γ", "y"), ("ϲ", "c"), ("ј", "j"), ("ԍ", "g"), ("ո", "n"), ("ԛ", "q"), ("ɑ", "a"), ("ꭰ", "d"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"), ("Ј", "J"), ("К", "K"), ("М", "M"),
    ("О", "O"), ("Р", "P"), ("Т", "T"), ("Х", "X"), ("У", "Y"), ("Ѕ", "S"), ("Ү", "Y"),
    ("Α", "A"), ("Β", "B"), ("Ε", "E"), ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"), ("Ν", "N"),
    ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Υ", "Y"), ("Χ", "X"), ("Ϲ", "C"), ("Ⅰ", "I"),
    ("ہ", "o"), ("ھ", "o"), ("ﻩ", "o"), ("ﮪ", "o"), ("ﮬ", "o"), ("ﻫ", "o"), ("ﻬ", "o"), ("ﮭ", "o"),
]:
    LOOKALIKE[_a] = _b

RUN_RE = re.compile(r"[^\W\d_]+")


def homoglyph_tokens(text):
    """Yield (start, end, token) for tokens meeting the homoglyph condition."""
    for m in re.finditer(r"\S+", text):
        tok = m.group(0)
        if tok.isascii():
            continue
        ok = True
        for ch in tok:
            if ord(ch) > 127 and ch.isalpha() and ch not in LOOKALIKE:
                ok = False
                break
        if not ok:
            continue
        mixed = False
        for r in RUN_RE.finditer(tok):
            run = r.group(0)
            has_ascii = any(ord(c) < 128 for c in run)
            has_look = any(c in LOOKALIKE for c in run)
            if has_ascii and has_look:
                mixed = True
        if mixed:
            yield m.start(), m.end(), tok


def fold_token(tok):
    out = []
    pos = 0
    for r in RUN_RE.finditer(tok):
        run = r.group(0)
        out.append(tok[pos:r.start()])
        if any(ord(c) < 128 for c in run) and any(c in LOOKALIKE for c in run):
            run = "".join(LOOKALIKE.get(c, c) for c in run)
        out.append(run)
        pos = r.end()
    out.append(tok[pos:])
    return "".join(out)


def char_layer(text):
    """Return counts and samples for invisible, spaces, homoglyphs on text."""
    inv = 0
    spc = 0
    inv_s = []
    spc_s = []
    if text.isascii() and "\x00" not in text and not re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", text):
        return {"invisible": 0, "spaces": 0, "homoglyphs": 0, "tokens": 0, "inv_s": [], "spc_s": [], "hg_s": []}
    has_rtl = any(in_ranges(c, RTL) for c in text if ord(c) > 0x58F)
    tagkeep = set()
    for m in TAG_RE.finditer(text):
        for k in range(m.start() + 1, m.end()):
            tagkeep.add(k)
    for m in NONASCII_SCAN.finditer(text):
        i = m.start()
        c = text[i]
        if c in SPACE_CHARS:
            if not nbsp_kept(text, i, c):
                spc += 1
                if len(spc_s) < 3:
                    spc_s.append("U+%04X" % ord(c))
        elif c in LINE_SEPS:
            spc += 1
            if len(spc_s) < 3:
                spc_s.append("U+%04X" % ord(c))
        elif is_invisible_candidate(c):
            if not kept(text, i, c, has_rtl, tagkeep):
                inv += 1
                if len(inv_s) < 3:
                    inv_s.append("U+%04X" % ord(c))
    hg = 0
    toks = 0
    hg_s = []
    # lookalike characters appear only in non-ASCII text
    for s, e, tok in homoglyph_tokens(text):
        toks += 1
        for r in RUN_RE.finditer(tok):
            run = r.group(0)
            if any(ord(c) < 128 for c in run):
                hg += sum(1 for c in run if c in LOOKALIKE)
        if len(hg_s) < 3:
            hg_s.append(tok[:40])
    return {"invisible": inv, "spaces": spc, "homoglyphs": hg, "tokens": toks, "inv_s": inv_s, "spc_s": spc_s, "hg_s": hg_s}


def cleanup_text(text):
    """Deterministic character cleanup (FP-03)."""
    if not text.isascii() or re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", text):
        has_rtl = any(in_ranges(c, RTL) for c in text if ord(c) > 0x58F)
        tagkeep = set()
        for m in TAG_RE.finditer(text):
            for k in range(m.start() + 1, m.end()):
                tagkeep.add(k)
        out = []
        last = 0
        for m in NONASCII_SCAN.finditer(text):
            i = m.start()
            c = text[i]
            rep = None
            if c in SPACE_CHARS:
                if not nbsp_kept(text, i, c):
                    rep = " "
            elif c in LINE_SEPS:
                rep = "\n"
            elif is_invisible_candidate(c):
                if not kept(text, i, c, has_rtl, tagkeep):
                    rep = ""
            if rep is not None:
                out.append(text[last:i])
                out.append(rep)
                last = i + 1
        out.append(text[last:])
        text = "".join(out)
        # fold homoglyph tokens
        if not text.isascii():
            pieces = []
            last = 0
            for s, e, tok in homoglyph_tokens(text):
                pieces.append(text[last:s])
                pieces.append(fold_token(tok))
                last = e
            pieces.append(text[last:])
            text = "".join(pieces)
    # trim
    ended_lf = text.endswith("\n")
    crlf = text.endswith("\r\n")
    lines = text.split("\n")
    lines = [ln.rstrip(" \t") if not ln.endswith("\r") else ln[:-1].rstrip(" \t") + "\r" for ln in lines]
    text = "\n".join(lines)
    # drop leading blank lines
    k = 0
    n = len(text)
    while True:
        j = k
        while j < n and text[j] in " \t\r":
            j += 1
        if j < n and text[j] == "\n":
            k = j + 1
        else:
            break
    text = text[k:]
    text = text.rstrip(" \t\r\n")
    if ended_lf and text:
        text += "\r\n" if crlf else "\n"
    return text


# ---------------------------------------------------------------- markdown masking

FENCE_RE = re.compile(r"^( {0,3})(`{3,}|~{3,})(.*)$")
LIST_RE = re.compile(r"^\s{0,3}(?:[-*+]|\d{1,9}[.)])\s+")
BADGE_RE = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
HEADING_RE = re.compile(r"^\s{0,3}#{1,6}(?:\s|$)")
INLINE_CODE_RE = re.compile(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", re.S)


def mask_markdown(text):
    lines = text.split("\n")
    n = len(lines)
    out = [None] * n
    i = 0
    # YAML front matter
    if n and lines[0].rstrip() == "---":
        for j in range(1, n):
            if lines[j].rstrip() in ("---", "..."):
                for k in range(0, j + 1):
                    out[k] = ""
                i = j + 1
                break
    in_para = False
    in_list = False
    prev_blank = True
    while i < n:
        ln = lines[i]
        m = FENCE_RE.match(ln)
        if m and not (m.group(2)[0] == "`" and "`" in m.group(3)):
            ch = m.group(2)[0]
            ln_open = len(m.group(2))
            out[i] = ""
            i += 1
            while i < n:
                c = re.match(r"^ {0,3}(" + re.escape(ch) + r"{%d,})\s*$" % ln_open, lines[i])
                out[i] = ""
                i += 1
                if c:
                    break
            in_para = False
            prev_blank = True
            continue
        stripped = ln.strip()
        if not stripped:
            out[i] = ""
            in_para = False
            prev_blank = True
            i += 1
            continue
        indent = len(ln) - len(ln.lstrip(" \t"))
        expanded = len(ln.expandtabs(4)) - len(ln.expandtabs(4).lstrip(" "))
        if expanded >= 4 and not in_para and not in_list:
            out[i] = ""
            prev_blank = False
            i += 1
            continue
        if LIST_RE.match(ln):
            in_list = True
        elif indent < 2 and not LIST_RE.match(ln):
            if not (in_para and in_list):
                in_list = False
        if stripped.startswith("|") and stripped.count("|") >= 2:
            out[i] = ""
            in_para = False
            i += 1
            continue
        if BADGE_RE.match(ln):
            out[i] = ""
            i += 1
            continue
        if stripped.startswith(">"):
            j = i
            while j < n and lines[j].lstrip().startswith(">"):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    out[k] = ""
                i = j
                in_para = False
                continue
        out[i] = ln
        in_para = not HEADING_RE.match(ln)
        prev_blank = False
        i += 1
    res = "\n".join(out)
    if "`" in res:
        res = INLINE_CODE_RE.sub("", res)
    return res


# ---------------------------------------------------------------- text structure

WORD_RE = re.compile(r"[^\W_](?:[^\W_]|['’-])*")


def words(s):
    return WORD_RE.findall(s)


def collapse_ws(s):
    return re.sub(r"\s+", " ", s).strip()


SENT_SPLIT = re.compile(r"(?<=[.!?…])[\"')\]]*\s+")
LISTITEM_RE = re.compile(r"^\s*(?:[-*+•]|\d{1,9}[.)])\s+")


def paragraphs(A, line_paras=False):
    """Blocks of lines (list of lists)."""
    blocks = []
    cur = []
    for ln in A.split("\n"):
        if not ln.strip():
            if cur:
                blocks.append(cur)
                cur = []
        elif line_paras:
            blocks.append([ln])
        else:
            cur.append(ln)
    if cur:
        blocks.append(cur)
    return blocks


def is_heading(ln):
    return bool(HEADING_RE.match(ln))


def sentences_of(blocks):
    """List of (para_index, sentence)."""
    res = []
    for pi, b in enumerate(blocks):
        prose = []
        for ln in b:
            if is_heading(ln):
                continue
            if LISTITEM_RE.match(ln):
                if prose:
                    res.extend((pi, s) for s in SENT_SPLIT.split(" ".join(prose)) if s.strip())
                    prose = []
                it = LISTITEM_RE.sub("", ln)
                res.extend((pi, s) for s in SENT_SPLIT.split(it) if s.strip())
            else:
                prose.append(ln.strip())
        if prose:
            res.extend((pi, s) for s in SENT_SPLIT.split(" ".join(prose)) if s.strip())
    return [(p, s) for p, s in res if words(s)]


def cv(vals):
    if not vals:
        return None
    mean = sum(vals) / float(len(vals))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


# ---------------------------------------------------------------- patterns

def P(pat, flags=re.I):
    return re.compile(pat.replace(" ", r"\s+"), flags)


VOCAB_1 = [
    r"additionally", r"align(?:s|ed|ing)? with", r"crucial", r"delv(?:e|es|ed|ing)", r"tapestr(?:y|ies)",
    r"pivotal", r"vibrant", r"meticulous(?:ly)?", r"testament(?:s)?", r"underscor(?:e|es|ed|ing)",
    r"intricate(?:ly)?", r"intricac(?:y|ies)", r"interplay", r"garner(?:s|ed|ing)?", r"bolster(?:s|ed|ing)?",
    r"foster(?:s|ed|ing)?", r"showcas(?:e|es|ed|ing)", r"emphasi[sz](?:e|es|ed|ing)", r"enduring",
    r"enhanc(?:e|es|ed|ing)", r"leverag(?:e|es|ed|ing)", r"utili[sz](?:e|es|ed|ing)",
    r"facilitat(?:e|es|ed|ing)", r"encompass(?:es|ed|ing)?", r"harness(?:es|ed|ing)?", r"holistic(?:ally)?",
    r"paradigm(?:s)?", r"transformative", r"unprecedented", r"myriad", r"plethora", r"robust(?:ness)?",
    r"seamless(?:ly)?", r"navigat(?:e|es|ed|ing)", r"embark(?:s|ed|ing)?", r"craft(?:s|ed|ing)?",
    r"landscape(?:s)?", r"journey(?:s|ed|ing)?", r"realm(?:s)?", r"multifaceted", r"elevat(?:e|es|ed|ing)",
    r"empower(?:s|ed|ing)?", r"unlock(?:s|ed|ing)?", r"captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic)",
]
RX1 = re.compile(r"(?<![\w-])(?:" + "|".join(v.replace(" ", r"\s+") for v in VOCAB_1) + r")(?![\w-])", re.I)

RX2 = re.compile(r"(?<![\w-])(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly|"
                 r"quietly\s+(?:powerful|profound|radical)|deeply\s+(?:human|personal|felt|unsettling)|"
                 r"resonat(?:es|ed|ing)\s+deeply|game[- ]chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|"
                 r"skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioni[sz](?:e|es|ed|ing)|"
                 r"doubl(?:e|es|ed|ing)\s+down\s+on|div(?:e|es|ed|ing)\s+deep(?:er)?\s+into|"
                 r"unlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)|"
                 r"tak(?:e|es|ing|en)\s+(?:\w+\s+){1,4}?to\s+the\s+next\s+level)(?![\w-])", re.I)

PROMO = P(r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|"
          r"rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|"
          r"leading(?! (?:to|up|into|from|off|with|the|a|an)\b)|esteemed organization|valuable asset|"
          r"passion for excellence|proven track record|results-oriented|wealth of experience|dynamic team|"
          r"fast-paced environment|deeply passionate|perfectly situated|(?:close|tight)-knit team|"
          r"i am excited to (?:apply|bring)|uniquely positioned to)\b")
IMPERATIVES = set("install join grab download try discover experience escape transform reclaim unlock elevate boost say "
                  "imagine explore meet introducing upgrade claim unleash supercharge level stop start".split())

HYPH4 = P(r"\b(?:state-of-the-art|cutting-edge|best-in-class|data-driven|results-driven|forward-thinking|"
          r"customer-centric|mission-critical|next-generation|end-to-end|user-friendly|high-quality|"
          r"well-rounded|detail-oriented|self-starter|team-player|value-added|big-picture|cross-functional|"
          r"thought-provoking|ever-evolving|ever-changing|one-of-a-kind|world-leading|results-focused|"
          r"fast-growing|full-service|client-focused|hard-working|high-performing|innovative-minded)\b")

SIMPLE_YET = P(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")

SYN_CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]
SYN_RX = []
for cl in SYN_CLUSTERS:
    alts = []
    for w in cl:
        if w.endswith("y"):
            alts.append(w[:-1] + r"(?:y|ies)")
        elif w.endswith("s") or w.endswith("sh") or w.endswith("ch") or w.endswith("x"):
            alts.append(w + r"(?:es)?")
        else:
            alts.append(w + r"s?")
    SYN_RX.append((cl, [re.compile(r"(?<![\w-])" + a.replace(" ", r"\s+") + r"(?![\w-])", re.I) for a in alts]))

SIGNIF = [
    P(r"\b(?:stands|serves|stood|served) as (?:a|an|the) (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b"),
    P(r"\b(?:underscor(?:es|ed|ing)|highlight(?:s|ed|ing)) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b"),
    P(r"\breflect(?:s|ed|ing)? a broader (?:trend|shift|pattern)\b"),
    P(r"\bmark(?:s|ed|ing)? a (?:turning point|milestone|watershed|new chapter|new era)\b"),
    P(r"\bsymboli[sz](?:es|ed|ing)\b"),
    P(r"\bsets? the stage for\b"),
    P(r"\bleft an indelible mark\b"),
    P(r"\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b"),
    P(r"\bhas (?:shaped|sparked)\b"),
    P(r"\bhas come to (?:define|symbolize)\b"),
]
NOTABILITY = [
    P(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [^.!?\n]{0,80}?\b[A-Z][\w&.'-]+(?:,| and| or)\s+(?:and |or )?(?:the )?[A-Z][\w&.'-]+", 0),
    P(r"\b(?:[\d,.]+[kKmM]?\+?) (?:followers|subscribers)\b"),
    P(r"\b(?:strong|active|robust|significant|notable|growing) (?:online|digital|social[- ]media) presence\b"),
    P(r"\bwidely covered\b"),
    P(r"\bindependent (?:media )?coverage\b"),
]
VAGUE = P(r"\b(?:experts (?:argue|believe|say|claim|note|suggest)|industry (?:reports|observers|analysts)|"
          r"observers have (?:cited|noted)|some critics argue|researchers have found|studies suggest|"
          r"it is widely believed)\b")
ARTICLE_TITLE = P(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of (?:[\w'’&-]+ ){1,12}?(?:is|are) (?:a|an|the)\b")
CONSERV = P(r"\b(?:plays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem|"
            r"conservation efforts are (?:underway|ongoing|in place)|serves as an indicator species|"
            r"contributes to biodiversity)\b")
FALSE_RANGE = [
    P(r"\bfrom the (?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?]{0,160}?\bto the (?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"),
    P(r"\bfrom (?:the )?humble\b[^.!?]{0,120}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b"),
]
ING_TAIL = P(r",\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|"
             r"encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|"
             r"leveraging|aligning|embodying|exemplifying|epitomizing)\b")
TAIL_NEG = P(r",\s*no (?:wasted motion|guessing|waste|hassle|fluff|stress|jargon)\b")
PARALLEL = [
    P(r"\bit's not (?:just|merely) (?:about|an?)\b"),
    P(r"\bnot only\b[^.!?]{0,40}?\bbut\b"),
    P(r"\bdoesn't just\b[^,.]{0,40}?\bit\b"),
]
NOT_JUST = [
    P(r"\b(?:no|not) \w+, (?:just|only|simply) \w+"),
    P(r"\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely) (?:(?:a|an|the) )?\w+\s*(?:,|—|–|--| - )\s*(?:it's|it is|it was|they're|they are|they were|that's|but)\b"),
]
FILLER = P(r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to|"
           r"it is important to note that|it should be mentioned that|needless to say)\b")
PIVOT = P(r"\b(?:it's worth (?:noting|mentioning) that|it bears (?:noting|mentioning) that|"
          r"one thing to (?:consider|keep in mind) is|it is interesting to note that|a key consideration is|"
          r"a point to highlight is)")
OUTCOME = P(r",\s*(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|"
            r"reshaping our understanding of|paving the way for|signaling a shift toward)\b")
AUTHORITY = P(r"(?:\bhere's the thing\b|\bmake no mistake\b|\bthe truth is\b|\blet's be honest\b|\bthe simple fact is\b|"
              r"\bat its core\b|\bwhat really matters\b|\bmore than anything\b|\bat the end of the day\b|"
              r"\bthe bottom line is\b|\bin reality\b|\bfundamentally,|\bthe real question is\b|\bthe heart of the matter\b|"
              r"\bthe deeper issue\b|\bwhen you get down to it\b|\bwhen all is said and done\b)")
EDITORIAL = P(r"\b(?:it(?:'s| is) important to (?:remember|note|understand|recognize)|one must note that|"
              r"it is worth pointing out|it cannot be overstated that|it must be emphasized that)\b")
SELF_THOROUGH = P(r"\b(?:this comprehensive (?:guide|overview|analysis)|this in-depth (?:analysis|look|examination)|"
                  r"this complete (?:guide|overview)|a thorough examination of|everything you need to know about)\b")
QA = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))\s*(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|Was|Were|May|Might|Must|Shall)\b[^.!?\n]{0,80}\?\s+"
                r"(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Certainly|Sometimes|Nope|Indeed)\s*[.!]", re.I)
CONCRETE = P(r"\b(?:without concrete evidence|do you have concrete evidence|i (?:would )?need concrete (?:evidence|examples) to|"
             r"absent concrete proof|provide concrete evidence)\b")
HOOKS = P(r"\b(?:in today's (?:\w+ ){0,2}(?:world|landscape|environment|market)|in a world where|in an era of|"
          r"in recent years,|more than ever before|we live in a (?:time|world) when|(?:great|exciting|big) news\s*[!:]|"
          r"ever (?:wanted|wondered|dreamed|wished) to[^.!?\n]{0,100}\?|"
          r"in an increasingly (?:interconnected|digital|competitive|complex) world)")
DIFF = [
    P(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b"),
    P(r"\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b"),
    P(r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b"),
    P(r"\bpreviously\b[^.!?]{0,160}?\bnow\b"),
    P(r"\b(?:wasn't|weren't) there before\b"),
    P(r"\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"),
]
SIGNPOST = P(r"\b(?:let's (?:dive|delve|explore)|let's break (?:this|it) down|here's what you need to know|"
             r"without further ado|now let's look at|buckle up|stay with me|(?:are you )?ready to dive in)\b")
CATALOGUING = [
    P(r"\b(?:used|uses|employs?|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+"),
    re.compile(r"(?:^|[.!?]\s+)(?-i:These)(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insights?|understanding|details|data)\b", re.M),
    P(r"\b(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b"),
]
CHALLENGES = P(r"\b(?:despite (?:these|its|the) (?:challenges|obstacles)|challenges and (?:future )?(?:prospects|outlook|legacy)|"
               r"continues to thrive|typical of (?:emerging|urban|modern)|faces (?:several|many|numerous) challenges)\b")
TRANSITIONS = ("Additionally", "Furthermore", "Moreover", "However", "Nevertheless", "Consequently", "Subsequently", "Notably")
CONCLUSION = re.compile(r"^[ \t>*_#-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b", re.I | re.M)
POSITIVE_END = P(r"\b(?:the future looks bright|exciting times lie ahead|journey toward excellence|step in the right direction|"
                 r"(?:the )?(?:outlook|future)(?: for [\w ]{1,40}?)? (?:is|looks|remains) bright|"
                 r"well[- ]positioned for (?:whatever comes next|the future|the road ahead))")
CHATBOT = [
    P(r"\bi hope this helps\b"), re.compile(r"\b(?:Certainly|Of course)!", re.I), P(r"\blet me know if you\b"),
    P(r"\bwould you like me to\b"), P(r"\bfeel free to (?:ask|reach out)\b"),
    re.compile(r"\bhappy to help(?=\s*(?:[.!?]|$))", re.I | re.M),
    P(r"\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b"),
    P(r"\bhere(?: are|'s) (?:a few|some|two|three) (?:\w+ )?(?:options|drafts|versions|variations)\b"),
    P(r"\bhere(?: is|'s) a draft\b"), P(r"\bdepending on the (?:vibe|tone|style)\b"),
    P(r"\bi hope (?:this email )?finds you well\b"),
    P(r"\bas an? (?:ai assistant|ai language model|large language model|language model|llm|ai)\b"),
    P(r"\bto (?:answer|address) your question\b"), P(r"\bin (?:response|answer) to your question\b"),
    P(r"\byour question (?:about|regarding|concerning)\b"), P(r"\bas (?:you )?(?:requested|asked), here\b"),
    P(r"\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b"),
]
SYCOPHANT = [
    P(r"\byou(?:'re| are) absolutely right\b"), P(r"\b(?:great question|excellent point)\s*[!.,]"),
    P(r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b"),
    P(r"\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"),
]
CUTOFF = P(r"\b(?:as of my (?:last )?(?:training|knowledge)|up to my (?:last )?(?:training|knowledge)|"
           r"while specific details are (?:limited|scarce|not (?:extensively|widely) documented)|"
           r"based on (?:the )?available information|as of my (?:knowledge )?cutoff|maintains? a low profile|"
           r"keeps? (?:his|her|their) personal life private)")
COPULA = P(r"\b(?:serves as|stands as|functions as|acts as|represents (?:a|the)|marks (?:a|the)|boasts|"
           r"features (?:a|an|the|\d+|several|many|numerous|multiple|various|a number)|offers a|refers to)\b")
HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
MARKETING = P(r"\b(?:unlocking (?:its |their |your )?full potential|navigating the complexities|"
              r"a testament to the (?:power|importance)|staying ahead of the curve|turning challenges into opportunities|"
              r"tak(?:e|es|ing) (?:\w+ ){1,3}?to the next level|harness(?:es|ed|ing)? the power of|paving the way for|"
              r"saying goodbye to|imagining a world where|ever-evolving landscape|at the forefront of|"
              r"unlock(?:s|ed|ing)? the secrets|a game-changer for)")
PLACEHOLDER = [
    re.compile(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])", re.I),
    re.compile(r"\[[^\]\n]{0,40}\b(?:name|company|client|place|city|source|person|location|organization|firm)\b[^\]\n]{0,40}\](?![\(\[])", re.I),
    re.compile(r"\{\{[^}\n]*\}\}"),
    re.compile(r"(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])"),
    re.compile(r"lorem\s+ipsum", re.I),
]
CAPS_SLOT = re.compile(r"\[([A-Z][A-Z0-9 _/-]*)\](?![\(\[])")
CHATMARK = re.compile(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|\bnavlist\b|【\d+†[^】]*】", re.I)
UTM = re.compile(r"utm_source=([A-Za-z0-9.\-]+)", re.I)
UTM_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com", "copilot.microsoft.com", "poe.com"}
YEAR_RANGE = re.compile(r"(?<![\d-])((?:1[0-9]|20)\d\d)-((?:1[0-9]|20)\d\d)(?![\d-])")
HRULE = re.compile(r"^\s{0,3}([-*_])(?:\s*\1){2,}\s*$")
BOLD = re.compile(r"\*\*[^*\n]+?\*\*")
INLINE_HEADER = re.compile(r"^\s*(?:[-*+]\s+|\d{1,9}[.)]\s+)?\*\*[^*\n]+?(?::\*\*|\*\*\s*:)", re.M)
FIRST_PERSON = re.compile(r"\b(?:i|i'm|i've|i'll|i'd|me|my|mine|myself|we|we're|we've|our|ours|us)\b", re.I)
FULL_FORMS = re.compile(r"\b(?:(?:do|does|did|is|are|was|were|will|would|should|could|have|has|had|can|must) not|cannot|"
                        r"(?:it|that|there|what|who|here|let) (?:is|us)|(?:i|we|they|you) (?:am|are|have|will|would))\b", re.I)
CONTRACTED = re.compile(r"\b\w+(?:n't|'re|'ll|'ve|'d|'m)\b|\b(?:it|that|there|what|who|here|let|he|she)'s\b", re.I)

LABELS = {
    1: "AI vocabulary", 2: "model-dialect vocabulary", 3: "promotional language", 4: "hyphenated word-pair overuse",
    5: "\"simple yet X\" cliche", 6: "stacked adjective chains", 8: "synonym cycling", 10: "significance inflation",
    11: "notability name-dropping", 12: "vague attributions", 13: "article titles as proper nouns",
    14: "conservation / ecosystem padding", 15: "false ranges", 16: "superficial -ing tail clauses",
    17: "negative parallelisms and tailing negations", 18: "\"Not X, just Y\" constructions", 19: "filler phrases",
    20: "empty pivot phrases", 21: "outcome speculation tails", 22: "persuasive authority tropes",
    23: "editorial interjections", 24: "self-thoroughness phrases", 25: "question-answer rhetorical pattern",
    26: "\"concrete evidence\" defense phrase", 27: "compulsive intro hooks", 30: "diff-anchored writing",
    31: "signposting and announcements", 32: "cataloguing lead-ins", 33: "inline-header vertical lists",
    34: "mid-essay bullet injection", 35: "fragmented headers", 36: "formulaic challenges sections",
    37: "transition cluster overuse", 38: "compulsive conclusion phrases", 39: "generic positive conclusions",
    40: "sentence-length monotony", 41: "mechanical sentence-length alternation", 42: "opener repetition",
    44: "uniform paragraph length", 46: "semicolon and parenthesis underuse", 47: "chatbot artifacts",
    48: "sycophantic / servile tone", 50: "knowledge-cutoff disclaimers", 51: "copula avoidance",
    54: "excessive hedging", 55: "contraction absence", 56: "boldface overuse", 57: "emojis",
    58: "em-dash overuse", 59: "title case in headings", 60: "curly quotation marks",
    61: "hyphen for en dash in numeric ranges", 62: "invisible / zero-width characters",
    63: "placeholder / Mad-Libs text", 64: "chatbot reference-markup leak", 65: "AI tracking params",
    66: "homoglyph / mixed-script confusables", 67: "non-standard spaces", 68: "trailing / stray whitespace",
    69: "canonical marketing-slop phrases", 70: "decorative horizontal rules", 71: "degenerate repetition",
}
SLUGS = {
    1: "ai_vocabulary", 2: "model_dialect", 3: "promotional", 4: "hyphenated_pairs", 5: "simple_yet",
    6: "adjective_chains", 8: "synonym_cycling", 10: "significance_inflation", 11: "name_dropping",
    12: "vague_attribution", 13: "article_title", 14: "ecosystem_padding", 15: "false_ranges", 16: "ing_tails",
    18: "not_x_just_y", 19: "filler", 20: "empty_pivot", 21: "outcome_speculation", 22: "authority_tropes",
    23: "editorial", 24: "self_thoroughness", 25: "question_answer", 26: "concrete_evidence", 27: "intro_hooks",
    30: "diff_anchored", 31: "signposting", 32: "cataloguing", 33: "inline_headers", 34: "bullet_injection",
    35: "fragmented_headers", 36: "challenges", 37: "transitions", 38: "conclusions", 39: "positive_ending",
    40: "monotony", 41: "alternation", 42: "opener_repetition", 44: "uniform_paragraphs", 46: "underuse",
    47: "chatbot_artifacts", 48: "sycophancy", 50: "cutoff", 51: "copula_avoidance", 54: "hedging",
    55: "no_contractions", 56: "boldface", 57: "emojis", 58: "em_dashes", 59: "title_case", 60: "curly_quotes",
    61: "hyphen_ranges", 62: "invisible_chars", 63: "placeholders", 64: "chat_markup", 65: "tracking_params",
    66: "homoglyphs", 67: "nonstandard_spaces", 68: "trailing_whitespace", 69: "marketing_slop",
    70: "horizontal_rules", 71: "repetition",
}
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 44}
SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
WEIGHTS = {40: 6, 44: 6, 56: 7, 57: 7, 70: 7, 33: 8, 34: 8, 35: 8, 59: 5, 37: 9, 38: 9, 62: 18, 63: 18,
           64: 18, 65: 18, 66: 18, 13: 18, 47: 18, 50: 18, 48: 18}


def clip(s, n=80):
    s = collapse_ws(s)
    return s if len(s) <= n else s[: n - 1] + "…"


class Collector:
    def __init__(self):
        self.items = {}

    def add(self, key, num, count, samples, moving=True, label=None):
        if count <= 0:
            return
        slug = key
        self.items[slug] = {
            "num": num, "label": label or LABELS[num], "count": int(count),
            "samples": [clip(s) for s in samples[:3] if s], "moving": moving,
        }


def scan(rx_list, A):
    if not isinstance(rx_list, (list, tuple)):
        rx_list = [rx_list]
    count = 0
    samples = []
    for rx in rx_list:
        for m in rx.finditer(A):
            count += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return count, samples


def excerpt_sample(A, W, m):
    s, e = m.start(), m.end()
    lo = max(0, s - 25)
    hi = min(len(A), e + 25)
    core = collapse_ws(A[lo:hi])
    pre = "…" if lo > 0 else ""
    post = "…" if hi < len(A) else ""
    wnorm = collapse_ws(W)
    if core and core in wnorm:
        return pre + core + post
    word = collapse_ws(m.group(0))
    if word in wnorm:
        return word
    return word


def analyze(W, line_paras=False, ci_mode=False):
    raw = W.replace("\r\n", "\n").replace("\r", "\n")
    ch = char_layer(W)
    M = mask_markdown(raw)
    C = cleanup_text(M)
    A = C.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    col = Collector()
    wl = words(A)
    nwords = len(wl)
    blocks = paragraphs(A, line_paras)
    sents = sentences_of(blocks)
    wc = [len(words(s)) for _, s in sents]

    # 1
    cnt = 0
    samples = []
    for m in RX1.finditer(A):
        cnt += 1
        if len(samples) < 3:
            samples.append(excerpt_sample(A, W, m))
    col.add("1_ai_vocabulary", 1, cnt, samples)
    # 2
    c2, s2 = scan(RX2, A)
    if c2 >= 2:
        col.add("2_model_dialect", 2, c2, s2)
    # 3
    c3, s3 = scan(PROMO, A)
    imp = 0
    for _, s in sents:
        fw = words(s)
        if fw and fw[0].lower() in IMPERATIVES:
            imp += 1
            if len(s3) < 3 and imp >= 3:
                s3.append(s[:60])
    if imp >= 3:
        c3 += imp
    col.add("3_promotional", 3, c3, s3)
    # 4
    c, s = scan(HYPH4, A)
    col.add("4_hyphenated_pairs", 4, c, s, moving=False)
    # 5
    c, s = scan(SIMPLE_YET, A)
    col.add("5_simple_yet", 5, c, s)
    # 6
    c6 = 0
    s6 = []
    ADJ_END = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial", "ary", "ory", "ish")
    STOCK_ADJ = set("innovative dynamic powerful seamless robust cutting-edge comprehensive vibrant bold sleek modern "
                    "scalable reliable secure efficient flexible intuitive elegant stunning rich unique exciting "
                    "versatile fast simple clean beautiful engaging impactful transformative".split())
    NOUNISH = set("student parent client agent patient moment comment president event element department document "
                  "ingredient incident component continent government instrument management argument".split())
    for m in re.finditer(r"(?<![\w'-])(?:[A-Za-z][\w-]*,\s+){3,}(?:and\s+|or\s+)?[A-Za-z][\w-]*(?:\s+[A-Za-z][\w-]*)?", A):
        chain = [w.strip().lower() for w in re.split(r",\s+|\s+and\s+|\s+or\s+", m.group(0))]
        flat = []
        for w in chain:
            flat.extend(w.split())
        ok = False
        for w in flat[:-1] if len(flat) > 4 else flat:
            if w in NOUNISH:
                continue
            if w in STOCK_ADJ or (w.endswith(ADJ_END) and not w.endswith("s")):
                ok = True
        if ok:
            c6 += 1
            if len(s6) < 3:
                s6.append(m.group(0))
    col.add("6_adjective_chains", 6, c6, s6)
    # 8
    c8 = 0
    s8 = []
    for cl, rxs in SYN_RX:
        found = 0
        tot = 0
        names = []
        for name, rx in zip(cl, rxs):
            n = len(rx.findall(A))
            if n:
                found += 1
                tot += n
                names.append(name)
        if found >= 3:
            c8 += tot
            s8.append(", ".join(names))
    col.add("8_synonym_cycling", 8, c8, s8)
    # 10
    c, s = scan(SIGNIF, A)
    col.add("10_significance_inflation", 10, c, s)
    # 11
    c, s = scan(NOTABILITY, A)
    col.add("11_name_dropping", 11, c, s)
    c, s = scan(VAGUE, A)
    col.add("12_vague_attribution", 12, c, s)
    c, s = scan(ARTICLE_TITLE, A)
    col.add("13_article_title", 13, c, s)
    c, s = scan(CONSERV, A)
    col.add("14_ecosystem_padding", 14, c, s)
    c, s = scan(FALSE_RANGE, A)
    col.add("15_false_ranges", 15, c, s)
    c, s = scan(ING_TAIL, A)
    col.add("16_ing_tails", 16, c, s)
    # 17
    c, s = scan(PARALLEL, A)
    col.add("17_negative_parallelism", 17, c, s, moving=False, label="negative parallelisms (not just X, but Y)")
    c, s = scan(TAIL_NEG, A)
    col.add("17_tailing_negation", 17, c, s, label="tailing negations (no fluff, no waste)")
    c, s = scan(NOT_JUST, A)
    col.add("18_not_x_just_y", 18, c, s)
    c, s = scan(FILLER, A)
    col.add("19_filler", 19, c, s, moving=False)
    c, s = scan(PIVOT, A)
    col.add("20_empty_pivot", 20, c, s)
    c, s = scan(OUTCOME, A)
    col.add("21_outcome_speculation", 21, c, s)
    c, s = scan(AUTHORITY, A)
    col.add("22_authority_tropes", 22, c, s, moving=False)
    c, s = scan(EDITORIAL, A)
    col.add("23_editorial", 23, c, s)
    c, s = scan(SELF_THOROUGH, A)
    col.add("24_self_thoroughness", 24, c, s)
    c, s = scan(QA, A)
    col.add("25_question_answer", 25, c, s)
    c, s = scan(CONCRETE, A)
    col.add("26_concrete_evidence", 26, c, s)
    c, s = scan(HOOKS, A)
    col.add("27_intro_hooks", 27, c, s)
    c, s = scan(DIFF, A)
    col.add("30_diff_anchored", 30, c, s)
    c, s = scan(SIGNPOST, A)
    col.add("31_signposting", 31, c, s)
    c, s = scan(CATALOGUING, A)
    col.add("32_cataloguing", 32, c, s)
    # 33
    c, s = scan(INLINE_HEADER, A)
    col.add("33_inline_headers", 33, c, s)
    # 34
    has_heading = any(is_heading(ln) for ln in A.split("\n")) or bool(re.search(r"^.+\n(?:=+|-{2,})\s*$", A, re.M))
    if not has_heading:
        list_paras = 0
        prose_paras = 0
        sample = []
        for b in paragraphs(A, False):
            if all(LISTITEM_RE.match(ln) for ln in b):
                list_paras += 1
                if not sample:
                    sample.append(b[0].strip())
            else:
                prose_paras += 1
        if list_paras >= 1 and prose_paras >= 2:
            col.add("34_bullet_injection", 34, list_paras, sample)
    # 35
    c35 = 0
    s35 = []
    alines = A.split("\n")
    for i, ln in enumerate(alines):
        if is_heading(ln):
            htxt = re.sub(r"^\s*#+\s*", "", ln).strip().rstrip("#").strip()
            j = i + 1
            while j < len(alines) and not alines[j].strip():
                j += 1
            if j < len(alines):
                nx = alines[j].strip()
                if (not is_heading(nx) and not LISTITEM_RE.match(nx) and not nx.startswith("|")
                        and 0 < len(words(nx)) <= 6):
                    hw = set(w.lower() for w in words(htxt) if len(w) > 3)
                    if any(w.lower() in hw for w in words(nx)):
                        c35 += 1
                        if len(s35) < 3:
                            s35.append(htxt + " / " + nx)
    col.add("35_fragmented_headers", 35, c35, s35)
    c, s = scan(CHALLENGES, A)
    col.add("36_challenges", 36, c, s)
    # 37
    c37 = 0
    s37 = []
    byp = {}
    for pi, s in sents:
        fw = s.lstrip().split(None, 1)
        if fw:
            w0 = fw[0].rstrip(",;:")
            if w0 in TRANSITIONS:
                byp.setdefault(pi, []).append(s)
    for pi, lst in byp.items():
        if len(lst) >= 2:
            c37 += len(lst)
            if len(s37) < 3:
                s37.append(lst[0][:50])
    col.add("37_transitions", 37, c37, s37)
    c, s = scan(CONCLUSION, A)
    col.add("38_conclusions", 38, c, [x.strip() for x in s])
    c, s = scan(POSITIVE_END, A)
    col.add("39_positive_ending", 39, c, s)
    # 40
    if len(wc) >= 3:
        v = cv(wc)
        if v is not None and v < 0.35:
            col.add("40_monotony", 40, 1, ["%d sentences, length variation %.2f" % (len(wc), v)])
    # 41
    if len(wc) >= 6:
        hit = 0
        for st in range(0, len(wc) - 5):
            w6 = wc[st:st + 6]
            d = [w6[k + 1] - w6[k] for k in range(5)]
            if any(x == 0 for x in d):
                continue
            flips = sum(1 for k in range(4) if (d[k] > 0) != (d[k + 1] > 0))
            if flips >= 3 and sum(abs(x) for x in d) / 5.0 >= 6:
                hit += 1
                break
        if hit:
            col.add("41_alternation", 41, 1, ["alternating sentence lengths"], moving=False)
    # 42
    c42 = 0
    s42 = []
    bysent = {}
    for pi, s in sents:
        bysent.setdefault(pi, []).append(s)
    for pi, lst in bysent.items():
        if len(lst) >= 3:
            cnts = {}
            for s in lst:
                fw = [w.lower() for w in words(s)[:2]]
                if len(fw) == 2:
                    cnts[tuple(fw)] = cnts.get(tuple(fw), 0) + 1
            for k, n in cnts.items():
                if n >= 3:
                    c42 += n
                    if len(s42) < 3:
                        s42.append(" ".join(k) + " ... x%d" % n)
    col.add("42_opener_repetition", 42, c42, s42, moving=False)
    # 44
    pw = []
    for b in blocks:
        if all(is_heading(ln) for ln in b):
            continue
        n = len(words(" ".join(b)))
        if n:
            pw.append(n)
    if len(pw) >= 4:
        v = cv(pw)
        if v is not None and v < 0.4:
            col.add("44_uniform_paragraphs", 44, 1, ["%d paragraphs, length variation %.2f" % (len(pw), v)])
    # 46
    if nwords >= 300 and ";" not in A and A.count("(") <= 1:
        col.add("46_underuse", 46, 1, ["no semicolons, almost no parentheticals"], moving=False)
    # 47, 48
    c, s = scan(CHATBOT, A)
    col.add("47_chatbot_artifacts", 47, c, s)
    c, s = scan(SYCOPHANT, A)
    col.add("48_sycophancy", 48, c, s)
    c, s = scan(CUTOFF, A)
    col.add("50_cutoff", 50, c, s)
    c, s = scan(COPULA, A)
    col.add("51_copula_avoidance", 51, c, s)
    # 54
    c54 = 0
    s54 = []
    for _, s in sents:
        n = len(HEDGE.findall(s))
        if n >= 2:
            c54 += 1
            if len(s54) < 3:
                s54.append(s[:80])
    col.add("54_hedging", 54, c54, s54, moving=False)
    # 55
    fp = len(FIRST_PERSON.findall(A))
    if nwords and fp / float(nwords) >= 0.02 and fp >= 3:
        full = len(FULL_FORMS.findall(A))
        con = len(CONTRACTED.findall(A))
        if full >= 3 and full / float(full + con) >= 0.7:
            col.add("55_no_contractions", 55, full, ["%d uncontracted forms, %d contracted" % (full, con)], moving=False)
    # 56
    c, s = scan(BOLD, M)
    col.add("56_boldface", 56, c, s)
    # 57
    emo = [c_ for c_ in M if ord(c_) > 0x2000 and in_ranges(c_, EMOJI) and c_ not in "©®™"]
    col.add("57_emojis", 57, len(emo), emo[:3])
    # 58
    c58 = 0
    for b in blocks:
        n = " ".join(b).count("—")
        if n >= 2:
            c58 += n
    col.add("58_em_dashes", 58, c58, ["em dashes: %d" % c58] if c58 else [], moving=False)
    # 59
    c59 = 0
    s59 = []
    SMALL = set("a an the and but or nor for so yet of in on at to by up as is if via per with from into over off out vs".split())
    for ln in A.split("\n"):
        if not is_heading(ln):
            continue
        htxt = re.sub(r"^\s*#+\s*", "", ln).strip().rstrip("#").strip()
        hw = htxt.split()
        if len(hw) < 3 or not htxt[:1].isalpha() or htxt == htxt.upper():
            continue
        major = [w for w in hw if w.strip("\"'(),:;").lower() not in SMALL and len(w.strip("\"'(),:;")) > 0]
        if len(major) >= 2 and all(w.strip("\"'(),:;")[:1].isupper() for w in major):
            c59 += 1
            if len(s59) < 3:
                s59.append(htxt)
    col.add("59_title_case", 59, c59, s59)
    # 60
    curly = [c_ for c_ in M if c_ in "‘’“”"]
    col.add("60_curly_quotes", 60, len(curly), ["".join(curly[:3])] if curly else [], moving=False)
    # 61
    c61 = 0
    s61 = []
    for m in YEAR_RANGE.finditer(A):
        if int(m.group(1)) < int(m.group(2)):
            c61 += 1
            if len(s61) < 3:
                s61.append(m.group(0))
    col.add("61_hyphen_ranges", 61, c61, s61, moving=False)
    # 62, 66, 67
    col.add("62_invisible_chars", 62, ch["invisible"], ch["inv_s"])
    # 63
    c63 = 0
    s63 = []
    for rx in PLACEHOLDER:
        for m in rx.finditer(A):
            c63 += 1
            if len(s63) < 3:
                s63.append(m.group(0))
    for m in CAPS_SLOT.finditer(A):
        letters = sum(1 for c_ in m.group(1) if c_.isalpha())
        if letters >= 3:
            c63 += 1
            if len(s63) < 3:
                s63.append(m.group(0))
    col.add("63_placeholders", 63, c63, s63)
    # 64
    c, s = scan(CHATMARK, A)
    col.add("64_chat_markup", 64, c, s)
    # 65
    c65 = 0
    s65 = []
    for m in UTM.finditer(A):
        host = m.group(1).rstrip(".").lower()
        if host in UTM_HOSTS:
            c65 += 1
            s65.append(m.group(0))
    col.add("65_tracking_params", 65, c65, s65)
    col.add("66_homoglyphs", 66, ch["tokens"], ch["hg_s"])
    col.add("67_nonstandard_spaces", 67, ch["spaces"], ch["spc_s"])
    # 68
    c68 = 0
    wl_lines = W.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    for i, ln in enumerate(wl_lines):
        if i < len(wl_lines) - 1 and ln != ln.rstrip(" \t"):
            c68 += 1
        elif i == len(wl_lines) - 1 and ln and ln != ln.rstrip(" \t"):
            c68 += 1
    rawn = W.replace("\r\n", "\n").replace("\r", "\n")
    if rawn.endswith("\n\n"):
        c68 += 1
    if rawn and rawn[0] in " \t\n":
        c68 += 1
    col.add("68_trailing_whitespace", 68, c68, ["stray whitespace"] if c68 else [], moving=False)
    # 69
    c, s = scan(MARKETING, A)
    col.add("69_marketing_slop", 69, c, s)
    # 70
    alines = A.split("\n")
    if len(raw.split("\n")) >= 24:
        c70 = 0
        for i, ln in enumerate(alines):
            if HRULE.match(ln):
                prevl = alines[i - 1] if i > 0 else ""
                if prevl.strip() and not HRULE.match(prevl) and ln.strip().startswith("-") and not ln.strip().startswith("---"):
                    continue
                if prevl.strip() and ln.strip().startswith("-") and not LISTITEM_RE.match(prevl):
                    # setext underline
                    continue
                c70 += 1
        if c70 >= 3:
            col.add("70_horizontal_rules", 70, c70, ["%d horizontal rules" % c70])
    # 71
    if nwords >= 12:
        lw = [w.lower() for w in wl]
        grams = {}
        total = len(lw) - 5
        if total > 0:
            for i in range(total):
                g = tuple(lw[i:i + 6])
                grams[g] = grams.get(g, 0) + 1
            rep = sum(n for n in grams.values() if n > 1)
            if rep and rep / float(total) >= 0.2:
                top = max(grams.items(), key=lambda kv: kv[1])[0]
                col.add("71_repetition", 71, rep, [" ".join(top)])

    items = col.items
    moving_nums = set(v["num"] for v in items.values() if v["moving"])
    nfam = len(moving_nums)
    # confidence
    if nwords < 40:
        conf, reason = "none", "fewer than 40 words, too little text to score reliably"
    elif nwords < 120 or (nwords < 300 and nfam == 1):
        conf = "low"
        reason = "short text (%d words) or a single pattern family; treat the score as a rough hint" % nwords
    elif nwords < 300:
        conf, reason = "moderate", "under 300 words; the score is a moderate-confidence estimate"
    else:
        conf, reason = "high", ""
    # score
    raw_score = 0.0
    for v in items.values():
        if not v["moving"]:
            continue
        w = WEIGHTS.get(v["num"], 11)
        raw_score += w * (1 + 0.15 * min(v["count"] - 1, 6))
    score = int(min(100, round(raw_score)))
    if nfam == 1:
        score = min(score, 40)
    if moving_nums and moving_nums <= RHYTHM:
        score = min(score, 40)
    if moving_nums == {40}:
        score = min(score, 20)
    dec = moving_nums & DECISIVE
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and nfam == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    elif len(dec) == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    shortfam = len(moving_nums & SHORT_SET)
    if nwords < 120:
        if shortfam >= 3:
            score = max(score, 45)
        elif shortfam >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if nfam >= 6:
            score = max(score, 45)
        elif nfam >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))
    return {
        "items": items, "score": score, "conf": conf, "reason": reason, "words": nwords,
        "ch": ch, "sents": [s for _, s in sents], "nfam": nfam,
    }


def build_report(W, truncated, line_paras, ci):
    r = analyze(W, line_paras)
    rep = {}
    for key in sorted(r["items"], key=lambda k: (r["items"][k]["num"], k)):
        v = r["items"][key]
        rep[key] = {"label": v["label"], "count": v["count"], "samples": v["samples"]}
    met = {
        "scanned_chars": len(W),
        "truncated": bool(truncated),
        "ai_tell_score": r["score"],
        "ai_tell_band": band_of(r["score"]),
        "confidence": r["conf"],
        "confidence_reason": r["reason"],
        "patterns_flagged": len(rep),
        "invisible_chars": r["ch"]["invisible"],
        "nonstandard_spaces": r["ch"]["spaces"],
        "homoglyphs": r["ch"]["homoglyphs"],
        "words": r["words"],
    }
    if ci:
        sents = r["sents"]
        if len(sents) >= 4:
            lo, hi = bootstrap(sents, line_paras)
            met["score_ci"] = [lo, hi]
            met["score_ci_note"] = "resampled over sentences; interval is a rough guide"
        else:
            met["score_ci"] = None
            met["score_ci_note"] = "too few sentences (fewer than 4) for an interval"
    rep["_metrics"] = met
    return rep


def bootstrap(sents, line_paras):
    rnd = random.Random(20240601)
    scores = []
    t0 = time.time()
    n = len(sents)
    for _ in range(60):
        pick = [sents[rnd.randrange(n)] for _ in range(n)]
        text = " ".join(pick)
        try:
            scores.append(analyze(text, False)["score"])
        except Exception:
            continue
        if time.time() - t0 > 2.5 and len(scores) >= 8:
            break
    if not scores:
        return 0.0, 0.0
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
    return float(lo), float(max(lo, hi))


# ---------------------------------------------------------------- main

def err_exit(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    return code


def run(argv):
    clean = False
    ci = False
    operands = []
    opts_done = False
    for a in argv:
        if opts_done:
            operands.append(a)
        elif a == "--":
            opts_done = True
        elif a in ("--help", "-h"):
            sys.stdout.buffer.write(USAGE.encode("utf-8"))
            sys.stdout.flush()
            return 0
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-"):
            return err_exit("unknown option: %s (try --help)" % a, 2)
        else:
            operands.append(a)
    try:
        line_paras = False
        if operands:
            if len(operands) > 1:
                sys.stderr.write("prosecheck: only the first file was scanned: %s\n" % operands[0])
            text, line_paras = extract_file(operands[0])
        else:
            data = sys.stdin.buffer.read()
            text = decode_bytes(data)
        if not text.strip():
            return err_exit("empty input", 1)
        if clean:
            out = cleanup_text(text)
            sys.stdout.buffer.write(out.encode("utf-8", "replace"))
            sys.stdout.flush()
            return 0
        truncated = len(text) > WINDOW
        W = text[:WINDOW]
        rep = build_report(W, truncated, line_paras, ci)
        sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=1) + "\n").encode("utf-8", "replace"))
        sys.stdout.flush()
        return 0
    except Fail as f:
        return err_exit(f.msg, f.code)


def main():
    try:
        code = run(sys.argv[1:])
    except BrokenPipeError:
        code = 0
    except Exception as e:  # never a traceback
        code = err_exit("cannot read input: %s" % e, 1)
    sys.exit(code)


if __name__ == "__main__":
    main()
