#!/usr/bin/env node
'use strict';
// prompt-submit hook: the /prosecheck command router and the ordinary-prompt reminder.
// spec: N-000620 N-000621 N-000825 N-000826 N-000839 N-000841 N-000842 N-000858 N-000859 N-000861
const core = require('./prosecheck-core');
const commands = require('./prosecheck-commands');

function main() {
  const input = core.readStdinJson();
  const dir = core.configDir();
  const ctx = {
    dir,
    root: core.pluginRoot(),
    sessionId: input.session_id,
    transcriptPath: input.transcript_path,
    cwd: typeof input.cwd === 'string' ? input.cwd : process.cwd(),
  };
  const result = commands.route(input.prompt, ctx);
  if (result.action === 'block') {
    return JSON.stringify({ decision: 'block', reason: result.reason }) + '\n';
  }
  if (result.action === 'context') {
    return JSON.stringify({
      hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: result.text },
    }) + '\n';
  }
  return '';
}

try {
  process.stdout.write(main());
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
