#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
// spec: N-000623 N-000790 N-000791 N-000792 N-000793 N-000794 N-000795 N-000796 N-000797 N-000798
// spec: N-000799 N-000800 N-000802 N-000803 N-000804 N-000805 N-000378 N-000385 N-000386 N-000391
// spec: N-000392 N-000393 N-000394 N-000412 N-000413 N-000414 N-000415 N-000416 N-000419 N-000420
// spec: N-000426 N-000427 N-000428 N-000429 N-000430 N-000434 N-000435 N-000436 N-000423 N-000424
const fs = require('fs');
const path = require('path');
const core = require('./prosecheck-core');

function ledgerRow(dir, sessionId, row) {
  core.appendLedger(dir, sessionId, row);
}

function nudge(base, res, truncated) {
  const info = core.bandInfo(res.score);
  const coverage = truncated ? ', first 262,144 characters only' : '';
  const labels = res.labels.slice(0, core.GUARD_LABEL_CAP).join('; ');
  return 'prosecheck: ' + base + ' ' + info.phrase + ' (score ' + res.score + ', band ' + res.band + coverage + '). ' +
    'Flagged: ' + labels + '. Fix the flagged spans.';
}

function main() {
  const input = core.readStdinJson();
  const dir = core.configDir();
  const root = core.pluginRoot();
  const { level } = core.readLevel(dir);
  if (level !== 'full' && level !== 'strict') return '';
  const sessionId = input.session_id;
  const threshold = core.THRESHOLDS[level];
  const names = core.namedPaths(input.tool_name, input.tool_input, typeof input.cwd === 'string' ? input.cwd : null);
  const nudges = [];

  for (const file of names) {
    if (core.isSkippedPath(file, root)) continue;
    const ext = core.extOf(file);
    const isPlain = core.PLAIN_EXT.has(ext);
    const isZip = core.ZIP_EXT.has(ext);
    const isBinary = core.NO_PROSE_EXT.has(ext);
    if (!isPlain && !isZip && !isBinary) continue;
    const base = path.basename(file);
    let stat = null;
    try {
      stat = fs.statSync(file);
    } catch (err) {
      ledgerRow(dir, sessionId, { base, kind: 'failed', reason: 'file could not be read' });
      continue;
    }
    if (!stat.isFile()) continue;
    if (isBinary) {
      ledgerRow(dir, sessionId, { base, kind: 'binary' });
      continue;
    }
    const cap = isZip ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
    if (stat.size > cap) {
      ledgerRow(dir, sessionId, { base, kind: 'size', cap: isZip ? '4096 KB' : '512 KB' });
      continue;
    }
    const run = core.runDetector([file], { timeout: isZip ? core.ARCHIVE_TIMEOUT_MS : core.PLAIN_TIMEOUT_MS });
    const res = core.reportFrom(run);
    if (!res.ok) {
      ledgerRow(dir, sessionId, { base, kind: 'failed', reason: res.reason });
      continue;
    }
    const flagged = res.score > threshold && res.confidence !== 'none';
    ledgerRow(dir, sessionId, {
      base, kind: 'scored', score: res.score, band: res.band, labels: res.labels.slice(0, core.GUARD_LABEL_CAP),
      flagged, truncated: res.truncated,
    });
    if (flagged) nudges.push(nudge(base, res, res.truncated));
  }

  if (!nudges.length) return '';
  return JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: nudges.join('\n') },
  }) + '\n';
}

try {
  process.stdout.write(main());
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
