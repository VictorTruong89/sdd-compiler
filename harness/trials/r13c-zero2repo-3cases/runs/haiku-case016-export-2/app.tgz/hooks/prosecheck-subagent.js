#!/usr/bin/env node
'use strict';
// subagent-start hook: the same writing contract, inside the subagent JSON envelope.
// spec: N-000784 N-000785 N-000786 N-000787 N-000788 N-000789 N-000622 N-000367 N-000368
const core = require('./prosecheck-core');

function main() {
  core.readStdinJson();
  const { level } = core.readLevel(core.configDir());
  if (level === 'off') return '';
  const text = core.liveContract(level, core.pluginRoot());
  return JSON.stringify({ hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: text } }) + '\n';
}

try {
  process.stdout.write(main());
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
