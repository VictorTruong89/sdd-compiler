#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract in the session (first start also shows the welcome).
// spec: N-000759 N-000760 N-000761 N-000762 N-000763 N-000764 N-000765 N-000620
const fs = require('fs');
const core = require('./prosecheck-core');

function main() {
  core.readStdinJson();
  const dir = core.configDir();
  core.pruneLedgers(dir);
  const flagExisted = fs.existsSync(core.flagPath(dir));
  const { level } = core.readLevel(dir);
  if (level === 'off') return '';
  let out = '';
  // first start of a fresh install: store the level and show the welcome once
  if (!flagExisted && core.writeLevel(level, dir)) out += core.welcomeBlock() + '\n\n';
  out += core.liveContract(level, core.pluginRoot());
  return out + '\n';
}

try {
  process.stdout.write(main());
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
