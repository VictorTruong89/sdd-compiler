'use strict';
// prosecheck /prosecheck command router and replies. Used by the prompt-submit and stats hooks.
// Replies are the block "reason" of the hook decision, except ordinary prompts (see route()).

const fs = require('fs');
const path = require('path');
const core = require('./prosecheck-core');

const CMD_RE = /^\/prosecheck(:prosecheck)?(?=\s|$)\s*([\s\S]*)$/i;
const STOP_PHRASES = ['stop prosecheck', 'prosecheck off'];

function phraseFor(band) {
  return core.BANDS.find((b) => b.band === band) || core.BANDS[0];
}

// spec: N-000840 N-000841 N-000842 N-000843 N-000844 N-000845 N-000846 N-000847
// spec: N-000852 N-000853 N-000854 N-000855 N-000856 N-000857 N-000858 N-000859 N-000860 N-000861
function route(prompt, ctx) {
  const text = String(prompt || '');
  const trimmed = text.trim();
  const lowered = trimmed.toLowerCase();
  const { dir, root } = ctx;

  if (STOP_PHRASES.includes(lowered)) {
    if (!core.writeLevel('off', dir)) return block('prosecheck could not save the level, so it is unchanged.');
    return block('prosecheck is off. Saved files will not be scored until you run /prosecheck on.');
  }

  const m = CMD_RE.exec(trimmed);
  if (!m) return ordinaryPrompt(ctx);

  const formTyped = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const args = m[2].trim();
  const word = args.split(/\s+/)[0] || '';
  const sub = word.toLowerCase();
  const rest = args.slice(word.length).trim();
  const live = core.readLevel(dir).level;

  if (sub === '' || sub === 'help') return block(helpReply(live, formTyped));
  if (sub === 'lite' || sub === 'full' || sub === 'strict') {
    if (!core.writeLevel(sub, dir)) return block('prosecheck could not save the level, so it is unchanged.');
    const detail = {
      lite: 'writing contract on, no saved-file scoring',
      full: 'writing contract on, saved-file guard at threshold 40',
      strict: 'writing contract on, saved-file guard at threshold 20, with the cleanup scrub',
    }[sub];
    return block('prosecheck level set to ' + sub + ' (' + detail + ').');
  }
  if (sub === 'off') {
    if (!core.writeLevel('off', dir)) return block('prosecheck could not save the level, so it is unchanged.');
    return block('prosecheck is now off. Saved files will not be scored; run ' + formTyped + ' on to turn it back on.');
  }
  if (sub === 'on') {
    if (!core.writeLevel('full', dir)) return block('prosecheck could not save the level, so it is unchanged.');
    return block('prosecheck is on; the level is set to full.');
  }
  if (sub === 'status') return block('prosecheck status: level is ' + live + '.');
  if (sub === 'show') return block(showReply(dir, ctx.sessionId));
  if (sub === 'check') return block(checkReply(rest, ctx.cwd));
  if (sub === 'doctor') return block(doctorReply(live, formTyped, dir, root));
  if (sub === 'stats') return block(statsReply(ctx.transcriptPath, dir, live));
  if (sub === 'init') return block(initReply(live, formTyped, ctx.cwd || process.cwd(), root));
  return block('unknown subcommand "' + word + '". Valid subcommands: lite, full, strict, off, on, status, show, ' +
    'check, doctor, stats, init, help. The stored level did not change.');
}

function block(reason) {
  return { action: 'block', reason };
}

function ordinaryPrompt(ctx) {
  const { level } = core.readLevel(ctx.dir);
  if (level === 'off') return { action: 'silent' };
  return {
    action: 'context',
    text: 'Prose deliverables follow the writing contract at level ' + level + '. ' +
      'Code, config, and commits are untouched.',
  };
}

function helpReply(live, formTyped) {
  // spec: N-000879 N-000880 N-000881 N-000882 N-000883 N-000884 N-000885 N-000886 N-000887 N-000888
  // spec: N-000889 N-000890 N-000891 N-000892 N-000893 N-000894 N-000895 N-000896 N-000897 N-000898
  // spec: N-000899 N-000900 N-000901 N-000902 N-000903 N-000904
  return [
    'prosecheck help. Live level: ' + live + '.',
    'Code, commits, config, and chat are never touched; this covers prose deliverables only.',
    'For a deep rewrite, say "prosecheck this" or "humanize this" in plain language.',
    '/prosecheck lite - turns on the writing contract and scoring-free prose shaping; saved files are not scored.',
    '/prosecheck full - the contract plus the saved-file guard at threshold 40 (default).',
    '/prosecheck strict - the guard at threshold 20 plus the cleanup scrub.',
    '/prosecheck off | on - off: disable the tool; on: re-enable it (on stores full).',
    '/prosecheck status - shows the live level in one line.',
    '/prosecheck show - lists this session\'s scored files, newest first.',
    '/prosecheck check <path> - scores one file; it is a report only and does not rewrite the file.',
    '/prosecheck doctor - a health check of the install.',
    '/prosecheck stats - session token use and the score of the session\'s own prose.',
    '/prosecheck init - exports the contract to AGENTS.md for agents other than Claude Code.',
  ].join('\n');
}

// ---------------------------------------------------------------- check

function checkReply(rawArg, cwd) {
  // spec: N-000927 N-000928 N-000929 N-000930 N-000931 N-000932 N-000933 N-000934 N-000935 N-000936
  // spec: N-000940 N-000941 N-000942 N-000943 N-000944 N-000945 N-000946 N-000947 N-000948 N-000949
  // spec: N-000950 N-000951 N-000952 N-000953 N-000954 N-000955 N-000956 N-000957 N-000958 N-000959
  // spec: N-000960 N-000961 N-000962
  let arg = String(rawArg || '').trim();
  if (arg.startsWith('@')) arg = arg.slice(1);
  if (arg.length >= 2 && (arg[0] === '"' || arg[0] === "'") && arg[arg.length - 1] === arg[0]) arg = arg.slice(1, -1);
  if (!arg) return 'usage: /prosecheck check <path> (scores one file; the file is not rewritten)';

  const full = path.resolve(cwd || process.cwd(), arg);
  const base = path.basename(full);
  let stat;
  try {
    stat = fs.statSync(full);
  } catch (err) {
    return 'cannot read ' + arg + ': the path is not on disk';
  }
  if (stat.isDirectory() || !stat.isFile()) return 'not a file: ' + arg;
  const ext = core.extOf(full);
  if (core.NO_PROSE_EXT.has(ext)) return 'no readable text: ' + base;
  const zip = core.ZIP_EXT.has(ext);
  const cap = zip ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
  if (stat.size > cap) return 'over ' + (zip ? '4096' : '512') + ' KB: ' + base;

  const run = core.runDetector([full], { timeout: zip ? core.ARCHIVE_TIMEOUT_MS : core.PLAIN_TIMEOUT_MS });
  if (run.state === 'missing') return 'detector unavailable: ' + base;
  if (run.state === 'timeout') return base + ' failed: the detector timed out';
  if (run.status !== 0) {
    const err = (run.stderr || '').trim();
    return base + ' failed' + (err ? ': ' + err : ': exit status ' + run.status);
  }
  const out = (run.stdout || '').trim();
  if (!out) return 'no report: ' + base;
  let report = null;
  try {
    report = JSON.parse(out);
  } catch (err) {
    report = null;
  }
  const metrics = report && report._metrics;
  if (!metrics || typeof metrics.ai_tell_score !== 'number') return 'no report from the detector';

  const info = phraseFor(metrics.ai_tell_band);
  const lines = [base + ' - ' + info.phrase + ' (score ' + metrics.ai_tell_score + '/100, band: ' + metrics.ai_tell_band + ')'];
  let confidence = 'confidence: ' + metrics.confidence;
  if (metrics.confidence !== 'high' && metrics.confidence_reason) confidence += ' - ' + metrics.confidence_reason;
  lines.push(confidence);
  if (metrics.truncated) lines.push('coverage: first 262,144 characters only');
  const tells = Object.keys(report).filter((k) => k !== '_metrics')
    .map((k) => report[k].label + ' (x' + report[k].count + ')').slice(0, core.CHECK_LABEL_CAP);
  lines.push(tells.length ? 'tells: ' + tells.join('; ') : 'tells: none');
  lines.push('This is report only: the file was not changed.');
  return lines.join('\n');
}

// ---------------------------------------------------------------- doctor

function doctorReply(live, formTyped, dir, root) {
  // spec: N-000963 N-000964 N-000965 N-000966 N-000967 N-000968 N-000969 N-000970 N-000971 N-000972
  // spec: N-000973 N-000974 N-000975 N-000976 N-000977 N-000978 N-000979 N-000980 N-000981 N-000982
  // spec: N-000983 N-000984 N-000985 N-000986 N-000987 N-000988 N-000989 N-000990 N-000991 N-000992
  // spec: N-000993 N-000995 N-000996 N-000998 N-000999
  const lines = ['prosecheck doctor: install health'];
  const modeOk = live !== 'off';
  lines.push(modeOk ? 'mode: ' + live + ' [OK]' : 'mode: off (not a fault; run /prosecheck on to switch it back on)');

  const detOk = core.detectorPath(root) !== null;
  lines.push(detOk ? 'detector: bundled detector found [OK]' : 'detector: bundled detector missing from the plugin tree');

  const sample = 'The quick brown fox sleeps. It is a plain check sentence for the doctor.';
  const run = core.runDetector([], { stdin: sample, timeout: core.PLAIN_TIMEOUT_MS });
  let pyOk = false;
  if (run.state === 'missing') {
    lines.push('python not found on PATH: saved files are not re-scored until Python is available, ' +
      'but the writing contract still applies and prose is still shaped.');
  } else {
    let score = null;
    try {
      const parsed = JSON.parse((run.stdout || '').trim());
      if (parsed && parsed._metrics && typeof parsed._metrics.ai_tell_score === 'number') score = parsed._metrics.ai_tell_score;
    } catch (err) {
      score = null;
    }
    pyOk = run.status === 0 && score !== null;
    lines.push(pyOk ? 'python: ran the bundled detector and got a numeric score [OK]'
      : 'python: ran but did not return a numeric score');
  }

  let setOk = true;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
  } catch (err) {
    setOk = false;
  }
  lines.push(setOk ? 'settings: settings folder is writable [OK]' : 'settings: settings folder is not writable');

  const allOk = modeOk && detOk && pyOk && setOk;
  if (allOk) {
    lines.push('prosecheck is active. Plain text is capped at 512 KB, archives at 4 MB, and the scan window is ' +
      '262,144 characters. Run ' + formTyped + ' show to see files that were only partly scanned or skipped.');
  } else if (!modeOk && detOk && pyOk && setOk) {
    lines.push('The install is healthy: while the tool is off, no files are scored. Turn it back on with ' +
      formTyped + ' on to resume scoring.');
  } else {
    lines.push('Repair the faults above and fix the faulty checks, then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- show

function showReply(dir, sessionId) {
  // spec: N-001001 N-001002 N-001004 N-001007 N-001008 N-001012 N-001013 N-001014 N-001016 N-001017
  // spec: N-001018 N-001019 N-001020 N-001021 N-001022 N-001024 N-001027 N-001029 N-001030
  const rows = core.readLedger(core.ledgerFile(dir, sessionId));
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Session ledger, newest first:'];
  for (const r of rows.slice().reverse()) out.push(showRow(r));
  return out.join('\n');
}

function showRow(r) {
  if (r.kind === 'scored') {
    const info = phraseFor(r.band);
    let body = info.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first 262,144 characters only' : '') + ')';
    if (r.labels && r.labels.length) {
      body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, core.SHOW_LABEL_CAP).join('; ');
    }
    return r.base + ' - ' + body;
  }
  if (r.kind === 'size') return r.base + ' - not scored: file is over ' + r.cap;
  if (r.kind === 'binary') return r.base + ' - not re-scored: binary format with no readable prose';
  return r.base + ' - not scored: ' + (r.reason || 'unknown reason');
}

// ---------------------------------------------------------------- init

function initReply(live, formTyped, cwd, root) {
  // spec: N-001033 N-001034 N-001035 N-001037 N-001038 N-001039 N-001040 N-001041 N-001042 N-001043
  // spec: N-001044 N-001045 N-001046 N-001058 N-001059 N-001060 N-001070 N-001071 N-001072 N-001073
  // spec: N-001074 N-001075
  if (live === 'off') {
    return 'The tool is switched off, so nothing was written. Run ' + formTyped + ' on first to allow the export.';
  }
  const lines = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let agentsRead = true;
  try {
    existing = fs.existsSync(agents) ? fs.readFileSync(agents, 'utf8') : '';
  } catch (err) {
    agentsRead = false;
  }
  if (!agentsRead) {
    lines.push('cannot read AGENTS.md: the contract was not written.');
  } else if (existing.includes(core.EXPORT_BEGIN)) {
    lines.push('AGENTS.md already contains the writing contract; it is left unchanged.');
  } else {
    const section = [core.EXPORT_BEGIN, core.exportContract(live), core.EXPORT_END].join('\n');
    const joiner = existing === '' ? '' : (existing.endsWith('\n') ? '\n' : '\n\n');
    try {
      fs.writeFileSync(agents, existing + joiner + section + '\n');
      lines.push('AGENTS.md: writing contract written at level ' + live + '.');
    } catch (err) {
      lines.push('cannot write AGENTS.md: the contract was not written.');
    }
  }

  const ruleDir = path.join(cwd, '.cursor', 'rules');
  const rule = path.join(ruleDir, 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    lines.push('.cursor/rules/prosecheck.mdc already exists; it is left unchanged.');
  } else {
    const shipped = path.join(root, '.cursor', 'rules', 'prosecheck.mdc');
    let body = core.cursorRule();
    try {
      if (fs.existsSync(shipped)) body = fs.readFileSync(shipped, 'utf8');
    } catch (err) {
      body = core.cursorRule();
    }
    try {
      fs.mkdirSync(ruleDir, { recursive: true });
      fs.writeFileSync(rule, body);
      lines.push('Cursor rule written to .cursor/rules/prosecheck.mdc.');
    } catch (err) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc: the rule was not created.');
    }
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- stats

function statsReply(transcriptPath, dir, live) {
  // spec: N-001076 N-001077 N-001078 N-001080 N-001081 N-001082 N-001083 N-001084 N-001085 N-001086
  // spec: N-001087 N-001088 N-001089 N-001091 N-001092 N-000506 N-000507 N-000508 N-000509 N-000510
  // spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000518 N-000519 N-000520
  const file = transcriptPath ? String(transcriptPath) : newestTranscript(path.join(dir, 'projects'));
  let raw = null;
  try {
    raw = file ? fs.readFileSync(file, 'utf8') : null;
  } catch (err) {
    raw = null;
  }
  if (raw === null) {
    return 'prosecheck stats: no readable transcript' + (file ? ' at ' + file : '') + '. level: ' + live + '.';
  }
  const seen = new Set();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (err) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : null;
    const counted = id === null || !seen.has(id);
    if (id !== null) seen.add(id);
    if (counted) {
      turns += 1;
      const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
      outputTokens += Number(usage.output_tokens) || 0;
      cacheRead += Number(usage.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  const lines = [
    'prosecheck stats for this session',
    'level: ' + live,
    'assistant turns: ' + turns,
    'output tokens: ' + outputTokens,
    'cache-read input tokens: ' + cacheRead,
  ];
  let slice = texts.join('\n').replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '');
  slice = slice.slice(-40000).trim();
  if (slice.length > 200) {
    const run = core.runDetector([], { stdin: slice, timeout: core.PLAIN_TIMEOUT_MS });
    try {
      const parsed = JSON.parse((run.stdout || '').trim());
      if (parsed && parsed._metrics && typeof parsed._metrics.ai_tell_score === 'number') {
        lines.push('session prose ai_tell_score: ' + parsed._metrics.ai_tell_score);
      }
    } catch (err) {
      // no score when the detector cannot give one
    }
  }
  return lines.join('\n');
}

function newestTranscript(root) {
  let best = null;
  let bestTime = -1;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (err) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        const t = fs.statSync(full).mtimeMs;
        if (t > bestTime) {
          bestTime = t;
          best = full;
        }
      }
    }
  };
  walk(root, 0);
  return best;
}

module.exports = {
  route, helpReply, checkReply, doctorReply, showReply, showRow, initReply, statsReply, newestTranscript,
  ordinaryPrompt,
};
