'use strict';
// prosecheck shared core: config, writing contract, detector calls, session ledger, command replies.
// Every hook requires this module. Standard library only; no network access.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

// spec: N-000652 N-000653 N-000668 N-000874 N-000875 N-000876 N-000877 N-000372 N-000373 N-000374
const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const CAPS = { plainKb: '512 KB', archiveMb: '4 MB', plainKbNumber: 512, archiveKbNumber: 4096 };
const WINDOW_TEXT = '262,144';
const PLAIN_CAP_BYTES = 524288; // spec: N-000235
const ARCHIVE_CAP_BYTES = 4194304;
const PLAIN_EXT = new Set(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc']);
const ZIP_EXT = new Set(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const NO_PROSE_EXT = new Set(['.pdf', '.rtf']);
const LEDGER_MAX = 20; // spec: N-000413
const LEDGER_AGE_MS = 7 * 24 * 60 * 60 * 1000; // spec: N-000056
const PLAIN_TIMEOUT_MS = 8000; // spec: N-000419
const ARCHIVE_TIMEOUT_MS = 15000;
const CHECK_LABEL_CAP = 8; // spec: N-000942
const GUARD_LABEL_CAP = 5; // spec: N-000800
const SHOW_LABEL_CAP = 5;
const PYTHON_NAMES = ['python3', 'python', 'py'];
const THRESHOLDS = { full: 40, strict: 20 };

const BANDS = [
  { max: 20, band: 'clean', phrase: 'reads clean' },
  { max: 40, band: 'light tells', phrase: 'reads mostly clean' },
  { max: 60, band: 'mixed', phrase: 'reads with some AI tells' },
  { max: 80, band: 'heavy tells', phrase: 'reads with heavy AI tells' },
  { max: 100, band: 'pervasive tells', phrase: 'reads with pervasive AI tells' },
];

function bandInfo(score) {
  for (const b of BANDS) {
    if (score <= b.max) return b;
  }
  return BANDS[BANDS.length - 1];
}

function configDir() {
  // spec: N-000658 N-000659 N-000660
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  // spec: N-000661 N-000662 N-000663
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function detectorPath(root) {
  // spec: N-000663 N-000664 N-000642
  const primary = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(primary)) return primary;
  const fallback = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(fallback)) return fallback;
  return null;
}

function flagPath(dir) {
  // spec: N-000669 N-000694 N-000695
  return path.join(dir || configDir(), '.prosecheck-active');
}

function validLevel(word) {
  return typeof word === 'string' && LEVELS.includes(word.trim().toLowerCase()) ? word.trim().toLowerCase() : null;
}

// Effective level: a valid stored word, else PROSECHECK_DEFAULT_MODE, else full. spec: N-000372-N-000377
function readLevel(dir) {
  let stored = null;
  try {
    stored = validLevel(fs.readFileSync(flagPath(dir), 'utf8'));
  } catch (err) {
    stored = null;
  }
  if (stored) return { level: stored, stored: true };
  const fromEnv = validLevel(process.env.PROSECHECK_DEFAULT_MODE || '');
  return { level: fromEnv || 'full', stored: false };
}

// Writes the level flag; returns false when it cannot be written.
function writeLevel(word, dir) {
  try {
    fs.mkdirSync(dir || configDir(), { recursive: true });
    fs.writeFileSync(flagPath(dir), word, { mode: 0o600 });
    return true;
  } catch (err) {
    return false;
  }
}

function readStdinJson() {
  // spec: N-000369 N-000371 N-000760 N-000785
  try {
    const text = fs.readFileSync(0, 'utf8');
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (err) {
    return {};
  }
}

// ---------------------------------------------------------------- writing contract

const BANNED = 'delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, showcase, ' +
  'landscape (abstract), journey (abstract), realm, multifaceted, holistic, testament, vibrant, comprehensive, ' +
  'plethora, myriad, boast, elevate, empower, unlock, game-changer, supercharge, genuinely, fascinating, nuanced';

function contractShell() {
  // spec: N-000324 N-000325 N-000326 N-000329 N-000330 N-000331 N-000332 N-000333 N-000334 N-000335
  // spec: N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342 N-000774 N-000775
  return [
    'Writing contract for prose deliverables: documents, README and markdown prose, CVs, cover letters, ' +
      'emails, reports, essays, articles, and drafted text the user will publish or send.',
    'This contract never touches source code, code comments, commit messages, JSON, YAML or other configuration, ' +
      'CLI output, logs, error messages, or the conversational register of chat.',
    '',
    'Shape the prose as you write it:',
    '- Vary sentence length irregularly. No metronome, no mechanical short-long alternation.',
    '- Banned vocabulary, never used as standalone words: ' + BANNED + '.',
    '- Avoid banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y" constructions, hedge stacking, ' +
      'signposting such as "let\'s dive in", empty pivots such as "it\'s worth noting", "In conclusion" or ' +
      '"Overall" closers, outcome-speculation tails, self-thoroughness phrases, generic upbeat endings, and ' +
      'chatbot phrases such as "I hope this helps".',
    '- Use at most one em dash per paragraph. Do not bold phrases for emphasis inside prose sentences. ' +
      'Use no emojis.',
    '- Keep factual or encyclopedic content neutral and in the third person. First-person or opinion content ' +
      'may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
    '- End each section on a fact or an observation.',
    '- Stay silent about these rules. Never announce them, never name the tool, never report a score, a band, ' +
      'a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

function detectorStep(level, detectorCommand) {
  // spec: N-000347 N-000348 N-000349 N-000350 N-000351 N-000352 N-000353
  if (level === 'lite') return [];
  if (level === 'full') {
    return [
      '',
      'After writing a prose file, run the bundled detector on it: ' + detectorCommand,
      'Target: a score of 40 or below, band clean or light tells.',
      'If the band is worse than the target, fix the flagged spans, for at most two fix passes, keeping the rhythm variation.',
    ];
  }
  return [
    '',
    'After writing a prose file, run the bundled detector on it: ' + detectorCommand,
    'Target: a score of 20 or below, band clean.',
    'If the band is worse than the target, fix the flagged spans, for at most two fix passes, keeping the rhythm variation.',
    'Finish through `--clean`: run the detector with the --clean switch on the file and keep its scrubbed text as the final prose.',
  ];
}

// Contract text for a live session (or subagent). Names this machine's detector command.
function liveContract(level, root) {
  const det = detectorPath(root);
  const command = det ? 'python3 "' + det + '" "<file>"' : 'python3 scripts/detect.py "<file>"';
  if (level === 'off') return '';
  return contractShell().concat(detectorStep(level, command)).join('\n');
}

// Portable export for AGENTS.md: no install path, no user name. spec: N-001047-N-001057
function exportContract(level) {
  const shell = contractShell();
  const lines = shell.slice();
  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('To run the detector, use the CLAUDE_PLUGIN_ROOT environment variable when it is set; otherwise locate the ' +
      'detector script in the installed skills and plugins folders, and run it on the saved file.');
    lines.push('After writing a prose file, run the detector on it.');
    if (level === 'full') {
      lines.push('Target: a score of 40 or below, band clean or light tells.');
    } else {
      lines.push('Target: a score of 20 or below, band clean.');
      lines.push('Finish through `--clean`: run the detector with the --clean switch and keep its scrubbed text as the final prose.');
    }
    lines.push('If the band is worse than the target, fix the flagged spans, for at most two fix passes, keeping the rhythm variation.');
  }
  return lines.join('\n');
}

const EXPORT_BEGIN = '<!-- prose-contract:begin -->';
const EXPORT_END = '<!-- prose-contract:end -->';

function cursorRule() {
  // spec: N-001061 N-001062 N-001064 N-001065 N-001066 N-001069
  return [
    '---',
    'description: Writing contract for prose deliverables',
    'globs: *.md, *.mdx, *.markdown, *.txt, *.rst, *.tex, *.org, *.adoc',
    'alwaysApply: false',
    '---',
    '',
    'This contract covers prose deliverables only.',
    '',
    contractShell().join('\n'),
    '',
  ].join('\n');
}

function welcomeBlock() {
  // spec: N-000766 N-000767 N-000768 N-000770 N-000771 N-000354 N-000356 N-000357 N-000358 N-000359 N-000360 N-000361
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB, and the detector scores the first 262,144 characters.',
    'There is no website and no upload; nothing leaves the machine. This welcome is shown once.',
    'Commands: `/prosecheck doctor`, `/prosecheck check`, `/prosecheck off`, `/prosecheck help`.',
  ].join('\n');
}

// ---------------------------------------------------------------- detector runs

function runDetector(args, opts) {
  // spec: N-000589 N-000590 N-000591 N-000592 N-000430 N-000431 N-000432
  const root = pluginRoot();
  const script = detectorPath(root);
  if (!script) return { state: 'missing' };
  for (const name of PYTHON_NAMES) {
    const result = spawnSync(name, [script].concat(args || []), {
      input: opts && opts.stdin !== undefined ? opts.stdin : undefined,
      encoding: 'utf8',
      timeout: (opts && opts.timeout) || PLAIN_TIMEOUT_MS,
      env: process.env,
      windowsHide: true,
      maxBuffer: 64 * 1024 * 1024,
    });
    if (result.error) {
      if (result.error.code === 'ENOENT') continue;
      if (result.error.code === 'ETIMEDOUT') return { state: 'timeout' };
      return { state: 'missing' };
    }
    if (result.signal) return { state: 'timeout' };
    return { state: 'ran', status: result.status, stdout: result.stdout || '', stderr: result.stderr || '' };
  }
  return { state: 'missing' };
}

// Maps a detector run to a score or a readable failure reason. spec: N-000430 N-000431 N-000432 N-000434 N-000435
function reportFrom(run) {
  if (run.state === 'missing') return { ok: false, reason: 'Python cannot be found on PATH' };
  if (run.state === 'timeout') return { ok: false, reason: 'the detector timed out' };
  const out = run.stdout.trim();
  if (run.status !== 0) {
    const err = run.stderr.trim().split('\n').filter(Boolean).pop();
    return { ok: false, reason: 'the detector exited without a usable result' + (err ? ': ' + err : ''), status: run.status };
  }
  if (!out) return { ok: false, reason: 'the detector produced no output' };
  let report = null;
  try {
    report = JSON.parse(out);
  } catch (err) {
    return { ok: false, reason: 'the detector printed text that is not a report' };
  }
  const metrics = report && report._metrics;
  if (!metrics || typeof metrics.ai_tell_score !== 'number') {
    return { ok: false, reason: 'the report has no numeric score' };
  }
  const labels = [];
  for (const key of Object.keys(report)) {
    if (key === '_metrics') continue;
    labels.push(report[key].label);
  }
  return { ok: true, score: metrics.ai_tell_score, band: metrics.ai_tell_band, confidence: metrics.confidence,
    confidenceReason: metrics.confidence_reason || '', truncated: !!metrics.truncated, labels, report };
}

// ---------------------------------------------------------------- session ledger

function safeSession(sessionId) {
  return String(sessionId || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
}

function ledgerFile(dir, sessionId) {
  // spec: N-000669 N-000670 N-000412 N-000417
  const sid = safeSession(sessionId);
  return path.join(dir || configDir(), sid ? '.prosecheck-ledger-' + sid : '.prosecheck-ledger');
}

function readLedger(file) {
  try {
    const stat = fs.statSync(file);
    if (Date.now() - stat.mtimeMs > LEDGER_AGE_MS) return [];
    return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((line) => {
      try {
        return JSON.parse(line);
      } catch (err) {
        return null;
      }
    }).filter(Boolean);
  } catch (err) {
    return [];
  }
}

function appendLedger(dir, sessionId, record) {
  // spec: N-000413 N-000414 N-000415 N-000416 N-000057
  try {
    fs.mkdirSync(dir || configDir(), { recursive: true });
    const file = ledgerFile(dir, sessionId);
    const rows = readLedger(file).concat([Object.assign({ at: Date.now() }, record)]).slice(-LEDGER_MAX);
    fs.writeFileSync(file, rows.map((r) => JSON.stringify(r)).join('\n') + '\n', { mode: 0o600 });
  } catch (err) {
    // a ledger that cannot be written never blocks the host
  }
}

// Removes ledgers untouched for more than seven days. spec: N-000056 N-000491
function pruneLedgers(dir) {
  try {
    for (const name of fs.readdirSync(dir)) {
      if (name !== '.prosecheck-ledger' && !name.startsWith('.prosecheck-ledger-')) continue;
      const full = path.join(dir, name);
      const stat = fs.statSync(full);
      if (Date.now() - stat.mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(full);
    }
  } catch (err) {
    // missing folder: nothing to prune
  }
}

// ---------------------------------------------------------------- guard helpers

function extOf(file) {
  return path.extname(file).toLowerCase();
}

// Skipped instruction files and plugin-owned paths. spec: N-000404-N-000409
function isSkippedPath(file, root) {
  const resolved = path.resolve(file);
  const parts = resolved.split(/[\\/]/);
  if (parts.some((p) => p === 'node_modules' || p === '.git' || p === 'memory')) return true;
  const rootResolved = path.resolve(root);
  if (resolved === rootResolved || resolved.startsWith(rootResolved + path.sep)) return true;
  const base = path.basename(resolved).toLowerCase();
  if (['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'].includes(base)) return true;
  const stem = base.split('.')[0];
  if (['claude', 'agents', 'skill', 'memory'].includes(stem)) {
    const ext = path.extname(base);
    if (!PLAIN_EXT.has(ext) && !ZIP_EXT.has(ext)) return true;
  }
  return false;
}

// Paths named by a file-edit tool request. spec: N-000378 N-000379 N-000384 N-000409 N-000410
function namedPaths(toolName, toolInput, cwd) {
  const input = toolInput && typeof toolInput === 'object' ? toolInput : {};
  let names = [];
  if (typeof input.command === 'string' && /\*\*\*\s/.test(input.command)) {
    const re = /^\*\*\* (?:Add File|Update File|Move to):\s*(.+)$/gm;
    let m;
    while ((m = re.exec(input.command)) !== null) names.push(m[1].trim());
  }
  if (!names.length) {
    if (typeof input.file_path === 'string') names.push(input.file_path.trim());
    if (typeof input.notebook_path === 'string') names.push(input.notebook_path.trim());
  }
  names = names.filter(Boolean).map((n) => (path.isAbsolute(n) || !cwd ? n : path.join(cwd, n)));
  return Array.from(new Set(names)).slice(0, 16);
}

module.exports = {
  LEVELS, SUBCOMMANDS, CAPS, WINDOW_TEXT, PLAIN_CAP_BYTES, ARCHIVE_CAP_BYTES, PLAIN_EXT, ZIP_EXT, NO_PROSE_EXT,
  PLAIN_TIMEOUT_MS, ARCHIVE_TIMEOUT_MS, CHECK_LABEL_CAP, GUARD_LABEL_CAP, SHOW_LABEL_CAP, THRESHOLDS,
  EXPORT_BEGIN, EXPORT_END,
  BANDS, bandInfo, configDir, pluginRoot, detectorPath, flagPath, readLevel, writeLevel, readStdinJson,
  liveContract, exportContract, cursorRule, welcomeBlock, contractShell,
  runDetector, reportFrom, ledgerFile, readLedger, appendLedger, pruneLedgers, safeSession,
  extOf, isSkippedPath, namedPaths,
};
