#!/usr/bin/env node
'use strict';
// stats hook: session token use and the session-prose score, read from the transcript.
// spec: N-000624 N-001080 N-001081 N-001096 N-001097
const core = require('./prosecheck-core');
const commands = require('./prosecheck-commands');

function main() {
  const input = core.readStdinJson();
  const dir = core.configDir();
  const { level } = core.readLevel(dir);
  const reason = commands.statsReply(input.transcript_path, dir, level);
  return JSON.stringify({ decision: 'block', reason }) + '\n';
}

try {
  process.stdout.write(main());
} catch (err) {
  // a hook never fails the host session
}
process.exitCode = 0;
