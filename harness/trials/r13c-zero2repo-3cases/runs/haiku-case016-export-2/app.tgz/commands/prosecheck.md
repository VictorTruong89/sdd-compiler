---
description: Writing-contract controls and checks for prose (levels, check, doctor, show, init, stats, help)
argument-hint: [lite|full|strict|off|on|status|show|check <path>|doctor|stats|init|help]
---

/prosecheck $ARGUMENTS
