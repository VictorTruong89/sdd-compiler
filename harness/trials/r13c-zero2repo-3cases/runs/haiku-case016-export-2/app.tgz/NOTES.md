# prosecheck build notes

Built from `spec/` (not modified). Entry points:

- `scripts/detect.py` - the detector (Python 3.9+ standard library only). `--clean`, `--ci`, `--`, `-h/--help`.
- `hooks/prosecheck-activate.js` (session start), `prosecheck-tracker.js` (prompt submit and the `/prosecheck` router),
  `prosecheck-subagent.js` (subagent start), `prosecheck-guard.js` (post tool use), `prosecheck-stats.js` (stats).
  Shared logic lives in `hooks/prosecheck-core.js` and `hooks/prosecheck-commands.js`. `hooks/hooks.json` registers them.
- `commands/prosecheck.md` - the menu document (`$ARGUMENTS` forwarding). `.cursor/rules/prosecheck.mdc` - the shipped Cursor rule.
- `.claude-plugin/plugin.json` - manifest. `tests/test_prosecheck.py` - detector tests, named after acceptance-criterion ids.

## Decisions I made where the spec leaves room

- Score weights per catalogue family, the decisive families, floors and caps follow FP-01 exactly; the per-family
  weights themselves are my choice. Writing-advice numbers (4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, and the
  parallelism form of 17) are reported and carry weight zero.
- Lexical lists are the spec's examples; the stock hyphenated pairs (4), stacked-adjective stock words, synonym
  clusters, marketing-slop list (69) and the homoglyph map are subsets chosen by me.
- Invisible and non-standard-space keep rules approximate the script lists in FP-03 (e.g. script membership by Unicode block).
- `--ci` bootstraps sentences with a fixed seed (100 resamples; fewer for long documents).
- Ledger file: `.prosecheck-ledger-<session>` (JSON lines, owner-only mode, newest 20 rows, pruned after seven days).
- The flag file and ledgers live under `CLAUDE_CONFIG_DIR` (default `~/.claude`).
- Doctor, show, check and init reply wording is mine, constrained by the spec's required words and forbidden words.

## Verified here

- `python3 -m unittest discover -s tests` (9 tests, including N-000292 and N-000296).
- Manual runs of every hook and subcommand against a scratch config directory, including missing Python, an
  unwritable settings folder, `apply_patch` payloads, `PROSECHECK_DEFAULT_MODE`, and the plugin-tree skip rule.
- Timing: a 500 KB adversarial input scans in about 1 s; `--clean` in under 0.4 s.

## Not verified

- Python 3.9 and Windows/macOS behaviour (only Python 3.13 and Node 22 were available).
- Claude Code and other host integrations end to end; the hooks were exercised by piping JSON, as the host would.
