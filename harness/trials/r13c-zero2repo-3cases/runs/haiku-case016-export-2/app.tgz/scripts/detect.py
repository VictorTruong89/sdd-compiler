#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic scan of prose for AI-writing patterns.

Standard library only. No network, no model, no random component (the optional
--ci interval uses a fixed seed). Prints one JSON report, or scrubbed text with --clean.

Usage: detect.py [--clean] [--ci] [--] [FILE]
       detect.py --help | -h
"""
# spec: N-000698 N-000699 N-000700 N-000701 N-000702 N-000703 N-000704
# spec: N-000705 N-000706 N-000733 N-000734 N-000735 N-000736 N-000737
# spec: N-000754 N-000755 N-000756 N-000757 N-000758

import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000279 N-000280 N-000281 N-000222 N-000223
WINDOW = 262144
ZIP_EXT = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXT = '.ipynb'
NO_PROSE_EXT = frozenset(['.pdf', '.rtf'])

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns. This is a triage heuristic, not an authorship test.
  --clean      print scrubbed text (invisible characters removed, spacing normalized)
                 instead of the JSON report
  --ci         add a resampled low/high interval on the score (needs four sentences)
  --           end option parsing, so FILE may begin with a dash
  -h, --help   print this message and exit
With no FILE the text is read from standard input as UTF-8.
"""


class ReadError(Exception):
    pass


def fail(message, code):
    # spec: N-000736 N-000737 N-000673 N-000674 N-000675 N-000677
    data = json.dumps({"error": message}, ensure_ascii=False) + "\n"
    sys.stderr.buffer.write(data.encode("utf-8"))
    sys.stderr.flush()
    return code


# ---------------------------------------------------------------- decoding and extraction

def _local(tag):
    return tag.rsplit('}', 1)[-1]


def _plain(el, mapping=None):
    """Visible text of an XML element; mapping gives text for empty-ish tags such as tabs."""
    mapping = mapping or {}
    out = []

    def walk(e):
        name = _local(e.tag)
        if name in mapping:
            out.append(mapping[name])
        if e.text:
            out.append(e.text)
        for child in e:
            walk(child)
            if child.tail:
                out.append(child.tail)

    walk(el)
    return ''.join(out)


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', name)]


class _HtmlText(HTMLParser):
    BLOCK = frozenset(['p', 'div', 'br', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'tr', 'section', 'blockquote'])
    SKIP = frozenset(['script', 'style', 'head', 'nav'])

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            if self.skip:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(re.sub(r'\s+', ' ', data))


def _html_text(data):
    parser = _HtmlText()
    try:
        parser.feed(data.decode('utf-8', errors='replace'))
        parser.close()
    except Exception:  # tolerant: a broken chapter still yields what it can
        pass
    lines = [ln.strip() for ln in ''.join(parser.parts).split('\n')]
    return '\n'.join(ln for ln in lines if ln)


def _docx(z):
    root = _parse_xml(z.read('word/document.xml'))
    if root is None:
        return ''
    mapping = {'tab': '\t', 'br': '\n', 'cr': '\n'}
    paras = [_plain(p, mapping) for p in root.iter() if _local(p.tag) == 'p']
    return '\n'.join(p for p in paras if p.strip())


def _pptx(z):
    slides = []
    for name in z.namelist():
        m = re.fullmatch(r'ppt/slides/slide(\d+)\.xml', name)
        if m:
            slides.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(slides):
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        for p in root.iter():
            if _local(p.tag) == 'p':
                text = _plain(p, {'br': '\n'})
                if text.strip():
                    out.append(text)
    return '\n'.join(out)


def _xlsx(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = _parse_xml(z.read('xl/sharedStrings.xml'))
        if root is not None:
            shared = [_plain(si) for si in root.iter() if _local(si.tag) == 'si']
    sheets = []
    for name in z.namelist():
        m = re.fullmatch(r'xl/worksheets/sheet(\d+)\.xml', name)
        if m:
            sheets.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(sheets):
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        for cell in root.iter():
            if _local(cell.tag) != 'c':
                continue
            kind = cell.get('t')
            text = ''
            if kind == 's':
                v = None
                for child in cell:
                    if _local(child.tag) == 'v':
                        v = child.text
                try:
                    idx = int(v)
                    text = shared[idx] if 0 <= idx < len(shared) else ''
                except (TypeError, ValueError):
                    text = ''
            elif kind == 'inlineStr':
                text = ''.join(_plain(c) for c in cell if _local(c.tag) == 'is')
            elif kind == 'str':
                text = ''.join(c.text or '' for c in cell if _local(c.tag) == 'v')
            if text.strip():
                out.append(text)
    return '\n'.join(out)


def _odf(z):
    root = _parse_xml(z.read('content.xml'))
    if root is None:
        return ''
    mapping = {'s': ' ', 'tab': '\t', 'line-break': '\n'}
    paras = [_plain(el, mapping) for el in root.iter() if _local(el.tag) in ('p', 'h')]
    return '\n'.join(p for p in paras if p.strip())


def _epub(z):
    names = []
    for name in z.namelist():
        low = name.lower()
        if not low.endswith(('.xhtml', '.html', '.htm')):
            continue
        base = low.rsplit('/', 1)[-1]
        if 'nav' in base or 'toc' in base:
            continue
        names.append(name)
    chapters = []
    for name in sorted(names, key=_natural_key):
        text = _html_text(z.read(name))
        if text:
            chapters.append(text)
    return '\n'.join(chapters)


def _notebook(raw):
    try:
        obj = json.loads(raw.decode('utf-8', errors='replace'))
    except ValueError:
        return ''
    cells = obj.get('cells') if isinstance(obj, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        out.append(src)
    return '\n'.join(out).strip()


def decode_text(raw):
    """Plain-text bytes to str. None means the buffer is not text (NUL byte, not UTF-16)."""
    # spec: N-000600 N-000601 N-000602 N-000603 N-000225 N-000226 N-000227
    if raw.startswith(b'\xef\xbb\xbf'):
        raw = raw[3:]
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16', errors='replace')
    if b'\x00' in raw:
        return None
    return raw.decode('utf-8', errors='replace')


def extract_prose(raw, ext):
    """Visible prose of a source file. Raises ReadError for unreadable archives."""
    # spec: N-000241 N-000243 N-000244 N-000245 N-000251 N-000254 N-000258 N-000263 N-000264
    if ext in NO_PROSE_EXT:
        return ''
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(raw))
        except zipfile.BadZipFile:
            raise ReadError('cannot read input: not a readable zip archive')
        with z:
            try:
                if ext in ('.docx', '.docm'):
                    text = _docx(z)
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx(z)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx(z)
                elif ext == '.epub':
                    text = _epub(z)
                else:
                    text = _odf(z)
            except (KeyError, zipfile.BadZipFile, ET.ParseError, OSError):
                text = ''
        return text.strip()
    if ext == NOTEBOOK_EXT:
        return _notebook(raw)
    text = decode_text(raw)
    return '' if text is None else text


def read_source(path):
    if path is None:
        return sys.stdin.buffer.read()
    try:
        with open(path, 'rb') as fh:
            return fh.read()
    except IsADirectoryError:
        raise ReadError('cannot read input: %s is a directory' % path)
    except OSError as exc:
        raise ReadError('cannot read input: %s' % (exc.strerror or exc))


# ---------------------------------------------------------------- character layer

_EXTRA_INVISIBLE = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C,
                              0x180D, 0x180E, 0x3164, 0xFFA0])
_SCRIPT_SPACE_RANGES = ((0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x3040, 0x30FF))


def _in(c, lo, hi):
    return bool(c) and lo <= ord(c) <= hi


def _cjk(c):
    return _in(c, 0x3400, 0x4DBF) or _in(c, 0x4E00, 0x9FFF) or _in(c, 0xF900, 0xFAFF)


def _cjkish(c):
    return _cjk(c) or any(_in(c, lo, hi) for lo, hi in _SCRIPT_SPACE_RANGES)


def _joinish(c):
    return any(_in(c, lo, hi) for lo, hi in ((0x0590, 0x08FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)))


def _symbolish(c):
    return bool(c) and (unicodedata.category(c) in ('So', 'Sk') or _in(c, 0x1F000, 0x1FAFF) or _in(c, 0x2600, 0x27BF))


def is_invisible(ch):
    # spec: N-000154 N-000290 N-000225
    if ch in '\t\n\r':
        return False
    cp = ord(ch)
    if unicodedata.category(ch) in ('Cc', 'Cf'):
        return True
    return cp in _EXTRA_INVISIBLE or 0xFE00 <= cp <= 0xFE0F or 0xE0000 <= cp <= 0xE0FFF


def invisible_kept(text, i, rtl):
    """True when an invisible character does a job in its position and cleanup keeps it."""
    # spec: N-000290 N-000291
    cp = ord(text[i])
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if cp == 0xAD:
        return prev.isalpha() and nxt.isalpha()
    if cp == 0x200B:
        return _cjkish(prev) or _cjkish(nxt)
    if cp in (0x200C, 0x200D):
        return _joinish(prev) or _joinish(nxt) or _symbolish(prev) or _symbolish(nxt)
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return _symbolish(prev) or _cjk(prev) or nxt == '\u20e3'
    if 0xE0000 <= cp <= 0xE0FFF:
        j = i - 1
        while j >= 0 and 0xE0000 <= ord(text[j]) <= 0xE0FFF:
            j -= 1
        return j >= 0 and ord(text[j]) == 0x1F3F4
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return rtl
    if 0x180B <= cp <= 0x180D:
        return _in(prev, 0x1800, 0x18AF)
    if cp in (0x17B4, 0x17B5):
        return _in(prev, 0x1780, 0x17FF)
    return False


def is_nonstandard_space(ch):
    return ch != ' ' and (unicodedata.category(ch) == 'Zs' or ch in ('\u2028', '\u2029'))


def space_kept(text, i):
    """A no-break space (or narrow no-break space) that holds something together stays."""
    # spec: N-000293 N-000294 N-000162
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    return prev.isdigit() or nxt.isdigit() or nxt in ':;!?»›%€' or prev in '«‹'


def char_pass(text, keep_nbsp):
    """Remove invisible characters, normalize non-standard spaces. Returns (text, invisible, nonstandard)."""
    # spec: N-000290 N-000293 N-000295 N-000154 N-000161 N-000299
    rtl = any(_in(c, 0x0590, 0x08FF) for c in text)
    out = []
    invisible = 0
    nonstandard = 0
    for i, ch in enumerate(text):
        if is_invisible(ch):
            if invisible_kept(text, i, rtl):
                out.append(ch)
            else:
                invisible += 1
            continue
        if ch in ('\u2028', '\u2029'):
            nonstandard += 1
            out.append('\n')
            continue
        if is_nonstandard_space(ch):
            if ord(ch) in (0xA0, 0x202F) and space_kept(text, i):
                out.append(ch if keep_nbsp else ' ')
                continue
            nonstandard += 1
            out.append(' ')
            continue
        out.append(ch)
    return ''.join(out), invisible, nonstandard


_CONFUSABLE_PAIRS = [
    (0x0430, 'a'), (0x0441, 'c'), (0x0501, 'd'), (0x0435, 'e'), (0x04BB, 'h'), (0x0456, 'i'),
    (0x0458, 'j'), (0x043E, 'o'), (0x0440, 'p'), (0x0455, 's'), (0x0443, 'y'), (0x0445, 'x'),
    (0x051B, 'q'), (0x051D, 'w'), (0x0410, 'A'), (0x0412, 'B'), (0x0415, 'E'), (0x041A, 'K'),
    (0x041C, 'M'), (0x041D, 'H'), (0x041E, 'O'), (0x0420, 'P'), (0x0421, 'C'), (0x0422, 'T'),
    (0x0425, 'X'), (0x0406, 'I'), (0x0408, 'J'), (0x0405, 'S'), (0x0423, 'Y'),
    (0x03BF, 'o'), (0x03BD, 'v'), (0x03C1, 'p'), (0x03B9, 'i'), (0x0391, 'A'), (0x0392, 'B'),
    (0x0395, 'E'), (0x0396, 'Z'), (0x0397, 'H'), (0x0399, 'I'), (0x039A, 'K'), (0x039C, 'M'),
    (0x039D, 'N'), (0x039F, 'O'), (0x03A1, 'P'), (0x03A4, 'T'), (0x03A7, 'X'), (0x03A5, 'Y'),
    (0x0573, 'u'), (0x0585, 'o'), (0x0578, 'n'), (0x03F2, 'c'),
]
_CONFUSABLE = dict((chr(cp), ascii_ch) for cp, ascii_ch in _CONFUSABLE_PAIRS)
_TOKEN_RE = re.compile(r'\S+')


def fold_homoglyphs(text):
    """Fold lookalike letters inside Latin runs to ASCII. Returns (text, folded token count)."""
    # spec: N-000160 N-000297 N-000298 N-000132
    count = [0]

    def repl(m):
        tok = m.group(0)
        has_ascii = any(c.isascii() and c.isalpha() for c in tok)
        has_conf = any(c in _CONFUSABLE for c in tok)
        foreign = any(c.isalpha() and not c.isascii() and c not in _CONFUSABLE for c in tok)
        if has_ascii and has_conf and not foreign:
            count[0] += 1
            return ''.join(_CONFUSABLE.get(c, c) for c in tok)
        return tok

    return _TOKEN_RE.sub(repl, text), count[0]


# ---------------------------------------------------------------- structure

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})\s*$')
BLOCKQUOTE = re.compile(r'^ {0,3}>')
BADGE_LINE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
INLINE_CODE = re.compile(r'`[^`\n]*`')
TABLE_ROW = re.compile(r'^\s*\|.*\|\s*$')


def strip_nonprose(lines):
    """Blank the lines the scan must not read: code, tables, quotes, badges, front matter."""
    # spec: N-000130 N-000223
    n = len(lines)
    out = list(lines)
    start = 0
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    out[k] = ''
                start = j + 1
                break
    fence = None
    in_indent = False
    prev_blank = True
    for idx in range(start, n):
        line = lines[idx]
        if fence:
            out[idx] = ''
            m = FENCE_CLOSE.match(line)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
            continue
        m = FENCE_OPEN.match(line)
        if m:
            fence = (m.group(1)[0], len(m.group(1)))
            out[idx] = ''
            in_indent = False
            prev_blank = False
            continue
        if line.strip() == '':
            out[idx] = ''
            prev_blank = True
            in_indent = False
            continue
        indented = line.startswith('    ') or line.startswith('\t')
        if indented and (prev_blank or in_indent):
            out[idx] = ''
            in_indent = True
            prev_blank = False
            continue
        in_indent = False
        prev_blank = False
        if TABLE_ROW.match(line) or BADGE_LINE.match(line):
            out[idx] = ''
            continue
        out[idx] = INLINE_CODE.sub(' ', line)
    # runs of two or more blockquote lines
    run = []
    for idx in range(start, n + 1):
        if idx < n and BLOCKQUOTE.match(lines[idx]):
            run.append(idx)
            continue
        if len(run) >= 2:
            for r in run:
                out[r] = ''
        run = []
    return out


WORD_RE = re.compile(r"[^\W_]+(?:['’-][^\W_]+)*")
SENT_SPLIT = re.compile(r'(?<=[.!?])["\'”’)\]]*\s+|\n+')


def sentences_of(text):
    return [s for s in (p.strip() for p in SENT_SPLIT.split(text)) if WORD_RE.search(s)]


def paragraphs_of(text):
    return [p for p in re.split(r'\n[ \t]*\n', text) if p.strip()]


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


def _snip(text, start, end, pad=40):
    ls = text.rfind('\n', 0, start) + 1
    le = text.find('\n', end)
    if le < 0:
        le = len(text)
    line = text[ls:le]
    s, e = start - ls, end - ls
    a = max(0, s - pad)
    b = min(len(line), e + pad)
    out = line[a:b]
    if a > 0:
        out = '…' + out
    if b < len(line):
        out = out + '…'
    return out


# ---------------------------------------------------------------- catalogue families

def _rx(pattern, flags=re.I):
    return re.compile(pattern, flags)


# spec: N-000136 N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000144
LEXICAL = {
    # (1) AI vocabulary
    1: [_rx(r"\b(?:additionally|align\s+with|crucial|delv(?:e|es|ed|ing)|tapestry|pivotal|vibrant|meticulous(?:ly)?|"
            r"testament|underscor(?:e|es|ed|ing)|intricac(?:y|ies)|intricate|interplay|garner(?:s|ed|ing)?|"
            r"bolster(?:s|ed|ing)?|foster(?:s|ed|ing)?|showcas(?:e|es|ed|ing)|emphasi[sz](?:e|es|ed|ing)|enduring|"
            r"enhance[sd]?|leverag(?:e|es|ed|ing)|utiliz(?:e|es|ed|ing)|facilitat(?:e|es|ed|ing)|"
            r"encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?|holistic|paradigm|transformative|unprecedented|"
            r"myriad|plethora|robust|seamless(?:ly)?|navigat(?:e|es|ed|ing)|embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|"
            r"landscapes?|journeys?|realms?|multifaceted|elevat(?:e|es|ed|ing)|empower(?:s|ed|ing)?|"
            r"unlock(?:s|ed|ing)?|capture the (?:essence|spirit|imagination|heart|magic))\b")],
    # (3) promotional language
    3: [_rx(r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|"
            r"rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|esteemed organization|"
            r"valuable asset|passion for excellence|proven track record|results-oriented|wealth of experience|"
            r"dynamic team|fast-paced environment|deeply passionate|perfectly situated|(?:close|tight)-knit team|"
            r"I am excited to (?:apply|bring)|uniquely positioned to)\b")],
    # (5) simple yet X
    5: [_rx(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")],
    # (10) significance inflation
    10: [_rx(r"\b(?:stands?|stood|serves?|served) as (?:a |an |the )?(?:testament|reminder|symbol|beacon|cornerstone|"
             r"bridge|gateway|hallmark)\b"),
         _rx(r"\b(?:underscor(?:es|ed|ing)|highlight(?:s|ed|ing)?) (?:its|the|their|his|her) "
             r"(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b"),
         _rx(r"\breflects? a broader (?:trend|shift|pattern)\b"),
         _rx(r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b"),
         _rx(r"\bsymboli[sz]es\b"),
         _rx(r"\bsets the stage for\b"),
         _rx(r"\bleft an indelible mark\b"),
         _rx(r"\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b"),
         _rx(r"\bhas (?:shaped|sparked)\b|\bhas come to (?:define|symbolize)\b")],
    # (11) notability name-dropping
    11: [_rx(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [^.!?\n]{0,80}?"
             r"(?-i:[A-Z][\w&.'-]*)(?:,\s*|\s+and\s+)(?-i:[A-Z][\w&.'-]*)"),
         _rx(r"\b\d[\d,.]*\s*[KkMm]?\s+followers\b"),
         _rx(r"\b(?:strong|active) (?:online|digital|social[- ]media) presence\b|\bwidely covered\b|"
             r"\bindependent coverage\b")],
    # (12) vague attributions
    12: [_rx(r"\bexperts? (?:argue|believe|say|claim|note|suggest)\b|\bindustry (?:reports|observers|analysts)\b|"
             r"\bobservers (?:have )?(?:cited|noted)\b|\bsome critics argue\b|\bresearchers have found\b|"
             r"\bstudies suggest\b|\bit is widely believed\b")],
    # (14) conservation / ecosystem padding
    14: [_rx(r"\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b|"
             r"\bconservation efforts are (?:underway|ongoing|in place)\b|\bserves as an indicator species\b|"
             r"\bcontributes to biodiversity\b")],
    # (15) false ranges
    15: [_rx(r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?"
             r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"),
         _rx(r"\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b")],
    # (16) superficial -ing tails
    16: [_rx(r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|"
             r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|"
             r"reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")],
    # (18) "Not X, just Y"
    18: [_rx(r"\b(?:no|not) \w+,\s+(?:just|only|simply) \w+"),
         _rx(r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t) (?:just|merely) (?:a|an|the) "
             r"\w+[,–—-]\s*(?:it[’']s|it is|it was|they[’']re|they are|they were|that[’']s|but)\b")],
    # (19) filler phrases (writing advice)
    19: [_rx(r"\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|\bin the event that\b|"
             r"\bhas the ability to\b|\bit is important to note that\b|\bit should be mentioned that\b|"
             r"\bneedless to say\b")],
    # (20) empty pivot phrases
    20: [_rx(r"\bit[’']s worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b|"
             r"\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b|"
             r"\ba key consideration is\b|\ba point to highlight is\b")],
    # (21) outcome speculation tails
    21: [_rx(r",\s+(?:raising questions about|prompting reflection on|sparking debate about|"
             r"with broader implications for|reshaping our understanding of|paving the way for|"
             r"signaling a shift toward)\b")],
    # (23) editorial interjections
    23: [_rx(r"\bit(?:[’']s| is) important to (?:remember|note|understand|recognize)\b|\bone must note that\b|"
             r"\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasized that\b")],
    # (24) self-thoroughness phrases
    24: [_rx(r"\bthis comprehensive (?:guide|overview|analysis)\b|\bthis in-depth (?:analysis|look|examination)\b|"
             r"\bthis complete (?:guide|overview)\b|\ba thorough examination of\b|"
             r"\beverything you need to know about\b")],
    # (26) "concrete evidence" defense phrase
    26: [_rx(r"\bwithout concrete (?:evidence|proof)\b|\bdo you have concrete evidence\b|"
             r"\bI (?:would )?need concrete (?:evidence|examples) to\b|\babsent concrete proof\b|"
             r"\bprovide concrete evidence\b")],
    # (27) compulsive intro hooks
    27: [_rx(r"\bin today[’']s (?:\w+ ){0,2}?(?:world|landscape|environment|market)\b|\bin a world where\b|"
             r"\bin an era of\b|\bin recent years,|\bmore than ever before\b|\bwe live in a (?:time|world) when\b|"
             r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b|"
             r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?|\b(?:great|exciting|big) news\s*[!:]")],
    # (30) diff-anchored writing
    30: [_rx(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b|"
             r"\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) "
             r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b|"
             r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b|"
             r"\bpreviously\b[^.!?\n]{0,80}\bnow\b|\bwasn[’']t there before\b|\bweren[’']t there before\b|"
             r"\bwe(?:[’']ve| have)(?: now)? (?:added|removed|replaced|refactored|migrated)\b")],
    # (31) signposting and announcements
    31: [_rx(r"\blet[’']s (?:dive|delve|explore)\b|\blet[’']s break (?:this|it) down\b|"
             r"\bhere[’']s what you need to know\b|\bwithout further ado\b|\bnow let[’']s look at\b|"
             r"\bbuckle up\b|\bstay with me\b|\bready to dive in\b")],
    # (32) cataloguing lead-ins
    32: [_rx(r"\b(?:used|uses|employs?|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|"
             r"different|many|numerous) \w+"),
         _rx(r"\bThese (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) "
             r"(?:information|insight|understanding|details|data)\b"),
         _rx(r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|"
             r"lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b")],
    # (36) formulaic challenges
    36: [_rx(r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|\bchallenges and (?:future )?(?:prospects|outlook|"
             r"legacy)\b|\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b|"
             r"\bfaces (?:several|many|numerous) challenges\b")],
    # (39) generic positive conclusions
    39: [_rx(r"\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b|"
             r"\bstep in the right direction\b|\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{0,40})? "
             r"(?:is|looks|remains) bright\b|\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b")],
    # (47) chatbot artifacts (decisive)
    47: [_rx(r"\bI hope this helps\b|\bCertainly!|\bOf course!|\blet me know if you\b|\bwould you like me to\b|"
             r"\bfeel free to (?:ask|reach out)\b|\bhappy to help[.!]|"
             r"\bhere (?:is|are|[’']s) (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b|"
             r"\bhere (?:are|[’']s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b|"
             r"\bhere (?:is|[’']s) (?:or here[’']s )?a draft\b|\bdepending on the (?:vibe|tone|style)\b|"
             r"\bI hope (?:this email )?finds you well\b|\bas an AI\b|\bas an (?:AI assistant|AI language model|LLM)\b|"
             r"\bas a large language model\b|\bto (?:answer|address) your question\b|"
             r"\bin (?:response|answer) to your question\b|\byour question (?:about|regarding|concerning)\b|"
             r"\bas (?:you )?(?:requested|asked), here\b|"
             r"\bhere is (?:the|a) (?:draft|first pass|revised version of|revised version for)\b")],
    # (48) sycophantic tone (decisive)
    48: [_rx(r"\byou(?:[’']re| are) absolutely right\b|"
             r"\b(?:great|excellent|thoughtful|wonderful|fantastic|brilliant) (?:question|point)\s*[!.,]|"
             r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b|"
             r"\bthat[’']s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b")],
    # (50) knowledge-cutoff disclaimers (decisive)
    50: [_rx(r"\bas of my (?:last )?(?:training|knowledge)(?: cutoff)?\b|\bup to my (?:last )?(?:training|knowledge)\b|"
             r"\bwhile specific details are (?:limited|scarce|not (?:extensively |widely )?documented)\b|"
             r"\bbased on (?:the )?available information\b|\bas of my knowledge cutoff\b|"
             r"\bmaintains a low profile\b|\bkeeps (?:his|her|their) personal life private\b")],
    # (51) copula avoidance
    51: [_rx(r"\b(?:serves as|stands as|functions as|acts as|boasts)\b|\brepresents (?:a|the)\b|"
             r"\bmarks (?:a|the)\b(?! (?:turning|milestone|watershed|new))|"
             r"\bfeatures (?:a|an|the|\d[\d,.]*|several|many|numerous|multiple)\b|\boffers a\b|\brefers to\b")],
    # (57) emojis: handled as a character count below
    # (69) canonical marketing phrases
    69: [_rx(r"\bunlocking (?:your |the )?full potential\b|\bnavigating the complexities\b|"
             r"\ba testament to the (?:power|importance) of\b|\bstaying ahead of the curve\b|"
             r"\bturning challenges into opportunities\b|\btaking (?:it|something|your \w+|\w+) to the next level\b|"
             r"\bharnessing the power of\b|\bpaving the way for\b|\bsaying goodbye to\b|"
             r"\bimagining a world where\b")],
    # (64) chat reference markup (decisive)
    64: [_rx(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b|\bnavlist\b|【\d+†")],
    # (65) AI tracking parameters (decisive)
    65: [_rx(r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|"
             r"copilot\.microsoft\.com|poe\.com)(?![\w-]|\.[\w-])")],
    # (63) placeholder text (decisive)
    63: [_rx(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])"),
         _rx(r"\[[A-Z][A-Z _]{2,}\](?![(\[])", 0),
         _rx(r"\{\{[^}\n]*\}\}"),
         _rx(r"\bxxx+\b"),
         _rx(r"\blorem ipsum\b")],
}

# spec: N-000150 N-000151 N-000152 N-000153
_HEDGE_LOWER = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b"
                          r"|\bseems? (?:to|like)\b|\bappears? to\b|\bkind of\b|\bsort of\b")
_MODEL_DIALECT = [_rx(p) for p in (
    r"\bgenuinely\b", r"\bfascinating\b", r"\bnuanced\b", r"\bthoughtfully\b", r"\brefreshingly\b",
    r"\bstrikingly\b", r"\bcompellingly\b", r"\bquietly (?:powerful|profound|radical)\b",
    r"\bdeeply (?:human|personal|felt|unsettling)\b", r"\bresonates deeply\b",
    r"\bgame[- ]chang(?:er|ers|ing)\b", r"\bsupercharg(?:e|es|ed|ing)\b", r"\bskyrocket(?:s|ed|ing)?\b",
    r"\bturbocharg(?:e|es|ed|ing)\b", r"\brevolutioniz(?:e|es|ed|ing)\b", r"\bdouble down on\b",
    r"\bdive deep(?:er)? into\b", r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b",
    r"\btake\b[^.!?\n]{0,60}?\bto the next level\b")]

_MARKETING_VERBS = re.compile(r"^(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|"
                              r"unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|"
                              r"supercharge|level|stop|start)\b", re.I)
_TRANSITIONS = frozenset(['additionally', 'furthermore', 'moreover', 'however', 'nevertheless', 'consequently',
                          'subsequently', 'notably'])
_SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
_SYNONYM_RX = [[(w, _rx(r"\b" + re.escape(w).replace(r"\ ", r"\s+") + r"s?\b")) for w in cluster]
               for cluster in _SYNONYM_CLUSTERS]
_STACK_ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
_STACK_ADJ_STOCK = frozenset(['innovative', 'seamless', 'robust', 'powerful', 'cutting-edge', 'vibrant', 'dynamic',
                              'elegant', 'bold', 'stunning', 'breathtaking', 'comprehensive', 'holistic'])
_STACK_RX = re.compile(r"\b([A-Za-z][\w-]*)(?:,\s*|\s+and\s+)([A-Za-z][\w-]*)(?:,\s*|\s+and\s+)"
                       r"([A-Za-z][\w-]*)(?:,\s*|\s+and\s+)([A-Za-z][\w-]*)\b")
_SMALL_WORDS = frozenset(['a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at',
                          'to', 'by', 'up', 'as', 'with', 'from', 'into', 'onto', 'over', 'off', 'per', 'via', 'vs'])
_CURLY_QUOTE = re.compile("[‘’“”]")
_EMOJI = re.compile('[\U0001F000-\U0001FAFF\u2600-\u27BF]')
_EM = '—'


def _collect(patterns, text):
    count = 0
    samples = []
    for pat in patterns:
        for m in pat.finditer(text):
            count += 1
            if len(samples) < 3:
                samples.append(_snip(text, m.start(), m.end()))
    return count, samples


def _f_model_dialect(text):
    count, samples = _collect(_MODEL_DIALECT, text)
    return (count, samples) if count >= 2 else (0, [])


def _f_stacked(text):
    count = 0
    samples = []
    for m in _STACK_RX.finditer(text):
        words = [m.group(i) for i in range(1, 5)]
        if any(_STACK_ADJ_SUFFIX.search(w) or w.lower() in _STACK_ADJ_STOCK for w in words[:3]):
            count += 1
            if len(samples) < 3:
                samples.append(_snip(text, m.start(), m.end()))
    return count, samples


def _f_synonyms(text):
    total = 0
    samples = []
    for cluster in _SYNONYM_RX:
        used = []
        hits = 0
        for word, rx in cluster:
            found = list(rx.finditer(text))
            if found:
                used.append(word)
                hits += len(found)
                for m in found[:1]:
                    if len(samples) < 3:
                        samples.append(_snip(text, m.start(), m.end()))
        if len(used) >= 3:
            total += hits
    return total, samples


def _f_promotional(text):
    count, samples = _collect(LEXICAL[3], text)
    openers = [s for s in sentences_of(text) if _MARKETING_VERBS.match(s)]
    if len(openers) >= 3:
        count += len(openers)
        for s in openers[:3 - len(samples)]:
            samples.append(s[:80])
    return count, samples


def _f_title_proper(text):
    rx = re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^\n.!?]{1,80}? "
                    r"(?:is|are) (?:a|an|the)\b")
    return _collect([rx], text)


def _f_monotony(sents):
    lengths = [len(WORD_RE.findall(s)) for s in sents]
    cv = _cv(lengths)
    if len(lengths) >= 3 and cv is not None and cv < 0.35:
        return 1, ['%d sentences of similar length' % len(lengths)]
    return 0, []


def _f_uniform_paragraphs(paras):
    lengths = [len(WORD_RE.findall(p)) for p in paras]
    cv = _cv(lengths)
    if len(paras) >= 4 and cv is not None and cv < 0.4:
        return 1, ['%d paragraphs of similar length' % len(paras)]
    return 0, []


def _f_alternation(sents):
    lengths = [len(WORD_RE.findall(s)) for s in sents]
    if len(lengths) < 6:
        return 0, []
    mean = sum(lengths) / float(len(lengths))
    best = run = 0
    prev_d = 0
    for i in range(len(lengths) - 1):
        d = lengths[i + 1] - lengths[i]
        if abs(d) >= 0.4 * mean and d * prev_d < 0:
            run += 1
        else:
            run = 1 if abs(d) >= 0.4 * mean else 0
        best = max(best, run)
        prev_d = d if abs(d) >= 0.4 * mean else 0
    return (1, ['alternating sentence lengths']) if best + 1 >= 6 else (0, [])


def _f_opener_repetition(paras):
    count = 0
    samples = []
    for p in paras:
        sents = sentences_of(p)
        if len(sents) < 3:
            continue
        openers = {}
        for s in sents:
            words = WORD_RE.findall(s)[:2]
            if len(words) == 2:
                key = ' '.join(w.lower() for w in words)
                openers[key] = openers.get(key, 0) + 1
        if openers and max(openers.values()) >= 3:
            count += 1
            if len(samples) < 3:
                samples.append(max(openers, key=openers.get))
    return count, samples


def _f_hedges(sents):
    count = 0
    samples = []
    for s in sents:
        found = _HEDGE_LOWER.findall(s)
        if len(found) >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(s[:80])
    return count, samples


def _f_contractions(text):
    words = WORD_RE.findall(text)
    if not words:
        return 0, []
    first_person = sum(1 for w in words if w.lower() in ('i', 'we', 'my', 'our', 'me', 'us'))
    if first_person < 4 or first_person < 0.02 * len(words):
        return 0, []
    expanded = len(re.findall(r"\b(?:do not|does not|did not|cannot|I am|I will|I have|it is|that is|we are|"
                              r"they are|you are|is not|are not|will not|can not|I would|we will)\b", text))
    contracted = len(re.findall(r"n[’']t\b|[’']re\b|[’']m\b|[’']ll\b|[’']ve\b|"
                                r"[’']d\b|[’']s\b", text))
    if expanded >= 3 and expanded >= 2 * contracted:
        return 1, ['%d expanded forms, %d contractions' % (expanded, contracted)]
    return 0, []


def _f_semicolons(text, words):
    if words < 300:
        return 0, []
    if ';' in text or text.count('(') > 1:
        return 0, []
    return 1, ['no semicolons, almost no parentheses']


def _f_bold(text):
    found = re.findall(r"\*\*[^*\n]+\*\*", text)
    return (len(found), found[:3]) if found else (0, [])


def _f_em_dash_paragraphs(paras):
    count = 0
    samples = []
    for p in paras:
        if p.count(_EM) >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(p[:80])
    return count, samples


_HEADING = re.compile(r"^#{1,6}\s+(.+?)\s*#*\s*$", re.M)


def _f_title_case_headings(text):
    count = 0
    samples = []
    for m in _HEADING.finditer(text):
        heading = m.group(1).strip()
        words = heading.split()
        if len(words) < 3 or not heading[:1].isalpha():
            continue
        if heading.upper() == heading and any(c.isalpha() for c in heading):
            continue
        major = [w for w in words if w.lower().strip('.,:;!?') not in _SMALL_WORDS]
        if len(major) < 2:
            continue
        if all(w[:1].isupper() for w in major):
            count += 1
            if len(samples) < 3:
                samples.append(heading[:80])
    return count, samples


_HEADING_LINE = re.compile(r"^\s*#{1,6}\s")
_LIST_LINE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")


def _f_mid_essay_bullets(text, paras):
    if re.search(r"^#{1,6}\s", text, re.M):
        return 0, []
    lists = [p for p in paras if all(_LIST_LINE.match(ln) for ln in p.split('\n') if ln.strip())]
    prose = [p for p in paras if p not in lists]
    if lists and len(prose) >= 2:
        return len(lists), [lists[0][:80]]
    return 0, []


def _f_fragmented_headers(lines):
    count = 0
    samples = []
    for i, line in enumerate(lines):
        m = re.match(r"^#{1,6}\s+(.*)$", line)
        if not m:
            continue
        heading_words = set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", m.group(1)))
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if _HEADING_LINE.match(nxt) or _LIST_LINE.match(nxt) or nxt.startswith('|'):
            continue
        if len(nxt.split()) > 4:
            continue
        shared = heading_words & set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", nxt))
        if shared:
            count += 1
            if len(samples) < 3:
                samples.append(nxt[:80])
    return count, samples


def _f_transitions(paras):
    count = 0
    samples = []
    for p in paras:
        starts = 0
        for s in sentences_of(p):
            words = WORD_RE.findall(s)
            if words and words[0].lower() in _TRANSITIONS:
                starts += 1
        if starts >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(p[:80])
    return count, samples


_CONCLUDE = re.compile(r"^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|"
                       r"ultimately)\b[,:]?", re.I | re.M)
_LINE_HEAD_MARK = re.compile(r"^[ \t]*(?:[-*+]|\d+\.)?[ \t]*\*\*[^*\n]+(?::\*\*|\*\*:)", re.M)


def _f_inline_headers(text):
    return _collect([_LINE_HEAD_MARK], text)


def _f_chars_from_text(text, pattern):
    found = list(pattern.finditer(text))
    return len(found), [_snip(text, m.start(), m.end()) for m in found[:3]]


_RX_EMOJI = _EMOJI
_RX_CURLY = _CURLY_QUOTE
_RX_YEARS = re.compile(r"\b(1[89]\d\d|20\d\d)-(1[89]\d\d|20\d\d)\b")
_RX_RULE = re.compile(r"^\s*(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$", re.M)


def _f_years(text):
    count = 0
    samples = []
    for m in _RX_YEARS.finditer(text):
        if int(m.group(1)) < int(m.group(2)):
            count += 1
            if len(samples) < 3:
                samples.append(_snip(text, m.start(), m.end()))
    return count, samples


def _f_degenerate(words):
    if len(words) < 12:
        return 0, []
    grams = {}
    total = 0
    for i in range(len(words) - 5):
        g = tuple(w.lower() for w in words[i:i + 6])
        grams[g] = grams.get(g, 0) + 1
        total += 1
    repeated = [g for g, n in grams.items() if n > 1]
    if not repeated:
        return 0, []
    occurrences = sum(grams[g] for g in repeated)
    if occurrences / float(total) >= 0.2:
        return len(repeated), [' '.join(repeated[0])]
    return 0, []


# ---------------------------------------------------------------- scoring

# Family numbers that can move the score; weight 0 means writing advice (reported, never scores).
WEIGHTS = {
    1: 10, 2: 8, 3: 8, 5: 8, 6: 8, 8: 8, 10: 8, 11: 8, 12: 6, 13: 30, 14: 8, 15: 8, 16: 6, 18: 8,
    20: 6, 21: 8, 23: 6, 24: 8, 25: 6, 26: 8, 27: 8, 30: 8, 31: 8, 32: 6, 33: 6, 34: 6, 35: 6,
    36: 6, 37: 6, 38: 6, 39: 6, 40: 5, 44: 5, 47: 30, 48: 30, 50: 30, 51: 6, 56: 4, 57: 10,
    59: 6, 62: 30, 63: 30, 64: 30, 65: 30, 66: 30, 67: 6, 69: 8, 70: 6, 71: 10,
    17: 10,  # tailing-negation form; the parallelism form is advice (weight 0)
}
DECISIVE = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
RHYTHM = frozenset([40, 44])
SHORT_FAMILIES = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])


def band_for(score):
    # spec: N-000098
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def _finding(num, key, label, count, samples, family=None, weight=None):
    return {
        'key': key,
        'family': num if family is None else family,
        'label': label,
        'count': count,
        'samples': samples[:3],
        'weight': WEIGHTS.get(num, 0) if weight is None else weight,
        'decisive': num in DECISIVE and (weight is None),
    }


def _slug(label):
    return re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')


LABELS = {
    1: 'AI vocabulary', 2: 'model-dialect vocabulary', 3: 'promotional language',
    4: 'hyphenated word-pair overuse', 5: 'simple-yet-X cliche', 6: 'stacked adjective chains',
    7: 'rule of three overuse', 8: 'synonym cycling', 9: 'generic character naming',
    10: 'significance inflation', 11: 'notability name-dropping', 12: 'vague attributions',
    13: 'article title as proper noun', 14: 'conservation padding', 15: 'false ranges',
    16: 'superficial -ing tail clauses', 18: 'not-X-just-Y contrast', 19: 'filler phrases',
    20: 'empty pivot phrases', 21: 'outcome speculation tails', 22: 'persuasive authority tropes',
    23: 'editorial interjections', 24: 'self-thoroughness phrases',
    25: 'question-answer rhetorical pattern', 26: 'concrete evidence defense', 27: 'compulsive intro hooks',
    30: 'diff-anchored writing', 31: 'signposting and announcements', 32: 'cataloguing lead-ins',
    33: 'inline-header vertical lists', 34: 'mid-essay bullet injection', 35: 'fragmented headers',
    36: 'formulaic challenges', 37: 'transition cluster overuse', 38: 'compulsive conclusion phrases',
    39: 'generic positive conclusions', 40: 'sentence-length monotony',
    41: 'mechanical sentence-length alternation', 42: 'opener repetition', 44: 'uniform paragraph length',
    46: 'semicolon and parenthesis underuse', 47: 'chatbot artifacts', 48: 'sycophantic tone',
    50: 'knowledge-cutoff disclaimer', 51: 'copula avoidance', 54: 'hedge stacking',
    55: 'contraction absence', 56: 'boldface overuse', 57: 'emoji', 58: 'em-dash overuse',
    59: 'title case in headings', 60: 'curly quotation marks', 61: 'hyphen-for-en-dash in ranges',
    62: 'invisible characters', 63: 'placeholder text', 64: 'chatbot reference markup',
    65: 'AI tracking parameters', 66: 'mixed-script homoglyphs', 67: 'non-standard spaces',
    68: 'trailing whitespace', 69: 'canonical marketing phrases', 70: 'decorative horizontal rules',
    71: 'degenerate repetition',
}
# spec: N-000654 N-000655 N-000712 N-000713 N-000714 N-000717


def analyze(norm, char_counts):
    """Score the normalized window. char_counts: {62, 66, 67, 68: (count, samples)}."""
    # spec: N-000099 N-000100 N-000101 N-000103 N-000105 N-000106 N-000114 N-000115
    # spec: N-000116 N-000118 N-000119 N-000120 N-000121 N-000122 N-000124 N-000125
    # spec: N-000128 N-000129 N-000707 N-000708 N-000709 N-000710 N-000711
    lines = norm.split('\n')
    prose_lines = strip_nonprose(lines)
    prose = '\n'.join(prose_lines)
    paras = paragraphs_of(prose)
    sents = sentences_of(prose)
    words = WORD_RE.findall(prose)
    word_count = len(words)

    found = {}

    def add(num, count, samples, key=None, label=None, family=None, weight=None):
        if count > 0:
            found[key or num] = _finding(num, key or num, label or LABELS[num], count, samples, family, weight)

    for num, patterns in LEXICAL.items():
        count, samples = _collect(patterns, prose)
        if num == 3:
            count, samples = _f_promotional(prose)
        add(num, count, samples)
    count, samples = _f_model_dialect(prose)
    add(2, count, samples)
    count, samples = _f_stacked(prose)
    add(6, count, samples)
    count, samples = _f_synonyms(prose)
    add(8, count, samples)
    count, samples = _f_title_proper(prose)
    add(13, count, samples)
    count, samples = _f_monotony(sents)
    add(40, count, samples)
    count, samples = _f_uniform_paragraphs(paras)
    add(44, count, samples)
    count, samples = _f_alternation(sents)
    add(41, count, samples)
    count, samples = _f_opener_repetition(paras)
    add(42, count, samples)
    count, samples = _f_hedges(sents)
    add(54, count, samples)
    count, samples = _f_contractions(prose)
    add(55, count, samples)
    count, samples = _f_semicolons(prose, word_count)
    add(46, count, samples)
    count, samples = _f_bold(prose)
    add(56, count, samples)
    count, samples = _f_em_dash_paragraphs(paras)
    add(58, count, samples)
    count, samples = _f_title_case_headings(prose)
    add(59, count, samples)
    count, samples = _f_mid_essay_bullets(prose, paras)
    add(34, count, samples)
    count, samples = _f_fragmented_headers(prose_lines)
    add(35, count, samples)
    count, samples = _f_transitions(paras)
    add(37, count, samples)
    count, samples = _f_inline_headers(prose)
    add(33, count, samples)
    count, samples = _f_chars_from_text(prose, _CONCLUDE)
    add(38, count, samples)
    count, samples = _f_chars_from_text(prose, _RX_EMOJI)
    add(57, count, samples)
    count, samples = _f_chars_from_text(prose, _RX_CURLY)
    add(60, count, samples)
    count, samples = _f_years(prose)
    add(61, count, samples)
    count, samples = _f_chars_from_text(prose, _RX_RULE)
    if count >= 3 and len(lines) >= 24:
        add(70, count, samples)
    count, samples = _f_degenerate(WORD_RE.findall(prose))
    add(71, count, samples)
    # the parallelism form of 17 is advice; the tailing-negation form scores
    par = re.compile(r"\bit[’']s not (?:just|merely) (?:about|a|an)\b|\bnot only\b[^.!?\n]{0,40}?\bbut\b|"
                     r"\bdoesn[’']t just\b[^,.\n]{0,40}?\bit\b", re.I)
    count, samples = _collect([par], prose)
    add(17, count, samples, key='17_negative_parallelism', label='negative parallelism', family=17, weight=0)
    tail = re.compile(r",\s+no\s+(?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", re.I)
    count, samples = _collect([tail], prose)
    add(17, count, samples, key='17_tailing_negation', label='tailing negation', family=17, weight=10)
    # character layer (computed on the window by the caller)
    for num in (62, 66, 67, 68):
        count, samples = char_counts.get(num, (0, []))
        add(num, count, samples, weight=None)
    # advice-only numbers never move the score
    for num in (4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68):
        if num in found:
            found[num]['weight'] = 0

    ordered = sorted(found.values(), key=lambda f: (f['family'], f['key']))
    for f in ordered:
        f['decisive'] = f['family'] in DECISIVE and f['weight'] > 0

    moving = set(f['family'] for f in ordered if f['weight'] > 0)
    decisive = set(f['family'] for f in ordered if f['decisive'])
    total = 0.0
    for f in ordered:
        if f['weight'] > 0:
            total += f['weight'] * min(1 + 0.2 * (f['count'] - 1), 2.0)
    raw = min(100, int(round(total)))

    confidence, reason = _confidence(word_count, len(moving))
    floor = 0
    keep_cap = True
    if len(decisive) >= 2:
        floor = max(floor, 65)
        keep_cap = False
    elif len(decisive) == 1 and confidence in ('moderate', 'high'):
        floor = max(floor, 45)
        keep_cap = False
    if word_count < 120:
        n = len(moving & SHORT_FAMILIES)
        if n >= 3:
            floor = max(floor, 45)
        elif n == 2:
            floor = max(floor, 25)
    elif word_count >= 400:
        n = len(moving)
        if n >= 6:
            floor = max(floor, 45)
        elif n >= 5:
            floor = max(floor, 25)
    score = max(raw, floor)
    if keep_cap and len(moving) == 1:
        score = min(score, 40)
    if moving and moving <= RHYTHM:
        score = min(score, 20 if moving == frozenset([40]) else 40)
    score = max(0, min(100, score))
    return {
        'findings': ordered,
        'score': score,
        'band': band_for(score),
        'confidence': confidence,
        'confidence_reason': reason,
        'words': word_count,
        'moving': len(moving),
    }


def _confidence(words, moving):
    # spec: N-000128 N-000129 N-000023 N-000649 N-000650
    if words < 40:
        return 'none', 'only %d words; too short to score' % words
    if words < 120:
        return 'low', 'only %d words; short text' % words
    if words < 300 and moving == 1:
        return 'low', 'only one score-moving pattern family in %d words' % words
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def char_layer_counts(window):
    """Counts for families 62, 66, 67 and 68 over the scan window."""
    # spec: N-000154 N-000160 N-000161 N-000164 N-000165 N-000279 N-000280
    _, invisible, nonstd = char_pass(window, keep_nbsp=True)
    _, homoglyphs = fold_homoglyphs(char_pass(window, keep_nbsp=True)[0])
    lines = window.split('\n')
    trailing = []
    for i, line in enumerate(lines):
        body = line[:-1] if line.endswith('\r') else line
        if body != body.rstrip(' \t'):
            trailing.append(body[-40:])
    if window.endswith((' ', '\t')):
        trailing.append('end of text')
    if window.endswith('\n\n'):
        trailing.append('blank lines at end')
    if window[:1].isspace():
        trailing.append('leading whitespace')
    return {
        62: (invisible, ['U+%04X' % ord(c) for c in window if is_invisible(c)][:3]),
        66: (homoglyphs, []),
        67: (nonstd, ['U+%04X' % ord(c) for c in window if is_nonstandard_space(c)][:3]),
        68: (len(trailing), trailing[:3]),
    }


def _homoglyph_samples(window):
    out = []
    for tok in _TOKEN_RE.findall(window):
        folded, n = fold_homoglyphs(tok)
        if n and len(out) < 3:
            out.append(tok[:40])
    return out


def scan(text, ci=False):
    """Build the full JSON report for extracted prose."""
    # spec: N-000705 N-000718 N-000719 N-000720 N-000721 N-000722 N-000726 N-000727
    # spec: N-000728 N-000729 N-000730 N-000731 N-000732
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    norm, invisible, nonstd = char_pass(window, keep_nbsp=False)
    norm, _ = fold_homoglyphs(norm)
    counts = char_layer_counts(window)
    counts[66] = (counts[66][0], _homoglyph_samples(window))
    result = analyze(norm, counts)

    report = {}
    for f in result['findings']:
        # keys are "<catalogue number>_<slug>"; 17 keeps its two exact forms
        key = f['key'] if isinstance(f['key'], str) else '%d_%s' % (f['family'], _slug(f['label']))
        report[key] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': result['score'],
        'ai_tell_band': result['band'],
        'confidence': result['confidence'],
        'confidence_reason': result['confidence_reason'],
        'patterns_flagged': len(result['findings']),
        'invisible_chars': invisible,
        'nonstandard_spaces': nonstd,
        'homoglyphs': counts[66][0],
        'words': result['words'],
    }
    if ci:
        low, high, note = resample_interval(norm, result['words'])
        metrics['score_ci'] = None if low is None else [low, high]
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


def resample_interval(norm, words):
    """Bootstrap interval over sentences; fixed seed so the output is repeatable."""
    # spec: N-000729 N-000730 N-000731 N-000205 N-000206 N-000207 N-000209
    sents = sentences_of(norm)
    if len(sents) < 4:
        return None, None, 'too few sentences for an interval (need at least four)'
    rounds = 100 if words <= 5000 else (40 if words <= 20000 else 20)
    rng = random.Random(7)
    scores = []
    for _ in range(rounds):
        pick = [sents[rng.randrange(len(sents))] for _ in sents]
        scores.append(analyze('\n'.join(pick), {})['score'])
    scores.sort()
    low = scores[int(0.05 * rounds)]
    high = scores[min(rounds - 1, int(0.95 * rounds))]
    return low, high, '90%% resampled interval over %d sentences (%d resamples, fixed seed)' % (len(sents), rounds)


# ---------------------------------------------------------------- cleanup

def scrub(text):
    """Scrubbed plain text: invisible characters removed, spacing normalized, trailing space trimmed."""
    # spec: N-000288 N-000290 N-000293 N-000299 N-000300 N-000301 N-000302 N-000316
    newline = '\r\n' if '\r\n' in text else '\n'
    ended_with_lf = text.endswith('\n')
    body, _, _ = char_pass(text, keep_nbsp=True)
    body, _ = fold_homoglyphs(body)
    lines = body.split('\n')
    cleaned = []
    for line in lines:
        cr = line.endswith('\r')
        content = line[:-1] if cr else line
        cleaned.append(content.rstrip(' \t'))
    while cleaned and not cleaned[0].strip():
        cleaned.pop(0)
    out = newline.join(cleaned).rstrip()
    if ended_with_lf and out:
        out += newline
    return out


# ---------------------------------------------------------------- command line

def _write_out(data):
    sys.stdout.buffer.write(data.encode('utf-8'))
    sys.stdout.flush()


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    clean = False
    ci = False
    operands = []
    end_of_options = False
    for arg in args:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_options = True
            continue
        if arg in ('-h', '--help'):
            _write_out(USAGE)
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            ci = True
            continue
        if arg.startswith('-'):
            return fail("unknown option %s; see --help" % arg, 2)
        operands.append(arg)

    if len(operands) > 1:
        sys.stderr.buffer.write(('note: scanning only the first file: %s (%d more ignored)\n'
                                 % (operands[0], len(operands) - 1)).encode('utf-8'))
        sys.stderr.flush()
    path = operands[0] if operands else None

    try:
        raw = read_source(path)
        ext = os.path.splitext(path)[1].lower() if path else ''
        text = extract_prose(raw, ext)
    except ReadError as exc:
        return fail(str(exc), 1)

    if not text or not text.strip():
        return fail('empty input', 1)

    if clean:
        _write_out(scrub(text))
        return 0

    report = scan(text, ci=ci)
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
