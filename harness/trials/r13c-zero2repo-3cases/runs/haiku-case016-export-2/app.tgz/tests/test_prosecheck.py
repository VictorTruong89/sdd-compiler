"""Tests for the prosecheck detector and its acceptance criteria. Run: python3 -m unittest discover -s tests"""
import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')


def run_detect(args=(), stdin=b''):
    proc = subprocess.run([sys.executable, DETECT] + list(args), input=stdin, capture_output=True, timeout=120)
    return proc.returncode, proc.stdout, proc.stderr


class DetectorContract(unittest.TestCase):
    def test_help_first_line_is_exact(self):
        code, out, _ = run_detect(['--help'])
        self.assertEqual(code, 0)
        self.assertEqual(out.decode('utf-8').splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_empty_input_is_an_error_object(self):
        code, out, err = run_detect([], stdin=b'   \n')
        self.assertEqual(code, 1)
        self.assertEqual(out, b'')
        self.assertEqual(json.loads(err.decode('utf-8').strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unknown_option_exit_two(self):
        code, out, err = run_detect(['--bogus'])
        self.assertEqual(code, 2)
        self.assertEqual(out, b'')
        message = json.loads(err.decode('utf-8').strip().splitlines()[-1])['error']
        self.assertIn('unknown option', message)
        self.assertIn('--bogus', message)
        self.assertIn('--help', message)
        self.assertNotIn('Traceback', err.decode('utf-8'))

    def test_report_shape_and_keys(self):
        code, out, _ = run_detect([], stdin=b'It is crucial to delve into the robust landscape. Certainly! Here it is.')
        self.assertEqual(code, 0)
        report = json.loads(out.decode('utf-8'))
        metrics = report['_metrics']
        for key in ('scanned_chars', 'truncated', 'ai_tell_score', 'ai_tell_band', 'confidence', 'confidence_reason',
                    'patterns_flagged', 'invisible_chars', 'nonstandard_spaces', 'homoglyphs'):
            self.assertIn(key, metrics)
        self.assertIn('1_ai_vocabulary', report)
        self.assertIn('label', report['1_ai_vocabulary'])
        self.assertTrue(0 <= metrics['ai_tell_score'] <= 100)

    def test_tailing_negation_and_parallelism_keys(self):
        text = (b"It is fast, no guessing. It is not just about speed, it's not just about cost, and it is what it is "
                b"for many teams who ship. The tool is quick and it saves real time for everyone on the team every week.")
        _, out, _ = run_detect([], stdin=text)
        keys = [k for k in json.loads(out.decode('utf-8')) if k.startswith('17_')]
        self.assertEqual(sorted(keys), ['17_negative_parallelism', '17_tailing_negation'])

    def test_two_decisive_families_raise_floor(self):
        text = 'Certainly! I hope this helps.​​ and more text here.'.encode('utf-8')
        _, out, _ = run_detect([], stdin=text)
        metrics = json.loads(out.decode('utf-8'))['_metrics']
        self.assertGreaterEqual(metrics['ai_tell_score'], 65)

    def test_two_files_scan_first_and_notice_names_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            first = os.path.join(tmp, 'first.md')
            second = os.path.join(tmp, 'second.md')
            with open(first, 'w', encoding='utf-8') as fh:
                fh.write('This is the first file with enough plain words to be scanned.')
            with open(second, 'w', encoding='utf-8') as fh:
                fh.write('Second file.')
            code, out, err = run_detect([first, second])
            self.assertEqual(code, 0)
            self.assertIn('scanned_chars', json.loads(out.decode('utf-8'))['_metrics'])
            self.assertIn(first, err.decode('utf-8'))


class CleanupAcceptance(unittest.TestCase):
    def test_N_000292_cleanup_leaves_zero_invisible_hits(self):
        raw = 'Hello​ world⁠ with﻿ hidden­­ marks.\n'.encode('utf-8')
        _, cleaned, _ = run_detect(['--clean'], stdin=raw)
        _, out, _ = run_detect([], stdin=cleaned)
        self.assertEqual(json.loads(out.decode('utf-8'))['_metrics']['invisible_chars'], 0)

    def test_N_000296_cleanup_leaves_zero_nonstandard_space_hits(self):
        raw = 'Spacing　here and there    done.\n'.encode('utf-8')
        _, cleaned, _ = run_detect(['--clean'], stdin=raw)
        _, out, _ = run_detect([], stdin=cleaned)
        self.assertEqual(json.loads(out.decode('utf-8'))['_metrics']['nonstandard_spaces'], 0)


if __name__ == '__main__':
    unittest.main()
