"""Exception classes and their standalone exit statuses (FP-13)."""


class OptlynError(Exception):
    """Base class for errors signalled by Optlyn."""

    exit_code = 1

    def __init__(self, message=None, ctx=None, param=None):
        super().__init__(message)
        self.message = message or ""
        self.ctx = ctx
        self.param = param

    def show(self, file=None):
        import sys

        print(f"Error: {self.message}", file=file or sys.stderr)


class UsageError(OptlynError):
    """Incorrect usage; standalone exit status 2."""

    exit_code = 2


class BadParameter(UsageError):
    """A parameter value was refused (conversion or callback)."""


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""


class NoSuchOption(UsageError):
    """An unknown option token."""


class Abort(OptlynError):
    """User or author abort; standalone exit status 1."""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)


class Exit(Exception):
    """Author clean stop or intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
