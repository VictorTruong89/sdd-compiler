"""In-process runner (FP-14): ``optlyn.testing.CliRunner``."""

import contextlib
import io
import os
import shutil
import sys
import tempfile

from .exceptions import Exit


class Result:
    """Captured outcome of one ``CliRunner.invoke`` call."""

    def __init__(self, exit_code, stdout_bytes, stderr_bytes, exception=None):
        self.exit_code = exit_code
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.exception = exception

    @property
    def stdout(self):
        return self.stdout_bytes.decode("utf-8", "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode("utf-8", "replace")

    @property
    def output(self):
        return self.stdout + self.stderr


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False,
                 catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None):
        out = io.BytesIO()
        err = io.BytesIO()
        stdin_bytes = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        old = (sys.stdin, sys.stdout, sys.stderr)
        in_wrap = io.TextIOWrapper(io.BytesIO(stdin_bytes), encoding=self.charset)
        out_wrap = io.TextIOWrapper(out, encoding=self.charset, write_through=True)
        err_wrap = io.TextIOWrapper(err, encoding=self.charset, write_through=True)
        sys.stdin, sys.stdout, sys.stderr = in_wrap, out_wrap, err_wrap
        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for k, v in merged.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        try:
            yield out, err
        finally:
            out_wrap.flush()
            err_wrap.flush()
            sys.stdin, sys.stdout, sys.stderr = old
            # Detach so the wrappers do not close the underlying buffers.
            out_wrap.detach()
            err_wrap.detach()
            in_wrap.detach()
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = args.split()
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env) as (out, err):
            try:
                extra.setdefault("color", color)
                extra.setdefault("standalone_mode", True)
                cli.main(args=list(args or []), **extra)
            except SystemExit as e:
                exit_code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
            except Exit as e:
                exit_code = e.exit_code
            except Exception as e:  # noqa: BLE001 - reported on Result
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
        return Result(exit_code, out.getvalue(), err.getvalue(), exception)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
