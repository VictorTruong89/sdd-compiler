"""Terminal output helpers: echo, styling, unstyling (FP-11)."""

import re
import sys

from .core import get_current_context

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 0,
}
_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _color_code(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"unknown color {color!r}")
        code = _COLORS[color]
        if background and code != 0:
            code += 10
        return f"{code}"
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError("color index must be 0-255")
        return f"{base + 8}8;5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base + 8}8;2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise TypeError."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    flags = {"bold": bold, "dim": dim, "underline": underline, "overline": overline,
             "italic": italic, "blink": blink, "reverse": reverse,
             "strikethrough": strikethrough}
    for name, on in flags.items():
        if on is not None:
            bits.append(str(_SWITCHES[name] if on else _SWITCHES[name] + 20))
    if not bits:
        return str(text)
    prefix = f"\x1b[{';'.join(bits)}m"
    return prefix + str(text) + ("\x1b[0m" if reset else "")


def unstyle(text):
    """Remove ANSI style sequences; other text is unchanged."""
    return _ANSI_RE.sub("", str(text))


def _use_color(file, color):
    if color is not None:
        return bool(color)
    ctx = get_current_context(silent=True)
    if ctx is not None and ctx.color is not None:
        return bool(ctx.color)
    return bool(getattr(file, "isatty", lambda: False)())


def _write(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        enc = getattr(file, "buffer", None)
        if enc is not None:
            enc.write(text.encode("utf-8"))
        else:
            file.write(text.encode("utf-8", "replace").decode("ascii", "replace"))


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes; strips styles unless the stream is a terminal or color is forced."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        target = getattr(file, "buffer", file)
        target.write(message + (b"\n" if nl else b""))
        return
    text = str(message)
    if not _use_color(file, color):
        text = unstyle(text)
    _write(file, text + ("\n" if nl else ""))
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """echo() of a styled message."""
    if message is not None and styles:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)
