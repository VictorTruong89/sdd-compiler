"""Optlyn: command line interface composition kit."""

from .core import Argument, Command, Context, Group, Option, Parameter, get_current_context
from .decorators import (
    argument,
    command,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    version_option,
)
from .exceptions import Abort, BadParameter, Exit, MissingParameter, NoSuchOption, UsageError
from .terminal import echo, secho, style, unstyle
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    FloatRange,
    IntRange,
    ParamType,
    Tuple,
)

__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "pass_context", "pass_obj", "make_pass_decorator",
    "Command", "Group", "Context", "Option", "Parameter", "ParamType",
    "BadParameter", "Abort", "UsageError", "MissingParameter", "NoSuchOption", "Exit",
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
    "echo", "secho", "style", "unstyle", "get_current_context",
]
