"""Text wrapping helpers for help pages."""

import textwrap


def wrap_text(text, width=78, indent=0, preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns; never fails on any string."""
    if text is None:
        return ""
    text = str(text)
    prefix = " " * indent
    paragraphs = text.split("\n\n") if preserve_paragraphs else [text]
    out = []
    for para in paragraphs:
        # Single newlines are not hard breaks inside a paragraph.
        flat = " ".join(line.strip() for line in para.splitlines() if line.strip())
        if not flat:
            continue
        out.append(
            textwrap.fill(
                flat,
                width=max(width, indent + 1),
                initial_indent=prefix,
                subsequent_indent=prefix,
            )
        )
    return "\n\n".join(out)
