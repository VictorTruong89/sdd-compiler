"""Help page rendering (FP-02, section 2 of the contract)."""

from .core import Argument, Group, Option
from .formatting import wrap_text


def _usage(cmd, ctx):
    parts = [ctx.prog_name]
    if isinstance(cmd, Group):
        parts.append(cmd.name and f"{cmd.name}" or "")
    elif cmd.name:
        parts.append(cmd.name)
    if any(isinstance(p, Option) and not p.hidden for p in cmd.params) or cmd.options_metavar:
        parts.append(cmd.options_metavar or "[OPTIONS]")
    for p in cmd.params:
        if isinstance(p, Argument):
            label = p.metavar or p.name.upper()
            if p.nargs == -1:
                label += "..."
            parts.append(label if p.required else f"[{label}]")
    if isinstance(cmd, Group):
        if cmd.subcommand_metavar:
            parts.append(cmd.subcommand_metavar)
        else:
            parts.append("COMMAND [ARGS]...")
    return "Usage: " + " ".join(p for p in parts if p)


def _option_entry(p):
    names = ", ".join(p.opts)
    if p.takes_value and p.metavar:
        names += f" {p.metavar}"
    elif p.takes_value:
        names += f" {p.type.name.upper()}"
    text = p.help or ""
    extras = []
    if p.show_default and p.default is not None and not (p.is_flag and p.default is False):
        extras.append(f"default: {p.default}")
    if p.show_envvar and p.envvar:
        extras.append(f"env var: {p.envvar[0]}")
    if extras:
        text = (text + " " if text else "") + f"[{'; '.join(extras)}]"
    return names, text


def format_help(cmd, ctx):
    """Return the help page text for ``cmd`` in ``ctx``."""
    width = ctx.terminal_width or min(ctx.max_content_width, 80)
    lines = [_usage(cmd, ctx), ""]
    if cmd.help:
        lines.append(wrap_text(cmd.help, width=width))
        lines.append("")
    args = [p for p in cmd.params if isinstance(p, Argument) and p.help and not p.hidden]
    if args:
        lines.append("Positional arguments:")
        for a in args:
            label = a.metavar or a.name.upper()
            lines.append(f"  {label}  {a.help}")
        lines.append("")
    opts = [p for p in cmd.params if isinstance(p, Option) and not p.hidden and p.expose_value]
    help_names = ctx.help_option_names if cmd.add_help_option else []
    if opts or help_names:
        lines.append("Options:")
        for p in opts:
            names, text = _option_entry(p)
            lines.append(f"  {names}" + (f"  {text}" if text else ""))
        if help_names:
            lines.append(f"  {', '.join(help_names)}  Show this message and exit.")
        lines.append("")
    if isinstance(cmd, Group):
        visible = [
            (n, c) for n in cmd.list_commands(ctx)
            if (c := cmd.get_command(ctx, n)) is not None and not c.hidden
        ]
        if visible:
            lines.append("Commands:")
            for n, c in visible:
                short = c.short_help or (c.help or "").split(".")[0].strip()
                lines.append(f"  {n}  {short}".rstrip())
            lines.append("")
    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")
    return "\n".join(lines) + "\n"
