"""Parameter types and conversion (FP-05)."""

import datetime as _dt
import enum
import uuid as _uuid

from .exceptions import BadParameter

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)


class _String(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value if isinstance(value, str) else str(value)


class _Int(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            raise BadParameter("not a valid integer", ctx, param)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            raise BadParameter(f"{value!r} is not a valid integer", ctx, param)


class _Float(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            raise BadParameter(f"{value!r} is not a valid float", ctx, param)


class _Bool(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        raise BadParameter(f"{value!r} is not a valid boolean", ctx, param)


class _UUID(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            raise BadParameter(f"{value!r} is not a valid UUID", ctx, param)


class _Unprocessed(ParamType):
    name = "text"


STRING = _String()
INT = _Int()
FLOAT = _Float()
BOOL = _Bool()
UUID = _UUID()
UNPROCESSED = _Unprocessed()


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum = choices
            self.choices = list(choices.__members__.items())  # (name, member)
            self._items = [(n, m) for n, m in self.choices]
        else:
            self.enum = None
            self._items = [(str(c), c) for c in choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(n for n, _ in self._items) + "]"

    def convert(self, value, param=None, ctx=None):
        for name, original in self._items:
            if value == name:
                return original
        if not self.case_sensitive:
            folded = str(value).casefold()
            for name, original in self._items:
                if folded == name.casefold():
                    return original
        allowed = ", ".join(n for n, _ in self._items)
        raise BadParameter(f"{value!r} is not one of {allowed}", ctx, param)


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = tuple(formats) if formats is not None else self.DEFAULT_FORMATS

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        raise BadParameter(f"{value!r} does not match the date-time formats", ctx, param)


class IntRange(ParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = _INT.convert(value, param, ctx)
        lo_bad = self.min is not None and (value < self.min or (self.min_open and value == self.min))
        hi_bad = self.max is not None and (value > self.max or (self.max_open and value == self.max))
        if not (lo_bad or hi_bad):
            return value
        if not self.clamp:
            raise BadParameter(f"{value} is out of the allowed range", ctx, param)
        if lo_bad:
            return self.min + 1 if self.min_open else self.min
        return self.max - 1 if self.max_open else self.max


class FloatRange(ParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("clamp is only allowed when both bounds are closed")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = _FLOAT.convert(value, param, ctx)
        if self.min is not None and value < self.min:
            if self.clamp:
                return float(self.min)
            raise BadParameter(f"{value} is out of the allowed range", ctx, param)
        if self.max is not None and value > self.max:
            if self.clamp:
                return float(self.max)
            raise BadParameter(f"{value} is out of the allowed range", ctx, param)
        return value


class Tuple(ParamType):
    name = "tuple"

    def __init__(self, types):
        self.types = [_resolve(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            raise BadParameter(f"expected {len(self.types)} values", ctx, param)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


_INT = INT
_FLOAT = FLOAT


def _resolve(t):
    """Turn a builtin Python type or a conversion function into a ParamType."""
    if isinstance(t, ParamType):
        return t
    if t is str:
        return STRING
    if t is int:
        return INT
    if t is float:
        return FLOAT
    if t is bool:
        return BOOL
    return _FuncType(t)


class _FuncType(ParamType):
    """Adapter for a conversion function that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "value")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError:
            raise BadParameter(f"{value!r} is not valid", ctx, param)


def infer_type(default):
    """Infer a built-in type from a default value (FP-05)."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, _uuid.UUID):
        return UUID
    return None
