"""Declaration decorators: command, group, option, argument, and helpers (section 3-4)."""

import functools
import sys

from .core import Argument, Command, Context, Group, Option, get_current_context
from .exceptions import Exit


def _attach(f, param):
    """Store a declaration on ``f``; applied bottom-up so the list is reversed later."""
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)
    return f


def _pop_params(f):
    """Move declarations off ``f`` (they belong to the new command now)."""
    params = list(getattr(f, "__optlyn_params__", []))
    params.reverse()
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _derive_name(func_name):
    name = func_name.lower().replace("_", "-")
    for suffix in ("-command", "-cmd", "-group", "-grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def _make(cls, name, f, attrs):
    if callable(name) and f is None:  # used as bare @command
        f, name = name, None
    if f is None:
        def decorator(func):
            return _make(cls, name, func, attrs)
        return decorator
    params = _pop_params(f)
    explicit = name
    cmd_name = explicit if explicit is not None else _derive_name(f.__name__)
    if attrs.get("help") is None and f.__doc__:
        # Form feed truncates the help text (FP-02).
        attrs = dict(attrs)
        attrs["help"] = f.__doc__.split("\f", 1)[0].strip()
    return cls(name=cmd_name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    """Decorate a function as a leaf command."""
    return _factory(cls or Command, name, attrs)


def _factory(cls, name, attrs):
    def decorator(f):
        return _make(cls, name, f, attrs)

    if callable(name):
        return _make(cls, None, name, attrs)
    return decorator


def group(name=None, cls=None, **attrs):
    """Decorate a function as a group."""
    return _factory(cls or Group, name, attrs)


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function it decorates."""
    def decorator(f):
        return _attach(f, (cls or Option)(param_decls=param_decls, **attrs))
    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function it decorates."""
    def decorator(f):
        return _attach(f, (cls or Argument)(param_decls=param_decls, **attrs))
    return decorator


def help_option(*param_decls, **kwargs):
    """Extra eager help flag; prints the help page and exits."""
    decls = param_decls or ("--help",)

    def callback(ctx, param, value):
        if value:
            ctx.command._print_help(ctx)
            raise Exit(0)
        return value

    def decorator(f):
        opt = Option(param_decls=decls, is_flag=True, expose_value=False,
                     is_eager=True, callback=callback, **kwargs)
        return _attach(f, opt)
    return decorator


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Eager version flag. ``version=None`` detects the version via ``package_name``."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return value
        ver = version
        if ver is None:
            ver = _detect_version(package_name or prog_name or ctx.prog_name)
        pname = prog_name or ctx.prog_name
        text = message % {"prog": pname, "package": package_name or pname, "version": ver} \
            if message else f"{pname}, version {ver}"
        sys.stdout.write(text + "\n")
        raise Exit(0)

    def decorator(f):
        return _attach(f, Option(param_decls=decls, is_flag=True, expose_value=False,
                                 is_eager=True, callback=callback, **kwargs))
    return decorator


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Eager version flag whose whole identity is ``callback_fn(ctx)``."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return value
        sys.stdout.write(str(callback_fn(ctx)) + "\n")
        raise Exit(0)

    def decorator(f):
        return _attach(f, Option(param_decls=decls, is_flag=True, expose_value=False,
                                 is_eager=True, callback=callback, **kwargs))
    return decorator


def _detect_version(name):
    from importlib import metadata

    try:
        return metadata.version(name)
    except Exception:
        return "unknown"


def pass_context(f):
    """Pass the current ``Context`` as the first argument."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return wrapper


def pass_obj(f):
    """Pass the current context's author object as the first argument."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return wrapper


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest ``object_type`` instance found walking up the context chain."""
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            ctx = get_current_context()
            node = ctx
            found = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    found = node.obj
                    break
                node = node.parent
            if found is None:
                if not ensure:
                    raise RuntimeError(f"no {object_type.__name__} object on the context")
                found = object_type()
                ctx.obj = found
            return f(found, *args, **kwargs)
        return wrapper
    return decorator
