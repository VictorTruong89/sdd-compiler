"""Commands, groups, parameters, invocation context, and parsing (FP-01..FP-07)."""

import os
import sys
from contextlib import ExitStack

from .exceptions import Abort, BadParameter, Exit, MissingParameter, NoSuchOption, UsageError
from .types import BOOL, INT, STRING, _resolve, infer_type

SOURCE_PROMPT = "prompt"
SOURCE_COMMANDLINE = "commandline"
SOURCE_ENVIRONMENT = "environment"
SOURCE_DEFAULT_MAP = "default_map"
SOURCE_DEFAULT = "default"

_MISSING = object()
_local = None  # the context current on this thread


def get_current_context(silent=False):
    if _local is None and not silent:
        raise RuntimeError("There is no active Optlyn context.")
    return _local


class Context:
    """Per-invocation state (section 6 of the contract)."""

    def __init__(self, command, parent=None, obj=None, prog_name=None, **settings):
        self.command = command
        self.parent = parent
        self.obj = obj if obj is not None else (parent.obj if parent else None)
        self.prog_name = prog_name or (parent.prog_name if parent else os.path.basename(sys.argv[0]))
        merged = dict(parent._settings if parent else {})
        merged.update(command.context_settings or {})
        merged.update(settings)
        self._settings = merged
        self.params = {}
        self.invoked_subcommand = None
        self._sources = {}
        self._exit_stack = ExitStack()
        self._prev = []
        self.help_option_names = list(merged.get("help_option_names", ["--help"]))
        self.color = merged.get("color")
        self.terminal_width = merged.get("terminal_width")
        self.max_content_width = merged.get("max_content_width", 80)
        self.allow_extra_args = merged.get("allow_extra_args", False)
        self.ignore_unknown_options = merged.get("ignore_unknown_options", False)
        self.auto_envvar_prefix = merged.get("auto_envvar_prefix")
        self.default_map = merged.get("default_map")
        self.token_normalize_func = merged.get("token_normalize_func")

    def __enter__(self):
        global _local
        self._prev.append(_local)
        _local = self
        return self

    def __exit__(self, exc_type, exc, tb):
        global _local
        _local = self._prev.pop()
        return False

    def close(self):
        self._exit_stack.close()

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def get_parameter_source(self, name):
        return self._sources.get(name)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, cmd, **values):
        """Run ``cmd`` with exactly ``values`` as its parameters."""
        sub = Context(cmd, parent=self, prog_name=self.prog_name)
        with sub:
            for p in cmd.params:
                if p.name in values:
                    sub.params[p.name] = values[p.name]
                    sub._sources[p.name] = SOURCE_COMMANDLINE
            return cmd._run_callback(sub)

    def forward(self, cmd, **values):
        """Run ``cmd`` with this command's values, overridden by ``values``."""
        merged = dict(self.params)
        merged.update(values)
        return self.invoke(cmd, **merged)

    def __repr__(self):
        return f"<Context {self.command.name}>"


class Parameter:
    """Base class for options and arguments."""

    def __init__(self, name, type=None, default=None, required=False, callback=None,
                 nargs=1, multiple=False, envvar=None, metavar=None, expose_value=True,
                 is_eager=False, deprecated=False, help=None, hidden=False,
                 show_default=False, show_envvar=False):
        self.name = name
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.envvar = [envvar] if isinstance(envvar, str) else list(envvar or [])
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        if type is not None:
            self.type = _resolve(type)
        else:
            self.type = infer_type(default) or STRING

    def get_default(self, ctx):
        d = self.default
        return d() if callable(d) else d

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter, declared with ``option()``."""

    def __init__(self, param_decls=(), is_flag=None, flag_value=None, count=False, **attrs):
        decls = list(param_decls)
        self.flag_names = []
        self.secondary_names = []
        dests = []
        for d in decls:
            if d[:1] in ("-", "+", "/") and len(d) > 1:
                if "/" in d[1:] and d[:1] in ("-", "+"):
                    on, off = d.split("/", 1)
                    self.flag_names.append(on)
                    self.secondary_names.append(off)
                else:
                    self.flag_names.append(d)
            else:
                dests.append(d)
        self.count = count
        if count:
            is_flag = False
        self.is_flag = bool(is_flag) if is_flag is not None else bool(self.secondary_names)
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        name = dests[0] if dests else _name_from_decls(self.flag_names + self.secondary_names)
        super().__init__(name, **attrs)
        if count:
            self.type = INT
            if self.default is None:
                self.default = 0
        if self.is_flag and self.default is None:
            self.default = False
        if self.is_flag and "type" not in attrs:
            self.type = BOOL
        self.opts = self.flag_names + self.secondary_names

    @property
    def takes_value(self):
        return not (self.is_flag or self.count)


class Argument(Parameter):
    """A positional parameter, declared with ``argument()``."""

    def __init__(self, param_decls=(), **attrs):
        decls = list(param_decls)
        if len(decls) != 1:
            raise TypeError("an argument takes exactly one destination name")
        attrs.setdefault("required", "default" not in attrs)
        super().__init__(decls[0], **attrs)


def _name_from_decls(decls):
    for d in decls:
        if d.isidentifier():
            return d
    longs = [d for d in decls if d.startswith("--")]
    if longs:
        return longs[0][2:].replace("-", "_")
    shorts = [d for d in decls if d.startswith("-")]
    return shorts[0].lstrip("-").replace("-", "_") if shorts else None


def _is_neg_number(tok):
    try:
        float(tok)
        return True
    except ValueError:
        return False


class Command:
    """A leaf command: options, arguments, and an author callback."""

    def __init__(self, name=None, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False, **extra):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = context_settings or {}
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden

    # -- parsing -----------------------------------------------------------

    def make_context(self, args, parent=None, prog_name=None, obj=None, **settings):
        ctx = Context(self, parent=parent, obj=obj, prog_name=prog_name, **settings)
        rest = self.parse_args(ctx, list(args))
        return ctx, rest

    def _option_map(self):
        opt_map = {}
        for p in self.params:
            if isinstance(p, Option):
                for n in p.opts:
                    opt_map[n] = p
        return opt_map

    def parse_args(self, ctx, args):
        """Parse tokens into ``ctx.params``; return leftover tokens."""
        opt_map = self._option_map()
        help_names = list(ctx.help_option_names) if self.add_help_option else []
        raw = {}
        pos_tokens = []
        literal = False
        i = 0
        while i < len(args):
            tok = args[i]
            i += 1
            if not literal and tok == "--":
                literal = True
                continue
            if not literal and tok in help_names:
                self._print_help(ctx)
                raise Exit(0)
            if not literal and tok.startswith("-") and tok != "-" and not _is_neg_number(tok):
                try:
                    i += self._parse_option(ctx, tok, args, i, opt_map, raw)
                    continue
                except NoSuchOption:
                    if not ctx.ignore_unknown_options:
                        raise
            pos_tokens.append(tok)
        leftover = self._bind_positional(ctx, pos_tokens)
        self._finish_params(ctx, raw)
        return leftover

    def _parse_option(self, ctx, tok, args, i, opt_map, raw):
        """Parse one option token; return how many following tokens were used."""
        if tok.startswith("--"):
            name, eq, value = tok.partition("=")
            p = opt_map.get(name)
            if p is None:
                raise NoSuchOption(f"no such option: {name}")
            return self._take(ctx, p, name, value if eq else None, args, i, raw)
        used = 0
        j = 1
        while j < len(tok):
            name = "-" + tok[j]
            p = opt_map.get(name)
            if p is None:
                raise NoSuchOption(f"no such option: {name}")
            rest = tok[j + 1:]
            if not p.takes_value:
                self._take(ctx, p, name, None, args, i, raw)
                j += 1
                continue
            if rest:
                return self._take(ctx, p, name, rest, args, i, raw)
            return self._take(ctx, p, name, None, args, i, raw)
        return used

    def _take(self, ctx, p, name, value, args, i, raw):
        """Record one occurrence of option ``p``; return tokens consumed beyond the flag."""
        if p.count:
            raw.setdefault(p.name, {"count": 0})["count"] += 1
            ctx._sources[p.name] = SOURCE_COMMANDLINE
            return 0
        if p.is_flag:
            entry = raw.setdefault(p.name, {"flag": None})
            entry["flag"] = False if name in p.secondary_names else p.flag_value
            ctx._sources[p.name] = SOURCE_COMMANDLINE
            return 0
        if name in p.secondary_names:
            raise UsageError(f"option {name} takes no value", ctx, p)
        used = 0
        n = p.nargs if isinstance(p.nargs, int) and p.nargs > 0 else 1
        if value is not None:
            tokens = [value] if n == 1 else [value] + list(args[i:i + n - 1])
            used = len(tokens) - 1
            if len(tokens) < n:
                raise UsageError(f"option {name} requires {n} values", ctx, p)
        else:
            if i + n > len(args):
                raise UsageError(f"option {name} requires a value", ctx, p)
            tokens = list(args[i:i + n])
            used = n
        converted = [self._convert(ctx, p, t) for t in tokens]
        value_out = converted[0] if n == 1 else tuple(converted)
        entry = raw.setdefault(p.name, {"values": []})
        entry["values"].append(value_out)
        ctx._sources[p.name] = SOURCE_COMMANDLINE
        return used

    def _convert(self, ctx, p, raw_value):
        try:
            return p.type.convert(raw_value, p, ctx)
        except BadParameter:
            raise
        except Exception as exc:  # conversion failures are usage errors
            raise BadParameter(f"invalid value for {p.name}: {exc}", ctx, p)

    def _bind_positional(self, ctx, tokens):
        """Bind tokens to declared arguments; return leftover tokens."""
        positional = [p for p in self.params if isinstance(p, Argument)]
        ti = 0
        for a in positional:
            if a.nargs == -1:
                take = tokens[ti:]
                ti = len(tokens)
                ctx.params[a.name] = tuple(self._convert(ctx, a, t) for t in take)
                ctx._sources[a.name] = SOURCE_COMMANDLINE
                continue
            n = a.nargs
            if ti + n > len(tokens):
                continue  # too few tokens: left to _finish_params
            take = tokens[ti:ti + n]
            ti += n
            value = self._convert(ctx, a, take[0]) if n == 1 else tuple(self._convert(ctx, a, t) for t in take)
            ctx.params[a.name] = value
            ctx._sources[a.name] = SOURCE_COMMANDLINE
        return tokens[ti:]

    def _finish_params(self, ctx, raw):
        """Fill every declared parameter from the value sources, highest priority first."""
        for p in self.params:
            if isinstance(p, Argument) and p.name in ctx.params:
                value, source = ctx.params[p.name], ctx._sources[p.name]
            else:
                value, source = self._resolve_value(ctx, p, raw.get(p.name))
            if p.required and source in (None, SOURCE_DEFAULT) and value is None:
                raise MissingParameter(f"missing parameter '{p.name}'", ctx, p)
            if isinstance(p, Argument) and source is None:
                if p.required:
                    raise MissingParameter(f"missing argument '{p.name.upper()}'", ctx, p)
            if p.deprecated and source == SOURCE_COMMANDLINE:
                _warn(f"DeprecationWarning: '{p.name}' is deprecated.")
            if p.callback is not None:
                value = p.callback(ctx, p, value)
            ctx.params[p.name] = value
            ctx._sources[p.name] = source

    def _resolve_value(self, ctx, p, entry):
        if isinstance(p, Option):
            if entry is not None:
                if p.count:
                    return entry["count"], SOURCE_COMMANDLINE
                if p.is_flag:
                    return entry["flag"], SOURCE_COMMANDLINE
                values = entry["values"]
                return (tuple(values) if p.multiple else values[-1]), SOURCE_COMMANDLINE
        for var in p.envvar:
            raw_env = os.environ.get(var)
            if raw_env:
                if p.is_flag:
                    return self._env_flag(ctx, p, raw_env), SOURCE_ENVIRONMENT
                return self._convert(ctx, p, raw_env), SOURCE_ENVIRONMENT
        if isinstance(p, Option) and ctx.default_map and p.name in ctx.default_map:
            return ctx.default_map[p.name], SOURCE_DEFAULT_MAP
        if p.multiple or (isinstance(p, Argument) and p.nargs == -1):
            d = p.get_default(ctx)
            return (tuple(d) if d is not None else ()), SOURCE_DEFAULT
        d = p.get_default(ctx)
        if d is None and isinstance(p, Argument) and not p.required:
            return None, SOURCE_DEFAULT
        return d, SOURCE_DEFAULT

    def _env_flag(self, ctx, p, text):
        t = text.strip().lower()
        if t in ("true", "1", "yes", "on", "t", "y"):
            return p.flag_value if p.flag_value is not None else True
        if t in ("false", "0", "no", "off", "f", "n", ""):
            return False
        raise BadParameter(f"'{text}' is not a valid boolean", ctx, p)

    def _print_help(self, ctx):
        from .help import format_help

        sys.stdout.write(format_help(self, ctx))

    # -- execution ---------------------------------------------------------

    def _run_callback(self, ctx):
        """Call the author function with the converted parameter values."""
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        return self.callback(**kwargs)

    def _execute(self, ctx, rest):
        if rest:
            raise UsageError(f"got unexpected extra argument ({' '.join(rest)})", ctx)
        return self._run_callback(ctx)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        if args is None:
            args = sys.argv[1:]
        prog = prog_name or os.path.basename(sys.argv[0])
        return _run_main(self, args, prog, standalone_mode, extra)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)


def _run_main(cmd, args, prog, standalone_mode, extra):
    ctx = None
    try:
        try:
            if cmd.no_args_is_help and not args:
                ctx, _ = cmd.make_context([], prog_name=prog, **extra)
                from .help import format_help

                sys.stderr.write(format_help(cmd, ctx))
                raise UsageError("no arguments given", ctx)
            ctx, rest = cmd.make_context(args, prog_name=prog, **extra)
            with ctx:
                return cmd._execute(ctx, rest)
        finally:
            if ctx is not None:
                ctx.close()
    except Exit as e:
        if standalone_mode:
            sys.exit(e.exit_code)
        return e.exit_code
    except UsageError as e:
        if not standalone_mode:
            raise
        sys.stderr.write(f"Usage: {prog}\nError: {e.message}\n")
        sys.exit(2)
    except (Abort, KeyboardInterrupt, EOFError) as e:
        if not standalone_mode:
            raise
        sys.stderr.write("Aborted!\n")
        sys.exit(1)


def _warn(message):
    sys.stderr.write(message + "\n")


class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback = result_callback

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("groups cannot be nested under a chaining group")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def parse_args(self, ctx, args):
        """Group options come before the subcommand name; everything after it is dispatched."""
        opt_map = self._option_map()
        help_names = list(ctx.help_option_names) if self.add_help_option else []
        raw = {}
        i = 0
        while i < len(args):
            tok = args[i]
            i += 1
            if tok in help_names:
                self._print_help(ctx)
                raise Exit(0)
            if tok == "--":
                break
            if tok.startswith("-") and tok != "-" and not _is_neg_number(tok):
                i += self._parse_option(ctx, tok, args, i, opt_map, raw)
                continue
            i -= 1
            break
        rest = args[i:]
        pos_tokens = []
        # Arguments of a group are bound from tokens before the subcommand name.
        if rest and rest[0] != "--" and any(isinstance(p, Argument) for p in self.params):
            n_args = len([p for p in self.params if isinstance(p, Argument)])
            pos_tokens = rest[:n_args]
            rest = rest[n_args:]
        leftover = self._bind_positional(ctx, pos_tokens)
        self._finish_params(ctx, raw)
        return list(leftover) + list(rest)

    def _execute(self, ctx, rest):
        if not rest and not self.invoke_without_command:
            raise UsageError("missing command", ctx)
        if self.chain:
            return self._run_chain(ctx, rest)
        if not rest:
            return self._run_callback(ctx)
        cmd = self._lookup(ctx, rest[0])
        self._run_callback(ctx) if self.callback else None
        ctx.invoked_subcommand = cmd.name
        child, child_rest = cmd.make_context(rest[1:], parent=ctx)
        with child:
            result = cmd._execute(child, child_rest)
        child.close()
        if self.result_callback is not None:
            return self.result_callback(result, **ctx.params)
        return result

    def _run_chain(self, ctx, rest):
        if self.callback is not None:
            self._run_callback(ctx)
        results = []
        tokens = list(rest)
        while tokens:
            cmd = self._lookup(ctx, tokens[0])
            tokens = tokens[1:]
            child, tokens = cmd.make_context(tokens, parent=ctx)
            with child:
                results.append(cmd._run_callback(child))
            child.close()
        if self.result_callback is not None:
            return self.result_callback(results, **ctx.params)
        return results

    def _lookup(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"no such command '{name}'", ctx)
        return cmd

    def result_callback_decorator(self, f):
        self.result_callback = f
        return f
