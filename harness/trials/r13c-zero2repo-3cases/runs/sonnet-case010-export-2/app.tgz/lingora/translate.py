"""BLEU score."""
import math
import sys
from collections import Counter
from fractions import Fraction


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def _closest_ref_len(references, hyp_len):
    lens = (len(r) for r in references)
    return min(lens, key=lambda l: (abs(l - hyp_len), l))


def brevity_penalty(closest_ref_len, hyp_len):
    if hyp_len > closest_ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest_ref_len / hyp_len)


def smoothing_method1(p_n, references, hypothesis, hyp_len, epsilon=0.1):
    return [p if p.numerator != 0 else Fraction(epsilon) for p in p_n]


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    # spec: N-000494
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("references and hypothesis must be token lists")
    weights = list(weights)
    p_n = []
    for i in range(1, len(weights) + 1):
        counts = Counter(_ngrams(hypothesis, i))
        max_counts = {}
        for ref in references:
            rc = Counter(_ngrams(ref, i))
            for ng in counts:
                max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
        num = sum(min(c, max_counts.get(ng, 0)) for ng, c in counts.items())
        den = max(1, sum(counts.values()))
        p_n.append(Fraction(num, den))
    hyp_len = len(hypothesis)
    if p_n[0].numerator == 0:
        return 0
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, references, hypothesis, hyp_len)
    bp = brevity_penalty(_closest_ref_len(references, hyp_len), hyp_len)
    s = 0.0
    for w, p in zip(weights, p_n):
        p = float(p)
        if p == 0:
            p = sys.float_info.min
        s += w * math.log(p)
    return bp * math.exp(s)
