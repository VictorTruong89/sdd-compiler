"""Constituent trees."""
# spec: N-000471 N-000386


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, str):
            raise TypeError("children must be a list of children, not %r" % (children,))
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat())
            elif isinstance(c, tuple):
                parts.append("/".join(str(x) for x in c))
            else:
                parts.append(str(c))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        out = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                out += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            elif isinstance(c, tuple):
                out += "\n" + " " * (indent + 2) + "/".join(str(x) for x in c)
            else:
                out += "\n" + " " * (indent + 2) + str(c)
        return out + ")"

    @classmethod
    def fromstring(cls, s, brackets="()"):
        op, cl = brackets
        import re
        toks = re.findall(r"\%s|\%s|[^\s\%s\%s]+" % (op, cl, op, cl), s)
        if not toks or toks[0] != op:
            raise ValueError("Tree.fromstring: expected %r" % op)
        pos = [0]

        def node():
            pos[0] += 1  # open
            if pos[0] >= len(toks):
                raise ValueError("unbalanced tree text")
            label = ""
            if toks[pos[0]] not in (op, cl):
                label = toks[pos[0]]
                pos[0] += 1
            kids = []
            while True:
                if pos[0] >= len(toks):
                    raise ValueError("unbalanced tree text")
                t = toks[pos[0]]
                if t == cl:
                    pos[0] += 1
                    return cls(label, kids)
                if t == op:
                    kids.append(node())
                else:
                    kids.append(t)
                    pos[0] += 1

        t = node()
        if pos[0] != len(toks):
            raise ValueError("extra text after tree")
        return t
