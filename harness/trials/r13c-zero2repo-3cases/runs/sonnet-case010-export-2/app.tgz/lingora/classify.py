"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict


def accuracy(classifier, gold):
    if not gold:
        return 0.0
    right = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return right / len(gold)


class _ProbDist:
    def __init__(self, probs):
        self._p = dict(probs)

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def samples(self):
        return list(self._p)

    def max(self):
        return max(self._p, key=lambda s: self._p[s])


class NaiveBayesClassifier:
    def __init__(self, label_logprob, feature_probdist, labels):
        self._label_logprob = label_logprob
        self._fp = feature_probdist  # (label, fname) -> (counter, N, bins)
        self._labels = labels

    @classmethod
    def train(cls, labeled_featuresets):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on no data")
        label_freq = Counter()
        feat_freq = defaultdict(Counter)
        values = defaultdict(set)
        fnames = []
        seen = set()
        for fs, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in fs.items():
                feat_freq[label, fname][fval] += 1
                values[fname].add(fval)
                if fname not in seen:
                    seen.add(fname)
                    fnames.append(fname)
        total = len(labeled_featuresets)
        for label in label_freq:
            for fname in fnames:
                cnt = sum(feat_freq[label, fname].values())
                if label_freq[label] - cnt > 0:
                    feat_freq[label, fname][None] += label_freq[label] - cnt
                    values[fname].add(None)
        n = sum(label_freq.values())
        b = len(label_freq)
        lp = {l: math.log((c + 0.5) / (n + 0.5 * b)) for l, c in label_freq.items()}
        fp = {}
        for (label, fname), cnt in feat_freq.items():
            fp[label, fname] = (cnt, sum(cnt.values()), len(values[fname]))
        return cls(lp, fp, list(label_freq))

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._fp for l in self._labels)}
        logp = {}
        for label in self._labels:
            lp = self._label_logprob[label]
            for fname, fval in fs.items():
                cnt, n, bins = self._fp[label, fname]
                lp += math.log((cnt.get(fval, 0) + 0.5) / (n + 0.5 * bins))
            logp[label] = lp
        m = max(logp.values())
        exps = {l: math.exp(v - m) for l, v in logp.items()}
        z = sum(exps.values())
        return _ProbDist({l: e / z for l, e in exps.items()})

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


def _entropy(counter):
    n = sum(counter.values())
    return -sum((c / n) * math.log2(c / n) for c in counter.values() if c)


class DecisionTreeClassifier:
    def __init__(self, label, fname=None, decisions=None, default=None):
        self._label = label
        self._fname = fname
        self._decisions = decisions
        self._default = default

    def labels(self):
        out = [self._label]
        for d in (self._decisions or {}).values():
            out.extend(d.labels())
        return list(dict.fromkeys(out))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        return self._label

    def error(self, data):
        errors = sum(1 for fs, l in data if self.classify(fs) != l)
        return errors / len(data)

    @staticmethod
    def _stump(fname, data):
        label = Counter(l for _, l in data).most_common(1)[0][0]
        freqs = defaultdict(Counter)
        for fs, l in data:
            freqs[fs.get(fname)][l] += 1
        decisions = {v: DecisionTreeClassifier(c.most_common(1)[0][0]) for v, c in freqs.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100,
              support_cutoff=10):
        data = list(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on no data")
        names = list(dict.fromkeys(f for fs, _ in data for f in fs))
        if not names:
            return cls(Counter(l for _, l in data).most_common(1)[0][0])
        best, best_err = None, 2.0
        for fname in names:
            s = cls._stump(fname, data)
            e = s.error(data)
            if e < best_err:
                best, best_err = s, e
        best._refine(data, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return best

    def _refine(self, data, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(data) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in data if fs.get(self._fname) == fval]
            if not sub:
                continue
            if _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
