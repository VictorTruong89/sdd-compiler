"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


class TaggerI:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose(self, token, i, tokens, tags):  # pragma: no cover
        return None

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str")
        tokens = list(tokens)
        tagged = []
        for i, tok in enumerate(tokens):
            tag = self._choose(tok, i, tokens, tagged)
            if tag is None and self._backoff is not None:
                tag = self._backoff.tag(tokens)[i][1]
            tagged.append((tok, tag))
        return tagged


class DefaultTagger(TaggerI):
    def __init__(self, tag):
        TaggerI.__init__(self, None)
        self._tag = tag

    def _choose(self, token, i, tokens, tagged):
        return self._tag


class UnigramTagger(TaggerI):
    def __init__(self, train=None, model=None, backoff=None):
        TaggerI.__init__(self, backoff)
        if model is not None:
            self._model = dict(model)
            return
        if train is None:
            raise TypeError("train is required")
        counts = defaultdict(Counter)
        for sent in train:
            for tok, tag in sent:
                counts[tok][tag] += 1
        self._model = {w: c.most_common(1)[0][0] for w, c in counts.items()}

    def _choose(self, token, i, tokens, tagged):
        return self._model.get(token)


class RegexpTagger(TaggerI):
    def __init__(self, regexps, backoff=None):
        TaggerI.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def _choose(self, token, i, tokens, tagged):
        for rx, t in self._regexps:
            if rx.match(token):
                return t
        return None


# ---------------------------------------------------------------- perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            w = self.weights.get(feat)
            if w is None or value == 0:
                continue
            for label, weight in w.items():
                scores[label] += value * weight
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_cache = {}


def _load_tagger(lang):
    base = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    stem = os.path.join(base, "averaged_perceptron_tagger_%s" % lang)
    files = [stem + s for s in (".weights.json", ".tagdict.json", ".classes.json")]
    for f in files:
        if not os.path.isfile(f):
            raise LookupError("missing tagger file %s" % f)
    key = tuple((f, os.stat(f).st_mtime_ns, os.stat(f).st_size) for f in files)
    if key in _cache:
        return _cache[key]
    objs = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            objs.append(json.load(fh))
    t = PerceptronTagger(*objs)
    _cache.clear()
    _cache[key] = t
    return t


_RNC_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "NUM": "NUM", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "INTJ": "PRT", "NONLEX": ".", "COM": "X",
    "S-PRO": "PRON", "A-PRO": "PRON", "ADV-PRO": "PRON", "APRO": "PRON",
    "SPRO": "PRON", "ADVPRO": "PRON", "A-NUM": "NUM",
}


def _load_universal_map():
    lines = data.read_lines("taggers/universal_tagset", "en-ptb.map")
    m = {}
    for ln in lines:
        if not ln.strip():
            continue
        parts = ln.split("\t")
        if len(parts) >= 2:
            m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagger = _load_tagger(lang)
    if tagset == "universal" and lang == "eng":
        mapping = _load_universal_map()
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            return [(w, mapping.get(t, "X")) for w, t in tagged]
        return [(w, _RNC_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged]
    return tagged
