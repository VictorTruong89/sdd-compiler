"""Command line: ``cli.main(args=['tokenize'], standalone_mode=True)``."""
# spec: N-000397 N-000398 N-000399 N-000400 N-000401
import sys

from . import tokenize as _tok


def _read_stdin(encoding):
    stream = sys.stdin
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf.read().decode(encoding)
    text = stream.read()
    return text.decode(encoding) if isinstance(text, bytes) else text


def _write(text):
    out = sys.stdout
    buf = getattr(out, "buffer", None)
    if buf is not None:
        out.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()
    else:
        out.write(text)
        out.flush()


class _Group:
    def main(self, args=None, standalone_mode=True, **_):
        args = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(args)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        except Exception as e:  # failure: non-zero status, message on stderr
            sys.stderr.write("Error: %s\n" % (e,))
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    __call__ = main

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write("Usage: lingora tokenize [--language LANG] [--delimiter D] [--encoding ENC]\n")
            return 0 if args else 2
        if args[0] != "tokenize":
            sys.stderr.write("Error: no such command %r\n" % args[0])
            return 2
        language, delim, enc = "english", " ", "utf-8"
        rest = args[1:]
        i = 0
        while i < len(rest):
            a = rest[i]
            key, eq, val = a.partition("=")
            if key in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
                if not eq:
                    i += 1
                    if i >= len(rest):
                        sys.stderr.write("Error: option %s requires a value\n" % a)
                        return 2
                    val = rest[i]
                if key in ("-l", "--language"):
                    language = val
                elif key in ("-d", "--delimiter"):
                    delim = val
                else:
                    enc = val
            else:
                sys.stderr.write("Error: unexpected argument %r\n" % a)
                return 2
            i += 1
        _tok._load_punkt(language)  # fail before writing anything
        text = _read_stdin(enc)
        lines = text.split("\n")
        if lines and lines[-1] == "":
            lines.pop()
        result = []
        for line in lines:
            line = line.rstrip("\r")
            result.append(delim.join(_tok.word_tokenize(line, language=language)) + "\n")
        _write("".join(result))
        return 0


cli = _Group()


def main():  # console entry
    cli.main()
