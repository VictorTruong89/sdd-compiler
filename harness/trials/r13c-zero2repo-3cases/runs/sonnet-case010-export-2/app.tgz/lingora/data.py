"""Packaged-resource finder."""
# spec: N-000368 N-000369 N-000370 N-000371
import os

# Mutable list of directory strings searched for packaged resources.
path = []
for _p in (os.environ.get("LINGORA_DATA"), os.path.expanduser("~/lingora_data"),
           os.path.expanduser("~/nltk_data"), "/usr/share/nltk_data",
           "/usr/local/share/nltk_data"):
    if _p:
        path.append(_p)


def find(name):
    """Return the filesystem path of resource `name`, or raise LookupError."""
    name = name.strip("/")
    for d in list(path):
        cand = os.path.join(str(d), *name.split("/"))
        if os.path.exists(cand):
            return cand
    raise LookupError("resource %r not found in data.path" % name)


def read_lines(resource, filename):
    """Lines (without terminators) of a UTF-8 text file in a resource dir."""
    base = find(resource)
    fp = os.path.join(base, filename)
    if not os.path.isfile(fp):
        raise LookupError("resource file %r not found" % fp)
    with open(fp, encoding="utf-8", newline="") as f:
        text = f.read()
    return text.splitlines()
