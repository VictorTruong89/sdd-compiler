"""Regular-expression chunking."""
# spec: N-000430 N-000437
import re

from . import data
from .tree import Tree

ROOT_LABEL = "S"
_TOKEN = re.compile(r"[{}]|<[^<>{}]*>")


def tag_pattern2re_pattern(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = p.replace("<", "(?:<(?:").replace(">", ")>)")
    # a '.' inside an element must not cross element boundaries
    out, depth, i = [], 0, 0
    while i < len(p):
        if p.startswith("(?:<(?:", i):
            depth += 1
            out.append("(?:<(?:")
            i += 7
            continue
        if p.startswith(")>)", i):
            depth -= 1
            out.append(")>)")
            i += 3
            continue
        c = p[i]
        if c == "\\" and i + 1 < len(p):
            out.append(p[i:i + 2])
            i += 2
            continue
        out.append(r"[^\{\}<>]" if (c == "." and depth > 0) else c)
        i += 1
    return "".join(out)


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        try:
            core = tag_pattern2re_pattern(pattern)
            if kind == "chunk":
                self.regexp = re.compile(r"(?P<x>%s)(?=[^\}]*(\{|$))" % core)
                self.repl = r"{\g<x>}"
            else:
                self.regexp = re.compile(r"(?P<x>%s)(?=[^\{]*\})" % core)
                self.repl = r"}\g<x>{"
        except re.error as e:
            raise ValueError("bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        s = self.regexp.sub(self.repl, s)
        return s.replace("{}", "")


class ChunkStage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = list(rules)

    def apply(self, elems):
        """elems: list of (tuple leaf | Tree). Returns new list."""
        s = "".join("<%s>" % (e.label() if isinstance(e, Tree) else e[1]) for e in elems)
        for r in self.rules:
            s = r.apply(s)
        out, idx, cur = [], 0, None
        for m in _TOKEN.finditer(s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    out.append(Tree(self.label, cur))
                cur = None
            else:
                e = elems[idx]
                idx += 1
                (cur if cur is not None else out).append(e)
        if cur:
            out.append(Tree(self.label, cur))
        return out


def _parse_grammar(text):
    stages = []
    cur = None
    for raw in text.split("\n"):
        line = raw.split("#")[0] if "#" in raw else raw
        if not line.strip():
            continue
        if line[0] in " \t":
            if cur is None:
                raise ValueError("pattern line before any clause: %r" % raw)
            cur[1].append(line.strip())
            continue
        m = re.match(r"^\s*([^\s:]+)\s*:\s*(.*)$", line)
        if not m:
            raise ValueError("Illegal chunk grammar line: %r" % raw)
        cur = (m.group(1), [])
        stages.append(cur)
        if m.group(2).strip():
            cur[1].append(m.group(2).strip())
    out = []
    for label, pats in stages:
        rules = []
        for p in pats:
            if len(p) >= 2 and p[0] == "{" and p[-1] == "}":
                rules.append(_Rule("chunk", p[1:-1]))
            elif len(p) >= 2 and p[0] == "}" and p[-1] == "{":
                rules.append(_Rule("chink", p[1:-1]))
            else:
                raise ValueError("Illegal chunk pattern: %r" % p)
        out.append(ChunkStage(label, rules))
    if not out:
        raise ValueError("empty chunk grammar")
    return out


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT_LABEL):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, ChunkStage) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk stages")
        self._root = root_label

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("expected a list of (token, tag) pairs")
        elems = []
        for p in tagged:
            if not isinstance(p, (tuple, list)) or len(p) != 2:
                raise TypeError("expected (token, tag) pairs")
            elems.append((p[0], p[1]))
        for st in self._stages:
            elems = st.apply(elems)
        return Tree(self._root, elems)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    if isinstance(tagged_tokens, str):
        raise TypeError("expected a list of (token, tag) pairs")
    return Tree(ROOT_LABEL, [(t, g) for t, g in tagged_tokens])
