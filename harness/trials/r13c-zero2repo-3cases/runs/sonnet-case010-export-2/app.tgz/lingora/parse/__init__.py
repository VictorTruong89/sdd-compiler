"""Parsers."""
# spec: N-000448
from ..grammar import Nonterminal
from ..tree import Tree


def _check_coverage(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str")
    missing = [t for t in tokens if t not in grammar.terminals()]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r"
                         % ", ".join(map(repr, missing)))


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._prods = {}
        for p in grammar.productions():
            self._prods.setdefault(str(p.lhs()), []).append(p)

    def parse(self, tokens):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        n = len(tokens)
        memo = {}
        active = set()

        def sym(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            out = []
            for p in self._prods.get(name, []):
                for kids in seq(p.rhs(), 0, i, j):
                    out.append(Tree(name, kids))
            active.discard(key)
            memo[key] = out
            return out

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            s = rhs[k]
            if isinstance(s, str):
                if s == "":
                    yield from seq(rhs, k + 1, i, j)
                elif i < j and tokens[i] == s:
                    for r in seq(rhs, k + 1, i + 1, j):
                        yield [s] + r
                return
            for m in range(i, j + 1):
                for t in sym(str(s), i, m):
                    for r in seq(rhs, k + 1, m, j):
                        yield [t] + r

        return sym(str(self._grammar.start()), 0, n)


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for p in self._grammar.productions():
            rhs = p.rhs()
            n = len(rhs)
            if n == 0 or len(stack) < n:
                continue
            ok = True
            for s, r in zip(stack[-n:], rhs):
                if isinstance(r, str):
                    if not (isinstance(s, str) and s == r):
                        ok = False
                        break
                elif not (isinstance(s, Tree) and s.label() == str(r)):
                    ok = False
                    break
            if ok:
                kids = stack[-n:]
                del stack[-n:]
                stack.append(Tree(str(p.lhs()), kids))
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == str(self._grammar.start()):
            return [stack[0]]
        return []
