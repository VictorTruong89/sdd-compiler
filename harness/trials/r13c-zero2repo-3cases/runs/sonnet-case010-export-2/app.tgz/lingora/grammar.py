"""Context-free grammars."""
# spec: N-000448
import re


class Nonterminal:
    """A nonterminal symbol (not a ``str``); compares equal to its name."""

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __hash__(self):
        return hash(self._symbol)

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "%s" % self._symbol


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for s in self._rhs:
            parts.append(repr(s) if isinstance(s, str) else str(s))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_RHS_TOKEN = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar must be text")
        prods = []
        for line in input.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\S+?)\s*(?:->|→)(.*)$", line)
            if not m:
                raise ValueError("Unable to parse line: %r" % line)
            lhs = Nonterminal(m.group(1))
            rest = m.group(2)
            alts = [[]]
            pos = 0
            rest_s = rest.strip()
            consumed = ""
            for tm in _RHS_TOKEN.finditer(rest_s):
                tok = tm.group(0)
                if tok == "|":
                    alts.append([])
                elif tok[0] in "'\"":
                    if len(tok) < 2 or tok[-1] != tok[0]:
                        raise ValueError("Unterminated quote in %r" % line)
                    alts[-1].append(tok[1:-1])
                else:
                    if tok[0] in "'\"":
                        raise ValueError("bad token %r" % tok)
                    alts[-1].append(Nonterminal(tok))
            for a in alts:
                prods.append(Production(lhs, a))
        if not prods:
            raise ValueError("No productions found")
        return cls(prods[0].lhs(), prods)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n%s" % (
            len(self._productions), self._start,
            "\n".join("    " + str(p) for p in self._productions))
