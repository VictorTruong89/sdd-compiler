"""Snowball stemmers for the non-English languages (compact ports)."""


def _starts(word, vowels):
    """Index where R1 begins (after first non-vowel following a vowel)."""
    for i in range(1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            return i + 1
    return len(word)


def _longest(word, suffixes):
    best = ""
    for s in suffixes:
        if len(s) > len(best) and word.endswith(s):
            best = s
    return best


def _undouble_end(word, pairs):
    for p in pairs:
        if word.endswith(p):
            return word[:-1]
    return word


# ------------------------------------------------------------------ German
class German:
    v = "aeiouyäöü"
    s_end = "bdfghklmnrt"
    st_end = "bdfghklmnt"

    def stem(self, word):
        v = self.v
        word = word.replace("ß", "ss")
        w = list(word)
        for i in range(1, len(w) - 1):
            if w[i - 1] in v and w[i + 1] in v:
                if w[i] == "u":
                    w[i] = "U"
                elif w[i] == "y":
                    w[i] = "Y"
        word = "".join(w)
        p1 = max(_starts(word, v), 3) if len(word) >= 3 else len(word)
        p1 = min(p1, len(word))
        p2 = _starts(word[p1:], v) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        # step 1
        suf = _longest(word, ("ern", "em", "er", "en", "es", "e", "s"))
        if suf and len(word) - len(suf) >= p1:
            if suf == "s":
                if len(word) >= 2 and word[-2] in self.s_end:
                    word = word[:-1]
            else:
                word = word[:-len(suf)]
                if suf in ("en", "es", "e") and word.endswith("niss"):
                    word = word[:-1]
        # step 2
        suf = _longest(word, ("est", "en", "er", "st"))
        if suf and len(word) - len(suf) >= p1:
            if suf == "st":
                if len(word) >= 6 and word[-3] in self.st_end:
                    word = word[:-2]
            else:
                word = word[:-len(suf)]
        # step 3
        suf = _longest(word, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
        if suf and len(word) - len(suf) >= p2:
            base = word[:-len(suf)]
            if suf in ("end", "ung"):
                word = base
                if word.endswith("ig") and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
                    word = word[:-2]
            elif suf in ("ig", "ik", "isch"):
                if not base.endswith("e"):
                    word = base
            elif suf in ("lich", "heit"):
                word = base
                if word.endswith(("er", "en")) and len(word) - 2 >= p1:
                    word = word[:-2]
            elif suf == "keit":
                word = base
                s2 = _longest(word, ("lich", "ig"))
                if s2 and len(word) - len(s2) >= p2:
                    word = word[:-len(s2)]
        word = word.replace("U", "u").replace("Y", "y")
        return word.translate(str.maketrans("äöü", "aou"))


# ------------------------------------------------------------------ Spanish
class Spanish:
    v = "aeiouáéíóúü"

    def _rv(self, word):
        v = self.v
        if len(word) < 2:
            return len(word)
        if word[1] not in v:
            for i in range(2, len(word)):
                if word[i] in v:
                    return i + 1
            return len(word)
        if word[0] in v and word[1] in v:
            for i in range(2, len(word)):
                if word[i] not in v:
                    return i + 1
            return len(word)
        return min(3, len(word))

    def stem(self, word):
        v = self.v
        p1 = _starts(word, v)
        p2 = _starts(word[p1:], v) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        rv = self._rv(word)
        orig = word

        def inr(w, suf, p):
            return len(w) - len(suf) >= p

        # step 0: attached pronouns
        pron = _longest(word, ("selas", "selos", "sela", "selo", "las", "les", "los", "nos",
                               "me", "se", "la", "le", "lo"))
        if pron and inr(word, pron, rv):
            base = word[:-len(pron)]
            for pre in ("iéndo", "ándo", "ár", "ér", "ír"):
                if base.endswith(pre) and inr(base, pre, rv):
                    word = base[:-len(pre)] + pre.translate(str.maketrans("éáíó", "eaio"))
                    break
            else:
                for pre in ("iendo", "ando", "ar", "er", "ir"):
                    if base.endswith(pre) and inr(base, pre, rv):
                        word = base
                        break
                else:
                    if base.endswith("yendo") and base[-6:-5] == "u" and inr(base, "yendo", rv):
                        word = base
        # step 1
        changed = False
        s1 = _longest(word, (
            "anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables", "able",
            "ibles", "ible", "istas", "ista", "osos", "osas", "oso", "osa", "amientos",
            "amiento", "imientos", "imiento", "adoras", "adores", "adora", "ador", "aciones",
            "ación", "antes", "ante", "ancias", "ancia", "logías", "logía", "uciones", "ución",
            "encias", "encia", "amente", "mente", "idades", "idad", "ivas", "ivos", "iva", "ivo"))
        if s1:
            base = word[:-len(s1)]
            if s1 in ("anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables",
                      "able", "ibles", "ible", "istas", "ista", "osos", "osas", "oso", "osa",
                      "amientos", "amiento", "imientos", "imiento"):
                if inr(word, s1, p2):
                    word, changed = base, True
            elif s1 in ("adoras", "adores", "adora", "ador", "aciones", "ación", "antes",
                        "ante", "ancias", "ancia"):
                if inr(word, s1, p2):
                    word, changed = base, True
                    if word.endswith("ic") and inr(word, "ic", p2):
                        word = word[:-2]
            elif s1 in ("logías", "logía"):
                if inr(word, s1, p2):
                    word, changed = base + "log", True
            elif s1 in ("uciones", "ución"):
                if inr(word, s1, p2):
                    word, changed = base + "u", True
            elif s1 in ("encias", "encia"):
                if inr(word, s1, p2):
                    word, changed = base + "ente", True
            elif s1 == "amente":
                if inr(word, s1, p1):
                    word, changed = base, True
                    if word.endswith("iv") and inr(word, "iv", p2):
                        word = word[:-2]
                        if word.endswith("at") and inr(word, "at", p2):
                            word = word[:-2]
                    else:
                        for x in ("os", "ic", "ad"):
                            if word.endswith(x) and inr(word, x, p2):
                                word = word[:-len(x)]
                                break
            elif s1 == "mente":
                if inr(word, s1, p2):
                    word, changed = base, True
                    for x in ("ante", "able", "ible"):
                        if word.endswith(x) and inr(word, x, p2):
                            word = word[:-len(x)]
                            break
            elif s1 in ("idades", "idad"):
                if inr(word, s1, p2):
                    word, changed = base, True
                    for x in ("abil", "ic", "iv"):
                        if word.endswith(x) and inr(word, x, p2):
                            word = word[:-len(x)]
                            break
            else:  # iva ivo ivas ivos
                if inr(word, s1, p2):
                    word, changed = base, True
                    if word.endswith("at") and inr(word, "at", p2):
                        word = word[:-2]
        if not changed:
            # step 2a
            s = _longest(word, ("yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes",
                                "ya", "ye", "yo", "yó"))
            if s and inr(word, s, rv) and word[:-len(s)].endswith("u"):
                word = word[:-len(s)]
                changed = True
        if not changed:
            # step 2b
            s = _longest(word, (
                "aríamos", "eríamos", "iríamos", "iéramos", "iésemos", "aríais", "aremos",
                "eríais", "eremos", "iríais", "iremos", "ierais", "ieseis", "asteis", "isteis",
                "ábamos", "áramos", "ásemos", "arían", "arías", "arás", "aréis", "erían",
                "erías", "erás", "eréis", "irían", "irías", "irás", "iréis", "ieran", "iesen",
                "ieron", "iendo", "ieras", "ieses", "abais", "arais", "aseis", "íamos",
                "arán", "erán", "irán", "aría", "ería", "iría", "ará", "aré", "erá", "eré",
                "irá", "iré", "aban", "aran", "asen", "aron", "ando", "abas", "adas", "idas",
                "aras", "ases", "íais", "ados", "idos", "amos", "imos", "emos", "iera",
                "iese", "aste", "iste", "aba", "ada", "ida", "ara", "ase", "ían", "ado",
                "ido", "ías", "áis", "éis", "ía", "ad", "ed", "id", "an", "ió", "ar", "er",
                "ir", "as", "ís", "en", "es"))
            if s and inr(word, s, rv):
                word = word[:-len(s)]
                if s in ("en", "es", "éis", "emos") and word.endswith("gu"):
                    word = word[:-1]
                changed = True
        # step 3
        s = _longest(word, ("os", "a", "o", "á", "í", "ó", "e", "é"))
        if s and inr(word, s, rv):
            if s in ("e", "é"):
                word = word[:-1]
                if word.endswith("gu") and inr(word, "u", rv):
                    word = word[:-1]
            else:
                word = word[:-len(s)]
        del orig
        return word.translate(str.maketrans("áéíóú", "aeiou"))


# ---------------------------------------------------------------- Scandinavian
class Swedish:
    v = "aeiouyäåö"
    s_end = "bcdfghjklmnoprtvy"
    sfx = ("heterna", "hetens", "anden", "heten", "heter", "arnas", "ernas", "ornas", "andes",
           "arens", "andet", "arna", "erna", "orna", "ande", "arne", "aste", "aren", "ades",
           "erns", "ade", "are", "ern", "ens", "het", "ast", "ad", "en", "ar", "er", "or",
           "as", "es", "at", "a", "e", "s")

    def stem(self, word):
        p1 = min(max(_starts(word, self.v), 3), len(word))
        s = _longest(word, self.sfx)
        if s and len(word) - len(s) >= p1:
            if s == "s":
                if word[-2:-1] and word[-2] in self.s_end:
                    word = word[:-1]
            else:
                word = word[:-len(s)]
        if len(word) >= p1 and word.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")) \
                and len(word) - 2 >= p1 - 1 and len(word) > p1:
            word = word[:-1]
        s = _longest(word, ("fullt", "löst", "lig", "els", "ig"))
        if s and len(word) - len(s) >= p1:
            if s == "fullt":
                word = word[:-1]
            elif s == "löst":
                word = word[:-1]
            else:
                word = word[:-len(s)]
        return word


class Danish:
    v = "aeiouyæåø"
    s_end = "abcdfghjklmnoprtvyzå"
    sfx = ("erendes", "erende", "hedens", "ethed", "erede", "heden", "heder", "endes", "ernes",
           "erens", "erets", "ered", "ende", "erne", "eren", "erer", "heds", "enes", "eres",
           "eret", "hed", "ene", "ere", "ens", "ers", "ets", "en", "er", "es", "et", "e", "s")

    def stem(self, word):
        p1 = min(max(_starts(word, self.v), 3), len(word))
        s = _longest(word, self.sfx)
        if s and len(word) - len(s) >= p1:
            if s == "s":
                if word[-2:-1] and word[-2] in self.s_end:
                    word = word[:-1]
            else:
                word = word[:-len(s)]
        if word.endswith(("gd", "dt", "gt", "kt")) and len(word) - 1 >= p1:
            word = word[:-1]
        if word.endswith("igst") and len(word) - 4 >= p1 - 0:
            word = word[:-2]
        s = _longest(word, ("elig", "løst", "lig", "els", "ig"))
        if s and len(word) - len(s) >= p1:
            if s == "løst":
                word = word[:-1]
            else:
                word = word[:-len(s)]
                if word.endswith(("gd", "dt", "gt", "kt")) and len(word) - 1 >= p1:
                    word = word[:-1]
        if len(word) > p1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in self.v:
            word = word[:-1]
        return word


class Norwegian:
    v = "aeiouyæåø"
    s_end = "bcdfghjlmnoprtvyz"
    sfx = ("hetenes", "hetene", "hetens", "heten", "heter", "endes", "ande", "ende", "edes",
           "enes", "erte", "ede", "ane", "ene", "ens", "ers", "ets", "het", "ast", "ert",
           "en", "ar", "er", "as", "es", "et", "a", "e", "s")

    def stem(self, word):
        p1 = min(max(_starts(word, self.v), 3), len(word))
        s = _longest(word, self.sfx)
        if s and len(word) - len(s) >= p1:
            if s == "s":
                if word[-2:-1] and (word[-2] in self.s_end
                                    or (word[-2] == "k" and word[-3:-2] and word[-3] not in self.v)):
                    word = word[:-1]
            elif s in ("erte", "ert"):
                word = word[:-len(s)] + "er"
            else:
                word = word[:-len(s)]
        if word.endswith(("dt", "vt")) and len(word) - 1 >= p1:
            word = word[:-1]
        s = _longest(word, ("hetslov", "eleg", "elig", "elov", "slov", "leg", "eig", "lig",
                            "els", "lov", "ig"))
        if s and len(word) - len(s) >= p1:
            word = word[:-len(s)]
        return word


# -------------------------------------------------------------------- Dutch
class Dutch:
    v = "aeiouyè"

    def _undouble(self, w):
        if w.endswith(("kk", "dd", "tt")):
            return w[:-1]
        return w

    def stem(self, word):
        v = self.v
        word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
        w = list(word)
        if w and w[0] == "y":
            w[0] = "Y"
        for i in range(1, len(w)):
            if w[i - 1] in v and w[i] in "iy":
                w[i] = w[i].upper()
        # i before vowel becomes I only when between vowels: keep original rule
        word = "".join(w)
        for i in range(1, len(word) - 1):
            if word[i] == "I" and not (word[i - 1] in v and word[i + 1] in v):
                word = word[:i] + "i" + word[i + 1:]
        word = word.replace("Y", "Y")
        v2 = v + "IY"
        p1 = min(max(_starts(word, v2), 3), len(word))
        p2 = _starts(word[p1:], v2) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        # step 1
        if word.endswith("heden") and len(word) - 5 >= p1:
            word = word[:-5] + "heid"
        else:
            s = _longest(word, ("ene", "en", "se", "s"))
            if s and len(word) - len(s) >= p1:
                base = word[:-len(s)]
                if s in ("ene", "en"):
                    if base and base[-1] not in v2 and not base.endswith("gem"):
                        word = self._undouble(base)
                elif base and base[-1] not in v2 and base[-1] != "j":
                    word = base
        # step 2
        removed_e = False
        if word.endswith("e") and len(word) - 1 >= p1 and len(word) > 1 and word[-2] not in v2:
            word = self._undouble(word[:-1])
            removed_e = True
        # step 3a
        if word.endswith("heid") and len(word) - 4 >= p2 and word[-5:-4] != "c":
            word = word[:-4]
            if word.endswith("en") and len(word) - 2 >= p1 and word[-3:-2] \
                    and word[-3] not in v2 and not word[:-2].endswith("gem"):
                word = self._undouble(word[:-2])
        # step 3b
        s = _longest(word, ("baar", "lijk", "ing", "end", "bar", "ig"))
        if s and len(word) - len(s) >= p2:
            if s in ("end", "ing"):
                word = word[:-3]
                if word.endswith("ig") and len(word) - 2 >= p2 and word[-3:-2] != "e":
                    word = word[:-2]
                else:
                    word = self._undouble(word)
            elif s == "ig":
                if word[-3:-2] != "e":
                    word = word[:-2]
            elif s == "lijk":
                word = word[:-4]
                if word.endswith("e") and len(word) - 1 >= p1 and len(word) > 1 \
                        and word[-2] not in v2:
                    word = self._undouble(word[:-1])
            elif s == "baar":
                word = word[:-4]
            elif s == "bar" and removed_e:
                word = word[:-3]
        # step 4
        if len(word) >= 4 and word[-1] not in v2 and word[-1] != "I" \
                and word[-4] not in v2 and word[-3] == word[-2] and word[-3] in "aeou" \
                and word[-2] in v2:
            word = word[:-2] + word[-1]
        return word.replace("I", "i").replace("Y", "y")


# ------------------------------------------------------------------ Russian
class Russian:
    v = "аеиоуыэюя"
    _pg1 = ("в", "вши", "вшись")
    _pg2 = ("ив", "ивши", "ившись", "ыв", "ывши", "ывшись")
    _refl = ("ся", "сь")
    _adj = ("ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий",
            "ый", "ой", "ем", "им", "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
    _part1 = ("ем", "нн", "вш", "ющ", "щ")
    _part2 = ("ивш", "ывш", "ующ")
    _verb1 = ("ла", "на", "ете", "йте", "ли", "й", "л", "ем", "н", "ло", "но", "ет", "ют",
              "ны", "ть", "ешь", "нно")
    _verb2 = ("ила", "ыла", "ена", "ейте", "уйте", "ите", "или", "ыли", "ей", "уй", "ил",
              "ыл", "им", "ым", "ен", "ило", "ыло", "ено", "ят", "ует", "уют", "ит", "ыт",
              "ены", "ить", "ыть", "ишь", "ую", "ю")
    _noun = ("иями", "ями", "ами", "ией", "иям", "ием", "иях", "ие", "ье", "еи", "ии", "ей",
             "ой", "ий", "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия", "ья", "а",
             "ев", "ов", "е", "и", "й", "о", "у", "ы", "ь", "ю", "я")

    def _grp(self, w, rv, g1, g2):
        s = _longest(w, g1 + g2)
        if not s:
            return None
        if len(w) - len(s) < rv:
            return None
        if s in g1 and s not in g2:
            if w[:-len(s)][-1:] in ("а", "я"):
                return w[:-len(s)]
            return None
        return w[:-len(s)]

    def stem(self, word):
        word = word.replace("ё", "е")
        rv = len(word)
        for i, c in enumerate(word):
            if c in self.v:
                rv = i + 1
                break
        p1 = _starts(word, self.v)
        p2 = _starts(word[p1:], self.v) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        w = word
        # step 1
        r = self._rem_all(w, rv, self._pg1, self._pg2)
        if r is not None:
            w = r
        else:
            for s in self._refl:
                if w.endswith(s) and len(w) - 2 >= rv:
                    w = w[:-2]
                    break
            r = self._rem_all(w, rv, (), self._adj)
            if r is not None:
                w = r
                rp = self._rem_all(w, rv, self._part1, self._part2)
                if rp is not None:
                    w = rp
            else:
                r = self._rem_all(w, rv, self._verb1, self._verb2)
                if r is not None:
                    w = r
                else:
                    r = self._rem_all(w, rv, (), self._noun)
                    if r is not None:
                        w = r
        # step 2
        if w.endswith("и") and len(w) - 1 >= rv:
            w = w[:-1]
        # step 3
        s = _longest(w, ("ость", "ост"))
        if s and len(w) - len(s) >= p2:
            w = w[:-len(s)]
        # step 4
        if w.endswith("ь") and len(w) - 1 >= rv:
            w = w[:-1]
        else:
            s = _longest(w, ("ейше", "ейш"))
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
            if w.endswith("нн"):
                w = w[:-1]
        return w

    def _rem_all(self, w, rv, g1, g2):
        s = _longest(w, tuple(g1) + tuple(g2))
        if not s:
            return None
        base = w[:-len(s)]
        if len(w) - len(s) < rv:
            return None
        if s in g2 or s in ("в", "вши", "вшись") and False:
            return base
        # group 1 requires preceding а / я
        if base[-1:] in ("а", "я") and len(base) - 1 >= rv - 0 or base[-1:] in ("а", "я"):
            return base
        # fall back: shorter group-2 / group-1 candidates
        for cand in sorted(tuple(g1) + tuple(g2), key=len, reverse=True):
            if cand != s and w.endswith(cand) and len(w) - len(cand) >= rv:
                b = w[:-len(cand)]
                if cand in g2 or b[-1:] in ("а", "я"):
                    return b
        return None


# ------------------------------------------------------------------ Italian
class Italian:
    v = "aeiouàèìòù"

    def stem(self, word):
        v = self.v
        word = word.translate(str.maketrans("áéíóú", "àèìòù"))
        for a, b in (("qu", "qU"),):
            word = word.replace(a, b)
        w = list(word)
        for i in range(1, len(w) - 1):
            if w[i - 1] in v and w[i + 1] in v:
                if w[i] == "u":
                    w[i] = "U"
                elif w[i] == "i":
                    w[i] = "I"
        word = "".join(w)
        v2 = v + "UI"
        p1 = _starts(word, v2)
        p2 = _starts(word[p1:], v2) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        rv = self._rv(word, v2)
        pron = ("gliela", "gliele", "glieli", "glielo", "gliene", "sene", "mela", "mele",
                "meli", "melo", "mene", "tela", "tele", "teli", "telo", "tene", "cela",
                "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo", "vene", "gli",
                "ci", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi")
        s = _longest(word, pron)
        if s:
            base = word[:-len(s)]
            for pre in ("ando", "endo"):
                if base.endswith(pre) and len(base) - len(pre) >= rv:
                    word = base
                    break
            else:
                for pre in ("ar", "er", "ir"):
                    if base.endswith(pre) and len(base) - len(pre) >= rv:
                        word = base + "e"
                        break
        orig = word
        s1 = _longest(word, (
            "amente", "atrici", "atrice", "azioni", "azione", "amenti", "amento", "imenti",
            "imento", "abilità", "ibilità", "ività", "logie", "logia", "uzioni", "uzione",
            "usioni", "usione", "mente", "anza", "anze", "iche", "ichi", "ismo", "ismi",
            "abile", "abili", "ibile", "ibili", "ista", "iste", "isti", "istà", "istì",
            "istè", "oso", "osi", "osa", "ose", "anti", "ante", "ico", "ici", "ica", "ice",
            "enza", "enze", "atori", "atore", "ità", "ivo", "ivi", "iva", "ive"))
        if s1 and len(word) - len(s1) >= p2 or (s1 in ("amente",) and len(word) - 6 >= p1):
            if s1 in ("logie", "logia"):
                word = word[:-len(s1)] + "log"
            elif s1 in ("uzioni", "uzione", "usioni", "usione"):
                word = word[:-len(s1)] + "u"
            elif s1 in ("enza", "enze"):
                word = word[:-len(s1)] + "ente"
            elif s1 == "amente":
                word = word[:-6]
                for x in ("iv", "os", "ic", "abil"):
                    if word.endswith(x) and len(word) - len(x) >= p2:
                        word = word[:-len(x)]
                        if x == "iv" and word.endswith("at") and len(word) - 2 >= p2:
                            word = word[:-2]
                        break
            elif s1 == "mente":
                word = word[:-5]
            elif s1 in ("amenti", "amento", "imenti", "imento"):
                word = word[:-len(s1)]
            elif s1 in ("ità", "abilità", "ibilità", "ività"):
                word = word[:-len(s1)]
                for x in ("abil", "ic", "iv"):
                    if word.endswith(x) and len(word) - len(x) >= p2:
                        word = word[:-len(x)]
                        break
            elif s1 in ("ivo", "ivi", "iva", "ive"):
                word = word[:-len(s1)]
                if word.endswith("at") and len(word) - 2 >= p2:
                    word = word[:-2]
                    if word.endswith("ic") and len(word) - 2 >= p2:
                        word = word[:-2]
            else:
                word = word[:-len(s1)]
                if s1 in ("azioni", "azione", "atori", "atore", "atrici", "atrice"):
                    if word.endswith("ic") and len(word) - 2 >= p2:
                        word = word[:-2]
        if word == orig:
            s2 = _longest(word, (
                "erebbero", "irebbero", "assero", "assimo", "eranno", "erebbe", "eremmo",
                "ereste", "eresti", "essero", "iranno", "irebbe", "iremmo", "ireste",
                "iresti", "iscano", "iscono", "issero", "arono", "avamo", "avano", "avate",
                "eremo", "erete", "erono", "evamo", "evano", "evate", "iremo", "irete",
                "irono", "ivamo", "ivano", "ivate", "ammo", "ando", "asse", "assi", "emmo",
                "enda", "ende", "endi", "endo", "erai", "erei", "Yamo", "iamo", "immo",
                "irai", "irei", "isca", "isce", "isci", "isco", "ano", "are", "ata", "ate",
                "ati", "ato", "ava", "avi", "avo", "erà", "ere", "erò", "ete", "eva", "evi",
                "evo", "irà", "ire", "irò", "ita", "ite", "iti", "ito", "iva", "ivi", "ivo",
                "ono", "uta", "ute", "uti", "uto", "ar", "ir"))
            if s2 and len(word) - len(s2) >= rv:
                word = word[:-len(s2)]
        # residual
        if word and word[-1] in "aeioàèìò" and len(word) - 1 >= rv:
            word = word[:-1]
            if word.endswith("i") and len(word) - 1 >= rv:
                word = word[:-1]
        if word.endswith("ch") or word.endswith("gh"):
            word = word[:-1]
        word = word.replace("I", "i").replace("U", "u")
        return word.translate(str.maketrans("àèìòù", "aeiou")) if False else word

    def _rv(self, word, v):
        if len(word) < 2:
            return len(word)
        if word[1] not in v:
            for i in range(2, len(word)):
                if word[i] in v:
                    return i + 1
            return len(word)
        if word[0] in v and word[1] in v:
            for i in range(2, len(word)):
                if word[i] not in v:
                    return i + 1
            return len(word)
        return min(3, len(word))


# --------------------------------------------------------------- Portuguese
class Portuguese(Spanish):
    v = "aeiouáéíóúâêô"

    def stem(self, word):
        word = word.replace("ã", "a~").replace("õ", "o~")
        v = self.v
        p1 = _starts(word, v)
        p2 = _starts(word[p1:], v) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        rv = self._rv(word)
        o = word

        def inr(w, suf, p):
            return len(w) - len(suf) >= p

        s = _longest(word, (
            "amentos", "imentos", "amento", "imento", "adoras", "adores", "aço~es", "logias",
            "ências", "amente", "idades", "logia", "ância", "ência", "adora", "ações",
            "antes", "ismos", "istas", "ações", "mente", "idade", "ável", "ível", "ismo",
            "ista", "ador", "ação", "ante", "eza", "ezas", "ico", "ica", "icos", "icas",
            "oso", "osa", "osos", "osas", "ivo", "iva", "ivos", "ivas", "uça~o", "uça~es"))
        if s and inr(word, s, p2 if s != "amente" else p1):
            base = word[:-len(s)]
            if s in ("logia", "logias"):
                word = base + "log"
            elif s in ("ência", "ências"):
                word = base + "ente"
            elif s == "amente":
                word = base
                for x in ("iv", "os", "ic", "ad"):
                    if word.endswith(x) and inr(word, x, p2):
                        word = word[:-len(x)]
                        if x == "iv" and word.endswith("at") and inr(word, "at", p2):
                            word = word[:-2]
                        break
            elif s == "mente":
                word = base
                for x in ("ante", "avel", "ível"):
                    if word.endswith(x) and inr(word, x, p2):
                        word = word[:-len(x)]
                        break
            elif s in ("idade", "idades"):
                word = base
                for x in ("abil", "ic", "iv"):
                    if word.endswith(x) and inr(word, x, p2):
                        word = word[:-len(x)]
                        break
            elif s in ("ivo", "iva", "ivos", "ivas"):
                word = base
                if word.endswith("at") and inr(word, "at", p2):
                    word = word[:-2]
            else:
                word = base
                if s in ("ador", "adora", "adores", "adoras", "ação", "ações") \
                        and word.endswith("ic") and inr(word, "ic", p2):
                    word = word[:-2]
        if word == o:
            s = _longest(word, (
                "aríamos", "eríamos", "iríamos", "ássemos", "êssemos", "íssemos", "aremos",
                "eremos", "iremos", "ávamos", "íamos", "aríei", "eríei", "iríei", "ásseis",
                "ésseis", "ísseis", "áramos", "éramos", "íramos", "aríam", "eríam", "iríam",
                "assem", "essem", "issem", "aremo", "arias", "erias", "irias", "ardes",
                "erdes", "irdes", "asses", "esses", "isses", "astes", "estes", "istes",
                "áveis", "íeis", "aram", "eram", "iram", "avam", "arem", "erem", "irem",
                "ando", "endo", "indo", "adas", "idas", "arás", "aras", "erás", "irás",
                "ar", "er", "ir", "as", "es", "is", "ou", "ia", "ei", "am", "em", "ia",
                "ada", "ida", "ara", "era", "ira", "ava", "ado", "ido", "ará", "erá",
                "irá", "aria", "eria", "iria", "ass", "ar", "ia", "ia"))
            if s and inr(word, s, rv):
                word = word[:-len(s)]
        else:
            pass
        if word != o or True:
            if word.endswith("os") or word.endswith(("a", "i", "o", "á", "í", "ó")):
                for x in ("os", "a", "i", "o", "á", "í", "ó"):
                    if word.endswith(x) and inr(word, x, rv):
                        word = word[:-len(x)]
                        break
            else:
                for x in ("e", "é", "ê"):
                    if word.endswith(x) and inr(word, x, rv):
                        word = word[:-1]
                        break
        word = word.replace("a~", "ã").replace("o~", "õ")
        return word.translate(str.maketrans("áéíóúâêô", "aeiouaeo")) if False else word


# ------------------------------------------------------------------- French
class French:
    v = "aeiouyâàëéêèïîôûù"

    def stem(self, word):
        v = self.v
        w = list(word)
        for i in range(len(w)):
            c = w[i]
            prev = w[i - 1] if i else ""
            nxt = w[i + 1] if i + 1 < len(w) else ""
            if c == "u" and prev == "q":
                w[i] = "U"
            elif c in "ui" and prev in v and nxt in v and prev and nxt:
                w[i] = c.upper()
            elif c == "y" and (prev in v and prev or nxt in v and nxt):
                w[i] = "Y"
        word = "".join(w)
        v2 = v
        p1 = _starts(word, v2)
        p2 = _starts(word[p1:], v2) + p1 if p1 < len(word) else len(word)
        p2 = min(p2, len(word))
        if word.startswith(("par", "col", "tap")):
            rv = 3
        elif len(word) > 1 and word[0] in v2 and word[1] in v2:
            rv = 3
        else:
            rv = len(word)
            for i in range(1, len(word)):
                if word[i] in v2:
                    rv = i + 1
                    break
        rv = min(rv, len(word))

        def inr(x, suf, p):
            return len(x) - len(suf) >= p

        orig = word
        step2a_needed = False
        s = _longest(word, (
            "issements", "issement", "atrices", "atrice", "ateurs", "ateur", "ations",
            "ation", "usions", "usion", "utions", "ution", "logies", "logie", "ements",
            "ement", "ences", "ence", "ances", "ance", "iqUes", "iqUe", "ismes", "isme",
            "ables", "able", "istes", "iste", "euses", "euse", "eux", "ités", "ité", "ives",
            "ive", "ifs", "if", "eaux", "aux", "amment", "emment", "ments", "ment"))
        if s:
            base = word[:-len(s)]
            if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes",
                     "ables", "istes"):
                if inr(word, s, p2):
                    word = base
            elif s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
                if inr(word, s, p2):
                    word = base
                    if word.endswith("ic"):
                        if inr(word, "ic", p2):
                            word = word[:-2]
                        else:
                            word = word[:-2] + "iqU"
            elif s in ("logie", "logies"):
                if inr(word, s, p2):
                    word = base + "log"
            elif s in ("usion", "ution", "usions", "utions"):
                if inr(word, s, p2):
                    word = base + "u"
            elif s in ("ence", "ences"):
                if inr(word, s, p2):
                    word = base + "ent"
            elif s in ("ement", "ements"):
                if inr(word, s, rv):
                    word = base
                    if word.endswith("iv") and inr(word, "iv", p2):
                        word = word[:-2]
                        if word.endswith("at") and inr(word, "at", p2):
                            word = word[:-2]
                    elif word.endswith(("eus",)):
                        if inr(word, "eus", p2):
                            word = word[:-3]
                        elif inr(word, "eus", p1):
                            word = word[:-3] + "eux"
                    elif word.endswith(("abl", "iqU")) and inr(word, "abl", p2):
                        word = word[:-3]
                    elif word.endswith(("ièr", "Ièr")) and inr(word, "ièr", rv):
                        word = word[:-3] + "i"
            elif s in ("ité", "ités"):
                if inr(word, s, p2):
                    word = base
                    if word.endswith("abil"):
                        if inr(word, "abil", p2):
                            word = word[:-4]
                        else:
                            word = word[:-4] + "abl"
                    elif word.endswith("ic"):
                        if inr(word, "ic", p2):
                            word = word[:-2]
                        else:
                            word = word[:-2] + "iqU"
                    elif word.endswith("iv") and inr(word, "iv", p2):
                        word = word[:-2]
            elif s in ("if", "ive", "ifs", "ives"):
                if inr(word, s, p2):
                    word = base
                    if word.endswith("at") and inr(word, "at", p2):
                        word = word[:-2]
                        if word.endswith("ic"):
                            if inr(word, "ic", p2):
                                word = word[:-2]
                            else:
                                word = word[:-2] + "iqU"
            elif s == "eaux":
                word = base + "eau"
            elif s == "aux":
                if inr(word, s, p1):
                    word = base + "al"
            elif s in ("euse", "euses"):
                if inr(word, s, p2):
                    word = base
                elif inr(word, s, p1):
                    word = base + "eux"
            elif s in ("issement", "issements"):
                if inr(word, s, p1) and base and base[-1] not in v:
                    word = base
            elif s == "amment":
                if inr(word, s, rv):
                    word = base + "ant"
                    step2a_needed = True
            elif s == "emment":
                if inr(word, s, rv):
                    word = base + "ent"
                    step2a_needed = True
            elif s in ("ment", "ments"):
                if inr(word, s, rv) and base and base[-1] in v:
                    word = base
                    step2a_needed = True
        if word == orig or step2a_needed:
            before = word
            s = _longest(word, (
                "issaIent", "issantes", "issions", "irions", "issante", "issants", "issais",
                "issait", "issant", "issent", "issiez", "issons", "irions", "iraIent", "irais",
                "irait", "irent", "iriez", "irons", "iront", "isses", "îmes", "îtes", "irai",
                "iras", "irez", "isse", "issez", "ies", "ira", "ir", "is", "it", "ie", "îtes",
                "ît", "i"))
            if s:
                base = word[:-len(s)]
                if inr(word, s, rv) and base and base[-1] not in v and base[-1] != "H":
                    word = base
            if word == before:
                s = _longest(word, ("assions", "assiez", "assent", "asses", "âmes", "âtes",
                                    "antes", "ante", "ants", "ant", "aIent", "asse", "ais",
                                    "ait", "ai", "as", "ât", "a", "ions", "èrent", "erions",
                                    "eraIent", "eront", "erons", "eriez", "erais", "erait",
                                    "eras", "erez", "erai", "era", "ées", "iez", "ez", "er",
                                    "ée", "és", "é"))
                if s:
                    if s == "ions":
                        if inr(word, s, p2):
                            word = word[:-4]
                    elif inr(word, s, rv):
                        word = word[:-len(s)]
                        if s in ("assions", "assiez", "assent", "asses", "âmes", "âtes",
                                 "antes", "ante", "ants", "ant", "aIent", "asse", "ais",
                                 "ait", "ai", "as", "ât", "a") and word.endswith("e") \
                                and inr(word, "e", rv):
                            word = word[:-1]
        if word != orig or True:
            word = word.replace("Y", "i") if word.endswith("Y") else word
            if word.endswith("ç"):
                word = word[:-1] + "c"
        # residual suffix
        if word == orig or True:
            if word.endswith("s") and len(word) >= 2 and word[-2] not in "aiouès" \
                    and inr(word, "s", rv):
                word = word[:-1]
            s = _longest(word, ("ion", "ier", "ière", "Ier", "Ière", "e", "ë"))
            if s and inr(word, s, rv):
                if s == "ion":
                    if inr(word, s, p2) and word[-4:-3] in ("s", "t") and len(word) >= 4:
                        word = word[:-3]
                elif s in ("ier", "ière", "Ier", "Ière"):
                    word = word[:-len(s)] + "i"
                elif s == "e":
                    word = word[:-1]
                elif s == "ë" and word.endswith("guë"):
                    word = word[:-1]
        if word.endswith(("enn", "onn", "ett", "ell", "eill")):
            word = word[:-1]
        # unaccent
        for i in range(len(word) - 1, -1, -1):
            if word[i] in "éè":
                if i + 1 < len(word) and all(c not in v for c in word[i + 1:]) \
                        and i != len(word) - 1:
                    word = word[:i] + "e" + word[i + 1:]
                break
            if word[i] in v:
                break
        return word.replace("U", "u").replace("I", "i").replace("Y", "y")


class _Passthrough:
    def stem(self, word):
        return word


_MAP = {"german": German, "spanish": Spanish, "swedish": Swedish, "danish": Danish,
        "norwegian": Norwegian, "dutch": Dutch, "russian": Russian, "italian": Italian,
        "portuguese": Portuguese, "french": French}


def make(language):
    return _MAP.get(language, _Passthrough)()
