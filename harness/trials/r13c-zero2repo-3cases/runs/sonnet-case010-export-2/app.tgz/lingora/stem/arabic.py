"""Light Arabic stemmers."""
import re

_DIACRITICS = re.compile("[ً-ْـ]")
_PREFIXES = ("وال", "فال", "بال", "كال",
             "لل", "ال", "و")
_SUFFIXES = ("هما", "كما", "ات", "ان",
             "ين", "ون", "ها", "هم", "ة", "ه",
             "ي")


class ARLSTem:
    def stem(self, word):
        w = _DIACRITICS.sub("", word)
        w = re.sub("[أإآ]", "ا", w)
        for p in _PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 2:
                w = w[len(p):]
                break
        for s in _SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass
