"""Snowball stemmers."""
from .. import data
from .porter import PorterStemmer

LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
             "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
             "russian", "spanish", "swedish")


def _r1r2(word, vowels):
    def region(start_word):
        for i in range(1, len(start_word)):
            if start_word[i] not in vowels and start_word[i - 1] in vowels:
                return start_word[i + 1:]
        return ""
    r1 = region(word)
    return r1, region(r1)


class _EnglishStemmer:
    vowels = "aeiouy"
    double = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    li_ending = "cdeghkmnrt"
    s1a = ("sses", "ied", "ies", "us", "ss", "s")
    s1b = ("eedly", "ingly", "edly", "eed", "ing", "ed")
    s2 = ("ization", "ational", "fulness", "ousness", "iveness", "tional", "biliti", "lessli",
          "entli", "ation", "alism", "aliti", "ousli", "iviti", "fulli", "enci", "anci",
          "abli", "izer", "ator", "alli", "bli", "ogi", "li")
    s2map = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
             "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
             "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
             "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
             "fulli": "ful", "lessli": "less"}
    s3 = ("ational", "tional", "alize", "icate", "iciti", "ative", "ical", "ness", "ful")
    s3map = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
             "ical": "ic", "ful": "", "ness": ""}
    s4 = ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti",
          "ous", "ive", "ize", "ion", "al", "er", "ic")
    special = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
               "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
               "only": "onli", "singly": "singl", "sky": "sky", "news": "news", "howe": "howe",
               "atlas": "atlas", "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    exc2 = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")

    def _short_syllable_end(self, w):
        v = self.vowels
        if len(w) == 2:
            return w[0] in v and w[1] not in v
        if len(w) >= 3:
            return w[-1] not in v and w[-1] not in "wxY" and w[-2] in v and w[-3] not in v
        return False

    def _region_start(self, w, start=0):
        v = self.vowels
        for i in range(start + 1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                return i + 1
        return len(w)

    def stem(self, word):
        word = word.lower()
        if len(word) <= 2:
            return word
        if word in self.special:
            return self.special[word]
        if word.startswith("'"):
            word = word[1:]
        if len(word) <= 2:
            return word
        v = self.vowels
        chars = list(word)
        if chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i - 1] in v and chars[i] == "y":
                chars[i] = "Y"
        word = "".join(chars)
        if word.startswith(("gener", "arsen")):
            p1 = 5
        elif word.startswith("commun"):
            p1 = 6
        else:
            p1 = self._region_start(word)
        p2 = self._region_start(word, p1) if p1 < len(word) else len(word)

        def in_r1(suf):
            return len(word) - len(suf) >= p1

        def in_r2(suf):
            return len(word) - len(suf) >= p2

        # step 0
        for suf in ("'s'", "'s", "'"):
            if word.endswith(suf):
                word = word[:-len(suf)]
                break
        # step 1a
        for suf in self.s1a:
            if word.endswith(suf):
                if suf == "sses":
                    word = word[:-2]
                elif suf in ("ied", "ies"):
                    word = word[:-2] if len(word) - 3 > 1 else word[:-1]
                elif suf == "s":
                    if any(c in v for c in word[:-2]):
                        word = word[:-1]
                break
        if word in self.exc2:
            return word
        # step 1b
        for suf in self.s1b:
            if word.endswith(suf):
                if suf in ("eed", "eedly"):
                    if in_r1(suf):
                        word = word[:-len(suf)] + "ee"
                else:
                    stem = word[:-len(suf)]
                    if any(c in v for c in stem):
                        word = stem
                        if word.endswith(("at", "bl", "iz")):
                            word += "e"
                        elif word.endswith(self.double):
                            word = word[:-1]
                        elif p1 >= len(word) and self._short_syllable_end(word):
                            word += "e"
                break
        # step 1c
        if len(word) > 2 and word[-1] in "yY" and word[-2] not in v:
            word = word[:-1] + "i"
        # step 2
        for suf in self.s2:
            if word.endswith(suf):
                if in_r1(suf):
                    if suf == "ogi":
                        if word[-4:-3] == "l":
                            word = word[:-1]
                    elif suf == "li":
                        if len(word) >= 3 and word[-3] in self.li_ending:
                            word = word[:-2]
                    else:
                        word = word[:-len(suf)] + self.s2map[suf]
                break
        # step 3
        for suf in self.s3:
            if word.endswith(suf):
                if in_r1(suf):
                    if suf == "ative":
                        if in_r2(suf):
                            word = word[:-5]
                    else:
                        word = word[:-len(suf)] + self.s3map[suf]
                break
        # step 4
        for suf in self.s4:
            if word.endswith(suf):
                if in_r2(suf):
                    if suf == "ion":
                        if word[-4:-3] in ("s", "t") and len(word) >= 4:
                            word = word[:-3]
                    else:
                        word = word[:-len(suf)]
                break
        # step 5
        if word.endswith("l"):
            if in_r2("l") and word[-2:-1] == "l":
                word = word[:-1]
        elif word.endswith("e"):
            if in_r2("e"):
                word = word[:-1]
            elif in_r1("e") and not self._short_syllable_end(word[:-1]):
                word = word[:-1]
        return word.replace("Y", "y")


class _PorterSnowball:
    def __init__(self):
        self._p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        return self._p.stem(word.lower())


def _make(language):
    if language == "english":
        return _EnglishStemmer()
    if language == "porter":
        return _PorterSnowball()
    from . import snowball_langs
    return snowball_langs.make(language)


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in LANGUAGES:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            lines = data.read_lines("corpora/stopwords", language)
            self.stopwords = {l.strip() for l in lines if l.strip()}
        self.stemmer = _make(language)

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self.stemmer.stem(word)
