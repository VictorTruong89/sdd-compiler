"""Porter stemmer (three modes) and Lancaster stemmer."""
import re


class PorterStemmer:
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("unknown Porter stemmer mode %r" % (mode,))
        self.mode = mode
        self.pool = {}
        irregular = {
            "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
            "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
            "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
            "exceed": ["exceed"], "succeed": ["succeed"],
        }
        for key, vals in irregular.items():
            for v in vals:
                self.pool[v] = key

    # helpers ---------------------------------------------------------
    def _is_consonant(self, word, i):
        if word[i] in "aeiou":
            return False
        if word[i] == "y":
            return True if i == 0 else not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_pm(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        n = len(word)
        return (n >= 3 and self._is_consonant(word, n - 3) and not self._is_consonant(word, n - 2)
                and self._is_consonant(word, n - 1) and word[-1] not in "wxy") or (
            self.mode == self.NLTK_EXTENSIONS and n == 2
            and not self._is_consonant(word, 0) and self._is_consonant(word, 1))

    @staticmethod
    def _replace_suffix(word, suffix, repl):
        return word + repl if suffix == "" else word[:-len(suffix)] + repl

    def _apply_rule_list(self, word, rules):
        for suffix, repl, cond in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if cond is None or cond(stem):
                    return stem + repl
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if cond is None or cond(stem):
                    return stem + repl
                return word
        return word

    # steps -----------------------------------------------------------
    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("ies") and len(word) == 4:
            return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None),
                                            ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("ied"):
            return self._replace_suffix(word, "ied", "ie" if len(word) == 4 else "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            return stem + "ee" if self._measure(stem) > 0 else word
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                cand = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(cand):
                    inter = cand
                    break
        if inter is None:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda s: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda s: self._measure(s) == 1 and self._ends_cvc(s)),
        ])

    def _step1c(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            cond = lambda s: len(s) > 1 and self._is_consonant(s, len(s) - 1)
        else:
            cond = self._contains_vowel
        return self._apply_rule_list(word, [("y", "i", cond)])

    def _step2(self, word):
        pm = self._has_pm
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pm)
        abli = ("abli", "able", pm)
        rules = [("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm),
                 ("anci", "ance", pm), ("izer", "ize", pm),
                 abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
                 ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm), ("ousli", "ous", pm),
                 ("ization", "ize", pm), ("ation", "ate", pm), ("ator", "ate", pm),
                 ("alism", "al", pm), ("iveness", "ive", pm), ("fulness", "ful", pm),
                 ("ousness", "ous", pm), ("aliti", "al", pm), ("iviti", "ive", pm),
                 ("biliti", "ble", pm)]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda s: pm(word[:-3])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_pm
        return self._apply_rule_list(word, [("icate", "ic", pm), ("ative", "", pm),
                                            ("alize", "al", pm), ("iciti", "ic", pm),
                                            ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        m1 = lambda s: self._measure(s) > 1
        return self._apply_rule_list(word, [
            ("al", "", m1), ("ance", "", m1), ("ence", "", m1), ("er", "", m1), ("ic", "", m1),
            ("able", "", m1), ("ible", "", m1), ("ant", "", m1), ("ement", "", m1),
            ("ment", "", m1), ("ent", "", m1),
            ("ion", "", lambda s: self._measure(s) > 1 and s[-1:] in ("s", "t")),
            ("ou", "", m1), ("ism", "", m1), ("ate", "", m1), ("iti", "", m1), ("ous", "", m1),
            ("ive", "", m1), ("ize", "", m1)])

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda s: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem


_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1j<", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.",
    "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.", "mu*2.",
    "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>",
    "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.",
    "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>",
    "yli3y>", "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.",
    "yrtsi5.", "yra3>", "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)
_VALID_RULE = re.compile(r"^([a-z]+)(\*?)(\d+)([a-z]*)([>\.]?)$")


class LancasterStemmer:
    def __init__(self):
        self.rule_dictionary = {}
        for rule in _LANCASTER_RULES:
            self.rule_dictionary.setdefault(rule[0], []).append(rule)

    @staticmethod
    def _last_letter(word):
        for i in range(len(word)):
            if not word[i].isalpha():
                return i - 1
        return len(word) - 1

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def stem(self, word):
        word = word.lower()
        intact = word
        proceed = True
        while proceed:
            pos = self._last_letter(word)
            if pos < 0 or word[pos] not in self.rule_dictionary:
                break
            applied = False
            for rule in self.rule_dictionary[word[pos]]:
                m = _VALID_RULE.match(rule)
                if not m:
                    continue
                ending, intact_flag, remove, append, cont = m.groups()
                remove = int(remove)
                if word.endswith(ending[::-1]):
                    if intact_flag:
                        if word == intact and self._acceptable(word, remove):
                            word = word[:len(word) - remove] + append
                            applied = True
                            if cont == ".":
                                proceed = False
                            break
                    elif self._acceptable(word, remove):
                        word = word[:len(word) - remove] + append
                        applied = True
                        if cont == ".":
                            proceed = False
                        break
            if not applied:
                proceed = False
        return word
