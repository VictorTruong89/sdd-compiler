"""Stemmers."""
import re

from .. import data
from .porter import LancasterStemmer, PorterStemmer
from .snowball import SnowballStemmer
from .arabic import ARLSTem, ARLSTem2


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if isinstance(regexp, str):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


class WordNetLemmatizer:
    def __init__(self):
        data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        base = data.find("corpora/wordnet")
        import os
        # minimal lookup against WordNet index files when available
        names = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "r": "index.adv"}
        fp = os.path.join(base, names.get(pos, "index.noun"))
        words = set()
        if os.path.isfile(fp):
            with open(fp, encoding="utf-8") as f:
                for line in f:
                    if line and line[0] != " ":
                        words.add(line.split(" ", 1)[0])
        subs = {"n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
                      ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
                "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"),
                      ("ed", ""), ("ing", "e"), ("ing", "")],
                "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")], "r": []}
        forms = [word] + [word[:-len(o)] + n for o, n in subs.get(pos, []) if o and word.endswith(o)]
        cands = [f for f in forms if f in words]
        return min(cands, key=len) if cands else word


__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
           "SnowballStemmer", "WordNetLemmatizer"]
