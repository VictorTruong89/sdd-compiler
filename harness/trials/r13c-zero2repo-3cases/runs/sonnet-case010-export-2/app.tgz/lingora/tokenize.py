"""Tokenizers: regexp, Penn Treebank, tweet and Punkt sentence splitting."""
# spec: N-000386 N-000387
import html.entities
import os
import re

from . import data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
           "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
           "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
           "NLTKWordTokenizer", "PunktSentenceTokenizer"]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


# ------------------------------------------------------------------ regexp
class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                s, e = m.span()
                if e == s and False:
                    continue
                if not (self._discard_empty and s == pos):
                    yield (pos, s)
                pos = e
            if not (self._discard_empty and pos == len(text)):
                yield (pos, len(text))
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.end() == m.start():
                    continue
                yield m.span()

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            parts = self._regexp.split(text)
            # split() with groups would interleave captures; use spans instead
            toks = [text[s:e] for s, e in self.span_tokenize(text)]
            del parts
            return toks
        return [m.group(0) for m in self._regexp.finditer(text)
                if not (self._discard_empty and m.end() == m.start())]


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# ---------------------------------------------------------------- treebank
def _align_tokens(tokens, text):
    pos = 0
    spans = []
    for tok in tokens:
        start = text.index(tok, pos)
        end = start + len(tok)
        spans.append((start, end))
        pos = end
    return spans


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2 \3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check_text(text)
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        raw = self.tokenize(text)
        quotes = [m.group() for m in re.finditer(r"``|'{2}|\"", text)]
        toks = [quotes.pop(0) if t in ('"', "``", "''") and quotes else t for t in raw]
        for span in _align_tokens(toks, text):
            yield span


class NLTKWordTokenizer(TreebankWordTokenizer):
    """The improved Penn Treebank tokenizer used by ``word_tokenize``."""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([^\.])(\.)([\]\)}>\"\'»”’ ]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒-―]", re.U), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"\s+"), " "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_treebank = TreebankWordTokenizer()
_nltk_word = NLTKWordTokenizer()


# -------------------------------------------------------------------- tweet
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""

_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""

_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""

_WORD_PARTS = (
    _URLS, _PHONE, _EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.%+-]+@[\w.-]+\.[a-zA-Z]{2,}""",
    r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])""",
    r"""(?:[+\-]?\d+[,/.:-]\d+[+\-]?)""",
    r"""(?:[\w_]+)""",
    r"""(?:\.(?:\s*\.){1,})""",
    r"""(?:\S)""",
)
_WORD_RE = re.compile("(%s)" % "|".join(_WORD_PARTS), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_LENGTHENING_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_ENT_RE = re.compile(r"&(#?(x?))([^&;\s]+);")


def _replace_entities(text):
    def sub(m):
        body = m.group(3)
        if m.group(1):
            try:
                num = int(body, 16) if m.group(2) else int(body)
                return chr(num)
            except (ValueError, OverflowError):
                return m.group(0)
        if body in html.entities.name2codepoint:
            return chr(html.entities.name2codepoint[body])
        return m.group(0)
    return _ENT_RE.sub(sub, text)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        text = _replace_entities(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTHENING_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(1) for m in _WORD_RE.finditer(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words


# ------------------------------------------------------------------- punkt
_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_UC = 14
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_LC = 112

_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI_CHAR = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_PERIOD_CONTEXT_RE = re.compile(r"""
        [.?!]
        (?=(?P<after_tok>
            %s
            |
            \s+(?P<next_tok>\S+)
        ))""" % _NON_WORD, re.UNICODE | re.VERBOSE)
_PUNKT_WORD_RE = re.compile(r"""(
        %(m)s
        |
        (?=%(ws)s)\S+?
        (?=
            \s|
            $|
            %(nw)s|%(m)s|
            ,(?=$|\s|%(nw)s|%(m)s)
        )
        |
        \S
    )""" % {"m": _MULTI_CHAR, "ws": _WORD_START, "nw": _NON_WORD}, re.UNICODE | re.VERBOSE)
_BOUNDARY_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_RE_NON_PUNCT = re.compile(r"[^\W\d]", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "parastart", "linestart", "sentbreak", "abbr", "ellipsis",
                 "type", "period_final", "type_no_period", "type_no_sentperiod",
                 "first_upper", "first_lower", "is_ellipsis", "is_initial")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = self.abbr = self.ellipsis = False
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        t = self.type
        self.type_no_period = t[:-1] if len(t) > 1 and t.endswith(".") else t
        self.type_no_sentperiod = self.type_no_period if self.period_final else t
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_ellipsis = bool(_RE_ELLIPSIS.match(tok))
        self.is_initial = bool(_RE_INITIAL.match(tok))


class PunktSentenceTokenizer:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = set(abbrev_types)
        self.sent_starters = set(sent_starters)
        self.collocations = set(collocations)
        self.ortho_context = dict(ortho_context)

    @classmethod
    def load(cls, language="english"):
        res = "tokenizers/punkt_tab/%s" % language
        data.find(res)
        abbrev = [l.strip() for l in data.read_lines(res, "abbrev_types.txt") if l.strip()]
        starters = [l.strip() for l in data.read_lines(res, "sent_starters.txt") if l.strip()]
        colls = []
        for l in data.read_lines(res, "collocations.tab"):
            if not l.strip():
                continue
            parts = l.split("\t")
            if len(parts) != 2:
                raise ValueError("bad collocations line %r" % l)
            colls.append((parts[0], parts[1]))
        ortho = {}
        for l in data.read_lines(res, "ortho_context.tab"):
            if not l.strip():
                continue
            parts = l.split("\t")
            if len(parts) != 2:
                raise ValueError("bad ortho_context line %r" % l)
            ortho[parts[0]] = int(parts[1])
        return cls(abbrev, starters, colls, ortho)

    # -- token annotation
    def _words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = _PUNKT_WORD_RE.findall(line)
                if not toks:
                    continue
                yield _Tok(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for t in toks[1:]:
                    yield _Tok(t)
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        if tok in (".", "?", "!"):
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if (tok[:-1].lower() in self.abbrev_types
                    or tok[:-1].lower().split("-")[-1] in self.abbrev_types):
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho_heuristic(self, t):
        if t.tok in tuple(";:,.!?"):
            return False
        oc = self.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            starter = self._ortho_heuristic(t2)
            if starter is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            starter = self._ortho_heuristic(t2)
            if starter is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (starter == "unknown" and initial and t2.first_upper
                    and not (self.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _contains_sentbreak(self, text):
        toks = list(self._words(text))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # -- slicing
    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i].isspace():
                return i
        return 0

    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_CONTEXT_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            pw = (idx, m.start())
            if prev_match is not None and prev_slice[1] <= pw[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() \
                    + prev_match.group("after_tok")
            prev_match = m
            prev_slice = pw
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() \
                + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for m, ctx in self._contexts(text):
            if self._contains_sentbreak(ctx):
                yield (last, m.end())
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _BOUNDARY_REALIGN.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text):
        _check_text(text)
        return iter(list(self._realign(text, self._slices(text))))

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text)]


_punkt_cache = {}


def _load_punkt(language):
    if not isinstance(language, str) or not language or "/" in language or ".." in language:
        raise ValueError("invalid language %r" % (language,))
    base = data.find("tokenizers/punkt_tab/%s" % language)
    names = ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")
    stamp = []
    for n in names:
        fp = os.path.join(base, n)
        if not os.path.isfile(fp):
            raise LookupError("missing Punkt file %s" % fp)
        st = os.stat(fp)
        stamp.append((fp, st.st_mtime_ns, st.st_size))
    key = tuple(stamp)
    tok = _punkt_cache.get(key)
    if tok is None:
        tok = PunktSentenceTokenizer.load(language)
        _punkt_cache.clear()
        _punkt_cache[key] = tok
    return tok


def sent_tokenize(text, language="english"):
    _check_text(text)
    return _load_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    _check_text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sentences for t in _nltk_word.tokenize(s)]
