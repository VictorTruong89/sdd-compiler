import pytest

from lingora.chunk import RegexpParser
from lingora.classify import NaiveBayesClassifier
from lingora.grammar import CFG
from lingora.metrics import accuracy, edit_distance, f_measure
from lingora.parse import ChartParser
from lingora.stem import PorterStemmer, SnowballStemmer
from lingora.tokenize import WordPunctTokenizer, word_tokenize
from lingora.tree import Tree


def test_wordpunct():
    assert WordPunctTokenizer().tokenize("Hi, you!") == ["Hi", ",", "you", "!"]


def test_word_tokenize_line():
    assert word_tokenize("can't go.", preserve_line=True) == ["ca", "n't", "go", "."]


def test_porter_and_snowball():
    assert PorterStemmer().stem("ponies") == "poni"
    assert SnowballStemmer("english").stem("generously") == "generous"
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_chunk_and_tree():
    t = RegexpParser("NP: {<DT><NN>}").parse([("a", "DT"), ("b", "NN")])
    assert t[0].label() == "NP"
    with pytest.raises(TypeError):
        Tree("S", "abc")


def test_chart():
    g = CFG.fromstring("S -> 'a' S | 'a'")
    assert len(list(ChartParser(g).parse(["a", "a"]))) == 1


def test_metrics_and_classify():
    assert edit_distance("abc", "ca", transpositions=True) == 2
    assert f_measure(set(), {1}) is None
    with pytest.raises(ValueError):
        accuracy([1], [])
    c = NaiveBayesClassifier.train([({"a": 1}, "x"), ({"a": 2}, "y")])
    assert c.classify({"a": 2}) == "y"
