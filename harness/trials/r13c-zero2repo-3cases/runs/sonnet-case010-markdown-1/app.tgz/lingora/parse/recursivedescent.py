from lingora.parse.chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Top-down parser; results coincide with the exhaustive parser."""
