from lingora.grammar import Nonterminal
from lingora.tree import Tree


class ChartParser:
    """Exhaustive chart-style parser returning every parse tree."""

    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens, tree_class))

    def _parse(self, tokens, tree_class):
        g = self._grammar
        n = len(tokens)
        memo = {}
        seq_memo = {}
        in_progress = set()

        def derive(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in in_progress:
                return []
            in_progress.add(key)
            result = []
            for prod in g.productions(sym):
                for kids in seq(prod.rhs(), 0, i, j, id(prod)):
                    result.append(tree_class(str(sym), list(kids)))
            in_progress.discard(key)
            memo[key] = result
            return result

        def seq(rhs, idx, i, j, pid):
            key = (pid, idx, i, j)
            if key in seq_memo:
                return seq_memo[key]
            out = []
            if idx == len(rhs):
                if i == j:
                    out.append(())
            else:
                s = rhs[idx]
                last = idx == len(rhs) - 1
                if isinstance(s, Nonterminal):
                    ends = [j] if last else range(i, j + 1)
                    for k in ends:
                        subs = derive(s, i, k)
                        if not subs:
                            continue
                        rests = seq(rhs, idx + 1, k, j, pid)
                        for sub in subs:
                            for rest in rests:
                                out.append((sub,) + rest)
                else:
                    if i < j and tokens[i] == s and (not last or j == i + 1):
                        for rest in seq(rhs, idx + 1, i + 1, j, pid):
                            out.append((s,) + rest)
            seq_memo[key] = out
            return out

        return derive(g.start(), 0, n)
