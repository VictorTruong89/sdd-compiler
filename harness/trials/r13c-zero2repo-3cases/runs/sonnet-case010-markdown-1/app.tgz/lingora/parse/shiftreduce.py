from lingora.grammar import Nonterminal
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            if len(rhs) > len(stack):
                continue
            tail = stack[len(stack) - len(rhs):] if rhs else []
            if self._match(rhs, tail):
                del stack[len(stack) - len(rhs):]
                stack.append(Tree(str(prod.lhs()), list(tail)))
                return True
        return False

    @staticmethod
    def _match(rhs, items):
        for sym, item in zip(rhs, items):
            if isinstance(sym, Nonterminal):
                if not (isinstance(item, Tree) and item.label() == sym):
                    return False
            else:
                if isinstance(item, Tree) or item != sym:
                    return False
        return True

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        # empty productions can reduce at any point; bound the loops
        guard = 0
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                guard += 1
                if guard > 10000:
                    return
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == self._grammar.start():
            yield stack[0]
