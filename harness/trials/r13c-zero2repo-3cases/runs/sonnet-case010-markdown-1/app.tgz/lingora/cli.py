"""Command-line group."""
import sys


class UsageError(Exception):
    pass


class _Command:
    def __init__(self, name, func, help_text=""):
        self.name = name
        self.func = func
        self.help = help_text


class Group:
    def __init__(self, name="lingora"):
        self.name = name
        self.commands = {}

    def command(self, name, help_text=""):
        def deco(func):
            self.commands[name] = _Command(name, func, help_text)
            return func
        return deco

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write("Usage: %s COMMAND [ARGS]...\n\nCommands:\n%s" % (
                self.name, "".join("  %s  %s\n" % (c.name, c.help) for c in self.commands.values())))
            return 0 if args else 2
        cmd = self.commands.get(args[0])
        if cmd is None:
            raise UsageError("No such command %r." % args[0])
        return cmd.func(list(args[1:])) or 0

    def main(self, args=None, prog_name=None, standalone_mode=True, **kwargs):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            code = self._run(args)
        except UsageError as e:
            sys.stderr.write("Error: %s\n" % e)
            code = 2
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        except Exception as e:  # noqa: BLE001
            sys.stderr.write("Error: %s\n" % e)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    __call__ = main


cli = Group("lingora")


def _tokenize(args):
    language = "english"
    delimiter = " "
    encoding = "utf8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            sys.stdout.write("Usage: lingora tokenize [OPTIONS]\n\n"
                             "  -l, --language TEXT   Punkt language (default english)\n"
                             "  -d, --delimiter TEXT  Token delimiter (default ' ')\n"
                             "  -e, --encoding TEXT   Input encoding (default utf8)\n")
            return 0
        opt, val = a, None
        if a.startswith("--") and "=" in a:
            opt, val = a.split("=", 1)
        if opt in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if val is None:
                i += 1
                if i >= len(args):
                    raise UsageError("Option %s requires an argument." % opt)
                val = args[i]
            if opt in ("-l", "--language"):
                language = val
            elif opt in ("-d", "--delimiter"):
                delimiter = val
            else:
                encoding = val
        else:
            raise UsageError("Got unexpected extra argument (%s)" % a)
        i += 1

    from lingora.tokenize import word_tokenize
    from lingora.tokenize.punkt import _get_tokenizer
    _get_tokenizer(language)  # fail before writing anything when Punkt is missing

    stdin = sys.stdin
    if hasattr(stdin, "buffer"):
        import io
        stdin = io.TextIOWrapper(stdin.buffer, encoding=encoding, newline="")
    out = sys.stdout
    for line in stdin:
        line = line.rstrip("\r\n") if not line.endswith("\r\n") else line[:-2]
        tokens = word_tokenize(line, language)
        out.write(delimiter.join(tokens) + "\n")
    out.flush()
    return 0


cli.command("tokenize", "Tokenize text from standard input.")(_tokenize)
