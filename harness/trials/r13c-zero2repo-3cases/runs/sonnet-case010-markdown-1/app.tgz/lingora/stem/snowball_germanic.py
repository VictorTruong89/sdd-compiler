"""Snowball stemmers: German, Dutch, Swedish, Norwegian, Danish."""
from lingora.stem._util import longest_suffix, regions


# ----------------------------------------------------------------------- German
_DE_VOWELS = "aeiouyäöü"
_DE_S_END = "bdfghklmnrt"
_DE_ST_END = "bdfghklmnt"


def stem_german(word):
    word = word.lower().replace("ß", "ss")
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i - 1] in _DE_VOWELS and chars[i + 1] in _DE_VOWELS:
            if chars[i] == "u":
                chars[i] = "U"
            elif chars[i] == "y":
                chars[i] = "Y"
    word = "".join(chars)
    r1 = regions(word, _DE_VOWELS)
    r1 = max(3, r1) if len(word) >= 3 or True else r1
    r2 = regions(word, _DE_VOWELS, r1) if r1 < len(word) else len(word)
    r1 = min(r1, len(word))

    def in_r(suffix, r):
        return len(word) - len(suffix) >= r

    # Step 1
    s = longest_suffix(word, ("em", "ern", "er", "e", "en", "es", "s"))
    # Snowball 'among' with condition: the longest matching suffix decides
    if s and in_r(s, r1):
        if s in ("em", "ern", "er"):
            word = word[:-len(s)]
        elif s in ("e", "en", "es"):
            word = word[:-len(s)]
            if word.endswith("niss"):
                word = word[:-1]
        elif s == "s":
            if len(word) >= 2 and word[-2] in _DE_S_END:
                word = word[:-1]
    # Step 2
    s = longest_suffix(word, ("en", "er", "est", "st"))
    if s and in_r(s, r1):
        if s in ("en", "er", "est"):
            word = word[:-len(s)]
        elif s == "st":
            if len(word) >= 6 and word[-3] in _DE_ST_END:
                word = word[:-2]
    # Step 3
    s = longest_suffix(word, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
    if s and in_r(s, r2):
        if s in ("end", "ung"):
            word = word[:-3]
            if word.endswith("ig") and len(word) - 2 >= r2 and not word[:-2].endswith("e"):
                word = word[:-2]
        elif s in ("ig", "ik", "isch"):
            if not word[:-len(s)].endswith("e"):
                word = word[:-len(s)]
        elif s in ("lich", "heit"):
            word = word[:-4]
            t = longest_suffix(word, ("er", "en"))
            if t and in_r(t, r1):
                word = word[:-2]
        elif s == "keit":
            word = word[:-4]
            t = longest_suffix(word, ("lich", "ig"))
            if t and in_r(t, r2):
                word = word[:-len(t)]
    word = word.replace("U", "u").replace("Y", "y")
    return word.translate(str.maketrans("äöü", "aou"))


# ------------------------------------------------------------------------ Dutch
_NL_VOWELS = "aeiouyè"


def _nl_undouble(word):
    if word.endswith(("kk", "dd", "tt")):
        return word[:-1]
    return word


def stem_dutch(word):
    word = word.lower()
    word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _NL_VOWELS:
            chars[i] = "Y"
    for i in range(1, len(chars) - 1):
        if chars[i] == "i" and chars[i - 1] in _NL_VOWELS and chars[i + 1] in _NL_VOWELS:
            chars[i] = "I"
    word = "".join(chars)
    r1 = max(3, regions(word, _NL_VOWELS))
    r1 = min(r1, len(word))
    r2 = regions(word, _NL_VOWELS, r1) if r1 < len(word) else len(word)

    def in_r(suffix, r, w=None):
        w = word if w is None else w
        return len(w) - len(suffix) >= r

    def gem_ok(w, suffix):
        base = w[:-len(suffix)]
        return bool(base) and base[-1] not in _NL_VOWELS and not base.endswith("gem")

    # Step 1
    s = longest_suffix(word, ("heden", "ene", "en", "se", "s"))
    if s and in_r(s, r1):
        if s == "heden":
            word = word[:-5] + "heid"
        elif s in ("ene", "en"):
            if gem_ok(word, s):
                word = _nl_undouble(word[:-len(s)])
        else:
            base = word[:-len(s)]
            if base and base[-1] not in _NL_VOWELS and base[-1] != "j":
                word = base
    # Step 2
    e_found = False
    if word.endswith("e") and in_r("e", r1) and len(word) >= 2 and word[-2] not in _NL_VOWELS:
        word = _nl_undouble(word[:-1])
        e_found = True
    # Step 3a
    if word.endswith("heid") and in_r("heid", r2) and not word[:-4].endswith("c"):
        word = word[:-4]
        if word.endswith("en") and in_r("en", r1) and gem_ok(word, "en"):
            word = _nl_undouble(word[:-2])
    # Step 3b
    s = longest_suffix(word, ("end", "ing", "ig", "lijk", "baar", "bar"))
    if s and in_r(s, r2):
        if s in ("end", "ing"):
            word = word[:-3]
            if word.endswith("ig") and in_r("ig", r2) and not word[:-2].endswith("e"):
                word = word[:-2]
            else:
                word = _nl_undouble(word)
        elif s == "ig":
            if not word[:-2].endswith("e"):
                word = word[:-2]
        elif s == "lijk":
            word = word[:-4]
            if word.endswith("e") and in_r("e", r1) and len(word) >= 2 and word[-2] not in _NL_VOWELS:
                word = _nl_undouble(word[:-1])
        elif s == "baar":
            word = word[:-4]
        elif s == "bar" and e_found:
            word = word[:-3]
    # Step 4: undouble vowel
    if len(word) >= 4 and word[-3] == word[-2] and word[-3] in "aeou" \
            and word[-4] not in _NL_VOWELS and word[-1] not in _NL_VOWELS and word[-1] != "I":
        word = word[:-2] + word[-1]
    return word.replace("I", "i").replace("Y", "y")


# --------------------------------------------------------------------- Swedish
_SV_VOWELS = "aeiouyäåö"
_SV_STEP1 = ("a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are",
             "aste", "en", "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as",
             "arnas", "ernas", "ornas", "es", "ades", "andes", "ens", "arens", "hetens", "erns",
             "at", "andet", "het", "ast", "s")
_SV_S_END = "bcdfghjklmnoprtvy"


def stem_swedish(word):
    word = word.lower()
    r1 = min(max(3, regions(word, _SV_VOWELS)), len(word))
    s = longest_suffix(word, _SV_STEP1)
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) >= 2 and word[-2] in _SV_S_END:
                word = word[:-1]
        else:
            word = word[:-len(s)]
    t = longest_suffix(word, ("dd", "gd", "nn", "dt", "gt", "kt", "tt"))
    if t and len(word) - len(t) >= r1:
        word = word[:-1]
    s = longest_suffix(word, ("lig", "ig", "els", "löst", "fullt"))
    if s and len(word) - len(s) >= r1:
        if s == "löst":
            word = word[:-1]
        elif s == "fullt":
            word = word[:-1]
        else:
            word = word[:-len(s)]
    return word


# ------------------------------------------------------------------- Norwegian
_NO_VOWELS = "aeiouyæåø"
_NO_STEP1 = ("a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar",
             "er", "heter", "as", "es", "edes", "endes", "enes", "hetenes", "ens", "hetens",
             "ers", "ets", "et", "het", "ast", "s", "erte", "ert")
_NO_S_END = "bcdfghjlmnoprtvyz"


def stem_norwegian(word):
    word = word.lower()
    r1 = min(max(3, regions(word, _NO_VOWELS)), len(word))
    s = longest_suffix(word, _NO_STEP1)
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) >= 2 and (word[-2] in _NO_S_END
                                   or (word[-2] == "k" and len(word) >= 3 and word[-3] not in _NO_VOWELS)):
                word = word[:-1]
        elif s in ("erte", "ert"):
            word = word[:-len(s)] + "er"
        else:
            word = word[:-len(s)]
    t = longest_suffix(word, ("dt", "vt"))
    if t and len(word) - len(t) >= r1:
        word = word[:-1]
    s = longest_suffix(word, ("leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov", "elov",
                              "slov", "hetslov"))
    if s and len(word) - len(s) >= r1:
        word = word[:-len(s)]
    return word


# ---------------------------------------------------------------------- Danish
_DA_VOWELS = "aeiouyæåø"
_DA_STEP1 = ("hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en",
             "heden", "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes",
             "ernes", "eres", "ens", "hedens", "erens", "ers", "ets", "erets", "et", "eret", "s")
_DA_S_END = "abcdfghjklmnoprtvyzå"


def stem_danish(word):
    word = word.lower()
    r1 = min(max(3, regions(word, _DA_VOWELS)), len(word))
    s = longest_suffix(word, _DA_STEP1)
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) >= 2 and word[-2] in _DA_S_END:
                word = word[:-1]
        else:
            word = word[:-len(s)]

    def consonant_pair(w):
        t = longest_suffix(w, ("gd", "dt", "gt", "kt"))
        if t and len(w) - len(t) >= r1:
            return w[:-1]
        return w

    word = consonant_pair(word)
    if word.endswith("igst") and len(word) - 4 >= r1:
        word = word[:-2]
    s = longest_suffix(word, ("elig", "lig", "ig", "els", "løst"))
    if s and len(word) - len(s) >= r1:
        if s == "løst":
            word = word[:-1]
        else:
            word = consonant_pair(word[:-len(s)])
    # undouble consonant
    if len(word) - 1 >= r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in _DA_VOWELS:
        word = word[:-1]
    return word
