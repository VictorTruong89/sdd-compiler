import os
import re

from lingora import data

_POS_FILES = (("n", "noun"), ("v", "verb"), ("a", "adj"), ("r", "adv"))
_DETACH = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}


class WordNetLemmatizer:
    def __init__(self):
        self._root = data.find("corpora/wordnet")
        self._index = {}

    def _words(self, pos):
        if pos in self._index:
            return self._index[pos]
        words = set()
        fname = dict(_POS_FILES)[pos]
        path = os.path.join(self._root, "index." + fname)
        for line in data.read_lines(path):
            if line.startswith(" ") or not line:
                continue
            words.add(line.split(" ", 1)[0])
        self._index[pos] = words
        return words

    def lemmatize(self, word, pos="n"):
        if pos not in dict(_POS_FILES):
            raise ValueError("unsupported part of speech %r" % (pos,))
        words = self._words(pos)
        cands = []
        if word in words:
            cands.append(word)
        for suf, rep in _DETACH[pos]:
            if word.endswith(suf):
                c = word[:len(word) - len(suf)] + rep
                if c in words:
                    cands.append(c)
        return min(cands, key=len) if cands else word
