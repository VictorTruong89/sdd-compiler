from lingora import data
from lingora.stem.porter import PorterStemmer
from lingora.stem.snowball_english import stem_english
from lingora.stem.snowball_germanic import (
    stem_danish, stem_dutch, stem_german, stem_norwegian, stem_swedish)
from lingora.stem.snowball_romance import (
    stem_french, stem_italian, stem_portuguese, stem_spanish)
from lingora.stem.snowball_russian import stem_russian
from lingora.stem.snowball_other import (
    stem_arabic, stem_finnish, stem_hungarian, stem_romanian)

_FUNCS = {
    "arabic": stem_arabic,
    "danish": stem_danish,
    "dutch": stem_dutch,
    "english": stem_english,
    "finnish": stem_finnish,
    "french": stem_french,
    "german": stem_german,
    "hungarian": stem_hungarian,
    "italian": stem_italian,
    "norwegian": stem_norwegian,
    "portuguese": stem_portuguese,
    "romanian": stem_romanian,
    "russian": stem_russian,
    "spanish": stem_spanish,
    "swedish": stem_swedish,
}

_porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)


def _porter_stem(word):
    return _porter.stem(word)


_FUNCS["porter"] = _porter_stem


class SnowballStemmer:
    languages = tuple(sorted(_FUNCS))

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self._func = _FUNCS[language]
        self.stopwords = set()
        if ignore_stopwords:
            path = data.find("corpora/stopwords/%s" % language)
            self.stopwords = set(w.strip() for w in data.read_lines(path) if w.strip())

    def stem(self, word):
        if self.stopwords and word.lower() in self.stopwords:
            return word.lower()
        return self._func(word)
