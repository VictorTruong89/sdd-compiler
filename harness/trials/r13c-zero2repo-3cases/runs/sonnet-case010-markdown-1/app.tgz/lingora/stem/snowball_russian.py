"""Snowball Russian stemmer."""
from lingora.stem._util import longest_suffix, regions

_V = "аеиоуыэюя"

_PG1 = ("в", "вши", "вшись")
_PG2 = ("ив", "ивши", "ившись", "ыв", "ывши", "ывшись")
_REFLEXIVE = ("ся", "сь")
_ADJECTIVE = ("ее", "ие", "ые", "ое", "ими", "ыми", "ей", "ий", "ый", "ой", "ем", "им", "ым",
              "ом", "его", "ого", "ему", "ому", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
_PART1 = ("ем", "нн", "вш", "ющ", "щ")
_PART2 = ("ивш", "ывш", "ующ")
_VERB1 = ("ла", "на", "ете", "йте", "ли", "й", "л", "ем", "н", "ло", "но", "ет", "ют", "ны",
          "ть", "ешь", "нно")
_VERB2 = ("ила", "ыла", "ена", "ейте", "уйте", "ите", "или", "ыли", "ей", "уй", "ил", "ыл",
          "им", "ым", "ен", "ило", "ыло", "ено", "ят", "ует", "уют", "ит", "ыт", "ены", "ить",
          "ыть", "ишь", "ую", "ю")
_NOUN = ("а", "ев", "ов", "ие", "ье", "е", "иями", "ями", "ами", "еи", "ии", "и", "ией", "ей",
         "ой", "ий", "й", "иям", "ям", "ием", "ем", "ам", "ом", "о", "у", "ах", "иях", "ях",
         "ы", "ь", "ию", "ью", "ю", "ия", "ья", "я")
_SUPER = ("ейш", "ейше")
_DERIV = ("ость", "ост")


def stem_russian(word):
    word = word.lower().replace("ё", "е")
    rv = len(word)
    for i, c in enumerate(word):
        if c in _V:
            rv = i + 1
            break
    r1 = regions(word, _V)
    r2 = regions(word, _V, r1) if r1 < len(word) else len(word)
    if rv >= len(word):
        return word
    head, w = word[:rv], word[rv:]

    def group1(w, sufs):
        """Group-1 endings need a preceding 'а' or 'я' (inside RV)."""
        s = longest_suffix(w, sufs)
        if s is None:
            return None, False
        base = w[:-len(s)]
        if base and base[-1] in "ая":
            return s, True
        return s, False

    def perfective(w):
        s = longest_suffix(w, _PG1 + _PG2)
        if s is None:
            return w, False
        base = w[:-len(s)]
        if s in _PG1:
            if base and base[-1] in "ая":
                return base, True
            return w, False
        return base, True

    def reflexive(w):
        s = longest_suffix(w, _REFLEXIVE)
        return (w[:-len(s)], True) if s else (w, False)

    def adjective(w):
        s = longest_suffix(w, _ADJECTIVE)
        return (w[:-len(s)], True) if s else (w, False)

    def participle(w):
        s = longest_suffix(w, _PART1 + _PART2)
        if s is None:
            return w, False
        base = w[:-len(s)]
        if s in _PART1:
            if base and base[-1] in "ая":
                return base, True
            return w, False
        return base, True

    def adjectival(w):
        w2, ok = adjective(w)
        if not ok:
            return w, False
        w3, ok2 = participle(w2)
        return (w3, True) if ok2 else (w2, True)

    def verb(w):
        s = longest_suffix(w, _VERB1 + _VERB2)
        if s is None:
            return w, False
        base = w[:-len(s)]
        if s in _VERB1:
            if base and base[-1] in "ая":
                return base, True
            return w, False
        return base, True

    def noun(w):
        s = longest_suffix(w, _NOUN)
        return (w[:-len(s)], True) if s else (w, False)

    w1, ok = perfective(w)
    if ok:
        w = w1
    else:
        w, _ = reflexive(w)
        for fn in (adjectival, verb, noun):
            w1, ok = fn(w)
            if ok:
                w = w1
                break
    # Step 2
    if w.endswith("и"):
        w = w[:-1]
    # Step 3: derivational ending in R2
    full = head + w
    s = longest_suffix(full, _DERIV)
    if s and len(full) - len(s) >= r2 and len(full) - len(s) >= rv:
        w = w[:-len(s)]
    # Step 4
    s = longest_suffix(w, _SUPER)
    if s:
        w = w[:-len(s)]
        if w.endswith("нн"):
            w = w[:-1]
    elif w.endswith("нн"):
        w = w[:-1]
    elif w.endswith("ь"):
        w = w[:-1]
    return head + w
