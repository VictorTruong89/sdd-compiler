"""Snowball stemmers: Spanish, French, Portuguese, Italian."""
from lingora.stem._util import longest_suffix, regions


def _rv_spanish_style(word, vowels):
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
        return n
    return min(3, n)


# ---------------------------------------------------------------------- Spanish
_ES_V = "aeiouáéíóúü"
_ES_PRON = ("selas", "selos", "sela", "selo", "las", "les", "los", "nos", "me", "se", "la",
            "le", "lo")
_ES_STEP1_DELETE_R2 = (
    "anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables", "able", "ibles",
    "ible", "istas", "ista", "osos", "osas", "oso", "osa", "amientos", "amiento", "imientos",
    "imiento")
_ES_STEP1_B = ("adoras", "adores", "adora", "ador", "aciones", "ación", "antes", "ante",
               "ancias", "ancia")
_ES_STEP1_ALL = _ES_STEP1_DELETE_R2 + _ES_STEP1_B + (
    "logías", "logía", "uciones", "ución", "encias", "encia", "amente", "mente", "idades",
    "idad", "ivas", "ivos", "iva", "ivo")
_ES_2A = ("yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes", "ya", "ye", "yo", "yó")
_ES_2B_GU = ("en", "es", "éis", "emos")
_ES_2B = (
    "arían", "arías", "arán", "arás", "aríais", "aría", "aréis", "aríamos", "aremos", "ará",
    "aré", "erían", "erías", "erán", "erás", "eríais", "ería", "eréis", "eríamos", "eremos",
    "erá", "eré", "irían", "irías", "irán", "irás", "iríais", "iría", "iréis", "iríamos",
    "iremos", "irá", "iré", "abais", "aban", "abas", "aba", "adas", "adas", "ada", "idas",
    "ida", "ías", "ía", "aras", "ara", "ieras", "iera", "arais", "ierais", "aran", "ieran",
    "ases", "ase", "ieses", "iese", "aseis", "ieseis", "asen", "iesen", "asteis", "isteis",
    "aste", "iste", "ados", "ado", "idos", "ido", "ando", "iendo", "amos", "ábamos", "íamos",
    "imos", "áramos", "iéramos", "iésemos", "ásemos", "aron", "ieron", "ían", "an", "ad",
    "ed", "id", "ió", "ar", "er", "ir", "as", "ís", "áis", "íais", "ais")


def stem_spanish(word):
    word = word.lower()
    r1 = regions(word, _ES_V)
    r2 = regions(word, _ES_V, r1) if r1 < len(word) else len(word)
    rv = _rv_spanish_style(word, _ES_V)

    def inr(w, suffix, r):
        return len(w) - len(suffix) >= r

    # Step 0
    s = longest_suffix(word, _ES_PRON)
    if s and inr(word, s, rv):
        base = word[:-len(s)]
        for pre, rep in (("iéndo", "iendo"), ("ándo", "ando"), ("ár", "ar"), ("ér", "er"),
                         ("ír", "ir")):
            if base.endswith(pre) and len(base) - len(pre) >= rv:
                word = base[:-len(pre)] + rep
                break
        else:
            for pre in ("iendo", "ando", "ar", "er", "ir"):
                if base.endswith(pre) and len(base) - len(pre) >= rv:
                    word = base
                    break
            else:
                if base.endswith("yendo") and base[:-5].endswith("u") and len(base) - 6 >= rv:
                    word = base
    original = word

    # Step 1
    done1 = False
    s = longest_suffix(word, _ES_STEP1_ALL)
    if s:
        base = word[:-len(s)]
        if s in _ES_STEP1_DELETE_R2:
            if inr(word, s, r2):
                word = base
                done1 = True
        elif s in _ES_STEP1_B:
            if inr(word, s, r2):
                word = base
                done1 = True
                if word.endswith("ic") and inr(word, "ic", r2):
                    word = word[:-2]
        elif s in ("logías", "logía"):
            if inr(word, s, r2):
                word = base + "log"
                done1 = True
        elif s in ("uciones", "ución"):
            if inr(word, s, r2):
                word = base + "u"
                done1 = True
        elif s in ("encias", "encia"):
            if inr(word, s, r2):
                word = base + "ente"
                done1 = True
        elif s == "amente":
            if inr(word, s, r1):
                word = base
                done1 = True
                if word.endswith("iv") and inr(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and inr(word, "at", r2):
                        word = word[:-2]
                else:
                    for t in ("os", "ic", "ad"):
                        if word.endswith(t) and inr(word, t, r2):
                            word = word[:-len(t)]
                            break
        elif s == "mente":
            if inr(word, s, r2):
                word = base
                done1 = True
                t = longest_suffix(word, ("ante", "able", "ible"))
                if t and inr(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("idades", "idad"):
            if inr(word, s, r2):
                word = base
                done1 = True
                t = longest_suffix(word, ("abil", "ic", "iv"))
                if t and inr(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("ivas", "ivos", "iva", "ivo"):
            if inr(word, s, r2):
                word = base
                done1 = True
                if word.endswith("at") and inr(word, "at", r2):
                    word = word[:-2]
    if not done1:
        # Step 2a
        s = longest_suffix(word, _ES_2A)
        done2 = False
        if s and inr(word, s, rv) and word[:-len(s)].endswith("u"):
            word = word[:-len(s)]
            done2 = True
        if not done2:
            # Step 2b
            cands = _ES_2B_GU + _ES_2B
            s = longest_suffix(word, cands)
            if s and inr(word, s, rv):
                if s in _ES_2B_GU:
                    word = word[:-len(s)]
                    if word.endswith("gu"):
                        word = word[:-1]
                else:
                    word = word[:-len(s)]
    # Step 3
    s = longest_suffix(word, ("os", "a", "o", "á", "í", "ó", "e", "é"))
    if s and inr(word, s, rv):
        if s in ("e", "é"):
            word = word[:-len(s)]
            if word.endswith("gu") and len(word) - 1 >= rv:
                word = word[:-1]
        else:
            word = word[:-len(s)]
    return word.translate(str.maketrans("áéíóú", "aeiou"))


# ----------------------------------------------------------------------- French
_FR_V = "aeiouyâàëéêèïîôûù"


def _fr_prelude(word):
    chars = list(word)
    n = len(chars)
    out = []
    i = 0
    # ë / ï are marked so they do not count as vowels
    tmp = []
    for ch in chars:
        if ch == "ë":
            tmp.append("He")
        elif ch == "ï":
            tmp.append("Hi")
        else:
            tmp.append(ch)
    chars = list("".join(tmp))
    n = len(chars)
    res = list(chars)
    for i in range(n):
        c = chars[i]
        prev = chars[i - 1] if i > 0 else ""
        nxt = chars[i + 1] if i + 1 < n else ""
        if c == "u" and prev in _FR_V and prev and nxt in _FR_V and nxt:
            res[i] = "U"
        elif c == "i" and prev and nxt and prev in _FR_V and nxt in _FR_V:
            res[i] = "I"
        elif c == "y" and ((prev and prev in _FR_V) or (nxt and nxt in _FR_V)):
            res[i] = "Y"
        elif c == "u" and prev == "q":
            res[i] = "U"
    return "".join(res)


def _fr_rv(word):
    n = len(word)
    if word.startswith(("par", "col", "tap")):
        return min(3, n)
    if n >= 2 and word[0] in _FR_V and word[1] in _FR_V:
        return min(3, n)
    for i in range(1, n):
        if word[i] in _FR_V:
            return i + 1
    return n


_FR_STEP1 = (
    "issements", "issement", "atrices", "atrice", "ateurs", "ations", "logies", "usions",
    "utions", "ements", "amment", "emment", "ances", "iqUes", "ismes", "ables", "istes",
    "ateur", "ation", "logie", "usion", "ution", "ences", "ement", "euses", "ments", "ance",
    "iqUe", "isme", "able", "iste", "ence", "ités", "ives", "eaux", "euse", "ment", "eux",
    "ité", "ive", "ifs", "aux", "if")
_FR_2A = (
    "issantes", "issante", "issants", "issions", "irions", "issais", "issait", "issant",
    "issent", "issiez", "issons", "irais", "irait", "irent", "irez", "iront", "isses", "issez",
    "îmes", "îtes", "irai", "iras", "ies", "ira", "ît", "ie", "ir", "is", "it", "i", "isse")
_FR_2B = (
    "assions", "erions", "assent", "assiez", "èrent", "erais", "erait", "eriez", "erons",
    "eront", "antes", "asses", "ions", "erai", "eras", "erez", "âmes", "âtes", "ante", "ants",
    "asse", "ées", "era", "iez", "ais", "ait", "ant", "ée", "és", "er", "ez", "ai", "as", "é",
    "a", "ât")
_FR_2B_A = ("âmes", "âtes", "ât", "a", "ai", "ais", "ait", "ant", "ante", "antes", "ants",
            "as", "asse", "assent", "asses", "assiez", "assions")


def stem_french(word):
    word = _fr_prelude(word.lower())
    rv = _fr_rv(word)
    r1 = regions(word, _FR_V)
    r2 = regions(word, _FR_V, r1) if r1 < len(word) else len(word)

    def ok(w, suffix, r):
        return len(w) - len(suffix) >= r

    altered = False
    step2a_needed = True
    s = longest_suffix(word, _FR_STEP1)
    ran_step1 = False
    force_2a = False
    if s:
        b = word[:-len(s)]
        if s in ("ances", "iqUes", "ismes", "ables", "istes", "ance", "iqUe", "isme", "able",
                 "iste", "eux"):
            if ok(word, s, r2):
                word = b
                ran_step1 = True
        elif s in ("atrices", "atrice", "ateurs", "ateur", "ations", "ation"):
            if ok(word, s, r2):
                word = b
                ran_step1 = True
                if word.endswith("ic"):
                    if ok(word, "ic", r2):
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
        elif s in ("logies", "logie"):
            if ok(word, s, r2):
                word = b + "log"
                ran_step1 = True
        elif s in ("usions", "usion", "utions", "ution"):
            if ok(word, s, r2):
                word = b + "u"
                ran_step1 = True
        elif s in ("ences", "ence"):
            if ok(word, s, r2):
                word = b + "ent"
                ran_step1 = True
        elif s in ("ements", "ement"):
            if ok(word, s, rv):
                word = b
                ran_step1 = True
                if word.endswith("iv"):
                    if ok(word, "iv", r2):
                        word = word[:-2]
                        if word.endswith("at") and ok(word, "at", r2):
                            word = word[:-2]
                elif word.endswith("eus"):
                    if ok(word, "eus", r2):
                        word = word[:-3]
                    elif ok(word, "eus", r1):
                        word = word[:-3] + "eux"
                elif word.endswith(("abl", "iqU")):
                    if ok(word, "abl", r2):
                        word = word[:-3]
                elif word.endswith(("ièr", "Ièr")):
                    if ok(word, "ièr", rv):
                        word = word[:-3] + "i"
        elif s in ("ités", "ité"):
            if ok(word, s, r2):
                word = b
                ran_step1 = True
                if word.endswith("abil"):
                    if ok(word, "abil", r2):
                        word = word[:-4]
                    else:
                        word = word[:-4] + "abl"
                elif word.endswith("ic"):
                    if ok(word, "ic", r2):
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
                elif word.endswith("iv"):
                    if ok(word, "iv", r2):
                        word = word[:-2]
        elif s in ("ifs", "ives", "if", "ive"):
            if ok(word, s, r2):
                word = b
                ran_step1 = True
                if word.endswith("at"):
                    if ok(word, "at", r2):
                        word = word[:-2]
                        if word.endswith("ic"):
                            if ok(word, "ic", r2):
                                word = word[:-2]
                            else:
                                word = word[:-2] + "iqU"
        elif s == "eaux":
            word = b + "eau"
            ran_step1 = True
        elif s == "aux":
            if ok(word, s, r1):
                word = b + "al"
                ran_step1 = True
        elif s in ("euses", "euse"):
            if ok(word, s, r2):
                word = b
                ran_step1 = True
            elif ok(word, s, r1):
                word = b + "eux"
                ran_step1 = True
        elif s in ("issements", "issement"):
            if ok(word, s, r1) and b and b[-1] not in _FR_V:
                word = b
                ran_step1 = True
        elif s == "amment":
            if ok(word, s, rv):
                word = b + "ant"
                ran_step1 = True
                force_2a = True
        elif s == "emment":
            if ok(word, s, rv):
                word = b + "ent"
                ran_step1 = True
                force_2a = True
        elif s in ("ments", "ment"):
            if ok(word, s, rv) and b and b[-1] in _FR_V and len(b) - 1 >= rv:
                word = b
                ran_step1 = True
                force_2a = True
    last_altered = ran_step1
    if not ran_step1 or force_2a:
        did2a = False
        t = longest_suffix(word, _FR_2A)
        if t and ok(word, t, rv):
            b = word[:-len(t)]
            if b and b[-1] not in _FR_V and b[-1] != "H":
                word = b
                did2a = True
        last_altered = did2a
        if not did2a:
            t = longest_suffix(word, _FR_2B)
            if t and ok(word, t, rv):
                if t == "ions":
                    if ok(word, t, r2):
                        word = word[:-4]
                        last_altered = True
                else:
                    word = word[:-len(t)]
                    last_altered = True
                    if t in _FR_2B_A and word.endswith("e") and ok(word, "e", rv):
                        word = word[:-1]
    if last_altered:
        # Step 3
        if word.endswith("Y"):
            word = word[:-1] + "i"
        elif word.endswith("ç"):
            word = word[:-1] + "c"
    else:
        # Step 4
        if word.endswith("s") and len(word) >= 2 and word[-2] not in "aiouès":
            word = word[:-1]
        t = longest_suffix(word, ("ière", "Ière", "ion", "ier", "Ier", "e", "ë"))
        if t and ok(word, t, rv):
            if t == "ion":
                if ok(word, t, r2) and len(word) >= 4 and word[-4] in "st":
                    word = word[:-3]
            elif t in ("ière", "Ière", "ier", "Ier"):
                word = word[:-len(t)] + "i"
            elif t == "e":
                word = word[:-1]
    # Step 5
    if word.endswith(("enn", "onn", "ett", "ell", "eill")):
        word = word[:-1]
    # Step 6
    for i in range(len(word) - 1, -1, -1):
        if word[i] in _FR_V:
            if word[i] in "éè" and i < len(word) - 1:
                word = word[:i] + "e" + word[i + 1:]
            break
    word = word.replace("I", "i").replace("U", "u").replace("Y", "y")
    word = word.replace("He", "ë").replace("Hi", "ï")
    return word


# ------------------------------------------------------------------- Portuguese
_PT_V = "aeiouáéíóúâêô"
_PT_STEP1_R2 = (
    "eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista",
    "istas", "oso", "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "adora",
    "ador", "aça~o", "adoras", "adores", "aço~es", "ante", "antes", "ância")
_PT_VERB = (
    "aríamos", "eríamos", "iríamos", "ássemos", "êssemos", "íssemos", "aremos", "areis", "ariam",
    "arias", "assem", "aremos", "eremos", "eriam", "erias", "essem", "iremos", "iriam", "irias",
    "issem", "ávamos", "ásseis", "êsseis", "ísseis", "aríeis", "eríeis", "iríeis", "arão",
    "arei", "aria", "asse", "aste", "avam", "avas", "áreis", "ando", "endo", "indo", "ar", "er",
    "ir", "amos", "ara", "ará", "are", "ava", "emos", "era", "erá", "ere", "iam", "ias", "imos",
    "ira", "irá", "ire", "isse", "iste", "ado", "ada", "ados", "adas", "ido", "ida", "idos",
    "idas", "ia", "ais", "am", "ou", "ei", "eu", "iu", "ão", "as", "es", "is", "ia", "ei",
    "era", "eram", "aram", "iram", "ariam", "eras", "aras", "iras", "arem", "erem", "irem",
    "ardes", "erdes", "irdes", "armos", "ermos", "irmos", "ar", "ou", "ava", "avas", "avam",
    "ávamos", "áveis", "íeis", "iam", "ia", "ias", "iamos", "aram", "ei", "este", "estes",
    "astes", "aste", "ásseis", "ássemos", "asses", "esses", "isses", "assemos", "âssemos",
    "arde", "erde", "irde", "ou", "eram", "emos", "es", "ar", "er", "ir")


def stem_portuguese(word):
    word = word.lower().replace("ã", "a~").replace("õ", "o~")
    v = _PT_V
    r1 = regions(word, v)
    r2 = regions(word, v, r1) if r1 < len(word) else len(word)
    rv = _rv_spanish_style(word, v)

    def ok(w, suffix, r):
        return len(w) - len(suffix) >= r

    changed = False
    s = longest_suffix(word, _PT_STEP1_R2 + (
        "logia", "logias", "uça~o", "uço~es", "ência", "ências", "amente", "mente", "idade",
        "idades", "iva", "ivo", "ivas", "ivos", "ira", "iras"))
    if s:
        b = word[:-len(s)]
        if s in _PT_STEP1_R2:
            if ok(word, s, r2):
                word = b
                changed = True
                if word.endswith("ic") and ok(word, "ic", r2):
                    word = word[:-2]
        elif s in ("logia", "logias"):
            if ok(word, s, r2):
                word = b + "log"
                changed = True
        elif s in ("uça~o", "uço~es"):
            if ok(word, s, r2):
                word = b + "u"
                changed = True
        elif s in ("ência", "ências"):
            if ok(word, s, r2):
                word = b + "ente"
                changed = True
        elif s == "amente":
            if ok(word, s, r1):
                word = b
                changed = True
                if word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and ok(word, "at", r2):
                        word = word[:-2]
                else:
                    for t in ("os", "ic", "ad"):
                        if word.endswith(t) and ok(word, t, r2):
                            word = word[:-len(t)]
                            break
        elif s == "mente":
            if ok(word, s, r2):
                word = b
                changed = True
                t = longest_suffix(word, ("ante", "avel", "ível"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("idade", "idades"):
            if ok(word, s, r2):
                word = b
                changed = True
                t = longest_suffix(word, ("abil", "ic", "iv"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("iva", "ivo", "ivas", "ivos"):
            if ok(word, s, r2):
                word = b
                changed = True
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
        elif s in ("ira", "iras"):
            if ok(word, s, rv) and b.endswith("e"):
                word = b[:-1] + "ir"
                changed = True
    if not changed:
        t = longest_suffix(word, _PT_VERB)
        if t and ok(word, t, rv):
            word = word[:-len(t)]
            changed = True
    if changed:
        if word.endswith("ci") and len(word) - 1 >= rv:
            word = word[:-1]
    else:
        t = longest_suffix(word, ("os", "a", "i", "o", "á", "í", "ó"))
        if t and ok(word, t, rv):
            word = word[:-len(t)]
    t = longest_suffix(word, ("e", "é", "ê"))
    if t and ok(word, t, rv):
        word = word[:-1]
        if word.endswith(("gu", "ci")) and len(word) - 1 >= rv:
            word = word[:-1]
    elif word.endswith("ç"):
        word = word[:-1] + "c"
    return word.replace("a~", "ã").replace("o~", "õ")


# ----------------------------------------------------------------------- Italian
_IT_V = "aeiouàèìòù"
_IT_PRON = ("gliela", "gliele", "glieli", "glielo", "gliene", "sene", "mela", "mele", "meli",
            "melo", "mene", "tela", "tele", "teli", "telo", "tene", "cela", "cele", "celi",
            "celo", "cene", "vela", "vele", "veli", "velo", "vene", "ci", "gli", "la", "le",
            "li", "lo", "mi", "ne", "si", "ti", "vi")
_IT_VERB = (
    "erebbero", "irebbero", "assero", "assimo", "eranno", "erebbe", "eremmo", "ereste",
    "eresti", "essero", "iranno", "irebbe", "iremmo", "ireste", "iresti", "iscano", "iscono",
    "issero", "avamo", "avano", "avate", "eremo", "erete", "erono", "evamo", "evano", "evate",
    "iremo", "irete", "irono", "ivamo", "ivano", "ivate", "ammo", "ando", "asse", "assi",
    "arono", "emmo", "enda", "ende", "endi", "endo", "erai", "erei", "erà", "erò", "immo",
    "irai", "irei", "irà", "irò", "isca", "isci", "isco", "yamo", "iamo", "ano", "are", "ata",
    "ate", "ati", "ato", "ava", "avi", "avo", "ere", "ete", "eva", "evi", "evo", "ire", "ita",
    "ite", "iti", "ito", "iva", "ivi", "ivo", "ono", "uta", "ute", "uti", "uto", "ar", "ir")


def stem_italian(word):
    word = word.lower()
    for a, b in (("á", "à"), ("é", "è"), ("í", "ì"), ("ó", "ò"), ("ú", "ù")):
        word = word.replace(a, b)
    chars = list(word)
    n = len(chars)
    res = list(chars)
    for i in range(n):
        c = chars[i]
        if c == "u" and i > 0 and chars[i - 1] == "q":
            res[i] = "U"
        elif c in "ui" and 0 < i < n - 1 and chars[i - 1] in _IT_V and chars[i + 1] in _IT_V:
            res[i] = c.upper()
    word = "".join(res)
    r1 = regions(word, _IT_V)
    r2 = regions(word, _IT_V, r1) if r1 < len(word) else len(word)
    rv = _rv_spanish_style(word, _IT_V)

    def ok(w, suffix, r):
        return len(w) - len(suffix) >= r

    # Step 0
    s = longest_suffix(word, _IT_PRON)
    if s and ok(word, s, rv):
        b = word[:-len(s)]
        for pre, rep in (("ando", ""), ("endo", ""), ("ar", "e"), ("er", "e"), ("ir", "e")):
            if b.endswith(pre) and len(b) - len(pre) >= rv:
                word = b + rep
                break
    # Step 1
    done = False
    stds = ("abilità", "icità", "ività", "ità", "atrice", "atrici", "azione", "azioni", "atore",
            "atori", "logia", "logie", "uzione", "uzioni", "usione", "usioni", "enza", "enze",
            "amente", "mente", "anza", "anze", "iche", "ichi", "ismo", "ismi", "abile", "abili",
            "ibile", "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "ico", "ici",
            "ica", "ice", "oso", "osi", "osa", "ose", "ivo", "ivi", "iva", "ive")
    s = longest_suffix(word, stds)
    if s:
        b = word[:-len(s)]
        if s in ("anza", "anze", "iche", "ichi", "ismo", "ismi", "abile", "abili", "ibile",
                 "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "ico", "ici", "ica",
                 "ice", "oso", "osi", "osa", "ose", "mente", "atrice", "atrici"):
            if ok(word, s, r2):
                word = b
                done = True
                if s in ("atrice", "atrici") and word.endswith("ic") and ok(word, "ic", r2):
                    word = word[:-2]
        elif s in ("azione", "azioni", "atore", "atori"):
            if ok(word, s, r2):
                word = b
                done = True
                if word.endswith("ic") and ok(word, "ic", r2):
                    word = word[:-2]
        elif s in ("logia", "logie"):
            if ok(word, s, r2):
                word = b + "log"
                done = True
        elif s in ("uzione", "uzioni", "usione", "usioni"):
            if ok(word, s, r2):
                word = b + "u"
                done = True
        elif s in ("enza", "enze"):
            if ok(word, s, r2):
                word = b + "ente"
                done = True
        elif s == "amente":
            if ok(word, s, r1):
                word = b
                done = True
                if word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and ok(word, "at", r2):
                        word = word[:-2]
                else:
                    t = longest_suffix(word, ("os", "ic", "abil"))
                    if t and ok(word, t, r2):
                        word = word[:-len(t)]
        elif s == "ità":
            if ok(word, s, r2):
                word = b
                done = True
                t = longest_suffix(word, ("abil", "ic", "iv"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("ivo", "ivi", "iva", "ive"):
            if ok(word, s, r2):
                word = b
                done = True
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
                    if word.endswith("ic") and ok(word, "ic", r2):
                        word = word[:-2]
    if not done:
        t = longest_suffix(word, _IT_VERB)
        if t and ok(word, t, rv):
            word = word[:-len(t)]
    # Step 3a
    t = longest_suffix(word, ("a", "e", "i", "o", "à", "è", "ì", "ò"))
    if t and ok(word, t, rv):
        word = word[:-1]
        if word.endswith("i") and len(word) - 1 >= rv:
            word = word[:-1]
    # Step 3b
    if word.endswith(("ch", "gh")) and len(word) - 2 >= rv:
        word = word[:-1]
    return word.replace("I", "i").replace("U", "u")
