"""Snowball stemmers: Romanian, Finnish, Hungarian, Arabic (compact renderings)."""
from lingora.stem._util import longest_suffix, regions

# --------------------------------------------------------------------- Romanian
_RO_V = "aeiouăâî"
_RO_STEP0 = {
    "ul": "", "ului": "", "aua": "a", "ea": "e", "ele": "e", "elor": "e", "ii": "i",
    "iua": "i", "iei": "i", "iile": "i", "iilor": "i", "ilor": "i", "ile": "i", "atei": "at",
    "ație": "ați", "ației": "ați", "aţie": "aţi", "aţiei": "aţi",
}
_RO_STEP1 = {}
for _s in ("abilitate", "abilitati", "abilități", "abilităţi"):
    _RO_STEP1[_s] = "abil"
for _s in ("ibilitate", "ibilități", "ibilităţi"):
    _RO_STEP1[_s] = "ibil"
for _s in ("ivitate", "ivitati", "ivități", "ivităţi"):
    _RO_STEP1[_s] = "iv"
for _s in ("icitate", "icitati", "icități", "icităţi", "icator", "icatori", "iciv", "iciva",
           "icive", "icivi", "icivă", "ical", "icala", "icale", "icali", "icală"):
    _RO_STEP1[_s] = "ic"
for _s in ("ativ", "ativa", "ative", "ativi", "ativă", "ațiune", "atoare", "ator", "atori",
           "ătoare", "ător", "ători", "aţiune"):
    _RO_STEP1[_s] = "at"
for _s in ("itiv", "itiva", "itive", "itivi", "itivă", "iţiune", "itoare", "itor", "itori",
           "ițiune"):
    _RO_STEP1[_s] = "it"
_RO_STEP2 = ("at", "ata", "ată", "ati", "ate", "ut", "uta", "ută", "uti", "ute", "it", "ita",
             "ită", "iti", "ite", "ic", "ica", "ice", "ici", "ică", "abil", "abila", "abile",
             "abili", "abilă", "ibil", "ibila", "ibile", "ibili", "ibilă", "oasa", "oasă",
             "oase", "os", "osi", "oși", "oşi", "ant", "anta", "ante", "anti", "antă", "anța",
             "anţa", "ante", "anțe", "anţe", "anți", "anţi", "ator", "atori", "itate", "itati",
             "ități", "ităţi", "iv", "iva", "ive", "ivi", "ivă")
_RO_ISM = ("ism", "isme", "ist", "ista", "iste", "isti", "istă", "iști", "işti")
_RO_VERB = (
    "seserăţi", "seserăți", "serăţi", "serăți", "aserăţi", "easca", "ează", "eaza", "esc",
    "eşte", "ește", "ească", "eau", "ia", "iau", "aţi", "ați", "eţi", "eți", "iţi", "iți",
    "ară", "ură", "ire", "are", "ere", "ând", "ând", "ind", "ând", "indu", "ând", "am",
    "ai", "a", "ează", "ează", "ez", "eze", "ezi", "ăm", "ăţi", "ăți", "ui", "ut", "ui",
    "asem", "isem", "usem", "ase", "ise", "use", "aseşi", "asei", "iseşi", "isei", "useşi",
    "usei", "ara", "ira", "ura", "ând", "ăm", "au", "ea", "ește", "eşte", "it", "ut", "at",
    "ând", "ind", "em", "im", "ăsem", "ește", "ește", "iră", "ură", "ară", "eră", "ește",
    "ește", "ește")


def stem_romanian(word):
    word = word.lower().replace("ş", "ș").replace("ţ", "ț")
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i] in "ui" and chars[i - 1] in _RO_V and chars[i + 1] in _RO_V:
            chars[i] = chars[i].upper()
    word = "".join(chars)
    r1 = regions(word, _RO_V)
    r2 = regions(word, _RO_V, r1) if r1 < len(word) else len(word)
    n = len(word)
    if n >= 2 and word[1] not in _RO_V:
        rv = next((i + 1 for i in range(2, n) if word[i] in _RO_V), n)
    elif n >= 2 and word[0] in _RO_V and word[1] in _RO_V:
        rv = next((i + 1 for i in range(2, n) if word[i] not in _RO_V), n)
    else:
        rv = min(3, n)
    norm = {k.replace("ş", "ș").replace("ţ", "ț"): v.replace("ş", "ș").replace("ţ", "ț")
            for k, v in _RO_STEP0.items()}
    s = longest_suffix(word, norm)
    if s:
        if s == "ile" and word[:-3].endswith("ab"):
            pass
        else:
            word = word[:-len(s)] + norm[s]
    step1 = {k.replace("ş", "ș").replace("ţ", "ț"): v for k, v in _RO_STEP1.items()}
    changed_any = False
    while True:
        s = longest_suffix(word, step1)
        if s and len(word) - len(s) >= r1:
            word = word[:-len(s)] + step1[s]
            changed_any = True
        else:
            break
    done2 = False
    sufs2 = tuple(x.replace("ş", "ș").replace("ţ", "ț") for x in _RO_STEP2)
    ism = tuple(x.replace("ş", "ș").replace("ţ", "ț") for x in _RO_ISM)
    s = longest_suffix(word, sufs2 + ism + ("iune", "iuni"))
    if s and len(word) - len(s) >= r2:
        if s in ism:
            word = word[:-len(s)] + "ist"
        elif s in ("iune", "iuni"):
            if word[:-len(s)].endswith("ț"):
                word = word[:-len(s)]
                done2 = True
        else:
            word = word[:-len(s)]
        done2 = True
    if not (changed_any or done2):
        vs = tuple(x.replace("ş", "ș").replace("ţ", "ț") for x in _RO_VERB)
        s = longest_suffix(word, vs)
        if s and len(word) - len(s) >= rv:
            word = word[:-len(s)]
    s = longest_suffix(word, ("ie", "a", "e", "i", "ă"))
    if s and len(word) - len(s) >= rv:
        word = word[:-len(s)]
    return word.replace("I", "i").replace("U", "u")


# ---------------------------------------------------------------------- Finnish
_FI_V = "aeiouyäö"
_FI_RV = "aeiouäö"
_FI_CONS = "bcdfghjklmnpqrstvwxz"
_FI_CASES = ("ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi", "tta",
             "ttä", "ine", "na", "nä", "a", "ä", "n", "han", "hen", "hin", "hon", "hän", "hön",
             "seen", "den", "tten", "ta", "tä", "ssa")


def stem_finnish(word):
    word = word.lower()
    r1 = regions(word, _FI_V)
    r2 = regions(word, _FI_V, r1) if r1 < len(word) else len(word)

    def inr(w, s, r):
        return len(w) - len(s) >= r

    # Step 1: particles
    s = longest_suffix(word, ("kaan", "kään", "sti", "kin", "han", "hän", "ko", "kö", "pa", "pä"))
    if s and inr(word, s, r1):
        if s == "sti":
            if inr(word, s, r2):
                word = word[:-3]
        elif len(word) > len(s) and word[-len(s) - 1] in "nt" + _FI_V:
            word = word[:-len(s)]
    # Step 2: possessives
    s = longest_suffix(word, ("nsa", "nsä", "mme", "nne", "si", "ni", "an", "än", "en"))
    if s and inr(word, s, r1):
        base = word[:-len(s)]
        if s == "si":
            if not base.endswith("k"):
                word = base
        elif s == "ni":
            word = base[:-3] + "ksi" if base.endswith("kse") else base
        elif s in ("nsa", "nsä", "mme", "nne"):
            word = base
        elif s in ("an", "än"):
            if base.endswith(("ta", "ssa", "sta", "lla", "lta", "na")) or \
                    base.endswith(("tä", "ssä", "stä", "llä", "ltä", "nä")):
                word = base
        elif s == "en":
            if base.endswith(("ta", "ssa", "sta", "lla", "lta", "na", "tä", "ssä", "stä", "llä",
                              "ltä", "nä")):
                word = base
    # Step 3: cases
    s = longest_suffix(word, ("sti", "hXn") + _FI_CASES + ("lla", "ssa"))
    if s and s != "sti" and inr(word, s, r1):
        base = word[:-len(s)]
        if s in ("han", "hen", "hin", "hon", "hän", "hön"):
            if base and base[-1] == s[1]:
                word = base
        elif s in ("seen",):
            word = base
        elif s in ("den", "tten"):
            if base.endswith("i"):
                word = base[:-1] if s == "den" else base
        elif s in ("a", "ä"):
            if base and base[-1] in _FI_V + "":
                word = base
            elif base[-1:] in _FI_CONS and False:
                word = base
        elif s == "n":
            if base and base[-1] in _FI_V:
                word = base
                if base.endswith(("ei", "ie") ) and False:
                    pass
        else:
            word = base
    # Step 4: other endings
    s = longest_suffix(word, ("impi", "impa", "impä", "immi", "imma", "immä", "mpi", "mpa",
                              "mpä", "mmi", "mma", "mmä", "eja", "ejä"))
    if s and inr(word, s, r2):
        word = word[:-len(s)]
    # Step 5: plurals
    if word.endswith("i") and inr(word, "i", r1) and len(word) > 1 and word[-2] in _FI_V:
        word = word[:-1]
    elif word.endswith("j") and inr(word, "j", r1):
        word = word[:-1]
    elif word.endswith("t") and inr(word, "t", r1):
        word = word[:-1]
    # Step 6: tidy
    if len(word) >= 2 and word[-1] == word[-2] and word[-1] in _FI_CONS and inr(word, "x", r1):
        word = word[:-1]
    elif len(word) >= 2 and word[-1] == word[-2] and word[-1] in _FI_RV and inr(word, "x", r1):
        word = word[:-1]
    if word.endswith(("a", "ä", "e", "i", "o", "u", "ö")) and inr(word, "a", r1) and False:
        word = word[:-1]
    return word


# -------------------------------------------------------------------- Hungarian
_HU_V = "aeiouáéíóöőúüű"
_HU_ENDINGS = (
    "kodásokkal", "ságokkal", "ségekkel", "okkal", "ekkel", "ökkel", "akkal", "ban", "ben",
    "ból", "ből", "ba", "be", "ra", "re", "nak", "nek", "val", "vel", "tól", "től", "ról",
    "ről", "hoz", "hez", "höz", "ért", "ig", "kor", "ul", "ül", "ként", "án", "én", "at", "et",
    "ot", "öt", "ak", "ek", "ok", "ök", "ük", "uk", "ja", "je", "ai", "ei", "ünk", "unk",
    "jai", "jei", "nk", "k", "t", "n")


def stem_hungarian(word):
    word = word.lower()
    n = len(word)
    # R1: after first consonant following a vowel (or after the first two letters if a
    # consonant-initial word starts with consonant + vowel)
    if n and word[0] in _HU_V:
        r1 = regions(word, _HU_V)
    else:
        r1 = next((i + 1 for i in range(1, n) if word[i] not in _HU_V), n)
        r1 = max(r1, 0)
        r1 = n if r1 > n else r1
        v = next((i for i in range(n) if word[i] in _HU_V), n)
        r1 = min(max(r1, v + 1), n) if v < n else n
    for _ in range(3):
        s = longest_suffix(word, _HU_ENDINGS)
        if s and len(word) - len(s) >= max(r1, 1) and len(word) - len(s) >= 2:
            word = word[:-len(s)]
        else:
            break
    if word and word[-1] in "áé":
        word = word[:-1] + {"á": "a", "é": "e"}[word[-1]]
    return word


# ----------------------------------------------------------------------- Arabic
_AR_PREFIXES = ("وال", "بال", "كال", "فال", "لل", "ال", "و")
_AR_SUFFIXES = ("ات", "ان", "ين", "ون", "ها", "ية", "ة", "ي", "ه", "ا")
_AR_DIACRITICS = "".join(chr(c) for c in range(0x064B, 0x0653)) + "ـ"


def stem_arabic(word):
    for d in _AR_DIACRITICS:
        word = word.replace(d, "")
    word = word.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    for p in _AR_PREFIXES:
        if word.startswith(p) and len(word) - len(p) >= 3:
            word = word[len(p):]
            break
    s = longest_suffix(word, _AR_SUFFIXES)
    if s and len(word) - len(s) >= 3:
        word = word[:-len(s)]
    return word
