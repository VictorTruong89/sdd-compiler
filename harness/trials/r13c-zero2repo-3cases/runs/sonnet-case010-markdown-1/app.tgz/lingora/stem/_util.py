def regions(word, vowels, start=0):
    """Index of the first letter after the first non-vowel that follows a vowel,
    searching from ``start``; len(word) when there is none."""
    for i in range(start + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            return i + 1
    return len(word)


def longest_suffix(word, suffixes):
    """Longest suffix from ``suffixes`` the word ends with, or None."""
    best = None
    for s in suffixes:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best
