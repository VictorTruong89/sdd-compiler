from lingora.stem._util import longest_suffix, regions

_VOWELS = "aeiouy"
_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_LI_END = "cdeghkmnrt"

_SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_EXCEPTION2 = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")

_STEP0 = ("'s'", "'s", "'")
_STEP1A = ("sses", "ied", "ies", "us", "ss", "s")
_STEP1B = ("eedly", "ingly", "edly", "eed", "ing", "ed")
_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "fulli": "ful", "lessli": "less", "ogi": "og", "li": "",
}
_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
    "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ism", "ate", "iti", "ous", "ive", "ize", "ion")


def _short_syllable(w):
    n = len(w)
    if n >= 3 and w[-1] not in _VOWELS and w[-1] not in "wxY" and w[-2] in _VOWELS \
            and w[-3] not in _VOWELS:
        return True
    if n == 2 and w[0] in _VOWELS and w[1] not in _VOWELS:
        return True
    return False


def stem_english(word):
    word = word.lower()
    if len(word) <= 2:
        return word
    if word in _SPECIAL:
        return _SPECIAL[word]
    word = word.replace("’", "'").replace("‘", "'").replace("‛", "'")
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(chars)):
        if chars[i - 1] in _VOWELS and chars[i] == "y":
            chars[i] = "Y"
    word = "".join(chars)

    if word.startswith(("gener", "arsen")):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1 = regions(word, _VOWELS)
    r2 = regions(word, _VOWELS, r1) if r1 < len(word) else len(word)

    def in_r1(suffix):
        return len(word) - len(suffix) >= r1

    def in_r2(suffix):
        return len(word) - len(suffix) >= r2

    # Step 0
    s = longest_suffix(word, _STEP0)
    if s:
        word = word[:-len(s)]

    # Step 1a
    s = longest_suffix(word, _STEP1A)
    if s == "sses":
        word = word[:-2]
    elif s in ("ied", "ies"):
        if len(word) - len(s) > 1:
            word = word[:-2]
        else:
            word = word[:-1]
    elif s == "s":
        if any(c in _VOWELS for c in word[:-2]):
            word = word[:-1]

    if word in _EXCEPTION2:
        return word

    # Step 1b
    s = longest_suffix(word, _STEP1B)
    if s in ("eed", "eedly"):
        if in_r1(s):
            word = word[:-len(s)] + "ee"
    elif s:
        base = word[:-len(s)]
        if any(c in _VOWELS for c in base):
            word = base
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif word.endswith(_DOUBLES):
                word = word[:-1]
            elif r1 >= len(word) and _short_syllable(word):
                word += "e"

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _VOWELS:
        word = word[:-1] + "i"

    # Step 2
    s = longest_suffix(word, _STEP2)
    if s and in_r1(s):
        rep = _STEP2[s]
        if s == "ogi":
            if len(word) >= 4 and word[-4] == "l":
                word = word[:-len(s)] + rep
        elif s == "li":
            if len(word) >= 3 and word[-3] in _LI_END:
                word = word[:-2]
        else:
            word = word[:-len(s)] + rep

    # Step 3
    s = longest_suffix(word, _STEP3)
    if s and in_r1(s):
        if s == "ative":
            if in_r2(s):
                word = word[:-len(s)]
        else:
            word = word[:-len(s)] + _STEP3[s]

    # Step 4
    s = longest_suffix(word, _STEP4)
    if s and in_r2(s):
        if s == "ion":
            if len(word) >= 4 and word[-4] in "st":
                word = word[:-3]
        else:
            word = word[:-len(s)]

    # Step 5
    if word.endswith("e"):
        if in_r2("e") or (in_r1("e") and not _short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if in_r2("l") and len(word) >= 2 and word[-2] == "l":
            word = word[:-1]

    return word.replace("Y", "y")
