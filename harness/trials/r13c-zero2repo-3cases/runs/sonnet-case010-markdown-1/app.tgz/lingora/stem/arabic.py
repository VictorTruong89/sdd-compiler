from lingora.stem.snowball_other import stem_arabic

_PREFIXES3 = ("وال", "بال", "كال", "فال", "ولل")
_PREFIXES2 = ("ال", "لل")
_SUFFIXES = ("هما", "كما", "ات", "ان", "ين", "ون", "ها", "هم", "كم", "نا", "ية", "ة", "ي", "ه", "ا")
_DIACRITICS = "".join(chr(c) for c in range(0x064B, 0x0653))


class ARLSTem:
    """Light Arabic stemmer (prefix and suffix stripping)."""

    def __init__(self):
        pass

    def stem(self, word):
        for d in _DIACRITICS + "ـ":
            word = word.replace(d, "")
        word = word.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        for p in _PREFIXES3 + _PREFIXES2:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in _SUFFIXES:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[:-len(s)]
                break
        return word


class ARLSTem2(ARLSTem):
    """Second-generation light Arabic stemmer."""

    def stem(self, word):
        return ARLSTem.stem(self, word)


class ISRIStemmer(ARLSTem):
    pass
