"""Stemmers."""
from lingora.stem.porter import PorterStemmer
from lingora.stem.lancaster import LancasterStemmer
from lingora.stem.regexp import RegexpStemmer
from lingora.stem.snowball import SnowballStemmer
from lingora.stem.arabic import ARLSTem, ARLSTem2, ISRIStemmer
from lingora.stem.wordnet import WordNetLemmatizer

__all__ = ["ARLSTem", "ARLSTem2", "ISRIStemmer", "LancasterStemmer", "PorterStemmer",
           "RegexpStemmer", "SnowballStemmer", "WordNetLemmatizer"]
