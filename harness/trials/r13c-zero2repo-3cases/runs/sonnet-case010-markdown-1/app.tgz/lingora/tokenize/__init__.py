"""Tokenizers."""
from lingora.tokenize.api import TokenizerI
from lingora.tokenize.regexp import (
    BlanklineTokenizer, RegexpTokenizer, WhitespaceTokenizer, WordPunctTokenizer,
    blankline_tokenize, regexp_tokenize, wordpunct_tokenize)
from lingora.tokenize.treebank import NLTKWordTokenizer, TreebankWordTokenizer
from lingora.tokenize.casual import TweetTokenizer
from lingora.tokenize.punkt import PunktSentenceTokenizer, sent_tokenize

_treebank_word_tokenizer = NLTKWordTokenizer()


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("word_tokenize expects a string")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [token for sent in sentences for token in _treebank_word_tokenizer.tokenize(sent)]


__all__ = [
    "TokenizerI", "RegexpTokenizer", "WhitespaceTokenizer", "WordPunctTokenizer",
    "BlanklineTokenizer", "TreebankWordTokenizer", "NLTKWordTokenizer", "TweetTokenizer",
    "PunktSentenceTokenizer", "blankline_tokenize", "regexp_tokenize", "sent_tokenize",
    "word_tokenize", "wordpunct_tokenize",
]
