import html
import re
import sys

from lingora.tokenize.api import TokenizerI

EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]                     # eyes
      [\-o\*\']?                 # optional nose
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      [\-o\*\']?                 # optional nose
      [:;=8]                     # eyes
      [<>]?
      |
      </?3                       # heart
    )"""

URLS = r"""			# Capture 1: entire matched URL
  (?:
  https?:				# URL protocol and colon
    (?:
      /{1,3}				# 1-3 slashes
      |					#   or
      [a-z0-9%]				# Single letter or digit or '%'
    )
    |					#   or
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:					# One or more:
    [^\s()<>{}\[\]]+			# Run of non-space, non-()<>{}[]
    |					#   or
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\) # balanced parens, one level deep: (...(...)...)
    |
    \([^\s]+?\)				# balanced parens, non-recursive: (...)
  )+
  (?:					# End with:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)	# balanced parens, one level deep: (...(...)...)
    |
    \([^\s]+?\)				# balanced parens, non-recursive: (...)
    |					#   or
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]	# not a space or one of these punct chars
  )
  |					# OR, the following to match naked domains:
  (?:
    (?<!@)			        # not preceded by a @, avoid matching foo@_gmail.com_
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)			        # not succeeded by a @,
  )
"""

PHONE_REGEX = r"""
    (?:
      (?:            # (international)
        \+?[01]
        [ *\-.\)]*
      )?
      (?:            # (area code)
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}          # exchange
      [ *\-.\)]*
      \d{4}          # base
    )"""

REGEXPS = (
    URLS,
    PHONE_REGEX,
    EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_]) # Words with apostrophes or dashes.
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)  # Numbers, including fractions, decimals.
    |
    (?:[\w_]+)                     # Words without apostrophes or dashes.
    |
    (?:\.(?:\s*\.){1,})            # Ellipsis dots.
    |
    (?:\S)                         # Everything else that isn't whitespace.
    """,
)

WORD_RE = re.compile("(%s)" % "|".join(REGEXPS), re.VERBOSE | re.I | re.UNICODE)
EMOTICON_RE = re.compile(EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_LENGTHENING_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_ENTITY_RE = re.compile(r"&(#?(x?))([^&;\s]+);")


def _replace_html_entities(text):
    def convert(m):
        match = m.group(0)
        if m.group(1):
            try:
                if m.group(2):
                    number = int(m.group(3), 16)
                else:
                    number = int(m.group(3), 10)
                if 128 <= number <= 159:
                    return bytes((number,)).decode("cp1252")
                return chr(number)
            except (ValueError, OverflowError, UnicodeDecodeError):
                return ""
        out = html.unescape(match)
        return out

    return _ENTITY_RE.sub(convert, text)


class TweetTokenizer(TokenizerI):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = _replace_html_entities(text)
        if self.strip_handles:
            text = HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTHENING_RE.sub(r"\1\1\1", text)
        safe_text = HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in WORD_RE.finditer(safe_text)]
        if not self.preserve_case:
            words = [w if EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
