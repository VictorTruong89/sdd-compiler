import re

from lingora.tokenize.api import TokenizerI


class TreebankWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r"(?i)\b(can)(?#X)(not)\b"),
                     re.compile(r"(?i)\b(d)(?#X)('ye)\b"),
                     re.compile(r"(?i)\b(gim)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(gon)(?#X)(na)\b"),
                     re.compile(r"(?i)\b(got)(?#X)(ta)\b"),
                     re.compile(r"(?i)\b(lem)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(more)(?#X)('n)\b"),
                     re.compile(r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r"(?i) ('t)(?#X)(is)\b"),
                     re.compile(r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        regexp, sub = self.PARENS_BRACKETS
        text = regexp.sub(sub, text)
        regexp, sub = self.DOUBLE_DASHES
        text = regexp.sub(sub, text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        raw = self.tokenize(text)
        pos = 0
        for tok in raw:
            if tok in ("``", "''"):
                candidates = ['"', tok]
                best = None
                for c in candidates:
                    i = text.find(c, pos)
                    if i >= 0 and (best is None or i < best[0]):
                        best = (i, c)
                if best is None:
                    raise ValueError("Could not align token %r" % tok)
                i, c = best
                yield (i, i + len(c))
                pos = i + len(c)
                continue
            i = text.find(tok, pos)
            if i < 0:
                raise ValueError("Could not align token %r" % tok)
            yield (i, i + len(tok))
            pos = i + len(tok)


class NLTKWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    CONTRACTIONS2 = TreebankWordTokenizer.CONTRACTIONS2
    CONTRACTIONS3 = TreebankWordTokenizer.CONTRACTIONS3
    DASHES = (re.compile("[‒-―]"), r" \g<0> ")

    def tokenize(self, text):
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        regexp, sub = self.PARENS_BRACKETS
        text = regexp.sub(sub, text)
        regexp, sub = self.DOUBLE_DASHES
        text = regexp.sub(sub, text)
        regexp, sub = self.DASHES
        text = regexp.sub(sub, text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()

    span_tokenize = TreebankWordTokenizer.span_tokenize
