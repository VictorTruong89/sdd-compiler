class TokenizerI:
    def tokenize(self, s):
        raise NotImplementedError

    def span_tokenize(self, s):
        raise NotImplementedError

    def tokenize_sents(self, strings):
        return [self.tokenize(s) for s in strings]
