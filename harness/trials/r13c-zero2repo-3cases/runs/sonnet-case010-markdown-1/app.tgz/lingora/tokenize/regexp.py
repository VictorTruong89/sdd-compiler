import re

from lingora.tokenize.api import TokenizerI


class RegexpTokenizer(TokenizerI):
    def __init__(self, pattern, gaps=False, discard_empty=True,
                 flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        pattern = getattr(pattern, "pattern", pattern)
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [tok for tok in self._regexp.split(text) if tok]
            return self._regexp.split(text)
        return self._regexp.findall(text)

    def span_tokenize(self, text):
        if self._gaps:
            left = 0
            spans = []
            for m in self._regexp.finditer(text):
                right, nxt = m.span()
                spans.append((left, right))
                left = nxt
            spans.append((left, len(text)))
            for s in spans:
                if self._discard_empty and s[0] == s[1]:
                    continue
                yield s
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r, flags=%r)" % (
            self.__class__.__name__, self._pattern, self._gaps, self._discard_empty, self._flags)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


def regexp_tokenize(text, pattern, gaps=False, discard_empty=True,
                    flags=re.UNICODE | re.MULTILINE | re.DOTALL):
    return RegexpTokenizer(pattern, gaps, discard_empty, flags).tokenize(text)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)
