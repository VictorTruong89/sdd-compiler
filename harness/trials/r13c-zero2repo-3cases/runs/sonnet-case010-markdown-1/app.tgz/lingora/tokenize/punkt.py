"""Punkt sentence tokenizer (Kiss & Strunk, 2006) using packaged parameters."""
import os
import re

from lingora import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

_RE_NON_WORD = r"(?:[)\";}\]\*:@\'\({\[])"
_RE_MULTI_CHAR_PUNCT = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_RE_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"

_WORD_TOKENIZE_RE = re.compile(
    r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?  # Accept word characters until end is found
        (?= # Sequences marking a word's end
            \s|                                 # White-space
            $|                                  # End-of-string
            %(NonWord)s|%(MultiChar)s|          # Punctuation
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s) # Comma if at end of word
        )
        |
        \S
    )""" % {"NonWord": _RE_NON_WORD, "MultiChar": _RE_MULTI_CHAR_PUNCT, "WordStart": _RE_WORD_START},
    re.UNICODE | re.VERBOSE)

_PERIOD_CONTEXT_RE = re.compile(
    r"""
        [.?!]                        # a potential sentence ending
        (?=(?P<after_tok>
            %(NonWord)s              # either other punctuation
            |
            \s+(?P<next_tok>\S+)     # or whitespace and some other token
        ))""" % {"NonWord": _RE_NON_WORD},
    re.UNICODE | re.VERBOSE)

_BOUNDARY_REALIGNMENT_RE = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"^\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$")
_RE_ALPHA = re.compile(r"^[^\W\d]+$")
_RE_NON_PUNCT = re.compile(r"[^\W\d]")

_PUNCTUATION = tuple(";:,.!?")
_SENT_END_CHARS = (".", "?", "!")


class _Params:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


class _Token:
    __slots__ = ("tok", "type", "period_final", "parastart", "linestart",
                 "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        if self.sentbreak:
            return self.type_no_period
        return self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


def _load_params(language):
    base = data.find("tokenizers/punkt_tab/%s" % language)
    params = _Params()
    for line in data.read_lines(os.path.join(base, "abbrev_types.txt")):
        if line != "":
            params.abbrev_types.add(line)
    for line in data.read_lines(os.path.join(base, "sent_starters.txt")):
        if line != "":
            params.sent_starters.add(line)
    for line in data.read_lines(os.path.join(base, "collocations.tab")):
        if line == "":
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            params.collocations.add((parts[0], parts[1]))
    for line in data.read_lines(os.path.join(base, "ortho_context.tab")):
        if line == "":
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            params.ortho_context[parts[0]] = int(parts[1])
    return params


class PunktSentenceTokenizer:
    def __init__(self, language="english", params=None):
        if params is None:
            params = _load_params(language)
        self._params = params

    # -- word-level annotation ------------------------------------------
    @staticmethod
    def _tokenize_words(plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                line_toks = iter(_WORD_TOKENIZE_RE.findall(line))
                try:
                    tok = next(line_toks)
                except StopIteration:
                    continue
                yield _Token(tok, parastart=parastart, linestart=True)
                parastart = False
                for tok in line_toks:
                    yield _Token(tok)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in _SENT_END_CHARS:
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            if (t[:-1].lower() in self._params.abbrev_types
                    or t[:-1].lower().split("-")[-1] in self._params.abbrev_types):
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho_heuristic(self, tok):
        if tok.tok in _PUNCTUATION:
            return False
        ctx = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, tok1, tok2):
        if tok2 is None:
            return
        if not tok1.period_final:
            return
        typ = tok1.type_no_period
        next_typ = tok2.type_no_sentperiod
        tok_is_initial = tok1.is_initial

        if (typ, next_typ) in self._params.collocations:
            tok1.sentbreak = False
            tok1.abbr = True
            return

        if (tok1.abbr or tok1.ellipsis) and not tok_is_initial:
            is_sent_starter = self._ortho_heuristic(tok2)
            if is_sent_starter is True:
                tok1.sentbreak = True
                return
            if tok2.first_upper and next_typ in self._params.sent_starters:
                tok1.sentbreak = True
                return

        if tok_is_initial or typ == "##number##":
            is_sent_starter = self._ortho_heuristic(tok2)
            if is_sent_starter is False:
                tok1.sentbreak = False
                tok1.abbr = True
                return
            if (is_sent_starter == "unknown" and tok_is_initial and tok2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                tok1.sentbreak = False
                tok1.abbr = True
                return

    def _annotate_tokens(self, tokens):
        tokens = list(tokens)
        for t in tokens:
            self._first_pass(t)
        for i, t in enumerate(tokens):
            nxt = tokens[i + 1] if i + 1 < len(tokens) else None
            self._second_pass(t, nxt)
        return tokens

    def text_contains_sentbreak(self, text):
        found = False
        for tok in self._annotate_tokens(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    # -- sentence-level -------------------------------------------------
    @staticmethod
    def _last_whitespace_index(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i].isspace():
                return i
        return 0

    def _match_potential_end_contexts(self, text):
        previous_slice = slice(0, 0)
        previous_match = None
        for match in _PERIOD_CONTEXT_RE.finditer(text):
            before_text = text[previous_slice.stop:match.start()]
            index_after_last_space = self._last_whitespace_index(before_text)
            if index_after_last_space:
                index_after_last_space += previous_slice.stop + 1
            else:
                index_after_last_space = previous_slice.start
            prev_word_slice = slice(index_after_last_space, match.start())
            if previous_match and previous_slice.stop <= prev_word_slice.start:
                yield (previous_match, text[previous_slice] + previous_match.group()
                       + previous_match.group("after_tok"))
            previous_match = match
            previous_slice = prev_word_slice
        if previous_match:
            yield (previous_match, text[previous_slice] + previous_match.group()
                   + previous_match.group("after_tok"))

    def _slices_from_text(self, text):
        last_break = 0
        for match, context in self._match_potential_end_contexts(text):
            if self.text_contains_sentbreak(context):
                yield slice(last_break, match.end())
                if match.group("next_tok"):
                    last_break = match.start("next_tok")
                else:
                    last_break = match.end()
        yield slice(last_break, len(text.rstrip()))

    def _realign_boundaries(self, text, slices):
        realign = 0
        slices = list(slices)
        for idx, sentence1 in enumerate(slices):
            sentence2 = slices[idx + 1] if idx + 1 < len(slices) else None
            sentence1 = slice(sentence1.start + realign, sentence1.stop)
            if sentence2 is None:
                if text[sentence1]:
                    yield sentence1
                continue
            m = _BOUNDARY_REALIGNMENT_RE.match(text[sentence2])
            if m:
                yield slice(sentence1.start, sentence2.start + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[sentence1]:
                    yield sentence1

    def span_tokenize(self, text, realign_boundaries=True):
        slices = self._slices_from_text(text)
        if realign_boundaries:
            slices = self._realign_boundaries(text, slices)
        for sl in slices:
            yield (sl.start, sl.stop)

    def tokenize(self, text, realign_boundaries=True):
        return [text[s:e] for s, e in self.span_tokenize(text, realign_boundaries)]


_cache = {}


def _get_tokenizer(language):
    base = data.find("tokenizers/punkt_tab/%s" % language)
    files = [os.path.join(base, n) for n in
             ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")]
    key = (base, tuple(os.stat(f).st_mtime_ns for f in files))
    cached = _cache.get(language)
    if cached and cached[0] == key:
        return cached[1]
    tok = PunktSentenceTokenizer(language)
    _cache[language] = (key, tok)
    return tok


def sent_tokenize(text, language="english"):
    if not isinstance(text, str):
        raise TypeError("sent_tokenize expects a string")
    return _get_tokenizer(language).tokenize(text)
