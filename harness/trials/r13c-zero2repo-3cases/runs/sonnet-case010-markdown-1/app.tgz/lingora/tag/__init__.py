"""Part-of-speech taggers."""
from lingora.tag.sequential import (
    AffixTagger, BigramTagger, DefaultTagger, RegexpTagger, SequentialBackoffTagger,
    TaggerI, TrigramTagger, UnigramTagger)
from lingora.tag.perceptron import PerceptronTagger, pos_tag, pos_tag_sents

__all__ = ["AffixTagger", "BigramTagger", "DefaultTagger", "RegexpTagger",
           "SequentialBackoffTagger", "TaggerI", "TrigramTagger", "UnigramTagger",
           "PerceptronTagger", "pos_tag", "pos_tag_sents"]
