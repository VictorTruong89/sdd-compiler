"""Greedy averaged perceptron tagger (after textblob-aptagger)."""
import json
import os
from collections import defaultdict

from lingora import data

_cache = {}

START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]


def _load(lang):
    base = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    stem = os.path.join(base, "averaged_perceptron_tagger_%s" % lang)
    files = [stem + ".weights.json", stem + ".tagdict.json", stem + ".classes.json"]
    key = (base, tuple(os.stat(f).st_mtime_ns for f in files))
    cached = _cache.get(lang)
    if cached and cached[0] == key:
        return cached[1]
    loaded = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            loaded.append(json.load(fh))
    tagger = PerceptronTagger(*loaded)
    _cache[lang] = (key, tagger)
    return tagger


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = set(classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _get_features(self, i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = START
        output = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._get_features(i, word, context, prev, prev2)
                tag = self.predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_RNC_TO_UNIVERSAL = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ",
    "CONJ": "CONJ", "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT",
    "PART": "PRT", "PR": "ADP", "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON",
    "S": "NOUN", "S-PRO": "PRON", "V": "VERB",
}


def _penn_to_universal(tagmap, tag):
    return tagmap.get(tag, "X")


def _load_ptb_map():
    base = data.find("taggers/universal_tagset")
    mapping = {}
    for line in data.read_lines(os.path.join(base, "en-ptb.map")):
        parts = line.split("\t")
        if len(parts) >= 2:
            mapping[parts[0]] = parts[1].strip()
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, LINGORA pos_tag only supports English and Russian "
                                  "(i.e. lang='eng' or lang='rus')")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("tokens must be strings")
    tagger = _load(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_ptb_map()
            tagged = [(w, None if t is None else _penn_to_universal(mapping, t)) for w, t in tagged]
        else:
            tagged = [(w, None if t is None else _RNC_TO_UNIVERSAL.get(t.partition("=")[0], "X"))
                      for w, t in tagged]
    return [tuple(x) for x in tagged]


def pos_tag_sents(sentences, tagset=None, lang="eng"):
    return [pos_tag(s, tagset, lang) for s in sentences]
