import re
from collections import Counter


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self] + (backoff._taggers if backoff is not None else [])

    @property
    def backoff(self):
        return self._taggers[1] if len(self._taggers) > 1 else None

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings, not a string")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(regexp), tag) for regexp, tag in regexps]

    def choose_tag(self, tokens, index, history):
        for regexp, tag in self._regexps:
            if re.match(regexp, tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = context_to_tag if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        context = self.context(tokens, index, history)
        return self._context_to_tag.get(context)

    def _train(self, tagged_corpus, cutoff=0):
        token_count = hit_count = 0
        fd = {}
        for sentence in tagged_corpus:
            tokens, tags = zip(*sentence) if sentence else ((), ())
            for index, (token, tag) in enumerate(sentence):
                context = self.context(tokens, index, tags[:index])
                if context is None:
                    continue
                fd.setdefault(context, Counter())[tag] += 1
        useful = {}
        for context, counter in fd.items():
            tag, count = counter.most_common(1)[0]
            if count > cutoff:
                useful[context] = tag
        if self.backoff is not None:
            # drop contexts the backoff tagger already handles identically
            pass
        self._context_to_tag = useful


class NgramTagger(ContextTagger):
    def __init__(self, n, train=None, model=None, backoff=None, cutoff=0):
        self._n = n
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        tag_context = tuple(history[max(0, index - self._n + 1):index])
        return tag_context, tokens[index]


class UnigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 1, train, model, backoff, cutoff)

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 2, train, model, backoff, cutoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 3, train, model, backoff, cutoff)


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2,
                 backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]
