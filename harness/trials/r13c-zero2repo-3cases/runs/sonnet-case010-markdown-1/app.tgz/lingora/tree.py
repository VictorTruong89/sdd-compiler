"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, str):
            raise TypeError("Tree children must be a list of children, not %r" % (children,))
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def height(self):
        h = 0
        for child in self:
            h = max(h, child.height() if isinstance(child, Tree) else 1)
        return h + 1

    def copy(self, deep=False):
        import copy as _copy
        return _copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    # ------------------------------------------------------------------
    @staticmethod
    def _leaf_str(leaf):
        if isinstance(leaf, tuple) and len(leaf) == 2:
            return "%s/%s" % (leaf[0], leaf[1])
        return str(leaf)

    def _flat(self):
        parts = []
        for child in self:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(Tree._leaf_str(child))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts)) if parts else "(%s)" % (self._label,)

    def pformat(self, margin=70, indent=0):
        flat = self._flat()
        if len(flat) + indent <= margin:
            return flat
        s = "(%s" % (self._label,)
        for child in self:
            s += "\n" + " " * (indent + 2)
            if isinstance(child, Tree):
                s += child.pformat(margin, indent + 2)
            else:
                s += Tree._leaf_str(child)
        return s + ")"

    def pprint(self, **kwargs):
        print(self.pformat(**kwargs))

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        tok_re = re.compile(r"[%s]|[^\s%s]+" % (re.escape(open_b + close_b), re.escape(open_b + close_b)))
        tokens = tok_re.findall(s)
        pos = 0
        n = len(tokens)

        def parse_node():
            nonlocal pos
            # tokens[pos] is an open bracket
            pos += 1
            label = ""
            if pos < n and tokens[pos] not in (open_b, close_b):
                label = tokens[pos]
                pos += 1
            children = []
            while True:
                if pos >= n:
                    raise ValueError("Tree.fromstring: expected %r" % close_b)
                t = tokens[pos]
                if t == close_b:
                    pos += 1
                    return cls(label, children)
                if t == open_b:
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos += 1

        if not tokens:
            raise ValueError("Tree.fromstring: empty input")
        if tokens[0] != open_b:
            raise ValueError("Tree.fromstring: expected %r" % open_b)
        tree = parse_node()
        if pos != n:
            raise ValueError("Tree.fromstring: unexpected text after tree")
        return tree
