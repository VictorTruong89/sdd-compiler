"""Shallow chunking."""
import os
import re

from lingora import data
from lingora.tree import Tree

_IN_CHUNK = r"(?=[^\{]*\})"
_IN_STRIP = r"(?=[^\}]*(\{|$))"


def tag_pattern2re_pattern(tag_pattern):
    tag_pattern = re.sub(r"\s", "", tag_pattern)
    tag_pattern = re.sub(r"<", "(?:<(?:", tag_pattern)
    tag_pattern = re.sub(r">", ")>)", tag_pattern)
    tag_pattern = re.sub(r"([^\\])\.", r"\1[^\\{\\}<>]", tag_pattern)
    tag_pattern = re.sub(r"^\.", r"[^\\{\\}<>]", tag_pattern)
    return tag_pattern


class _Rule:
    def __init__(self, kind, tag_pattern):
        self.kind = kind
        self.tag_pattern = tag_pattern
        try:
            body = tag_pattern2re_pattern(tag_pattern)
            if kind == "chunk":
                self._re = re.compile("(?P<chunk>" + body + ")" + _IN_STRIP)
            else:
                self._re = re.compile("(?P<chink>" + body + ")" + _IN_CHUNK)
        except re.error as e:
            raise ValueError("Bad tag pattern %r: %s" % (tag_pattern, e))

    def apply(self, s):
        if self.kind == "chunk":
            return self._re.sub(r"{\g<chunk>}", s)
        return self._re.sub(r"}\g<chink>{", s)


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def parse(self, root_label, children):
        # encode
        def code(item):
            if isinstance(item, Tree):
                return "<%s>" % item.label()
            return "<%s>" % (item[1],)

        s = "".join(code(c) for c in children)
        for rule in self.rules:
            s = rule.apply(s)
        # decode: walk braces and tag elements
        out = []
        cur = None
        idx = 0
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    out.append(Tree(self.label, cur))
                cur = None
            else:
                item = children[idx]
                idx += 1
                (out if cur is None else cur).append(item)
        if cur:
            out.append(Tree(self.label, cur))
        return out


class ChunkParserI:
    pass


class RegexpParser(ChunkParserI):
    def __init__(self, grammar, root_label="S", loop=1):
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, _Stage) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")
        self._root_label = root_label
        self._loop = loop

    @staticmethod
    def _parse_grammar(text):
        stages = []
        label = None
        rules = []

        def flush():
            if label is not None:
                stages.append(_Stage(label, rules))

        def add_rule(pat):
            pat = re.sub(r"\s+#.*$", "", pat).strip()
            if not pat:
                return
            if pat.startswith("{") and pat.endswith("}"):
                rules.append(_Rule("chunk", pat[1:-1]))
            elif pat.startswith("}") and pat.endswith("{"):
                rules.append(_Rule("chink", pat[1:-1]))
            else:
                raise ValueError("Illegal chunk pattern: %r" % pat)

        for line in text.split("\n"):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if not line[0].isspace():
                m = re.match(r"^([^:{}<>\s][^:]*?)\s*:\s*(.*)$", stripped)
                if not m:
                    raise ValueError("Illegal chunk grammar line: %r" % line)
                flush()
                label, rules = m.group(1), []
                add_rule(m.group(2))
            else:
                if label is None:
                    raise ValueError("Illegal chunk grammar line: %r" % line)
                add_rule(stripped)
        flush()
        return stages

    def parse(self, tagged, trace=0):
        children = []
        for tok in tagged:
            tok = tuple(tok)
            if len(tok) != 2:
                raise ValueError("expected (token, tag) pairs")
            children.append(tok)
        for _ in range(self._loop):
            for stage in self._stages:
                children = stage.parse(self._root_label, children)
        return Tree(self._root_label, children)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    children = []
    run = []
    label = "NE" if binary else "PERSON"

    def flush():
        if run:
            children.append(Tree(label, list(run)))
            run.clear()

    for tok in tagged_tokens:
        tok = tuple(tok)
        if tok[1] in ("NNP", "NNPS"):
            run.append(tok)
        else:
            flush()
            children.append(tok)
    flush()
    return Tree("S", children)


__all__ = ["RegexpParser", "ne_chunk"]
