"""Classifiers."""
import math
from collections import defaultdict

from lingora.classify.naivebayes import NaiveBayesClassifier, DictionaryProbDist
from lingora.classify.decisiontree import DecisionTreeClassifier
from lingora.classify.util import accuracy

ProbDist = DictionaryProbDist

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "ProbDist"]
