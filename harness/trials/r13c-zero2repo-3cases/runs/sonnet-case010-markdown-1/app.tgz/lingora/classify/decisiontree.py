import math
from collections import defaultdict


def _majority(labels):
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    best, bc = None, -1
    for l, c in counts.items():
        if c > bc:
            best, bc = l, c
    return best


def _entropy(labels):
    n = len(labels)
    if n == 0:
        return 0.0
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        labels = [self._label]
        if self._decisions is not None:
            for d in self._decisions.values():
                labels.extend(d.labels())
        if self._default is not None:
            labels.extend(self._default.labels())
        return list(set(labels))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = sum(1 for fs, label in labeled_featuresets if self.classify(fs) != label)
        return errors / len(labeled_featuresets)

    @staticmethod
    def leaf(labeled_featuresets):
        return DecisionTreeClassifier(_majority([l for _, l in labeled_featuresets]))

    @staticmethod
    def stump(feature_name, labeled_featuresets):
        label = _majority([l for _, l in labeled_featuresets])
        groups = {}
        for fs, l in labeled_featuresets:
            groups.setdefault(fs.get(feature_name), []).append(l)
        decisions = {v: DecisionTreeClassifier(_majority(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, feature_name, decisions)

    @staticmethod
    def best_stump(feature_names, labeled_featuresets):
        best = DecisionTreeClassifier.leaf(labeled_featuresets)
        best_error = best.error(labeled_featuresets)
        for fname in feature_names:
            stump = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = stump.error(labeled_featuresets)
            if err < best_error:
                best, best_error = stump, err
        return best

    def refine(self, training_data, entropy_cutoff, depth_cutoff):
        if len(training_data) == 0:
            raise ValueError("empty training data")
        if self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            data = [(fs, l) for fs, l in training_data if fs.get(self._fname) == fval]
            if _entropy([l for _, l in data]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    data, entropy_cutoff, depth_cutoff)
        if self._default is not None:
            data = [(fs, l) for fs, l in training_data if fs.get(self._fname) not in self._decisions]
            if data and _entropy([l for _, l in data]) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(data, entropy_cutoff, depth_cutoff)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, **kwargs):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for n in fs:
                if n not in seen:
                    seen.add(n)
                    names.append(n)
        tree = DecisionTreeClassifier.best_stump(names, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1)
        return tree
