import math
from collections import defaultdict


class DictionaryProbDist:
    def __init__(self, prob_dict, log=False, normalize=False):
        self._prob_dict = dict(prob_dict)
        self._log = log
        if normalize:
            if log:
                vals = list(self._prob_dict.values())
                m = max(vals) if vals else 0.0
                if m == -math.inf:
                    n = len(vals)
                    for k in self._prob_dict:
                        self._prob_dict[k] = -math.log(n)
                else:
                    total = m + math.log(sum(math.exp(v - m) for v in vals))
                    for k in self._prob_dict:
                        self._prob_dict[k] -= total
            else:
                total = sum(self._prob_dict.values())
                if total == 0:
                    for k in self._prob_dict:
                        self._prob_dict[k] = 1.0 / len(self._prob_dict)
                else:
                    for k in self._prob_dict:
                        self._prob_dict[k] /= total

    def prob(self, sample):
        if sample not in self._prob_dict:
            return 0.0
        v = self._prob_dict[sample]
        return float(math.exp(v)) if self._log else float(v)

    def logprob(self, sample):
        if sample not in self._prob_dict:
            return -math.inf
        v = self._prob_dict[sample]
        if self._log:
            return v
        return math.log(v) if v > 0 else -math.inf

    def max(self):
        return max(self._prob_dict, key=self._prob_dict.get)

    def samples(self):
        return self._prob_dict.keys()

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._prob_dict)


class _ELE:
    """Expected likelihood estimate over a frequency table."""

    def __init__(self, counts, bins=None):
        self._counts = counts
        self._n = sum(counts.values())
        self._bins = len(counts) if bins is None else bins

    def logprob(self, sample):
        c = self._counts.get(sample, 0)
        denom = self._n + 0.5 * self._bins
        return math.log((c + 0.5) / denom)


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist._counts)

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        for fname in list(featureset):
            for label in self._labels:
                if (label, fname) in self._feature_probdist:
                    break
            else:
                del featureset[fname]
        logprob = {}
        for label in self._labels:
            logprob[label] = self._label_probdist.logprob(label)
        for label in self._labels:
            for fname, fval in featureset.items():
                if (label, fname) in self._feature_probdist:
                    logprob[label] += self._feature_probdist[label, fname].logprob(fval)
                else:
                    logprob[label] += -math.inf
        return DictionaryProbDist(logprob, normalize=True, log=True)

    @staticmethod
    def train(labeled_featuresets):
        label_counts = {}
        feature_counts = defaultdict(dict)
        feature_values = defaultdict(set)
        fnames = set()
        for featureset, label in labeled_featuresets:
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, fval in featureset.items():
                d = feature_counts[label, fname]
                d[fval] = d.get(fval, 0) + 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label, num in label_counts.items():
            for fname in fnames:
                count = sum(feature_counts[label, fname].values()) if (label, fname) in feature_counts else 0
                if num - count > 0:
                    feature_counts[label, fname][None] = feature_counts[label, fname].get(None, 0) + num - count
                    feature_values[fname].add(None)
        label_probdist = _ELE(label_counts)
        feature_probdist = {}
        for (label, fname), counts in feature_counts.items():
            feature_probdist[label, fname] = _ELE(counts, bins=len(feature_values[fname]))
        return NaiveBayesClassifier(label_probdist, feature_probdist)
