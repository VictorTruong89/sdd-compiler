def accuracy(classifier, gold):
    if not gold:
        return 0
    correct = 0
    for featureset, label in gold:
        if classifier.classify(featureset) == label:
            correct += 1
    return correct / len(gold)
