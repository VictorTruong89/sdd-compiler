"""Sentence-level BLEU (Papineni et al., 2002)."""
import math
import sys
from collections import Counter


def _ngrams(seq, n):
    return zip(*[seq[i:] for i in range(n)])


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for reference in references:
        ref_counts = Counter(_ngrams(reference, n)) if len(reference) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), ref_counts[ng])
    clipped = {ng: min(c, max_counts[ng]) for ng, c in counts.items()}
    numerator = sum(clipped.values())
    denominator = max(1, sum(counts.values()))
    return numerator, denominator


def closest_ref_length(references, hyp_len):
    ref_lens = (len(r) for r in references)
    return min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))


def brevity_penalty(closest_ref_len, hyp_len):
    if hyp_len > closest_ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest_ref_len / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, references, hypothesis, hyp_len):
        return [p if p[0] != 0 else (sys.float_info.min, 1) for p in p_n]

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [((p[0] + self.epsilon), p[1]) if p[0] == 0 else p for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [(p[0] + 1, p[1] + 1) if i != 0 else p for i, p in enumerate(p_n)]


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    nums = []
    for i in range(1, len(weights) + 1):
        nums.append(modified_precision(references, hypothesis, i))
    if not nums or nums[0][0] == 0:
        return 0
    hyp_len = len(hypothesis)
    ref_len = closest_ref_length(references, hyp_len)
    bp = brevity_penalty(ref_len, hyp_len)
    p_n = list(nums)
    if smoothing_function is None:
        p_n = [p if p[0] != 0 else (sys.float_info.min, 1) for p in p_n]
    else:
        p_n = smoothing_function(p_n, references, hypothesis, hyp_len)
    probs = [p[0] / p[1] if isinstance(p, tuple) else float(p) for p in p_n]
    s = math.fsum(w * math.log(p) for w, p in zip(weights, probs) if w != 0 or True)
    return bp * math.exp(s)


sentence_bleu = bleu
