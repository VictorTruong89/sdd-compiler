"""Locating packaged resources (models, corpora)."""
import os
import sys

path = []


def _initial_path():
    out = []
    for d in os.environ.get("LINGORA_DATA", "").split(os.pathsep):
        if d:
            out.append(d)
    home = os.path.expanduser("~")
    for name in ("lingora_data", "nltk_data"):
        out.append(os.path.join(home, name))
    for root in ("/usr/share", "/usr/local/share", "/usr/lib", "/usr/local/lib"):
        out.append(os.path.join(root, "lingora_data"))
        out.append(os.path.join(root, "nltk_data"))
    out.append(os.path.join(sys.prefix, "nltk_data"))
    return out


path[:] = _initial_path()


def find(resource):
    """Return the filesystem path of ``resource`` (a '/'-separated name) found
    on ``path``; raise LookupError when no listed directory holds it."""
    parts = [p for p in resource.split("/") if p]
    for d in list(path):
        candidate = os.path.join(str(d), *parts)
        if os.path.exists(candidate):
            return candidate
    raise LookupError("Resource %r not found in data.path" % resource)


def read_text(filename):
    with open(filename, encoding="utf-8", newline="") as f:
        return f.read()


def read_lines(filename):
    """Lines of a text file without their terminators."""
    text = read_text(filename)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [ln[:-1] if ln.endswith("\r") else ln for ln in lines]
