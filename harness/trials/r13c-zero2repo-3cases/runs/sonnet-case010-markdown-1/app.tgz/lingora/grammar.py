"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    def __hash__(self):
        return hash(self._symbol)

    def __lt__(self, other):
        return str(self) < str(other)

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __truediv__(self, rhs):
        return Nonterminal("%s/%s" % (self._symbol, rhs))


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)
        self._hash = hash((self._lhs, self._rhs))

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return self._hash

    def __str__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


def _split_rhs(text):
    """Return a list of alternatives; each is a list of ('t', str)/('n', str)."""
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN_RE.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("Unable to parse grammar right-hand side: %r" % text)
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(("t", m.group(1)))
        elif m.group(2) is not None:
            alts[-1].append(("t", m.group(2)))
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(("n", m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)
        self._rhs_terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._rhs_terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._lhs_index.get(lhs, []))

    def terminals(self):
        return set(self._rhs_terminals)

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._rhs_terminals]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %s"
                             % ", ".join(repr(t) for t in missing))

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects a string")
        lines = input.split("\n")
        start = None
        productions = []
        current = None
        statements = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("%start"):
                start = Nonterminal(line.split(None, 1)[1].strip())
                continue
            if line.startswith("|") and statements:
                statements[-1] += " " + line
                continue
            statements.append(line)
        for st in statements:
            m = re.match(r"^\s*(\S+?)\s*(?:->|→|=>)\s*(.*)$", st)
            if not m:
                raise ValueError("Unable to parse production: %r" % st)
            lhs = Nonterminal(m.group(1))
            for alt in _split_rhs(m.group(2)):
                rhs = [s if k == "t" else Nonterminal(s) for k, s in alt]
                productions.append(Production(lhs, rhs))
        if start is None:
            if not productions:
                raise ValueError("No productions found")
            start = productions[0].lhs()
        return cls(start, productions)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join(
            "    %s" % p for p in self._productions)

    __repr__ = __str__


def nonterminals(symbols):
    names = symbols.replace(",", " ").split() if isinstance(symbols, str) else symbols
    res = [Nonterminal(s) for s in names]
    return res[0] if len(res) == 1 else tuple(res)
