"""Serialize-and-sign helpers: plain, timestamped, and URL-safe variants."""

from __future__ import annotations

import json
import zlib

from ._encoding import as_bytes, b64decode, b64encode, coerce_token, compress, decompress
from .exceptions import BadPayload, BadSignature, SignatureExpired
from .signer import DEFAULT_SALT, Signer, TimestampSigner


class _CompactJSON:
    """Default dump/load object for URL-safe tokens: JSON with no whitespace outside strings."""

    # spec: N-000371 N-000236 N-000066

    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(data):
        return json.loads(data)


class Serializer:
    """Serializes an object with a dump/load object and signs the result."""

    # spec: N-000350 N-000351 N-000354 N-000006 N-000145 N-000146 N-000150 N-000005 N-000147
    # spec: N-000148 N-000149 N-000151 N-000259 N-000014
    _default_serializer = json
    _default_signer = Signer

    def __init__(
        self,
        secret_key,
        salt=None,
        serializer=None,
        serializer_kwargs=None,
        signer=None,
        signer_kwargs=None,
        fallback_signers=None,
    ):
        self.secret_key = secret_key
        self.salt = DEFAULT_SALT if salt is None else as_bytes(salt)  # spec: N-000292 N-000293
        self.serializer = self._default_serializer if serializer is None else serializer
        self.serializer_kwargs = dict(serializer_kwargs or {})  # spec: N-000352 N-000163
        self.signer = self._default_signer if signer is None else signer  # spec: N-000353 N-000355
        self.signer_kwargs = dict(signer_kwargs or {})  # spec: N-000356
        self.fallbacks = [self._parse_fallback(item) for item in fallback_signers or []]  # spec: N-000357 N-000171
        self._text = self._is_text_serializer()  # spec: N-000156
        # spec: N-000358 — an illegal separator raises here, before any token is produced.
        self.make_signer()

    def _parse_fallback(self, item):
        # spec: N-000171 N-000172
        if isinstance(item, tuple):
            signer_cls, options = item
            return signer_cls, dict(options)
        if isinstance(item, type):
            return item, self.signer_kwargs
        return self.signer, dict(item)

    def _is_text_serializer(self) -> bool:
        # spec: N-000156 — text dump objects produce text tokens and load from text.
        try:
            return isinstance(self.serializer.dumps({}, **self.serializer_kwargs), str)
        except Exception:
            return False

    def make_signer(self, salt=None, signer_cls=None, options=None):
        """Build a signer of the configured type with this helper's secret."""
        # spec: N-000355 N-000160
        signer_cls = self.signer if signer_cls is None else signer_cls
        options = self.signer_kwargs if options is None else options
        salt = self.salt if salt is None else salt
        return signer_cls(self.secret_key, salt=salt, **options)

    def _signers(self, salt):
        # spec: N-000169 N-000170 N-000185 — the current configuration, then each fallback.
        signers = [self.make_signer(salt)]
        signers.extend(self.make_signer(salt, cls, options) for cls, options in self.fallbacks)
        return signers

    # Serialization of one object to its payload section.

    def _pack(self, obj):
        # spec: N-000152 N-000154 N-000155 N-000157 N-000350 N-000352 N-000163
        return self.serializer.dumps(obj, **self.serializer_kwargs)

    def _unpack_bytes(self, payload: bytes, sep: bytes) -> bytes:
        """Undo any transport encoding of the payload section (none for plain tokens)."""
        return payload

    def _deserialize(self, payload: bytes, sep: bytes):
        # spec: N-000182 N-000183 N-000249 N-000022 N-000379 N-000157
        try:
            data = self._unpack_bytes(payload, sep)
            if self._text:
                data = data.decode("utf-8")
            return self.serializer.loads(data)
        except BadPayload:
            raise
        except Exception as error:
            raise BadPayload("Payload could not be deserialized", original_error=error) from error

    # Verification across the configuration and its fallbacks.

    def _scan(self, token, salt, max_age):
        """Find the first configuration that verifies the token.

        Returns ``(signer, verified, payload, signed_at, error)``. ``error`` is set when the
        token is refused. A verified configuration whose time check fails ends the search
        (``verified`` is True); otherwise the primary configuration's refusal is reported.
        """
        # spec: N-000169 N-000215 N-000216 N-000185
        token = coerce_token(token)
        first = None
        for signer in self._signers(salt):
            try:
                signed, verified = signer._verify(token)
            except BadSignature as error:
                first = first or (signer, False, error)
                continue
            if not verified:
                first = first or (signer, False, signer._mismatch(signed))
                continue
            try:
                payload, signed_at = signer._accept(signed, max_age)
            except BadSignature as error:
                return signer, True, error.payload, None, error
            return signer, True, payload, signed_at, None
        signer, _, error = first
        return signer, False, error.payload, None, error

    def _load(self, token, salt=None, max_age=None):
        # spec: N-000361 N-000367 N-000373 N-000057 N-000153
        signer, _, payload, signed_at, error = self._scan(token, salt, max_age)
        if error is not None:
            raise error
        return self._deserialize(payload, signer.sep), signed_at

    def _load_unsafe(self, token, salt=None, max_age=None):
        # spec: N-000176 N-000177 N-000178 N-000179 N-000180 N-000214 N-000020 N-000034 N-000035
        signer, verified, payload, _, error = self._scan(token, salt, max_age)
        if verified:
            if error is None or isinstance(error, SignatureExpired):
                return error is None, self._deserialize(payload, signer.sep)
            raise error  # missing or malformed timestamp on a verified signature
        if payload is None:
            return False, None
        try:
            return False, self._deserialize(payload, signer.sep)
        except BadPayload:
            return False, None

    # Public surface.

    def dumps(self, obj, salt=None):
        """Return the signed token for ``obj``; text when the dump object produces text."""
        # spec: N-000359 N-000313 N-000317 N-000318 N-000156
        raw = self._pack(obj)
        token = self.make_signer(salt).sign(as_bytes(raw))
        return token.decode("utf-8") if isinstance(raw, str) else token

    def dump(self, obj, f, salt=None):
        """Write the token for ``obj`` to ``f`` (text stream for text tokens, binary otherwise)."""
        # spec: N-000360 N-000158 N-000033 N-000366 N-000367
        f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        """Verify and deserialize a token."""
        # spec: N-000361 N-000181 N-000184
        obj, _ = self._load(s, salt=salt)
        return obj

    def load(self, f, salt=None):
        """Read a token from ``f`` and load it."""
        # spec: N-000363 N-000033 N-000159 N-000366 N-000365
        return self.loads(f.read(), salt=salt)

    def loads_unsafe(self, s, salt=None):
        """Return ``(signature_valid, obj)``; raises ``BadPayload`` on a decode failure."""
        # spec: N-000364 N-000035 N-000034
        return self._load_unsafe(s, salt=salt)

    def load_unsafe(self, f, salt=None):
        """Read a token from ``f`` and inspect it with :meth:`loads_unsafe`."""
        # spec: N-000365 N-000033
        return self.loads_unsafe(f.read(), salt=salt)


class TimedSerializer(Serializer):
    """Serializer that records the signing time and can enforce a maximum age."""

    # spec: N-000362 N-000186 N-000188 N-000190 N-000191 N-000187 N-000194 N-000314 N-000189

    _default_signer = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        """Verify, age-check, and deserialize a token; optionally return the signing time."""
        # spec: N-000362 N-000206 N-000207 N-000208
        obj, signed_at = self._load(s, salt=salt, max_age=max_age)
        if return_timestamp:
            return obj, signed_at
        return obj

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        """Read a token from ``f`` and load it."""
        return self.loads(f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        """Return ``(signature_valid, obj)``; an expired token gives ``(False, obj)``."""
        # spec: N-000214 N-000183
        return self._load_unsafe(s, salt=salt, max_age=max_age)

    def load_unsafe(self, f, max_age=None, salt=None):
        """Read a token from ``f`` and inspect it with :meth:`loads_unsafe`."""
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


class URLSafeSerializer(Serializer):
    """Serializer whose tokens use only URL-safe characters and compress when that shortens them."""

    # spec: N-000229 N-000230 N-000234 N-000235 N-000231 N-000237 N-000238 N-000239 N-000240
    # spec: N-000241 N-000242 N-000243 N-000246 N-000248 N-000251 N-000252 N-000009 N-000043
    # spec: N-000044 N-000045 N-000368 N-000370 N-000372
    _default_serializer = _CompactJSON()

    def _pack_url(self, obj, sep: bytes) -> bytes:
        """Encode the payload section; a compressed section starts with ``sep``."""
        # spec: N-000241 N-000242 N-000238 N-000239 N-000240
        data = as_bytes(self._pack(obj))
        plain = b64encode(data)
        packed = b64encode(compress(data))
        # Compress only when the encoded token section gets strictly shorter.
        if len(sep) + len(packed) < len(plain):
            return sep + packed
        return plain

    def _unpack_bytes(self, payload: bytes, sep: bytes) -> bytes:
        # spec: N-000247 N-000248 N-000249 N-000250
        compressed = payload.startswith(sep)
        body = payload[len(sep):] if compressed else payload
        try:
            data = b64decode(body)
            if compressed:
                data = decompress(data)
        except (ValueError, zlib.error) as error:
            raise BadPayload("Payload is not valid URL-safe data", original_error=error) from error
        return data

    def dumps(self, obj, salt=None) -> str:
        """Return the URL-safe text token for ``obj``."""
        # spec: N-000234 N-000359 N-000315
        signer = self.make_signer(salt)
        return signer.sign(self._pack_url(obj, signer.sep)).decode("ascii")


class URLSafeTimedSerializer(URLSafeSerializer, TimedSerializer):
    """URL-safe serializer with the timestamp and maximum-age behaviour of :class:`TimedSerializer`."""

    # spec: N-000316 N-000233 N-000244 N-000245 N-000197 N-000369 N-000370 N-000372
    _default_signer = TimestampSigner
