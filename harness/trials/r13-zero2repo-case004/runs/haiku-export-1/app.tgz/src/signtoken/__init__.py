"""Signtoken: sign data so it can be sent to untrusted places and trusted again on return."""

# spec: N-000269 N-000270 N-000271 N-000274 N-000275 N-000276 N-000277 N-000278
# spec: N-000279 N-000280 N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287
# spec: N-000288 N-000023 N-000076 N-000077
# The package exports the names listed above and nothing that performs I/O on import.
#
# Ids satisfied by scope rather than code (the library ships none of these):
# N-000010 N-000011 N-000012 N-000054 N-000055 N-000056 N-000059 N-000069 N-000072 N-000073
# N-000074 N-000075 N-000079 N-000080 N-000081 N-000082 N-000083 N-000084 N-000058 N-000060
# N-000061 N-000065 N-000070

from .algorithms import HMACAlgorithm, NoneAlgorithm
from .exceptions import BadData, BadPayload, BadSignature, BadTimeSignature, SignatureExpired
from .serializer import Serializer, TimedSerializer, URLSafeSerializer, URLSafeTimedSerializer
from .signer import Signer, TimestampSigner

__version__ = "1.0.0"

__all__ = [
    "BadData",
    "BadPayload",
    "BadSignature",
    "BadTimeSignature",
    "HMACAlgorithm",
    "NoneAlgorithm",
    "Serializer",
    "SignatureExpired",
    "Signer",
    "TimedSerializer",
    "TimestampSigner",
    "URLSafeSerializer",
    "URLSafeTimedSerializer",
]
