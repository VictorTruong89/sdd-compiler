"""Signing algorithms passed to a signer as ``algorithm``."""

from __future__ import annotations

import hashlib
import hmac


class HMACAlgorithm:
    """HMAC (RFC 2104) over the payload, keyed with the signer's derived key."""

    # spec: N-000134 N-000348 N-000347 N-000031 N-000303 N-000304

    def __init__(self, digest_method=None):
        # spec: N-000348 — without a digest, HMAC uses SHA-1.
        self.digest_method = hashlib.sha1 if digest_method is None else digest_method

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return hmac.new(key, value, self.digest_method).digest()

    def verify_signature(self, key: bytes, value: bytes, signature: bytes) -> bool:
        return hmac.compare_digest(signature, self.get_signature(key, value))


class NoneAlgorithm:
    """No-op algorithm: the signature is always empty and gives no tamper detection."""

    # spec: N-000349 N-000135 N-000136 N-000137

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return b""

    def verify_signature(self, key: bytes, value: bytes, signature: bytes) -> bool:
        return hmac.compare_digest(signature, b"")
