"""Basic and timestamped signers."""

from __future__ import annotations

import hashlib
import hmac
import re
import time
from collections.abc import Sequence
from datetime import timedelta

from ._encoding import (
    as_bytes,
    b64decode,
    b64encode,
    coerce_token,
    decode_time,
    encode_time,
    to_utc_datetime,
)
from .algorithms import HMACAlgorithm
from .exceptions import BadSignature, BadTimeSignature, SignatureExpired

# spec: N-000295 N-000296 N-000289
# Product-defined default salt, shared by every signer and serializer.
DEFAULT_SALT = b"signtoken.default-salt"

# spec: N-000118 — the four built-in key-derivation schemes.
KEY_DERIVATION_SCHEMES = ("concat", "django-concat", "hmac", "none")
DEFAULT_KEY_DERIVATION = "django-concat"

# spec: N-000141 — characters that can appear in an encoded signature or time field.
_FORBIDDEN_SEP = re.compile(rb"[A-Za-z0-9=_-]")


def _normalize_secrets(secret_key) -> list[bytes]:
    # spec: N-000290 N-000114 N-000029 N-000085 N-000090 N-000091
    if isinstance(secret_key, (str, bytes, bytearray)):
        secrets = [secret_key]
    elif isinstance(secret_key, Sequence):
        secrets = list(secret_key)
    else:
        raise TypeError("secret_key must be str, bytes, or a sequence of them")
    if not secrets:
        raise ValueError("secret_key must contain at least one key")
    return [as_bytes(secret) for secret in secrets]


def _now() -> int:
    # spec: N-000307 N-000308 N-000310 N-000067 N-000200 — whole seconds, read on each call.
    return int(time.time())


class Signer:
    """Signs a byte value into ``payload<sep><signature>``."""

    # spec: N-000331 N-000086 N-000087 N-000088 N-000089 N-000095 N-000001 N-000002 N-000004
    # spec: N-000016 N-000024 N-000092 N-000093 N-000094 N-000058 N-000125 N-000126 N-000131
    # spec: N-000017 N-000064 N-000298 — a subclass may assign another digest constructor here.
    default_digest_method = staticmethod(hashlib.sha1)

    def __init__(
        self,
        secret_key,
        salt=None,
        sep=".",
        key_derivation=None,
        digest_method=None,
        algorithm=None,
    ):
        # spec: N-000109 N-000115 N-000122 N-000121 N-000030 N-000062 N-000304 N-000302 N-000301
        self.secret_keys = _normalize_secrets(secret_key)
        self.salt = DEFAULT_SALT if salt is None else as_bytes(salt)  # spec: N-000112 N-000293 N-000294 N-000295

        self.sep = as_bytes(sep)  # spec: N-000297 N-000142
        self._check_sep(self.sep)  # spec: N-000141 N-000337 N-000338 N-000340

        # spec: N-000299 N-000300 N-000019 N-000063 N-000119 N-000339 N-000143 — construction refuses
        # a scheme outside the built-in names, so no unknown scheme can produce a token.
        self.key_derivation = DEFAULT_KEY_DERIVATION if key_derivation is None else key_derivation
        if self.key_derivation not in KEY_DERIVATION_SCHEMES:
            raise ValueError(f"unknown key derivation scheme: {self.key_derivation!r}")

        # spec: N-000132 N-000133 N-000167 N-000168 — an explicit digest beats the class default.
        if digest_method is None:
            digest_method = type(self).default_digest_method
        self.digest_method = digest_method

        # spec: N-000134 N-000031 N-000303 — the default algorithm is HMAC with the configured digest.
        self.algorithm = HMACAlgorithm(self.digest_method) if algorithm is None else algorithm

        # spec: N-000121 N-000122 — derived once per secret, in the order given.
        self._keys = [self._derive_key(secret) for secret in self.secret_keys]

    @staticmethod
    def _check_sep(sep: bytes) -> None:
        if not sep:
            raise ValueError("separator must not be empty")
        if _FORBIDDEN_SEP.search(sep):
            raise ValueError("separator must not contain letters, digits, '-', '_' or '='")

    def _derive_key(self, secret: bytes) -> bytes:
        # spec: N-000121 N-000122 N-000123 N-000128 — each scheme derives a different key,
        # and the digest is used by key derivation.
        digest = self.digest_method
        if self.key_derivation == "concat":
            return digest(self.salt + secret).digest()
        if self.key_derivation == "django-concat":
            return digest(self.salt + b"signer" + secret).digest()
        if self.key_derivation == "hmac":
            mac = hmac.new(secret, digestmod=digest)
            mac.update(self.salt)
            return mac.digest()
        return secret  # "none": the secret itself, salt not mixed in

    def _signature_text(self, value: bytes) -> bytes:
        # spec: N-000319 N-000320 N-000115 — signs with the newest key.
        return b64encode(self.algorithm.get_signature(self._keys[-1], value))

    def sign(self, value) -> bytes:
        # spec: N-000311 N-000332 N-000096 N-000093 N-000104 N-000001 N-000002 N-000058
        payload = as_bytes(value)
        return payload + self.sep + self._signature_text(payload)

    def _verify(self, token):
        """Split and verify a token; return ``(signed_part, verified)``.

        Raises a plain ``BadSignature`` (no payload) when the token has no separator.
        """
        # spec: N-000103 N-000104 N-000105 N-000116 N-000117 N-000003 N-000060 N-000091 N-000330
        token = coerce_token(token)
        index = token.rfind(self.sep)
        if index < 0:
            raise BadSignature("No separator found in value", payload=None)  # spec: N-000108
        signed = token[:index]
        signature = token[index + len(self.sep):]
        try:
            raw_signature = b64decode(signature)
        except ValueError:
            return signed, False
        verified = any(
            self.algorithm.verify_signature(key, signed, raw_signature) for key in self._keys
        )
        return signed, verified

    def _mismatch(self, signed: bytes) -> BadSignature:
        # spec: N-000107 N-000173 N-000376 N-000220 N-000224
        return BadSignature("Signature does not match", payload=signed)

    def _accept(self, signed: bytes, max_age=None):
        # spec: N-000206 — a plain signer has no time field and no age check.
        return signed, None

    def _open(self, token, max_age=None):
        signed, verified = self._verify(token)
        if not verified:
            raise self._mismatch(signed)
        return self._accept(signed, max_age)

    def unsign(self, signed_value) -> bytes:
        """Return the payload if the token verifies; raise ``BadSignature`` otherwise."""
        # spec: N-000333 N-000334 N-000342 N-000097 N-000098 N-000015
        payload, _ = self._open(signed_value)
        return payload

    def validate(self, signed_value) -> bool:
        """Return whether the token verifies; never raises for a bad token."""
        # spec: N-000335 N-000336 N-000099 N-000100 N-000101 N-000106
        try:
            self.unsign(signed_value)
        except BadSignature:
            return False
        return True


class TimestampSigner(Signer):
    """Signs ``payload<sep><time><sep><signature>`` and can enforce a maximum age."""

    # spec: N-000341 N-000312 N-000189 N-000193 N-000198 N-000199 N-000007 N-000039 N-000008 N-000040
    # spec: N-000071 N-000192 N-000194 N-000068 N-000309 N-000310

    def sign(self, value) -> bytes:
        # spec: N-000312 N-000200 N-000201 N-000202
        payload = as_bytes(value)
        signed = payload + self.sep + encode_time(_now())
        return signed + self.sep + self._signature_text(signed)

    def _mismatch(self, signed: bytes) -> BadSignature:
        # spec: N-000221 N-000222 N-000228 N-000225 N-000223 N-000376 N-000377
        if self.sep not in signed:
            # spec: N-000224 — signature failure with no separator is a plain mismatch.
            return BadSignature("Signature does not match", payload=signed)
        payload, time_field = signed.rsplit(self.sep, 1)
        try:
            seconds = decode_time(time_field, strict=False)
        except ValueError:
            return BadTimeSignature("Time signature does not match", payload=payload)
        date_signed = to_utc_datetime(seconds)
        if date_signed is None:
            # spec: N-000223 — an unrepresentable time is a malformed timestamp.
            return BadTimeSignature("Malformed timestamp", payload=payload, reason="malformed")
        return BadTimeSignature("Time signature does not match", payload=payload, date_signed=date_signed)

    def _accept(self, signed: bytes, max_age=None):
        """Check the time field of a verified token and apply the age limit."""
        # spec: N-000205 N-000206 N-000207 N-000209 N-000210 N-000211 N-000212 N-000226
        if self.sep not in signed:
            # spec: N-000217 N-000218 — missing timestamp.
            raise BadTimeSignature("Missing timestamp", payload=signed, reason="missing")
        payload, time_field = signed.rsplit(self.sep, 1)
        try:
            seconds = decode_time(time_field, strict=True)
        except ValueError:
            seconds = None
        date_signed = None if seconds is None else to_utc_datetime(seconds)
        if date_signed is None:
            # spec: N-000219 — malformed timestamp.
            raise BadTimeSignature("Malformed timestamp", payload=payload, reason="malformed")

        if max_age is not None:
            if isinstance(max_age, timedelta):
                max_age = max_age.total_seconds()
            age = _now() - seconds
            if age > max_age or age < 0:
                raise SignatureExpired("Signature expired", payload=payload, date_signed=date_signed)
        return payload, date_signed

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        """Return the payload, or ``(payload, signed_at)`` when asked for the time."""
        # spec: N-000342 N-000343 N-000344 N-000345 N-000206 N-000207
        payload, signed_at = self._open(signed_value, max_age)
        if return_timestamp:
            return payload, signed_at
        return payload

    def validate(self, signed_value, max_age=None) -> bool:
        """Return whether the token verifies and is not expired; never raises for a bad token."""
        # spec: N-000346 N-000213 N-000099 N-000101
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadSignature:
            return False
        return True
