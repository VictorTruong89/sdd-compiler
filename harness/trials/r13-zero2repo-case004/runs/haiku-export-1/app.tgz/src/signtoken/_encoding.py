"""Byte-level helpers shared by the signers and serializers."""

from __future__ import annotations

import base64
import re
import zlib
from datetime import datetime, timezone

from .exceptions import BadSignature

# spec: N-000319 N-000328
_URL_SAFE_TEXT = re.compile(rb"[A-Za-z0-9_-]*")

# spec: N-000324 — the time field is at most this many characters.
MAX_TIME_FIELD_LENGTH = 11


def as_bytes(value: str | bytes | bytearray) -> bytes:
    """Return ``value`` as bytes, encoding text as UTF-8."""
    # spec: N-000291 N-000305
    if isinstance(value, str):
        return value.encode("utf-8")
    return bytes(value)


def coerce_token(value: str | bytes | bytearray):
    """Return a token as bytes; text that cannot be encoded is a bad token."""
    # spec: N-000306
    if isinstance(value, str):
        try:
            return value.encode("utf-8")
        except UnicodeEncodeError:
            raise BadSignature("Token is not encodable as UTF-8", payload=None) from None
    return bytes(value)


def b64encode(data: bytes) -> bytes:
    """URL-safe base64 with the ``=`` padding removed.

    Internal helper only; it is not exported, because the encoding exists to serve the signer.
    """
    # spec: N-000319 N-000328 N-000046 N-000078 N-000047
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def b64decode(text: bytes) -> bytes:
    """Strict inverse of :func:`b64encode`; raises ``ValueError`` on anything else."""
    if not _URL_SAFE_TEXT.fullmatch(text) or len(text) % 4 == 1:
        raise ValueError("not URL-safe base64")
    raw = base64.urlsafe_b64decode(text + b"=" * (-len(text) % 4))
    # Reject non-canonical encodings, so a changed trailing character cannot verify.
    if b64encode(raw) != text:
        raise ValueError("non-canonical URL-safe base64")
    return raw


def encode_time(seconds: int) -> bytes:
    """Encode whole Unix seconds as a URL-safe field of at most 11 characters."""
    # spec: N-000321 N-000323 N-000200
    raw = seconds.to_bytes(max(1, (seconds.bit_length() + 7) // 8), "big")
    return b64encode(raw)


def decode_time(text: bytes, strict: bool) -> int:
    """Decode a time field to whole Unix seconds; raises ``ValueError`` if it is not one.

    ``strict`` also applies the length limit, which is used once a signature verifies.
    """
    # spec: N-000324 N-000326 N-000325 N-000327
    if strict and len(text) > MAX_TIME_FIELD_LENGTH:
        raise ValueError("time field too long")
    raw = b64decode(text)
    if not raw:
        raise ValueError("empty time field")
    return int.from_bytes(raw, "big")


def to_utc_datetime(seconds: int) -> datetime | None:
    """Return the UTC datetime for ``seconds``, or None if the standard type cannot hold it."""
    # spec: N-000223 N-000343 N-000041 N-000207
    try:
        return datetime.fromtimestamp(seconds, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


def compress(data: bytes) -> bytes:
    """Lossless compression for URL-safe payloads (zlib; the format is the implementer's choice)."""
    # spec: N-000237 N-000329
    return zlib.compress(data, 9)


def decompress(data: bytes) -> bytes:
    """Inverse of :func:`compress`; refuses anything that is not exactly one stream."""
    decoder = zlib.decompressobj()
    out = decoder.decompress(data)
    if not decoder.eof or decoder.unused_data:
        raise zlib.error("not an intact compressed stream")
    return out
