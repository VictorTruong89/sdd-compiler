"""Failure classes raised when a token is refused."""

from __future__ import annotations

from datetime import datetime


# Failure messages (str()) are free text; the kinds below are the contract.
# spec: N-000380 N-000042 N-000048 N-000375 N-000374


class BadData(Exception):
    """Base class of every refusal raised by Signtoken."""

    # spec: N-000375


class BadSignature(BadData):
    """The token's signature does not verify, or the token has no separator."""

    # spec: N-000376 N-000021 N-000107 N-000173 N-000381

    def __init__(self, message: str = "Signature does not match", payload: bytes | None = None):
        super().__init__(message)
        # The unverified payload section, or None when the token has none.
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused for its time field."""

    # spec: N-000377

    def __init__(
        self,
        message: str = "Time signature failure",
        payload: bytes | None = None,
        date_signed: datetime | None = None,
        reason: str | None = None,
    ):
        super().__init__(message, payload)
        self.date_signed = date_signed
        # "missing", "malformed", or None.
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The token verified but is older than the caller's maximum age."""

    # spec: N-000378

    def __init__(self, message: str = "Signature expired", payload: bytes | None = None, date_signed: datetime | None = None):
        super().__init__(message, payload, date_signed, reason=None)


class BadPayload(BadData):
    """The signature verified but the payload could not be decoded or deserialized."""

    # spec: N-000379

    def __init__(self, message: str = "Payload could not be deserialized", original_error: BaseException | None = None):
        super().__init__(message)
        # The exception the decoder or dump/load object raised.
        self.original_error = original_error
