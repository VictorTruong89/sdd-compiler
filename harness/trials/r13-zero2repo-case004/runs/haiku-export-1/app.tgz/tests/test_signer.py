"""Tests for the basic and timestamped signers (FP-01, FP-03 signer side)."""

import hashlib
import re
from datetime import datetime, timedelta, timezone

import pytest

import signtoken
from signtoken import (
    BadSignature,
    BadTimeSignature,
    HMACAlgorithm,
    NoneAlgorithm,
    SignatureExpired,
    Signer,
    TimestampSigner,
)


SECRET = "secret-key"


def test_n000025_recover_original_bytes_from_valid_token():  # spec: N-000025 N-000097
    signer = Signer(SECRET)
    token = signer.sign(b"hello world")
    assert isinstance(token, bytes)
    assert signer.unsign(token) == b"hello world"


def test_n000096_text_is_encoded_as_utf8_and_recovers_as_bytes():  # spec: N-000096 N-000098
    signer = Signer(SECRET)
    token = signer.sign("héllo")
    assert signer.unsign(token) == "héllo".encode("utf-8")


def test_n000095_token_is_payload_separator_signature():  # spec: N-000095 N-000103
    signer = Signer(SECRET)
    token = signer.sign(b"payload")
    payload, sig = token.rsplit(b".", 1)
    assert payload == b"payload"
    assert b"." not in sig
    assert re.fullmatch(rb"[A-Za-z0-9_-]+", sig)


def test_n000026_validate_reports_boolean_without_payload():  # spec: N-000026 N-000099 N-000100
    signer = Signer(SECRET)
    token = signer.sign(b"x")
    assert signer.validate(token) is True
    assert signer.validate(b"x.wrong") is False


@pytest.mark.parametrize("bad", [b"", b"nosep", b"abc.", b"abc.!!!", "naïve\ud800", b"x.AAAA"])
def test_n000101_validate_never_raises_for_bad_tokens(bad):  # spec: N-000101 N-000336
    assert Signer(SECRET).validate(bad) is False


def test_n000105_any_alteration_is_refused_as_signature_mismatch():  # spec: N-000105 N-000106 N-000144
    signer = Signer(SECRET)
    token = bytearray(signer.sign(b"payload"))
    for index in range(len(token)):
        altered = bytes(token[:index]) + bytes([token[index] ^ 0x01]) + bytes(token[index + 1:])
        assert not signer.validate(altered), index
    assert not signer.validate(signer.sign(b"payload")[:-1])


def test_n000107_refused_token_carries_unverified_payload():  # spec: N-000107 N-000173
    signer = Signer(SECRET)
    with pytest.raises(BadSignature) as info:
        signer.unsign(b"payload.bogus")
    assert info.value.payload == b"payload"


def test_n000108_token_without_separator_carries_no_payload():  # spec: N-000108 N-000027
    signer = Signer(SECRET)
    with pytest.raises(BadSignature) as info:
        signer.unsign(b"nosepatall")
    assert info.value.payload is None


def test_n000102_payload_may_contain_separator():  # spec: N-000102 N-000104 N-000204
    signer = Signer(SECRET)
    token = signer.sign(b"a.b.c")
    assert signer.unsign(token) == b"a.b.c"


@pytest.mark.parametrize("sep", ["a", "7", "-", "_", "="])
def test_n000141_forbidden_separators_refused(sep):  # spec: N-000141 N-000337
    with pytest.raises(ValueError):
        Signer(SECRET, sep=sep)


@pytest.mark.parametrize("sep", [".", "|", ":", "~"])
def test_n000142_other_separators_accepted(sep):  # spec: N-000142
    signer = Signer(SECRET, sep=sep)
    assert signer.unsign(signer.sign(b"v")) == b"v"


def test_n000109_salt_isolates_contexts():  # spec: N-000109 N-000110 N-000028
    token = Signer(SECRET, salt="one").sign(b"v")
    assert Signer(SECRET, salt="one").unsign(token) == b"v"
    assert not Signer(SECRET, salt="two").validate(token)


def test_n000112_omitted_salt_uses_default_and_interchanges():  # spec: N-000112 N-000113
    assert Signer(SECRET).unsign(Signer(SECRET, salt=None).sign(b"v")) == b"v"


def test_n000114_key_rotation_accepts_any_listed_key_and_signs_with_newest():  # spec: N-000114 N-000115 N-000116
    old_only = Signer("old").sign(b"v")
    rotated = Signer(["old", "new"])
    assert rotated.unsign(old_only) == b"v"
    assert Signer("new").unsign(rotated.sign(b"w")) == b"w"


def test_n000117_token_signed_only_with_removed_key_is_refused():  # spec: N-000117 N-000013
    token = Signer("retired").sign(b"v")
    assert not Signer(["current"]).validate(token)


@pytest.mark.parametrize("scheme", ["concat", "django-concat", "hmac", "none"])
def test_n000120_every_scheme_round_trips(scheme):  # spec: N-000120 N-000118
    signer = Signer(SECRET, key_derivation=scheme)
    assert signer.unsign(signer.sign(b"v")) == b"v"


def test_n000124_tokens_do_not_interchange_between_schemes():  # spec: N-000124 N-000123
    token = Signer(SECRET, key_derivation="concat").sign(b"v")
    assert not Signer(SECRET, key_derivation="hmac").validate(token)
    assert not Signer(SECRET, key_derivation="django-concat").validate(token)


def test_n000119_default_key_derivation_is_django_concat():  # spec: N-000119
    assert Signer(SECRET).key_derivation == "django-concat"
    token = Signer(SECRET, key_derivation="django-concat").sign(b"v")
    assert Signer(SECRET).unsign(token) == b"v"


def test_n000143_unknown_key_derivation_refused_at_construction():  # spec: N-000143
    with pytest.raises(ValueError):
        Signer(SECRET, key_derivation="sha512-magic")


def test_n000126_default_digest_is_sha1_and_explicit_sha1_matches():  # spec: N-000126 N-000127 N-000018
    default = Signer(SECRET).sign(b"v")
    explicit = Signer(SECRET, digest_method=hashlib.sha1).sign(b"v")
    assert default == explicit
    assert len(default.rsplit(b".", 1)[1]) == 27  # SHA-1 digest size, URL-safe base64, unpadded


def test_n000130_signers_with_different_digests_do_not_interchange():  # spec: N-000130 N-000129
    token = Signer(SECRET, digest_method=hashlib.sha256).sign(b"v")
    assert not Signer(SECRET).validate(token)
    assert Signer(SECRET, digest_method=hashlib.sha256).unsign(token) == b"v"


def test_n000131_signer_type_default_digest_applies_and_explicit_wins():  # spec: N-000131 N-000132 N-000133
    class Sha256Signer(Signer):
        default_digest_method = hashlib.sha256

    token = Sha256Signer(SECRET).sign(b"v")
    assert Signer(SECRET, digest_method=hashlib.sha256).unsign(token) == b"v"
    explicit = Sha256Signer(SECRET, digest_method=hashlib.sha1).sign(b"v")
    assert Signer(SECRET).unsign(explicit) == b"v"


def test_n000125_any_hash_constructor_accepted():  # spec: N-000125
    signer = Signer(SECRET, digest_method=hashlib.sha512)
    assert signer.unsign(signer.sign(b"v")) == b"v"


def test_n000135_none_algorithm_round_trips_but_offers_no_tamper_detection():  # spec: N-000135 N-000136 N-000137 N-000138
    signer = Signer(SECRET, algorithm=NoneAlgorithm())
    token = signer.sign(b"v")
    assert token == b"v."
    assert signer.unsign(token) == b"v"
    assert signer.unsign(b"changed.") == b"changed"


def test_n000139_hmac_refuses_none_tokens_and_none_refuses_hmac_tokens():  # spec: N-000139 N-000140
    none_token = Signer(SECRET, algorithm=NoneAlgorithm()).sign(b"v")
    hmac_token = Signer(SECRET).sign(b"v")
    assert not Signer(SECRET).validate(none_token)
    assert not Signer(SECRET, algorithm=NoneAlgorithm()).validate(hmac_token)


def test_n000134_default_algorithm_is_hmac_with_configured_digest():  # spec: N-000134 N-000348
    assert isinstance(Signer(SECRET).algorithm, HMACAlgorithm)
    assert HMACAlgorithm().digest_method is hashlib.sha1


def test_n000144_wrong_secret_or_salt_refuses():  # spec: N-000144
    token = Signer(SECRET).sign(b"v")
    assert not Signer("other").validate(token)
    assert not Signer(SECRET, salt="x").validate(token)


def test_n000161_none_scheme_ignores_salt():  # spec: N-000111 N-000161
    token = Signer(SECRET, key_derivation="none", salt="a").sign(b"v")
    assert Signer(SECRET, key_derivation="none", salt="b").unsign(token) == b"v"


def test_n000338_timestamp_signer_inherits_constructor_refusals():  # spec: N-000341 N-000337
    with pytest.raises(ValueError):
        TimestampSigner(SECRET, sep="1")


# Timestamped signer.


def test_n000189_timestamp_recorded_and_returned_as_utc_datetime(monkeypatch):  # spec: N-000189 N-000207 N-000208
    monkeypatch.setattr("time.time", lambda: 1_700_000_000.9)
    signer = TimestampSigner(SECRET)
    token = signer.sign(b"v")
    payload, signed_at = signer.unsign(token, return_timestamp=True)
    assert payload == b"v"
    assert signed_at == datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    assert signed_at.tzinfo is not None
    assert TimestampSigner(SECRET).unsign(token, return_timestamp=True)[1] == signed_at


def test_n000206_no_max_age_accepts_any_age(monkeypatch):  # spec: N-000206
    monkeypatch.setattr("time.time", lambda: 1_000_000_000)
    token = TimestampSigner(SECRET).sign(b"v")
    monkeypatch.setattr("time.time", lambda: 9_000_000_000)
    assert TimestampSigner(SECRET).unsign(token) == b"v"


def test_n000209_expired_when_age_exceeds_max_age(monkeypatch):  # spec: N-000209 N-000212 N-000226 N-000213
    monkeypatch.setattr("time.time", lambda: 1_000_000_000)
    token = TimestampSigner(SECRET).sign(b"v")
    monkeypatch.setattr("time.time", lambda: 1_000_000_011)
    with pytest.raises(SignatureExpired) as info:
        TimestampSigner(SECRET).unsign(token, max_age=10)
    assert info.value.payload == b"v"
    assert info.value.date_signed == datetime.fromtimestamp(1_000_000_000, tz=timezone.utc)
    assert info.value.reason is None
    assert not TimestampSigner(SECRET).validate(token, max_age=10)
    assert TimestampSigner(SECRET).validate(token, max_age=11)


def test_n000209_future_timestamp_is_expired_when_max_age_given(monkeypatch):  # spec: N-000209
    monkeypatch.setattr("time.time", lambda: 1_000_000_100)
    token = TimestampSigner(SECRET).sign(b"v")
    monkeypatch.setattr("time.time", lambda: 1_000_000_000)
    with pytest.raises(SignatureExpired):
        TimestampSigner(SECRET).unsign(token, max_age=1000)


def test_n000211_age_checked_only_after_signature_verifies(monkeypatch):  # spec: N-000211
    monkeypatch.setattr("time.time", lambda: 1_000_000_000)
    token = TimestampSigner(SECRET).sign(b"v")
    monkeypatch.setattr("time.time", lambda: 2_000_000_000)
    with pytest.raises(BadSignature) as info:
        TimestampSigner(SECRET).unsign(token[:-1] + b"A", max_age=1)
    assert not isinstance(info.value, SignatureExpired)


def test_n000224_missing_timestamp_when_signature_verifies():  # spec: N-000217 N-000218 N-000227
    token = Signer(SECRET).sign(b"plain")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(token)
    assert info.value.reason == "missing"
    assert info.value.date_signed is None


def test_n000224_plain_mismatch_without_separator_is_not_missing_timestamp():  # spec: N-000224 N-000228
    with pytest.raises(BadSignature) as info:
        TimestampSigner(SECRET).unsign(b"payload.badsig")
    assert not isinstance(info.value, BadTimeSignature)
    assert info.value.payload == b"payload"


def test_n000219_malformed_timestamp_when_signature_verifies():  # spec: N-000219 N-000227
    signer = Signer(SECRET)
    token = signer.sign(b"v.!!!")  # signature verifies over a non-timestamp field
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(token)
    assert info.value.reason == "malformed"


def test_n000321_time_field_longer_than_eleven_characters_is_malformed():  # spec: N-000324 N-000326 N-000322
    signer = Signer(SECRET)
    token = signer.sign(b"v.AAAAAAAAAAAA")  # 12 URL-safe characters, signature verifies
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(token)
    assert info.value.reason == "malformed"


def test_n000220_time_signature_failure_carries_payload_and_time():  # spec: N-000220 N-000221 N-000222 N-000376
    token = TimestampSigner(SECRET).sign(b"v")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(token[:-2] + b"AA")
    assert type(info.value) is BadTimeSignature
    assert info.value.payload == b"v"
    assert info.value.reason is None
    assert info.value.date_signed is not None


def test_n000223_unrepresentable_time_is_malformed_when_signature_fails():  # spec: N-000223
    huge = signtoken._encoding.encode_time(10**15)
    token = Signer(SECRET).sign(b"v." + huge)  # signature verifies here; not what we check
    tampered = token[:-1] + (b"A" if token[-1:] != b"A" else b"B")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(tampered)
    assert info.value.reason == "malformed"


def test_n000199_signature_covers_payload_and_time_field(monkeypatch):  # spec: N-000198 N-000199 N-000205
    monkeypatch.setattr("time.time", lambda: 1_000_000_000)
    token = TimestampSigner(SECRET).sign(b"a.b")
    assert TimestampSigner(SECRET).unsign(token) == b"a.b"
    head, _ = token.rsplit(b".", 1)
    assert head.rsplit(b".", 1)[0] == b"a.b"  # the time field sits between the last two separators


def test_n000193_timestamp_signer_interchanges_salt_with_plain_signer(monkeypatch):  # spec: N-000193 N-000195 N-000196
    token = TimestampSigner(SECRET, salt="s").sign(b"v")
    assert TimestampSigner(SECRET, salt="s").validate(token)
    assert not TimestampSigner(SECRET, salt="t").validate(token)


def test_n000200_timestamp_is_whole_seconds_and_url_safe(monkeypatch):  # spec: N-000200 N-000321 N-000324
    monkeypatch.setattr("time.time", lambda: 1_700_000_000.999)
    token = TimestampSigner(SECRET).sign(b"v")
    time_field = token.split(b".")[1]
    assert len(time_field) <= 11
    assert re.fullmatch(rb"[A-Za-z0-9_-]+", time_field)
    assert TimestampSigner(SECRET).unsign(token, return_timestamp=True)[1].second == 20


def test_n000202_signing_succeeds_beyond_standard_datetime_range(monkeypatch):  # spec: N-000202 N-000203
    monkeypatch.setattr("time.time", lambda: 1e15)
    token = TimestampSigner(SECRET).sign(b"v")
    assert token.startswith(b"v.")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner(SECRET).unsign(token)
    assert info.value.reason == "malformed"


def test_n000201_clock_read_at_each_call(monkeypatch):  # spec: N-000201 N-000067 N-000307 N-000308
    clock = iter([1_000_000_000, 1_000_000_500])
    monkeypatch.setattr("time.time", lambda: next(clock))
    signer = TimestampSigner(SECRET)
    first = signer.sign(b"v")
    second = signer.sign(b"v")
    assert first != second
    assert signer.unsign(first, return_timestamp=True)[1].timestamp() == 1_000_000_000
    assert signer.unsign(second, return_timestamp=True)[1].timestamp() == 1_000_000_500


def test_n000215_validate_bad_token_with_timestamp_never_raises():  # spec: N-000346 N-000213
    assert not TimestampSigner(SECRET).validate(b"nope")
    assert not TimestampSigner(SECRET).validate(b"a.b.c")
    assert not TimestampSigner(SECRET).validate(b"a.b.c", max_age=timedelta(seconds=5))
