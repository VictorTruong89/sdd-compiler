"""Tests for the serialize-and-sign helpers (FP-02, FP-03 serializer side, FP-04)."""

import hashlib
import io
import json
import re
from datetime import datetime, timezone

import pytest

import signtoken
from signtoken import (
    BadData,
    BadPayload,
    BadSignature,
    BadTimeSignature,
    NoneAlgorithm,
    SignatureExpired,
    Signer,
    Serializer,
    TimedSerializer,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)

SECRET = "serializer-secret"
OBJ = {"user": 7, "roles": ["a", "b"], "name": "Zoë"}


def test_n000152_dump_then_load_round_trips():  # spec: N-000152 N-000153 N-000154 N-000032
    serializer = Serializer(SECRET)
    assert serializer.loads(serializer.dumps(OBJ)) == OBJ


def test_n000155_default_payload_is_exact_json_text():  # spec: N-000155 N-000006
    token = Serializer(SECRET).dumps(OBJ)
    assert isinstance(token, str)
    payload = token.rsplit(".", 1)[0]
    assert payload == json.dumps(OBJ)


def test_n000156_text_dump_returns_text_and_bytes_dump_returns_bytes():  # spec: N-000156 N-000157
    class BytesDump:
        def dumps(self, obj, **kwargs):
            return json.dumps(obj).encode("utf-8")

        def loads(self, data):
            return json.loads(data)

    text_token = Serializer(SECRET).dumps(OBJ)
    bytes_token = Serializer(SECRET, serializer=BytesDump()).dumps(OBJ)
    assert isinstance(text_token, str)
    assert isinstance(bytes_token, bytes)
    assert Serializer(SECRET).loads(text_token.encode("utf-8")) == OBJ
    assert Serializer(SECRET, serializer=BytesDump()).loads(bytes_token) == OBJ


def test_n000158_streams_round_trip():  # spec: N-000158 N-000033 N-000159
    buffer = io.StringIO()
    Serializer(SECRET).dump(OBJ, buffer)
    buffer.seek(0)
    assert Serializer(SECRET).load(buffer) == OBJ
    buffer.seek(0)
    valid, obj = Serializer(SECRET).load_unsafe(buffer)
    assert valid is True
    assert obj == OBJ


def test_n000181_any_alteration_refused_as_signature_mismatch():  # spec: N-000181 N-000184
    token = Serializer(SECRET).dumps(OBJ)
    tampered = token.replace("7", "8", 1)
    with pytest.raises(BadSignature) as info:
        Serializer(SECRET).loads(tampered)
    assert not isinstance(info.value, BadPayload)
    assert info.value.payload == tampered.rsplit(".", 1)[0].encode("utf-8")


def test_n000174_signature_mismatch_payload_recovers_object():  # spec: N-000173 N-000174 N-000175
    token = Serializer(SECRET).dumps(OBJ)
    head, _ = token.rsplit(".", 1)
    with pytest.raises(BadSignature) as info:
        Serializer(SECRET).loads(head + ".bogus")
    assert json.loads(info.value.payload) == OBJ


def test_n000182_verified_but_undeserializable_is_payload_decode_failure():  # spec: N-000182 N-000183 N-000379
    other = Serializer(SECRET, serializer=_TextDump())
    token = other.dumps("not json at all")
    with pytest.raises(BadPayload) as info:
        Serializer(SECRET).loads(token)
    assert isinstance(info.value.original_error, json.JSONDecodeError)


def test_n000183_unsafe_load_raises_payload_decode_failure_on_verified_garbage():  # spec: N-000183
    token = Serializer(SECRET, serializer=_TextDump()).dumps("plain text")
    with pytest.raises(BadPayload):
        Serializer(SECRET).loads_unsafe(token)


def test_n000176_unsafe_load_pairs():  # spec: N-000176 N-000177 N-000178 N-000179 N-000180
    serializer = Serializer(SECRET)
    token = serializer.dumps(OBJ)
    assert serializer.loads_unsafe(token) == (True, OBJ)
    head = token.rsplit(".", 1)[0]
    assert serializer.loads_unsafe(head + ".bogus") == (False, OBJ)
    assert serializer.loads_unsafe("no-separator-here") == (False, None)
    assert serializer.loads_unsafe("!!!.bogus") == (False, None)


def test_n000160_per_call_salt_replaces_helper_salt():  # spec: N-000160 N-000161 N-000036
    serializer = Serializer(SECRET, salt="helper")
    token = serializer.dumps(OBJ, salt="per-call")
    assert serializer.loads(token, salt="per-call") == OBJ
    with pytest.raises(BadSignature):
        serializer.loads(token)


def test_n000162_custom_dump_load_object_and_extra_options():  # spec: N-000162 N-000163 N-000352 N-000037
    seen = []

    class Recorder:
        def dumps(self, obj, **kwargs):
            seen.append(kwargs)
            return json.dumps(obj, sort_keys=kwargs.get("sort_keys", False))

        def loads(self, data):
            return json.loads(data)

    serializer = Serializer(SECRET, serializer=Recorder(), serializer_kwargs={"sort_keys": True})
    assert serializer.loads(serializer.dumps({"b": 1, "a": 2})) == {"a": 2, "b": 1}
    assert all(kwargs == {"sort_keys": True} for kwargs in seen)


def test_n000166_different_signing_configs_do_not_interchange():  # spec: N-000166 N-000164 N-000165
    token = Serializer(SECRET, signer_kwargs={"key_derivation": "concat"}).dumps(OBJ)
    assert not_loads(Serializer(SECRET, signer_kwargs={"key_derivation": "hmac"}), token)
    token_b = Serializer(SECRET, signer_kwargs={"digest_method": hashlib.sha256}).dumps(OBJ)
    assert not_loads(Serializer(SECRET), token_b)
    round_trip = Serializer(SECRET, signer=Signer, signer_kwargs={"algorithm": NoneAlgorithm()})
    assert round_trip.loads(round_trip.dumps(OBJ)) == OBJ


def test_n000167_signer_type_default_digest_applies_unless_signing_options_name_one():  # spec: N-000167 N-000168
    class Sha256Signer(Signer):
        default_digest_method = hashlib.sha256

    token = Serializer(SECRET, signer=Sha256Signer).dumps(OBJ)
    assert Serializer(SECRET, signer=Sha256Signer).loads(token) == OBJ
    assert not_loads(Serializer(SECRET), token)
    explicit = Serializer(SECRET, signer=Sha256Signer, signer_kwargs={"digest_method": hashlib.sha1}).dumps(OBJ)
    assert Serializer(SECRET).loads(explicit) == OBJ


def test_n000169_fallbacks_tried_in_order_and_token_loads_under_any():  # spec: N-000169 N-000170 N-000171 N-000172 N-000038
    old = Serializer(SECRET, signer_kwargs={"key_derivation": "concat"}).dumps(OBJ)
    modern = Serializer(
        SECRET,
        signer_kwargs={"key_derivation": "django-concat"},
        fallback_signers=[{"key_derivation": "concat"}],
    )
    assert modern.loads(old) == OBJ
    assert modern.loads(modern.dumps(OBJ)) == OBJ

    as_pair = Serializer(
        SECRET,
        signer_kwargs={"key_derivation": "django-concat"},
        fallback_signers=[(Signer, {"key_derivation": "concat"})],
    )
    assert as_pair.loads(old) == OBJ


def test_n000185_no_configuration_verifies_is_signature_mismatch():  # spec: N-000185 N-000169
    token = Serializer("other").dumps(OBJ)
    serializer = Serializer(SECRET, fallback_signers=[{"key_derivation": "concat"}])
    with pytest.raises(BadSignature) as info:
        serializer.loads(token)
    assert not isinstance(info.value, BadPayload)


def test_n000358_illegal_separator_raises_before_any_token():  # spec: N-000358 N-000337
    with pytest.raises(ValueError):
        Serializer(SECRET, signer_kwargs={"sep": "a"})


def test_n000351_default_serializer_is_json():  # spec: N-000351 N-000350
    assert Serializer(SECRET).serializer is json


def test_n000371_non_text_key_material_and_list_of_secrets():  # spec: N-000289 N-000290 N-000291
    # Signing uses the newest key; a token verifies under any key still in the list.
    token = Serializer([b"old", "new"]).dumps(OBJ)
    assert Serializer("new").loads(token) == OBJ
    assert Serializer(["older", b"new"]).loads(token) == OBJ
    assert not_loads(Serializer(b"old"), token)


# Timed serializer.


def test_n000186_timed_serializer_returns_signing_time_and_enforces_age(monkeypatch):  # spec: N-000186 N-000190 N-000206 N-000207
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    token = TimedSerializer(SECRET).dumps(OBJ)
    obj, signed_at = TimedSerializer(SECRET).loads(token, return_timestamp=True)
    assert obj == OBJ
    assert signed_at == datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    monkeypatch.setattr("time.time", lambda: 1_700_000_100)
    with pytest.raises(SignatureExpired) as info:
        TimedSerializer(SECRET).loads(token, max_age=50)
    assert info.value.payload == json.dumps(OBJ).encode("utf-8")
    assert TimedSerializer(SECRET).loads(token, max_age=100) == OBJ


def test_n000214_unsafe_load_with_max_age_returns_false_object_for_expired(monkeypatch):  # spec: N-000214 N-000183
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    token = TimedSerializer(SECRET).dumps(OBJ)
    monkeypatch.setattr("time.time", lambda: 1_700_000_100)
    assert TimedSerializer(SECRET).loads_unsafe(token, max_age=10) == (False, OBJ)
    assert TimedSerializer(SECRET).loads_unsafe(token) == (True, OBJ)


def test_n000215_verified_but_expired_ends_fallback_search(monkeypatch):  # spec: N-000215 N-000216
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    token = TimedSerializer(SECRET, signer_kwargs={"key_derivation": "concat"}).dumps(OBJ)
    monkeypatch.setattr("time.time", lambda: 1_700_000_100)
    serializer = TimedSerializer(
        SECRET,
        signer_kwargs={"key_derivation": "django-concat"},
        fallback_signers=[{"key_derivation": "concat"}],
    )
    # The first fallback verifies the signature but the token is too old: refused as expired.
    with pytest.raises(SignatureExpired):
        serializer.loads(token, max_age=10)
    assert serializer.loads(token, max_age=1000) == OBJ


def test_n000187_timed_serializer_missing_timestamp_on_untimed_token():  # spec: N-000217 N-000227
    token = Serializer(SECRET).dumps(OBJ)
    with pytest.raises(BadTimeSignature) as info:
        TimedSerializer(SECRET).loads(token)
    assert info.value.reason == "missing"


def test_n000197_timed_and_untimed_share_default_salt_and_signature(monkeypatch):  # spec: N-000195 N-000196 N-000197
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    token = TimedSerializer(SECRET).dumps(OBJ)
    # The signature verifies on the untimed helper, so the refusal is about the payload.
    with pytest.raises(BadPayload):
        Serializer(SECRET).loads(token)
    assert URLSafeTimedSerializer(SECRET).loads(URLSafeTimedSerializer(SECRET).dumps(OBJ)) == OBJ


# URL-safe helpers.

URL_SAFE = re.compile(r"[A-Za-z0-9._-]*")


def test_n000234_url_safe_dump_returns_text_in_restricted_alphabet():  # spec: N-000234 N-000235 N-000230
    token = URLSafeSerializer(SECRET).dumps({"name": "Zoë", "v": "x" * 50})
    assert isinstance(token, str)
    assert URL_SAFE.fullmatch(token)


def test_n000236_url_safe_default_json_is_compact():  # spec: N-000236 N-000066 N-000371
    token = URLSafeSerializer(SECRET).dumps({"a": [1, 2], "b": "x y"})
    body = token.split(".")[0]
    raw = _b64_decode(body)
    assert raw == b'{"a":[1,2],"b":"x y"}'


def test_n000231_compression_used_only_when_it_shortens_token():  # spec: N-000231 N-000238 N-000240
    short = URLSafeSerializer(SECRET).dumps({"a": 1})
    assert not short.startswith(".")
    repetitive = URLSafeSerializer(SECRET).dumps({"data": "abc" * 200})
    assert repetitive.startswith(".")
    plain_section = _b64_encode(json.dumps({"data": "abc" * 200}, separators=(",", ":")).encode())
    assert len(repetitive.rsplit(".", 1)[0]) < len(plain_section)


def test_n000241_compressed_payload_marked_by_leading_separator_and_loads_everywhere():  # spec: N-000241 N-000242 N-000243 N-000239
    obj = {"data": "x" * 500}
    token = URLSafeSerializer(SECRET).dumps(obj)
    assert token.startswith(".")
    assert URLSafeSerializer(SECRET).loads(token) == obj
    assert URLSafeSerializer(SECRET, signer_kwargs={"sep": "|"}).loads(
        URLSafeSerializer(SECRET, signer_kwargs={"sep": "|"}).dumps(obj)
    ) == obj


def test_n000247_payload_not_valid_url_safe_base64_is_payload_decode_failure():  # spec: N-000247 N-000250 N-000246
    serializer = URLSafeSerializer(SECRET)
    token = Signer(SECRET).sign(b"not*base64")
    with pytest.raises(BadPayload):
        serializer.loads(token)


def test_n000248_marked_compressed_but_not_a_stream_is_payload_decode_failure():  # spec: N-000248 N-000250
    serializer = URLSafeSerializer(SECRET)
    bad = b"." + _b64_encode(b"definitely not zlib").encode("ascii")
    token = Signer(SECRET).sign(bad)
    with pytest.raises(BadPayload):
        serializer.loads(token)


def test_n000249_payload_that_does_not_deserialize_is_payload_decode_failure():  # spec: N-000249 N-000250
    serializer = URLSafeSerializer(SECRET)
    token = Signer(SECRET).sign(_b64_encode(b"{not json"))
    with pytest.raises(BadPayload):
        serializer.loads(token)


def test_n000244_url_safe_timed_round_trip_compressed_and_plain(monkeypatch):  # spec: N-000244 N-000245 N-000233 N-000316
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    serializer = URLSafeTimedSerializer(SECRET)
    tokens = []
    for obj in ({"a": 1}, {"data": "y" * 400}):
        token = serializer.dumps(obj)
        tokens.append(token)
        assert URL_SAFE.fullmatch(token)
        obj_back, signed_at = serializer.loads(token, return_timestamp=True)
        assert obj_back == obj
        assert signed_at.tzinfo is timezone.utc
    monkeypatch.setattr("time.time", lambda: 1_700_000_600)
    with pytest.raises(SignatureExpired):
        serializer.loads(tokens[0], max_age=60)
    assert serializer.loads(tokens[1], max_age=600) == {"data": "y" * 400}


def test_n000246_url_safe_tampered_compressed_token_is_signature_mismatch():  # spec: N-000246 N-000181
    serializer = URLSafeSerializer(SECRET)
    token = serializer.dumps({"data": "z" * 300})
    head, sig = token.rsplit(".", 1)
    flipped = head[:-1] + ("A" if head[-1] != "A" else "B")
    with pytest.raises(BadSignature) as info:
        serializer.loads(flipped + "." + sig)
    assert not isinstance(info.value, BadPayload)


def test_n000232_url_safe_serializer_satisfies_fallbacks_and_salt():  # spec: N-000232 N-000169 N-000160
    old = URLSafeSerializer(SECRET, signer_kwargs={"key_derivation": "concat"}).dumps({"x": 1})
    modern = URLSafeSerializer(
        SECRET,
        signer_kwargs={"key_derivation": "django-concat"},
        fallback_signers=[{"key_derivation": "concat"}],
    )
    assert modern.loads(old) == {"x": 1}
    salted = URLSafeSerializer(SECRET, salt="a").dumps({"x": 1}, salt="b")
    assert URLSafeSerializer(SECRET, salt="a").loads(salted, salt="b") == {"x": 1}


def test_n000045_url_safe_round_trips_mapping_and_text():  # spec: N-000045 N-000243
    serializer = URLSafeSerializer(SECRET)
    obj = {"emoji": "🙂", "nested": {"k": [1, 2, 3]}}
    assert serializer.loads(serializer.dumps(obj)) == obj


def test_n000373_refusals_are_all_bad_data_subclasses():  # spec: N-000373 N-000374 N-000375
    for cls in (BadSignature, BadTimeSignature, SignatureExpired, BadPayload):
        assert issubclass(cls, BadData)
        assert issubclass(cls, Exception)


def test_n000226_expiry_is_never_a_successful_load(monkeypatch):  # spec: N-000226
    monkeypatch.setattr("time.time", lambda: 1_700_000_000)
    token = TimedSerializer(SECRET).dumps(OBJ)
    monkeypatch.setattr("time.time", lambda: 1_700_001_000)
    with pytest.raises(SignatureExpired):
        TimedSerializer(SECRET).loads(token, max_age=1)


def test_n000174_public_names_importable_from_root():  # spec: N-000277 N-000278 N-000279 N-000280 N-000287
    for name in (
        "Signer",
        "TimestampSigner",
        "Serializer",
        "TimedSerializer",
        "URLSafeSerializer",
        "URLSafeTimedSerializer",
        "HMACAlgorithm",
        "NoneAlgorithm",
        "BadData",
        "BadSignature",
        "BadTimeSignature",
        "SignatureExpired",
        "BadPayload",
    ):
        assert isinstance(getattr(signtoken, name), type), name


def test_n000275_library_calls_raise_instead_of_exiting():  # spec: N-000275 N-000276 N-000274
    with pytest.raises(BadData):
        Serializer(SECRET).loads("definitely not a token")


class _TextDump:
    def dumps(self, obj, **kwargs):
        return obj

    def loads(self, data):
        return json.loads(data)


def _b64_encode(data: bytes) -> str:
    import base64

    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64_decode(text: str) -> bytes:
    import base64

    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def not_loads(serializer, token) -> bool:
    try:
        serializer.loads(token)
    except BadData:
        return True
    return False
