import base64
import datetime
import hashlib
import hmac
import time
from collections.abc import Iterable

from .exc import BadSignature, BadTimeSignature, SignatureExpired

DEFAULT_SALT = b"signtoken.signer"
_BAD_SEP = set(b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_=")


def want_bytes(s, encoding="utf-8"):
    if isinstance(s, str):
        return s.encode(encoding)
    return bytes(s)


def b64e(data: bytes) -> bytes:
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def b64d(data) -> bytes:
    data = want_bytes(data)
    data += b"=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data)


class SigningAlgorithm:
    def get_signature(self, key, value):
        raise NotImplementedError

    def verify_signature(self, key, value, sig):
        return hmac.compare_digest(sig, self.get_signature(key, value))


class NoneAlgorithm(SigningAlgorithm):
    def get_signature(self, key, value):
        return b""


class HMACAlgorithm(SigningAlgorithm):
    default_digest_method = hashlib.sha1

    def __init__(self, digest_method=None):
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method

    def get_signature(self, key, value):
        return hmac.new(key, msg=value, digestmod=self.digest_method).digest()


class Signer:
    default_digest_method = staticmethod(hashlib.sha1)
    default_key_derivation = "django-concat"

    def __init__(self, secret_key, salt=None, sep=".", key_derivation=None,
                 digest_method=None, algorithm=None):
        if isinstance(secret_key, (str, bytes, bytearray)):
            secret_key = [secret_key]
        self.secret_keys = [want_bytes(k) for k in secret_key]
        if not self.secret_keys:
            raise ValueError("secret_key must not be empty")
        self.sep = want_bytes(sep)
        if not self.sep or any(c in _BAD_SEP for c in self.sep):
            raise ValueError("Invalid separator")
        self.salt = want_bytes(DEFAULT_SALT if salt is None else salt)
        if key_derivation is None:
            key_derivation = self.default_key_derivation
        if key_derivation not in ("concat", "django-concat", "hmac", "none"):
            raise ValueError("Unknown key derivation method")
        self.key_derivation = key_derivation
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method
        if algorithm is None:
            algorithm = HMACAlgorithm(self.digest_method)
        self.algorithm = algorithm

    @property
    def secret_key(self):
        return self.secret_keys[-1]

    def derive_key(self, secret_key=None):
        if secret_key is None:
            secret_key = self.secret_keys[-1]
        else:
            secret_key = want_bytes(secret_key)
        kd = self.key_derivation
        if kd == "concat":
            return self.digest_method(self.salt + secret_key).digest()
        if kd == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret_key).digest()
        if kd == "hmac":
            mac = hmac.new(secret_key, digestmod=self.digest_method)
            mac.update(self.salt)
            return mac.digest()
        return secret_key

    def get_signature(self, value):
        value = want_bytes(value)
        key = self.derive_key()
        return b64e(self.algorithm.get_signature(key, value))

    def sign(self, value):
        value = want_bytes(value)
        return value + self.sep + self.get_signature(value)

    def verify_signature(self, value, sig):
        try:
            sig = b64d(sig)
        except Exception:
            return False
        value = want_bytes(value)
        for secret_key in reversed(self.secret_keys):
            key = self.derive_key(secret_key)
            if self.algorithm.verify_signature(key, value, sig):
                return True
        return False

    def unsign(self, signed_value):
        signed_value = want_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature("No %r found in value" % self.sep)
        value, sig = signed_value.rsplit(self.sep, 1)
        if self.verify_signature(value, sig):
            return value
        raise BadSignature("Signature does not match", payload=value)

    def validate(self, signed_value):
        try:
            self.unsign(signed_value)
            return True
        except BadSignature:
            return False


def _int_to_bytes(n):
    return n.to_bytes((n.bit_length() + 7) // 8, "big")


def _utc(ts):
    return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc)


class TimestampSigner(Signer):
    def get_timestamp(self):
        return int(time.time())

    def timestamp_to_datetime(self, ts):
        return _utc(ts)

    def sign(self, value):
        value = want_bytes(value)
        ts = b64e(_int_to_bytes(self.get_timestamp()))
        value = value + self.sep + ts
        return value + self.sep + self.get_signature(value)

    def _decode_time(self, ts_bytes):
        """Return (seconds, datetime) or raise ValueError."""
        if len(ts_bytes) > 11:
            raise ValueError("too long")
        try:
            secs = int.from_bytes(b64d(ts_bytes), "big")
            return secs, _utc(secs)
        except Exception as e:
            raise ValueError(str(e))

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        try:
            result = super().unsign(signed_value)
            sig_error = None
        except BadSignature as e:
            sig_error = e
            result = None

        if sig_error is not None:
            payload = sig_error.payload
            if payload is None or self.sep not in payload:
                raise sig_error
            value, ts_bytes = payload.rsplit(self.sep, 1)
            try:
                _, dt = self._decode_time(ts_bytes)
            except ValueError:
                raise BadTimeSignature("Malformed timestamp", payload=value,
                                       date_signed=None, reason="malformed")
            raise BadTimeSignature("Signature does not match", payload=value,
                                   date_signed=dt)

        if self.sep not in result:
            raise BadTimeSignature("timestamp missing", payload=result,
                                   date_signed=None, reason="missing")
        value, ts_bytes = result.rsplit(self.sep, 1)
        try:
            secs, dt = self._decode_time(ts_bytes)
        except ValueError:
            raise BadTimeSignature("Malformed timestamp", payload=value,
                                   date_signed=None, reason="malformed")
        if max_age is not None:
            age = int(time.time()) - secs
            if age > max_age:
                raise SignatureExpired("Signature age %s > %s seconds" % (age, max_age),
                                       payload=value, date_signed=dt)
            if age < 0:
                raise SignatureExpired("Signature age %s < 0 seconds" % age,
                                       payload=value, date_signed=dt)
        if return_timestamp:
            return value, dt
        return value

    def validate(self, signed_value, max_age=None):
        try:
            self.unsign(signed_value, max_age=max_age)
            return True
        except BadSignature:
            return False
