import json
import zlib

from .exc import BadPayload, BadSignature, SignatureExpired
from .signer import Signer, TimestampSigner, b64d, b64e, want_bytes, DEFAULT_SALT


class _CompactJSON:
    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(data, **kwargs):
        return json.loads(data, **kwargs)


class Serializer:
    default_signer = Signer
    default_serializer = json
    default_fallback_signers = ()

    def __init__(self, secret_key, salt=None, serializer=None, serializer_kwargs=None,
                 signer=None, signer_kwargs=None, fallback_signers=None):
        self.secret_key = secret_key
        self.salt = DEFAULT_SALT if salt is None else salt
        if serializer is None:
            serializer = self.default_serializer
        self.serializer = serializer
        self.is_text_serializer = isinstance(serializer.dumps({}), str)
        self.serializer_kwargs = dict(serializer_kwargs or {})
        if signer is None:
            signer = self.default_signer
        self.signer = signer
        self.signer_kwargs = dict(signer_kwargs or {})
        if fallback_signers is None:
            fallback_signers = list(self.default_fallback_signers)
        self.fallback_signers = list(fallback_signers)
        # fail early on illegal signer options
        self.make_signer(None)

    def make_signer(self, salt=None):
        if salt is None:
            salt = self.salt
        return self.signer(self.secret_key, salt=salt, **self.signer_kwargs)

    def iter_unsigners(self, salt=None):
        if salt is None:
            salt = self.salt
        yield self.make_signer(salt)
        for fb in self.fallback_signers:
            if isinstance(fb, dict):
                cls, kw = self.signer, fb
            elif isinstance(fb, tuple):
                cls, kw = fb
            else:
                cls, kw = fb, self.signer_kwargs
            yield cls(self.secret_key, salt=salt, **kw)

    def load_payload(self, payload, serializer=None):
        if serializer is None:
            serializer = self.serializer
            is_text = self.is_text_serializer
        else:
            is_text = isinstance(serializer.dumps({}), str)
        try:
            if is_text:
                payload = payload.decode("utf-8")
            return serializer.loads(payload)
        except Exception as e:
            raise BadPayload("Could not load the payload because an exception "
                             "occurred on unserializing the data.",
                             original_error=e) from e

    def dump_payload(self, obj):
        return want_bytes(self.serializer.dumps(obj, **self.serializer_kwargs))

    def dumps(self, obj, salt=None):
        payload = self.dump_payload(obj)
        rv = self.make_signer(salt).sign(payload)
        if self.is_text_serializer:
            return rv.decode("utf-8")
        return rv

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt))

    def _unsign(self, s, salt, **kw):
        s = want_bytes(s)
        last = None
        for signer in self.iter_unsigners(salt):
            try:
                return signer.unsign(s, **kw)
            except SignatureExpired:
                raise
            except BadSignature as e:
                last = e
        raise last

    def loads(self, s, salt=None, **kw):
        return self.load_payload(self._unsign(s, salt))

    def load(self, f, salt=None):
        return self.loads(f.read(), salt)

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe_impl(s, salt)

    def _loads_unsafe_impl(self, s, salt, load_kwargs=None):
        try:
            return True, self.loads(s, salt=salt, **(load_kwargs or {}))
        except BadSignature as e:
            if e.payload is None:
                return False, None
            try:
                return False, self.load_payload(e.payload)
            except BadPayload:
                return False, None

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt)


class TimedSerializer(Serializer):
    default_signer = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        payload, ts = self._unsign(s, salt, max_age=max_age, return_timestamp=True)
        obj = self.load_payload(payload)
        if return_timestamp:
            return obj, ts
        return obj

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe_impl(s, salt, {"max_age": max_age})

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age,
                          return_timestamp=return_timestamp, salt=salt)

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


class _URLSafeMixin:
    default_serializer = _CompactJSON

    def load_payload(self, payload, *args, **kwargs):
        try:
            sep = want_bytes(self.make_signer(None).sep)
            decompress = False
            if payload.startswith(sep):
                payload = payload[len(sep):]
                decompress = True
            data = b64d(payload)
            if decompress:
                data = zlib.decompress(data)
        except Exception as e:
            raise BadPayload("Could not base64 decode the payload because of "
                             "an exception", original_error=e) from e
        return super().load_payload(data, *args, **kwargs)

    def dump_payload(self, obj):
        raw = super().dump_payload(obj)
        sep = want_bytes(self.make_signer(None).sep)
        compressed = zlib.compress(raw)
        is_compressed = False
        if len(compressed) < len(raw) - 1:
            raw = compressed
            is_compressed = True
        out = b64e(raw)
        if is_compressed:
            out = sep + out
        return out

    def dumps(self, obj, salt=None):
        rv = super().dumps(obj, salt)
        if isinstance(rv, bytes):
            rv = rv.decode("utf-8")
        return rv


class URLSafeSerializer(_URLSafeMixin, Serializer):
    pass


class URLSafeTimedSerializer(_URLSafeMixin, TimedSerializer):
    pass
