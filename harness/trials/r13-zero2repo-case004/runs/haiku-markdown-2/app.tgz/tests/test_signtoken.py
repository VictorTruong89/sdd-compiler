import ast
import hashlib
import io
import time
from datetime import datetime, timezone
from unittest import mock

import pytest

from signtoken import (
    BadData,
    BadPayload,
    BadSignature,
    BadTimeSignature,
    HMACAlgorithm,
    NoneAlgorithm,
    SignatureExpired,
    Serializer,
    Signer,
    TimedSerializer,
    TimestampSigner,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)

T0 = datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
T0_SECONDS = 1_700_000_000


def test_signer_round_trip_and_tamper():
    s = Signer("secret", salt="a")
    token = s.sign("hello.world")
    assert s.unsign(token) == b"hello.world"
    assert s.validate(token)
    tampered = token[:-1] + (b"A" if token[-1:] != b"A" else b"B")
    assert not s.validate(tampered)
    with pytest.raises(BadSignature) as info:
        s.unsign(b"hello.world.AAAA")
    assert info.value.payload == b"hello.world"


def test_signer_wrong_salt_and_no_separator():
    token = Signer("secret", salt="a").sign("v")
    assert not Signer("secret", salt="b").validate(token)
    with pytest.raises(BadSignature) as info:
        Signer("secret").unsign(b"nosep")
    assert info.value.payload is None


def test_signer_rejects_bad_separator():
    with pytest.raises(ValueError):
        Signer("secret", sep="a")
    with pytest.raises(ValueError):
        Signer("secret", sep="-")
    Signer("secret", sep="*")


def test_key_rotation():
    old = Signer("old")
    token = old.sign("v")
    assert Signer(["old", "new"]).unsign(token) == b"v"
    assert Signer(["old", "new"]).sign("w") != old.sign("w")
    assert Signer(["new", "old"]).sign("w") == old.sign("w")
    with pytest.raises(BadSignature):
        Signer("new").unsign(token)


def test_none_algorithm_has_no_tamper_detection():
    s = Signer("k", algorithm=NoneAlgorithm())
    assert s.sign("abc") == b"abc."
    assert s.unsign(b"xyz.") == b"xyz"
    with pytest.raises(BadSignature):
        Signer("k").unsign(b"abc.")


def test_digest_and_derivation_matter():
    token = Signer("k").sign("v")
    assert Signer("k", digest_method=hashlib.sha1).unsign(token) == b"v"
    assert not Signer("k", digest_method=hashlib.sha256).validate(token)
    assert not Signer("k", key_derivation="concat").validate(token)
    with pytest.raises(ValueError):
        Signer("k", key_derivation="bogus")


def test_hmac_default_sha1_signature_length():
    token = Signer("k", algorithm=HMACAlgorithm()).sign("v")
    assert len(token.rsplit(b".", 1)[1]) == 27  # 20 bytes, unpadded base64


def test_timestamp_signer_time_and_expiry():
    s = TimestampSigner("k")
    with mock.patch("time.time", return_value=T0_SECONDS + 0.9):
        token = s.sign("payload.with.dots")
    value, when = s.unsign(token, return_timestamp=True)
    assert value == b"payload.with.dots"
    assert when == T0
    with mock.patch("time.time", return_value=T0_SECONDS + 30):
        assert s.unsign(token, max_age=30) == b"payload.with.dots"
        with pytest.raises(SignatureExpired) as info:
            s.unsign(token, max_age=29)
        assert info.value.payload == b"payload.with.dots"
        assert not s.validate(token, max_age=29)
        assert s.validate(token, max_age=30)


def test_timestamp_in_future_is_expired():
    s = TimestampSigner("k")
    with mock.patch("time.time", return_value=2_000_000_000):
        token = s.sign("v")
    with mock.patch("time.time", return_value=1_999_999_999):
        with pytest.raises(SignatureExpired):
            s.unsign(token, max_age=100)


def test_timestamp_missing_and_malformed():
    s = TimestampSigner("k")
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(Signer("k").sign("v"))
    assert info.value.reason == "missing"
    assert info.value.date_signed is None
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(Signer("k").sign("v.AAAAAAAAAAAAAA"))
    assert info.value.reason == "malformed"


def test_time_signature_failure_carries_payload_and_time():
    s = TimestampSigner("k")
    with mock.patch("time.time", return_value=T0_SECONDS):
        token = s.sign("body")
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(token.replace(b"body", b"bodx", 1))
    assert info.value.payload == b"bodx"
    assert info.value.date_signed == T0
    assert info.value.reason is None


def test_serializer_round_trip_default_json():
    s = Serializer("k", salt="x")
    obj = {"a": [1, 2, {"b": None}], "c": "d e"}
    token = s.dumps(obj)
    assert isinstance(token, str)
    assert s.loads(token) == obj
    assert s.loads(token.encode()) == obj
    assert s.loads_unsafe(token) == (True, obj)
    with pytest.raises(BadSignature):
        s.loads(token + "x")
    with pytest.raises(BadSignature):
        s.loads(token, salt="other")


def test_serializer_streams():
    s = Serializer("k")
    buf = io.StringIO()
    s.dump([1, 2], buf)
    buf.seek(0)
    assert s.load(buf) == [1, 2]


class _LiteralSerializer:
    def dumps(self, obj, **kwargs):
        return repr(obj).encode()

    def loads(self, data):
        return ast.literal_eval(data.decode())


def test_bytes_serializer_returns_bytes():
    s = Serializer("k", serializer=_LiteralSerializer())
    token = s.dumps({"x": 1})
    assert isinstance(token, bytes)
    assert s.loads(token) == {"x": 1}


def test_unsafe_load_and_payload_decode_failure():
    s = Serializer("k")
    token = s.dumps([1])
    assert s.loads_unsafe(token) == (True, [1])
    not_json = Signer("k").sign(b"not json {")
    with pytest.raises(BadPayload):
        s.loads(not_json)
    with pytest.raises(BadPayload):
        s.loads_unsafe(not_json)
    forged = token.replace("[1]", "[2]")
    assert s.loads_unsafe(forged) == (False, [2])
    assert s.loads_unsafe(Signer("k").sign(b"not json {") + b"x") == (False, None)
    assert s.loads_unsafe("nosep") == (False, None)


def test_mismatch_carries_payload_for_inspection():
    s = Serializer("k")
    token = s.dumps({"a": 1})
    body, sig = token.rsplit(".", 1)
    tampered = body.replace('"a": 1', '"a": 2') + "." + sig
    with pytest.raises(BadSignature) as info:
        s.loads(tampered)
    assert info.value.payload is not None
    assert Serializer("k").loads(token) == {"a": 1}


def test_fallback_signers_accept_old_configuration():
    old = Serializer("k", signer_kwargs={"digest_method": hashlib.md5})
    token = old.dumps("v")
    new = Serializer("k", fallback_signers=[{"digest_method": hashlib.md5}])
    assert new.loads(token) == "v"
    assert new.loads_unsafe(token) == (True, "v")
    with pytest.raises(BadSignature):
        Serializer("k").loads(token)


def test_timed_serializer_round_trip_and_expiry():
    s = TimedSerializer("k")
    with mock.patch("time.time", return_value=T0_SECONDS):
        token = s.dumps({"u": 7})
    obj, when = s.loads(token, return_timestamp=True)
    assert obj == {"u": 7}
    assert when == T0
    with mock.patch("time.time", return_value=T0_SECONDS + 100):
        with pytest.raises(SignatureExpired):
            s.loads(token, max_age=50)
        assert s.loads(token, max_age=100) == {"u": 7}
        assert s.loads_unsafe(token, max_age=50) == (False, {"u": 7})


def test_timed_serializer_refuses_untimed_token():
    token = Serializer("k", salt="s").dumps([1])
    with pytest.raises(BadTimeSignature):
        TimedSerializer("k", salt="s").loads(token)


def test_url_safe_alphabet_and_compression():
    s = URLSafeSerializer("k")
    small = s.dumps({"a": 1})
    assert isinstance(small, str)
    assert all(c.isascii() and (c.isalnum() or c in "-_.") for c in small)
    assert not small.startswith(".")
    items = {"items": ["abcdefgh" * 4] * 50}
    big = s.dumps(items)
    assert big.startswith(".")
    assert s.loads(big) == items
    assert s.loads(small) == {"a": 1}
    assert s.loads_unsafe(big) == (True, items)


def test_url_safe_refuses_bad_payload_section():
    s = URLSafeSerializer("k")
    with pytest.raises(BadPayload):
        s.loads(Signer("k").sign(b"!!!"))
    with pytest.raises(BadPayload):
        s.loads(Signer("k").sign(b".AAAA"))


def test_url_safe_timed_round_trip_and_expiry():
    s = URLSafeTimedSerializer("k", salt="u")
    with mock.patch("time.time", return_value=T0_SECONDS):
        token = s.dumps(["x" * 200])
    assert token.count(".") == 3
    obj, when = s.loads(token, return_timestamp=True)
    assert obj == ["x" * 200]
    assert when == T0
    assert s.loads_unsafe(token) == (True, ["x" * 200])
    with mock.patch("time.time", return_value=T0_SECONDS + 10):
        with pytest.raises(SignatureExpired):
            s.loads(token, max_age=1)


def test_signing_past_datetime_range_succeeds_and_is_malformed_when_verified():
    s = TimestampSigner("k")
    with mock.patch("time.time", return_value=1e12):
        token = s.sign("v")
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(token)
    assert info.value.reason == "malformed"


def test_refusals_are_bad_data():
    with pytest.raises(BadData):
        Signer("k").unsign(b"x.y")
