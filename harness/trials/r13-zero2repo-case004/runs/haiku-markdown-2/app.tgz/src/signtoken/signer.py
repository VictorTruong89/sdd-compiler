"""Basic signer and timestamped signer."""

import hashlib
import hmac
import time

from .algorithms import HMACAlgorithm
from .encoding import (
    FORBIDDEN_SEPARATOR_BYTES,
    base64_decode,
    base64_encode,
    decode_time,
    encode_time,
    time_to_datetime,
    to_bytes,
)
from .exc import BadData, BadSignature, BadTimeSignature, SignatureExpired

KEY_DERIVATIONS = ("concat", "django-concat", "hmac", "none")
DEFAULT_KEY_DERIVATION = "django-concat"
DEFAULT_SALT = b"signtoken"


def _normalize_secrets(secret_key):
    if isinstance(secret_key, (str, bytes)):
        keys = [secret_key]
    else:
        keys = list(secret_key)
    if not keys:
        raise ValueError("at least one secret key is required")
    return [to_bytes(key) for key in keys]


def _check_separator(sep):
    sep = to_bytes(sep)
    if not sep:
        raise ValueError("separator must not be empty")
    if any(byte in FORBIDDEN_SEPARATOR_BYTES for byte in sep):
        raise ValueError("separator must not be an ASCII letter, digit, '-', '_' or '='")
    return sep


class Signer:
    """Signs raw byte values as ``<payload><sep><signature>``."""

    default_digest_method = staticmethod(hashlib.sha1)

    def __init__(self, secret_key, salt=None, sep=".", key_derivation=None,
                 digest_method=None, algorithm=None):
        self.secret_keys = _normalize_secrets(secret_key)
        self.salt = DEFAULT_SALT if salt is None else to_bytes(salt)
        self.sep = _check_separator(sep)
        self.key_derivation = DEFAULT_KEY_DERIVATION if key_derivation is None else key_derivation
        if self.key_derivation not in KEY_DERIVATIONS:
            raise ValueError(f"unknown key derivation: {self.key_derivation!r}")
        self.digest_method = (
            self.default_digest_method if digest_method is None else digest_method
        )
        self.algorithm = HMACAlgorithm(self.digest_method) if algorithm is None else algorithm

    def derive_key(self, secret):
        if self.key_derivation == "none":
            return secret
        if self.key_derivation == "hmac":
            return hmac.new(secret, self.salt, self.digest_method).digest()
        if self.key_derivation == "concat":
            return self.digest_method(self.salt + secret).digest()
        return self.digest_method(self.salt + b"signer" + secret).digest()

    def get_signature(self, value):
        """Encoded signature of ``value`` under the newest secret key."""
        key = self.derive_key(self.secret_keys[-1])
        return base64_encode(self.algorithm.get_signature(key, value))

    def verify_signature(self, value, encoded_signature):
        """True if any secret key in the list verifies the encoded signature."""
        try:
            signature = base64_decode(encoded_signature)
        except ValueError:
            return False
        for secret in reversed(self.secret_keys):
            key = self.derive_key(secret)
            if self.algorithm.verify_signature(key, value, signature):
                return True
        return False

    def sign(self, value):
        value = to_bytes(value)
        return value + self.sep + self.get_signature(value)

    def unsign(self, signed_value):
        signed_value = to_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature("No separator found in the token.")
        value, encoded_signature = signed_value.rsplit(self.sep, 1)
        if not self.verify_signature(value, encoded_signature):
            raise BadSignature("Signature does not match.", payload=value)
        return value

    def validate(self, signed_value):
        try:
            self.unsign(signed_value)
        except BadData:
            return False
        return True


class TimestampSigner(Signer):
    """Signs as ``<payload><sep><time><sep><signature>``, with an age check."""

    default_digest_method = staticmethod(hashlib.sha1)

    def sign(self, value):
        value = to_bytes(value)
        stamped = value + self.sep + encode_time(int(time.time()))
        return stamped + self.sep + self.get_signature(stamped)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        signed_value = to_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature("No separator found in the token.")
        signed_part, encoded_signature = signed_value.rsplit(self.sep, 1)

        if not self.verify_signature(signed_part, encoded_signature):
            if self.sep not in signed_part:
                raise BadSignature("Signature does not match.", payload=signed_part)
            value, time_field = signed_part.rsplit(self.sep, 1)
            timestamp = decode_time(time_field)
            date_signed = None if timestamp is None else time_to_datetime(timestamp)
            reason = "malformed" if timestamp is not None and date_signed is None else None
            raise BadTimeSignature(
                "Signature does not match.",
                payload=value,
                date_signed=date_signed,
                reason=reason,
            )

        if self.sep not in signed_part:
            raise BadTimeSignature(
                "Timestamp is missing.", payload=signed_part, reason="missing"
            )
        value, time_field = signed_part.rsplit(self.sep, 1)
        timestamp = decode_time(time_field)
        date_signed = None if timestamp is None else time_to_datetime(timestamp)
        if date_signed is None:
            raise BadTimeSignature("Timestamp is malformed.", payload=value, reason="malformed")

        if max_age is not None:
            age = int(time.time()) - timestamp
            if age < 0 or age > max_age:
                raise SignatureExpired(
                    "Signature is expired.", payload=value, date_signed=date_signed
                )

        if return_timestamp:
            return value, date_signed
        return value

    def validate(self, signed_value, max_age=None):
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadData:
            return False
        return True
