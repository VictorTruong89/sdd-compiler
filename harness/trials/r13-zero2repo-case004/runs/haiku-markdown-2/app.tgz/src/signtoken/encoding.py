"""URL-safe base64 and signing-time encoding helpers."""

import base64
import re
import string
from datetime import datetime, timedelta, timezone

# Characters that can appear in an encoded signature or time field, so they
# cannot be used as separators.
FORBIDDEN_SEPARATOR_BYTES = frozenset(
    string.ascii_letters.encode("ascii") + string.digits.encode("ascii") + b"-_="
)

_URL_SAFE_RE = re.compile(rb"[A-Za-z0-9_-]*")
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def to_bytes(value):
    """Return ``value`` as bytes, encoding text as UTF-8."""
    if isinstance(value, str):
        return value.encode("utf-8")
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise TypeError(f"expected str or bytes, not {type(value).__name__}")


def base64_encode(data):
    """URL-safe base64 without padding."""
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def base64_decode(data):
    """Strict URL-safe base64 decode of unpadded input; raises ValueError."""
    if not _URL_SAFE_RE.fullmatch(data) or len(data) % 4 == 1:
        raise ValueError("not valid URL-safe base64")
    return base64.urlsafe_b64decode(data + b"=" * (-len(data) % 4))


def encode_time(timestamp):
    """Encode whole Unix seconds as at most 11 URL-safe characters."""
    if timestamp < 0:
        raise ValueError("signing time is before the Unix epoch")
    raw = timestamp.to_bytes(max(1, (timestamp.bit_length() + 7) // 8), "big")
    return base64_encode(raw)


def decode_time(data):
    """Return the Unix seconds in a time field, or None if it is not one we wrote."""
    if not 0 < len(data) <= 11:
        return None
    try:
        raw = base64_decode(data)
    except ValueError:
        return None
    timestamp = int.from_bytes(raw, "big")
    if encode_time(timestamp) != data:
        return None
    return timestamp


def time_to_datetime(timestamp):
    """Return a UTC datetime for the Unix seconds, or None if it is unrepresentable."""
    try:
        return _EPOCH + timedelta(seconds=timestamp)
    except (OverflowError, ValueError):
        return None
