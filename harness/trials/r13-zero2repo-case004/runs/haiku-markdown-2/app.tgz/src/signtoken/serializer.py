"""Serialize-and-sign helpers, plain, timestamped and URL-safe."""

import json
import zlib
from collections.abc import Mapping

from .encoding import base64_decode, base64_encode, to_bytes
from .exc import BadPayload, BadSignature, BadTimeSignature, SignatureExpired
from .signer import DEFAULT_SALT, Signer, TimestampSigner

COMPACT_JSON_KWARGS = {"separators": (",", ":")}


class Serializer:
    """Serializes an object and signs the result as ``<serialized><sep><signature>``."""

    default_signer = Signer
    _timed = False
    _url_safe = False

    def __init__(self, secret_key, salt=None, serializer=None, serializer_kwargs=None,
                 signer=None, signer_kwargs=None, fallback_signers=None):
        self.secret_key = secret_key
        self.salt = DEFAULT_SALT if salt is None else to_bytes(salt)
        self.serializer = json if serializer is None else serializer
        self.serializer_kwargs = dict(serializer_kwargs or {})
        self.signer_class = self.default_signer if signer is None else signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])
        self._text_serializer = self._probe_text_serializer()
        # Build the primary signer now so bad signing options fail early.
        next(self._signers(self.salt))

    def _probe_text_serializer(self):
        try:
            return isinstance(self.serializer.dumps(None, **self.serializer_kwargs), str)
        except Exception:
            return False

    def _resolve_salt(self, salt):
        return self.salt if salt is None else to_bytes(salt)

    def _signers(self, salt):
        """Yield the primary signer, then one signer per fallback configuration."""
        yield self.signer_class(self.secret_key, salt=salt, **self.signer_kwargs)
        for item in self.fallback_signers:
            if isinstance(item, Mapping):
                signer_class, kwargs = self.signer_class, item
            elif isinstance(item, tuple):
                signer_class, kwargs = item
            else:
                signer_class, kwargs = item, self.signer_kwargs
            yield signer_class(self.secret_key, salt=salt, **kwargs)

    def _encode_payload(self, raw, sep):
        return raw

    def _decode_payload(self, payload, sep):
        return payload

    def _unsign(self, token, salt, max_age=None):
        """Return ``(signer, payload, signed_at)`` from the first configuration that verifies."""
        first_error = None
        for signer in self._signers(salt):
            try:
                if self._timed:
                    payload, signed_at = signer.unsign(
                        token, max_age=max_age, return_timestamp=True
                    )
                else:
                    payload, signed_at = signer.unsign(token), None
            except BadSignature as error:
                verified = isinstance(error, SignatureExpired) or (
                    isinstance(error, BadTimeSignature) and error.reason is not None
                )
                if verified:
                    raise
                if first_error is None:
                    first_error = error
                continue
            return signer, payload, signed_at
        raise first_error

    def _load_payload(self, payload, sep):
        try:
            data = self._decode_payload(payload, sep)
            if self._text_serializer:
                data = data.decode("utf-8")
            return self.serializer.loads(data)
        except BadPayload:
            raise
        except Exception as error:
            raise BadPayload("Could not deserialize the payload.", original_error=error) from error

    def _loads_unsafe(self, s, max_age, salt):
        token = to_bytes(s)
        salt = self._resolve_salt(salt)
        try:
            signer, payload, _ = self._unsign(token, salt, max_age)
        except BadSignature as error:
            if error.payload is None:
                return False, None
            primary_sep = next(self._signers(salt)).sep
            try:
                return False, self._load_payload(error.payload, primary_sep)
            except BadPayload:
                return False, None
        return True, self._load_payload(payload, signer.sep)

    def dumps(self, obj, salt=None):
        raw = self.serializer.dumps(obj, **self.serializer_kwargs)
        is_text = isinstance(raw, str)
        if is_text:
            raw = raw.encode("utf-8")
        signer = next(self._signers(self._resolve_salt(salt)))
        token = signer.sign(self._encode_payload(raw, signer.sep))
        if is_text or self._url_safe:
            return token.decode("utf-8")
        return token

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        signer, payload, _ = self._unsign(to_bytes(s), self._resolve_salt(salt))
        return self._load_payload(payload, signer.sep)

    def load(self, f, salt=None):
        return self.loads(f.read(), salt=salt)

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe(s, None, salt)

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt=salt)


class _TimedMixin:
    """Timestamped behaviour: default signer, max age and signing time on load."""

    default_signer = TimestampSigner
    _timed = True

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        signer, payload, signed_at = self._unsign(
            to_bytes(s), self._resolve_salt(salt), max_age
        )
        obj = self._load_payload(payload, signer.sep)
        if return_timestamp:
            return obj, signed_at
        return obj

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe(s, max_age, salt)

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


class TimedSerializer(_TimedMixin, Serializer):
    """Serializer whose tokens carry a signing time and support a maximum age."""


class _URLSafeMixin:
    """URL-safe encoding: compact JSON, base64 payload, optional zlib compression."""

    _url_safe = True

    def __init__(self, secret_key, salt=None, serializer=None, serializer_kwargs=None,
                 signer=None, signer_kwargs=None, fallback_signers=None):
        if serializer is None and serializer_kwargs is None:
            serializer_kwargs = COMPACT_JSON_KWARGS
        super().__init__(
            secret_key,
            salt=salt,
            serializer=serializer,
            serializer_kwargs=serializer_kwargs,
            signer=signer,
            signer_kwargs=signer_kwargs,
            fallback_signers=fallback_signers,
        )

    def _encode_payload(self, raw, sep):
        encoded = base64_encode(raw)
        compressed = base64_encode(zlib.compress(raw, 9))
        # Compress only when the marked, compressed section is strictly shorter.
        if len(sep) + len(compressed) < len(encoded):
            return sep + compressed
        return encoded

    def _decode_payload(self, payload, sep):
        compressed = payload.startswith(sep)
        if compressed:
            payload = payload[len(sep):]
        try:
            data = base64_decode(payload)
        except ValueError as error:
            raise BadPayload("Payload is not valid URL-safe base64.", original_error=error) from error
        if compressed:
            try:
                data = zlib.decompress(data)
            except zlib.error as error:
                raise BadPayload("Payload is not a valid compressed stream.", original_error=error) from error
        return data


class URLSafeSerializer(_URLSafeMixin, Serializer):
    """Serializer whose tokens are URL-safe text."""


class URLSafeTimedSerializer(_URLSafeMixin, _TimedMixin, Serializer):
    """URL-safe serializer whose tokens carry a signing time and support a maximum age."""
