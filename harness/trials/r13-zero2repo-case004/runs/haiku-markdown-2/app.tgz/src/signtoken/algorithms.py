"""Signing algorithms used by the signers."""

import hashlib
import hmac


class HMACAlgorithm:
    """HMAC (RFC 2104) over the payload with the given digest; SHA-1 by default."""

    def __init__(self, digest_method=None):
        self.digest_method = hashlib.sha1 if digest_method is None else digest_method

    def get_signature(self, key, value):
        return hmac.new(key, value, self.digest_method).digest()

    def verify_signature(self, key, value, signature):
        return hmac.compare_digest(signature, self.get_signature(key, value))


class NoneAlgorithm:
    """No-op algorithm: the signature is empty and gives no tamper detection."""

    def get_signature(self, key, value):
        return b""

    def verify_signature(self, key, value, signature):
        return hmac.compare_digest(signature, b"")
