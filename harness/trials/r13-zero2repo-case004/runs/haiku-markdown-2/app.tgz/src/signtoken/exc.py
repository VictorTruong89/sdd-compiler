"""Failure classes raised when a token is refused."""


class BadData(Exception):
    """Base class for every refusal raised by signtoken."""

    def __init__(self, message):
        super().__init__(message)
        self.message = message


class BadSignature(BadData):
    """The signature does not verify, or the token has no separator.

    ``payload`` is the unverified payload section as bytes, or None.
    """

    def __init__(self, message, payload=None):
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused.

    ``reason`` is ``"missing"`` or ``"malformed"`` for those refusals, and None
    for a plain time-signature failure. ``date_signed`` is the decoded signing
    time (UTC datetime) when there is one.
    """

    def __init__(self, message, payload=None, date_signed=None, reason=None):
        super().__init__(message, payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The signature verified but the token is older than the maximum age."""

    def __init__(self, message, payload=None, date_signed=None):
        super().__init__(message, payload, date_signed, reason=None)


class BadPayload(BadData):
    """The signature verified but the payload could not be decoded."""

    def __init__(self, message, original_error=None):
        super().__init__(message)
        self.original_error = original_error
