from __future__ import annotations

import json
import zlib

from .exc import BadData, BadPayload, BadSignature, SignatureExpired
from .signer import Signer, TimestampSigner, b64_decode, b64_encode, want_bytes


class _CompactJSON:
    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(data):
        return json.loads(data)


class Serializer:
    default_serializer = json
    default_signer = Signer
    default_salt = b"signtoken.Serializer"
    force_text = False

    def __init__(
        self,
        secret_key,
        salt=None,
        serializer=None,
        serializer_kwargs=None,
        signer=None,
        signer_kwargs=None,
        fallback_signers=None,
    ) -> None:
        self.secret_key = secret_key
        self.salt = want_bytes(self.default_salt if salt is None else salt)
        if serializer is None:
            serializer = self.default_serializer
        self.serializer = serializer
        self.is_text_serializer = isinstance(serializer.dumps({}), str)
        self.serializer_kwargs = dict(serializer_kwargs or {})
        self.signer = signer if signer is not None else self.default_signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])

    # -- payload ---------------------------------------------------------
    def dump_payload(self, obj) -> bytes:
        return want_bytes(self.serializer.dumps(obj, **self.serializer_kwargs))

    def load_payload(self, payload, serializer=None):
        serializer = serializer or self.serializer
        try:
            if self.is_text_serializer:
                return serializer.loads(want_bytes(payload).decode("utf-8"))
            return serializer.loads(want_bytes(payload))
        except Exception as e:
            raise BadPayload(
                "Could not load the payload because an exception occurred on unserializing the data.",
                original_error=e,
            ) from e

    # -- signers ---------------------------------------------------------
    def make_signer(self, salt=None):
        if salt is None:
            salt = self.salt
        return self.signer(self.secret_key, salt=salt, **self.signer_kwargs)

    def iter_unsigners(self, salt=None):
        if salt is None:
            salt = self.salt
        yield self.make_signer(salt)
        for fb in self.fallback_signers:
            if isinstance(fb, dict):
                cls, kwargs = self.signer, fb
            elif isinstance(fb, tuple):
                cls, kwargs = fb
            else:
                cls, kwargs = fb, self.signer_kwargs
            yield cls(self.secret_key, salt=salt, **kwargs)

    def _unsign(self, signer, s, **kw):
        return signer.unsign(s, **kw)

    def _out(self, token: bytes):
        if self.is_text_serializer or self.force_text:
            return token.decode("utf-8")
        return token

    # -- public ----------------------------------------------------------
    def dumps(self, obj, salt=None):
        payload = self.dump_payload(obj)
        return self._out(self.make_signer(salt).sign(payload))

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt))

    def _loads(self, s, salt=None, unsign_kw=None, **_):
        s = want_bytes(s)
        unsign_kw = unsign_kw or {}
        last = None
        for signer in self.iter_unsigners(salt):
            try:
                return self._unsign(signer, s, **unsign_kw)
            except SignatureExpired:
                raise
            except BadSignature as e:
                last = e
        raise last

    def loads(self, s, salt=None):
        return self.load_payload(self._loads(s, salt))

    def load(self, f, salt=None):
        return self.loads(f.read(), salt)

    def _loads_unsafe(self, s, salt=None, unsign_kw=None):
        try:
            return True, self.load_payload(self._loads(s, salt, unsign_kw))
        except BadSignature as e:
            if e.payload is None:
                return False, None
            try:
                return False, self.load_payload(e.payload)
            except BadPayload:
                return False, None

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe(s, salt)

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read())


class TimedSerializer(Serializer):
    default_signer = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        s = want_bytes(s)
        payload, ts = self._loads(
            s, salt, {"max_age": max_age, "return_timestamp": True}
        )
        obj = self.load_payload(payload)
        if return_timestamp:
            return obj, ts
        return obj

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age, return_timestamp, salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        s = want_bytes(s)
        try:
            payload, _ts = self._loads(
                s, salt, {"max_age": max_age, "return_timestamp": True}
            )
            return True, self.load_payload(payload)
        except BadSignature as e:
            if e.payload is None:
                return False, None
            try:
                return False, self.load_payload(e.payload)
            except BadPayload:
                return False, None

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age)


class _URLSafeMixin:
    default_serializer = _CompactJSON
    force_text = True

    def dump_payload(self, obj) -> bytes:
        raw = super().dump_payload(obj)
        compressed = zlib.compress(raw)
        is_compressed = len(compressed) < len(raw) - 1
        data = compressed if is_compressed else raw
        encoded = b64_encode(data)
        if is_compressed:
            encoded = self._sep() + encoded
        return encoded

    def _sep(self) -> bytes:
        return self.make_signer().sep

    def load_payload(self, payload, serializer=None):
        payload = want_bytes(payload)
        try:
            sep = self._sep()
            decompress = payload.startswith(sep)
            if decompress:
                payload = payload[len(sep):]
            data = b64_decode(payload)
            if decompress:
                data = zlib.decompress(data)
        except Exception as e:
            raise BadPayload(
                "Could not decode the payload.", original_error=e
            ) from e
        return super().load_payload(data, serializer)


class URLSafeSerializer(_URLSafeMixin, Serializer):
    pass


class URLSafeTimedSerializer(_URLSafeMixin, TimedSerializer):
    pass
