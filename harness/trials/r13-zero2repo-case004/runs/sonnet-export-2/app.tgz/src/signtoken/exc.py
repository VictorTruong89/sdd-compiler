from __future__ import annotations

import datetime as _dt


class BadData(Exception):
    """Base of all failure classes."""

    def __init__(self, message: str = "") -> None:
        super().__init__(message)
        self.message = message

    def __str__(self) -> str:
        return self.message


class BadSignature(BadData):
    def __init__(self, message: str = "", payload: bytes | None = None) -> None:
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    def __init__(
        self,
        message: str = "",
        payload: bytes | None = None,
        date_signed: _dt.datetime | None = None,
        reason: str | None = None,
    ) -> None:
        super().__init__(message, payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    pass


class BadPayload(BadData):
    def __init__(self, message: str = "", original_error: BaseException | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error
