from __future__ import annotations

import base64
import datetime as _dt
import hashlib
import hmac
import time

from .exc import BadData, BadSignature, BadTimeSignature, SignatureExpired

_B64_ALPHABET = frozenset(
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
)
_EPOCH = _dt.datetime(1970, 1, 1, tzinfo=_dt.timezone.utc)


def want_bytes(s, encoding: str = "utf-8") -> bytes:
    if isinstance(s, str):
        return s.encode(encoding)
    return bytes(s)


def b64_encode(data) -> bytes:
    return base64.urlsafe_b64encode(want_bytes(data)).rstrip(b"=")


def b64_decode(data) -> bytes:
    """Strict decode of unpadded URL-safe base64."""
    data = want_bytes(data)
    if any(c not in _B64_ALPHABET for c in data) or len(data) % 4 == 1:
        raise ValueError("invalid URL-safe base64")
    return base64.urlsafe_b64decode(data + b"=" * (-len(data) % 4))


def int_to_bytes(n: int) -> bytes:
    return n.to_bytes((n.bit_length() + 7) // 8, "big")


def bytes_to_int(b: bytes) -> int:
    return int.from_bytes(b, "big")


class SigningAlgorithm:
    def get_signature(self, key: bytes, value: bytes) -> bytes:
        raise NotImplementedError

    def verify_signature(self, key: bytes, value: bytes, sig: bytes) -> bool:
        return hmac.compare_digest(sig, self.get_signature(key, value))


class NoneAlgorithm(SigningAlgorithm):
    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return b""


class HMACAlgorithm(SigningAlgorithm):
    default_digest_method = staticmethod(hashlib.sha1)

    def __init__(self, digest_method=None) -> None:
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return hmac.new(key, value, self.digest_method).digest()


class Signer:
    default_digest_method = staticmethod(hashlib.sha1)
    default_key_derivation = "django-concat"
    default_salt = b"signtoken.Signer"

    def __init__(
        self,
        secret_key,
        salt=None,
        sep=".",
        key_derivation=None,
        digest_method=None,
        algorithm=None,
    ) -> None:
        if isinstance(secret_key, (str, bytes, bytearray)):
            secret_key = [secret_key]
        self.secret_keys = [want_bytes(k) for k in secret_key]
        if not self.secret_keys:
            raise ValueError("at least one secret key is required")
        self.sep = want_bytes(sep)
        if not self.sep or any(c in _B64_ALPHABET or c == 0x3D for c in self.sep):
            raise ValueError(
                "The given separator cannot be used because it may be contained in the signature itself."
            )
        self.salt = want_bytes(self.default_salt if salt is None else salt)
        if key_derivation is None:
            key_derivation = self.default_key_derivation
        self.key_derivation = key_derivation
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method
        if algorithm is None:
            algorithm = HMACAlgorithm(self.digest_method)
        self.algorithm = algorithm

    @property
    def secret_key(self) -> bytes:
        return self.secret_keys[-1]

    def derive_key(self, secret_key: bytes | None = None) -> bytes:
        if secret_key is None:
            secret_key = self.secret_keys[-1]
        kd = self.key_derivation
        if kd == "concat":
            return self.digest_method(self.salt + secret_key).digest()
        if kd == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret_key).digest()
        if kd == "hmac":
            return hmac.new(secret_key, self.salt, self.digest_method).digest()
        if kd == "none":
            return secret_key
        raise TypeError(f"Unknown key derivation method {kd!r}")

    def get_signature(self, value) -> bytes:
        value = want_bytes(value)
        return b64_encode(self.algorithm.get_signature(self.derive_key(), value))

    def sign(self, value) -> bytes:
        value = want_bytes(value)
        return value + self.sep + self.get_signature(value)

    def verify_signature(self, value, sig) -> bool:
        value = want_bytes(value)
        try:
            sig = want_bytes(sig)
        except Exception:
            return False
        for secret in reversed(self.secret_keys):
            key = self.derive_key(secret)
            expected = b64_encode(self.algorithm.get_signature(key, value))
            if hmac.compare_digest(sig, expected):
                return True
        return False

    def unsign(self, signed_value) -> bytes:
        signed_value = want_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature(f"No {self.sep!r} found in value")
        value, sig = signed_value.rsplit(self.sep, 1)
        if self.verify_signature(value, sig):
            return value
        raise BadSignature(f"Signature {sig!r} does not match", payload=value)

    def validate(self, signed_value) -> bool:
        try:
            self.unsign(signed_value)
            return True
        except BadData:
            return False


class TimestampSigner(Signer):
    def get_timestamp(self) -> int:
        return int(time.time())

    @staticmethod
    def timestamp_to_datetime(ts: int) -> _dt.datetime:
        return _EPOCH + _dt.timedelta(seconds=ts)

    def sign(self, value) -> bytes:
        value = want_bytes(value)
        stamped = value + self.sep + b64_encode(int_to_bytes(self.get_timestamp()))
        return super().sign(stamped)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        sig_error = None
        try:
            result = super().unsign(signed_value)
        except BadSignature as e:
            sig_error = e
            result = e.payload or b""

        if self.sep not in result:
            if sig_error is not None:
                raise sig_error
            raise BadTimeSignature(
                "timestamp missing", payload=result, reason="missing"
            )

        value, ts_bytes = result.rsplit(self.sep, 1)
        ts_int = None
        ts_dt = None
        if len(ts_bytes) <= 11:
            try:
                ts_int = bytes_to_int(b64_decode(ts_bytes))
                ts_dt = self.timestamp_to_datetime(ts_int)
            except (ValueError, OverflowError):
                ts_dt = None
        if ts_dt is None:
            ts_int = None

        if sig_error is not None:
            if ts_dt is None:
                raise BadTimeSignature(
                    str(sig_error), payload=value, reason="malformed"
                )
            raise BadTimeSignature(
                str(sig_error), payload=value, date_signed=ts_dt
            )

        if ts_dt is None:
            raise BadTimeSignature(
                "Malformed timestamp", payload=value, reason="malformed"
            )

        if max_age is not None:
            age = int(time.time()) - ts_int
            if age > max_age:
                raise SignatureExpired(
                    f"Signature age {age} > {max_age} seconds",
                    payload=value,
                    date_signed=ts_dt,
                )
            if age < 0:
                raise SignatureExpired(
                    f"Signature age {age} < 0 seconds",
                    payload=value,
                    date_signed=ts_dt,
                )

        if return_timestamp:
            return value, ts_dt
        return value

    def validate(self, signed_value, max_age=None) -> bool:
        try:
            self.unsign(signed_value, max_age=max_age)
            return True
        except BadData:
            return False
