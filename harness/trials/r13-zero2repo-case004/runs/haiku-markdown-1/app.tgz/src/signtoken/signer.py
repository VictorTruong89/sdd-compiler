"""Basic and timestamped signers."""

import hashlib
import hmac
import string
import time
from datetime import datetime, timezone

from .algorithms import HMACAlgorithm
from .encoding import b64decode, b64encode, to_bytes
from .exc import BadSignature, BadTimeSignature, SignatureExpired

DEFAULT_SALT = "signtoken.signer"
KEY_DERIVATIONS = ("concat", "django-concat", "hmac", "none")
DEFAULT_KEY_DERIVATION = "django-concat"

# A separator containing any of these could appear in a URL-safe encoded signature.
_FORBIDDEN_SEP_CHARS = frozenset((string.ascii_letters + string.digits + "-_=").encode())


def normalize_secret_keys(secret_key):
    """Return a non-empty list of secret keys as bytes, oldest first."""
    if isinstance(secret_key, (str, bytes)):
        keys = [secret_key]
    else:
        keys = list(secret_key)
    if not keys:
        raise ValueError("at least one secret key is required")
    return [to_bytes(key) for key in keys]


def encode_timestamp(value):
    """Encode a whole-second Unix time as URL-safe base64 of its big-endian bytes."""
    raw = value.to_bytes(max(1, (value.bit_length() + 7) // 8), "big")
    return b64encode(raw)


def decode_timestamp(encoded):
    """Return the integer time for a canonical time field, or ``None``."""
    if len(encoded) > 11:
        return None
    try:
        raw = b64decode(encoded)
    except ValueError:
        return None
    value = int.from_bytes(raw, "big")
    if encode_timestamp(value) != encoded:
        return None
    return value


def to_utc_datetime(value):
    """Return the UTC datetime for a Unix time, or ``None`` if it is not representable."""
    try:
        return datetime.fromtimestamp(value, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class Signer:
    """Signs raw byte values: ``<payload><sep><signature>``."""

    default_digest_method = hashlib.sha1

    def __init__(
        self,
        secret_key,
        salt=None,
        sep=".",
        key_derivation=None,
        digest_method=None,
        algorithm=None,
    ):
        self.secret_keys = normalize_secret_keys(secret_key)
        self.salt = to_bytes(DEFAULT_SALT if salt is None else salt)

        self.sep = to_bytes(sep)
        if not self.sep or any(char in _FORBIDDEN_SEP_CHARS for char in self.sep):
            raise ValueError(f"separator {sep!r} is not allowed")

        self.key_derivation = DEFAULT_KEY_DERIVATION if key_derivation is None else key_derivation
        if self.key_derivation not in KEY_DERIVATIONS:
            raise ValueError(f"unknown key derivation {key_derivation!r}")

        # Read through the class so a plain hash function assigned in a subclass body is not bound.
        if digest_method is None:
            digest_method = type(self).default_digest_method
        self.digest_method = digest_method

        self.algorithm = HMACAlgorithm(self.digest_method) if algorithm is None else algorithm

    def derive_key(self, secret_key=None):
        """Derive the signing key from a secret (the newest key by default)."""
        secret = self.secret_keys[-1] if secret_key is None else secret_key
        if self.key_derivation == "concat":
            return self.digest_method(self.salt + secret).digest()
        if self.key_derivation == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret).digest()
        if self.key_derivation == "hmac":
            return hmac.new(secret, self.salt, self.digest_method).digest()
        return secret

    def get_signature(self, value):
        """Return the URL-safe encoded signature of ``value`` under the newest key."""
        raw = self.algorithm.get_signature(self.derive_key(), value)
        return b64encode(raw)

    def sign(self, value):
        value = to_bytes(value)
        return value + self.sep + self.get_signature(value)

    def verify_signature(self, value, encoded_sig):
        try:
            sig = b64decode(encoded_sig)
        except ValueError:
            return False
        for secret in reversed(self.secret_keys):
            key = self.derive_key(secret)
            if self.algorithm.verify_signature(key, value, sig):
                return True
        return False

    def unsign(self, signed_value):
        signed_value = to_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature("No separator found in value")
        value, encoded_sig = signed_value.rsplit(self.sep, 1)
        if self.verify_signature(value, encoded_sig):
            return value
        raise BadSignature("Signature does not match", payload=value)

    def validate(self, signed_value):
        try:
            self.unsign(signed_value)
        except BadSignature:
            return False
        return True


class TimestampSigner(Signer):
    """Signs a value together with its signing time: ``<payload><sep><time><sep><signature>``."""

    def sign(self, value):
        value = to_bytes(value)
        timestamp = encode_timestamp(int(time.time()))
        return super().sign(value + self.sep + timestamp)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        sig_error = None
        try:
            result = Signer.unsign(self, signed_value)
        except BadSignature as exc:
            sig_error = exc
            result = exc.payload or b""

        if self.sep not in result:
            if sig_error is not None:
                raise sig_error
            err = BadTimeSignature("Timestamp missing", payload=result, reason="missing")
            err._verified = True
            raise err

        value, encoded_ts = result.rsplit(self.sep, 1)
        timestamp = decode_timestamp(encoded_ts)

        if sig_error is not None:
            # The time field is only reported when it decodes; a decodable but unrepresentable time is malformed.
            date_signed = None if timestamp is None else to_utc_datetime(timestamp)
            reason = "malformed" if timestamp is not None and date_signed is None else None
            raise BadTimeSignature(
                str(sig_error), payload=value, date_signed=date_signed, reason=reason
            )

        date_signed = None if timestamp is None else to_utc_datetime(timestamp)
        if date_signed is None:
            err = BadTimeSignature("Malformed timestamp", payload=value, reason="malformed")
            err._verified = True
            raise err

        if max_age is not None:
            age = int(time.time()) - timestamp
            if age > max_age:
                raise SignatureExpired("Signature age exceeds maximum", payload=value, date_signed=date_signed)
            if age < 0:
                raise SignatureExpired("Signature age is in the future", payload=value, date_signed=date_signed)

        if return_timestamp:
            return value, date_signed
        return value

    def validate(self, signed_value, max_age=None):
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadSignature:
            return False
        return True
