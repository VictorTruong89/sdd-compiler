"""URL-safe serialize-and-sign helpers."""

import json
import zlib

from .encoding import b64decode, b64encode
from .serializer import Serializer, TimedSerializer
from .signer import TimestampSigner

# Marks a compressed payload section. It is the default separator, which is URL-safe.
_COMPRESSED_MARK = b"."


class _CompactJSON:
    """JSON with no whitespace outside strings."""

    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(data):
        return json.loads(data)


class URLSafeSerializer(Serializer):
    """Serializer whose tokens are URL-safe text and whose payload is compressed when that shortens it."""

    default_serializer = _CompactJSON()
    _always_text = True

    def _encode_payload(self, raw):
        plain = b64encode(raw)
        packed = _COMPRESSED_MARK + b64encode(zlib.compress(raw, 9))
        return packed if len(packed) < len(plain) else plain

    def _decode_payload(self, data):
        compressed = data.startswith(_COMPRESSED_MARK)
        if compressed:
            data = data[len(_COMPRESSED_MARK):]
        raw = b64decode(data)
        return zlib.decompress(raw) if compressed else raw


class URLSafeTimedSerializer(URLSafeSerializer, TimedSerializer):
    """URL-safe serializer with a signing time and a maximum-age check."""

    default_signer = TimestampSigner
