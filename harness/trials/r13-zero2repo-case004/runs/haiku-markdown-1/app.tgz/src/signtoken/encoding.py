"""URL-safe base64 and byte-conversion helpers."""

import base64
import binascii


def to_bytes(value):
    """Return ``value`` as bytes, encoding text as UTF-8."""
    if isinstance(value, str):
        return value.encode("utf-8")
    return bytes(value)


def b64encode(data):
    """URL-safe base64 (RFC 4648 section 5) with the padding removed."""
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def b64decode(data):
    """Strict inverse of :func:`b64encode`.

    Raises ``ValueError`` for anything outside the URL-safe alphabet, for bad
    padding, and for any input that does not re-encode to exactly itself
    (for example a changed trailing bit that decodes to the same bytes).
    """
    if len(data) % 4 == 1:
        raise ValueError("invalid base64 length")
    padded = data + b"=" * (-len(data) % 4)
    try:
        raw = base64.b64decode(padded, altchars=b"-_", validate=True)
    except binascii.Error as exc:
        raise ValueError("invalid base64") from exc
    if b64encode(raw) != data:
        raise ValueError("non-canonical base64")
    return raw
