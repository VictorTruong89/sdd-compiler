"""Failure classes raised when a token is refused."""


class BadData(Exception):
    """Base class for every refusal raised by signtoken."""


class BadSignature(BadData):
    """The signature does not verify, or the token has no separator.

    ``payload`` is the unverified payload section as bytes, or ``None`` when
    the token has none.
    """

    # True only when the signature verified and a later check refused the token.
    # Serializer fallbacks use this to decide whether to keep searching.
    _verified = False

    def __init__(self, message, payload=None):
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused.

    ``reason`` is ``"missing"`` or ``"malformed"`` for those refusals and
    ``None`` otherwise. ``date_signed`` is the decoded UTC signing time when
    there is one.
    """

    def __init__(self, message, payload=None, date_signed=None, reason=None):
        super().__init__(message, payload=payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The signature verified but the token is older than the allowed maximum age."""

    _verified = True

    def __init__(self, message, payload=None, date_signed=None):
        super().__init__(message, payload=payload, date_signed=date_signed, reason=None)


class BadPayload(BadData):
    """The signature verified but the payload could not be decoded or deserialized."""

    def __init__(self, message, original_error=None):
        super().__init__(message)
        self.original_error = original_error
