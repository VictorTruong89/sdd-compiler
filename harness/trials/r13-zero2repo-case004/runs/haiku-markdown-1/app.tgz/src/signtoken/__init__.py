"""Signtoken: sign data so it can be sent to untrusted places and verified on return."""

from .algorithms import HMACAlgorithm, NoneAlgorithm
from .exc import BadData, BadPayload, BadSignature, BadTimeSignature, SignatureExpired
from .serializer import Serializer, TimedSerializer
from .signer import Signer, TimestampSigner
from .url_safe import URLSafeSerializer, URLSafeTimedSerializer

__version__ = "1.0.0"

__all__ = [
    "Signer",
    "TimestampSigner",
    "Serializer",
    "TimedSerializer",
    "URLSafeSerializer",
    "URLSafeTimedSerializer",
    "HMACAlgorithm",
    "NoneAlgorithm",
    "BadData",
    "BadSignature",
    "BadTimeSignature",
    "SignatureExpired",
    "BadPayload",
]
