"""Serialize-and-sign helpers."""

import json

from .encoding import to_bytes
from .exc import BadPayload, BadSignature
from .signer import DEFAULT_SALT, Signer, TimestampSigner, normalize_secret_keys


class Serializer:
    """Serializes an object, then signs the payload: ``<serialized><sep><signature>``."""

    default_signer = Signer
    default_serializer = json
    # Tokens are always text when True; otherwise text only when the dump/load object produces text.
    _always_text = False

    def __init__(
        self,
        secret_key,
        salt=None,
        serializer=None,
        serializer_kwargs=None,
        signer=None,
        signer_kwargs=None,
        fallback_signers=None,
    ):
        self.secret_keys = normalize_secret_keys(secret_key)
        self.salt = to_bytes(DEFAULT_SALT if salt is None else salt)
        self.serializer = self.default_serializer if serializer is None else serializer
        self.serializer_kwargs = dict(serializer_kwargs or {})
        self.signer = self.default_signer if signer is None else signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])
        # Build the primary signer now so bad signer options fail at construction.
        self._signer_for(self.salt)

    def _signer_for(self, salt):
        return self.signer(self.secret_keys, salt=salt, **self.signer_kwargs)

    def _iter_signers(self, salt):
        """Yield the primary signer, then each fallback configuration for each key."""
        salt = self.salt if salt is None else to_bytes(salt)
        yield self._signer_for(salt)
        for fallback in self.fallback_signers:
            if isinstance(fallback, dict):
                signer_cls, kwargs = self.signer, fallback
            elif isinstance(fallback, tuple):
                signer_cls, kwargs = fallback
            else:
                signer_cls, kwargs = fallback, self.signer_kwargs
            for key in self.secret_keys:
                yield signer_cls(key, salt=salt, **kwargs)

    def _unsign_all(self, s, salt, unsign):
        """Try each configuration in order; return the first ``(payload, extra)`` that verifies.

        A refusal after the signature verified (expiry, missing or malformed
        timestamp) ends the search. A signature mismatch moves on to the next
        configuration; if none verifies, the last mismatch is raised.
        """
        s = to_bytes(s)
        last_error = None
        for signer in self._iter_signers(salt):
            try:
                return unsign(signer, s)
            except BadSignature as err:
                if err._verified:
                    raise
                last_error = err
        raise last_error

    def _encode_payload(self, raw):
        return raw

    def _decode_payload(self, data):
        return data

    def _load_payload(self, payload):
        try:
            return self.serializer.loads(self._decode_payload(payload))
        except Exception as exc:
            raise BadPayload(f"Could not deserialize signed payload: {exc}", original_error=exc) from exc

    def dumps(self, obj, salt=None):
        raw = self.serializer.dumps(obj, **self.serializer_kwargs)
        token = self._signer_for(self.salt if salt is None else salt).sign(
            self._encode_payload(to_bytes(raw))
        )
        if self._always_text or isinstance(raw, str):
            return token.decode("utf-8")
        return token

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        payload, _ = self._unsign_all(s, salt, lambda signer, data: (signer.unsign(data), None))
        return self._load_payload(payload)

    def load(self, f, salt=None):
        return self.loads(f.read(), salt=salt)

    def _loads_unsafe(self, s, salt, unsign):
        try:
            payload, _ = self._unsign_all(s, salt, unsign)
        except BadSignature as err:
            if err.payload is None:
                return False, None
            try:
                return False, self._load_payload(err.payload)
            except BadPayload:
                return False, None
        return True, self._load_payload(payload)

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe(s, salt, lambda signer, data: (signer.unsign(data), None))

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt=salt)


class TimedSerializer(Serializer):
    """A :class:`Serializer` whose tokens record the signing time and can enforce a maximum age."""

    default_signer = TimestampSigner

    def _timed_unsign(self, max_age):
        def unsign(signer, data):
            return signer.unsign(data, max_age=max_age, return_timestamp=True)

        return unsign

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        payload, signed_at = self._unsign_all(s, salt, self._timed_unsign(max_age))
        obj = self._load_payload(payload)
        if return_timestamp:
            return obj, signed_at
        return obj

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe(s, salt, self._timed_unsign(max_age))

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)
