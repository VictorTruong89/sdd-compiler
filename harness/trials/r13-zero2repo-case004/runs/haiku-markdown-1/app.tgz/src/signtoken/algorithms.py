"""Signing algorithms passed as the ``algorithm`` option of a signer."""

import hashlib
import hmac


class SigningAlgorithm:
    """Produces a raw signature for a derived key and a value."""

    def get_signature(self, key, value):
        raise NotImplementedError

    def verify_signature(self, key, value, sig):
        return hmac.compare_digest(sig, self.get_signature(key, value))


class HMACAlgorithm(SigningAlgorithm):
    """HMAC (RFC 2104) over the value with the configured digest."""

    def __init__(self, digest_method=None):
        self.digest_method = hashlib.sha1 if digest_method is None else digest_method

    def get_signature(self, key, value):
        return hmac.new(key, value, self.digest_method).digest()


class NoneAlgorithm(SigningAlgorithm):
    """No-op algorithm: the signature is always empty and gives no tamper detection."""

    def get_signature(self, key, value):
        return b""
