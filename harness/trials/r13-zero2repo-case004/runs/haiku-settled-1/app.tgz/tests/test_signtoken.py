"""Behavioural tests for signtoken.

Each test names the spec ids it covers in its docstring.
"""

import base64
import hashlib
import io
import json
import zlib
from datetime import timezone

import pytest

from signtoken import (
    BadData,
    BadPayload,
    BadSignature,
    BadTimeSignature,
    HMACAlgorithm,
    NoneAlgorithm,
    SignatureExpired,
    Serializer,
    Signer,
    TimedSerializer,
    TimestampSigner,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)
from signtoken import signer as signer_module


@pytest.fixture
def frozen_clock(monkeypatch):
    """Pin time.time so age checks are deterministic."""
    now = [1_700_000_000.0]
    monkeypatch.setattr(signer_module.time, "time", lambda: now[0])
    return now


# FP-01 / N-000332 N-000333 N-000335 N-000336
def test_signer_round_trip_and_validate():
    s = Signer("secret")
    token = s.sign("hello")
    assert isinstance(token, bytes)
    assert s.unsign(token) == b"hello"
    assert s.validate(token)
    assert not s.validate(token + b"x")


# FP-01 / N-000333 N-000334: payload may contain the separator
def test_payload_may_contain_separator():
    s = Signer("secret")
    assert s.unsign(s.sign(b"a.b.c")) == b"a.b.c"


# FP-01: refused tokens carry the unverified payload section
def test_tampered_token_refused_with_payload():
    s = Signer("secret")
    token = s.sign(b"payload")
    with pytest.raises(BadSignature) as info:
        s.unsign(b"other." + token.rsplit(b".", 1)[1])
    assert info.value.payload == b"other"
    assert not s.validate(b"other." + token.rsplit(b".", 1)[1])


# FP-01: a value with no separator carries no payload
def test_no_separator_refused_without_payload():
    with pytest.raises(BadSignature) as info:
        Signer("secret").unsign(b"nosep")
    assert info.value.payload is None


# FP-01 / N-000337: illegal separators refused at construction
@pytest.mark.parametrize("sep", ["a", "Z", "7", "-", "_", "="])
def test_illegal_separator_refused(sep):
    with pytest.raises(ValueError):
        Signer("secret", sep=sep)


# FP-01: other separators accepted
def test_legal_separator_accepted():
    s = Signer("secret", sep="~")
    assert s.unsign(s.sign("v")) == b"v"


# FP-01 / N-000339: unknown key derivation refused
def test_unknown_key_derivation_refused():
    with pytest.raises(ValueError):
        Signer("secret", key_derivation="bogus")


# FP-01: every built-in scheme round-trips; schemes do not interchange
@pytest.mark.parametrize("scheme", ["concat", "django-concat", "hmac", "none"])
def test_key_derivation_schemes_round_trip(scheme):
    s = Signer("secret", key_derivation=scheme)
    assert s.unsign(s.sign("v")) == b"v"


def test_key_derivation_schemes_do_not_interchange():
    tokens = {
        scheme: Signer("secret", key_derivation=scheme).sign("v")
        for scheme in ["concat", "django-concat", "hmac", "none"]
    }
    for scheme, token in tokens.items():
        for other in tokens:
            if other != scheme:
                assert not Signer("secret", key_derivation=other).validate(token)


# FP-01: salt isolates contexts; default salt interchanges between identical signers
def test_salt_isolation_and_default_salt():
    assert not Signer("k", salt="a").validate(Signer("k", salt="b").sign("v"))
    assert Signer("k").validate(Signer("k").sign("v"))


# FP-01: key rotation accepts any listed key; signs with the newest
def test_key_rotation():
    old_token = Signer("old").sign("v")
    assert Signer(["old", "new"]).validate(old_token)
    assert not Signer(["new"]).validate(old_token)
    new_token = Signer(["old", "new"]).sign("v")
    assert Signer(["new"]).validate(new_token)
    assert not Signer(["old"]).validate(new_token)


# FP-01: digest default SHA-1; explicit SHA-1 matches; different digests differ
def test_digest_default_and_explicit():
    assert Signer("k").sign("v") == Signer("k", digest_method=hashlib.sha1).sign("v")
    assert not Signer("k", digest_method=hashlib.sha256).validate(Signer("k").sign("v"))


# FP-01: a subclass may set its own default digest; a digest argument wins
def test_subclass_default_digest():
    class SHA256Signer(Signer):
        default_digest_method = staticmethod(hashlib.sha256)

    assert SHA256Signer("k").sign("v") == Signer("k", digest_method=hashlib.sha256).sign("v")
    assert SHA256Signer("k", digest_method=hashlib.sha1).sign("v") == Signer("k").sign("v")


# FP-01 / N-000347 N-000349: no-op algorithm round-trips but detects nothing
def test_none_algorithm_has_no_tamper_detection():
    s = Signer("k", algorithm=NoneAlgorithm())
    token = s.sign("v")
    assert token == b"v."
    assert s.unsign(token) == b"v"
    assert s.validate(b"changed.")
    assert not Signer("k").validate(token)
    assert not s.validate(Signer("k").sign("v"))


# FP-01: HMAC algorithm may pick its own digest
def test_hmac_algorithm_digest():
    token = Signer("k", algorithm=HMACAlgorithm(hashlib.sha256)).sign("v")
    assert Signer("k", algorithm=HMACAlgorithm(hashlib.sha256)).validate(token)
    assert not Signer("k").validate(token)


# N-000347: HMAC with no digest uses SHA-1
def test_hmac_algorithm_default_digest_is_sha1():
    assert HMACAlgorithm().digest_method is hashlib.sha1


# FP-03 / N-000341-N-000346
def test_timestamp_signer_round_trip_and_return_timestamp(frozen_clock):
    s = TimestampSigner("k")
    token = s.sign("v")
    payload, signed_at = s.unsign(token, return_timestamp=True)
    assert payload == b"v"
    assert signed_at.tzinfo == timezone.utc
    assert int(signed_at.timestamp()) == 1_700_000_000
    assert s.unsign(token) == b"v"


def test_timestamp_signer_max_age(frozen_clock):
    s = TimestampSigner("k")
    token = s.sign("v")
    frozen_clock[0] += 10
    assert s.unsign(token, max_age=10) == b"v"
    assert s.validate(token, max_age=10)
    frozen_clock[0] += 1
    with pytest.raises(SignatureExpired) as info:
        s.unsign(token, max_age=10)
    assert info.value.payload == b"v"
    assert info.value.date_signed.tzinfo == timezone.utc
    assert not s.validate(token, max_age=10)


def test_timestamp_signer_future_token_is_expired(frozen_clock):
    s = TimestampSigner("k")
    token = s.sign("v")
    frozen_clock[0] -= 100
    with pytest.raises(SignatureExpired):
        s.unsign(token, max_age=1000)


def test_timestamp_signer_tampered_time_is_time_signature_failure(frozen_clock):
    s = TimestampSigner("k")
    value, time_field, sig = s.sign("v").split(b".")
    forged = b".".join([value, b"AAAAAAAAAA", sig])
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(forged)
    assert info.value.reason is None
    assert info.value.payload == b"v"
    assert info.value.date_signed is not None


def test_timestamp_signer_missing_timestamp(frozen_clock):
    token = Signer("k").sign("v")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(token)
    assert info.value.reason == "missing"
    assert info.value.date_signed is None


def test_timestamp_signer_malformed_timestamp(frozen_clock):
    s = TimestampSigner("k")
    stamped = b"v." + b"A" * 12
    token = stamped + b"." + s.get_signature(stamped)
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(token)
    assert info.value.reason == "malformed"


def test_timestamp_signer_plain_mismatch_is_not_time_signature(frozen_clock):
    with pytest.raises(BadSignature) as info:
        TimestampSigner("k").unsign(b"nosep")
    assert not isinstance(info.value, BadTimeSignature)


# FP-02 / N-000359-N-000367
def test_serializer_round_trip_text_and_bytes():
    s = Serializer("k")
    token = s.dumps({"a": [1, 2]})
    assert isinstance(token, str)
    assert s.loads(token) == {"a": [1, 2]}
    assert s.loads(token.encode("utf-8")) == {"a": [1, 2]}


def test_serializer_default_payload_is_json():
    token = Serializer("k").dumps({"a": 1})
    payload = token.rsplit(".", 1)[0]
    assert payload == '{"a": 1}'


def test_serializer_bytes_serializer_returns_bytes():
    class BytesJSON:
        dumps = staticmethod(lambda obj, **kw: json.dumps(obj).encode("utf-8"))
        loads = staticmethod(lambda data: json.loads(data))

    s = Serializer("k", serializer=BytesJSON)
    token = s.dumps([1])
    assert isinstance(token, bytes)
    assert s.loads(token) == [1]


def test_serializer_file_streams():
    s = Serializer("k")
    buf = io.StringIO()
    s.dump({"x": 1}, buf)
    buf.seek(0)
    assert s.load(buf) == {"x": 1}
    buf.seek(0)
    assert s.load_unsafe(buf) == (True, {"x": 1})


def test_serializer_per_call_salt():
    s = Serializer("k")
    token = s.dumps("v", salt="other")
    assert s.loads(token, salt="other") == "v"
    with pytest.raises(BadSignature):
        s.loads(token)


def test_serializer_serializer_kwargs_passed_to_dumps():
    s = Serializer("k", serializer_kwargs={"sort_keys": True})
    assert s.dumps({"b": 1, "a": 2}).startswith('{"a": 2, "b": 1}.')


def test_serializer_tampered_refused_and_unsafe_reports_invalid():
    s = Serializer("k")
    token = s.dumps({"a": 1})
    tampered = token.replace('"a": 1', '"a": 2')
    with pytest.raises(BadSignature):
        s.loads(tampered)
    assert s.loads_unsafe(tampered) == (False, {"a": 2})


def test_serializer_unsafe_without_payload_returns_none():
    assert Serializer("k").loads_unsafe("nosep") == (False, None)


def test_serializer_bad_payload_is_payload_decode_failure():
    other = Serializer("k", serializer=_NotJSON())
    token = other.dumps("v")
    with pytest.raises(BadPayload) as info:
        Serializer("k").loads(token)
    assert info.value.original_error is not None
    with pytest.raises(BadPayload):
        Serializer("k").loads_unsafe(token)


class _NotJSON:
    dumps = staticmethod(lambda obj, **kw: "not json at all")

    @staticmethod
    def loads(data):
        return json.loads(data)


def test_serializer_fallback_mapping_is_tried():
    token = Serializer("k").dumps({"a": 1})  # default key derivation
    strict = Serializer("k", signer_kwargs={"key_derivation": "hmac"})
    with pytest.raises(BadSignature):
        strict.loads(token)
    s = Serializer(
        "k",
        signer_kwargs={"key_derivation": "hmac"},
        fallback_signers=[{"key_derivation": "django-concat"}],
    )
    assert s.loads(token) == {"a": 1}
    assert s.loads_unsafe(token) == (True, {"a": 1})


def test_serializer_fallback_pair_and_class_forms():
    token = Serializer("k", signer_kwargs={"digest_method": hashlib.sha256}).dumps([1])
    with pytest.raises(BadSignature):
        Serializer("k").loads(token)
    pair = Serializer("k", fallback_signers=[(Signer, {"digest_method": hashlib.sha256})])
    assert pair.loads(token) == [1]
    # A signer class fallback is built with the helper's current signing options.
    cls_form = Serializer("k", signer_kwargs={"sep": "~"}, fallback_signers=[Signer])
    assert [s.sep for s in cls_form._signers(None)] == [b"~", b"~"]


def test_serializer_bad_fallback_refused_when_all_fail():
    token = Serializer("k", signer_kwargs={"sep": "~"}).dumps([1])
    s = Serializer("k", fallback_signers=[{"key_derivation": "hmac"}])
    with pytest.raises(BadSignature):
        s.loads(token)


def test_serializer_bad_fallback_type_refused():
    with pytest.raises(TypeError):
        Serializer("k", fallback_signers=["nope"])


def test_serializer_illegal_sep_refused_at_construction():
    with pytest.raises(ValueError):
        Serializer("k", signer_kwargs={"sep": "a"})


# FP-03 for serializers
def test_timed_serializer_round_trip_and_age(frozen_clock):
    s = TimedSerializer("k")
    token = s.dumps({"a": 1})
    assert s.loads(token, max_age=5) == {"a": 1}
    obj, signed_at = s.loads(token, return_timestamp=True)
    assert obj == {"a": 1} and signed_at.tzinfo == timezone.utc
    frozen_clock[0] += 6
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=5)
    assert s.loads_unsafe(token, max_age=5) == (False, {"a": 1})


def test_timed_serializer_stream_load_with_max_age(frozen_clock):
    s = TimedSerializer("k")
    buf = io.StringIO(s.dumps("x"))
    assert s.load(buf, max_age=100) == "x"


def test_timed_serializer_missing_timestamp_refused(frozen_clock):
    token = Serializer("k").dumps("x")
    with pytest.raises(BadTimeSignature) as info:
        TimedSerializer("k").loads(token)
    assert info.value.reason == "missing"


def test_timed_serializer_fallback_expired_ends_search(frozen_clock):
    token = TimedSerializer("k", signer_kwargs={"key_derivation": "hmac"}).dumps("x")
    frozen_clock[0] += 100
    s = TimedSerializer("k", fallback_signers=[{"key_derivation": "hmac"}])
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=10)
    assert s.loads(token) == "x"


# FP-04 / N-000368-N-000372
def test_url_safe_serializer_round_trip_and_alphabet():
    s = URLSafeSerializer("k")
    token = s.dumps({"a": 1, "b": "x y"})
    assert isinstance(token, str)
    assert all(c.isalnum() or c in "-_." for c in token)
    assert s.loads(token) == {"a": 1, "b": "x y"}


def test_url_safe_default_is_compact_json():
    s = URLSafeSerializer("k")
    payload = s.dumps({"a": 1}).rsplit(".", 1)[0]
    assert base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)) == b'{"a":1}'


def test_url_safe_compresses_repetitive_payload():
    s = URLSafeSerializer("k")
    token = s.dumps({"x": "a" * 300})
    assert token.startswith(".")
    assert s.loads(token) == {"x": "a" * 300}


def test_url_safe_does_not_compress_small_payload():
    token = URLSafeSerializer("k").dumps({"a": 1})
    assert not token.startswith(".")


def test_url_safe_timed_round_trip(frozen_clock):
    s = URLSafeTimedSerializer("k")
    token = s.dumps({"x": "a" * 200})
    assert s.loads(token, max_age=10) == {"x": "a" * 200}
    frozen_clock[0] += 11
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=10)


def test_url_safe_timed_shares_signature_with_plain_helper(frozen_clock):
    # Same secret and default salt: the plain token verifies under the timed
    # helper's signer, which then refuses it only for lacking a timestamp.
    token = Signer("k").sign(b"abc")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(token)
    assert info.value.reason == "missing"


def test_url_safe_corrupt_payload_is_payload_decode_failure():
    s = URLSafeSerializer("k")
    value = Signer("k").sign(b"!!!")  # signed but not URL-safe base64
    with pytest.raises(BadPayload):
        s.loads(value)
    compressed_garbage = Signer("k").sign(b".AAAA")  # not an intact stream
    with pytest.raises(BadPayload):
        s.loads(compressed_garbage)


def test_url_safe_compressed_intact_check():
    data = zlib.compress(b'"x"')
    token = Signer("k").sign(b"." + base64.urlsafe_b64encode(data).rstrip(b"="))
    assert URLSafeSerializer("k").loads(token) == "x"


# Failure hierarchy / N-000373-N-000381
def test_failure_hierarchy():
    assert issubclass(BadSignature, BadData)
    assert issubclass(BadTimeSignature, BadSignature)
    assert issubclass(SignatureExpired, BadTimeSignature)
    assert issubclass(BadPayload, BadData)
