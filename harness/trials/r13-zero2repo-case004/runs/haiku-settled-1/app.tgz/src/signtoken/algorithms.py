"""Signing algorithms passed to a signer as ``algorithm``.

# spec: N-000347 N-000348 N-000349
"""

import hashlib
import hmac


class HMACAlgorithm:
    """HMAC signature over the value, keyed with the derived key."""

    def __init__(self, digest_method=None):
        if digest_method is None:
            digest_method = hashlib.sha1
        self.digest_method = digest_method

    def get_signature(self, key, value):
        return hmac.new(key, value, self.digest_method).digest()


class NoneAlgorithm:
    """No-op algorithm: the signature is always empty."""

    def get_signature(self, key, value):
        return b""
