"""Serialize-and-sign helpers, including the URL-safe variants.

# spec: N-000350 N-000351 N-000352 N-000353 N-000354 N-000355 N-000356 N-000357
# spec: N-000358 N-000359 N-000360 N-000361 N-000362 N-000363 N-000364 N-000365
# spec: N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000372
# spec: N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317 N-000318
# spec: N-000328 N-000329 N-000330
"""

import json
import zlib
from collections.abc import Mapping

from ._encoding import to_bytes, urlsafe_b64decode, urlsafe_b64encode
from .exceptions import BadPayload, BadSignature
from .signer import DEFAULT_SALT, Signer, TimestampSigner


class _CompactJSON:
    """Default dump/load object for the URL-safe helpers: JSON without whitespace."""

    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    loads = staticmethod(json.loads)


def _is_text_serializer(serializer, kwargs):
    try:
        return isinstance(serializer.dumps({}, **kwargs), str)
    except Exception:
        return False


def _is_verified(error):
    return getattr(error, "_signature_verified", False)


class Serializer:
    """Serialize an object with a dump/load object, then sign the result."""

    _timed = False
    _default_signer_class = Signer

    def __init__(
        self,
        secret_key,
        salt=DEFAULT_SALT,
        serializer=None,
        serializer_kwargs=None,
        signer=None,
        signer_kwargs=None,
        fallback_signers=None,
    ):
        self.secret_key = secret_key
        self.salt = salt
        self.serializer = self._default_serializer() if serializer is None else serializer
        self.serializer_kwargs = dict(serializer_kwargs or {})
        self.signer_class = self._default_signer_class if signer is None else signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = [
            self._parse_fallback(item) for item in (fallback_signers or ())
        ]
        self._is_text = _is_text_serializer(self.serializer, self.serializer_kwargs)
        # Build the signers once so a bad separator or key derivation fails here.
        self._signers(None)

    def _default_serializer(self):
        return json

    def _parse_fallback(self, item):
        if isinstance(item, Mapping):
            return (self.signer_class, dict(item))
        if isinstance(item, type):
            return (item, dict(self.signer_kwargs))
        if isinstance(item, tuple) and len(item) == 2:
            signer_class, options = item
            return (signer_class, dict(options))
        raise TypeError(
            "fallback signer must be a mapping, a signer class, or a (class, mapping) pair"
        )

    def _signers(self, salt):
        """Primary signer first, then each fallback, all built with ``salt``."""
        salt = self.salt if salt is None else salt
        primary = self.signer_class(self.secret_key, salt=salt, **self.signer_kwargs)
        fallbacks = [
            signer_class(self.secret_key, salt=salt, **options)
            for signer_class, options in self.fallback_signers
        ]
        return [primary] + fallbacks

    # Payload hooks. The URL-safe mixin overrides these.

    def _encode_payload(self, obj, sep):
        data = self.serializer.dumps(obj, **self.serializer_kwargs)
        is_text = isinstance(data, str)
        return self._encode_section(to_bytes(data), sep), is_text

    def _encode_section(self, data, sep):
        return data

    def _decode_section(self, section, sep):
        return section

    def _decode_payload(self, section, sep):
        data = self._decode_section(section, sep)
        try:
            if self._is_text:
                data = data.decode("utf-8")
            return self.serializer.loads(data)
        except Exception as error:
            raise BadPayload(
                "Payload could not be deserialized", original_error=error
            ) from error

    # Loading

    def _open(self, token, salt, max_age):
        """Find the first signer configuration that verifies ``token``.

        Returns ``(signer, payload, signed_at, error)``. On success ``error``
        is None. On refusal ``error`` is the refusal to report and ``payload``
        is the section it carried. A verified refusal (expired, missing or
        malformed timestamp) ends the search at once.
        """
        token = to_bytes(token)
        first = None
        for signer in self._signers(salt):
            try:
                if self._timed:
                    payload, signed_at = signer.unsign(
                        token, max_age=max_age, return_timestamp=True
                    )
                else:
                    payload, signed_at = signer.unsign(token), None
                return signer, payload, signed_at, None
            except BadSignature as error:
                if _is_verified(error):
                    return signer, error.payload, None, error
                if first is None:
                    first = (signer, error)
        signer, error = first
        return signer, error.payload, None, error

    def _load(self, s, salt, max_age, return_timestamp):
        signer, payload, signed_at, error = self._open(s, salt, max_age)
        if error is not None:
            raise error
        obj = self._decode_payload(payload, signer.sep)
        if return_timestamp:
            return obj, signed_at
        return obj

    def _loads_unsafe(self, s, salt, max_age):
        signer, payload, _, error = self._open(s, salt, max_age)
        if error is None:
            return True, self._decode_payload(payload, signer.sep)
        if payload is None:
            return False, None
        try:
            return False, self._decode_payload(payload, signer.sep)
        except BadPayload:
            return False, None

    # Public API

    def dumps(self, obj, salt=None):
        signer = self._signers(salt)[0]
        payload, is_text = self._encode_payload(obj, signer.sep)
        token = signer.sign(payload)
        return token.decode("utf-8") if is_text else token

    def dump(self, obj, f, salt=None):
        return f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        return self._load(s, salt, None, False)

    def load(self, f, salt=None):
        return self.loads(f.read(), salt=salt)

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe(s, salt, None)

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt=salt)


class TimedSerializer(Serializer):
    """Serializer whose tokens carry a signing time and enforce a maximum age."""

    _timed = True
    _default_signer_class = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        return self._load(s, salt, max_age, return_timestamp)

    def load(self, f, salt=None, *, max_age=None, return_timestamp=False):
        return self.loads(
            f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt
        )

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe(s, salt, max_age)

    def load_unsafe(self, f, salt=None, *, max_age=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


class _URLSafeMixin:
    """Token payloads in URL-safe base64, compressed when that shortens them."""

    def _default_serializer(self):
        return _CompactJSON

    def _encode_payload(self, obj, sep):
        payload, _ = super()._encode_payload(obj, sep)
        return payload, True

    def _encode_section(self, data, sep):
        encoded = urlsafe_b64encode(data)
        packed = urlsafe_b64encode(zlib.compress(data, 9))
        # A compressed section is marked by a leading separator.
        if len(sep) + len(packed) < len(encoded):
            return sep + packed
        return encoded

    def _decode_section(self, section, sep):
        compressed = section.startswith(sep)
        if compressed:
            section = section[len(sep):]
        try:
            data = urlsafe_b64decode(section)
        except ValueError as error:
            raise BadPayload(
                "Payload is not URL-safe base64", original_error=error
            ) from error
        if not compressed:
            return data
        try:
            inflater = zlib.decompressobj()
            data = inflater.decompress(data)
            if not inflater.eof or inflater.unused_data:
                raise zlib.error("trailing data after compressed payload")
            return data
        except zlib.error as error:
            raise BadPayload(
                "Compressed payload is not intact", original_error=error
            ) from error


class URLSafeSerializer(_URLSafeMixin, Serializer):
    """URL-safe serialize-and-sign helper; ``dumps`` returns text."""


class URLSafeTimedSerializer(_URLSafeMixin, TimedSerializer):
    """URL-safe timestamped serialize-and-sign helper; ``dumps`` returns text."""
