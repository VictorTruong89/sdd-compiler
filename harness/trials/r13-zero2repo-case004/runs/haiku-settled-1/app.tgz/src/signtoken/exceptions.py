"""Failure classes raised when a token is refused.

# spec: N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379 N-000381
"""


class BadData(Exception):
    """Base class of every refusal raised while loading a token."""


class BadSignature(BadData):
    """The signature does not match, or the token has no separator.

    ``payload`` is the unverified payload section as bytes, or ``None`` when
    the token has none.
    """

    # Set on refusals raised after the signature has verified. Used by the
    # serializers to decide whether a fallback search should continue.
    _signature_verified = False

    def __init__(self, message, payload=None):
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused.

    ``reason`` is ``"missing"`` or ``"malformed"`` for those refusals and
    ``None`` for a plain time-signature failure.
    """

    def __init__(self, message, payload=None, date_signed=None, reason=None):
        super().__init__(message, payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The signature verified but the token is older than the allowed age."""

    def __init__(self, message, payload=None, date_signed=None):
        super().__init__(message, payload, date_signed, reason=None)


class BadPayload(BadData):
    """The signature verified but the payload could not be decoded."""

    def __init__(self, message, original_error=None):
        super().__init__(message)
        self.original_error = original_error
