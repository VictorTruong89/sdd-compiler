"""Signtoken: sign data so it can be sent to untrusted places and trusted again.

# spec: N-000271 N-000272 N-000273 N-000277 N-000278 N-000279 N-000280 N-000281
# spec: N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 N-000288
"""

from .algorithms import HMACAlgorithm, NoneAlgorithm
from .exceptions import BadData, BadPayload, BadSignature, BadTimeSignature, SignatureExpired
from .serializer import (
    Serializer,
    TimedSerializer,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)
from .signer import Signer, TimestampSigner

__version__ = "0.1.0"

__all__ = [
    "Signer",
    "TimestampSigner",
    "Serializer",
    "TimedSerializer",
    "URLSafeSerializer",
    "URLSafeTimedSerializer",
    "HMACAlgorithm",
    "NoneAlgorithm",
    "BadData",
    "BadSignature",
    "BadTimeSignature",
    "SignatureExpired",
    "BadPayload",
]
