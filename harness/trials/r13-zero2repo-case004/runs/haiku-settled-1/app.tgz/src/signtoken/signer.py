"""Basic signer and timestamped signer.

# spec: N-000331 N-000332 N-000333 N-000334 N-000335 N-000336 N-000337 N-000339
# spec: N-000341 N-000342 N-000343 N-000344 N-000345 N-000346
"""

import hashlib
import hmac
import re
import time
from datetime import datetime, timezone

from ._encoding import to_bytes, urlsafe_b64decode, urlsafe_b64encode
from .algorithms import HMACAlgorithm
from .exceptions import BadData, BadSignature, BadTimeSignature, SignatureExpired

DEFAULT_SALT = b"signtoken.signer"
KEY_DERIVATIONS = ("concat", "django-concat", "hmac", "none")

# Separators that can appear in an encoded signature or time field are refused.
_UNSAFE_SEPARATOR = re.compile(rb"[A-Za-z0-9=_-]")

# The time field is at most this many URL-safe characters (8 bytes of seconds).
MAX_TIMESTAMP_LENGTH = 11


def _normalize_secret_keys(secret_key):
    if isinstance(secret_key, (str, bytes)):
        keys = [secret_key]
    else:
        keys = list(secret_key)
    if not keys:
        raise ValueError("at least one secret key is required")
    return [to_bytes(key) for key in keys]


def _verified(error):
    """Mark ``error`` as raised after the signature verified."""
    error._signature_verified = True
    return error


def _format_timestamp(seconds):
    raw = seconds.to_bytes((seconds.bit_length() + 7) // 8 or 1, "big")
    return urlsafe_b64encode(raw)


def _parse_timestamp(field):
    """Return the signing time in whole seconds, or raise ValueError."""
    if not 0 < len(field) <= MAX_TIMESTAMP_LENGTH:
        raise ValueError("timestamp field has the wrong length")
    raw = urlsafe_b64decode(field)
    if not raw:
        raise ValueError("empty timestamp field")
    return int.from_bytes(raw, "big")


def _to_datetime(seconds):
    """Return a UTC datetime for ``seconds``, or None if it is not representable."""
    try:
        return datetime.fromtimestamp(seconds, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class Signer:
    """Sign byte values into ``<payload><sep><signature>`` tokens."""

    default_digest_method = staticmethod(hashlib.sha1)
    default_key_derivation = "django-concat"

    def __init__(
        self,
        secret_key,
        salt=DEFAULT_SALT,
        sep=".",
        key_derivation=None,
        digest_method=None,
        algorithm=None,
    ):
        self.secret_keys = _normalize_secret_keys(secret_key)
        self.salt = DEFAULT_SALT if salt is None else to_bytes(salt)

        self.sep = to_bytes(sep)
        if not self.sep or _UNSAFE_SEPARATOR.search(self.sep):
            raise ValueError("separator may not be a letter, digit, '-', '_' or '='")

        if key_derivation is None:
            key_derivation = self.default_key_derivation
        if key_derivation not in KEY_DERIVATIONS:
            raise ValueError("unknown key derivation: %r" % (key_derivation,))
        self.key_derivation = key_derivation

        if digest_method is None:
            digest_method = type(self).default_digest_method
        self.digest_method = digest_method

        if algorithm is None:
            algorithm = HMACAlgorithm(self.digest_method)
        self.algorithm = algorithm

    def derive_key(self, secret_key):
        """Derive the signing key from one secret and this signer's salt."""
        if self.key_derivation == "concat":
            return self.digest_method(self.salt + secret_key).digest()
        if self.key_derivation == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret_key).digest()
        if self.key_derivation == "hmac":
            return hmac.new(secret_key, self.salt, self.digest_method).digest()
        return secret_key

    def get_signature(self, value):
        """Encoded signature of ``value`` under the newest secret key."""
        key = self.derive_key(self.secret_keys[-1])
        return urlsafe_b64encode(self.algorithm.get_signature(key, value))

    def _signature_matches(self, value, signature):
        # Any key in the list may verify, so a rotated secret still accepts
        # tokens signed under an older key that is still listed.
        for secret_key in reversed(self.secret_keys):
            key = self.derive_key(secret_key)
            expected = urlsafe_b64encode(self.algorithm.get_signature(key, value))
            if hmac.compare_digest(expected, signature):
                return True
        return False

    def _split_signature(self, signed_value):
        """Split at the last separator; return (value, signature) or (None, None)."""
        head, sep, signature = to_bytes(signed_value).rpartition(self.sep)
        if not sep:
            return None, None
        return head, signature

    def sign(self, value):
        value = to_bytes(value)
        return value + self.sep + self.get_signature(value)

    def unsign(self, signed_value):
        value, signature = self._split_signature(signed_value)
        if value is None:
            raise BadSignature("No separator found in the value", payload=None)
        if not self._signature_matches(value, signature):
            raise BadSignature("Signature does not match", payload=value)
        return value

    def validate(self, signed_value):
        try:
            self.unsign(signed_value)
        except BadData:
            return False
        return True


class TimestampSigner(Signer):
    """Signer whose tokens carry the signing time: ``<payload><sep><time><sep><signature>``."""

    def sign(self, value):
        value = to_bytes(value)
        stamped = value + self.sep + _format_timestamp(int(time.time()))
        return stamped + self.sep + self.get_signature(stamped)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        value, signature = self._split_signature(signed_value)
        if value is None:
            raise BadSignature("No separator found in the value", payload=None)

        head, sep, time_field = value.rpartition(self.sep)
        has_time = bool(sep)

        if not self._signature_matches(value, signature):
            if not has_time:
                raise BadSignature("Signature does not match", payload=value)
            try:
                seconds = _parse_timestamp(time_field)
            except ValueError:
                raise BadTimeSignature(
                    "Signature does not match", payload=head
                ) from None
            signed_at = _to_datetime(seconds)
            if signed_at is None:
                raise BadTimeSignature(
                    "Malformed timestamp", payload=head, reason="malformed"
                )
            raise BadTimeSignature(
                "Signature does not match", payload=head, date_signed=signed_at
            )

        if not has_time:
            raise _verified(
                BadTimeSignature("Missing timestamp", payload=value, reason="missing")
            )
        try:
            seconds = _parse_timestamp(time_field)
        except ValueError:
            raise _verified(
                BadTimeSignature("Malformed timestamp", payload=head, reason="malformed")
            ) from None
        signed_at = _to_datetime(seconds)
        if signed_at is None:
            raise _verified(
                BadTimeSignature("Malformed timestamp", payload=head, reason="malformed")
            )

        if max_age is not None:
            age = int(time.time()) - seconds
            if age > max_age or age < 0:
                raise _verified(
                    SignatureExpired(
                        "Signature is older than the allowed age",
                        payload=head,
                        date_signed=signed_at,
                    )
                )

        if return_timestamp:
            return head, signed_at
        return head

    def validate(self, signed_value, max_age=None):
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadData:
            return False
        return True
