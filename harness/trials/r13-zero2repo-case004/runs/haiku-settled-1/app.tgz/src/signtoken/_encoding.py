"""Byte-level helpers shared by the signers and the serializers."""

import base64
import re

_URLSAFE_B64 = re.compile(rb"[A-Za-z0-9_-]*")


def to_bytes(value):
    """Return ``value`` as bytes; text is encoded as UTF-8."""
    if isinstance(value, str):
        return value.encode("utf-8")
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    raise TypeError("expected str or bytes, not %s" % type(value).__name__)


def urlsafe_b64encode(data):
    """URL-safe base64 (RFC 4648 section 5) with the padding removed."""
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def urlsafe_b64decode(data):
    """Decode unpadded URL-safe base64; raise ValueError on anything else."""
    if not _URLSAFE_B64.fullmatch(data) or len(data) % 4 == 1:
        raise ValueError("not URL-safe base64")
    return base64.urlsafe_b64decode(data + b"=" * (-len(data) % 4))
