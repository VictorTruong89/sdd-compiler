"""Byte, text and URL-safe base64 helpers shared by the signers and serializers."""

from __future__ import annotations

import base64
import binascii

# Characters that can appear in an encoded signature or timestamp; a separator
# made of any of these would make the token ambiguous.
BASE64_ALPHABET = frozenset(b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_=")


def want_bytes(value, encoding: str = "utf-8") -> bytes:
    """Return ``value`` as bytes, encoding text as UTF-8."""
    if isinstance(value, str):
        return value.encode(encoding)
    return bytes(value)


def want_str(value, encoding: str = "utf-8") -> str:
    """Return ``value`` as text, decoding bytes as UTF-8."""
    if isinstance(value, bytes):
        return value.decode(encoding)
    return str(value)


def base64_encode(value: bytes) -> bytes:
    """URL-safe base64 (RFC 4648 section 5) with the ``=`` padding removed."""
    return base64.urlsafe_b64encode(value).rstrip(b"=")


def base64_decode(value) -> bytes:
    """Strict inverse of :func:`base64_encode`.

    Raises ``binascii.Error`` (a ``ValueError``) for anything that is not the
    canonical unpadded URL-safe encoding of some byte string.
    """
    value = want_bytes(value)
    if b"=" in value:
        raise binascii.Error("padding is not allowed")
    padded = value + b"=" * (-len(value) % 4)
    raw = base64.urlsafe_b64decode(padded)
    if base64_encode(raw) != value:
        raise binascii.Error("not canonical URL-safe base64")
    return raw


def int_to_bytes(number: int) -> bytes:
    """Big-endian bytes of a non-negative integer, without leading zero bytes."""
    return number.to_bytes((number.bit_length() + 7) // 8, "big")
