"""Basic signer and timestamped signer."""

from __future__ import annotations

import hashlib
import hmac
import time
from datetime import datetime, timezone

from ._encoding import BASE64_ALPHABET, base64_decode, base64_encode, int_to_bytes, want_bytes
from .algorithms import HMACAlgorithm, SigningAlgorithm
from .exceptions import BadData, BadSignature, BadTimeSignature, SignatureExpired

DEFAULT_SALT = b"signtoken.signer"
KEY_DERIVATIONS = ("concat", "django-concat", "hmac", "none")
DEFAULT_KEY_DERIVATION = "django-concat"


# spec: N-000289 N-000114
def _secret_list(secret_key) -> list[bytes]:
    if isinstance(secret_key, (str, bytes)):
        keys = [want_bytes(secret_key)]
    else:
        keys = [want_bytes(key) for key in secret_key]
    if not keys:
        raise ValueError("at least one secret key is required")
    return keys


# spec: N-000141 N-000142
def _check_sep(sep: bytes) -> None:
    if not sep:
        raise ValueError("the separator must not be empty")
    if any(byte in BASE64_ALPHABET for byte in sep):
        raise ValueError(f"separator {sep!r} may appear in an encoded signature")


# spec: N-000095 N-000332 N-000333 N-000335
class Signer:
    """Signs byte values into ``<payload><sep><signature>`` tokens."""

    default_digest_method = hashlib.sha1

    def __init__(
        self,
        secret_key,
        salt=None,
        sep=".",
        key_derivation=None,
        digest_method=None,
        algorithm: SigningAlgorithm | None = None,
    ) -> None:
        self.secret_keys = _secret_list(secret_key)
        self.salt = DEFAULT_SALT if salt is None else want_bytes(salt)
        self.sep = want_bytes(sep)
        _check_sep(self.sep)
        self.key_derivation = DEFAULT_KEY_DERIVATION if key_derivation is None else key_derivation
        if self.key_derivation not in KEY_DERIVATIONS:
            raise ValueError(f"unknown key derivation {self.key_derivation!r}")
        self.digest_method = self.default_digest_method if digest_method is None else digest_method
        self.algorithm = HMACAlgorithm(self.digest_method) if algorithm is None else algorithm

    # spec: N-000118 N-000120 N-000121 N-000122
    def derive_key(self, secret_key: bytes) -> bytes:
        """Derive the signing key from one secret and this signer's salt."""
        if self.key_derivation == "concat":
            return self.digest_method(self.salt + secret_key).digest()
        if self.key_derivation == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret_key).digest()
        if self.key_derivation == "hmac":
            return hmac.new(secret_key, self.salt, digestmod=self.digest_method).digest()
        return secret_key  # "none"

    def get_signature(self, value: bytes) -> bytes:
        """Signature of ``value`` under the newest key, URL-safe base64 encoded."""
        # spec: N-000115
        key = self.derive_key(self.secret_keys[-1])
        return base64_encode(self.algorithm.get_signature(key, value))

    def verify_signature(self, value: bytes, sig: bytes) -> bool:
        """True when any key in the secret list verifies ``sig`` over ``value``."""
        try:
            raw_sig = base64_decode(sig)
        except ValueError:
            return False
        # spec: N-000116 N-000117
        for secret_key in reversed(self.secret_keys):
            key = self.derive_key(secret_key)
            if self.algorithm.verify_signature(key, value, raw_sig):
                return True
        return False

    def sign(self, value) -> bytes:
        value = want_bytes(value)
        return value + self.sep + self.get_signature(value)

    def unsign(self, signed_value) -> bytes:
        value = want_bytes(signed_value)
        # spec: N-000104 N-000108
        if self.sep not in value:
            raise BadSignature("No separator found in value", payload=None)
        payload, _, sig = value.rpartition(self.sep)
        if self.verify_signature(payload, sig):
            return payload
        raise BadSignature(f"Signature {sig!r} does not match", payload=payload)

    def validate(self, signed_value) -> bool:
        try:
            self.unsign(signed_value)
        except BadData:
            return False
        return True


# spec: N-000200 N-000219 N-000321 N-000324
def _int_from_time_field(field: bytes) -> int:
    """Decode a time field as the product writes it; ``ValueError`` otherwise."""
    if not field or len(field) > 11:
        raise ValueError("time field has an impossible length")
    number = int.from_bytes(base64_decode(field), "big")
    if base64_encode(int_to_bytes(number)) != field:
        raise ValueError("time field is not canonical")
    return number


# spec: N-000202 N-000203 N-000207 N-000223
def _datetime_from_epoch(number: int) -> datetime:
    """UTC datetime for a Unix-epoch second; ``ValueError`` when unrepresentable."""
    try:
        return datetime.fromtimestamp(number, tz=timezone.utc)
    except (OverflowError, OSError, ValueError) as err:
        raise ValueError("timestamp is not representable") from err


# spec: N-000186 N-000189 N-000198 N-000199
class TimestampSigner(Signer):
    """Signs values and records the signing time (whole Unix seconds) in the token.

    The token is ``<payload><sep><time><sep><signature>``.
    """

    def sign(self, value) -> bytes:
        value = want_bytes(value)
        timestamp = base64_encode(int_to_bytes(int(time.time())))
        return super().sign(value + self.sep + timestamp)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        value = want_bytes(signed_value)
        try:
            signed_part = Signer.unsign(self, value)
        except BadSignature as err:
            if err.payload is None or self.sep not in err.payload:
                raise
            payload, _, field = err.payload.rpartition(self.sep)
            try:
                number = _int_from_time_field(field)
            except ValueError:
                raise BadTimeSignature("Signature does not match", payload=payload)
            try:
                date_signed = _datetime_from_epoch(number)
            except ValueError:
                raise BadTimeSignature("Malformed timestamp", payload=payload, reason="malformed")
            raise BadTimeSignature("Signature does not match", payload=payload, date_signed=date_signed)

        # spec: N-000217 N-000227
        if self.sep not in signed_part:
            raise BadTimeSignature("Timestamp missing", payload=signed_part, reason="missing")
        payload, _, field = signed_part.rpartition(self.sep)
        try:
            number = _int_from_time_field(field)
            date_signed = _datetime_from_epoch(number)
        except ValueError:
            raise BadTimeSignature("Malformed timestamp", payload=payload, reason="malformed") from None

        # spec: N-000209 N-000210 N-000211 N-000212
        if max_age is not None:
            age = int(time.time()) - number
            if age > max_age or age < 0:
                raise SignatureExpired(
                    f"Signature age {age} exceeds max_age {max_age}",
                    payload=payload,
                    date_signed=date_signed,
                )
        if return_timestamp:
            return payload, date_signed
        return payload

    def validate(self, signed_value, max_age=None) -> bool:
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadData:
            return False
        return True

