"""Serialize-and-sign helpers: plain, timestamped and URL-safe variants."""

from __future__ import annotations

import json
import zlib
from collections.abc import Mapping

from ._encoding import base64_decode, base64_encode, want_bytes, want_str
from .exceptions import BadPayload, BadSignature, SignatureExpired
from .signer import Signer, TimestampSigner

DEFAULT_SERIALIZER_SALT = b"signtoken"


class _CompactJSON:
    """JSON with no whitespace outside strings; the URL-safe default."""

    @staticmethod
    def dumps(obj, **kwargs) -> str:
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)

    loads = staticmethod(json.loads)


# spec: N-000145 N-000152 N-000154 N-000160 N-000161
class Serializer:
    """Serializes an object with ``serializer`` and signs the result.

    Token form: ``<serialized><sep><signature>``.
    """

    default_signer = Signer
    default_serializer = json

    def __init__(
        self,
        secret_key,
        salt=None,
        serializer=None,
        serializer_kwargs=None,
        signer=None,
        signer_kwargs=None,
        fallback_signers=None,
    ) -> None:
        self.secret_key = secret_key
        self.salt = DEFAULT_SERIALIZER_SALT if salt is None else want_bytes(salt)
        self.serializer = self.default_serializer if serializer is None else serializer
        self.serializer_kwargs = dict(serializer_kwargs or {})
        self.signer = self.default_signer if signer is None else signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])
        # Build the signer once so a bad separator or key derivation fails here.
        self.make_signer()

    def make_signer(self, salt=None):
        salt = self.salt if salt is None else want_bytes(salt)
        return self.signer(self.secret_key, salt=salt, **self.signer_kwargs)

    # spec: N-000169 N-000171 N-000172
    def iter_unsigners(self, salt=None):
        """Yield the current signer, then one signer per fallback configuration."""
        salt = self.salt if salt is None else want_bytes(salt)
        yield self.make_signer(salt)
        for fallback in self.fallback_signers:
            if isinstance(fallback, Mapping):
                signer_class, kwargs = self.signer, fallback
            elif isinstance(fallback, tuple):
                signer_class, kwargs = fallback
            else:
                signer_class, kwargs = fallback, self.signer_kwargs
            yield signer_class(self.secret_key, salt=salt, **kwargs)

    # spec: N-000155 N-000156
    def dump_payload(self, obj, sep: bytes) -> tuple[bytes, bool]:
        """Return ``(payload_bytes, is_text)`` for ``obj``."""
        raw = self.serializer.dumps(obj, **self.serializer_kwargs)
        return want_bytes(raw), isinstance(raw, str)

    # spec: N-000182 N-000183
    def load_payload(self, payload: bytes, sep: bytes):
        try:
            return self.serializer.loads(payload)
        except Exception as err:
            raise BadPayload("Could not deserialize the payload", original_error=err) from err

    def _unsign(self, signer, value: bytes, max_age):
        """Verify one signer's token; return ``(payload, signed_at)``."""
        return signer.unsign(value), None

    def _unsign_first(self, value: bytes, salt, max_age):
        # spec: N-000170 N-000185 N-000215 N-000216
        """Try each signer in turn.

        Returns ``(signer, payload, signed_at, error)``. The first signer that
        verifies wins. An expired token ends the search. When nothing verifies,
        ``error`` is the last refusal and ``signer`` is the last signer tried.
        """
        error = None
        last_signer = None
        for signer in self.iter_unsigners(salt):
            last_signer = signer
            try:
                payload, signed_at = self._unsign(signer, value, max_age)
            except SignatureExpired as err:
                return signer, None, None, err
            except BadSignature as err:
                error = err
                continue
            return signer, payload, signed_at, None
        return last_signer, None, None, error

    def dumps(self, obj, salt=None):
        signer = self.make_signer(salt)
        payload, is_text = self.dump_payload(obj, signer.sep)
        token = signer.sign(payload)
        return want_str(token) if is_text else token

    def dump(self, obj, f, salt=None) -> None:
        f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        signer, payload, _, error = self._unsign_first(want_bytes(s), salt, None)
        if error is not None:
            raise error
        return self.load_payload(payload, signer.sep)

    def load(self, f, salt=None):
        return self.loads(f.read(), salt=salt)

    # spec: N-000176 N-000177 N-000178 N-000179
    def _loads_unsafe(self, s, salt, max_age):
        signer, payload, _, error = self._unsign_first(want_bytes(s), salt, max_age)
        if error is None:
            return True, self.load_payload(payload, signer.sep)
        if error.payload is None:
            return False, None
        try:
            return False, self.load_payload(error.payload, signer.sep)
        except BadPayload:
            return False, None

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe(s, salt, None)

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt=salt)


# spec: N-000187 N-000188 N-000190 N-000191
class TimedSerializer(Serializer):
    """Serializer whose tokens carry a signing time and can enforce a maximum age."""

    default_signer = TimestampSigner

    def _unsign(self, signer, value: bytes, max_age):
        payload, signed_at = signer.unsign(value, max_age=max_age, return_timestamp=True)
        return payload, signed_at

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        signer, payload, signed_at, error = self._unsign_first(want_bytes(s), salt, max_age)
        if error is not None:
            raise error
        obj = self.load_payload(payload, signer.sep)
        if return_timestamp:
            return obj, signed_at
        return obj

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe(s, salt, max_age)

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt)

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


# spec: N-000229 N-000230 N-000234 N-000236 N-000241 N-000242
class URLSafeSerializerMixin:
    """Token payloads in URL-safe base64, compressed when that shortens them.

    A compressed payload section is marked by a leading separator.
    """

    default_serializer = _CompactJSON

    def dump_payload(self, obj, sep: bytes) -> tuple[bytes, bool]:
        raw, _ = super().dump_payload(obj, sep)
        # spec: N-000231 N-000237 N-000238 N-000240
        compressed = zlib.compress(raw)
        if len(compressed) < len(raw):
            return sep + base64_encode(compressed), True
        return base64_encode(raw), True

    def load_payload(self, payload: bytes, sep: bytes):
        # spec: N-000247 N-000248 N-000249 N-000250
        compressed = payload.startswith(sep)
        if compressed:
            payload = payload[len(sep):]
        try:
            raw = base64_decode(payload)
        except ValueError as err:
            raise BadPayload("Payload is not URL-safe base64", original_error=err) from err
        if compressed:
            try:
                raw = zlib.decompress(raw)
            except zlib.error as err:
                raise BadPayload("Payload is not a valid compressed stream", original_error=err) from err
        return super().load_payload(raw, sep)


class URLSafeSerializer(URLSafeSerializerMixin, Serializer):
    """Serialize-and-sign helper whose tokens are URL-safe text."""


class URLSafeTimedSerializer(URLSafeSerializerMixin, TimedSerializer):
    """Timestamped serialize-and-sign helper whose tokens are URL-safe text."""
