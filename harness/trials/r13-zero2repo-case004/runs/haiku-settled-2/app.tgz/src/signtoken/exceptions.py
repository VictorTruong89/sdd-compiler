"""Failure classes raised by the signing and loading helpers."""

from __future__ import annotations

import datetime as _dt


class BadData(Exception):
    """Base class for every refusal of a token."""


class BadSignature(BadData):
    """The signature does not verify, or the token has no separator.

    ``payload`` is the unverified payload section as bytes, or ``None``
    when the token has no payload section.
    """

    def __init__(self, message: str, payload: bytes | None = None) -> None:
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused because of its time field.

    ``reason`` is ``"missing"`` for a missing timestamp, ``"malformed"`` for
    a malformed timestamp, and ``None`` for a time-signature failure.
    ``date_signed`` is a UTC ``datetime`` or ``None``.
    """

    def __init__(
        self,
        message: str,
        payload: bytes | None = None,
        date_signed: _dt.datetime | None = None,
        reason: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The token's signature verifies but its signing time is outside ``max_age``."""

    def __init__(
        self,
        message: str,
        payload: bytes | None = None,
        date_signed: _dt.datetime | None = None,
    ) -> None:
        super().__init__(message, payload=payload, date_signed=date_signed, reason=None)


class BadPayload(BadData):
    """The signature verifies but the payload cannot be decoded or deserialized."""

    def __init__(self, message: str, original_error: BaseException | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error
