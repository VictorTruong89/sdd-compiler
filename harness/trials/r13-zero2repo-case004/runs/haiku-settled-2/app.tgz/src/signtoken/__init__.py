"""Signtoken: sign data so it can be sent to untrusted places and trusted on return."""

from .algorithms import HMACAlgorithm, NoneAlgorithm, SigningAlgorithm
from .exceptions import BadData, BadPayload, BadSignature, BadTimeSignature, SignatureExpired
from .serializer import (
    Serializer,
    TimedSerializer,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)
from .signer import Signer, TimestampSigner

__all__ = [
    "BadData",
    "BadPayload",
    "BadSignature",
    "BadTimeSignature",
    "HMACAlgorithm",
    "NoneAlgorithm",
    "Serializer",
    "SignatureExpired",
    "Signer",
    "SigningAlgorithm",
    "TimedSerializer",
    "TimestampSigner",
    "URLSafeSerializer",
    "URLSafeTimedSerializer",
]

__version__ = "0.1.0"
