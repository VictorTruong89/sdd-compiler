"""Signing algorithms: HMAC (default) and a no-op variant."""

from __future__ import annotations

import hashlib
import hmac


class SigningAlgorithm:
    """Interface for a signing algorithm used by a signer."""

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        raise NotImplementedError

    def verify_signature(self, key: bytes, value: bytes, sig: bytes) -> bool:
        return hmac.compare_digest(sig, self.get_signature(key, value))


# spec: N-000134 N-000126
class HMACAlgorithm(SigningAlgorithm):
    """HMAC (RFC 2104) over the payload bytes. Defaults to SHA-1."""

    default_digest_method = hashlib.sha1

    def __init__(self, digest_method=None) -> None:
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return hmac.new(key, msg=value, digestmod=self.digest_method).digest()


# spec: N-000135 N-000349
class NoneAlgorithm(SigningAlgorithm):
    """No-op algorithm: the signature is always empty and nothing is verified."""

    def get_signature(self, key: bytes, value: bytes) -> bytes:
        return b""

    def verify_signature(self, key: bytes, value: bytes, sig: bytes) -> bool:
        return sig == b""
