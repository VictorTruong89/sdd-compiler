"""Behavioral tests for signtoken. Each test cites the spec node ids it covers."""

import datetime as dt
import hashlib
import io
import time

import pytest

import signtoken
from signtoken import (
    BadData,
    BadPayload,
    BadSignature,
    BadTimeSignature,
    HMACAlgorithm,
    NoneAlgorithm,
    Serializer,
    SignatureExpired,
    Signer,
    TimedSerializer,
    TimestampSigner,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)


# --- package surface (N-000277 .. N-000287) ---------------------------------

def test_N_000277_names_importable_from_root():
    for name in [
        "Signer", "TimestampSigner", "Serializer", "TimedSerializer",
        "URLSafeSerializer", "URLSafeTimedSerializer", "HMACAlgorithm",
        "NoneAlgorithm", "BadData", "BadSignature", "BadTimeSignature",
        "SignatureExpired", "BadPayload",
    ]:
        assert isinstance(getattr(signtoken, name), type)


def test_N_000274_import_has_no_side_effects_on_caller_files():
    assert signtoken.__name__ == "signtoken"


# --- FP-01 signer -------------------------------------------------------------

def test_N_000095_sign_yields_payload_sep_signature_bytes():
    token = Signer("secret").sign("hello")
    assert isinstance(token, bytes)
    assert token.startswith(b"hello.")


def test_N_000097_round_trip_returns_bytes():
    s = Signer("secret")
    assert s.unsign(s.sign(b"payload")) == b"payload"
    assert s.unsign(s.sign("payload")) == b"payload"


def test_N_000099_N_000101_validate_never_raises():
    s = Signer("secret")
    assert s.validate(s.sign("x")) is True
    assert s.validate(b"nope") is False
    assert s.validate(b"no-separator") is False


def test_N_000102_payload_may_contain_separator():
    s = Signer("secret")
    assert s.unsign(s.sign("a.b.c")) == b"a.b.c"


def test_N_000105_any_alteration_refused():
    s = Signer("secret")
    token = bytearray(s.sign("payload"))
    token[0] ^= 0x01
    with pytest.raises(BadSignature):
        s.unsign(bytes(token))
    with pytest.raises(BadSignature):
        s.unsign(s.sign("payload")[:-1])


def test_N_000107_refused_token_carries_payload():
    s = Signer("secret")
    with pytest.raises(BadSignature) as info:
        s.unsign(b"tampered.AAAAAAAAAAAAAAAAAAAAAAAAAAA")
    assert info.value.payload == b"tampered"


def test_N_000108_no_separator_carries_no_payload():
    with pytest.raises(BadSignature) as info:
        Signer("secret").unsign(b"nosep")
    assert info.value.payload is None


def test_N_000110_N_000113_salt_isolation_and_default_interchange():
    token = Signer("k", salt="a").sign("v")
    with pytest.raises(BadSignature):
        Signer("k", salt="b").unsign(token)
    assert Signer("k").unsign(Signer("k").sign("v")) == b"v"


def test_N_000114_N_000116_key_rotation():
    old = Signer("old")
    token = old.sign("v")
    assert Signer(["new", "old"]).unsign(token) == b"v"
    with pytest.raises(BadSignature):
        Signer(["new"]).unsign(token)
    # signing uses the newest key
    assert Signer(["old", "new"]).unsign(Signer("new").sign("w")) == b"w"


@pytest.mark.parametrize("scheme", ["concat", "django-concat", "hmac", "none"])
def test_N_000118_N_000120_every_scheme_round_trips(scheme):
    s = Signer("secret", key_derivation=scheme)
    assert s.unsign(s.sign("v")) == b"v"


def test_N_000118_schemes_do_not_interchange():
    tokens = {
        scheme: Signer("secret", key_derivation=scheme).sign("v")
        for scheme in ["concat", "django-concat", "hmac", "none"]
    }
    for scheme, token in tokens.items():
        for other in tokens:
            if other != scheme:
                with pytest.raises(BadSignature):
                    Signer("secret", key_derivation=other).unsign(token)


def test_N_000143_unknown_key_derivation_refused():
    with pytest.raises(Exception):
        Signer("secret", key_derivation="bogus").sign("v")


def test_N_000121_none_scheme_uses_secret_directly():
    s = Signer("secret", key_derivation="none", algorithm=NoneAlgorithm())
    assert s.derive_key(b"secret") == b"secret"


def test_N_000126_N_000127_default_digest_is_sha1():
    assert Signer("k").sign("v") == Signer("k", digest_method=hashlib.sha1).sign("v")
    assert len(Signer("k").get_signature(b"v")) == 27  # 20-byte SHA-1 digest, unpadded


def test_N_000129_N_000130_digest_changes_signature_and_isolates():
    sha256 = Signer("k", digest_method=hashlib.sha256)
    assert len(sha256.get_signature(b"v")) == 43
    with pytest.raises(BadSignature):
        Signer("k").unsign(sha256.sign("v"))


class _SHA256Signer(Signer):
    default_digest_method = hashlib.sha256


def test_N_000131_N_000133_class_default_digest_and_precedence():
    assert _SHA256Signer("k").digest_method is hashlib.sha256
    assert _SHA256Signer("k", digest_method=hashlib.sha1).digest_method is hashlib.sha1


def test_N_000134_default_algorithm_is_hmac():
    assert isinstance(Signer("k").algorithm, HMACAlgorithm)


def test_N_000135_N_000138_none_algorithm_no_tamper_detection():
    s = Signer("k", algorithm=NoneAlgorithm())
    token = s.sign("payload")
    assert token == b"payload."
    assert s.unsign(b"changed.") == b"changed"


def test_N_000139_N_000140_algorithms_refuse_each_other():
    hmac_token = Signer("k").sign("v")
    none_token = Signer("k", algorithm=NoneAlgorithm()).sign("v")
    with pytest.raises(BadSignature):
        Signer("k", algorithm=NoneAlgorithm()).unsign(hmac_token)
    with pytest.raises(BadSignature):
        Signer("k").unsign(none_token)


@pytest.mark.parametrize("sep", ["a", "Z", "5", "-", "_", "="])
def test_N_000141_illegal_separators_refused(sep):
    with pytest.raises(Exception):
        Signer("k", sep=sep)


@pytest.mark.parametrize("sep", [".", ":", "|", "~"])
def test_N_000142_other_separators_accepted(sep):
    s = Signer("k", sep=sep)
    assert s.unsign(s.sign("a.b")) == b"a.b"


def test_N_000144_wrong_secret_refused():
    with pytest.raises(BadSignature):
        Signer("other").unsign(Signer("k").sign("v"))


# --- FP-03 timestamp signer ----------------------------------------------------

def test_N_000198_N_000205_time_field_between_payload_and_signature():
    token = TimestampSigner("k").sign("payload.with.dots")
    parts = token.rsplit(b".", 2)
    assert parts[0] == b"payload.with.dots"
    assert 1 <= len(parts[1]) <= 11


def test_N_000206_no_max_age_yields_value_regardless_of_age(monkeypatch):
    s = TimestampSigner("k")
    token = s.sign("v")
    monkeypatch.setattr(time, "time", lambda: time.time() + 10**7)
    assert s.unsign(token) == b"v"


def test_N_000207_return_timestamp_is_utc_and_matches_signing_second(monkeypatch):
    fixed = 1_700_000_000.7
    monkeypatch.setattr(time, "time", lambda: fixed)
    token = TimestampSigner("k").sign("v")
    value, when = TimestampSigner("k").unsign(token, return_timestamp=True)
    assert value == b"v"
    assert when == dt.datetime(2023, 11, 14, 22, 13, 20, tzinfo=dt.timezone.utc)
    assert when.tzinfo is not None


def test_N_000209_N_000210_expiry_window(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = TimestampSigner("k")
    token = s.sign("v")
    now[0] += 10
    assert s.unsign(token, max_age=10) == b"v"
    now[0] += 1
    with pytest.raises(SignatureExpired) as info:
        s.unsign(token, max_age=10)
    assert info.value.payload == b"v"
    assert info.value.date_signed == dt.datetime.fromtimestamp(1_700_000_000, tz=dt.timezone.utc)


def test_N_000209_negative_age_is_expired(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    token = TimestampSigner("k").sign("v")
    now[0] -= 5
    with pytest.raises(SignatureExpired):
        TimestampSigner("k").unsign(token, max_age=100)


def test_N_000213_validate_with_max_age(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = TimestampSigner("k")
    token = s.sign("v")
    now[0] += 100
    assert s.validate(token, max_age=200) is True
    assert s.validate(token, max_age=50) is False


def test_N_000219_missing_timestamp_kind():
    key = Signer("k")
    token = key.sign("nots")  # verifies, but there is no time field
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(token)
    assert info.value.reason == "missing"
    assert info.value.date_signed is None


def test_N_000219_malformed_timestamp_kind():
    signed = Signer("k").sign(b"payload.!!!!")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(signed)
    assert info.value.reason == "malformed"
    assert info.value.payload == b"payload"


def test_N_000220_N_000221_time_signature_failure_carries_payload():
    token = TimestampSigner("k").sign("payload")
    tampered = token[:-1] + (b"A" if token[-1:] != b"A" else b"B")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(tampered)
    assert info.value.reason is None
    assert info.value.payload == b"payload"


def test_N_000224_plain_mismatch_without_separator_is_not_missing():
    with pytest.raises(BadSignature) as info:
        TimestampSigner("k").unsign(b"nosep")
    assert not isinstance(info.value, BadTimeSignature)


def test_N_000203_N_000223_time_past_datetime_range_is_malformed_when_verified():
    # Sign a time field that is valid base64 but names an unrepresentable instant.
    from signtoken._encoding import base64_encode, int_to_bytes

    field = base64_encode(int_to_bytes(10**15))
    token = Signer("k").sign(b"payload." + field)
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("k").unsign(token)
    assert info.value.reason == "malformed"


def test_N_000202_sign_succeeds_past_datetime_range(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 10**15)
    token = TimestampSigner("k").sign("v")
    assert token.startswith(b"v.")


# --- FP-02 serializer ------------------------------------------------------------

def test_N_000152_N_000155_dumps_loads_round_trip_json():
    s = Serializer("k")
    obj = {"user": 1, "roles": ["a", "b"]}
    token = s.dumps(obj)
    assert isinstance(token, str)  # JSON produces text
    assert s.loads(token) == obj
    assert token.split(".")[0] == '{"user": 1, "roles": ["a", "b"]}'


def test_N_000157_loads_accepts_bytes():
    s = Serializer("k")
    assert s.loads(s.dumps([1]).encode()) == [1]


def test_N_000156_bytes_serializer_gives_bytes():
    class BytesSerializer:
        dumps = staticmethod(lambda obj, **kw: b"\x00" + repr(obj).encode())
        loads = staticmethod(lambda data: data)

    s = Serializer("k", serializer=BytesSerializer())
    token = s.dumps("x")
    assert isinstance(token, bytes)


def test_N_000158_N_000159_stream_round_trip():
    s = Serializer("k")
    buf = io.StringIO()
    s.dump({"a": 1}, buf)
    buf.seek(0)
    assert s.load(buf) == {"a": 1}
    buf.seek(0)
    assert s.load_unsafe(buf) == (True, {"a": 1})


def test_N_000160_N_000161_per_call_salt():
    s = Serializer("k")
    token = s.dumps([1], salt="other")
    with pytest.raises(BadSignature):
        s.loads(token)
    assert s.loads(token, salt="other") == [1]


def test_N_000169_N_000172_fallback_signers_tried_in_order():
    old = Serializer("k", signer_kwargs={"digest_method": hashlib.sha256}).dumps({"x": 1})
    new = Serializer("k", fallback_signers=[{"digest_method": hashlib.sha256}])
    assert new.loads(old) == {"x": 1}
    fallback_class = Serializer("k", fallback_signers=[(Signer, {"digest_method": hashlib.sha256})])
    assert fallback_class.loads(old) == {"x": 1}


def test_N_000173_N_000174_signature_mismatch_carries_payload():
    s = Serializer("k")
    token = s.dumps({"x": 1})
    tampered = token[:-1] + ("A" if token[-1] != "A" else "B")
    with pytest.raises(BadSignature) as info:
        s.loads(tampered)
    assert s.load_payload(info.value.payload, b".") == {"x": 1}


def test_N_000176_N_000179_loads_unsafe_pairs():
    s = Serializer("k")
    token = s.dumps({"x": 1})
    assert s.loads_unsafe(token) == (True, {"x": 1})
    tampered = token[:-1] + ("A" if token[-1] != "A" else "B")
    assert s.loads_unsafe(tampered) == (False, {"x": 1})
    assert s.loads_unsafe("nosep") == (False, None)


def test_N_000182_N_000183_payload_decode_failure():
    other = Serializer("k", serializer=_Plain())
    token = other.dumps("not-json")
    with pytest.raises(BadPayload) as info:
        Serializer("k").loads(token)
    assert info.value.original_error is not None
    with pytest.raises(BadPayload):
        Serializer("k").loads_unsafe(token)


class _Plain:
    dumps = staticmethod(lambda obj, **kw: str(obj))
    loads = staticmethod(lambda data: (_ for _ in ()).throw(ValueError("plain")))


def test_N_000185_all_fail_is_signature_mismatch():
    token = Serializer("a").dumps(1)
    with pytest.raises(BadSignature) as info:
        Serializer("b", fallback_signers=[{"digest_method": hashlib.sha256}]).loads(token)
    assert not isinstance(info.value, BadPayload)


# --- FP-03 timed serializer -------------------------------------------------------

def test_N_000186_N_000188_timed_serializer_round_trip_with_timestamp(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = TimedSerializer("k")
    token = s.dumps({"a": 1})
    obj, when = s.loads(token, return_timestamp=True)
    assert obj == {"a": 1}
    assert when == dt.datetime.fromtimestamp(1_700_000_000, tz=dt.timezone.utc)


def test_N_000215_N_000216_expired_ends_fallback_search(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    token = TimedSerializer("k").dumps("v")
    now[0] += 1000
    s = TimedSerializer("k", fallback_signers=[{"digest_method": hashlib.sha256}])
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=10)


def test_N_000214_timed_loads_unsafe_expired(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    token = TimedSerializer("k").dumps({"a": 1})
    now[0] += 1000
    assert TimedSerializer("k").loads_unsafe(token, max_age=10) == (False, {"a": 1})


# --- FP-04 URL-safe ---------------------------------------------------------------

def test_N_000234_N_000235_url_safe_token_alphabet():
    s = URLSafeSerializer("k")
    token = s.dumps({"name": "x" * 50, "items": list(range(20))})
    assert isinstance(token, str)
    assert set(token) <= set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.")


def test_N_000236_compact_json_default():
    token = URLSafeSerializer("k").dumps({"a": [1, 2]})
    payload = token.rsplit(".", 1)[0]
    assert payload == "eyJhIjpbMSwyXX0"  # base64url of '{"a":[1,2]}'


def test_N_000237_N_000238_compression_only_when_shorter():
    s = URLSafeSerializer("k")
    big = s.dumps({"data": "abc" * 300})
    assert big.startswith(".")
    small = s.dumps({"a": 1})
    assert not small.startswith(".")
    assert s.loads(big) == {"data": "abc" * 300}


def test_N_000243_compressed_and_plain_load_on_equivalent_helper():
    token = URLSafeSerializer("k").dumps({"data": "abc" * 300})
    assert URLSafeSerializer("k").loads(token) == {"data": "abc" * 300}


def test_N_000244_N_000245_url_safe_timed_round_trip(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = URLSafeTimedSerializer("k")
    token = s.dumps({"data": "abc" * 300})
    assert token.startswith(".")
    value, when = s.loads(token, return_timestamp=True)
    assert value == {"data": "abc" * 300}
    now[0] += 500
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=60)


def test_N_000246_url_safe_tamper_refused():
    s = URLSafeSerializer("k")
    token = s.dumps({"data": "abc" * 300})
    tampered = token[:-1] + ("A" if token[-1] != "A" else "B")
    with pytest.raises(BadSignature):
        s.loads(tampered)


def test_N_000247_invalid_base64_payload_is_payload_failure():
    s = URLSafeSerializer("k")
    token = Signer("k", salt=b"signtoken").sign(b"!!notb64!!")
    with pytest.raises(BadPayload):
        s.loads(token)


def test_N_000248_bad_compressed_stream_is_payload_failure():
    s = URLSafeSerializer("k")
    token = Signer("k", salt=b"signtoken").sign(b".AAAA")
    with pytest.raises(BadPayload):
        s.loads(token)


def test_N_000249_undeserializable_payload_is_payload_failure():
    s = URLSafeSerializer("k")
    from signtoken._encoding import base64_encode

    token = Signer("k", salt=b"signtoken").sign(base64_encode(b"not json"))
    with pytest.raises(BadPayload):
        s.loads(token)


# --- ids not otherwise exercised ----------------------------------------------------

def test_N_000269_N_000270_no_entry_point_module():
    # no console script or `python -m` entry: there is no __main__ module
    import importlib.util

    assert importlib.util.find_spec("signtoken.__main__") is None
