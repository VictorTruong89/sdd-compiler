class BadData(Exception):
    """Base of all failures."""

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return self.message


class BadSignature(BadData):
    def __init__(self, message="", payload=None):
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    def __init__(self, message="", payload=None, date_signed=None, reason=None):
        super().__init__(message, payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    pass


class BadPayload(BadData):
    def __init__(self, message="", original_error=None):
        super().__init__(message)
        self.original_error = original_error
