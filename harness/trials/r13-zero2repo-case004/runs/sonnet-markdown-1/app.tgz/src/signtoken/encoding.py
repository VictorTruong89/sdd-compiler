import base64
import binascii


def want_bytes(s, encoding="utf-8", errors="strict"):
    if isinstance(s, str):
        return s.encode(encoding, errors)
    return bytes(s)


def base64_encode(string):
    return base64.urlsafe_b64encode(want_bytes(string)).rstrip(b"=")


def base64_decode(string):
    s = want_bytes(string, "ascii", "ignore")
    s += b"=" * (-len(s) % 4)
    try:
        return base64.b64decode(s, altchars=b"-_", validate=True)
    except (binascii.Error, ValueError) as e:
        raise ValueError("Invalid base64-encoded data") from e


def int_to_bytes(num):
    out = bytearray()
    while num:
        out.append(num & 0xFF)
        num >>= 8
    return bytes(reversed(out))


def bytes_to_int(b):
    return int.from_bytes(b, "big")
