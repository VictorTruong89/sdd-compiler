import json
import zlib

from .encoding import want_bytes, base64_encode, base64_decode
from .exc import BadPayload, BadSignature, SignatureExpired
from .signer import Signer, TimestampSigner, DEFAULT_SALT


class _CompactJSON:
    @staticmethod
    def loads(payload):
        return json.loads(payload)

    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)


class Serializer:
    default_serializer = json
    default_signer = Signer

    def __init__(self, secret_key, salt=DEFAULT_SALT, serializer=None,
                 serializer_kwargs=None, signer=None, signer_kwargs=None,
                 fallback_signers=None):
        if isinstance(secret_key, (str, bytes, bytearray)):
            self.secret_keys = [want_bytes(secret_key)]
        else:
            self.secret_keys = [want_bytes(k) for k in secret_key]
        self.salt = want_bytes(DEFAULT_SALT if salt is None else salt)
        if serializer is None:
            serializer = self.default_serializer
        self.serializer = serializer
        self.is_text_serializer = isinstance(serializer.dumps({}), str)
        self.serializer_kwargs = dict(serializer_kwargs or {})
        if signer is None:
            signer = self.default_signer
        self.signer = signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])

    @property
    def secret_key(self):
        return self.secret_keys[-1]

    def load_payload(self, payload, serializer=None):
        if serializer is None:
            serializer = self.serializer
            is_text = self.is_text_serializer
        else:
            is_text = isinstance(serializer.dumps({}), str)
        try:
            if is_text:
                return serializer.loads(payload.decode("utf-8"))
            return serializer.loads(payload)
        except Exception as e:
            raise BadPayload(
                "Could not load the payload because an exception occurred on"
                " unserializing the data.", original_error=e) from e

    def dump_payload(self, obj):
        return want_bytes(self.serializer.dumps(obj, **self.serializer_kwargs))

    def make_signer(self, salt=None):
        if salt is None:
            salt = self.salt
        return self.signer(self.secret_keys, salt=salt, **self.signer_kwargs)

    def iter_unsigners(self, salt=None):
        if salt is None:
            salt = self.salt
        yield self.make_signer(salt)
        for fallback in self.fallback_signers:
            if isinstance(fallback, dict):
                signer, kwargs = self.signer, fallback
            elif isinstance(fallback, tuple):
                signer, kwargs = fallback
            else:
                signer, kwargs = fallback, self.signer_kwargs
            yield signer(self.secret_keys, salt=salt, **kwargs)

    def dumps(self, obj, salt=None):
        rv = self.make_signer(salt).sign(self.dump_payload(obj))
        if self.is_text_serializer:
            return rv.decode("utf-8")
        return rv

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt))

    def loads(self, s, salt=None, **kwargs):
        s = want_bytes(s)
        last_exc = None
        for signer in self.iter_unsigners(salt):
            try:
                return self.load_payload(signer.unsign(s))
            except SignatureExpired:
                raise
            except BadSignature as err:
                last_exc = err
        raise last_exc

    def load(self, f, salt=None):
        return self.loads(f.read(), salt)

    def _loads_unsafe_impl(self, s, salt, load_kwargs=None):
        try:
            return True, self.loads(s, salt=salt, **(load_kwargs or {}))
        except BadSignature as e:
            if e.payload is None:
                return False, None
            try:
                return False, self.load_payload(
                    e.payload, **(self._unsafe_payload_kwargs()))
            except BadPayload:
                return False, None

    def _unsafe_payload_kwargs(self):
        return {}

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe_impl(s, salt)

    def load_unsafe(self, f, *args, **kwargs):
        return self.loads_unsafe(f.read(), *args, **kwargs)


class TimedSerializer(Serializer):
    default_signer = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        s = want_bytes(s)
        last_exc = None
        for signer in self.iter_unsigners(salt):
            try:
                base64d, timestamp = signer.unsign(
                    s, max_age=max_age, return_timestamp=True)
                payload = self.load_payload(base64d)
                if return_timestamp:
                    return payload, timestamp
                return payload
            except SignatureExpired:
                raise
            except BadSignature as err:
                last_exc = err
        raise last_exc

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age,
                          return_timestamp=return_timestamp, salt=salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe_impl(s, salt, {"max_age": max_age})


class _URLSafeMixin:
    default_serializer = _CompactJSON

    def load_payload(self, payload, *args, **kwargs):
        decompress = False
        if payload.startswith(b"."):
            payload = payload[1:]
            decompress = True
        try:
            json_bytes = base64_decode(payload)
            if decompress:
                json_bytes = zlib.decompress(json_bytes)
        except Exception as e:
            raise BadPayload(
                "Could not base64 decode the payload because of an exception",
                original_error=e) from e
        return super().load_payload(json_bytes, *args, **kwargs)

    def dump_payload(self, obj):
        json_bytes = super().dump_payload(obj)
        is_compressed = False
        compressed = zlib.compress(json_bytes)
        if len(compressed) < (len(json_bytes) - 1):
            json_bytes = compressed
            is_compressed = True
        encoded = base64_encode(json_bytes)
        if is_compressed:
            encoded = b"." + encoded
        return encoded


class URLSafeSerializer(_URLSafeMixin, Serializer):
    pass


class URLSafeTimedSerializer(_URLSafeMixin, TimedSerializer):
    pass
