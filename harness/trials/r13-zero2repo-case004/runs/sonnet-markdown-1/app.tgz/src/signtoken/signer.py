import hashlib
import hmac
import string
import time
from datetime import datetime, timezone

from .encoding import (want_bytes, base64_encode, base64_decode,
                       int_to_bytes, bytes_to_int)
from .exc import BadSignature, BadTimeSignature, SignatureExpired

DEFAULT_SALT = b"signtoken.signer"
_ALPHABET = set(string.ascii_letters + string.digits + "-_=")


class SigningAlgorithm:
    def get_signature(self, key, value):
        raise NotImplementedError()

    def verify_signature(self, key, value, sig):
        return hmac.compare_digest(sig, self.get_signature(key, value))


class NoneAlgorithm(SigningAlgorithm):
    def get_signature(self, key, value):
        return b""


class HMACAlgorithm(SigningAlgorithm):
    default_digest_method = staticmethod(hashlib.sha1)

    def __init__(self, digest_method=None):
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method

    def get_signature(self, key, value):
        return hmac.new(key, msg=value, digestmod=self.digest_method).digest()


def _make_keys(secret_key):
    if isinstance(secret_key, (str, bytes, bytearray)):
        return [want_bytes(secret_key)]
    return [want_bytes(k) for k in secret_key]


class Signer:
    default_digest_method = staticmethod(hashlib.sha1)
    default_key_derivation = "django-concat"

    def __init__(self, secret_key, salt=DEFAULT_SALT, sep=".",
                 key_derivation=None, digest_method=None, algorithm=None):
        self.secret_keys = _make_keys(secret_key)
        self.sep = want_bytes(sep)
        if any(chr(c) in _ALPHABET for c in self.sep) or not self.sep:
            raise ValueError("The given separator cannot be used because it may be"
                             " contained in the signature itself.")
        self.salt = want_bytes(DEFAULT_SALT if salt is None else salt)
        if key_derivation is None:
            key_derivation = self.default_key_derivation
        if key_derivation not in ("concat", "django-concat", "hmac", "none"):
            raise TypeError("Unknown key derivation method")
        self.key_derivation = key_derivation
        if digest_method is None:
            digest_method = self.default_digest_method
        self.digest_method = digest_method
        if algorithm is None:
            algorithm = HMACAlgorithm(self.digest_method)
        self.algorithm = algorithm

    @property
    def secret_key(self):
        return self.secret_keys[-1]

    def derive_key(self, secret_key=None):
        if secret_key is None:
            secret_key = self.secret_keys[-1]
        else:
            secret_key = want_bytes(secret_key)
        kd = self.key_derivation
        if kd == "concat":
            return self.digest_method(self.salt + secret_key).digest()
        if kd == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret_key).digest()
        if kd == "hmac":
            return hmac.new(secret_key, msg=self.salt,
                            digestmod=self.digest_method).digest()
        if kd == "none":
            return secret_key
        raise TypeError("Unknown key derivation method")

    def get_signature(self, value):
        value = want_bytes(value)
        return base64_encode(self.algorithm.get_signature(self.derive_key(), value))

    def sign(self, value):
        value = want_bytes(value)
        return value + self.sep + self.get_signature(value)

    def verify_signature(self, value, sig):
        try:
            sig = base64_decode(sig)
        except Exception:
            return False
        value = want_bytes(value)
        for secret_key in reversed(self.secret_keys):
            key = self.derive_key(secret_key)
            if self.algorithm.verify_signature(key, value, sig):
                return True
        return False

    def unsign(self, signed_value):
        signed_value = want_bytes(signed_value)
        if self.sep not in signed_value:
            raise BadSignature("No %r found in value" % self.sep)
        value, sig = signed_value.rsplit(self.sep, 1)
        if self.verify_signature(value, sig):
            return value
        raise BadSignature("Signature %r does not match" % sig, payload=value)

    def validate(self, signed_value):
        try:
            self.unsign(signed_value)
            return True
        except BadSignature:
            return False


class TimestampSigner(Signer):
    def get_timestamp(self):
        return int(time.time())

    def timestamp_to_datetime(self, ts):
        return datetime.fromtimestamp(ts, tz=timezone.utc)

    def sign(self, value):
        value = want_bytes(value)
        ts = base64_encode(int_to_bytes(self.get_timestamp()))
        return super().sign(value + self.sep + ts)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        try:
            result = super().unsign(signed_value)
            sig_error = None
        except BadSignature as e:
            sig_error = e
            result = e.payload or b""

        if self.sep not in result:
            if sig_error:
                raise sig_error
            raise BadTimeSignature("timestamp missing", payload=result,
                                   reason="missing")

        value, ts_bytes = result.rsplit(self.sep, 1)
        ts_int = None
        if len(ts_bytes) <= 11:
            try:
                ts_int = bytes_to_int(base64_decode(ts_bytes))
            except Exception:
                ts_int = None
        ts_dt = None
        if ts_int is not None:
            try:
                ts_dt = self.timestamp_to_datetime(ts_int)
            except (ValueError, OSError, OverflowError):
                ts_int = None

        if sig_error is not None:
            if ts_int is None:
                if len(ts_bytes) > 0 and self._decodes(ts_bytes):
                    raise BadTimeSignature("Malformed timestamp", payload=value,
                                           reason="malformed")
                raise BadTimeSignature(str(sig_error), payload=value)
            raise BadTimeSignature(str(sig_error), payload=value, date_signed=ts_dt)

        if ts_int is None:
            raise BadTimeSignature("Malformed timestamp", payload=value,
                                   reason="malformed")

        if max_age is not None:
            age = int(time.time()) - ts_int
            if age > max_age:
                raise SignatureExpired("Signature age %s > %s seconds" % (age, max_age),
                                       payload=value, date_signed=ts_dt)
            if age < 0:
                raise SignatureExpired("Signature age %s < 0 seconds" % age,
                                       payload=value, date_signed=ts_dt)

        if return_timestamp:
            return value, ts_dt
        return value

    @staticmethod
    def _decodes(ts_bytes):
        # time field decodes but is unrepresentable (as opposed to undecodable)
        if len(ts_bytes) > 11:
            return False
        try:
            base64_decode(ts_bytes)
            return True
        except Exception:
            return False

    def validate(self, signed_value, max_age=None):
        try:
            self.unsign(signed_value, max_age=max_age)
            return True
        except BadSignature:
            return False
