# Spec coverage

Every id in `spec/CHECKLIST.md` (381) is either implemented, with the tests that exercise it, or listed as not done with a reason.

Code carries `# spec: <id>` markers beside what satisfies each id. Run the tests with `PYTHONPATH=src python -m pytest tests/`.

Counts: implemented 378, not done 3.

## Choices made where the spec is open

The export was made with `--allow-open`, so 18 contradictions have no human verdict. Where they conflict, the implementation takes the reading below. Each choice is in code and covered by a test where it matters.

- **Signing key and `none` (CF-000005).** The key is the secret itself under `none`; every other scheme derives it from the secret and salt.
- **Signing time beyond the datetime range (CF-000008, CF-000034, CF-000044).** Signing succeeds. Verification first checks the signature. A verified token whose time is unrepresentable is refused as malformed. An unverified token keeps its time-signature failure and reports `date_signed=None`.
- **Missing and malformed timestamps (CF-000013, CF-000018).** A token whose signature fails and whose signed part has no separator is a plain `BadSignature`. A time field longer than 11 characters is malformed. A time field that fails to decode is malformed.
- **Payload section base64 vs. compressed marker (CF-000014, CF-000029).** A section with a leading separator is the compressed form. Any other section must be strict URL-safe base64. The helpers' payload section is URL-safe base64; the plain `Signer` signs raw bytes and does not rewrite them.
- **Undecodable payloads (CF-000017, CF-000052).** Unsafe load returns `(False, None)` for a signature refusal whose payload cannot be decoded. It raises `BadPayload` only when the signature verified.
- **Fallbacks and expiry (CF-000038).** An expired token ends the fallback search and is refused. A token that verifies under a fallback and is not expired loads.
- **Empty signatures and digest length (CF-000023, CF-000024, CF-000027, CF-000028).** `NoneAlgorithm` signatures are empty. HMAC signatures have the digest's length. Under `NoneAlgorithm` the signature is empty, so neither the payload nor the time field is protected. The spec describes this no-op behaviour explicitly.
- **Changed payloads under `NoneAlgorithm` (CF-000019, CF-000021, CF-000022).** A changed payload under `NoneAlgorithm` is recovered and reported valid, because the spec says so explicitly. For HMAC signers, nothing changes.
- **Unsafe load with a verified but undecodable payload (CF-000052).** It raises `BadPayload`, per the explicit rule for unsafe load.
- **Serializer text output.** `dumps` returns `str` when the dump/load object returns `str`, and `bytes` otherwise. URL-safe helpers always return `str`.
- **Time encoding.** Minimal big-endian bytes encoded as URL-safe base64 without padding. That is at most 11 characters for any 64-bit time.
- **Compression.** zlib level 9, used only when the marked section is strictly shorter than the uncompressed one.
- **Default salt.** `b"signtoken.default-salt"` for all signers and serializers.
- **Separator refusal.** A separator with an ASCII letter, digit, `-`, `_` or `=` raises `ValueError` at construction. So does an empty separator.
- **Private helpers.** The URL-safe base64 helpers live in `signtoken._encoding` and are not exported (N-000046, N-000078).

## Checklist

| Id | Status | Where |
|---|---|---|
| N-000253 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000254 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000255 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000256 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000257 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000258 | implemented; tested in tests/test_package.py | behaviour in src/signtoken (see tests) |
| N-000259 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000260 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000261 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000262 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000263 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000264 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000265 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000266 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000267 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000268 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000269 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000270 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000271 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000272 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000273 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000274 | implemented; tested in tests/test_package.py | pyproject.toml, src/signtoken/__init__.py |
| N-000275 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000276 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000277 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000278 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000279 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000280 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000281 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000282 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000283 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000284 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000285 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000286 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000287 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000288 | implemented; tested in tests/test_package.py | src/signtoken/__init__.py |
| N-000289 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000290 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000291 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000292 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000293 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000294 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000295 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000296 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000297 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000298 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000299 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000300 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000301 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000302 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000303 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000304 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000305 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000306 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000307 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000308 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000309 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000310 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000311 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000312 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000313 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000314 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000315 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000316 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000317 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000318 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000319 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000320 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000321 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000322 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000323 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000324 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000325 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000326 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000327 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000328 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000329 | implemented; tested in tests/test_signer.py | behaviour in src/signtoken (see tests) |
| N-000330 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000331 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000332 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000333 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000334 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000335 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000336 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000337 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000338 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000339 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000340 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000341 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000342 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000343 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000344 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000345 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000346 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000347 | implemented; tested in tests/test_serializer.py | src/signtoken/algorithms.py |
| N-000348 | implemented; tested in tests/test_serializer.py | src/signtoken/algorithms.py |
| N-000349 | implemented; tested in tests/test_serializer.py | src/signtoken/algorithms.py |
| N-000350 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000351 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000352 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000353 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000354 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000355 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000356 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000357 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000358 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000359 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000360 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000361 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000362 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000363 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000364 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000365 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000366 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000367 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000368 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000369 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000370 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000371 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000372 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000373 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000374 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000375 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000376 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000377 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000378 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000379 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000380 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000381 | implemented; tested in tests/test_serializer.py | src/signtoken/exceptions.py |
| N-000001 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000002 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000003 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000004 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000005 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000006 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000007 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000008 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000009 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000010 | not done: Scope statement about the specification document itself; it defines no behaviour to build. | — |
| N-000011 | not done: Documentation-placement note: says where symbol names live (the Interface Contract); no behaviour to build. | — |
| N-000012 | not done: Rule for how the specification refines itself; no code behaviour. | — |
| N-000013 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000014 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000015 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000016 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000017 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000018 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000019 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000020 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000021 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000022 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000023 | implemented; tested in tests/test_package.py | behaviour in src/signtoken (see tests) |
| N-000024 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000025 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000026 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000027 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000028 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000029 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000030 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000031 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000032 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000033 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000034 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000035 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000036 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000037 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000038 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000039 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000040 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000041 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000042 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000043 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000044 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000045 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000046 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000047 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000048 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000049 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000050 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000051 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000052 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000053 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000054 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000055 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000056 | implemented; tested in tests/test_package.py | pyproject.toml |
| N-000057 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000058 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000059 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000060 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000061 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000062 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000063 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000064 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000065 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000066 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000067 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000068 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000069 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000070 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000071 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000072 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000073 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000074 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000075 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000076 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000077 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000078 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000079 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000080 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000081 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000082 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000083 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000084 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000085 | implemented; tested in tests/test_serializer.py | behaviour in src/signtoken (see tests) |
| N-000086 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000087 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000088 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000089 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000090 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000091 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000092 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000093 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000094 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000095 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000096 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000097 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000098 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000099 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000100 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000101 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000102 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000103 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000104 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000105 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000106 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000107 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000108 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000109 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000110 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000111 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000112 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000113 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000114 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000115 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000116 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000117 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000118 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000119 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000120 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000121 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000122 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000123 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000124 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000125 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000126 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000127 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000128 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000129 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000130 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000131 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000132 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000133 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000134 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000135 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000136 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000137 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000138 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000139 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000140 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000141 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000142 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000143 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000144 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000145 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000146 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000147 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000148 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000149 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000150 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000151 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000152 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000153 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000154 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000155 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000156 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000157 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000158 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000159 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000160 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000161 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000162 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000163 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000164 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000165 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000166 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000167 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000168 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000169 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000170 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000171 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000172 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000173 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000174 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000175 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000176 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000177 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000178 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000179 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000180 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000181 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000182 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000183 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000184 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000185 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000186 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000187 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000188 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000189 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000190 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000191 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000192 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000193 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000194 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000195 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000196 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000197 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000198 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000199 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000200 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000201 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000202 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000203 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000204 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000205 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000206 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000207 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000208 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000209 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000210 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000211 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000212 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000213 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000214 | implemented; tested in tests/test_signer.py | src/signtoken/serializer.py |
| N-000215 | implemented; tested in tests/test_signer.py | src/signtoken/serializer.py |
| N-000216 | implemented; tested in tests/test_signer.py | src/signtoken/serializer.py |
| N-000217 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000218 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000219 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000220 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000221 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000222 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000223 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000224 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000225 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000226 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000227 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000228 | implemented; tested in tests/test_signer.py | src/signtoken/signer.py |
| N-000229 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000230 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000231 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000232 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000233 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000234 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000235 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000236 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000237 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000238 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000239 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000240 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000241 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000242 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000243 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000244 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000245 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000246 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000247 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000248 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000249 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000250 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000251 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
| N-000252 | implemented; tested in tests/test_serializer.py | src/signtoken/serializer.py |
