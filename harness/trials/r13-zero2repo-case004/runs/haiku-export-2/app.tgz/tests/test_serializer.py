"""Serializer, timed, and URL-safe helpers (FP-02, FP-03, FP-04)."""

import base64
import hashlib
import io
import json
import pickle
import time

import pytest

from signtoken import (
    BadPayload,
    BadSignature,
    BadTimeSignature,
    SignatureExpired,
    Serializer,
    Signer,
    TimedSerializer,
    TimestampSigner,
    URLSafeSerializer,
    URLSafeTimedSerializer,
)

OBJ = {"user": 42, "roles": ["a", "b"], "name": "Zoë"}


def _decode_section(section):
    body = section.encode()
    return base64.urlsafe_b64decode(body + b"=" * (-len(body) % 4))


def test_round_trip_default_json_text_token():
    s = Serializer("secret")
    token = s.dumps(OBJ)
    assert isinstance(token, str)  # json.dumps returns str, so dumps returns str
    assert s.loads(token) == OBJ
    assert s.loads(token.encode()) == OBJ  # bytes tokens are accepted
    assert token.rsplit(".", 1)[0] == json.dumps(OBJ)  # payload is exactly the JSON text


def test_bytes_serializer_returns_bytes():
    s = Serializer("secret", serializer=pickle)
    token = s.dumps(OBJ)
    assert isinstance(token, bytes)
    assert s.loads(token) == OBJ


def test_serializer_kwargs_passed_to_every_dumps():
    calls = []

    class Spy:
        def dumps(self, obj, **kw):
            calls.append(kw)
            return json.dumps(obj, **kw)

        def loads(self, data):
            return json.loads(data)

    s = Serializer("secret", serializer=Spy(), serializer_kwargs={"sort_keys": True})
    calls.clear()  # construction probes the dump/load object once
    s.dumps({"b": 1, "a": 2})
    s.dumps(OBJ)
    assert calls == [{"sort_keys": True}, {"sort_keys": True}]


def test_dump_and_load_streams_text_and_binary():
    s = Serializer("secret")
    buf = io.StringIO()
    s.dump(OBJ, buf)
    buf.seek(0)
    assert s.load(buf) == OBJ
    b = Serializer("secret", serializer=pickle)
    bbuf = io.BytesIO()
    b.dump(OBJ, bbuf)
    bbuf.seek(0)
    assert b.load(bbuf) == OBJ


def test_per_call_salt_and_none_scheme_ignores_salt():
    s = Serializer("secret")
    token = s.dumps(OBJ, salt="ctx")
    assert s.loads(token, salt="ctx") == OBJ
    with pytest.raises(BadSignature):
        s.loads(token)
    n = Serializer("secret", signer_kwargs={"key_derivation": "none"})
    assert n.loads(n.dumps(OBJ, salt="x"), salt="y") == OBJ


def test_tampered_token_refused_as_signature_mismatch_with_payload():
    s = Serializer("secret")
    body, sig = s.dumps(OBJ).rsplit(".", 1)
    with pytest.raises(BadSignature) as info:
        s.loads(body.replace("42", "43") + "." + sig)
    assert info.value.payload is not None


def test_payload_decode_failure_is_distinct_kind_and_keeps_error():
    token = Signer("secret").sign(b"not json")
    with pytest.raises(BadPayload) as info:
        Serializer("secret").loads(token)
    assert isinstance(info.value.original_error, ValueError)
    assert not isinstance(info.value, BadSignature)


def test_unsafe_load_pairs():
    s = Serializer("secret")
    token = s.dumps(OBJ)
    assert s.loads_unsafe(token) == (True, OBJ)
    assert s.load_unsafe(io.StringIO(token)) == (True, OBJ)

    body, sig = token.rsplit(".", 1)
    changed = body.replace("42", "43") + "." + sig
    assert s.loads_unsafe(changed) == (False, {**OBJ, "user": 43})
    assert s.loads_unsafe("nosepartoken") == (False, None)
    assert s.loads_unsafe(Signer("other").sign(b"not json")) == (False, None)


def test_unsafe_load_raises_for_verified_undecodable_payload():
    with pytest.raises(BadPayload):
        Serializer("secret").loads_unsafe(Signer("secret").sign(b"{bad"))


def test_fallback_mapping_class_and_pair_each_verify():
    old = Serializer("secret", salt="s", signer_kwargs={"digest_method": hashlib.sha256})
    token = old.dumps(OBJ)
    assert Serializer("secret", salt="s", fallback_signers=[{"digest_method": hashlib.sha256}]).loads(token) == OBJ
    assert Serializer("secret", salt="s", fallback_signers=[Signer]).loads(
        Serializer("secret", salt="s").dumps(OBJ)) == OBJ
    assert Serializer("secret", salt="s", fallback_signers=[(Signer, {"sep": "|"})]).loads(
        Serializer("secret", salt="s", signer_kwargs={"sep": "|"}).dumps(OBJ)) == OBJ


def test_fallback_mapping_can_override_salt():
    token = Serializer("secret", salt="old").dumps(OBJ)
    assert Serializer("secret", salt="new", fallback_signers=[{"salt": "old"}]).loads(token) == OBJ


def test_refusal_when_current_and_all_fallbacks_fail():
    s = Serializer("x", fallback_signers=[{"salt": "nope"}])
    with pytest.raises(BadSignature):
        s.loads(Serializer("y").dumps(OBJ))


def test_illegal_sep_and_key_derivation_rejected_at_construction():
    with pytest.raises(ValueError):
        Serializer("secret", signer_kwargs={"sep": "a"})
    with pytest.raises(ValueError):
        Serializer("secret", signer_kwargs={"key_derivation": "nope"})


def test_salt_passed_positionally_to_url_safe():
    s = URLSafeSerializer("secret", "positional")
    assert s.loads(s.dumps(OBJ)) == OBJ
    assert Serializer("secret", "positional").loads(
        Serializer("secret", "positional").dumps(OBJ)) == OBJ


# --- URL-safe helpers -------------------------------------------------------

def test_url_safe_token_alphabet_and_text_output():
    s = URLSafeSerializer("secret")
    token = s.dumps(OBJ)
    assert isinstance(token, str)
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-.")
    assert set(token) <= allowed
    assert s.loads(token) == OBJ


def test_url_safe_default_payload_is_compact_json():
    token = URLSafeSerializer("secret").dumps({"a": [1, 2]})
    assert _decode_section(token.rsplit(".", 1)[0]) == b'{"a":[1,2]}'


def test_compression_marker_and_round_trip_for_both_forms():
    s = URLSafeSerializer("secret")
    repetitive = {"k": "abc" * 200}
    token = s.dumps(repetitive)
    assert token.rsplit(".", 1)[0].startswith(".")  # compressed: leading separator
    assert s.loads(token) == repetitive
    short = {"x": 1}
    token2 = s.dumps(short)
    assert not token2.startswith(".")  # not shorter, so left uncompressed
    assert s.loads(token2) == short


@pytest.mark.parametrize("obj", [{"a": "b"}, {"x": list(range(50))}, {"y": "q" * 30}])
def test_compression_only_when_strictly_shorter(obj):
    section = URLSafeSerializer("secret").dumps(obj).rsplit(".", 1)[0]
    raw = json.dumps(obj, separators=(",", ":")).encode()
    plain = base64.urlsafe_b64encode(raw).rstrip(b"=").decode()
    if section.startswith("."):
        assert len(section) < len(plain)
    else:
        assert section == plain


def test_url_safe_undecodable_verified_payload_is_payload_decode_failure():
    with pytest.raises(BadPayload):
        URLSafeSerializer("secret").loads(Signer("secret").sign(b"!!!"))
    with pytest.raises(BadPayload):
        URLSafeSerializer("secret").loads(Signer("secret").sign(b".AAAA"))  # bad zlib stream


def test_url_safe_timed_round_trip_timestamp_and_max_age(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = URLSafeTimedSerializer("secret")
    token = s.dumps(OBJ)
    assert s.loads(token) == OBJ
    obj, signed_at = s.loads(token, return_timestamp=True)
    assert obj == OBJ and signed_at.year == 2023
    now[0] += 60
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=30)
    assert s.loads_unsafe(token, max_age=30) == (False, OBJ)
    assert s.loads_unsafe(token, max_age=300) == (True, OBJ)


def test_timed_stream_load_with_max_age(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = TimedSerializer("secret")
    token = s.dumps({"a": 1})
    assert s.load(io.StringIO(token), max_age=10) == {"a": 1}
    now[0] += 11
    with pytest.raises(SignatureExpired):
        s.load(io.StringIO(token), max_age=10)


def test_timed_token_without_timestamp_refused_as_missing():
    token = Serializer("secret").dumps({"a": 1})
    with pytest.raises(BadTimeSignature) as info:
        TimedSerializer("secret").loads(token)
    assert info.value.reason == "missing"


def test_timed_expired_fallback_ends_search(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    token = TimedSerializer("secret", salt="s").dumps({"a": 1})
    now[0] += 100
    s = TimedSerializer("secret", salt="s", fallback_signers=[{"salt": "s"}])
    with pytest.raises(SignatureExpired):
        s.loads(token, max_age=10)


def test_default_signer_classes():
    assert isinstance(TimedSerializer("k").make_signer(), TimestampSigner)
    assert type(Serializer("k").make_signer()) is Signer
    assert isinstance(URLSafeTimedSerializer("k").make_signer(), TimestampSigner)


def test_url_safe_and_timed_url_safe_share_default_salt_and_signature():
    token = URLSafeSerializer("secret").dumps({"a": 1})
    with pytest.raises(BadTimeSignature) as info:  # verifies, but untimed: no time field
        URLSafeTimedSerializer("secret").loads(token)
    assert info.value.reason == "missing"
    timed = URLSafeTimedSerializer("secret").dumps({"a": 1})
