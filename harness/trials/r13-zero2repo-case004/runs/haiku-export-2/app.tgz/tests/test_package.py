"""Package layout, public surface, and import-time behaviour (packaging and scope rules)."""

import inspect
import pathlib
import subprocess
import sys
import tomllib

import signtoken

ROOT = pathlib.Path(__file__).resolve().parent.parent

PUBLIC = [
    "Signer", "TimestampSigner", "Serializer", "TimedSerializer",
    "URLSafeSerializer", "URLSafeTimedSerializer", "HMACAlgorithm", "NoneAlgorithm",
    "BadData", "BadSignature", "BadTimeSignature", "SignatureExpired", "BadPayload",
]


def test_public_names_importable_from_root_and_are_classes():
    for name in PUBLIC:
        assert hasattr(signtoken, name), name
        assert inspect.isclass(getattr(signtoken, name)), name


def test_failure_class_hierarchy():
    assert issubclass(signtoken.BadSignature, signtoken.BadData)
    assert issubclass(signtoken.BadTimeSignature, signtoken.BadSignature)
    assert issubclass(signtoken.SignatureExpired, signtoken.BadTimeSignature)
    assert issubclass(signtoken.BadPayload, signtoken.BadData)
    assert issubclass(signtoken.BadData, Exception)


def test_src_layout_and_importable_from_src():
    assert (ROOT / "src" / "signtoken" / "__init__.py").is_file()
    out = subprocess.run(
        [sys.executable, "-c", "import signtoken, sys; print(signtoken.__file__)"],
        env={"PYTHONPATH": str(ROOT / "src")},
        capture_output=True, text=True, check=True,
    )
    assert out.stdout.strip().startswith(str(ROOT / "src"))


def test_pyproject_declares_pep517_no_deps_and_no_entry_points():
    data = tomllib.loads((ROOT / "pyproject.toml").read_text())
    assert data["build-system"]["build-backend"] == "setuptools.build_meta"
    assert data["project"]["name"] == "signtoken"
    assert data["project"]["dependencies"] == []
    assert data["project"]["requires-python"] == ">=3.10"
    assert "scripts" not in data["project"] and "gui-scripts" not in data["project"]
    assert data["tool"]["setuptools"]["packages"]["find"]["where"] == ["src"]


def test_no_main_module_or_compiled_code():
    assert not (ROOT / "src" / "signtoken" / "__main__.py").exists()
    assert not list((ROOT / "src").rglob("*.so")) and not list((ROOT / "src").rglob("*.pyd"))


def test_import_has_no_side_effects_on_files_or_process_exit():
    out = subprocess.run(
        [sys.executable, "-c",
         "import os; before = set(os.listdir('.')); "
         "import signtoken; assert set(os.listdir('.')) == before; print('ok')"],
        env={"PYTHONPATH": str(ROOT / "src")},
        cwd="/",
        capture_output=True, text=True,
    )
    assert out.returncode == 0 and out.stdout.strip() == "ok", out.stderr


def test_library_calls_raise_rather_than_exit():
    import pytest
    with pytest.raises(signtoken.BadSignature):
        signtoken.Signer("k").unsign(b"no-separator")
