"""Signer behaviour (FP-01, FP-03 token rules). Node ids are cited in test names/comments."""

import hashlib
import hmac
import time
from datetime import datetime, timezone

import pytest

from signtoken import (
    BadSignature,
    BadTimeSignature,
    HMACAlgorithm,
    NoneAlgorithm,
    SignatureExpired,
    Signer,
    TimestampSigner,
)


def test_sign_round_trip_bytes_and_text():
    s = Signer("secret")
    token = s.sign("hello")
    assert isinstance(token, bytes)
    assert s.unsign(token) == b"hello"
    assert s.unsign(token.decode()) == b"hello"


def test_token_form_payload_sep_signature():
    s = Signer("secret")
    payload, sig = s.sign(b"abc").rsplit(b".", 1)
    assert payload == b"abc"
    assert b"=" not in sig and b"+" not in sig and b"/" not in sig


def test_payload_may_contain_separator():
    s = Signer("secret")
    assert s.unsign(s.sign("a.b.c")) == b"a.b.c"


def test_validate_returns_bool_and_never_raises():
    s = Signer("secret")
    assert s.validate(s.sign("x")) is True
    assert s.validate(b"nosep") is False
    assert s.validate("x.!!!") is False


def test_every_single_byte_change_is_refused():
    s = Signer("secret")
    token = s.sign("payload")
    for i in range(len(token)):
        mutated = bytearray(token)
        mutated[i] = ord("A") if mutated[i] != ord("A") else ord("B")
        assert not s.validate(bytes(mutated))
    assert not s.validate(token[:-1])


def test_refused_token_carries_unverified_payload():
    s = Signer("secret")
    with pytest.raises(BadSignature) as info:
        s.unsign(b"tampered.AAAA")
    assert info.value.payload == b"tampered"


def test_no_separator_is_signature_mismatch_without_payload():
    with pytest.raises(BadSignature) as info:
        Signer("secret").unsign(b"nosepat all")
    assert info.value.payload is None


@pytest.mark.parametrize("bad", ["a", "Z", "5", "-", "_", "="])
def test_refused_separators_raise_at_construction(bad):
    with pytest.raises(ValueError):
        Signer("secret", sep=bad)


@pytest.mark.parametrize("ok", [".", ":", "|", "~", "+"])
def test_accepted_separators(ok):
    s = Signer("secret", sep=ok)
    assert s.unsign(s.sign("v")) == b"v"


def test_salt_isolates_contexts():
    a = Signer("secret", salt="one")
    b = Signer("secret", salt="two")
    assert not b.validate(a.sign("v"))
    assert Signer("secret").unsign(Signer("secret").sign("v")) == b"v"  # default salt interchanges


def test_key_rotation_newest_signs_any_listed_key_verifies():
    old = Signer(["old"])
    rotated = Signer(["old", "new"])
    assert rotated.unsign(old.sign("v")) == b"v"  # old key still accepted
    assert Signer(["new"]).unsign(rotated.sign("v")) == b"v"  # signs with newest
    assert not Signer(["new2"]).validate(old.sign("v"))  # removed key refused


@pytest.mark.parametrize("scheme", ["concat", "django-concat", "hmac", "none"])
def test_each_key_derivation_round_trips(scheme):
    s = Signer("secret", key_derivation=scheme)
    assert s.unsign(s.sign("v")) == b"v"


def test_schemes_do_not_interchange():
    tokens = {sch: Signer("secret", key_derivation=sch).sign("v") for sch in
              ["concat", "django-concat", "hmac", "none"]}
    for a, token in tokens.items():
        for b in tokens:
            if a != b:
                assert not Signer("secret", key_derivation=b).validate(token)


def test_unknown_key_derivation_refused():
    with pytest.raises(ValueError):
        Signer("secret", key_derivation="bogus")


def test_none_scheme_key_is_secret_itself():
    s = Signer("secret", key_derivation="none", salt="ignored")
    assert s.derive_key() == b"secret"
    assert Signer("secret", key_derivation="none", salt="other").validate(
        Signer("secret", key_derivation="none", salt="ignored").sign("v")
    )


def test_default_digest_is_sha1_and_explicit_sha1_matches():
    default = Signer("secret").sign("v")
    explicit = Signer("secret", digest_method=hashlib.sha1).sign("v")
    assert default == explicit


def test_signature_length_follows_digest_size():
    sig = Signer("secret", digest_method=hashlib.sha256).sign("v").split(b".")[-1]
    assert len(sig) == 43  # 32 bytes, unpadded base64


def test_different_digests_do_not_interchange():
    t = Signer("secret", digest_method=hashlib.sha256).sign("v")
    assert not Signer("secret").validate(t)


class SHA256Signer(Signer):
    default_digest_method = staticmethod(hashlib.sha256)


def test_signer_subclass_default_digest_and_precedence():
    assert SHA256Signer("k").digest_method is hashlib.sha256
    assert SHA256Signer("k", digest_method=hashlib.sha1).digest_method is hashlib.sha1


def test_hmac_algorithm_is_default_and_matches_rfc2104():
    s = Signer("secret", salt="s")
    key = s.derive_key()
    expected = hmac.new(key, b"v", hashlib.sha1).digest()
    from signtoken._encoding import b64encode_nopad
    assert s.sign("v").endswith(b"." + b64encode_nopad(expected))


def test_none_algorithm_empty_signature_and_no_tamper_detection():
    s = Signer("secret", algorithm=NoneAlgorithm())
    assert s.sign("v") == b"v."
    assert s.unsign(b"changed.") == b"changed"  # documented: no tamper detection
    hmac_signer = Signer("secret")
    assert not hmac_signer.validate(b"v.")
    assert not s.validate(hmac_signer.sign("v"))


def test_hmac_algorithm_with_digest():
    alg = HMACAlgorithm(hashlib.sha256)
    s = Signer("secret", algorithm=alg)
    assert len(s.sign("v").split(b".")[-1]) == 43


def test_text_is_utf8_encoded_before_signing():
    s = Signer("secret")
    assert s.sign("héllo") == s.sign("héllo".encode())


# --- timestamped signer -----------------------------------------------------

def test_timestamp_round_trip_and_return_timestamp(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 1_700_000_000.9)
    s = TimestampSigner("secret")
    token = s.sign("v")
    assert s.unsign(token) == b"v"
    payload, signed_at = s.unsign(token, return_timestamp=True)
    assert payload == b"v"
    assert signed_at == datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    assert signed_at.tzinfo is timezone.utc


def test_timestamp_encoding_is_at_most_11_chars(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 2**63 - 1)
    token = TimestampSigner("secret").sign("v")
    assert len(token.split(b".")[1]) <= 11


def test_max_age_expiry_and_future_timestamp(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    s = TimestampSigner("secret")
    token = s.sign("v")
    now[0] += 10
    assert s.unsign(token, max_age=10) == b"v"  # age == N is accepted
    now[0] += 1
    with pytest.raises(SignatureExpired) as info:
        s.unsign(token, max_age=10)
    assert info.value.payload == b"v"
    assert info.value.date_signed.tzinfo is timezone.utc
    assert not s.validate(token, max_age=10)
    now[0] = 1_699_999_000  # clock moved backwards: age < 0
    with pytest.raises(SignatureExpired):
        s.unsign(token, max_age=10**9)


def test_expiry_checked_only_after_signature(monkeypatch):
    now = [1_700_000_000]
    monkeypatch.setattr(time, "time", lambda: now[0])
    token = TimestampSigner("secret").sign("v")
    now[0] += 1000
    with pytest.raises(BadSignature) as info:
        TimestampSigner("other").unsign(token, max_age=1)
    assert not isinstance(info.value, SignatureExpired)


def test_missing_timestamp(monkeypatch):
    s = TimestampSigner("secret")
    token = Signer("secret").sign("plainpayload")  # signed, but no time field
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(token)
    assert info.value.reason == "missing"
    assert info.value.payload == b"plainpayload"
    assert info.value.date_signed is None


def test_malformed_timestamp_is_refused_with_signature_verified():
    s = TimestampSigner("secret")
    signed = Signer("secret").sign(b"payload.!!")  # verifies, time field is junk
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(signed)
    assert info.value.reason == "malformed"
    assert info.value.payload == b"payload"


def test_overlong_timestamp_is_malformed():
    s = TimestampSigner("secret")
    signed = Signer("secret").sign(b"payload.AAAAAAAAAAAAAAAA")
    with pytest.raises(BadTimeSignature) as info:
        s.unsign(signed)
    assert info.value.reason == "malformed"


def test_time_signature_failure_carries_payload_and_time(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 1_700_000_000)
    token = TimestampSigner("secret").sign("v")
    mutated = token[:-2] + (b"AA" if token[-2:] != b"AA" else b"BB")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("secret").unsign(mutated)
    assert not isinstance(info.value, SignatureExpired)
    assert info.value.reason is None
    assert info.value.payload == b"v"
    assert info.value.date_signed == datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)


def test_plain_mismatch_on_timestamp_signer_has_no_time_identity():
    # Untimed token: the signed part has no separator, so the refusal is plain.
    token = Signer("secret").sign("v")
    with pytest.raises(BadSignature) as info:
        TimestampSigner("secret", salt="other").unsign(token)
    assert type(info.value) is BadSignature
    assert info.value.payload == b"v"


def test_time_signature_failure_with_wrong_key_is_time_failure():
    token = TimestampSigner("secret").sign("v")
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("other").unsign(token)
    assert info.value.payload == b"v"


def test_timestamp_signer_validate_default_and_compat_with_plain_signer(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 1_700_000_000)
    plain = Signer("secret").sign("v")
    stamped = TimestampSigner("secret").sign("v")
    assert TimestampSigner("secret").validate(stamped) is True
    assert TimestampSigner("secret").unsign(stamped) == b"v"
    assert TimestampSigner("secret").validate(plain) is False


def test_unrepresentable_time_signs_but_is_refused_as_malformed(monkeypatch):
    # N-000203: signing succeeds past the datetime range; N-000223: the refusal is malformed.
    monkeypatch.setattr(time, "time", lambda: 2**50)
    token = TimestampSigner("secret").sign("v")
    monkeypatch.setattr(time, "time", lambda: 0)
    with pytest.raises(BadTimeSignature) as info:
        TimestampSigner("secret").unsign(token)
    assert info.value.reason == "malformed"
    assert info.value.payload == b"v"
    assert info.value.date_signed is None


def test_time_is_whole_seconds_truncated(monkeypatch):
    monkeypatch.setattr(time, "time", lambda: 1_700_000_000.999)
    _, signed_at = TimestampSigner("secret").unsign(TimestampSigner("secret").sign("v"), return_timestamp=True)
    assert signed_at.microsecond == 0 and signed_at.second == 20


def test_validate_never_raises_for_odd_input():
    s = TimestampSigner("secret")
    for bad in ["", "☃", "a.b.c.d", ".", "..", "a..", b"\xff\xfe.x"]:
        assert s.validate(bad) is False
