"""Basic and timestamped signers (FP-01, FP-03).

# spec: N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092
# spec: N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099
# spec: N-000100 N-000101 N-000102 N-000103 N-000104 N-000105 N-000106
# spec: N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000113
# spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120
# spec: N-000121 N-000122 N-000123 N-000124 N-000125 N-000126 N-000127
# spec: N-000128 N-000129 N-000130 N-000131 N-000132 N-000133 N-000134
# spec: N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141
# spec: N-000142 N-000143 N-000144
# spec: N-000193 N-000194 N-000195 N-000196 N-000197 N-000198 N-000199
# spec: N-000200 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213
# spec: N-000217 N-000218 N-000219 N-000220 N-000221 N-000222 N-000223
# spec: N-000224 N-000225 N-000226 N-000227 N-000228
# spec: N-000311 N-000312 N-000319 N-000320 N-000321 N-000322 N-000323
# spec: N-000324 N-000325 N-000326 N-000327 N-000330
# spec: N-000331 N-000332 N-000333 N-000334 N-000335 N-000336 N-000337
# spec: N-000338 N-000339 N-000340 N-000341 N-000342 N-000343 N-000344
# spec: N-000345 N-000346
"""

import hashlib
import hmac
import re
import time
from datetime import datetime, timezone

from ._encoding import b64decode_nopad, b64encode_nopad, want_bytes
from .algorithms import HMACAlgorithm
from .exceptions import BadSignature, BadTimeSignature, SignatureExpired

#: Salt used when the caller omits one. Shared by every signer and serializer.
DEFAULT_SALT = b"signtoken.default-salt"

KEY_DERIVATIONS = ("concat", "django-concat", "hmac", "none")

_REFUSED_SEP = re.compile(rb"[A-Za-z0-9_=-]")
_TIMESTAMP_MAX_CHARS = 11


def _check_sep(sep):
    sep = want_bytes(sep)
    if not sep:
        raise ValueError("separator must not be empty")
    if _REFUSED_SEP.search(sep):
        raise ValueError("separator must not contain letters, digits, '-', '_' or '='")
    return sep


def _make_keys_list(secret_key):
    if isinstance(secret_key, (str, bytes, bytearray)):
        return [want_bytes(secret_key)]
    keys = [want_bytes(key) for key in secret_key]
    if not keys:
        raise ValueError("at least one secret key is required")
    return keys


def _encode_timestamp(timestamp):
    """Big-endian minimal bytes, URL-safe base64, no padding (at most 11 chars)."""
    return b64encode_nopad(timestamp.to_bytes((timestamp.bit_length() + 7) // 8 or 1, "big"))


def _decode_timestamp(field):
    """Return the integer signing time, or ``None`` if the field is not one we wrote."""
    if not field or len(field) > _TIMESTAMP_MAX_CHARS:
        return None
    try:
        timestamp = int.from_bytes(b64decode_nopad(field), "big")
    except ValueError:
        return None
    if _encode_timestamp(timestamp) != field:
        return None
    return timestamp


def _to_datetime(timestamp):
    """UTC datetime for an integer time, or ``None`` if the type cannot represent it."""
    try:
        return datetime.fromtimestamp(timestamp, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class Signer:
    """Signs byte values as ``<payload><sep><signature>``."""

    #: Hash constructor used when no ``digest_method`` is passed. Subclasses may
    #: assign another hash constructor in their class body.
    default_digest_method = staticmethod(hashlib.sha1)

    def __init__(self, secret_key, salt=DEFAULT_SALT, sep=".", key_derivation=None,
                 digest_method=None, algorithm=None):
        self.secret_keys = _make_keys_list(secret_key)
        self.salt = want_bytes(salt)
        self.sep = _check_sep(sep)
        self.key_derivation = "django-concat" if key_derivation is None else key_derivation
        if self.key_derivation not in KEY_DERIVATIONS:
            raise ValueError(f"unknown key_derivation {self.key_derivation!r}")
        self.digest_method = (
            self.default_digest_method if digest_method is None else digest_method
        )
        self.algorithm = (
            HMACAlgorithm(self.digest_method) if algorithm is None else algorithm
        )

    def derive_key(self, secret_key=None):
        """Derive the signing key from one secret and the salt (``# spec: N-000109``)."""
        secret = self.secret_keys[-1] if secret_key is None else secret_key
        if self.key_derivation == "concat":
            return self.digest_method(self.salt + secret).digest()
        if self.key_derivation == "django-concat":
            return self.digest_method(self.salt + b"signer" + secret).digest()
        if self.key_derivation == "hmac":
            return hmac.new(secret, self.salt, self.digest_method).digest()
        return secret  # "none": the secret is the key

    def get_signature(self, value):
        """URL-safe base64 signature of ``value`` under the newest key."""
        signature = self.algorithm.get_signature(self.derive_key(), value)
        return b64encode_nopad(signature)

    def sign(self, value):
        """Return ``value`` followed by the separator and its signature."""
        value = want_bytes(value)
        return value + self.sep + self.get_signature(value)

    def verify_signature(self, value, signature_field):
        """True if any key in the list verifies ``signature_field`` over ``value``."""
        try:
            signature = b64decode_nopad(signature_field)
        except ValueError:
            return False
        for secret in reversed(self.secret_keys):
            if self.algorithm.verify_signature(self.derive_key(secret), value, signature):
                return True
        return False

    def unsign(self, signed_value):
        """Return the payload bytes, or raise ``BadSignature``."""
        value = want_bytes(signed_value)
        if self.sep not in value:
            raise BadSignature("No separator found in the value", payload=None)
        payload, signature_field = value.rsplit(self.sep, 1)
        if self.verify_signature(payload, signature_field):
            return payload
        raise BadSignature("Signature does not match", payload=payload)

    def validate(self, signed_value):
        """True if ``unsign`` would accept the value; never raises for a bad token."""
        try:
            self.unsign(signed_value)
        except BadSignature:
            return False
        return True


class TimestampSigner(Signer):
    """Signs values as ``<payload><sep><time><sep><signature>``."""

    def sign(self, value):
        value = want_bytes(value)
        timestamp = _encode_timestamp(int(time.time()))
        return super().sign(value + self.sep + timestamp)

    def unsign(self, signed_value, max_age=None, return_timestamp=False):
        """Return the payload, or ``(payload, signed_at)`` with ``return_timestamp``.

        Raises ``BadSignature`` (plain mismatch), ``BadTimeSignature`` (time-field
        failure, missing or malformed timestamp), or ``SignatureExpired``.
        """
        try:
            signed_part = super().unsign(signed_value)
        except BadSignature as error:
            if error.payload is None or self.sep not in error.payload:
                raise
            payload, timestamp_field = error.payload.rsplit(self.sep, 1)
            timestamp = _decode_timestamp(timestamp_field)
            raise BadTimeSignature(
                "Signature does not match",
                payload=payload,
                date_signed=None if timestamp is None else _to_datetime(timestamp),
            ) from None

        if self.sep not in signed_part:
            raise BadTimeSignature(
                "Timestamp missing", payload=signed_part, date_signed=None, reason="missing"
            )
        payload, timestamp_field = signed_part.rsplit(self.sep, 1)
        timestamp = _decode_timestamp(timestamp_field)
        date_signed = None if timestamp is None else _to_datetime(timestamp)
        if date_signed is None:
            raise BadTimeSignature(
                "Timestamp malformed", payload=payload, date_signed=None, reason="malformed"
            )

        if max_age is not None:
            age = int(time.time()) - timestamp
            if age < 0:
                raise SignatureExpired(
                    f"Signature age {age} < 0 seconds", payload=payload, date_signed=date_signed
                )
            if age > max_age:
                raise SignatureExpired(
                    f"Signature age {age} > {max_age} seconds",
                    payload=payload,
                    date_signed=date_signed,
                )

        if return_timestamp:
            return payload, date_signed
        return payload

    def validate(self, signed_value, max_age=None):
        """True if the token verifies, is not expired, and carries a timestamp."""
        try:
            self.unsign(signed_value, max_age=max_age)
        except BadSignature:
            return False
        return True
