"""Serialize-and-sign helpers (FP-02, FP-03, FP-04).

# spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151
# spec: N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158
# spec: N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165
# spec: N-000166 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
# spec: N-000173 N-000174 N-000175 N-000176 N-000177 N-000178 N-000179
# spec: N-000180 N-000181 N-000182 N-000183 N-000184 N-000185
# spec: N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000192
# spec: N-000214 N-000215 N-000216
# spec: N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235
# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242
# spec: N-000243 N-000244 N-000245 N-000246 N-000247 N-000248 N-000249
# spec: N-000250 N-000251 N-000252
# spec: N-000289 N-000290 N-000291 N-000292 N-000293 N-000294 N-000295
# spec: N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302
# spec: N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
# spec: N-000310 N-000350 N-000351 N-000352 N-000353 N-000354 N-000355
# spec: N-000356 N-000357 N-000358 N-000359 N-000360 N-000361 N-000362
# spec: N-000363 N-000364 N-000365 N-000366 N-000367 N-000368 N-000369
# spec: N-000370 N-000371 N-000372
"""

import json
import zlib
from collections.abc import Mapping

from ._encoding import b64decode_nopad, b64encode_nopad, want_bytes
from .exceptions import BadPayload, BadSignature, SignatureExpired
from .signer import DEFAULT_SALT, Signer, TimestampSigner

# Compact JSON for the URL-safe helpers: no whitespace outside strings.
_COMPACT_JSON = {"separators": (",", ":")}


class Serializer:
    """Serializes an object with a dump/load object, then signs the payload."""

    #: Signer class used when ``signer`` is omitted.
    default_signer = Signer
    #: True for helpers that expect a timestamped signer and accept max_age.
    _timed = False
    #: True for the URL-safe helpers: text tokens and optional compression.
    _url_safe = False

    def __init__(self, secret_key, salt=DEFAULT_SALT, serializer=None, serializer_kwargs=None,
                 signer=None, signer_kwargs=None, fallback_signers=None):
        self.secret_key = secret_key
        self.salt = salt
        if serializer is None:
            self.serializer = json
            default_kwargs = dict(_COMPACT_JSON) if self._url_safe else {}
        else:
            self.serializer = serializer
            default_kwargs = {}
        self.serializer_kwargs = {**default_kwargs, **(serializer_kwargs or {})}
        self.signer_class = self.default_signer if signer is None else signer
        self.signer_kwargs = dict(signer_kwargs or {})
        self.fallback_signers = list(fallback_signers or [])
        # Probe once: a dump/load object that produces str gets text on load.
        self._text_serializer = isinstance(
            self.serializer.dumps({}, **self.serializer_kwargs), str
        )
        # Build every signer now so a refused separator or key derivation fails here.
        list(self._iter_signers(None))

    def make_signer(self, salt=None):
        """The helper's own signer, using ``salt`` if given (``# spec: N-000160``)."""
        return self.signer_class(
            self.secret_key,
            salt=self.salt if salt is None else salt,
            **self.signer_kwargs,
        )

    def _iter_signers(self, salt):
        """The helper's signer, then each fallback in the order listed (FP-02)."""
        yield self.make_signer(salt)
        resolved_salt = self.salt if salt is None else salt
        for item in self.fallback_signers:
            if isinstance(item, type):
                signer_class, options = item, self.signer_kwargs
            elif isinstance(item, Mapping):
                signer_class, options = self.signer_class, item
            else:
                signer_class, options = item
            yield signer_class(self.secret_key, **{"salt": resolved_salt, **options})

    def _dump_raw(self, obj):
        raw = self.serializer.dumps(obj, **self.serializer_kwargs)
        return want_bytes(raw), isinstance(raw, str)

    def _encode_section(self, raw, sep):
        """Payload section: URL-safe base64, or sep + compressed base64 when shorter."""
        encoded = b64encode_nopad(raw)
        marked = sep + b64encode_nopad(zlib.compress(raw, 9))
        return marked if len(marked) < len(encoded) else encoded

    def _decode_section(self, section, sep):
        if not self._url_safe:
            return section
        try:
            if section.startswith(sep):
                return zlib.decompress(b64decode_nopad(section[len(sep):]))
            return b64decode_nopad(section)
        except (ValueError, zlib.error) as error:
            raise BadPayload("Payload could not be decoded", original_error=error) from error

    def _load_raw(self, raw):
        try:
            data = raw.decode("utf-8") if self._text_serializer else raw
            return self.serializer.loads(data)
        except Exception as error:
            raise BadPayload("Payload could not be deserialized", original_error=error) from error

    def _load_section(self, signer, section):
        return self._load_raw(self._decode_section(section, signer.sep))

    def _unsign(self, signed_value, salt=None, max_age=None):
        """Verify with each configured signer in turn.

        Returns ``(signer, payload_section, signed_at, refusal)``; ``refusal`` is
        ``None`` when some configuration verified the token. An expired token
        ends the search (FP-03). A refusal from the last signer is returned.
        """
        signer = refusal = None
        for signer in self._iter_signers(salt):
            try:
                if self._timed:
                    payload, signed_at = signer.unsign(
                        signed_value, max_age=max_age, return_timestamp=True
                    )
                else:
                    payload, signed_at = signer.unsign(signed_value), None
                return signer, payload, signed_at, None
            except SignatureExpired as error:
                return signer, error.payload, None, error
            except BadSignature as error:
                refusal = error
        return signer, refusal.payload, None, refusal

    def dumps(self, obj, salt=None):
        """Return the signed token: text for text dump output or URL-safe helpers."""
        signer = self.make_signer(salt)
        raw, is_text = self._dump_raw(obj)
        section = self._encode_section(raw, signer.sep) if self._url_safe else raw
        token = signer.sign(section)
        if is_text or self._url_safe:
            return token.decode("utf-8")
        return token

    def dump(self, obj, f, salt=None):
        """Write the ``dumps`` token to a stream."""
        f.write(self.dumps(obj, salt=salt))

    def loads(self, s, salt=None):
        """Verify and deserialize a token, or raise a failure class."""
        signer, payload, _, refusal = self._unsign(s, salt)
        if refusal is not None:
            raise refusal
        return self._load_section(signer, payload)

    def load(self, f, salt=None):
        """``loads`` of the whole stream."""
        return self.loads(f.read(), salt=salt)

    def loads_unsafe(self, s, salt=None):
        """Return ``(signature_valid, obj)``; ``BadPayload`` only for a verified token."""
        return self._loads_unsafe(s, salt)

    def load_unsafe(self, f, salt=None):
        """``loads_unsafe`` of the whole stream."""
        return self.loads_unsafe(f.read(), salt=salt)

    def _loads_unsafe(self, s, salt, max_age=None):
        signer, payload, _, refusal = self._unsign(s, salt, max_age=max_age)
        if refusal is None:
            return True, self._load_section(signer, payload)
        if payload is None:
            return False, None
        try:
            return False, self._load_section(signer, payload)
        except BadPayload:
            return False, None


class TimedSerializer(Serializer):
    """Serialize-and-sign with a signing time and an optional maximum age."""

    default_signer = TimestampSigner
    _timed = True

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        """Verify, check age, and deserialize; optionally return ``(obj, signed_at)``."""
        signer, payload, signed_at, refusal = self._unsign(s, salt, max_age=max_age)
        if refusal is not None:
            raise refusal
        obj = self._load_section(signer, payload)
        return (obj, signed_at) if return_timestamp else obj

    def load(self, f, max_age=None, return_timestamp=False, salt=None):
        return self.loads(f.read(), max_age=max_age, return_timestamp=return_timestamp, salt=salt)

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe(s, salt, max_age=max_age)

    def load_unsafe(self, f, max_age=None, salt=None):
        return self.loads_unsafe(f.read(), max_age=max_age, salt=salt)


class URLSafeSerializer(Serializer):
    """Serializer whose tokens are text in the URL-safe alphabet (FP-04)."""

    _url_safe = True


class URLSafeTimedSerializer(TimedSerializer):
    """URL-safe serializer that also records and checks a signing time (FP-04, FP-03)."""

    _url_safe = True
