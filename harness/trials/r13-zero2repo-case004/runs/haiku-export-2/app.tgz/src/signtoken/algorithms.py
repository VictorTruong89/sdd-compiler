"""Signing algorithms that a signer can be given as ``algorithm=``.

# spec: N-000347 N-000348 N-000349
"""

import hashlib
import hmac


class HMACAlgorithm:
    """HMAC (RFC 2104) over the payload. SHA-1 unless a digest is given."""

    def __init__(self, digest_method=None):
        self.digest_method = hashlib.sha1 if digest_method is None else digest_method

    def get_signature(self, key, value):
        return hmac.new(key, value, self.digest_method).digest()

    def verify_signature(self, key, value, signature):
        return hmac.compare_digest(self.get_signature(key, value), signature)


class NoneAlgorithm:
    """No-op algorithm: the signature is always empty, so nothing is detected."""

    def get_signature(self, key, value):
        return b""

    def verify_signature(self, key, value, signature):
        return hmac.compare_digest(b"", signature)
