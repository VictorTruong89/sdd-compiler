"""Failure classes raised by every refusal in the library.

# spec: N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379
# spec: N-000380 N-000381
"""


class BadData(Exception):
    """Base class of all signtoken failures."""


class BadSignature(BadData):
    """The signature does not match, or the token has no separator.

    ``payload`` is the unverified payload section as bytes, or ``None`` when
    the token has none.
    """

    def __init__(self, message="", payload=None):
        super().__init__(message)
        self.payload = payload


class BadTimeSignature(BadSignature):
    """A timestamped token was refused for its time field.

    ``reason`` is ``"missing"``, ``"malformed"``, or ``None`` for a plain
    time-signature failure. ``date_signed`` is a UTC ``datetime`` or ``None``.
    """

    def __init__(self, message="", payload=None, date_signed=None, reason=None):
        super().__init__(message, payload)
        self.date_signed = date_signed
        self.reason = reason


class SignatureExpired(BadTimeSignature):
    """The signature verified but the signing time is outside ``max_age``."""

    def __init__(self, message="", payload=None, date_signed=None):
        super().__init__(message, payload, date_signed, reason=None)


class BadPayload(BadData):
    """The signature verified but the payload could not be decoded.

    ``original_error`` is the exception the decoder or dump/load object raised.
    """

    def __init__(self, message="", original_error=None):
        super().__init__(message)
        self.original_error = original_error
