"""Byte and base64 helpers shared by the signer and serializer modules.

Nothing here is exported from the package root.
"""

import base64
import re

_URLSAFE_B64 = re.compile(rb"[A-Za-z0-9_-]*")


def want_bytes(value, encoding="utf-8"):
    """Return ``value`` as bytes; text is encoded as UTF-8."""
    if isinstance(value, str):
        return value.encode(encoding)
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    raise TypeError(f"expected str or bytes, got {type(value).__name__}")


def b64encode_nopad(data):
    """URL-safe base64 (RFC 4648 section 5) with ``=`` padding removed."""
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def b64decode_nopad(data):
    """Strictly decode unpadded URL-safe base64.

    Raises ``ValueError`` for anything that is not the canonical encoding of
    some byte string, so that no altered section can decode to the same bytes.
    """
    if not _URLSAFE_B64.fullmatch(data) or len(data) % 4 == 1:
        raise ValueError("not URL-safe base64")
    raw = base64.urlsafe_b64decode(data + b"=" * (-len(data) % 4))
    if b64encode_nopad(raw) != data:
        raise ValueError("non-canonical URL-safe base64")
    return raw
