from __future__ import annotations

import base64
import re

_ALPHABET = re.compile(rb"^[A-Za-z0-9_-]*$")


def want_bytes(s, encoding="utf-8", errors="strict"):
    if isinstance(s, str):
        return s.encode(encoding, errors)
    return bytes(s)


def base64_encode(string):
    return base64.urlsafe_b64encode(want_bytes(string)).rstrip(b"=")


def base64_decode(string):
    try:
        data = want_bytes(string, "ascii")
    except UnicodeEncodeError as e:
        raise ValueError("invalid base64") from e
    if not _ALPHABET.match(data) or len(data) % 4 == 1:
        raise ValueError("invalid base64")
    return base64.urlsafe_b64decode(data + b"=" * (-len(data) % 4))


def int_to_bytes(num):
    out = bytearray()
    while num:
        out.append(num & 0xFF)
        num >>= 8
    return bytes(reversed(out))


def bytes_to_int(b):
    return int.from_bytes(b, "big")
