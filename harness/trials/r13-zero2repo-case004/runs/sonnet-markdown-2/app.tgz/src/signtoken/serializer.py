from __future__ import annotations

import json
import zlib

from .encoding import base64_decode, base64_encode, want_bytes
from .exc import BadPayload, BadSignature, SignatureExpired
from .signer import Signer, TimestampSigner


class _CompactJSON:
    @staticmethod
    def loads(payload):
        return json.loads(payload)

    @staticmethod
    def dumps(obj, **kwargs):
        kwargs.setdefault("separators", (",", ":"))
        return json.dumps(obj, **kwargs)


class Serializer:
    default_serializer = json
    default_signer = Signer
    default_fallback_signers = []
    default_salt = b"signtoken.Serializer"

    def __init__(self, secret_key, salt=None, serializer=None, serializer_kwargs=None,
                 signer=None, signer_kwargs=None, fallback_signers=None):
        self.secret_key = secret_key
        self.salt = want_bytes(salt if salt is not None else self.default_salt)
        if serializer is None:
            serializer = self.default_serializer
        self.serializer = serializer
        self.is_text_serializer = isinstance(serializer.dumps({}), str)
        if signer is None:
            signer = self.default_signer
        self.signer = signer
        self.signer_kwargs = dict(signer_kwargs or {})
        if fallback_signers is None:
            fallback_signers = list(self.default_fallback_signers)
        self.fallback_signers = list(fallback_signers)
        self.serializer_kwargs = dict(serializer_kwargs or {})
        # fail early on illegal signer options
        self.make_signer()

    def load_payload(self, payload, serializer=None):
        if serializer is None:
            serializer = self.serializer
            is_text = self.is_text_serializer
        else:
            is_text = isinstance(serializer.dumps({}), str)
        try:
            if is_text:
                return serializer.loads(payload.decode("utf-8"))
            return serializer.loads(payload)
        except Exception as e:
            raise BadPayload("Could not load the payload because an exception occurred "
                             "on unserializing the data.", original_error=e) from e

    def dump_payload(self, obj):
        return want_bytes(self.serializer.dumps(obj, **self.serializer_kwargs))

    def make_signer(self, salt=None):
        if salt is None:
            salt = self.salt
        return self.signer(self.secret_key, salt=salt, **self.signer_kwargs)

    def iter_unsigners(self, salt=None):
        if salt is None:
            salt = self.salt
        yield self.make_signer(salt)
        for fallback in self.fallback_signers:
            if isinstance(fallback, dict):
                cls, kwargs = self.signer, fallback
            elif isinstance(fallback, tuple):
                cls, kwargs = fallback
            else:
                cls, kwargs = fallback, self.signer_kwargs
            yield cls(self.secret_key, salt=salt, **kwargs)

    def dumps(self, obj, salt=None):
        payload = self.dump_payload(obj)
        rv = self.make_signer(salt).sign(payload)
        if self.is_text_serializer:
            return rv.decode("utf-8")
        return rv

    def dump(self, obj, f, salt=None):
        f.write(self.dumps(obj, salt))

    def _loads_impl(self, s, salt, **kwargs):
        s = want_bytes(s)
        last = None
        for signer in self.iter_unsigners(salt):
            try:
                return signer.unsign(s, **kwargs)
            except SignatureExpired:
                raise
            except BadSignature as err:
                last = err
        raise last

    def loads(self, s, salt=None, **kwargs):
        return self.load_payload(self._loads_impl(s, salt))

    def load(self, f, salt=None):
        return self.loads(f.read(), salt)

    def loads_unsafe(self, s, salt=None):
        return self._loads_unsafe_impl(s, salt)

    def _loads_unsafe_impl(self, s, salt, load_kwargs=None, load_payload_kwargs=None):
        try:
            return True, self.loads(s, salt=salt, **(load_kwargs or {}))
        except BadSignature as e:
            if e.payload is None:
                return False, None
            try:
                return False, self.load_payload(e.payload, **(load_payload_kwargs or {}))
            except BadPayload:
                return False, None

    def load_unsafe(self, f, salt=None):
        return self.loads_unsafe(f.read(), salt=salt)


class TimedSerializer(Serializer):
    default_signer = TimestampSigner

    def loads(self, s, max_age=None, return_timestamp=False, salt=None):
        s = want_bytes(s)
        result = self._loads_impl(s, salt, max_age=max_age, return_timestamp=return_timestamp)
        if return_timestamp:
            payload, ts = result
            return self.load_payload(payload), ts
        return self.load_payload(result)

    def loads_unsafe(self, s, max_age=None, salt=None):
        return self._loads_unsafe_impl(s, salt, load_kwargs={"max_age": max_age})


class _URLSafeMixin:
    default_serializer = _CompactJSON

    def load_payload(self, payload, *args, **kwargs):
        payload = want_bytes(payload)
        sep = self._payload_sep()
        decompress = False
        if payload.startswith(sep):
            payload = payload[len(sep):]
            decompress = True
        try:
            json_data = base64_decode(payload)
        except Exception as e:
            raise BadPayload("Could not base64 decode the payload because of an exception",
                             original_error=e) from e
        if decompress:
            try:
                json_data = zlib.decompress(json_data)
            except Exception as e:
                raise BadPayload("Could not zlib decompress the payload before decoding the payload",
                                 original_error=e) from e
        return super().load_payload(json_data, *args, **kwargs)

    def dump_payload(self, obj):
        json_data = super().dump_payload(obj)
        is_compressed = False
        compressed = zlib.compress(json_data)
        if len(compressed) < (len(json_data) - 1):
            json_data = compressed
            is_compressed = True
        base64d = base64_encode(json_data)
        if is_compressed:
            base64d = self._payload_sep() + base64d
        return base64d

    def _payload_sep(self):
        return want_bytes(self.signer_kwargs.get("sep", "."))


class URLSafeSerializer(_URLSafeMixin, Serializer):
    pass


class URLSafeTimedSerializer(_URLSafeMixin, TimedSerializer):
    pass
