"""Parameter objects: options and arguments."""

from __future__ import annotations

import re
from typing import Any, Callable, List, Optional, Sequence

from ._exceptions import BadParameter, DeclarationError, MissingParameter
from ._types import BOOL, FLOAT, INT, STRING, UNPROCESSED, File, ParamType, Path, Tuple, _resolve_type

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_PREFIX_CHARS = "-/+"
_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}
MISSING = object()  # no value from the command line
NO_VALUE = object()  # flag present without a value


def _is_option_name(s: str) -> bool:
    return bool(s) and s[0] in _PREFIX_CHARS and len(s) > 1


def _split_decls(param_decls: Sequence[str]):
    """Return (dest, flag_names, secondary_names)."""
    dest = None
    names: List[str] = []
    secondary: List[str] = []
    for decl in param_decls:
        if not isinstance(decl, str) or decl == "":
            raise DeclarationError(f"Invalid parameter declaration: {decl!r}")
        if _is_option_name(decl):
            if decl[0] in "-+" and "/" in decl:
                first, second = decl.split("/", 1)
                names.append(first)
                secondary.append(second)
            else:
                names.append(decl)
        else:
            if dest is not None:
                raise DeclarationError("Only one destination name is allowed.")
            if not _IDENT.match(decl):
                raise DeclarationError(f"Destination {decl!r} is not a valid identifier.")
            dest = decl
    if dest is None:
        candidates = [n.lstrip("".join(_PREFIX_CHARS)) for n in names]
        long_names = [n for n in names if n.startswith(("--", "++", "//")) or (n[0] != "-" and len(n) > 2)]
        # Preference: a long name, else the first short name.
        chosen = None
        if long_names:
            chosen = long_names[0].lstrip("-+/")
        elif names:
            chosen = names[0].lstrip("-+/")
        dest = chosen.replace("-", "_") if chosen else None
    return dest, names, secondary


class Parameter:
    """Common base for options and arguments."""

    param_type_name = "parameter"
    is_flag = False
    count = False
    is_bool_flag = False
    optional_value = False
    is_pair = False
    prompt = None
    prompt_required = False
    hide_input = False
    confirmation_prompt = False
    flag_value_arg = None
    variadic = False
    flag_value = None

    def __init__(
        self,
        param_decls=(),
        type=None,
        default=None,
        required=None,
        nargs=None,
        multiple=False,
        envvar=None,
        allow_from_autoenv=True,
        callback: Optional[Callable] = None,
        is_eager=False,
        expose_value=True,
        hidden=False,
        deprecated=False,
        help=None,
        metavar=None,
        show_default=None,
        show_envvar=False,
        shell_complete=None,
        hidden_from_callback=False,
    ) -> None:
        self.type_arg = type
        self.default = default
        self.multiple = bool(multiple)
        self.allow_from_autoenv = allow_from_autoenv
        self.callback = callback
        self.is_eager = bool(is_eager)
        self.expose_value = bool(expose_value)
        self.hidden = bool(hidden)
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete_func = shell_complete
        self.hidden_from_callback = hidden_from_callback
        if envvar is None:
            self.envvar: List[str] = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.required = bool(required) if required is not None else False
        self._required_given = required is not None
        self.nargs = nargs
        self.type: ParamType = STRING

    # helpers shared by subclasses ----------------------------------------
    def _finish_type(self, is_flag_bool: bool = False) -> None:
        t = self.type_arg
        if isinstance(t, Tuple):
            self.type = t
            self.nargs = t.arity
        elif t is not None:
            self.type = _resolve_type(t)
        elif is_flag_bool:
            self.type = BOOL
        else:
            self.type = self._infer_type()
        if isinstance(self.type, Tuple):
            self.nargs = self.type.arity
        if self.nargs is None:
            self.nargs = 1

    def _infer_type(self) -> ParamType:
        d = self.default
        if d is None or callable(d):
            return STRING
        if self.multiple and isinstance(d, (list, tuple)) and d:
            d = d[0]
        if isinstance(d, bool):
            return BOOL
        if isinstance(d, int):
            return INT
        if isinstance(d, float):
            return FLOAT
        if isinstance(d, (list, tuple)) and d:
            return Tuple([type(x) for x in d]) if all(isinstance(x, (int, float, str)) for x in d) else STRING
        return STRING

    @property
    def is_unary(self) -> bool:
        return self.nargs == 1 and not isinstance(self.type, Tuple)

    def get_error_hint(self) -> str:
        return self.name

    def get_metavar(self) -> Optional[str]:
        if self.metavar is not None:
            return self.metavar
        return None

    def type_metavar(self) -> str:
        return self.type.get_metavar(self) or self.type.name.upper()

    @property
    def is_deprecated(self) -> bool:
        return bool(self.deprecated)

    def deprecation_message(self) -> str:
        label = self.get_error_hint()
        note = self.deprecated if isinstance(self.deprecated, str) else None
        msg = f"DeprecationWarning: The {self.param_type_name} '{label}' is deprecated."
        if note:
            msg += f" {note}"
        return msg

    def process_value(self, ctx, value):
        """Run the parameter callback. May replace the value or raise BadParameter."""
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def shell_complete(self, ctx, incomplete: str):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    # conversion ------------------------------------------------------------
    def convert_one(self, raw, ctx):
        """Convert one occurrence (a token, or a sequence of tokens for nargs > 1)."""
        if isinstance(self.type, Tuple):
            return self.type.convert(list(raw), self, ctx)
        if self.nargs != 1:
            raw = list(raw)
            if len(raw) != self.nargs:
                raise BadParameter(f"Takes {self.nargs} values but {len(raw)} were given.", ctx, self)
            return tuple(self.type.convert(v, self, ctx) for v in raw)
        return self.type.convert(raw, self, ctx)

    def convert_occurrences(self, occurrences: list, ctx):
        """Convert gathered occurrences into the delivered shape."""
        if self.multiple:
            return tuple(self.convert_one(o, ctx) for o in occurrences)
        if not occurrences:
            return None
        return self.convert_one(occurrences[-1], ctx)

    def convert_default(self, value, ctx):
        if value is None:
            return None
        if self.is_flag or self.count:
            # Flags and counters are scalar; their defaults are used as given.
            return value if not isinstance(value, str) else self.type.convert(value, self, ctx)
        if self.multiple:
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    f"The default for this option needs an iterable (sequence) default, not {value!r}.",
                    ctx, self,
                )
            return tuple(self.convert_one(v, ctx) if not self._already(v) else v for v in value)
        if self.nargs != 1 and not isinstance(value, (list, tuple)):
            value = [value]
        if self._already(value):
            return value
        if self.nargs != 1 or isinstance(self.type, Tuple):
            return self.convert_one(value, ctx)
        return self.type.convert(value, self, ctx)

    def _already(self, value) -> bool:
        return False

    def split_env(self, raw: str) -> list:
        """Split a non-empty environment string into occurrence tokens."""
        if self.is_unary and not self.multiple:
            return [raw]
        return self.type.split_envvar_value(raw)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} {self.name}>"


class Option(Parameter):
    """A named parameter introduced by a prefix."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls=(),
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=None,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        required=None,
        default=None,
        **kwargs,
    ) -> None:
        dest, names, secondary = _split_decls(param_decls)
        if not names:
            if dest is None:
                raise DeclarationError("An option needs at least one flag name.")
            names = ["--" + dest.replace("_", "-")]
        self.opts = names
        self.secondary_opts = secondary
        self.count = bool(count)
        self.prompt = prompt
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)
        self.flag_value_arg = flag_value
        self.is_pair = bool(secondary)
        is_bool_default = isinstance(default, bool)
        if is_flag is None:
            is_flag = self.is_pair or is_bool_default or flag_value is not None or self.count
        self.is_flag = bool(is_flag) or self.is_pair
        if self.count:
            self.is_flag = False
        self.is_bool_flag = self.is_flag and not self.count and (
            self.is_pair or flag_value is None or isinstance(flag_value, bool)
        )
        self.optional_value = (not self.is_flag and not self.count and flag_value is not None)
        if self.is_flag and flag_value is None and not self.count:
            flag_value = True
        self.flag_value = flag_value
        self.default = default
        self.dest = dest
        nargs = kwargs.pop("nargs", None)
        if self.is_flag or self.count:
            nargs = 0
        elif nargs is None:
            nargs = 1
        super().__init__(param_decls, default=default, required=required, nargs=nargs, **kwargs)
        self.name = dest if dest is not None else names[0].lstrip("-+/").replace("-", "_")
        if self.name == "" or not _IDENT.match(self.name):
            self.name = re.sub(r"\W", "_", self.name) or "option"
        if self.count:
            self.type = INT if self.type_arg is None else _resolve_type(self.type_arg)
            self.nargs = 0
        else:
            self._finish_type(is_flag_bool=self.is_bool_flag and self.type_arg is None)
            if self.is_flag:
                self.nargs = 0
                if not self.is_bool_flag and self.type_arg is None:
                    self.type = _resolve_type(type(flag_value)) if flag_value is not None else STRING
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if self.multiple and self.default is not None and not isinstance(self.default, (list, tuple)) and not callable(self.default):
            pass  # reported at parse time as a usage error
        if self.multiple and self.nargs < 1:
            raise DeclarationError("A repeatable flag option must have a value.")

    @property
    def is_unary(self) -> bool:
        return self.nargs == 1 and not isinstance(self.type, Tuple) and not self.is_flag

    @property
    def takes_value(self) -> bool:
        return not self.is_flag

    def get_error_hint(self) -> str:
        return " / ".join(self.opts + self.secondary_opts)

    def get_metavar(self) -> Optional[str]:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag:
            return None
        return self.type_metavar()

    def _already(self, value) -> bool:
        if isinstance(self.type, Tuple):
            return isinstance(value, tuple)
        return isinstance(value, self.type_python_class()) if self.type_python_class() else False

    def type_python_class(self):
        return {"integer": int, "float": float, "boolean": bool, "text": str}.get(self.type.name)

    def flag_default_for(self, source_default):
        return source_default

    def env_bool(self, raw: str):
        """Interpret an environment string for a boolean flag. None means unset."""
        text = raw.strip().lower()
        if text == "":
            return False
        if text in _TRUE_ENV:
            return True
        if text in _FALSE_ENV:
            return False
        if self.is_bool_flag and self.flag_value is not None and isinstance(self.flag_value, bool) is False:
            if text == str(self.flag_value).lower():
                return True
        if self.is_bool_flag:
            raise BadParameter(f"{raw!r} is not a valid boolean.", None, self)
        return None


class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(self, param_decls=(), required=None, default=None, nargs=None, **kwargs) -> None:
        dest, names, _ = _split_decls(param_decls)
        if names:
            raise DeclarationError("Arguments take a destination name only.")
        if dest is None:
            raise DeclarationError("An argument needs a destination name.")
        if nargs is not None and nargs != -1 and nargs < 1:
            raise DeclarationError("nargs must be a positive integer or -1.")
        self.name = dest
        self.dest = dest
        self.opts = []
        self.secondary_opts = []
        self.default = default
        if required is None:
            # Variadic arguments are optional unless the author marks them required.
            required = default is None and nargs != -1
        super().__init__(param_decls, default=default, required=required, nargs=nargs, **kwargs)
        self.variadic = nargs == -1
        self._finish_type()
        if self.variadic:
            self.nargs = -1
        if self.variadic and self.nargs is None:
            self.nargs = -1
        self.multiple = self.variadic
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")
        if self.variadic and not self.required and self._required_given is False:
            pass

    @property
    def is_unary(self) -> bool:
        return self.nargs == 1 and not isinstance(self.type, Tuple)

    @property
    def arity_slots(self) -> int:
        return 0 if self.variadic else (self.type.arity if isinstance(self.type, Tuple) else self.nargs)

    def get_error_hint(self) -> str:
        return self.name

    def get_metavar(self) -> Optional[str]:
        return self.metavar

    def placeholder(self) -> str:
        return self.metavar if self.metavar is not None else self.name.upper()

    def _already(self, value) -> bool:
        return False

    def convert_occurrences(self, tokens: list, ctx):
        if self.variadic:
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        if self.is_unary:
            return self.type.convert(tokens[0], self, ctx)
        if isinstance(self.type, Tuple):
            return self.type.convert(list(tokens), self, ctx)
        return tuple(self.type.convert(t, self, ctx) for t in tokens)


__all__ = ["Parameter", "Option", "Argument", "MISSING", "NO_VALUE", "_split_decls"]
