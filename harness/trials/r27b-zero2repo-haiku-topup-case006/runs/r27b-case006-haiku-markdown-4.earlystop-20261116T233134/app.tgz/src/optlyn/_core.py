"""Command, Group, CommandCollection: parsing, value resolution and dispatch."""

from __future__ import annotations

import os
import re
import sys
from typing import Any, Dict, List, Optional

from ._context import Context, ParameterSource, get_current_context
from ._exceptions import (
    Abort,
    BadArgumentUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingCommand,
    MissingParameter,
    NoSuchCommand,
    OptlynError,
    UsageError,
)
from ._help import format_help, usage_line
from ._params import MISSING, NO_VALUE, Argument, Option, Parameter
from ._parser import Parser
from ._types import Tuple
from . import _terminal as term

CHAIN_MARK = object()  # invoked_subcommand value while a chain runs its children


class SilentUsageError(UsageError):
    """Usage failure whose report has already been written (e.g. help shown)."""

    def show(self, file=None) -> None:
        return None


def _env_name_parts(ctx: Context, dest: str) -> Optional[str]:
    prefix = ctx.auto_envvar_prefix
    if not prefix:
        return None
    parts = []
    node = ctx
    while node is not None and node.parent is not None:
        parts.insert(0, node.info_name or "")
        node = node.parent
    segs = [prefix] + parts + [dest]
    return "_".join(re.sub(r"[-\s]", "_", s).upper() for s in segs if s)


def _occurrences_from_flat(param: Parameter, tokens: List[str]) -> List[Any]:
    """Group a flat token list into per-occurrence raw values."""
    if isinstance(param, Argument) and param.variadic:
        return list(tokens)
    if isinstance(param.type, Tuple) or param.nargs != 1:
        n = param.type.arity if isinstance(param.type, Tuple) else param.nargs
        return [tokens[i:i + n] for i in range(0, len(tokens) - n + 1, n)]
    return list(tokens)


class Command:
    """A leaf command: runs a callback with converted parameter values."""

    is_group = False
    chain = False

    def __init__(
        self,
        name: Optional[str] = None,
        callback=None,
        params=None,
        help: Optional[str] = None,
        epilog: Optional[str] = None,
        short_help: Optional[str] = None,
        options_metavar: Optional[str] = "[OPTIONS]",
        context_settings: Optional[dict] = None,
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        deprecated=False,
        hidden: bool = False,
        **extra,
    ) -> None:
        self.name = name
        self.callback = callback
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra
        self.params: List[Parameter] = list(params or [])
        self.arguments: List[Argument] = [p for p in self.params if isinstance(p, Argument)]
        variadic = [a for a in self.arguments if a.variadic]
        if len(variadic) > 1:
            raise DeclarationError("Only one variadic argument is allowed per command.")
        if name is None and callback is not None:
            self.name = _name_from_callback(callback)

    # --- inspection -----------------------------------------------------
    @property
    def options(self) -> List[Option]:
        return [p for p in self.params if isinstance(p, Option)]

    def get_help(self, ctx) -> str:
        return format_help(self, ctx)

    def get_usage(self, ctx) -> str:
        return usage_line(self, ctx)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # --- running ----------------------------------------------------------
    def make_context(self, info_name: Optional[str], args, parent: Optional[Context] = None, **extra) -> Context:
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        ctx._args = list(args)
        return ctx

    def main(
        self,
        args=None,
        prog_name: Optional[str] = None,
        complete_var: Optional[str] = None,
        standalone_mode: bool = True,
        **extra,
    ):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "") or (self.name or "cli")
            if prog_name.endswith((".py", ".exe")):
                prog_name = prog_name.rsplit(".", 1)[0]
        var = complete_var or "_" + re.sub(r"[-\s.]", "_", prog_name).upper() + "_COMPLETE"
        instruction = os.environ.get(var)
        if instruction:
            from ._completion import run_completion

            return run_completion(self, prog_name, instruction, standalone_mode)

        ctx = None
        try:
            ctx = self.make_context(prog_name, args, **extra)
            with ctx:
                rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            return rv
        except Exit as e:
            if not standalone_mode:
                return None
            _exit(e.exit_code)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            _exit(e.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            term.echo("Aborted!", err=True)
            _exit(1)
        finally:
            if ctx is not None:
                ctx.close()
        return None

    def invoke(self, ctx: Context, bypass_parse: bool = False):
        with ctx:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else None
                msg = f"DeprecationWarning: The command {ctx.command_path!r} is deprecated."
                if note:
                    msg += f" {note}"
                term.echo(msg, err=True)
            rest: List[str] = []
            if not bypass_parse:
                rest = self._parse_and_bind(ctx, getattr(ctx, "_args", []))
            return self._run(ctx, rest)

    def _run(self, ctx: Context, rest: List[str]):
        if rest:
            raise UsageError(f"Got unexpected extra argument ({' '.join(rest)})", ctx)
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params
                  if p.expose_value and not p.hidden_from_callback}
        return self.callback(**kwargs)

    # --- parsing ----------------------------------------------------------
    def _parser_for(self, ctx: Context, chain: bool = False) -> Parser:
        options = self.options
        author_names = set()
        for opt in options:
            author_names.update(opt.opts + opt.secondary_opts)
        norm = ctx.token_normalize_func or (lambda s: s)
        help_names = []
        if self.add_help_option:
            help_names = [n for n in (ctx.help_option_names or ["--help"])
                          if norm(n) not in {norm(a) for a in author_names}]
        if self.is_group:
            stop_at = True
            interspersed = bool(ctx.allow_interspersed_args) if ctx.allow_interspersed_args is not None else False
        else:
            stop_at = False
            interspersed = bool(ctx.allow_interspersed_args) if ctx.allow_interspersed_args is not None else True
        if any(a.variadic for a in self.arguments):
            slots = None
        else:
            slots = sum(a.arity_slots for a in self.arguments)
        return Parser(
            options,
            help_names,
            on_eager=lambda opt, payload: self._on_eager(ctx, opt, payload),
            interspersed=interspersed,
            ignore_unknown=bool(ctx.ignore_unknown_options),
            stop_at_positional=stop_at,
            arg_slots=slots,
            stop_when_full=chain,
            normalize=norm,
            ctx=ctx,
        )

    def _on_eager(self, ctx: Context, opt, payload) -> None:
        if opt is None:
            term.echo(ctx.get_help(), nl=False)
            raise Exit(0)
        if opt.callback is not None:
            opt.process_value(ctx, payload)

    def _parse_and_bind(self, ctx: Context, args: List[str], chain: bool = False) -> List[str]:
        """Parse tokens, bind arguments and resolve values. Returns unconsumed tokens."""
        if self.no_args_is_help and not args:
            # "No arguments means help" is a usage failure: help goes to stderr, exit 2.
            term.echo(ctx.get_help(), err=True, nl=False)
            raise SilentUsageError("", ctx)
        parser = self._parser_for(ctx, chain=chain)
        res = parser.parse(list(args))
        bound, extra = self._bind_arguments(ctx, res.positional)
        if extra and not chain and not self.is_group and not ctx.allow_extra_args:
            raise UsageError(
                f"Got unexpected extra argument{'s' if len(extra) > 1 else ''} ({' '.join(extra)})", ctx
            )
        ctx.args = list(extra)
        self._resolve(ctx, res.hits, bound)
        return list(res.rest)

    def _bind_arguments(self, ctx: Context, tokens: List[str]):
        values: Dict[Argument, Any] = {}
        i = 0
        n = len(tokens)
        for k, arg in enumerate(self.arguments):
            later_min = sum(
                0 if (a.variadic or not a.required) else a.arity_slots for a in self.arguments[k + 1:]
            )
            remaining = n - i
            if arg.variadic:
                take = max(0, remaining - later_min)
                if take == 0 and arg.required:
                    raise MissingParameter(f"Missing argument '{arg.name}'.", ctx, arg)
                toks = tokens[i:i + take]
                i += take
                if toks:
                    values[arg] = tuple(arg.type.convert(t, arg, ctx) for t in toks)
                continue
            need = arg.arity_slots
            if remaining >= need and remaining > 0:
                toks = tokens[i:i + need]
                i += need
                values[arg] = arg.convert_occurrences(toks, ctx)
            elif remaining == 0:
                if arg.required:
                    raise MissingParameter(f"Missing argument '{arg.name}'.", ctx, arg)
            else:
                if arg.required:
                    raise MissingParameter(f"Missing argument '{arg.name}'.", ctx, arg)
                raise BadArgumentUsage(f"Argument '{arg.name}' takes {need} values.", ctx)
        return values, tokens[i:]

    # --- value resolution -------------------------------------------------
    def _resolve(self, ctx: Context, hits, bound) -> None:
        by_dest: Dict[str, List[Parameter]] = {}
        for p in self.params:
            by_dest.setdefault(p.name, []).append(p)
        for dest, group in by_dest.items():
            winner = None
            with_hits = [p for p in group if any(h[0] is p for h in hits)]
            if with_hits:
                winner = with_hits[-1]
            else:
                winner = group[-1]
            p = winner
            if isinstance(p, Argument):
                value, source = self._resolve_argument(ctx, p, bound)
            else:
                value, source = self._resolve_option(ctx, p, [h for h in hits if h[0] is p])
            if source is None and p.required:
                raise MissingParameter(f"Missing {p.param_type_name} '{p.get_error_hint()}'.", ctx, p)
            if source is ParameterSource.COMMANDLINE and p.deprecated:
                term.echo(p.deprecation_message(), err=True)
            value = p.process_value(ctx, value)
            if p.expose_value:
                ctx._set_param(p.name, value, source)

    def _default_value(self, ctx: Context, p: Parameter):
        d = p.default
        if callable(d):
            d = d()
        if d is None:
            if p.is_flag and not p.count:
                return False
            if p.count:
                return 0
            if p.multiple:
                return ()
            return None
        return p.convert_default(d, ctx)

    def _default_map_value(self, ctx: Context, p: Parameter):
        dm = ctx.default_map
        if not isinstance(dm, dict) or p.name not in dm:
            return MISSING
        raw = dm[p.name]
        if isinstance(raw, str) and not p.is_flag:
            multi_valued = p.nargs != 1 or isinstance(p.type, Tuple)
            if multi_valued:
                # Split only when one occurrence takes several tokens.
                return p.convert_default(_occurrences_from_flat(p, p.split_env(raw)) if p.multiple
                                         else p.split_env(raw), ctx)
            # One token per occurrence: a string is not an iterable, so a
            # repeatable option refuses it inside convert_default.
            return p.convert_default(raw, ctx)
        return p.convert_default(raw, ctx)

    def _env_value(self, ctx: Context, p: Parameter):
        names = list(p.envvar)
        if isinstance(p, Option) and p.allow_from_autoenv:
            auto = _env_name_parts(ctx, p.name)
            if auto:
                names.append(auto)
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if p.is_flag and not p.count:
                flag = p.env_bool(raw)
                if flag is None:
                    continue
                return flag
            if p.count:
                continue
            tokens = p.split_env(raw)
            if not tokens:
                continue
            if p.multiple:
                occ = _occurrences_from_flat(p, tokens) if p.nargs != 1 else tokens
                return p.convert_occurrences(occ, ctx)
            if p.nargs != 1 or isinstance(p.type, Tuple):
                return p.convert_one(tokens[:p.nargs] if not isinstance(p, Argument) else tokens, ctx)
            return p.convert_one(raw if p.is_unary else tokens[0], ctx)
        return MISSING

    def _resolve_argument(self, ctx: Context, p: Argument, bound):
        if p in bound:
            value = bound[p]
            return value, ParameterSource.COMMANDLINE
        env = self._env_value(ctx, p)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT
        dm = self._default_map_value(ctx, p)
        if dm is not MISSING:
            return dm, ParameterSource.DEFAULT_MAP
        if p.variadic:
            return (), (ParameterSource.DEFAULT if not p.required else None)
        if p.default is None and not p.required:
            return None, None
        value = self._default_value(ctx, p)
        return value, ParameterSource.DEFAULT if p.default is not None else None

    def _resolve_option(self, ctx: Context, p: Option, hits):
        if p.count:
            n = len(hits)
            if n:
                return n, ParameterSource.COMMANDLINE
            env = self._env_value(ctx, p)
            if env is not MISSING:
                return env, ParameterSource.ENVIRONMENT
            dm = self._default_map_value(ctx, p)
            if dm is not MISSING:
                return dm, ParameterSource.DEFAULT_MAP
            return self._default_value(ctx, p), ParameterSource.DEFAULT
        if p.is_flag:
            if hits:
                return hits[-1][2], ParameterSource.COMMANDLINE
            env = self._env_value(ctx, p)
            if env is not MISSING:
                return env, ParameterSource.ENVIRONMENT
            dm = self._default_map_value(ctx, p)
            if dm is not MISSING:
                return dm, ParameterSource.DEFAULT_MAP
            if p.default is None:
                return False, ParameterSource.DEFAULT
            return self._default_value(ctx, p), ParameterSource.DEFAULT

        # value options
        bare_flag = any(payload is NO_VALUE for _, _, payload in hits)
        if hits and not (bare_flag and p.prompt):
            occ = []
            for _, _, payload in hits:
                if payload is NO_VALUE:
                    occ.append(p.flag_value_arg if p.flag_value_arg is not None else p.default)
                elif p.nargs == 1 and not isinstance(p.type, Tuple):
                    occ.append(payload[0])
                else:
                    occ.append(list(payload))
            return p.convert_occurrences(occ, ctx), ParameterSource.COMMANDLINE
        env = self._env_value(ctx, p)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT
        dm_present = isinstance(ctx.default_map, dict) and p.name in ctx.default_map
        if p.prompt and (p.prompt_required or bare_flag):
            shown = ctx.default_map[p.name] if dm_present else p.default
            return self._prompt_for(ctx, p, shown), ParameterSource.PROMPT
        if dm_present:
            return self._default_map_value(ctx, p), ParameterSource.DEFAULT_MAP
        if p.default is None and not p.multiple:
            return None, None
        if p.default is None and p.multiple:
            return (), None
        return self._default_value(ctx, p), ParameterSource.DEFAULT

    def _prompt_for(self, ctx: Context, p: Option, default):
        if isinstance(p.prompt, str):
            text = p.prompt
        else:
            text = p.name.replace("_", " ").capitalize()
        if p.confirmation_prompt and not p.hide_input:
            pass
        value = term.prompt(
            text,
            default=default,
            hide_input=p.hide_input,
            confirmation_prompt=p.confirmation_prompt,
            type=p.type,
        )
        if p.multiple:
            return (value,)
        return value


def _exit(code: int):
    raise SystemExit(code)


def _name_from_callback(func) -> str:
    n = func.__name__.lower()
    for suf in ("_command", "_cmd", "_group", "_grp"):
        if n.endswith(suf) and len(n) > len(suf):
            n = n[: -len(suf)]
            break
    return n.replace("_", "-")


class Group(Command):
    """A command that dispatches to named subcommands."""

    is_group = True

    def __init__(
        self,
        name: Optional[str] = None,
        commands=None,
        invoke_without_command: bool = False,
        no_args_is_help: Optional[bool] = None,
        subcommand_metavar: Optional[str] = None,
        chain: bool = False,
        result_callback=None,
        **kwargs,
    ) -> None:
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = bool(invoke_without_command)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self.commands: Dict[str, Command] = {}
        self._result_callback = result_callback
        if commands:
            items = commands.items() if isinstance(commands, dict) else [(None, c) for c in commands]
            for key, cmd in items:
                self.add_command(cmd, key)

    # --- registration -----------------------------------------------------
    def add_command(self, cmd: Command, name: Optional[str] = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise DeclarationError("A subcommand needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from ._decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from ._decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # --- lookup (override points) -------------------------------------------
    def list_commands(self, ctx) -> List[str]:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name: str) -> Optional[Command]:
        norm = (ctx.token_normalize_func if ctx is not None else None) or (lambda s: s)
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        target = norm(cmd_name)
        for key, cmd in self.commands.items():
            if norm(key) == target:
                return cmd
        return None

    # --- running -------------------------------------------------------------
    def _run(self, ctx: Context, rest: List[str]):
        if not rest:
            if not self.invoke_without_command:
                raise MissingCommand("Missing command.", ctx)
            ctx.invoked_subcommand = None
            rv = self._call_group_callback(ctx)
            if self._result_callback is not None:
                return self._result_callback(([] if self.chain else rv), **self._group_params(ctx))
            return rv
        if self.chain:
            return self._run_chain(ctx, rest)
        name = rest[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, f"No such command {name!r}.", ctx)
        ctx.invoked_subcommand = name
        rv = self._call_group_callback(ctx)
        child = cmd.make_context(name, rest[1:], parent=ctx)
        result = cmd.invoke(child)
        if self._result_callback is not None:
            return self._result_callback(result, **self._group_params(ctx))
        return result

    def _run_chain(self, ctx: Context, rest: List[str]):
        ctx.invoked_subcommand = CHAIN_MARK
        self._call_group_callback(ctx)
        results = []
        tokens = list(rest)
        while tokens:
            name = tokens[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, f"No such command {name!r}.", ctx)
            child = cmd.make_context(name, tokens[1:], parent=ctx)
            with child:
                tokens = cmd._parse_and_bind(child, tokens[1:], chain=True)
                results.append(cmd._run(child, []))
            child.close()
        if self._result_callback is not None:
            return self._result_callback(results, **self._group_params(ctx))
        return results

    def _call_group_callback(self, ctx: Context):
        if self.callback is None:
            return None
        return self.callback(**self._group_params(ctx))

    def _group_params(self, ctx: Context) -> dict:
        return {p.name: ctx.params.get(p.name) for p in self.params
                if p.expose_value and not p.hidden_from_callback}


class CommandCollection(Group):
    """Presents the union of subcommands from several source groups."""

    def __init__(self, name: Optional[str] = None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> List[str]:
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name: str) -> Optional[Command]:
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            found = src.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


__all__ = ["Command", "Group", "CommandCollection", "SilentUsageError", "CHAIN_MARK"]
