"""Invocation context, value sources, and the thread-local current context."""

from __future__ import annotations

import enum
import functools
import threading
from contextlib import ExitStack
from typing import Any, Callable, Optional

from ._exceptions import Abort, Exit, OptlynError

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Ranked most explicit first."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_CONTEXT_KEYS = (
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args",
)


class Context:
    """Per-invocation state. Created by the library for each command run."""

    def __init__(
        self,
        command,
        parent: Optional["Context"] = None,
        info_name: Optional[str] = None,
        obj: Any = None,
        default_map: Optional[dict] = None,
        terminal_width: Optional[int] = None,
        max_content_width: Optional[int] = None,
        help_option_names: Optional[list] = None,
        token_normalize_func: Optional[Callable[[str], str]] = None,
        color: Optional[bool] = None,
        show_default: Optional[bool] = None,
        allow_extra_args: Optional[bool] = None,
        ignore_unknown_options: Optional[bool] = None,
        allow_interspersed_args: Optional[bool] = None,
        auto_envvar_prefix: Optional[str] = None,
        **extra,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self._obj = obj
        self._has_obj = obj is not None
        settings = dict(command.context_settings or {}) if command is not None else {}
        self.default_map = default_map if default_map is not None else settings.get("default_map")
        if parent is not None and self.default_map is None and parent.default_map is not None:
            # A group's map nests a dict under each child name.
            if info_name is not None and isinstance(parent.default_map, dict):
                nested = parent.default_map.get(info_name)
                if isinstance(nested, dict):
                    self.default_map = nested

        def pick(key, value, default):
            if value is not None:
                return value
            if key in settings and settings[key] is not None:
                return settings[key]
            if parent is not None:
                return getattr(parent, key)
            return default

        self.terminal_width = pick("terminal_width", terminal_width, None)
        self.max_content_width = pick("max_content_width", max_content_width, 80)
        self.help_option_names = pick("help_option_names", help_option_names, ["--help"])
        self.token_normalize_func = pick("token_normalize_func", token_normalize_func, None)
        self.color = pick("color", color, None)
        self.show_default = pick("show_default", show_default, None)
        self.allow_extra_args = pick("allow_extra_args", allow_extra_args, None)
        self.ignore_unknown_options = pick("ignore_unknown_options", ignore_unknown_options, None)
        self.allow_interspersed_args = pick("allow_interspersed_args", allow_interspersed_args, None)
        self.auto_envvar_prefix = pick("auto_envvar_prefix", auto_envvar_prefix, None)
        self.extra = extra
        self.params: dict = {}
        self._sources: dict = {}
        self.invoked_subcommand: Any = None
        self._close_callbacks: list = []
        self._exit_stack = ExitStack()
        self._entered = 0
        self._stack_ref = None

    # --- object handling -------------------------------------------------
    @property
    def obj(self):
        if self._has_obj:
            return self._obj
        if self.parent is not None:
            return self.parent.obj
        return None

    @obj.setter
    def obj(self, value) -> None:
        self._obj = value
        self._has_obj = True

    def find_object(self, object_type):
        node = self
        while node is not None:
            if node._has_obj and isinstance(node._obj, object_type):
                return node._obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # --- naming -----------------------------------------------------------
    @property
    def command_path(self) -> str:
        parts = []
        node = self
        while node is not None:
            if node.info_name:
                parts.append(node.info_name)
            node = node.parent
        return " ".join(reversed(parts))

    # --- sources and params ----------------------------------------------
    def get_parameter_source(self, name: str):
        return self._sources.get(name)

    def _set_param(self, name: str, value, source) -> None:
        self.params[name] = value
        self._sources[name] = source

    # --- resources ---------------------------------------------------------
    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, func: Callable[[], Any]) -> None:
        self._close_callbacks.append(func)

    def close(self) -> None:
        for func in reversed(self._close_callbacks):
            try:
                func()
            except Exception:
                pass
        self._close_callbacks = []
        self._exit_stack.close()

    # --- help -----------------------------------------------------------------
    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    # --- author actions ---------------------------------------------------
    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, cmd, **kwargs):
        """Run ``cmd`` with exactly the given values."""
        return self._run_child(cmd, kwargs, forward=False)

    def forward(self, cmd, **kwargs):
        """Run ``cmd`` with this command's values, plus any given overrides."""
        values = dict(self.params)
        values.update(kwargs)
        return self._run_child(cmd, values, forward=True)

    def _run_child(self, cmd, values: dict, forward: bool):
        sub = Context(cmd, parent=self, info_name=cmd.name, **{})
        sub.params = {}
        for key, value in values.items():
            sub.params[key] = value
            sub._sources[key] = ParameterSource.DEFAULT
        with sub:
            return cmd.invoke(sub, bypass_parse=True)

    # --- thread-local current context --------------------------------------
    def __enter__(self):
        stack = _stack()
        stack.append(self)
        self._entered += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        self._entered -= 1
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)
        return False

    def __repr__(self) -> str:
        return f"<Context {self.command_path!r}>"


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def get_current_context(silent: bool = False):
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def pass_context(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return wrapper


def pass_obj(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return wrapper


def make_pass_decorator(object_type, ensure: bool = False):
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return wrapper

    return decorator


__all__ = [
    "Context", "ParameterSource", "get_current_context",
    "pass_context", "pass_obj", "make_pass_decorator",
]
