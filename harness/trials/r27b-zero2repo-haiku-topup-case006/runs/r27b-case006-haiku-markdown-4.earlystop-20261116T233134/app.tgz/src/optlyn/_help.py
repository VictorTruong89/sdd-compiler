"""Help page rendering."""

from __future__ import annotations

import shutil
from typing import List

from ._params import Argument, Option
from ._types import Choice
from .formatting import ellipsize_short, wrap_text


def _content_width(ctx) -> int:
    if ctx is not None and ctx.terminal_width:
        return int(ctx.terminal_width)
    cap = ctx.max_content_width if ctx is not None and ctx.max_content_width else 80
    detected = shutil.get_terminal_size((80, 24)).columns
    return max(min(detected, cap), 20)


def _description_text(cmd) -> str:
    text = cmd.help
    if text is None:
        text = cmd.callback.__doc__ if cmd.callback is not None else None
    if not text:
        return ""
    if "\f" in text:
        text = text.split("\f", 1)[0]
    return text


def short_help_for(cmd) -> str:
    if cmd.short_help:
        return cmd.short_help
    text = _description_text(cmd)
    paragraphs = [p for p in text.strip().split("\n\n") if p.strip()]
    first = paragraphs[0] if paragraphs else ""
    return ellipsize_short(first, 45)


def usage_line(cmd, ctx) -> str:
    parts = [ctx.command_path]
    visible_opts = [p for p in cmd.params if isinstance(p, Option) and not p.hidden]
    if visible_opts or cmd.add_help_option:
        parts.append(cmd.options_metavar or "[OPTIONS]")
    for arg in cmd.arguments:
        ph = arg.placeholder()
        if arg.variadic:
            ph = f"[{ph}]..." if not arg.required else f"{ph}..."
        elif not arg.required:
            ph = f"[{ph}]"
        parts.append(ph)
    if cmd.is_group:
        if cmd.chain:
            parts.append("[COMMAND [ARGS]]...")
        elif cmd.invoke_without_command:
            parts.append("[COMMAND] [ARGS]...")
        else:
            parts.append("COMMAND [ARGS]...")
    return "Usage: " + " ".join(parts)


def _option_label(opt: Option) -> str:
    names = list(opt.opts)
    if opt.secondary_opts:
        label = "/".join([opt.opts[0]] + opt.secondary_opts)
    else:
        label = ", ".join(names)
    metavar = opt.get_metavar()
    if metavar and not opt.is_flag and not opt.count:
        label += " " + metavar
    return label


def _option_extras(opt: Option, ctx) -> List[str]:
    extras: List[str] = []
    show = opt.show_default
    if show is None and ctx is not None:
        show = ctx.show_default
    if show and opt.default is not None and not (opt.is_flag and opt.default is False):
        if isinstance(show, str):
            extras.append(f"default: {show}")
        elif callable(opt.default):
            extras.append("default: (dynamic)")
        else:
            extras.append(f"default: {opt.default}")
    if opt.show_envvar and opt.envvar:
        extras.append(f"env var: {opt.envvar[0]}")
    if isinstance(opt.type, Choice) and not opt.is_flag:
        extras.append("choices: " + ", ".join(opt.type.choices))
    if opt.is_deprecated:
        extras.append("deprecated")
    return extras


def _two_col(rows: List[tuple], indent: str = "  ", width: int = 80) -> List[str]:
    if not rows:
        return []
    label_w = min(max(len(r[0]) for r in rows), 30)
    out: List[str] = []
    for label, text in rows:
        if not text:
            out.append(f"{indent}{label}")
            continue
        help_w = max(width - len(indent) - label_w - 2, 20)
        lines = wrap_text(text, width=help_w).split("\n") if text else [""]
        if len(label) > label_w:
            out.append(f"{indent}{label}")
            out.append(" " * (len(indent) + label_w + 2) + lines[0])
        else:
            out.append(f"{indent}{label.ljust(label_w)}  {lines[0]}")
        for ln in lines[1:]:
            out.append(" " * (len(indent) + label_w + 2) + ln)
    return out


def format_help(cmd, ctx) -> str:
    width = _content_width(ctx)
    lines: List[str] = [usage_line(cmd, ctx), ""]
    desc = _description_text(cmd)
    if cmd.deprecated:
        note = cmd.deprecated if isinstance(cmd.deprecated, str) else None
        desc = (desc.rstrip() + "\n\n" if desc.strip() else "") + "(Deprecated)" + (f" {note}" if note else "")
    if desc.strip():
        lines.append(wrap_text(desc, width=width))
        lines.append("")
    args_with_help = [a for a in cmd.arguments if a.help and not a.hidden]
    if args_with_help:
        lines.append("Positional arguments:")
        rows = [(a.placeholder(), a.help) for a in args_with_help]
        lines.extend(_two_col(rows, width=width))
        lines.append("")

    rows = []
    for opt in cmd.params:
        if not isinstance(opt, Option) or opt.hidden or not opt.expose_value and opt.is_eager:
            continue
        text = " ".join(filter(None, [opt.help or "", *(f"[{e}]" for e in _option_extras(opt, ctx))]))
        rows.append((_option_label(opt), text))
    if cmd.add_help_option and not any(isinstance(p, Option) and p.is_eager for p in cmd.params):
        rows.append((", ".join(ctx.help_option_names or ["--help"]), "Show this message and exit."))
    if rows:
        lines.append("Options:")
        lines.extend(_two_col(rows, width=width))
        lines.append("")

    if cmd.is_group:
        visible = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            visible.append((name, short_help_for(sub)))
        if visible:
            lines.append("Commands:")
            lines.extend(_two_col(visible, width=width))
            lines.append("")

    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


__all__ = ["format_help", "usage_line", "short_help_for"]
