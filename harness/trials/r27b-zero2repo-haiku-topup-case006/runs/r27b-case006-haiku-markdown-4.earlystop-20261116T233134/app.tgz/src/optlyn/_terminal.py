"""Terminal helpers: echo, styling, prompts, pager, progress bars, launching."""

from __future__ import annotations

import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
from typing import Any, Iterable, Optional

from ._context import get_current_context
from ._exceptions import Abort

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07")

_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_BG = {k: (v + 10 if v != 39 else 49) for k, v in _FG.items()}
_BG.update({"bright_black": 100, "bright_red": 101, "bright_green": 102,
            "bright_yellow": 103, "bright_blue": 104, "bright_magenta": 105,
            "bright_cyan": 106, "bright_white": 107})
_BG["black"] = 40
_BG["white"] = 47
_BG["reset"] = 49
_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def _color_code(color, background: bool) -> str:
    table = _BG if background else _FG
    if isinstance(color, bool):
        raise TypeError(f"Invalid color: {color!r}")
    if isinstance(color, str):
        if color not in table:
            raise TypeError(f"Unknown color {color!r}.")
        return str(table[color])
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color number out of range: {color}")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{48 if background else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color: {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True) -> str:
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on:
            codes.append(str(_SWITCHES[name]))
    if not codes:
        return str(text)
    seq = f"\x1b[{';'.join(codes)}m"
    out = f"{seq}{text}"
    if reset:
        out += "\x1b[0m"
    return out


def unstyle(text) -> str:
    return _ANSI_RE.sub("", str(text))


def _is_tty(stream) -> bool:
    try:
        return bool(stream and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive() -> bool:
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _current_color():
    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _write_text(file, text: str, nl: bool) -> None:
    data = text + ("\n" if nl else "")
    try:
        file.write(data)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(data.encode("utf-8"))
            buf.flush()
        else:
            file.write(data.encode("ascii", "replace").decode("ascii"))
    file.flush()


def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buf = getattr(file, "buffer", None)
        data = bytes(message) + (b"\n" if nl else b"")
        if buf is not None:
            file.flush()
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace") + ("" if not nl else "\n"))
            file.flush()
        return
    text = str(message)
    keep = color
    if keep is None:
        keep = _current_color()
    if keep is None:
        keep = _is_tty(file)
    if not keep:
        text = unstyle(text)
    _write_text(file, text, nl)


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- input


def _read_line(prompt_text: str, hide_input: bool = False) -> str:
    stream = sys.stdin
    if hide_input and _is_tty(stream):
        import getpass

        try:
            return getpass.getpass(prompt_text)
        except EOFError:
            raise Abort()
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = stream.readline() if stream is not None else ""
    if line == "":
        sys.stdout.write("\n")
        sys.stdout.flush()
        raise Abort()
    line = line.rstrip("\r\n")
    if not hide_input and not _is_tty(stream):
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    from ._types import BOOL, FLOAT, INT, STRING, convert_type

    if callable(default):
        default = default()
    ptype = type
    if ptype is None:
        ptype = {bool: BOOL, int: INT, float: FLOAT}.get(builtin_type(default), STRING)
    suffix = f" [{default}]" if default is not None and show_default and not hide_input else ""
    question = f"{text}{suffix}{prompt_suffix}"
    while True:
        value = _read_line(question, hide_input)
        if value == "":
            if default is None:
                echo("Error: Value is required.", err=True)
                continue
            if isinstance(default, str):
                value = default
            else:
                return default
        try:
            converted = convert_type(ptype, value)
        except Exception as exc:  # BadParameter from a conversion
            echo(f"Error: {getattr(exc, 'message', exc)}", err=True)
            continue
        if confirmation_prompt:
            second = _read_line("Repeat for confirmation" + prompt_suffix, hide_input)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return converted


builtin_type = type


def confirm(text, default: bool = False, abort: bool = False, prompt_suffix: str = ": ",
            show_default: bool = True, err: bool = False) -> bool:
    if not _is_tty(sys.stdout):
        text = unstyle(text)
    suffix = " [Y/n]" if default else " [y/N]"
    question = f"{text}{suffix}{prompt_suffix}"
    while True:
        answer = _read_line(question).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo_char: bool = False) -> str:
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError, termios_error()):
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo_char:
        echo(ch, nl=False)
    return ch


def termios_error():
    try:
        import termios

        return termios.error
    except ImportError:
        return OSError


def pause(info: Optional[str] = None, err: bool = False) -> None:
    if not is_interactive():
        return
    echo(info if info is not None else "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear() -> None:
    if _is_tty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


# ---------------------------------------------------------------- editor / launch


def edit(text=None, editor=None, env=None, require_save: bool = True,
         extension: str = ".txt", filename=None):
    editor = editor or (env or {}).get("EDITOR") or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        editor = "notepad" if sys.platform == "win32" else "vi"
    if filename is not None:
        cmd = shlex.split(editor) + [os.fspath(filename)]
        subprocess.call(cmd)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text or "")
        mtime = os.path.getmtime(path)
        subprocess.call(shlex.split(editor) + [path])
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
        if require_save and (os.path.getmtime(path) == mtime and result == (text or "")):
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        cmd = ["open"] + (["-R"] if locate else []) + [url]
    else:
        cmd = ["xdg-open", url]
    try:
        proc = subprocess.Popen(cmd)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


# ---------------------------------------------------------------- app dirs / filenames


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    home = os.path.expanduser("~")
    if sys.platform == "win32" and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten: bool = False) -> str:
    if isinstance(filename, (bytes, bytearray)):
        s = bytes(filename).decode("utf-8", "surrogateescape")
    else:
        s = os.fspath(filename)
        if isinstance(s, bytes):
            s = s.decode("utf-8", "surrogateescape")
    if shorten:
        s = os.path.basename(s)
    return s.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def open_file(filename, mode: str = "r", encoding=None, errors: str = "strict",
              lazy: bool = False, atomic: bool = False):
    from ._types import open_stream

    return open_stream(filename, mode, encoding, errors, lazy, atomic)


# ---------------------------------------------------------------- pager


def _pager_command() -> Optional[str]:
    return os.environ.get("PAGER") or None


def _iter_chunks(text_or_generator) -> Iterable[str]:
    if callable(text_or_generator) and not isinstance(text_or_generator, (str, bytes)):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        yield text_or_generator
    else:
        for chunk in text_or_generator:
            yield chunk


def echo_via_pager(text_or_generator, color=None) -> None:
    pager = _pager_command()
    if is_interactive() and pager:
        proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE, text=True)
        try:
            for chunk in _iter_chunks(text_or_generator):
                proc.stdin.write(chunk if color else unstyle(chunk))
                proc.stdin.flush()
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass
            proc.wait()
        return
    for chunk in _iter_chunks(text_or_generator):
        echo(chunk, nl=False, color=color)
    sys.stdout.flush()


@contextlib.contextmanager
def get_pager_file(color=None):
    pager = _pager_command()
    if is_interactive() and pager:
        proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE, text=True)
        try:
            yield proc.stdin
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass
            proc.wait()
        return
    yield sys.stdout


# ---------------------------------------------------------------- progress bar


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, file=None):
        self.iter = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.width = width
        self.file = file or sys.stdout
        self.start = time.time()
        self.visible = (not hidden) and _is_tty(self.file)
        if not hidden and not _is_tty(self.file) and label:
            echo(label, file=self.file)

    def __iter__(self):
        if self.iter is None:
            return
        for item in self.iter:
            yield item
            self.update(1)
        self.render_finished()

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        if not self.visible:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * self.width)
            bar = "#" * filled + "-" * (self.width - filled)
            elapsed = time.time() - self.start
            eta = (elapsed / frac - elapsed) if frac > 0 else 0
            line = f"\r{self.label or ''} [{bar}]  {self.pos}/{self.length}  eta {int(eta)}s"
        else:
            line = f"\r{self.label or ''} {self.pos}"
        self.file.write(line)
        self.file.flush()

    def render_finished(self) -> None:
        if self.visible:
            self.file.write("\n")
            self.file.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        if bar.visible and bar.pos:
            pass


__all__ = [
    "echo", "secho", "style", "unstyle", "prompt", "confirm", "getchar", "pause",
    "edit", "launch", "clear", "get_app_dir", "format_filename", "open_file",
    "echo_via_pager", "get_pager_file", "progressbar", "is_interactive",
]
