"""Parameter types and conversion."""

from __future__ import annotations

import datetime as _dt
import enum
import io
import os
import pathlib
import sys
import tempfile
import uuid as _uuid
from typing import Any, Callable, Iterable, Optional, Sequence

from ._exceptions import BadParameter, DeclarationError, FileError


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False
    envvar_list_splitter: Optional[str] = None  # None means whitespace

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message: str, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None) -> Optional[str]:
        return self.name.upper()

    def get_missing_message(self, param=None) -> str:
        return "Missing value."

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        return []

    def split_envvar_value(self, rv: str) -> list:
        if self.envvar_list_splitter is None:
            return rv.split()
        return [v for v in rv.split(self.envvar_list_splitter) if v != ""]

    def __repr__(self) -> str:
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return value if isinstance(value, str) else str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            text = str(value).strip()
            return int(text, 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()

# Aliases matching the interface names.
String = _StringType
Integer = _IntType


class Choice(ParamType):
    """A closed list of allowed values, or an enum class."""

    name = "choice"

    def __init__(self, choices, case_sensitive: Optional[bool] = None) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._originals = list(choices)
            self._tokens = [m.name for m in self._originals]
            self._is_enum = True
        else:
            self._originals = list(choices)
            self._tokens = [str(c) for c in self._originals]
            self._is_enum = False
        # Enum members match ignoring case unless the author says otherwise;
        # plain lists match case-sensitively by default.
        self.case_sensitive = (not self._is_enum) if case_sensitive is None else bool(case_sensitive)
        if not self._originals:
            raise DeclarationError("Choice requires at least one choice.")

    @property
    def choices(self) -> list:
        return list(self._tokens)

    def get_metavar(self, param=None) -> str:
        return "[" + "|".join(self._tokens) + "]"

    def _match(self, value: str):
        if self.case_sensitive:
            for orig, tok in zip(self._originals, self._tokens):
                if tok == value:
                    return orig
            return None
        folded = value.casefold()
        for orig, tok in zip(self._originals, self._tokens):
            if tok.casefold() == folded:
                return orig
        return None

    def convert(self, value, param=None, ctx=None):
        if self._is_enum and isinstance(value, enum.Enum) and value in self._originals:
            return value
        if not self._is_enum and value in self._originals:
            return value
        text = value if isinstance(value, str) else str(value)
        found = self._match(text)
        if found is None:
            choices = ", ".join(repr(t) for t in self._tokens)
            self.fail(f"{text!r} is not one of {choices}.", param, ctx)
        return found

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        return [t for t in self._tokens if t.startswith(incomplete)]


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: Optional[Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{text!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None) -> str:
        return "integer"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None:
            if v < self.min or (self.min_open and v == self.min):
                if self.clamp:
                    v = self.min + 1 if self.min_open else self.min
                    return v
                self._range_fail(v, param, ctx)
        if self.max is not None:
            if v > self.max or (self.max_open and v == self.max):
                if self.clamp:
                    v = self.max - 1 if self.max_open else self.max
                    return v
                self._range_fail(v, param, ctx)
        return v

    def _range_fail(self, v, param, ctx):
        self.fail(f"{v} is not in the valid range of {self._describe()}.", param, ctx)

    def _describe(self) -> str:
        lo = "-inf" if self.min is None else (f"{'>' if self.min_open else '>='}{self.min}")
        hi = "inf" if self.max is None else (f"{'<' if self.max_open else '<='}{self.max}")
        return f"{lo} and {hi}"


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise DeclarationError("Clamp is only allowed when both bounds are closed.")
        if min is not None and max is not None and min > max:
            raise DeclarationError("Range minimum is greater than maximum.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None) -> str:
        return "float"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            if self.clamp:
                return float(self.min)
            self.fail(f"{v} is out of range.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            if self.clamp:
                return float(self.max)
            self.fail(f"{v} is out of range.", param, ctx)
        return v


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types: Iterable) -> None:
        self.types = [_resolve_type(t) for t in types]
        if not self.types:
            raise DeclarationError("Tuple requires at least one type.")

    @property
    def arity(self) -> int:
        return len(self.types)

    def get_metavar(self, param=None) -> str:
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (list, tuple)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


def _resolve_type(t) -> ParamType:
    if isinstance(t, ParamType):
        return t
    if isinstance(t, type) and issubclass(t, ParamType):
        return t()
    if t is str:
        return STRING
    if t is int:
        return INT
    if t is float:
        return FLOAT
    if t is bool:
        return BOOL
    if t is _uuid.UUID:
        return UUID
    if callable(t):
        return FuncType(t)
    raise DeclarationError(f"Unsupported parameter type: {t!r}")


class FuncType(ParamType):
    """Adapter for a conversion function ``f(token) -> value`` that raises ValueError to refuse."""

    def __init__(self, func: Callable) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").replace("_", "-")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def convert_type(ptype, value, param=None, ctx=None):
    """Convert ``value`` with any accepted type form (ParamType, callable, Python type)."""
    if ptype is None:
        return value
    return _resolve_type(ptype).convert(value, param, ctx)


# ---------------------------------------------------------------- files / paths


class _NoCloseStream(io.IOBase):
    """Wrap a standard stream without closing it when the block ends."""

    def __init__(self, stream) -> None:
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self) -> None:  # standard streams are never closed by Optlyn
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        pass


class LazyFile:
    """A file that opens on first I/O."""

    def __init__(self, filename: str, mode: str, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self._args = (encoding, errors, atomic)
        self._file = None
        self._closed = False

    def _open(self):
        if self._file is None:
            encoding, errors, atomic = self._args
            try:
                self._file = open_stream(self.name, self.mode, encoding, errors, False, atomic)
            except OSError as exc:
                raise FileError(self.name, exc.strerror or str(exc)) from exc
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self) -> None:
        if self._file is not None and not self._closed:
            self._file.close()
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


class AtomicFile:
    """Writes to a sibling temp file; replaces the target on close."""

    def __init__(self, filename: str, mode: str, encoding=None, errors="strict") -> None:
        self._target = os.path.abspath(filename)
        directory = os.path.dirname(self._target)
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        binary = "b" in mode
        self._file = open(self._tmp, "wb" if binary else "w", encoding=None if binary else encoding,
                          errors=None if binary else errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or ``-`` for the standard stream matching the mode.

    Dash streams are never closed. Read files open immediately; write files
    open lazily when ``lazy`` is true, otherwise immediately.
    """
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    binary = "b" in mode
    writing = any(c in mode for c in "wax+")
    if filename == "-":
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _NoCloseStream(stream)
    if writing and lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    if writing and atomic:
        return AtomicFile(filename, mode, encoding, errors)
    try:
        if binary:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as exc:
        raise FileError(filename, exc.strerror or str(exc)) from exc


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"Unsupported File mode: {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        if lazy is None:
            lazy = mode in ("w", "wb")
        self.lazy = lazy

    def get_metavar(self, param=None) -> str:
        return "FILENAME"

    def split_envvar_value(self, rv: str) -> list:
        return [v for v in rv.split(os.pathsep) if v != ""]

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        name = os.fspath(value) if not isinstance(value, str) else value
        if name != "-" and self.mode in ("r", "rb") and not os.path.exists(name):
            self.fail(f"{name!r} does not exist.", param, ctx)
        try:
            f = open_stream(name, self.mode, self.encoding, self.errors,
                            lazy=self.lazy, atomic=self.atomic)
        except FileError as exc:
            self.fail(f"{name!r}: {exc.message}", param, ctx)
        if ctx is not None and name != "-":
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None) -> str:
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        raw = os.fspath(value) if not isinstance(value, str) else value
        if self.allow_dash and raw == "-":
            return self._out("-")
        path = raw
        if self.resolve_path:
            path = os.path.realpath(os.path.expanduser(path))
        exists = os.path.exists(path)
        if self.exists and not exists:
            self.fail(f"{raw!r} does not exist.", param, ctx)
        if exists:
            if not self.file_okay and os.path.isfile(path):
                self.fail(f"{raw!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(path):
                self.fail(f"{raw!r} is a directory.", param, ctx)
            if self.readable and not os.access(path, os.R_OK):
                self.fail(f"{raw!r} is not readable.", param, ctx)
            if self.writable and not os.access(path, os.W_OK):
                self.fail(f"{raw!r} is not writable.", param, ctx)
            if self.executable and not os.access(path, os.X_OK):
                self.fail(f"{raw!r} is not executable.", param, ctx)
        return self._out(path)

    def _out(self, path: str):
        if self.path_type is pathlib.Path:
            return pathlib.Path(path)
        if self.path_type is None or self.path_type is str:
            return path
        return self.path_type(path)

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        return []

    def split_envvar_value(self, rv: str) -> list:
        return [v for v in rv.split(os.pathsep) if v != ""]


__all__ = [
    "ParamType", "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    "FuncType", "convert_type", "open_stream", "LazyFile", "AtomicFile",
]
