"""Token parser: splits an argument list into option hits and positional tokens."""

from __future__ import annotations

from typing import Callable, List, Optional

from ._exceptions import BadOptionUsage, NoSuchOption
from ._params import NO_VALUE, Option


def _looks_like_option(token: str, prefixes: str) -> bool:
    return len(token) > 1 and token[0] in prefixes


class ParseResult:
    def __init__(self) -> None:
        # list of (option, kind, payload); kind in {"flag", "count", "value"}
        self.hits: List[tuple] = []
        self.positional: List[str] = []
        self.rest: List[str] = []  # tokens after a stop point (group subcommand names etc.)
        self.stopped = False


class Parser:
    """Parses one command's option tokens.

    ``stop_at_positional``: a group stops at its first positional token that
    is not needed by its own arguments; the remaining tokens start with the
    subcommand name.
    ``arg_slots``: number of positional tokens the command's arguments take
    (None when a variadic argument is present, meaning unlimited).
    ``stop_when_full``: stop as soon as all positional slots are filled
    (used for chained subcommands, whose options must precede arguments).
    """

    def __init__(
        self,
        options: List[Option],
        help_names: List[str],
        on_eager: Callable[[Option, object], None],
        *,
        interspersed: bool = True,
        ignore_unknown: bool = False,
        stop_at_positional: bool = False,
        arg_slots: Optional[int] = 0,
        stop_when_full: bool = False,
        normalize: Optional[Callable[[str], str]] = None,
        ctx=None,
    ) -> None:
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.stop_at_positional = stop_at_positional
        self.arg_slots = arg_slots
        self.stop_when_full = stop_when_full
        self.normalize = normalize or (lambda s: s)
        self.on_eager = on_eager
        self.ctx = ctx
        self.lookup: dict = {}
        self.prefixes = set("-")
        for opt in options:
            for name in opt.opts + opt.secondary_opts:
                self.lookup[self.normalize(name)] = (opt, name)
                self.prefixes.add(name[0])
        for name in help_names:
            key = self.normalize(name)
            if key not in self.lookup:
                self.lookup[key] = ("help", name)
                self.prefixes.add(name[0])
        self.prefix_str = "".join(sorted(self.prefixes))

    # ------------------------------------------------------------------
    def _is_option_like(self, token: str) -> bool:
        return _looks_like_option(token, self.prefix_str)

    def _record(self, res: ParseResult, opt: Option, kind: str, payload, name: str = "") -> None:
        if opt.is_eager:
            # Eager flags act immediately, in the order the user typed them.
            self.on_eager(opt, payload)
        res.hits.append((opt, kind, payload))

    def _consume_value(self, opt: Option, args: List[str], i: int, attached: Optional[str]):
        """Return (payload, new_index) for a value-taking option."""
        if attached is not None:
            return [attached], i
        if opt.optional_value:
            if i < len(args) and not self._is_option_like(args[i]) and args[i] != "--":
                return [args[i]], i + 1
            return NO_VALUE, i
        need = opt.nargs
        if i + need > len(args) or any(a == "--" for a in args[i:i + need]):
            raise BadOptionUsage(f"Option '{opt.get_error_hint()}' requires an argument.", self.ctx)
        return list(args[i:i + need]), i + need

    def _handle_option_token(self, res, args, i, tok) -> int:
        """Handle an option-shaped token at index i. Returns the next index."""
        key = self.normalize(tok)
        if key in self.lookup:
            return self._apply(res, args, i, self.lookup[key], None, tok)
        if "=" in tok:
            name, _, val = tok.partition("=")
            k2 = self.normalize(name)
            if k2 in self.lookup:
                return self._apply(res, args, i, self.lookup[k2], val, tok)
        if tok.startswith("--"):
            return self._unknown(res, tok, i)
        # short option stack
        j = 1
        while j < len(tok):
            ch = tok[j]
            name = tok[0] + ch
            k = self.normalize(name)
            if k not in self.lookup:
                if self.ignore_unknown:
                    res.positional.append(tok[0] + tok[j:])
                    return i + 1
                raise NoSuchOption(name, ctx=self.ctx)
            opt, _ = self.lookup[k]
            if opt == "help":
                self.on_eager(None, True)  # help handled by the caller's eager callback
                return i + 1
            if opt.is_flag or opt.count:
                self._apply_flag(res, opt, name)
                j += 1
                continue
            rest = tok[j + 1:]
            if rest:
                return self._apply(res, args, i, (opt, name), rest, tok)
            return self._apply(res, args, i, (opt, name), None, tok)
        return i + 1

    def _unknown(self, res, tok, i):
        if self.ignore_unknown:
            res.positional.append(tok)
            return i + 1
        raise NoSuchOption(tok.partition("=")[0], ctx=self.ctx)

    def _apply_flag(self, res, opt: Option, name: str) -> None:
        if opt.count:
            self._record(res, opt, "count", None, name)
        elif name in opt.secondary_opts:
            self._record(res, opt, "flag", False, name)
        else:
            self._record(res, opt, "flag", opt.flag_value, name)

    def _apply(self, res, args, i, entry, attached, tok) -> int:
        opt, name = entry
        if opt == "help":
            self.on_eager(None, True)
            return i + 1
        if opt.is_flag or opt.count:
            if attached is not None and attached != "":
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            self._apply_flag(res, opt, name)
            return i + 1
        payload, nxt = self._consume_value(opt, args, i + (0 if attached is not None else 1), attached)
        self._record(res, opt, "value", payload, name)
        return nxt

    # ------------------------------------------------------------------
    def parse(self, args: List[str]) -> ParseResult:
        res = ParseResult()
        i = 0
        after_dd = False
        seen_positional = False
        n = len(args)
        while i < n:
            tok = args[i]
            if after_dd:
                if self.stop_at_positional and self._stop_here(res):
                    res.rest = args[i:]
                    res.stopped = True
                    return res
                res.positional.append(tok)
                i += 1
                continue
            if tok == "--":
                after_dd = True
                i += 1
                continue
            if self._is_option_like(tok) and (self.interspersed or not seen_positional):
                i = self._handle_option_token(res, args, i, tok)
                continue
            # positional token
            if self.stop_at_positional and self._stop_here(res):
                res.rest = args[i:]
                res.stopped = True
                return res
            if self.stop_when_full and self._full(res):
                res.rest = args[i:]
                res.stopped = True
                return res
            res.positional.append(tok)
            seen_positional = True
            i += 1
        return res

    def _full(self, res) -> bool:
        return self.arg_slots is not None and len(res.positional) >= self.arg_slots

    def _stop_here(self, res) -> bool:
        """A group stops at the first positional not needed by its arguments."""
        return self._full(res)
