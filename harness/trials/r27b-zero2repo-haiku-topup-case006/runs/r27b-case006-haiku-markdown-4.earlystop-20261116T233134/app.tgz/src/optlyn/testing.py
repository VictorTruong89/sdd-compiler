"""In-process runner for invoking commands in tests."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
from typing import Optional


class _Capture:
    """A text+binary stream that records every write into a shared, ordered log."""

    def __init__(self, name: str, log: list, charset: str) -> None:
        self.name = name
        self._log = log
        self._charset = charset
        self._buf = bytearray()

    @property
    def encoding(self) -> str:
        return self._charset

    @property
    def errors(self) -> str:
        return "strict"

    @property
    def buffer(self):
        return self

    def write(self, data) -> int:
        if isinstance(data, str):
            raw = data.encode(self._charset)  # strict: lets echo fall back to UTF-8
        else:
            raw = bytes(data)
        self._buf += raw
        self._log.append(raw)
        return len(data)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def getvalue(self) -> bytes:
        return bytes(self._buf)


class _Stdin:
    def __init__(self, data: bytes, charset: str, echo_to=None) -> None:
        self._text = io.TextIOWrapper(io.BytesIO(data), encoding=charset, errors="replace")
        self._echo_to = echo_to

    def readline(self) -> str:
        line = self._text.readline()
        if self._echo_to is not None and line:
            self._echo_to(line)
        return line

    def read(self, n: int = -1) -> str:
        data = self._text.read(n)
        if self._echo_to is not None and data:
            self._echo_to(data)
        return data

    def isatty(self) -> bool:
        return False


class Result:
    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, combined: bytes,
                 exit_code: int, exception, charset: str) -> None:
        self.runner = runner
        self.exit_code = exit_code
        self.exception = exception
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self._combined = combined
        self._charset = charset

    @property
    def output(self) -> str:
        return self._combined.decode(self._charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset: str = "utf-8", env=None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color: bool = False):
        data = input or b""
        if isinstance(data, str):
            data = data.encode(self.charset)
        log: list = []
        out = _Capture("stdout", log, self.charset)
        err = _Capture("stderr", log, self.charset)
        echo_to = (lambda text: out.write(text)) if self.echo_stdin else None
        stdin = _Stdin(data, self.charset, echo_to)
        merged = {**self.env, **(env or {})}
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield out, err, log
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color: bool = False, **extra) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        prog_name = extra.pop("prog_name", "cli")
        standalone = extra.pop("standalone_mode", True)
        extra["color"] = color
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env, color=color) as (out, err, log):
            try:
                cli.main(args=list(args), prog_name=prog_name, standalone_mode=standalone, **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:  # noqa: BLE001 - reported on the Result
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
        combined = b"".join(log)
        return Result(self, out.getvalue(), err.getvalue(), combined, exit_code, exception, self.charset)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: Optional[str] = None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)


__all__ = ["CliRunner", "Result"]
