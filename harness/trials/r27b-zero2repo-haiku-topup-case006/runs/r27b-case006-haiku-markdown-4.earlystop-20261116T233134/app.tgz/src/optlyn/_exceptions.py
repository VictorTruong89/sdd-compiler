"""Exception classes and exit-status classes for Optlyn."""

from __future__ import annotations

from typing import Optional


class OptlynError(Exception):
    """Base class for all Optlyn-signalled errors."""

    exit_code = 1

    def __init__(self, message: str = "", ctx=None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None) -> None:
        import sys

        print(f"Error: {self.message}", file=file or sys.stderr)


class DeclarationError(OptlynError, TypeError):
    """Raised when a command, group or parameter is declared incorrectly."""


class UsageError(OptlynError):
    """A usage failure; standalone exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx=None, show_help: bool = False) -> None:
        super().__init__(message, ctx)
        self.show_help = show_help

    def show(self, file=None) -> None:
        import sys

        out = file or sys.stderr
        prog = getattr(self.ctx, "command_path", None) if self.ctx else None
        if prog:
            print(f"{prog}: {self.message}", file=out)
        else:
            print(f"Error: {self.message}", file=out)
        if self.show_help and self.ctx is not None:
            print(self.ctx.get_help(), file=out)


class BadParameter(UsageError):
    """A value was refused. Names the offending parameter."""

    def __init__(
        self,
        message: str,
        ctx=None,
        param=None,
        param_hint: Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> str:
        if self.param_hint:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint()
        else:
            return ""
        return hint

    def show(self, file=None) -> None:
        import sys

        out = file or sys.stderr
        hint = self._hint()
        if hint:
            print(f"Invalid value for {hint}: {self.message}", file=out)
        else:
            print(f"Invalid value: {self.message}", file=out)


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def show(self, file=None) -> None:
        import sys

        out = file or sys.stderr
        hint = self._hint()
        print(f"Missing parameter: {hint or self.message}", file=out)


class NoSuchOption(UsageError):
    """An unknown option token."""

    def __init__(self, option_name: str, message: Optional[str] = None, ctx=None) -> None:
        self.option_name = option_name
        super().__init__(message or f"No such option: {option_name}", ctx)


class NoSuchCommand(UsageError):
    """An unknown subcommand name."""

    def __init__(self, name: str, message: Optional[str] = None, ctx=None) -> None:
        self.command_name = name
        super().__init__(message or f"No such command: {name}", ctx)


class MissingCommand(UsageError):
    """A group was invoked without a subcommand where one is required."""


class BadOptionUsage(UsageError):
    """Usage error about an option that is not a parameter conversion problem."""


class BadArgumentUsage(UsageError):
    """Usage error about an argument that is not a parameter conversion problem."""


class Abort(OptlynError):
    """User abort or author abort; standalone exit status 1."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!", ctx=None) -> None:
        super().__init__(message, ctx)

    def show(self, file=None) -> None:
        import sys

        print(self.message, file=file or sys.stderr)


class FileError(OptlynError):
    """A file could not be opened at first I/O; general error class (status 1)."""

    exit_code = 1

    def __init__(self, filename: str, message: str, ctx=None) -> None:
        super().__init__(f"Could not open file {filename!r}: {message}", ctx)
        self.filename = filename


class Exit(Exception):
    """Author clean stop. ``code`` is the process status to exit with."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


__all__ = [
    "OptlynError",
    "DeclarationError",
    "UsageError",
    "BadParameter",
    "MissingParameter",
    "NoSuchOption",
    "NoSuchCommand",
    "MissingCommand",
    "BadOptionUsage",
    "BadArgumentUsage",
    "Abort",
    "FileError",
    "Exit",
]
