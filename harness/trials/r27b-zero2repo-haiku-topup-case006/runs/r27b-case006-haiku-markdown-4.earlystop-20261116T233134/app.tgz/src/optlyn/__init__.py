"""Optlyn: a command line interface composition kit.

Public names are re-exported here; the implementation lives in private modules.
"""

from ._context import (
    Context,
    ParameterSource,
    get_current_context,
    make_pass_decorator,
    pass_context,
    pass_obj,
)
from ._core import Command, CommandCollection, Group
from ._decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    option,
    password_option,
    version_option,
)
from ._exceptions import (
    Abort,
    BadParameter,
    DeclarationError,
    Exit,
    FileError,
    MissingParameter,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from ._params import Argument, Option, Parameter
from ._terminal import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    format_filename,
    get_app_dir,
    get_pager_file,
    getchar,
    launch,
    open_file,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from ._types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from ._types import Choice as _Choice  # noqa: F401  (re-export alias kept for symmetry)

__version__ = "1.0.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
    "pass_context", "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "Argument", "ParamType", "BadParameter", "Abort", "ParameterSource",
    "UsageError", "MissingParameter", "NoSuchOption", "NoSuchCommand",
    "DeclarationError", "OptlynError", "FileError", "Exit",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch",
    "clear", "get_app_dir", "get_current_context", "format_filename", "open_file",
]
