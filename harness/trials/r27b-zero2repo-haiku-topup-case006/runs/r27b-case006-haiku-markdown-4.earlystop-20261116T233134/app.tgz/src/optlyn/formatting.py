"""Text wrapping helpers used by help pages."""

from __future__ import annotations

import textwrap
from typing import List

DEFAULT_WIDTH = 100


def _paragraphs(text: str) -> List[List[str]]:
    """Split text into paragraphs, each a list of its raw lines."""
    paras: List[List[str]] = []
    current: List[str] = []
    for line in text.splitlines():
        if line.strip() == "":
            if current:
                paras.append(current)
                current = []
        else:
            current.append(line.rstrip())
    if current:
        paras.append(current)
    return paras


def wrap_text(
    text,
    width: int = DEFAULT_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap text to ``width`` columns. Accepts any string without failing."""
    if text is None:
        text = ""
    text = str(text)
    width = max(int(width), 1)
    out: List[str] = []
    for para in _paragraphs(text):
        if para and para[0].strip() == "\b":
            # A paragraph starting with a backspace line keeps its line breaks.
            body = [ln for ln in para[1:]]
            for ln in body:
                out.append(initial_indent + ln if not out else subsequent_indent + ln)
            out.append("")
            continue
        if preserve_paragraphs:
            joined = " ".join(ln.strip() for ln in para)
        else:
            joined = " ".join(ln.strip() for ln in para)
        wrapper = textwrap.TextWrapper(
            width=width,
            initial_indent=initial_indent if not out else subsequent_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=True,
            break_on_hyphens=False,
            replace_whitespace=False,
            drop_whitespace=True,
        )
        lines = wrapper.wrap(joined) or [""]
        out.extend(lines)
        out.append("")
    if out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def ellipsize_short(text: str, limit: int = 45) -> str:
    """Cut text to at most ``limit`` characters, marking the cut with ``...``."""
    text = " ".join(text.split())
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


__all__ = ["wrap_text", "ellipsize_short", "DEFAULT_WIDTH"]
