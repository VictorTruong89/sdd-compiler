"""Declaration decorators and ready-made parameter options."""

from __future__ import annotations

from typing import Optional

from ._core import Command, CommandCollection, Group
from ._exceptions import Exit
from ._params import Argument, Option
from ._terminal import confirm, echo


def _attach(f, param) -> object:
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        params = []
        f.__optlyn_params__ = params
    params.append(param)
    return f


def _pop_params(f) -> list:
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    return list(reversed(params))


def command(name=None, cls=None, **attrs):
    """Turn a function into a command. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)
    klass = cls or Command

    def decorator(f):
        params = _pop_params(f)
        return klass(name=name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)
    klass = cls or Group

    def decorator(f):
        params = _pop_params(f)
        return klass(name=name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function it decorates."""
    klass = cls or Option

    def decorator(f):
        return _attach(f, klass(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function it decorates."""
    klass = cls or Argument

    def decorator(f):
        return _attach(f, klass(param_decls, **attrs))

    return decorator


# ---------------------------------------------------------------- ready-made options


def _help_callback(ctx, param, value):
    if not value or param is None:
        return value
    echo(ctx.get_help(), nl=False)
    raise Exit(0)


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. Prints the help page and exits with status 0."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        return _attach(f, Option(decls, is_flag=True, expose_value=False, is_eager=True,
                                 callback=_help_callback, **kwargs))

    return decorator


def _detect_version(package_name: Optional[str]) -> str:
    from importlib import metadata

    if not package_name:
        return "unknown"
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name) or []
    except Exception:
        dists = []
    for dist in dists:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag. Prints the identity and exits with status 0."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or param is None:
            return value
        ver = version
        pkg = package_name
        if ver is None:
            if pkg is None:
                mod = ctx.command.callback.__module__ if ctx.command.callback is not None else ""
                pkg = (mod or "").split(".")[0] or None
            ver = _detect_version(pkg)
        root = ctx
        while root.parent is not None:
            root = root.parent
        prog = prog_name or root.info_name or "cli"
        text = message % {"prog": prog, "version": ver} if message else f"{prog}, version {ver}"
        echo(text)
        raise Exit(0)

    def decorator(f):
        return _attach(f, Option(decls, is_flag=True, expose_value=False, is_eager=True,
                                 callback=callback, **kwargs))

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager version flag whose identity is exactly ``callback(ctx)``."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("help", "Show the version and exit.")

    def cb(ctx, param, value):
        if not value or param is None:
            return value
        echo(callback(ctx))
        raise Exit(0)

    def decorator(f):
        return _attach(f, Option(decls, is_flag=True, expose_value=False, is_eager=True,
                                 callback=cb, **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option. Default flag name ``--password``."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs["hide_input"] = True
    kwargs["confirmation_prompt"] = True

    def decorator(f):
        return _attach(f, Option(decls, **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that asks when omitted and aborts when the user declines."""
    decls = param_decls or ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def cb(ctx, param, value):
        if value:
            return value
        if param is None:
            return value
        confirm(question, default=False, abort=True)
        return True

    def decorator(f):
        return _attach(f, Option(decls, is_flag=True, default=False, expose_value=False,
                                 hidden_from_callback=True, callback=cb, **kwargs))

    return decorator


__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
]
