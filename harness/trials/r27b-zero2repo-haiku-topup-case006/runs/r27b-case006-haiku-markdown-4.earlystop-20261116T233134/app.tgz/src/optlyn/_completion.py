"""Shell completion: registration scripts and suggestion streams."""

from __future__ import annotations

import os
import re
import sys
from typing import List, Tuple

from ._exceptions import Exit
from ._params import Argument, Option
from ._types import File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "@path-file:"
PATH_DIR = "@path-dir:"


def _var_name(prog_name: str) -> str:
    return "_" + re.sub(r"[-\s.]", "_", prog_name).upper() + "_COMPLETE"


def _script(shell: str, prog_name: str) -> str:
    var = _var_name(prog_name)
    if shell == "bash":
        return (
            f"_{prog_name.replace('-', '_')}_completion() {{\n"
            "    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog_name} ) )\n"
            "    return 0\n}\n"
            f"complete -o default -F _{prog_name.replace('-', '_')}_completion {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"_{prog_name.replace('-', '_')}_completion() {{\n"
            f"    local -a suggestions\n"
            f"    suggestions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog_name})}}\")\n"
            "    _describe 'values' suggestions\n}\n"
            f"compdef _{prog_name.replace('-', '_')}_completion {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog_name} --arguments "
            f"\"(env COMP_WORDS=(commandline -opc) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog_name})\"\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString(); $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog_name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        "}\n"
    )


def _visible_options(cmd) -> List[Option]:
    return [o for o in cmd.params if isinstance(o, Option) and not o.hidden]


def _option_for(cmd, token: str):
    for o in cmd.params:
        if isinstance(o, Option) and token in o.opts + o.secondary_opts:
            return o
    return None


def _param_suggestions(ctx, param, incomplete: str) -> List[Tuple[str, str]]:
    if param.shell_complete_func is not None:
        items = param.shell_complete_func(ctx, param, incomplete) or []
        out = []
        for it in items:
            if isinstance(it, str):
                out.append((it, ""))
            else:
                out.append((str(getattr(it, "value", it)), getattr(it, "help", None) or ""))
        return out
    ptype = param.type
    if isinstance(ptype, Path) or isinstance(ptype, File):
        if isinstance(ptype, Path) and not ptype.file_okay and ptype.dir_okay:
            return [(PATH_DIR + incomplete, "")]
        return [(PATH_FILE + incomplete, "")]
    out = []
    for it in ptype.shell_complete(ctx, param, incomplete) or []:
        if isinstance(it, str):
            out.append((it, ""))
        else:
            out.append((str(getattr(it, "value", it)), getattr(it, "help", None) or ""))
    return out


def suggestions_for(cmd, prog_name: str, words: List[str], cword: int) -> List[Tuple[str, str]]:
    from ._context import Context

    incomplete = words[cword] if 0 <= cword < len(words) else ""
    ctx = Context(cmd, info_name=prog_name)
    current = cmd
    pending_opt = None
    skip_next = False
    for idx, word in enumerate(words[1:cword], start=1):
        if skip_next:
            skip_next = False
            continue
        if pending_opt is None and word.startswith("-") and word != "-":
            opt = _option_for(current, word)
            if opt is not None and not opt.is_flag and not opt.count:
                skip_next = True
            continue
        if current.is_group and word in getattr(current, "commands", {}):
            current = current.commands[word]
    # Completing the value of an option that expects one.
    if cword >= 1 and cword - 1 < len(words) and cword - 1 >= 1:
        prev = words[cword - 1]
        opt = _option_for(current, prev)
        if opt is not None and not opt.is_flag and not opt.count:
            return [(v, h) for v, h in _param_suggestions(ctx, opt, incomplete)
                    if v.startswith(incomplete) or v.startswith(PATH_FILE) or v.startswith(PATH_DIR)]
    out: List[Tuple[str, str]] = []
    if incomplete.startswith("-"):
        for o in _visible_options(current):
            for name in o.opts + o.secondary_opts:
                if name.startswith(incomplete):
                    out.append((name, o.help or ""))
        if current.add_help_option:
            for name in ctx.help_option_names or ["--help"]:
                if name.startswith(incomplete):
                    out.append((name, "Show this message and exit."))
        return out
    if current.is_group:
        for name in current.list_commands(ctx):
            sub = current.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            from ._help import short_help_for

            out.append((name, short_help_for(sub)))
    if incomplete == "" and not current.is_group:
        return out
    return out


def run_completion(cmd, prog_name: str, instruction: str, standalone_mode: bool):
    if "_" not in instruction:
        return _finish(standalone_mode, 1)
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return _finish(standalone_mode, 1)
    if mode == "source":
        sys.stdout.write(_script(shell, prog_name))
        sys.stdout.flush()
        return _finish(standalone_mode, 0)
    line = os.environ.get("COMP_WORDS", "")
    if shell == "fish":
        # fish passes the completed words, then the incomplete token itself.
        incomplete = os.environ.get("COMP_CWORD", "")
        words = (line.split() if line else [prog_name]) + [incomplete]
        cword = len(words) - 1
    else:
        words = line.split(" ") if line else [prog_name]
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words) - 1)))
        except ValueError:
            cword = len(words) - 1
    for value, help_text in suggestions_for(cmd, prog_name, words, cword):
        if shell in ("zsh", "fish") and help_text:
            sys.stdout.write(f"{value}\t{help_text}\n")
        else:
            sys.stdout.write(f"{value}\n")
    sys.stdout.flush()
    return _finish(standalone_mode, 0)


def _finish(standalone_mode: bool, code: int):
    if standalone_mode:
        raise SystemExit(code)
    return None


__all__ = ["run_completion", "suggestions_for", "SHELLS", "PATH_FILE", "PATH_DIR"]
