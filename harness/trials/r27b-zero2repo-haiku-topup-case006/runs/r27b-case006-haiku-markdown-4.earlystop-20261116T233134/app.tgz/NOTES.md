# Implementation notes

Optlyn is built as `src/optlyn` (src layout, zero runtime dependencies, Python 3.10+).
`pyproject.toml` declares a setuptools PEP 517 backend. The tests run with `PYTHONPATH=src`.

## Spec conflicts and what was built

Each entry gives the two statements (with their location in `spec/`) and the choice made.

1. **Callback for an omitted parameter.**
   - `Full_PRD.md` glossary, "Callback": "A parameter callback is not called for a parameter that was omitted and received no value from any source."
   - `Full_PRD.md` FP-03, last normal-behavior bullet: "A missing parameter still runs its callback, so that callback can default from an earlier parameter's value."
   - **Built:** the callback runs for omitted parameters too (FP-03 wording, the more specific rule). Omitted values arrive as `None` (or `()` for repeatable/variadic).

2. **Counting option when omitted.**
   - `Full_PRD.md` FP-03: "A counting option yields how many times it occurred (zero if omitted)."
   - `Interface_Contract.md` §"Delivered values": "counting option | an `int`, or `None` when the option was omitted".
   - **Built:** `0` when omitted.

3. **`Choice` case sensitivity.**
   - `Interface_Contract.md` §5 signature: `Choice(choices, case_sensitive=True)`.
   - `Interface_Contract.md` §5 enum note: "members are matched by name; by default the match ignores letter case".
   - **Built:** `case_sensitive` defaults to `None`, which means case-sensitive for plain lists and case-insensitive for enum classes. Passing `True`/`False` overrides this.

4. **`DateTime` with several matching formats.**
   - `Full_PRD.md` FP-05: "Formats are tried in order; the first success wins."
   - `Interface_Contract.md` §5: "When several formats match a value, the last matching format is used."
   - **Built:** first success wins (PRD). The default formats cannot overlap, so this only matters for author formats.

5. **`FloatRange` clamp with an open bound.**
   - `Full_PRD.md` FP-05: "Clamp is only allowed when both bounds are closed"; "Float range refuses clamp when a bound is open (declaration error)."
   - `Interface_Contract.md` §5: "With `clamp=True` and an open bound, a value beyond that bound becomes the bound."
   - **Built:** declaration error (PRD).

6. **`Path(resolve_path=True)` and a leading `~`.**
   - `Full_PRD.md` FP-09: resolve "(symlinks resolved to their real target; a leading tilde is not expanded)".
   - `Interface_Contract.md` §5: "With `resolve_path=True`, a leading `~` is first expanded to the home directory."
   - **Built:** the Interface wording (`~` is expanded when `resolve_path=True`). Without `resolve_path`, the path is unchanged.

7. **Confirmation prompt mismatch.**
   - `Full_PRD.md` FP-08: "A confirmation prompt ... rejects a mismatch by asking the pair again; mismatched values are not delivered."
   - `Full_PRD.md` FP-13: "Abort — ... two different values typed into a confirmation prompt ... yields ... abort-class exit (1)."
   - **Built:** mismatches re-ask (FP-08). Abort happens only on end of input, which FP-08 also specifies.

8. **Isolated filesystem cleanup.**
   - `Full_PRD.md` FP-14: "When no parent is given, the runner removes that directory on exit"; the same paragraph says "The new directory is always left in place after the block ends".
   - **Built:** removed when no `temp_dir` is given, left in place when one is given (the first, more specific rule).

9. **Metavar for an integer option.**
   - `Full_PRD.md` FP-02: "an integer option `--count` appears on the help page as `--count COUNT`" (example).
   - `Full_PRD.md` FP-02, same paragraph (rule): "the default metavar is the type name in uppercase".
   - **Built:** the rule, so an integer option shows `--count INTEGER`.

10. **Short help for group listings.**
    - `Full_PRD.md` FP-02: short help is "the first sentence of the docstring ... ellipsized if it cannot fit on one line at the wrap width".
    - `Interface_Contract.md` §2 item 5: "the start of the child's first paragraph, cut with `...` at 45 characters".
    - **Built:** the Interface rule (first paragraph, cut to 45 characters with `...`).

11. **Form feed in a docstring or `help`.**
    - `Full_PRD.md` FP-02: "text after that character is omitted from the help page".
    - `Interface_Contract.md` §3 `command`: "a form-feed character in it is dropped and the text after it is kept".
    - **Built:** the PRD rule, truncation at the form feed.

12. **`show_default` on a `False` flag.**
    - `Full_PRD.md` FP-02: "For a single-option boolean flag whose default is off (false), that default remains hidden even if show-default is on".
    - `Interface_Contract.md` §4 `show_default`: "when on, the default is shown for every option, a flag whose default is `False` included".
    - **Built:** the PRD rule (a `False` flag default stays hidden).

13. **Completion on an empty token.**
    - `Full_PRD.md` FP-12: "Options are listed only once at least a dash has been typed."
    - `Interface_Contract.md` §8: "the suggestions for an empty token are the subcommand names followed by the option names".
    - **Built:** the PRD rule. An empty token suggests subcommands only.

14. **Help width versus wrap width.**
    - `Full_PRD.md` FP-02: "a maximum content width that defaults to 80 columns" caps auto-detected width.
    - `Full_PRD.md` FP-11: "Help pages and wrapped text use a maximum content width of 100 columns unless the caller sets another."
    - **Built:** help pages use `max_content_width` (default 80, as in FP-02). `optlyn.formatting.wrap_text` defaults to 100 (as in FP-11).

15. **Context `invoked_subcommand` for a chain.**
    - `Interface_Contract.md` §6 leaves the chain value's form to the implementer. The PRD says only that it must be distinguishable.
    - **Built:** a private sentinel object, so it is neither `None` nor a child name.

## Interpretations and gaps

- `CliRunner(capture="fd")` is accepted but behaves like `"sys"`. OS-level file-descriptor capture is not implemented.
- Windows argument expansion (glob, `~`, environment) is not implemented. The spec allows this to be disabled, and the default is no expansion.
- Pager, editor and launch helpers are functional on Linux but thin. They are not exercised by tests here.
- `getchar` reads from `/dev/tty` in raw mode when that is available. Otherwise it falls back to `sys.stdin`.
- Shell completion scripts for zsh, fish and PowerShell are minimal. The suggestion streams follow the interface. Path requests are emitted as `@path-file:<token>` / `@path-dir:<token>` lines.
- Duplicate destinations (feature-switch groups) pick a winner: the last declared option that appeared on the command line, else the last declared option.
