"""In-process runner for invoking a command with argument tokens and capturing output."""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _state


class Result:
    """Outcome of a runner invocation."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Recorder:
    """Keeps captured writes per channel and in overall write order."""

    def __init__(self):
        self.chunks = []
        self.stdout = bytearray()
        self.stderr = bytearray()

    def add(self, channel, data):
        if not data:
            return
        self.chunks.append((channel, bytes(data)))
        (self.stdout if channel == "stdout" else self.stderr).extend(data)


class _ChannelBuffer(io.BytesIO):
    def __init__(self, recorder, channel):
        super().__init__()
        self._recorder = recorder
        self._channel = channel

    def write(self, data):
        self._recorder.add(self._channel, data)
        return len(data)

    def writable(self):
        return True


class _EchoStdin(io.StringIO):
    """Standard input that echoes everything actually read into the output."""

    _optlyn_echo_stdin = True

    def __init__(self, text, out):
        super().__init__(text)
        self._out = out

    def _echo(self, data):
        if data:
            self._out.write(data)
            self._out.flush()
        return data

    def readline(self, size=-1):
        return self._echo(super().readline(size))

    def read(self, size=-1):
        return self._echo(super().read(size))


class CliRunner:
    """Invokes a command in-process with captured streams."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def _input_text(self, input):
        if input is None:
            return ""
        if isinstance(input, bytes):
            return input.decode(self.charset, "replace")
        return str(input)

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        recorder = _Recorder()
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        text = self._input_text(input)
        try:
            if self.capture == "fd":
                yield from self._fd_isolation(recorder, text)
            else:
                out = io.TextIOWrapper(_ChannelBuffer(recorder, "stdout"),
                                       encoding=self.charset, errors="replace",
                                       write_through=True)
                err = io.TextIOWrapper(_ChannelBuffer(recorder, "stderr"),
                                       encoding=self.charset, errors="replace",
                                       write_through=True)
                if self.echo_stdin:
                    inp = _EchoStdin(text, out)
                else:
                    inp = io.StringIO(text)
                sys.stdin, sys.stdout, sys.stderr = inp, out, err
                _state.runner_depth += 1
                try:
                    yield recorder
                finally:
                    _state.runner_depth -= 1
                    for stream in (out, err):
                        try:
                            stream.flush()
                        except Exception:
                            pass
                    sys.stdin, sys.stdout, sys.stderr = old_streams
        finally:
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def _fd_isolation(self, recorder, text):
        """Descriptor capture: OS-level writes to fds 1 and 2 are recorded too."""
        out_tmp = tempfile.TemporaryFile()
        err_tmp = tempfile.TemporaryFile()
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.flush()
            except Exception:
                pass
        saved1 = os.dup(1)
        saved2 = os.dup(2)
        os.dup2(out_tmp.fileno(), 1)
        os.dup2(err_tmp.fileno(), 2)
        out = io.TextIOWrapper(open(1, "wb", closefd=False, buffering=0),
                               encoding=self.charset, errors="replace", write_through=True)
        err = io.TextIOWrapper(open(2, "wb", closefd=False, buffering=0),
                               encoding=self.charset, errors="replace", write_through=True)
        inp = _EchoStdin(text, out) if self.echo_stdin else io.StringIO(text)
        sys.stdin, sys.stdout, sys.stderr = inp, out, err
        _state.runner_depth += 1
        try:
            yield recorder
        finally:
            _state.runner_depth -= 1
            for stream in (out, err):
                try:
                    stream.flush()
                except Exception:
                    pass
            sys.stdin, sys.stdout, sys.stderr = old_streams
            os.dup2(saved1, 1)
            os.dup2(saved2, 2)
            os.close(saved1)
            os.close(saved2)
            out_tmp.seek(0)
            err_tmp.seek(0)
            recorder.stdout.extend(out_tmp.read())
            recorder.stderr.extend(err_tmp.read())
            recorder.chunks.append(("stdout", bytes(recorder.stdout)))
            recorder.chunks.append(("stderr", bytes(recorder.stderr)))
            out_tmp.close()
            err_tmp.close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        if isinstance(args, str):
            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as recorder:
            try:
                return_value = cli.main(args=list(args or ()), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
                if exit_code != 0:
                    exception = e
            except Exception as e:
                if not catch:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        output = b"".join(data for _, data in recorder.chunks)
        if self.capture == "fd":
            output = bytes(recorder.stdout) + bytes(recorder.stderr)
        return Result(
            self,
            stdout_bytes=bytes(recorder.stdout),
            stderr_bytes=bytes(recorder.stderr),
            output_bytes=output,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a fresh empty working directory.

        Without ``temp_dir`` the directory is removed on exit; with a parent
        path the new directory is created under it and left in place.
        """
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
