"""Commands, groups, parameters and the invocation context."""

import contextlib
import enum
import inspect
import os
import re
import shutil
import sys

from . import _state, termui
from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingParameter,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter
from .parser import FLAG_VALUE_MARK, PROMPT_MARK, OptionParser
from .paramtypes import BOOL, INT, File, Path, Tuple, convert_type

UNSET = object()

_TRUE_STRINGS = {"1", "true", "t", "yes", "y", "on"}
_FALSE_STRINGS = {"0", "false", "f", "no", "n", "off"}


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT = "default"
    DEFAULT_MAP = "default_map"
    PROMPT = "prompt"


_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


def _warn_deprecated(kind, name, note=None):
    msg = f"DeprecationWarning: The {kind} {name!r} is deprecated."
    if isinstance(note, str) and note:
        msg += " " + note
    termui.echo(msg, err=True)


def _wrap_width(ctx):
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    cols = shutil.get_terminal_size((80, 24)).columns
    limit = ctx.max_content_width if ctx.max_content_width is not None else 80
    return max(min(cols, limit) - 2, 50)


# ---------------------------------------------------------------- context


class Context:
    """Per-invocation state: parsed values, linkage to parent, settings."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, auto_envvar_prefix=None,
                 help_option_names=None, token_normalize_func=None, color=None,
                 show_default=None, allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, resilient_parsing=False, **extra):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        inherit = parent if parent is not None else None
        self.terminal_width = terminal_width if terminal_width is not None else (inherit.terminal_width if inherit else None)
        self.max_content_width = max_content_width if max_content_width is not None else (inherit.max_content_width if inherit else None)
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix is not None and info_name:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix
        if help_option_names is not None:
            self.help_option_names = list(help_option_names)
        elif inherit is not None:
            self.help_option_names = list(inherit.help_option_names)
        else:
            self.help_option_names = ["--help"]
        self.token_normalize_func = token_normalize_func if token_normalize_func is not None else (inherit.token_normalize_func if inherit else None)
        self.color = color if color is not None else (inherit.color if inherit else None)
        self.show_default = show_default if show_default is not None else (inherit.show_default if inherit else None)
        self.allow_extra_args = bool(allow_extra_args) if allow_extra_args is not None else False
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None
            else command.allow_interspersed_args
        )
        self.ignore_unknown_options = bool(ignore_unknown_options) if ignore_unknown_options is not None else False
        self.resilient_parsing = resilient_parsing
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._declared = set()
        self._stack = contextlib.ExitStack()
        self._depth = 0
        self.extra = extra

    # -- scope and resources
    def _push(self):
        _state.push_context(self)

    def _pop(self):
        _state.pop_context()

    def __enter__(self):
        self._push()
        self._depth += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        self._pop()
        self._depth -= 1
        if self._depth <= 0:
            self.close()

    @contextlib.contextmanager
    def scope(self, cleanup=True):
        self._push()
        try:
            yield self
        finally:
            self._pop()
            if cleanup and self._depth <= 0:
                self.close()

    def call_on_close(self, func):
        self._stack.callback(func)

    def with_resource(self, cm):
        return self._stack.enter_context(cm)

    def close(self):
        self._stack.close()

    # -- navigation
    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    # -- helpers for callbacks
    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def fail(self, message):
        raise UsageError(message, self)

    def get_parameter_source(self, name):
        if name not in self._declared:
            return None
        return self._sources.get(name)

    def invoke(self, callback, *args, **kwargs):
        if isinstance(callback, Command):
            other = callback
            ctx = Context(other, info_name=other.name, parent=self)
            for p in other.params:
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.default_for_invoke(ctx)
            with ctx:
                if other.callback is None:
                    return None
                return other.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)


# ---------------------------------------------------------------- parameters


def _is_name_decl(decl):
    return bool(decl) and not (decl[0].isalnum() or decl[0] == "_")


def _split_decls(decls):
    dest = None
    opts = []
    secondary = []
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise TypeError(f"Invalid parameter declaration: {decl!r}")
        if not _is_name_decl(decl):
            if dest is not None:
                raise TypeError("A parameter may have only one destination name.")
            dest = decl
            continue
        parts = decl.split("/")
        if len(parts) == 2 and parts[0] and parts[1] and _is_name_decl(parts[1]):
            opts.append(parts[0])
            secondary.append(parts[1])
        else:
            opts.append(decl)
    return dest, opts, secondary


def _derive_name(names):
    longs = [n for n in names if len(n) > 2]
    chosen = longs[0] if longs else names[0]
    return re.sub(r"^[^A-Za-z0-9_]+", "", chosen).replace("-", "_")


class Parameter:
    """Common machinery for options and arguments."""

    param_kind = "parameter"
    is_flag = False
    count = False
    optional_value = False
    prompt_on = False
    prompt_required = False
    hide_input = False
    confirmation_prompt = False
    opts = ()
    secondary_opts = ()

    def _init_common(self, name, type_, default, required, callback, nargs, multiple,
                     metavar, expose_value, is_eager, envvar, shell_complete, deprecated,
                     help_text, hidden, allow_from_autoenv):
        self.name = name
        self.type = type_
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help_text
        self.hidden = hidden
        self.allow_from_autoenv = allow_from_autoenv
        self.is_tuple = isinstance(type_, Tuple)
        self.is_multi = bool(multiple) or nargs == -1
        self.auto_default = False

    # -- declared information used by callbacks and completion
    def get_error_hint(self):
        return "/".join(list(self.opts) + list(self.secondary_opts)) or self.name.upper()

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        base = self.type.metavar_text(self)
        if self.is_tuple:
            return base
        if self.nargs > 1:
            return " ".join([base] * self.nargs)
        return base

    def _declared_default(self):
        d = self.default
        if callable(d):
            d = d()
        if d is None and self.auto_default:
            return False
        return d

    def default_for_invoke(self, ctx):
        d = self._declared_default()
        if d is None:
            return self._empty_value()
        return d

    def _empty_value(self):
        if self.is_flag:
            return False
        if self.count:
            return 0
        if self.is_multi:
            return ()
        return None

    def _conv(self, ctx, ty, value):
        try:
            return ty.convert(value, self, ctx)
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def _split(self, raw):
        if isinstance(self.type, (File, Path)):
            return raw.split(os.pathsep)
        return raw.split()

    def _conv_tokens(self, ctx, tokens):
        tokens = tuple(tokens)
        if self.is_tuple:
            if len(tokens) != len(self.type.types):
                raise BadParameter(f"takes {len(self.type.types)} values.", ctx, self)
            return tuple(self._conv(ctx, t, v) for t, v in zip(self.type.types, tokens))
        if self.nargs == 1:
            if len(tokens) != 1:
                raise BadParameter("takes 1 value.", ctx, self)
            return self._conv(ctx, self.type, tokens[0])
        if len(tokens) != self.nargs:
            raise BadParameter(f"takes {self.nargs} values.", ctx, self)
        return tuple(self._conv(ctx, self.type, v) for v in tokens)

    @property
    def _elem_tuple(self):
        return self.is_tuple or self.nargs > 1

    def _chunked(self, ctx, tokens):
        if self._elem_tuple:
            size = len(self.type.types) if self.is_tuple else self.nargs
            if len(tokens) % size:
                raise BadParameter(f"takes {size} values per occurrence.", ctx, self)
            groups = [tokens[i:i + size] for i in range(0, len(tokens), size)]
            return tuple(self._conv_tokens(ctx, g) for g in groups)
        return tuple(self._conv(ctx, self.type, t) for t in tokens)

    def _coerce_value(self, ctx, x):
        if isinstance(x, (list, tuple)) and self._elem_tuple:
            return self._conv_tokens(ctx, x)
        if isinstance(x, str):
            if self._elem_tuple:
                return self._conv_tokens(ctx, self._split(x))
            return self._conv(ctx, self.type, x)
        return x

    def _coerce(self, ctx, v):
        """Convert a default-map or declared default value."""
        if self.is_flag or self.count:
            if isinstance(v, str):
                return self._conv(ctx, INT if self.count else self.type, v)
            return v
        if self.is_multi:
            if isinstance(v, str):
                if self.multiple and self.nargs == 1 and not self.is_tuple:
                    raise BadParameter(
                        "needs an iterable (sequence) default, not a string.", ctx, self
                    )
                return self._chunked(ctx, self._split(v))
            if not isinstance(v, (list, tuple)):
                raise BadParameter(
                    f"needs an iterable (sequence) default, not {type(v).__name__}.", ctx, self
                )
            return tuple(self._coerce_value(ctx, x) for x in v)
        if self._elem_tuple and isinstance(v, str):
            return self._conv_tokens(ctx, self._split(v))
        return self._coerce_value(ctx, v)

    def _from_default_map(self, ctx):
        dm = ctx.default_map
        if not isinstance(dm, dict) or self.name not in dm:
            return UNSET
        value = dm[self.name]
        return UNSET if value is None else value

    def _env_names(self, ctx):
        names = list(self.envvar)
        if isinstance(self, Option) and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            auto = "_".join([ctx.auto_envvar_prefix, self.name]).upper().replace("-", "_")
            names.append(auto)
        return names

    def _from_env(self, ctx):
        raw = None
        for name in self._env_names(ctx):
            value = os.environ.get(name)
            if value:
                raw = value
                break
        if raw is None:
            return UNSET
        if self.is_flag:
            return self._flag_from_env(ctx, raw)
        if self.count:
            return self._conv(ctx, INT, raw)
        if self.is_multi or self._elem_tuple:
            if self.is_multi:
                return self._chunked(ctx, self._split(raw))
            return self._conv_tokens(ctx, self._split(raw)[: self.nargs])
        return self._conv(ctx, self.type, raw)

    def _flag_from_env(self, ctx, raw):
        fv = self.flag_value
        text = raw.strip().lower()
        if not isinstance(fv, bool) and raw.strip() == str(fv):
            return fv
        if text in _TRUE_STRINGS:
            return True
        if text in _FALSE_STRINGS or text == "":
            return False
        if not isinstance(fv, bool):
            return UNSET
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx, self)

    def _prompt(self, ctx, fallback):
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()

        def convert(raw):
            return self._coerce_value(ctx, raw)

        try:
            value = termui.prompt_value(text, fallback, self.hide_input,
                                        self.confirmation_prompt, convert)
        except EOFError as e:
            raise Abort() from e
        if self.multiple:
            value = (value,)
        return value

    def _resolve(self, ctx, raw):
        value = UNSET
        source = None
        forced = False
        if raw is not None:
            if raw and all(o is PROMPT_MARK for o in raw):
                forced = True
            else:
                value = self._from_commandline(ctx, [o for o in raw if o is not PROMPT_MARK])
                source = ParameterSource.COMMANDLINE
        if value is UNSET and not forced:
            value = self._from_env(ctx)
            if value is not UNSET:
                source = ParameterSource.ENVIRONMENT
        dm = UNSET
        if value is UNSET:
            dm = self._from_default_map(ctx)
        declared = None
        if value is UNSET:
            declared = self._declared_default()
        if value is UNSET and self.prompt_on and (forced or self.prompt_required):
            fallback = dm if dm is not UNSET else declared
            value = self._prompt(ctx, fallback)
            source = ParameterSource.PROMPT
        if value is UNSET and dm is not UNSET:
            value = self._coerce(ctx, dm)
            source = ParameterSource.DEFAULT_MAP
        if value is UNSET and declared is not None:
            value = self._coerce(ctx, declared)
            source = ParameterSource.DEFAULT
        if value is UNSET:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self)
            value = self._empty_value()
            source = ParameterSource.DEFAULT
        return value, source

    def process(self, ctx, raw):
        """Resolve, convert and run the callback. Returns (value, source)."""
        value, source = self._resolve(ctx, raw)
        if source is ParameterSource.COMMANDLINE and self.deprecated:
            _warn_deprecated(self.param_kind, self.name if self.param_kind == "argument" else "/".join(self.opts), self.deprecated if isinstance(self.deprecated, str) else None)
        if self.callback is not None:
            try:
                value = self.callback(ctx, self, value)
            except BadParameter as e:
                if e.param is None:
                    e.param = self
                if e.ctx is None:
                    e.ctx = ctx
                raise
        return value, source


class Option(Parameter):
    param_kind = "option"

    def __init__(self, param_decls=(), *, type=None, default=None, required=False,
                 is_flag=None, flag_value=None, count=False, multiple=False, nargs=None,
                 envvar=None, allow_from_autoenv=True, prompt=False, prompt_required=True,
                 hide_input=False, confirmation_prompt=False, callback=None, is_eager=False,
                 expose_value=True, hidden=False, deprecated=False, help=None, metavar=None,
                 show_default=None, show_envvar=False, show_choices=True,
                 shell_complete=None, **kwargs):
        dest, opts, secondary = _split_decls(tuple(param_decls))
        if not opts:
            if dest is None:
                raise TypeError("An option needs at least one name.")
            opts = ["--" + dest.replace("_", "-")]
        name = dest if dest is not None else _derive_name(opts + secondary)
        if is_flag is None:
            is_flag = (bool(secondary) or flag_value is not None
                       or (isinstance(default, bool) and not count))
        if count:
            is_flag = False
        if is_flag and multiple:
            raise TypeError("A flag option cannot be repeatable.")
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot prompt.")
        if nargs is not None and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("nargs must be a positive integer for an option.")

        self.opts = list(opts)
        self.secondary_opts = list(secondary)
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.prompt = prompt
        self.prompt_on = bool(prompt)
        self.prompt_required = prompt_required

        if self.is_flag:
            ty = type if type is not None else BOOL
            if flag_value is None:
                flag_value = True
            self.flag_value = flag_value
            self.optional_value = False
        elif self.count:
            ty = type if type is not None else INT
            self.flag_value = None
            self.optional_value = False
        else:
            ty = convert_type(type, default)
            self.flag_value = flag_value
            self.optional_value = flag_value is not None
        if isinstance(ty, Tuple):
            if nargs is not None and nargs != len(ty.types):
                raise TypeError("nargs does not match the tuple type length.")
            nargs = len(ty.types)
        nargs = 1 if nargs is None else nargs
        self._init_common(
            name=name, type_=ty, default=default, required=required, callback=callback,
            nargs=nargs, multiple=bool(multiple), metavar=metavar,
            expose_value=expose_value, is_eager=is_eager, envvar=envvar,
            shell_complete=shell_complete, deprecated=deprecated, help_text=help,
            hidden=hidden, allow_from_autoenv=allow_from_autoenv,
        )
        self.auto_default = self.is_flag and default is None
        self.is_multi = bool(multiple)

    def _from_commandline(self, ctx, occ):
        if self.is_flag:
            return occ[-1]
        if self.count:
            return len(occ)
        if self.multiple:
            return tuple(self._occ_value(ctx, o) for o in occ)
        return self._occ_value(ctx, occ[-1])

    def _occ_value(self, ctx, occ):
        if occ is FLAG_VALUE_MARK:
            return self.flag_value
        return self._conv_tokens(ctx, occ)


class Argument(Parameter):
    param_kind = "argument"

    def __init__(self, param_decls=(), *, type=None, default=None, required=None, nargs=None,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 expose_value=True, is_eager=False, hidden=False, shell_complete=None,
                 **kwargs):
        decls = tuple(param_decls)
        if len(decls) != 1 or not isinstance(decls[0], str) or not decls[0]:
            raise TypeError("An argument needs exactly one destination name.")
        name = decls[0]
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        ty = convert_type(type, default)
        if isinstance(ty, Tuple):
            if nargs not in (1, len(ty.types)):
                raise TypeError("nargs does not match the tuple type length.")
            nargs = len(ty.types)
        self.is_flag = False
        self.flag_value = None
        self._init_common(
            name=name, type_=ty, default=default, required=bool(required), callback=callback,
            nargs=nargs, multiple=False, metavar=metavar, expose_value=expose_value,
            is_eager=is_eager, envvar=envvar, shell_complete=shell_complete,
            deprecated=deprecated, help_text=help, hidden=hidden, allow_from_autoenv=False,
        )

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def get_error_hint(self):
        return self.name.upper()

    def _from_commandline(self, ctx, tokens):
        if self.nargs == -1:
            return tuple(self._conv(ctx, self.type, t) for t in tokens)
        if len(tokens) != self.nargs:
            raise UsageError(
                f"Argument {self.name.upper()!r} takes {self.nargs} values.", ctx
            )
        return self._conv_tokens(ctx, tokens)


def _assign_arguments(arguments, tokens):
    """Distribute positional tokens over declared arguments in order.

    Returns (mapping argument -> list of tokens or None, leftover tokens).
    """
    rest = list(tokens)
    out = {}
    for idx, arg in enumerate(arguments):
        need_after = sum(
            b.nargs for b in arguments[idx + 1:] if b.required and b.nargs > 0
        )
        avail = len(rest) - need_after
        if arg.nargs == -1:
            take = max(0, avail)
            out[arg] = rest[:take]
            rest = rest[take:]
            continue
        n = arg.nargs
        if arg.required:
            take = n if len(rest) >= n else len(rest)
        else:
            take = n if avail >= n else 0
        if take == 0:
            out[arg] = None
            continue
        out[arg] = rest[:take]
        rest = rest[take:]
    return out, rest


# ---------------------------------------------------------------- commands


class _NoArgsHelp(UsageError):
    """Help shown because a command was invoked with no arguments (usage failure)."""

    def show(self):
        termui.echo(self.ctx.get_help(), err=True)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help())
    ctx.exit()


def _make_help_option(names):
    return Option(
        tuple(names),
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_show_help,
    )


def _split_pieces_placeholder(arg, ctx):
    ph = arg.get_metavar(ctx)
    if arg.nargs == -1:
        base = ph if arg.required else f"[{ph}]"
        return base + "..."
    return ph if arg.required else f"[{ph}]"


class Command:
    """A leaf command: parses options/arguments and runs a callback."""

    allow_interspersed_args = True
    is_group = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]",
                 add_help_option=True, no_args_is_help=False, hidden=False,
                 deprecated=False, **kwargs):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        variadic = [p for p in self.params if isinstance(p, Argument) and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument may be declared on a command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters and parsing
    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            taken = set()
            for p in params:
                taken.update(p.opts)
                taken.update(p.secondary_opts)
            names = [n for n in ctx.help_option_names if n not in taken]
            if names:
                params.append(_make_help_option(names))
        return params

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            try:
                self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise _NoArgsHelp("", ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        ctx._declared = {p.name for p in params if p.expose_value}
        mixing_group = self.is_group and ctx.allow_interspersed_args
        parser = OptionParser(
            options,
            interspersed=ctx.allow_interspersed_args,
            ignore_unknown=ctx.ignore_unknown_options,
            normalize=ctx.token_normalize_func,
            unknown_after_positional=mixing_group,
        )
        try:
            occ, order, positional = parser.parse(args)
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            raise
        assigned, rest = _assign_arguments(arguments, positional)
        if rest and not self.is_group and not ctx.allow_extra_args:
            raise UsageError(
                f"Got unexpected extra argument{'s' if len(rest) > 1 else ''} ({' '.join(rest)})",
                ctx,
            )
        ctx.args = rest
        raw = {}
        for o in options:
            raw[o] = occ.get(o)
        for a in arguments:
            tokens = assigned.get(a)
            if a.nargs == -1 and not tokens:
                tokens = None
            raw[a] = tokens
        self._process_params(ctx, params, raw, order)

    def _process_params(self, ctx, params, raw, order):
        eager_given = [p for p in order if p.is_eager]
        eager_rest = [p for p in params if p.is_eager and p not in eager_given]
        ordered = []
        for p in eager_given + eager_rest + [p for p in params if not p.is_eager]:
            if p not in ordered:
                ordered.append(p)
        winners = {}
        for p in ordered:
            value, source = p.process(ctx, raw.get(p))
            if not p.expose_value:
                continue
            # Within the default tier an explicit declared default beats an
            # auto-derived one; otherwise the last declared option wins a tie.
            default_bonus = (0 if p.auto_default else 1) if source is ParameterSource.DEFAULT else 0
            rank = (_RANK[source], default_bonus, params.index(p))
            prev = winners.get(p.name)
            if prev is None or rank > prev[0]:
                winners[p.name] = (rank, p)
                ctx.params[p.name] = value
                ctx._sources[p.name] = source

    # -- invocation
    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated("command", self.name, self.deprecated if isinstance(self.deprecated, str) else None)
        if self.callback is None:
            return None
        kwargs = dict(ctx.params)
        with ctx:
            return self.callback(**kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        args = list(sys.argv[1:]) if args is None else list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "root"
        if complete_var is None:
            complete_var = "_" + re.sub(r"[^0-9A-Za-z]", "_", prog_name).upper() + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            return run_completion(self, prog_name, instruction, args, standalone_mode,
                                  complete_var)
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                if not standalone_mode:
                    raise
                termui.echo(file=sys.stderr)
                raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)

    # -- help
    def get_help_text(self):
        text = inspect.cleandoc(self.help or "")
        if "\f" in text:
            text = text.split("\f", 1)[0]
        return text

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = self.short_help
        else:
            text = " ".join(self.get_help_text().split("\n\n", 1)[0].split())
            m = re.search(r"[.!?](?=\s|$)", text)
            if m:
                text = text[: m.end()]
        if self.deprecated:
            text = "(Deprecated) " + text
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

    def _usage_pieces(self, ctx):
        params = self.get_params(ctx)
        pieces = []
        if self.options_metavar and any(isinstance(p, Option) and not p.hidden for p in params):
            pieces.append(self.options_metavar)
        for arg in params:
            if isinstance(arg, Argument):
                pieces.append(_split_pieces_placeholder(arg, ctx))
        return pieces

    def get_usage(self, ctx):
        pieces = self._usage_pieces(ctx)
        line = f"Usage: {ctx.command_path}"
        if pieces:
            line += " " + " ".join(pieces)
        return line

    def get_help(self, ctx):
        return self.format_help(ctx)

    def format_help(self, ctx):
        width = _wrap_width(ctx)
        fmt = HelpFormatter(width)
        fmt.write_line(self.get_usage(ctx))
        fmt.write_line("")
        if self.deprecated:
            fmt.write_line("(Deprecated)")
            fmt.write_line("")
        fmt.write_paragraph(self.get_help_text())
        params = self.get_params(ctx)
        arg_rows = [
            (a.get_metavar(ctx), a.help) for a in params
            if isinstance(a, Argument) and a.help and not a.hidden
        ]
        fmt.write_section("Positional arguments", arg_rows)
        opt_rows = []
        for p in params:
            if isinstance(p, Option) and not p.hidden:
                opt_rows.append(self._option_row(ctx, p))
        fmt.write_section("Options", opt_rows)
        if self.is_group:
            cmd_rows = self._command_rows(ctx, width)
            fmt.write_section("Commands", cmd_rows)
        if self.epilog:
            fmt.write_paragraph(self.epilog)
        return fmt.getvalue()

    def _option_row(self, ctx, p):
        if p.secondary_opts:
            names = "/".join(p.opts + p.secondary_opts)
            metavar = None
        else:
            names = ", ".join(p.opts)
            metavar = None if (p.is_flag or p.count) else p.get_metavar(ctx)
        first = names + (f" {metavar}" if metavar else "")
        extras = []
        if p.help:
            extras.append(p.help)
        show = p.show_default if p.show_default is not None else ctx.show_default
        hide_flag_off = p.is_flag and not p.secondary_opts and p.default is False
        if show and p.default is not None and not hide_flag_off:
            if isinstance(show, str):
                text = show
            elif callable(p.default):
                text = "(dynamic)"
            elif isinstance(p.default, (list, tuple)):
                text = ", ".join(str(d) for d in p.default)
            else:
                text = str(p.default)
            extras.append(f"[default: {text}]")
        if p.show_envvar:
            env = p._env_names(ctx) if p.envvar else []
            if env:
                extras.append(f"[env var: {', '.join(env)}]")
        if p.required:
            extras.append("[required]")
        if p.deprecated:
            extras.append("(DEPRECATED)")
        return (first, " ".join(extras))

    def _command_rows(self, ctx, width):
        return []


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False
    is_group = True

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_cb = result_callback
        if commands:
            items = commands.items() if isinstance(commands, dict) else [(c.name, c) for c in commands]
            for cname, cmd in items:
                self.add_command(cmd, cname)

    # -- registration
    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Cannot attach a group beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            self._result_cb = f
            return f

        return decorator

    # -- lookup (override points)
    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        if ctx is not None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for name, cmd in self.commands.items():
                if ctx.token_normalize_func(name) == wanted:
                    return cmd
        return None

    def _command_rows(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(limit=max(width - 34, 20))))
        return rows

    def _usage_pieces(self, ctx):
        pieces = super()._usage_pieces(ctx)
        if self.subcommand_metavar:
            sub = self.subcommand_metavar
        elif self.chain:
            sub = "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        elif self.invoke_without_command:
            sub = "[COMMAND] [ARGS]..."
        else:
            sub = "COMMAND [ARGS]..."
        pieces.append(sub)
        return pieces

    def _resolve_command(self, ctx, args):
        name = args[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        return name, cmd, args[1:]

    # -- invocation
    def invoke(self, ctx):
        args = list(ctx.args)
        if not args:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                if self.chain:
                    return self._invoke_chain(ctx, [])
                rv = Command.invoke(self, ctx)
                if self._result_cb is not None:
                    with ctx:
                        return ctx.invoke(self._result_cb, rv, **ctx.params)
                return rv
            raise UsageError("Missing command.", ctx)
        if self.chain:
            return self._invoke_chain(ctx, args)
        cmd_name, cmd, rest = self._resolve_command(ctx, args)
        ctx.invoked_subcommand = cmd_name
        Command.invoke(self, ctx)
        sub_ctx = cmd.make_context(cmd_name, rest, parent=ctx)
        with sub_ctx:
            sub_rv = cmd.invoke(sub_ctx)
        if self._result_cb is not None:
            with ctx:
                return ctx.invoke(self._result_cb, sub_rv, **ctx.params)
        return sub_rv

    def _invoke_chain(self, ctx, args):
        ctx.invoked_subcommand = "*"
        Command.invoke(self, ctx)
        contexts = []
        while args:
            name, cmd, args = self._resolve_command(ctx, args)
            sub = cmd.make_context(
                name, args, parent=ctx,
                allow_extra_args=True, allow_interspersed_args=False,
            )
            contexts.append(sub)
            args = list(sub.args)
        results = []
        for sub in contexts:
            with sub:
                results.append(sub.command.invoke(sub))
        if self._result_cb is not None:
            with ctx:
                ctx.invoke(self._result_cb, results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group presenting the union of subcommands from several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for src in self.sources:
            found = src.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return super().get_command(ctx, cmd_name)

