"""Token-level option parsing (no value conversion here)."""

from .exceptions import NoSuchOption, UsageError

# Marker stored in an occurrence list: a valued option given with no value
# where the option prompts (the prompt is run later).
PROMPT_MARK = object()
# Marker for an optional-value option given without a value.
FLAG_VALUE_MARK = object()


class OptionParser:
    """Scans tokens and records option occurrences in command-line order.

    ``occurrences`` maps each option to a list of entries:
      * flags: the bool value delivered for that occurrence
      * counting options: ``None`` per occurrence
      * valued options: a tuple of raw tokens, PROMPT_MARK, or FLAG_VALUE_MARK
    """

    def __init__(self, options, interspersed=True, ignore_unknown=False,
                 normalize=None, unknown_after_positional=False):
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.normalize = normalize
        self.unknown_after_positional = unknown_after_positional
        self.prefixes = {"-"}
        self.table = {}
        self.norm_table = {}
        for opt in options:
            for name in opt.opts:
                self._add(name, opt, True)
            for name in opt.secondary_opts:
                self._add(name, opt, False)

    def _add(self, name, opt, on):
        self.table.setdefault(name, (opt, on))
        self.prefixes.add(name[0])
        if self.normalize is not None:
            self.norm_table.setdefault(self.normalize(name), (opt, on))

    def _lookup(self, name):
        found = self.table.get(name)
        if found is None and self.normalize is not None:
            found = self.norm_table.get(self.normalize(name))
        return found

    def _is_optionish(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args):
        occ = {}
        order = []
        positional = []
        seen_positional = False
        i = 0
        n = len(args)
        while i < n:
            arg = args[i]
            i += 1
            if not self.interspersed and seen_positional:
                positional.append(arg)
                continue
            if arg == "--":
                positional.extend(args[i:])
                break
            if not self._is_optionish(arg):
                positional.append(arg)
                seen_positional = True
                continue
            before = len(positional)
            i = self._parse_one(arg, args, i, occ, order, positional, seen_positional)
            if len(positional) != before:
                seen_positional = True
        return occ, order, positional

    def _record(self, opt, value, occ, order):
        occ.setdefault(opt, []).append(value)
        if opt not in order:
            order.append(opt)

    def _record_flag(self, opt, on, occ, order):
        if opt.count:
            self._record(opt, None, occ, order)
            return
        if on:
            value = opt.flag_value
        else:
            value = (not opt.flag_value) if isinstance(opt.flag_value, bool) else False
        self._record(opt, value, occ, order)

    def _unknown(self, token, name, positional, seen):
        if self.ignore_unknown or (self.unknown_after_positional and seen):
            positional.append(token)
            return True
        raise NoSuchOption(name)

    def _parse_one(self, arg, args, i, occ, order, positional, seen):
        found = self._lookup(arg)
        if found is not None:
            opt, on = found
            return self._take(opt, on, None, args, i, occ, order, arg)
        if len(arg) > 2 and arg[1] in self.prefixes and arg[0] in self.prefixes:
            name, eq, value = arg.partition("=")
            found = self._lookup(name)
            if found is not None:
                opt, on = found
                return self._take(opt, on, value if eq else None, args, i, occ, order, name)
            self._unknown(arg, name, positional, seen)
            return i
        # Short option stack: -abc is -a -b -c.
        prefix = arg[0]
        chars = arg[1:]
        j = 0
        while j < len(chars):
            name = prefix + chars[j]
            found = self._lookup(name)
            if found is None:
                rest = prefix + chars[j:]
                if self.ignore_unknown or (self.unknown_after_positional and seen):
                    positional.append(rest)
                    return i
                raise NoSuchOption(name)
            opt, on = found
            if opt.is_flag or opt.count:
                self._record_flag(opt, on, occ, order)
                j += 1
                continue
            inline = chars[j + 1:] or None
            return self._take(opt, on, inline, args, i, occ, order, name)
        return i

    def _take(self, opt, on, inline, args, i, occ, order, name):
        if opt.is_flag or opt.count:
            if inline is not None:
                raise UsageError(f"Option {name!r} does not take a value.")
            self._record_flag(opt, on, occ, order)
            return i
        if opt.optional_value:
            if inline is not None:
                self._record(opt, (inline,), occ, order)
            elif i < len(args) and not self._is_optionish(args[i]):
                self._record(opt, (args[i],), occ, order)
                i += 1
            else:
                self._record(opt, FLAG_VALUE_MARK, occ, order)
            return i
        need = opt.nargs
        tokens = [inline] if inline is not None else []
        while len(tokens) < need and i < len(args):
            tokens.append(args[i])
            i += 1
        if len(tokens) < need:
            if opt.prompt_on:
                self._record(opt, PROMPT_MARK, occ, order)
                return i
            raise UsageError(f"Option {name!r} requires an argument.")
        self._record(opt, tuple(tokens), occ, order)
        return i
