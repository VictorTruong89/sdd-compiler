"""Text wrapping and two-column layout used by help pages."""

import textwrap

DEFAULT_WIDTH = 78


def _wrap_one(text, width, initial_indent="", subsequent_indent=""):
    width = max(int(width), 1)
    return textwrap.fill(
        text,
        width=width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=True,
        break_on_hyphens=False,
        replace_whitespace=True,
        drop_whitespace=True,
    )


def wrap_text(text, width=DEFAULT_WIDTH, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap text to ``width``. Single newlines inside a paragraph are not kept.

    A paragraph whose first line is only a backspace character is not rewrapped:
    its line breaks are kept and the backspace line is removed.
    """
    text = "" if text is None else str(text)
    if not preserve_paragraphs:
        flat = " ".join(text.split())
        return _wrap_one(flat, width, initial_indent, subsequent_indent)
    out = []
    paragraphs = [p for p in text.replace("\r\n", "\n").split("\n\n")]
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln if i == 0 else subsequent_indent + ln
                                 for i, ln in enumerate(kept)).rstrip())
            continue
        if not para.strip():
            continue
        flat = " ".join(" ".join(lines).split())
        out.append(_wrap_one(flat, width, initial_indent, subsequent_indent))
    return "\n\n".join(out)


def format_dl(rows, width, indent=2, col_max=30, col_spacing=2):
    """Lay out ``(first, second)`` rows as a two-column list, Click-style."""
    rows = [(str(a), b) for a, b in rows]
    if not rows:
        return []
    first_w = max(len(a) for a, _ in rows)
    first_col = min(first_w, col_max) + col_spacing
    text_width = max(width - first_col - 2, 10)
    lines = []
    for first, second in rows:
        if not second:
            lines.append(" " * indent + first)
            continue
        body = wrap_text(second, text_width, preserve_paragraphs=True).splitlines() or [""]
        if len(first) <= first_col - col_spacing:
            head = " " * indent + first + " " * (first_col - len(first))
            lines.append((head + body[0]).rstrip())
        else:
            lines.append(" " * indent + first)
            lines.append(" " * (indent + first_col) + body[0])
        for line in body[1:]:
            lines.append((" " * (indent + first_col) + line).rstrip())
    return lines


class HelpFormatter:
    """Accumulates help-page lines with section headings."""

    def __init__(self, width=DEFAULT_WIDTH):
        self.width = width
        self.lines = []

    def write_line(self, line=""):
        self.lines.append(line)

    def write_paragraph(self, text):
        if text:
            self.lines.append(wrap_text(text, self.width, preserve_paragraphs=True))
            self.lines.append("")

    def write_section(self, heading, rows):
        if not rows:
            return
        self.lines.append(heading + ":")
        self.lines.extend(format_dl(rows, self.width))
        self.lines.append("")

    def getvalue(self):
        text = "\n".join(self.lines)
        while text.endswith("\n\n"):
            text = text[:-1]
        return text.rstrip("\n") + "\n"
