"""Declaration decorators and callback-argument helpers."""

import functools
import importlib.metadata
import sys

from . import _state, termui
from .core import Argument, Command, Group, Option, _show_help
from .exceptions import Abort


def _pop_params(f):
    """Take the declarations attached to a function; they belong to the new command."""
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    del f.__optlyn_params__
    params.reverse()
    return params


def _attach_param(f, param):
    if isinstance(f, Command):
        f.params.append(param)
        return
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _default_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Turn a function into a command."""
    if cls is None:
        cls = Command
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f):
        cmd_name = name if name is not None else _default_name(f)
        attrs.setdefault("help", f.__doc__)
        params = _pop_params(f)
        return cls(cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group."""
    if cls is None:
        cls = Group
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f):
        grp_name = name if name is not None else _default_name(f)
        attrs.setdefault("help", f.__doc__)
        params = _pop_params(f)
        return cls(grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function (or command) below it."""
    if cls is None:
        cls = Option

    def decorator(f):
        _attach_param(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function (or command) below it."""
    if cls is None:
        cls = Argument

    def decorator(f):
        _attach_param(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    mapping = importlib.metadata.packages_distributions()
    for dist in mapping.get(package_name, []):
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """An eager version flag printing a version identity and exiting."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        module = sys._getframe(1).f_globals.get("__name__", "")
        package_name = module.partition(".")[0] or None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name
        ver = version if version is not None else _detect_version(package_name)
        template = message or "%(prog)s, version %(version)s"
        termui.echo(template % {"prog": prog, "package": package_name, "version": ver},
                    color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(version_callback, *param_decls, **kwargs):
    """An eager version flag whose identity is the string returned by ``version_callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        termui.echo(version_callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag; when omitted the user is asked, and a refusal aborts."""
    if not param_decls:
        param_decls = ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value and not ctx.resilient_parsing:
            if not termui.confirm(question, default=False):
                raise Abort()
        return value

    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def pass_context(f):
    """Pass the current Context as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_state.get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_state.get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator passing the nearest object of ``object_type``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = _state.get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def get_current_context(silent=False):
    return _state.get_current_context(silent=silent)

