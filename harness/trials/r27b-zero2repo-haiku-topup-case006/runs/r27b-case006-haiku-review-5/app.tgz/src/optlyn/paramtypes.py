"""Parameter types: conversion of command-line tokens into Python values."""

import datetime as _dt
import enum
import os
import pathlib
import stat
import uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return None

    def metavar_text(self, param=None):
        return self.get_metavar(param) or self.name.upper()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class Choice(ParamType):
    """A closed list of values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.is_enum = True
            self.choices = list(choices)
        else:
            self.is_enum = False
            self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _token(self, choice):
        if self.is_enum:
            return choice.name
        return str(choice)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def _norm(self, text, ctx):
        if ctx is not None and getattr(ctx, "token_normalize_func", None) is not None:
            text = ctx.token_normalize_func(text)
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if value is choice:
                return choice
        if not isinstance(value, str):
            self.fail(f"{value!r} is not one of {self._listing()}.", param, ctx)
        wanted = self._norm(value, ctx)
        for choice in self.choices:
            if self._norm(self._token(choice), ctx) == wanted:
                return choice
        self.fail(f"{value!r} is not one of {self._listing()}.", param, ctx)

    def _listing(self):
        return ", ".join(repr(self._token(c)) for c in self.choices)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for choice in self.choices:
            token = self._token(choice)
            a, b = (token, incomplete) if self.case_sensitive else (token.casefold(), incomplete.casefold())
            if a.startswith(b):
                out.append(token)
        return out


DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the format{'s' if len(self.formats) != 1 else ''} "
            + ", ".join(repr(f) for f in self.formats) + ".",
            param,
            ctx,
        )


def _range_text(lo, hi, lo_open, hi_open):
    lo_s = "" if lo is None else f"{lo}{'<' if lo_open else '<='}"
    hi_s = "" if hi is None else f"{'<' if hi_open else '<='}{hi}"
    return f"{lo_s}x{hi_s}"


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        return None

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None:
            below = v <= self.min if self.min_open else v < self.min
            if below:
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self.fail(f"{v} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        if self.max is not None:
            above = v >= self.max if self.max_open else v > self.max
            if above:
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self.fail(f"{v} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        return v


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise TypeError("Clamping is not supported when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None:
            below = v <= self.min if self.min_open else v < self.min
            if below:
                if self.clamp:
                    return float(self.min)
                self.fail(f"{v} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        if self.max is not None:
            above = v >= self.max if self.max_open else v > self.max
            if above:
                if self.clamp:
                    return float(self.max)
                self.fail(f"{v} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        return v


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.metavar_text(param) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (list, tuple)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        from .utils import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except Exception as e:
            from .exceptions import FileError

            if isinstance(e, FileError):
                self.fail(f"Could not open file '{_fname(value)}': {e.hint}", param, ctx)
            raise
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return _PathRequest("file", incomplete)


def _fname(value):
    from .utils import format_filename

    return format_filename(value)


class _PathRequest:
    """Marker returned by path-like types asking the shell for path completion."""

    def __init__(self, kind, incomplete):
        self.kind = kind
        self.incomplete = incomplete


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _to_type(self, value):
        if self.path_type is None or self.path_type is str:
            return value
        if self.path_type is pathlib.Path:
            return pathlib.Path(value)
        return self.path_type(value)

    def convert(self, value, param=None, ctx=None):
        from .utils import format_filename

        if hasattr(value, "__fspath__"):
            value = os.fspath(value)
        if self.allow_dash and value == "-":
            return self._to_type("-")
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(value)
        shown = format_filename(value)
        try:
            st = os.stat(rv)
        except OSError:
            st = None
        if st is None:
            if self.exists:
                self.fail(f'"{shown}" does not exist.', param, ctx)
            return self._to_type(rv)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f'"{shown}" is a file.', param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f'"{shown}" is a directory.', param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f'"{shown}" is not readable.', param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f'"{shown}" is not writable.', param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f'"{shown}" is not executable.', param, ctx)
        return self._to_type(rv)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return _PathRequest(kind, incomplete)


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that raises ValueError to refuse."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


_BUILTIN_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    uuid.UUID: UUID,
}


def convert_type(ty, default=None):
    """Turn an author-supplied type (or a default's type) into a ParamType."""
    if ty is None:
        probe = default
        if isinstance(probe, (list, tuple)):
            probe = probe[0] if probe else None
        if isinstance(probe, bool):
            return BOOL
        if isinstance(probe, int):
            return INT
        if isinstance(probe, float):
            return FLOAT
        if isinstance(probe, uuid.UUID):
            return UUID
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, type) and ty in _BUILTIN_MAP:
        return _BUILTIN_MAP[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
