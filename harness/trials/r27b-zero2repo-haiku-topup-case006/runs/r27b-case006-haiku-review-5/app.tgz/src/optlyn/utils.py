"""File opening, filename formatting and per-user application directories."""

import os
import re
import sys
import tempfile

from .exceptions import FileError

_WRITE_MODES = ("w", "a", "x", "+")


def _is_write(mode):
    return any(c in mode for c in _WRITE_MODES)


def format_filename(filename, shorten=False):
    """Return printable text for a path (str, bytes or path-like)."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, str):
        raw = os.fsencode(filename)
    else:
        raw = bytes(filename)
    if shorten:
        raw = os.path.basename(raw)
    return raw.decode("utf-8", "backslashreplace")


class _StdStream:
    """Wraps a standard stream; closing it does not close the process stream."""

    def __init__(self, stream, encoding=None, errors="strict", binary=False):
        self._stream = stream
        self._encoding = encoding
        self._errors = errors
        self._binary = binary

    @property
    def name(self):
        return getattr(self._stream, "name", "<std>")

    def write(self, data):
        if self._binary:
            return self._stream.write(data)
        if self._encoding is not None and isinstance(data, str):
            buf = getattr(self._stream, "buffer", None)
            if buf is not None:
                self._stream.flush()
                buf.write(data.encode(self._encoding, self._errors))
                buf.flush()
                return len(data)
        return self._stream.write(data)

    def read(self, size=-1):
        if self._binary or self._encoding is None:
            return self._stream.read(size)
        buf = getattr(self._stream, "buffer", None)
        if buf is None:
            return self._stream.read(size)
        return buf.read(size).decode(self._encoding, self._errors)

    def readline(self, size=-1):
        if self._binary or self._encoding is None:
            return self._stream.readline(size)
        buf = getattr(self._stream, "buffer", None)
        if buf is None:
            return self._stream.readline(size)
        return buf.readline(size).decode(self._encoding, self._errors)

    def __iter__(self):
        return iter(self._stream)

    def flush(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def close(self):
        self.flush()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _open_std(filename, mode, encoding, errors):
    reading = not _is_write(mode)
    stream = sys.stdin if reading else sys.stdout
    binary = "b" in mode
    if binary:
        stream = getattr(stream, "buffer", stream)
        return _StdStream(stream, binary=True)
    return _StdStream(stream, encoding=encoding, errors=errors)


class AtomicFile:
    """Writes to a sibling temporary file; replaces the target on close."""

    def __init__(self, filename, mode, encoding=None, errors="strict"):
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-")
        binary = "b" in mode
        self._f = os.fdopen(
            fd,
            "wb" if binary else "w",
            **({} if binary else {"encoding": encoding, "errors": errors}),
        )
        self._closed = False

    def __getattr__(self, name):
        return getattr(self.__dict__["_f"], name)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def _open_real(filename, mode, encoding, errors, atomic):
    if atomic and _is_write(mode):
        return AtomicFile(filename, mode, encoding, errors)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class LazyFile:
    """Opens the real file on first I/O; a write target is not truncated earlier."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        object.__setattr__(self, "_args", (filename, mode, encoding, errors, atomic))
        object.__setattr__(self, "_f", None)
        object.__setattr__(self, "name", filename)

    def _ensure(self):
        if self._f is None:
            filename, mode, encoding, errors, atomic = self._args
            try:
                f = _open_real(filename, mode, encoding, errors, atomic)
            except OSError as e:
                raise FileError(filename, e.strerror or str(e)) from e
            object.__setattr__(self, "_f", f)
        return self._f

    def __getattr__(self, name):
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def close(self):
        if self._f is not None:
            self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when filename is ``-``."""
    if filename == "-":
        return _open_std(filename, mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as e:
        raise FileError(filename, e.strerror or str(e)) from e


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for an application."""
    home = os.path.expanduser("~")
    if force_posix:
        folder = re.sub(r"\s+", "-", app_name.lower())
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA")
        if base is None:
            base = os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    config = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config, folder)


