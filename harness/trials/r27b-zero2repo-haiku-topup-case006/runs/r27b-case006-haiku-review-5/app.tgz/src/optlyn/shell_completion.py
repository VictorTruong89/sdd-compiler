"""Shell completion: registration scripts and suggestion output."""

import os
import re
import sys

from .core import Argument, Context, Group, Option
from .paramtypes import _PathRequest

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_MARK = "__optlyn_path_{kind}__"


def complete_variable(prog_name):
    return "_" + re.sub(r"[^0-9A-Za-z]", "_", prog_name).upper() + "_COMPLETE"


def _source_script(shell, prog, var):
    fn = "_" + re.sub(r"[^0-9A-Za-z]", "_", prog) + "_completion"
    if shell == "bash":
        return (
            f"{fn}() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    local line\n"
            f"    COMPREPLY=()\n"
            f"    for line in $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog}); do\n"
            f"        case \"$line\" in\n"
            f"            {PATH_MARK.format(kind='dir')}*) COMPREPLY+=( $(compgen -d -- \"${{COMP_WORDS[COMP_CWORD]}}\") ) ;;\n"
            f"            {PATH_MARK.format(kind='file')}*) COMPREPLY+=( $(compgen -f -- \"${{COMP_WORDS[COMP_CWORD]}}\") ) ;;\n"
            f"            *) COMPREPLY+=( \"${{line%%$'\\t'*}}\" ) ;;\n"
            f"        esac\n"
            f"    done\n"
            f"}}\n"
            f"complete -o default -F {fn} {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"{fn}() {{\n"
            f"    local -a items\n"
            f"    items=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})}}\")\n"
            f"    _describe 'values' items\n"
            f"}}\n"
            f"compdef {fn} {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $words = $commandAst.ToString()\n"
        f"    $env:COMP_WORDS = $words\n"
        f"    $env:COMP_CWORD = $words.Split(' ').Count - 1\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{\n"
        f"        $value = $_.Split(\"`t\")[0]\n"
        f"        [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)\n"
        f"    }}\n"
        f"    Remove-Item Env:{var} -ErrorAction SilentlyContinue\n"
        f"}}\n"
    )


def _find_option(cmd, ctx, name):
    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and (name in p.opts or name in p.secondary_opts):
            return p
    return None


def _normalize_items(raw, incomplete):
    items = []
    if isinstance(raw, _PathRequest):
        return [(raw.incomplete, None, raw.kind)]
    for r in raw or []:
        if isinstance(r, _PathRequest):
            return [(r.incomplete, None, r.kind)]
        if isinstance(r, str):
            items.append((r, None, "plain"))
        else:
            items.append((r.value, getattr(r, "help", None), getattr(r, "type", "plain") or "plain"))
    return items


def _param_items(param, ctx, incomplete):
    if param.shell_complete_func is not None:
        raw = param.shell_complete_func(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    return _normalize_items(raw, incomplete)


def _collect(root, prog, args, incomplete):
    cmd = root
    ctx = Context(root, info_name=prog)
    positional = []
    pending = None
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        if pending is not None:
            pending = None
            continue
        if tok == "--":
            positional.extend(args[i:])
            break
        if tok.startswith("-") and len(tok) > 1:
            name = tok.split("=", 1)[0]
            opt = _find_option(cmd, ctx, name)
            if opt is not None and "=" not in tok and not (opt.is_flag or opt.count or opt.optional_value):
                pending = opt
            continue
        if isinstance(cmd, Group):
            child = cmd.get_command(ctx, tok)
            if child is not None:
                ctx = Context(child, info_name=tok, parent=ctx)
                cmd = child
                positional = []
                continue
        positional.append(tok)
    if pending is not None:
        return _param_items(pending, ctx, incomplete)
    params = cmd.get_params(ctx)
    if incomplete.startswith("-"):
        out = []
        for p in params:
            if isinstance(p, Option) and not p.hidden:
                for name in p.opts + p.secondary_opts:
                    if name.startswith(incomplete):
                        out.append((name, p.help, "plain"))
        return out
    if isinstance(cmd, Group):
        out = []
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            out.append((name, child.get_short_help_str(), "plain"))
        return out
    arguments = [p for p in params if isinstance(p, Argument)]
    idx = len(positional)
    target = None
    if idx < len(arguments):
        target = arguments[idx]
    elif arguments and arguments[-1].nargs == -1:
        target = arguments[-1]
    if target is None:
        return []
    return _param_items(target, ctx, incomplete)


def _format_item(shell, item):
    value, help_text, kind = item
    if kind in ("file", "dir"):
        return PATH_MARK.format(kind=kind) + "\t" + value
    if help_text and shell in ("zsh", "fish"):
        return f"{value}\t{help_text}"
    return value


def run_completion(cmd, prog_name, instruction, args, standalone_mode, complete_var=None):
    """Handle a completion instruction. Returns None (non-standalone) or exits."""
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        if standalone_mode:
            sys.exit(1)
        return None
    var = complete_var or complete_variable(prog_name)
    if mode == "source":
        sys.stdout.write(_source_script(shell, prog_name, var))
        sys.stdout.flush()
    else:
        words = os.environ.get("COMP_WORDS", "").split()
        cword_raw = os.environ.get("COMP_CWORD", "")
        if shell == "fish":
            incomplete = cword_raw
            complete_args = words[1:]
        else:
            try:
                cword = int(cword_raw)
            except ValueError:
                cword = len(words)
            complete_args = words[1:cword]
            incomplete = words[cword] if 0 <= cword < len(words) else ""
        for item in _collect(cmd, prog_name, complete_args, incomplete):
            sys.stdout.write(_format_item(shell, item) + "\n")
        sys.stdout.flush()
    if standalone_mode:
        sys.exit(0)
    return None
