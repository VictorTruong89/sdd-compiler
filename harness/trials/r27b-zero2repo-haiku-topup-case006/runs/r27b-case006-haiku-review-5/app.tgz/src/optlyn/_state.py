"""Per-thread stack of current invocation contexts, and runner bookkeeping."""

import threading

_local = threading.local()

# Depth of nested in-process runner invocations (changes terminal behaviour).
runner_depth = 0


def _stack():
    st = getattr(_local, "stack", None)
    if st is None:
        st = []
        _local.stack = st
    return st


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


def get_current_context(silent=False):
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
