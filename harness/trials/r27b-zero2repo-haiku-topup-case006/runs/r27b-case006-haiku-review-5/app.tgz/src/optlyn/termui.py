"""Terminal helpers: echo, styling, prompts, pager, progress, editor and launch."""

import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from ._state import get_current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLOR_NAMES = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"]
_SWITCHES = [
    ("bold", 1),
    ("dim", 2),
    ("italic", 3),
    ("underline", 4),
    ("blink", 5),
    ("reverse", 7),
    ("strikethrough", 9),
    ("overline", 53),
]


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _stdin_echoes(stream):
    return bool(getattr(stream, "_optlyn_echo_stdin", False))


def unstyle(text):
    """Remove ANSI escape sequences, leaving other text unchanged."""
    return _ANSI_RE.sub("", text)


def _color_code(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        bright = color.startswith("bright_")
        name = color[len("bright_"):] if bright else color
        if name not in _COLOR_NAMES:
            raise ValueError(f"Unknown color {color!r}.")
        code = base + _COLOR_NAMES.index(name) + (60 if bright else 0)
        return str(code)
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{48 if background else 38};5;{color}"
        raise ValueError(f"Color {color!r} out of range 0-255.")
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            r, g, b = color
            return f"{48 if background else 38};2;{r};{g};{b}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap text in ANSI SGR sequences."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    flags = {
        "bold": bold,
        "dim": dim,
        "italic": italic,
        "underline": underline,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
        "overline": overline,
    }
    for name, code in _SWITCHES:
        if flags[name]:
            codes.append(str(code))
    text = str(text)
    if codes:
        text = f"\x1b[{';'.join(codes)}m{text}"
    if reset:
        text += "\x1b[0m"
    return text


def _should_strip(stream, color):
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def _write_text(file, text):
    enc = getattr(file, "encoding", None) or ""
    buf = getattr(file, "buffer", None)
    if "ascii" in enc.lower() and buf is not None:
        file.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        if buf is None:
            raise
        file.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text (or bytes) to standard output, or standard error when err is set."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
        return
    text = str(message) + ("\n" if nl else "")
    if _should_strip(file, color):
        text = unstyle(text)
    _write_text(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- input


def _read_line(hide_input=False):
    stream = sys.stdin
    if hide_input and _is_tty(stream):
        try:
            import termios

            fd = stream.fileno()
            old = termios.tcgetattr(fd)
            new = old[:]
            new[3] &= ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSADRAIN, new)
            try:
                line = stream.readline()
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
                echo()
        except (ImportError, OSError, AttributeError, ValueError):
            line = stream.readline()
    else:
        line = stream.readline()
    if line == "":
        raise EOFError()
    return line.rstrip("\r\n")


def _prompt_input(text, hide_input=False, err=False):
    echo(text, nl=False, err=err, color=True if not hide_input else None)
    try:
        line = _read_line(hide_input)
    except EOFError:
        echo("", err=err)
        raise
    if not _is_tty(sys.stdin):
        if hide_input:
            echo("", err=err)
        elif not _stdin_echoes(sys.stdin):
            echo(line, err=err)
    return line


def _default_text(default):
    if isinstance(default, bool):
        return str(default)
    if isinstance(default, (list, tuple)):
        return ", ".join(str(d) for d in default)
    return str(default)


def prompt_value(text, default, hide_input, confirmation, convert, show_default=True, err=False):
    """Ask until a value converts. ``convert`` gets the raw string (or the raw default)."""
    shown = f"{text} [{_default_text(default)}]" if (default is not None and show_default and not hide_input) else text
    while True:
        if confirmation:
            first = _prompt_input(f"{shown}: ", hide_input, err)
            second = _prompt_input("Repeat for confirmation: ", hide_input, err)
            if first != second:
                echo("Error: The two entered values do not match.", err=True)
                continue
            raw = first
        else:
            raw = _prompt_input(f"{shown}: ", hide_input, err)
        if raw == "":
            if default is None:
                continue
            raw = default
            try:
                return convert(raw)
            except BadParameter as e:
                echo(f"Error: {e.message}", err=True)
                continue
        try:
            return convert(raw)
        except BadParameter as e:
            echo("Error: " + e.format_message(), err=True)
            continue


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Standalone prompt returning a converted value."""
    from .paramtypes import convert_type

    ty = convert_type(type, default)

    def convert(raw):
        if not isinstance(raw, str):
            return raw
        value = ty.convert(raw, None, None)
        if value_proc is not None:
            value = value_proc(value)
        return value

    try:
        return prompt_value(text, default, hide_input, confirmation_prompt, convert,
                            show_default, err)
    except EOFError as e:
        raise Abort() from e


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a bool."""
    if default is True:
        suffix = " [Y/n]"
    elif default is False:
        suffix = " [y/N]"
    else:
        suffix = " [y/n]"
    while True:
        try:
            raw = _prompt_input(f"{text}{suffix}{prompt_suffix}", False, err)
        except EOFError as e:
            raise Abort() from e
        raw = raw.strip().lower()
        if raw == "":
            if default is None:
                continue
            value = default
            break
        if raw in ("y", "yes"):
            value = True
            break
        if raw in ("n", "no"):
            value = False
            break
        echo("Error: invalid input", err=True)
    if abort and not value:
        raise Abort()
    return value


def getchar(echo=False):
    """Read one character; interrupt and end-of-file keys raise."""
    from . import _state

    ch = ""
    if _state.runner_depth == 0 and not _is_tty(sys.stdin):
        ch = _getchar_from_tty()
    if not ch:
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        globals()["echo"](ch, nl=False)
    return ch


def _getchar_from_tty():
    try:
        import termios
        import tty
    except ImportError:
        return ""
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        return ""
    try:
        if not os.isatty(fd):
            return ""
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except (OSError, termios.error):
        return ""
    finally:
        os.close(fd)


def _interactive():
    return _is_tty(sys.stdin)


def pause(info=None, err=False):
    """Print a message and wait for a key when the session is interactive."""
    if not _interactive():
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear():
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[1;1H")
        sys.stdout.flush()


# ---------------------------------------------------------------- pager


class _PlainWriter:
    """Writes to the standard output, stripping styles when it is not a terminal."""

    def __init__(self, color):
        self._color = color

    def write(self, text):
        echo(text, nl=False, color=self._color)

    def flush(self):
        try:
            sys.stdout.flush()
        except Exception:
            pass


@contextlib.contextmanager
def get_pager_file(color=None):
    if not _interactive():
        yield _PlainWriter(color)
        return
    pager = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    writer = _PagerWriter(proc.stdin, color)
    try:
        yield writer
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


class _PagerWriter:
    def __init__(self, pipe, color):
        self._pipe = pipe
        self._color = color

    def write(self, text):
        if not self._color:
            text = unstyle(text)
        self._pipe.write(text.encode("utf-8"))

    def flush(self):
        try:
            self._pipe.flush()
        except OSError:
            pass


def echo_via_pager(text_or_generator, color=None):
    text = text_or_generator
    if callable(text):
        text = text()
    chunks = [text] if isinstance(text, str) else text
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(chunk)
            f.flush()


# ---------------------------------------------------------------- progress


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.show = (not hidden) and _is_tty(sys.stdout)
        if not hidden and not self.show and self.label:
            echo(self.label)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if self.show:
            echo("")

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        if self.show and self.length is None:
            self.render_progress()

    def update(self, n_steps):
        self.pos += n_steps
        if self.show:
            self.render_progress()

    def _eta(self):
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f"  ETA: {int(remaining)}s"

    def render_progress(self):
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            line = f"\r{self.label}  [{bar}]  {self.pos}/{self.length}{self._eta()}"
        else:
            line = f"\r{self.label}  {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- editor / launch


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    default_editor = "notepad" if sys.platform.startswith("win") else "vi"
    cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or default_editor
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(cmd) + [os.fspath(filename)], env=run_env)
        return None
    original = "" if text is None else str(text)
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(original.encode("utf-8"))
        subprocess.call(shlex.split(cmd) + [path], env=run_env)
        with open(path, "rb") as f:
            result = f.read().decode("utf-8")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


def launch(url, wait=False, locate=False):
    if sys.platform == "darwin":
        cmd = ["open"] + (["-R"] if locate else []) + [url]
    elif sys.platform.startswith("win"):
        try:
            os.startfile(url)  # type: ignore[attr-defined]
            return 0
        except OSError:
            return 1
    else:
        target = os.path.dirname(url) if locate else url
        cmd = ["xdg-open", target]
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0
