"""Exception classes and their standalone-mode presentation."""


class OptlynError(Exception):
    """Base for library-signalled errors that are not usage errors (exit 1)."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self):
        from .termui import echo

        echo("Error: " + self.format_message(), err=True)


class UsageError(OptlynError):
    """Incorrect invocation (exit 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self):
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            names = self.ctx.help_option_names
            if names:
                echo(
                    f"Try '{self.ctx.command_path} {names[0]}' for help.",
                    err=True,
                )
            echo("", err=True)
        echo("Error: " + self.format_message(), err=True)


def _param_hint(param):
    if param is None:
        return None
    return param.get_error_hint()


class BadParameter(UsageError):
    """A value was refused (conversion failure or parameter callback)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint or _param_hint(self.param)
        if hint is None:
            return self.message
        return f"Invalid value for '{hint}': {self.message}"


class MissingParameter(UsageError):
    """A required parameter was not supplied from any source."""

    def __init__(self, ctx=None, param=None):
        super().__init__("", ctx)
        self.param = param

    def format_message(self):
        kind = self.param.param_kind
        return f"Missing {kind} '{_param_hint(self.param)}'."


class NoSuchOption(UsageError):
    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    pass


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    def __init__(self, filename, hint):
        from .utils import format_filename

        self.filename = filename
        self.hint = hint
        super().__init__(f"Could not open file '{format_filename(filename)}': {hint}")


class Abort(RuntimeError):
    """User or author abort; standalone exit 1 with an abort indication."""


class Exit(RuntimeError):
    """Author clean stop, or intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
