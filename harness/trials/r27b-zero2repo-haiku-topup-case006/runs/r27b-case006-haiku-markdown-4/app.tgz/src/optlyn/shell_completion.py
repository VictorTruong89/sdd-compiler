"""Shell completion: registration scripts and suggestions.

Completion mode is selected by the environment variable named after the
program (``_<PROG>_COMPLETE``). Its value is ``<shell>_source`` to print the
registration script, or ``<shell>_complete`` to print suggestions.

Suggestion stream framing (implementer's choice, documented in NOTES.md):

* a plain value is printed verbatim on its own line; for zsh and fish a
  help string follows after a tab;
* a path request is printed as ``\\x1ffile\\x1f<incomplete>`` (any path) or
  ``\\x1fdir\\x1f<incomplete>`` (directories only).
"""

import os
import sys

from . import core
from .param_types import CompletionItem
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
_FILE_MARK = "\x1ffile\x1f"
_DIR_MARK = "\x1fdir\x1f"


def run_completion(cli, prog_name, complete_var, instruction, args, standalone_mode):
    """Handle a completion request. Never runs the command callback."""
    instruction = instruction.strip()
    shell, _, mode = instruction.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        # Not a successful source or complete run: print nothing on stdout.
        echo(f"Error: unrecognized completion instruction {instruction!r}.", err=True)
        if standalone_mode:
            sys.exit(1)
        return None

    if mode == "source":
        echo(source_script(shell, prog_name, complete_var))
    else:
        words = os.environ.get("COMP_WORDS", "")
        tokens = words.split(" ")
        if shell == "fish":
            incomplete = os.environ.get("COMP_CWORD", "")
            if tokens and tokens[-1] == incomplete:
                tokens = tokens[:-1]
        else:
            try:
                index = int(os.environ.get("COMP_CWORD", str(len(tokens) - 1)))
            except ValueError:
                index = len(tokens) - 1
            incomplete = tokens[index] if 0 <= index < len(tokens) else ""
            tokens = tokens[:index]
        command_args = tokens[1:]
        items = get_suggestions(cli, prog_name, command_args, incomplete)
        for item in items:
            echo(_format_item(shell, item))

    if standalone_mode:
        sys.exit(0)
    return None


def _format_item(shell, item):
    if item.type == "file":
        return _FILE_MARK + item.value
    if item.type == "dir":
        return _DIR_MARK + item.value
    if item.help and shell in ("zsh", "fish"):
        return f"{item.value}\t{item.help}"
    return item.value


def _as_items(values):
    out = []
    for v in values or []:
        if isinstance(v, CompletionItem):
            out.append(v)
        elif isinstance(v, str):
            out.append(CompletionItem(v))
        else:
            out.append(CompletionItem(getattr(v, "value"), getattr(v, "help", None),
                                      getattr(v, "type", "plain") or "plain"))
    return out


def _takes_value(cmd, token):
    """Return the option taking a value for ``token`` when ``token`` is one."""
    if not token.startswith("-") or "=" in token:
        return None
    for p in cmd.params:
        if isinstance(p, core.Option) and token in p.opts + p.secondary_opts and p.takes_value:
            return p
    return None


def get_suggestions(cli, prog_name, args, incomplete):
    """Compute completion items for ``incomplete`` after ``args``."""
    ctx = core.Context(cli, info_name=prog_name)
    cmd = cli
    cur_ctx = ctx
    positional_seen = 0
    pending_option = None
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        opt = _takes_value(cmd, tok)
        if opt is not None:
            if i < len(args):
                i += 1  # its value is the next token
            else:
                pending_option = opt  # the incomplete token is its value
            continue
        if tok.startswith("-") or tok == "--":
            continue
        if isinstance(cmd, core.Group) and positional_seen == 0:
            sub = cmd.get_command(cur_ctx, tok)
            if sub is not None:
                cur_ctx = core.Context(sub, info_name=tok, parent=cur_ctx)
                cmd = sub
                continue
        positional_seen += 1

    if pending_option is not None:
        return _as_items(pending_option.shell_complete(cur_ctx, incomplete))

    if incomplete.startswith("-"):
        items = []
        for p in cmd.get_params(cur_ctx):
            if not isinstance(p, core.Option) or p.hidden:
                continue
            for name in p.opts + p.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, p.help))
        return items

    if isinstance(cmd, core.Group):
        items = []
        for name in cmd.list_commands(cur_ctx):
            sub = cmd.get_command(cur_ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, sub.get_short_help_str(45)))
        return items

    # A leaf command: the next positional argument may offer values.
    arguments = [p for p in cmd.params if isinstance(p, core.Argument)]
    if positional_seen < len(arguments):
        return _as_items(arguments[positional_seen].shell_complete(cur_ctx, incomplete))
    return []


_BASH = """\
_{func}() {{
    local IFS=$'\\n'
    local response line
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete $1)
    COMPREPLY=()
    for line in $response; do
        case "$line" in
            $'\\x1ffile\\x1f'*) COMPREPLY+=( $(compgen -f -- "${{line#$'\\x1ffile\\x1f'}}") ) ;;
            $'\\x1fdir\\x1f'*) COMPREPLY+=( $(compgen -d -- "${{line#$'\\x1fdir\\x1f'}}") ) ;;
            *) COMPREPLY+=( "$line" ) ;;
        esac
    done
    return 0
}}
complete -o default -F _{func} {prog}
"""

_ZSH = """\
#compdef {prog}
_{func}() {{
    local -a lines vals
    local line
    lines=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}")
    for line in "${{lines[@]}}"; do
        case "$line" in
            $'\\x1ffile\\x1f'*) _files ;;
            $'\\x1fdir\\x1f'*) _files -/ ;;
            *) vals+=("${{line//:/\\\\:}}") ;;
        esac
    done
    (( ${{#vals}} )) && _describe 'value' vals
}}
compdef _{func} {prog}
"""

_FISH = """\
complete -c {prog} -f -a "(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog})"
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:{var} = 'powershell_complete'
    & {prog} | ForEach-Object {{
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }}
    Remove-Item Env:{var}
}}
"""


def source_script(shell, prog_name, complete_var):
    """Return the registration script for ``shell``."""
    func = "".join(ch if ch.isalnum() else "_" for ch in prog_name)
    template = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}[shell]
    return template.format(func=func, var=complete_var, prog=prog_name).rstrip("\n")
