"""Text wrapping and two-column layout used by help pages."""

import re
import textwrap

_PARA_SPLIT = re.compile(r"\n\s*\n")


def _wrap_paragraph(para, width, initial_indent, subsequent_indent):
    lines = para.split("\n")
    # A paragraph whose first line is only a backspace is not rewrapped.
    if lines and lines[0].strip(" \t") == "\b":
        body = [line for line in lines[1:]]
        out = []
        for i, line in enumerate(body):
            indent = initial_indent if i == 0 else subsequent_indent
            out.append(indent + line.rstrip())
        return "\n".join(out)
    text = " ".join(para.split())
    if not text:
        return ""
    return textwrap.fill(
        text,
        width=max(int(width), 1),
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=True,
        break_on_hyphens=False,
    )


def wrap_text(text, width=100, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Always returns a string."""
    text = "" if text is None else str(text)
    if preserve_paragraphs:
        paras = [p for p in _PARA_SPLIT.split(text.strip("\n"))]
        rendered = []
        for i, para in enumerate(paras):
            ii = initial_indent if i == 0 else subsequent_indent
            rendered.append(_wrap_paragraph(para, width, ii, subsequent_indent))
        return "\n\n".join(r for r in rendered if r != "")
    return _wrap_paragraph(text, width, initial_indent, subsequent_indent)


def write_rows(rows, width, col_max=30, indent=2):
    """Render ``(first, second)`` rows as an aligned two-column block."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    text_width = max(width - indent - first_width - 2, 10)
    pad = " " * (indent + first_width + 2)
    out = []
    for first, second in rows:
        lines = wrap_text(second, width=text_width).splitlines() if second else []
        lead = " " * indent
        if not lines:
            out.append(lead + first)
            continue
        if len(first) > first_width:
            out.append(lead + first)
            out.extend(pad + line for line in lines)
        else:
            out.append(lead + first.ljust(first_width) + "  " + lines[0])
            out.extend(pad + line for line in lines[1:])
    return out
