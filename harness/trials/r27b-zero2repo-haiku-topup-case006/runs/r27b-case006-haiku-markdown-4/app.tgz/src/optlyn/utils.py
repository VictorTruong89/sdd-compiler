"""Shared helpers: the per-thread context stack, streams, files, app dirs."""

import io
import os
import sys
import tempfile
import threading

from .exceptions import FileError

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    stack = _stack()
    if stack:
        stack.pop()


def get_current_context(silent=False):
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true,
    in which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def is_tty(stream):
    try:
        return stream is not None and bool(stream.isatty())
    except Exception:
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return is_tty(sys.stdin) or is_tty(sys.stdout)


class KeepOpenFile:
    """Wraps a standard stream. Closing it does not close the stream."""

    def __init__(self, stream, owned_wrapper=None):
        self._stream = stream
        self._owned = owned_wrapper

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def __del__(self):
        owned = self.__dict__.get("_owned")
        if owned is not None:
            try:
                owned.detach()
            except Exception:
                pass


def _open_real(name, mode, encoding, errors, atomic):
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    if atomic and ("w" in mode or "a" in mode):
        directory = os.path.dirname(os.path.abspath(name))
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        return os.fdopen(fd, mode, **kwargs), tmp
    return open(name, mode, **kwargs), None


class LazyFile:
    """A file that opens on first use, or immediately when requested.

    With ``atomic`` the data is written to a sibling temporary file that
    replaces the target when the file is closed.
    """

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename) if not isinstance(filename, bytes) else filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None

    def _open(self, lazy_trigger=False):
        if self._f is None:
            try:
                self._f, self._tmp = _open_real(
                    self.name, self.mode, self.encoding, self.errors, self.atomic
                )
            except OSError as e:
                if lazy_trigger:
                    raise FileError(self.name, e.strerror or str(e)) from e
                raise
        return self._f

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._open(lazy_trigger=True), name)

    def __iter__(self):
        return iter(self._open(lazy_trigger=True))

    def __next__(self):
        return next(self._open(lazy_trigger=True))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    @property
    def closed(self):
        return self._f is None or self._f.closed

    def close(self):
        if self._f is None or self._f.closed:
            return
        self._f.close()
        if self._tmp is not None:
            os.replace(self._tmp, self.name)
            self._tmp = None


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for the name ``-``.

    Reading opens immediately by default. ``lazy=True`` defers the open
    until the first I/O.
    """
    if isinstance(filename, str) and filename == "-":
        if "w" in mode or "a" in mode:
            stream = sys.stdout
        else:
            stream = sys.stdin
        if "b" in mode:
            return KeepOpenFile(getattr(stream, "buffer", stream))
        if encoding:
            wrapper = io.TextIOWrapper(
                getattr(stream, "buffer", stream), encoding=encoding, errors=errors
            )
            return KeepOpenFile(wrapper, owned_wrapper=wrapper)
        return KeepOpenFile(stream)

    lf = LazyFile(filename, mode, encoding, errors, atomic)
    if not lazy:
        lf._open()
    return lf


def format_filename(filename, shorten=False):
    """Return printable text for a file name (bytes, str or path-like)."""
    if isinstance(filename, (bytes, bytearray)):
        text = os.fsdecode(bytes(filename))
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    # Undecodable bytes arrive as lone surrogates; render them as escapes so
    # the result encodes as strict UTF-8.
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    if not force_posix and sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if not force_posix and sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    unix_name = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + unix_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, unix_name)
