"""Core model: invocation context, parameters, commands and groups."""

import enum
import os
import re
import shutil
import sys
from contextlib import ExitStack, contextmanager

from . import param_types as pt
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import wrap_text, write_rows

from .termui import echo, prompt as _prompt
from .utils import pop_context, push_context


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _Marker:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"<{self.name}>"


CHAIN_MARKER = _Marker("chain")
_ARG_SEQ_BASE = 10 ** 9
_HELP_DEST = "_optlyn_help"
_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}
_PATH_TYPES = (pt.File, pt.Path)
_NEGATIVE_NUMBER = re.compile(r"-(\d+(\.\d*)?|\.\d+)")


def _is_prefix_char(ch):
    return not (ch.isalnum() or ch == "_")


def _derive_dest(opts):
    long_names = [o for o in opts if len(o) > 1 and o[1] == o[0]]
    pick = long_names[0] if long_names else opts[0]
    return re.sub(r"^[^A-Za-z0-9_]+", "", pick).replace("-", "_")


def _help_width(ctx):
    if ctx.terminal_width:
        return ctx.terminal_width
    cols = shutil.get_terminal_size((80, 24)).columns
    return max(min(cols - 2, ctx.max_content_width), 10)


def _fmt_default(value):
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------

class Context:
    """Per-invocation state: parsed values, parent linkage, settings, cleanup."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        **extra,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self._sources = {}
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.extra = extra

        def inherit(value, attr, default):
            if value is not None:
                return value
            if parent is not None and getattr(parent, attr) is not None:
                return getattr(parent, attr)
            return default

        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", 80)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", None)

        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix and info_name:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix

        if default_map is None and parent is not None and parent.default_map and info_name:
            nested = parent.default_map.get(info_name)
            if isinstance(nested, dict):
                default_map = nested
        self.default_map = default_map

        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.ignore_unknown_options = (
            ignore_unknown_options
            if ignore_unknown_options is not None
            else command.ignore_unknown_options
        )
        self.allow_interspersed_args = (
            allow_interspersed_args
            if allow_interspersed_args is not None
            else command.allow_interspersed_args
        )
        self.resilient_parsing = False
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self._close_callbacks = []
        self._exit_stack = None
        self._depth = 0

    # -- scope and cleanup ------------------------------------------------

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()

    @contextmanager
    def scope(self, cleanup=True):
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            pop_context()
            self._depth -= 1
            if cleanup and self._depth == 0:
                self.close()

    def call_on_close(self, func):
        self._close_callbacks.append(func)
        return func

    def with_resource(self, cm):
        if self._exit_stack is None:
            self._exit_stack = ExitStack()
        return self._exit_stack.enter_context(cm)

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        try:
            for func in reversed(callbacks):
                func()
        finally:
            stack, self._exit_stack = self._exit_stack, None
            if stack is not None:
                stack.close()

    # -- navigation and objects -------------------------------------------

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- values -----------------------------------------------------------

    def lookup_default(self, name):
        dm = self.default_map
        if not dm or name not in dm:
            return False, None
        return True, dm[name]

    def get_parameter_source(self, name):
        return self._sources.get(name)

    # -- help and control -------------------------------------------------

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, callback, /, *args, **kwargs):
        """Run a command or callable from inside a callback."""
        if isinstance(callback, Command):
            other = callback
            if other.callback is None:
                return None
            sub = Context(other, info_name=other.name, parent=self)
            for p in other.get_params(sub):
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.get_default(sub)
            sub.params.update(kwargs)
            with sub:
                return other.callback(*args, **kwargs)
        with self.scope(cleanup=False):
            return callback(*args, **kwargs)

    def forward(self, cmd, /, **kwargs):
        """Run ``cmd`` with this context's current parameters plus ``kwargs``."""
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, **merged)


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

class Parameter:
    """Common base for options and arguments."""

    is_argument = False

    def __init__(
        self,
        name,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        hidden=False,
        help=None,
    ):
        self.name = name
        self.required = bool(required)
        self.default = default
        self.callback = callback
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        if envvar is None:
            self.envvar = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self._explicit_default = default is not None
        if isinstance(type, pt.Tuple):
            nargs = len(type.types)
            self.type = type
        else:
            if type is None and multiple and isinstance(default, (list, tuple)) and default:
                self.type = pt.convert_type(None, default[0])
            else:
                self.type = pt.convert_type(type, default)
            if isinstance(self.type, pt.Tuple):
                nargs = len(self.type.types)
        self.nargs = nargs

    # -- hooks -------------------------------------------------------------

    def get_error_hint(self, ctx):
        return self.name

    def get_default(self, ctx):
        d = self.default
        return d() if callable(d) else d

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return list(self.shell_complete_func(ctx, self, incomplete) or [])
        return self.type.shell_complete(ctx, self, incomplete)

    def _env_names(self, ctx):
        names = list(self.envvar)
        prefix = ctx.auto_envvar_prefix if ctx is not None else None
        if prefix and getattr(self, "allow_from_autoenv", True):
            names.append(f"{prefix}_{self.name}".upper().replace("-", "_"))
        return names

    def _split_env(self, raw):
        if isinstance(self.type, _PATH_TYPES):
            return [p for p in raw.split(os.pathsep) if p != ""]
        return raw.split()

    # -- conversion --------------------------------------------------------

    def _convert_tokens(self, ctx, tokens):
        """Convert the tokens of one occurrence (scalar for unary arity)."""
        if isinstance(self.type, pt.Tuple):
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs == 1:
            return self.type.convert(tokens[0], self, ctx)
        return tuple(self.type.convert(t, self, ctx) for t in tokens)

    def _convert_item(self, ctx, item):
        """Convert one occurrence's worth of value (multiple/nargs handling)."""
        if self.nargs == 1 and not isinstance(self.type, pt.Tuple):
            return self.type.convert(item, self, ctx)
        if isinstance(item, str) or not hasattr(item, "__iter__"):
            return self._convert_tokens(ctx, (item,))
        return self._convert_tokens(ctx, tuple(item))

    def _occ_value(self, ctx, occ):
        _, kind, payload = occ
        if kind == "raw":
            return self._convert_tokens(ctx, payload)
        return payload

    def _convert_occurrences(self, ctx, occs):
        if any(kind == "count" for _, kind, _ in occs):
            return len(occs)
        if self.multiple:
            return tuple(self._occ_value(ctx, o) for o in occs)
        return self._occ_value(ctx, occs[-1])

    def _convert_default(self, ctx, raw, from_map=False):
        if raw is None:
            return None
        if self.nargs == 0 and not self.multiple:
            # Flags and counting options: the default is a plain value.
            return self.type.convert(raw, self, ctx)
        if self.multiple:
            if isinstance(raw, str) or not hasattr(raw, "__iter__"):
                raise BadOptionUsage(
                    f"The default for {self.get_error_hint(ctx)!r} needs an iterable (sequence) default.",
                    ctx=ctx,
                )
            return tuple(self._convert_item(ctx, item) for item in raw)
        if self.nargs != 1 or isinstance(self.type, pt.Tuple):
            if isinstance(raw, str):
                raw = self._split_env(raw)
            return self._convert_tokens(ctx, tuple(raw))
        return self._convert_tokens(ctx, (raw,))

    def _convert_env(self, ctx, raw):
        if self.multiple:
            parts = self._split_env(raw)
            size = max(self.nargs, 1)
            chunks = [parts[i:i + size] for i in range(0, len(parts), size)]
            return tuple(self._convert_tokens(ctx, tuple(c)) for c in chunks)
        if self.nargs != 1 or isinstance(self.type, pt.Tuple):
            return self._convert_tokens(ctx, tuple(self._split_env(raw)))
        return self._convert_tokens(ctx, (raw,))

    # -- value resolution --------------------------------------------------

    def _implicit_default(self, ctx):
        if self.multiple or self.nargs == -1:
            return (), ParameterSource.DEFAULT
        return None, None

    def _prompt_value(self, ctx):
        found, raw = ctx.lookup_default(self.name)
        if not found:
            raw = self.get_default(ctx)
        text = self.prompt or self.name.replace("_", " ").capitalize()
        value = _prompt(
            text,
            default=raw,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        return (value,) if self.multiple else value

    def resolve(self, ctx, occs):
        """Return ``(value, source)``. ``source`` is None when nothing supplied it."""
        if occs:
            if any(kind == "prompt" for _, kind, _ in occs):
                return self._prompt_value(ctx), ParameterSource.PROMPT
            return self._convert_occurrences(ctx, occs), ParameterSource.COMMANDLINE

        found, value = self._from_env(ctx)
        if found:
            return value, ParameterSource.ENVIRONMENT

        if self.prompt_wanted_when_omitted():
            return self._prompt_value(ctx), ParameterSource.PROMPT

        found, raw = ctx.lookup_default(self.name)
        if found and raw is not None:
            return self._convert_default(ctx, raw, from_map=True), ParameterSource.DEFAULT_MAP

        if self.default is not None:
            return self._convert_default(ctx, self.get_default(ctx)), ParameterSource.DEFAULT

        return self._implicit_default(ctx)

    def prompt_wanted_when_omitted(self):
        return False

    def _from_env(self, ctx):
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self._env_value(ctx, raw)
            if value is _NO_VALUE:
                continue
            return True, value
        return False, None

    def _env_value(self, ctx, raw):
        return self._convert_env(ctx, raw)

    def run_callback(self, ctx, value):
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def get_help_record(self, ctx):
        return None


_NO_VALUE = object()


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    _KNOWN = {
        "type", "default", "required", "is_flag", "flag_value", "count", "multiple",
        "nargs", "envvar", "allow_from_autoenv", "prompt", "prompt_required", "hide_input",
        "confirmation_prompt", "callback", "is_eager", "expose_value", "hidden", "deprecated",
        "help", "metavar", "show_default", "show_envvar", "shell_complete",
    }

    def __init__(self, param_decls=(), **attrs):
        unknown = set(attrs) - self._KNOWN
        if unknown:
            raise TypeError(f"Unknown option keyword(s): {', '.join(sorted(unknown))}")
        opts, secondary, dest = self._parse_decls(list(param_decls))
        if not opts:
            if dest is None:
                raise TypeError("An option needs at least one name.")
            opts = ["--" + dest.replace("_", "-")]
        if dest is None:
            dest = _derive_dest(opts)
        self.opts = opts
        self.secondary_opts = secondary

        default = attrs.get("default")
        is_flag = attrs.get("is_flag")
        count = bool(attrs.get("count", False))
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool)
        if count and is_flag:
            raise TypeError("A counting option cannot also be a flag.")
        multiple = bool(attrs.get("multiple", False))
        prompt = attrs.get("prompt", False)
        deprecated = attrs.get("deprecated", False)
        required = bool(attrs.get("required", False))
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if is_flag and attrs.get("nargs", 1) not in (1, None):
            raise TypeError("A flag cannot take a nargs value.")

        self.is_flag = bool(is_flag)
        self.count = count
        flag_value = attrs.get("flag_value")
        if self.is_flag and flag_value is None:
            flag_value = not default if isinstance(default, bool) else True
        self.flag_value = flag_value
        # An option with an explicit is_flag=False and a flag_value takes an
        # optional value: the bare flag yields flag_value.
        self.optional_value = (
            not self.is_flag and not count and attrs.get("is_flag") is False and flag_value is not None
        )
        # None: no prompt. "": prompt with a text derived from the name.
        if isinstance(prompt, str):
            self.prompt = prompt
        else:
            self.prompt = "" if prompt else None
        self.prompt_required = bool(attrs.get("prompt_required", True))
        self.hide_input = bool(attrs.get("hide_input", False))
        self.confirmation_prompt = bool(attrs.get("confirmation_prompt", False))
        self.allow_from_autoenv = bool(attrs.get("allow_from_autoenv", True))
        self.show_default = attrs.get("show_default")
        self.show_envvar = bool(attrs.get("show_envvar", False))

        nargs = attrs.get("nargs")
        if nargs is None:
            nargs = 1
        if nargs < 1:
            raise TypeError("nargs must be a positive integer for options.")

        declared_type = attrs.get("type")
        if declared_type is None:
            if self.is_flag:
                declared_type = pt.BOOL
            elif self.count:
                declared_type = pt.INT
        if self.prompt is not None and self.is_flag:
            raise TypeError("A flag cannot prompt.")

        super().__init__(
            dest,
            type=declared_type,
            required=required,
            default=default,
            callback=attrs.get("callback"),
            nargs=nargs,
            multiple=multiple,
            metavar=attrs.get("metavar"),
            expose_value=attrs.get("expose_value", True),
            is_eager=attrs.get("is_eager", False),
            envvar=attrs.get("envvar"),
            shell_complete=attrs.get("shell_complete"),
            deprecated=deprecated,
            hidden=attrs.get("hidden", False),
            help=attrs.get("help"),
        )
        self.allow_from_autoenv = bool(attrs.get("allow_from_autoenv", True))
        if self.is_flag or self.count:
            self.nargs = 0

    @staticmethod
    def _parse_decls(decls):
        opts, secondary, dest = [], [], None
        for d in decls:
            if not d:
                continue
            if _is_prefix_char(d[0]):
                if len(d) > 1 and "/" in d[1:]:
                    i = d.index("/", 1)
                    opts.append(d[:i])
                    secondary.append(d[i + 1:])
                else:
                    opts.append(d)
            else:
                dest = d
        return opts, secondary, dest

    # -- prompt and flag behaviour ----------------------------------------

    def prompt_wanted_when_omitted(self):
        return self.prompt is not None and (self.prompt_required or self.required)

    def flag_value_for(self, name):
        if name in self.secondary_opts:
            return False
        return self.flag_value

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    # -- conversion details ------------------------------------------------

    def _env_value(self, ctx, raw):
        if self.is_flag:
            return self._env_flag(ctx, raw)
        return self._convert_env(ctx, raw)

    def _env_flag(self, ctx, raw):
        low = raw.strip().lower()
        if isinstance(self.flag_value, bool) or not self.is_flag or self.flag_value is True or self.flag_value is False:
            if low in _TRUE_ENV:
                return True
            if low in _FALSE_ENV or low == "":
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
        if low == str(self.flag_value).lower():
            return self.flag_value
        if low in _TRUE_ENV:
            return True
        if low in _FALSE_ENV:
            return False
        return _NO_VALUE

    def get_error_hint(self, ctx):
        return "/".join(self.opts + self.secondary_opts)

    def _implicit_default(self, ctx):
        if self.count:
            return 0, ParameterSource.DEFAULT
        if self.is_flag:
            return False, ParameterSource.DEFAULT
        return super()._implicit_default(ctx)

    def make_metavar(self):
        if self.is_flag or self.count:
            return None
        if self.metavar is not None:
            return self.metavar
        base = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs > 1 and not isinstance(self.type, pt.Tuple):
            return " ".join([base] * self.nargs)
        return base

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        names = ", ".join(self.opts)
        if self.secondary_opts:
            names += " / " + ", ".join(self.secondary_opts)
        meta = self.make_metavar()
        if meta:
            names += " " + meta
        extras = []
        show_default = self.show_default if self.show_default is not None else ctx.show_default
        if show_default:
            if isinstance(show_default, str):
                extras.append(f"default: {show_default}")
            elif self.default is not None and not callable(self.default):
                if not (self.is_flag and self.default is False):
                    extras.append(f"default: {_fmt_default(self.default)}")
        if self.show_envvar:
            envs = self._env_names(ctx)
            if envs:
                extras.append("env var: " + ", ".join(envs))
        if self.required:
            extras.append("required")
        text = self.help or ""
        if extras:
            text = (text + " " if text else "") + "[" + "; ".join(extras) + "]"
        return names, text

    def __repr__(self):
        return f"<Option {self.name} {'/'.join(self.opts)}>"


class Argument(Parameter):
    """A positional parameter. ``nargs=-1`` marks a variadic argument."""

    is_argument = True

    def __init__(self, name, **attrs):
        if not name:
            raise TypeError("An argument needs a name.")
        dest = name.replace("-", "_")
        nargs = attrs.get("nargs", 1)
        if nargs is None:
            nargs = 1
        if nargs != -1 and nargs < 1:
            raise TypeError("nargs must be a positive integer or -1 for arguments.")
        default = attrs.get("default")
        required = attrs.get("required")
        if required is None:
            required = default is None
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        super().__init__(
            dest,
            type=attrs.get("type"),
            required=required,
            default=default,
            callback=attrs.get("callback"),
            nargs=nargs,
            metavar=attrs.get("metavar"),
            expose_value=attrs.get("expose_value", True),
            envvar=attrs.get("envvar"),
            deprecated=attrs.get("deprecated", False),
            hidden=attrs.get("hidden", False),
            help=attrs.get("help"),
            shell_complete=attrs.get("shell_complete"),
        )
        self.allow_from_autoenv = False

    def get_error_hint(self, ctx):
        return self.name.upper()

    def placeholder(self):
        return self.metavar or self.name.upper()

    def prompt_wanted_when_omitted(self):
        return False

    def _env_value(self, ctx, raw):
        return self._convert_env(ctx, raw)

    def get_help_record(self, ctx):
        if not self.help:
            return None
        return self.placeholder(), self.help

    def __repr__(self):
        return f"<Argument {self.name}>"


# ---------------------------------------------------------------------------
# Option parser
# ---------------------------------------------------------------------------

class _OptionParser:
    def __init__(self, ctx, options, interspersed, ignore_unknown):
        self.ctx = ctx
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.map = {}
        self.prefixes = {"-"}
        for opt in options:
            for name in opt.opts + opt.secondary_opts:
                self.map[self._norm(name)] = opt
                self.prefixes.add(name[0])
        self.seq = 0
        self.occ = {}
        self.positional = []

    def _norm(self, text):
        func = self.ctx.token_normalize_func
        return func(text) if func else text

    def _is_opt(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def _is_value_token(self, tok):
        """A token that may be consumed as an option's value.

        Option-shaped tokens are not values, except negative numbers such as
        ``-1`` and ``-2.5``.
        """
        if not self._is_opt(tok):
            return True
        if _NEGATIVE_NUMBER.fullmatch(tok):
            return True
        return False

    def _add(self, opt, kind, payload):
        self.seq += 1
        self.occ.setdefault(opt, []).append((self.seq, kind, payload))

    def parse(self, args):
        i = 0
        n = len(args)
        stop = False
        while i < n:
            tok = args[i]
            i += 1
            if stop or (not self.interspersed and self.positional):
                self.positional.append(tok)
                continue
            if tok == "--":
                stop = True
                continue
            if self._is_opt(tok):
                i = self._handle(tok, args, i)
            else:
                self.positional.append(tok)
        return self.occ, self.positional

    def _handle(self, tok, args, i):
        p = tok[0]
        if len(tok) > 1 and tok[1] == p:
            name, eq, value = tok.partition("=")
            opt = self.map.get(self._norm(name))
            if opt is None:
                if self.ignore_unknown:
                    self.positional.append(tok)
                    return i
                raise NoSuchOption(name, ctx=self.ctx)
            return self._take(opt, name, value if eq else None, args, i)
        for j in range(1, len(tok)):
            name = p + tok[j]
            opt = self.map.get(self._norm(name))
            if opt is None:
                if self.ignore_unknown:
                    self.positional.append(p + tok[j:])
                    return i
                raise NoSuchOption(name, ctx=self.ctx)
            if opt.takes_value:
                rest = tok[j + 1:]
                return self._take(opt, name, rest if rest else None, args, i)
            if opt.count:
                self._add(opt, "count", None)
            else:
                self._add(opt, "value", opt.flag_value_for(name))
        return i

    def _take(self, opt, name, explicit, args, i):
        if opt.count:
            if explicit is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
            self._add(opt, "count", None)
            return i
        if opt.is_flag:
            if explicit is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
            self._add(opt, "value", opt.flag_value_for(name))
            return i
        if opt.optional_value:
            if explicit is not None:
                self._add(opt, "raw", (explicit,))
                return i
            if i < len(args) and self._is_value_token(args[i]):
                self._add(opt, "raw", (args[i],))
                return i + 1
            self._add(opt, "value", opt.flag_value)
            return i
        toks = []
        if explicit is not None:
            toks.append(explicit)
        while len(toks) < opt.nargs and i < len(args) and self._is_value_token(args[i]):
            toks.append(args[i])
            i += 1
        if len(toks) < opt.nargs:
            if opt.prompt is not None:
                self._add(opt, "prompt", None)
                return i
            raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx=self.ctx)
        self._add(opt, "raw", tuple(toks))
        return i


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------

def _first_sentence(text):
    flat = " ".join(text.split())
    m = re.match(r"(.*?[.!?])(\s|$)", flat)
    return m.group(1) if m else flat


class Command:
    """A leaf command: options, arguments, and a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name=None,
        callback=None,
        params=None,
        *,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
        context_settings=None,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.context_settings = dict(context_settings or {})

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters -------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            taken = set()
            for p in params:
                if isinstance(p, Option):
                    taken.update(p.opts + p.secondary_opts)
            names = [n for n in ctx.help_option_names if n not in taken]
            if names:
                params.append(_make_help_option(names))
        return params

    # -- parsing ----------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        try:
            with ctx.scope(cleanup=False):
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    def _accepts_leftover(self):
        return False

    def _assign_arguments(self, ctx, arguments, tokens):
        """Split positional tokens between arguments in declaration order."""
        rem = list(tokens)
        assigned = {}
        for idx, arg in enumerate(arguments):
            later = arguments[idx + 1:]
            reserve = sum(a.nargs for a in later if a.nargs > 0 and a.required)
            if arg.nargs == -1:
                take = max(0, len(rem) - reserve)
                if take:
                    assigned[arg] = tuple(rem[:take])
                    rem = rem[take:]
                continue
            available = len(rem) - reserve
            if arg.required:
                if len(rem) >= arg.nargs:
                    assigned[arg] = tuple(rem[:arg.nargs])
                    rem = rem[arg.nargs:]
                elif rem and arg.nargs > 1:
                    raise BadArgumentUsage(
                        f"Argument '{arg.name}' takes {arg.nargs} values.", ctx=ctx
                    )
            elif rem and available >= arg.nargs:
                assigned[arg] = tuple(rem[:arg.nargs])
                rem = rem[arg.nargs:]
        return assigned, rem

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        parser = _OptionParser(ctx, options, ctx.allow_interspersed_args, ctx.ignore_unknown_options)
        occ, positional = parser.parse(args)
        assigned, rest = self._assign_arguments(ctx, arguments, positional)
        for index, arg in enumerate(arguments):
            if arg in assigned:
                occ[arg] = [(_ARG_SEQ_BASE + index, "raw", assigned[arg])]
        self._process_params(ctx, params, occ)
        ctx.args = list(rest)
        if rest and not self._accepts_leftover():
            if not ctx.allow_extra_args:
                raise BadArgumentUsage(
                    f"Got unexpected extra argument(s) ({' '.join(rest)})", ctx=ctx
                )
            if not ctx.ignore_unknown_options:
                for tok in rest:
                    if parser._is_opt(tok):
                        raise NoSuchOption(tok, ctx=ctx)
        return ctx.args

    def _process_params(self, ctx, params, occ):
        def first_seq(p):
            return occ[p][0][0]

        given = [p for p in params if p in occ]
        eager = sorted((p for p in given if p.is_eager), key=first_seq)
        eager += [p for p in params if p.is_eager and p not in occ]
        for p in eager:
            self._process_one(ctx, p, occ.get(p, []))

        ordered = sorted((p for p in given if not p.is_eager), key=first_seq)
        ordered += [p for p in params if not p.is_eager and p not in occ]
        done = set()
        for p in ordered:
            if p.name in done:
                continue
            done.add(p.name)
            cands = [q for q in params if q.name == p.name and not q.is_eager]
            winner = self._pick_winner(ctx, cands, occ)
            self._process_one(ctx, winner, occ.get(winner, []))

    def _pick_winner(self, ctx, cands, occ):
        if len(cands) == 1:
            return cands[0]
        given = [c for c in cands if c in occ]
        if given:
            return max(given, key=lambda c: occ[c][-1][0])
        with_env = [c for c in cands if c._from_env(ctx)[0]]
        if with_env:
            return with_env[-1]
        explicit = [c for c in cands if c._explicit_default]
        return (explicit or cands)[-1]

    def _process_one(self, ctx, p, occs):
        value, source = p.resolve(ctx, occs)
        if occs and p.deprecated:
            _warn_deprecated(ctx, p)
        if source is None and p.required:
            raise MissingParameter(ctx=ctx, param=p)
        value = p.run_callback(ctx, value)
        if p.expose_value:
            ctx.params[p.name] = value
        ctx._sources[p.name] = source
        return value

    # -- help and usage ---------------------------------------------------

    def collect_usage_pieces(self, ctx):
        rv = [self.options_metavar] if self.options_metavar else []
        for arg in self.params:
            if not isinstance(arg, Argument) or arg.hidden:
                continue
            text = arg.placeholder()
            if arg.nargs == -1:
                text += "..."
            if not arg.required:
                text = f"[{text}]"
            rv.append(text)
        return rv

    def get_usage(self, ctx):
        pieces = self.collect_usage_pieces(ctx)
        return " ".join(["Usage:", ctx.command_path] + pieces).rstrip()

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = " ".join(self.short_help.split())
        elif self.help:
            text = _first_sentence(self.help.split("\n\n")[0])
        else:
            text = ""
        if len(text) > limit:
            text = text[: limit - 3].rstrip() + "..."
        return text

    def get_help(self, ctx):
        return self.format_help(ctx)

    def format_help(self, ctx):
        width = _help_width(ctx)
        lines = [self.get_usage(ctx), ""]
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            lines.append("DEPRECATED: " + (note or "This command is deprecated."))
            lines.append("")
        if self.help:
            lines.extend(wrap_text(self.help, width, preserve_paragraphs=True).splitlines())
            lines.append("")
        args = [p for p in self.params if isinstance(p, Argument) and not p.hidden]
        arg_rows = [p.get_help_record(ctx) for p in args]
        arg_rows = [r for r in arg_rows if r]
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(write_rows(arg_rows, width))
            lines.append("")
        records = []
        for p in self.get_params(ctx):
            if isinstance(p, Option) and not p.hidden:
                rec = p.get_help_record(ctx)
                if rec:
                    records.append(rec)
        if records:
            lines.append("Options:")
            lines.extend(write_rows(records, width))
            lines.append("")
        lines.extend(self.format_extra_sections(ctx, width))
        if self.epilog:
            lines.extend(wrap_text(self.epilog, width, preserve_paragraphs=True).splitlines())
            lines.append("")
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines) + "\n"

    def format_extra_sections(self, ctx, width):
        return []

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(ctx, self)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def _main_inner(self, args, prog_name, standalone_mode, extra):
        with self.make_context(prog_name, args, **extra) as ctx:
            rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
        return rv

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run this command on ``args`` (default ``sys.argv[1:]``)."""
        args = list(sys.argv[1:]) if args is None else list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        if complete_var is None:
            complete_var = "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"

        completion_instruction = os.environ.get(complete_var)
        if completion_instruction:
            from .shell_completion import run_completion

            return run_completion(
                self, prog_name, complete_var, completion_instruction, args, standalone_mode
            )

        try:
            rv = self._main_inner(args, prog_name, standalone_mode, extra)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except (EOFError, KeyboardInterrupt) as e:
            if not standalone_mode:
                raise
            echo(file=sys.stderr)
            self._exit_aborted()
            raise SystemExit(1) from e
        except Abort:
            if not standalone_mode:
                raise
            self._exit_aborted()
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        if not standalone_mode:
            return rv
        sys.exit(0)

    @staticmethod
    def _exit_aborted():
        echo("Aborted!", err=True)
        sys.exit(1)


def _warn_deprecated(ctx, obj):
    if isinstance(obj, Command):
        what = f"The command {obj.name!r} is deprecated."
    elif isinstance(obj, Option):
        what = f"The option {obj.get_error_hint(ctx)!r} is deprecated."
    else:
        what = f"The argument {obj.name!r} is deprecated."
    note = obj.deprecated if isinstance(obj.deprecated, str) else ""
    message = f"DeprecationWarning: {what}"
    if note:
        message += f" {note}"
    echo(message, err=True)


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _make_help_option(names):
    return Option(
        list(names) + [_HELP_DEST],
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=_help_callback,
        help="Show this message and exit.",
        hidden=False,
    )




class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)

    # -- registration -----------------------------------------------------

    def add_command(self, cmd, name=None):
        key = name or cmd.name
        if key is None:
            raise TypeError("A command must have a name to be added.")
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Cannot attach a group beneath a chaining group.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # -- lookup -----------------------------------------------------------

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _lookup(self, ctx, name):
        """Return ``(resolved_name, command)`` or ``(None, None)``."""
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return name, cmd
        if ctx.token_normalize_func:
            wanted = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    cmd = self.get_command(ctx, candidate)
                    if cmd is not None:
                        return candidate, cmd
        return None, None

    def resolve_command(self, ctx, name):
        resolved, cmd = self._lookup(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx=ctx)
        return resolved, cmd

    # -- parsing ----------------------------------------------------------

    def _accepts_leftover(self):
        return True

    def parse_args(self, ctx, args):
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = []
            ctx.args = list(rest)
        else:
            ctx.protected_args = list(rest[:1])
            ctx.args = list(rest[1:])
        return ctx.args

    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        if self.chain:
            rv.append("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]...")
        elif self.subcommand_metavar:
            rv.append(self.subcommand_metavar)
        elif self.invoke_without_command:
            rv.append("[COMMAND] [ARGS]...")
        else:
            rv.append("COMMAND [ARGS]...")
        return rv

    def format_extra_sections(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(45)))
        if not rows:
            return []
        return ["Commands:"] + write_rows(rows, width) + [""]

    # -- invocation -------------------------------------------------------

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx=ctx)
            ctx.invoked_subcommand = None
            rv = Command.invoke(self, ctx)
            if self._result_callback is not None:
                return ctx.invoke(self._result_callback, rv, **ctx.params)
            return rv

        name, cmd = self.resolve_command(ctx, ctx.protected_args[0])
        ctx.invoked_subcommand = name
        Command.invoke(self, ctx)
        sub = cmd.make_context(name, ctx.args, parent=ctx)
        with sub:
            rv = cmd.invoke(sub)
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, rv, **ctx.params)
        return rv

    def _invoke_chain(self, ctx):
        rest = list(ctx.args)
        if not rest and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx=ctx)
        if rest:
            self.resolve_command(ctx, rest[0])
            ctx.invoked_subcommand = CHAIN_MARKER
        else:
            ctx.invoked_subcommand = None
        Command.invoke(self, ctx)
        results = []
        while rest:
            name, cmd = self.resolve_command(ctx, rest[0])
            sub = cmd.make_context(
                name, rest[1:], parent=ctx, allow_extra_args=True, allow_interspersed_args=False
            )
            rest = list(sub.args)
            with sub:
                results.append(cmd.invoke(sub))
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None
