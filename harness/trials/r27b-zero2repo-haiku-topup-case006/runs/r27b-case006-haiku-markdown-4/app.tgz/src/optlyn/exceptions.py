"""Exception classes raised and handled by Optlyn.

Exit statuses in standalone mode:

* ``UsageError`` (and subclasses) -> 2
* ``Abort`` and other ``OptlynError`` -> 1
* ``Exit`` -> the code it carries
"""


class OptlynError(Exception):
    """Base class for library-signalled errors that are not usage errors."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        if file is None:
            echo(f"Error: {self.message}", err=True)
        else:
            echo(f"Error: {self.message}", file=file)


class UsageError(OptlynError):
    """Incorrect command-line usage. Exit status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message, ctx)
        self.cmd = ctx.command if ctx is not None else None

    def show(self, file=None):
        from .termui import echo

        lines = []
        ctx = self.ctx
        if ctx is not None:
            lines.append(ctx.get_usage())
            if ctx.command.add_help_option and ctx.help_option_names:
                lines.append(
                    f"Try '{ctx.command_path} {ctx.help_option_names[0]}' for help."
                )
            lines.append("")
        lines.append(f"Error: {self.message}")
        echo("\n".join(lines), file=file, err=file is None)


class BadParameter(UsageError):
    """A value that cannot be used for a parameter. Names that parameter."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        self.param = param
        hint = param_hint
        if hint is None and param is not None:
            hint = param.get_error_hint(ctx)
        self.param_hint = hint
        if hint:
            message = f"Invalid value for '{hint}': {message}"
        super().__init__(message, ctx)


class MissingParameter(BadParameter):
    """A required parameter received no value."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        self.param = param
        if param is not None and param_hint is None:
            kind = "argument" if param.is_argument else "option"
            param_hint = f"'{param.get_error_hint(ctx)}'"
            message = f"Missing {kind} {param_hint}."
        elif message is None:
            message = "Missing parameter."
        UsageError.__init__(self, message, ctx)
        self.param_hint = param_hint


class NoSuchOption(UsageError):
    """An option token that matches no declared option."""

    def __init__(self, option_name, message=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """Option used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """Argument tokens used incorrectly (for example extra arguments)."""


class NoArgsIsHelp(UsageError):
    """No arguments were given and the command shows help on that path."""

    def __init__(self, ctx):
        super().__init__("No arguments were given.", ctx)

    def show(self, file=None):
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=file is None)


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error, exit 1."""

    def __init__(self, filename, message):
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


class Abort(RuntimeError):
    """Abort the program (exit status 1 in standalone mode)."""


class Exit(RuntimeError):
    """Clean stop with an exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
