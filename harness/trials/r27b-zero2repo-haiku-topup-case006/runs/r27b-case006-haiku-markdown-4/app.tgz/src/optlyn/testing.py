"""In-process runner: invoke a command with tokens and capture its output."""

import io
import os
import shlex
import shutil
import sys
import tempfile
from contextlib import contextmanager


class _Buckets:
    def __init__(self):
        self.stdout = bytearray()
        self.stderr = bytearray()
        self.combined = bytearray()


class _CaptureBinary:
    def __init__(self, text_stream):
        self._text = text_stream

    def write(self, data):
        self._text._record(bytes(data))
        return len(data)

    def flush(self):
        pass

    def isatty(self):
        return False

    def readable(self):
        return False

    def writable(self):
        return True


class _CaptureText:
    """Text stream whose writes are recorded in a bucket and the combined log."""

    encoding = "utf-8"
    errors = "strict"

    def __init__(self, buckets, name, charset):
        self._buckets = buckets
        self._name = name
        self._charset = charset
        self.buffer = _CaptureBinary(self)
        self.encoding = charset

    def _record(self, data):
        getattr(self._buckets, self._name).extend(data)
        self._buckets.combined.extend(data)

    def write(self, text):
        if isinstance(text, (bytes, bytearray)):
            self._record(bytes(text))
            return len(text)
        # Strict: an unencodable character raises UnicodeEncodeError, which
        # echo() answers by writing UTF-8 to the underlying buffer.
        self._record(text.encode(self._charset))
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def writable(self):
        return True

    def readable(self):
        return False


class _InputStream:
    """Standard input for an invocation. Optionally echoes what it reads."""

    def __init__(self, data, charset, echo_target=None):
        self._text = io.TextIOWrapper(io.BytesIO(data), encoding=charset, newline="\n")
        self._echo = echo_target

    def _maybe_echo(self, s):
        if self._echo is not None and s:
            self._echo.write(s)
        return s

    def readline(self, size=-1):
        return self._maybe_echo(self._text.readline(size))

    def read(self, size=-1):
        return self._maybe_echo(self._text.read(size))

    def __iter__(self):
        return iter(self.readline, "")

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def readable(self):
        return True

    @property
    def buffer(self):
        return self._text.buffer


class Result:
    """Outcome of ``CliRunner.invoke``."""

    def __init__(self, runner, buckets, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self._buckets = buckets
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _text(self, data):
        return bytes(data).decode("utf-8", "replace")

    @property
    def output(self):
        return self._text(self._buckets.combined)

    @property
    def stdout(self):
        return self._text(self._buckets.stdout)

    @property
    def stderr(self):
        return self._text(self._buckets.stderr)

    @property
    def stdout_bytes(self):
        return bytes(self._buckets.stdout)

    @property
    def stderr_bytes(self):
        return bytes(self._buckets.stderr)

    @property
    def output_bytes(self):
        return bytes(self._buckets.combined)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke commands in-process, capturing standard streams and exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None, color=False):
        buckets = _Buckets()
        data = b""
        if input is not None:
            data = input.encode(self.charset) if isinstance(input, str) else bytes(input)
        out = _CaptureText(buckets, "stdout", self.charset)
        err = _CaptureText(buckets, "stderr", self.charset)
        stdin_echo = out if self.echo_stdin else None
        stdin = _InputStream(data, self.charset, stdin_echo)

        merged_env = dict(self.env)
        merged_env.update(env or {})
        old_env = {}
        for key, value in merged_env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield buckets
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        return_value = None
        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as buckets:
            try:
                return_value = cli.main(
                    args=list(args),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if standalone:
                    exit_code = 0
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    exit_code = 1
                    sys.stderr.write(str(e.code) + "\n")
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        return Result(self, buckets, return_value, exit_code, exception, exc_info)

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run in a new empty directory. Removed on exit unless ``temp_dir`` is given."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
