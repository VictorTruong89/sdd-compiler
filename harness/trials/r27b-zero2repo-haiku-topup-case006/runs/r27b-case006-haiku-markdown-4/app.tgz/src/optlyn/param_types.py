"""Parameter types: conversion of command-line text into Python values."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter
from .utils import open_file


class CompletionItem:
    """A shell-completion suggestion.

    ``type`` is ``"plain"`` for an ordinary value, ``"file"`` or ``"dir"``
    for a request that the shell complete a path.
    """

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _norm(ctx, text):
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    return func(text) if func else text


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return self.name.upper() if self.name else None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return value


class _IntType(ParamType):
    name = "integer"
    python_type = int

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if not isinstance(value, str):
            return value
        try:
            return int(value.strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if not isinstance(value, str):
            return value
        try:
            return float(value.strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        if not isinstance(value, str):
            return value
        low = value.strip().lower()
        if low in _TRUE:
            return True
        if low in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID) or not isinstance(value, str):
            return value
        try:
            return uuid.UUID(value.strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class _FuncType(ParamType):
    """Adapts a plain conversion function ``f(token) -> value``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._is_enum = True
        else:
            self.choices = list(choices)
            self._is_enum = False

    def _key(self, choice):
        if self._is_enum:
            return choice.name
        return str(choice)

    def get_metavar(self, param):
        return "[" + "|".join(self._key(c) for c in self.choices) + "]"

    def convert(self, value, param, ctx):
        if self._is_enum and isinstance(value, enum.Enum):
            return value
        if not self._is_enum and any(value is c for c in self.choices):
            return value
        if not isinstance(value, str):
            return value
        token = _norm(ctx, value)
        for choice in self.choices:
            key = _norm(ctx, self._key(choice))
            if self.case_sensitive:
                matched = key == token
            else:
                matched = key.casefold() == token.casefold()
            if matched:
                return choice
        options = ", ".join(repr(self._key(c)) for c in self.choices)
        self.fail(f"{value!r} is not {'one of ' if len(self.choices) != 1 else ''}{options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for choice in self.choices:
            key = self._key(choice)
            if key.startswith(incomplete):
                out.append(CompletionItem(key))
        return out


_DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime) or not isinstance(value, str):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(value.strip(), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        lo = "" if self.min is None else (f"{self.min} < " if self.min_open else f"{self.min} <= ")
        hi = "" if self.max is None else (f" < {self.max}" if self.max_open else f" <= {self.max}")
        return f"{lo}x{hi}" if (lo or hi) else "any integer"

    def convert(self, value, param, ctx):
        v = super().convert(value, param, ctx)
        if not isinstance(v, int):
            return v
        low_ok = self.min is None or (v > self.min if self.min_open else v >= self.min)
        high_ok = self.max is None or (v < self.max if self.max_open else v <= self.max)
        if low_ok and high_ok:
            return v
        if self.clamp:
            if not low_ok:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        self.fail(f"{v} is not in the range {self._describe()}.", param, ctx)


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        lo = "" if self.min is None else (f"{self.min} < " if self.min_open else f"{self.min} <= ")
        hi = "" if self.max is None else (f" < {self.max}" if self.max_open else f" <= {self.max}")
        return f"{lo}x{hi}" if (lo or hi) else "any float"

    def convert(self, value, param, ctx):
        v = super().convert(value, param, ctx)
        if not isinstance(v, float):
            return v
        low_ok = self.min is None or (v > self.min if self.min_open else v >= self.min)
        high_ok = self.max is None or (v < self.max if self.max_open else v <= self.max)
        if low_ok and high_ok:
            return v
        if self.clamp:
            if not low_ok:
                return float(self.min)
            return float(self.max)
        self.fail(f"{v} is not in the range {self._describe()}.", param, ctx)


def _convert_type_arg(ty):
    if isinstance(ty, ParamType):
        return ty
    mapping = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}
    if isinstance(ty, type) and ty in mapping:
        return mapping[ty]
    if isinstance(ty, (tuple, list)):
        return Tuple(list(ty))
    if callable(ty):
        return _FuncType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_convert_type_arg(t) for t in types]

    def get_metavar(self, param):
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, str) or not hasattr(value, "__iter__"):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        values = tuple(value)
        if len(values) != len(self.types):
            self.fail(
                f"Expected {len(self.types)} values, got {len(values)}.",
                param,
                ctx,
            )
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, values))


def infer_type(default):
    """Infer a parameter type from a default value."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, tuple):
        return Tuple([infer_type(x) for x in default])
    return STRING


def convert_type(ty, default=None):
    """Turn a declared ``type=`` (or None) into a ParamType instance."""
    if ty is None:
        return infer_type(default) if default is not None else STRING
    return _convert_type_arg(ty)


class File(ParamType):
    """An open file. ``-`` means stdin for reading and stdout for writing."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"{value!r}: {e.strerror or e}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """A filesystem path (a string or pathlib.Path), validated by options."""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _out(self, rv):
        if self.path_type is str:
            return str(rv)
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def convert(self, value, param, ctx):
        if isinstance(value, pathlib.PurePath):
            value = os.fspath(value)
        if not isinstance(value, str):
            return value
        if self.allow_dash and value == "-":
            return self._out(value)
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(rv)
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._out(rv)
        is_dir = os.path.isdir(rv)
        if is_dir and not self.dir_okay:
            self.fail(f"{value!r} is a directory.", param, ctx)
        if not is_dir and not self.file_okay:
            self.fail(f"{value!r} is a file.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._out(rv)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]
