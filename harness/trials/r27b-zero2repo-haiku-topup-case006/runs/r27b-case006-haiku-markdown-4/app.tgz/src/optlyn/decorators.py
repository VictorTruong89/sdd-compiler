"""Declaration decorators: commands, groups, options, arguments and helpers."""

import inspect
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option
from .exceptions import Abort
from .termui import confirm, echo
from .utils import get_current_context


def _truncate_form_feed(text):
    if text is not None and "\f" in text:
        return text.split("\f", 1)[0]
    return text


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _attach(f, param):
    if isinstance(f, Command):
        f.params.insert(0, param)
        return f
    f.__dict__.setdefault("__optlyn_params__", []).append(param)
    return f


def _pop_params(f):
    if isinstance(f, Command):
        return []
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _doc_help(f, attrs):
    help_text = attrs.pop("help", None)
    if help_text is None and f.__doc__:
        help_text = inspect.cleandoc(f.__doc__)
    return _truncate_form_feed(help_text)


def command(name=None, cls=None, **attrs):
    """Turn a function into a `Command`. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls=cls)(name)
    if cls is None:
        cls = Command

    def decorator(f):
        params = _pop_params(f)
        local = dict(attrs)
        local["help"] = _doc_help(f, local)
        cmd_name = name if name is not None else _derive_name(f.__name__)
        return cls(name=cmd_name, callback=f, params=params, **local)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a `Group`. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls=cls)(name)
    if cls is None:
        cls = Group

    def decorator(f):
        params = _pop_params(f)
        local = dict(attrs)
        local["help"] = _doc_help(f, local)
        grp_name = name if name is not None else _derive_name(f.__name__)
        return cls(name=grp_name, callback=f, params=params, **local)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function (or command) being declared."""
    if cls is None:
        cls = Option

    def decorator(f):
        _attach(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a function being declared."""
    if cls is None:
        cls = Argument
    if len(param_decls) != 1:
        raise TypeError("An argument takes exactly one destination name.")

    def decorator(f):
        _attach(f, cls(param_decls[0], **attrs))
        return f

    return decorator


def _caller_package(depth=2):
    try:
        frame = sys._getframe(depth)
    except ValueError:
        return None
    module = frame.f_globals.get("__name__", "")
    return module.split(".")[0] or None


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name) or []
    except Exception:
        dists = []
    for dist in dists:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


def help_option(*param_decls, **kwargs):
    """An extra eager help flag (default ``--help``)."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    from .core import _help_callback

    kwargs.setdefault("callback", _help_callback)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag (default ``--version``) printing a version identity."""
    decls = list(param_decls) or ["--version"]
    if version is None and package_name is None:
        package_name = _caller_package()
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name or ""
        ver = version if version is not None else _detect_version(package_name)
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)

    def decorator(f):
        _attach(f, Option(decls, callback=callback, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager version flag whose whole identity is ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)

    def on_value(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    def decorator(f):
        _attach(f, Option(decls, callback=on_value, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """A hidden, confirmed prompt option (default ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes flag (default ``--yes``); when omitted, asks and aborts on 'no'."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def on_value(ctx, param, value):
        if not value and not ctx.resilient_parsing:
            confirm(question, abort=True)
        return value

    def decorator(f):
        _attach(f, Option(decls, callback=on_value, **kwargs))
        return f

    return decorator


def pass_context(f):
    """Pass the current `Context` as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    """Pass the current context's author object as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
