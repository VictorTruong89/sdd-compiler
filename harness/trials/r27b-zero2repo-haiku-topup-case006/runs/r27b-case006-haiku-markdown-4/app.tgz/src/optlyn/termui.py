"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch."""

import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from . import param_types as pt
from .exceptions import Abort, BadParameter
from .utils import get_current_context, is_interactive, is_tty

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_SWITCHES = {
    "bold": (1, 22),
    "dim": (2, 22),
    "italic": (3, 23),
    "underline": (4, 24),
    "blink": (5, 25),
    "reverse": (7, 27),
    "strikethrough": (9, 29),
    "overline": (53, 55),
}


def unstyle(text):
    """Remove ANSI escape sequences, leaving all other text."""
    return _ANSI_RE.sub("", text)


def _color_codes(color, background):
    if isinstance(color, str):
        if color not in _FG:
            raise ValueError(f"Unknown color {color!r}.")
        code = _FG[color] + (10 if background else 0)
        return [str(code)]
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return [f"{48 if background else 38};5;{color}"]
        raise ValueError(f"Color index out of range: {color}.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        r, g, b = color
        return [f"{48 if background else 38};2;{r};{g};{b}"]
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ValueError."""
    codes = []
    if fg is not None:
        codes += _color_codes(fg, False)
    if bg is not None:
        codes += _color_codes(bg, True)
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, value in flags.items():
        if value is not None:
            on, off = _SWITCHES[name]
            codes.append(str(on if value else off))
    text = "" if text is None else str(text)
    if not codes:
        return text
    prefix = "\x1b[" + ";".join(codes) + "m"
    return prefix + text + ("\x1b[0m" if reset else "")


def _should_strip(file, color):
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is True:
        return False
    if color is False:
        return True
    return not is_tty(file)


def _write_text(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is None:
            file.write(text.encode("ascii", "replace").decode("ascii"))
            return
        file.flush()
        buf.write(text.encode("utf-8", "replace"))
        buf.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr with ``err=True``)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        file.flush()
        buf = getattr(file, "buffer", file)
        buf.write(data)
        buf.flush()
        return
    text = str(message)
    if _should_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """``echo`` with the given styles applied first."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------------------
# Input and prompts
# ---------------------------------------------------------------------------

def _read_hidden_tty(stream):
    try:
        import termios
    except ImportError:
        return stream.readline()
    fd = stream.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] &= ~termios.ECHO
    termios.tcsetattr(fd, termios.TCSADRAIN, new)
    try:
        line = stream.readline()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        sys.stdout.write("\n")
        sys.stdout.flush()
    return line


def _read_line(hide_input):
    stream = sys.stdin
    if stream is None:
        raise EOFError
    if hide_input and is_tty(stream):
        line = _read_hidden_tty(stream)
    else:
        line = stream.readline()
    if not line:
        raise EOFError
    if line.endswith("\n"):
        line = line[:-1]
    if line.endswith("\r"):
        line = line[:-1]
    return line


def _visible_or_hidden_input(prompt_text, hide_input, err):
    out = sys.stderr if err else sys.stdout
    echo(prompt_text, file=out, nl=False, err=err)
    line = _read_line(hide_input)
    if not hide_input and not is_tty(sys.stdin):
        # Input that did not come from a terminal is echoed so the transcript
        # shows the answer, as a terminal would.
        echo(line, file=out, err=err)
    return line


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, converting it with ``type``. Re-asks on bad input.

    End of input raises ``EOFError``, which standalone mode reports as an abort.
    """
    ptype = pt.convert_type(type, default)
    ctx = get_current_context(silent=True)
    shown = ""
    if default is not None and show_default:
        shown = f" [{'***' if hide_input else default}]"
    question = f"{text}{shown}{prompt_suffix}"
    while True:
        value = _visible_or_hidden_input(question, hide_input, err)
        if value == "" and default is not None:
            value = default
            return ptype.convert(value, None, ctx) if isinstance(value, str) else value
        if value == "":
            continue
        if confirmation_prompt:
            again = _visible_or_hidden_input("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return ptype.convert(value, None, ctx)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Returns a bool; aborts on 'no' when asked to."""
    if show_default:
        hint = "[Y/n]" if default else "[y/N]"
    else:
        hint = ""
    question = f"{text} {hint}{prompt_suffix}".replace("  ", " ")
    while True:
        answer = _visible_or_hidden_input(question, False, err).strip().lower()
        if answer == "":
            result = bool(default)
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal (not from a piped stdin)."""
    ch = None
    try:
        tty_fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        tty_fd = None
    if tty_fd is not None:
        try:
            try:
                import termios
                import tty as _tty
            except ImportError:
                ch = os.read(tty_fd, 1).decode("utf-8", "replace")
            else:
                old = termios.tcgetattr(tty_fd)
                try:
                    _tty.setraw(tty_fd)
                    ch = os.read(tty_fd, 1).decode("utf-8", "replace")
                finally:
                    termios.tcsetattr(tty_fd, termios.TCSADRAIN, old)
        finally:
            os.close(tty_fd)
    else:
        ch = sys.stdin.read(1) if sys.stdin is not None else ""
    if not ch:
        raise EOFError
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch == "\x04":
        raise EOFError
    if echo:
        _write_text(sys.stdout, ch)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key, only in interactive sessions."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(file=sys.stderr if err else sys.stdout)


def clear():
    """Clear the terminal screen when stdout is a terminal."""
    if is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Pager
# ---------------------------------------------------------------------------

def _chunks_of(text_or_generator):
    gen = text_or_generator
    if callable(gen):
        gen = gen()
    if isinstance(gen, str):
        return [gen]
    return gen


def echo_via_pager(text_or_generator, color=None):
    """Write text through ``$PAGER`` when interactive, else to stdout."""
    chunks = _chunks_of(text_or_generator)
    strip = _should_strip(sys.stdout, color)
    pager = os.environ.get("PAGER")
    if not is_interactive() or not pager:
        for chunk in chunks:
            text = unstyle(chunk) if strip else chunk
            _write_text(sys.stdout, text)
            sys.stdout.flush()
        return
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            text = unstyle(chunk) if strip else chunk
            proc.stdin.write(text.encode("utf-8", "replace"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


class _PagerStream:
    """Writable text stream that feeds the pager or the real stdout."""

    def __init__(self, target, strip):
        self._target = target
        self._strip = strip

    def write(self, text):
        if self._strip:
            text = unstyle(text)
        self._target.write(text)
        self._target.flush()
        return len(text)

    def flush(self):
        self._target.flush()

    def close(self):
        pass


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager when used."""
    strip = _should_strip(sys.stdout, color)
    pager = os.environ.get("PAGER")
    if is_interactive() and pager:
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
        import io

        wrapper = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace")
        try:
            yield _PagerStream(wrapper, strip)
        finally:
            wrapper.close()
            proc.wait()
    else:
        yield _PagerStream(sys.stdout, strip)


# ---------------------------------------------------------------------------
# Progress bar
# ---------------------------------------------------------------------------

class ProgressBar:
    """Wraps an iterable or a known length and reports progress on a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.visible = (not hidden) and is_tty(sys.stdout)
        self._started = time.monotonic()
        self._label_printed = False

    def _print_label(self):
        if self.label and not self._label_printed:
            self._label_printed = True
            echo(self.label)

    def __enter__(self):
        if not self.visible and not self.hidden:
            self._print_label()
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.visible:
            echo(file=sys.stdout)

    def _render(self):
        if not self.visible:
            return
        elapsed = time.monotonic() - self._started
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            eta = ""
            if self.pos:
                remaining = elapsed / self.pos * (self.length - self.pos)
                eta = f"  eta {int(remaining)}s"
            sys.stdout.write(f"\r{self.label} [{bar}] {self.pos}/{self.length}{eta}")
        else:
            sys.stdout.write(f"\r{self.label} {self.pos}")
        sys.stdout.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        if not self.visible and not self.hidden:
            self._print_label()
        for item in self.iterable:
            yield item
            self.update(1)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a progress bar; use as a context manager and/or iterate it."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------------------
# Editor and launch
# ---------------------------------------------------------------------------

def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor. Returns the saved text, or None (see the contract)."""
    cmd_env = dict(os.environ)
    if env:
        cmd_env.update(env)
    if editor is None:
        editor = cmd_env.get("VISUAL") or cmd_env.get("EDITOR") or "vi"
    argv = shlex.split(editor)
    if filename is not None:
        subprocess.call(argv + [os.fspath(filename)], env=cmd_env)
        return None
    initial = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(initial.encode("utf-8"))
        subprocess.call(argv + [path], env=cmd_env)
        with open(path, "rb") as f:
            saved = f.read().decode("utf-8")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and saved == initial:
        return None
    return saved


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. Returns a status."""
    if sys.platform == "darwin":
        argv = ["open"]
        if wait:
            argv.append("-W")
        if locate:
            argv.append("-R")
        argv.append(os.fspath(url))
    elif sys.platform.startswith("win"):
        os.startfile(os.fspath(url))  # type: ignore[attr-defined]
        return 0
    else:
        opener = shutil.which("xdg-open") or "xdg-open"
        argv = [opener, os.fspath(url)]
    try:
        proc = subprocess.Popen(argv)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0
