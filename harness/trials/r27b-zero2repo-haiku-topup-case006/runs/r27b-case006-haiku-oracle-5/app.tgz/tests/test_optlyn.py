"""Behavioural tests for Optlyn, organised by feature point (FP-01 .. FP-14)."""

import datetime
import enum
import os
import uuid

import pytest

import optlyn
from optlyn import (
    Abort,
    BadParameter,
    Choice,
    Command,
    CommandCollection,
    DateTime,
    File,
    FloatRange,
    Group,
    IntRange,
    ParamType,
    Path,
    Tuple,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    prompt,
    confirm,
    secho,
    style,
    unstyle,
    version_option,
    wrap_text,
    get_current_context,
)
from optlyn.context import ParameterSource
from optlyn.testing import CliRunner
from optlyn.termui import echo_via_pager
from optlyn.utils import format_filename, get_app_dir
from optlyn.completion import suggest


@pytest.fixture
def runner():
    return CliRunner()


# ---------------------------------------------------------------------------
# FP-01: declaration, naming and invocation
# ---------------------------------------------------------------------------


def test_name_derivation_strips_suffix_and_dashes():
    @command()
    def sync_data_command():
        pass

    @group()
    def tools_grp():
        pass

    assert sync_data_command.name == "sync-data"
    assert tools_grp.name == "tools"


def test_explicit_name_replaces_derived_name(runner):
    @command(name="go")
    def whatever():
        echo("ran")

    assert whatever.name == "go"

    @group()
    def tool():
        pass

    @tool.command(name="run-it")
    def runner_fn():
        echo("ran")

    assert runner.invoke(tool, ["run-it"]).stdout == "ran\n"
    assert runner.invoke(tool, ["runner-fn"]).exit_code == 2


def test_callback_runs_once_and_return_value_is_available_without_standalone(runner):
    calls = []

    @command()
    def run():
        calls.append(1)
        return 7

    res = runner.invoke(run, [], standalone_mode=False)
    assert res.return_value == 7
    assert calls == [1]


def test_unknown_option_is_usage_error(runner):
    @command()
    def cmd():
        echo("should not run")

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert "should not run" not in res.output
    assert "Error" in res.stderr


def test_leftover_tokens_are_usage_error_unless_allowed(runner):
    @command()
    def cmd():
        echo("ran")

    assert runner.invoke(cmd, ["extra"]).exit_code == 2
    res = runner.invoke(cmd, ["extra"], allow_extra_args=True)
    assert res.exit_code == 0
    assert res.output == "ran\n"


def test_deprecated_command_still_runs_with_warning(runner):
    @command(deprecated="use new-thing")
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "deprecated" in res.stderr and "use new-thing" in res.stderr


# ---------------------------------------------------------------------------
# FP-02: help and version
# ---------------------------------------------------------------------------


def test_help_prints_page_and_skips_callback(runner):
    calls = []

    @command()
    @option("--name", help="who")
    def hi(name):
        """Greets.

        More text.
        """
        calls.append(1)

    res = runner.invoke(hi, ["--help"])
    assert res.exit_code == 0
    assert calls == []
    assert res.output.startswith("Usage: hi [OPTIONS]")
    assert "Greets." in res.output
    assert "--name TEXT" in res.output
    assert "who" in res.output


def test_help_before_subcommand_is_group_help_after_is_child_help(runner):
    @group()
    def cli():
        """Top."""

    @cli.command()
    def child():
        """Child help text."""
        echo("child ran")

    assert "Commands:" in runner.invoke(cli, ["--help"]).output
    child_help = runner.invoke(cli, ["child", "--help"])
    assert child_help.exit_code == 0
    assert "Child help text." in child_help.output


def test_group_without_subcommand_is_usage_failure_with_help(runner):
    @group()
    def cli():
        """Top."""

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr


def test_version_option_uses_given_string_and_is_eager(runner):
    @command()
    @version_option("1.2.3", prog_name="demo")
    @option("--must", required=True)
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert "1.2.3" in res.stdout
    assert "ran" not in res.stdout


def test_custom_version_is_exact_callback_output(runner):
    @command()
    @custom_version_option(lambda ctx: "custom identity")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.stdout == "custom identity\n"


def test_first_eager_flag_wins(runner):
    @command()
    @version_option("9.9", prog_name="demo")
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["--help", "--version"])
    assert "Usage:" in res.stdout
    assert "9.9" not in res.stdout

    res = runner.invoke(cmd, ["--version", "--help"])
    assert "9.9" in res.stdout
    assert "Usage:" not in res.stdout


def test_help_option_names_can_be_replaced(runner):
    @command()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["-h"], help_option_names=["-h"])
    assert res.exit_code == 0
    assert "Usage:" in res.stdout
    res = runner.invoke(cmd, ["--help"], help_option_names=["-h"])
    assert res.exit_code == 2


def test_help_truncated_at_form_feed(runner):
    @command()
    def cmd():
        """Shown.\f hidden part"""

    res = runner.invoke(cmd, ["--help"])
    assert "Shown." in res.stdout
    assert "hidden part" not in res.stdout


def test_show_default_for_non_false_flag_and_hidden_false_flag(runner):
    @command()
    @option("--on", is_flag=True, default=True, show_default=True, help="on flag")
    @option("--off", is_flag=True, default=False, show_default=True, help="off flag")
    def cmd(on, off):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    on_line = [line for line in out.splitlines() if "--on" in line][0]
    off_line = [line for line in out.splitlines() if "--off" in line][0]
    assert "[default: True]" in on_line
    assert "default" not in off_line


def test_show_envvar_and_hidden_options(runner):
    @command()
    @option("--token", envvar="MY_TOKEN", show_envvar=True)
    @option("--secret", hidden=True)
    def cmd(token, secret):
        echo(f"{token}-{secret}")

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "MY_TOKEN" in out
    assert "--secret" not in out
    assert runner.invoke(cmd, ["--secret", "x"]).stdout == "None-x\n"


# ---------------------------------------------------------------------------
# FP-03: options
# ---------------------------------------------------------------------------


def test_short_option_stacking_and_attached_values(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def cmd(a, b, n):
        echo(f"{a} {b} {n}")

    assert runner.invoke(cmd, ["-ab", "-n5"]).stdout == "True True 5\n"
    assert runner.invoke(cmd, ["-abn", "7"]).stdout == "True True 7\n"


def test_long_option_equals_and_separate_value(runner):
    @command()
    @option("--name")
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, ["--name=ann"]).stdout == "ann\n"
    assert runner.invoke(cmd, ["--name", "bob"]).stdout == "bob\n"


def test_double_dash_ends_options(runner):
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(flag, rest):
        echo(f"{flag} {rest}")

    res = runner.invoke(cmd, ["--", "--flag", "x"])
    assert res.stdout == "False ('--flag', 'x')\n"


def test_on_off_pair(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    def cmd(shout):
        echo(shout)

    assert runner.invoke(cmd, ["--shout"]).stdout == "True\n"
    assert runner.invoke(cmd, ["--no-shout"]).stdout == "False\n"
    assert runner.invoke(cmd, []).stdout == "False\n"


def test_counting_option_counts_each_flag(runner):
    @command()
    @option("-v", count=True)
    def cmd(v):
        echo(v)

    assert runner.invoke(cmd, ["-vvv"]).stdout == "3\n"
    assert runner.invoke(cmd, []).stdout == "0\n"


def test_repeatable_option_collects_in_order_and_defaults_to_empty_tuple(runner):
    @command()
    @option("--item", multiple=True)
    def cmd(item):
        echo(repr(item))

    assert runner.invoke(cmd, ["--item", "a", "--item", "b"]).stdout == "('a', 'b')\n"
    assert runner.invoke(cmd, []).stdout == "()\n"


def test_bare_string_default_on_repeatable_option_is_usage_error(runner):
    @command()
    @option("--item", multiple=True, default="abc")
    def cmd(item):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "iterable" in res.stderr


def test_multi_value_option_takes_fixed_tokens(runner):
    @command()
    @option("--pair", nargs=2, type=int)
    @argument("tail", nargs=-1)
    def cmd(pair, tail):
        echo(f"{pair} {tail}")

    assert runner.invoke(cmd, ["--pair", "1", "2", "x"]).stdout == "(1, 2) ('x',)\n"
    assert runner.invoke(cmd, ["--pair", "1"]).exit_code == 2


def test_optional_value_option(runner):
    @command()
    @option("--color", flag_value="auto", default="never")
    def cmd(color):
        echo(color)

    assert runner.invoke(cmd, ["--color"]).stdout == "auto\n"
    assert runner.invoke(cmd, ["--color", "always"]).stdout == "always\n"
    assert runner.invoke(cmd, []).stdout == "never\n"


def test_required_option_missing_is_usage_error(runner):
    calls = []

    @command()
    @option("--must", required=True)
    def cmd(must):
        calls.append(must)

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert calls == []
    assert "--must" in res.stderr


def test_environment_variable_supplies_value_and_source_is_tracked(runner):
    seen = {}

    @command()
    @option("--name", envvar=["NAME_ONE", "NAME_TWO"])
    def cmd(name):
        ctx = get_current_context()
        seen["src"] = ctx.get_parameter_source("name")
        echo(name)

    res = runner.invoke(cmd, [], env={"NAME_ONE": None, "NAME_TWO": "two"})
    assert res.stdout == "two\n"
    assert seen["src"] is ParameterSource.ENVIRONMENT
    res = runner.invoke(cmd, ["--name", "cli"], env={"NAME_TWO": "two"})
    assert res.stdout == "cli\n"
    assert seen["src"] is ParameterSource.COMMANDLINE


def test_first_set_envvar_name_wins(runner):
    @command()
    @option("--name", envvar=["A_NAME", "B_NAME"])
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, [], env={"A_NAME": "first", "B_NAME": "second"})
    assert res.stdout == "first\n"


def test_empty_envvar_is_not_supplied(runner):
    @command()
    @option("--name", envvar="EMPTY_NAME", default="dflt")
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, [], env={"EMPTY_NAME": ""}).stdout == "dflt\n"


def test_boolean_flag_from_env(runner):
    @command()
    @option("--debug", envvar="DBG", is_flag=True)
    def cmd(debug):
        echo(debug)

    assert runner.invoke(cmd, [], env={"DBG": " YES "}).stdout == "True\n"
    assert runner.invoke(cmd, [], env={"DBG": "off"}).stdout == "False\n"
    assert runner.invoke(cmd, [], env={"DBG": "   "}).stdout == "False\n"
    assert runner.invoke(cmd, [], env={"DBG": "maybe"}).exit_code == 2


def test_parameter_callback_can_replace_value(runner):
    def upper(ctx, param, value):
        return value.upper()

    @command()
    @option("--word", callback=upper)
    def cmd(word):
        echo(word)

    assert runner.invoke(cmd, ["--word", "abc"]).stdout == "ABC\n"


def test_parameter_callback_refusal_is_usage_error(runner):
    def refuse(ctx, param, value):
        raise BadParameter("nope", ctx=ctx, param=param)

    @command()
    @option("--word", callback=refuse)
    def cmd(word):
        echo("ran")

    res = runner.invoke(cmd, ["--word", "x"])
    assert res.exit_code == 2
    assert "ran" not in res.stdout


def test_missing_parameter_still_runs_callback_for_defaulting(runner):
    @command()
    @option("--first", default="one")
    @option("--second", default=None)
    def cmd(first, second):
        echo(f"{first} {second}")

    def fill(ctx, param, value):
        return value if value is not None else ctx.params["first"] + "!"

    cmd.params[1].callback = fill
    assert runner.invoke(cmd, []).stdout == "one one!\n"


def test_feature_switch_group_last_on_command_line_wins(runner):
    @command()
    @option("--fast", "mode", flag_value="fast", is_flag=True)
    @option("--slow", "mode", flag_value="slow", is_flag=True)
    def cmd(mode):
        echo(mode)

    assert runner.invoke(cmd, ["--fast", "--slow"]).stdout == "slow\n"
    assert runner.invoke(cmd, ["--slow", "--fast"]).stdout == "fast\n"


def test_deprecated_option_warns_only_when_supplied(runner):
    @command()
    @option("--old", deprecated=True, default="x")
    def cmd(old):
        echo(old)

    assert "deprecated" not in runner.invoke(cmd, []).stderr
    res = runner.invoke(cmd, ["--old", "y"])
    assert "deprecated" in res.stderr
    assert res.stdout == "y\n"


def test_deprecated_option_cannot_be_required():
    with pytest.raises(ValueError):
        option("--x", deprecated=True, required=True)(lambda: None)


def test_unknown_short_option_splits_into_leftover_with_ignore(runner):
    @command()
    @option("-v", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(v, rest):
        echo(f"{v} {rest}")

    res = runner.invoke(cmd, ["-vx"], ignore_unknown_options=True)
    assert res.exit_code == 0
    assert res.stdout == "True ('-x',)\n"


def test_prefix_characters_other_than_dash(runner):
    @command()
    @option("/force", is_flag=True)
    def cmd(force):
        echo(force)

    assert runner.invoke(cmd, ["/force"]).stdout == "True\n"


# ---------------------------------------------------------------------------
# FP-04: positional arguments
# ---------------------------------------------------------------------------


def test_arguments_bind_in_order_and_variadic_takes_rest(runner):
    @command()
    @argument("src")
    @argument("dst")
    @argument("extra", nargs=-1)
    def cmd(src, dst, extra):
        echo(f"{src} {dst} {extra}")

    assert runner.invoke(cmd, ["a", "b", "c", "d"]).stdout == "a b ('c', 'd')\n"
    assert runner.invoke(cmd, ["a", "b"]).stdout == "a b ()\n"
    assert runner.invoke(cmd, ["a"]).exit_code == 2


def test_optional_argument_default(runner):
    @command()
    @argument("who", required=False, default="world")
    def cmd(who):
        echo(who)

    assert runner.invoke(cmd, []).stdout == "world\n"
    assert runner.invoke(cmd, ["me"]).stdout == "me\n"


def test_argument_env_var_only_when_named(runner):
    @command()
    @argument("who", envvar="WHO_ENV")
    def cmd(who):
        echo(who)

    assert runner.invoke(cmd, [], env={"WHO_ENV": "env"}).stdout == "env\n"
    assert runner.invoke(cmd, ["cli"], env={"WHO_ENV": "env"}).stdout == "cli\n"


def test_leaf_mixes_options_and_arguments(runner):
    @command()
    @option("--loud", is_flag=True)
    @argument("word")
    def cmd(loud, word):
        echo(f"{loud} {word}")

    assert runner.invoke(cmd, ["hi", "--loud"]).stdout == "True hi\n"


# ---------------------------------------------------------------------------
# FP-05: parameter types
# ---------------------------------------------------------------------------


def test_builtin_type_inference_from_default(runner):
    @command()
    @option("--n", default=3)
    @option("--f", default=1.5)
    @option("--b", default=False)
    def cmd(n, f, b):
        echo(f"{type(n).__name__} {type(f).__name__} {type(b).__name__}")

    assert runner.invoke(cmd, []).stdout == "int float bool\n"


def test_choice_delivers_original_object_case_insensitive_on_request(runner):
    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @command()
    @option("--color", type=Choice(Color), default=Color.RED)
    @option("--pick", type=Choice(["alpha", "beta"], case_sensitive=False))
    def cmd(color, pick):
        echo(f"{color!r} {pick!r}")

    res = runner.invoke(cmd, ["--color", "BLUE", "--pick", "ALPHA"])
    assert res.stdout == "<Color.BLUE: 2> 'alpha'\n"
    bad = runner.invoke(cmd, ["--color", "green"])
    assert bad.exit_code == 2


def test_int_range_clamp_open_bound_uses_adjacent_integer():
    rng = IntRange(min=0, max=10, min_open=True, clamp=True)
    assert rng.convert("0", None, None) == 1
    assert rng.convert("99", None, None) == 10
    with pytest.raises(BadParameter):
        IntRange(min=0, max=10).convert("11", None, None)


def test_float_range_refuses_clamp_with_open_bound():
    with pytest.raises(ValueError):
        FloatRange(min=0.0, min_open=True, clamp=True)
    assert FloatRange(min=0.0, max=1.0, clamp=True).convert("5", None, None) == 1.0


def test_datetime_default_formats_and_custom_replaces_them():
    dt = DateTime()
    assert dt.convert("2024-02-03", None, None) == datetime.datetime(2024, 2, 3)
    assert dt.convert("2024-02-03T04:05:06", None, None).hour == 4
    custom = DateTime(["%d/%m/%Y"])
    assert custom.convert("03/02/2024", None, None).day == 3
    with pytest.raises(BadParameter):
        custom.convert("2024-02-03", None, None)


def test_tuple_type_and_uuid(runner):
    @command()
    @option("--point", type=Tuple([int, int]))
    @option("--id", type=optlyn.UUID)
    def cmd(point, id):
        echo(f"{point} {id}")

    res = runner.invoke(cmd, ["--point", "1", "2", "--id", "12345678-1234-5678-1234-567812345678"])
    assert res.stdout == "(1, 2) 12345678-1234-5678-1234-567812345678\n"


def test_custom_paramtype_subclass_and_function_type(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str):
                return value.upper()
            return value

    def positive(text):
        value = int(text)
        if value <= 0:
            raise ValueError("must be positive")
        return value

    @command()
    @option("--u", type=Upper())
    @option("--p", type=positive)
    def cmd(u, p):
        echo(f"{u} {p}")

    assert runner.invoke(cmd, ["--u", "abc", "--p", "3"]).stdout == "ABC 3\n"
    res = runner.invoke(cmd, ["--p", "-1"])
    assert res.exit_code == 2
    assert "must be positive" in res.stderr


def test_conversion_failure_names_only_that_parameter(runner):
    @command()
    @option("--good", default="x")
    @option("--bad", type=int)
    def cmd(good, bad):
        echo("ran")

    res = runner.invoke(cmd, ["--bad", "q"])
    assert res.exit_code == 2
    assert "--bad" in res.stderr
    assert "--good" not in res.stderr


# ---------------------------------------------------------------------------
# FP-06: groups, nesting, lazy loading
# ---------------------------------------------------------------------------


def test_group_callback_runs_before_child_and_skipped_for_group_help(runner):
    order = []

    @group()
    def cli():
        order.append("group")

    @cli.command()
    def child():
        order.append("child")

    assert runner.invoke(cli, ["child"]).exit_code == 0
    assert order == ["group", "child"]
    order.clear()
    runner.invoke(cli, ["--help"])
    assert order == []


def test_nested_groups_and_skipping_a_middle_name_fails(runner):
    @group()
    def top():
        pass

    @top.group()
    def mid():
        pass

    @mid.command()
    def leaf():
        echo("leaf")

    assert runner.invoke(top, ["mid", "leaf"]).stdout == "leaf\n"
    assert runner.invoke(top, ["leaf"]).exit_code == 2


def test_group_option_must_precede_subcommand(runner):
    @group()
    @option("--g", is_flag=True)
    def cli(g):
        echo(f"g={g}")

    @cli.command()
    @option("--c", is_flag=True)
    def sub(c):
        echo(f"c={c}")

    assert runner.invoke(cli, ["--g", "sub", "--c"]).stdout == "g=True\nc=True\n"
    assert runner.invoke(cli, ["sub", "--g"]).exit_code == 2


def test_invoke_without_command_reports_subcommand_state(runner):
    seen = []

    @group(invoke_without_command=True)
    def cli():
        seen.append(get_current_context().invoked_subcommand)

    @cli.command()
    def sub():
        pass

    runner.invoke(cli, [])
    runner.invoke(cli, ["sub"])
    assert seen == [None, "sub"]


def test_custom_group_lazy_lookup(runner):
    class Lazy(Group):
        def get_command(self, ctx, name):
            if name == "dyn":
                @command()
                def dyn():
                    echo("dynamic")

                return dyn
            return super().get_command(ctx, name)

        def list_commands(self, ctx):
            return ["dyn"]

    cli = Lazy(name="lazy")
    assert runner.invoke(cli, ["dyn"]).stdout == "dynamic\n"
    assert "dyn" in runner.invoke(cli, ["--help"]).stdout


def test_command_collection_unions_sources(runner):
    @group()
    def one():
        pass

    @group()
    def two():
        pass

    @one.command()
    def alpha():
        echo("alpha")

    @two.command()
    def beta():
        echo("beta")

    coll = CommandCollection(name="all", sources=[one, two])
    assert runner.invoke(coll, ["alpha"]).stdout == "alpha\n"
    assert runner.invoke(coll, ["beta"]).stdout == "beta\n"
    assert "alpha" in runner.invoke(coll, ["--help"]).stdout


def test_hidden_command_is_omitted_from_help_but_runnable(runner):
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("secret")

    assert "secret" not in runner.invoke(cli, ["--help"]).stdout
    assert runner.invoke(cli, ["secret"]).stdout == "secret\n"


# ---------------------------------------------------------------------------
# FP-07: context, default map, auto env prefix, forwarding
# ---------------------------------------------------------------------------


class Config:
    pass


def test_pass_obj_and_find_object_up_the_chain(runner):
    @group()
    @pass_obj
    def cli(obj):
        obj.values = ["root"]

    @cli.command()
    @make_pass_decorator(Config, ensure=True)
    def sub(cfg):
        echo(type(cfg).__name__)

    res = runner.invoke(cli, ["sub"], obj=Config())
    assert res.stdout == "Config\n"


def test_pass_context_receives_context(runner):
    @command()
    @pass_context
    def cmd(ctx):
        echo(type(ctx).__name__)

    assert runner.invoke(cmd, []).stdout == "Context\n"


def test_default_map_nests_by_subcommand_and_is_overridden_by_cli(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--name", default="declared")
    @option("--num", type=int, default=0)
    def sub(name, num):
        echo(f"{name} {num}")

    res = runner.invoke(cli, ["sub"], default_map={"sub": {"name": "mapped"}})
    assert res.stdout == "mapped 0\n"
    res = runner.invoke(cli, ["sub", "--name", "cli"], default_map={"sub": {"name": "mapped"}})
    assert res.stdout == "cli 0\n"
    res = runner.invoke(cli, ["sub"], default_map={"other": {"name": "mapped"}})
    assert res.stdout == "declared 0\n"


def test_default_map_string_split_for_multi_value(runner):
    @command()
    @option("--pair", nargs=2)
    def cmd(pair):
        echo(repr(pair))

    res = runner.invoke(cmd, [], default_map={"pair": "a b"})
    assert res.stdout == "('a', 'b')\n"


def test_auto_envvar_prefix_includes_subcommand_names(runner):
    @group()
    def cli():
        pass

    @cli.group()
    def mid():
        pass

    @mid.command()
    @option("--token")
    def leaf(token):
        echo(token)

    res = runner.invoke(cli, ["mid", "leaf"], auto_envvar_prefix="APP", env={"APP_MID_LEAF_TOKEN": "t1"})
    assert res.stdout == "t1\n"


def test_auto_envvar_prefix_can_be_opted_out(runner):
    @command()
    @option("--token", allow_from_autoenv=False)
    def cmd(token):
        echo(str(token))

    res = runner.invoke(cmd, [], auto_envvar_prefix="APP", env={"APP_TOKEN": "t1"})
    assert res.stdout == "None\n"


def test_invoke_and_forward_between_commands(runner):
    @command()
    @option("--x", type=int, default=1)
    def target(x):
        echo(f"target {x}")

    @command()
    @option("--x", type=int, default=5)
    def caller(x):
        ctx = get_current_context()
        ctx.forward(target)
        ctx.invoke(target, x=99)

    assert runner.invoke(caller, []).stdout == "target 5\ntarget 99\n"


def test_resources_closed_at_end_of_invocation(runner):
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            closed.append(True)

    @command()
    def cmd():
        get_current_context().with_resource(Res())
        echo("ran")

    runner.invoke(cmd, [])
    assert closed == [True]


# ---------------------------------------------------------------------------
# FP-08: prompts, confirmation, hidden input
# ---------------------------------------------------------------------------


def test_prompt_option_reads_stdin_when_omitted(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(f"hi {name}")

    res = runner.invoke(cmd, [], input="ann\n")
    assert res.exit_code == 0
    assert res.stdout.endswith("hi ann\n")
    assert "Name" in res.stdout


def test_prompt_with_default_on_empty_answer(runner):
    @command()
    @option("--name", prompt="Who", default="guest")
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, [], input="\n")
    assert res.stdout.endswith("guest\n")


def test_command_line_value_does_not_read_input(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, ["--name", "x"], input="never\n")
    assert res.stdout == "x\n"


def test_prompt_reasks_on_conversion_failure(runner):
    @command()
    @option("--n", prompt=True, type=int)
    def cmd(n):
        echo(n)

    res = runner.invoke(cmd, [], input="abc\n12\n")
    assert res.stdout.strip().splitlines()[-1] == "12"


def test_end_of_input_during_prompt_aborts(runner):
    @command()
    @option("--n", prompt=True)
    def cmd(n):
        echo("ran")

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1
    assert "ran" not in res.stdout


def test_password_option_confirms_pair(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(f"pw={password}")

    res = runner.invoke(cmd, [], input="secret\nsecret\n")
    assert res.exit_code == 0
    assert "pw=secret" in res.stdout
    assert "secret\n" not in res.stdout.replace("pw=secret", "")


def test_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1
    assert "ran" not in res.stdout
    assert runner.invoke(cmd, ["--yes"], input="").stdout == "ran\n"
    assert runner.invoke(cmd, [], input="y\n").stdout.endswith("ran\n")


def test_confirmation_declined_propagates_without_standalone(runner):
    @command()
    @confirmation_option()
    def cmd():
        pass

    res = runner.invoke(cmd, [], input="no\n", standalone_mode=False)
    assert isinstance(res.exception, Abort)


def test_standalone_confirm_and_prompt_helpers(runner):
    @command()
    def cmd():
        if confirm("Sure?"):
            echo("yes-branch")
        else:
            echo("no-branch")
        echo(prompt("Num", type=int, default=2))

    out = runner.invoke(cmd, [], input="Y\n5\n").stdout
    assert "yes-branch" in out and out.endswith("5\n5\n")
    out = runner.invoke(cmd, [], input="n\n\n").stdout
    assert "no-branch" in out and out.endswith("2\n")


# ---------------------------------------------------------------------------
# FP-09: file and path parameters
# ---------------------------------------------------------------------------


def test_file_read_and_write_roundtrip(runner, tmp_path):
    @command()
    @argument("src", type=File("r"))
    @argument("dst", type=File("w"))
    def cmd(src, dst):
        dst.write(src.read().upper())

    with runner.isolated_filesystem(temp_dir=tmp_path):
        with open("in.txt", "w") as f:
            f.write("hello")
        res = runner.invoke(cmd, ["in.txt", "out.txt"])
        assert res.exit_code == 0
        with open("out.txt") as f:
            assert f.read() == "HELLO"


def test_missing_read_file_is_usage_error_identifying_path(runner, tmp_path):
    @command()
    @argument("src", type=File("r"))
    def cmd(src):
        echo("ran")

    with runner.isolated_filesystem(temp_dir=tmp_path):
        res = runner.invoke(cmd, ["nope.txt"])
    assert res.exit_code == 2
    assert "nope.txt" in res.stderr


def test_lazy_write_not_truncated_until_used(runner, tmp_path):
    @command()
    @option("--out", type=File("w"), default=None)
    def cmd(out):
        echo("ran")

    with runner.isolated_filesystem(temp_dir=tmp_path):
        with open("keep.txt", "w") as f:
            f.write("original")
        res = runner.invoke(cmd, ["--out", "keep.txt"])
        assert res.exit_code == 0
        with open("keep.txt") as f:
            assert f.read() == "original"


def test_dash_is_stdout_and_survives_close(runner):
    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        out.write("via dash\n")
        out.close()
        echo("after")

    res = runner.invoke(cmd, ["-"])
    assert res.stdout == "via dash\nafter\n"


def test_dash_reads_stdin(runner):
    @command()
    @argument("src", type=File("r"))
    def cmd(src):
        echo(src.read().strip().upper())

    assert runner.invoke(cmd, ["-"], input="abc\n").stdout == "ABC\n"


def test_path_checks(runner, tmp_path):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        echo(p)

    with runner.isolated_filesystem(temp_dir=tmp_path):
        os.mkdir("adir")
        with open("afile", "w") as f:
            f.write("x")
        assert runner.invoke(cmd, ["afile"]).stdout == "afile\n"
        assert runner.invoke(cmd, ["adir"]).exit_code == 2
        res = runner.invoke(cmd, ["missing"])
        assert res.exit_code == 2
        assert "missing" in res.stderr


def test_path_dash_allowed_is_not_opened(runner):
    @command()
    @argument("p", type=Path(allow_dash=True))
    def cmd(p):
        echo(p)

    assert runner.invoke(cmd, ["-"]).stdout == "-\n"


def test_format_filename_is_printable():
    assert format_filename("plain.txt") == "plain.txt"
    weird = os.fsdecode(b"bad\xff.txt")
    text = format_filename(weird)
    text.encode("utf-8")
    assert text != format_filename("bad.txt")


# ---------------------------------------------------------------------------
# FP-10: chaining
# ---------------------------------------------------------------------------


def test_chained_group_runs_each_subcommand_and_result_callback_gets_list(runner):
    @group(chain=True)
    def cli():
        pass

    results = []

    @cli.result_callback()
    def done(values):
        results.append(values)
        return sum(values)

    @cli.command()
    @argument("n", type=int)
    def add(n):
        return n

    @cli.command()
    @argument("n", type=int)
    def double(n):
        return n * 2

    res = runner.invoke(cli, ["add", "1", "double", "5"], standalone_mode=False)
    assert res.return_value == 11
    assert results == [[1, 10]]


def test_chain_group_refuses_nested_groups():
    @group(chain=True)
    def cli():
        pass

    with pytest.raises(TypeError):
        @group()
        def inner():
            pass

        cli.add_command(inner)


def test_chained_group_without_command_runs_result_callback(runner):
    @group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(values):
        echo(f"values={values}")

    assert runner.invoke(cli, []).stdout == "values=[]\n"


# ---------------------------------------------------------------------------
# FP-11: terminal helpers
# ---------------------------------------------------------------------------


def test_style_and_unstyle_roundtrip():
    styled = style("hi", fg="red", bold=True)
    assert styled.startswith("\x1b[")
    assert unstyle(styled) == "hi"
    assert style("x", fg=(1, 2, 3)) != style("x", fg=(3, 2, 1))
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", fg=200) != style("x", fg=201)


def test_invalid_color_raises():
    with pytest.raises(ValueError):
        style("x", fg="octarine")
    with pytest.raises(ValueError):
        style("x", fg=(1, 2, 300))
    with pytest.raises(ValueError):
        style("x", fg=256)


def test_echo_strips_styles_when_not_a_terminal(runner):
    @command()
    def cmd():
        secho("plain", fg="green")

    assert runner.invoke(cmd, []).stdout == "plain\n"
    assert "\x1b[" in runner.invoke(cmd, [], color=True).stdout


def test_echo_to_stderr(runner):
    @command()
    def cmd():
        echo("oops", err=True)

    res = runner.invoke(cmd, [])
    assert res.stderr == "oops\n"
    assert res.stdout == ""


def test_ascii_stream_does_not_abort_echo():
    import io
    import sys

    class AsciiBuffer(io.TextIOWrapper):
        pass

    raw = io.BytesIO()
    stream = io.TextIOWrapper(raw, encoding="ascii", errors="strict")
    echo("héllo", file=stream)
    stream.flush()
    assert raw.getvalue() == "héllo\n".encode("utf-8")


def test_pager_non_interactive_writes_to_stdout(runner):
    @command()
    def cmd():
        echo_via_pager(iter(["a", "b\n"]))

    res = runner.invoke(cmd, [])
    assert res.stdout == "ab\n"


def test_wrap_text_accepts_any_string_and_respects_width():
    text = "word " * 40
    lines = wrap_text(text, width=20).splitlines()
    assert all(len(line) <= 20 for line in lines)
    assert wrap_text("\x00\xff☃") != ""


def test_app_dir_rules(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    import sys

    if sys.platform.startswith("linux"):
        assert get_app_dir("My  App") == str(tmp_path / "xdg" / "my-app")
        assert get_app_dir("My App", force_posix=True) == str(tmp_path / ".my-app")


def test_progressbar_visits_every_item_without_tty(runner):
    @command()
    def cmd():
        with optlyn.progressbar(range(5), label="work") as bar:
            seen = [item for item in bar]
        echo(seen)

    res = runner.invoke(cmd, [])
    assert "[0, 1, 2, 3, 4]" in res.stdout
    assert "work" in res.stdout


def test_hidden_progressbar_prints_nothing(runner):
    @command()
    def cmd():
        with optlyn.progressbar(range(3), label="quiet", hidden=True) as bar:
            list(bar)

    assert runner.invoke(cmd, []).stdout == ""


def test_pause_does_not_block_when_not_interactive(runner):
    @command()
    def cmd():
        optlyn.pause("continue?")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 0
    assert "continue?" in res.stdout


# ---------------------------------------------------------------------------
# FP-12: shell completion
# ---------------------------------------------------------------------------


def test_completion_suggests_subcommands_and_options(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def build():
        pass

    @cli.command()
    @option("--verbose", is_flag=True, help="chatty")
    def deploy(verbose):
        pass

    names = [i.value for i in suggest(cli, "cli", [], "")]
    assert names == ["build", "deploy"]
    assert [i.value for i in suggest(cli, "cli", ["deploy"], "--ver")] == ["--verbose"]
    assert [i.value for i in suggest(cli, "cli", ["deploy"], "")] == []


def test_completion_choice_filters_by_prefix():
    @command()
    @option("--mode", type=Choice(["fast", "full", "slow"]))
    def cmd(mode):
        pass

    items = suggest(cmd, "cmd", ["--mode"], "f")
    assert [i.value for i in items] == ["fast", "full"]


def test_completion_path_request_kinds():
    from optlyn.paramtypes import Path as P

    @command()
    @argument("d", type=P(file_okay=False))
    def cmd(d):
        pass

    items = suggest(cmd, "cmd", [], "sr")
    assert items[0].type == "path:dir"


def test_completion_source_script_and_unknown_instruction(runner, monkeypatch, capsys):
    from optlyn.completion import handle_completion

    @command()
    def cmd():
        echo("should not run")

    monkeypatch.setenv("_MYTOOL_COMPLETE", "bash_source")
    res = runner.invoke(cmd, [], prog_name="mytool", complete_var="_MYTOOL_COMPLETE")
    assert "should not run" not in res.stdout
    assert "complete" in res.stdout and "mytool" in res.stdout

    monkeypatch.setenv("_MYTOOL_COMPLETE", "tcsh_nope")
    res = runner.invoke(cmd, [], prog_name="mytool", complete_var="_MYTOOL_COMPLETE")
    assert "should not run" not in res.stdout
    assert res.exit_code != 0 or res.stdout == ""


# ---------------------------------------------------------------------------
# FP-13: exit statuses
# ---------------------------------------------------------------------------


def test_author_clean_stop_status(runner):
    @command()
    def cmd():
        echo("before")
        get_current_context().exit(4)
        echo("after")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 4
    assert res.stdout == "before\n"


def test_author_abort_status(runner):
    @command()
    def cmd():
        get_current_context().abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted" in res.stderr


def test_exit_statuses_are_distinct(runner):
    @group(invoke_without_command=False)
    def cli():
        pass

    @cli.command()
    def ok():
        pass

    assert runner.invoke(cli, ["--help"]).exit_code == 0
    assert runner.invoke(cli, []).exit_code == 2
    assert runner.invoke(cli, ["ok"]).exit_code == 0


def test_standalone_off_propagates_usage_error(runner):
    @command()
    @option("--n", type=int)
    def cmd(n):
        pass

    res = runner.invoke(cmd, ["--n", "x"], standalone_mode=False)
    assert isinstance(res.exception, BadParameter)


# ---------------------------------------------------------------------------
# FP-14: in-process runner
# ---------------------------------------------------------------------------


def test_runner_captures_stdout_and_stderr_separately(runner):
    @command()
    def cmd():
        echo("out")
        echo("err", err=True)

    res = runner.invoke(cmd, [])
    assert res.stdout == "out\n"
    assert res.stderr == "err\n"
    assert res.output == "out\nerr\n"
    assert res.stdout_bytes == b"out\n"


def test_runner_exception_is_inspectable_and_can_propagate(runner):
    @command()
    def cmd():
        raise RuntimeError("boom")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert isinstance(res.exception, RuntimeError)
    with pytest.raises(RuntimeError):
        runner.invoke(cmd, [], catch_exceptions=False)


def test_runner_env_none_unsets(runner, monkeypatch):
    monkeypatch.setenv("UNSET_ME", "value")

    @command()
    @option("--v", envvar="UNSET_ME", default="dflt")
    def cmd(v):
        echo(v)

    assert runner.invoke(cmd, [], env={"UNSET_ME": None}).stdout == "dflt\n"


def test_isolated_filesystem_removed_without_parent():
    runner = CliRunner()
    cwd = os.getcwd()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == path
        open("inside.txt", "w").close()
    assert os.getcwd() == cwd
    assert not os.path.exists(path)


def test_isolated_filesystem_kept_with_parent(tmp_path):
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path) as path:
        open("keep.txt", "w").close()
    assert os.path.exists(os.path.join(path, "keep.txt"))


def test_invoke_string_args_and_input_echo(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, "", input="zed\n")
    assert "zed" in res.output
    res2 = runner.invoke(cmd, "--name bob")
    assert res2.stdout == "bob\n"


def test_hidden_input_not_echoed(runner):
    @command()
    @option("--pw", prompt=True, hide_input=True)
    def cmd(pw):
        echo("got")

    res = runner.invoke(cmd, [], input="topsecret\n")
    assert "topsecret" not in res.output
    assert res.stdout.endswith("got\n")


# ---------------------------------------------------------------------------
# Declaration-time checks and package surface
# ---------------------------------------------------------------------------


def test_argument_declaration_rules():
    with pytest.raises(ValueError):
        argument("x", nargs=0)(lambda: None)
    with pytest.raises(ValueError):
        argument("x", deprecated=True)(lambda: None)
    argument("x", default="d", deprecated=True)(lambda: None)


def test_option_deprecated_with_prompt_refused():
    with pytest.raises(ValueError):
        option("--x", deprecated=True, prompt=True)(lambda: None)


def test_package_exports_contract_names():
    for name in [
        "command", "group", "option", "argument", "help_option", "version_option",
        "custom_version_option", "password_option", "confirmation_option", "pass_context",
        "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection", "Context",
        "Option", "Parameter", "ParamType", "BadParameter", "Abort", "STRING", "INT", "FLOAT",
        "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
        "File", "Path", "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
        "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
        "get_app_dir", "get_current_context", "format_filename", "open_file",
    ]:
        assert hasattr(optlyn, name), name
    from optlyn.testing import CliRunner as CR
    from optlyn.formatting import wrap_text as wt
    assert CR and wt
