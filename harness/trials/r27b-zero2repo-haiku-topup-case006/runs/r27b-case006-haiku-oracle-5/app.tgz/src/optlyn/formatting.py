"""Text wrapping and help-page layout helpers (FP-02, FP-11)."""

from __future__ import annotations

import re
import textwrap

DEFAULT_WIDTH = 80


def _paragraphs(text: str):
    """Yield (lines, rewrap) pairs for each blank-line separated paragraph."""
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n")):
        lines = block.split("\n")
        if not any(line.strip() for line in lines):
            continue
        if lines[0] == "\b" or lines[0].strip() == "\b":
            # Verbatim paragraph: keep its line breaks, drop the backspace line.
            kept = [line for line in lines[1:]]
            yield kept, False
        else:
            yield lines, True


# spec: N-000133..N-000138 (rewrap; backspace paragraphs), N-000680 (width cap, CF-000087)
def wrap_text(
    text,
    width: int = DEFAULT_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns. Accepts any string.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace is kept line-for-line and that line is removed.
    """
    if text is None:
        return ""
    if not isinstance(text, str):
        text = str(text)
    width = max(int(width), 1)
    out = []
    for lines, rewrap in _paragraphs(text):
        if rewrap:
            joined = " ".join(line.strip() for line in lines if line.strip())
            wrapped = textwrap.fill(
                joined,
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=True,
                break_on_hyphens=False,
            )
            out.append(wrapped)
        else:
            out.append("\n".join(initial_indent + line.rstrip() for line in lines))
    return "\n\n".join(out)


def first_sentence(text: str) -> str:
    """The first sentence of the first paragraph of ``text``."""
    if not text:
        return ""
    para = text.strip().split("\n\n", 1)[0]
    para = " ".join(line.strip() for line in para.split("\n")).strip()
    match = re.search(r"[.!?](?=\s|$)", para)
    return para[: match.end()] if match else para


# spec: N-000122..N-000124 and N-000843; CF-000063
def short_help_text(text: str, limit: int = 45) -> str:
    """Default short help: the first sentence, cut with ``...`` at ``limit`` characters."""
    sentence = first_sentence(text)
    if len(sentence) > limit:
        return sentence[: limit - 3].rstrip() + "..."
    return sentence


# spec: N-000115 / N-000853; CF-000156
def truncate_at_formfeed(text: str | None) -> str | None:
    """A form feed truncates a docstring: text after it is omitted from the help page."""
    if text is None:
        return None
    return text.split("\f", 1)[0]


def format_rows(rows, width: int, indent: int = 2, col_max: int = 30) -> str:
    """Two-column layout: ``rows`` is a list of (first, second) strings."""
    if not rows:
        return ""
    first_width = min(max(len(first) for first, _ in rows), col_max)
    lines = []
    for first, second in rows:
        pad = " " * indent
        second_width = max(width - indent - first_width - 2, 20)
        if len(first) > first_width:
            lines.append(f"{pad}{first}")
            body_indent = " " * (indent + first_width + 2)
            if second:
                lines.append(wrap_text(second, width=width, initial_indent=body_indent, subsequent_indent=body_indent).lstrip())
            continue
        wrapped = wrap_text(second, width=second_width) if second else ""
        body = wrapped.split("\n")
        lines.append(f"{pad}{first.ljust(first_width)}  {body[0]}".rstrip())
        for extra in body[1:]:
            lines.append(" " * (indent + first_width + 2) + extra)
    return "\n".join(lines)
