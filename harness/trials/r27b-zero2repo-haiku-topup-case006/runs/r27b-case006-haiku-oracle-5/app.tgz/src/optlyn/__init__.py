"""Optlyn: composable command line interfaces with as little code as necessary.

The package root exports the declaration helpers, classes, parameter types and
terminal helpers listed in the Interface Contract (section 1).
"""

from .context import Context, ParameterSource, get_current_context
from .core import (
    Argument,
    Command,
    CommandCollection,
    Group,
    Option,
    Parameter,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, OptlynError, UsageError
from .formatting import wrap_text
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, get_app_dir, open_file

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Parameter",
    "ParamType",
    "BadParameter",
    "Abort",
    # exceptions beyond the contract's list
    "UsageError",
    "OptlynError",
    "ParameterSource",
    # parameter types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
    "wrap_text",
]
