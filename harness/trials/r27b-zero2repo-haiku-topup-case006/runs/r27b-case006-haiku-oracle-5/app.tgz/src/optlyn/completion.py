"""Shell completion (section 8 of the Interface Contract; FP-12).

Two instruction families are selected through the ``_<PROG>_COMPLETE``
environment variable:

* ``<shell>_source`` prints the registration script for ``<shell>``;
* ``<shell>_complete`` prints suggestions for the incomplete token.

Path requests are emitted as ``__optlyn_path__:file:<token>`` (any path, or
files) or ``__optlyn_path__:dir:<token>`` (directories only).
"""

from __future__ import annotations

import os
import sys

from .context import Context
from .core import Argument, Group, Option
from .paramtypes import CompletionItem

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_MARKER = "__optlyn_path__"


# spec: N-000689..N-000714 (FP-12), N-001013..N-001035 (section 8); N-000714 unknown instruction exits non-success
def handle_completion(cli, prog_name: str, instruction: str):
    """Run a completion instruction. Returns an exit status, or None when not a completion instruction."""
    if instruction.endswith("_source"):
        shell = instruction[: -len("_source")]
        if shell not in SHELLS:
            _fail(f"unknown completion shell {shell!r}")
            return 1
        sys.stdout.write(_source_script(shell, prog_name, _var_name(prog_name)) + "\n")
        sys.stdout.flush()
        return 0
    if instruction.endswith("_complete"):
        shell = instruction[: -len("_complete")]
        if shell not in SHELLS:
            _fail(f"unknown completion shell {shell!r}")
            return 1
        args, incomplete = _completion_input(shell)
        lines = [_format(item, shell) for item in suggest(cli, prog_name, args, incomplete)]
        if lines:
            sys.stdout.write("\n".join(lines) + "\n")
        sys.stdout.flush()
        return 0
    _fail(f"unrecognized completion instruction {instruction!r}")
    return 1


def _fail(message: str) -> None:
    sys.stderr.write(f"Error: {message}\n")
    sys.stderr.flush()


def _var_name(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def _completion_input(shell: str):
    words = os.environ.get("COMP_WORDS", "").split(" ")
    cword_raw = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = cword_raw
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        cword = int(cword_raw) if cword_raw != "" else len(words)
    except ValueError:
        cword = len(words)
    args = words[1:cword]
    incomplete = words[cword] if 0 <= cword < len(words) else ""
    return args, incomplete


def _format(item: CompletionItem, shell: str) -> str:
    if item.type.startswith("path:"):
        kind = item.type.split(":", 1)[1]
        return f"{PATH_MARKER}:{kind}:{item.value}"
    if shell in ("zsh", "fish") and item.help:
        return f"{item.value}\t{item.help}"
    return item.value


def _option_takes_value(param: Option) -> bool:
    return not (param.is_flag or param.count)


# spec: N-000694..N-000713 (suggestions); CF-000161 (options only after a dash)
def suggest(cli, prog_name: str, args, incomplete: str):
    """Return the list of CompletionItem for the given arguments and incomplete token."""
    ctx = Context(cli, info_name=prog_name, resilient_parsing=True)
    cmd = cli
    positional_seen = 0
    pending_option = None
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        params = cmd.get_params(ctx)
        if tok == "--":
            continue
        if pending_option is not None:
            pending_option = None
            continue
        if tok.startswith("-") and tok != "-":
            match = next((p for p in params if isinstance(p, Option) and tok in p.all_names), None)
            if match is not None and _option_takes_value(match) and not match.optional_value:
                pending_option = match
            continue
        if isinstance(cmd, Group):
            name, sub = cmd.resolve_command(ctx, tok)
            if sub is not None:
                ctx = Context(sub, parent=ctx, info_name=name, resilient_parsing=True)
                cmd = sub
                positional_seen = 0
                continue
            break
        positional_seen += 1

    params = cmd.get_params(ctx)
    options = [p for p in params if isinstance(p, Option) and not p.hidden]

    if pending_option is not None:
        return _value_items(ctx, pending_option, incomplete)

    if incomplete.startswith("-"):
        items = []
        for p in options:
            for name in p.all_names:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items

    if isinstance(cmd, Group):
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str() or None))
        return items

    arguments = [p for p in params if isinstance(p, Argument)]
    if positional_seen < len(arguments):
        arg = arguments[positional_seen]
        return _param_items(ctx, arg, incomplete)
    if arguments and arguments[-1].variadic:
        return _param_items(ctx, arguments[-1], incomplete)
    return []


def _value_items(ctx, param, incomplete):
    return _param_items(ctx, param, incomplete)


def _param_items(ctx, param, incomplete):
    if param.shell_complete is not None:
        result = param.shell_complete(ctx, param, incomplete)
    else:
        result = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for entry in result or []:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif hasattr(entry, "value"):
            items.append(CompletionItem(entry.value, help=getattr(entry, "help", None), type=getattr(entry, "type", "plain")))
        else:
            items.append(CompletionItem(str(entry)))
    return items


# ---------------------------------------------------------------------------
# Registration scripts
# ---------------------------------------------------------------------------


def _source_script(shell: str, prog: str, var: str) -> str:
    func = "_" + prog.replace("-", "_") + "_completion"
    complete_instr = f"{shell}_complete"
    if shell == "bash":
        return f"""{func}() {{
    local IFS=$'\\n'
    local line
    COMPREPLY=()
    for line in $(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}={complete_instr} {prog} 2>/dev/null); do
        case "$line" in
            {PATH_MARKER}:file:*) COMPREPLY+=( $(compgen -f -- "${{line#*:*:}}") ) ;;
            {PATH_MARKER}:dir:*)  COMPREPLY+=( $(compgen -d -- "${{line#*:*:}}") ) ;;
            *) COMPREPLY+=( "$line" ) ;;
        esac
    done
    return 0
}}
complete -o default -F {func} {prog}"""
    if shell == "zsh":
        return f"""#compdef {prog}
{func}() {{
    local -a values
    local line
    values=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}={complete_instr} {prog} 2>/dev/null)}}")
    for line in $values; do
        compadd -- "${{line%%$'\\t'*}}"
    done
}}
compdef {func} {prog}"""
    if shell == "fish":
        return (
            f"complete --command {prog} --no-files --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}={complete_instr} {prog} 2>/dev/null)'\n"
            f"complete --command {prog} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}={complete_instr} {prog} 2>/dev/null)' --force-files"
        )
    # powershell
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:{var} = '{complete_instr}'
    & '{prog}' | ForEach-Object {{
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }}
    Remove-Item Env:\\{var} -ErrorAction SilentlyContinue
}}"""
