"""Parameter types: conversion of command line text into Python values (FP-05, FP-09)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import uuid as _uuid

from .exceptions import BadParameter
from .utils import open_file


class CompletionItem:
    """A suggestion with optional help. ``type`` is ``"plain"`` for ordinary values."""

    __slots__ = ("value", "help", "type")

    def __init__(self, value, help=None, type="plain") -> None:
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param) -> str | None:
        return self.name.upper()

    def split_envvar_value(self, value: str) -> list[str]:
        return value.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self) -> str:
        return self.name.upper()


def _norm(value: str, ctx, case_sensitive: bool = True) -> str:
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    if func is not None:
        value = func(value)
    if not case_sensitive:
        value = value.casefold()
    return value


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    """Pass-through: the raw token is delivered unchanged."""

    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class FuncParamType(ParamType):
    """Adapter for a plain conversion function ``f(token) -> value`` that raises ValueError to refuse."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").upper()

    def convert(self, value, param, ctx):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


# spec: N-000348 vs N-000937 (CF-000163: case-sensitive default), N-000350..N-000352
class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._names = [m.name for m in choices]
        else:
            self.choices = list(choices)
            self._names = [str(c) for c in self.choices]

    def get_metavar(self, param) -> str:
        return "[" + "|".join(self._names) + "]"

    def convert(self, value, param, ctx):
        for original in self.choices:
            if value is original:
                return original
        if not isinstance(value, str):
            self.fail(f"{value!r} is not one of {self._quoted()}.", param, ctx)
        wanted = _norm(value, ctx, self.case_sensitive)
        for choice, name in zip(self.choices, self._names):
            if _norm(name, ctx, self.case_sensitive) == wanted:
                return choice
        self.fail(f"{value!r} is not one of {self._quoted()}.", param, ctx)

    def _quoted(self) -> str:
        return ", ".join(repr(n) for n in self._names)

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(n) for n in self._names if n.startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")


# spec: N-000354 vs N-000939 (CF-000158), N-000356 (replace, CF-000136)
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        # An author list replaces the defaults (it does not extend them).
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value)
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text.strip(), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.", param, ctx)


# spec: N-000361 / N-000362 (CF-000016, CF-000092: adjacent integer under clamp)
class _RangeMixin:
    def _check_range(self, value, param, ctx, min_, max_, min_open, max_open, clamp):
        below = min_ is not None and (value <= min_ if min_open else value < min_)
        above = max_ is not None and (value >= max_ if max_open else value > max_)
        if not below and not above:
            return value
        if clamp:
            if below:
                if min_open:
                    return min_ + 1 if isinstance(min_, int) else min_
                return min_
            if max_open:
                return max_ - 1 if isinstance(max_, int) else max_
            return max_
        self.fail(f"{value!r} is not in the range {self._range_text(min_, max_, min_open, max_open)}.", param, ctx)

    @staticmethod
    def _range_text(min_, max_, min_open, max_open) -> str:
        lo = "" if min_ is None else f"{'>' if min_open else '>='}{min_}"
        hi = "" if max_ is None else f"{'<' if max_open else '<='}{max_}"
        return " and ".join(p for p in (lo, hi) if p) or "(unbounded)"


class IntRange(_RangeMixin, IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = IntParamType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx, self.min, self.max, self.min_open, self.max_open, self.clamp)


# spec: N-000364 / N-000381 / N-000943 (CF-000100, CF-000107: refuse clamp with open bound)
class FloatRange(_RangeMixin, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("FloatRange cannot clamp when a bound is open.")
        if min is not None and max is not None and min > max:
            raise ValueError("FloatRange min is greater than max.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = FloatParamType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx, self.min, self.max, self.min_open, self.max_open, self.clamp)


def to_param_type(ty):
    """Turn a declared type (ParamType, builtin Python type, or function) into a ParamType."""
    if ty is None or isinstance(ty, ParamType):
        return ty
    if ty is str:
        return STRING
    if ty is bool:
        return BOOL
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is _uuid.UUID:
        return UUID
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"unsupported parameter type {ty!r}")


def infer_type(default):
    """Infer a parameter type from a default value (FP-05)."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, _uuid.UUID):
        return UUID
    if isinstance(default, tuple) and default:
        return Tuple([infer_type(d) for d in default])
    if isinstance(default, list) and default:
        return infer_type(default[0])
    return STRING


class Tuple(ParamType):
    """Fixed-length product of inner types. Delivers a tuple."""

    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [to_param_type(t) for t in types]
        self.name = "<" + ", ".join(t.name for t in self.types) + ">"

    def convert(self, value, param, ctx):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def get_metavar(self, param) -> str:
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)


class File(ParamType):
    """Opens a file. ``-`` is standard input (reading) or standard output (writing)."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        # Reading opens immediately; writing is lazy unless the author says otherwise.
        self.lazy = (mode in ("w", "wb")) if lazy is None else bool(lazy)

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
            )
        except Exception as e:  # FileError or OSError from an eager open
            message = getattr(e, "message", None) or str(e)
            self.fail(f"'{value}': {message}", param, ctx)

    def split_envvar_value(self, value: str) -> list[str]:
        return value.split(os.pathsep)


# spec: N-000547..N-000558 (path checks); N-000947 (resolve expands ~, CF-000160)
class Path(ParamType):
    """A filesystem path (not an open file). Optional checks are selectable."""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param, ctx):
        if hasattr(value, "__fspath__") or isinstance(value, (str, bytes)):
            raw = os.fsdecode(value) if isinstance(value, bytes) else str(os.fspath(value))
        else:
            raw = str(value)
        if self.allow_dash and raw == "-":
            return self._result("-")
        path = raw
        if self.resolve_path:
            path = os.path.realpath(os.path.expanduser(path))
        if self.exists and not os.path.exists(path):
            self.fail(f"'{raw}' does not exist.", param, ctx)
        if os.path.exists(path):
            if os.path.isdir(path) and not self.dir_okay:
                self.fail(f"'{raw}' is a directory.", param, ctx)
            if os.path.isfile(path) and not self.file_okay:
                self.fail(f"'{raw}' is a file.", param, ctx)
            if self.readable and not os.access(path, os.R_OK):
                self.fail(f"'{raw}' is not readable.", param, ctx)
            if self.writable and not os.access(path, os.W_OK):
                self.fail(f"'{raw}' is not writable.", param, ctx)
            if self.executable and not os.access(path, os.X_OK):
                self.fail(f"'{raw}' is not executable.", param, ctx)
        return self._result(path)

    def _result(self, path):
        if self.path_type is None:
            return path
        if self.path_type is str:
            return path
        return self.path_type(path)

    def split_envvar_value(self, value: str) -> list[str]:
        return value.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=f"path:{kind}")]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()
