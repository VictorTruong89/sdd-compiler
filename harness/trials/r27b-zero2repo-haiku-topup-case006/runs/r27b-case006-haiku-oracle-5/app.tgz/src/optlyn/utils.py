"""File, stream and filesystem helpers shared by the parameter types and terminal helpers."""

from __future__ import annotations

import io
import os
import re
import sys
import tempfile

from .exceptions import FileError


class NonClosingStream:
    """Proxy for a standard stream. Closing it only flushes; the real stream stays open."""

    def __init__(self, stream) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_stream"), name)

    def __iter__(self):
        return iter(object.__getattribute__(self, "_stream"))

    def close(self) -> None:
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


def _std_stream(name: str, binary: bool, encoding=None, errors="strict"):
    stream = getattr(sys, name)
    if binary:
        buf = getattr(stream, "buffer", None)
        if buf is None:
            buf = io.BytesIO()
        return NonClosingStream(buf)
    if encoding:
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            wrapper = io.TextIOWrapper(buf, encoding=encoding, errors=errors, line_buffering=True)
            # Keep the real buffer open: the wrapper must not own it.
            wrapper.close = lambda: wrapper.flush()  # type: ignore[assignment]
            return NonClosingStream(wrapper)
    return NonClosingStream(stream)


class LazyFile:
    """A file that is opened on first I/O rather than when created."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False) -> None:
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._file = None
        self._tmp_name = None

    def _open(self):
        if self._file is not None:
            return self._file
        writing = any(c in self._mode for c in "wax+")
        binary = "b" in self._mode
        kwargs = {} if binary else {"encoding": self._encoding, "errors": self._errors}
        try:
            if self._atomic and writing:
                directory = os.path.dirname(os.path.abspath(self._filename))
                fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
                os.close(fd)
                self._tmp_name = tmp
                self._file = AtomicFile(open(tmp, self._mode, **kwargs), tmp, self._filename)
            else:
                self._file = open(self._filename, self._mode, **kwargs)
        except OSError as e:
            raise FileError(str(self._filename), e.strerror or str(e)) from e
        return self._file

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self) -> None:
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class AtomicFile:
    """Writes to a temporary sibling and replaces the target when closed."""

    def __init__(self, f, tmp_name, target) -> None:
        self._f = f
        self._tmp = tmp_name
        self._target = target
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is None:
            self.close()
        else:
            self._closed = True
            self._f.close()
            try:
                os.remove(self._tmp)
            except OSError:
                pass


# spec: N-000528..N-000590 (open helper, dash rule, lazy and atomic writes)
def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-``.

    The result can be used as a context manager. Standard streams are never
    closed by the returned object. Reading opens at once; writing may be lazy.
    """
    if mode not in ("r", "w", "rb", "wb"):
        raise ValueError(f"unsupported mode {mode!r}")
    if filename == "-":
        if "r" in mode:
            return _std_stream("stdin", "b" in mode, encoding, errors)
        return _std_stream("stdout", "b" in mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    writing = "w" in mode
    if atomic and writing:
        return LazyFile(filename, mode, encoding, errors, atomic)._open()
    try:
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as e:
        raise FileError(str(filename), e.strerror or str(e)) from e


# spec: N-000528..N-000531 (filename formatting)
def format_filename(filename, shorten: bool = False) -> str:
    """Return printable text for a filename that may not be valid Unicode."""
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


# spec: N-000676 / N-001005; CF-000129 (XDG_CONFIG_HOME when set)
def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Per-user configuration directory for an application."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)
