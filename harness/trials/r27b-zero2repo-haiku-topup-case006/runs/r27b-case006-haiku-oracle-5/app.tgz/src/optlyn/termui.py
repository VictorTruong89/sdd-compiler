"""Terminal helpers: echo, styling, prompts, pager, progress bars, editor and launch (FP-08, FP-11)."""

from __future__ import annotations

import contextlib
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from .context import get_current_context
from .exceptions import Abort
from .formatting import wrap_text  # noqa: F401  (re-exported from termui for convenience)
from .utils import format_filename, get_app_dir, open_file  # noqa: F401

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLORS = {
    "black": 0, "red": 1, "green": 2, "yellow": 3, "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
    "bright_black": 60, "bright_red": 61, "bright_green": 62, "bright_yellow": 63,
    "bright_blue": 64, "bright_magenta": 65, "bright_cyan": 66, "bright_white": 67,
}

_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def unstyle(text: str) -> str:
    """Remove ANSI style sequences; other text is untouched."""
    return _ANSI_RE.sub("", text)


def _color_codes(color, background: bool) -> list[str]:
    if isinstance(color, bool) or color is None:
        raise ValueError(f"invalid color {color!r}")
    if isinstance(color, str):
        if color == "reset":
            return [str(49 if background else 39)]
        if color not in _COLORS:
            raise ValueError(f"unknown color {color!r}")
        return [str(_named(color, background))]
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"color index out of range: {color}")
        return [("48" if background else "38"), "5", str(color)]
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return [("48" if background else "38"), "2", *(str(c) for c in color)]
    raise ValueError(f"invalid color {color!r}")


def _named(color: str, background: bool) -> int:
    code = _COLORS[color]
    if color.startswith("bright_"):
        return (100 if background else 90) + code - 60
    return (40 if background else 30) + code


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences. An invalid color raises ValueError."""
    codes: list[str] = []
    if fg is not None:
        codes += _color_codes(fg, False)
    if bg is not None:
        codes += _color_codes(bg, True)
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in flags.items():
        if on is not None:
            codes.append(str(_SWITCHES[name]) if on else str(_SWITCHES[name] + 20))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + str(text) + suffix


def _current_color_setting():
    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _should_color(stream, color) -> bool:
    if color is None:
        color = _current_color_setting()
    if color is not None:
        return bool(color)
    return _isatty(stream)


def _isatty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def _write_text(stream, text: str) -> None:
    try:
        stream.write(text)
    except UnicodeEncodeError:
        # Misconfigured (ASCII) stream: write the UTF-8 bytes instead of failing.
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()
        else:
            stream.write(text.encode("ascii", "backslashreplace").decode("ascii"))


def _resolve_stream(file, err):
    if file is not None:
        return file
    return sys.stderr if err else sys.stdout


# spec: N-000812..N-000821 (channels), N-000803 family; FP-11 echo: ASCII fallback, style stripping
def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Write text (or bytes) to stdout, stderr or ``file``. Styles are stripped unless colour applies."""
    stream = _resolve_stream(file, err)
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(bytes(message))
            if nl:
                buf.write(b"\n")
            buf.flush()
        else:
            _write_text(stream, bytes(message).decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if not _should_color(stream, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(stream, text)
    stream.flush()


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    """``echo`` of ``style(message, **styles)``."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive() -> bool:
    """A session is interactive when standard input or standard output is a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _pager_command():
    cmd = os.environ.get("PAGER")
    return shlex.split(cmd) if cmd else None


def echo_via_pager(text_or_generator, color=None) -> None:
    """Show long text through the pager when interactive; otherwise write it to stdout."""
    if callable(text_or_generator) and not isinstance(text_or_generator, (str, bytes)):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    cmd = _pager_command() if is_interactive() else None
    if cmd is None:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            data = chunk if isinstance(chunk, str) else chunk.decode("utf-8", "replace")
            if not (color or False):
                data = unstyle(data)
            proc.stdin.write(data.encode("utf-8", "replace"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Context manager yielding a writable text stream that goes through the pager when interactive."""
    cmd = _pager_command() if is_interactive() else None
    if cmd is None:
        from .utils import NonClosingStream

        yield NonClosingStream(sys.stdout)
        return
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


class ProgressBar:
    """Progress over an iterable (or a known length). Visits every item."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.file = file
        self.pos = 0
        self.start = time.monotonic()
        self.options = options
        self._tty = (not hidden) and _isatty(file or sys.stdout)
        if not hidden and not self._tty and label:
            echo(label, file=file)

    def _render(self) -> None:
        if not self._tty:
            return
        stream = self.file or sys.stdout
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 30)
            bar = "#" * filled + "-" * (30 - filled)
            eta = ""
            if self.pos:
                elapsed = time.monotonic() - self.start
                remaining = elapsed / self.pos * (self.length - self.pos)
                eta = f" eta {int(remaining)}s"
            text = f"\r{self.label + ' ' if self.label else ''}[{bar}] {self.pos}/{self.length}{eta}"
        else:
            text = f"\r{self.label + ' ' if self.label else ''}{self.pos}"
        _write_text(stream, text)
        stream.flush()

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def finish(self) -> None:
        if self._tty:
            _write_text(self.file or sys.stdout, "\n")


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(prompt_text: str, hide_input: bool) -> str:
    """Read one line from standard input, echoing it into captured output when not a terminal."""
    stream = sys.stdout
    _write_text(stream, prompt_text)
    stream.flush()
    stdin = sys.stdin
    if hide_input and _isatty(stdin):
        import getpass

        return getpass.getpass("", stream=stream)
    if hasattr(stdin, "_prompting"):
        stdin._prompting = True
    try:
        line = stdin.readline()
    finally:
        if hasattr(stdin, "_prompting"):
            stdin._prompting = False
    if line == "" or line is None:
        raise EOFError
    value = line.rstrip("\r\n")
    if not _isatty(stdin) and not hide_input:
        _write_text(stream, value + "\n")
        stream.flush()
    elif hide_input and not _isatty(stdin):
        _write_text(stream, "\n")
        stream.flush()
    return value


# spec: N-000484..N-000527 (prompts), N-000520 (re-ask on conversion failure; CF-000159)
def prompt(
    text,
    default=None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
):
    """Ask for a value. Re-asks on conversion failure; end of input aborts."""
    from .paramtypes import STRING, to_param_type

    if type is None:
        from .paramtypes import infer_type

        ptype = infer_type(default) if default is not None else STRING
    else:
        ptype = to_param_type(type)
    if ptype is None:
        ptype = STRING
    shown = ""
    if default is not None and show_default:
        shown_default = default if isinstance(default, str) else (
            ", ".join(str(d) for d in default) if isinstance(default, (tuple, list)) else str(default)
        )
        shown = f" [{shown_default}]"
    text = _strip_for_prompt(text)
    while True:
        try:
            value = _read_line(f"{text}{shown}{prompt_suffix}", hide_input)
        except EOFError:
            raise Abort() from None
        if value == "" and default is not None:
            return default
        try:
            converted = ptype.convert(value, None, None) if value_proc is None else value_proc(value)
        except Exception as e:  # BadParameter and friends: re-ask
            message = getattr(e, "message", None) or str(e)
            echo(f"Error: {message}", err=True)
            continue
        if confirmation_prompt:
            try:
                second = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input)
            except EOFError:
                raise Abort() from None
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return converted


def _strip_for_prompt(text: str) -> str:
    return text if _isatty(sys.stdout) else unstyle(text)


# spec: N-000484..N-000527 (confirm), FP-13 abort class
def confirm(text, default: bool = False, abort: bool = False, prompt_suffix: str = ": ", show_default: bool = True, err: bool = False) -> bool:
    """Yes/no question. Empty answer takes ``default``. End of input aborts."""
    suffix = " [Y/n]" if default else " [y/N]"
    if not show_default:
        suffix = ""
    text = _strip_for_prompt(text)
    while True:
        try:
            answer = _read_line(f"{text}{suffix}{prompt_suffix}", False).strip().lower()
        except EOFError:
            raise Abort() from None
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal (not from a piped standard input)."""
    tty = None
    try:
        tty = open("/dev/tty", "rb", buffering=0)
    except OSError:
        tty = None
    try:
        if tty is None:
            ch = sys.stdin.read(1)
            if ch == "":
                raise EOFError
        else:
            import termios
            import tty as ttymod

            fd = tty.fileno()
            old = termios.tcgetattr(fd)
            try:
                ttymod.setraw(fd)
                raw = os.read(fd, 1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            if raw == b"":
                raise EOFError
            ch = raw.decode("utf-8", "replace")
    finally:
        if tty is not None:
            tty.close()
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch == "\x04":
        raise EOFError
    if echo:
        _write_text(sys.stdout, ch)
        sys.stdout.flush()
    return ch


# spec: N-000663 / N-000687; CF-000128
def pause(info=None, err: bool = False) -> None:
    """Print a message and wait for a key in interactive sessions. Never blocks otherwise."""
    message = info if info is not None else "Press any key to continue..."
    echo(message, err=err)
    if is_interactive():
        try:
            getchar()
        except KeyboardInterrupt:
            raise Abort() from None
        except EOFError:
            pass


def edit(text=None, editor=None, env=None, require_save: bool = True, extension: str = ".txt", filename=None):
    """Open an editor. Returns the saved text (or None), or None when ``filename`` is given."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or (
            "notepad" if sys.platform.startswith("win") else "vi"
        )
    cmd = shlex.split(editor) if isinstance(editor, str) else list(editor)
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(cmd + [os.fspath(filename)], env=run_env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            if text:
                handle.write(text)
        before = text or ""
        subprocess.call(cmd + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
        if require_save and result == before:
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def launch(url, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or path with the default application. Returns the opener's status."""
    target = os.fspath(url) if not isinstance(url, str) else url
    if sys.platform.startswith("win"):
        os.startfile(target)  # type: ignore[attr-defined]
        return 0
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    args = [opener]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(target)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the terminal. Does nothing when not connected to a terminal."""
    if _isatty(sys.stdout):
        _write_text(sys.stdout, "\033[2J\033[H")
        sys.stdout.flush()


__all__ = [
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "format_filename", "open_file", "is_interactive",
]
