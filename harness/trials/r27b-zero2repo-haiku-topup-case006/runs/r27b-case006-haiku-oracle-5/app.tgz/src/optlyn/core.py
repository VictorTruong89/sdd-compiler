"""Commands, groups, parameters, parsing and dispatch (FP-01 .. FP-07, FP-10, FP-13).

Each parse follows the same order: scan tokens into raw occurrences, assign
positional arguments, run eager parameters, then resolve every other
parameter from its sources (command line, environment, prompt, default map,
declared default), converting and running parameter callbacks as it goes,
and finally run the command callback.
"""

from __future__ import annotations

import functools
import inspect
import os
import sys
from importlib import metadata as _metadata

from . import termui
from .context import CHAINED_SUBCOMMAND, UNSET, Context, ParameterSource, get_current_context
from .exceptions import (
    Abort,
    BadOptionUsage,
    BadArgumentUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import format_rows, short_help_text, truncate_at_formfeed, wrap_text
from .paramtypes import BOOL, INT, STRING, Choice, Tuple, infer_type, to_param_type

PREFIX_CHARS = ("-", "/", "+")
_TRUE_TEXT = {"true", "1", "yes", "on", "t", "y"}
_FALSE_TEXT = {"false", "0", "no", "off", "f", "n"}

__all__ = [
    "Command",
    "Group",
    "CommandCollection",
    "Parameter",
    "Option",
    "Argument",
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
]


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------


def _parse_decls(decls):
    """Split declarations into (flag names, secondary flag names, destination)."""
    opts: list[str] = []
    secondary: list[str] = []
    dest = None
    for decl in decls:
        if not decl:
            continue
        if decl[0] in PREFIX_CHARS and decl.strip("".join(PREFIX_CHARS)) != "":
            if "/" in decl[1:] and decl[0] != "/":
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        elif dest is None:
            dest = decl
        else:
            raise ValueError(f"unexpected parameter declaration {decl!r}")
    return opts, secondary, dest


def _infer_dest(opts, dest_decl) -> str:
    if dest_decl is not None:
        return dest_decl
    names = list(opts)
    longs = [n for n in names if n.startswith("--")]
    pick = longs[0] if longs else (names[0] if names else None)
    if pick is None:
        raise ValueError("a parameter needs a name")
    stripped = pick.lstrip("".join(PREFIX_CHARS))
    return stripped.replace("-", "_")


class Parameter:
    """Common behaviour of options and arguments."""

    param_type_name = "parameter"

    def __init__(self, dest, *, type=None, default=UNSET, required=False, callback=None, nargs=1,
                 multiple=False, metavar=None, expose_value=True, is_eager=False, envvar=None,
                 deprecated=False, help=None, hidden=False, show_default=None, show_envvar=None,
                 shell_complete=None, allow_from_autoenv=True) -> None:
        self.dest = dest
        self.default = UNSET if default is None else default
        self.required = bool(required)
        self.callback = callback
        self.nargs = nargs
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = bool(expose_value)
        self.is_eager = bool(is_eager)
        if envvar is None:
            self.envvars: list[str] = []
        elif isinstance(envvar, str):
            self.envvars = [envvar]
        else:
            self.envvars = list(envvar)
        self.deprecated = deprecated
        self.help = help
        self.hidden = bool(hidden)
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete = shell_complete
        self.allow_from_autoenv = bool(allow_from_autoenv)
        self.is_flag = False
        self.count = False
        self.is_confirmation = False
        self.prompt = None
        self.prompt_required = True
        self.hide_input = False
        self.confirmation_prompt = False
        self.type = to_param_type(type) or STRING
        if isinstance(self.type, Tuple):
            self.nargs = len(self.type.types)

    # -- declaration-time helpers -----------------------------------------
    @property
    def variadic(self) -> bool:
        return False

    @property
    def prompt_enabled(self) -> bool:
        return bool(self.prompt)

    @property
    def name(self) -> str:
        """The destination name (the key the callback receives)."""
        return self.dest

    @property
    def explicit_default(self) -> bool:
        return self.default is not UNSET

    # -- naming -----------------------------------------------------------
    def get_error_hint(self, ctx) -> str:
        return self.dest.upper()

    def auto_envvar_name(self, ctx) -> str | None:
        prefix = getattr(ctx, "auto_envvar_prefix", None) if ctx is not None else None
        if not prefix or not self.allow_from_autoenv:
            return None
        return f"{prefix}_{self.dest}".upper().replace("-", "_")

    def env_names(self, ctx) -> list[str]:
        names = list(self.envvars)
        auto = self.auto_envvar_name(ctx)
        if auto and auto not in names:
            names.append(auto)
        return names

    # -- token shape --------------------------------------------------------
    def split_tokens(self, text: str) -> list[str]:
        multi = self.multiple or self.variadic or self.nargs != 1 or isinstance(self.type, Tuple)
        if not multi:
            return [text]
        return self.type.split_envvar_value(text)

    def _chunks(self, ctx, tokens):
        n = self.nargs if self.nargs and self.nargs > 0 else 1
        if n == 1:
            return [[t] for t in tokens]
        if len(tokens) % n:
            raise BadOptionUsage(f"{self.get_error_hint(ctx)} expects {n} values per occurrence.", ctx)
        return [tokens[i:i + n] for i in range(0, len(tokens), n)]

    def _convert_occurrence(self, ctx, tokens):
        """Convert the tokens of one occurrence."""
        if isinstance(self.type, Tuple):
            if len(tokens) != len(self.type.types):
                raise BadOptionUsage(f"{self.get_error_hint(ctx)} expects {len(self.type.types)} values.", ctx)
            return tuple(t.convert(tok, self, ctx) for t, tok in zip(self.type.types, tokens))
        if self.nargs != 1:
            if len(tokens) != self.nargs:
                raise BadOptionUsage(f"{self.get_error_hint(ctx)} requires {self.nargs} values.", ctx)
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        return self.type.convert(tokens[0], self, ctx)

    def _convert_item(self, ctx, item):
        if isinstance(item, str):
            return self.type.convert(item, self, ctx)
        return item

    # -- values -------------------------------------------------------------
    def empty_value(self):
        if self.count:
            return 0
        if self.is_flag:
            return False
        if self.multiple or self.variadic:
            return ()
        return None

    def declared_default(self, ctx):
        """The declared default (callable invoked here) or UNSET."""
        if self.default is UNSET:
            if self.is_flag:
                return False
            if self.count:
                return 0
            return UNSET
        value = self.default
        if callable(value) and not isinstance(value, type):
            value = value()
        return value

    def coerce_default(self, ctx, value):
        """Convert a default-map value or declared default to the delivered form."""
        if self.is_flag:
            if isinstance(value, str):
                parsed = self._flag_text(ctx, value, self.get_error_hint(ctx))
                return False if parsed is UNSET else parsed
            return value
        if self.count:
            return value
        multi = self.multiple or self.variadic
        if isinstance(value, str):
            if self.multiple and self.nargs == 1 and not isinstance(self.type, Tuple):
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default; pass a one-element sequence.",
                    ctx,
                )
            tokens = self.split_tokens(value)
            if multi:
                return tuple(self._convert_occurrence(ctx, c) for c in self._chunks(ctx, tokens))
            return self._convert_occurrence(ctx, tokens)
        if multi:
            if value is None:
                return ()
            if not isinstance(value, (list, tuple)):
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx
                )
            return tuple(self._convert_item(ctx, item) for item in value)
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if isinstance(value, (list, tuple)):
                return tuple(self._convert_item(ctx, item) for item in value)
        return value

    def fallback_value(self, ctx):
        """Declared/default-map value without prompting, or the empty value."""
        mapped = ctx.lookup_default(self.dest) if ctx is not None else UNSET
        if mapped is not UNSET:
            return self.coerce_default(ctx, mapped)
        declared = self.declared_default(ctx)
        if declared is UNSET:
            return self.empty_value()
        return self.coerce_default(ctx, declared)

    def _flag_text(self, ctx, text, hint):
        """Strict boolean text (defaults, default map). Unrecognised text is an error."""
        s = text.strip().lower()
        if s == "" or s in _FALSE_TEXT:
            return False
        if s in _TRUE_TEXT:
            return True
        raise BadOptionUsage(f"{hint}: {text!r} is not a valid boolean.", ctx)

    def _flag_from_env(self, ctx, raw: str):
        """Environment flag text. Returns a value, or UNSET when the text does not apply."""
        hint = self.get_error_hint(ctx)
        s = raw.strip().lower()
        flag_value = getattr(self, "flag_value", True)
        if isinstance(flag_value, bool) or flag_value is None:
            if s == "" or s in _FALSE_TEXT:
                return False
            if s in _TRUE_TEXT:
                return True
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx, self, hint)
        if raw == str(flag_value):
            return flag_value
        if s in _TRUE_TEXT:
            return flag_value
        if s in _FALSE_TEXT:
            return False
        return UNSET

    def env_occurrences(self, ctx):
        """Occurrences from the first environment name that is set, or None."""
        for name in self.env_names(ctx):
            raw = os.environ.get(name)
            if not raw:
                continue
            if self.is_flag:
                value = self._flag_from_env(ctx, raw)
                if value is UNSET:
                    continue
                return [("value", value)]
            if self.count:
                continue
            tokens = self.split_tokens(raw)
            if self.multiple or self.variadic or self.nargs != 1 or isinstance(self.type, Tuple):
                if self.variadic:
                    return [("tokens", list(tokens))]
                return [("tokens", chunk) for chunk in self._chunks(ctx, tokens)]
            return [("tokens", [raw])]
        return None

    def value_from_occurrences(self, ctx, occs):  # pragma: no cover - overridden
        raise NotImplementedError

    # -- prompting ------------------------------------------------------------
    def prompt_text(self) -> str:
        if isinstance(self.prompt, str):
            return self.prompt
        return self.dest.replace("_", " ").replace("-", " ").capitalize()

    def prompt_value(self, ctx, fallback):
        default = None if fallback is UNSET else fallback
        return termui.prompt(
            self.prompt_text(),
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    # -- callbacks ------------------------------------------------------------
    def run_callback(self, ctx, value):
        if self.callback is None:
            return value
        return self.callback(ctx, self, value)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.dest}>"


class Option(Parameter):
    """A named parameter, given as ``--name value``, ``-n value``, flags, or on/off pairs."""

    param_type_name = "option"

    def __init__(self, param_decls=(), *, type=None, default=UNSET, required=False, is_flag=None,
                 flag_value=UNSET, count=False, multiple=False, nargs=None, envvar=None,
                 allow_from_autoenv=True, prompt=None, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, callback=None, is_eager=False, expose_value=True,
                 hidden=False, deprecated=False, help=None, metavar=None, show_default=None,
                 show_envvar=None, shell_complete=None, is_confirmation=False) -> None:
        opts, secondary, dest_decl = _parse_decls(param_decls)
        if not opts and not secondary:
            if dest_decl is None:
                raise ValueError("an option needs at least one flag name")
            opts = ["--" + dest_decl.replace("_", "-")]
        dest = _infer_dest(opts, dest_decl)
        default_is_none = default is None
        if default_is_none:
            default = UNSET

        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool) or (
                count is False and flag_value is not UNSET and isinstance(flag_value, bool) and default is UNSET
            )
        if count and is_flag:
            raise ValueError("an option cannot be both a flag and a counting option")
        if nargs is not None and nargs < 1 and not is_flag and not count:
            raise ValueError("nargs must be a positive integer")
        if deprecated and required:
            raise ValueError("a deprecated option cannot also be required")
        if deprecated and prompt:
            raise ValueError("a deprecated option cannot use a prompt")

        if is_flag and flag_value is UNSET:
            flag_value = True
        if is_flag and secondary:
            flag_value = True

        if type is None:
            if is_flag:
                type = BOOL if isinstance(flag_value, bool) or flag_value is True else infer_type(flag_value)
            elif count:
                type = INT
            elif default is not UNSET and not callable(default):
                type = infer_type(default)
        if count:
            nargs_value = 0
        elif is_flag:
            nargs_value = 0
        else:
            nargs_value = nargs or 1

        super().__init__(
            dest,
            type=type,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs_value,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            show_default=show_default,
            show_envvar=show_envvar,
            shell_complete=shell_complete,
            allow_from_autoenv=allow_from_autoenv,
        )
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.is_confirmation = bool(is_confirmation)
        if self.count:
            self.nargs = 0
        if not self.is_flag and not self.count and nargs_value != 1:
            self.nargs = nargs_value
        self.prompt = prompt if prompt not in (False, None) else None
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)
        if self.is_flag:
            self.nargs = 0
            if self.type is None:
                self.type = BOOL
        if self.multiple and self.is_flag:
            raise ValueError("a flag cannot be repeatable")

    @property
    def all_names(self) -> list[str]:
        return self.opts + self.secondary_opts

    @property
    def optional_value(self) -> bool:
        return (not self.is_flag) and (not self.count) and self.flag_value is not UNSET

    def get_error_hint(self, ctx) -> str:
        return " / ".join(self.all_names)

    def get_metavar(self, ctx=None) -> str | None:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def value_from_occurrences(self, ctx, occs):
        if self.is_flag:
            return occs[-1][1]
        if self.count:
            return len(occs)
        values = [payload if kind == "value" else self._convert_occurrence(ctx, payload) for kind, payload in occs]
        return tuple(values) if self.multiple else values[-1]

    def prompt_value(self, ctx, fallback):
        return super().prompt_value(ctx, fallback)


class Argument(Parameter):
    """A positional parameter. Tokens bind in declaration order."""

    param_type_name = "argument"

    def __init__(self, param_decls=(), *, type=None, default=UNSET, required=None, nargs=1,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 is_eager=False, expose_value=True, hidden=False, shell_complete=None,
                 show_default=None, show_envvar=None) -> None:
        opts, secondary, dest_decl = _parse_decls(param_decls)
        if opts or secondary:
            raise ValueError("an argument takes a destination name only")
        if dest_decl is None:
            raise ValueError("an argument needs a destination name")
        if nargs != -1 and nargs < 1:
            raise ValueError("argument nargs must be a positive integer or -1")
        if default is None:
            default = UNSET
        if required is None:
            required = default is UNSET and nargs != -1
        if deprecated:
            if required:
                raise ValueError("a deprecated argument cannot be required")
            if default is UNSET and required is not False:
                raise ValueError("a deprecated argument needs a default or must be optional")
        if type is None and default is not UNSET and not callable(default):
            type = infer_type(default)
        super().__init__(
            dest_decl,
            type=type,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            show_default=show_default,
            show_envvar=show_envvar,
            shell_complete=shell_complete,
            allow_from_autoenv=False,
        )
        self.required = bool(required)

    @property
    def variadic(self) -> bool:
        return self.nargs == -1

    def get_error_hint(self, ctx) -> str:
        return self.dest.upper()

    def get_metavar(self, ctx=None) -> str:
        return self.metavar if self.metavar is not None else self.dest.upper()

    def min_tokens(self) -> int:
        if self.variadic or not self.required:
            return 0
        return self.nargs

    def env_occurrences(self, ctx):
        for name in self.env_names(ctx):
            raw = os.environ.get(name)
            if raw:
                return [("tokens", self.split_tokens(raw))]
        return None

    def value_from_occurrences(self, ctx, occs):
        tokens = [tok for _, payload in occs for tok in payload]
        if self.variadic:
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        if self.nargs != 1 or isinstance(self.type, Tuple):
            return self._convert_occurrence(ctx, tokens)
        return self.type.convert(tokens[0], self, ctx)

    def coerce_default(self, ctx, value):
        if self.variadic:
            if isinstance(value, str):
                return tuple(self.type.convert(t, self, ctx) for t in self.split_tokens(value))
            if value is None:
                return ()
            return tuple(self._convert_item(ctx, item) for item in value)
        if isinstance(value, str):
            return self._convert_occurrence(ctx, self.split_tokens(value))
        if self.nargs != 1 and isinstance(value, (list, tuple)):
            return tuple(self._convert_item(ctx, item) for item in value)
        return value


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------


class _Event:
    __slots__ = ("param", "kind", "payload", "index")

    def __init__(self, param, kind, payload, index) -> None:
        self.param = param
        self.kind = kind
        self.payload = payload
        self.index = index


def _expand_windows_argv(argv: list) -> list:
    """On Windows, expand globs, ``~`` and ``%VAR%`` in the argument list (other platforms: no-op)."""
    if not sys.platform.startswith("win"):
        return list(argv)
    import glob as _glob

    out: list = []
    for token in argv:
        token = os.path.expanduser(os.path.expandvars(token))
        matches = _glob.glob(token) if any(c in token for c in "*?[") else []
        out.extend(sorted(matches) if matches else [token])
    return out


def _warn_deprecated(ctx, what: str, note) -> None:
    text = f"DeprecationWarning: {what} is deprecated."
    if isinstance(note, str) and note:
        text += f" {note}"
    termui.echo(text, err=True)


class Command:
    """A leaf command: parses a slice of the command line and runs a callback."""

    default_interspersed = True

    def __init__(self, name=None, callback=None, params=None, context_settings=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, deprecated=False, hidden=False) -> None:
        self.name = name
        self.callback = callback
        self.params: list = list(params or [])
        self.context_settings = dict(context_settings or {})
        if help is None and callback is not None and getattr(callback, "__doc__", None):
            help = inspect.cleandoc(callback.__doc__)
        self.help = truncate_at_formfeed(help)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = bool(no_args_is_help)
        self.deprecated = deprecated
        self.hidden = bool(hidden)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    # -- parameters ---------------------------------------------------------
    def get_params(self, ctx) -> list:
        params = list(self.params)
        if self.add_help_option and ctx.help_option_names:
            taken = {n for p in params if isinstance(p, Option) for n in p.all_names}
            remaining = [n for n in ctx.help_option_names if n not in taken]
            if remaining:
                params.append(_help_option_param(remaining))
        return params

    # -- contexts -------------------------------------------------------------
    def make_context(self, info_name, args, parent=None, chain=False, **extra) -> Context:
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        ctx.raw_args_len = len(args)
        try:
            with ctx:
                rest = self.parse_args(ctx, list(args), chain=chain)
        except BaseException:
            ctx.close()
            raise
        ctx.args_rest = rest
        return ctx

    def invoke(self, ctx):
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated(ctx, f"The command '{self.name}'", self.deprecated)
                return self.run_callback(ctx)
        finally:
            ctx.close()

    def run_callback(self, ctx):
        if self.callback is None:
            return None
        return self.callback(**ctx.params)

    # spec: N-000807..N-000810 (standalone exit), N-000761 (runner), FP-13 exit classes
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        from .completion import handle_completion

        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "program") if sys.argv else "program"
            if prog_name.endswith(".py"):
                prog_name = prog_name[:-3]
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        if args is None:
            args = _expand_windows_argv(sys.argv[1:])
        else:
            args = list(args)

        if complete_var in os.environ:
            status = handle_completion(self, prog_name, os.environ[complete_var])
            if status is not None:
                if standalone_mode:
                    sys.exit(status)
                return None

        try:
            ctx = self.make_context(prog_name, args, **extra)
            rv = self.invoke(ctx)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.code)
            return None
        except (KeyboardInterrupt, EOFError):
            error = Abort()
            if standalone_mode:
                error.show()
                sys.exit(1)
            raise error from None
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        if standalone_mode:
            sys.exit(0)
        return rv

    # -- parsing ------------------------------------------------------------
    def parse_args(self, ctx, args, interspersed=None, chain=False):
        """Parse ``args`` into ``ctx.params``. Returns the tokens no parameter consumed."""
        try:
            return self._parse_args(ctx, args, interspersed, chain)
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            raise

    # spec: N-000110..N-000113 (help does not run callback), N-000388..N-000393 (dispatch order), N-000227..N-000233 (env sources)
    def _parse_args(self, ctx, args, interspersed, chain):
        if not args and self.no_args_is_help and not isinstance(self, Group):
            # Leaf configured so that no arguments means help: a usage failure (FP-02).
            raise NoArgsIsHelp("Missing argument.", ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        if interspersed is None:
            interspersed = ctx.allow_interspersed_args if ctx.allow_interspersed_args is not None else self.default_interspersed
        if chain:
            interspersed = False

        events, positionals = self._scan(ctx, args, options, arguments, interspersed)
        arg_events, leftover = self._assign_arguments(ctx, arguments, positionals, len(events))
        events.extend(arg_events)

        by_param: dict = {}
        for ev in events:
            by_param.setdefault(ev.param, []).append(ev)

        # spec: N-000162..N-000169 (eager version/help: first typed wins)
        # Eager parameters run first, in the order the user typed them.
        processed = set()
        for ev in events:
            param = ev.param
            if param.is_eager and param not in processed:
                processed.add(param)
                value = param.value_from_occurrences(ctx, [(e.kind, e.payload) for e in by_param[param]])
                param.run_callback(ctx, value)

        # spec: N-000250..N-000263 (parameter callbacks), N-000264..N-000265 (hidden from callback)
        # Everything else, in declaration order, one destination at a time.
        groups: dict = {}
        for param in params:
            key = param.dest if param.expose_value else id(param)
            groups.setdefault(key, []).append(param)
        for key, group in groups.items():
            if all(p in processed for p in group):
                continue
            winner, value, source = self._resolve(ctx, group, by_param)
            if winner.deprecated and source is ParameterSource.COMMANDLINE:
                _warn_deprecated(ctx, f"The {winner.param_type_name} '{winner.get_error_hint(ctx)}'", winner.deprecated)
            value = winner.run_callback(ctx, value)
            if winner.expose_value:
                ctx.params[winner.dest] = value
            ctx._sources[winner.dest] = source

        if chain or isinstance(self, Group):
            return leftover
        if leftover:
            if not ctx.allow_extra_args:
                names = " ".join(leftover)
                raise UsageError(f"Got unexpected extra argument(s) ({names}).", ctx)
            for tok in leftover:
                if tok.startswith("-") and tok != "-" and not ctx.ignore_unknown_options:
                    raise NoSuchOption(tok, ctx)
        return leftover

    # spec: N-000181..N-000220 (option forms), N-000226 (prefixes), N-000285..N-000287 (after --)
    def _scan(self, ctx, args, options, arguments, interspersed):
        """Read option tokens. Returns (events, positional tokens)."""
        index: dict = {}
        prefixes = {"-"}
        normalize = ctx.token_normalize_func or (lambda s: s)
        for p in options:
            for name in p.opts:
                index[normalize(name)] = (p, name)
                prefixes.add(name[0])
            for name in p.secondary_opts:
                index[normalize(name)] = (p, name)
                prefixes.add(name[0])

        is_group = isinstance(self, Group)
        capacity = 0
        if is_group:
            if any(a.variadic for a in arguments):
                capacity = float("inf")
            else:
                capacity = sum(a.nargs for a in arguments)

        events: list = []
        positionals: list = []
        counter = [0]
        stop_opts = False
        seen_positional = 0
        i = 0

        def push(param, kind, payload):
            counter[0] += 1
            events.append(_Event(param, kind, payload, counter[0]))

        def option_like(tok: str) -> bool:
            return len(tok) > 1 and tok[0] in prefixes

        def take_value(param, name, attached, i):
            """Consume the value for ``param`` (starting at args[i]). Returns the new index."""
            if param.is_flag or param.count:
                if attached is not None:
                    raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx)
                if param.count:
                    push(param, "value", 1)
                    return i
                if param.secondary_opts and name in param.secondary_opts:
                    push(param, "value", False)
                else:
                    push(param, "value", param.flag_value)
                return i
            if param.optional_value:
                if attached is not None:
                    push(param, "tokens", [attached])
                elif i < len(args) and not option_like(args[i]) and args[i] != "--":
                    push(param, "tokens", [args[i]])
                    return i + 1
                else:
                    push(param, "value", param.flag_value)
                return i
            need = param.nargs or 1
            toks = [] if attached is None else [attached]
            while len(toks) < need and i < len(args):
                toks.append(args[i])
                i += 1
            if len(toks) < need:
                if param.prompt_enabled and not toks:
                    push(param, "prompt", None)
                    return i
                raise BadOptionUsage(f"Option '{name}' requires {need} argument(s).", ctx)
            push(param, "tokens", toks)
            return i

        while i < len(args):
            tok = args[i]
            i += 1
            if stop_opts:
                positionals.append(tok)
                continue
            if tok == "--":
                stop_opts = True
                continue
            if option_like(tok):
                key = normalize(tok)
                if key in index:
                    param, name = index[key]
                    i = take_value(param, name, None, i)
                    continue
                if "=" in tok:
                    head, _, attached = tok.partition("=")
                    hkey = normalize(head)
                    if hkey in index:
                        param, name = index[hkey]
                        i = take_value(param, name, attached, i)
                        continue
                if tok[0] == "-" and not tok.startswith("--") and len(tok) > 2:
                    chars = tok[1:]
                    j = 0
                    handled_all = True
                    while j < len(chars):
                        short = "-" + chars[j]
                        skey = normalize(short)
                        if skey not in index:
                            rest = "-" + chars[j:]
                            if ctx.ignore_unknown_options or (is_group and interspersed):
                                positionals.append(rest)
                                break
                            raise NoSuchOption(short, ctx)
                        param, name = index[skey]
                        if param.is_flag or param.count:
                            i_before = i
                            i = take_value(param, short, None, i)
                            assert i == i_before
                            j += 1
                            continue
                        attached = chars[j + 1:] or None
                        i = take_value(param, short, attached, i)
                        handled_all = True
                        break
                    if handled_all:
                        continue
                if ctx.ignore_unknown_options or (is_group and interspersed):
                    positionals.append(tok)
                    seen_positional += 1
                    if not interspersed and seen_positional > capacity:
                        stop_opts = True
                    continue
                raise NoSuchOption(tok, ctx)

            positionals.append(tok)
            seen_positional += 1
            if not interspersed and seen_positional > capacity:
                stop_opts = True
        return events, positionals

    # spec: N-000285..N-000329 (positional arguments; variadic takes the rest)
    def _assign_arguments(self, ctx, arguments, positionals, base_index):
        events: list = []
        counter = base_index
        i = 0
        n = len(positionals)
        for k, arg in enumerate(arguments):
            reserve = sum(a.min_tokens() for a in arguments[k + 1:])
            available = n - i - reserve
            if arg.variadic:
                take = max(available, 0)
            elif arg.nargs > 1:
                take = arg.nargs if available >= arg.nargs else 0
                if take == 0 and available > 0 and arg.required:
                    raise BadArgumentUsage(f"Argument '{arg.dest.upper()}' requires {arg.nargs} values.", ctx)
            else:
                take = 1 if available >= 1 else 0
            if take == 0:
                continue
            counter += 1
            events.append(_Event(arg, "tokens", positionals[i:i + take], counter))
            i += take
        return events, positionals[i:]

    def _resolve(self, ctx, group, by_param):
        """Pick the winning parameter for a destination and its value. Returns (param, value, source)."""
        try:
            return self._resolve_inner(ctx, group, by_param)
        except BadParameter as e:
            if e.param is None:
                e.param = group[-1]
            if e.ctx is None:
                e.ctx = ctx
            raise

    # spec: N-000243..N-000245 (source ranking), N-000246..N-000249 (feature switches), N-000200..N-000201 (required), N-000321 (missing argument)
    def _resolve_inner(self, ctx, group, by_param):
        # 1. command line: the most recent occurrence wins.
        winner = None
        best = -1
        for p in group:
            evs = by_param.get(p)
            if evs and evs[-1].index > best:
                best = evs[-1].index
                winner = p
        if winner is not None:
            evs = by_param[winner]
            occs = [(e.kind, e.payload) for e in evs]
            if winner.prompt_enabled and any(e.kind == "prompt" for e in evs):
                fallback = self._fallback_or_unset(ctx, winner)
                return winner, winner.prompt_value(ctx, fallback), ParameterSource.PROMPT
            return winner, winner.value_from_occurrences(ctx, occs), ParameterSource.COMMANDLINE

        # 2. environment.
        for p in group:
            occs = p.env_occurrences(ctx)
            if occs is not None:
                return p, p.value_from_occurrences(ctx, occs), ParameterSource.ENVIRONMENT

        single = group[0] if len(group) == 1 else None
        # 3. prompts that run when the option was omitted.
        if single is not None and single.is_confirmation:
            termui.confirm(single.prompt_text() if isinstance(single.prompt, str) else "Do you want to continue?", abort=True)
            return single, True, ParameterSource.PROMPT
        if single is not None and single.prompt_enabled and (single.prompt_required or single.required):
            fallback = self._fallback_or_unset(ctx, single)
            return single, single.prompt_value(ctx, fallback), ParameterSource.PROMPT

        # 4. default map.
        for p in group:
            mapped = ctx.lookup_default(p.dest)
            if mapped is not UNSET:
                return p, p.coerce_default(ctx, mapped), ParameterSource.DEFAULT_MAP

        # 5. declared default: an explicit default beats an automatic one; ties go to the last declared.
        explicit = [p for p in group if p.explicit_default]
        cand = explicit[-1] if explicit else group[-1]
        declared = cand.declared_default(ctx)
        if declared is UNSET:
            if cand.required:
                raise MissingParameter(
                    f"Missing {cand.param_type_name} {cand.get_error_hint(ctx)}.", ctx, cand
                )
            return cand, cand.empty_value(), ParameterSource.DEFAULT
        return cand, cand.coerce_default(ctx, declared), ParameterSource.DEFAULT

    @staticmethod
    def _fallback_or_unset(ctx, param):
        mapped = ctx.lookup_default(param.dest)
        if mapped is not UNSET:
            return param.coerce_default(ctx, mapped)
        declared = param.declared_default(ctx)
        if declared is UNSET:
            return UNSET
        return param.coerce_default(ctx, declared)

    # -- help ---------------------------------------------------------------
    def get_short_help_str(self) -> str:
        if self.short_help is not None:
            return self.short_help
        return short_help_text(self.help or "")

    def _usage_pieces(self, ctx) -> list[str]:
        pieces = [ctx.command_path]
        params = self.get_params(ctx)
        if any(isinstance(p, Option) and not p.hidden for p in params):
            pieces.append(self.options_metavar)
        for arg in params:
            if not isinstance(arg, Argument) or arg.hidden:
                continue
            placeholder = arg.get_metavar(ctx)
            if arg.variadic:
                piece = f"{placeholder}..."
                if not arg.required:
                    piece = f"[{piece}]"
            else:
                piece = " ".join([placeholder] * max(arg.nargs, 1))
                if not arg.required:
                    piece = f"[{piece}]"
            pieces.append(piece)
        if isinstance(self, Group):
            if self.chain:
                pieces.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
            elif self.invoke_without_command:
                pieces.append("[COMMAND [ARGS]...]")
            else:
                pieces.append("COMMAND [ARGS]...")
        return pieces

    def get_usage(self, ctx) -> str:
        return "Usage: " + " ".join(self._usage_pieces(ctx))

    def _help_body(self) -> str:
        return self.help or ""

    def _option_row(self, ctx, param: Option):
        first = "/".join([param.opts[0], param.secondary_opts[0]]) if param.secondary_opts else ", ".join(param.opts)
        if not param.is_flag or param.secondary_opts:
            metavar = param.get_metavar(ctx)
            if metavar and not param.is_flag:
                first = f"{first} {metavar}"
        extras = []
        if param.help:
            extras.append(param.help)
        show = param.show_default if param.show_default is not None else ctx.show_default
        if show:
            default_text = _default_text(param, ctx)
            if default_text is not None:
                extras.append(f"[default: {default_text}]")
        if param.show_envvar:
            names = param.env_names(ctx)
            if names:
                extras.append(f"[env var: {', '.join(names)}]")
        if isinstance(param.type, Choice):
            extras.append(f"[choices: {', '.join(param.type._names)}]")
        if param.required:
            extras.append("[required]")
        if param.deprecated:
            extras.append("(Deprecated)")
        return first, " ".join(extras)

    def _argument_row(self, ctx, param: Argument):
        extras = [param.help] if param.help else []
        if param.deprecated:
            extras.append("(Deprecated)")
        return param.get_metavar(ctx), " ".join(extras)

    # spec: N-000827..N-000845 (help page sections in order); CF-000047 (epilog last)
    def get_help(self, ctx) -> str:
        width = ctx.get_terminal_width()
        sections = [self.get_usage(ctx), ""]
        if self.deprecated:
            sections.append("(Deprecated)")
        body = self._help_body()
        if body:
            sections.append(wrap_text(body, width=width))
            sections.append("")
        params = self.get_params(ctx)
        arg_rows = [self._argument_row(ctx, p) for p in params if isinstance(p, Argument) and not p.hidden and p.help]
        if arg_rows:
            sections.append("Positional arguments:")
            sections.append(format_rows(arg_rows, width))
            sections.append("")
        opt_rows = [self._option_row(ctx, p) for p in params if isinstance(p, Option) and not p.hidden]
        if opt_rows:
            sections.append("Options:")
            sections.append(format_rows(opt_rows, width))
            sections.append("")
        if isinstance(self, Group):
            cmd_rows = []
            for name in self.list_commands(ctx):
                cmd = self.get_command(ctx, name)
                if cmd is None or cmd.hidden:
                    continue
                short = cmd.get_short_help_str()
                if cmd.deprecated:
                    short = (short + " (Deprecated)").strip()
                cmd_rows.append((name, short))
            if cmd_rows:
                sections.append("Commands:")
                sections.append(format_rows(cmd_rows, width))
                sections.append("")
        if self.epilog:
            sections.append(wrap_text(self.epilog, width=width))
            sections.append("")
        return "\n".join(sections).rstrip("\n") + "\n"


# spec: N-000146..N-000151 (show-default); CF-000162 (default-off flag stays hidden)
def _default_text(param: Parameter, ctx):
    if isinstance(param.show_default, str):
        return param.show_default
    if param.is_flag and param.default is UNSET:
        return None
    if param.is_flag and param.default is False:
        return None
    if param.default is UNSET:
        return None
    if callable(param.default) and not isinstance(param.default, type):
        return "(dynamic)"
    value = param.default
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)


class Group(Command):
    """A command that dispatches to named subcommands."""

    default_interspersed = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.commands: dict = {}
        self.invoke_without_command = bool(invoke_without_command)
        if no_args_is_help is None:
            no_args_is_help = not self.invoke_without_command
        self.no_args_is_help = bool(no_args_is_help)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback
        if commands:
            items = commands.items() if isinstance(commands, dict) else [(c.name, c) for c in commands]
            for key, cmd in items:
                self.add_command(cmd, key)

    # -- registration ---------------------------------------------------------
    def add_command(self, cmd, name=None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise TypeError("A command needs a name before it can be added to a group.")
        self.commands[key] = cmd

    def result_callback(self):
        """Decorator registering the function run after the subcommands (see FP-10)."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def command(self, *args, **kwargs):
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    # -- lookup (override points) ---------------------------------------------
    def list_commands(self, ctx) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name: str):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name: str):
        """Return (exported name, command) or (None, None)."""
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return name, cmd
        normalize = ctx.token_normalize_func
        if normalize is not None:
            wanted = normalize(name)
            for candidate in self.list_commands(ctx):
                if normalize(candidate) == wanted:
                    found = self.get_command(ctx, candidate)
                    if found is not None:
                        return candidate, found
        return None, None

    # -- invocation -----------------------------------------------------------
    def invoke(self, ctx):
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated(ctx, f"The command '{self.name}'", self.deprecated)
                if self.chain:
                    return self._invoke_chain(ctx)
                return self._invoke_single(ctx)
        finally:
            ctx.close()

    def _no_command(self, ctx):
        if ctx.raw_args_len == 0 and self.no_args_is_help:
            return NoArgsIsHelp("Missing command.", ctx)
        return UsageError("Missing command.", ctx)

    # spec: N-000388..N-000393 (group callback before child; unknown names fail first)
    def _invoke_single(self, ctx):
        rest = ctx.args_rest
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self.run_callback(ctx)
                if self._result_callback is not None:
                    return self._result_callback(rv, **ctx.params)
                return rv
            raise self._no_command(ctx)
        name, cmd = self.resolve_command(ctx, rest[0])
        if cmd is None:
            raise NoSuchCommand(rest[0], ctx)
        ctx.invoked_subcommand = name
        self.run_callback(ctx)
        sub = cmd.make_context(name, rest[1:], parent=ctx)
        rv = cmd.invoke(sub)
        if self._result_callback is not None:
            return self._result_callback(rv, **ctx.params)
        return rv

    # spec: N-000385..N-000387 (chaining group, FP-10 results)
    def _invoke_chain(self, ctx):
        rest = ctx.args_rest
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                self.run_callback(ctx)
                if self._result_callback is not None:
                    return self._result_callback([], **ctx.params)
                return []
            raise self._no_command(ctx)
        ctx.invoked_subcommand = CHAINED_SUBCOMMAND
        self.run_callback(ctx)
        results = []
        while rest:
            name, cmd = self.resolve_command(ctx, rest[0])
            if cmd is None:
                raise NoSuchCommand(rest[0], ctx)
            sub = cmd.make_context(name, rest[1:], parent=ctx, chain=True)
            results.append(cmd.invoke(sub))
            rest = sub.args_rest
        if self._result_callback is not None:
            return self._result_callback(results, **ctx.params)
        return results


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> list[str]:
        names: set = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name: str):
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return self.commands.get(cmd_name)


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------


def _derive_name(f) -> str:
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _pop_params(f) -> list:
    if isinstance(f, Command):
        return []
    declared = f.__dict__.pop("__optlyn_params__", [])
    return list(reversed(declared))


def _attach_param(f, param):
    if isinstance(f, Command):
        f.params.insert(0, param)
    else:
        f.__dict__.setdefault("__optlyn_params__", []).append(param)
    return f


def command(name=None, cls=None, **attrs):
    """Turn a function into a ``Command``. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, (str, type)):
        return command()(name)

    def decorator(f):
        cmd_cls = cls or Command
        cmd_name = name if name is not None else _derive_name(f)
        params = _pop_params(f)
        return cmd_cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a ``Group``. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, (str, type)):
        return group()(name)

    def decorator(f):
        grp_cls = cls or Group
        grp_name = name if name is not None else _derive_name(f)
        params = _pop_params(f)
        return grp_cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function or command. Returns a decorator."""

    def decorator(f):
        param_cls = cls or Option
        return _attach_param(f, param_cls(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a function or command. Returns a decorator."""

    def decorator(f):
        param_cls = cls or Argument
        return _attach_param(f, param_cls(param_decls, **attrs))

    return decorator


# spec: N-000110..N-000113, N-000827 (help page on standard output, exit 0)
def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _help_option_param(names):
    return Option(
        tuple(names),
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_show_help_callback,
    )


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return option(*param_decls, **kwargs)


def _detect_version(package_name: str) -> str:
    try:
        return _metadata.version(package_name)
    except _metadata.PackageNotFoundError:
        providers = _metadata.packages_distributions().get(package_name) or []
        for dist in providers:
            try:
                return _metadata.version(dist)
            except _metadata.PackageNotFoundError:
                continue
    raise RuntimeError(f"Could not determine the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager version flag. The identity is ``version`` or the version of ``package_name``."""
    if isinstance(version, str) and version.startswith("-"):
        param_decls = (version, *param_decls)
        version = None
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        frame = inspect.currentframe()
        caller = frame.f_back if frame is not None else None
        module = caller.f_globals.get("__name__", "") if caller is not None else ""
        package_name = module.split(".")[0] or None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or "program"
        template = message or "%(prog)s, version %(version)s"
        termui.echo(template % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose identity is exactly ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def on_value(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        termui.echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = on_value
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default ``--password``)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that asks when omitted and aborts when declined (default ``--yes``)."""
    if not param_decls:
        param_decls = ("--yes",)
    prompt = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["prompt"] = prompt
    kwargs["is_confirmation"] = True
    return option(*param_decls, **kwargs)


def pass_context(f):
    """Pass the current ``Context`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure: bool = False):
    """Pass the nearest object of ``object_type`` found walking up the context chain."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator

