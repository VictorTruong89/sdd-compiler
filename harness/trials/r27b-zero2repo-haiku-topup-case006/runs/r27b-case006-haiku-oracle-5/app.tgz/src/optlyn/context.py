"""Invocation context (section 6 of the Interface Contract; FP-07)."""

from __future__ import annotations

import contextlib
import enum
import threading

from .exceptions import Abort, Exit

_local = threading.local()

UNSET = object()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Five distinct values."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class ChainedSubcommand:
    """``invoked_subcommand`` value on a chaining group: neither None nor a child name."""

    def __repr__(self) -> str:
        return "<chained subcommands>"


CHAINED_SUBCOMMAND = ChainedSubcommand()

_INHERITED = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
    "allow_extra_args",
    "ignore_unknown_options",
)


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent: bool = False):
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true, in
    which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """Per-invocation state. Built by the library, one per command run."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        auto_envvar_prefix=None,
        resilient_parsing=False,
        **extra,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params: dict = {}
        self.args_rest: list = []
        self.raw_args_len = 0
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self.extra = extra
        self._sources: dict = {}
        self._exit_stack = contextlib.ExitStack()
        self._closed = False

        given = {
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
            "allow_extra_args": allow_extra_args,
            "ignore_unknown_options": ignore_unknown_options,
            "auto_envvar_prefix": auto_envvar_prefix,
        }
        for key in _INHERITED:
            value = given[key]
            if value is None and parent is not None:
                value = getattr(parent, key)
            setattr(self, key, value)
        if self.max_content_width is None:
            self.max_content_width = 80
        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        self.help_option_names = list(self.help_option_names)
        if self.allow_extra_args is None:
            self.allow_extra_args = False
        if self.ignore_unknown_options is None:
            self.ignore_unknown_options = False
        # Interspersing is a per-group choice, never inherited.
        self.allow_interspersed_args = allow_interspersed_args

        if parent is not None and info_name is not None and parent.auto_envvar_prefix and auto_envvar_prefix is None:
            self.auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"

        # Object: explicit value, else inherited from the parent.
        if obj is None and parent is not None:
            self.obj = parent.obj
        else:
            self.obj = obj

        # Default map: nested by subcommand name, else the command's own setting.
        if default_map is None and parent is not None and parent.default_map is not None and info_name is not None:
            nested = parent.default_map.get(info_name)
            if isinstance(nested, dict):
                default_map = nested
        if default_map is None:
            default_map = command.context_settings.get("default_map") if command is not None else None
        self.default_map = dict(default_map) if isinstance(default_map, dict) else None

    # -- lifecycle -------------------------------------------------------
    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    def with_resource(self, cm):
        """Enter a context manager now; it is exited when this context closes."""
        return self._exit_stack.enter_context(cm)

    # -- hierarchy -------------------------------------------------------
    @property
    def command_path(self) -> str:
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names)) or "program"

    @property
    def root(self):
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def parent_chain(self):
        ctx = self
        while ctx is not None:
            yield ctx
            ctx = ctx.parent

    def find_object(self, object_type):
        for ctx in self.parent_chain:
            if isinstance(ctx.obj, object_type):
                return ctx.obj
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def find_root(self):
        return self.root

    # -- values ----------------------------------------------------------
    def lookup_default(self, name: str):
        """Return the default-map value for ``name`` or UNSET."""
        if self.default_map is None:
            return UNSET
        return self.default_map.get(name, UNSET)

    def get_parameter_source(self, name: str):
        """Source of a declared parameter's value, or None for an undeclared name."""
        return self._sources.get(name)

    def get_terminal_width(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        import shutil

        return min(shutil.get_terminal_size((80, 24)).columns, self.max_content_width)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    # -- control flow ----------------------------------------------------
    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, callback, **kwargs):
        """Run another command (or callable) from inside a callback.

        Values not given are the declared defaults; given values are passed
        as-is (no conversion, no source tracking).
        """
        from .core import Command

        if isinstance(callback, Command):
            child = Context(callback, parent=self, info_name=callback.name)
            with child:
                for param in callback.get_params(child):
                    if not param.expose_value:
                        continue
                    if param.dest in kwargs:
                        child.params[param.dest] = kwargs[param.dest]
                    else:
                        child.params[param.dest] = param.fallback_value(child)
                try:
                    return callback.run_callback(child)
                finally:
                    child.close()
        with self:
            return callback(**kwargs)

    def forward(self, callback, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(callback, **values)

    def __repr__(self) -> str:
        return f"<Context {self.command_path!r}>"
