"""Exceptions raised by Optlyn.

The standalone runner turns these into a process exit status:

* ``UsageError`` (and subclasses) -> status 2, message on standard error.
* ``Abort`` -> status 1, "Aborted!" on standard error.
* ``FileError`` and other ``OptlynError`` -> status 1, error on standard error.
* ``Exit`` -> the author's clean-stop status (0 unless given).
"""

from __future__ import annotations

import sys


class OptlynError(Exception):
    """Base class for errors reported by Optlyn itself."""

    #: process exit status used in standalone mode
    exit_code = 1

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self) -> str:
        return self.message

    def show(self, file=None) -> None:
        file = file or sys.stderr
        file.write(f"Error: {self.format_message()}\n")
        file.flush()


# spec: N-000804 (usage-error status 2, channel N-000816)
class UsageError(OptlynError):
    """Incorrect command line usage. Exit status 2."""

    exit_code = 2

    def show(self, file=None) -> None:
        file = file or sys.stderr
        ctx = self.ctx
        if ctx is not None:
            file.write(ctx.get_usage() + "\n")
            file.write(f"Try '{ctx.command_path} {ctx.help_option_names[0]}' for help.\n")
        file.write(f"Error: {self.format_message()}\n")
        file.flush()


class BadParameter(UsageError):
    """A value for a parameter was refused (conversion or callback)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> str | None:
        if self.param_hint is not None:
            return self.param_hint
        if self.param is not None:
            return self.param.get_error_hint(self.ctx)
        return None

    def format_message(self) -> str:
        hint = self._hint()
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self) -> str:
        hint = self._hint() or "parameter"
        kind = "argument" if self.param is not None and self.param.param_type_name == "argument" else "option"
        return f"Missing {kind} {hint}."


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class NoSuchOption(UsageError):
    """An unknown option token was given."""

    def __init__(self, option_name: str, ctx=None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """A subcommand name is unknown."""

    def __init__(self, name: str, ctx=None) -> None:
        super().__init__(f"No such command '{name}'.", ctx)
        self.name = name


class NoArgsIsHelp(UsageError):
    """No arguments were given and the command shows help as a usage failure.

    In standalone mode the help page is written to standard error and the
    process exits with the usage-error status (2).
    """

    def show(self, file=None) -> None:
        file = file or sys.stderr
        if self.ctx is not None:
            file.write(self.ctx.get_help() + "\n")
        file.flush()


# spec: N-000805 (abort status 1, indication N-000817); CF-000134
class Abort(OptlynError):
    """The user (or the author) aborted the run. Exit status 1."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!", ctx=None) -> None:
        super().__init__(message, ctx)

    def show(self, file=None) -> None:
        file = file or sys.stderr
        file.write(f"{self.message}\n")
        file.flush()


class FileError(OptlynError):
    """A file could not be opened when I/O started. General error, status 1."""

    def __init__(self, filename: str, message: str, ctx=None) -> None:
        super().__init__(f"Could not open file '{filename}': {message}", ctx)
        self.filename = filename


# spec: N-000803, N-000806 (author clean stop and its status)
class Exit(Exception):
    """Author clean stop (or intentional help/version). Carries the status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.code = code

