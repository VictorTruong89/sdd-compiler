"""In-process runner: ``optlyn.testing.CliRunner`` (FP-14, section 9 of the Interface Contract)."""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import sys
import tempfile
import shutil

from .exceptions import Abort


class _Sink:
    """A byte sink recording its own writes and the shared, interleaved order."""

    def __init__(self, order: list, name: str) -> None:
        self.data = bytearray()
        self._order = order
        self._name = name

    def write(self, b: bytes) -> int:
        self.data.extend(b)
        self._order.append((self._name, bytes(b)))
        return len(b)

    def flush(self) -> None:
        pass


class _CaptureStream(io.TextIOBase):
    """Text stream used for interpreter-level capture."""

    def __init__(self, sink: _Sink, bytes_sink: _Sink, charset: str, errors="strict") -> None:
        super().__init__()
        self._sink = sink
        self._bytes = bytes_sink
        self._charset = charset
        self._errors = errors
        self.buffer = _ByteStream(self)

    @property
    def encoding(self) -> str:
        return self._charset

    @property
    def errors(self) -> str:
        return self._errors

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, text) -> int:
        data = text.encode(self._charset, "replace") if isinstance(text, str) else bytes(text)
        self._sink.write(data)
        return len(text)

    def flush(self) -> None:
        pass


class _ByteStream(io.RawIOBase):
    def __init__(self, text_stream: _CaptureStream) -> None:
        super().__init__()
        self._text = text_stream

    def writable(self) -> bool:
        return True

    def write(self, b) -> int:
        self._text._sink.write(bytes(b))
        return len(b)

    def flush(self) -> None:
        pass


class _InputStream(io.TextIOBase):
    """Standard input for an invocation: reads the supplied bytes; optionally echoes what is read."""

    def __init__(self, data: bytes, charset: str, echo: bool, order: list) -> None:
        super().__init__()
        self._raw = io.BytesIO(data)
        self._charset = charset
        self._echo = echo
        self._order = order
        self._prompting = False
        self.buffer = _BinaryInput(self)

    @property
    def encoding(self) -> str:
        return self._charset

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def readable(self) -> bool:
        return True

    def readline(self, size=-1) -> str:
        line = self._raw.readline(size) if size is not None and size >= 0 else self._raw.readline()
        text = line.decode(self._charset, "replace")
        # Prompt reads echo themselves (termui); echo_stdin covers every other read.
        if self._echo and not self._prompting and text:
            self._order.append(("stdout", text.encode(self._charset)))
        return text

    def read(self, size=-1) -> str:
        data = self._raw.read() if size is None or size < 0 else self._raw.read(size)
        text = data.decode(self._charset, "replace")
        if self._echo and text:
            self._order.append(("stdout", text.encode(self._charset)))
        return text


class _BinaryInput(io.RawIOBase):
    def __init__(self, text: _InputStream) -> None:
        super().__init__()
        self._text = text

    def readable(self) -> bool:
        return True

    def readline(self, size=-1) -> bytes:
        return self._text._raw.readline(size) if size is not None and size >= 0 else self._text._raw.readline()

    def read(self, size=-1) -> bytes:
        return self._text._raw.read(size)


class Result:
    """Outcome of ``CliRunner.invoke``."""

    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, output_bytes: bytes,
                 return_value, exit_code: int, exception, exc_info=None) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


# spec: N-000736..N-000762 (in-process runner), N-001038..N-001044 (section 9 contract)
class CliRunner:
    """Invokes a command in-process with argument tokens and captures its output."""

    def __init__(self, charset: str = "utf-8", env=None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    # -- environment ------------------------------------------------------
    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color: bool = False):
        order: list = []
        out_sink = _Sink(order, "stdout")
        err_sink = _Sink(order, "stderr")
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        stdin = _InputStream(data, self.charset, self.echo_stdin, order)
        stdout = _CaptureStream(out_sink, out_sink, self.charset)
        stderr = _CaptureStream(err_sink, err_sink, self.charset)
        env_patch = dict(self.env)
        env_patch.update(env or {})
        saved_env = {}
        for key, value in env_patch.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield (out_sink, err_sink, order)
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    @contextlib.contextmanager
    def _fd_isolation(self, input=None, env=None):
        """Capture at the file-descriptor level: the streams report real descriptors."""
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out, saved_err = os.dup(1), os.dup(2)
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        with self.isolation(input=input, env=env) as (out_sink, err_sink, order):
            sys.stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset, write_through=True)
            sys.stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset, write_through=True)
            try:
                yield (out_file, err_file, order)
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                os.dup2(saved_out, 1)
                os.dup2(saved_err, 2)
                os.close(saved_out)
                os.close(saved_err)
        out_file.seek(0)
        err_file.seek(0)

    # -- invocation ---------------------------------------------------------
    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color: bool = False, **extra) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        else:
            args = list(args)
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        captured = None
        manager = self._fd_isolation if self.capture == "fd" else self.isolation
        with manager(input=input, env=env) as (out_sink, err_sink, order):
            try:
                return_value = cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if standalone:
                    exit_code = 0
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stdout.write(str(code) + "\n")
                    exit_code = 1
            except Abort as e:
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()
                if not catch_exceptions:
                    raise
            except Exception as e:  # noqa: BLE001
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            captured = (out_sink, err_sink, order)

        if self.capture == "fd":
            out_sink, err_sink, order = captured
            stdout_bytes = out_sink.read()
            stderr_bytes = err_sink.read()
            output_bytes = stdout_bytes + stderr_bytes
        else:
            out_sink, err_sink, order = captured
            stdout_bytes = bytes(out_sink.data)
            stderr_bytes = bytes(err_sink.data)
            output_bytes = b"".join(chunk for _, chunk in order)

        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    # spec: N-000744 and N-001044 (isolated filesystem; CF-000154 removal rule)
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty working directory; yields its path.

        Without ``temp_dir`` the directory is removed on exit. With ``temp_dir``
        it is created as a child of that path and left in place.
        """
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
