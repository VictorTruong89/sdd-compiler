"""Declaration decorators and ready-made options (PRD FP-01, FP-02, FP-07, FP-08; Interface sections 3-4)."""

from __future__ import annotations

import functools
import importlib.metadata as _md
import inspect
import re

from .context import get_current_context
from .core import Command, CommandCollection, Group
from .exceptions import DeclarationError, Exit
from .formatting import strip_form_feed, truncate_form_feed
from .parameters import Argument, Option
from .termui import confirm, echo

_SUFFIX_RE = re.compile(r"_(command|cmd|group|grp)$")


def _take_params(f) -> list:
    """Pop the declarations attached to ``f``; the command gets them, the function does not."""
    params = list(getattr(f, "__optlyn_params__", []))
    params.reverse()  # decorators apply bottom-up; declaration order is top-down
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _memo(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _derive_name(func_name: str) -> str:
    base = _SUFFIX_RE.sub("", func_name.lower())
    return base.replace("_", "-")


def _help_text(f, attrs: dict):
    explicit = attrs.pop("help", None)
    if explicit is not None:
        return strip_form_feed(explicit)
    doc = inspect.getdoc(f) if f is not None else None
    if doc is None:
        return None
    return truncate_form_feed(doc)


def _build(cls, f, name, attrs, register_on):
    params = _take_params(f)
    name = name if name is not None else _derive_name(f.__name__)
    help_text = _help_text(f, attrs)
    cmd = cls(name=name, callback=f, params=params, help=help_text, **attrs)
    if register_on is not None:
        register_on.add_command(cmd, cmd.name)
    return cmd


def command(name=None, cls=None, *, _register_on=None, **attrs):
    """Declare a command. Usable as ``@command()`` or ``@command``."""
    if callable(name) and cls is None and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        return _build(cls, f, name, dict(attrs), _register_on)

    return decorator


def group(name=None, cls=None, *, _register_on=None, **attrs):
    """Declare a group. Usable as ``@group()`` or ``@group``."""
    if callable(name) and cls is None and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        return _build(cls, f, name, dict(attrs), _register_on)

    return decorator


def option(*param_decls, cls=None, **attrs):
    cls = cls or Option

    def decorator(f):
        _memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    cls = cls or Argument

    def decorator(f):
        _memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


# --- callback decorators -----------------------------------------------------


def pass_context(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return wrapper


def pass_obj(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        ctx = get_current_context()
        return f(ctx.obj, *args, **kwargs)

    return wrapper


def make_pass_decorator(object_type, ensure: bool = False):
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return wrapper

    return decorator


# --- ready-made options --------------------------------------------------------


def _show_help_cb(ctx, param, value):
    if not value:
        return value
    ctx.command.show_help(ctx)
    ctx.exit(0)


def help_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", _show_help_cb)
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        _memo(f, Option(decls, **kwargs))
        return f

    return decorator


def _detect_version(package_name: str | None) -> str:
    if not package_name:
        return "unknown"
    try:
        return _md.version(package_name)
    except _md.PackageNotFoundError:
        pass
    try:
        dists = _md.packages_distributions().get(package_name)
    except Exception:
        dists = None
    if dists:
        try:
            return _md.version(dists[0])
        except _md.PackageNotFoundError:
            pass
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return value
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or "cli"
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        echo(text)
        ctx.exit(0)

    kwargs.setdefault("callback", callback)

    def decorator(f):
        _memo(f, Option(decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")

    def cb(ctx, param, value):
        if not value:
            return value
        echo(callback(ctx))
        ctx.exit(0)

    kwargs["callback"] = cb

    def decorator(f):
        _memo(f, Option(decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _memo(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def cb(ctx, param, value):
        if not value:
            confirm(question, default=False, abort=True)
        return value

    kwargs["callback"] = cb

    def decorator(f):
        _memo(f, Option(decls, **kwargs))
        return f

    return decorator
