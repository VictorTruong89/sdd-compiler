"""Terminal helpers (PRD FP-08, FP-11; Interface section 7)."""

from __future__ import annotations

import os
import re
import subprocess
import shlex
import sys
import time
from contextlib import contextmanager
from typing import Any, Callable, Iterable, Iterator

from .exceptions import Abort

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_BG = {k: v + 10 if v < 90 else v + 10 for k, v in _FG.items()}
_BG["reset"] = 49

_SWITCHES = {
    "bold": (1, 22), "dim": (2, 22), "italic": (3, 23), "underline": (4, 24),
    "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29), "overline": (53, 55),
}


def unstyle(text: str) -> str:
    return _ANSI_RE.sub("", str(text))


def _color_code(color, base: int) -> str:
    """base 38 for fg, 48 for bg."""
    if isinstance(color, str):
        if color not in _FG:
            raise TypeError(f"Unknown color {color!r}.")
        table = _FG if base == 38 else _BG
        return str(table[color])
    if isinstance(color, bool):
        raise TypeError("Invalid color.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color {color} out of range 0-255.")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
) -> str:
    codes: list[str] = []
    if fg is not None:
        codes.append(_color_code(fg, 38))
    if bg is not None:
        codes.append(_color_code(bg, 48))
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in flags.items():
        if on is None:
            continue
        on_code, off_code = _SWITCHES[name]
        codes.append(str(on_code) if on else str(off_code))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + str(text) + suffix


def _current_color_flag():
    try:
        from .context import get_current_context

        ctx = get_current_context(silent=True)
    except Exception:
        ctx = None
    if ctx is None:
        return None
    return getattr(ctx, "color", None)


def _is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _resolve_strip(stream, color) -> bool:
    """True if styles should be stripped from output to ``stream``."""
    if color is None:
        color = _current_color_flag()
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def _encode_for(stream, text: str):
    enc = getattr(stream, "encoding", None) or "utf-8"
    try:
        "".join(text).encode(enc)
        return text
    except (UnicodeEncodeError, LookupError):
        return text.encode("utf-8")


def _write(stream, text: str):
    payload = _encode_for(stream, text)
    if isinstance(payload, bytes):
        target = getattr(stream, "buffer", None)
        if target is not None:
            stream.flush()
            target.write(payload)
            target.flush()
            return
        stream.write(payload.decode("utf-8", "replace"))
        return
    stream.write(payload)


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        target = getattr(file, "buffer", None)
        if target is not None:
            file.flush()
            target.write(message + (b"\n" if nl else b""))
            target.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if _resolve_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _get_pager_cmd():
    return os.environ.get("PAGER")


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks: Iterable[str] = [text_or_generator]
    else:
        chunks = text_or_generator
    if not _is_tty(sys.stdin) or not _is_tty(sys.stdout):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    cmd = _get_pager_cmd()
    if not cmd:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(shlex.split(cmd), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            text = chunk
            if _resolve_strip(sys.stdout, color):
                text = unstyle(text)
            proc.stdin.write(text.encode("utf-8"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class _PagerStream:
    def __init__(self, color):
        self._color = color
        self._buf = []

    def write(self, data):
        self._buf.append(str(data))
        return len(data)

    def flush(self):
        return None


@contextmanager
def get_pager_file(color=None):
    stream = _PagerStream(color)
    yield stream
    echo_via_pager(iter(stream._buf), color=color)


class ProgressBar:
    """Iterable wrapper that reports progress when attached to a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden or not _is_tty(sys.stdout)
        self.pos = 0
        self.start = time.time()
        self.options = options
        if hidden is False and not _is_tty(sys.stdout) and label:
            echo(label)  # no terminal: the label is still printed once

    def _render(self):
        if self.hidden:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            elapsed = time.time() - self.start
            eta = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            bar_w = 30
            filled = int(bar_w * frac)
            line = f"\r{self.label or ''} [{'#' * filled}{'-' * (bar_w - filled)}] {self.pos}/{self.length} eta {int(eta)}s"
        else:
            line = f"\r{self.label or ''} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()

    def update(self, n_steps=1):
        self.pos += n_steps
        self._render()

    def __iter__(self) -> Iterator[Any]:
        if self.iterable is None:
            return iter(())
        for item in self.iterable:
            yield item
            self.update(1)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if not self.hidden:
            sys.stdout.write("\n")
            sys.stdout.flush()
        return False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


def _read_line(prompt_text: str, hide_input: bool) -> str:
    if hide_input:
        import getpass

        try:
            return getpass.getpass(prompt_text, stream=sys.stdout)
        except (EOFError, KeyboardInterrupt) as exc:
            raise Abort() from exc
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        raise Abort()
    line = line.rstrip("\n").rstrip("\r")
    if not _is_tty(sys.stdin):
        # Echo the typed line for captured/visible prompts.
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    return line


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    from .types import STRING, infer_type, _to_type

    if type is None:
        type = infer_type(default) or STRING
    else:
        type = _to_type(type)
    dflt = default() if callable(default) else default
    suffix_default = ""
    if dflt is not None and show_default:
        suffix_default = f" [{'*' * 6 if hide_input else dflt}]"
    while True:
        value = _read_line(f"{text}{suffix_default}{prompt_suffix}", hide_input)
        if value == "" and dflt is not None:
            value = dflt
        if confirmation_prompt:
            second = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input)
            if second != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return type.convert(value, None, None)
        except Exception as exc:
            echo(f"Error: {getattr(exc, 'message', exc)}", err=True)
            continue


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    suffix = " [y/N]" if not default else " [Y/n]"
    if not show_default:
        suffix = ""
    while True:
        sys.stdout.write(f"{text}{suffix}{prompt_suffix}")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line == "":
            raise Abort()
        answer = line.strip().lower()
        if not _is_tty(sys.stdin):
            sys.stdout.write(line.rstrip("\n") + "\n")
        if answer == "":
            result = bool(default)
        elif answer in ("y", "yes"):
            result = True
        elif answer in ("n", "no"):
            result = False
        else:
            echo("Error: invalid input", err=True)
            continue
        if not result and abort:
            raise Abort()
        return result


def getchar(echo=False) -> str:
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    stream = sys.stderr if err else sys.stdout
    if not (_is_tty(sys.stdin) and _is_tty(stream)):
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    import tempfile

    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        subprocess.call(shlex.split(editor_cmd) + [filename], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        before = os.path.getmtime(path)
        subprocess.call(shlex.split(editor_cmd) + [path], env=env)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == before and text is not None:
            return None
        return result
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def launch(url, wait=False, locate=False) -> int:
    if sys.platform == "darwin":
        args = ["open"]
    elif sys.platform.startswith("win"):
        args = ["cmd", "/c", "start", ""]
    else:
        args = ["xdg-open"]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    home = os.path.expanduser("~")
    if force_posix and sys.platform != "win32":
        return os.path.join(home, "." + "-".join(app_name.lower().split()))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(xdg, "-".join(app_name.lower().split()))


def format_filename(filename, shorten: bool = False) -> str:
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    if shorten:
        text = os.path.basename(text)
    return text
