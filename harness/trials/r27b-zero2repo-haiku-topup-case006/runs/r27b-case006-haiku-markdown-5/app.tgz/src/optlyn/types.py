"""Parameter types and conversion (PRD FP-05, FP-09; Interface section 5)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid
from typing import Any, Callable, Iterable, Sequence

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    envvar_list_splitter: str | None = None  # None -> whitespace split
    is_composite = False

    def convert(self, value: Any, param=None, ctx=None) -> Any:
        return value

    def fail(self, message: str, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None) -> str | None:
        return self.name.upper()

    def split_envvar(self, value: str) -> list[str]:
        if self.envvar_list_splitter is None:
            return value.split()
        return [v for v in value.split(self.envvar_list_splitter) if v != ""]

    def shell_complete(self, ctx, param, incomplete: str):
        return []

    def completion_kind(self) -> str | None:
        """Return 'path', 'dir', or None for shell completion behaviour."""
        return None

    def arity(self) -> int:
        return 1

    def __repr__(self) -> str:
        return f"<{type(self).__name__}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            text = str(value).strip()
            if not text or not text.lstrip("+-").isdigit():
                raise ValueError
            return int(text)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._tokens = [m.name for m in choices]
            self._is_enum = True
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]
            self._is_enum = False
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def _normalize(self, token: str) -> str:
        return token if self.case_sensitive else token.casefold()

    def convert(self, value, param=None, ctx=None):
        if any(value is c for c in self.choices):
            return value
        norm = self._normalize(str(value))
        for tok, original in zip(self._tokens, self.choices):
            if self._normalize(tok) == norm:
                return original
        self.fail(
            f"{value!r} is not one of {', '.join(repr(t) for t in self._tokens)}.",
            param,
            ctx,
        )

    def shell_complete(self, ctx, param, incomplete: str):
        return [t for t in self._tokens if t.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"

    DEFAULT_FORMATS = (
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    )

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param,
            ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        return f"[{'(' if self.min_open else ''}{lo}..{hi}{')' if self.max_open else ''}]"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None:
            if v < self.min or (self.min_open and v == self.min):
                if self.clamp:
                    v = self.min + 1 if self.min_open else self.min
                else:
                    self._range_fail(v, param, ctx)
        if self.max is not None:
            if v > self.max or (self.max_open and v == self.max):
                if self.clamp:
                    v = self.max - 1 if self.max_open else self.max
                else:
                    self._range_fail(v, param, ctx)
        return v

    def _range_fail(self, v, param, ctx):
        self.fail(f"{v} is out of the range {self.get_metavar()}.", param, ctx)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise TypeError("FloatRange clamp is not allowed with an open bound.")
        if clamp and (min is None or max is None):
            raise TypeError("FloatRange clamp requires both bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        return f"[{'(' if self.min_open else ''}{lo}..{hi}{')' if self.max_open else ''}]"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and v < self.min:
                v = float(self.min)
            if self.max is not None and v > self.max:
                v = float(self.max)
            return v
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            self.fail(f"{v} is out of the range {self.get_metavar()}.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            self.fail(f"{v} is out of the range {self.get_metavar()}.", param, ctx)
        return v


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types: Sequence):
        self.types = [_to_type(t) for t in types]

    def arity(self) -> int:
        return len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)

    def convert(self, value, param=None, ctx=None):
        values = list(value)
        if len(values) != len(self.types):
            self.fail(f"requires exactly {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, values))


class _PathLike(ParamType):
    def completion_kind(self):
        return "path"


class Path(_PathLike):
    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def completion_kind(self):
        if self.dir_okay and not self.file_okay:
            return "dir"
        return "path"

    def convert(self, value, param=None, ctx=None):
        raw = os.fsdecode(value) if isinstance(value, bytes) else str(value)
        if self.allow_dash and raw == "-":
            return self._deliver("-")
        path = raw
        if self.resolve_path:
            path = os.path.realpath(path)
        exists = os.path.exists(path)
        if not exists:
            if self.exists:
                self.fail(f"{raw!r} does not exist.", param, ctx)
            return self._deliver(path)
        if os.path.isdir(path):
            if not self.dir_okay:
                self.fail(f"{raw!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{raw!r} is a file.", param, ctx)
        if self.readable and not os.access(path, os.R_OK):
            self.fail(f"{raw!r} is not readable.", param, ctx)
        if self.writable and not os.access(path, os.W_OK):
            self.fail(f"{raw!r} is not writable.", param, ctx)
        if self.executable and not os.access(path, os.X_OK):
            self.fail(f"{raw!r} is not executable.", param, ctx)
        return self._deliver(path)

    def _deliver(self, path: str):
        if self.path_type is pathlib.Path:
            return pathlib.Path(path)
        return path


class File(_PathLike):
    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported File mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def completion_kind(self):
        return "path"

    @property
    def _is_read(self) -> bool:
        return self.mode.startswith("r")

    def convert(self, value, param=None, ctx=None):
        from .fileio import open_file_value

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = not self._is_read
        filename = os.fsdecode(value) if isinstance(value, bytes) else str(value)
        try:
            return open_file_value(
                filename,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"could not open {filename!r}: {exc.strerror or exc}.", param, ctx)


UUID = UUIDParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UNPROCESSED = UnprocessedParamType()


def _to_type(obj) -> ParamType:
    """Coerce a Python type, a ParamType, or a conversion function to a ParamType."""
    if isinstance(obj, ParamType):
        return obj
    if obj is None or obj is str:
        return STRING
    if obj is bool:
        return BOOL
    if obj is int:
        return INT
    if obj is float:
        return FLOAT
    if obj is _uuid.UUID:
        return UUID
    if isinstance(obj, tuple):
        return Tuple(obj)
    if isinstance(obj, type) and issubclass(obj, ParamType):
        return obj()
    if callable(obj):
        return FuncParamType(obj)
    raise TypeError(f"unsupported parameter type: {obj!r}")


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func: Callable[[Any], Any]):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def infer_type(default) -> ParamType | None:
    """Infer a type from a default value (FP-03/FP-05)."""
    if default is None or callable(default):
        return None
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, _uuid.UUID):
        return UUID
    if isinstance(default, (tuple, list)) and default:
        return Tuple([infer_type(x) or STRING for x in default])
    return None
