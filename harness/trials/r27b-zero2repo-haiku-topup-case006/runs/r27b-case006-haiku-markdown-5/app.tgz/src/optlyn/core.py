"""Commands, groups, and dispatch (PRD FP-01, FP-02, FP-03, FP-04, FP-06, FP-10, FP-13)."""

from __future__ import annotations

import os
import sys
from typing import Any

from .context import Context, ParameterSource, _stack
from .exceptions import (
    Abort,
    BadParameter,
    DeclarationError,
    Exit,
    MissingCommand,
    MissingParameter,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import (
    DEFAULT_MAX_CONTENT_WIDTH,
    detect_width,
    short_help_text,
    strip_form_feed,
    truncate_form_feed,
    wrap_text,
)
from .parameters import Argument, Option, Parameter, _MISSING
from .parser import HELP_SENTINEL, parse_tokens
from .termui import echo
from .types import Tuple

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


def _env_flag(param: Option, raw: str):
    """Interpret a boolean flag environment value (PRD FP-03). None means unset."""
    text = raw.strip().lower()
    fv = param.flag_value
    if not isinstance(fv, bool):
        if text == str(fv).lower():
            return fv
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        return None
    if text == "" or text in _FALSE:
        return False
    if text in _TRUE:
        return True
    raise BadParameter(f"{raw!r} is not a valid boolean.", param=param)


class Command:
    """A leaf command: parses a token slice and runs the author callback."""

    allow_interspersed_args = True
    allow_extra_args = False

    def __init__(
        self,
        name: str | None = None,
        callback=None,
        params=None,
        *,
        help: str | None = None,
        short_help: str | None = None,
        epilog: str | None = None,
        options_metavar: str | None = "[OPTIONS]",
        context_settings: dict | None = None,
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        deprecated=False,
        hidden: bool = False,
        **_ignored,
    ):
        self.name = name
        self.callback = callback
        self.params: list[Parameter] = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self._check_params()

    # --- declaration -----------------------------------------------------
    def _check_params(self):
        seen = set()
        for p in self.params:
            if p.name in seen and isinstance(p, Argument):
                raise DeclarationError(f"duplicate destination {p.name!r}")
            seen.add(p.name)
        variadic = [p for p in self.params if isinstance(p, Argument) and p.variadic]
        if len(variadic) > 1:
            raise DeclarationError("only one variadic argument is allowed per command.")

    @property
    def options(self) -> list[Option]:
        return [p for p in self.params if isinstance(p, Option)]

    @property
    def arguments(self) -> list[Argument]:
        return [p for p in self.params if isinstance(p, Argument)]

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help is not None:
            return self.short_help
        return short_help_text(self.help or "", limit)

    # --- contexts --------------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra) -> Context:
        settings = dict(self.context_settings)
        settings.update(extra)
        if parent is None and "default_map" not in settings:
            settings["default_map"] = None
        if parent is not None and parent.default_map and isinstance(parent.default_map, dict):
            sub = parent.default_map.get(info_name)
            if isinstance(sub, dict):
                settings["default_map"] = sub
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        ctx._args = list(args)
        return ctx

    # --- parsing ---------------------------------------------------------
    def _help_names(self, ctx) -> list[str]:
        return list(ctx.help_option_names) if self.add_help_option else []

    def _eager_help_names(self, ctx):
        names = self._help_names(ctx)
        declared = {n for p in self.params for n in getattr(p, "opts", [])}
        return [n for n in names if n not in declared]

    def _parse(self, ctx, tokens, *, stop_mode=False, limit=None):
        return parse_tokens(
            tokens,
            self.params,
            ctx,
            help_names=self._eager_help_names(ctx),
            stop_after_positionals=limit,
            stop_mode=stop_mode,
            interspersed=ctx.allow_interspersed_args,
            ignore_unknown=ctx.ignore_unknown_options,
        )

    def _fixed_arity(self) -> int:
        return sum(a.nargs for a in self.arguments if not a.variadic)

    def _env_for_argument(self, ctx, arg: Argument):
        if not arg.envvars:
            return None
        for name in arg.envvars:
            if name in os.environ and os.environ[name] != "":
                return os.environ[name]
        return None

    def _bind_arguments(self, ctx, positional: list) -> dict:
        """Bind positional tokens to arguments. Returns dest -> ('tokens', value) or sentinel."""
        bound: dict[str, Any] = {}
        idx = 0
        args = self.arguments
        for pos, arg in enumerate(args):
            if arg.variadic:
                later_fixed = sum(a.nargs for a in args[pos + 1:] if not a.variadic)
                end = max(idx, len(positional) - later_fixed)
                take = positional[idx:end]
                idx = end
                bound[arg.name] = take if take else None
                continue
            need = arg.nargs
            take = positional[idx:idx + need]
            if len(take) == need:
                idx += need
                bound[arg.name] = take
            else:
                bound[arg.name] = None
        extra = positional[idx:]
        if extra and not ctx.allow_extra_args:
            raise UsageError(f"Got unexpected extra argument{'s' if len(extra) > 1 else ''} ({' '.join(extra)})", ctx)
        if extra:
            ctx.extra_args = extra
        return bound

    def _process_option(self, ctx, param: Option, res):
        occ = res.occurrences.get(param.name)
        if param.is_flag:
            if param.count:
                if occ:
                    return sum(occ), ParameterSource.COMMANDLINE
                return 0, None
            if occ:
                return occ[-1], ParameterSource.COMMANDLINE
        elif occ:
            # prompting option given with no value -> prompt below
            tokens_occ = [o for o in occ if o != ()]
            if tokens_occ:
                converted = [param.convert_token(ctx, o) for o in tokens_occ]
                if param.multiple:
                    return tuple(converted), ParameterSource.COMMANDLINE
                if param.nargs != 1 and not isinstance(param.type, Tuple):
                    return tuple(converted[-1]), ParameterSource.COMMANDLINE
                return converted[-1], ParameterSource.COMMANDLINE
            # bare flag (no tokens) on prompting option
            if param.prompt_enabled:
                return self._prompt(ctx, param), ParameterSource.PROMPT

        # environment
        if param.is_flag:
            raw = param.env_raw(ctx) if param.env_names(ctx) else None
            if raw is not None:
                val = _env_flag(param, raw)
                if val is not None:
                    return val, ParameterSource.ENVIRONMENT
        else:
            raw = param.env_raw(ctx)
            if raw is not None:
                return param.value_from_env(ctx, raw), ParameterSource.ENVIRONMENT

        # prompt for omitted option that requires it
        dm = param.default_map_value(ctx)
        if param.prompt_enabled and param.prompt_required and not param.is_flag:
            if dm is not _MISSING:
                return self._prompt(ctx, param, shown_default=dm), ParameterSource.PROMPT
            return self._prompt(ctx, param), ParameterSource.PROMPT

        if dm is not _MISSING:
            return param.value_from_default(ctx, dm), ParameterSource.DEFAULT_MAP

        if param.is_flag:
            if param.has_default():
                return param.value_from_default(ctx, param.get_default(ctx)), ParameterSource.DEFAULT
            return False, None
        if param.has_default():
            d = param.get_default(ctx)
            if d is None:
                return (() if param.multiple else None), ParameterSource.DEFAULT
            return param.value_from_default(ctx, d), ParameterSource.DEFAULT
        if param.multiple:
            return (), None
        return None, None

    def _prompt(self, ctx, param: Option, shown_default=_MISSING):
        from .termui import prompt as _prompt_fn

        text = param.prompt_text or (param.name or "").replace("_", " ").capitalize()
        if shown_default is _MISSING:
            default = param.get_default(ctx) if param.has_default() else None
        else:
            default = shown_default
        value = _prompt_fn(
            text,
            default=default,
            hide_input=param.hide_input,
            confirmation_prompt=param.confirmation_prompt,
            type=param.type,
        )
        return value

    def _process_argument(self, ctx, arg: Argument, tokens):
        if tokens is not None and tokens != []:
            return arg.convert_tokens(ctx, tokens), ParameterSource.COMMANDLINE
        if tokens == [] and arg.variadic:
            pass
        env = self._env_for_argument(ctx, arg)
        if env is not None:
            if arg.variadic or arg.nargs != 1:
                parts = arg.type.split_envvar(env)
                if arg.variadic:
                    return tuple(arg.type.convert(p, arg, ctx) for p in parts), ParameterSource.ENVIRONMENT
                return arg.convert_tokens(ctx, parts), ParameterSource.ENVIRONMENT
            return arg.type.convert(env, arg, ctx), ParameterSource.ENVIRONMENT
        dm = arg.default_map_value(ctx)
        if dm is not _MISSING:
            return arg.value_from_default(ctx, dm), ParameterSource.DEFAULT_MAP
        if arg.variadic:
            if arg.required:
                raise MissingParameter(ctx=ctx, param=arg)
            if arg.has_default():
                return arg.value_from_default(ctx, arg.get_default(ctx)), ParameterSource.DEFAULT
            return (), None
        if arg.has_default():
            d = arg.get_default(ctx)
            if d is None:
                return None, ParameterSource.DEFAULT
            return arg.value_from_default(ctx, d), ParameterSource.DEFAULT
        if arg.required:
            raise MissingParameter(ctx=ctx, param=arg)
        return None, None

    def _bind_values(self, ctx, res, bound):
        """Resolve every parameter and run callbacks. Fills ctx.params."""
        # eager parameters first, in the order the user typed them
        for item, _idx in res.eager:
            if item is HELP_SENTINEL:
                self.show_help(ctx, stream=sys.stdout)
                raise Exit(0)
            value, _src = self._process_option(ctx, item, res)
            item.run_callback(ctx, value)
            ctx.params[item.name] = value
            ctx.set_source(item.name, _src or ParameterSource.COMMANDLINE)
            if item.is_eager and (item.is_flag and value):
                raise Exit(0)
        # deprecation warnings for supplied parameters
        for p in res.deprecated_used:
            note = p.deprecated if isinstance(p.deprecated, str) else None
            msg = f"DeprecationWarning: The {'option' if isinstance(p, Option) else 'argument'} '{p.hint() if isinstance(p, Option) else p.name}' is deprecated."
            echo(msg + (f" {note}" if note else ""), err=True)
        for p in self.params:
            if p.is_eager and p in [x for x, _ in res.eager]:
                continue
            if isinstance(p, Option):
                value, src = self._process_option(ctx, p, res)
            else:
                value, src = self._process_argument(ctx, p, bound.get(p.name))
            if p.required and src is None:
                raise MissingParameter(ctx=ctx, param=p)
            value = p.run_callback(ctx, value)
            if p.expose_value:
                ctx.params[p.name] = value
            if src is not None:
                ctx.set_source(p.name, src)

    def parse_args(self, ctx, args=None, *, chain=False):
        """Parse and bind; returns the leftover tokens (chain subcommand boundary)."""
        tokens = list(getattr(ctx, "_args", []) if args is None else args)
        arity = self._fixed_arity()
        has_var = any(a.variadic for a in self.arguments)
        limit = arity if (chain and not has_var) else None
        res = self._parse(ctx, tokens, stop_mode=chain and not has_var, limit=limit)
        bound = self._bind_arguments(ctx, res.positional)
        ctx.parse_result = res
        self._bind_values(ctx, res, bound)
        return res.rest

    # --- running ---------------------------------------------------------
    def invoke(self, ctx: Context):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else None
            echo(f"DeprecationWarning: The command '{self.name}' is deprecated." + (f" {note}" if note else ""), err=True)
        if self.no_args_is_help and not getattr(ctx, "_args", None):
            self.show_help(ctx, stream=sys.stderr)
            raise UsageError("", ctx, show_help=True)
        self.parse_args(ctx)
        return self._run_callback(ctx)

    def invoke_with_values(self, ctx: Context, values: dict):
        """Run with explicit values; parameters not supplied fall back to their declared default."""
        for p in self.params:
            if not p.expose_value:
                continue
            if p.name in values:
                ctx.params[p.name] = p.run_callback(ctx, values[p.name])
                ctx.set_source(p.name, ParameterSource.COMMANDLINE)
                continue
            if isinstance(p, Option) and p.is_flag and p.count:
                value = 0
            elif p.has_default():
                value = p.value_from_default(ctx, p.get_default(ctx))
            elif isinstance(p, Option) and p.multiple:
                value = ()
            else:
                value = None
            ctx.params[p.name] = p.run_callback(ctx, value)
        return self._run_callback(ctx)

    def _run_callback(self, ctx: Context):
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        return self.callback(**kwargs)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "cli")
            if prog_name.endswith(".py"):
                prog_name = prog_name[:-3]
        var = complete_var or ("_" + prog_name.upper().replace("-", "_") + "_COMPLETE")
        if var in os.environ and os.environ[var]:
            from .completion import handle_completion

            handled = handle_completion(self, prog_name, args, os.environ[var], var)
            if standalone_mode:
                sys.stdout.flush()
                sys.exit(0 if handled else 1)
            return None

        ctx = None
        try:
            ctx = self.make_context(prog_name, args, **extra)
            with ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.stdout.flush()
                sys.exit(0)
        except Exit as e:
            if not standalone_mode:
                return e.exit_code
            sys.stdout.flush()
            sys.exit(e.exit_code)
        except UsageError as e:
            if not standalone_mode:
                raise
            if e.message:
                e.show()
            sys.exit(2)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        finally:
            if ctx is not None:
                ctx.close()

    # --- help ------------------------------------------------------------
    def command_path(self, ctx: Context) -> str:
        return " ".join(n for n in ctx.path_names if n)

    def _width(self, ctx) -> int:
        return detect_width(ctx.max_content_width or DEFAULT_MAX_CONTENT_WIDTH, ctx.terminal_width)

    def format_usage(self, ctx) -> str:
        parts = [self.command_path(ctx)]
        if self.options or self.add_help_option:
            parts.append(self.options_metavar or "")
        for a in self.arguments:
            ph = a.get_metavar()
            if a.variadic:
                ph = ph + "..."
            parts.append(ph if a.required else f"[{ph}]")
        return "Usage: " + " ".join(p for p in parts if p)

    def format_help(self, ctx) -> str:
        width = self._width(ctx)
        lines: list[str] = [self.format_usage(ctx), ""]
        desc = self.help
        if desc is None and self.callback is not None and getattr(self.callback, "__doc__", None):
            desc = truncate_form_feed(self.callback.__doc__)
        if desc:
            desc = strip_form_feed(desc)
            lines.append(wrap_text(inspect_cleandoc(desc), width=width, initial_indent="  ", subsequent_indent="  "))
            lines.append("")
        if self.deprecated:
            lines.append("  (Deprecated)")
            lines.append("")
        arg_rows = [(a.get_metavar(), a.help) for a in self.arguments if a.help and not a.hidden]
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(_rows(arg_rows, width))
            lines.append("")
        opt_rows = []
        for o in self.options:
            if o.hidden:
                continue
            names = ", ".join(o.opts + o.secondary_opts)
            metavar = o.get_metavar()
            if metavar:
                names = f"{names} {metavar}"
            extras = []
            if o.help:
                extras.append(o.help)
            show = o.show_default if o.show_default is not None else ctx.show_default
            if show and o.has_default():
                default = o.get_default(ctx)
                # a single-option boolean flag defaulting to off keeps its default hidden
                if not (o.is_flag and default is False):
                    text = show if isinstance(show, str) else str(default)
                    extras.append(f"[default: {text}]")
            if o.show_envvar and o.envvars:
                extras.append(f"[env var: {', '.join(o.envvars)}]")
            if o.deprecated:
                extras.append("(Deprecated)")
            opt_rows.append((names, " ".join(extras)))
        if self.add_help_option:
            opt_rows.append((", ".join(ctx.help_option_names), "Show this message and exit."))
        if opt_rows:
            lines.append("Options:")
            lines.extend(_rows(opt_rows, width))
            lines.append("")
        lines.extend(self._command_section(ctx, width))
        if self.epilog:
            lines.append(wrap_text(self.epilog, width=width))
        return "\n".join(lines).rstrip() + "\n"

    def _command_section(self, ctx, width) -> list[str]:
        return []

    def show_help(self, ctx, stream=None):
        text = self.format_help(ctx)
        echo(text, file=stream or sys.stdout, nl=False)


def inspect_cleandoc(text: str) -> str:
    import inspect

    return inspect.cleandoc(text)


def _rows(rows, width):
    from .formatting import two_column

    return two_column([(a, b) for a, b in rows], width=width)


class Group(Command):
    """Dispatches to named subcommands (PRD FP-06, FP-10)."""

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command: bool = False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain: bool = False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        kwargs["no_args_is_help"] = no_args_is_help
        super().__init__(name=name, **kwargs)
        self.commands: dict[str, Command] = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_fn = result_callback
        self._deferred: list = []

    allow_interspersed_args = False

    # --- registration ----------------------------------------------------
    def add_command(self, cmd: Command, name: str | None = None):
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if key is None:
            raise DeclarationError("command needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        return _command(*args, **kwargs, _register_on=self)

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        return _group(*args, **kwargs, _register_on=self)

    def result_callback(self):
        def decorator(f):
            self.result_callback_fn = f
            return f

        return decorator

    # --- lookup overrides ------------------------------------------------
    def list_commands(self, ctx) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name: str):
        norm = ctx.token_normalize_func
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        if norm:
            for key, cmd in self.commands.items():
                if norm(key) == norm(cmd_name):
                    return cmd
        return None

    # --- help ------------------------------------------------------------
    def format_usage(self, ctx) -> str:
        base = super().format_usage(ctx)
        if self.chain:
            tail = "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        elif self.invoke_without_command:
            tail = "[COMMAND] [ARGS]..."
        else:
            tail = "COMMAND [ARGS]..."
        return f"{base} {tail}"

    def _command_section(self, ctx, width) -> list[str]:
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(45)))
        if not rows:
            return []
        return ["Commands:"] + _rows(rows, width) + [""]

    # --- running ---------------------------------------------------------
    def invoke(self, ctx: Context):
        if self.deprecated:
            echo(f"DeprecationWarning: The command '{self.name}' is deprecated.", err=True)
        raw_args = list(getattr(ctx, "_args", []))
        if self.no_args_is_help and not raw_args:
            self.show_help(ctx, stream=sys.stderr)
            raise UsageError("", ctx, show_help=True)

        limit = self._fixed_arity() if not any(a.variadic for a in self.arguments) else None
        rest = self.parse_args(ctx, raw_args, chain=True if limit is not None else False)
        if limit is None:
            rest = []

        if self.chain:
            return self._invoke_chain(ctx, raw_args, rest)

        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                return self._run_callback_and_result(ctx, None)
            raise MissingCommand(ctx)

        name, tail = rest[0], rest[1:]
        child = self.get_command(ctx, name)
        if child is None:
            raise NoSuchCommand(name, ctx)
        ctx.invoked_subcommand = child.name if child.name is not None else name
        self._run_callback_and_result(ctx, None, pre=True)
        sub_ctx = child.make_context(name, tail, parent=ctx)
        with sub_ctx:
            value = child.invoke(sub_ctx)
        return self._apply_result(ctx, value)

    def _run_callback_and_result(self, ctx, value, pre=False):
        if pre:
            return self._run_callback(ctx) if self.callback is not None else None
        value = self._run_callback(ctx)
        return self._apply_result(ctx, value)

    def _apply_result(self, ctx, value):
        if self.result_callback_fn is not None:
            return self.result_callback_fn(value, **ctx.params)
        return value

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        return super()._run_callback(ctx)

    def _invoke_chain(self, ctx, raw_args, rest):
        ctx.invoked_subcommand = _CHAIN
        results = []
        self._run_callback_pre(ctx)
        while rest:
            name, tail = rest[0], rest[1:]
            child = self.get_command(ctx, name)
            if child is None:
                raise NoSuchCommand(name, ctx)
            if isinstance(child, Group):
                raise DeclarationError("groups cannot be nested under a chaining group.")
            sub_ctx = child.make_context(name, tail, parent=ctx)
            with sub_ctx:
                leftover = child.parse_args(sub_ctx, tail, chain=True)
                results.append(child._run_callback(sub_ctx))
            rest = leftover
        if self.result_callback_fn is not None:
            return self.result_callback_fn(results, **ctx.params)
        return results

    def _run_callback_pre(self, ctx):
        if self.callback is not None:
            self._run_callback(ctx)


_CHAIN = object()


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> list[str]:
        names: set[str] = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name: str):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            found = src.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None
