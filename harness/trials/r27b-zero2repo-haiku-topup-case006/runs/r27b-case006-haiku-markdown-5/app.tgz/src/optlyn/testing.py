"""In-process runner (PRD FP-14; Interface section 9)."""

from __future__ import annotations

import io
import os
import shutil
import sys
import tempfile
from contextlib import contextmanager


class _Recorder(io.TextIOBase):
    """A text stream that records writes to its own buffer and to a shared, ordered log."""

    def __init__(self, name: str, log: list, charset: str):
        super().__init__()
        self._name = name
        self._log = log
        self._charset = charset
        self.bytes_buf = io.BytesIO()
        self.buffer = self  # ``buffer`` yields raw bytes writes for echo(bytes)

    @property
    def encoding(self):
        return self._charset

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, s):
        if isinstance(s, bytes):
            data = s
        else:
            data = s.encode(self._charset, "replace")
        self.bytes_buf.write(data)
        self._log.append((self._name, data))
        return len(s)

    def flush(self):
        return None


class Result:
    def __init__(self, exit_code, stdout_bytes, stderr_bytes, output_bytes, exception, charset):
        self.exit_code = exit_code
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exception = exception
        self._charset = charset

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self._charset, "replace")

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self._charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None):
        log: list = []
        out = _Recorder("stdout", log, self.charset)
        err = _Recorder("stderr", log, self.charset)
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = input
        stdin_text = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
        stdin_text.isatty = lambda: False  # type: ignore[assignment]

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for k, v in merged_env.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin_text, out, err
        try:
            yield (out, err, log)
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env) as (out, err, log):
            extra.setdefault("prog_name", "cli")
            extra.setdefault("standalone_mode", True)
            try:
                try:
                    cli.main(args=list(args), color=color, **extra)
                except SystemExit as e:
                    code = e.code
                    if code is None:
                        exit_code = 0
                    elif isinstance(code, int):
                        exit_code = code
                    else:
                        exit_code = 1
                        sys.stderr.write(str(code) + "\n")
                except Exception as e:  # noqa: BLE001 - reported on the result
                    if not catch_exceptions:
                        raise
                    exception = e
                    exit_code = 1
            finally:
                pass
        stdout_bytes = b"".join(d for n, d in log if n == "stdout")
        stderr_bytes = b"".join(d for n, d in log if n == "stderr")
        output_bytes = b"".join(d for _, d in log)
        return Result(exit_code, stdout_bytes, stderr_bytes, output_bytes, exception, self.charset)

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            os.makedirs(temp_dir, exist_ok=True)
            path = tempfile.mkdtemp(dir=temp_dir)
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
