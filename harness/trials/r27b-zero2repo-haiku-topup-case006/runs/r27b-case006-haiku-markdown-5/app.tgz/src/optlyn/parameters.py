"""Parameters (options and arguments): declaration, sources, conversion (PRD FP-03, FP-04, FP-05, FP-07, FP-08)."""

from __future__ import annotations

import os
from typing import Any

from .context import ParameterSource
from .exceptions import BadParameter, DeclarationError, MissingParameter
from .types import BOOL, INT, STRING, ParamType, Tuple, _to_type, infer_type

_MISSING = object()
UNSET = _MISSING

BOOL_TRUE = {"1", "true", "t", "yes", "y", "on"}
BOOL_FALSE = {"0", "false", "f", "no", "n", "off"}


class Parameter:
    """Common base for Option and Argument."""

    param_type_name = "parameter"

    def __init__(
        self,
        decls,
        *,
        type=None,
        required: bool = False,
        default: Any = _MISSING,
        callback=None,
        nargs: int = 1,
        multiple: bool = False,
        metavar: str | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar=None,
        help: str | None = None,
        hidden: bool = False,
        deprecated=False,
        show_default=None,
        show_envvar: bool = False,
        shell_complete=None,
        allow_from_autoenv: bool = True,
    ):
        self.name = decls[0] if decls else None
        self.type_arg = type
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvars: list[str] | None = None
        elif isinstance(envvar, str):
            self.envvars = [envvar]
        else:
            self.envvars = list(envvar)
        self.help = help
        self.hidden = hidden
        self.deprecated = deprecated
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete_fn = shell_complete
        self.allow_from_autoenv = allow_from_autoenv
        self.is_flag = False
        self.count = False
        self.flag_value = True
        self.prompt = None
        self.prompt_required = True
        self.hide_input = False
        self.confirmation_prompt = False
        self.type: ParamType = STRING

    # --- type inference -------------------------------------------------
    def _finalize_type(self):
        if self.type_arg is not None:
            self.type = _to_type(self.type_arg)
            if isinstance(self.type, Tuple):
                self.nargs = len(self.type.types)
            return
        if self.is_flag:
            self.type = BOOL
            return
        if self.count:
            self.type = INT
            return
        d = self.default
        if d is not _MISSING and d is not None and not callable(d):
            if (self.multiple or self.nargs != 1) and isinstance(d, (list, tuple)):
                if d:
                    inner = infer_type(d[0]) or STRING
                    self.type = inner
                    return
            else:
                inferred = infer_type(d)
                if inferred is not None:
                    self.type = inferred
                    return
        self.type = STRING

    def hint(self) -> str:
        return self.name or ""

    def get_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self) or self.type.name.upper()

    def has_default(self) -> bool:
        return self.default is not _MISSING

    def get_default(self, ctx):
        d = self.default
        if callable(d):
            d = d()
        return d

    # --- sources ---------------------------------------------------------
    def env_names(self, ctx) -> list[str]:
        names = list(self.envvars or [])
        prefix = ctx.auto_envvar_prefix if ctx is not None else None
        if prefix and self.allow_from_autoenv and self.name and not isinstance(self, Argument):
            parts = [prefix] + list(ctx.path_names[1:] if ctx.path_names else []) + [self.name]
            auto = "_".join(p.replace("-", "_") for p in parts).upper()
            if auto not in names:
                names.append(auto)
        return names

    def env_raw(self, ctx):
        """Return the first non-empty env value, or None."""
        for name in self.env_names(ctx):
            if name in os.environ and os.environ[name] != "":
                return os.environ[name]
        return None

    def default_map_value(self, ctx):
        dm = ctx.default_map if ctx is not None else None
        if not dm or not isinstance(dm, dict):
            return _MISSING
        if self.name in dm:
            return dm[self.name]
        return _MISSING

    # --- conversion ------------------------------------------------------
    def convert_token(self, ctx, occ):
        """Convert one occurrence, given as a tuple of ``nargs`` raw tokens."""
        if isinstance(self.type, Tuple):
            return self.type.convert(list(occ), self, ctx)
        if self.nargs == 1:
            return self.type.convert(occ[0], self, ctx)
        return tuple(self.type.convert(t, self, ctx) for t in occ)

    def split_string(self, value):
        if isinstance(value, str) and (self.multiple or self.nargs != 1 or isinstance(self.type, Tuple)):
            return self.type.split_envvar(value)
        return value

    def shape(self, occurrences: list):
        """Shape a list of converted occurrences into the delivered value."""
        if self.multiple:
            return tuple(occurrences)
        if self.nargs != 1 and not isinstance(self.type, Tuple):
            return tuple(occurrences[0]) if occurrences else None
        if self.nargs != 1 and isinstance(self.type, Tuple):
            return occurrences[0]
        return occurrences[0] if occurrences else None

    def value_from_default(self, ctx, raw):
        """Convert a default-map or declared default value."""
        if self.multiple:
            if not isinstance(raw, (list, tuple)):
                raise BadParameter(
                    f"needs an iterable (sequence) default, got {raw!r}.",
                    ctx=ctx, param=self,
                )
            return tuple(self.type.convert(v, self, ctx) for v in raw)
        if self.nargs != 1 and not isinstance(self.type, Tuple):
            if isinstance(raw, str):
                raw = self.split_string(raw)
            return tuple(self.type.convert(v, self, ctx) for v in raw)
        if isinstance(self.type, Tuple):
            if isinstance(raw, str):
                raw = self.split_string(raw)
            return self.type.convert(raw, self, ctx)
        return self.type.convert(raw, self, ctx)

    def value_from_env(self, ctx, raw: str):
        if self.multiple or self.nargs != 1 or isinstance(self.type, Tuple):
            parts = self.split_string(raw)
            if self.nargs != 1 and not isinstance(self.type, Tuple):
                if len(parts) % self.nargs:
                    raise BadParameter(f"environment value needs a multiple of {self.nargs} items.", ctx=ctx, param=self)
                groups = [tuple(parts[i:i + self.nargs]) for i in range(0, len(parts), self.nargs)]
                return self.shape([self.convert_token(ctx, g) for g in groups])
            if isinstance(self.type, Tuple):
                return self.shape([self.type.convert(parts, self, ctx)])
            return tuple(self.type.convert(p, self, ctx) for p in parts) if self.multiple else self.type.convert(parts[0], self, ctx)
        return self.type.convert(raw, self, ctx)

    def run_callback(self, ctx, value):
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def shell_complete(self, ctx, incomplete: str):
        if self.shell_complete_fn is not None:
            return self.shell_complete_fn(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, decls, *, is_flag=None, count=False, flag_value=None, prompt=None,
                 prompt_required=True, hide_input=False, confirmation_prompt=False, **kwargs):
        self.opts: list[str] = []
        self.secondary_opts: list[str] = []
        self.prefixes: set[str] = {"-"}
        dest = None
        for decl in decls:
            parts = decl.split("/") if decl and decl[0] in "-/+" else [decl]
            # on/off pair: "--shout/--no-shout" (second part starts with a prefix char)
            if len(parts) == 2 and parts[0] and parts[1][:1] in ("-", "+", "/") and parts[1][:1]:
                self._add_name(parts[0])
                self._add_secondary(parts[1])
            elif decl and decl[0] in "-/+":
                self._add_name(decl)
            else:
                if dest is not None:
                    raise DeclarationError(f"option declares more than one destination: {decls}")
                dest = decl
        if not self.opts and not self.secondary_opts and dest is None:
            raise DeclarationError("option needs at least one flag name or a destination.")
        if dest is None:
            dest = self._infer_dest()
        kwargs.setdefault("nargs", 1)
        super().__init__([dest] + [], **kwargs)
        self.name = dest
        self.is_flag = bool(is_flag) if is_flag is not None else bool(self.secondary_opts or (
            isinstance(kwargs.get("default"), bool) and kwargs.get("type") is None))
        self.count = bool(count)
        if self.count:
            self.is_flag = True
        self.flag_value = True if flag_value is None else flag_value
        if self.secondary_opts:
            self.is_flag = True
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_enabled = bool(prompt)
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        if self.deprecated and self.required:
            raise DeclarationError("a deprecated option cannot also be required.")
        if self.deprecated and self.prompt_enabled:
            raise DeclarationError("a deprecated option cannot use a prompt.")
        if self.is_flag and self.nargs != 1:
            raise DeclarationError("a flag cannot take a value count.")
        self._finalize_type()

    def _infer_dest(self) -> str:
        names = self.opts + self.secondary_opts
        for n in names:
            bare = n.lstrip("-/+")
            if bare.isidentifier():
                return bare
        for n in names:
            if n.startswith(tuple(self.prefixes)) and n[:2] in ("--", "//", "++") and n.lstrip("-/+"):
                return n.lstrip("-/+").replace("-", "_")
        return names[0].lstrip("-/+").replace("-", "_")

    def _add_name(self, decl: str):
        self.prefixes.add(decl[0])
        self.opts.append(decl)

    def _add_secondary(self, decl: str):
        self.prefixes.add(decl[0])
        self.secondary_opts.append(decl)

    def hint(self) -> str:
        names = self.opts + self.secondary_opts
        return " / ".join(names) if names else (self.name or "")

    def get_metavar(self) -> str:
        if self.is_flag or self.count:
            return ""
        return super().get_metavar()

class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, decls, *, nargs=1, **kwargs):
        if len(decls) != 1 or not decls[0] or decls[0][0] in "-/+":
            raise DeclarationError("an argument takes exactly one destination name.")
        if nargs == -1:
            nargs_v = -1
        elif isinstance(nargs, int) and nargs >= 1:
            nargs_v = nargs
        else:
            raise DeclarationError("argument nargs must be a positive int or -1.")
        self.variadic = nargs_v == -1
        required = kwargs.pop("required", None)
        default = kwargs.get("default", _MISSING)
        optional = kwargs.pop("optional", None)
        if required is None:
            # A variadic argument omitted yields () unless marked required.
            # Any other argument with no default and not marked optional is required.
            required = default is _MISSING and not optional and not self.variadic
        kwargs["required"] = bool(required)
        if kwargs.get("deprecated") and required:
            raise DeclarationError("a deprecated argument cannot be required.")
        super().__init__(decls, nargs=nargs_v if not self.variadic else 1, multiple=False, **kwargs)
        self.name = decls[0]
        self.nargs = nargs_v
        self.variadic = nargs_v == -1
        self._finalize_type()

    def hint(self) -> str:
        return self.name or ""

    def get_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def convert_tokens(self, ctx, tokens: list):
        """Convert the tokens bound to this argument into its delivered value."""
        if self.variadic or self.nargs != 1:
            if self.variadic and isinstance(self.type, Tuple):
                raise DeclarationError("variadic arguments cannot be tuples.")
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        if isinstance(self.type, Tuple):
            return self.type.convert(tokens, self, ctx)
        return self.type.convert(tokens[0], self, ctx)
