"""Token parser for commands and groups (PRD FP-01, FP-03, FP-04, FP-06, FP-10)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .exceptions import BadParameter, NoSuchOption, UsageError

HELP_SENTINEL = object()


@dataclass
class ParseResult:
    # dest -> list of occurrences; flags store bool/flag_value; nargs options store tuples
    occurrences: dict = field(default_factory=dict)
    # dest -> param for options seen on command line, in order of first appearance
    seen_order: list = field(default_factory=list)
    positional: list = field(default_factory=list)
    rest: list = field(default_factory=list)
    eager: list = field(default_factory=list)  # (param or HELP_SENTINEL) in typed order
    deprecated_used: list = field(default_factory=list)


class OptionTable:
    def __init__(self, params, normalize=None):
        self.normalize = normalize or (lambda s: s)
        self.by_name: dict[str, tuple] = {}
        self.prefixes: set[str] = {"-"}
        for p in params:
            if getattr(p, "param_type_name", "") != "option":
                continue
            for n in p.opts:
                self.by_name[self.normalize(n)] = (p, False)
                self.prefixes.add(n[0])
            for n in p.secondary_opts:
                self.by_name[self.normalize(n)] = (p, True)
                self.prefixes.add(n[0])

    def is_option_like(self, tok: str) -> bool:
        return len(tok) > 1 and tok[0] in self.prefixes


def parse_tokens(
    tokens: list,
    params: list,
    ctx,
    *,
    help_names: list,
    stop_after_positionals: int | None = None,
    stop_mode: bool = False,
    interspersed: bool = True,
    ignore_unknown: bool = False,
) -> ParseResult:
    """Parse ``tokens`` against ``params``.

    ``stop_mode`` (groups and chain subcommands): stop when ``stop_after_positionals``
    positional tokens have been collected; the remaining tokens (starting with the
    next token that cannot bind) go to ``rest``.
    """
    norm = ctx.token_normalize_func if ctx is not None else None
    table = OptionTable(params, norm)
    res = ParseResult()
    help_set = {norm(h) if norm else h for h in help_names}
    allow_opts = True
    i = 0
    n = len(tokens)

    def add_occurrence(param, value, secondary=False):
        dest = param.name
        if dest not in res.occurrences:
            res.occurrences[dest] = []
            res.seen_order.append(param)
        if param.deprecated:
            res.deprecated_used.append(param)
        res.occurrences[dest].append(value)
        if param.is_eager:
            res.eager.append((param, len(res.eager)))

    def is_help(tok):
        return (norm(tok) if norm else tok) in help_set

    def take_value(param, tok_index, name, inline):
        """Return (value_tuple_or_str, new_index) for an option taking nargs values."""
        if inline is not None:
            if param.nargs != 1:
                raise BadParameter(f"option {name} needs {param.nargs} values.", ctx, param)
            return (inline,), tok_index
        needed = param.nargs
        if tok_index + needed > n:
            if getattr(param, "prompt_enabled", False):
                return (), tok_index  # bare flag on a prompting option: prompt later
            raise BadParameter(f"option {name} requires an argument.", ctx, param)
        vals = tokens[tok_index:tok_index + needed]
        return tuple(vals), tok_index + needed

    def handle_option(param, is_secondary, name, inline):
        nonlocal i
        if param.is_flag:
            if inline is not None:
                raise BadParameter(f"option {name} does not take a value.", ctx, param)
            if param.count:
                add_occurrence(param, 1)
            elif is_secondary:
                add_occurrence(param, False)
            else:
                add_occurrence(param, param.flag_value)
            return
        value, i2 = take_value(param, i, name, inline)
        i = i2
        add_occurrence(param, value)

    while i < n:
        tok = tokens[i]
        if not allow_opts:
            if stop_mode and stop_after_positionals is not None and len(res.positional) >= stop_after_positionals:
                res.rest = tokens[i:]
                return res
            res.positional.append(tok)
            i += 1
            continue
        if tok == "--":
            allow_opts = False
            i += 1
            continue
        if table.is_option_like(tok):
            i += 1
            if len(tok) > 2 and tok[1] == tok[0]:  # doubled prefix: long option
                # long option
                name, eq, val = tok.partition("=")
                key = norm(name) if norm else name
                if key in table.by_name:
                    param, sec = table.by_name[key]
                    handle_option(param, sec, name, val if eq else None)
                    continue
                if is_help(name):
                    res.eager.append((HELP_SENTINEL, len(res.eager)))
                    continue
                if ignore_unknown:
                    res.positional.append(tok)
                    continue
                raise NoSuchOption(name, ctx=ctx)
            # short option or stack (single prefix char)
            pfx = tok[0]
            j = 1
            while j < len(tok):
                ch = tok[j]
                name = pfx + ch
                key = norm(name) if norm else name
                if key in table.by_name:
                    param, sec = table.by_name[key]
                    if param.is_flag:
                        handle_option(param, sec, name, None)
                        j += 1
                        continue
                    inline = tok[j + 1:]
                    if inline:
                        handle_option(param, sec, name, inline)
                    else:
                        handle_option(param, sec, name, None)
                    break
                if is_help(name):
                    res.eager.append((HELP_SENTINEL, len(res.eager)))
                    j += 1
                    continue
                if ignore_unknown:
                    res.positional.append(pfx + tok[j:])
                    break
                raise NoSuchOption(name, ctx=ctx)
            continue
        # positional token
        if stop_mode and stop_after_positionals is not None and len(res.positional) >= stop_after_positionals:
            res.rest = tokens[i:]
            return res
        if not interspersed:
            allow_opts = False
        res.positional.append(tok)
        i += 1
    return res
