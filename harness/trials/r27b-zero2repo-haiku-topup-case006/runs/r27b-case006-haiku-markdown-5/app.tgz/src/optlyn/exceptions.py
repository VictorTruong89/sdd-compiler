"""Exception hierarchy for Optlyn.

Exit-status classes (standalone mode):
  * ``UsageError`` (and subclasses) -> status 2
  * ``Abort`` and ``FileError`` -> status 1
  * ``Exit`` -> author-supplied status (0 by default)
"""

from __future__ import annotations

import sys


class OptlynError(Exception):
    """Base class for all Optlyn-signalled errors."""

    exit_code = 1

    def __init__(self, message: str = "", ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.format_message()}\n")

    def format_message(self) -> str:
        return self.message


class UsageError(OptlynError):
    """Incorrect command-line usage. Exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx=None, show_help: bool = False):
        super().__init__(message, ctx)
        self.show_help = show_help

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.message}\n")


class NoSuchOption(UsageError):
    """An unknown option token was given."""

    def __init__(self, option_name: str, message: str | None = None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadParameter(UsageError):
    """A parameter value was refused. Names the offending parameter."""

    def __init__(self, message: str, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint or (self.param.hint() if self.param is not None else None)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.format_message()}\n")


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def __init__(self, message: str | None = None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "missing", ctx, param, param_hint)

    def format_message(self) -> str:
        hint = self.param_hint or (self.param.hint() if self.param is not None else None)
        return f"Missing parameter: {hint}" if hint else "Missing parameter"


class MissingCommand(UsageError):
    """A group was invoked without a subcommand where one is required."""

    def __init__(self, ctx=None):
        super().__init__("Missing command.", ctx)


class NoSuchCommand(UsageError):
    """An unknown subcommand name was given."""

    def __init__(self, name: str, ctx=None):
        super().__init__(f"No such command '{name}'.", ctx)
        self.name = name


class Abort(OptlynError):
    """User abort or author abort. Exit status 1."""

    exit_code = 1

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        file.write("Aborted!\n")


class FileError(OptlynError):
    """A file could not be opened during I/O. General error, exit status 1."""

    exit_code = 1

    def __init__(self, filename: str, message: str = "", ctx=None):
        super().__init__(message or f"Could not open file '{filename}'.", ctx)
        self.filename = filename

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.message}\n")


class Exit(Exception):
    """Author-requested clean stop. ``code`` is the status to exit with."""

    def __init__(self, code: int = 0):
        super().__init__(code)
        self.exit_code = code


class DeclarationError(TypeError):
    """An invalid declaration combination, raised at decoration time."""
