"""Text wrapping and help-page layout helpers (PRD FP-02, FP-11)."""

from __future__ import annotations

import shutil
import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80
TERMINAL_WRAP_FALLBACK = 80


def detect_width(max_content_width: int = DEFAULT_MAX_CONTENT_WIDTH, terminal_width=None) -> int:
    """Wrap width. An explicit terminal width is used as-is; auto-detected width is capped."""
    if terminal_width is not None:
        return int(terminal_width)
    try:
        cols = shutil.get_terminal_size((TERMINAL_WRAP_FALLBACK, 24)).columns
    except Exception:
        cols = TERMINAL_WRAP_FALLBACK
    return max(20, min(cols, max_content_width))


def wrap_text(
    text: str,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width``. Single newlines are not hard breaks.

    A paragraph whose first line is only a backspace (``\\b``) is not rewrapped:
    its line breaks are kept and the backspace line is stripped.
    Never raises on arbitrary strings.
    """
    if text is None:
        return ""
    text = str(text)
    out_lines: list[str] = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [ln for ln in lines[1:]]
            for ln in kept:
                out_lines.append(initial_indent + ln if not out_lines else subsequent_indent + ln)
            out_lines.append("")
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            out_lines.append("")
            continue
        w = max(1, width)
        wrapped = textwrap.wrap(
            flat,
            width=w,
            initial_indent=initial_indent if not out_lines else subsequent_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=True,
            break_on_hyphens=False,
        ) or [""]
        out_lines.extend(wrapped)
        out_lines.append("")
    while out_lines and out_lines[-1] == "":
        out_lines.pop()
    return "\n".join(out_lines)


def short_help_text(text: str, limit: int = 45) -> str:
    """Start of the first paragraph, cut with '...' at ``limit`` characters."""
    if not text:
        return ""
    first = text.strip().split("\n\n", 1)[0]
    flat = " ".join(first.split())
    if len(flat) <= limit:
        return flat
    return flat[: max(0, limit - 3)].rstrip() + "..."


def first_sentence(text: str) -> str:
    if not text:
        return ""
    flat = " ".join(text.strip().split())
    idx = flat.find(". ")
    if idx != -1:
        return flat[: idx + 1]
    return flat


def truncate_form_feed(text: str) -> str:
    """Docstring form-feed truncates the help text (PRD FP-02)."""
    if text is None:
        return None
    if "\f" in text:
        return text.split("\f", 1)[0]
    return text


def strip_form_feed(text: str) -> str:
    """Explicit help attribute: form-feed is dropped, following text kept (Interface section 3)."""
    if text is None:
        return None
    return text.replace("\f", "")


def format_usage_line(prog: str, options_placeholder: str, args: list[str], extra: str = "") -> str:
    parts = [prog]
    if options_placeholder:
        parts.append(options_placeholder)
    parts.extend(args)
    if extra:
        parts.append(extra)
    return "Usage: " + " ".join(p for p in parts if p)


def two_column(rows: list[tuple[str, str]], width: int = 78, indent: int = 2) -> list[str]:
    """Layout (first, second) pairs in two aligned columns."""
    if not rows:
        return []
    first_w = min(max(len(a) for a, _ in rows), max(10, width // 2))
    lines: list[str] = []
    for first, second in rows:
        pad = " " * indent
        if not second:
            lines.append(f"{pad}{first}")
            continue
        avail = max(20, width - indent - first_w - 2)
        wrapped = textwrap.wrap(" ".join(second.split()), width=avail) or [""]
        if len(first) > first_w:
            lines.append(f"{pad}{first}")
            lines.extend(" " * (indent + first_w + 2) + w for w in wrapped)
        else:
            lines.append(f"{pad}{first.ljust(first_w)}  {wrapped[0]}")
            lines.extend(" " * (indent + first_w + 2) + w for w in wrapped[1:])
    return lines
