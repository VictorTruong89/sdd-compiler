"""Invocation context (PRD FP-07; Interface section 6)."""

from __future__ import annotations

import enum
import threading
from contextlib import ExitStack
from typing import Any

from .exceptions import Abort, Exit
from .formatting import DEFAULT_MAX_CONTENT_WIDTH

_local = threading.local()


class ParameterSource(enum.Enum):
    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_INHERITED = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
    "allow_extra_args",
    "ignore_unknown_options",
    "allow_interspersed_args",
)


class Context:
    def __init__(
        self,
        command,
        parent: "Context | None" = None,
        info_name: str | None = None,
        obj: Any = None,
        default_map: dict | None = None,
        terminal_width: int | None = None,
        max_content_width: int | None = None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        auto_envvar_prefix=None,
        **_ignored,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        self.terminal_width = terminal_width if terminal_width is not None else (
            parent.terminal_width if parent else None)
        self.max_content_width = max_content_width if max_content_width is not None else (
            parent.max_content_width if parent and parent.max_content_width is not None
            else DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = (
            list(help_option_names) if help_option_names is not None
            else (list(parent.help_option_names) if parent else ["--help"]))
        self.token_normalize_func = token_normalize_func or (parent.token_normalize_func if parent else None)
        self.color = color if color is not None else (parent.color if parent else None)
        self.show_default = show_default if show_default is not None else (
            parent.show_default if parent else None)
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None
            else (getattr(command, "allow_extra_args", False) or (parent.allow_extra_args if parent else False)))
        self.ignore_unknown_options = (
            ignore_unknown_options if ignore_unknown_options is not None
            else (parent.ignore_unknown_options if parent else False))
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None
            else getattr(command, "allow_interspersed_args", True))
        self.auto_envvar_prefix = (
            auto_envvar_prefix if auto_envvar_prefix is not None
            else (parent.auto_envvar_prefix if parent else None))
        self.params: dict[str, Any] = {}
        self._sources: dict[str, ParameterSource] = {}
        self.invoked_subcommand: Any = None
        self._exit_stack = ExitStack()
        self._closed = False
        # Full command path from the root, e.g. ["tool", "sub", "leaf"].
        if parent is not None:
            self.path_names: list[str] = parent.path_names + ([info_name] if info_name is not None else [])
        else:
            self.path_names = [info_name] if info_name is not None else []
        self._entered = 0

    # --- hierarchy -------------------------------------------------------
    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def get_parameter_source(self, name: str):
        return self._sources.get(name)

    def set_source(self, name: str, source: ParameterSource):
        self._sources[name] = source

    # --- resources -------------------------------------------------------
    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f):
        self._exit_stack.callback(f)

    def close(self):
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    # --- control ---------------------------------------------------------
    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, other, **kwargs):
        """Run another command with exactly the caller's chosen values."""
        from .core import Command

        if not isinstance(other, Command):
            raise TypeError("invoke() expects a Command instance.")
        sub = Context(other, parent=self, info_name=other.name, obj=self.obj)
        with sub:
            return other.invoke_with_values(sub, dict(kwargs))

    def forward(self, other, **kwargs):
        """Run another command, filling its parameters from this command's values."""
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(other, **merged)

    # --- thread-local stack ----------------------------------------------
    def __enter__(self):
        stack = _stack()
        stack.append(self)
        self._entered += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        self._entered -= 1
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        if self._entered == 0:
            self.close()
        return False


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def get_current_context(silent: bool = False):
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
