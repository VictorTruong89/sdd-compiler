"""File opening helpers shared by the File type and ``open_file`` (PRD FP-09, FP-11)."""

from __future__ import annotations

import io
import os
import sys
import tempfile
from contextlib import contextmanager


class LazyFile(io.IOBase):
    """Write-mode file that opens on first I/O (PRD FP-09 lazy mode)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None

    def _open(self):
        if self._fh is not None:
            return self._fh
        target = self._filename
        if self._atomic:
            d = os.path.dirname(os.path.abspath(target))
            fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-", suffix=".tmp")
            os.close(fd)
            target = self._tmp
        if "b" in self._mode:
            self._fh = open(target, self._mode)
        else:
            self._fh = open(target, self._mode, encoding=self._encoding, errors=self._errors)
        return self._fh

    def write(self, data):
        return self._open().write(data)

    def flush(self):
        if self._fh is not None:
            self._fh.flush()

    def writable(self):
        return True

    def readable(self):
        return False

    @property
    def name(self):
        return self._filename

    def close(self):
        if self._fh is not None:
            self._fh.close()
        if self._atomic and self._tmp is not None:
            if self._fh is not None:
                os.replace(self._tmp, self._filename)
            else:
                os.unlink(self._tmp)
        self._tmp = None
        super().close()


def _std_stream(mode: str):
    if "w" in mode or "a" in mode:
        stream = sys.stdout
    else:
        stream = sys.stdin
    return stream


def _wrap_std(stream, mode):
    """Return the standard stream, not closed when the caller's block ends."""
    if "b" in mode:
        buf = getattr(stream, "buffer", None)
        if buf is None:
            return _NoCloseProxy(stream)
        return _NoCloseProxy(buf)
    return _NoCloseProxy(stream)


class _NoCloseProxy:
    """Proxy that forwards everything but ignores ``close``."""

    def __init__(self, inner):
        object.__setattr__(self, "_inner", inner)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_inner"), name)

    def close(self):
        return None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __iter__(self):
        return iter(object.__getattribute__(self, "_inner"))


def open_file_value(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename`` according to FP-09 rules.

    ``-`` means stdin for read modes and stdout for write modes.
    Read modes open immediately. Write modes open immediately unless lazy.
    """
    if filename == "-":
        return _wrap_std(_std_stream(mode), mode)
    if "r" in mode:
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    if lazy:
        return LazyFile(filename, mode, encoding=encoding, errors=errors, atomic=atomic)
    lf = LazyFile(filename, mode, encoding=encoding, errors=errors, atomic=atomic)
    lf._open()
    return lf


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Public ``optlyn.open_file``: opens immediately and returns a file object
    usable as a context manager (the file closes at block end, std streams do not)."""
    return open_file_value(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)
