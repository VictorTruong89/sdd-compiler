"""Shell completion (PRD FP-12; Interface section 8)."""

from __future__ import annotations

import os
import sys

from .parameters import Option
from .types import Choice

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_MARK = "__optlyn_path__"
DIR_MARK = "__optlyn_dir__"


def _source_script(prog: str, var: str, shell: str) -> str:
    if shell == "bash":
        fn = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"{fn}() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog} ) )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F {fn} {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local -a completions\n"
            f"    completions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})\"}})\n"
            f"    compadd -a completions\n"
            f"}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"function _{prog.replace('-', '_')}_completion\n"
            f"    set -l cmd (commandline -cp)\n"
            f"    env COMP_WORDS=\"$cmd\" COMP_CWORD=(commandline -ct) {var}=fish_complete {prog}\n"
            f"end\n"
            f"complete -c {prog} -f -a '(_{prog.replace('-', '_')}_completion)'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        f"}}\n"
    )


def _suggestions(cmd, prog: str, words: list[str], cword: int, incomplete: str):
    """Return list of (value, help, type) tuples for the current position."""
    from .context import Context
    from .core import Group

    ctx = Context(cmd, info_name=prog)
    current = cmd
    tokens = words[1:cword] if cword >= 1 else []
    # walk down groups by subcommand name
    i = 0
    while isinstance(current, Group) and i < len(tokens):
        tok = tokens[i]
        if tok.startswith("-"):
            i += 1
            continue
        child = current.get_command(ctx, tok)
        if child is None:
            break
        current = child
        ctx = Context(current, parent=ctx, info_name=tok)
        tokens = tokens[i + 1:]
        i = 0
    out: list[tuple[str, str | None, str]] = []
    prev = tokens[-1] if tokens else None

    # value completion for an option that expects a value
    if prev and prev.startswith("-"):
        for p in current.params:
            if isinstance(p, Option) and prev in p.opts and not p.is_flag:
                if p.shell_complete_fn is not None or isinstance(p.type, Choice):
                    for item in p.shell_complete(ctx, incomplete) or []:
                        out.append((getattr(item, "value", item), getattr(item, "help", None), "plain"))
                    return _filter_hidden(out)
                kind = p.type.completion_kind()
                if kind:
                    return [(incomplete, None, PATH_MARK if kind == "path" else DIR_MARK)]

    if incomplete.startswith("-"):
        for p in current.params:
            if isinstance(p, Option) and not p.hidden:
                for n in p.opts + p.secondary_opts:
                    if n.startswith(incomplete):
                        out.append((n, p.help, "plain"))
        if current.add_help_option:
            for n in ctx.help_option_names:
                if n.startswith(incomplete):
                    out.append((n, "Show this message and exit.", "plain"))
        return out

    if isinstance(current, Group):
        for name in current.list_commands(ctx):
            child = current.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            if name.startswith(incomplete):
                out.append((name, child.get_short_help_str(), "plain"))
        return out
    return out


def _filter_hidden(items):
    return items


def handle_completion(cmd, prog: str, args: list, value: str, var: str) -> bool:
    """Handle the completion variable. Returns True when a script/suggestions were printed."""
    if "_" not in value:
        return False
    shell, _, mode = value.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return False
    if mode == "source":
        sys.stdout.write(_source_script(prog, var, shell))
        sys.stdout.flush()
        return True

    line = os.environ.get("COMP_WORDS", "")
    words = line.split(" ") if line else [prog]
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        cword = len(words) - (0 if incomplete == "" else 1)
        words = words[:-1] if incomplete and words and words[-1] == incomplete else words
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
    lines = []
    for val, help_text, kind in _suggestions(cmd, prog, words, cword, incomplete):
        if kind == PATH_MARK:
            lines.append(f"{PATH_MARK}\t{val}")
        elif kind == DIR_MARK:
            lines.append(f"{DIR_MARK}\t{val}")
        elif shell in ("zsh", "fish") and help_text:
            lines.append(f"{val}\t{help_text}")
        else:
            lines.append(val)
    sys.stdout.write("\n".join(lines) + ("\n" if lines else ""))
    sys.stdout.flush()
    return True
