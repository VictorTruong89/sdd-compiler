"""FP-01 command declaration, naming and invocation; Interface section 3."""

import pytest

import optlyn as o
from optlyn.testing import CliRunner


def test_name_derived_from_function_strips_suffix():
    """spec: N-000079, N-000080, N-000081, N-000082"""

    @o.command()
    def sync_data_command():
        pass

    @o.group()
    def admin_grp():
        pass

    assert sync_data_command.name == "sync-data"
    assert admin_grp.name == "admin"


def test_explicit_name_is_only_accepted_name():
    """spec: N-000082"""

    @o.group()
    def root():
        pass

    @root.command("go")
    def run_it():
        o.echo("ran")

    assert run_it.name == "go"
    assert CliRunner().invoke(root, ["go"]).output == "ran\n"
    assert CliRunner().invoke(root, ["run-it"]).exit_code == 2


def test_callback_runs_once_and_returns_success():
    """spec: N-000083, N-000084, N-000085"""
    calls = []

    @o.command()
    def once():
        calls.append(1)
        o.echo("body")

    res = CliRunner().invoke(once, [])
    assert res.exit_code == 0
    assert calls == [1]


def test_deprecated_command_runs_and_warns_on_stderr():
    """spec: N-000086, N-000087, N-000088, N-000089, N-000090"""

    @o.command(deprecated="use new-thing")
    def old():
        o.echo("ran")

    res = CliRunner().invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "DeprecationWarning" in res.stderr
    assert "use new-thing" in res.stderr


def test_deprecated_command_unknown_option_is_usage_error():
    """spec: N-000090"""

    @o.command(deprecated=True)
    def old():
        pass

    assert CliRunner().invoke(old, ["--nope"]).exit_code == 2


def test_parameters_delivered_under_destination_names():
    """spec: N-000091, N-000092, N-000093, N-000094, N-000095, N-000096"""

    @o.command()
    @o.option("--tag", multiple=True)
    @o.option("--dry-run", is_flag=True)
    def push(tag, dry_run):
        o.echo(f"{tag!r} {dry_run}")

    res = CliRunner().invoke(push, [])
    assert res.output == "() False\n"
    res = CliRunner().invoke(push, ["--tag", "a", "--dry-run"])
    assert res.output == "('a',) True\n"


def test_creating_command_moves_declarations_off_function():
    """spec: N-000096"""

    def base(x):
        pass

    o.option("--x")(base)
    cmd = o.command("base")(base)
    assert [p.name for p in cmd.params] == ["x"]
    assert "__optlyn_params__" not in base.__dict__


def test_disabled_standalone_returns_value_and_raises_failures():
    """spec: N-000097, N-000098, N-000099, N-000100"""

    @o.command()
    @o.option("--n", type=int)
    def double(n):
        return n * 2

    assert double.main(["--n", "4"], standalone_mode=False) == 8
    with pytest.raises(o.UsageError):
        double.main(["--n", "x"], standalone_mode=False)


def test_unknown_option_and_missing_required_do_not_run_callback():
    """spec: N-000101, N-000102"""
    ran = []

    @o.command()
    @o.option("--req", required=True)
    def strict(req):
        ran.append(req)

    runner = CliRunner()
    assert runner.invoke(strict, ["--bogus"]).exit_code == 2
    assert runner.invoke(strict, []).exit_code == 2
    assert ran == []


def test_extra_args_rejected_unless_allowed():
    """spec: N-000105, N-000106, N-000107, N-000108, N-000109"""

    @o.command()
    def plain():
        pass

    assert CliRunner().invoke(plain, ["stray"]).exit_code == 2

    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("first")
    def loose(first):
        o.echo(first)

    res = CliRunner().invoke(loose, ["a", "b"])
    assert res.exit_code == 0 and res.output == "a\n"
    res = CliRunner().invoke(loose, ["a", "--bogus"])
    assert res.exit_code == 2


def test_no_args_is_help_on_leaf_is_usage_error():
    """spec: N-000172, N-000173, N-000174, N-000175"""

    @o.command(no_args_is_help=True)
    @o.argument("x")
    def leaf(x):
        pass

    res = CliRunner().invoke(leaf, [])
    assert res.exit_code == 2
    assert "Usage:" in res.output
