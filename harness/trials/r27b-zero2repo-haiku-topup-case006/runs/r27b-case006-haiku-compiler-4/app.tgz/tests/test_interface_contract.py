"""Interface Contract sections 1, 2 and 3: package exports, help and version shapes."""

import optlyn as o
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner
from optlyn.testing import CliRunner as RunnerAlias


EXPORTS = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection", "Context",
    "Option", "Parameter", "ParamType", "BadParameter", "Abort",
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime",
    "IntRange", "FloatRange", "Tuple", "File", "Path",
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
    "get_app_dir", "get_current_context", "format_filename", "open_file",
]


def test_root_package_exports_listed_names():
    """spec: N-000791, N-000795, N-000796, N-000797, N-000798, N-000799"""
    for name in EXPORTS:
        assert hasattr(o, name), name


def test_testing_and_formatting_exports():
    """spec: N-000800, N-000801"""
    assert RunnerAlias is CliRunner
    assert callable(wrap_text)


def test_exit_status_table_and_standalone_systemexit(capsys):
    """spec: N-000803, N-000804, N-000805, N-000806, N-000807, N-000808, N-000809, N-000810"""

    @o.command()
    @o.option("--bad", type=int)
    def cmd(bad):
        pass

    try:
        cmd.main(["--bad", "x"], prog_name="cmd")
    except SystemExit as exc:
        assert exc.code == 2
    else:
        raise AssertionError("expected SystemExit")


def test_channel_assignments():
    """spec: N-000812, N-000813, N-000814, N-000815, N-000816, N-000817, N-000818, N-000819, N-000820, N-000821"""

    @o.group(invoke_without_command=False)
    @o.option("--opt", is_flag=True)
    def g(opt):
        pass

    @g.command()
    def c():
        o.echo("body")

    r = CliRunner()
    help_out = r.invoke(g, ["c", "--help"])
    assert help_out.stdout.startswith("Usage:")
    usage_err = r.invoke(c, ["--nope"])
    assert "Usage:" in usage_err.stderr and usage_err.stdout == ""
    missing_cmd = r.invoke(g, ["--opt"])
    assert "Missing command." in missing_cmd.stderr


def test_help_page_section_order_and_positional_section_only_with_help():
    """spec: N-000827, N-000828, N-000829, N-000830, N-000831, N-000835, N-000837, N-000844"""

    @o.command(epilog="Epilog text.")
    @o.argument("x", help="The x")
    @o.option("--yes", is_flag=True, help="Say yes.")
    def cmd(x, yes):
        """Description."""

    out = CliRunner().invoke(cmd, ["--help"]).stdout
    order = [out.index(s) for s in ("Usage:", "Description.", "Positional arguments:", "Options:", "Epilog text.")]
    assert order == sorted(order)


def test_version_identity_shapes():
    """spec: N-000846, N-000847, N-000848, N-000849, N-000930, N-000931"""

    @o.command()
    @o.version_option("3.1", prog_name="prog", message="%(prog)s v%(version)s")
    def cmd():
        pass

    res = CliRunner().invoke(cmd, ["--version"])
    assert res.stdout == "prog v3.1\n"


def test_declaration_helpers_and_pass_decorators_shape():
    """spec: N-000850, N-000851, N-000852, N-000853, N-000854, N-000855, N-000856, N-000857, N-000858, N-000859, N-000860, N-000861, N-000862, N-000863, N-000864, N-000865, N-000866, N-000867, N-000868, N-000869, N-000870, N-000871, N-000872, N-000873, N-000874, N-000875, N-000876, N-000877, N-000878, N-000879, N-000880"""
    cmd = o.command(name="x", help="Doc\fHidden", short_help="short")(lambda: None)
    assert isinstance(cmd, o.Command)
    assert cmd.help == "DocHidden"
    assert cmd.get_short_help_str() == "short"
    def helper_fn():
        pass

    cmd2 = o.command()(helper_fn)
    assert cmd2.name == "helper-fn"

    @o.group()
    def g():
        pass

    @g.command()
    def child():
        pass

    assert g.get_command(None, "child") is not None
    assert g.list_commands(None) == ["child"]
    assert o.Group is type(g)
    assert o.Command.main is not None


def test_option_declaration_rules():
    """spec: N-000881, N-000882, N-000883, N-000884, N-000885, N-000886, N-000887, N-000888, N-000889, N-000890, N-000891, N-000892, N-000893, N-000894, N-000895, N-000896, N-000897, N-000898, N-000899, N-000900, N-000901, N-000902, N-000903, N-000904, N-000905, N-000906, N-000907, N-000908, N-000909, N-000910, N-000911, N-000912"""
    opt = o.Option(["--on/--off", "-x"], default=True)
    assert opt.is_flag and opt.name == "on"
    assert opt.opts == ["--on", "-x"] and opt.secondary_opts == ["--off"]
    try:
        o.Option(["--zzz"], nargs=0)
    except o.exceptions.DeclarationError:
        pass
    else:
        raise AssertionError("nargs=0 should be refused")


def test_delivered_values_table():
    """spec: N-000914, N-000915, N-000916, N-000917, N-000918, N-000919, N-000920"""

    @o.command()
    @o.option("--flag", is_flag=True)
    @o.option("--tuple", nargs=2)
    @o.option("--many", multiple=True)
    @o.option("--plain")
    @o.argument("rest", nargs=-1)
    def cmd(flag, tuple, many, plain, rest):
        o.echo(repr((flag, tuple, many, plain, rest)))

    out = CliRunner().invoke(cmd, []).output
    assert out == "(False, None, (), None, ())\n"


def test_param_objects_expose_name_and_metavar():
    """spec: N-000921, N-000922, N-000923"""
    opt = o.Option(["--out"], metavar="PATH")
    assert opt.name == "out" and opt.metavar == "PATH"
    assert o.Option(["--x"]).metavar is None


def test_ready_made_options_shape():
    """spec: N-000924, N-000925, N-000926, N-000927, N-000928, N-000929"""

    @o.command()
    @o.help_option()
    @o.password_option()
    @o.confirmation_option()
    def cmd(password):
        pass

    params = {p.name: p for p in cmd.params}
    assert "password" in params
    assert "--help" in params["help"].opts


def test_bad_parameter_attributes():
    """spec: N-000933, N-000934, N-000935"""
    err = o.BadParameter("bad", param_hint="'--x'")
    assert err.param_hint == "'--x'"
    assert "Invalid value for '--x': bad" == err.format_message()


def test_context_members():
    """spec: N-000950, N-000951, N-000952, N-000953, N-000965, N-000966, N-000967, N-000968, N-000969, N-000970, N-000971, N-000972, N-000973, N-000974, N-000978, N-000979, N-000980"""
    seen = {}

    @o.group()
    @o.pass_context
    def g(ctx):
        seen["parent"] = ctx.parent
        seen["invoked"] = ctx.invoked_subcommand
        ctx.obj = "object"

    @g.command()
    @o.pass_context
    def c(ctx):
        seen["child_parent"] = ctx.parent.command.name
        seen["child_obj"] = ctx.obj
        seen["params"] = dict(ctx.params)

    CliRunner().invoke(g, ["c"], obj="root")
    assert seen["parent"] is None
    assert seen["invoked"] == "c"
    assert seen["child_parent"] == "g"
    assert seen["child_obj"] == "object"
    assert seen["params"] == {}
