"""FP-02 help pages, short help, version flags; Interface sections 2 and 4."""

import optlyn as o
from optlyn.formatting import make_default_short_help, wrap_text
from optlyn.testing import CliRunner


def test_help_option_prints_page_and_skips_callback():
    """spec: N-000110, N-000111, N-000112, N-000113"""
    ran = []

    @o.command()
    def hello():
        """Say hi."""
        ran.append(1)

    res = CliRunner().invoke(hello, ["--help"])
    assert res.exit_code == 0
    assert "Say hi." in res.stdout
    assert ran == []


def test_form_feed_truncates_docstring():
    """spec: N-000114, N-000115, N-000116, N-000117"""

    @o.command()
    def fmt():
        """Visible part.

        \f
        Hidden part.
        """

    res = CliRunner().invoke(fmt, ["--help"])
    assert "Visible part." in res.stdout
    assert "Hidden part" not in res.stdout
    assert "\f" not in res.stdout


def test_usage_line_brackets_optional_and_variadic():
    """spec: N-000127, N-000128, N-000129, N-000130, N-000131, N-000132"""

    @o.group(invoke_without_command=True)
    def g():
        pass

    @o.command()
    @o.argument("req")
    @o.argument("opt", required=False, default="x")
    @o.argument("rest", nargs=-1, required=False)
    def leaf(req, opt, rest):
        pass

    res = CliRunner().invoke(leaf, ["--help"])
    usage = res.stdout.splitlines()[0]
    assert "REQ" in usage and "[OPT]" in usage and "[REST]..." in usage
    res = CliRunner().invoke(g, ["--help"])
    assert "[COMMAND] [ARGS]..." in res.stdout.splitlines()[0]


def test_metavar_defaults_and_choice_values():
    """spec: N-000139, N-000140, N-000141, N-000142, N-000143, N-000144, N-000145"""

    @o.command()
    @o.option("--count", type=int)
    @o.option("--flag", is_flag=True)
    @o.option("--color", type=o.Choice(["red", "blue"]))
    def cmd(count, flag, color):
        pass

    out = CliRunner().invoke(cmd, ["--help"]).stdout
    assert "--count INTEGER" in out
    assert "--color [red|blue]" in out
    assert "  --flag\n" in out


def test_show_default_and_envvar_extras():
    """spec: N-000146, N-000147, N-000148, N-000149, N-000150, N-000151"""

    @o.command()
    @o.option("--level", default=3, show_default=True, envvar="LVL", show_envvar=True)
    @o.option("--quiet", is_flag=True, show_default=True)
    @o.option("--hidden-default", default="z", show_default="see docs")
    def cmd(level, quiet, hidden_default):
        pass

    out = CliRunner().invoke(cmd, ["--help"]).stdout
    assert "[default: 3]" in out
    assert "[env var: LVL]" in out
    assert "[default: False]" not in out
    assert "see docs" in out


def test_hidden_items_omitted_from_help_but_invocable():
    """spec: N-000153, N-000154, N-000426, N-000427"""

    @o.group()
    def g():
        pass

    @g.command(hidden=True)
    @o.option("--secret", hidden=True)
    def sneaky(secret):
        o.echo(str(secret))

    res = CliRunner().invoke(g, ["--help"])
    assert "sneaky" not in res.stdout
    res = CliRunner().invoke(g, ["sneaky", "--secret", "s"])
    assert res.stdout == "s\n"


def test_help_names_replacement_and_extra_help_option():
    """spec: N-000155, N-000156, N-000157, N-000158, N-000159, N-000160, N-000161"""

    @o.command()
    @o.help_option("-h", "--halp")
    def cmd():
        o.echo("body")

    runner = CliRunner()
    assert "Usage:" in runner.invoke(cmd, ["-h"]).stdout
    assert "Usage:" in runner.invoke(cmd, ["--help"]).stdout

    @o.command()
    def other():
        pass

    res = runner.invoke(other, ["--help"], help_option_names=["-?"])
    assert res.exit_code == 2
    assert "No such option" in res.stderr or "No such option" in res.output


def test_version_option_prints_identity_and_is_eager():
    """spec: N-000162, N-000163, N-000164, N-000165, N-000166, N-000167, N-000168, N-000169"""

    @o.command()
    @o.version_option("9.9.9", prog_name="tool")
    @o.option("--req", required=True)
    def tool(req):
        o.echo("should not run")

    res = CliRunner().invoke(tool, ["--version"])
    assert res.exit_code == 0
    assert "9.9.9" in res.stdout
    assert "should not run" not in res.stdout


def test_custom_version_option_prints_callback_string_exactly():
    """spec: N-000846, N-000847, N-000849, N-000932"""

    @o.command()
    @o.custom_version_option(lambda ctx: "build-42")
    def tool():
        pass

    res = CliRunner().invoke(tool, ["--version"])
    assert res.stdout == "build-42\n"


def test_help_before_and_after_subcommand_belong_to_correct_command():
    """spec: N-000395, N-000396, N-000397"""

    @o.group()
    @o.option("--g")
    def g(g):
        o.echo("group ran")

    @g.command()
    def child():
        o.echo("child ran")

    runner = CliRunner()
    assert "Commands:" in runner.invoke(g, ["--help", "child"]).stdout
    assert "child ran" not in runner.invoke(g, ["--help", "child"]).stdout
    assert "Usage: root child" in runner.invoke(g, ["child", "--help"], prog_name="root").stdout


def test_group_help_lists_children_with_short_help_and_epilog():
    """spec: N-000125, N-000126, N-000842, N-000843, N-000844"""

    @o.group(epilog="See more.")
    def g():
        pass

    @g.command()
    def first():
        """First sentence. More text."""

    @g.command()
    def second():
        """This is a very long first sentence that will not fit in the short help area at all."""

    out = CliRunner().invoke(g, ["--help"]).stdout
    assert "First sentence." in out
    assert "..." in out
    assert out.rstrip().endswith("See more.")


def test_short_help_helper_truncates_at_45():
    """spec: N-000122, N-000123, N-000124, N-000843"""
    text = "x" * 60
    short = make_default_short_help(text, 45)
    assert short.endswith("...")
    assert len(short) <= 45
    assert make_default_short_help("Only one. Two.") == "Only one."


def test_wrap_text_paragraphs_and_backspace_rule():
    """spec: N-000133, N-000134, N-000135, N-000136, N-000137, N-000138, N-000679, N-000680"""
    assert wrap_text("aaa bbb ccc ddd", width=8) == "aaa bbb\nccc ddd"
    assert wrap_text("\b\nkeep\nlines", width=40) == "keep\nlines"
    assert wrap_text("") == ""
    assert wrap_text("one\ntwo", width=40) == "one two"


def test_help_width_caps_auto_detected_but_not_explicit(monkeypatch):
    """spec: N-000134, N-000135, N-000136, N-000137"""

    long_text = " ".join(["word"] * 60)

    @o.command(help=long_text)
    def wide():
        pass

    res = CliRunner().invoke(wide, ["--help"], terminal_width=40)
    assert all(len(line) <= 40 for line in res.stdout.splitlines())
    res = CliRunner().invoke(wide, ["--help"], max_content_width=60)
    assert all(len(line) <= 60 for line in res.stdout.splitlines())


def test_group_no_args_help_is_usage_failure():
    """spec: N-000170, N-000171, N-000172, N-000173, N-000732, N-000733"""

    @o.group()
    def g():
        pass

    @g.command()
    def c():
        pass

    res = CliRunner().invoke(g, [])
    assert res.exit_code == 2
    assert "Usage:" in res.output
