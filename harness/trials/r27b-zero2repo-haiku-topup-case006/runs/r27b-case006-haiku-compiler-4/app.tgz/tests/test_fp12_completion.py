"""FP-12 shell completion; Interface section 8."""

import os

import optlyn as o
from optlyn.shell_completion import completions_for_environment, complete_var_name, registration_script
from optlyn.testing import CliRunner


def build_cli():
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--verbose", "-v", is_flag=True, help="be loud")
    @o.option("--secret", hidden=True, is_flag=True)
    @o.argument("path", type=o.Path())
    def run(verbose, secret, path):
        pass

    @cli.command(hidden=True)
    def hidden_one():
        pass

    @cli.command()
    @o.argument("mode", type=o.Choice(["fast", "slow"]))
    def pick(mode):
        pass

    return cli


def complete(cli, words, cword, shell="zsh"):
    os.environ["COMP_WORDS"] = words
    os.environ["COMP_CWORD"] = str(cword)
    try:
        return [(i.type, i.value) for i in completions_for_environment(cli, "cli", shell)]
    finally:
        os.environ.pop("COMP_WORDS", None)
        os.environ.pop("COMP_CWORD", None)


def test_completion_variable_name_and_registration_scripts():
    """spec: N-001013, N-001014, N-001015, N-000689, N-000690, N-000691, N-000701, N-000702"""
    assert complete_var_name("my-cli") == "_MY_CLI_COMPLETE"
    for shell in ("bash", "zsh", "fish", "powershell"):
        script = registration_script(shell, "cli", "_CLI_COMPLETE")
        assert "cli" in script and "_CLI_COMPLETE" in script


def test_source_mode_prints_script_and_exits_zero():
    """spec: N-000701, N-000702, N-000714"""
    cli = build_cli()
    os.environ["_CLI_COMPLETE"] = "bash_source"
    try:
        res = CliRunner().invoke(cli, [], prog_name="cli")
    finally:
        os.environ.pop("_CLI_COMPLETE", None)
    assert res.exit_code == 0
    assert "complete -o default" in res.stdout


def test_complete_mode_prints_suggestions_and_skips_callback():
    """spec: N-000703, N-000704, N-000705, N-000694, N-000695"""
    cli = build_cli()
    os.environ["_CLI_COMPLETE"] = "zsh_complete"
    os.environ["COMP_WORDS"] = "cli pi"
    os.environ["COMP_CWORD"] = "1"
    try:
        res = CliRunner().invoke(cli, [], prog_name="cli")
    finally:
        for key in ("_CLI_COMPLETE", "COMP_WORDS", "COMP_CWORD"):
            os.environ.pop(key, None)
    assert res.exit_code == 0
    assert "plain,pick" in res.stdout


def test_command_names_options_and_hidden_rules():
    """spec: N-000694, N-000695, N-000696, N-000697, N-000698, N-000699, N-000700, N-000713"""
    cli = build_cli()
    assert ("plain", "run") in complete(cli, "cli ", 1)
    assert ("plain", "hidden-one") not in complete(cli, "cli ", 1)
    names = [v for _, v in complete(cli, "cli run -", 2)]
    assert "--verbose" in names and "-v" in names and "--help" in names
    assert "--secret" not in names
    assert "--" not in [v for _, v in complete(cli, "cli run ", 2)]


def test_choice_values_and_path_requests():
    """spec: N-000697, N-000698, N-000694"""
    cli = build_cli()
    assert complete(cli, "cli pick s", 2) == [("plain", "slow")]
    assert complete(cli, "cli pick ", 2) == [("plain", "fast"), ("plain", "slow")]
    assert ("file", "x") in complete(cli, "cli run x", 2)


def test_no_match_gives_empty_list():
    """spec: N-000712"""
    cli = build_cli()
    assert complete(cli, "cli zzz", 1) == []


def test_unrecognized_instruction_prints_nothing_and_skips_callback():
    """spec: N-000714, N-000715"""
    ran = []

    @o.command()
    def cmd():
        ran.append(1)

    os.environ["_CMD_COMPLETE"] = "weird_thing"
    try:
        res = CliRunner().invoke(cmd, [], prog_name="cmd")
    finally:
        os.environ.pop("_CMD_COMPLETE", None)
    assert res.exit_code != 0
    assert ran == []
    assert "plain," not in res.stdout


def test_completion_variable_from_other_name_is_ignored():
    """spec: N-000692, N-000693"""
    ran = []

    @o.command()
    def cmd():
        ran.append(1)

    os.environ["_OTHER_COMPLETE"] = "bash_complete"
    try:
        CliRunner().invoke(cmd, [], prog_name="cmd")
    finally:
        os.environ.pop("_OTHER_COMPLETE", None)
    assert ran == [1]


def test_parameter_completion_function_and_custom_items():
    """spec: N-000706, N-000707, N-000708, N-000709, N-000710, N-000711, N-001031, N-001032, N-001033, N-001034, N-001035, N-001036, N-001037"""

    class Item:
        value = "beta"
        help = "b"
        type = "plain"

    def suggest(ctx, param, incomplete):
        return ["alpha", Item()]

    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--pick", shell_complete=suggest)
    def cmd(pick):
        pass

    names = [v for _, v in complete(cli, "cli cmd --pick ", 3)]
    assert "alpha" in names and "beta" in names
