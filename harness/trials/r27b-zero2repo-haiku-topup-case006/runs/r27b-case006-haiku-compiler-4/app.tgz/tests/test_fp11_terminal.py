"""FP-11 terminal output and interaction helpers; Interface section 7."""

import io
import os

import pytest

import optlyn as o
from optlyn.testing import CliRunner
from optlyn.utils import format_filename, get_app_dir


def test_echo_strips_styles_on_non_terminal_and_keeps_when_forced():
    """spec: N-000619, N-000620, N-000621, N-000622, N-000623, N-000624, N-000625, N-000626, N-000627, N-000681, N-000682, N-000683"""

    @o.command()
    def cmd():
        o.echo(o.style("plain", fg="red"))
        o.echo(o.style("forced", fg="red"), color=True)

    res = CliRunner().invoke(cmd, [])
    assert "\x1b[" not in res.stdout.split("\n")[0]
    assert "\x1b[31m" in res.stdout


def test_echo_forced_color_off_strips_on_terminal_stream():
    """spec: N-000627, N-000683"""
    buf = io.StringIO()
    o.echo(o.style("x", fg="red"), file=buf, color=False)
    assert buf.getvalue() == "x\n"


def test_echo_to_ascii_stream_writes_utf8_instead_of_failing():
    """spec: N-000621, N-000624"""
    raw = io.BytesIO()
    stream = io.TextIOWrapper(raw, encoding="ascii")
    o.echo("café ✓", file=stream)
    stream.flush()
    assert raw.getvalue() == "café ✓\n".encode("utf-8")


def test_echo_bytes_and_stderr():
    """spec: N-000619, N-000618"""

    @o.command()
    def cmd():
        o.echo(b"raw bytes")
        o.echo("problem", err=True)

    res = CliRunner().invoke(cmd, [])
    assert res.stdout_bytes == b"raw bytes\n"
    assert res.stderr == "problem\n"
    assert res.output == "raw bytes\nproblem\n"


def test_style_switches_colors_and_errors():
    """spec: N-000628, N-000629, N-000630, N-000631, N-000632, N-000633, N-000634, N-000635, N-000636, N-000637, N-000638, N-000639, N-000640, N-000688"""
    assert o.style("x", fg="red") != o.style("x", bg="red")
    assert o.style("x", fg="red") != o.style("x", fg="blue")
    assert o.style("x", fg=200) != o.style("x", fg=201)
    assert o.style("x", fg=(1, 2, 3)) != o.style("x", fg=(1, 2, 4))
    assert o.style("x", bold=True) != o.style("x", italic=True)
    assert o.style("x", bold=True, italic=True) not in (o.style("x", bold=True), o.style("x", italic=True))
    assert o.style("x", bold=True).endswith("\x1b[0m")
    assert o.style("x", bold=True, reset=False).endswith("x")
    assert o.unstyle(o.style("abc", fg="green", underline=True)) == "abc"
    with pytest.raises(ValueError):
        o.style("x", fg="not-a-color")
    with pytest.raises(ValueError):
        o.style("x", fg=(1, 2))
    with pytest.raises(ValueError):
        o.style("x", bg=300)


def test_secho_is_echo_plus_style():
    """spec: N-000628"""
    buf = io.StringIO()
    o.secho("hi", file=buf, color=True, bold=True)
    assert buf.getvalue().startswith("\x1b[1m")


def test_pager_non_interactive_writes_to_stdout_in_order(monkeypatch):
    """spec: N-000641, N-000642, N-000643, N-000644, N-000645, N-000646, N-000647, N-000648"""
    monkeypatch.delenv("PAGER", raising=False)

    @o.command()
    def cmd():
        o.echo_via_pager(["a", "b", "c"])
        o.echo_via_pager(lambda: "d\n")
        with o.get_pager_file() as f:
            f.write("e\n")

    res = CliRunner().invoke(cmd, [])
    assert res.stdout == "abcd\ne\n"


def test_progressbar_visits_every_item_without_terminal():
    """spec: N-000649, N-000650, N-000651, N-000652, N-000653, N-000654, N-000655, N-000656, N-000657, N-000684, N-000685"""
    seen = []
    with o.progressbar(range(4), label="work") as bar:
        for item in bar:
            seen.append(item)
    assert seen == [0, 1, 2, 3]
    hidden_seen = list(o.progressbar([7, 8], hidden=True))
    assert hidden_seen == [7, 8]


def test_progressbar_label_printed_once_without_terminal():
    """spec: N-000653, N-000654"""

    @o.command()
    def cmd():
        with o.progressbar([1, 2], label="Doing") as bar:
            for _ in bar:
                pass

    res = CliRunner().invoke(cmd, [])
    assert res.stdout.count("Doing") == 1


def test_getchar_pause_clear_are_safe_without_terminal():
    """spec: N-000658, N-000659, N-000660, N-000661, N-000662, N-000663, N-000672, N-000673, N-000686, N-000687"""

    @o.command()
    def cmd():
        o.pause("Press a key")
        o.clear()

    res = CliRunner().invoke(cmd, [])
    assert "Press a key" in res.stdout
    assert "\x1b[2J" not in res.stdout


def test_prompt_and_confirm_strip_styles_when_not_terminal():
    """spec: N-000505, N-000506, N-000507, N-000508, N-000509"""

    @o.command()
    def cmd():
        o.prompt(o.style("Name", bold=True), default="x")

    res = CliRunner().invoke(cmd, [], input="\n")
    assert "\x1b[" not in res.stdout


def test_editor_launch_with_filename_returns_none(tmp_path, monkeypatch):
    """spec: N-000664, N-000665, N-000666"""
    target = tmp_path / "doc.txt"
    target.write_text("start")
    monkeypatch.setenv("EDITOR", "true")
    assert o.edit(filename=str(target)) is None


def test_edit_returns_text_or_none_when_unchanged(monkeypatch):
    """spec: N-000664, N-000665, N-000666"""
    monkeypatch.setenv("EDITOR", "true")
    assert o.edit("unchanged") is None
    assert o.edit("unchanged", require_save=False) == "unchanged"


def test_launch_returns_int_status():
    """spec: N-000667, N-000668, N-000669, N-000670, N-000671"""
    assert isinstance(o.launch("/nonexistent-path-for-test", wait=True), int)


def test_get_app_dir_locations(monkeypatch, tmp_path):
    """spec: N-000674, N-000675, N-000676, N-000677, N-000678"""
    monkeypatch.setattr("sys.platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    assert get_app_dir("My  App") == str(tmp_path / "xdg" / "my-app")
    monkeypatch.delenv("XDG_CONFIG_HOME")
    assert get_app_dir("My App").endswith(os.path.join(".config", "my-app"))
    assert get_app_dir("My App", force_posix=True) == os.path.join(os.path.expanduser("~"), ".my-app")


def test_format_filename_is_printable_and_distinct():
    """spec: N-000575, N-000576, N-000577"""
    assert format_filename("a/b.txt") == "a/b.txt"
    assert format_filename("a/b.txt", shorten=True) == "b.txt"
    raw = format_filename(b"x\xff")
    assert raw != format_filename(b"x\xfe")
    raw.encode("utf-8")
