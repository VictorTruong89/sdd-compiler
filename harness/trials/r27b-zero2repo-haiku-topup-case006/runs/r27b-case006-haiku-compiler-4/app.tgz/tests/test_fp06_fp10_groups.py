"""FP-06 groups and nesting, FP-10 chaining and pipelines; Interface section 3."""

import pytest

import optlyn as o
from optlyn.core import CommandCollection
from optlyn.testing import CliRunner


def make_tree():
    @o.group()
    def root():
        o.echo("root cb")

    @root.group()
    def mid():
        o.echo("mid cb")

    @mid.command()
    def leaf():
        o.echo("leaf cb")

    return root


def test_nested_groups_run_outside_in():
    """spec: N-000388, N-000389, N-000390, N-000391, N-000392, N-000393, N-000398"""
    root = make_tree()
    res = CliRunner().invoke(root, ["mid", "leaf"])
    assert res.output == "root cb\nmid cb\nleaf cb\n"


def test_skipping_middle_name_is_unknown_command_of_invoked_group():
    """spec: N-000399, N-000400, N-000429, N-000430"""
    root = make_tree()
    res = CliRunner().invoke(root, ["leaf"])
    assert res.exit_code == 2
    assert "No such command 'leaf'" in res.output
    assert "root cb" not in res.output


def test_naming_nested_group_without_child_shows_its_help():
    """spec: N-000411, N-000412"""
    root = make_tree()
    res = CliRunner().invoke(root, ["mid"])
    assert res.exit_code == 2
    assert "Usage: root mid" in res.output
    assert "leaf cb" not in res.output


def test_missing_command_is_usage_error_without_help_page():
    """spec: N-000431, N-000432"""

    @o.group(no_args_is_help=False)
    @o.option("--x")
    def g(x):
        pass

    @g.command()
    def c():
        pass

    res = CliRunner().invoke(g, ["--x", "1"])
    assert res.exit_code == 2
    assert "Missing command." in res.output
    assert "Commands:" not in res.output


def test_group_callback_runs_for_group_only_and_invoke_without_command():
    """spec: N-000403, N-000404, N-000405, N-000607, N-000608"""
    seen = []

    @o.group(invoke_without_command=True)
    @o.pass_context
    def g(ctx):
        seen.append(ctx.invoked_subcommand)

    @g.command()
    def c():
        pass

    r = CliRunner()
    assert r.invoke(g, []).exit_code == 0
    r.invoke(g, ["c"])
    assert seen == [None, "c"]


def test_late_registration_and_explicit_names():
    """spec: N-000401, N-000402, N-000428"""

    @o.group()
    def g():
        pass

    @o.command()
    def hidden_name():
        o.echo("late")

    g.add_command(hidden_name, name="alias")
    assert CliRunner().invoke(g, ["alias"]).output == "late\n"


def test_lazy_subcommand_loading():
    """spec: N-000413, N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420, N-000421"""
    loaded = []

    class Lazy(o.Group):
        def list_commands(self, ctx):
            return ["lazy-one", "lazy-two"]

        def get_command(self, ctx, name):
            if name not in ("lazy-one", "lazy-two"):
                return None
            loaded.append(name)

            @o.command(name=name)
            def body():
                o.echo(f"{name} ran")

            return body

    lz = Lazy(name="lz")
    r = CliRunner()
    assert loaded == []
    r.invoke(lz, ["--help"])
    assert sorted(set(loaded)) == ["lazy-one", "lazy-two"]
    loaded.clear()
    assert r.invoke(lz, ["lazy-one"]).output == "lazy-one ran\n"
    assert loaded == ["lazy-one"]


def test_command_collection_union_and_dispatch():
    """spec: N-000422, N-000423, N-000424, N-000425"""

    @o.group()
    def a():
        pass

    @a.command()
    def one():
        o.echo("one")

    @o.group()
    def b():
        pass

    @b.command()
    def two():
        o.echo("two")

    coll = CommandCollection(name="coll", sources=[a, b])
    r = CliRunner()
    out = r.invoke(coll, ["--help"]).stdout
    assert "one" in out and "two" in out
    assert r.invoke(coll, ["two"]).output == "two\n"


def test_chaining_runs_each_in_order_and_result_callback_gets_list():
    """spec: N-000593, N-000594, N-000595, N-000597, N-000598, N-000599, N-000600, N-000601, N-000602, N-000603, N-000604"""

    @o.group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(values):
        o.echo(f"results={values}")

    @pipe.command()
    @o.argument("n", type=int)
    def add(n):
        return n + 1

    @pipe.command()
    @o.argument("n", type=int)
    def mul(n):
        return n * 10

    r = CliRunner()
    assert r.invoke(pipe, ["add", "1", "mul", "2"]).output == "results=[2, 20]\n"
    assert pipe.main(["add", "1", "mul", "2"], standalone_mode=False) == [2, 20]


def test_chaining_empty_pipeline_runs_result_callback():
    """spec: N-000605, N-000606"""

    @o.group(chain=True, invoke_without_command=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(values):
        o.echo(f"empty={values}")

    assert CliRunner().invoke(pipe, []).output == "empty=[]\n"


def test_chaining_group_refuses_nested_group():
    """spec: N-000612, N-000613, N-000614, N-000433"""

    @o.group(chain=True)
    def pipe():
        pass

    @o.group()
    def inner():
        pass

    with pytest.raises(o.exceptions.DeclarationError):
        pipe.add_command(inner)
    with pytest.raises(o.exceptions.DeclarationError):
        pipe.group()(lambda: None)


def test_group_options_precede_subcommand_and_mixing_enabled():
    """spec: N-000196, N-000197, N-000198, N-000199"""

    @o.group(allow_interspersed_args=True)
    @o.option("--g", is_flag=True)
    def g(g):
        o.echo(f"g={g}")

    @g.command()
    def c():
        o.echo("c")

    assert CliRunner().invoke(g, ["c", "--g"]).output == "g=True\nc\n"


def test_hidden_nested_group_reachable_by_name():
    """spec: N-000426, N-000427"""

    @o.group()
    def root():
        pass

    @root.group(hidden=True)
    def secret():
        pass

    @secret.command()
    def inside():
        o.echo("found")

    assert "secret" not in CliRunner().invoke(root, ["--help"]).stdout
    assert CliRunner().invoke(root, ["secret", "inside"]).output == "found\n"


def test_chained_option_after_argument_not_bound_to_subcommand():
    """spec: N-000593, N-000594, N-000595, N-000596"""

    @o.group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @o.argument("v")
    @o.option("--flag", is_flag=True)
    def one(v, flag):
        return f"{v}:{flag}"

    res = CliRunner().invoke(pipe, ["one", "x", "--flag"])
    assert res.exit_code == 2


def test_attaching_subcommands_by_decorator_and_group_callback_order():
    """spec: N-000391, N-000394, N-000395, N-000396"""

    @o.group()
    @o.option("--flag", is_flag=True)
    def top(flag):
        o.echo(f"top {flag}")

    @top.command()
    @o.option("--flag", is_flag=True)
    def sub(flag):
        o.echo(f"sub {flag}")

    assert CliRunner().invoke(top, ["--flag", "sub", "--flag"]).output == "top True\nsub True\n"
