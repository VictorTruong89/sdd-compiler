"""FP-03 options: parsing, value sources, flags, counting, multi-value, envvars."""

import os

import pytest

import optlyn as o
from optlyn.testing import CliRunner


def test_long_and_short_forms_and_equals():
    """spec: N-000188, N-000189, N-000190"""

    @o.command()
    @o.option("--name", "-n")
    def cmd(name):
        o.echo(name)

    r = CliRunner()
    assert r.invoke(cmd, ["--name=bob"]).output == "bob\n"
    assert r.invoke(cmd, ["--name", "bob"]).output == "bob\n"
    assert r.invoke(cmd, ["-n", "bob"]).output == "bob\n"
    assert r.invoke(cmd, ["-nbob"]).output == "bob\n"


def test_short_flag_stacking_and_unknown_char():
    """spec: N-000191, N-000192, N-000193, N-000268, N-000269, N-000270, N-000271, N-000272, N-000273, N-000274"""

    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-c", "val")
    def cmd(a, b, val):
        o.echo(f"{a} {b} {val}")

    r = CliRunner()
    assert r.invoke(cmd, ["-abc", "X"]).output == "True True X\n"
    assert r.invoke(cmd, ["-abcXYZ"]).output == "True True XYZ\n"
    assert r.invoke(cmd, ["-az"]).exit_code == 2


def test_destination_inferred_from_declared_names():
    """spec: N-000194, N-000195"""

    @o.command()
    @o.option("-v", "--very-loud", is_flag=True)
    @o.option("--count-me")
    def cmd(very_loud, count_me):
        o.echo(f"{very_loud} {count_me}")

    assert CliRunner().invoke(cmd, ["--very-loud", "--count-me", "3"]).output == "True 3\n"


def test_group_options_must_precede_subcommand_name():
    """spec: N-000196, N-000197, N-000198, N-000199, N-000283, N-000284"""

    @o.group()
    @o.option("--g", is_flag=True)
    def grp(g):
        o.echo(f"g={g}")

    @grp.command()
    @o.option("--c", is_flag=True)
    def sub(c):
        o.echo(f"c={c}")

    r = CliRunner()
    assert r.invoke(grp, ["--g", "sub", "--c"]).output == "g=True\nc=True\n"
    assert r.invoke(grp, ["sub", "--g"]).exit_code == 2


def test_required_option_missing_is_usage_error():
    """spec: N-000200, N-000201"""

    @o.command()
    @o.option("--key", required=True)
    def cmd(key):
        pass

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 2
    assert "--key" in res.output


def test_boolean_flags_and_on_off_pairs():
    """spec: N-000202, N-000203, N-000204, N-000205, N-000206"""

    @o.command()
    @o.option("--shout/--no-shout", default=False)
    @o.option("--verbose", is_flag=True)
    def cmd(shout, verbose):
        o.echo(f"{shout} {verbose}")

    r = CliRunner()
    assert r.invoke(cmd, []).output == "False False\n"
    assert r.invoke(cmd, ["--shout", "--verbose"]).output == "True True\n"
    assert r.invoke(cmd, ["--no-shout"]).output == "False False\n"
    assert r.invoke(cmd, ["--", "--verbose"]).exit_code == 2


def test_counting_option():
    """spec: N-000207, N-000208, N-000920"""

    @o.command()
    @o.option("-v", count=True)
    def cmd(v):
        o.echo(str(v))

    r = CliRunner()
    assert r.invoke(cmd, []).output == "0\n"
    assert r.invoke(cmd, ["-vvv"]).output == "3\n"
    assert r.invoke(cmd, ["-v", "-v"]).output == "2\n"


def test_repeatable_option_and_empty_default():
    """spec: N-000209, N-000210, N-000211, N-000212, N-000213, N-000214"""

    @o.command()
    @o.option("-i", multiple=True)
    def cmd(i):
        o.echo(repr(i))

    r = CliRunner()
    assert r.invoke(cmd, []).output == "()\n"
    assert r.invoke(cmd, ["-i", "1", "-i", "2"]).output == "('1', '2')\n"


def test_repeatable_string_default_is_usage_error():
    """spec: N-000276, N-000277, N-000278, N-000279"""

    @o.command()
    @o.option("-i", multiple=True, default="abc")
    def cmd(i):
        pass

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 2
    assert "iterable" in res.output


def test_multi_value_option_and_tuple_type():
    """spec: N-000215, N-000216, N-000217, N-000218, N-000219, N-000220"""

    @o.command()
    @o.option("--pair", nargs=2, type=int)
    @o.option("--point", type=(str, int))
    def cmd(pair, point):
        o.echo(f"{pair} {point}")

    r = CliRunner()
    assert r.invoke(cmd, ["--pair", "1", "2", "--point", "x", "3"]).output == "(1, 2) ('x', 3)\n"
    assert r.invoke(cmd, ["--pair", "1"]).exit_code == 2


def test_optional_value_option():
    """spec: N-000221, N-000222, N-000223, N-000224, N-000225"""

    @o.command()
    @o.option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def cmd(opt):
        o.echo(opt)

    r = CliRunner()
    assert r.invoke(cmd, []).output == "DEF\n"
    assert r.invoke(cmd, ["--opt"]).output == "FLAG\n"
    assert r.invoke(cmd, ["--opt", "val"]).output == "val\n"


def test_alternative_prefixes():
    """spec: N-000226"""

    @o.command()
    @o.option("/verbose", is_flag=True)
    def cmd(verbose):
        o.echo(str(verbose))

    assert CliRunner().invoke(cmd, ["/verbose"]).output == "True\n"


def test_environment_value_first_set_wins_and_empty_ignored():
    """spec: N-000227, N-000228, N-000229, N-000230, N-000231, N-000232, N-000233, N-000088"""

    @o.command()
    @o.option("--v", envvar=["AAA_V", "BBB_V"])
    def cmd(v):
        o.echo(repr(v))

    r = CliRunner()
    assert r.invoke(cmd, [], env={"AAA_V": "", "BBB_V": "second"}).output == "'second'\n"
    assert r.invoke(cmd, [], env={"AAA_V": "first", "BBB_V": "second"}).output == "'first'\n"


def test_environment_flag_values():
    """spec: N-000234, N-000235, N-000236, N-000237, N-000238, N-000239, N-000240, N-000241, N-000242"""

    @o.command()
    @o.option("--f/--no-f", envvar="FF", default=True)
    def cmd(f):
        o.echo(str(f))

    r = CliRunner()
    assert r.invoke(cmd, [], env={"FF": "off"}).output == "False\n"
    assert r.invoke(cmd, [], env={"FF": "YES"}).output == "True\n"
    assert r.invoke(cmd, [], env={"FF": ""}).output == "True\n"
    assert r.invoke(cmd, [], env={"FF": "  "}).output == "False\n"
    assert r.invoke(cmd, [], env={"FF": "maybe"}).exit_code == 2


def test_environment_split_for_multi_value_path_type():
    """spec: N-000233, N-000574"""

    @o.command()
    @o.option("--paths", multiple=True, type=o.Path(), envvar="PTHS")
    def cmd(paths):
        o.echo(repr(paths))

    res = CliRunner().invoke(cmd, [], env={"PTHS": "a" + os.pathsep + "b"})
    assert res.output == "('a', 'b')\n"


def test_value_precedence_command_line_env_default_map_default():
    """spec: N-000243, N-000244, N-000245, N-000246, N-000247, N-000248, N-000249"""

    @o.command()
    @o.option("--x", envvar="XX_X", default="declared")
    def cmd(x):
        o.echo(x)

    r = CliRunner()
    assert r.invoke(cmd, ["--x", "cli"], env={"XX_X": "env"}).output == "cli\n"
    assert r.invoke(cmd, [], env={"XX_X": "env"}).output == "env\n"
    assert r.invoke(cmd, [], default_map={"x": "map"}, env={"XX_X": "env"}).output == "env\n"
    assert r.invoke(cmd, [], default_map={"x": "map"}).output == "map\n"
    assert r.invoke(cmd, []).output == "declared\n"


def test_callback_refusal_is_usage_error_and_names_option():
    """spec: N-000250, N-000251, N-000252, N-000253, N-000254, N-000255, N-000256, N-000257"""

    def refuse(ctx, param, value):
        if value == "bad":
            raise o.BadParameter("not allowed")
        return value.upper()

    @o.command()
    @o.option("--x", callback=refuse)
    def cmd(x):
        o.echo(x)

    r = CliRunner()
    res = r.invoke(cmd, ["--x", "bad"])
    assert res.exit_code == 2
    assert "--x" in res.stderr
    assert r.invoke(cmd, ["--x", "ok"]).output == "OK\n"


def test_hidden_parameter_parsed_but_not_delivered():
    """spec: N-000264, N-000265"""

    @o.command()
    @o.option("--quiet", is_flag=True, expose_value=False)
    def cmd():
        o.echo("ran")

    assert CliRunner().invoke(cmd, ["--quiet"]).output == "ran\n"


def test_unknown_option_is_usage_error_and_unknown_long_kept_when_ignored():
    """spec: N-000268, N-000269, N-000270, N-000271, N-000272"""

    @o.command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @o.argument("rest", nargs=-1)
    def cmd(rest):
        o.echo(repr(rest))

    res = CliRunner().invoke(cmd, ["-x", "--bogus"])
    assert res.output == "('-x', '--bogus')\n"


def test_missing_value_and_too_few_values_are_usage_errors():
    """spec: N-000275, N-000221"""

    @o.command()
    @o.option("--name")
    def cmd(name):
        pass

    assert CliRunner().invoke(cmd, ["--name"]).exit_code == 2


def test_deprecated_option_warns_only_when_supplied():
    """spec: N-000266, N-000267, N-000280, N-000281, N-000282"""

    @o.command()
    @o.option("--old", deprecated=True, default="d")
    def cmd(old):
        o.echo(old)

    r = CliRunner()
    assert "DeprecationWarning" not in r.invoke(cmd, []).stderr
    assert "DeprecationWarning" in r.invoke(cmd, ["--old", "x"]).stderr

    with pytest.raises(o.exceptions.DeclarationError):
        o.Option(["--z"], deprecated=True, required=True)
    with pytest.raises(o.exceptions.DeclarationError):
        o.Option(["--z"], deprecated=True, prompt=True)


def test_prefix_option_after_argument_on_leaf():
    """spec: N-000196, N-000197"""

    @o.command()
    @o.argument("a")
    @o.option("--flag", is_flag=True)
    def cmd(a, flag):
        o.echo(f"{a} {flag}")

    assert CliRunner().invoke(cmd, ["x", "--flag"]).output == "x True\n"
