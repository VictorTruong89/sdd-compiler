"""FP-13 usage failures, abort and exit status; FP-14 in-process runner; Interface sections 2 and 9."""

import os

import pytest

import optlyn as o
from optlyn.testing import CliRunner


def test_exit_statuses_success_usage_abort_and_clean_stop():
    """spec: N-000716, N-000717, N-000718, N-000719, N-000720, N-000721, N-000722, N-000723, N-000724, N-000725, N-000726, N-000727, N-000732, N-000733"""

    @o.command()
    @o.option("--n", type=int)
    @o.pass_context
    def cmd(ctx, n):
        if n == 1:
            ctx.exit(7)
        if n == 2:
            ctx.abort()
        if n == 3:
            raise o.OptlynError("general failure")
        o.echo("ok")

    r = CliRunner()
    assert r.invoke(cmd, []).exit_code == 0
    assert r.invoke(cmd, ["--n", "1"]).exit_code == 7
    assert r.invoke(cmd, ["--n", "2"]).exit_code == 1
    assert r.invoke(cmd, ["--n", "3"]).exit_code == 1
    assert r.invoke(cmd, ["--n", "x"]).exit_code == 2


def test_clean_stop_without_status_is_zero():
    """spec: N-000716"""

    @o.command()
    @o.pass_context
    def cmd(ctx):
        ctx.exit()
        o.echo("never")

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 0 and "never" not in res.output


def test_keyboard_interrupt_is_abort_in_standalone():
    """spec: N-000734, N-000725"""

    @o.command()
    def cmd():
        raise KeyboardInterrupt()

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_usage_error_message_identifies_parameter_and_is_distinct():
    """spec: N-000735, N-000735, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380"""

    @o.command()
    @o.option("--count", type=int)
    def cmd(count):
        pass

    r = CliRunner()
    bad = r.invoke(cmd, ["--count", "abc"])
    assert bad.exit_code == 2
    assert "--count" in bad.stderr
    unknown = r.invoke(cmd, ["--zzz"])
    assert unknown.exit_code == 2
    assert "--count" not in unknown.stderr


def test_standalone_off_propagates_usage_and_abort():
    """spec: N-000728, N-000729, N-000730, N-000731"""

    @o.command()
    def cmd():
        raise o.Abort()

    with pytest.raises(o.Abort):
        cmd.main([], standalone_mode=False)


def test_runner_captures_output_and_exit_code():
    """spec: N-000739, N-000740, N-000741, N-000742, N-000743, N-000758, N-000759, N-000760, N-000761, N-001039, N-001040, N-001041, N-001042, N-001043"""

    @o.group()
    def g():
        pass

    @g.command()
    @o.option("--boom", is_flag=True)
    def sub(boom):
        o.echo("out")
        o.echo("err", err=True)
        if boom:
            raise RuntimeError("kaboom")

    r = CliRunner()
    res = r.invoke(g, ["sub"])
    assert res.exit_code == 0
    assert res.stdout == "out\n" and res.stderr == "err\n"
    assert res.output == "out\nerr\n"
    assert res.stdout_bytes == b"out\n"
    assert res.exception is None
    res = r.invoke(g, ["sub", "--boom"])
    assert res.exit_code == 1
    assert isinstance(res.exception, RuntimeError)
    with pytest.raises(RuntimeError):
        r.invoke(g, ["sub", "--boom"], catch_exceptions=False)


def test_runner_input_env_and_visible_prompt_echo():
    """spec: N-000748, N-000749, N-000750, N-000525, N-000526, N-000527, N-000742, N-000743"""

    @o.command()
    @o.option("--who", prompt=True)
    @o.option("--flag-env", envvar="RUN_FLAG")
    def cmd(who, flag_env):
        o.echo(f"{who}:{flag_env}")

    r = CliRunner()
    res = r.invoke(cmd, [], input="ann\n", env={"RUN_FLAG": "x"})
    assert res.output.endswith("ann:x\n")
    assert "Who: ann" in res.output
    assert "RUN_FLAG" not in os.environ
    res = r.invoke(cmd, [], input="ann\n", env={"RUN_FLAG": None})
    assert res.exit_code == 0


def test_runner_group_subcommand_selection_and_context_settings():
    """spec: N-000741, N-000742, N-000743"""

    @o.command()
    @o.option("--width-test", default="d")
    def cmd(width_test):
        o.echo(f"{width_test}")

    res = CliRunner().invoke(cmd, [], terminal_width=40)
    assert res.exit_code == 0


def test_runner_isolated_filesystem_default_removes_and_parent_keeps(tmp_path):
    """spec: N-000744, N-000745, N-000746, N-000747, N-000762, N-000763"""
    r = CliRunner()
    cwd = os.getcwd()
    with r.isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
        open("inside.txt", "w").write("x")
        kept = path
    assert os.getcwd() == cwd
    assert not os.path.exists(kept)

    with r.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        open("keep.txt", "w").write("y")
    assert os.path.exists(os.path.join(path, "keep.txt"))
    assert os.path.dirname(path) == str(tmp_path)


def test_runner_fd_capture_mode_records_os_level_writes():
    """spec: N-000751, N-000752, N-000753, N-000754, N-000755"""

    @o.command()
    def cmd():
        os.write(1, b"via fd\n")
        o.echo("via sys")

    res = CliRunner(capture="fd").invoke(cmd, [])
    assert "via fd" in res.stdout and "via sys" in res.stdout

    @o.command()
    def sys_only():
        o.echo("only sys")

    res = CliRunner().invoke(sys_only, [])
    assert res.stdout == "only sys\n"


def test_runner_echo_stdin_mode_echoes_reads():
    """spec: N-000750"""

    @o.command()
    def cmd():
        import sys

        value = sys.stdin.readline()
        o.echo(f"read:{value.strip()}")

    res = CliRunner(echo_stdin=True).invoke(cmd, [], input="hello\n")
    assert "hello" in res.output and "read:hello" in res.output


def test_runner_reports_nonzero_return_when_standalone_off():
    """spec: N-000760"""

    @o.command()
    def cmd():
        return 3

    res = CliRunner().invoke(cmd, [], standalone_mode=False)
    assert res.return_value == 3
