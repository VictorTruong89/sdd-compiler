"""FP-09 file and path parameters; FP-11 dash rule; Interface section 5 (File)."""

import os

import optlyn as o
from optlyn.testing import CliRunner
from optlyn.utils import open_file


def test_file_read_missing_is_usage_error_naming_path():
    """spec: N-000532, N-000533, N-000578, N-000579"""

    @o.command()
    @o.argument("f", type=o.File("r"))
    def cat(f):
        o.echo(f.read())

    r = CliRunner()
    with r.isolated_filesystem():
        res = r.invoke(cat, ["missing.txt"])
        assert res.exit_code == 2
        assert "missing.txt" in res.output


def test_file_write_truncates_before_callback_and_lazy_write_defers():
    """spec: N-000534, N-000535, N-000536, N-000537, N-000538, N-000539, N-000540, N-000541, N-000581, N-000582"""

    @o.command()
    @o.argument("f", type=o.File("w"))
    def nothing(f):
        pass

    @o.command()
    @o.argument("f", type=o.File("w", lazy=False))
    def eager(f):
        pass

    @o.command()
    @o.argument("f", type=o.File("w", lazy=True))
    def lazy(f):
        pass

    r = CliRunner()
    with r.isolated_filesystem():
        open("keep.txt", "w").write("data")
        assert r.invoke(lazy, ["keep.txt"]).exit_code == 0
        assert open("keep.txt").read() == "data"
        assert r.invoke(nothing, ["keep.txt"]).exit_code == 0
        assert open("keep.txt").read() == "data"
        assert r.invoke(eager, ["keep.txt"]).exit_code == 0
        assert open("keep.txt").read() == ""


def test_dash_is_stdin_for_read_and_stdout_for_write_and_stays_open():
    """spec: N-000542, N-000543, N-000546, N-000547, N-000588, N-000589, N-000590, N-000772"""

    @o.command()
    @o.argument("f", type=o.File("r"))
    def read(f):
        o.echo(f.read().strip().upper())

    @o.command()
    @o.argument("f", type=o.File("w"))
    def write(f):
        f.write("to stdout\n")

    r = CliRunner()
    assert r.invoke(read, ["-"], input="abc\n").output == "ABC\n"
    res = r.invoke(write, ["-"])
    assert res.output == "to stdout\n"


def test_binary_file_round_trip_and_encoding():
    """spec: N-000539, N-000540"""

    @o.command()
    @o.argument("f", type=o.File("wb"))
    def wb(f):
        f.write(b"\x00\x01")

    @o.command()
    @o.argument("f", type=o.File("rb"))
    def rb(f):
        o.echo(f.read(), nl=False)

    @o.command()
    @o.argument("f", type=o.File("w", encoding="utf-8"))
    def wt(f):
        f.write("é")

    r = CliRunner()
    with r.isolated_filesystem():
        r.invoke(wb, ["b.bin"])
        assert open("b.bin", "rb").read() == b"\x00\x01"
        assert r.invoke(rb, ["b.bin"]).stdout_bytes == b"\x00\x01"
        r.invoke(wt, ["t.txt"])
        assert open("t.txt", "rb").read() == "é".encode("utf-8")


def test_atomic_write_replaces_on_close_only():
    """spec: N-000544, N-000545"""
    seen = {}

    @o.command()
    @o.argument("f", type=o.File("w", atomic=True))
    def cmd(f):
        f.write("new")
        seen["during"] = open("target.txt").read()

    r = CliRunner()
    with r.isolated_filesystem():
        open("target.txt", "w").write("old")
        r.invoke(cmd, ["target.txt"])
        assert seen["during"] == "old"
        assert open("target.txt").read() == "new"


def test_path_resolve_and_dash_not_special_by_default():
    """spec: N-000561, N-000562, N-000563, N-000564, N-000565, N-000566"""

    @o.command()
    @o.argument("p", type=o.Path(resolve_path=True))
    def cmd(p):
        o.echo(p)

    r = CliRunner()
    with r.isolated_filesystem():
        res = r.invoke(cmd, ["./x/../y.txt"])
        assert res.exit_code == 0
        assert os.path.isabs(res.stdout.strip())


def test_open_file_helper_dash_and_immediate_open(tmp_path):
    """spec: N-000532, N-000533, N-000534, N-000748, N-000749"""
    path = tmp_path / "a.txt"
    with open_file(str(path), "w") as handle:
        handle.write("hi")
    with open_file(str(path)) as handle:
        assert handle.read() == "hi"
    lazy = open_file(str(tmp_path / "later.txt"), "w", lazy=True)
    assert not (tmp_path / "later.txt").exists()
    lazy.write("x")
    lazy.close()
    assert (tmp_path / "later.txt").read_text() == "x"
