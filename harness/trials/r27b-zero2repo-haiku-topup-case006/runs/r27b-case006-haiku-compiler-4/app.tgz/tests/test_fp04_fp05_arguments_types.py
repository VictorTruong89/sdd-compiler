"""FP-04 positional arguments and FP-05 parameter types; Interface section 5."""

import datetime
import enum
import pathlib
import uuid

import pytest

import optlyn as o
from optlyn.exceptions import DeclarationError
from optlyn.testing import CliRunner


def test_arguments_bind_in_declaration_order():
    """spec: N-000285, N-000286, N-000287, N-000288, N-000289, N-000290"""

    @o.command()
    @o.argument("src")
    @o.argument("dst")
    def cp(src, dst):
        o.echo(f"{src}->{dst}")

    assert CliRunner().invoke(cp, ["a", "b"]).output == "a->b\n"
    assert CliRunner().invoke(cp, ["a"]).exit_code == 2


def test_missing_required_argument_names_it():
    """spec: N-000321, N-000322"""

    @o.command()
    @o.argument("target")
    def cmd(target):
        pass

    res = CliRunner().invoke(cmd, [])
    assert res.exit_code == 2
    assert "TARGET" in res.output


def test_optional_argument_default_and_variadic_rules():
    """spec: N-000291, N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298, N-000299, N-000300, N-000301, N-000302, N-000303"""

    @o.command()
    @o.argument("first", default="x")
    @o.argument("more", nargs=-1)
    def cmd(first, more):
        o.echo(f"{first} {more}")

    r = CliRunner()
    assert r.invoke(cmd, []).output == "x ()\n"
    assert r.invoke(cmd, ["a", "b", "c"]).output == "a ('b', 'c')\n"


def test_second_variadic_argument_refused_at_declaration():
    """spec: N-000293"""
    with pytest.raises(DeclarationError):

        @o.command()
        @o.argument("a", nargs=-1)
        @o.argument("b", nargs=-1)
        def bad(a, b):
            pass


def test_double_dash_makes_option_like_tokens_arguments():
    """spec: N-000304, N-000305, N-000306"""

    @o.command()
    @o.argument("x", nargs=-1)
    def cmd(x):
        o.echo(repr(x))

    assert CliRunner().invoke(cmd, ["--", "-a", "--b"]).output == "('-a', '--b')\n"


def test_argument_environment_only_when_named_explicitly():
    """spec: N-000309, N-000310, N-000311, N-000312, N-000313, N-000314, N-000315, N-000316, N-000317"""

    @o.command()
    @o.argument("name", envvar="NAME_FROM_ENV")
    @o.argument("other", required=False, default="o")
    def cmd(name, other):
        o.echo(f"{name} {other}")

    r = CliRunner()
    assert r.invoke(cmd, [], env={"NAME_FROM_ENV": "e"}).output == "e o\n"
    assert r.invoke(cmd, ["x"], env={"NAME_FROM_ENV": "e"}).output == "x o\n"
    # A variable merely named like the destination does not fill an argument.
    assert r.invoke(cmd, [], env={"NAME": "zz"}).exit_code == 2


def test_argument_help_section_and_metavar():
    """spec: N-000318, N-000319, N-000320, N-000835, N-000836"""

    @o.command()
    @o.argument("path", help="The file", metavar="FILE")
    def cmd(path):
        pass

    out = CliRunner().invoke(cmd, ["--help"]).stdout
    assert "Positional arguments:" in out
    assert "FILE" in out and "The file" in out


def test_deprecated_argument_and_required_combinations():
    """spec: N-000325, N-000326, N-000327, N-000328, N-000329"""
    with pytest.raises(DeclarationError):
        o.Argument(["x"], deprecated=True, required=True)
    arg = o.Argument(["x"], deprecated=True, default="d")
    assert arg.required is False


def test_builtin_types_convert_and_refuse():
    """spec: N-000332, N-000333, N-000334, N-000335, N-000336, N-000337, N-000338, N-000339, N-000340, N-000341, N-000342, N-000343, N-000344, N-000345, N-000346, N-000347"""
    assert o.STRING.convert("1") == "1"
    assert o.INT.convert("42") == 42
    with pytest.raises(o.BadParameter):
        o.INT.convert("1.5")
    assert o.FLOAT.convert("1.5") == 1.5
    assert o.BOOL.convert("Yes") is True
    assert o.BOOL.convert("off") is False
    with pytest.raises(o.BadParameter):
        o.BOOL.convert("maybe")
    assert o.UUID.convert(str(uuid.UUID(int=5))) == uuid.UUID(int=5)
    assert o.UNPROCESSED.convert("raw") == "raw"


def test_choice_case_rules_and_original_object_delivered():
    """spec: N-000348, N-000349, N-000350, N-000351, N-000352, N-000382, N-000383"""

    class Mode(enum.Enum):
        Fast = 1
        Slow = 2

    ci = o.Choice(["Alpha", "beta"], case_sensitive=False)
    assert ci.convert("ALPHA") == "Alpha"
    with pytest.raises(o.BadParameter):
        o.Choice(["Alpha"]).convert("alpha")
    assert o.Choice(Mode).convert("Fast") is Mode.Fast
    assert o.Choice(["x", "x"]).convert("x") == "x"


def test_datetime_default_and_custom_formats():
    """spec: N-000353, N-000354, N-000355, N-000356, N-000357"""
    assert o.DateTime().convert("2020-01-02") == datetime.datetime(2020, 1, 2)
    assert o.DateTime().convert("2020-01-02 03:04:05") == datetime.datetime(2020, 1, 2, 3, 4, 5)
    custom = o.DateTime(["%d/%m/%Y"])
    assert custom.convert("03/04/2021") == datetime.datetime(2021, 4, 3)
    with pytest.raises(o.BadParameter):
        custom.convert("2021-04-03")


def test_int_range_bounds_and_clamp():
    """spec: N-000358, N-000359, N-000360, N-000361, N-000362"""
    closed = o.IntRange(0, 10)
    assert closed.convert("10") == 10
    with pytest.raises(o.BadParameter):
        closed.convert("11")
    clamped = o.IntRange(0, 10, clamp=True)
    assert clamped.convert("99") == 10
    assert clamped.convert("-5") == 0
    open_min = o.IntRange(0, None, min_open=True, clamp=True)
    assert open_min.convert("0") == 1


def test_float_range_clamp_rules():
    """spec: N-000363, N-000364, N-000365, N-000381"""
    fr = o.FloatRange(0.0, 1.0, clamp=True)
    assert fr.convert("2") == 1.0
    assert fr.convert("-1") == 0.0
    with pytest.raises(DeclarationError):
        o.FloatRange(0.0, 1.0, min_open=True, clamp=True)
    with pytest.raises(o.BadParameter):
        o.FloatRange(0.0, 1.0).convert("2")


def test_tuple_type_converts_each_position():
    """spec: N-000366, N-000218, N-000219"""
    tup = o.Tuple([str, int])
    assert tup.convert(("a", "3")) == ("a", 3)
    with pytest.raises(o.BadParameter):
        tup.convert(("a",))


def check_tag(value):
    if not value.startswith("t"):
        raise ValueError("tags start with t")
    return value


def test_custom_type_and_conversion_function():
    """spec: N-000370, N-000371, N-000372, N-000373, N-000374, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380"""

    class Upper(o.ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str):
                return value.upper()
            return value

    @o.command()
    @o.option("--u", type=Upper())
    @o.option("--n", type=int)
    @o.option("--tag", type=check_tag)
    def cmd(u, n, tag):
        o.echo(f"{u} {n} {tag}")

    r = CliRunner()
    assert r.invoke(cmd, ["--u", "abc", "--n", "2", "--tag", "tx"]).output == "ABC 2 tx\n"
    res = r.invoke(cmd, ["--tag", "bad"])
    assert res.exit_code == 2
    assert "--tag" in res.output


def test_inferred_type_from_default():
    """spec: N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000333"""

    @o.command()
    @o.option("--n", default=3)
    @o.option("--f", default=1.5)
    def cmd(n, f):
        o.echo(f"{n!r} {f!r}")

    r = CliRunner()
    assert r.invoke(cmd, ["--n", "7", "--f", "2"]).output == "7 2.0\n"
    assert r.invoke(cmd, []).output == "3 1.5\n"


def test_path_type_checks_and_dash():
    """spec: N-000548, N-000549, N-000550, N-000551, N-000552, N-000553, N-000554, N-000555, N-000556, N-000557, N-000558, N-000583, N-000584, N-000585, N-000586, N-000587"""

    @o.command()
    @o.argument("p", type=o.Path(exists=True, dir_okay=False))
    def cmd(p):
        o.echo(p)

    @o.command()
    @o.argument("p", type=o.Path(allow_dash=True, path_type=pathlib.Path))
    def dash(p):
        o.echo(f"{type(p).__name__} {p}")

    r = CliRunner()
    with r.isolated_filesystem():
        open("f.txt", "w").write("x")
        import os

        os.mkdir("sub")
        assert r.invoke(cmd, ["f.txt"]).output == "f.txt\n"
        assert r.invoke(cmd, ["sub"]).exit_code == 2
        assert r.invoke(cmd, ["nope"]).exit_code == 2
        assert r.invoke(dash, ["-"]).output == "PosixPath -\n"
