"""FP-07 invocation context, defaults and value sources; FP-08 prompts; Interface section 6."""

import optlyn as o
from optlyn.testing import CliRunner


class Settings:
    def __init__(self):
        self.count = 0


class Other:
    pass


def test_context_object_inherited_and_replaced_by_nearest():
    """spec: N-000434, N-000435, N-000436, N-000437, N-000438, N-000439, N-000440, N-000441, N-000442, N-000443"""

    @o.group()
    @o.pass_context
    def top(ctx):
        ctx.obj = Settings()

    @top.command()
    @o.pass_obj
    def sub(obj):
        obj.count += 1
        o.echo(f"count={obj.count}")

    r = CliRunner()
    assert r.invoke(top, ["sub"]).output == "count=1\n"


def test_make_pass_decorator_finds_nearest_matching_type_and_ensures():
    """spec: N-000442, N-000443, N-000975, N-000976, N-000977"""
    pass_settings = o.make_pass_decorator(Settings, ensure=True)

    @o.command()
    @pass_settings
    def cmd(s):
        o.echo(str(type(s).__name__))

    assert CliRunner().invoke(cmd, []).output == "Settings\n"

    @o.group()
    @o.pass_context
    def g(ctx):
        ctx.obj = Other()

    @g.command()
    @o.make_pass_decorator(Settings, ensure=False)
    def strict(s):
        o.echo("found")

    res = CliRunner().invoke(g, ["strict"])
    assert res.exit_code != 0


def test_default_map_nests_by_subcommand_and_string_splitting():
    """spec: N-000450, N-000451, N-000452, N-000453, N-000454, N-000455, N-000456, N-000457, N-000458, N-000459, N-000460, N-000461, N-000462"""

    @o.group()
    def app():
        pass

    @app.command()
    @o.option("--num", type=int, default=0)
    def sub(num):
        o.echo(f"num={num}")

    r = CliRunner()
    assert r.invoke(app, ["sub"], default_map={"sub": {"num": 5}}).output == "num=5\n"
    assert r.invoke(app, ["sub"], default_map={"other": {"num": 5}}).output == "num=0\n"
    assert r.invoke(app, ["sub", "--num", "9"], default_map={"sub": {"num": 5}}).output == "num=9\n"


def test_default_map_on_leaf_keyed_by_destination():
    """spec: N-000460, N-000461"""

    @o.command()
    @o.option("--name", required=True)
    def leaf(name):
        o.echo(name)

    assert CliRunner().invoke(leaf, [], default_map={"name": "from-map"}).output == "from-map\n"


def test_command_context_settings_default_map():
    """spec: N-000462"""

    @o.command(context_settings={"default_map": {"who": "ctx-default"}})
    @o.option("--who", default="declared")
    def cmd(who):
        o.echo(who)

    assert CliRunner().invoke(cmd, []).output == "ctx-default\n"


def test_auto_envvar_prefix_built_from_subcommand_path():
    """spec: N-000444, N-000445, N-000446, N-000447, N-000448, N-000449, N-000481"""

    @o.group()
    def app():
        pass

    @app.command()
    @o.option("--num", type=int, default=0)
    @o.option("--private", default="p", allow_from_autoenv=False)
    @o.argument("pos", required=False, default="none")
    def sub(num, private, pos):
        o.echo(f"{num} {private} {pos}")

    r = CliRunner()
    res = r.invoke(app, ["sub"], auto_envvar_prefix="MYAPP", env={"MYAPP_SUB_NUM": "42", "MYAPP_SUB_PRIVATE": "no"})
    assert res.output == "42 p none\n"
    res = r.invoke(app, ["sub"], auto_envvar_prefix="MYAPP", env={"MYAPP_SUB_POS": "bad"})
    assert res.output == "0 p none\n"


def test_parameter_source_distinguishes_sources():
    """spec: N-000463, N-000464, N-000465, N-000466"""
    seen = {}

    @o.command()
    @o.option("--a", default=1)
    @o.option("--b", envvar="BB_B")
    @o.option("--c")
    @o.pass_context
    def cmd(ctx, a, b, c):
        seen.update({n: ctx.get_parameter_source(n) for n in ("a", "b", "c", "zzz")})

    CliRunner().invoke(cmd, ["--c", "x"], env={"BB_B": "e"})
    assert seen["a"] is o.ParameterSource.DEFAULT
    assert seen["b"] is o.ParameterSource.ENVIRONMENT
    assert seen["c"] is o.ParameterSource.COMMANDLINE
    assert seen["zzz"] is None


def test_invoke_and_forward_run_other_commands():
    """spec: N-000471, N-000472, N-000473, N-000474, N-000475, N-000476"""

    @o.command()
    @o.option("--who", default="me")
    def target(who):
        o.echo(f"target {who}")

    @o.command()
    @o.option("--who", default="me")
    @o.pass_context
    def caller(ctx, who):
        ctx.forward(target)
        ctx.invoke(target, who="direct")

    assert CliRunner().invoke(caller, ["--who", "x"]).output == "target x\ntarget direct\n"


def test_resources_closed_after_invocation_even_on_abort():
    """spec: N-000467, N-000482, N-000483"""
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            closed.append(True)

    @o.group()
    @o.pass_context
    def g(ctx):
        ctx.with_resource(Res())

    @g.command()
    def boom():
        raise o.Abort()

    res = CliRunner().invoke(g, ["boom"])
    assert res.exit_code == 1
    assert closed == [True]


def test_token_normalize_function_applies_to_names_and_choices():
    """spec: N-000468, N-000469, N-000470"""

    @o.command()
    @o.option("--mode", type=o.Choice(["Alpha"]))
    def cmd(mode):
        o.echo(mode)

    r = CliRunner()
    assert r.invoke(cmd, ["--MODE", "alpha"], token_normalize_func=str.lower).output == "Alpha\n"
    assert r.invoke(cmd, ["--mode", "alpha"]).exit_code == 2


def test_get_current_context_and_thread_visibility():
    """spec: N-000477, N-000478, N-000479"""
    import threading

    seen = []

    @o.command()
    def cmd():
        ctx = o.get_current_context()
        seen.append(ctx.command_path)
        results = []
        t = threading.Thread(target=lambda: results.append(o.get_current_context(silent=True)))
        t.start()
        t.join()
        seen.append(results[0])

    CliRunner().invoke(cmd, [], prog_name="prog")
    assert seen[0] == "prog" and seen[1] is None


# --------------------------------------------------------------- FP-08


def test_prompt_used_when_option_omitted_and_skipped_when_given():
    """spec: N-000488, N-000489, N-000490, N-000491, N-000492, N-000493, N-000494, N-000495, N-000496"""

    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        o.echo(f"hi {name}")

    r = CliRunner()
    assert r.invoke(cmd, [], input="bob\n").output.endswith("hi bob\n")
    assert r.invoke(cmd, ["--name", "x"], input="unused\n").output == "hi x\n"


def test_prompt_default_used_on_empty_line_and_custom_text():
    """spec: N-000497, N-000498, N-000499, N-000500, N-000488"""

    @o.command()
    @o.option("--age", type=int, prompt="How old", default=5)
    def cmd(age):
        o.echo(str(age))

    res = CliRunner().invoke(cmd, [], input="\n")
    assert "How old" in res.stdout
    assert res.output.strip().splitlines()[-1] == "5"


def test_prompt_reasks_on_conversion_failure():
    """spec: N-000520, N-000521, N-000522"""

    @o.command()
    @o.option("--n", type=int, prompt=True)
    def cmd(n):
        o.echo(str(n))

    res = CliRunner().invoke(cmd, [], input="x\n7\n")
    assert res.output.strip().splitlines()[-1] == "7"
    assert "Error" in res.stderr or "Error" in res.stdout


def test_standalone_prompt_and_confirm_answers():
    """spec: N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507, N-000508, N-000509"""

    @o.command()
    def cmd():
        o.echo(str(o.prompt("Value", type=int)))
        o.echo(str(o.confirm("Sure?")))
        o.echo(str(o.confirm("Really?", default=True)))

    res = CliRunner().invoke(cmd, [], input="12\nYES\n\n")
    assert "12\n" in res.output
    assert res.output.endswith("True\n")
    assert res.output.count("True\n") == 2


def test_confirm_abort_flag_and_eof_abort():
    """spec: N-000507, N-000524"""

    @o.command()
    def cmd():
        o.confirm("Go?", abort=True)
        o.echo("went")

    r = CliRunner()
    assert r.invoke(cmd, [], input="n\n").exit_code == 1
    assert r.invoke(cmd, [], input="y\n").output.endswith("went\n")
    assert r.invoke(cmd, [], input="").exit_code == 1


def test_password_option_hidden_and_confirmed():
    """spec: N-000510, N-000511, N-000512, N-000525, N-000526, N-000527"""

    @o.command()
    @o.password_option()
    def cmd(password):
        o.echo(f"pw={password}")

    r = CliRunner()
    res = r.invoke(cmd, [], input="secret\nsecret\n")
    assert res.output.endswith("pw=secret\n")
    assert "secret\n" not in res.output.split("pw=")[0]
    res = r.invoke(cmd, [], input="a\nb\nsecret\nsecret\n")
    assert res.output.endswith("pw=secret\n")


def test_confirmation_option_flag_skips_question_and_declining_aborts():
    """spec: N-000513, N-000514, N-000515, N-000516, N-000517, N-000518, N-000519"""

    @o.command()
    @o.confirmation_option(prompt="Proceed?")
    def cmd():
        o.echo("ran")

    r = CliRunner()
    assert r.invoke(cmd, ["--yes"]).output == "ran\n"
    res = r.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1
    assert "ran" not in res.output
    assert "Proceed?" in res.output
    assert r.invoke(cmd, [], input="y\n").output.endswith("ran\n")
