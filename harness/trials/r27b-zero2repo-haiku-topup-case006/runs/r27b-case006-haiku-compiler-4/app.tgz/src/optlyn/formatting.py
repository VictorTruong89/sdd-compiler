"""Text wrapping and help-page layout helpers."""

from __future__ import annotations

import re
import textwrap
import typing as t

# spec: N-000679, N-000680
# spec: N-001009
def wrap_text(
    text: str,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace character keeps its line breaks; the
    backspace line itself is removed. Accepts any string.
    """
    width = max(int(width), 1)
    text = str(text).replace("\r\n", "\n")
    paragraphs = re.split(r"\n\s*\n", text)
    out: list[str] = []
    for para in paragraphs:
        lines = para.split("\n")
        if not any(line.strip() for line in lines):
            continue
        if lines[0].strip() == "\b":
            kept = [line for line in lines[1:]]
            for line in kept:
                if not line.strip():
                    out.append("")
                    continue
                out.extend(
                    textwrap.wrap(
                        line.strip(),
                        width=width,
                        initial_indent=initial_indent,
                        subsequent_indent=subsequent_indent,
                        break_long_words=False,
                        break_on_hyphens=False,
                    )
                    or [""]
                )
            out.append("")
            continue
        joined = " ".join(line.strip() for line in lines if line.strip())
        wrapped = textwrap.wrap(
            joined,
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.extend(wrapped or [initial_indent.rstrip()])
        out.append("")
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def make_default_short_help(help_text: str, max_length: int = 45) -> str:
    """Short help: the first sentence of the first paragraph, cut to ``max_length``.

    A cut is marked with ``...``.
    """
    first_para = re.split(r"\n\s*\n", help_text.strip(), maxsplit=1)[0]
    joined = " ".join(line.strip() for line in first_para.split("\n") if line.strip())
    match = re.search(r"[.!?](\s|$)", joined)
    sentence = joined[: match.start() + 1] if match else joined
    if len(sentence) <= max_length:
        return sentence
    cut = sentence[: max_length - 3]
    if " " in cut:
        cut = cut[: cut.rfind(" ")]
    return cut.rstrip(" ,;:") + "..."


def write_dl(
    rows: t.Sequence[tuple[str, str]],
    width: int,
    indent: int = 2,
    col_max: int = 30,
    col_spacing: int = 2,
) -> list[str]:
    """Lay out ``(first, second)`` entries in two aligned columns."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    pad = " " * indent
    out: list[str] = []
    for first, second in rows:
        help_width = max(width - indent - first_width - col_spacing, 20)
        if not second:
            out.append(f"{pad}{first}")
            continue
        wrapped = wrap_text(second, width=help_width).split("\n") if second else []
        if len(first) > first_width:
            out.append(f"{pad}{first}")
            out.extend(f"{pad}{' ' * (first_width + col_spacing)}{line}" for line in wrapped)
            continue
        if not wrapped:
            out.append(f"{pad}{first}")
            continue
        out.append(f"{pad}{first.ljust(first_width + col_spacing)}{wrapped[0]}")
        out.extend(f"{pad}{' ' * (first_width + col_spacing)}{line}" for line in wrapped[1:])
    return out


__all__ = ["wrap_text", "make_default_short_help", "write_dl"]
