"""Parameter types: conversion of command-line tokens to Python values."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import typing as t
import uuid

from .exceptions import BadParameter, DeclarationError
from .utils import format_filename, open_file


# spec: N-000370, N-000371, N-000372, N-000373, N-000374, N-000941, N-000942
class ParamType:
    """Base class for parameter types.

    Subclasses set :attr:`name` (shown upper-cased as the default metavar) and
    implement :meth:`convert`, which must pass through values that already have
    the right type and refuse bad input by raising :class:`BadParameter`.
    """

    name = "text"
    is_composite = False

    # spec: N-000941, N-000942, N-000943, N-000946, N-000947, N-000948, N-000949
    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        if value is not None:
            return self.convert(value, param, ctx)
        return value

    # spec: N-000332, N-000333, N-000334, N-000335, N-000336, N-000337, N-000338, N-000339, N-000340, N-000341, N-000342, N-000343, N-000344, N-000345, N-000346, N-000347, N-000348, N-000349, N-000350, N-000351, N-000352, N-000353, N-000354, N-000355, N-000356, N-000357, N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364, N-000365, N-000366, N-000367, N-000368, N-000369, N-000370, N-000371, N-000372, N-000373, N-000374
    def convert(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return value

    def get_metavar(self, param: t.Any) -> str | None:
        return None

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list[t.Any]:
        return []

    def split_envvar_value(self, rv: str) -> list[str]:
        return rv.split()

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (bytes, bytearray)):
            return bytes(value).decode("utf-8", "replace")
        return value if isinstance(value, str) else str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


# spec: N-000348, N-000349, N-000350, N-000351, N-000352, N-000382, N-000383
class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        self.originals: list[t.Any] = []
        self.tokens: list[str] = []
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            members = list(choices)
            self.originals = members
            self.tokens = [m.name for m in members]
        else:
            for choice in choices:
                self.originals.append(choice)
                self.tokens.append(str(choice))
        self.choices = self.originals

    def _norm(self, text: str, ctx: t.Any) -> str:
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if func is not None:
            text = func(text)
        return text if self.case_sensitive else text.lower()

    def convert(self, value, param=None, ctx=None):
        for original in self.originals:
            if value is original:
                return original
        token = self._norm(str(value), ctx)
        for original, tok in zip(self.originals, self.tokens):
            if self._norm(tok, ctx) == token:
                return original
        choices = ", ".join(repr(tok) for tok in self.tokens)
        self.fail(f"{value!r} is not {'one of ' if len(self.tokens) > 1 else ''}{choices}.", param, ctx)

    def get_metavar(self, param):
        return "[" + "|".join(self.tokens) + "]"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        out = []
        for tok in self.tokens:
            candidate, prefix = (tok, incomplete) if self.case_sensitive else (tok.lower(), incomplete.lower())
            if candidate.startswith(prefix):
                out.append(CompletionItem(tok))
        return out

    def __repr__(self) -> str:
        return f"Choice({self.tokens!r})"


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


# spec: N-000353, N-000354, N-000355, N-000356, N-000357
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Sequence[str] | None = None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)

    def __repr__(self) -> str:
        return f"DateTime({self.formats!r})"


# spec: N-000358, N-000359, N-000360, N-000361, N-000362
class IntRange(IntParamType):
    name = "integer range"

    def __init__(
        self,
        min: int | None = None,
        max: int | None = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise DeclarationError("IntRange min is greater than max.")

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            if self.min_open:
                if rv <= self.min:
                    if self.clamp:
                        return self.min + 1
                    self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
            elif rv < self.min:
                if self.clamp:
                    return self.min
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if self.max_open:
                if rv >= self.max:
                    if self.clamp:
                        return self.max - 1
                    self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
            elif rv > self.max:
                if self.clamp:
                    return self.max
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        return rv

    def _range_text(self) -> str:
        lo = "" if self.min is None else (f"{'>' if self.min_open else '>='}{self.min}")
        hi = "" if self.max is None else (f"{'<' if self.max_open else '<='}{self.max}")
        return " and ".join(p for p in (lo, hi) if p) or "any"


# spec: N-000363, N-000364, N-000365, N-000381
class FloatRange(FloatParamType):
    name = "float range"

    def __init__(
        self,
        min: float | None = None,
        max: float | None = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if clamp and (min_open or max_open):
            raise DeclarationError("FloatRange cannot clamp when a bound is open.")
        if clamp and (min is None or max is None):
            raise DeclarationError("FloatRange clamp requires both bounds.")
        if min is not None and max is not None and min > max:
            raise DeclarationError("FloatRange min is greater than max.")

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            bad = rv <= self.min if self.min_open else rv < self.min
            if bad:
                if self.clamp:
                    return self.min
                self.fail(f"{rv} is outside the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            bad = rv >= self.max if self.max_open else rv > self.max
            if bad:
                if self.clamp:
                    return self.max
                self.fail(f"{rv} is outside the range {self._range_text()}.", param, ctx)
        return rv

    def _range_text(self) -> str:
        lo = "" if self.min is None else (f"{'>' if self.min_open else '>='}{self.min}")
        hi = "" if self.max is None else (f"{'<' if self.max_open else '<='}{self.max}")
        return " and ".join(p for p in (lo, hi) if p) or "any"


def _convert_nested(ty: t.Any) -> ParamType:
    return convert_type(ty)


class TupleParamType(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [_convert_nested(ty) for ty in types]

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (str, bytes)) or not isinstance(value, (tuple, list)):
            self.fail(f"expected {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(ty(v, param, ctx) for ty, v in zip(self.types, value))

    def __repr__(self) -> str:
        return f"Tuple({self.types!r})"


# spec: N-000528, N-000529, N-000530, N-000531, N-000580, N-000581, N-000582
class FileParamType(ParamType):
    name = "filename"

    def __init__(
        self,
        mode: str = "r",
        encoding: str | None = None,
        errors: str = "strict",
        lazy: bool | None = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"unsupported File mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        writing = "w" in self.mode
        lazy = self.lazy if self.lazy is not None else writing
        filename = os.fspath(value) if not isinstance(value, bytes) else os.fsdecode(value)
        try:
            handle = open_file(
                filename,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{format_filename(filename)}': {exc.strerror or exc}.", param, ctx)
        if ctx is not None and filename != "-":
            ctx.call_on_close(handle.close)
        return handle

    def get_metavar(self, param):
        return "FILENAME"

    def split_envvar_value(self, rv: str) -> list[str]:
        return rv.split(os.pathsep)

    def __repr__(self) -> str:
        return f"File({self.mode!r})"


# spec: N-000559, N-000560, N-000561, N-000562, N-000563, N-000564, N-000565, N-000566, N-000567, N-000568, N-000569, N-000570, N-000571, N-000572, N-000573
class PathParamType(ParamType):
    name = "path"

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, pathlib.PurePath):
            value = os.fspath(value)
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if self.allow_dash and value == "-":
            result = "-"
        else:
            path = value
            if self.resolve_path:
                path = os.path.realpath(os.path.expanduser(path))
            if not os.path.exists(path):
                if self.exists:
                    self.fail(f"{format_filename(value)!r} does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(path):
                    self.fail(f"{format_filename(value)!r} is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(path):
                    self.fail(f"{format_filename(value)!r} is a directory.", param, ctx)
                if self.readable and not os.access(path, os.R_OK):
                    self.fail(f"{format_filename(value)!r} is not readable.", param, ctx)
                if self.writable and not os.access(path, os.W_OK):
                    self.fail(f"{format_filename(value)!r} is not writable.", param, ctx)
                if self.executable and not os.access(path, os.X_OK):
                    self.fail(f"{format_filename(value)!r} is not executable.", param, ctx)
            result = path
        if self.path_type is pathlib.Path or self.path_type is pathlib.PurePath:
            return pathlib.Path(result)
        return result

    def get_metavar(self, param):
        return "PATH"

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv: str) -> list[str]:
        return rv.split(os.pathsep)

    def __repr__(self) -> str:
        return "Path()"


class FuncParamType(ParamType):
    """Adapter for a conversion function that refuses by raising ValueError."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BUILTIN_TYPES: dict[t.Any, ParamType] = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    uuid.UUID: UUID,
}


def _infer_from_value(value: t.Any) -> ParamType:
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    return STRING


# spec: N-000936, N-000937, N-000938, N-000939, N-000940, N-000944, N-000945
# spec: N-000330, N-000331, N-000936, N-000937, N-000938, N-000939, N-000940
def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Return a :class:`ParamType` for ``ty``, inferring from ``default`` if None."""
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, (list, tuple)):
            if default:
                return _infer_from_value(default[0])
            return STRING
        return _infer_from_value(default)
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, tuple) or (isinstance(ty, list)):
        return TupleParamType(ty)
    if ty in _BUILTIN_TYPES:
        return _BUILTIN_TYPES[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise DeclarationError(f"unsupported parameter type {ty!r}.")


__all__ = [
    "ParamType",
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    "convert_type",
]

# Public constructors use the names from the Interface Contract.
Tuple = TupleParamType
File = FileParamType
Path = PathParamType
