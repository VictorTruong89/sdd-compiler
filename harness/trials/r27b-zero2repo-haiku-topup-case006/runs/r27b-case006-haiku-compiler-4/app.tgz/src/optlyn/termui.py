"""Terminal output and interaction helpers."""

from __future__ import annotations

import codecs
import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import typing as t

from ._context import get_current_context
from .exceptions import Abort, BadParameter, InvalidColorError

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

# spec: N-000628, N-000629, N-000630
_FG_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
    "reset": 39,
}
_BG_COLORS = {name: (49 if name == "reset" else code + 10) for name, code in _FG_COLORS.items()}
_SWITCHES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _color_code(color: t.Any, names: dict[str, int], base: int) -> str:
    if isinstance(color, str):
        if color not in names:
            raise InvalidColorError(f"unknown color {color!r}")
        return str(names[color])
    if isinstance(color, bool):
        raise InvalidColorError(f"invalid color {color!r}")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{base};5;{color}"
        raise InvalidColorError(f"color index {color} is outside 0-255")
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            r, g, b = color
            return f"{base};2;{r};{g};{b}"
        raise InvalidColorError("RGB components must be integers 0-255")
    raise InvalidColorError(f"invalid color {color!r}")


# spec: N-000631, N-000632, N-000633, N-000634, N-000635, N-000636, N-000637, N-000638, N-000639, N-000640
# spec: N-000984, N-000985, N-000986
def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: bool | None = None,
    dim: bool | None = None,
    underline: bool | None = None,
    overline: bool | None = None,
    italic: bool | None = None,
    blink: bool | None = None,
    reverse: bool | None = None,
    strikethrough: bool | None = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise."""
    codes: list[str] = []
    if fg is not None:
        codes.append(_color_code(fg, _FG_COLORS, 38))
    if bg is not None:
        codes.append(_color_code(bg, _BG_COLORS, 48))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on:
            codes.append(str(_SWITCHES[name]))
    text = str(text)
    if not codes:
        return text
    prefix = f"\x1b[{';'.join(codes)}m"
    return prefix + text + ("\x1b[0m" if reset else "")


# spec: N-000640
def unstyle(text: t.Any) -> str:
    """Remove ANSI escape sequences, leaving all other text unchanged."""
    return _ANSI_RE.sub("", str(text))


def _isatty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


# spec: N-001012, N-000662
def is_interactive() -> bool:
    """True when standard input or standard output is a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


# spec: N-000480
def _should_strip(file: t.Any, color: bool | None) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is None:
        return not _isatty(file)
    return not color


def _is_ascii_stream(file: t.Any) -> bool:
    enc = getattr(file, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def _flush(file: t.Any) -> None:
    try:
        file.flush()
    except Exception:
        pass


def _write_bytes(file: t.Any, data: bytes) -> None:
    buf = getattr(file, "buffer", None)
    if buf is None:
        file.write(data.decode("utf-8", "replace"))
        return
    _flush(file)
    buf.write(data)
    try:
        buf.flush()
    except Exception:
        pass


# spec: N-000103, N-000104
def _write_text(file: t.Any, text: str) -> None:
    # spec: N-000624 - an ASCII-only stream gets UTF-8 bytes instead of failing
    if _is_ascii_stream(file):
        _write_bytes(file, text.encode("utf-8"))
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        _write_bytes(file, text.encode("utf-8"))


# spec: N-000619, N-000620, N-000621, N-000622, N-000623, N-000624, N-000625, N-000626, N-000627
# spec: N-000982, N-000983
# spec: N-000981
def echo(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: bool | None = None,
) -> None:
    """Write ``message`` (text or bytes) to stdout, stderr or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        _write_bytes(file, bytes(message) + (b"\n" if nl else b""))
    else:
        text = str(message)
        if _should_strip(file, color):
            text = unstyle(text)
        if nl:
            text += "\n"
        if text:
            _write_text(file, text)
    _flush(file)


def secho(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: bool | None = None,
    **styles: t.Any,
) -> None:
    """Echo ``message`` styled with the keyword arguments of :func:`style`."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- input

def _read_hidden_tty(stream: t.Any) -> str:
    try:
        import termios
    except ImportError:  # pragma: no cover - Windows
        return stream.readline()
    fd = stream.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] &= ~termios.ECHO
    try:
        termios.tcsetattr(fd, termios.TCSADRAIN, new)
        line = stream.readline()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    sys.stdout.write("\n")
    sys.stdout.flush()
    return line


def _read_line(hide_input: bool = False) -> str:
    """Read one line from standard input. Raises EOFError at end of input."""
    stream = sys.stdin
    if stream is None:
        raise EOFError
    if hide_input:
        if hasattr(stream, "_readline_hidden"):
            line = stream._readline_hidden()
        elif _isatty(stream):
            line = _read_hidden_tty(stream)
        else:
            line = stream.readline()
    else:
        line = stream.readline()
    if not line:
        raise EOFError
    return line.rstrip("\r\n")


# spec: N-000525, N-000526, N-000527
def _echo_typed(line: str, hide_input: bool) -> None:
    """Runner-only: echo a visible typed answer into captured output."""
    if hide_input:
        return
    stream = sys.stdin
    if getattr(stream, "runner_input", False) and not getattr(stream, "echo_stdin", False):
        echo(line)


# spec: N-000484, N-000485, N-000486, N-000487
def prompt_loop(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    value_proc: t.Callable[[str], t.Any] | None = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    default_display: str | None = None,
    err: bool = False,
) -> tuple[t.Any, bool]:
    """Ask until a valid answer is given.

    Returns ``(value, answered)``. When the user gives an empty answer and a
    default exists, returns ``(default, False)`` and the default is not
    converted. Otherwise returns the converted answer with ``answered`` true.
    Conversion failures re-ask. End of input raises :class:`Abort`.
    """
    suffix_default = ""
    if default is not None and show_default:
        shown = default_display if default_display is not None else str(default)
        suffix_default = f" [{shown}]"
    question = f"{text}{suffix_default}{prompt_suffix}"
    while True:
        echo(question, nl=False, err=err)
        try:
            answer = _read_line(hide_input)
        except EOFError:
            echo(err=err)
            raise Abort() from None
        _echo_typed(answer, hide_input)
        if answer == "":
            if default is not None:
                return default, False
            continue
        if value_proc is None:
            value = answer
        else:
            try:
                value = value_proc(answer)
            except BadParameter as exc:
                echo(f"Error: {exc.format_message()}", err=True)
                continue
        if confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, nl=False, err=err)
            try:
                second = _read_line(hide_input)
            except EOFError:
                echo(err=err)
                raise Abort() from None
            _echo_typed(second, hide_input)
            if second != answer:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return value, True


# spec: N-000488, N-000489, N-000490, N-000491, N-001009, N-001010
# spec: N-000993
def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Callable[[str], t.Any] | None = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    **_: t.Any,
) -> t.Any:
    """Ask the user for a value, converted with ``type`` when given."""
    from .parameter_types import convert_type

    if value_proc is None and type is not None:
        ptype = convert_type(type, default)
        value_proc = lambda s: ptype(s, None, get_current_context(silent=True))  # noqa: E731
    value, answered = prompt_loop(
        text,
        default=default,
        hide_input=hide_input,
        confirmation_prompt=confirmation_prompt,
        value_proc=value_proc,
        prompt_suffix=prompt_suffix,
        show_default=show_default,
        err=err,
    )
    if not answered and value_proc is not None:
        return value_proc(str(value)) if isinstance(value, str) else value
    return value


# spec: N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507, N-000508, N-000509
# spec: N-000994
def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. Empty answers take ``default``; end of input aborts."""
    hint = "[Y/n]" if default else "[y/N]"
    question = f"{text} {hint}{prompt_suffix}" if show_default else f"{text}{prompt_suffix}"
    while True:
        echo(question, nl=False, err=err)
        try:
            answer = _read_line(False)
        except EOFError:
            echo(err=err)
            raise Abort() from None
        _echo_typed(answer, False)
        value = answer.strip().lower()
        if value == "":
            result = default
            break
        if value in ("y", "yes"):
            result = True
            break
        if value in ("n", "no"):
            result = False
            break
    if abort and not result:
        raise Abort()
    return result


# ---------------------------------------------------------------- characters

# spec: N-000659, N-000660
def _getchar_raw() -> str:
    try:
        tty = open("/dev/tty", "rb+", buffering=0)
    except OSError:
        tty = None
    if tty is None:
        return sys.stdin.read(1)
    try:
        import termios
        import tty as ttymod

        fd = tty.fileno()
        old = termios.tcgetattr(fd)
        try:
            ttymod.setraw(fd)
            data = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return data.decode("utf-8", "replace")
    except (ImportError, OSError, ValueError):  # pragma: no cover - no usable tty
        return ""
    finally:
        tty.close()


# spec: N-000658, N-000659, N-000660, N-000661
# spec: N-000995
def getchar(echo: bool = False) -> str:
    """Read one character from the controlling terminal.

    Ctrl-C raises :class:`KeyboardInterrupt`; Ctrl-D (or end of input) raises
    :class:`EOFError`.
    """
    ch = _getchar_raw()
    if echo and ch:
        globals()["echo"](ch, nl=False)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", ""):
        raise EOFError()
    return ch


# spec: N-000662, N-000663, N-000686, N-000687
# spec: N-000996
def pause(info: str | None = None, err: bool = False) -> None:
    """Print ``info`` and, when interactive, wait for one key press."""
    if info is None:
        info = "Press any key to continue..."
    if is_interactive():
        echo(info, nl=False, err=err)
        try:
            getchar()
        except EOFError:
            pass
        echo(err=err)
    else:
        echo(info, err=err)


# spec: N-000672, N-000673
# spec: N-001002
def clear() -> None:
    """Clear the terminal screen; does nothing when stdout is not a terminal."""
    if not _isatty(sys.stdout):
        return
    sys.stdout.write("\x1b[2J\x1b[1;1H")
    sys.stdout.flush()


# ---------------------------------------------------------------- pager

# spec: N-001010, N-001011
def _pager_command() -> str | None:
    cmd = os.environ.get("PAGER")
    return cmd or None


def _strip_for_pager(color: bool | None) -> bool:
    return color is False


@contextlib.contextmanager
# spec: N-000641, N-000642, N-000646, N-000647, N-000648
# spec: N-000988
def get_pager_file(color: bool | None = None) -> t.Iterator[t.Any]:
    """Yield a writable text stream that goes through the pager when interactive."""
    pager = _pager_command()
    if is_interactive() and pager and _isatty(sys.stdout):
        proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE, text=True)
        try:
            stream = _PagerStream(proc.stdin, strip=_strip_for_pager(color))
            yield stream
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            proc.wait()
    else:
        yield sys.stdout


class _PagerStream:
    def __init__(self, inner: t.Any, strip: bool) -> None:
        self._inner = inner
        self._strip = strip

    def write(self, text: str) -> int:
        if self._strip:
            text = unstyle(text)
        self._inner.write(text)
        self._inner.flush()
        return len(text)

    def flush(self) -> None:
        self._inner.flush()


# spec: N-000641, N-000642, N-000643, N-000644, N-000645, N-000646, N-000647, N-000648
# spec: N-000987
def echo_via_pager(text_or_generator: t.Any, color: bool | None = None) -> None:
    """Write text through the pager when interactive, otherwise to stdout."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    pager = _pager_command()
    if is_interactive() and pager and _isatty(sys.stdout):
        proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE, text=True)
        try:
            for chunk in chunks:
                text = str(chunk)
                if color is False:
                    text = unstyle(text)
                proc.stdin.write(text)
                proc.stdin.flush()
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            proc.wait()
        return
    for chunk in chunks:
        echo(chunk, nl=False, color=color)


# ---------------------------------------------------------------- progress

class ProgressBar:
    """Iterates an iterable while showing progress on a terminal."""

    def __init__(
        self,
        iterable: t.Any = None,
        length: int | None = None,
        label: str | None = None,
        hidden: bool = False,
        width: int = 36,
        **options: t.Any,
    ) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.options = options
        self.started = time.monotonic()
        self._tty = (not hidden) and _isatty(sys.stdout)

    def __enter__(self) -> ProgressBar:
        self.started = time.monotonic()
        if not self.hidden and not self._tty and self.label:
            echo(self.label)
        return self

    def __exit__(self, *exc: t.Any) -> None:
        if self._tty:
            self._render()
            sys.stdout.write("\n")
            sys.stdout.flush()

    def __iter__(self) -> t.Iterator[t.Any]:
        if self.iterable is None:
            return
        if self._tty:
            self._render()
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int) -> None:
        self.pos += n_steps
        if self._tty:
            self._render()

    def _eta(self) -> str:
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.monotonic() - self.started
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining)}s"

    def _render(self) -> None:
        if self.length:
            filled = int(self.width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (self.width - filled)
            count = f"{self.pos}/{self.length}"
        else:
            bar = "#" * self.width
            count = str(self.pos)
        sys.stdout.write(f"\r{self.label} [{bar}] {count}{self._eta()}")
        sys.stdout.flush()


# spec: N-000649, N-000650, N-000651, N-000652, N-000653, N-000654, N-000655, N-000656, N-000657
# spec: N-000989, N-000990, N-000991, N-000992
def progressbar(
    iterable: t.Any = None,
    length: int | None = None,
    label: str | None = None,
    hidden: bool = False,
    **options: t.Any,
) -> ProgressBar:
    """Return a progress bar (a context manager that is also iterable)."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- editor / launch

# spec: N-000664, N-000665, N-000666
# spec: N-000997, N-000998, N-000999
def edit(
    text: str | None = None,
    editor: str | None = None,
    env: t.Mapping[str, str] | None = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Any = None,
) -> str | None:
    """Open an editor. Returns the saved text, or None (always None with filename)."""
    if editor is None:
        editor = (
            os.environ.get("VISUAL")
            or os.environ.get("EDITOR")
            or ("notepad" if sys.platform.startswith("win") else "vi")
        )
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    argv = shlex.split(editor) if not sys.platform.startswith("win") else [editor]
    if filename is not None:
        subprocess.call([*argv, os.fspath(filename)], env=run_env)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(original)
        subprocess.call([*argv, path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


# spec: N-000667, N-000668, N-000669, N-000670, N-000671
# spec: N-001000, N-001001
def launch(url: t.Any, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` (or a path) with the default application. Returns a status."""
    target = os.fspath(url) if not isinstance(url, str) else url
    if sys.platform.startswith("win"):
        try:
            os.startfile(target)  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    if sys.platform == "darwin":
        argv = ["open", "-R", target] if locate else ["open", target]
    else:
        opener = shutil.which("xdg-open")
        if opener is None:
            return 127
        argv = [opener, target]
    try:
        if wait:
            return subprocess.call(argv)
        subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    return 0


__all__ = [
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "is_interactive",
]
