"""Shell completion: registration scripts and suggestion output.

Completion mode is selected by the environment variable ``_<PROG>_COMPLETE``
(program name upper-cased, ``-`` replaced by ``_``). Its value is
``<shell>_source`` (print the registration script) or ``<shell>_complete``
(print suggestions for the incomplete word).

Suggestion output: one entry per line, ``plain,<value>`` for an ordinary
value, ``file,<token>`` or ``dir,<token>`` for a request that the shell
complete paths. For ``zsh`` and ``fish`` a plain entry may carry its help text
after a tab character.
"""

from __future__ import annotations

import os
import sys
import typing as t

from .core import Argument, Command, Context, Group, Option
from .parameter_types import FileParamType, PathParamType
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion with an optional help string and a kind (``plain`` by default)."""

    def __init__(self, value: str, help: str | None = None, type: str = "plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


# spec: N-001013, N-001014
def complete_var_name(prog_name: str) -> str:
    # spec: N-001013, N-001014
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


# spec: N-000692, N-000693, N-000714, N-000715, N-001021, N-001022
def maybe_handle_completion(
    root: Command,
    prog_name: str,
    args: list[str],
    complete_var: str | None = None,
) -> None:
    """If the completion variable is set, print the script or suggestions and exit."""
    name = complete_var or complete_var_name(prog_name)
    value = os.environ.get(name)
    if not value:
        return
    shell, _, action = value.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        echo(f"Error: unrecognized completion instruction {value!r}.", file=sys.stderr)
        sys.exit(2)
    if action == "source":
        echo(registration_script(shell, prog_name, name))
        sys.exit(0)
    print_completions(root, prog_name, shell)
    sys.exit(0)


# spec: N-001015, N-001022, N-000701, N-000702, N-000689, N-000690, N-000691
def registration_script(shell: str, prog_name: str, var_name: str) -> str:
    """Return the script a user sources to register completion for ``prog_name``."""
    ident = prog_name.replace("-", "_")
    if shell == "bash":
        return f"""_{ident}_completion() {{
    local words="${{COMP_WORDS[*]}}"
    local IFS=$'\\n'
    local line
    COMPREPLY=()
    for line in $(env COMP_WORDS="$words" COMP_CWORD=$COMP_CWORD {var_name}=bash_complete {prog_name}); do
        case "$line" in
            plain,*) COMPREPLY+=("${{line#plain,}}") ;;
        esac
    done
    return 0
}}
complete -o default -F _{ident}_completion {prog_name}"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
_{ident}_completion() {{
    local -a completions
    local line
    while IFS= read -r line; do
        case "$line" in
            plain,*) completions+=("${{line#plain,}}") ;;
        esac
    done < <(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var_name}=zsh_complete {prog_name})
    compadd -- "${{completions[@]}}"
}}
compdef _{ident}_completion {prog_name}"""
    if shell == "fish":
        return (
            f"complete --no-files --command {prog_name} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var_name}=fish_complete {prog_name} | string match -r \"^plain,.*\" | string replace -r \"^plain,\" \"\")'"
        )
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $commandAst.CommandElements.Count
    $env:{var_name} = 'powershell_complete'
    & '{prog_name}' | ForEach-Object {{
        if ($_ -like 'plain,*') {{
            $v = $_.Substring(6)
            [System.Management.Automation.CompletionResult]::new($v, $v, 'ParameterValue', $v)
        }}
    }}
    Remove-Item Env:{var_name} -ErrorAction SilentlyContinue
}}"""


# spec: N-001023, N-001024, N-001025, N-001026, N-001027, N-001028, N-001029, N-001030, N-000703, N-000704, N-000705
def print_completions(root: Command, prog_name: str, shell: str) -> None:
    """Write suggestions for the words in the completion environment."""
    items = completions_for_environment(root, prog_name, shell)
    for item in items:
        if item.type == "plain":
            line = f"plain,{item.value}"
            if shell in ("zsh", "fish") and item.help:
                line += "\t" + item.help
        else:
            line = f"{item.type},{item.value}"
        echo(line)


# spec: N-001016, N-001017, N-001018, N-001019, N-001020
def completions_for_environment(root: Command, prog_name: str, shell: str) -> list[CompletionItem]:
    words_env = os.environ.get("COMP_WORDS", "")
    cword_env = os.environ.get("COMP_CWORD", "")
    words = words_env.split(" ") if words_env else [prog_name]
    if shell == "fish":
        incomplete = cword_env
        if len(words) > 1 and words[-1] == incomplete:
            args = words[1:-1]
        else:
            args = words[1:]
    else:
        try:
            cword = int(cword_env)
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        args = words[1:cword]
    return suggest(root, prog_name, args, incomplete)


def _visible_options(cmd: Command, ctx: Context) -> list[Option]:
    return [p for p in cmd.get_params(ctx) if isinstance(p, Option) and not p.hidden]


def _option_takes_value(opt: Option) -> bool:
    return not (opt.is_flag or opt.count) and not opt.flag_needs_value


def _find_option(cmd: Command, ctx: Context, token: str) -> Option | None:
    for opt in _visible_options(cmd, ctx) + [p for p in cmd.get_params(ctx) if isinstance(p, Option) and p.hidden]:
        if token in opt.opts or token in opt.secondary_opts:
            return opt
    return None


# spec: N-000696, N-000699, N-001029, N-001030
def _path_items(param: t.Any, incomplete: str) -> list[CompletionItem]:
    if isinstance(param.type, FileParamType):
        return [CompletionItem(incomplete, type="file")]
    if isinstance(param.type, PathParamType):
        kind = "dir" if (param.type.dir_okay and not param.type.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]
    return []


# spec: N-000706, N-000707, N-000708, N-000709, N-000710, N-000711, N-001031, N-001032, N-001033, N-001034, N-001035, N-001036, N-001037
def _param_items(ctx: Context, param: t.Any, incomplete: str) -> list[CompletionItem]:
    if param.shell_complete is None and isinstance(param.type, (FileParamType, PathParamType)):
        return _path_items(param, incomplete)
    raw = param.shell_complete_items(ctx, incomplete)
    out: list[CompletionItem] = []
    for entry in raw:
        if isinstance(entry, CompletionItem):
            out.append(entry)
        elif isinstance(entry, str):
            out.append(CompletionItem(entry))
        else:
            out.append(
                CompletionItem(
                    str(entry.value),
                    help=getattr(entry, "help", None),
                    type=getattr(entry, "type", "plain") or "plain",
                )
            )
    return out


# spec: N-000694, N-000695, N-000696, N-000697, N-000698, N-000699, N-000700, N-000712, N-000713
def suggest(root: Command, prog_name: str, args: list[str], incomplete: str) -> list[CompletionItem]:
    """Work out the suggestions for ``incomplete`` after the words in ``args``."""
    ctx = Context(root, info_name=prog_name)
    cmd: Command = root
    cctx = ctx
    pending: Option | None = None
    positionals: list[str] = []
    i = 0
    while i < len(args):
        token = args[i]
        i += 1
        if token == "--":
            positionals.extend(args[i:])
            break
        if pending is not None:
            pending = None
            continue
        if token.startswith("-") and len(token) > 1:
            opt = _find_option(cmd, cctx, token)
            if opt is not None and _option_takes_value(opt) and "=" not in token:
                if i < len(args):
                    i += opt.nargs
                else:
                    pending = opt
            continue
        if isinstance(cmd, Group):
            sub = cmd.get_command(cctx, token)
            if sub is not None:
                cmd = sub
                cctx = Context(sub, info_name=token, parent=cctx)
                positionals = []
                continue
        positionals.append(token)

    if pending is not None and not incomplete.startswith("-"):
        return _param_items(cctx, pending, incomplete)

    if incomplete.startswith("-"):
        items: list[CompletionItem] = []
        for param in cmd.get_params(cctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=param.help))
        return items

    if isinstance(cmd, Group) and not positionals:
        items = []
        for name in cmd.list_commands(cctx):
            sub = cmd.get_command(cctx, name)
            if sub is None or sub.hidden:
                continue
            if name.startswith(incomplete):
                items.append(CompletionItem(name, help=sub.get_short_help_str() or None))
        return items

    arguments = [p for p in cmd.get_params(cctx) if isinstance(p, Argument) and not p.hidden]
    index = len(positionals)
    if index < len(arguments):
        return _param_items(cctx, arguments[index], incomplete)
    return []
