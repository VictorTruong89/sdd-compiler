"""In-process runner: invoke a command with tokens and capture its output."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t

from .core import Command


class _Sink(io.BytesIO):
    """Binary capture buffer that also records each write in a shared log."""

    def __init__(self, name: str, log: list[tuple[str, bytes]]) -> None:
        super().__init__()
        self._name = name
        self._log = log

    def write(self, data: t.Any) -> int:  # type: ignore[override]
        raw = bytes(data)
        self._log.append((self._name, raw))
        return super().write(raw)


class _TextSink(io.TextIOBase):
    """Text view over a binary sink, encoding with the runner charset."""

    def __init__(self, buffer: _Sink, charset: str) -> None:
        super().__init__()
        self._buffer = buffer
        self._charset = charset

    @property
    def encoding(self) -> str:  # type: ignore[override]
        return self._charset

    @property
    def errors(self) -> str:  # type: ignore[override]
        return "replace"

    @property
    def buffer(self) -> _Sink:  # type: ignore[override]
        return self._buffer

    def write(self, text: str) -> int:  # type: ignore[override]
        self._buffer.write(text.encode(self.encoding, "replace"))
        return len(text)

    def flush(self) -> None:
        return None

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")

    def writable(self) -> bool:
        return True


class _RunnerInput(io.TextIOBase):
    """Standard input for an invocation. Reads are echoed when ``echo_stdin`` is set."""

    runner_input = True

    def __init__(self, data: bytes, charset: str, echo_stdin: bool, out: _TextSink) -> None:
        super().__init__()
        self._buf = io.BytesIO(data)
        self._charset = charset
        self.echo_stdin = echo_stdin
        self._out = out

    @property
    def encoding(self) -> str:  # type: ignore[override]
        return self._charset

    @property
    def buffer(self) -> io.BytesIO:  # type: ignore[override]
        return self._buf

    def readline(self, size: int = -1) -> str:  # type: ignore[override]
        text = self._buf.readline(size).decode(self._charset, "replace")
        if self.echo_stdin and text:
            self._out.write(text)
        return text

    def _readline_hidden(self) -> str:
        return self._buf.readline().decode(self._charset, "replace")

    def read(self, size: int = -1) -> str:  # type: ignore[override]
        text = self._buf.read(size).decode(self._charset, "replace")
        if self.echo_stdin and text:
            self._out.write(text)
        return text

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")

    def readable(self) -> bool:
        return True


# spec: N-001039, N-001040, N-001041, N-001042
class Result:
    """What :meth:`CliRunner.invoke` returns."""

    def __init__(
        self,
        runner: CliRunner,
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        combined: bytes,
        return_value: t.Any,
        exit_code: int,
        exception: BaseException | None,
    ) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self._combined = combined
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    @property
    def output(self) -> str:
        return self._combined.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code!r}>"


# spec: N-000736, N-000737, N-000738, N-001038, N-001043
class CliRunner:
    """Invokes a command in-process and captures standard output and error."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Mapping[str, str | None] | None = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: Command) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    # spec: N-000748, N-000749, N-000750, N-000751, N-000752, N-000753, N-000754, N-000755, N-000756, N-000757
    def isolation(
        self,
        input: t.Any = None,
        env: t.Mapping[str, str | None] | None = None,
        color: bool = False,
    ) -> t.Iterator[tuple[io.BytesIO, io.BytesIO, io.BytesIO]]:
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        log: list[tuple[str, bytes]] = []
        fd_mode = self.capture == "fd"
        if fd_mode:
            # Descriptor capture: fds 1 and 2 point at temporary files, and the
            # interpreter streams wrap those same files.
            out_file = tempfile.TemporaryFile()
            err_file = tempfile.TemporaryFile()
            sys.stdout.flush()
            sys.stderr.flush()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            out_text: t.Any = io.TextIOWrapper(out_file, encoding=self.charset, errors="replace", write_through=True)
            err_text: t.Any = io.TextIOWrapper(err_file, encoding=self.charset, errors="replace", write_through=True)
            out_sink: t.Any = None
            err_sink: t.Any = None
        else:
            out_sink = _Sink("stdout", log)
            err_sink = _Sink("stderr", log)
            out_text = _TextSink(out_sink, self.charset)
            err_text = _TextSink(err_sink, self.charset)
        stdin = _RunnerInput(data, self.charset, self.echo_stdin, out_text)

        merged_env = dict(self.env)
        if env:
            merged_env.update(env)
        saved_env: dict[str, str | None] = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out_text, err_text
        try:
            yield out_sink, err_sink, io.BytesIO()
        finally:
            try:
                out_text.flush()
                err_text.flush()
            except Exception:  # pragma: no cover - best effort
                pass
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old
            if fd_mode:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                out_text.detach()
                err_text.detach()
                out_file.seek(0)
                err_file.seek(0)
                log.append(("stdout", out_file.read()))
                log.append(("stderr", err_file.read()))
                out_file.close()
                err_file.close()
            self._log = log

    @contextlib.contextmanager
    # spec: N-000744, N-000745, N-000746, N-000747, N-000762, N-000763, N-001044
    def isolated_filesystem(self, temp_dir: str | os.PathLike[str] | None = None) -> t.Iterator[str]:
        """Change into a new empty directory for the duration of the block."""
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)

    # spec: N-000739, N-000740, N-000741, N-000742, N-000743, N-000758, N-000759, N-000760, N-000761, N-001039, N-001040, N-001041, N-001042, N-001043, N-001038
    def invoke(
        self,
        cli: Command,
        args: t.Sequence[str] | str | None = None,
        input: t.Any = None,
        env: t.Mapping[str, str | None] | None = None,
        catch_exceptions: bool | None = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        """Run ``cli`` with ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            arg_list: list[str] = []
        elif isinstance(args, str):
            import shlex

            arg_list = shlex.split(args)
        else:
            arg_list = list(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        extra["color"] = color

        exception: BaseException | None = None
        exit_code = 0
        return_value: t.Any = None
        with self.isolation(input=input, env=env, color=color) as (out_sink, err_sink, _):
            try:
                return_value = cli.main(
                    args=arg_list,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if isinstance(return_value, int) and not standalone:
                    exit_code = return_value
            except SystemExit as exc:
                if exc.code is None:
                    exit_code = 0
                elif isinstance(exc.code, int):
                    exit_code = exc.code
                else:
                    sys.stdout.write(str(exc.code) + "\n")
                    exit_code = 1
            except Exception as exc:  # noqa: BLE001
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        log = self._log
        stdout_bytes = b"".join(data for name, data in log if name == "stdout")
        stderr_bytes = b"".join(data for name, data in log if name == "stderr")
        combined = b"".join(data for _, data in log)
        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            combined=combined,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
        )


__all__ = ["CliRunner", "Result"]
