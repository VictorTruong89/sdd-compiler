"""Exceptions used by Optlyn.

Standalone mode turns the failure classes below into process exit statuses:

* ``0``  success, intentional help or version, or an author clean stop
* ``2``  usage error (:class:`UsageError` and subclasses)
* ``1``  abort (:class:`Abort`) or another Optlyn-signalled error
         (:class:`OptlynError` subclasses that are not usage errors)
"""

from __future__ import annotations

import sys
import typing as t

if t.TYPE_CHECKING:  # pragma: no cover
    from .core import Context, Parameter


# spec: N-000811
class OptlynError(Exception):
    """Base class for errors that standalone mode reports and exits on."""

    #: exit status used when standalone mode ends the process for this error
    exit_code: int = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file: t.Any = None) -> None:
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr)


# spec: N-000812, N-000813, N-000814, N-000815, N-000816, N-000817, N-000818, N-000819, N-000820, N-000821, N-000822, N-000823, N-000824, N-000825, N-000826
class UsageError(OptlynError):
    """The command line was used incorrectly (exit status 2)."""

    exit_code = 2

    def __init__(self, message: str, ctx: Context | None = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file: t.Any = None) -> None:
        from .termui import echo

        file = file or sys.stderr
        ctx = self.ctx
        if ctx is not None:
            echo(ctx.get_usage(), file=file)
            if ctx.help_option_names:
                echo(
                    f"Try '{ctx.command_path} {ctx.help_option_names[0]}' for help.",
                    file=file,
                )
        echo(f"Error: {self.format_message()}", file=file)


def _quote_hint(hint: str) -> str:
    if hint.startswith("'") and hint.endswith("'"):
        return hint
    return f"'{hint}'"


# spec: N-000933, N-000934, N-000935
class BadParameter(UsageError):
    """A parameter value was refused (conversion failure or callback refusal)."""

    def __init__(
        self,
        message: str,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> str | None:
        if self.param_hint is not None:
            return _quote_hint(str(self.param_hint))
        if self.param is not None:
            return self.param.get_error_hint(self.ctx)
        return None

    def format_message(self) -> str:
        hint = self._hint()
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(
        self,
        message: str | None = None,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self) -> str:
        hint = self._hint()
        kind = getattr(self.param, "param_type_name", "parameter")
        if hint is None:
            return "Missing parameter."
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option-shaped token matches no declared option."""

    def __init__(self, option_name: str, message: str | None = None, ctx: Context | None = None) -> None:
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a value is missing)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class NoArgsIsHelp(UsageError):
    """No arguments were given and the command shows help instead.

    The help page has already been written to standard error when this is
    raised, so :meth:`show` prints nothing further. The exit status is the
    usage-error status.
    """

    def show(self, file: t.Any = None) -> None:  # pragma: no cover - trivial
        return None


# spec: N-000723, N-000724, N-000725, N-000734
class Abort(RuntimeError):
    """The user or the author aborted the run (exit status 1)."""


class Exit(RuntimeError):
    """Raised by :meth:`Context.exit` to stop the invocation cleanly."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


# spec: N-000582, N-000726
class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit status 1)."""

    def __init__(self, filename: t.Any, hint: str) -> None:
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.filename = filename


class DeclarationError(OptlynError, ValueError):
    """An invalid declaration was refused when it was made."""


class InvalidColorError(ValueError, TypeError):
    """A style color value is not a name, a 0-255 integer, or an RGB triple."""
