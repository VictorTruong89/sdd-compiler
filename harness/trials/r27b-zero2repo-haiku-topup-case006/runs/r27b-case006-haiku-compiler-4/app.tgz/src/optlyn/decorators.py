"""Decorators that declare commands, groups, options and arguments."""

from __future__ import annotations

import functools
import importlib.metadata as _metadata
import sys
import typing as t

from ._context import get_current_context
from .core import Argument, Command, Context, Group, Option, Parameter
from .termui import echo


def _param_memo(f: t.Any, param: Parameter) -> None:
    if isinstance(f, Command):
        f.params.append(param)
        return
    params = f.__dict__.setdefault("__optlyn_params__", [])
    params.append(param)


# spec: N-000079, N-000080, N-000081, N-000082
def _derive_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


# spec: N-000178, N-000179, N-000180, N-000181, N-000091, N-000092, N-000093, N-000094, N-000095, N-000096
def _make_command(
    f: t.Any,
    name: str | None,
    attrs: dict[str, t.Any],
    cls: type[Command],
) -> Command:
    if name is None:
        name = _derive_name(f.__name__)
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return cls(name=name, callback=f, params=params, **attrs)


# spec: N-000850, N-000851, N-000852, N-000853, N-000079, N-000080, N-000081, N-000082
def command(
    name: t.Any = None,
    cls: type[Command] | None = None,
    **attrs: t.Any,
) -> t.Any:
    """Turn a function into a :class:`Command`.

    Used as ``@command()`` or bare ``@command``.
    """
    if callable(name) and not isinstance(name, str):
        func = name
        return command(None, cls, **attrs)(func)
    command_cls = cls or Command

    def decorator(f: t.Any) -> Command:
        return _make_command(f, name, attrs, command_cls)

    return decorator


# spec: N-000862, N-000863, N-000864
def group(
    name: t.Any = None,
    cls: type[Group] | None = None,
    **attrs: t.Any,
) -> t.Any:
    """Turn a function into a :class:`Group`. Used as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        func = name
        return group(None, cls, **attrs)(func)
    group_cls = cls or Group

    def decorator(f: t.Any) -> Group:
        return _make_command(f, name, attrs, group_cls)  # type: ignore[return-value]

    return decorator


# spec: N-000881, N-000882, N-000883, N-000884, N-000909
def option(*param_decls: str, cls: type[Option] | None = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an option to a command or group function."""
    option_cls = cls or Option

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, option_cls(list(param_decls), **attrs))
        return f

    return decorator


# spec: N-000910, N-000911, N-000912
def argument(*param_decls: str, cls: type[Argument] | None = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a positional argument to a command or group function."""
    argument_cls = cls or Argument

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, argument_cls(list(param_decls), **attrs))
        return f

    return decorator


# ---------------------------------------------------------------- ready-made options

# spec: N-000924, N-000929
def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """An extra eager help flag. Its declared names print the help page and exit."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)
    return option(*decls, **kwargs)


def _help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _caller_package(depth: int = 2) -> str | None:
    try:
        module = sys._getframe(depth).f_globals.get("__name__")
    except (ValueError, AttributeError):  # pragma: no cover
        return None
    if not module:
        return None
    return module.partition(".")[0]


def _distribution_version(package_name: str) -> str | None:
    try:
        return _metadata.version(package_name)
    except _metadata.PackageNotFoundError:
        pass
    try:
        mapping = _metadata.packages_distributions()
    except Exception:  # pragma: no cover
        mapping = {}
    for dist_name in mapping.get(package_name, []):
        try:
            return _metadata.version(dist_name)
        except _metadata.PackageNotFoundError:  # pragma: no cover
            continue
    return None


# spec: N-000846, N-000847, N-000848, N-000849
def _version_callback_factory(
    get_identity: t.Callable[[Context], str],
    *,
    raw: bool,
    message: str | None,
    prog_name: str | None,
) -> t.Callable[[Context, Parameter, t.Any], None]:
    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        identity = get_identity(ctx)
        if raw:
            echo(identity, color=ctx.color)
        else:
            name = prog_name or ctx.find_root().info_name or ""
            template = message or "%(prog)s, version %(version)s"
            echo(template % {"prog": name, "version": identity}, color=ctx.color)
        ctx.exit()

    return callback


# spec: N-000925, N-000930, N-000931, N-000162, N-000163, N-000164, N-000165, N-000166, N-000167, N-000168, N-000169
def version_option(
    version: str | None = None,
    *param_decls: str,
    package_name: str | None = None,
    prog_name: str | None = None,
    message: str | None = None,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """An eager ``--version`` flag printing a version identity and exiting.

    When ``version`` is None it is detected from the installed distribution of
    ``package_name``; when that is not a distribution, the distribution that
    provides that import name is used.
    """
    decls = list(param_decls) or ["--version"]
    detected_package = package_name or _caller_package(2)

    def get_identity(ctx: Context) -> str:
        if version is not None:
            return version
        if detected_package is None:
            raise RuntimeError("Could not determine the version; pass version= or package_name=.")
        found = _distribution_version(detected_package)
        if found is None:
            raise RuntimeError(f"Could not determine the version of {detected_package!r}.")
        return found

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = _version_callback_factory(
        get_identity, raw=False, message=message, prog_name=prog_name
    )
    return option(*decls, **kwargs)


# spec: N-000932, N-000846, N-000847, N-000849
def custom_version_option(
    callback: t.Callable[[Context], str],
    *param_decls: str,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """An eager version flag whose printed identity is exactly ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]

    def get_identity(ctx: Context) -> str:
        return callback(ctx)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = _version_callback_factory(
        get_identity, raw=True, message=None, prog_name=None
    )
    return option(*decls, **kwargs)


# spec: N-000926, N-000510, N-000511, N-000512
def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """A prompting, hidden-input, confirmed option (default name ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def _confirmation_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value:
        ctx.abort()


# spec: N-000928, N-000513, N-000514, N-000515, N-000516, N-000517, N-000518, N-000519
def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """A confirmation flag (default ``--yes``). Declining aborts the command."""
    decls = list(param_decls) or ["--yes"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("callback", _confirmation_callback)
    return option(*decls, **kwargs)


# ---------------------------------------------------------------- pass decorators

# spec: N-000975, N-000976, N-000977
def pass_context(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current :class:`Context` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return new_func


# spec: N-000976
def pass_obj(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context's ``obj`` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


# spec: N-000977, N-000442, N-000443
def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable[[t.Any], t.Any]:
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
        @functools.wraps(f)
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing."
                )
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
]
