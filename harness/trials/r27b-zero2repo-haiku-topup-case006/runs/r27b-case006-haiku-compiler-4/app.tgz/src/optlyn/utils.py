"""File, path and application-directory helpers."""

from __future__ import annotations

import io
import os
import re
import sys
import tempfile
import typing as t

from .exceptions import FileError

# spec: N-000674, N-000675, N-000676, N-000677, N-000678
# spec: N-001003, N-001004, N-001005
def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``.

    ``roaming`` is accepted; on Windows it selects ``APPDATA`` (roaming) over
    ``LOCALAPPDATA``. On Unix the folder is the lowercased name with each run
    of whitespace replaced by one dash, under ``$XDG_CONFIG_HOME`` when that
    variable is set, otherwise under ``~/.config``.
    """
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        if roaming:
            base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        else:
            base = os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)


# spec: N-000575, N-000576, N-000577
def _escape_surrogates(text: str) -> str:
    out: list[str] = []
    for ch in text:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            out.append(f"\\x{code - 0xDC00:02x}")
        elif 0xD800 <= code <= 0xDFFF:
            out.append(f"\\u{code:04x}")
        else:
            out.append(ch)
    return "".join(out)


# spec: N-000575, N-000576, N-000577
# spec: N-001006, N-001007
def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Return ``filename`` as printable, strictly UTF-8-encodable text.

    Undecodable bytes are escaped, so different names stay different.
    """
    if isinstance(filename, (bytes, bytearray)):
        text = os.fsdecode(bytes(filename))
    else:
        path = os.fspath(filename)
        text = os.fsdecode(path) if isinstance(path, bytes) else path
    if shorten:
        text = os.path.basename(text)
    return _escape_surrogates(text)


class _NonClosing:
    """Wraps a standard stream so that closing the wrapper leaves it open."""

    def __init__(self, inner: t.Any) -> None:
        object.__setattr__(self, "_inner", inner)

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._inner, name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._inner)

    def __enter__(self) -> _NonClosing:
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        try:
            self._inner.flush()
        except Exception:
            pass


_KEEP_ALIVE: list[t.Any] = []


def _dash_stream(mode: str, encoding: str | None, errors: str | None) -> t.Any:
    writing = "w" in mode or "a" in mode
    base = sys.stdout if writing else sys.stdin
    if base is None:
        raise FileError("-", "no standard stream is available")
    if "b" in mode:
        return _NonClosing(getattr(base, "buffer", base))
    if encoding:
        buf = getattr(base, "buffer", None)
        if buf is not None:
            try:
                base.flush()
            except Exception:
                pass
            wrapper = io.TextIOWrapper(buf, encoding=encoding, errors=errors or "strict")
            # Keep a reference so the wrapper is never garbage collected while
            # attached, which would close the underlying stream.
            _KEEP_ALIVE.append(wrapper)
            return _NonClosing(wrapper)
    return _NonClosing(base)


class AtomicFile:
    """Writes to a sibling temporary file that replaces the target on close."""

    def __init__(self, filename: str, mode: str, encoding: str | None, errors: str | None) -> None:
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp_name = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        binary = "b" in mode
        self._file = open(
            self._tmp_name,
            "wb" if binary else "w",
            encoding=None if binary else encoding,
            errors=None if binary else errors,
        )
        self._closed = False

    @property
    def name(self) -> str:
        return self._target

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._file, name)

    def __enter__(self) -> AtomicFile:
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp_name, self._target)


class LazyFile:
    """A file that is opened on first I/O rather than when created."""

    def __init__(self, filename: str, mode: str, encoding: str | None, errors: str | None, atomic: bool) -> None:
        self.name = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._file: t.Any = None
        self._closed = False

    def _open(self) -> t.Any:
        if self._file is None:
            try:
                self._file = _open_real(self.name, self._mode, self._encoding, self._errors, self._atomic)
            except OSError as exc:
                raise FileError(self.name, exc.strerror or str(exc)) from exc
        return self._file

    def __getattr__(self, name: str) -> t.Any:
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._open())

    def __enter__(self) -> LazyFile:
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._file is not None and not self._closed:
            self._closed = True
            self._file.close()


def _open_real(filename: str, mode: str, encoding: str | None, errors: str | None, atomic: bool) -> t.Any:
    binary = "b" in mode
    if atomic and ("w" in mode or "a" in mode):
        return AtomicFile(filename, mode, encoding, errors)
    if binary:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


# spec: N-000532, N-000533, N-000534, N-000535, N-000536, N-000537
# spec: N-001008, N-000772, N-000528, N-000529, N-000530, N-000531
def open_file(
    filename: t.Any,
    mode: str = "r",
    encoding: str | None = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open ``filename``; ``-`` is standard input (reading) or output (writing).

    Opens immediately unless ``lazy`` is true. Dash streams are never closed.
    """
    if isinstance(filename, (bytes, bytearray)):
        filename = os.fsdecode(bytes(filename))
    else:
        filename = os.fspath(filename)
    if filename == "-":
        return _dash_stream(mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)
