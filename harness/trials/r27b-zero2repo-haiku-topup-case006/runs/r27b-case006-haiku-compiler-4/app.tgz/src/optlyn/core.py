"""Parameters, the argument parser, invocation contexts and commands."""

from __future__ import annotations

import enum
import inspect
import os
import shutil
import sys
import typing as t
from contextlib import ExitStack, contextmanager

from ._context import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import make_default_short_help, wrap_text, write_dl
from .parameter_types import (
    BOOL,
    INT,
    UNPROCESSED,
    ParamType,
    TupleParamType,
    convert_type,
)
from .termui import confirm, echo, prompt_loop

# Characters that start an option name. ``-`` is the usual prefix; ``/`` and
# ``+`` are accepted when an option declares them.
_PREFIX_CHARS = frozenset("-/+")


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Most explicit first: prompt, command line, environment, default map, default.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


class _Marker:
    def __init__(self, label: str) -> None:
        self.label = label

    def __repr__(self) -> str:
        return f"<{self.label}>"


# Occurrence placed by the parser for a value option given without a value.
_PROMPT_MARK = _Marker("prompt-needed")
# Value of ``Context.invoked_subcommand`` on a chaining group.
_CHAIN_SUBCOMMAND = _Marker("chain")

_TRUE_TEXT = {"true", "1", "yes", "on", "t", "y"}
_FALSE_TEXT = {"false", "0", "no", "off", "f", "n"}


# spec: N-000881, N-000882, N-000883, N-000194, N-000195
def _split_decls(decls: t.Sequence[str]) -> tuple[list[str], list[str], str | None]:
    """Split declarations into primary names, on/off names and an explicit name."""
    primary: list[str] = []
    secondary: list[str] = []
    explicit: str | None = None
    for decl in decls:
        if not decl:
            continue
        if decl[0] in _PREFIX_CHARS:
            if decl[0] != "/" and "/" in decl:
                first, second = decl.split("/", 1)
                primary.append(first)
                secondary.append(second)
            else:
                primary.append(decl)
        else:
            if explicit is not None:
                raise DeclarationError(f"more than one destination name given: {explicit!r} and {decl!r}")
            explicit = decl
    return primary, secondary, explicit


def _is_long_name(name: str) -> bool:
    return len(name) >= 3 and name[1] in _PREFIX_CHARS


# spec: N-000194, N-000195
def _infer_dest(primary: list[str]) -> str:
    for name in primary:
        if _is_long_name(name):
            return name.lstrip("".join(_PREFIX_CHARS)).replace("-", "_")
    for name in primary:
        return name.lstrip("".join(_PREFIX_CHARS)).replace("-", "_")
    raise DeclarationError("could not derive a destination name")


# spec: N-000015, N-000016, N-000017, N-000018, N-000019, N-000020, N-000021, N-000022, N-000023, N-000024, N-000921, N-000922, N-000923
class Parameter:
    """Common behaviour of options and arguments."""

    param_type_name = "parameter"
    # Defaults for the option-only features; Option overrides them.
    is_flag = False
    count = False
    prompt: str | None = None
    prompt_required = True
    hide_input = False
    confirmation_prompt = False
    hidden = False
    help: str | None = None

    def __init__(
        self,
        name: str,
        opts: list[str],
        secondary_opts: list[str],
        *,
        type: ParamType,
        default: t.Any = None,
        required: bool = False,
        nargs: int = 1,
        multiple: bool = False,
        metavar: str | None = None,
        callback: t.Callable[..., t.Any] | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: list[str] | None = None,
        shell_complete: t.Callable[..., t.Any] | None = None,
        deprecated: bool | str = False,
        auto_default: bool = False,
    ) -> None:
        self.name = name
        self.opts = opts
        self.secondary_opts = secondary_opts
        self.type = type
        self.default = default
        self.required = required
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.auto_default = auto_default
        self._decl_index = 0

    # ------------------------------------------------------------ introspection

    def get_error_hint(self, ctx: Context | None) -> str:
        return f"'{self.name.upper()}'"

    # spec: N-000139, N-000140, N-000141, N-000142, N-000143, N-000144
    def make_metavar(self) -> str:
        return (self.metavar or self.name).upper()

    def get_default(self, ctx: Context | None, call: bool = True) -> t.Any:
        if callable(self.default) and call:
            return self.default()
        return self.default

    def value_is_missing(self, value: t.Any) -> bool:
        if value is None:
            return True
        if (self.multiple or self.nargs == -1) and not value:
            return True
        return False

    @property
    def is_variadic(self) -> bool:
        return self.nargs == -1

    # spec: N-000444, N-000445, N-000446, N-000447, N-000448, N-000449, N-000481, N-000309, N-000310
    def _envvar_names(self, ctx: Context) -> list[str]:
        return list(self.envvar or [])

    # ------------------------------------------------------------ value shapes

    # spec: N-000209, N-000210, N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218, N-000219, N-000220
    def _shape_tokens(self, tokens: list[str]) -> t.Any:
        if self.nargs == -1:
            return tuple(tokens)
        if self.multiple:
            if self.nargs == 1:
                return list(tokens)
            n = self.nargs
            return [tuple(tokens[k : k + n]) for k in range(0, len(tokens), n)]
        if self.nargs > 1:
            return tuple(tokens)
        return tokens[0] if tokens else None

    def _shape_default(self, value: t.Any, source: ParameterSource) -> t.Any:
        if isinstance(value, str) and (self.nargs != 1 or self.nargs == -1):
            return self._shape_tokens(self.type.split_envvar_value(value))
        return value

    def _convert_one(self, ctx: Context | None, value: t.Any) -> t.Any:
        try:
            return self.type(value, self, ctx)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = self
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    # spec: N-000215, N-000216, N-000217, N-000218, N-000219, N-000220, N-000366, N-000301, N-000302
    def _convert_occurrence(self, ctx: Context | None, value: t.Any) -> t.Any:
        if self.nargs == -1:
            seq = value if isinstance(value, (tuple, list)) else (value,)
            return tuple(self._convert_one(ctx, v) for v in seq)
        if self.nargs > 1 or isinstance(self.type, TupleParamType):
            if isinstance(self.type, TupleParamType):
                try:
                    return self.type(value, self, ctx)
                except BadParameter as exc:
                    if exc.param is None:
                        exc.param = self
                    if exc.ctx is None:
                        exc.ctx = ctx
                    raise
            if isinstance(value, (str, bytes)) or not isinstance(value, (tuple, list)):
                raise BadParameter(f"expected {self.nargs} values.", ctx=ctx, param=self)
            if len(value) != self.nargs:
                raise BadParameter(f"expected {self.nargs} values, got {len(value)}.", ctx=ctx, param=self)
            return tuple(self._convert_one(ctx, v) for v in value)
        return self._convert_one(ctx, value)

    # spec: N-000913, N-000914, N-000915, N-000916, N-000917, N-000918, N-000919, N-000920
    def type_cast_value(self, ctx: Context | None, value: t.Any) -> t.Any:
        """Convert a raw value (any source) to the value the callback receives."""
        if value is None:
            return None
        if self.multiple:
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    "needs an iterable (sequence) default; a single string is not accepted.",
                    ctx=ctx,
                    param=self,
                )
            return tuple(self._convert_occurrence(ctx, v) for v in value)
        return self._convert_occurrence(ctx, value)

    # ------------------------------------------------------------ sources

    # spec: N-000227, N-000228, N-000229, N-000230, N-000231, N-000232, N-000233, N-000309, N-000310, N-000311, N-000312, N-000313, N-000314, N-000315, N-000316, N-000317, N-000574
    def _env_value(self, ctx: Context) -> t.Any:
        for name in self._envvar_names(ctx):
            raw = os.environ.get(name)
            if not raw:
                continue
            if self.is_flag:  # type: ignore[attr-defined]
                flag = self._flag_from_env(raw, name)  # type: ignore[attr-defined]
                if flag is None:
                    continue
                return flag
            if self.nargs == 1 and not self.multiple:
                return raw
            return self._shape_tokens(self.type.split_envvar_value(raw))
        return None

    # spec: N-000450, N-000451, N-000452, N-000453, N-000454, N-000455, N-000456, N-000457, N-000458, N-000459, N-000460, N-000461, N-000462, N-000182, N-000183, N-000184, N-000185, N-000186, N-000187
    def _default_candidate(self, ctx: Context) -> tuple[ParameterSource, t.Any]:
        mapped = ctx.lookup_default(self.name)
        if mapped is not None:
            return ParameterSource.DEFAULT_MAP, self._shape_default(mapped, ParameterSource.DEFAULT_MAP)
        declared = self.get_default(ctx)
        if declared is not None:
            return ParameterSource.DEFAULT, self._shape_default(declared, ParameterSource.DEFAULT)
        return ParameterSource.DEFAULT, None

    def _prompt_text(self) -> str:
        return self.name.replace("_", " ").capitalize()

    # spec: N-000488, N-000489, N-000490, N-000491, N-000492, N-000493, N-000494, N-000495, N-000496, N-000497, N-000498, N-000499, N-000500, N-000510, N-000511, N-000512, N-000520, N-000521, N-000522
    def _prompt(self, ctx: Context, shown: t.Any) -> tuple[bool, t.Any]:
        """Ask the user. Returns ``(answered, converted_value_or_default)``."""
        text = self.prompt or self._prompt_text()
        if self.is_flag:  # type: ignore[attr-defined]
            answer = confirm(text, default=bool(shown) if shown is not None else False)
            return True, answer

        def proc(raw_text: str) -> t.Any:
            tokens = self.type.split_envvar_value(raw_text) if (self.nargs != 1) else [raw_text]
            if self.nargs == 1:
                occurrence: t.Any = raw_text
            else:
                occurrence = tuple(tokens)
            converted = self._convert_occurrence(ctx, occurrence)
            return (converted,) if self.multiple else converted

        display = None
        if shown is not None:
            display = ", ".join(str(x) for x in shown) if isinstance(shown, (list, tuple)) else str(shown)
        value, answered = prompt_loop(
            text,
            default=shown,
            hide_input=self.hide_input,  # type: ignore[attr-defined]
            confirmation_prompt=self.confirmation_prompt,  # type: ignore[attr-defined]
            value_proc=proc,
            default_display=display,
        )
        if answered:
            return True, value
        return False, shown

    # spec: N-000243, N-000244, N-000245, N-000246, N-000247, N-000248, N-000249, N-000463, N-000464, N-000465, N-000466, N-000266, N-000267, N-000092, N-000093
    # spec: N-000766, N-000767, N-000768
    def consume_value(self, ctx: Context, parsed: dict[Parameter, list[t.Any]]) -> tuple[t.Any, ParameterSource, bool]:
        """Work out the raw value and its source, in precedence order."""
        occurrences = parsed.get(self)
        value: t.Any = None
        source: ParameterSource | None = None
        prompt_now = False
        if occurrences:
            if any(o is _PROMPT_MARK for o in occurrences):
                prompt_now = True
            elif getattr(self, "count", False):
                value = sum(occurrences)
                source = ParameterSource.COMMANDLINE
            elif self.multiple:
                value = list(occurrences)
                source = ParameterSource.COMMANDLINE
            else:
                value = occurrences[-1]
                source = ParameterSource.COMMANDLINE
        if source is None and not prompt_now:
            env_value = self._env_value(ctx)
            if env_value is not None:
                value, source = env_value, ParameterSource.ENVIRONMENT
        if source is None and self.prompt is not None and (prompt_now or self.prompt_required):  # type: ignore[attr-defined]
            shown_source, shown = self._default_candidate(ctx)
            answered, answer = self._prompt(ctx, shown)
            if answered:
                return answer, ParameterSource.PROMPT, False
            value, source = shown, shown_source
            auto = shown_source is ParameterSource.DEFAULT and self.auto_default and shown is None
            return self._fill_missing(value, source, auto)
        if source is None:
            cand_source, cand = self._default_candidate(ctx)
            auto = cand_source is ParameterSource.DEFAULT and self.auto_default and cand is not None
            value, source = cand, cand_source
            return self._fill_missing(value, source, auto)
        return value, source, False

    def _fill_missing(self, value: t.Any, source: ParameterSource, auto: bool) -> tuple[t.Any, ParameterSource, bool]:
        if value is None and (self.multiple or self.nargs == -1):
            return (), ParameterSource.DEFAULT, False
        return value, source, auto

    # ------------------------------------------------------------ processing

    def _winner_rank(self) -> tuple[int, int, int]:
        return (0, 0, self._decl_index)

    # spec: N-000250, N-000251, N-000252, N-000253, N-000254, N-000255, N-000256, N-000257, N-000258, N-000259, N-000260, N-000261, N-000262, N-000263, N-000200, N-000201, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380
    def handle_parse_result(self, ctx: Context, parsed: dict[Parameter, list[t.Any]]) -> t.Any:
        """Consume, convert, check, run the callback and store the value."""
        value, source, auto = self.consume_value(ctx, parsed)
        if source is ParameterSource.COMMANDLINE and self.deprecated and parsed.get(self):
            _warn_deprecated(self.param_type_name, self._deprecation_name(), self.deprecated)
        if source is ParameterSource.PROMPT:
            final = value
        else:
            final = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(final):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            try:
                final = self.callback(ctx, self, final)
            except BadParameter as exc:
                if exc.param is None:
                    exc.param = self
                if exc.ctx is None:
                    exc.ctx = ctx
                raise
        if self.expose_value:
            rank = (_SOURCE_RANK[source], 0 if auto else 1, self._decl_index)
            current = ctx._dest_rank.get(self.name)
            if current is None or rank >= current:
                ctx._dest_rank[self.name] = rank
                ctx.params[self.name] = final
                ctx._parameter_source[self.name] = source
        return final

    def _deprecation_name(self) -> str:
        return self.name


def _warn_deprecated(kind: str, name: str, note: t.Any) -> None:
    text = f"DeprecationWarning: The {kind} '{name}' is deprecated."
    if isinstance(note, str) and note:
        text = f"{text} {note}"
    echo(text, file=sys.stderr)


# spec: N-000523, N-000280, N-000281, N-000282, N-000202, N-000203, N-000204
class Option(Parameter):
    """A named parameter introduced by a prefix (``--name``, ``-n``, ``/n``)."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Sequence[str] | None = None,
        *,
        type: t.Any = None,
        default: t.Any = None,
        required: bool = False,
        is_flag: bool | None = None,
        flag_value: t.Any = None,
        count: bool = False,
        multiple: bool = False,
        nargs: int | None = None,
        envvar: str | t.Sequence[str] | None = None,
        allow_from_autoenv: bool = True,
        prompt: bool | str | None = None,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        callback: t.Callable[..., t.Any] | None = None,
        is_eager: bool = False,
        expose_value: bool = True,
        deprecated: bool | str = False,
        help: str | None = None,
        metavar: str | None = None,
        show_default: bool | str | None = None,
        show_envvar: bool = False,
        show_choices: bool = True,
        hidden: bool = False,
        shell_complete: t.Callable[..., t.Any] | None = None,
    ) -> None:
        primary, secondary, explicit = _split_decls(list(param_decls or []))
        if not primary and not secondary:
            raise DeclarationError("an option needs at least one flag name.")
        if explicit is not None:
            name = explicit.replace("-", "_")
        else:
            name = _infer_dest(primary)
        auto = False

        if count and multiple:
            raise DeclarationError("a counting option cannot also be repeatable.")
        if count:
            is_flag = True
            flag_value = 1
            if default is None:
                default = 0
                auto = True
        if is_flag is None:
            is_flag = bool(secondary) or flag_value is not None
        flag_needs_value = False
        if is_flag:
            if flag_value is None:
                flag_value = True
            if nargs not in (None, 1):
                raise DeclarationError("a flag takes exactly one value.")
            if multiple and not count:
                raise DeclarationError("a flag cannot be repeatable.")
            nargs = 1
            if default is None and not count:
                default = False
                auto = True
        elif flag_value is not None:
            flag_needs_value = True

        if type is None and is_flag:
            ty = BOOL if isinstance(flag_value, bool) else UNPROCESSED
            if count:
                ty = INT
        else:
            ty = convert_type(type, default)
        if isinstance(ty, TupleParamType):
            if nargs not in (None, len(ty.types)):
                raise DeclarationError("nargs does not match the Tuple type length.")
            nargs = len(ty.types)
        if nargs is None:
            nargs = 1
        if nargs < 1:
            raise DeclarationError("nargs must be a positive integer for an option.")

        if deprecated and (required or prompt):
            raise DeclarationError("a deprecated option cannot be required or prompt.")

        if envvar is None:
            env_list = None
        elif isinstance(envvar, str):
            env_list = [envvar]
        else:
            env_list = list(envvar)

        super().__init__(
            name,
            primary,
            secondary,
            type=ty,
            default=default,
            required=required,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            callback=callback,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=env_list,
            shell_complete=shell_complete,
            deprecated=deprecated,
            auto_default=auto,
        )
        self.help = help
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.flag_needs_value = flag_needs_value
        self.allow_from_autoenv = allow_from_autoenv
        if prompt is True:
            self.prompt: str | None = self._prompt_text()
        elif isinstance(prompt, str) and prompt:
            self.prompt = prompt
        else:
            self.prompt = None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.hidden = hidden

    # ------------------------------------------------------------ names

    def get_error_hint(self, ctx: Context | None) -> str:
        return "'" + " / ".join(self.opts + self.secondary_opts) + "'"

    def _deprecation_name(self) -> str:
        return " / ".join(self.opts + self.secondary_opts)

    def _envvar_names(self, ctx: Context) -> list[str]:
        names = list(self.envvar or [])
        if not names and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            names = [f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_")]
        return names

    # spec: N-000202, N-000203, N-000204, N-000205, N-000206, N-000207, N-000208
    def flag_occurrence(self, secondary: bool) -> t.Any:
        if self.count:
            return 1
        if secondary:
            return not self.flag_value
        return self.flag_value

    # spec: N-000234, N-000235, N-000236, N-000237, N-000238, N-000239, N-000240, N-000241, N-000242, N-000339, N-000340, N-000341, N-000342, N-000343, N-000344, N-000345
    def _flag_from_env(self, raw: str, name: str) -> t.Any:
        text = raw.strip().lower()
        if isinstance(self.flag_value, bool):
            if text == "":
                return False
            if text in _TRUE_TEXT:
                return True
            if text in _FALSE_TEXT:
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", param=self)
        if raw.strip() == str(self.flag_value):
            return self.flag_value
        if text in _TRUE_TEXT:
            return self.flag_value
        if text in _FALSE_TEXT:
            return False
        return None

    def make_metavar(self) -> str:
        if self.metavar:
            return self.metavar
        if self.is_flag:
            return ""
        if isinstance(self.type, TupleParamType):
            parts = [
                (ty.get_metavar(self) or ty.name.upper()) for ty in self.type.types
            ]
            return " ".join(parts)
        one = self.type.get_metavar(self) or self.type.name.upper()
        return " ".join([one] * self.nargs)

    def help_text_extras(self, ctx: Context) -> list[str]:
        extras: list[str] = []
        if self.help:
            extras.append(self.help)
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show and self.default is not None and not (self.is_flag and self.default is False):
            if isinstance(show, str):
                shown = show
            elif callable(self.default):
                shown = "(dynamic)"
            elif isinstance(self.default, (list, tuple)):
                shown = ", ".join(str(x) for x in self.default)
            else:
                shown = str(self.default)
            extras.append(f"[default: {shown}]")
        if self.required:
            extras.append("[required]")
        if self.show_envvar:
            names = self._envvar_names_for_help()
            if names:
                extras.append(f"[env var: {names[0]}]")
        if self.deprecated:
            extras.append("(DEPRECATED)")
        return extras

    def _envvar_names_for_help(self) -> list[str]:
        return list(self.envvar or [])

    def shell_complete_items(self, ctx: Context, incomplete: str) -> list[t.Any]:
        if self.shell_complete is not None:
            return list(self.shell_complete(ctx, self, incomplete))
        return list(self.type.shell_complete(ctx, self, incomplete))

    def __repr__(self) -> str:
        return f"<Option {self.name} {self.opts!r}>"


# spec: N-000285, N-000286, N-000287, N-000288, N-000289, N-000290
class Argument(Parameter):
    """A positional parameter. Arguments bind tokens in declaration order."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: t.Sequence[str] | None = None,
        *,
        type: t.Any = None,
        default: t.Any = None,
        required: bool | None = None,
        nargs: int | None = None,
        envvar: str | t.Sequence[str] | None = None,
        deprecated: bool | str = False,
        help: str | None = None,
        metavar: str | None = None,
        callback: t.Callable[..., t.Any] | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        hidden: bool = False,
        shell_complete: t.Callable[..., t.Any] | None = None,
    ) -> None:
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise DeclarationError("an argument takes exactly one destination name.")
        name = decls[0].replace("-", "_")
        ty = convert_type(type, default)
        if isinstance(ty, TupleParamType):
            if nargs not in (None, len(ty.types)):
                raise DeclarationError("nargs does not match the Tuple type length.")
            nargs = len(ty.types)
        if nargs is None:
            nargs = 1
        if nargs != -1 and nargs < 1:
            raise DeclarationError("nargs must be a positive integer or -1.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise DeclarationError("a deprecated argument cannot be required.")
        if envvar is None:
            env_list = None
        elif isinstance(envvar, str):
            env_list = [envvar]
        else:
            env_list = list(envvar)
        super().__init__(
            name,
            [name],
            [],
            type=ty,
            default=default,
            required=bool(required),
            nargs=nargs,
            multiple=False,
            metavar=metavar,
            callback=callback,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=env_list,
            shell_complete=shell_complete,
            deprecated=deprecated,
        )
        self.help = help
        self.hidden = hidden

    def get_error_hint(self, ctx: Context | None) -> str:
        return f"'{self.name.upper()}'"

    def make_metavar(self) -> str:
        return self.metavar or self.name.upper()

    # spec: N-000127, N-000128, N-000129, N-000130, N-000131, N-000132, N-000291, N-000292
    def make_usage_piece(self) -> str:
        name = self.metavar or self.name.upper()
        if self.nargs == -1:
            return f"{name}..." if self.required else f"[{name}]..."
        if self.nargs > 1:
            base = " ".join([name] * self.nargs)
            return base if self.required else f"[{base}]"
        return name if self.required else f"[{name}]"

    def shell_complete_items(self, ctx: Context, incomplete: str) -> list[t.Any]:
        if self.shell_complete is not None:
            return list(self.shell_complete(ctx, self, incomplete))
        return list(self.type.shell_complete(ctx, self, incomplete))

    def __repr__(self) -> str:
        return f"<Argument {self.name}>"


# spec: N-000283, N-000284, N-000264, N-000265, N-000803
def iter_params_for_processing(invocation_order: list[Parameter], declaration_order: list[Parameter]) -> list[Parameter]:
    """Eager parameters first, then in the order they appeared on the command line."""

    def key(item: Parameter) -> tuple[bool, int]:
        try:
            position = invocation_order.index(item)
        except ValueError:
            position = len(invocation_order)
        return (not item.is_eager, position)

    return sorted(declaration_order, key=key)


# ---------------------------------------------------------------- parser

class _Parser:
    """Splits the raw token list into option occurrences and leftover tokens."""

    def __init__(self, ctx: Context, params: list[Parameter]) -> None:
        self.ctx = ctx
        self.norm: t.Callable[[str], str] = ctx.token_normalize_func or (lambda s: s)
        self.map: dict[str, tuple[Option, bool]] = {}
        self.prefixes: set[str] = {"-"}
        for param in params:
            if isinstance(param, Option):
                for name in param.opts:
                    self._register(name, param, False)
                for name in param.secondary_opts:
                    self._register(name, param, True)
        self.interspersed = bool(ctx.allow_interspersed_args)
        self.ignore_unknown = bool(ctx.ignore_unknown_options)
        self.parsed: dict[Parameter, list[t.Any]] = {}
        self.order: list[Parameter] = []

    def _register(self, name: str, opt: Option, secondary: bool) -> None:
        self.prefixes.add(name[0])
        self.map[self.norm(name)] = (opt, secondary)

    def _is_optlike(self, token: str) -> bool:
        return len(token) > 1 and token[0] in self.prefixes

    def _add(self, opt: Option, occurrence: t.Any) -> None:
        if opt not in self.parsed:
            self.parsed[opt] = []
            self.order.append(opt)
        self.parsed[opt].append(occurrence)

    # spec: N-000196, N-000197, N-000198, N-000199, N-000304, N-000305, N-000306, N-000226
    def parse(self, args: list[str]) -> list[str]:
        largs: list[str] = []
        i = 0
        n = len(args)
        while i < n:
            token = args[i]
            if token == "--":
                largs.extend(args[i + 1 :])
                break
            if self._is_optlike(token):
                i = self._process_option(args, i, largs)
                continue
            if not self.interspersed:
                largs.extend(args[i:])
                break
            largs.append(token)
            i += 1
        return largs

    def _process_option(self, args: list[str], i: int, largs: list[str]) -> int:
        token = args[i]
        if len(token) > 2 and token[1] == token[0]:
            return self._process_long(args, i, largs)
        # A whole declared name with a non-dash prefix (for example ``/verbose``)
        # is one option; a single-dash token is always a stack of flags.
        name_part = token.split("=", 1)[0]
        if token[0] != "-" and self.norm(name_part) in self.map:
            return self._process_long(args, i, largs)
        return self._process_short(args, i, largs)

    # spec: N-000188, N-000189, N-000190, N-000268, N-000269, N-000270, N-000271, N-000272
    def _process_long(self, args: list[str], i: int, largs: list[str]) -> int:
        token = args[i]
        if "=" in token:
            name, value = token.split("=", 1)
            has_value = True
        else:
            name, value, has_value = token, None, False
        entry = self.map.get(self.norm(name))
        if entry is None:
            if self.ignore_unknown:
                largs.append(token)
                return i + 1
            raise NoSuchOption(name, ctx=self.ctx)
        opt, secondary = entry
        if opt.is_flag:
            if has_value:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
            self._add(opt, opt.flag_occurrence(secondary))
            return i + 1
        occurrence, nxt = self._take_value(opt, name, args, i + 1, value, has_value)
        self._add(opt, occurrence)
        return nxt

    # spec: N-000191, N-000192, N-000193, N-000273, N-000274
    def _process_short(self, args: list[str], i: int, largs: list[str]) -> int:
        token = args[i]
        prefix = token[0]
        body = token[1:]
        idx = i + 1
        j = 0
        while j < len(body):
            flag = prefix + body[j]
            entry = self.map.get(self.norm(flag))
            if entry is None:
                if self.ignore_unknown:
                    largs.append(prefix + body[j:])
                    return idx
                raise NoSuchOption(flag, ctx=self.ctx)
            opt, secondary = entry
            rest = body[j + 1 :]
            if opt.is_flag:
                self._add(opt, opt.flag_occurrence(secondary))
                j += 1
                continue
            if rest:
                occurrence, _ = self._take_value(opt, flag, args, idx, rest, True)
                self._add(opt, occurrence)
                return idx
            occurrence, nxt = self._take_value(opt, flag, args, idx, None, False)
            self._add(opt, occurrence)
            return nxt
        return idx

    # spec: N-000221, N-000222, N-000223, N-000224, N-000225, N-000275, N-000215, N-000216
    def _take_value(
        self,
        opt: Option,
        name: str,
        args: list[str],
        idx: int,
        inline: str | None,
        has_inline: bool,
    ) -> tuple[t.Any, int]:
        if opt.flag_needs_value:
            if has_inline:
                return inline, idx
            if idx < len(args) and not self._is_optlike(args[idx]):
                return args[idx], idx + 1
            if opt.prompt is not None:
                return _PROMPT_MARK, idx
            return opt.flag_value, idx
        nargs = opt.nargs
        if has_inline:
            if nargs == 1:
                return inline, idx
            raise BadOptionUsage(f"Option '{name}' requires {nargs} arguments.", ctx=self.ctx)
        if len(args) - idx < nargs:
            if opt.prompt is not None:
                return _PROMPT_MARK, idx
            if nargs == 1:
                raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx=self.ctx)
            raise BadOptionUsage(f"Option '{name}' requires {nargs} arguments.", ctx=self.ctx)
        values = args[idx : idx + nargs]
        occurrence = values[0] if nargs == 1 else tuple(values)
        return occurrence, idx + nargs


# ---------------------------------------------------------------- context

class Context:
    """The state of one invocation of a command."""

    # spec: N-000950, N-000951, N-000952, N-000953, N-000954, N-000955, N-000956, N-000957, N-000958, N-000959, N-000960, N-000961, N-000962, N-000963, N-000964, N-000965, N-000966, N-000967, N-000968, N-000969, N-000970, N-000971, N-000972, N-000973, N-000974
    def __init__(
        self,
        command: Command,
        parent: Context | None = None,
        info_name: str | None = None,
        obj: t.Any = None,
        auto_envvar_prefix: str | None = None,
        default_map: t.Mapping[str, t.Any] | None = None,
        terminal_width: int | None = None,
        max_content_width: int | None = None,
        allow_extra_args: bool | None = None,
        allow_interspersed_args: bool | None = None,
        ignore_unknown_options: bool | None = None,
        help_option_names: t.Sequence[str] | None = None,
        token_normalize_func: t.Callable[[str], str] | None = None,
        color: bool | None = None,
        show_default: bool | None = None,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name if info_name is not None else command.name
        if parent is not None:
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix and self.info_name:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{self.info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix
        if default_map is None and parent is not None and isinstance(parent.default_map, dict) and self.info_name:
            default_map = parent.default_map.get(self.info_name)
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width
        self.help_option_names = list(help_option_names) if help_option_names else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default) if show_default is not None else False
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else bool(allow_extra_args)
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args
            if allow_interspersed_args is None
            else bool(allow_interspersed_args)
        )
        self.ignore_unknown_options = (
            command.ignore_unknown_options
            if ignore_unknown_options is None
            else bool(ignore_unknown_options)
        )
        self.params: dict[str, t.Any] = {}
        self.args: list[str] = []
        self.protected_args: list[str] = []
        self.invoked_subcommand: t.Any = None
        self.resilient_parsing = False
        self._parameter_source: dict[str, ParameterSource] = {}
        self._dest_rank: dict[str, tuple[int, int, int]] = {}
        self._exit_stack = ExitStack()
        self._depth = 0

    # ------------------------------------------------------------ basics

    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            if parent_path:
                rv = f"{parent_path} {rv}" if rv else parent_path
        return rv.lstrip()

    def find_root(self) -> Context:
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: Context | None = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # spec: N-000450, N-000451, N-000452, N-000453, N-000454, N-000455
    def lookup_default(self, name: str) -> t.Any:
        if isinstance(self.default_map, dict):
            return self.default_map.get(name)
        return None

    # spec: N-000463, N-000464, N-000465, N-000466, N-000978
    def get_parameter_source(self, name: str) -> ParameterSource | None:
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._parameter_source.get(name, ParameterSource.DEFAULT)

    def fail(self, message: str) -> t.NoReturn:
        raise UsageError(message, self)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    # spec: N-000828, N-000829, N-000830, N-000831, N-000832, N-000833
    def get_usage(self) -> str:
        return self.command.get_usage(self)

    # spec: N-000827, N-000828, N-000829, N-000830, N-000831, N-000832, N-000833, N-000834, N-000835, N-000836, N-000837, N-000838, N-000839, N-000840, N-000841, N-000842, N-000843, N-000844, N-000845, N-000680
    # spec: N-000152
    def get_help(self) -> str:
        return self.command.get_help(self)

    def call_on_close(self, func: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(func)

    def with_resource(self, context_manager: t.ContextManager[t.Any]) -> t.Any:
        return self._exit_stack.enter_context(context_manager)

    def close(self) -> None:
        stack = self._exit_stack
        self._exit_stack = ExitStack()
        stack.close()

    # ------------------------------------------------------------ scope

    def __enter__(self) -> Context:
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type: t.Any, exc: t.Any, tb: t.Any) -> None:
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()

    @contextmanager
    # spec: N-000467, N-000482, N-000483, N-000477, N-000478, N-000479
    def scope(self, cleanup: bool = True) -> t.Iterator[Context]:
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            pop_context()
            self._depth -= 1
            if cleanup and self._depth == 0:
                self.close()

    # ------------------------------------------------------------ invocation

    # spec: N-000083, N-000084, N-000085, N-000388, N-000389, N-000390, N-000391, N-000392, N-000393, N-000403, N-000404, N-000405, N-000471, N-000472, N-000473, N-000474, N-000475, N-000476
    def invoke(self, callback: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run a command or a function from inside a callback."""
        if isinstance(callback, Command):
            other = callback
            child = Context(other, info_name=other.name, parent=self)
            with child:
                if other.callback is None:
                    return None
                return other.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    # spec: N-000471, N-000472, N-000473, N-000474, N-000475, N-000476
    def forward(self, cmd: Command, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run ``cmd`` with this command's current parameter values."""
        merged = {**self.params, **kwargs}
        return self.invoke(cmd, *args, **merged)

    def __repr__(self) -> str:
        return f"<Context {self.command_path}>"


# ---------------------------------------------------------------- commands

# spec: N-000114, N-000115, N-000116, N-000117, N-000853
def _clean_help(help_text: str | None, callback: t.Any) -> str | None:
    if help_text is not None:
        return help_text.replace("\f", "")
    if callback is None:
        return None
    doc = getattr(callback, "__doc__", None)
    if not doc:
        return None
    cleaned = inspect.cleandoc(doc)
    if "\f" in cleaned:
        cleaned = cleaned.split("\f", 1)[0].rstrip()
    return cleaned


# spec: N-000054
def _expand_windows_args(args: t.Sequence[str]) -> list[str]:
    """On Windows, expand glob, home-directory and environment tokens in argv."""
    import glob

    out: list[str] = []
    for arg in args:
        arg = os.path.expanduser(os.path.expandvars(arg)) if ("~" in arg or "%" in arg or "$" in arg) else arg
        if any(ch in arg for ch in "*?["):
            matches = sorted(glob.glob(arg))
            out.extend(matches if matches else [arg])
        else:
            out.append(arg)
    return out


# spec: N-000929, N-000110, N-000111, N-000112, N-000113
def _show_help(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _help_option(names: list[str]) -> Option:
    return Option(
        names,
        is_flag=True,
        expose_value=False,
        is_eager=True,
        help="Show this message and exit.",
        callback=_show_help,
    )


# spec: N-000133, N-000134, N-000135, N-000136, N-000137, N-000138, N-000679, N-000680
# spec: N-000133
def _help_width(ctx: Context) -> int:
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    max_width = ctx.max_content_width if ctx.max_content_width is not None else 80
    detected = shutil.get_terminal_size(fallback=(80, 24)).columns
    return max(min(detected, max_width), 20)


# spec: N-000079, N-000080, N-000081, N-000082, N-000850, N-000851
class Command:
    """A leaf command: parameters plus a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name: str | None,
        context_settings: t.Mapping[str, t.Any] | None = None,
        callback: t.Callable[..., t.Any] | None = None,
        params: t.Sequence[Parameter] | None = None,
        help: str | None = None,
        epilog: str | None = None,
        short_help: str | None = None,
        options_metavar: str | None = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: bool | str = False,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params: list[Parameter] = list(params or [])
        self.help = _clean_help(help, callback)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        arguments = [p for p in self.params if isinstance(p, Argument)]
        if sum(1 for a in arguments if a.nargs == -1) > 1:
            raise DeclarationError("at most one variadic argument may be declared on a command.")

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    # ------------------------------------------------------------ params

    # spec: N-000153, N-000154, N-000155, N-000156, N-000157, N-000158, N-000159, N-000160, N-000161, N-000176, N-000177
    def get_help_option(self, ctx: Context) -> Option | None:
        if not self.add_help_option:
            return None
        author_names = {n for p in self.params if isinstance(p, Option) for n in p.opts + p.secondary_opts}
        names = [n for n in ctx.help_option_names if n not in author_names]
        if not names:
            return None
        return _help_option(names)

    def get_params(self, ctx: Context) -> list[Parameter]:
        rv = list(self.params)
        help_opt = self.get_help_option(ctx)
        if help_opt is not None:
            rv.append(help_opt)
        return rv

    # ------------------------------------------------------------ parsing

    # spec: N-000434, N-000435, N-000436, N-000437, N-000438, N-000439, N-000440, N-000441, N-000442, N-000443
    def make_context(self, info_name: str | None, args: list[str], parent: Context | None = None, **extra: t.Any) -> Context:
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        try:
            with ctx.scope(cleanup=False):
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    # spec: N-000406, N-000407, N-000408, N-000409, N-000410, N-000764, N-000765
    def parse_args(self, ctx: Context, args: list[str]) -> list[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            echo(self.get_help(ctx), file=sys.stderr)
            raise NoArgsIsHelp("No arguments given.", ctx)
        params = self.get_params(ctx)
        for index, param in enumerate(params):
            param._decl_index = index
        parser = _Parser(ctx, params)
        largs = parser.parse(list(args))
        parsed = parser.parsed
        order = parser.order
        largs = self._consume_arguments(ctx, params, largs, parsed, order)
        for param in iter_params_for_processing(order, params):
            param.handle_parse_result(ctx, parsed)
        self._finish_parse(ctx, largs, parser)
        return ctx.args

    # spec: N-000291, N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298, N-000299, N-000300, N-000301, N-000302, N-000303
    def _consume_arguments(
        self,
        ctx: Context,
        params: list[Parameter],
        largs: list[str],
        parsed: dict[Parameter, list[t.Any]],
        order: list[Parameter],
    ) -> list[str]:
        remaining = list(largs)
        for param in params:
            if not isinstance(param, Argument):
                continue
            if param.nargs == 1:
                if not remaining:
                    continue
                occurrence: t.Any = remaining.pop(0)
            elif param.nargs == -1:
                if not remaining:
                    continue
                occurrence = tuple(remaining)
                remaining = []
            else:
                if not remaining:
                    continue
                if len(remaining) < param.nargs:
                    raise BadArgumentUsage(
                        f"Argument '{param.name.upper()}' takes {param.nargs} values.",
                        ctx=ctx,
                    )
                occurrence = tuple(remaining[: param.nargs])
                del remaining[: param.nargs]
            parsed.setdefault(param, []).append(occurrence)
            if param not in order:
                order.append(param)
        return remaining

    # spec: N-000105, N-000106, N-000107, N-000108, N-000109, N-000323, N-000324
    # spec: N-000307, N-000308
    def _finish_parse(self, ctx: Context, largs: list[str], parser: _Parser) -> None:
        if largs and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail(f"Got unexpected extra argument{'s' if len(largs) > 1 else ''} ({' '.join(largs)})")
        if largs and not ctx.ignore_unknown_options and not ctx.resilient_parsing:
            for token in largs:
                if parser._is_optlike(token):
                    raise NoSuchOption(token, ctx=ctx)
        ctx.args = list(largs)

    # ------------------------------------------------------------ invocation

    def invoke(self, ctx: Context) -> t.Any:
        if self.deprecated:
            _warn_deprecated("command", self.name or "", self.deprecated)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    # spec: N-000097, N-000098, N-000099, N-000100, N-000716, N-000717, N-000718, N-000719, N-000720, N-000721, N-000722, N-000723, N-000724, N-000725, N-000726, N-000727, N-000728, N-000729, N-000730, N-000731, N-000734, N-000854, N-000855, N-000856, N-000857, N-000858, N-000859, N-000860, N-000861
    def main(
        self,
        args: t.Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run this command as a program."""
        if args is None:
            args = sys.argv[1:]
            if sys.platform.startswith("win") and windows_expand_args:
                args = _expand_windows_args(args)
        args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        from .shell_completion import maybe_handle_completion

        maybe_handle_completion(self, prog_name, args, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as exc:
                raise Abort() from exc
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return exc.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except UsageError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        return None

    # ------------------------------------------------------------ help

    # spec: N-000122, N-000123, N-000124, N-000843
    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help:
            return self.short_help
        if self.help:
            return make_default_short_help(self.help, limit)
        return ""

    def collect_usage_pieces(self, ctx: Context) -> list[str]:
        pieces: list[str] = []
        params = self.get_params(ctx)
        if self.options_metavar and any(isinstance(p, Option) and not p.hidden for p in params):
            pieces.append(self.options_metavar)
        for param in params:
            if isinstance(param, Argument) and not param.hidden:
                pieces.append(param.make_usage_piece())
        return pieces

    def get_usage(self, ctx: Context) -> str:
        pieces = self.collect_usage_pieces(ctx)
        line = f"Usage: {ctx.command_path}"
        if pieces:
            line += " " + " ".join(pieces)
        return line

    def _option_rows(self, ctx: Context) -> list[tuple[str, str]]:
        rows: list[tuple[str, str]] = []
        for param in self.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            if param.secondary_opts:
                first = f"{', '.join(param.opts)} / {', '.join(param.secondary_opts)}"
            else:
                first = ", ".join(param.opts)
            metavar = param.make_metavar()
            if metavar:
                first = f"{first} {metavar}"
            rows.append((first, " ".join(param.help_text_extras(ctx))))
        return rows

    # spec: N-000118, N-000119, N-000120, N-000121, N-000318, N-000319, N-000320
    def _argument_rows(self, ctx: Context) -> list[tuple[str, str]]:
        return [
            (param.make_metavar(), param.help or "")
            for param in self.get_params(ctx)
            if isinstance(param, Argument) and param.help and not param.hidden
        ]

    # spec: N-000773, N-000774, N-000842, N-000843
    def _extra_sections(self, ctx: Context, width: int) -> list[str]:
        return []

    def get_help(self, ctx: Context) -> str:
        width = _help_width(ctx)
        lines: list[str] = [self.get_usage(ctx), ""]
        if self.help or self.deprecated:
            text = self.help or ""
            if self.deprecated:
                text = f"(Deprecated) {text}".strip()
            lines.append(wrap_text(text, width=width, initial_indent="  ", subsequent_indent="  "))
            lines.append("")
        arg_rows = self._argument_rows(ctx)
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(write_dl(arg_rows, width))
            lines.append("")
        opt_rows = self._option_rows(ctx)
        if opt_rows:
            lines.append("Options:")
            lines.extend(write_dl(opt_rows, width))
            lines.append("")
        lines.extend(self._extra_sections(ctx, width))
        if self.epilog:
            lines.append(wrap_text(self.epilog, width=width))
            lines.append("")
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines)

    def format_help(self, ctx: Context) -> str:
        return self.get_help(ctx)


# spec: N-000384, N-000385, N-000386, N-000387, N-000591, N-000592
class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(
        self,
        name: str | None = None,
        commands: t.Mapping[str, Command] | t.Iterable[Command] | None = None,
        invoke_without_command: bool = False,
        no_args_is_help: bool | None = None,
        subcommand_metavar: str | None = None,
        chain: bool = False,
        result_callback: t.Callable[..., t.Any] | None = None,
        allow_interspersed_args: bool | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.commands: dict[str, Command] = {}
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.allow_interspersed_args = False if allow_interspersed_args is None else allow_interspersed_args
        if commands:
            if isinstance(commands, dict):
                for key, cmd in commands.items():
                    self.add_command(cmd, key)
            else:
                for cmd in commands:
                    self.add_command(cmd)

    # ------------------------------------------------------------ registry

    # spec: N-000869, N-000870, N-000871, N-000612, N-000613, N-000614, N-000401, N-000402
    # spec: N-000769, N-000770, N-000771
    def add_command(self, cmd: Command, name: str | None = None) -> None:
        name = name or cmd.name
        if not name:
            raise DeclarationError("a subcommand needs a name.")
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("cannot attach a group beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], Command]:
        from .decorators import command as _command_decorator

        def decorator(f: t.Callable[..., t.Any]) -> Command:
            cmd = _command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], Group]:
        from .decorators import group as _group_decorator

        def decorator(f: t.Callable[..., t.Any]) -> Group:
            cmd = _group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self) -> t.Callable[[t.Callable[..., t.Any]], t.Callable[..., t.Any]]:
        def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            self._result_callback = f
            return f

        return decorator

    # spec: N-000422, N-000423, N-000424, N-000425, N-000876
    def list_commands(self, ctx: Context) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        return self.commands.get(cmd_name)

    # spec: N-000398, N-000399, N-000400, N-000429, N-000430, N-000431, N-000432, N-000413, N-000414
    def resolve_command(self, ctx: Context, args: list[str]) -> tuple[str, Command, list[str]]:
        cmd_name = args[0]
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    cmd = self.get_command(ctx, name)
                    if cmd is not None:
                        cmd_name = name
                        break
        if cmd is None:
            ctx.fail(f"No such command '{cmd_name}'.")
        return cmd_name, cmd, args[1:]

    # ------------------------------------------------------------ parsing

    def _finish_parse(self, ctx: Context, largs: list[str], parser: _Parser) -> None:
        if self.chain:
            ctx.protected_args = list(largs)
            ctx.args = []
        elif largs:
            ctx.protected_args = largs[:1]
            ctx.args = largs[1:]
        else:
            ctx.protected_args = []
            ctx.args = []

    # ------------------------------------------------------------ invocation

    def _process_result(self, value: t.Any, ctx: Context) -> t.Any:
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, value, **ctx.params)
        return value

    def invoke(self, ctx: Context) -> t.Any:
        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    if self.chain:
                        return self._process_result_chain([], ctx)
                    return self._process_result(rv, ctx)
            raise UsageError("Missing command.", ctx)

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return self._process_result(sub_ctx.command.invoke(sub_ctx), ctx)

        # spec: N-000609, N-000610, N-000611, N-000615, N-000616, N-000617
        with ctx:
            ctx.invoked_subcommand = _CHAIN_SUBCOMMAND
            super().invoke(ctx)
            contexts: list[Context] = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name,
                    args,
                    parent=ctx,
                    allow_extra_args=True,
                    allow_interspersed_args=False,
                )
                contexts.append(sub_ctx)
                args = sub_ctx.args
                sub_ctx.args = []
            results: list[t.Any] = []
            for sub_ctx in contexts:
                with sub_ctx:
                    results.append(sub_ctx.command.invoke(sub_ctx))
            return self._process_result_chain(results, ctx)

    # spec: N-000597, N-000598, N-000599, N-000600, N-000601, N-000602, N-000603, N-000604, N-000605, N-000606, N-000607, N-000608
    def _process_result_chain(self, results: list[t.Any], ctx: Context) -> list[t.Any]:
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results

    # ------------------------------------------------------------ help

    def collect_usage_pieces(self, ctx: Context) -> list[str]:
        pieces = super().collect_usage_pieces(ctx)
        if self.subcommand_metavar:
            command_piece = self.subcommand_metavar
        else:
            command_piece = "COMMAND"
        if self.chain:
            pieces.append(f"{command_piece} [ARGS]...")
            pieces.append(f"[{command_piece} [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(f"[{command_piece}] [ARGS]...")
        else:
            pieces.append(f"{command_piece} [ARGS]...")
        return pieces

    def _extra_sections(self, ctx: Context, width: int) -> list[str]:
        rows: list[tuple[str, str]] = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str()))
        if not rows:
            return []
        return ["Commands:", *write_dl(rows, width), ""]


# spec: N-000422, N-000423, N-000424, N-000425
class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface."""

    def __init__(self, name: str | None = None, sources: t.Sequence[Group] | None = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: list[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> list[str]:
        names: set[str] = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


__all__ = [
    "Argument",
    "Command",
    "CommandCollection",
    "Context",
    "Group",
    "Option",
    "Parameter",
    "ParameterSource",
    "get_current_context",
]
