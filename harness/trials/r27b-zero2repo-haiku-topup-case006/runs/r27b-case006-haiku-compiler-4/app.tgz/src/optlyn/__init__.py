"""Optlyn: a composable command line interface toolkit.

The package root exports the declaration decorators, the command classes,
the parameter types and the terminal helpers. See ``spec/`` for the contract.
"""
# spec: N-000001, N-000002, N-000003, N-000004, N-000005, N-000006, N-000007, N-000008, N-000009, N-000010
# spec: N-000011, N-000012, N-000013, N-000014, N-000025, N-000026, N-000027, N-000028, N-000029, N-000030
# spec: N-000031, N-000032, N-000033, N-000034, N-000035, N-000036, N-000037, N-000038, N-000039, N-000040
# spec: N-000041, N-000042, N-000043, N-000044
# spec: N-000045, N-000046, N-000047, N-000048, N-000049, N-000050, N-000051, N-000052, N-000053, N-000055
# spec: N-000056, N-000057, N-000058, N-000059, N-000060, N-000061, N-000062, N-000063, N-000064, N-000065, N-000066, N-000067, N-000068, N-000069
# spec: N-000775, N-000776, N-000777, N-000778, N-000779, N-000780, N-000781, N-000782, N-000783, N-000784, N-000785, N-000786, N-000787, N-000788, N-000789, N-000790
# spec: N-000791, N-000792, N-000793, N-000794, N-000802
# spec: N-000070, N-000071, N-000072, N-000073, N-000074, N-000075, N-000076, N-000077, N-000078
# (non-goals: no aliases, plugin discovery, config syntax, server, or GUI are built)

from __future__ import annotations

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, MissingParameter, OptlynError, UsageError
from .parameter_types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, get_app_dir, open_file
from ._context import get_current_context

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Argument",
    "Parameter",
    "ParamType",
    "ParameterSource",
    "BadParameter",
    "MissingParameter",
    "UsageError",
    "OptlynError",
    "Abort",
    # parameter types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
]
