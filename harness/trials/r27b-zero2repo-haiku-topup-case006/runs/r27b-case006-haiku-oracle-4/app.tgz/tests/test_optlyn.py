"""Behavioural tests for Optlyn.  Run with: PYTHONPATH=src python -m pytest tests

Test names carry the spec claim id they check, where one applies (``test_N_000803_...``),
or the feature point (``test_FP03_...``) otherwise.
"""

import os
import uuid

import pytest

import optlyn
from optlyn import (
    Abort,
    BadParameter,
    Choice,
    Context,
    File,
    FloatRange,
    Group,
    IntRange,
    ParamType,
    Path,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    style,
    unstyle,
    version_option,
    wrap_text,
)
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# ---------------------------------------------------------------- exit statuses (FP-13, N-000803..)

def test_N_000803_success_exit_zero(runner):
    @command()
    def ok():
        echo("fine")

    res = runner.invoke(ok, [])
    assert res.exit_code == 0 and res.output == "fine\n"


def test_N_000804_usage_error_exit_two(runner):
    @command()
    @option("--n", type=int)
    def cmd(n):
        echo("ran")

    res = runner.invoke(cmd, ["--n", "x"])
    assert res.exit_code == 2
    assert "'--n'" in res.output and "ran" not in res.output


def test_FP13_abort_exit_one_writes_aborted(runner):
    @command()
    def cmd():
        raise Abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_FP13_author_exit_status(runner):
    @command()
    def cmd():
        get_current_context().exit(3)

    assert runner.invoke(cmd, []).exit_code == 3


def test_FP13_standalone_off_propagates_and_returns():
    @command()
    @argument("x", type=int)
    def cmd(x):
        return x * 2

    assert cmd.main(["4"], standalone_mode=False, prog_name="cmd") == 8
    with pytest.raises(BadParameter):
        cmd.main(["zz"], standalone_mode=False, prog_name="cmd")


# ---------------------------------------------------------------- commands (FP-01)

def test_FP01_name_derivation():
    @command()
    def hello_world_cmd():
        pass

    @group()
    def tools_grp():
        pass

    assert hello_world_cmd.name == "hello-world"
    assert tools_grp.name == "tools"


def test_FP01_explicit_name_replaces_derived_name(runner):
    @command("renamed")
    def original():
        echo("x")

    assert original.name == "renamed"
    assert runner.invoke(original, [], prog_name="p").output == "x\n"


def test_FP01_deprecated_command_still_runs(runner):
    @command(deprecated="Use new.")
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "DeprecationWarning" in res.stderr and "Use new." in res.stderr


# ---------------------------------------------------------------- help (FP-02, N-000827..)

def test_FP02_help_exit_zero_and_skips_callback(runner):
    ran = []

    @command()
    @option("--n")
    def cmd(n):
        ran.append(True)

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0 and not ran
    assert res.output.startswith("Usage: ")
    assert "Options:" in res.output and "--help" in res.output


def test_FP02_group_without_subcommand_is_usage_failure(runner):
    @group()
    def grp():
        echo("should not run")

    res = runner.invoke(grp, [])
    assert res.exit_code == 2 and "Usage:" in res.output
    assert "should not run" not in res.output


def test_FP02_form_feed_truncates_help():
    @command(help="Kept.\fDropped.")
    def cmd():
        pass

    assert "Dropped" not in cmd.help and cmd.help == "Kept."


def test_FP02_metavar_and_choice_entries(runner):
    @command()
    @option("--count", type=int)
    @option("--level", type=Choice(["low", "high"]))
    def cmd(count, level):
        pass

    out = runner.invoke(cmd, ["--help"]).output
    assert "--count INTEGER" in out
    assert "[low|high]" in out


def test_FP02_show_default_hides_false_flag(runner):
    @command()
    @option("--shout", is_flag=True, show_default=True)
    @option("--n", default=3, show_default=True)
    def cmd(shout, n):
        pass

    out = runner.invoke(cmd, ["--help"]).output
    assert "[default: 3]" in out
    assert out.count("[default:") == 1


def test_FP02_hidden_options_are_omitted_but_parse(runner):
    @command()
    @option("--secret", hidden=True)
    def cmd(secret):
        echo(str(secret))

    assert "--secret" not in runner.invoke(cmd, ["--help"]).output
    assert runner.invoke(cmd, ["--secret", "s"]).output == "s\n"


def test_FP02_version_option_is_eager(runner):
    ran = []

    @command()
    @option("--req", required=True)
    @version_option("9.9.9", prog_name="tool")
    def cmd(req):
        ran.append(True)

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.output == "tool, version 9.9.9\n" and not ran


def test_FP02_custom_version_prints_exact_string(runner):
    @command()
    @custom_version_option(lambda ctx: "ID-42", "--ver")
    def cmd():
        pass

    assert runner.invoke(cmd, ["--ver"]).output == "ID-42\n"


def test_FP02_first_typed_eager_flag_wins(runner):
    def make(name):
        def cb(ctx, param, value):
            if value:
                echo(name)
                ctx.exit(0)
        return cb

    @command()
    @option("--a", is_flag=True, is_eager=True, expose_value=False, callback=make("A"))
    @option("--b", is_flag=True, is_eager=True, expose_value=False, callback=make("B"))
    def cmd():
        pass

    assert runner.invoke(cmd, ["--b", "--a"]).output == "B\n"
    assert runner.invoke(cmd, ["--a", "--b"]).output == "A\n"


def test_FP02_help_option_names_can_be_replaced(runner):
    @command(context_settings={"help_option_names": ["-h"]})
    def cmd():
        pass

    assert runner.invoke(cmd, ["-h"]).exit_code == 0
    assert runner.invoke(cmd, ["--help"]).exit_code == 2


def test_FP02_author_help_option_overrides_automatic(runner):
    @command()
    @help_option("--help", "-?")
    def cmd():
        echo("author")

    assert runner.invoke(cmd, ["--help"]).exit_code == 0


def test_FP11_wrap_text_accepts_any_string():
    text = wrap_text("aaa bbb ccc ddd eee", width=7)
    assert "\n" in text and "aaa" in text
    assert wrap_text("", width=10) == ""


def test_FP11_backspace_paragraph_keeps_line_breaks():
    text = wrap_text("\b\nline one\nline two", width=10, preserve_paragraphs=True)
    assert text == "line one\nline two"


# ---------------------------------------------------------------- options (FP-03)

def test_FP03_stacked_short_flags_and_attached_value(runner):
    @command()
    @option("-v", count=True)
    @option("-q", is_flag=True)
    @option("-x", "xval")
    def cmd(v, q, xval):
        echo(f"{v} {q} {xval}")

    assert runner.invoke(cmd, ["-vvvq", "-xHELLO"]).output == "3 True HELLO\n"


def test_FP03_long_equals_and_double_dash(runner):
    @command()
    @option("--out")
    @argument("rest", nargs=-1)
    def cmd(out, rest):
        echo(f"{out}|{rest}")

    assert runner.invoke(cmd, ["--out=a", "--", "--x"]).output == "a|('--x',)\n"


def test_FP03_repeatable_and_multi_value(runner):
    @command()
    @option("-t", "tags", multiple=True)
    @option("--pt", nargs=2, type=int)
    def cmd(tags, pt):
        echo(f"{tags} {pt}")

    assert runner.invoke(cmd, ["-t", "a", "-t", "b", "--pt", "1", "2"]).output == "('a', 'b') (1, 2)\n"
    assert runner.invoke(cmd, []).output == "() None\n"


def test_FP03_on_off_pair(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    def cmd(shout):
        echo(str(shout))

    assert runner.invoke(cmd, ["--shout"]).output == "True\n"
    assert runner.invoke(cmd, ["--no-shout"]).output == "False\n"


def test_FP03_missing_required_option(runner):
    @command()
    @option("--must", required=True)
    def cmd(must):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "Missing option '--must'" in res.output


def test_FP03_env_boolean_flag_rules(runner):
    @command()
    @option("--shout", is_flag=True, envvar="SHOUT")
    def cmd(shout):
        echo(str(shout))

    assert runner.invoke(cmd, [], env={"SHOUT": " YES "}).output == "True\n"
    assert runner.invoke(cmd, [], env={"SHOUT": "off"}).output == "False\n"
    assert runner.invoke(cmd, [], env={"SHOUT": "maybe"}).exit_code == 2


def test_FP03_env_for_option_with_default_map_precedence(runner):
    @command()
    @option("--a", type=int)
    def cmd(a):
        echo(str(a))

    res = runner.invoke(cmd, [], default_map={"a": 7})
    assert res.output == "7\n"
    assert runner.invoke(cmd, ["--a", "1"], default_map={"a": 7}).output == "1\n"


def test_FP03_default_map_string_refused_for_repeatable(runner):
    @command()
    @option("--lst", multiple=True)
    def cmd(lst):
        pass

    res = runner.invoke(cmd, [], default_map={"lst": "bad"})
    assert res.exit_code == 2 and "iterable" in res.output


def test_FP03_feature_switch_declared_default_wins(runner):
    @command()
    @option("--upper", "case", flag_value="upper")
    @option("--lower", "case", flag_value="lower", default="lower")
    def cmd(case):
        echo(case)

    assert runner.invoke(cmd, []).output == "lower\n"
    assert runner.invoke(cmd, ["--upper"]).output == "upper\n"


def test_FP03_parameter_source_inspection(runner):
    @command()
    @option("--x", default="d")
    @option("--y", envvar="YY")
    def cmd(x, y):
        c = get_current_context()
        echo(f"{c.get_parameter_source('x').name} {c.get_parameter_source('y').name}")

    assert runner.invoke(cmd, [], env={"YY": "1"}).output == "DEFAULT ENVIRONMENT\n"


def test_FP03_callback_refusal_is_usage_error(runner):
    def cb(ctx, param, value):
        if value == "bad":
            raise BadParameter("nope")
        return value.upper()

    @command()
    @option("--c", callback=cb)
    def cmd(c):
        echo(c)

    assert runner.invoke(cmd, ["--c", "ok"]).output == "OK\n"
    assert runner.invoke(cmd, ["--c", "bad"]).exit_code == 2


# ---------------------------------------------------------------- arguments (FP-04)

def test_FP04_variadic_and_leftover_rules(runner):
    @command()
    @argument("first")
    @argument("rest", nargs=-1)
    def cmd(first, rest):
        echo(f"{first} {rest}")

    assert runner.invoke(cmd, ["a", "b", "c"]).output == "a ('b', 'c')\n"
    assert runner.invoke(cmd, []).exit_code == 2


def test_FP04_extra_args_rejected_unless_allowed(runner):
    @command()
    @argument("a")
    def cmd(a):
        pass

    assert runner.invoke(cmd, ["1", "2"]).exit_code == 2


def test_FP04_deprecated_required_argument_refused_at_declaration():
    with pytest.raises(TypeError):
        argument("x", deprecated=True)(lambda: None)


# ---------------------------------------------------------------- types (FP-05)

def test_FP05_int_range_clamp_open_bound_adjacent():
    rng = IntRange(1, 10, min_open=True, clamp=True)
    assert rng.convert("1", None, None) == 2
    assert rng.convert("99", None, None) == 10


def test_FP05_float_range_refuses_clamp_with_open_bound():
    with pytest.raises(TypeError):
        FloatRange(0.0, 1.0, max_open=True, clamp=True)


def test_FP05_choice_is_case_sensitive_by_default():
    with pytest.raises(BadParameter):
        Choice(["a"])("A", None, None)
    assert Choice(["a"], case_sensitive=False)("A", None, None) == "a"


def test_FP05_uuid_and_datetime(runner):
    @command()
    @option("--u", type=optlyn.UUID)
    def cmd(u):
        echo(str(u))

    value = str(uuid.UUID(int=5))
    assert runner.invoke(cmd, ["--u", value]).output == value + "\n"


def test_FP05_custom_param_type_and_function_type(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if value.isupper():
                return value
            self.fail(f"{value} not upper", param, ctx)

    @command()
    @argument("u", type=Upper())
    @argument("n", type=int)
    def cmd(u, n):
        echo(f"{u}{n}")

    assert runner.invoke(cmd, ["AB", "3"]).output == "AB3\n"
    assert runner.invoke(cmd, ["ab", "3"]).exit_code == 2


def test_FP05_default_metavar_from_type_name():
    assert optlyn.INT.name == "integer"


# ---------------------------------------------------------------- groups (FP-06, FP-10)

def test_FP06_group_callback_runs_before_child(runner):
    @group()
    def outer():
        echo("outer")

    @outer.command()
    def child():
        echo("child")

    assert runner.invoke(outer, ["child"]).output == "outer\nchild\n"


def test_FP06_nested_groups_require_each_name(runner):
    @group()
    def outer():
        pass

    @outer.group()
    def middle():
        pass

    @middle.command()
    def inner():
        echo("inner")

    assert runner.invoke(outer, ["middle", "inner"]).output == "inner\n"
    assert runner.invoke(outer, ["inner"]).exit_code == 2


def test_FP06_unknown_subcommand_skips_callback(runner):
    @group()
    def grp():
        echo("should not run")

    res = runner.invoke(grp, ["nope"])
    assert res.exit_code == 2 and "should not run" not in res.output


def test_FP06_lazy_custom_group_is_consulted_on_demand(runner):
    loaded = []

    class Lazy(Group):
        def list_commands(self, ctx):
            return ["lazy-one"]

        def get_command(self, ctx, name):
            if name == "lazy-one":
                loaded.append(name)
                return command("lazy-one")(lambda: echo("lazy ran"))
            return None

    grp = group(cls=Lazy)(lambda: None)
    assert runner.invoke(grp, ["--help"]).exit_code == 0
    assert loaded == ["lazy-one"]
    assert runner.invoke(grp, ["lazy-one"]).output == "lazy ran\n"


def test_FP06_command_collection_union(runner):
    g1 = group("g1")(lambda: None)
    g2 = group("g2")(lambda: None)

    @g1.command()
    def a():
        echo("a")

    @g2.command()
    def b():
        echo("b")

    cc = group(cls=optlyn.CommandCollection, sources=[g1, g2])(lambda: None)
    assert runner.invoke(cc, ["b"]).output == "b\n"
    assert "a" in runner.invoke(cc, ["--help"]).output


def test_FP10_chain_runs_in_order_and_result_callback(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command("add")
    @argument("n", type=int)
    def add(n):
        return n

    @pipe.command("mul")
    @argument("n", type=int)
    def mul(n):
        return n

    @pipe.result_callback()
    def done(results):
        echo(f"results={results}")

    assert runner.invoke(pipe, ["add", "2", "mul", "3"]).output == "results=[2, 3]\n"


def test_FP10_groups_cannot_nest_under_chain():
    chain = group(chain=True)(lambda: None)
    with pytest.raises(TypeError):
        chain.add_command(group("inner")(lambda: None))


# ---------------------------------------------------------------- context (FP-07)

def test_FP07_obj_passed_to_children_and_ensure(runner):
    class Cfg:
        x = 1

    pass_cfg = make_pass_decorator(Cfg, ensure=True)

    @command()
    @pass_cfg
    def cmd(cfg):
        echo(str(cfg.x))

    assert runner.invoke(cmd, []).output == "1\n"


def test_FP07_invoke_and_forward_between_commands(runner):
    @command()
    @option("--v", default=1)
    def target(v):
        echo(f"v={v}")

    @command()
    @option("--v", default=2)
    @pass_context
    def caller(ctx, v):
        ctx.invoke(target, v=10)
        ctx.forward(target)

    assert runner.invoke(caller, []).output == "v=10\nv=2\n"


def test_FP07_auto_envvar_prefix_skips_top_level_name(runner):
    @command()
    @option("--name")
    def inner(name):
        echo(str(name))

    top = group("top")(lambda: None)
    top.add_command(inner, "inner")
    res = runner.invoke(top, ["inner"], auto_envvar_prefix="APP", env={"APP_INNER_NAME": "auto"})
    assert res.output == "auto\n"


def test_FP07_default_map_nested_by_subcommand(runner):
    @group()
    def top():
        pass

    @top.command()
    @option("--v", type=int)
    def kid(v):
        echo(str(v))

    assert runner.invoke(top, ["kid"], default_map={"kid": {"v": 9}}).output == "9\n"


def test_FP07_context_token_normalize(runner):
    @command(context_settings={"token_normalize_func": lambda s: s.lower()})
    @option("--name")
    def cmd(name):
        echo(str(name))

    assert runner.invoke(cmd, ["--NAME", "x"]).output == "x\n"


# ---------------------------------------------------------------- prompts (FP-08)

def test_FP08_prompt_reads_and_reasks_on_conversion_failure(runner):
    @command()
    @option("--n", type=int, prompt=True)
    def cmd(n):
        echo(f"n={n}")

    res = runner.invoke(cmd, [], input="abc\n12\n")
    assert res.output.endswith("n=12\n") and "not a valid integer" in res.output


def test_FP08_prompt_eof_is_abort(runner):
    @command()
    @option("--n", prompt=True)
    def cmd(n):
        pass

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_FP08_confirmation_option_aborts_when_declined(runner):
    ran = []

    @command()
    @confirmation_option("--yes", prompt="Sure?")
    def cmd():
        ran.append(True)

    assert runner.invoke(cmd, [], input="n\n").exit_code == 1
    assert not ran
    assert runner.invoke(cmd, ["--yes"]).exit_code == 0
    assert ran


def test_FP08_password_option_confirms(runner):
    @command()
    @optlyn.password_option()
    def cmd(password):
        echo(password)

    assert runner.invoke(cmd, [], input="s\ns\n").output.endswith("s\n")


# ---------------------------------------------------------------- files and paths (FP-09)

def test_FP09_file_write_then_read(runner):
    @command()
    @argument("f", type=File("w"))
    def writer(f):
        f.write("hi")

    with runner.isolated_filesystem():
        assert runner.invoke(writer, ["out.txt"]).exit_code == 0
        assert open("out.txt").read() == "hi"


def test_FP09_lazy_write_never_used_creates_nothing(runner):
    @command()
    @argument("f", type=File("w"))
    def cmd(f):
        pass

    with runner.isolated_filesystem():
        runner.invoke(cmd, ["lazy.txt"])
        assert not os.path.exists("lazy.txt")


def test_FP09_missing_read_file_is_usage_error_naming_path(runner):
    @command()
    @argument("f", type=File())
    def cmd(f):
        pass

    res = runner.invoke(cmd, ["/definitely/not/here.txt"])
    assert res.exit_code == 2 and "/definitely/not/here.txt" in res.output


def test_FP09_dash_is_stdin_and_stdout_not_closed(runner):
    @command()
    @argument("f", type=File())
    def cmd(f):
        echo(f.read())

    assert runner.invoke(cmd, ["-"], input="piped").output == "piped\n"


def test_FP09_path_checks(runner):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        echo(p)

    with runner.isolated_filesystem():
        open("f.txt", "w").close()
        assert runner.invoke(cmd, ["f.txt"]).output == "f.txt\n"
        assert runner.invoke(cmd, ["missing.txt"]).exit_code == 2
        os.mkdir("d")
        assert runner.invoke(cmd, ["d"]).exit_code == 2


def test_FP09_atomic_write_replaces_on_close(runner):
    @command()
    @argument("f", type=File("w", atomic=True))
    def cmd(f):
        f.write("new")

    with runner.isolated_filesystem():
        open("t.txt", "w").write("old")
        assert runner.invoke(cmd, ["t.txt"]).exit_code == 0
        assert open("t.txt").read() == "new"


# ---------------------------------------------------------------- terminal helpers (FP-11)

def test_FP11_echo_strips_styles_when_not_terminal(runner):
    @command()
    def cmd():
        echo(style("plain", fg="blue"))

    assert runner.invoke(cmd, []).output == "plain\n"
    assert runner.invoke(cmd, [], color=True).output == "\x1b[34mplain\x1b[0m\n"


def test_FP11_style_and_unstyle():
    assert unstyle(style("x", fg="red", bold=True)) == "x"
    with pytest.raises(TypeError):
        style("x", fg="nope")
    assert style("x", fg="red") != style("x", bg="red")


def test_FP11_ascii_stream_falls_back_to_utf8(runner):
    @command()
    def cmd():
        echo("héllo")

    res = CliRunner(charset="ascii").invoke(cmd, [])
    assert res.exit_code == 0 and "héllo" in res.output


def test_FP11_app_dir_respects_xdg(monkeypatch, tmp_path):
    if os.name == "nt" or os.sys.platform == "darwin":
        pytest.skip("Unix-only rule")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert optlyn.get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")


def test_FP11_format_filename_is_utf8_encodable():
    text = optlyn.format_filename("a\udcffb.txt")
    text.encode("utf-8")
    assert "\udcff" not in text


# ---------------------------------------------------------------- completion (FP-12)

def _complete(runner, cmd, words, cword, shell="bash", prog="cli"):
    res = runner.invoke(
        cmd, [], prog_name=prog,
        env={"_CLI_COMPLETE": f"{shell}_complete", "COMP_WORDS": words, "COMP_CWORD": str(cword)},
    )
    assert res.exit_code == 0
    return res.stdout


def test_FP12_subcommand_and_option_suggestions(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--mode", type=Choice(["fast", "slow"]))
    @option("--hid", hidden=True)
    def build():
        pass

    assert _complete(runner, cli, "cli ", 1) == "build\n"
    assert _complete(runner, cli, "cli build --m", 2) == "--mode\n"
    assert _complete(runner, cli, "cli build --mode f", 3) == "fast\n"
    assert "--hid" not in _complete(runner, cli, "cli build --", 2)


def test_FP12_source_script_and_unknown_instruction(runner):
    @command()
    def cli():
        echo("ran")

    res = runner.invoke(cli, [], prog_name="cli", env={"_CLI_COMPLETE": "zsh_source"})
    assert res.exit_code == 0 and "compdef" in res.stdout and "ran" not in res.stdout
    res = runner.invoke(cli, [], prog_name="cli", env={"_CLI_COMPLETE": "nonsense"})
    assert res.exit_code == 1 and res.stdout == ""


def test_FP12_path_request_for_path_type(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @argument("d", type=Path(file_okay=False))
    def go(d):
        pass

    assert _complete(runner, cli, "cli go ", 2) == "@@dir\t\n"


def test_FP12_completion_function_sees_parsed_params(runner):
    seen = {}

    def comp(ctx, param, incomplete):
        seen.update(ctx.params)
        return ["alpha", "beta"]

    @command()
    @option("--other")
    @option("--pick", shell_complete=comp)
    def cli(other, pick):
        pass

    assert _complete(runner, cli, "cli --other zz --pick ", 4) == "alpha\nbeta\n"
    assert seen.get("other") == "zz"


# ---------------------------------------------------------------- runner (FP-14)

def test_FP14_runner_captures_stdout_stderr_and_exception(runner):
    @command()
    def cmd():
        echo("out")
        echo("err", err=True)
        raise RuntimeError("boom")

    res = runner.invoke(cmd, [])
    assert res.stdout == "out\n" and res.stderr == "err\n"
    assert res.output == "out\nerr\n"
    assert res.exit_code == 1 and isinstance(res.exception, RuntimeError)


def test_FP14_runner_can_raise_exceptions(runner):
    @command()
    def cmd():
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        CliRunner(catch_exceptions=False).invoke(cmd, [])


def test_FP14_env_is_restored_after_invoke(runner):
    @command()
    def cmd():
        echo(os.environ.get("OPTLYN_TEST_VAR", "unset"))

    assert runner.invoke(cmd, [], env={"OPTLYN_TEST_VAR": "set"}).output == "set\n"
    assert "OPTLYN_TEST_VAR" not in os.environ


def test_FP14_echo_stdin_echoes_only_consumed_input(runner):
    @command()
    @option("--a", prompt=True)
    def cmd(a):
        echo("A=" + a)

    res = CliRunner(echo_stdin=True).invoke(cmd, [], input="typed\nunused\n")
    assert res.output == "A: typed\nA=typed\n"


def test_FP14_isolated_filesystem_removed_without_parent(runner):
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
        assert os.path.realpath(os.getcwd()) == os.path.realpath(path)
    assert not os.path.exists(path)


def test_FP14_isolated_filesystem_left_in_parent(runner, tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        open(os.path.join(path, "keep.txt"), "w").close()
    assert os.path.exists(os.path.join(path, "keep.txt"))


# ---------------------------------------------------------------- package surface (Interface 1)

def test_N_000795_to_N_000801_package_exports():
    for name in ["command", "group", "option", "argument", "help_option", "version_option",
                 "custom_version_option", "password_option", "confirmation_option", "pass_context",
                 "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection",
                 "Context", "Option", "Parameter", "ParamType", "BadParameter", "Abort",
                 "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime",
                 "IntRange", "FloatRange", "Tuple", "File", "Path", "echo", "secho", "style",
                 "unstyle", "echo_via_pager", "get_pager_file", "progressbar", "prompt", "confirm",
                 "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
                 "get_current_context", "format_filename", "open_file"]:
        assert hasattr(optlyn, name), name
    from optlyn.formatting import wrap_text as wt
    assert wt is wrap_text


def test_N_000800_testing_exports_cli_runner():
    from optlyn.testing import CliRunner as Runner
    assert Runner is CliRunner
