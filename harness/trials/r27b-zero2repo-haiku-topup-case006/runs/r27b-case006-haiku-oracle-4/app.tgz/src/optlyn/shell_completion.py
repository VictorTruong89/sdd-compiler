"""Shell completion: registration scripts and suggestion output.

# spec: FP-12 (completion), Interface section 8
"""

import os
import sys

from .core import Argument, Command, Context, Group, Option
from .exceptions import Exit

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion: ``value``, optional ``help``, and ``type`` ("plain" for values)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _var_name(prog_name):
    prog = os.path.basename(prog_name) if prog_name else "root"
    return "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def _normalize_items(result):
    items = []
    for r in result or []:
        if isinstance(r, CompletionItem):
            items.append(r)
        elif isinstance(r, str):
            items.append(CompletionItem(r))
        else:
            items.append(CompletionItem(r.value, getattr(r, "help", None),
                                        getattr(r, "type", "plain") or "plain"))
    return items


def _param_items(ctx, param, incomplete):
    custom = getattr(param, "_shell_complete", None)
    if custom is not None:
        result = custom(ctx, param, incomplete)
    else:
        result = param.type.shell_complete(ctx, param, incomplete)
    return _normalize_items(result)


def _fill_parsed_params(cmd, ctx, tokens):
    """Best-effort parse so completion functions see ctx.params.  # spec: FP-12

    Resilient parsing never prompts and never shows help; errors are ignored.
    """
    if ctx.params:
        return
    ctx.resilient_parsing = True
    try:
        cmd.parse_args(ctx, [t for t in tokens if t != "--"])
    except Exception:
        pass
    finally:
        ctx.resilient_parsing = False


def _find_option(cmd, ctx, token):
    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and (token in p.opts or token in p.secondary_opts):
            return p
    return None


def _collect(cmd, prog_name, tokens, incomplete, shell):
    """Work out the suggestions for the completion request.  # spec: FP-12"""
    ctx = Context(cmd, info_name=prog_name, **cmd.context_settings)
    cur_cmd, cur_ctx = cmd, ctx
    pending = None
    pos_index = 0
    level_wants_sub = isinstance(cmd, Group)
    level_start = 0
    for idx, tok in enumerate(tokens):
        if pending is not None:
            pending = None
            continue
        if tok == "--":
            continue
        if tok.startswith("-") and len(tok) > 1:
            opt = _find_option(cur_cmd, cur_ctx, tok)
            if opt is not None and opt.kind == "value" and "=" not in tok:
                pending = opt
            continue
        if isinstance(cur_cmd, Group) and level_wants_sub:
            sub = cur_cmd.get_command(cur_ctx, tok)
            if sub is not None:
                cur_ctx = Context(sub, info_name=tok, parent=cur_ctx)
                cur_cmd = sub
                level_start = idx + 1
                pos_index = 0
                level_wants_sub = isinstance(sub, Group)
                continue
            level_wants_sub = False
            continue
        pos_index += 1

    _fill_parsed_params(cur_cmd, cur_ctx, tokens[level_start:])
    if pending is not None:
        return _param_items(cur_ctx, pending, incomplete)
    if incomplete.startswith("-"):
        items = []
        for p in cur_cmd.get_params(cur_ctx):
            if isinstance(p, Option) and not p.hidden:
                for flag in p.opts + p.secondary_opts:
                    if flag.startswith(incomplete):
                        items.append(CompletionItem(flag, help=p.help))
        return items
    if isinstance(cur_cmd, Group) and level_wants_sub:
        items = []
        for name in cur_cmd.list_commands(cur_ctx):
            sub = cur_cmd.get_command(cur_ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str()))
        return items
    args = [p for p in cur_cmd.params if isinstance(p, Argument)]
    if pos_index < len(args):
        return _param_items(cur_ctx, args[pos_index], incomplete)
    return []


def _format_lines(items, shell):
    lines = []
    for item in items:
        if item.type == "file":
            lines.append(f"@@file\t{item.value}")
        elif item.type == "dir":
            lines.append(f"@@dir\t{item.value}")
        elif item.help and shell in ("zsh", "fish"):
            help_text = " ".join(str(item.help).split())
            lines.append(f"{item.value}\t{help_text}")
        else:
            lines.append(str(item.value))
    return lines


def _complete(cmd, prog_name, shell):
    comp_words = os.environ.get("COMP_WORDS", "")
    comp_cword = os.environ.get("COMP_CWORD", "")
    words = comp_words.split(" ")
    if shell == "fish":
        incomplete = comp_cword
        tokens = words[1:]
        if tokens and tokens[-1] == incomplete:
            tokens = tokens[:-1]
    else:
        try:
            idx = int(comp_cword)
        except ValueError:
            idx = len(words)
        tokens = words[1:idx]
        incomplete = words[idx] if idx < len(words) else ""
    items = _collect(cmd, prog_name, tokens, incomplete, shell)
    text = "\n".join(_format_lines(items, shell))
    if text:
        text += "\n"
    sys.stdout.write(text)
    sys.stdout.flush()


def _source_script(prog_name, var, shell):
    name = os.path.basename(prog_name).replace("-", "_")
    prog = os.path.basename(prog_name)
    if shell == "bash":
        return (
            f"_{name}_completion() {{\n"
            "    local IFS=$'\\n'\n"
            "    local response\n"
            "    COMPREPLY=()\n"
            f"    response=$(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog})\n"
            "    for completion in $response; do\n"
            "        case \"$completion\" in\n"
            "            @@file*) COMPREPLY+=($(compgen -f -- \"${COMP_WORDS[COMP_CWORD]}\")) ;;\n"
            "            @@dir*) COMPREPLY+=($(compgen -d -- \"${COMP_WORDS[COMP_CWORD]}\")) ;;\n"
            "            *) COMPREPLY+=(\"${completion%%$'\\t'*}\") ;;\n"
            "        esac\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -o default -F _{name}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{name}_completion() {{\n"
            "    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}\")\n"
            "    _describe 'values' completions\n"
            "}\n"
            f"compdef _{name}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & '{prog}' | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        "}\n"
    )


def maybe_handle_completion(cmd, prog_name, complete_var, args, extra):
    """Handle the completion environment variable, exiting if it is set.

    # spec: FP-12 completion mode selection; Interface section 8
    """
    var = complete_var or _var_name(prog_name)
    instruction = os.environ.get(var)
    if not instruction:
        return
    for shell in SHELLS:
        if instruction == f"{shell}_source":
            sys.stdout.write(_source_script(prog_name, var, shell))
            sys.stdout.flush()
            sys.exit(0)
        if instruction == f"{shell}_complete":
            _complete(cmd, prog_name, shell)
            sys.exit(0)
    # unknown instruction: neither a script nor suggestions; the command does not run
    sys.exit(1)
