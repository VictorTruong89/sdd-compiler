"""Exception classes and their standalone-mode exit statuses.

# spec: N-000812..N-000821 (channels), N-000803..N-000806 (exit statuses)
"""

import difflib


class OptlynError(Exception):
    """Base class for errors that Optlyn reports to the user.

    Standalone mode prints ``show()`` output to standard error and exits with
    ``exit_code``.  Exit status 1 is the general-error class.
    """

    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)

    def __str__(self):
        return self.message


class FileError(OptlynError):
    """A file could not be opened when I/O started (general-error class)."""

    def __init__(self, filename, message):
        super().__init__(f"Could not open file '{filename}': {message}")
        self.filename = filename


class UsageError(OptlynError):
    """Incorrect usage of the command line (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = ctx.command if ctx is not None else None

    def show(self, file=None):
        from .utils import echo

        if self.ctx is not None:
            hint = ""
            help_names = self.ctx.help_option_names
            if help_names:
                hint = f"Try '{self.ctx.command_path} {help_names[0]}' for help.\n"
            echo(self.ctx.get_usage() + "\n" + hint, file=file, err=True, color=self.ctx.color)
        echo(f"Error: {self.format_message()}", file=file, err=True,
             color=self.ctx.color if self.ctx is not None else None)

    def format_message(self):
        return self.message


class BadParameter(UsageError):
    """A value was refused: bad conversion, failed check, or refused by a callback."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        if hint is None:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_type=None):
        super().__init__(message or "", ctx, param)
        self.param_type = param_type

    def format_message(self):
        if self.param is not None:
            kind = "option" if getattr(self.param, "param_type_name", "") == "option" else "argument"
            return f"Missing {kind} {self.param.get_error_hint(self.ctx)}."
        return self.message or "Missing parameter."


class NoSuchOption(UsageError):
    """An option name is not declared on the command."""

    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities or []

    def format_message(self):
        if not self.possibilities:
            return self.message
        if len(self.possibilities) == 1:
            return f"{self.message}\n\nDid you mean {self.possibilities[0]}?"
        possibilities = ", ".join(sorted(self.possibilities))
        return f"{self.message}\n\n(Possible options: {possibilities})"


class NoSuchCommand(UsageError):
    """A subcommand name is not known to the group."""

    def __init__(self, name, possibilities=None, ctx=None):
        msg = f"No such command '{name}'."
        if possibilities:
            if len(possibilities) == 1:
                msg += f"\n\nDid you mean {possibilities[0]}?"
            else:
                msg += "\n\n(Possible commands: " + ", ".join(sorted(possibilities)) + ")"
        super().__init__(msg, ctx)
        self.command_name = name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a missing value)."""

    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly (for example, too few tokens)."""

    def __init__(self, message, ctx=None):
        super().__init__(message, ctx)


class NoArgsIsHelpError(UsageError):
    """No arguments were given and the command shows help instead (usage class)."""

    def __init__(self, ctx):
        super().__init__(ctx.get_help(), ctx)

    def show(self, file=None):
        from .utils import echo

        echo(self.message, file=file, err=True, color=self.ctx.color)


class Abort(OptlynError):
    """The user or author aborted the run (exit status 1)."""

    def show(self, file=None):
        from .utils import echo

        echo("Aborted!", file=file, err=True)


class Exit(RuntimeError):
    """Author clean stop.  Carries the status to exit with."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


def did_you_mean(word, candidates, n=3):
    return difflib.get_close_matches(word, list(candidates), n=n, cutoff=0.5)
