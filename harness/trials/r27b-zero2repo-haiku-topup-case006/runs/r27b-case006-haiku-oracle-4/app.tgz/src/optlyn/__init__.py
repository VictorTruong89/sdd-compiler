"""Optlyn: composable command line interfaces.

Public names are re-exported here, as the Interface Contract (section 1) requires.
"""

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
    get_current_context,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, MissingParameter, OptlynError, UsageError
from .param_types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
)
from .utils import (
    echo,
    format_filename,
    get_binary_stream,
    get_text_stream,
    get_app_dir,
    open_file,
    secho,
    strip_ansi,
    style,
    unstyle,
)
from .formatting import wrap_text

__version__ = "0.1.0"

__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection", "Context",
    "Option", "Parameter", "ParamType", "BadParameter", "Abort", "UsageError",
    "MissingParameter", "OptlynError", "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path", "echo", "secho",
    "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar", "prompt", "confirm",
    "getchar", "pause", "edit", "launch", "clear", "get_app_dir", "get_current_context",
    "format_filename", "open_file", "get_binary_stream", "get_text_stream", "wrap_text", "ParameterSource", "Argument",
]
