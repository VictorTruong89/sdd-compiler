"""Text wrapping and the help-page formatter.

# spec: FP-02 (help layout, rewrap, backspace paragraphs), FP-11 (wrap_text), N-000680
"""

import re
import shutil
import textwrap
from contextlib import contextmanager

from .utils import strip_ansi

FORCED_WIDTH = None
DEFAULT_MAX_CONTENT_WIDTH = 80


def term_len(text):
    return len(strip_ansi(text))


def _wrap_paragraph(text, width, initial_indent="", subsequent_indent=""):
    text = " ".join(text.split())
    if not text:
        return initial_indent.rstrip()
    return textwrap.fill(
        text,
        width=max(width, 1),
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=True,
        break_on_hyphens=False,
    )


def wrap_text(text, width=78, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Wrap text to ``width``.  Accepts any string.

    Single newlines inside a paragraph are not preserved.  A paragraph whose first
    line is only a backspace character is not rewrapped; its line breaks are kept
    and the backspace line itself is removed.
    """
    text = str(text)
    paragraphs = re.split(r"\n\s*\n", text.strip("\n"))
    out = []
    first = True
    for para in paragraphs:
        if not para.strip():
            continue
        lines = para.split("\n")
        ind_first = initial_indent if first else subsequent_indent
        if lines[0] == "\b":
            kept = []
            for i, ln in enumerate(lines[1:]):
                prefix = ind_first if i == 0 else subsequent_indent
                kept.append(prefix + ln)
            out.append("\n".join(kept))
        elif preserve_paragraphs:
            out.append(_wrap_paragraph("\n".join(lines), width, ind_first, subsequent_indent))
        else:
            out.append(_wrap_paragraph(para, width, ind_first, subsequent_indent))
        first = False
    return "\n\n".join(out)


def measure_table(rows):
    widths = [0, 0]
    for a, b in rows:
        widths[0] = max(widths[0], term_len(a))
        widths[1] = max(widths[1], term_len(b))
    return widths


def make_default_short_help(text, max_length=45):
    """First sentence of a help text, ellipsized to fit ``max_length``."""
    text = (text or "").strip()
    if not text:
        return ""
    first_para = re.split(r"\n\s*\n", text)[0]
    flat = " ".join(first_para.split())
    m = re.search(r"[.!?](\s|$)", flat)
    if m:
        sentence = flat[: m.end() - len(m.group(1))]
    else:
        sentence = flat
    if len(sentence) > max_length:
        sentence = sentence[: max(max_length - 3, 0)].rstrip() + "..."
    return sentence


class HelpFormatter:
    """Accumulates the lines of a help page.

    # spec: FP-02 help page order; N-000827..N-000849
    """

    def __init__(self, indent_increment=2, width=None, max_width=None):
        self.indent_increment = indent_increment
        if max_width is None:
            max_width = DEFAULT_MAX_CONTENT_WIDTH
        if width is None:
            width = FORCED_WIDTH
        if width is None:
            cols = shutil.get_terminal_size((80, 20)).columns
            width = max(min(cols, max_width) - 2, 50)
        self.width = width
        self.current_indent = 0
        self.buffer = []

    def write(self, string):
        self.buffer.append(string)

    def indent(self):
        self.current_indent += self.indent_increment

    def dedent(self):
        self.current_indent -= self.indent_increment

    @contextmanager
    def indentation(self):
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    @contextmanager
    def section(self, name):
        self.write(f"{' ' * self.current_indent}{name}:\n")
        self.indent()
        try:
            yield
        finally:
            self.dedent()
        self.write("\n")

    def write_usage(self, prog, args="", prefix="Usage: "):
        usage_prefix = f"{prefix}{prog} "
        text_width = self.width - len(usage_prefix)
        if args and len(args) > text_width and " " in args:
            # keep the leading part of the usage on the first line
            indent = " " * len(usage_prefix)
            parts = args.split(" ")
            lines = []
            cur = ""
            for p in parts:
                cand = f"{cur} {p}" if cur else p
                if len(cand) > text_width and cur:
                    lines.append(cur)
                    cur = p
                else:
                    cur = cand
            if cur:
                lines.append(cur)
            body = (usage_prefix + lines[0]) + "\n"
            for ln in lines[1:]:
                body += indent + ln + "\n"
            self.write(body + "\n")
        else:
            self.write(f"{usage_prefix}{args}\n\n" if args else f"{prefix}{prog}\n\n")

    def write_text(self, text):
        indent = " " * self.current_indent
        width = max(self.width - self.current_indent, 10)
        self.write(wrap_text(text, width, initial_indent=indent,
                             subsequent_indent=indent, preserve_paragraphs=True))
        self.write("\n")

    def write_paragraph(self):
        text = "".join(self.buffer)
        if text and not text.endswith("\n\n"):
            self.write("\n")

    def write_dl(self, rows, col_max=30, col_spacing=2):
        rows = list(rows)
        if not rows:
            return
        first_col = min(max(term_len(a) for a, _ in rows), col_max) + col_spacing
        indent = " " * self.current_indent
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}\n")
                continue
            text_width = max(self.width - first_col - 2 - self.current_indent, 10)
            wrapped = wrap_text(second, text_width, preserve_paragraphs=True).splitlines() or [""]
            if term_len(first) <= first_col - col_spacing:
                pad = " " * (first_col - term_len(first))
                self.write(f"{indent}{first}{pad}{wrapped[0]}\n")
                rest = wrapped[1:]
            else:
                self.write(f"{indent}{first}\n")
                rest = wrapped
            for ln in rest:
                self.write(f"{indent}{' ' * first_col}{ln}\n")

    def getvalue(self):
        return "".join(self.buffer)
