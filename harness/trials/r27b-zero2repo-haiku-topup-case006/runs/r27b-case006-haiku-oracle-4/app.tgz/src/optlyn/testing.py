"""In-process runner: ``CliRunner``.  # spec: FP-14, Interface section 9

# spec: N-000800 (optlyn.testing exports CliRunner)
"""

import contextlib
import io
import os
import shutil
import sys
import tempfile

from .utils import strip_ansi  # noqa: F401


class _Log:
    def __init__(self):
        self.entries = []  # (tag, bytes) in write order


class _RecordingBuffer(io.BytesIO):
    def __init__(self, log, tag):
        super().__init__()
        self._log = log
        self._tag = tag

    def write(self, b):
        data = bytes(b)
        self._log.entries.append((self._tag, data))
        return super().write(data)


class _EchoStdin(io.TextIOWrapper):
    """Stdin that echoes exactly what was read into captured stdout."""

    _optlyn_runner = True
    _optlyn_echoes_input = True

    def __init__(self, buffer, encoding, outstream_getter):
        super().__init__(buffer, encoding=encoding)
        self._get_out = outstream_getter

    def _echo(self, text):
        if text:
            out = self._get_out()
            out.write(text)
            out.flush()

    def readline(self, size=-1):
        line = super().readline(size)
        self._echo(line)
        return line

    def read(self, size=-1):
        text = super().read(size)
        self._echo(text)
        return text


class _PlainStdin(io.TextIOWrapper):
    _optlyn_runner = True
    _optlyn_echoes_input = False


class Result:
    """Outcome of ``CliRunner.invoke``.  # spec: Interface section 9 (Result)"""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _decode(self, data):
        # echo falls back to UTF-8 on ASCII-only streams, so try the runner's charset,
        # then UTF-8, and only then replace undecodable bytes.
        for enc in (self.runner.charset, "utf-8"):
            try:
                return data.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        return data.decode("utf-8", "replace")

    @property
    def output(self):
        return self._decode(self.output_bytes)

    @property
    def stdout(self):
        return self._decode(self.stdout_bytes)

    @property
    def stderr(self):
        return self._decode(self.stderr_bytes)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command in-process and capture its output.  # spec: FP-14"""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        log = _Log()
        if self.capture == "sys":
            out_buf = _RecordingBuffer(log, "stdout")
            err_buf = _RecordingBuffer(log, "stderr")
            out = io.TextIOWrapper(out_buf, encoding=self.charset, write_through=True)
            err = io.TextIOWrapper(err_buf, encoding=self.charset, write_through=True)
            if self.echo_stdin:
                stdin = _EchoStdin(io.BytesIO(data), self.charset, lambda: out)
            else:
                stdin = _PlainStdin(io.BytesIO(data), encoding=self.charset)
            sys.stdin, sys.stdout, sys.stderr = stdin, out, err
            fd_files = None
        else:
            out_f = tempfile.TemporaryFile()
            err_f = tempfile.TemporaryFile()
            in_f = tempfile.TemporaryFile()
            in_f.write(data)
            in_f.seek(0)
            sys.stdout.flush()
            sys.stderr.flush()
            saved_fds = (os.dup(0), os.dup(1), os.dup(2))
            os.dup2(in_f.fileno(), 0)
            os.dup2(out_f.fileno(), 1)
            os.dup2(err_f.fileno(), 2)
            out = io.TextIOWrapper(out_f, encoding=self.charset, write_through=True)
            err = io.TextIOWrapper(err_f, encoding=self.charset, write_through=True)
            sys.stdin = _PlainStdin(io.BytesIO(data), encoding=self.charset)
            sys.stdout, sys.stderr = out, err
            fd_files = (out_f, err_f, in_f, saved_fds)
            out_buf = out_f
            err_buf = err_f

        class _Outputs:
            def stdout(self_inner):
                out.flush()
                if fd_files is None:
                    return out_buf.getvalue()
                out_f.seek(0)
                return out_f.read()

            def stderr(self_inner):
                err.flush()
                if fd_files is None:
                    return err_buf.getvalue()
                err_f.seek(0)
                return err_f.read()

            def combined(self_inner):
                if fd_files is None:
                    return b"".join(d for _, d in log.entries)
                return self_inner.stdout() + self_inner.stderr()

        try:
            yield _Outputs()
        finally:
            try:
                out.flush()
                err.flush()
            except Exception:
                pass
            sys.stdin, sys.stdout, sys.stderr = old_streams
            if fd_files is not None:
                out_f_, err_f_, in_f_, saved_fds = fd_files
                os.dup2(saved_fds[0], 0)
                os.dup2(saved_fds[1], 1)
                os.dup2(saved_fds[2], 2)
                for fd in saved_fds:
                    os.close(fd)
                in_f_.close()
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Run ``cli`` with argument tokens and capture the result.  # spec: FP-14"""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        extra.setdefault("color", color)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        exception = None
        exit_code = 0
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as outputs:
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if isinstance(code, int):
                    exit_code = code
                else:
                    sys.stdout.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                stdout = outputs.stdout()
                stderr = outputs.stderr()
                combined = outputs.combined()
        return Result(
            runner=self,
            stdout_bytes=stdout,
            stderr_bytes=stderr,
            output_bytes=combined,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory.  # spec: FP-14 isolated filesystem

        When no parent is given the directory is removed on exit; when a parent is
        given the directory is created under it and left in place.
        """
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
