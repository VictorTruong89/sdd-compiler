"""Parameter types and conversion.

# spec: FP-05 (built-in types, conversion rules), FP-09 (File, Path),
#       Interface Contract section 5 (ParamType and constructors)
"""

import datetime as _dt
import enum
import os
import pathlib
import stat
import sys
import uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement ``convert(value, param, ctx)``.
    # spec: Interface section 5, ParamType
    """

    name = "text"
    is_composite = False
    arity = 1

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses with ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"'{value}' is not a valid {self.name}.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeDecodeError:
                self.fail("bytes are not valid UTF-8.", param, ctx)
        return str(value) if not isinstance(value, str) else value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            if isinstance(value, float):
                if not value.is_integer():
                    raise ValueError
                return int(value)
            return int(str(value).strip())
        except ValueError:
            self.fail(f"'{value}' is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"'{value}' is not a valid float.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    TRUE = frozenset({"1", "true", "t", "yes", "y", "on"})
    FALSE = frozenset({"0", "false", "f", "no", "n", "off"})

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self.TRUE:
            return True
        if text in self.FALSE:
            return False
        self.fail(f"'{value}' is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"'{value}' is not a valid UUID value.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def _norm(value, ctx):
    fn = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    text = str(value)
    return fn(text) if fn is not None else text


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration.

    # spec: FP-05 Choice; Interface section 5 (case_sensitive default True)
    """

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [m.name for m in self.choices]
        else:
            self.choices = list(choices)
            self._keys = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(self._keys) + "]"

    def _cmp(self, text, ctx):
        text = _norm(text, ctx)
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if choice is value:
                return choice
        normed = self._cmp(value, ctx)
        for choice, key in zip(self.choices, self._keys):
            if self._cmp(key, ctx) == normed:
                return choice
        choices_str = ", ".join(repr(k) for k in self._keys)
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        out = []
        inc = incomplete if self.case_sensitive else incomplete.casefold()
        for key in self._keys:
            cmp_key = key if self.case_sensitive else key.casefold()
            if cmp_key.startswith(inc):
                out.append(CompletionItem(key))
        return out


class DateTime(ParamType):
    """Parses date-time text.  # spec: FP-05 date-time formats (first success wins)"""

    name = "datetime"
    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(f"'{value}' does not match the formats {', '.join(repr(f) for f in self.formats)}.",
                  param, ctx)


class _Range(ParamType):
    base = None
    label = "number"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        self.name = self.label

    def get_metavar(self, param):
        return None

    def _check(self, value, param, ctx):
        below = self.min is not None and (value < self.min or (self.min_open and value == self.min))
        above = self.max is not None and (value > self.max or (self.max_open and value == self.max))
        if not below and not above:
            return value
        if self.clamp:
            return self._clamped(value, below)
        lo = "" if self.min is None else (f"{'>' if self.min_open else '>='} {self.min}")
        hi = "" if self.max is None else (f"{'<' if self.max_open else '<='} {self.max}")
        parts = " and ".join(p for p in (lo, hi) if p)
        self.fail(f"{value} is not in the valid range of {parts}.", param, ctx)


class IntRange(_Range):
    """Integer in a range.  # spec: FP-05 integer range clamping"""

    base = INT
    label = "integer range"

    def _clamped(self, value, below):
        if below:
            if self.min_open:
                return self.min + 1
            return self.min
        if self.max_open:
            return self.max - 1
        return self.max

    def convert(self, value, param, ctx):
        value = self.base.convert(value, param, ctx)
        return self._check(value, param, ctx)


class FloatRange(_Range):
    """Float in a range.  Clamp needs both bounds closed.  # spec: FP-05 float range"""

    base = FLOAT
    label = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise TypeError("FloatRange clamp is only allowed when both bounds are closed.")
        super().__init__(min, max, min_open, max_open, clamp)

    def _clamped(self, value, below):
        return float(self.min if below else self.max)

    def convert(self, value, param, ctx):
        value = self.base.convert(value, param, ctx)
        return self._check(value, param, ctx)


class Tuple(ParamType):
    """Fixed-length product of inner types.  # spec: FP-05 Tuple"""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]
        self.arity = len(self.types)
        self.name = "<" + " ".join(t.name.upper() for t in self.types) + ">"

    def get_metavar(self, param):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, str) or not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"'{value}' must be a sequence of {len(self.types)} values.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, value))


def _as_path_str(value):
    if isinstance(value, bytes):
        return os.fsdecode(value)
    return os.fspath(value) if hasattr(value, "__fspath__") else str(value)


class File(ParamType):
    """An open file.  # spec: FP-09 file parameter"""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def get_metavar(self, param):
        return "FILENAME"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]

    def convert(self, value, param, ctx):
        from .utils import LazyFile, _NonClosing, _open_raw

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        text = _as_path_str(value)
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        if text == "-":
            stream = sys.stdin if "r" in self.mode else sys.stdout
            if "b" in self.mode:
                stream = getattr(stream, "buffer", stream)
            return _NonClosing(stream)
        try:
            if lazy:
                f = LazyFile(text, self.mode, self.encoding, self.errors, self.atomic)
                if "r" in self.mode:
                    f._open()  # reading a lazy file still reports a missing file here
            else:
                f = _open_raw(text, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as e:
            self.fail(f"'{text}': {e.strerror or e}", param, ctx)
        except Exception as e:  # FileError from a lazy read
            self.fail(f"'{text}': {getattr(e, 'message', str(e))}", param, ctx)
        if ctx is not None and hasattr(ctx, "call_on_close"):
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """A filesystem path (not an open file).  # spec: FP-09 path parameter"""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def get_metavar(self, param):
        return "PATH"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]

    def _finish(self, rv):
        if self.path_type is not None and self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def convert(self, value, param, ctx):
        rv = _as_path_str(value)
        if self.allow_dash and rv == "-":
            return self._finish(rv)
        if self.resolve_path:
            rv = os.path.realpath(os.path.abspath(rv))
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._finish(rv)
            self.fail(f"'{value}' does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"'{value}' is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"'{value}' is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"'{value}' is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"'{value}' is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"'{value}' is not executable.", param, ctx)
        return self._finish(rv)


def convert_type(ty, default=None):
    """Resolve a type argument (or infer one from a default).

    # spec: FP-03 type inference from defaults; Interface section 5
    """
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is None:
        if default is None or callable(default):
            return STRING
        if isinstance(default, (list, tuple)):
            if default:
                return convert_type(None, default[0])
            return STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        return STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is uuid.UUID:
        return UUID
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")
