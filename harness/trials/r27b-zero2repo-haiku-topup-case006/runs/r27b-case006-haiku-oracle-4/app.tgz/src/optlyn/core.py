"""Core objects: invocation context, parameters, parser, commands and groups.

# spec: FP-01 (commands), FP-02 (help), FP-03 (options), FP-04 (arguments),
#       FP-06 (groups), FP-07 (context/defaults/env), FP-08 (prompts),
#       FP-10 (chaining), FP-13 (exit statuses); Interface sections 3, 4, 6
"""

import contextlib
import difflib
import inspect
import itertools
import os
import sys
import threading
from enum import Enum

from . import param_types as _types
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
    did_you_mean,
)
from .formatting import HelpFormatter, make_default_short_help, wrap_text
from .utils import echo, format_filename  # noqa: F401  (re-export convenience)

_param_counter = itertools.count()
_local = threading.local()
INF = float("inf")


class ParameterSource(Enum):
    """Where a parameter's value came from.  # spec: FP-07 five distinct sources"""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 4,
    ParameterSource.COMMANDLINE: 3,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 1,
    ParameterSource.DEFAULT: 0,
    None: 0,
}


class _ChainMarker:
    """Value of ``ctx.invoked_subcommand`` on a chaining group (neither None nor a name)."""

    def __repr__(self):
        return "<chain>"


CHAIN_SUBCOMMAND = _ChainMarker()


class _Literal(str):
    """A token that followed ``--``; it is never treated as an option."""


class _NeedsValue:
    def __repr__(self):
        return "<needs-value>"


_NEEDS_VALUE = _NeedsValue()

_TRUE_TOKENS = frozenset({"1", "true", "t", "yes", "y", "on"})
_FALSE_TOKENS = frozenset({"0", "false", "f", "no", "n", "off"})


def _stack():
    st = getattr(_local, "stack", None)
    if st is None:
        st = _local.stack = []
    return st


def get_current_context(silent=False):
    """Return the context current on this thread.  # spec: Interface section 6"""
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


@contextlib.contextmanager
def augment_usage_errors(ctx, param=None):
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
            e.cmd = ctx.command if ctx is not None else None
        raise


def _split_opt(opt):
    first = opt[:1]
    if first.isalnum() or not first:
        return "", opt
    if opt[1:2] == first:
        return opt[:2], opt[2:]
    return first, opt[1:]


def _parse_param_decls(decls, is_option, expose_value):
    """Return (name, opts, secondary_opts).  # spec: FP-03 destination inference"""
    opts, secondary, name = [], [], None
    for decl in decls:
        if not isinstance(decl, str):
            raise TypeError(f"Parameter declarations must be strings, got {decl!r}.")
        if decl.isidentifier():
            if name is not None:
                raise TypeError("Name defined twice.")
            name = decl
            continue
        if not is_option:
            if decl and decl[0] in "-/+" or "/" in decl:
                raise TypeError(f"Arguments take a name only, got {decl!r}.")
            name = decl.replace("-", "_") if name is None else name
            if not name.isidentifier():
                raise TypeError(f"Invalid argument name {decl!r}.")
            continue
        idx = decl.find("/", 1)
        pieces = [(decl[:idx], opts), (decl[idx + 1:], secondary)] if idx > 0 else [(decl, opts)]
        for piece, bucket in pieces:
            prefix, nm = _split_opt(piece)
            if not prefix or not nm:
                if piece.isidentifier():
                    if name is not None:
                        raise TypeError("Name defined twice.")
                    name = piece
                    continue
                raise TypeError(f"Invalid option declaration {piece!r}.")
            if len(prefix) == 1 and len(nm) != 1:
                raise TypeError(
                    f"Short option names must be a single character, got {piece!r}."
                )
            if len(prefix) == 2 and prefix[0] != prefix[1]:
                raise TypeError(f"Invalid option declaration {piece!r}.")
            bucket.append(piece)
    if name is None and expose_value and opts:
        longs = [o for o in opts if len(_split_opt(o)[0]) == 2]
        chosen = longs[0] if longs else opts[0]
        name = _split_opt(chosen)[1].replace("-", "_")
        if not name.isidentifier():
            raise TypeError(f"Could not determine a name from {chosen!r}; give one explicitly.")
    if name is None and expose_value:
        raise TypeError("Could not determine a name for the parameter; give one explicitly.")
    return name, opts, secondary


class Parameter:
    """Common base of options and arguments.

    # spec: FP-03, FP-04, Interface section 4 (parameters)
    """

    param_type_name = "parameter"
    kind_name = "parameter"

    def __init__(self, param_decls=(), type=None, required=False, default=None, callback=None,
                 nargs=None, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, help=None, hidden=False,
                 is_option=False):
        self.name, self.opts, self.secondary_opts = _parse_param_decls(
            tuple(param_decls), is_option, expose_value
        )
        self._order = next(_param_counter)
        self.type = _types.convert_type(type, default)
        if nargs is None:
            nargs = self.type.arity if self.type.is_composite else 1
        if isinstance(self.type, _types.Tuple):
            nargs = self.type.arity
        if not isinstance(nargs, int) or (nargs < 1 and nargs != -1):
            raise TypeError("nargs must be a positive integer, or -1 for variadic.")
        self.nargs = nargs
        self.required = required
        self.default = default
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar is not None else None
        self._shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self._explicit_default = default is not None

    # ------------------------------------------------------------ naming
    def get_error_hint(self, ctx=None):
        raise NotImplementedError

    def make_metavar(self):
        raise NotImplementedError

    # ------------------------------------------------------------ defaults
    def get_default(self, ctx, call=True):
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    def _env_names(self, ctx):
        return self.envvar or []

    # ------------------------------------------------------------ conversion
    def _cast_single(self, ctx, value):
        if self.type.is_composite or (self.nargs == 1 and self.nargs != -1):
            return self.type(value, self, ctx)
        if isinstance(value, str) or not isinstance(value, (list, tuple)):
            raise BadParameter(f"'{value}' needs a sequence of {self.nargs} values.", ctx, self)
        if self.nargs > 0 and len(value) != self.nargs:
            raise BadParameter(f"requires {self.nargs} values, got {len(value)}.", ctx, self)
        return tuple(self.type(v, self, ctx) for v in value)

    def type_cast_value(self, ctx, value):
        if value is None:
            return None
        if self.multiple:
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    f"needs an iterable (sequence) default of values; '{value}' is not one.",
                    ctx, self,
                )
            return tuple(self._cast_single(ctx, v) for v in value)
        return self._cast_single(ctx, value)

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.multiple or self.nargs != 1) and value == ():
            return True
        return False

    def process_value(self, ctx, value):
        value = self.type_cast_value(ctx, value)
        if value is None and (self.multiple or self.nargs == -1):
            value = ()
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def _split_env(self, text):
        if self.nargs == 1 and not self.multiple:
            return text
        tokens = self.type.split_envvar_value(text)
        if self.multiple and self.nargs == 1:
            return list(tokens)
        if self.multiple:
            return [tuple(tokens[i:i + self.nargs]) for i in range(0, len(tokens), self.nargs)]
        return tuple(tokens)

    def consume_value(self, ctx, raw):  # pragma: no cover - overridden
        raise NotImplementedError

    def handle_parse_result(self, ctx, raw):
        """Resolve, convert and store one parameter.  # spec: FP-03 value sources"""
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, raw)
            value = self.process_value(ctx, value)
        if self.deprecated and source is ParameterSource.COMMANDLINE:
            self._warn_deprecated(ctx)
        if self.expose_value:
            rank = (_SOURCE_RANK.get(source, 0), 1 if self._explicit_default else 0, self._order)
            prev = ctx._dest_ranks.get(self.name)
            if prev is None or rank >= prev:
                ctx.params[self.name] = value
                ctx._dest_ranks[self.name] = rank
                ctx._sources[self.name] = source
        return value

    def _warn_deprecated(self, ctx):
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        msg = f"DeprecationWarning: The {self.param_type_name} {self.get_error_hint(ctx)} is deprecated."
        if note:
            msg += " " + note
        echo(msg, err=True)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter.  # spec: FP-03, Interface section 4 (option)"""

    param_type_name = "option"

    def __init__(self, param_decls=(), show_default=None, prompt=None, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None,
                 count=False, allow_from_autoenv=True, show_envvar=False, show_choices=True,
                 **attrs):
        multiple = attrs.pop("multiple", False)
        default = attrs.get("default")
        required = attrs.get("required", False)
        deprecated = attrs.get("deprecated", False)
        self.prompt = prompt if prompt else None  # True, or the question text
        if count and multiple:
            raise TypeError("'count' is mutually exclusive with 'multiple'.")
        if is_flag is None:
            if flag_value is not None:
                is_flag = True
            elif self.prompt is not None and not prompt_required:
                is_flag = False
            else:
                is_flag = bool(self.secondary_opts_from(param_decls))
        if is_flag and multiple:
            raise TypeError("'multiple' and 'is_flag' are mutually exclusive.")
        if is_flag and count:
            raise TypeError("'count' and 'is_flag' are mutually exclusive.")
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        auto_default = False
        if self.is_flag and default is None and not required:
            default = False
            auto_default = True
        if self.count and default is None:
            default = 0
        if attrs.get("type") is None:
            if self.is_flag:
                attrs["type"] = _types.convert_type(None, flag_value)
            elif self.count:
                attrs["type"] = _types.INT
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and self.prompt is not None:
            raise TypeError("A deprecated option cannot use a prompt.")
        attrs["default"] = default
        attrs["multiple"] = multiple
        if self.is_flag and attrs.get("nargs") not in (None, 1):
            raise TypeError("A flag takes no values.")
        if attrs.get("nargs") == -1:
            raise TypeError("Options cannot be variadic; use nargs >= 1.")
        super().__init__(param_decls, is_option=True, **attrs)
        self._explicit_default = not auto_default and default is not None
        if self.type.is_composite and attrs.get("nargs") not in (None, self.type.arity):
            raise TypeError("nargs does not match the Tuple type arity.")
        if self.count:
            self.nargs = 1
        if self.is_flag and self.nargs != 1:
            raise TypeError("A flag takes no values.")
        if self.prompt is not None:
            if isinstance(prompt, str):
                self.prompt_text = prompt
            else:
                self.prompt_text = (self.name or "value").replace("_", " ").capitalize()
        else:
            self.prompt_text = None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.allow_from_autoenv = allow_from_autoenv
        self.secondary_flag_value = False  # the "off" value of an on/off pair
        self.kind = (
            "count" if self.count else "flag" if self.is_flag
            else "optvalue" if self.flag_value is not None else "value"
        )

    def get_help_record(self, ctx):
        """(first column, second column) for the Options section.  # spec: FP-02"""
        if self.hidden:
            return None
        first = ", ".join(self.opts)
        if self.secondary_opts:
            first = f"{first} / {', '.join(self.secondary_opts)}"
        metavar = self.make_metavar(ctx)
        if metavar:
            first = f"{first} {metavar}"
        parts = []
        if self.help:
            parts.append(self.help)
        show_default = self.show_default if self.show_default is not None else ctx.show_default
        hidden_flag_default = self.is_flag and not self.default and not callable(self.default)
        if show_default and not hidden_flag_default:
            if isinstance(show_default, str):
                shown = show_default
            elif callable(self.default):
                shown = "(dynamic)"
            elif self.default is None:
                shown = None
            elif isinstance(self.default, (list, tuple)):
                shown = ", ".join(str(x) for x in self.default)
            else:
                shown = str(self.default)
            if shown is not None:
                parts.append(f"[default: {shown}]")
        if self.show_envvar:
            names_env = self._env_names(ctx)
            if names_env:
                parts.append(f"[env var: {names_env[0]}]")
        if isinstance(self.type, _types.Choice) and self.show_choices and self.metavar is not None:
            # the default metavar already lists the choices; list them when it is overridden
            parts.append("[choices: " + ", ".join(self.type._keys) + "]")
        if self.required:
            parts.append("[required]")
        if self.deprecated:
            parts.append("(deprecated)")
        return first, " ".join(parts)

    @staticmethod
    def secondary_opts_from(decls):
        return any("/" in d[1:] for d in decls if isinstance(d, str))

    # ------------------------------------------------------------ names
    def get_error_hint(self, ctx=None):
        return " / ".join(f"'{o}'" for o in self.opts) if self.opts else f"'{self.name}'"

    @property
    def human_name(self):
        return self.opts[0] if self.opts else self.name

    def make_metavar(self, ctx=None):
        if self.is_flag or self.count:
            return None
        if self.metavar is not None:
            base = self.metavar
        else:
            base = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs != 1 and not self.type.is_composite:
            return " ".join([base] * self.nargs)
        return base

    # ------------------------------------------------------------ values
    def _auto_env_name(self, ctx):
        if not self.allow_from_autoenv or not ctx.auto_envvar_prefix:
            return None
        return ctx.auto_envvar_name(self.name)

    def _env_names(self, ctx):
        # explicit names first, then the automatic prefix-built name  # spec: FP-07
        names = list(self.envvar or [])
        auto = self._auto_env_name(ctx)
        if auto and auto not in names:
            names.append(auto)
        return names

    def _flag_from_env(self, text):
        t = text.strip().lower()
        if isinstance(self.flag_value, bool):
            if t in _TRUE_TOKENS:
                return True
            if t in _FALSE_TOKENS or t == "":
                return False
            raise BadParameter(f"'{text}' is not a valid boolean.", None, self)
        if text.strip() == str(self.flag_value):
            return self.flag_value
        if t in _TRUE_TOKENS:
            return self.flag_value
        if t in _FALSE_TOKENS:
            return False
        return None  # unrecognized: unset, the next source wins

    def _read_env(self, ctx):
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                val = self._flag_from_env(raw)
                if val is None:
                    continue
                return name, val
            return name, self._split_env(raw)
        return None, None

    def _prompt_for_value(self, ctx, default):
        from .termui import confirm, prompt

        if self.is_flag and isinstance(self.flag_value, bool):
            return confirm(self.prompt_text, default=bool(default))
        return prompt(
            self.prompt_text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
            show_default=self.show_default is not False,
        )

    def consume_value(self, ctx, raw):
        value, source = None, None
        if raw is not None:
            source = ParameterSource.COMMANDLINE
            if raw is _NEEDS_VALUE:
                if self.prompt is not None and not ctx.resilient_parsing:
                    value = self._prompt_for_value(ctx, self.get_default(ctx))
                    source = ParameterSource.PROMPT
                else:
                    value = self.flag_value
            elif self.multiple:
                value = []
                for v in raw:
                    if v is _NEEDS_VALUE:
                        v = self.flag_value
                    value.append(v)
            else:
                value = raw
        if source is None:
            _name, env = self._read_env(ctx)
            if env is not None:
                value, source = env, ParameterSource.ENVIRONMENT
        if source is None and ctx.default_map is not None and self.name in ctx.default_map:
            dm = ctx.default_map.get(self.name)
            if callable(dm):
                dm = dm()
            if dm is not None:
                if isinstance(dm, str) and (self.multiple or self.nargs != 1 or self.type.is_composite):
                    if self.multiple and self.nargs == 1:
                        raise BadParameter(
                            f"needs an iterable (sequence) default; '{dm}' is not one.", ctx, self
                        )
                    dm = self._split_env(dm)
                value, source = dm, ParameterSource.DEFAULT_MAP
        if source is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
            if self.multiple and isinstance(value, str):
                raise BadParameter(
                    f"needs an iterable (sequence) default; '{value}' is not one.", ctx, self
                )
        if self.prompt is not None and not ctx.resilient_parsing \
                and source in (None, ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP) \
                and (self.required or self.prompt_required):
            default = value if source is ParameterSource.DEFAULT_MAP else self.get_default(ctx)
            value = self._prompt_for_value(ctx, default)
            source = ParameterSource.PROMPT
        if value is None and self.multiple:
            value = ()
        return value, source


class Argument(Parameter):
    """A positional parameter.  # spec: FP-04, Interface section 4 (argument)"""

    param_type_name = "argument"

    def __init__(self, param_decls=(), required=None, **attrs):
        default = attrs.get("default")
        nargs = attrs.get("nargs")
        if nargs is None:
            nargs = 1
        if required is None:
            required = default is None and nargs != -1
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        attrs["nargs"] = nargs
        super().__init__(param_decls, required=required, is_option=False, **attrs)
        self.kind = "argument"

    def get_error_hint(self, ctx=None):
        return f"'{self.make_metavar()}'"

    def make_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def usage_placeholder(self):
        base = self.make_metavar()
        if self.nargs == -1:
            base = f"{base}..."
        if not self.required:
            base = f"[{base}]"
        return base

    def consume_value(self, ctx, raw):
        value, source = None, None
        if raw is not None:
            source = ParameterSource.COMMANDLINE
            value = raw[0] if self.nargs == 1 else tuple(raw)
        if source is None and self.envvar:
            for name in self.envvar:
                text = os.environ.get(name)
                if text:
                    value = text if (self.nargs == 1 and not self.multiple) else self._split_env(text)
                    source = ParameterSource.ENVIRONMENT
                    break
        if source is None and ctx.default_map is not None and self.name in ctx.default_map:
            dm = ctx.default_map.get(self.name)
            if dm is not None:
                if isinstance(dm, str) and self.nargs != 1:
                    dm = self._split_env(dm)
                value, source = dm, ParameterSource.DEFAULT_MAP
        if source is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
        return value, source


# ============================================================ parsing

class _OptionParser:
    """Left-to-right option parser.  # spec: FP-03 POSIX-style parsing"""

    def __init__(self, ctx, options, allow_interspersed, ignore_unknown):
        self.ctx = ctx
        self.allow_interspersed = allow_interspersed
        self.ignore_unknown = ignore_unknown
        self.map = {}
        self.prefixes = {"-"}
        for p in options:
            for flag in p.opts:
                self._add(flag, p, p.kind)
            for flag in p.secondary_opts:
                self._add(flag, p, "secondary")

    def _norm(self, flag):
        fn = self.ctx.token_normalize_func
        return fn(flag) if fn is not None else flag

    def _add(self, flag, param, kind):
        self.prefixes.add(flag[0])
        self.map[self._norm(flag)] = (param, kind)

    def _option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes and not isinstance(tok, _Literal)

    def _lookup(self, flag):
        return self.map.get(self._norm(flag))

    def _store(self, param, value, state, order):
        if param not in order:
            order[param] = len(order)
        if param.count:
            state[param] = state.get(param, 0) + 1
        elif param.multiple:
            state.setdefault(param, []).append(value)
        else:
            state[param] = value

    def _consume(self, param, kind, flag, attached, args, i, state, order):
        if kind in ("flag", "secondary"):
            if attached is not None:
                raise BadOptionUsage(flag, f"Option '{flag}' does not take a value.", self.ctx)
            value = param.flag_value if kind == "flag" else param.secondary_flag_value
            self._store(param, value, state, order)
            return i
        if kind == "count":
            if attached is not None:
                raise BadOptionUsage(flag, f"Option '{flag}' does not take a value.", self.ctx)
            self._store(param, 1, state, order)
            return i
        if kind == "optvalue" and attached is None:
            if i < len(args) and not self._option_like(args[i]):
                self._store(param, args[i], state, order)
                return i + 1
            self._store(param, _NEEDS_VALUE if param.prompt is not None else param.flag_value,
                        state, order)
            return i
        toks = [] if attached is None else [attached]
        while len(toks) < param.nargs and i < len(args):
            toks.append(args[i])
            i += 1
        if len(toks) < param.nargs:
            if not toks and param.prompt is not None:
                self._store(param, _NEEDS_VALUE, state, order)
                return i
            if self.ctx.resilient_parsing:
                return i
            if param.nargs == 1:
                raise BadOptionUsage(flag, f"Option '{flag}' requires an argument.", self.ctx)
            raise BadOptionUsage(
                flag, f"Option '{flag}' requires {param.nargs} arguments.", self.ctx
            )
        value = toks[0] if param.nargs == 1 else tuple(toks)
        self._store(param, value, state, order)
        return i

    def _unknown(self, flag):
        if self.ignore_unknown or self.ctx.resilient_parsing:
            return None
        possibilities = did_you_mean(flag, [k for k in self.map if k[:1] == flag[:1]])
        raise NoSuchOption(flag, f"No such option: {flag}", possibilities, self.ctx)

    def _handle(self, tok, args, i, state, order, largs):
        pc = tok[0]
        if tok[1] == pc:
            name, eq, val = tok[2:].partition("=")
            flag = pc * 2 + name
            found = self._lookup(flag)
            if found is None:
                if self.ignore_unknown:
                    largs.append(tok)
                    return i
                self._unknown(flag)
                return i
            param, kind = found
            attached = val if eq else None
            return self._consume(param, kind, flag, attached, args, i, state, order)
        body = tok[1:]
        j = 0
        while j < len(body):
            flag = pc + body[j]
            found = self._lookup(flag)
            if found is None:
                if self.ignore_unknown:
                    largs.append(pc + body[j:])
                    return i
                self._unknown(flag)
                return i
            param, kind = found
            if kind in ("flag", "secondary", "count"):
                self._consume(param, kind, flag, None, args, i, state, order)
                j += 1
                continue
            rest = body[j + 1:]
            return self._consume(param, kind, flag, rest if rest else None, args, i, state, order)
        return i

    def parse(self, args):
        state, order, largs = {}, {}, []
        i, n = 0, len(args)
        dd = False
        while i < n:
            tok = args[i]
            i += 1
            if isinstance(tok, _Literal):
                largs.append(tok)
                continue
            if dd:
                largs.append(_Literal(tok))
                continue
            if tok == "--":
                dd = True
                continue
            if not self.allow_interspersed and largs:
                largs.append(tok)
                continue
            if self._option_like(tok):
                i = self._handle(tok, args, i, state, order, largs)
            else:
                largs.append(tok)
        return state, order, largs


# ============================================================ context

class Context:
    """Per-invocation state.  # spec: FP-07, Interface section 6"""

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 help_option_names=None, token_normalize_func=None, color=None,
                 show_default=None, allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, resilient_parsing=False, meta=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self._sources = {}
        self._dest_ranks = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self.meta = dict(meta or {})
        self._close_callbacks = []
        self._exit_stack = contextlib.ExitStack()
        self._depth = 0
        if parent is not None:
            if obj is None:
                obj = parent.obj
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if auto_envvar_prefix is None:
                auto_envvar_prefix = parent.auto_envvar_prefix
        self.obj = obj
        if default_map is None and info_name is not None and parent is not None \
                and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width
        self.help_option_names = list(help_option_names) if help_option_names is not None else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default) if show_default is not None else False
        self.auto_envvar_prefix = auto_envvar_prefix
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_extra_args = bool(allow_extra_args)
        self.allow_interspersed_args = bool(allow_interspersed_args)
        self.ignore_unknown_options = bool(ignore_unknown_options)

    # ------------------------------------------------------------ tree
    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def auto_envvar_name(self, dest):
        names = []
        node = self
        while node.parent is not None:
            names.append(node.info_name or "")
            node = node.parent
        parts = [self.auto_envvar_prefix] + list(reversed(names)) + [dest]
        return "_".join(p for p in parts if p).replace("-", "_").upper()

    def lookup_default(self, name, call=True):
        if self.default_map is not None:
            value = self.default_map.get(name)
            if call and callable(value):
                value = value()
            return value
        return None

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.get_params(self) if p.name is not None}
        if name not in declared:
            return None
        return self._sources.get(name)

    # ------------------------------------------------------------ lifecycle
    def make_formatter(self):
        return HelpFormatter(width=self.terminal_width, max_width=self.max_content_width)

    def get_help(self):
        formatter = self.make_formatter()
        self.command.format_help(self, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_usage(self):
        formatter = self.make_formatter()
        self.command.format_usage(self, formatter)
        return formatter.getvalue().rstrip("\n")

    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def call_on_close(self, f):
        self._close_callbacks.append(f)
        return f

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for f in reversed(callbacks):
            try:
                f()
            except Exception:
                pass
        try:
            self._exit_stack.close()
        finally:
            self._exit_stack = contextlib.ExitStack()

    def __enter__(self):
        self._depth += 1
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        st = _stack()
        for idx in range(len(st) - 1, -1, -1):
            if st[idx] is self:
                del st[idx]
                break
        if self._depth == 0:
            self.close()
        return False

    @contextlib.contextmanager
    def scope(self, cleanup=True):
        if not cleanup:
            self._depth += 1
        try:
            with self:
                yield self
        finally:
            if not cleanup:
                self._depth -= 1

    # ------------------------------------------------------------ dispatch
    def invoke(self, callback, /, *args, **kwargs):
        """Call a callback, or run a Command with explicit values.

        # spec: FP-07 invoke/forward; Interface section 6
        """
        if isinstance(callback, Command):
            other = callback
            callback = other.callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name is not None and param.expose_value and param.name not in kwargs:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            ctx = self
        with augment_usage_errors(self):
            with ctx:
                return callback(*args, **kwargs)

    def forward(self, cmd, /, *args, **kwargs):
        kwargs = {**self.params, **kwargs}
        return self.invoke(cmd, *args, **kwargs)


# ============================================================ commands

def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _clean_docstring(text):
    if text is None:
        return None
    text = inspect.cleandoc(text)
    return text


class Command:
    """A leaf command.  # spec: FP-01, Interface section 3 (command)"""

    allow_extra_args = False
    allow_interspersed_args = True
    _is_multi = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = _clean_docstring(callback.__doc__)
        if help is not None:
            help = help.split("\f", 1)[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self._check_variadic()

    def _check_variadic(self):
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # ------------------------------------------------------------ params
    def get_help_option_names(self, ctx):
        declared = set()
        for p in self.params:
            declared.update(p.opts)
            declared.update(p.secondary_opts)
        return [n for n in ctx.help_option_names if n not in declared]

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        names = self.get_help_option_names(ctx)
        if not names:
            return None
        return Option(
            names, is_flag=True, is_eager=True, expose_value=False,
            callback=_show_help_callback, help="Show this message and exit.",
        )

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    # ------------------------------------------------------------ contexts
    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        try:
            with ctx.scope(cleanup=False):
                self.parse_args(ctx, args)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        parser = _OptionParser(ctx, options, ctx.allow_interspersed_args,
                               ctx.ignore_unknown_options)
        state, order, largs = parser.parse(list(args))
        tokens, largs = self._distribute_arguments(ctx, arguments, largs)
        for idx, arg in enumerate(arguments):
            if tokens.get(arg) is not None:
                order.setdefault(arg, 10 ** 6 + idx)
        def sort_key(p):
            return (not p.is_eager, order.get(p, INF), p._order)
        for param in sorted(params, key=sort_key):
            if isinstance(param, Argument):
                raw = tokens.get(param)
            else:
                raw = state.get(param)
            param.handle_parse_result(ctx, raw)
        if largs and not ctx.resilient_parsing:
            if not ctx.allow_extra_args and not self._is_multi:
                ctx.fail(f"Got unexpected extra argument{'s' if len(largs) > 1 else ''} "
                         f"({' '.join(str(a) for a in largs)})")
            if not self._is_multi and not ctx.ignore_unknown_options:
                bad = [a for a in largs if not isinstance(a, _Literal) and len(a) > 1
                       and a[0] in "-/+"]
                if bad:
                    ctx.fail(f"Got unexpected extra argument{'s' if len(bad) > 1 else ''} "
                             f"({' '.join(str(a) for a in bad)})")
        ctx.args = list(largs)
        return ctx.args

    def _distribute_arguments(self, ctx, arguments, largs):
        remaining = list(largs)
        tokens = {}
        for idx, arg in enumerate(arguments):
            if arg.nargs == -1:
                later = sum(a.nargs for a in arguments[idx + 1:] if a.nargs > 0)
                take = max(len(remaining) - later, 0)
                chunk = remaining[:take]
                remaining = remaining[take:]
                tokens[arg] = [str(x) for x in chunk] if chunk else None
                continue
            chunk = remaining[: arg.nargs]
            if len(chunk) < arg.nargs:
                if chunk:
                    raise BadArgumentUsage(
                        f"Argument '{arg.make_metavar()}' takes {arg.nargs} values.", ctx
                    )
                tokens[arg] = None
                continue
            remaining = remaining[arg.nargs:]
            tokens[arg] = [str(x) for x in chunk]
        return tokens, remaining

    # ------------------------------------------------------------ running
    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            msg = f"DeprecationWarning: The command '{self.name}' is deprecated."
            echo((msg + " " + note) if note else msg, err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        """Run the command.  # spec: Interface section 3; FP-13 exit statuses"""
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_prog_name()

        from .shell_completion import maybe_handle_completion

        maybe_handle_completion(self, prog_name, complete_var, args, extra)

        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except Exit as e:
                if standalone_mode:
                    sys.exit(e.exit_code)
                return e.exit_code
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    # ------------------------------------------------------------ help
    def collect_usage_pieces(self, ctx):
        rv = []
        if any(isinstance(p, Option) for p in self.get_params(ctx)):
            rv.append(self.options_metavar)
        for p in self.params:
            if isinstance(p, Argument):
                rv.append(p.usage_placeholder())
        return rv

    def format_usage(self, ctx, formatter):
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def format_help_text(self, ctx, formatter):
        text = self.help or ""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            mark = "(Deprecated)" + (f" {note}" if note else "")
            text = f"{text}\n\n{mark}" if text else mark
        if text:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(text)

    def _argument_rows(self, ctx):
        rows = []
        for p in self.params:
            if isinstance(p, Argument) and p.help:
                rows.append((p.usage_placeholder().strip("[]"), p.help))
        return rows

    def format_options(self, ctx, formatter):
        rows = self._argument_rows(ctx)
        if rows:
            formatter.write_paragraph()
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)
        opt_rows = []
        for p in self.get_params(ctx):
            if isinstance(p, Option) and not p.hidden:
                opt_rows.append(p.get_help_record(ctx))
        opt_rows = [r for r in opt_rows if r is not None]
        if opt_rows:
            formatter.write_paragraph()
            with formatter.section("Options"):
                formatter.write_dl(opt_rows)

    def format_extra(self, ctx, formatter):
        pass

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_extra(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        return make_default_short_help(self.help or "", max_length=limit)


def _detect_prog_name():
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0]) or "root"
    return "root"


class Group(Command):
    """A command that dispatches to named subcommands.  # spec: FP-06, FP-10"""

    allow_extra_args = True
    allow_interspersed_args = False
    _is_multi = True

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.commands = {}
        if commands:
            if isinstance(commands, dict):
                for n, c in commands.items():
                    self.add_command(c, n)
            else:
                for c in commands:
                    self.add_command(c)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar or "COMMAND"
        self.chain = chain
        self._result_callback = result_callback

    # ------------------------------------------------------------ registry
    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("Command has no name.")
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be attached beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    # ------------------------------------------------------------ parsing
    def parse_args(self, ctx, args):
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = []
            ctx.args = list(rest)
        else:
            ctx.protected_args = list(rest[:1])
            ctx.args = list(rest[1:])
        if not rest and not self.invoke_without_command:
            ctx.fail("Missing command.")
        return ctx.args

    def resolve_command(self, ctx, args):
        cmd_name = str(args[0])
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            norm = ctx.token_normalize_func(cmd_name)
            for n in self.list_commands(ctx):
                if ctx.token_normalize_func(n) == norm:
                    cmd_name, cmd = n, self.get_command(ctx, n)
                    break
        if cmd is None:
            raise NoSuchCommand(cmd_name, did_you_mean(cmd_name, self.list_commands(ctx)), ctx)
        return cmd_name, cmd, list(args[1:])

    # ------------------------------------------------------------ running
    def _process_result(self, ctx, value):
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            ctx.invoked_subcommand = None
            rv = Command.invoke(self, ctx)
            return self._process_result(ctx, rv)
        args = [*ctx.protected_args, *ctx.args]
        cmd_name, cmd, rest = self.resolve_command(ctx, args)
        ctx.invoked_subcommand = cmd_name
        Command.invoke(self, ctx)
        sub_ctx = cmd.make_context(cmd_name, rest, parent=ctx)
        with sub_ctx:
            rv = sub_ctx.command.invoke(sub_ctx)
        return self._process_result(ctx, rv)

    def _invoke_chain(self, ctx):
        args = [*ctx.protected_args, *ctx.args]
        ctx.protected_args = []
        ctx.args = []
        if not args:
            ctx.invoked_subcommand = None
            Command.invoke(self, ctx)
            return self._process_chain_result(ctx, [])
        self.resolve_command(ctx, args)  # an unknown first name fails before the callback
        ctx.invoked_subcommand = CHAIN_SUBCOMMAND
        Command.invoke(self, ctx)
        contexts = []
        pending = args
        while pending:
            cmd_name, cmd, rest = self.resolve_command(ctx, pending)
            sub = cmd.make_context(cmd_name, rest, parent=ctx, allow_extra_args=True,
                                   allow_interspersed_args=False)
            contexts.append(sub)
            pending = sub.args
        rv = []
        for sub in contexts:
            with sub:
                rv.append(sub.command.invoke(sub))
        return self._process_chain_result(ctx, rv)

    def _process_chain_result(self, ctx, rv):
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, rv, **ctx.params)
        return rv

    # ------------------------------------------------------------ help
    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        meta = self.subcommand_metavar
        lead = f"[{meta}]" if self.invoke_without_command else meta
        if self.chain:
            rv.append(f"{lead} [ARGS]... [{meta} [ARGS]...]...")
        else:
            rv.append(f"{lead} [ARGS]...")
        return rv

    def format_extra(self, ctx, formatter):
        rows = []
        names = [n for n in self.list_commands(ctx)]
        visible = []
        for name in names:
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            visible.append((name, cmd))
        if not visible:
            return
        width = max(len(n) for n, _ in visible)
        limit = max(formatter.width - 6 - width, 10)
        for name, cmd in visible:
            rows.append((name, cmd.get_short_help_str(limit=limit)))
        formatter.write_paragraph()
        with formatter.section("Commands"):
            formatter.write_dl(rows)


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups.  # spec: FP-06"""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx):
        rv = set()
        for source in self.sources:
            rv.update(source.list_commands(ctx))
        return sorted(rv)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
