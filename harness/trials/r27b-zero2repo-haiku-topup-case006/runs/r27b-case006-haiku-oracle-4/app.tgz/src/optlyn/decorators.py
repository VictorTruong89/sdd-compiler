"""Declaration decorators.  # spec: FP-01, FP-03, FP-06; Interface sections 3, 4, 6

# spec: N-000795 (declaration names), N-000846..N-000849 (version identity)
"""

import functools
import sys

from .core import (
    Argument,
    Command,
    Group,
    Option,
    _show_help_callback,
    get_current_context,
)
from .utils import echo

__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator", "get_current_context",
]


def _default_name(func_name):
    name = func_name.lower().replace("_", "-")
    for suffix in ("-command", "-cmd", "-group", "-grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def _take_params(f):
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    params = list(reversed(params))
    del f.__optlyn_params__
    return params


def command(name=None, cls=None, **attrs):
    """Turn a function into a command.  # spec: FP-01, Interface section 3"""
    if cls is None:
        cls = Command

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _default_name(f.__name__)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    if callable(name) and not attrs and cls is None:
        func, name = name, None
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group.  # spec: FP-06, Interface section 3"""
    if cls is None:
        cls = Group

    def decorator(f):
        params = _take_params(f)
        grp_name = name if name is not None else _default_name(f.__name__)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    if callable(name) and not attrs and cls is None:
        func, name = name, None
        return decorator(func)
    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option.  # spec: FP-03, Interface section 4"""
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument.  # spec: FP-04, Interface section 4"""
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    dists = metadata.packages_distributions().get(package_name)
    if dists:
        return metadata.version(dists[0])
    raise RuntimeError(f"Could not determine the version for {package_name!r}.")


def help_option(*param_decls, **kwargs):
    """An extra eager help flag.  # spec: FP-02, Interface section 4"""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """Eager version flag.  # spec: FP-02 version identity"""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        caller = sys._getframe(1).f_globals.get("__name__", "")
        package_name = caller.partition(".")[0] or None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name if prog_name is not None else ctx.find_root().info_name
        ver = version if version is not None else _detect_version(package_name)
        template = message if message is not None else "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback_func, *param_decls, **kwargs):
    """Eager version flag whose whole identity is the callback's return.  # spec: FP-02"""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        sys.stdout.write(str(callback_func(ctx)) + "\n")
        sys.stdout.flush()
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option.  # spec: FP-08"""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "Password input.")
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """Yes flag that prompts when omitted and aborts when declined.  # spec: FP-08"""
    if not param_decls:
        param_decls = ("--yes",)

    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def pass_context(f):
    """Pass the current Context as the first argument.  # spec: Interface section 6"""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type``.  # spec: FP-07 object lookup"""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def pass_obj(f):
    """Pass the current context's author object.  # spec: Interface section 6"""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func
