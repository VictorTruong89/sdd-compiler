"""Output helpers, ANSI styling, file helpers and application directories.

# spec: N-000803..N-000821, N-000981 (standard streams), N-001005 (app dir)
"""

import os
import re
import sys
import tempfile
import threading

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def _is_terminal(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except Exception:
        return False


def _current_color_flag():
    from .core import get_current_context

    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def strip_ansi(text):
    """Remove ANSI escape sequences, leaving all other text intact."""
    return _ANSI_RE.sub("", text)


def unstyle(text):
    return strip_ansi(text)


def _color_codes(color, base):
    """Return the SGR parameter string for a foreground (base 38) or background."""
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}")
        code = _COLORS[color]
        if color == "reset":
            return str(code + 10 if base == 48 else code)
        return str(code + 10 if base == 48 else code)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color out of range: {color!r}")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences.  Invalid colors raise TypeError."""
    bits = []
    if fg is not None:
        bits.append(_color_codes(fg, 38))
    if bg is not None:
        bits.append(_color_codes(bg, 48))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on is not None and on is not False:
            bits.append(str(_STYLE_CODES[name]))
    text = str(text)
    if not bits:
        return text
    rv = f"\x1b[{';'.join(bits)}m{text}"
    if reset:
        rv += "\x1b[0m"
    return rv


def _resolve_color(file, color):
    if color is None:
        color = _current_color_flag()
    if color is None:
        return _is_terminal(file)
    return bool(color)


def _encode_safe_write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        data = text.encode("utf-8")
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(data)
            buf.flush()
        else:
            stream.write(data.decode("ascii", "replace"))


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr / ``file``).

    Styles are stripped unless the destination is a terminal or color is forced on.
    # spec: N-000803..N-000821 (channels); FP-11 echo rules
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(bytes(message))
            if nl:
                buf.write(b"\n")
            buf.flush()
        else:
            file.write(bytes(message).decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if nl:
        text += "\n"
    if not _resolve_color(file, color):
        text = strip_ansi(text)
    _encode_safe_write(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- file helpers

class _NonClosing:
    """Proxy for a standard stream: closing it does not close the process stream."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _AtomicFile:
    """Writes to a temporary sibling and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        self._target = filename
        self._f = open(self._tmp, mode, encoding=encoding, errors=errors)
        self.name = filename
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def _open_raw(filename, mode, encoding, errors, atomic):
    if atomic and any(m in mode for m in "wa"):
        return _AtomicFile(filename, mode, encoding if "b" not in mode else None,
                           errors if "b" not in mode else None)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class LazyFile:
    """Opens its file on first I/O; never opened if unused.

    # spec: FP-09 lazy write; a failure at first I/O is a general FileError
    """

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self._args = (encoding, errors, atomic)
        self._f = None
        self._lock = threading.Lock()

    def _open(self):
        with self._lock:
            if self._f is None:
                from .exceptions import FileError

                try:
                    self._f = _open_raw(self.name, self.mode, *self._args)
                except OSError as e:
                    raise FileError(self.name, e.strerror or str(e)) from e
            return self._f

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._f is not None:
            self._f.close()

    close_intelligently = close

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or the standard stream for ``-``.

    # spec: FP-09 dash rule, FP-11 open helper
    """
    if filename == "-":
        if any(m in mode for m in "wa"):
            stream = sys.stdout
        else:
            stream = sys.stdin
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return _NonClosing(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_raw(filename, mode, encoding, errors, atomic)


def get_binary_stream(name):
    """Binary standard stream by name: 'stdin', 'stdout' or 'stderr'.  # spec: FP-11"""
    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    return getattr(stream, "buffer", stream)


def get_text_stream(name, encoding=None, errors="strict"):
    """Text standard stream by name, with optional encoding.  # spec: FP-11"""
    import io

    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    if encoding is None:
        return stream
    return io.TextIOWrapper(getattr(stream, "buffer", stream), encoding=encoding, errors=errors)


def format_filename(filename, shorten=False):
    """Return a printable, strict-UTF-8-encodable text form of a filename.

    # spec: FP-09 filename formatting
    """
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    out = []
    for ch in filename:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            out.append(f"\\x{code - 0xDC00:02x}")
        else:
            out.append(ch)
    text = "".join(out)
    text.encode("utf-8")
    return text


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory for an application.

    # spec: FP-11 application directory
    """
    home = os.path.expanduser("~")
    unix_name = re.sub(r"\s+", "-", app_name.lower())
    if force_posix or sys.platform not in ("darwin", "win32"):
        if force_posix:
            return os.path.join(home, "." + unix_name)
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
        return os.path.join(base, unix_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
    return os.path.join(base, app_name)
