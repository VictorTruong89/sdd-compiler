"""Interactive terminal helpers: prompts, pager, progress bars, editor, launch.

# spec: FP-08 (prompts), FP-11 (terminal helpers), Interface section 7
"""

import contextlib
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort, BadParameter, UsageError
from .param_types import convert_type
from .utils import _NonClosing, echo, strip_ansi


def _is_terminal(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except Exception:
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal.  # spec: Terminology"""
    return _is_terminal(sys.stdin) or _is_terminal(sys.stdout)


def _echoes_input(stream):
    return bool(getattr(stream, "_optlyn_echoes_input", False))


def _read_hidden_line(stream):
    try:
        import termios

        fd = stream.fileno()
        old = termios.tcgetattr(fd)
        new = termios.tcgetattr(fd)
        new[3] &= ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSADRAIN, new)
        try:
            return stream.readline()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except Exception:
        return stream.readline()


def _read_prompt(text, hide_input=False, err=False):
    echo(text, nl=False, err=err)
    stream = sys.stdin
    if hide_input and _is_terminal(stream):
        line = _read_hidden_line(stream)
    else:
        line = stream.readline()
    if line == "":
        raise Abort()
    line = line.rstrip("\r\n")
    if hide_input:
        echo("", err=err)
    elif not _is_terminal(stream) and not _echoes_input(stream):
        echo(line, err=err)
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False,
           show_choices=True):
    """Ask for a value and convert it.  Re-asks on conversion failure.

    # spec: FP-08 prompt, confirmation prompt, EOF is an abort
    """
    ptype = convert_type(type, default)
    shown = None
    if show_default and default is not None:
        shown_default = default() if callable(default) else default
        shown = str(shown_default)
    text_out = text + (f" [{shown}]" if shown is not None else "") + prompt_suffix
    while True:
        value = _read_prompt(text_out, hide_input, err)
        if not value:
            if default is None:
                continue
            value = default() if callable(default) else default
        try:
            result = value_proc(value) if value_proc is not None else ptype(value, None, None)
        except UsageError as e:
            echo(f"Error: {e.message}", err=True)
            continue
        if confirmation_prompt:
            second = _read_prompt("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if second != str(value):
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question.  # spec: FP-08 confirm"""
    if show_default:
        choices = "[Y/n]" if default else "[y/N]"
        text_out = f"{text} {choices}{prompt_suffix}"
    else:
        text_out = text + prompt_suffix
    while True:
        answer = _read_prompt(text_out, False, err).strip().lower()
        if answer == "":
            rv = bool(default)
            break
        if answer in ("y", "yes"):
            rv = True
            break
        if answer in ("n", "no"):
            rv = False
            break
        echo("Error: invalid input", err=True)
    if abort and not rv:
        raise Abort()
    return rv


def _read_tty_char():
    """Read one character from the controlling terminal.  # spec: FP-11 getchar"""
    try:
        import termios
        import tty
    except ImportError:  # pragma: no cover - Windows
        return sys.stdin.read(1)
    fd = None
    opened = False
    try:
        if _is_terminal(sys.stdin):
            fd = sys.stdin.fileno()
        else:
            fd = os.open("/dev/tty", os.O_RDONLY)
            opened = True
    except OSError:
        return sys.stdin.read(1)
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except termios.error:
        return sys.stdin.read(1)
    finally:
        if opened:
            os.close(fd)
    return ch.decode("utf-8", "replace")


def getchar(echo=False):
    """Read one character.  Interrupt raises KeyboardInterrupt, EOF raises EOFError."""
    if getattr(sys.stdin, "_optlyn_runner", False):
        ch = sys.stdin.read(1)
    else:
        ch = _read_tty_char()
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        globals()["echo"](ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive.  # spec: FP-11 pause"""
    msg = info if info is not None else "Press any key to continue..."
    echo(msg, nl=False, err=err)
    if is_interactive():
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or a file.  # spec: FP-11 edit"""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if editor is None:
        editor = "notepad" if sys.platform == "win32" else "vi"
    if filename is None:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text or "")
        cleanup = True
    else:
        path = filename
        cleanup = False
    mtime_before = os.path.getmtime(path) if os.path.exists(path) else None
    run_env = dict(os.environ)
    run_env.update(env or {})
    try:
        subprocess.call(shlex.split(editor) + [path], env=run_env)
        if filename is not None:
            return None
        mtime_after = os.path.getmtime(path)
        if require_save and mtime_before == mtime_after:
            return None
        with open(path, encoding="utf-8", newline="") as f:
            return f.read()
    finally:
        if cleanup:
            try:
                os.remove(path)
            except OSError:
                pass


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application.  # spec: FP-11 launch"""
    if sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    if sys.platform == "darwin":
        args = ["open"] + (["-R"] if locate else []) + [url]
    else:
        args = ["xdg-open", url]
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the terminal; nothing when not connected to one.  # spec: FP-11 clear"""
    if _is_terminal(sys.stdout):
        sys.stdout.write("\033[2J\033[1;1H")
        sys.stdout.flush()


class ProgressBar:
    """A progress bar that is also an iterator over its items.  # spec: FP-11 progress bar"""

    def __init__(self, iterable, length, label, hidden, file=None, width=36):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = bool(hidden)
        self.file = file or sys.stdout
        self.tty = (not self.hidden) and _is_terminal(self.file)
        self.width = width
        self.pos = 0
        self.start = time.time()
        self._drawn = False

    def __iter__(self):
        if self.iterable is None:
            return
        self._render()
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        self._render()

    def _eta(self):
        if not self.length or self.pos <= 0:
            return None
        elapsed = time.time() - self.start
        return max(elapsed / self.pos * (self.length - self.pos), 0)

    def _render(self):
        if not self.tty:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * self.width)
            bar = "#" * filled + "-" * (self.width - filled)
            eta = self._eta()
            eta_s = "" if eta is None else f"  eta {int(eta)}s"
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length}{eta_s}"
        else:
            line = f"\r{self.label} {self.pos}"
        self.file.write(line)
        self.file.flush()
        self._drawn = True

    def finish(self):
        if self.tty and self._drawn:
            self.file.write("\n")
            self.file.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden)
    if not bar.tty and not bar.hidden and bar.label:
        echo(bar.label)
    try:
        yield bar
    finally:
        bar.finish()


def _pager_command():
    return os.environ.get("PAGER") or "less"


def _write_chunks(stream, chunks, color):
    for chunk in chunks:
        text = str(chunk)
        if not color:
            text = strip_ansi(text)
        stream.write(text)
        stream.flush()


def echo_via_pager(text_or_generator, color=None):
    """Write long text through a pager when interactive.  # spec: FP-11 pager"""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    if isinstance(value, str):
        chunks = [value if value.endswith("\n") else value + "\n"]
    else:
        chunks = value
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE,
                            text=True, encoding="utf-8")
    try:
        _write_chunks(proc.stdin, chunks, bool(color))
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Writable text stream that goes through the pager when interactive."""
    if not is_interactive():
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE,
                            text=True, encoding="utf-8")

    class _Pager(io.TextIOBase):
        def write(self, s):
            if not color:
                s = strip_ansi(s)
            proc.stdin.write(s)
            proc.stdin.flush()
            return len(s)

    try:
        yield _Pager()
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
