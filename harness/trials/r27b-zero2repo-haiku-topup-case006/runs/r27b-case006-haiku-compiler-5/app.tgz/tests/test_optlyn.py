"""Behavioural tests for Optlyn. Each test names the spec ids it exercises."""

import datetime
import enum
import io
import os
import pathlib
import sys

import pytest

import optlyn as o
from optlyn import testing
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner
from optlyn.types import Choice, DateTime, FloatRange, IntRange, Path, Tuple, File


def run(cli, args=None, **kwargs):
    return CliRunner().invoke(cli, args or [], **kwargs)


# ---------------------------------------------------------------- FP-01 declaration and naming


def test_derived_name_strips_suffix():  # spec: N-000079, N-000080
    @o.command()
    def sync_data_command():
        pass

    assert sync_data_command.name == "sync-data"


def test_explicit_name_replaces_derived_name():  # spec: N-000080, N-000082
    @o.command("run-it")
    def whatever():
        pass

    assert whatever.name == "run-it"


def test_command_runs_once_and_succeeds():  # spec: N-000083, N-000084, N-000085
    calls = []

    @o.command()
    def go():
        calls.append(1)
        o.echo("hi")

    r = run(go)
    assert r.exit_code == 0
    assert r.output == "hi\n"
    assert calls == [1]


def test_deprecated_command_still_runs_and_warns():  # spec: N-000086, N-000087, N-000088
    @o.command(deprecated="use new-thing")
    def old():
        o.echo("ran")

    r = run(old)
    assert r.exit_code == 0
    assert "ran" in r.stdout
    assert "deprecated" in r.stderr and "use new-thing" in r.stderr


def test_unknown_option_on_deprecated_command_is_usage_error():  # spec: N-000090
    @o.command(deprecated=True)
    def old():
        o.echo("never")

    r = run(old, ["--nope"])
    assert r.exit_code == 2
    assert "never" not in r.stdout


def test_leftover_extra_arguments_are_usage_error():  # spec: N-000105
    @o.command()
    def leaf():
        o.echo("ran")

    r = run(leaf, ["extra"])
    assert r.exit_code == 2
    assert "ran" not in r.stdout


def test_allow_extra_args_runs_callback():  # spec: N-000106, N-000107
    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("first", required=False)
    def leaf(first):
        o.echo(f"first={first}")

    r = run(leaf, ["a", "b"])
    assert r.exit_code == 0
    assert r.stdout == "first=a\n"


def test_standalone_disabled_propagates_and_returns():  # spec: N-000097, N-000099, N-000100
    @o.command()
    @o.argument("x", type=int)
    def leaf(x):
        return x * 2

    assert leaf.main(["21"], standalone_mode=False) == 42
    with pytest.raises(o.BadParameter):
        leaf.main(["nope"], standalone_mode=False)


def test_ascii_environment_does_not_abort(monkeypatch):  # spec: N-000103, N-000104
    @o.command()
    def leaf():
        o.echo("héllo ✓")

    r = CliRunner(charset="ascii").invoke(leaf, [])
    assert r.exit_code == 0
    assert r.stdout_bytes.decode("utf-8") == "héllo ✓\n"


# ---------------------------------------------------------------- FP-02 help


def test_help_prints_page_and_skips_callback():  # spec: N-000110, N-000111, N-000113
    ran = []

    @o.command()
    @o.option("--count", type=int, help="How many.")
    def leaf(count):
        """Do the thing. Extra detail."""
        ran.append(1)

    r = run(leaf, ["--help"])
    assert r.exit_code == 0
    assert ran == []
    assert "Usage: leaf" in r.stdout
    assert "Do the thing. Extra detail." in r.stdout
    assert "Options:" in r.stdout
    assert "How many." in r.stdout


def test_form_feed_truncates_help():  # spec: N-000115, N-000116, N-000117
    @o.command(help="Visible text.\fHidden text.")
    def leaf():
        pass

    r = run(leaf, ["--help"])
    assert "Visible text." in r.stdout
    assert "Hidden text" not in r.stdout
    assert "\f" not in r.stdout


def test_group_no_args_is_usage_failure_with_help_on_stderr():  # spec: N-000170, N-000173, N-000175
    @o.group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    r = run(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.stderr
    assert r.stdout == ""


def test_epilog_at_end_of_help():  # spec: N-000125, N-000126, N-000844
    @o.command(epilog="The end.")
    def leaf():
        """Head."""

    text = run(leaf, ["--help"]).stdout
    assert text.rstrip().endswith("The end.")


def test_metavar_defaults_and_options_placeholder():  # spec: N-000139, N-000140, N-000827, N-000828
    @o.command(options_metavar="<opts>")
    @o.option("--count", type=int)
    @o.argument("target")
    def leaf(count, target):
        pass

    text = run(leaf, ["--help"]).stdout
    assert "Usage: leaf <opts> TARGET" in text


def test_help_shows_default_and_env_and_choice():  # spec: N-000146, N-000148, N-000149, N-000145
    @o.command()
    @o.option("--level", type=Choice(["low", "high"]), default="low", show_default=True,
              envvar="LEVEL", show_envvar=True)
    def leaf(level):
        pass

    text = run(leaf, ["--help"]).stdout
    assert "[default: low]" in text
    assert "[env var: LEVEL]" in text
    assert "[low|high]" in text


def test_flag_default_false_hidden_even_with_show_default():  # spec: N-000150
    @o.command(context_settings={"show_default": True})
    @o.option("--quiet", is_flag=True)
    def leaf(quiet):
        pass

    text = run(leaf, ["--help"]).stdout
    assert "[default" not in text


def test_hidden_options_omitted_from_help_but_invocable():  # spec: N-000153, N-000154
    @o.command()
    @o.option("--secret", hidden=True, is_flag=True)
    def leaf(secret):
        o.echo(f"secret={secret}")

    assert "--secret" not in run(leaf, ["--help"]).stdout
    assert run(leaf, ["--secret"]).stdout == "secret=True\n"


def test_help_option_names_can_be_replaced():  # spec: N-000155, N-000157, N-000158
    @o.command()
    def leaf():
        """Help me."""

    r = run(leaf, ["-h"], help_option_names=["-h"])
    assert r.exit_code == 0 and "Usage: leaf" in r.stdout
    r = run(leaf, ["--help"], help_option_names=["-h"])
    assert r.exit_code == 2


def test_parameter_named_help_does_not_disable_help():  # spec: N-000159
    @o.command()
    @o.argument("help", required=False)
    def leaf(help):
        o.echo(f"arg={help}")

    assert run(leaf, ["--help"]).exit_code == 0
    assert run(leaf, ["x"]).stdout == "arg=x\n"


def test_wrap_text_rules():  # spec: N-000133, N-000134, N-000135, N-000136
    text = "one two three four five six seven eight nine ten"
    assert "\n" in wrap_text(text, 20)
    kept = wrap_text("\b\nline one\nline two", 10)
    assert "line one\nline two" in kept
    assert "\b" not in kept
    assert wrap_text("", 10) == ""


# ---------------------------------------------------------------- FP-02 version


def test_version_option_is_eager_and_exits():  # spec: N-000162, N-000168, N-000169
    ran = []

    @o.command()
    @o.version_option("1.2.3", prog_name="tool")
    @o.option("--must", required=True)
    def leaf(must):
        ran.append(1)

    r = run(leaf, ["--version"])
    assert r.exit_code == 0
    assert "1.2.3" in r.stdout
    assert ran == []


def test_custom_version_option_prints_exact_string():  # spec: N-000167, N-000846, N-000849
    @o.command()
    @o.custom_version_option(lambda ctx: f"custom {ctx.info_name}")
    def leaf():
        pass

    r = run(leaf, ["--version"])
    assert r.stdout == "custom leaf\n"


def test_first_eager_flag_typed_wins():  # spec: N-000169
    @o.command()
    @o.version_option("9", prog_name="tool")
    def leaf():
        pass

    r = run(leaf, ["--help", "--version"])
    assert "Usage:" in r.stdout
    assert "9" not in r.stdout


# ---------------------------------------------------------------- FP-03 options


def test_option_forms_long_short_stacked_and_equals():  # spec: N-000188, N-000189, N-000190, N-000193
    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-n", "--number", type=int)
    def leaf(a, b, number):
        o.echo(f"{a} {b} {number}")

    assert run(leaf, ["-ab", "-n", "3"]).stdout == "True True 3\n"
    assert run(leaf, ["--number=7"]).stdout == "False False 7\n"
    assert run(leaf, ["-n5"]).stdout == "False False 5\n"


def test_destination_inference():  # spec: N-000194, N-000195
    @o.command()
    @o.option("--dry-run", is_flag=True)
    @o.option("-q", is_flag=True)
    def leaf(dry_run, q):
        o.echo(f"{dry_run} {q}")

    assert run(leaf, ["--dry-run", "-q"]).stdout == "True True\n"


def test_option_after_argument_on_leaf():  # spec: N-000196, N-000198
    @o.command()
    @o.option("--flag", is_flag=True)
    @o.argument("name")
    def leaf(flag, name):
        o.echo(f"{flag} {name}")

    assert run(leaf, ["bob", "--flag"]).stdout == "True bob\n"


def test_option_after_double_dash_is_argument():  # spec: N-000202, N-000304, N-000305
    @o.command()
    @o.option("--flag", is_flag=True)
    @o.argument("rest", required=False, nargs=-1)
    def leaf(flag, rest):
        o.echo(f"{flag} {rest}")

    assert run(leaf, ["--", "--flag"]).stdout == "False ('--flag',)\n"


def test_required_option_missing_is_usage_error():  # spec: N-000200, N-000201
    @o.command()
    @o.option("--name", required=True)
    def leaf(name):
        o.echo("ran")

    r = run(leaf, [])
    assert r.exit_code == 2
    assert "--name" in r.stderr
    assert "ran" not in r.stdout


def test_boolean_flag_and_on_off_pair():  # spec: N-000202, N-000203, N-000204, N-000205
    @o.command()
    @o.option("--shout/--no-shout", default=True)
    def leaf(shout):
        o.echo(shout)

    assert run(leaf, []).stdout == "True\n"
    assert run(leaf, ["--no-shout"]).stdout == "False\n"
    assert run(leaf, ["--shout"]).stdout == "True\n"


def test_counting_option_omitted_is_zero():  # spec: N-000207, N-000208
    @o.command()
    @o.option("-v", count=True)
    def leaf(v):
        o.echo(v)

    assert run(leaf, []).stdout == "0\n"
    assert run(leaf, ["-vvv"]).stdout == "3\n"


def test_repeatable_option_collects_values_and_omitted_is_empty_tuple():  # spec: N-000209, N-000211
    @o.command()
    @o.option("-i", multiple=True)
    def leaf(i):
        o.echo(repr(i))

    assert run(leaf, ["-i", "a", "-i", "b"]).stdout == "('a', 'b')\n"
    assert run(leaf, []).stdout == "()\n"


def test_multi_value_option_takes_fixed_tokens():  # spec: N-000213, N-000217, N-000219
    @o.command()
    @o.option("--pos", nargs=2, type=int)
    @o.argument("rest", required=False)
    def leaf(pos, rest):
        o.echo(f"{pos} {rest}")

    assert run(leaf, ["--pos", "1", "2", "tail"]).stdout == "(1, 2) tail\n"
    assert run(leaf, ["--pos", "1"]).exit_code == 2


def test_optional_value_option():  # spec: N-000221, N-000222, N-000224, N-000225
    @o.command()
    @o.option("--name", is_flag=False, flag_value="fallback", default="dflt")
    def leaf(name):
        o.echo(name)

    assert run(leaf, []).stdout == "dflt\n"
    assert run(leaf, ["--name"]).stdout == "fallback\n"
    assert run(leaf, ["--name", "given"]).stdout == "given\n"


def test_missing_value_for_option_requiring_one_is_usage_error():  # spec: N-000275
    @o.command()
    @o.option("--name")
    def leaf(name):
        pass

    assert run(leaf, ["--name"]).exit_code == 2


def test_string_default_on_repeatable_is_usage_error():  # spec: N-000276, N-000277, N-000279
    @o.command()
    @o.option("-i", multiple=True, default="abc")
    def leaf(i):
        pass

    r = run(leaf, [])
    assert r.exit_code == 2
    assert "iterable" in r.stderr


def test_deprecated_required_option_refused_at_declaration():  # spec: N-000280, N-000281, N-000282
    with pytest.raises(TypeError):
        o.option("--x", deprecated=True, required=True)(lambda x: None)
    with pytest.raises(TypeError):
        o.option("--x", deprecated=True, prompt=True)(lambda x: None)


def test_unknown_option_is_usage_error():  # spec: N-000268, N-000270, N-000271
    @o.command()
    def leaf():
        pass

    r = run(leaf, ["--bogus"])
    assert r.exit_code == 2
    assert "--bogus" in r.stderr


def test_ignore_unknown_options_consumes_as_argument():  # spec: N-000269, N-000324
    @o.command(context_settings={"ignore_unknown_options": True})
    @o.argument("rest", nargs=-1, required=False)
    def leaf(rest):
        o.echo(repr(rest))

    assert run(leaf, ["--zap", "x"]).stdout == "('--zap', 'x')\n"


def test_alternative_prefix_slash():  # spec: N-000226
    @o.command()
    @o.option("/verbose", is_flag=True)
    def leaf(verbose):
        o.echo(verbose)

    assert run(leaf, ["/verbose"]).stdout == "True\n"


def test_envvar_first_set_wins_and_empty_is_unset(monkeypatch):  # spec: N-000227, N-000229, N-000230
    @o.command()
    @o.option("--tok", envvar=["FIRST_TOK", "SECOND_TOK"])
    def leaf(tok):
        o.echo(tok)

    monkeypatch.setenv("FIRST_TOK", "")
    monkeypatch.setenv("SECOND_TOK", "two")
    assert run(leaf, []).stdout == "two\n"
    monkeypatch.setenv("FIRST_TOK", "one")
    assert run(leaf, []).stdout == "one\n"


def test_bool_envvar_values(monkeypatch):  # spec: N-000234, N-000235, N-000241
    @o.command()
    @o.option("--on", is_flag=True, envvar="ON_FLAG")
    def leaf(on):
        o.echo(on)

    monkeypatch.setenv("ON_FLAG", " YES ")
    assert run(leaf, []).stdout == "True\n"
    monkeypatch.setenv("ON_FLAG", "off")
    assert run(leaf, []).stdout == "False\n"
    monkeypatch.setenv("ON_FLAG", "maybe")
    r = run(leaf, [])
    assert r.exit_code == 2


def test_env_satisfies_required_option(monkeypatch):  # spec: N-000231, N-000200
    @o.command()
    @o.option("--key", required=True, envvar="KEY_VAR")
    def leaf(key):
        o.echo(key)

    monkeypatch.setenv("KEY_VAR", "abc")
    assert run(leaf, []).stdout == "abc\n"


def test_value_source_precedence_and_inspection(monkeypatch):  # spec: N-000243, N-000245, N-000463-ish
    seen = {}

    @o.command()
    @o.option("--name", envvar="NAME_VAR", default="dflt")
    @click_like_ctx
    def leaf(ctx, name):
        seen["cmd"] = ctx.get_parameter_source("name")
        seen["nope"] = ctx.get_parameter_source("nope")

    assert run(leaf, ["--name", "x"]).exit_code == 0
    assert seen["cmd"] == o.ParameterSource.COMMANDLINE
    assert seen["nope"] is None
    monkeypatch.setenv("NAME_VAR", "e")
    run(leaf, [])
    assert seen["cmd"] == o.ParameterSource.ENVIRONMENT
    monkeypatch.delenv("NAME_VAR")
    run(leaf, [])
    assert seen["cmd"] == o.ParameterSource.DEFAULT


def click_like_ctx(f):
    return o.pass_context(f)


def test_parameter_callback_replaces_or_refuses():  # spec: N-000250, N-000251, N-000254, N-000255
    def upper(ctx, param, value):
        if value == "bad":
            raise o.BadParameter("no bad values")
        return value.upper()

    @o.command()
    @o.option("--word", callback=upper)
    def leaf(word):
        o.echo(word)

    assert run(leaf, ["--word", "hi"]).stdout == "HI\n"
    r = run(leaf, ["--word", "bad"])
    assert r.exit_code == 2 and "no bad values" in r.stderr


def test_missing_parameter_callback_runs_with_default():  # spec: N-000256, N-000261
    @o.command()
    @o.option("--a", default=1, type=int)
    @o.option("--b", type=int, required=False)
    def leaf(a, b):
        o.echo(f"{a} {b}")

    assert run(leaf, []).stdout == "1 None\n"


def test_feature_switch_group_last_declared_wins():  # spec: N-000246, N-000249
    @o.command()
    @o.option("--fast", "mode", flag_value="fast", is_flag=True, default=False)
    @o.option("--slow", "mode", flag_value="slow", is_flag=True, default=False)
    def leaf(mode):
        o.echo(mode)

    assert run(leaf, ["--fast"]).stdout == "fast\n"


# ---------------------------------------------------------------- FP-04 arguments


def test_argument_binding_and_scalar_delivery():  # spec: N-000285, N-000293, N-000297
    @o.command()
    @o.argument("src")
    @o.argument("dst")
    def leaf(src, dst):
        o.echo(f"{src}->{dst}")

    assert run(leaf, ["a", "b"]).stdout == "a->b\n"


def test_missing_required_argument_names_it():  # spec: N-000321, N-000322
    @o.command()
    @o.argument("path")
    def leaf(path):
        o.echo("ran")

    r = run(leaf, [])
    assert r.exit_code == 2
    assert "path" in r.stderr.lower()
    assert "ran" not in r.stdout


def test_variadic_argument_and_omitted_empty():  # spec: N-000291, N-000301, N-000302
    @o.command()
    @o.argument("items", nargs=-1)
    def leaf(items):
        o.echo(repr(items))

    assert run(leaf, []).stdout == "()\n"
    assert run(leaf, ["a", "b"]).stdout == "('a', 'b')\n"


def test_arg_default_and_absent_value():  # spec: N-000294
    @o.command()
    @o.argument("maybe", required=False)
    @o.argument("dflt", default="d")
    def leaf(maybe, dflt):
        o.echo(f"{maybe!r} {dflt}")

    assert run(leaf, []).stdout == "None d\n"
    assert run(leaf, ["x"]).stdout == "'x' d\n"


def test_argument_envvar_explicit_only(monkeypatch):  # spec: N-000309, N-000311, N-000312, N-000313
    @o.command()
    @o.argument("token", envvar="TOK_ARG", required=False)
    @o.argument("other", required=False)
    def leaf(token, other):
        o.echo(f"{token} {other}")

    monkeypatch.setenv("TOK_ARG", "fromenv")
    monkeypatch.setenv("OTHER", "no")
    assert run(leaf, []).stdout == "fromenv None\n"


def test_deprecated_required_argument_refused():  # spec: N-000325, N-000326, N-000327
    with pytest.raises(TypeError):
        o.argument("x", deprecated=True, required=True)(lambda x: None)


# ---------------------------------------------------------------- FP-05 types


def test_builtin_types_convert():  # spec: N-000332, N-000333, N-000337, N-000339, N-000346
    import uuid

    @o.command()
    @o.option("--i", type=o.INT)
    @o.option("--f", type=o.FLOAT)
    @o.option("--b", type=o.BOOL)
    @o.option("--u", type=o.UUID)
    def leaf(i, f, b, u):
        o.echo(repr((i, f, b, u)))

    out = run(leaf, ["--i", "3", "--f", "2.5", "--b", "yes", "--u", "12345678-1234-5678-1234-567812345678"]).stdout
    assert "3, 2.5, True, UUID('12345678-1234-5678-1234-567812345678')" in out


def test_integer_fraction_is_usage_error():  # spec: N-000333, N-000375
    @o.command()
    @o.option("--i", type=o.INT)
    def leaf(i):
        pass

    assert run(leaf, ["--i", "1.5"]).exit_code == 2


def test_int_inferred_from_default():  # spec: N-000336, N-000183
    @o.command()
    @o.option("--n", default=4)
    def leaf(n):
        o.echo(repr(n))

    assert run(leaf, ["--n", "9"]).stdout == "9\n"
    assert run(leaf, []).stdout == "4\n"


def test_choice_case_and_original_object():  # spec: N-000348, N-000349, N-000350, N-000382
    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @o.command()
    @o.option("--c", type=Choice(Color))
    def leaf(c):
        o.echo(repr(c))

    assert run(leaf, ["--c", "RED"]).stdout == "<Color.RED: 1>\n"
    assert run(leaf, ["--c", "red"]).exit_code == 2

    @o.command()
    @o.option("--k", type=Choice(["Apple", "pear"], case_sensitive=False))
    def leaf2(k):
        o.echo(k)

    assert run(leaf2, ["--k", "APPLE"]).stdout == "Apple\n"


def test_datetime_formats_first_match_and_default_naive():  # spec: N-000353, N-000354, N-000356, N-000357
    dt = DateTime()
    assert dt.convert("2024-05-06", None, None) == datetime.datetime(2024, 5, 6)
    assert dt.convert("2024-05-06 07:08:09", None, None) == datetime.datetime(2024, 5, 6, 7, 8, 9)
    custom = DateTime(["%d/%m/%Y"])
    with pytest.raises(o.BadParameter):
        custom.convert("2024-05-06", None, None)


def test_int_range_and_clamp():  # spec: N-000358, N-000359, N-000361, N-000362
    r = IntRange(min=1, max=5)
    assert r.convert("3", None, None) == 3
    with pytest.raises(o.BadParameter):
        r.convert("9", None, None)
    clamped = IntRange(min=1, max=5, clamp=True)
    assert clamped.convert("9", None, None) == 5
    assert clamped.convert("-4", None, None) == 1
    open_clamped = IntRange(min=1, max=5, min_open=True, clamp=True)
    assert open_clamped.convert("1", None, None) == 2


def test_float_range_clamp_rules():  # spec: N-000363, N-000364, N-000365, N-000381
    fr = FloatRange(min=0.0, max=1.0, clamp=True)
    assert fr.convert("2.5", None, None) == 1.0
    with pytest.raises(ValueError):
        FloatRange(min=0.0, max=1.0, min_open=True, clamp=True)


def test_tuple_type_option_converts_positions():  # spec: N-000366, N-000220
    @o.command()
    @o.option("--pair", type=Tuple([str, int]))
    def leaf(pair):
        o.echo(repr(pair))

    assert run(leaf, ["--pair", "a", "2"]).stdout == "('a', 2)\n"


def test_custom_paramtype_and_function_type():  # spec: N-000370, N-000371, N-000372, N-000374
    class Upper(o.ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if value.isdigit():
                self.fail("digits not allowed", param, ctx)
            return value.upper()

    @o.command()
    @o.option("--u", type=Upper())
    @o.option("--h", type=lambda s: int(s, 16) if s.startswith("0x") else (_ for _ in ()).throw(ValueError("hex")))
    def leaf(u, h):
        o.echo(f"{u} {h}")

    assert run(leaf, ["--u", "abc", "--h", "0x10"]).stdout == "ABC 16\n"
    r = run(leaf, ["--u", "123", "--h", "0x10"])
    assert r.exit_code == 2 and "digits" in r.stderr


def test_path_type_checks(tmp_path):  # spec: N-000548, N-000583, N-000584, N-000585
    f = tmp_path / "f.txt"
    f.write_text("x")
    d = tmp_path / "d"
    d.mkdir()
    p = Path(exists=True, file_okay=True, dir_okay=False)
    assert p.convert(str(f), None, None) == str(f)
    with pytest.raises(o.BadParameter):
        p.convert(str(d), None, None)
    with pytest.raises(o.BadParameter):
        p.convert(str(tmp_path / "missing"), None, None)
    assert Path(path_type=pathlib.Path).convert("x", None, None) == pathlib.Path("x")
    assert Path(allow_dash=True).convert("-", None, None) == "-"


def test_file_type_read_and_lazy_write(tmp_path):  # spec: N-000532, N-000533, N-000536, N-000578
    src = tmp_path / "in.txt"
    src.write_text("hello")
    dst = tmp_path / "out.txt"

    @o.command()
    @o.option("--src", type=File("r"))
    @o.option("--dst", type=File("w"))
    def leaf(src, dst):
        o.echo(f"{src.read()}")
        dst.write("written")

    r = run(leaf, ["--src", str(src), "--dst", str(dst)])
    assert r.exit_code == 0
    assert dst.read_text() == "written"

    missing = tmp_path / "nope.txt"
    r = run(leaf, ["--src", str(missing), "--dst", str(dst)])
    assert r.exit_code == 2
    assert str(missing) in r.stderr


def test_lazy_write_not_truncated_when_unused(tmp_path):  # spec: N-000534, N-000537, N-000538
    target = tmp_path / "keep.txt"
    target.write_text("original")

    @o.command()
    @o.option("--dst", type=File("w"))
    def leaf(dst):
        o.echo("no writes")

    assert run(leaf, ["--dst", str(target)]).exit_code == 0
    assert target.read_text() == "original"


def test_atomic_write_replaces_on_close(tmp_path):  # spec: N-000542, N-000543
    target = tmp_path / "atomic.txt"
    target.write_text("old")
    f = File("w", atomic=True, lazy=False).convert(str(target), None, None)
    f.write("new")
    assert target.read_text() == "old"
    f.close()
    assert target.read_text() == "new"


def test_dash_stdin_and_stdout_do_not_close():  # spec: N-000546, N-000589, N-000590
    @o.command()
    @o.argument("out", type=File("w"))
    def leaf(out):
        out.write("via dash\n")

    r = run(leaf, ["-"])
    assert r.stdout == "via dash\n"
    assert r.exit_code == 0


# ---------------------------------------------------------------- FP-06 groups


def test_group_dispatch_and_outer_callback_runs_first():  # spec: N-000388, N-000391, N-000392, N-000393
    order = []

    @o.group()
    def cli():
        order.append("group")

    @cli.command()
    def child():
        order.append("child")

    run(cli, ["child"])
    assert order == ["group", "child"]


def test_group_options_before_subcommand_only():  # spec: N-000394, N-000395, N-000196, N-000197
    @o.group()
    @o.option("--g", is_flag=True)
    def cli(g):
        o.echo(f"g={g}")

    @cli.command()
    @o.option("--c", is_flag=True)
    def sub(c):
        o.echo(f"c={c}")

    assert run(cli, ["--g", "sub", "--c"]).stdout == "g=True\nc=True\n"


def test_help_before_subcommand_is_group_help():  # spec: N-000397, N-000396
    @o.group()
    def cli():
        """Group doc."""

    @cli.command()
    def sub():
        o.echo("ran")

    r = run(cli, ["--help", "sub"])
    assert "Group doc." in r.stdout
    assert "ran" not in r.stdout


def test_nested_groups_and_skipped_middle_name():  # spec: N-000398, N-000399, N-000400
    @o.group()
    def top():
        pass

    @top.group()
    def mid():
        pass

    @mid.command()
    def leaf():
        o.echo("leaf")

    assert run(top, ["mid", "leaf"]).stdout == "leaf\n"
    r = run(top, ["leaf"])
    assert r.exit_code == 2 and "No such command" in r.stderr


def test_late_registration_and_explicit_name():  # spec: N-000401, N-000428, N-000402
    @o.group()
    def cli():
        pass

    @o.command("hello-there")
    def hi():
        o.echo("hi")

    cli.add_command(hi)
    assert run(cli, ["hello-there"]).stdout == "hi\n"


def test_invoke_without_command_and_chain_marker():  # spec: N-000403, N-000404, N-000405
    seen = {}

    @o.group(invoke_without_command=True)
    @o.pass_context
    def cli(ctx):
        seen["sub"] = ctx.invoked_subcommand
        o.echo("group only")

    r = run(cli, [])
    assert r.exit_code == 0
    assert seen["sub"] is None
    assert r.stdout == "group only\n"


def test_no_args_is_help_default_for_leaf_off():  # spec: N-000406, N-000410
    @o.command()
    def leaf():
        o.echo("ran")

    assert run(leaf, []).stdout == "ran\n"


def test_nested_group_without_child_shows_its_help():  # spec: N-000411, N-000412
    @o.group()
    def top():
        """top doc"""

    @top.group()
    def mid():
        """mid doc"""

    @mid.command()
    def leaf():
        pass

    r = run(top, ["mid"])
    assert r.exit_code == 2
    assert "mid doc" in r.stderr


def test_command_collection_union():  # spec: N-000422, N-000423, N-000424, N-000425
    @o.group()
    def a():
        pass

    @a.command()
    def one():
        o.echo("one")

    @o.group()
    def b():
        pass

    @b.command()
    def two():
        o.echo("two")

    coll = o.group(cls=o.CommandCollection, sources=[a, b])(lambda: None)
    assert run(coll, ["one"]).stdout == "one\n"
    assert run(coll, ["two"]).stdout == "two\n"
    assert "one" in run(coll, ["--help"]).stdout


def test_hidden_command_not_listed_but_reachable():  # spec: N-000426, N-000427
    @o.group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        o.echo("found")

    assert "secret" not in run(cli, ["--help"]).stdout
    assert run(cli, ["secret"]).stdout == "found\n"


def test_lazy_custom_listing_and_lookup():  # spec: N-000413, N-000416, N-000418, N-000421
    class Lazy(o.Group):
        def list_commands(self, ctx):
            return ["dyn"]

        def get_command(self, ctx, name):
            if name != "dyn":
                return None

            @o.command()
            def dyn():
                o.echo("dyn ran")

            return dyn

    lazy = Lazy(name="lazy", callback=lambda: None)
    assert run(lazy, ["dyn"]).stdout == "dyn ran\n"
    assert "dyn" in run(lazy, ["--help"]).stdout


def test_group_cls_subclass_gets_constructor_args():  # spec: N-000866, N-000867
    class Mine(o.Group):
        marker = "x"

    @o.group(cls=Mine)
    def cli():
        pass

    assert isinstance(cli, Mine) and cli.marker == "x"


# ---------------------------------------------------------------- FP-10 chaining


def test_chain_runs_each_subcommand_and_result_callback():  # spec: N-000593, N-000597, N-000598, N-000603
    @o.group(chain=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results, **params):
        o.echo(f"results={results}")
        return sum(results)

    @cli.command()
    @o.argument("n", type=int)
    def add(n):
        return n

    @cli.command()
    @o.argument("n", type=int)
    def mul(n):
        return n * 10

    r = run(cli, ["add", "2", "mul", "3"])
    assert r.exit_code == 0
    assert "results=[2, 30]" in r.stdout


def test_chain_standalone_off_returns_list():  # spec: N-000604
    @o.group(chain=True)
    def cli():
        pass

    @cli.command()
    def a():
        return "A"

    @cli.command()
    def b():
        return "B"

    assert cli.main(["a", "b"], standalone_mode=False) == ["A", "B"]


def test_group_under_chain_group_refused():  # spec: N-000612, N-000613, N-000871
    @o.group(chain=True)
    def cli():
        pass

    @o.group()
    def inner():
        pass

    with pytest.raises(TypeError):
        cli.add_command(inner)


def test_result_callback_non_chain_gets_single_value():  # spec: N-000599, N-000600
    @o.group()
    def cli():
        pass

    @cli.result_callback()
    def done(value):
        o.echo(f"got {value}")

    @cli.command()
    def leaf():
        return 7

    assert run(cli, ["leaf"]).stdout == "got 7\n"


def test_chain_invoke_without_command_runs_result_callback():  # spec: N-000605, N-000606
    @o.group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        o.echo(f"empty={results}")

    assert run(cli, []).stdout == "empty=[]\n"


# ---------------------------------------------------------------- FP-07 context and default map


def test_pass_obj_and_make_pass_decorator():  # spec: N-000434, N-000435, N-000442, N-000975-N-000977
    class Config:
        def __init__(self):
            self.level = 0

    pass_config = o.make_pass_decorator(Config, ensure=True)

    @o.group()
    @o.pass_obj
    def cli(obj):
        obj.level += 1

    @cli.command()
    @pass_config
    def sub(cfg):
        o.echo(f"level={cfg.level}")

    cfg = Config()
    cfg.level = 5
    r = CliRunner().invoke(cli, ["sub"], obj=cfg)
    assert r.stdout == "level=6\n"


def test_make_pass_decorator_ensure_creates_empty_object():  # spec: N-000442
    class Thing:
        pass

    deco = o.make_pass_decorator(Thing, ensure=True)

    @o.command()
    @deco
    def leaf(t):
        o.echo(type(t).__name__)

    assert run(leaf).stdout == "Thing\n"


def test_default_map_nested_by_subcommand_and_precedence(monkeypatch):  # spec: N-000450, N-000451, N-000452
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--name", default="builtin", envvar="NAME_DM")
    def sub(name):
        o.echo(name)

    monkeypatch.setenv("NAME_DM", "envval")
    r = run(cli, ["sub"], default_map={"sub": {"name": "mapped"}})
    assert r.stdout == "envval\n"
    monkeypatch.delenv("NAME_DM")
    r = run(cli, ["sub"], default_map={"sub": {"name": "mapped"}})
    assert r.stdout == "mapped\n"
    r = run(cli, ["sub", "--name", "cmd"], default_map={"sub": {"name": "mapped"}})
    assert r.stdout == "cmd\n"


def test_default_map_string_split_for_multi_value():  # spec: N-000459, N-000460
    @o.command()
    @o.option("-i", multiple=True)
    def leaf(i):
        o.echo(repr(i))

    r = run(leaf, [], default_map={"i": ["a", "b"]})
    assert r.stdout == "('a', 'b')\n"


def test_auto_envvar_prefix(monkeypatch):  # spec: N-000444, N-000445, N-000446
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--token")
    def sub(token):
        o.echo(token)

    monkeypatch.setenv("MYAPP_SUB_TOKEN", "auto")
    r = run(cli, ["sub"], auto_envvar_prefix="myapp")
    assert r.stdout == "auto\n"


def test_auto_envvar_prefix_never_for_arguments(monkeypatch):  # spec: N-000481
    @o.command()
    @o.argument("value", required=False)
    def leaf(value):
        o.echo(repr(value))

    monkeypatch.setenv("MYAPP_VALUE", "nope")
    assert run(leaf, [], auto_envvar_prefix="myapp").stdout == "None\n"


def test_forward_and_invoke_between_commands():  # spec: N-000471, N-000472, N-000473, N-000476
    @o.command()
    @o.argument("n", type=int)
    def target(n):
        o.echo(f"target={n}")

    @o.command()
    @o.argument("n", type=int)
    @o.pass_context
    def caller(ctx, n):
        ctx.invoke(target, n=n + 1)
        ctx.forward(target)

    assert run(caller, ["4"]).stdout == "target=5\ntarget=4\n"


def test_get_current_context_threading_and_silent():  # spec: N-000477, N-000478, N-000479
    with pytest.raises(RuntimeError):
        o.get_current_context()
    assert o.get_current_context(silent=True) is None

    @o.command()
    def leaf():
        o.echo(o.get_current_context().info_name)

    assert run(leaf).stdout == "leaf\n"


# ---------------------------------------------------------------- FP-08 prompts


def test_option_prompt_reads_and_reasks(monkeypatch):  # spec: N-000488, N-000520, N-000521
    @o.command()
    @o.option("--count", type=int, prompt=True, required=True)
    def leaf(count):
        o.echo(count)

    r = CliRunner().invoke(leaf, [], input="x\n7\n")
    assert r.exit_code == 0
    assert "7" in r.stdout.splitlines()[-1]


def test_prompt_only_when_flag_present_without_value(monkeypatch):  # spec: N-000492, N-000493, N-000494
    @o.command()
    @o.option("--name", prompt="Your name")
    def leaf(name):
        o.echo(f"name={name}")

    assert CliRunner().invoke(leaf, [], input="").stdout == "name=None\n"
    r = CliRunner().invoke(leaf, ["--name"], input="zed\n")
    assert "name=zed" in r.stdout


def test_declared_default_still_prompts_and_empty_answer_uses_it():  # spec: N-000497, N-000498
    @o.command()
    @o.option("--name", prompt=True, default="dflt", required=True)
    def leaf(name):
        o.echo(f"name={name}")

    r = CliRunner().invoke(leaf, [], input="\n")
    assert "name=dflt" in r.stdout


def test_confirm_helper_and_abort():  # spec: N-000501, N-000502, N-000503, N-000505, N-000504
    @o.command()
    def leaf():
        ok = o.confirm("Proceed?", abort=False)
        o.echo(f"answer={ok}")

    assert "answer=True" in CliRunner().invoke(leaf, [], input="yes\n").stdout
    assert "answer=False" in CliRunner().invoke(leaf, [], input="n\n").stdout

    @o.command()
    def strict():
        o.confirm("Really?", abort=True)
        o.echo("continued")

    r = CliRunner().invoke(strict, [], input="no\n")
    assert r.exit_code == 1
    assert "continued" not in r.stdout
    assert "Aborted" in r.stderr


def test_eof_during_prompt_is_abort():  # spec: N-000524
    @o.command()
    @o.option("--name", prompt=True, required=True)
    def leaf(name):
        pass

    r = CliRunner().invoke(leaf, [], input="")
    assert r.exit_code == 1
    assert "Aborted" in r.stderr


def test_password_option_confirms_and_mismatch_reasks():  # spec: N-000510, N-000511, N-000512, N-000484
    @o.command()
    @o.password_option()
    def leaf(password):
        o.echo(f"pw={password}")

    r = CliRunner().invoke(leaf, [], input="aa\nbb\ncc\ncc\n")
    assert r.exit_code == 0
    assert "pw=cc" in r.stdout


def test_confirmation_option_flag_skips_question_and_declining_aborts():  # spec: N-000513, N-000514, N-000515, N-000517, N-000518, N-000519
    @o.command()
    @o.confirmation_option(prompt="Drop it?")
    def leaf():
        o.echo("dropped")

    assert run(leaf, ["--yes"]).stdout == "dropped\n"
    r = CliRunner().invoke(leaf, [], input="n\n")
    assert r.exit_code == 1
    assert "dropped" not in r.stdout
    assert "Drop it?" in r.stdout


def test_confirmation_option_positive_answer_runs():  # spec: N-000516
    @o.command()
    @o.confirmation_option()
    def leaf():
        o.echo("ran")

    assert CliRunner().invoke(leaf, [], input="y\n").stdout.endswith("ran\n")


# ---------------------------------------------------------------- FP-09 files and paths already covered; FP-11 terminal


def test_echo_strips_styles_when_not_terminal():  # spec: N-000623, N-000681, N-000683
    buf = io.StringIO()
    o.echo(o.style("hi", fg="red", bold=True), file=buf)
    assert buf.getvalue() == "hi\n"


def test_echo_keeps_styles_when_forced():  # spec: N-000625, N-000682
    buf = io.StringIO()
    o.echo(o.style("hi", fg="red"), file=buf, color=True)
    assert "\x1b[" in buf.getvalue()


def test_style_switches_and_colors_and_invalid():  # spec: N-000628, N-000629, N-000630, N-000639, N-000640
    a = o.style("x", fg="red")
    b = o.style("x", bg="red")
    c = o.style("x", fg="red", bold=True)
    assert a != b and a != c
    assert o.style("x", fg=200) != o.style("x", fg=201)
    assert o.style("x", fg=(1, 2, 3)) != o.style("x", fg=(1, 2, 4))
    with pytest.raises(ValueError):
        o.style("x", fg="ultraviolet")
    assert o.unstyle(o.style("abc", underline=True)) == "abc"


def test_secho_styles_then_echo():  # spec: N-000627
    buf = io.StringIO()
    o.secho("ok", file=buf, fg="green", color=True)
    assert o.unstyle(buf.getvalue()) == "ok\n"


def test_progressbar_visits_all_items_without_terminal():  # spec: N-000649, N-000684, N-000685
    seen = []
    with o.progressbar(["a", "b", "c"], label="work") as bar:
        for item in bar:
            seen.append(item)
    assert seen == ["a", "b", "c"]


def test_hidden_progressbar_prints_nothing(capsys):  # spec: N-000656, N-000650
    with o.progressbar([1, 2], label="quiet", hidden=True) as bar:
        assert list(bar) == [1, 2]
    assert capsys.readouterr().out == ""


def test_pause_does_nothing_without_terminal(capsys):  # spec: N-000662, N-000663, N-000686
    o.pause("press")
    assert capsys.readouterr().out == ""


def test_clear_does_nothing_without_terminal(capsys):  # spec: N-000672, N-000673
    o.clear()
    assert capsys.readouterr().out == ""


def test_get_app_dir_posix_and_xdg(monkeypatch):  # spec: N-000674, N-000675, N-000676, N-000677
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/xdgcfg")
    assert o.get_app_dir("My App") == os.path.join("/tmp/xdgcfg", "my-app")
    monkeypatch.delenv("XDG_CONFIG_HOME")
    home = os.path.expanduser("~")
    assert o.get_app_dir("My App") == os.path.join(home, ".config", "my-app")
    assert o.get_app_dir("My App", force_posix=True) == os.path.join(home, ".my-app")


def test_format_filename_text():  # spec: N-000575, N-000576
    assert o.format_filename("a/b.txt", shorten=True) == "b.txt"
    assert o.format_filename(b"plain.txt") == "plain.txt"


def test_open_file_helper_dash_and_regular(tmp_path):  # spec: N-000532, N-000588
    target = tmp_path / "x.txt"
    with o.open_file(str(target), "w") as fh:
        fh.write("data")
    assert target.read_text() == "data"


def test_formatting_module_exports_wrap_text():  # spec: N-000801, N-000679
    assert wrap_text("a b c", 80) == "a b c"


# ---------------------------------------------------------------- FP-12 completion


def test_completion_source_script_is_produced(monkeypatch):  # spec: N-000701, N-001022
    @o.command()
    def tool():
        o.echo("should not run")

    monkeypatch.setenv("_TOOL_COMPLETE", "bash_source")
    with pytest.raises(SystemExit) as info:
        tool.main([], prog_name="tool")
    assert info.value.code == 0


def test_completion_suggests_subcommands_and_options(monkeypatch, capsys):  # spec: N-000694, N-000695, N-000696, N-000699
    from optlyn.shell_completion import suggest

    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--alpha", help="a help")
    def alpha():
        pass

    @cli.command(hidden=True)
    def hiddenone():
        pass

    names = [i.value for i in suggest(cli, "cli", [], "")]
    assert "alpha" in names and "hiddenone" not in names
    assert "--alpha" not in names
    flags = [i.value for i in suggest(cli, "cli", ["alpha"], "--al")]
    assert flags == ["--alpha"]


def test_completion_choice_values_and_path_requests(tmp_path):  # spec: N-000696, N-000698, N-000700, N-000706
    from optlyn.shell_completion import suggest

    @o.command()
    @o.option("--mode", type=Choice(["fast", "slow"]))
    @o.argument("dest", type=Path(file_okay=False))
    def leaf(mode, dest):
        pass

    values = [i.value for i in suggest(leaf, "leaf", ["--mode"], "f")]
    assert values == ["fast"]
    path_items = suggest(leaf, "leaf", ["--mode", "fast"], "")
    assert path_items and path_items[0].type == "dir"


def test_completion_unknown_instruction_runs_nothing(monkeypatch, capsys):  # spec: N-000714, N-000715
    @o.command()
    def tool():
        o.echo("should not run")

    monkeypatch.setenv("_TOOL_COMPLETE", "tcsh_banana")
    with pytest.raises(SystemExit) as info:
        tool.main([], prog_name="tool")
    assert info.value.code != 0
    assert "should not run" not in capsys.readouterr().out


# ---------------------------------------------------------------- FP-13 exit status


def test_exit_statuses():  # spec: N-000716, N-000717, N-000719, N-000726, N-000732, N-000733
    @o.command()
    def ok():
        pass

    @o.command()
    def stop():
        o.get_current_context().exit(4)

    @o.command()
    def aborted():
        o.get_current_context().abort()

    assert run(ok).exit_code == 0
    assert run(stop).exit_code == 4
    r = run(aborted)
    assert r.exit_code == 1 and "Aborted" in r.stderr


def test_exit_with_zero_success_and_help_zero_vs_missing_command_two():  # spec: N-000718, N-000732
    @o.group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    assert run(cli, ["--help"]).exit_code == 0
    assert run(cli, ["--verbose"]).exit_code == 2


def test_non_standalone_errors_propagate():  # spec: N-000728, N-000731
    @o.command()
    def leaf():
        raise ValueError("boom")

    with pytest.raises(ValueError):
        leaf.main([], standalone_mode=False)


# ---------------------------------------------------------------- FP-14 in-process runner


def test_runner_captures_output_and_exit_and_exception():  # spec: N-000739, N-000758, N-000759, N-000761
    @o.command()
    def boom():
        o.echo("before")
        raise RuntimeError("kaput")

    r = CliRunner().invoke(boom, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, RuntimeError)
    assert "before" in r.stdout

    with pytest.raises(RuntimeError):
        CliRunner(catch_exceptions=False).invoke(boom, [])


def test_runner_stdin_and_prompt_echo_and_env(monkeypatch):  # spec: N-000748, N-000749, N-000750
    @o.command()
    def leaf():
        o.echo(os.environ.get("RUNNER_X", "unset"))
        o.echo(sys.stdin.readline().strip())

    r = CliRunner().invoke(leaf, [], input="typed\n", env={"RUNNER_X": "set-here"})
    assert r.stdout.splitlines() == ["set-here", "typed"]
    assert os.environ.get("RUNNER_X") is None


def test_runner_fd_capture_mode():  # spec: N-000751, N-000752, N-000754
    @o.command()
    def leaf():
        o.echo("py-line")
        os.write(1, b"os-line\n")

    r = CliRunner(capture="fd").invoke(leaf, [])
    assert "py-line" in r.stdout and "os-line" in r.stdout


def test_runner_result_stream_bytes():  # spec: N-001039, N-001040, N-001041
    @o.command()
    def leaf():
        o.echo("out")
        o.echo("err", err=True)

    r = run(leaf)
    assert r.stdout_bytes == b"out\n"
    assert r.stderr_bytes == b"err\n"
    assert r.output == "out\nerr\n"


def test_isolated_filesystem_removed_without_parent(tmp_path):  # spec: N-000744, N-000745, N-000746
    runner = CliRunner()
    cwd = os.getcwd()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
        marker = os.path.join(path, "m.txt")
        open(marker, "w").close()
    assert os.getcwd() == cwd
    assert not os.path.exists(marker)


def test_isolated_filesystem_left_in_place_with_parent(tmp_path):  # spec: N-000747
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        open(os.path.join(path, "kept.txt"), "w").close()
    assert os.path.exists(os.path.join(path, "kept.txt"))


def test_runner_env_none_unsets(monkeypatch):  # spec: N-001038
    monkeypatch.setenv("UNSET_ME", "1")

    @o.command()
    def leaf():
        o.echo(os.environ.get("UNSET_ME", "gone"))

    assert CliRunner().invoke(leaf, [], env={"UNSET_ME": None}).stdout == "gone\n"


# ---------------------------------------------------------------- package surface


def test_public_exports_present():  # spec: N-000797, N-000798, N-000799, N-000800
    for name in ["command", "group", "option", "argument", "help_option", "version_option",
                 "custom_version_option", "password_option", "confirmation_option", "pass_context",
                 "pass_obj", "make_pass_decorator", "Command", "Group", "CommandCollection", "Context",
                 "Option", "Parameter", "ParamType", "BadParameter", "Abort", "STRING", "INT", "FLOAT",
                 "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
                 "File", "Path", "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
                 "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
                 "get_app_dir", "get_current_context", "format_filename", "open_file"]:
        assert hasattr(o, name), name
    assert hasattr(testing, "CliRunner")


def test_callback_reads_earlier_bound_value():  # spec: N-000261, N-000263
    def derive(ctx, param, value):
        if value is None:
            return ctx.params.get("base", "fallback") + "-derived"
        return value

    @o.command()
    @o.option("--base", default="B")
    @o.option("--derived", callback=derive)
    def leaf(base, derived):
        o.echo(f"{base} {derived}")

    assert run(leaf, []).stdout == "B B-derived\n"


def test_leaf_default_map_keyed_by_destination():  # spec: N-000450, N-000462
    @o.command()
    @o.option("--name", default="builtin")
    def leaf(name):
        o.echo(name)

    assert run(leaf, [], default_map={"name": "mapped"}).stdout == "mapped\n"


def test_group_no_args_is_help_explicit_with_invoke_without_command():  # spec: N-000406, N-000409
    @o.group(invoke_without_command=True, no_args_is_help=True)
    def cli():
        o.echo("ran")

    r = run(cli, [])
    assert r.exit_code == 2 and "Usage:" in r.stderr
    assert "ran" not in r.stdout
