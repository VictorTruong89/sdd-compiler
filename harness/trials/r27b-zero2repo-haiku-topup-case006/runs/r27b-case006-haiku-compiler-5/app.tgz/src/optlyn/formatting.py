"""Text formatting helpers."""

from __future__ import annotations

import re
import textwrap

__all__ = ["wrap_text"]

_BLOCK_SPLIT = re.compile(r"\n[ \t]*\n")


# spec: N-000679–N-000680, N-000133–N-000138, N-001009, N-001010
def wrap_text(
    text: str,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not preserved as hard breaks.
    A paragraph whose first line is only a backspace character is not
    rewrapped: its line breaks are kept and the backspace line is removed.
    Any string is accepted.
    """
    if not text:
        return ""
    width = max(int(width), 10)
    rendered: list[str] = []
    for block in _BLOCK_SPLIT.split(text.strip("\n")):
        lines = block.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [line for line in lines[1:]]
            rendered.append("\n".join(initial_indent + line if i == 0 else subsequent_indent + line
                                      for i, line in enumerate(kept)))
            continue
        body = " ".join(line.strip() for line in lines if line.strip())
        if not body:
            continue
        rendered.append(
            textwrap.fill(
                body,
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(rendered)
