"""Parameter types and value conversion."""

from __future__ import annotations

import datetime as _dt
import enum
import io
import os
import pathlib
import sys
import tempfile
import uuid as _uuid
from typing import Any

from .exceptions import BadParameter, FileError

__all__ = [
    "ParamType", "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    "convert_type", "TRUE_STRINGS", "FALSE_STRINGS", "open_stream",
]

TRUE_STRINGS = frozenset({"1", "true", "t", "yes", "y", "on"})
FALSE_STRINGS = frozenset({"0", "false", "f", "no", "n", "off"})


# spec: N-000370–N-000374, N-000935
class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement ``convert(value, param, ctx)``,
    which refuses invalid input by raising :class:`BadParameter`.
    """

    name: str = "text"
    is_composite: bool = False

    def __call__(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        if value is None:
            return None
        try:
            return self.convert(value, param, ctx)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = param
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    def convert(self, value: Any, param: Any, ctx: Any) -> Any:
        return value

    def get_metavar(self, param: Any = None) -> str:
        return self.name.upper().replace(" ", "_")

    def split_envvar_value(self, text: str) -> list[str]:
        return text.split()

    def shell_complete(self, ctx: Any, param: Any, incomplete: str) -> list:
        return []

    def fail(self, message: str, param: Any = None, ctx: Any = None) -> None:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


def _normalize(value: str, ctx: Any) -> str:
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    return func(value) if func else value


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_STRINGS:
            return True
        if text in FALSE_STRINGS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


# spec: N-000348–N-000352, N-000382–N-000383
class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration.

    Matching is case-sensitive unless ``case_sensitive=False``. The delivered
    value is the original choice object (enumeration member or list entry).
    """

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self._keys = [str(choice) for choice in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(self._keys) + "]"

    def convert(self, value, param, ctx):
        if any(value is choice for choice in self.choices):
            return value
        token = _normalize(str(value), ctx)
        for choice, key in zip(self.choices, self._keys):
            candidate = _normalize(key, ctx)
            if self.case_sensitive:
                matched = candidate == token
            else:
                matched = candidate.casefold() == token.casefold()
            if matched:
                return choice
        options = ", ".join(repr(key) for key in self._keys)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(key) for key in self._keys if key.startswith(incomplete)]


# spec: N-000353–N-000357
class DateTime(ParamType):
    """Parses a date-time. Formats are tried in order; the first match wins."""

    name = "datetime"
    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None) -> None:
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


# spec: N-000358–N-000365, N-000381
class _NumericRange(ParamType):
    base: ParamType = INT

    def __init__(self, min=None, max=None, min_open: bool = False, max_open: bool = False,
                 clamp: bool = False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("The minimum bound cannot be greater than the maximum bound.")

    def get_metavar(self, param=None):
        return self.base.get_metavar(param)

    def _describe(self) -> str:
        left = "(" if self.min_open else "["
        right = ")" if self.max_open else "]"
        low = "-inf" if self.min is None else self.min
        high = "inf" if self.max is None else self.max
        return f"{left}{low}, {high}{right}"

    def convert(self, value, param, ctx):
        number = self.base.convert(value, param, ctx)
        below = self.min is not None and (number <= self.min if self.min_open else number < self.min)
        above = self.max is not None and (number >= self.max if self.max_open else number > self.max)
        if not (below or above):
            return number
        if self.clamp:
            if below:
                return self._adjacent_or_bound(self.min, self.min_open, +1)
            return self._adjacent_or_bound(self.max, self.max_open, -1)
        self.fail(f"{number} is not in the range {self._describe()}.", param, ctx)

    def _adjacent_or_bound(self, bound, is_open, step):
        return bound + step if is_open else bound


class IntRange(_NumericRange):
    """An integer that must lie in an optional range. Clamp to an open bound uses the adjacent integer."""

    name = "integer range"
    base = INT


class FloatRange(_NumericRange):
    """A float that must lie in an optional range."""

    name = "float range"
    base = FLOAT

    def __init__(self, min=None, max=None, min_open: bool = False, max_open: bool = False,
                 clamp: bool = False) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamp is not allowed for a float range with an open bound.")
        super().__init__(min, max, min_open, max_open, clamp)


# spec: N-000366
class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [convert_type(t) for t in types]

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param, ctx):
        values = list(value)
        if len(values) != len(self.types):
            self.fail(f"Takes {len(self.types)} values but {len(values)} were given.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, values))


# ---------------------------------------------------------------- file handling


# spec: N-000546–N-000547, N-000588–N-000590
class _NonClosing:
    """Wraps a standard stream: flushes on close but never closes it."""

    def __init__(self, stream) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_stream"), name)

    def __iter__(self):
        return iter(object.__getattribute__(self, "_stream"))

    def __next__(self):
        return next(object.__getattribute__(self, "_stream"))

    def close(self) -> None:
        object.__getattribute__(self, "_stream").flush()

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


# spec: N-000542–N-000543
class _AtomicFile:
    """Writes to a sibling temporary file; replaces the target on close."""

    def __init__(self, filename: str, mode: str, encoding, errors) -> None:
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
        self._file = open(self._tmp, mode, **kwargs)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_file"), name)

    def close(self) -> None:
        if self._file.closed:
            return
        self._file.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def _raw_open(filename: str, mode: str, encoding, errors, atomic: bool):
    if atomic and ("w" in mode or "a" in mode or "x" in mode):
        return _AtomicFile(filename, mode, encoding, errors)
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    return open(filename, mode, **kwargs)


# spec: N-000536, N-000578–N-000582
class LazyFile:
    """A file that opens on first I/O. A failure then is a general file error."""

    def __init__(self, filename: str, mode: str, encoding, errors, atomic: bool) -> None:
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._file = None

    def _open(self):
        if self._file is None:
            try:
                self._file = _raw_open(self._filename, self._mode, self._encoding, self._errors, self._atomic)
            except OSError as exc:
                raise FileError(f"Could not open file {self._filename!r}: {exc.strerror or exc}",
                                filename=self._filename) from exc
        return self._file

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __next__(self):
        return next(self._open())

    def close(self) -> None:
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def _std_stream(mode: str, encoding, errors):
    stream = sys.stdin if "r" in mode else sys.stdout
    if "b" in mode:
        stream = getattr(stream, "buffer", stream)
    elif encoding:
        stream = io.TextIOWrapper(stream.buffer, encoding=encoding, errors=errors, write_through=True)
    return _NonClosing(stream)


# spec: N-000532–N-000545, N-000578–N-000582, N-000588–N-000590
def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=None, atomic=False,
                param=None, ctx=None):
    """Open ``filename`` honouring the dash-as-standard-stream rule.

    Writing modes are lazy by default; reading opens immediately. A failure
    to open at conversion time is a usage error when ``param`` is given, and
    a general file error otherwise.
    """
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    writing = any(flag in mode for flag in "wax")
    if lazy is None:
        lazy = writing
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _raw_open(filename, mode, encoding, errors, atomic)
    except OSError as exc:
        message = f"Could not open file {filename!r}: {exc.strerror or exc}"
        if param is not None or ctx is not None:
            raise BadParameter(message, ctx=ctx, param=param) from exc
        raise FileError(message, filename=filename) from exc


# spec: N-000367, N-000528–N-000545, N-000578–N-000582
class File(ParamType):
    """Opens a file; the value is an open file object."""

    name = "filename"

    def __init__(self, mode: str = "r", encoding=None, errors: str = "strict", lazy=None,
                 atomic: bool = False) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def split_envvar_value(self, text):
        return text.split(os.pathsep)

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        return open_stream(str(value), self.mode, self.encoding, self.errors, self.lazy, self.atomic,
                           param=param, ctx=ctx)


# spec: N-000368, N-000548–N-000587
class Path(ParamType):
    """Validates a filesystem path and returns it (not an open file)."""

    name = "path"

    def __init__(self, exists: bool = False, file_okay: bool = True, dir_okay: bool = True,
                 writable: bool = False, readable: bool = True, resolve_path: bool = False,
                 allow_dash: bool = False, path_type=None, executable: bool = False) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def split_envvar_value(self, text):
        return text.split(os.pathsep)

    def _deliver(self, text: str):
        if self.path_type is None or self.path_type is str:
            return text
        if self.path_type is pathlib.Path:
            return pathlib.Path(text)
        return self.path_type(text)

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        text = str(value)
        if self.allow_dash and text == "-":
            return self._deliver("-")
        if self.resolve_path:
            text = os.path.realpath(os.path.abspath(text))
        if not os.path.exists(text):
            if self.exists:
                self.fail("Does not exist.", param, ctx)
            return self._deliver(text)
        if os.path.isdir(text):
            if not self.dir_okay:
                self.fail("Is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail("Is a file.", param, ctx)
        if self.readable and not os.access(text, os.R_OK):
            self.fail("Not readable.", param, ctx)
        if self.writable and not os.access(text, os.W_OK):
            self.fail("Not writable.", param, ctx)
        if self.executable and not os.access(text, os.X_OK):
            self.fail("Not executable.", param, ctx)
        return self._deliver(text)


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses with ValueError."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


_BUILTIN_TYPES = {int: INT, float: FLOAT, bool: BOOL, str: STRING}


# spec: N-000330–N-000331, N-000336, N-000183
def convert_type(ty: Any = None, default: Any = None) -> ParamType:
    """Resolve a type spec (ParamType, ParamType subclass, builtin, function) to an instance.

    With no type spec, the type is inferred from ``default``.
    """
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, (list, tuple)) and default:
            return convert_type(None, default[0])
        return STRING
    if ty in _BUILTIN_TYPES:
        return _BUILTIN_TYPES[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
