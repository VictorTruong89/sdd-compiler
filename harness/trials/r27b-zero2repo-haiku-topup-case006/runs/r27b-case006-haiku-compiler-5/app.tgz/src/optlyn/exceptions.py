"""Exceptions signalled by Optlyn.

Exit statuses (standalone mode): usage errors exit 2; aborts, general
errors and file-open failures at first I/O exit 1; author clean stops exit
with the status the author supplied (0 by default).
"""

from __future__ import annotations

from typing import Any


class OptlynError(Exception):
    """Base class for errors that Optlyn reports to the user or caller."""

    exit_code = 1

    def __init__(self, message: str, ctx: Any = None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self) -> None:
        from .termui import echo

        echo(f"Error: {self.message}", err=True)


class UsageError(OptlynError):
    """The user invoked the program incorrectly (exit status 2)."""

    exit_code = 2

    def _usage_hint(self) -> str:
        ctx = self.ctx
        if ctx is None:
            return ""
        lines = [f"Usage: {ctx.command.get_usage(ctx)}"]
        if ctx.help_option_names:
            lines.append(f"Try '{ctx.command_path} {ctx.help_option_names[0]}' for help.")
        return "\n".join(lines) + "\n\n"

    def show(self) -> None:
        from .termui import echo

        echo(self._usage_hint() + f"Error: {self.format_message()}", err=True)

    def format_message(self) -> str:
        return self.message


class BadParameter(UsageError):
    """A value was refused: raised by a type, a conversion function or a callback."""

    def __init__(self, message: str, ctx: Any = None, param: Any = None, param_hint: Any = None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.describe()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self) -> str:
        if self.param is None:
            return self.message
        kind = getattr(self.param, "param_type_name", "parameter")
        return f"Missing {kind} {self.param.describe()}."


class NoSuchOption(UsageError):
    """An unknown option token was used."""

    def __init__(self, option_name: str, message: str | None = None, ctx: Any = None) -> None:
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, without its required value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly (for example, too many arguments)."""


class NoArgsIsHelp(UsageError):
    """A command configured with no-args-is-help was invoked with no arguments.

    The help page is printed on standard error and the exit status is the
    usage-error status (2); no separate error line is shown.
    """

    def show(self) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), err=True)


class Abort(RuntimeError):
    """The user or the author aborted the program (exit status 1)."""


class Exit(RuntimeError):
    """An author or intentional clean stop. ``exit_code`` is the status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit status 1)."""

    exit_code = 1

    def __init__(self, message: str, filename: str | None = None, ctx: Any = None) -> None:
        super().__init__(message, ctx)
        self.filename = filename
