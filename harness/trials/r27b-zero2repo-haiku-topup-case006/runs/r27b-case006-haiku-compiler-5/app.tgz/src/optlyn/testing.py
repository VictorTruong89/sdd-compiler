"""In-process runner: invoke a command with argument tokens and capture its output."""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
from dataclasses import dataclass
from typing import Any

__all__ = ["CliRunner", "Result"]


@dataclass
# spec: N-001039–N-001043
class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    runner: "CliRunner"
    stdout_bytes: bytes
    stderr_bytes: bytes
    output_bytes: bytes
    exit_code: int
    exception: BaseException | None
    charset: str = "utf-8"

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.charset, "replace")


class _Recorder:
    """Records writes in order, tagged with the stream they went to."""

    def __init__(self) -> None:
        self.entries: list[tuple[str, bytes]] = []

    def bytes_for(self, name: str) -> bytes:
        return b"".join(data for kind, data in self.entries if kind == name)

    def all_bytes(self) -> bytes:
        return b"".join(data for _, data in self.entries)


class _RecordingRaw(io.RawIOBase):
    def __init__(self, recorder: _Recorder, name: str) -> None:
        self._recorder = recorder
        self._name = name

    def writable(self) -> bool:
        return True

    def write(self, data) -> int:
        data = bytes(data)
        self._recorder.entries.append((self._name, data))
        return len(data)


class _EchoingStdin(io.TextIOWrapper):
    """Stdin fed from the invoke input; optionally echoes what was read."""

    def __init__(self, data: bytes, charset: str, recorder: _Recorder, echo: bool) -> None:
        super().__init__(io.BytesIO(data), encoding=charset, write_through=True)
        self._recorder = recorder
        self._echo = echo

    def readline(self, size: int = -1) -> str:
        line = super().readline(size)
        if self._echo and line:
            self._recorder.entries.append(("stdout", line.encode(self.encoding, "replace")))
        return line

    def isatty(self) -> bool:
        return False


@contextlib.contextmanager
# spec: N-000751–N-000755
def _fd_capture(charset: str, recorder: "_Recorder"):
    """Capture OS-level writes to descriptors 1 and 2 as well as interpreter writes.

    While active, the interpreter streams report real descriptors. stdout
    and stderr are recorded separately, since descriptor writes carry no
    ordering between the two.
    """
    prev_out, prev_err = sys.stdout, sys.stderr
    prev_out.flush()
    prev_err.flush()
    out_file = tempfile.TemporaryFile()
    err_file = tempfile.TemporaryFile()
    saved_fds = (os.dup(1), os.dup(2))
    os.dup2(out_file.fileno(), 1)
    os.dup2(err_file.fileno(), 2)
    sys.stdout = io.TextIOWrapper(os.fdopen(os.dup(1), "wb", buffering=0), encoding=charset,
                                  errors="strict", write_through=True)
    sys.stderr = io.TextIOWrapper(os.fdopen(os.dup(2), "wb", buffering=0), encoding=charset,
                                  errors="backslashreplace", write_through=True)
    try:
        yield
    finally:
        sys.stdout.flush()
        sys.stderr.flush()
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout, sys.stderr = prev_out, prev_err
        os.dup2(saved_fds[0], 1)
        os.dup2(saved_fds[1], 2)
        os.close(saved_fds[0])
        os.close(saved_fds[1])
        out_file.seek(0)
        err_file.seek(0)
        recorder.entries.append(("stdout", out_file.read()))
        recorder.entries.append(("stderr", err_file.read()))
        out_file.close()
        err_file.close()


# spec: N-001038–N-001044, N-000736–N-000763
class CliRunner:
    """Runs commands in-process and captures standard output, standard error and the exit status."""

    def __init__(self, charset: str = "utf-8", env: dict | None = None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input: bytes, env: dict | None, recorder: _Recorder):
        env_all = dict(self.env)
        env_all.update(env or {})
        saved_env = {}
        for key, value in env_all.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin = _EchoingStdin(input, self.charset, recorder, self.echo_stdin)
        try:
            if self.capture == "fd":
                with _fd_capture(self.charset, recorder):
                    yield
            else:
                sys.stdout = io.TextIOWrapper(_RecordingRaw(recorder, "stdout"), encoding=self.charset,
                                              errors="strict", write_through=True)
                sys.stderr = io.TextIOWrapper(_RecordingRaw(recorder, "stderr"), encoding=self.charset,
                                              errors="backslashreplace", write_through=True)
                yield
        finally:
            for stream in (sys.stdout, sys.stderr):
                if stream is not saved[1] and stream is not saved[2]:
                    stream.flush()
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color: bool = False, **extra: Any) -> Result:
        """Invoke ``cli`` with ``args`` (a list of tokens) and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        extra.setdefault("color", color)
        recorder = _Recorder()
        exit_code = 0
        exception: BaseException | None = None
        with self.isolation(data, env, recorder):
            try:
                cli.main(args=list(args), prog_name=prog_name, **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
                if exit_code != 0:
                    exception = exc
            except Exception as exc:  # noqa: BLE001
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
        return Result(
            runner=self,
            stdout_bytes=recorder.bytes_for("stdout"),
            stderr_bytes=recorder.bytes_for("stderr"),
            output_bytes=recorder.all_bytes(),
            exit_code=exit_code,
            exception=exception,
            charset=self.charset,
        )

    @contextlib.contextmanager
    # spec: N-000744–N-000747, N-001044
    def isolated_filesystem(self, temp_dir: str | None = None):
        """Change into a new empty directory for the duration of the block.

        With no ``temp_dir`` the directory is created in the system temp area and
        removed on exit; with ``temp_dir`` it is created under that path and left in place.
        """
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
