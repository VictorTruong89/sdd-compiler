"""Core model: invocation context, parameters, commands and groups, decorators.

Flow of one invocation (standalone or not):

1. ``Command.make_context`` creates a :class:`Context`, tokenizes the argument
   list (``_parse``) and resolves every parameter's value (``_process``),
   running parameter callbacks; eager flags such as ``--help`` may stop here.
2. ``Command.invoke`` runs the author callback. Groups dispatch to a child
   by making the child's context and invoking it.
"""

from __future__ import annotations

import enum
import functools
import inspect
import os
import re
import shutil
import sys
import threading
from contextlib import ExitStack
from typing import Any, Callable

from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import wrap_text
from .termui import confirm, echo, prompt
from .types import BOOL, INT, Tuple, convert_type

__all__ = [
    "Context", "Parameter", "Option", "Argument", "Command", "Group", "CommandCollection",
    "ParameterSource", "get_current_context", "command", "group", "option", "argument",
    "help_option", "version_option", "custom_version_option", "password_option",
    "confirmation_option", "pass_context", "pass_obj", "make_pass_decorator",
]

_PREFIX_CHARS = ("-", "/", "+")
_PARAMS_ATTR = "__optlyn_params__"
_HELP_EXTRA_WIDTH = 2
_SHORT_HELP_LIMIT = 45


# ------------------------------------------------------------------ context stack

_local = threading.local()


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


# spec: N-000978–N-000980
def get_current_context(silent: bool = False):
    """Return the context current on this thread.

    Raises RuntimeError when there is none, unless ``silent`` is true, in
    which case None is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


class _ChainMarker:
    """Value of ``invoked_subcommand`` on a chaining group that runs children."""

    def __repr__(self) -> str:
        return "<chained subcommands>"


CHAIN_MARKER = _ChainMarker()


# spec: N-000434–N-000483 (FP-07), N-000950–N-000980 (Interface §6)
class Context:
    """The invocation context: parsed values, parent linkage, settings."""

    def __init__(
        self,
        command: "Command",
        parent: "Context | None" = None,
        info_name: str | None = None,
        obj: Any = None,
        default_map: dict | None = None,
        terminal_width: int | None = None,
        max_content_width: int | None = None,
        help_option_names: list | None = None,
        token_normalize_func: Callable[[str], str] | None = None,
        color: bool | None = None,
        show_default: bool | None = None,
        auto_envvar_prefix: str | None = None,
        allow_extra_args: bool | None = None,
        allow_interspersed_args: bool | None = None,
        ignore_unknown_options: bool | None = None,
        **extra: Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self._obj = obj
        self.default_map = default_map
        self.meta = extra
        p = parent

        def inherit(value, name, fallback=None):
            if value is not None:
                return value
            return getattr(p, name) if p is not None else fallback

        self.terminal_width = inherit(terminal_width, "terminal_width")
        self.max_content_width = inherit(max_content_width, "max_content_width", 80)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func")
        self.color = inherit(color, "color")
        self.show_default = inherit(show_default, "show_default")
        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix")
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None
            else command.allow_interspersed_args
        )
        self.ignore_unknown_options = (
            ignore_unknown_options if ignore_unknown_options is not None
            else command.ignore_unknown_options
        )
        self.params: dict[str, Any] = {}
        self._sources: dict[str, ParameterSource] = {}
        self.invoked_subcommand: Any = None
        self.protected_args: list[str] = []
        self.args: list[str] = []
        self._exit_stack = ExitStack() if parent is None else None

    # -- identity and linkage

    @property
    def obj(self) -> Any:
        node: Context | None = self
        while node is not None:
            if node._obj is not None:
                return node._obj
            node = node.parent
        return None

    @obj.setter
    def obj(self, value: Any) -> None:
        self._obj = value

    @property
    def command_path(self) -> str:
        names = []
        node: Context | None = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    # spec: N-000133–N-000138, N-000680
    def get_wrap_width(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        detected = shutil.get_terminal_size((80, 24)).columns
        return max(min(detected, self.max_content_width), 20)

    # spec: N-000827–N-000849, N-000110–N-000177 (FP-02)
    def get_help(self) -> str:
        return self.command.get_help(self)

    # -- context manager: makes this context current on the entering thread

    def __enter__(self) -> "Context":
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)
        return False

    # -- resources

    # spec: N-000467
    def with_resource(self, cm):
        return self.find_root()._exit_stack.enter_context(cm)

    def call_on_close(self, func) -> None:
        self.find_root()._exit_stack.callback(func)

    def close(self) -> None:
        self.find_root()._exit_stack.close()

    # -- control

    def exit(self, code: int = 0) -> None:
        raise Exit(code)

    def abort(self) -> None:
        raise Abort()

    # spec: N-000463–N-000466
    def get_parameter_source(self, name: str):
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    # spec: N-000083–N-000090, N-000716–N-000722
    def invoke(self, callback, *args, **kwargs):
        """Run a function, or another leaf command, from inside a callback."""
        if isinstance(callback, Command) and not isinstance(callback, Group):
            other = callback
            sub = Context(other, parent=self, info_name=other.name)
            for p in other.get_params(sub):
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.value_when_absent(sub)
            sub.params.update({k: v for k, v in kwargs.items()})
            with sub:
                return other._run_callback(sub)
        if isinstance(callback, Command):
            raise TypeError("Invoking a group from a callback is not supported.")
        with self:
            return callback(*args, **kwargs)

    # spec: N-000471–N-000476
    def forward(self, cmd, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)


# ------------------------------------------------------------------ parameters

_PROMPT = object()  # occurrence marker: the option was present without a value


class _Converted:
    """An occurrence whose value is already known (flags, counts, environment flags)."""

    __slots__ = ("value",)

    def __init__(self, value: Any) -> None:
        self.value = value


class _ParseResult:
    def __init__(self) -> None:
        self.occ: dict[Any, list] = {}
        self.eager: list = []
        self.args: list[str] = []
        self.leftover: list[str] = []

    def add(self, param, occurrence) -> None:
        self.occ.setdefault(param, []).append(occurrence)
        if getattr(param, "is_eager", False) and param not in self.eager:
            self.eager.append(param)


def _chain_below_root(ctx: Context) -> list[str]:
    names = []
    node = ctx
    while node.parent is not None:
        names.append(node.info_name or "")
        node = node.parent
    return list(reversed(names))


def _warn_deprecated(ctx, kind: str, name: str, note) -> None:
    text = f"DeprecationWarning: The {kind} {name!r} is deprecated."
    if isinstance(note, str) and note:
        text += f" {note}"
    echo(text, err=True)


# spec: N-000921–N-000923, N-000881–N-000884
class Parameter:
    """Base class of :class:`Option` and :class:`Argument`."""

    param_type_name = "parameter"

    def __init__(
        self,
        name: str,
        *,
        type: Any = None,
        default: Any = None,
        required: bool = False,
        callback: Callable | None = None,
        nargs: int = 1,
        multiple: bool = False,
        metavar: str | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: Any = None,
        shell_complete: Callable | None = None,
        deprecated: Any = False,
        help: str | None = None,
        hidden: bool = False,
        allow_from_autoenv: bool = True,
        show_default: Any = None,
        show_envvar: bool = False,
    ) -> None:
        if deprecated and required:
            raise TypeError("A deprecated parameter cannot also be required.")
        self.name = name
        self.default = default
        self.type: Any = convert_type(type, default)
        if isinstance(self.type, Tuple):
            nargs = len(self.type.types)
        if not (nargs == -1 or (isinstance(nargs, int) and nargs >= 1)):
            raise TypeError("nargs must be a positive integer, or -1 for a variadic argument.")
        self.nargs = nargs
        self.multiple = multiple
        self.required = required
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar: list[str] = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.allow_from_autoenv = allow_from_autoenv
        self.show_default = show_default
        self.show_envvar = show_envvar

    # helpers shared by subclasses

    @property
    def is_variadic(self) -> bool:
        return self.nargs == -1

    @property
    def _auto_default(self) -> bool:
        return False

    def _explicit_default(self) -> bool:
        return self.default is not None and not self._auto_default

    def describe(self) -> str:
        """The identity of this parameter as shown in messages."""
        raise NotImplementedError

    def get_default(self, ctx: Context | None = None) -> Any:
        if callable(self.default):
            return self.default()
        return self.default

    def value_when_absent(self, ctx: Context) -> Any:
        if self.default is not None:
            return self.get_default(ctx)
        return self._empty()

    def _empty(self) -> Any:
        if self.multiple or self.is_variadic:
            return ()
        return None

    def _is_sequence_shape(self) -> bool:
        return self.nargs != 1 or isinstance(self.type, Tuple)

    def _convert_tokens(self, ctx: Context, tokens) -> Any:
        tokens = list(tokens)
        if isinstance(self.type, Tuple):
            if len(tokens) != len(self.type.types):
                raise BadParameter(f"Takes {len(self.type.types)} values.", ctx=ctx, param=self)
            return tuple(t(tok, self, ctx) for t, tok in zip(self.type.types, tokens))
        if not self._is_sequence_shape():
            return self.type(tokens[0], self, ctx)
        return tuple(self.type(tok, self, ctx) for tok in tokens)

    def _coerce_default_item(self, ctx: Context, item: Any) -> Any:
        if isinstance(item, str):
            return self.type(item, self, ctx)
        return item

    # spec: N-000182–N-000187, N-000276–N-000279, N-000450–N-000462
    def _default_value(self, ctx: Context, raw: Any, from_map: bool) -> Any:
        """Deliver a declared default or default-map value."""
        if self.multiple:
            if isinstance(raw, str):
                if self.nargs == 1:
                    raise BadOptionUsage(
                        f"The default for {self.describe()} must be an iterable (sequence) of values, "
                        "not a string.",
                        ctx=ctx,
                    )
                tokens = self.type.split_envvar_value(raw)
                chunks = [tokens[k:k + self.nargs] for k in range(0, len(tokens), self.nargs)]
                return tuple(self._convert_tokens(ctx, chunk) for chunk in chunks)
            if self.nargs == 1:
                return tuple(self._coerce_default_item(ctx, item) for item in raw)
            return tuple(
                tuple(self._coerce_default_item(ctx, x) for x in item) if not isinstance(item, str)
                else self._convert_tokens(ctx, [item])
                for item in raw
            )
        if isinstance(raw, str):
            if self._is_sequence_shape() and not isinstance(self.type, Tuple) and self.nargs != 1:
                return self._convert_tokens(ctx, self.type.split_envvar_value(raw))
            if isinstance(self.type, Tuple) and self.nargs > 1:
                return self._convert_tokens(ctx, self.type.split_envvar_value(raw))
            return self.type(raw, self, ctx)
        if isinstance(raw, (list, tuple)) and self.nargs != 1:
            return tuple(self._coerce_default_item(ctx, x) for x in raw)
        return raw

    def _finish(self, ctx: Context, value: Any) -> Any:
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def _warn_if_deprecated(self, ctx: Context) -> None:
        if self.deprecated:
            _warn_deprecated(ctx, self.param_type_name, self.name, self.deprecated)

    def process(self, ctx: Context, res: _ParseResult):  # pragma: no cover - overridden
        raise NotImplementedError


# spec: N-000178–N-000233 (FP-03), N-000881–N-000909 (Interface §4)
class Option(Parameter):
    """A named parameter, introduced by a prefix character (``-``, ``--``, ``/``, ``+``)."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls=(),
        *,
        is_flag: bool | None = None,
        flag_value: Any = None,
        count: bool = False,
        prompt: Any = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        name: str | None = None,
        **kwargs: Any,
    ) -> None:
        opts, secondary, decl_name = _split_decls(param_decls)
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        dest = name or decl_name or _derive_dest(opts)
        default = kwargs.get("default")
        if is_flag is None:
            is_flag = bool(secondary) or (kwargs.get("type") is None and isinstance(default, bool))
        if count:
            is_flag = False
        if is_flag and flag_value is None:
            flag_value = True
        if is_flag and kwargs.get("type") is None:
            kwargs["type"] = BOOL if isinstance(flag_value, bool) else None
        if count and kwargs.get("type") is None:
            kwargs["type"] = INT
        super().__init__(dest, **kwargs)
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.is_optional_value = (not self.is_flag and not self.count and flag_value is not None)
        if self.count:
            self.nargs = 1
        if self.deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot be required.")
        self.prompt_enabled = bool(prompt)
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt

    @property
    def _auto_default(self) -> bool:
        return self.is_flag and self.default is None

    def value_when_absent(self, ctx: Context) -> Any:
        if self.default is not None:
            return self.get_default(ctx)
        return self._empty_for_option()

    # spec: N-000146–N-000151
    def get_help_text(self, ctx: Context) -> str:
        """Help text followed by bracketed extras (default, environment variable, required)."""
        parts: list[str] = []
        if self.help:
            parts.append(self.help)
        extras: list[str] = []
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show and self.default is not None and not (self.is_flag and self.default is False):
            if isinstance(show, str):
                extras.append(f"default: {show}")
            elif callable(self.default):
                extras.append("default: (dynamic)")
            else:
                extras.append(f"default: {self.default}")
        if self.show_envvar:
            names = self.envvar_names(ctx)
            if names:
                extras.append(f"env var: {' / '.join(names)}")
        if self.required:
            extras.append("required")
        if self.deprecated:
            extras.append("deprecated")
        if extras:
            parts.append(" ".join(f"[{e}]" for e in extras))
        return " ".join(parts)

    def describe(self) -> str:
        if self.secondary_opts:
            return f"'{self.opts[0]}/{self.secondary_opts[0]}'"
        return " / ".join(f"'{o}'" for o in self.opts)

    def display_names(self) -> str:
        if self.secondary_opts:
            return f"{self.opts[0]}/{self.secondary_opts[0]}"
        return ", ".join(self.opts)

    def takes_value(self) -> bool:
        return not (self.is_flag or self.count)

    def get_metavar_text(self) -> str | None:
        if self.metavar:
            return self.metavar
        if not self.takes_value():
            return None
        return self.type.get_metavar(self).replace(" ", "_")

    # spec: N-000444–N-000449, N-000309–N-000317
    def envvar_names(self, ctx: Context | None) -> list[str]:
        if self.envvar:
            return list(self.envvar)
        if self.allow_from_autoenv and ctx is not None and ctx.auto_envvar_prefix:
            parts = [ctx.auto_envvar_prefix] + _chain_below_root(ctx) + [self.name]
            return ["_".join(str(p).upper().replace("-", "_") for p in parts)]
        return []

    # -- occurrence handling

    def _occ_value(self, ctx: Context, occ) -> Any:
        if isinstance(occ, _Converted):
            return occ.value
        return self._convert_tokens(ctx, occ)

    def _combine(self, ctx: Context, occs) -> Any:
        values = [self._occ_value(ctx, o) for o in occs]
        if self.multiple:
            return tuple(values)
        return values[-1] if values else self._empty()

    # spec: N-000227–N-000233, N-000446–N-000447
    def _env_occurrences(self, ctx: Context) -> list:
        for name in self.envvar_names(ctx):
            text = os.environ.get(name)
            if text is None or text == "":
                continue
            if self.is_flag:
                value = self._env_flag_value(ctx, text)
                return [] if value is _UNSET else [_Converted(value)]
            if self.count:
                return []
            if self.multiple or self.nargs != 1 or isinstance(self.type, Tuple):
                tokens = self.type.split_envvar_value(text)
                chunks = [tuple(tokens[k:k + self.nargs]) for k in range(0, len(tokens), self.nargs)]
                chunks = [c for c in chunks if len(c) == self.nargs] or chunks
                return chunks if self.multiple else chunks[:1]
            return [(text,)]
        return []

    # spec: N-000234–N-000242
    def _env_flag_value(self, ctx: Context, text: str):
        stripped = text.strip().lower()
        flag_value = self.flag_value
        if isinstance(flag_value, bool):
            if stripped == "":
                return False
            if stripped in _TRUE_TOKENS:
                return True
            if stripped in _FALSE_TOKENS:
                return False
            raise BadParameter(f"{text!r} is not a valid boolean.", ctx=ctx, param=self)
        if text == str(flag_value) or stripped in _TRUE_TOKENS:
            return flag_value
        if stripped in _FALSE_TOKENS:
            return False
        return _UNSET

    # spec: N-000488–N-000491, N-000520–N-000522
    def _prompt_value(self, ctx: Context, default: Any) -> Any:
        text = self.prompt_text or self.name.replace("_", " ").capitalize()

        def convert(raw: str):
            return self.type(raw, self, ctx)

        return prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=convert,
        )

    # spec: N-000243–N-000245, N-000200–N-000201, N-000492–N-000500
    def _resolve_missing(self, ctx: Context, marker: bool):
        env = self._env_occurrences(ctx)
        if env:
            return self._combine(ctx, env), ParameterSource.ENVIRONMENT
        map_present = self._map_present(ctx)
        map_value = ctx.default_map[self.name] if map_present else None
        declared = self.get_default(ctx)
        prompt_needed = self.prompt_enabled and (marker or self.required)
        if prompt_needed:
            shown = map_value if map_present else declared
            return self._prompt_value(ctx, shown), ParameterSource.PROMPT
        if map_present:
            return self._default_value(ctx, map_value, from_map=True), ParameterSource.DEFAULT_MAP
        if declared is not None:
            return self._default_value(ctx, declared, from_map=False), ParameterSource.DEFAULT
        if self.required:
            raise MissingParameter("required", ctx=ctx, param=self)
        return self._empty_for_option(), ParameterSource.DEFAULT

    def _empty_for_option(self) -> Any:
        if self.count:
            return 0
        if self.is_flag:
            return False
        return self._empty()

    def _map_present(self, ctx: Context) -> bool:
        dm = ctx.default_map
        return isinstance(dm, dict) and self.name in dm

    def process(self, ctx: Context, res: _ParseResult):
        occ = res.occ.get(self, [])
        marker = any(o is _PROMPT for o in occ)
        real = [o for o in occ if o is not _PROMPT]
        if real:
            self._warn_if_deprecated(ctx)
            if self.count:
                value, source = len(real), ParameterSource.COMMANDLINE
            else:
                value, source = self._combine(ctx, real), ParameterSource.COMMANDLINE
        else:
            value, source = self._resolve_missing(ctx, marker)
        return self._finish(ctx, value), source


_UNSET = object()
_TRUE_TOKENS = frozenset({"true", "1", "yes", "on", "t", "y"})
_FALSE_TOKENS = frozenset({"false", "0", "no", "off", "f", "n"})


# spec: N-000285–N-000329 (FP-04), N-000910–N-000912
class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(self, param_decls=(), *, name: str | None = None, required: bool | None = None,
                 nargs: int = 1, **kwargs: Any) -> None:
        decls = list(param_decls)
        if name is None:
            if len(decls) != 1 or not isinstance(decls[0], str):
                raise TypeError("An argument takes exactly one destination name.")
            name = decls[0]
        if not (nargs == -1 or (isinstance(nargs, int) and nargs >= 1)):
            raise TypeError("An argument's nargs must be a positive integer, or -1.")
        if required is None:
            required = kwargs.get("default") is None and nargs != -1
        super().__init__(name, required=required, nargs=nargs, **kwargs)

    def describe(self) -> str:
        return f"'{self.name}'"

    def placeholder(self) -> str:
        text = self.metavar or self.name.upper().replace("-", "_")
        if self.nargs == -1:
            text += "..."
        return text

    def get_usage_name(self) -> str:
        text = self.placeholder()
        if not self.required:
            text = f"[{text}]"
        return text

    def envvar_names(self, ctx: Context | None) -> list[str]:
        return list(self.envvar)

    def _env_tokens(self, ctx: Context):
        for name in self.envvar_names(ctx):
            text = os.environ.get(name)
            if text is None or text == "":
                continue
            if self.is_variadic or self.nargs != 1 or isinstance(self.type, Tuple):
                tokens = self.type.split_envvar_value(text)
                if self.is_variadic:
                    return tokens
                return tokens[: self.nargs]
            return [text]
        return None

    def process(self, ctx: Context, res: _ParseResult):
        occ = res.occ.get(self, [])
        if occ:
            self._warn_if_deprecated(ctx)
            value = self._convert_tokens(ctx, occ[0])
            if self.is_variadic and not isinstance(value, tuple):
                value = tuple(value)
            return self._finish(ctx, value), ParameterSource.COMMANDLINE
        env = self._env_tokens(ctx)
        if env:
            return self._finish(ctx, self._convert_tokens(ctx, env)), ParameterSource.ENVIRONMENT
        declared = self.get_default(ctx)
        if declared is not None:
            return self._finish(ctx, self._default_value(ctx, declared, from_map=False)), ParameterSource.DEFAULT
        if self.required:
            raise MissingParameter("required", ctx=ctx, param=self)
        return self._finish(ctx, self._empty()), ParameterSource.DEFAULT


# spec: N-000881–N-000883 (declaration forms), N-000226 (alternative prefixes)
def _split_decls(decls):
    opts: list[str] = []
    secondary: list[str] = []
    dest: str | None = None
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise TypeError(f"Invalid parameter declaration: {decl!r}")
        if decl[0] in _PREFIX_CHARS:
            split_at = decl.find("/", 1)
            if split_at > 0 and split_at + 1 < len(decl) and decl[split_at + 1] in _PREFIX_CHARS:
                opts.append(decl[:split_at])
                secondary.append(decl[split_at + 1:])
            else:
                opts.append(decl)
        elif decl.isidentifier():
            dest = decl
        else:
            raise TypeError(f"Invalid parameter declaration: {decl!r}")
    return opts, secondary, dest


# spec: N-000194–N-000195
def _derive_dest(opts: list[str]) -> str:
    for opt in opts:
        if opt.isidentifier():
            return opt
    chosen = None
    for opt in opts:
        if opt.startswith("--"):
            chosen = opt
            break
    if chosen is None:
        chosen = opts[0]
    return chosen.lstrip("".join(_PREFIX_CHARS)).replace("-", "_")


def _key(token: str, norm) -> str:
    return norm(token) if norm else token


# spec: N-000188–N-000193, N-000884–N-000905
def _flag_table(options: list[Option], norm) -> dict:
    table: dict[str, tuple] = {}
    for p in options:
        if p.count:
            kind = "count"
        elif p.is_flag:
            kind = "flag"
        elif p.is_optional_value:
            kind = "optional"
        else:
            kind = "value"
        for opt in p.opts:
            value = p.flag_value if kind == "flag" else None
            table[_key(opt, norm)] = (p, kind, value)
        for opt in p.secondary_opts:
            table[_key(opt, norm)] = (p, "flag", False)
    return table


def _is_option_like(token: str, prefixes) -> bool:
    return len(token) > 1 and token[0] in prefixes


# spec: N-000291–N-000303, N-000321–N-000323
def _assign_arguments(arguments: list[Argument], tokens: list[str]):
    assigned: dict[Argument, tuple] = {}
    idx = 0
    for k, arg in enumerate(arguments):
        remaining = len(tokens) - idx
        if arg.nargs == -1:
            reserve = sum(b.nargs for b in arguments[k + 1:] if b.required and b.nargs > 0)
            take = max(0, remaining - reserve)
            if take:
                assigned[arg] = tuple(tokens[idx:idx + take])
                idx += take
        elif remaining >= arg.nargs:
            assigned[arg] = tuple(tokens[idx:idx + arg.nargs])
            idx += arg.nargs
        elif remaining > 0:
            raise BadArgumentUsage(f"Argument '{arg.name}' takes {arg.nargs} values.")
    return assigned, tokens[idx:]


# ------------------------------------------------------------------ commands


# spec: N-000114–N-000117, N-000853
def _clean_help(text: str | None) -> str:
    if not text:
        return ""
    text = text.split("\f")[0]
    return inspect.cleandoc(text).strip()


def _first_sentence(text: str) -> str:
    paragraph = text.split("\n\n")[0]
    flat = " ".join(line.strip() for line in paragraph.splitlines()).strip()
    match = re.match(r"(.*?[.!?])(?=\s|$)", flat)
    return match.group(1) if match else flat


def _entries(rows, width: int, indent: int = 2) -> list[str]:
    if not rows:
        return []
    col = min(max(len(first) for first, _ in rows), 30)
    lines: list[str] = []
    pad = " " * indent
    for first, text in rows:
        if not text:
            lines.append(pad + first)
            continue
        if len(first) <= col:
            help_width = max(width - (indent + col + 2), 20)
            wrapped = wrap_text(text, help_width).splitlines() or [""]
            lines.append(f"{pad}{first.ljust(col)}  {wrapped[0]}".rstrip())
            for extra in wrapped[1:]:
                lines.append(" " * (indent + col + 2) + extra)
        else:
            lines.append(pad + first)
            for extra in wrap_text(text, max(width - indent - 4, 20)).splitlines():
                lines.append(" " * (indent + 4) + extra)
    return lines


# spec: N-000850–N-000861 (Interface §3), N-000079–N-000109 (FP-01)
class Command:
    """A leaf command: options, arguments and a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False
    context_class = Context

    def __init__(
        self,
        name: str | None,
        context_settings: dict | None = None,
        callback: Callable | None = None,
        params: list | None = None,
        help: str | None = None,
        epilog: str | None = None,
        short_help: str | None = None,
        options_metavar: str | None = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: Any = False,
        **extra: Any,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = _clean_help(help if help is not None else (callback.__doc__ if callback else None))
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.extra = extra
        self._check_variadic()

    def _check_variadic(self) -> None:
        variadic = [p for p in self.params if isinstance(p, Argument) and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("A command may use a variadic argument at most once.")

    def has_variadic(self) -> bool:
        return any(isinstance(p, Argument) and p.nargs == -1 for p in self.params)

    def __call__(self, *args: Any, **kwargs: Any):
        return self.main(*args, **kwargs)

    # spec: N-000122–N-000124, N-000842–N-000843
    def get_short_help(self) -> str:
        if self.short_help:
            return self.short_help
        text = _first_sentence(self.help)
        if len(text) > _SHORT_HELP_LIMIT:
            text = text[: _SHORT_HELP_LIMIT - 3].rstrip() + "..."
        return text

    def get_params(self, ctx: Context) -> list:
        params = list(self.params)
        if self.add_help_option:
            author_names = {
                n for p in self.params if isinstance(p, Option) for n in p.opts + p.secondary_opts
            }
            names = [n for n in ctx.help_option_names if n not in author_names]
            if names:
                params.append(_make_help_option(names))
        return params

    def _run_callback(self, ctx: Context):
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **dict(ctx.params))

    # -- parsing

    def _parse(self, ctx: Context, tokens: list[str], params: list) -> _ParseResult:
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        norm = ctx.token_normalize_func
        table = _flag_table(options, norm)
        prefixes = {k[:1] for k in table} | {"-"}
        is_group = isinstance(self, Group)
        interspersed = ctx.allow_interspersed_args
        group_slots = sum(max(a.nargs, 1) for a in arguments) if is_group else 0
        res = _ParseResult()
        i = 0
        n = len(tokens)
        ended = False
        stopped = False
        while i < n:
            tok = tokens[i]
            if not ended and tok == "--":
                ended = True
                i += 1
                continue
            if not ended and not stopped and _is_option_like(tok, prefixes):
                consumed = self._consume_option(ctx, tokens, i, table, res, norm, prefixes)
                if consumed:
                    i += consumed
                    continue
            if is_group:
                if len(res.args) < group_slots:
                    res.args.append(tok)
                    i += 1
                    continue
                res.leftover = tokens[i:]
                break
            res.args.append(tok)
            if not interspersed:
                stopped = True
            i += 1
        if is_group and interspersed and res.leftover:
            res.leftover = self._mix_group_options(ctx, res, table, norm, prefixes)
        assigned, extra = _assign_arguments(arguments, res.args)
        for arg in arguments:
            if arg in assigned:
                res.occ.setdefault(arg, []).append(assigned[arg])
        if is_group:
            ctx.protected_args = list(res.leftover)
            ctx.args = []
        else:
            if extra:
                if not ctx.allow_extra_args:
                    raise BadArgumentUsage(
                        f"Got unexpected extra argument{'s' if len(extra) != 1 else ''} "
                        f"({' '.join(extra)})",
                        ctx=ctx,
                    )
                ctx.args = list(extra)
            else:
                ctx.args = []
        return res

    def _mix_group_options(self, ctx, res, table, norm, prefixes) -> list[str]:
        name, rest = res.leftover[0], res.leftover[1:]
        keep: list[str] = []
        j = 0
        while j < len(rest):
            tok = rest[j]
            if _is_option_like(tok, prefixes) and _key(tok.partition("=")[0], norm) in table:
                j += self._consume_option(ctx, rest, j, table, res, norm, prefixes) or 1
                continue
            keep.append(tok)
            j += 1
        return [name] + keep

    # spec: N-000188–N-000193 (short stacks, long options), N-000268–N-000274
    def _consume_option(self, ctx, tokens, i, table, res, norm, prefixes) -> int:
        tok = tokens[i]
        whole = table.get(_key(tok, norm))
        if whole is not None:
            return self._apply_option(ctx, tokens, i, whole, None, tok, res, prefixes)
        name, eq, attached = tok.partition("=")
        if eq:
            entry = table.get(_key(name, norm))
            if entry is not None:
                return self._apply_option(ctx, tokens, i, entry, attached, name, res, prefixes)
        if tok.startswith("--") or len(tok) < 2:
            if ctx.ignore_unknown_options:
                return 0
            raise NoSuchOption(name, ctx=ctx)
        prefix = tok[0]
        chars = tok[1:]
        j = 0
        while j < len(chars):
            flag = prefix + chars[j]
            entry = table.get(_key(flag, norm))
            if entry is None:
                if ctx.ignore_unknown_options:
                    res.args.append(prefix + chars[j:])
                    return 1
                raise NoSuchOption(flag, ctx=ctx)
            param, kind, value = entry
            if kind in ("flag", "count"):
                if kind == "count":
                    res.add(param, _Converted(1))
                else:
                    res.add(param, _Converted(value))
                j += 1
                continue
            rest = chars[j + 1:]
            return self._apply_option(ctx, tokens, i, entry, rest or None, flag, res, prefixes)
        return 1

    # spec: N-000202–N-000225 (flags, counts, values, optional values)
    def _apply_option(self, ctx, tokens, i, entry, attached, label, res, prefixes) -> int:
        param, kind, value = entry
        if kind in ("flag", "count"):
            if attached is not None:
                raise BadOptionUsage(f"Option '{label}' does not take a value.", ctx=ctx)
            res.add(param, _Converted(1 if kind == "count" else value))
            return 1
        if kind == "optional":
            if attached is not None:
                res.add(param, (attached,))
                return 1
            if i + 1 < len(tokens) and not _is_option_like(tokens[i + 1], prefixes):
                res.add(param, (tokens[i + 1],))
                return 2
            res.add(param, _Converted(param.flag_value))
            return 1
        nargs = param.nargs
        if attached is not None:
            if nargs == 1:
                res.add(param, (attached,))
                return 1
            extra = tokens[i + 1:i + nargs]
            if len(extra) != nargs - 1:
                raise BadOptionUsage(f"Option '{label}' requires {nargs} arguments.", ctx=ctx)
            res.add(param, tuple([attached] + extra))
            return nargs
        values = tokens[i + 1:i + 1 + nargs]
        if len(values) < nargs:
            if param.prompt_enabled:
                res.add(param, _PROMPT)
                return 1
            raise BadOptionUsage(f"Option '{label}' requires an argument.", ctx=ctx)
        res.add(param, tuple(values))
        return 1 + nargs

    # -- processing (callbacks, defaults, sources)

    # spec: N-000246–N-000263, N-000264–N-000265
    def _process(self, ctx: Context, res: _ParseResult, params: list) -> None:
        rest = [p for p in params if p not in res.eager]
        ordered = list(res.eager) + rest
        candidates: dict[str, list] = {}
        with ctx:
            for p in ordered:
                value, source = p.process(ctx, res)
                if p.expose_value:
                    # Bind as we go so later callbacks can read earlier values from the context.
                    ctx.params[p.name] = value
                    ctx._sources[p.name] = source
                    candidates.setdefault(p.name, []).append(
                        (
                            _SOURCE_RANK[source],
                            p._explicit_default(),
                            params.index(p),
                            value,
                            source,
                        )
                    )
        for name, cands in candidates.items():
            best = max(cands, key=lambda c: (c[0], c[1], c[2]))
            ctx.params[name] = best[3]
            ctx._sources[name] = best[4]

    # spec: N-000854–N-000860; N-000406–N-000410 (no-args-is-help)
    def make_context(self, info_name: str | None, args, parent: Context | None = None, **extra: Any) -> Context:
        settings = dict(self.context_settings)
        settings.update(extra)
        default_map = settings.pop("default_map", None)
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name)
        ctx = self.context_class(self, parent=parent, info_name=info_name, default_map=default_map, **settings)
        args = list(args)
        with ctx:
            if not args and self.no_args_is_help:
                raise NoArgsIsHelp("No arguments given.", ctx=ctx)
            params = self.get_params(ctx)
            res = self._parse(ctx, args, params)
            self._process(ctx, res, params)
        return ctx

    # -- invocation

    def invoke(self, ctx: Context):
        if self.deprecated:
            _warn_deprecated(ctx, "command", ctx.info_name or self.name, self.deprecated)
        with ctx:
            return self._run_callback(ctx)

    # spec: N-000854–N-000860, N-000097–N-000100, N-000716–N-000735
    def main(self, args=None, prog_name: str | None = None, complete_var: str | None = None,
             standalone_mode: bool = True, **extra: Any):
        """Run this command on ``args`` (default: ``sys.argv[1:]``)."""
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "root")
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import handle_completion

            status = handle_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(status)
            return None

        ctx = None
        try:
            ctx = self.make_context(prog_name, args, **extra)
            with ctx:
                rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as exc:
            if not standalone_mode:
                return None
            sys.exit(exc.exit_code)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            echo(err=True)
            echo("Aborted!", err=True)
            sys.exit(1)
        finally:
            if ctx is not None:
                ctx.find_root().close()

    # -- help

    def get_usage(self, ctx: Context, params: list | None = None) -> str:
        params = self.get_params(ctx) if params is None else params
        pieces = [ctx.command_path]
        if any(isinstance(p, Option) and not p.hidden for p in params) and self.options_metavar:
            pieces.append(self.options_metavar)
        for arg in params:
            if isinstance(arg, Argument) and not arg.hidden:
                pieces.append(arg.get_usage_name())
        if isinstance(self, Group):
            pieces.append(self._subcommand_usage())
        return " ".join(piece for piece in pieces if piece)

    def _subcommand_usage(self) -> str:
        if self.chain:
            return "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        if self.invoke_without_command:
            return "[COMMAND] [ARGS]..."
        return "COMMAND [ARGS]..."

    def get_help(self, ctx: Context) -> str:
        width = ctx.get_wrap_width()
        params = self.get_params(ctx)
        lines = ["Usage: " + self.get_usage(ctx, params), ""]
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            lines += [("(Deprecated) " + note).strip(), ""]
        if self.help:
            lines += [wrap_text(self.help, width), ""]
        arg_rows = [
            (p.placeholder(), p.help)
            for p in params if isinstance(p, Argument) and p.help and not p.hidden
        ]
        if arg_rows:
            lines.append("Positional arguments:")
            lines += _entries(arg_rows, width)
            lines.append("")
        opt_rows = [
            (self._option_names(p), p.get_help_text(ctx))
            for p in params if isinstance(p, Option) and not p.hidden
        ]
        if opt_rows:
            lines.append("Options:")
            lines += _entries(opt_rows, width)
            lines.append("")
        if isinstance(self, Group):
            rows = []
            for name in self.list_commands(ctx):
                sub = self.get_command(ctx, name)
                if sub is not None and not sub.hidden:
                    rows.append((name, sub.get_short_help()))
            if rows:
                lines.append("Commands:")
                lines += _entries(rows, width)
                lines.append("")
        if self.epilog:
            lines += [wrap_text(self.epilog, width), ""]
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines) + "\n"

    @staticmethod
    def _option_names(param: "Option") -> str:
        text = param.display_names()
        metavar = param.get_metavar_text()
        return f"{text} {metavar}" if metavar else text


def _make_help_option(names: list[str]) -> "Option":
    def callback(ctx, param, value):
        if not value:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    return Option(
        tuple(names),
        name="__optlyn_help__",
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=callback,
        help="Show this message and exit.",
    )


# spec: N-000384–N-000433 (FP-06), N-000865–N-000877 (Interface §3)
class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name: str | None = None,
        commands=None,
        invoke_without_command: bool = False,
        no_args_is_help: bool | None = None,
        subcommand_metavar: str | None = None,
        chain: bool = False,
        result_callback: Callable | None = None,
        **kwargs: Any,
    ) -> None:
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        if isinstance(commands, dict):
            self.commands: dict[str, Command] = dict(commands)
        else:
            self.commands = {cmd.name: cmd for cmd in (commands or [])}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    # spec: N-000869–N-000871, N-000612–N-000613
    def add_command(self, cmd: Command, name: str | None = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be attached beneath a chaining group.")
        self.commands[name or cmd.name] = cmd

    # spec: N-000850–N-000852, N-000079–N-000082
    def command(self, *args: Any, **kwargs: Any):
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    # spec: N-000862–N-000864
    def group(self, *args: Any, **kwargs: Any):
        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        return self.commands.get(cmd_name)

    def invoke(self, ctx: Context):
        if self.deprecated:
            _warn_deprecated(ctx, "command", ctx.info_name or self.name, self.deprecated)
        if self.chain:
            return self._invoke_chain(ctx)
        protected = ctx.protected_args
        if not protected:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_callback(ctx)
                return self._apply_result(ctx, rv)
            raise UsageError("Missing command.", ctx=ctx)
        name, rest = protected[0], protected[1:]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx=ctx)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub = cmd.make_context(name, rest, parent=ctx)
        with sub:
            rv = cmd.invoke(sub)
        return self._apply_result(ctx, rv)

    def _apply_result(self, ctx: Context, rv):
        if self._result_callback is None:
            return rv
        return ctx.invoke(self._result_callback, rv, **dict(ctx.params))

    # spec: N-000609–N-000611
    def _split_chain(self, ctx: Context, tokens: list[str]):
        units = []
        i = 0
        while i < len(tokens):
            name = tokens[i]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx=ctx)
            if cmd.has_variadic():
                end = len(tokens)
            else:
                end = i + 1
                while end < len(tokens) and self.get_command(ctx, tokens[end]) is None:
                    end += 1
            units.append((cmd, name, tokens[i + 1:end]))
            i = end
        return units

    # spec: N-000593–N-000606, N-000603–N-000604
    def _invoke_chain(self, ctx: Context):
        units = self._split_chain(ctx, ctx.protected_args)
        if not units and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx=ctx)
        ctx.invoked_subcommand = CHAIN_MARKER if units else None
        self._run_callback(ctx)
        results = []
        for cmd, name, args in units:
            sub = cmd.make_context(name, args, parent=ctx)
            with sub:
                results.append(cmd.invoke(sub))
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, results, **dict(ctx.params))
        return results


# spec: N-000422–N-000425, N-000878–N-000880
class CommandCollection(Group):
    """A group presenting the union of the subcommands of several source groups."""

    def __init__(self, name: str | None = None, sources=None, **kwargs: Any) -> None:
        self.sources = list(sources or [])
        super().__init__(name, **kwargs)

    def list_commands(self, ctx: Context) -> list[str]:
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


# ------------------------------------------------------------------ decorators


def _attach_param(f, param: Parameter):
    params = f.__dict__.setdefault(_PARAMS_ATTR, [])
    params.append(param)
    return f


def _take_params(f) -> list:
    params = f.__dict__.pop(_PARAMS_ATTR, [])
    return list(reversed(params))


def _default_command_name(fname: str) -> str:
    name = fname.lower().replace("_", "-")
    for suffix in ("-command", "-cmd", "-group", "-grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def command(name=None, cls=None, **attrs: Any):
    """Declare a leaf command from a function. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _default_command_name(f.__name__)
        klass = cls or Command
        return klass(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs: Any):
    """Declare a group from a function. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _default_command_name(f.__name__)
        klass = cls or Group
        return klass(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


# spec: N-000881–N-000884
def option(*param_decls, cls=None, **attrs: Any):
    """Attach an option to the function below it. Returns the function unchanged."""
    klass = cls or Option

    def decorator(f):
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


# spec: N-000910–N-000912
def argument(*param_decls, cls=None, **attrs: Any):
    """Attach a positional argument to the function below it."""
    klass = cls or Argument

    def decorator(f):
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


def _option_decorator(decls, attrs: dict):
    def decorator(f):
        return _attach_param(f, Option(decls, **attrs))

    return decorator


# spec: N-000924, N-000929
def help_option(*param_decls, **kwargs: Any):
    """An eager help flag that prints the help page and exits."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return _option_decorator(decls, kwargs)


def _detect_version(package_name: str | None) -> str:
    from importlib import metadata

    if not package_name:
        return "unknown"
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name, [])
    except Exception:  # pragma: no cover - defensive
        dists = []
    for dist in dists:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


# spec: N-000925, N-000930–N-000931, N-000162–N-000169
def version_option(version: str | None = None, *param_decls, package_name: str | None = None,
                   prog_name: str | None = None, message: str | None = None, **kwargs: Any):
    """An eager version flag. The identity is ``version`` or the installed version of ``package_name``."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return _option_decorator(decls, kwargs)


# spec: N-000932, N-000167, N-000846–N-000849
def custom_version_option(callback_fn: Callable, *param_decls, **kwargs: Any):
    """An eager version flag whose whole identity is the string ``callback_fn(ctx)`` returns."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        echo(callback_fn(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return _option_decorator(decls, kwargs)


# spec: N-000926, N-000484–N-000487, N-000510–N-000512
def password_option(*param_decls, **kwargs: Any):
    """A prompting, hidden, confirmed option (default ``--password``)."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("required", True)
    return _option_decorator(decls, kwargs)


# spec: N-000927, N-000513–N-000519
def confirmation_option(*param_decls, **kwargs: Any):
    """A confirmation flag (default ``--yes``). Omitted, it asks; declined, it aborts."""
    decls = param_decls or ("--yes",)
    question = kwargs.pop("prompt", None) or "Do you want to continue?"
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, abort=True)
        return value

    kwargs.setdefault("callback", callback)
    return _option_decorator(decls, kwargs)


# spec: N-000975
def pass_context(f):
    """Pass the current :class:`Context` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


# spec: N-000976
def pass_obj(f):
    """Pass the current context's ``obj`` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


# spec: N-000977, N-000442–N-000443
def make_pass_decorator(object_type, ensure: bool = False):
    """Pass the nearest context object of exactly ``object_type``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            found = None
            node: Context | None = ctx
            while node is not None:
                if type(node._obj) is object_type:
                    found = node._obj
                    break
                node = node.parent
            if found is None:
                if not ensure:
                    raise RuntimeError(
                        f"Managed to invoke callback without a context object of type "
                        f"{object_type.__name__!r} existing."
                    )
                found = object_type()
                ctx._obj = found
            return f(found, *args, **kwargs)

        return new_func

    return decorator

