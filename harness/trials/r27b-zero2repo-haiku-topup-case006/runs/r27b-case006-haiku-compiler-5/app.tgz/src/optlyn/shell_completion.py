"""Shell completion: registration scripts and suggestion output.

Output protocol (complete mode), one entry per line, tab separated:
``<type>\\t<value>\\t<help>`` where ``type`` is ``plain`` for an ordinary
value, ``dir`` for a directories-only path request, and ``file`` for a
file/any-path request (``value`` is then the incomplete token).
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

from .core import Argument, Command, Context, Group, Option
from .types import File, Path

__all__ = ["CompletionItem", "handle_completion", "SHELLS"]

SHELLS = ("bash", "zsh", "fish", "powershell")


@dataclass
# spec: N-001035–N-001037
class CompletionItem:
    """A suggestion with optional help text and a kind (``plain``, ``dir`` or ``file``)."""

    value: str
    help: str | None = None
    type: str = "plain"


def _var_name(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


# spec: N-000689–N-000693, N-000714–N-000715, N-001021–N-001022
def handle_completion(cli: Command, prog_name: str, instruction: str) -> int:
    """Handle a ``<shell>_source`` or ``<shell>_complete`` instruction. Returns the exit status."""
    shell, _, mode = instruction.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        print(f"Unknown completion instruction {instruction!r}.", file=sys.stderr)
        return 1
    if mode == "source":
        sys.stdout.write(_registration_script(shell, prog_name))
        sys.stdout.flush()
        return 0
    items = _suggest_from_environment(cli, prog_name, shell)
    for item in items:
        sys.stdout.write(f"{item.type}\t{item.value}\t{item.help or ''}\n")
    sys.stdout.flush()
    return 0


def _suggest_from_environment(cli: Command, prog_name: str, shell: str) -> list[CompletionItem]:
    words_text = os.environ.get("COMP_WORDS", "")
    words = words_text.split(" ")
    raw_cword = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = raw_cword
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(raw_cword)
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        args = words[1:cword]
    return suggest(cli, prog_name, args, incomplete)


# spec: N-000694–N-000700, N-000712–N-000713
def suggest(cli: Command, prog_name: str, args: list[str], incomplete: str) -> list[CompletionItem]:
    """Compute suggestions for ``incomplete`` given the already typed ``args``."""
    ctx = Context(cli, info_name=prog_name)
    cmd: Command = cli
    for tok in args:
        if isinstance(cmd, Group) and not tok.startswith("-"):
            sub = cmd.get_command(ctx, tok)
            if sub is not None:
                cmd = sub
                ctx = Context(sub, parent=ctx, info_name=tok)
    params = cmd.get_params(ctx)
    options = [p for p in params if isinstance(p, Option)]
    arguments = [p for p in params if isinstance(p, Argument)]

    # A value-taking option just before the incomplete token completes its values.
    if args and not incomplete.startswith("-"):
        previous = args[-1]
        for opt in options:
            if previous in opt.opts and opt.takes_value():
                return _value_items(ctx, opt, incomplete)

    if incomplete.startswith("-"):
        items: list[CompletionItem] = []
        for opt in options:
            if opt.hidden:
                continue
            for name in opt.opts + opt.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, opt.help))
        return items

    items = []
    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is not None and not sub.hidden and name.startswith(incomplete):
                items.append(CompletionItem(name, sub.get_short_help()))
    consumed = 0
    skip_next = False
    value_flags = {n: o for o in options if o.takes_value() for n in o.opts}
    for tok in args:
        if skip_next:
            skip_next = False
            continue
        if tok in value_flags:
            skip_next = True
        elif not tok.startswith("-"):
            consumed += 1
    if consumed < len(arguments):
        items.extend(_value_items(ctx, arguments[consumed], incomplete))
    return items


# spec: N-000696–N-000700, N-000706–N-000711
def _value_items(ctx: Context, param, incomplete: str) -> list[CompletionItem]:
    if param.shell_complete is not None:
        raw = param.shell_complete(ctx, param, incomplete)
    else:
        if isinstance(param.type, Path):
            kind = "dir" if (param.type.dir_okay and not param.type.file_okay) else "file"
            return [CompletionItem(incomplete, None, kind)]
        if isinstance(param.type, File):
            return [CompletionItem(incomplete, None, "file")]
        raw = param.type.shell_complete(ctx, param, incomplete)
    items: list[CompletionItem] = []
    for entry in raw:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            items.append(CompletionItem(entry.value, getattr(entry, "help", None),
                                        getattr(entry, "type", "plain") or "plain"))
    return items


# spec: N-000701–N-000702, N-001013–N-001015
def _registration_script(shell: str, prog_name: str) -> str:
    var = _var_name(prog_name)
    func = "_" + prog_name.replace("-", "_") + "_completion"
    if shell == "bash":
        return f"""{func}() {{
    local line type value cur="${{COMP_WORDS[COMP_CWORD]}}" words
    words="$(IFS=' '; printf '%s' "${{COMP_WORDS[*]}}")"
    local IFS=$'\\n'
    local lines=( $(env COMP_WORDS="$words" COMP_CWORD=$COMP_CWORD {var}=bash_complete "$1") )
    COMPREPLY=()
    for line in "${{lines[@]}}"; do
        type="${{line%%$'\\t'*}}"
        value="${{line#*$'\\t'}}"; value="${{value%%$'\\t'*}}"
        case "$type" in
            dir) COMPREPLY+=( $(compgen -d -- "$cur") ) ;;
            file) COMPREPLY+=( $(compgen -f -- "$cur") ) ;;
            *) COMPREPLY+=( "$value" ) ;;
        esac
    done
}}
complete -o default -F {func} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
{func}() {{
    local -a lines completions
    local line type value help
    lines=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name})}}")
    for line in $lines; do
        type="${{line%%$'\\t'*}}"
        value="${{${{line#*$'\\t'}}%%$'\\t'*}}"
        help="${{line##*$'\\t'}}"
        case "$type" in
            dir) _path_files -/ ;;
            file) _files ;;
            *) completions+=("${{value}}:${{help}}") ;;
        esac
    done
    _describe 'values' completions
}}
compdef {func} {prog_name}
"""
    if shell == "fish":
        return f"""function {func}
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog_name})
    for line in $response
        set -l parts (string split \\t -- $line)
        switch $parts[1]
            case dir
                __fish_complete_directories $parts[2]
            case file
                __fish_complete_path $parts[2]
            case '*'
                printf '%s\\t%s\\n' $parts[2] $parts[3]
        end
    end
end
complete -c {prog_name} -f -a '({func})'
"""
    if shell == "powershell":
        return f"""Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString() -split ' '
    $env:COMP_WORDS = ($words -join ' ')
    $env:COMP_CWORD = $words.Count - 1
    $env:{var} = 'powershell_complete'
    $response = & {prog_name} 2>$null
    Remove-Item Env:{var}
    foreach ($line in $response) {{
        $parts = $line -split "`t"
        if ($parts[0] -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
        }}
    }}
}}
"""
    raise ValueError(f"Unsupported shell {shell!r}")
