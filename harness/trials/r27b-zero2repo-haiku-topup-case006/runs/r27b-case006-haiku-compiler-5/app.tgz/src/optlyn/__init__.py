"""Optlyn: compose command line interfaces with as little code as necessary."""

from .core import (
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
    Argument,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    format_filename,
    get_app_dir,
    get_pager_file,
    getchar,
    launch,
    open_file,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
    "pass_context", "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "Argument",
    "ParamType", "BadParameter", "Abort", "ParameterSource",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
    # errors
    "OptlynError", "UsageError", "MissingParameter", "NoSuchOption", "BadOptionUsage",
    "BadArgumentUsage", "NoArgsIsHelp", "Exit", "FileError",
]
