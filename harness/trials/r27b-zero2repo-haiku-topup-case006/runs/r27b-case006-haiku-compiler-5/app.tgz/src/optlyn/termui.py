"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch."""

from __future__ import annotations

import contextlib
import enum
import io
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

from .exceptions import Abort, BadParameter

__all__ = [
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch",
    "clear", "get_app_dir", "format_filename", "open_file",
]

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

_NAMED_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def _ctx_color():
    from . import core

    ctx = core.get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _isatty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive() -> bool:
    """A session is interactive when stdin or stdout is a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _write(stream, text: str) -> None:
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            raise
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    stream.flush()


# spec: N-000632
def unstyle(text: str) -> str:
    """Remove ANSI escape sequences, keeping all other text."""
    return _ANSI_RE.sub("", text)


# spec: N-000619–N-000627, N-000681–N-000683
def echo(message: Any = None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Write a message to stdout (or stderr with ``err=True``, or to ``file``).

    ANSI styles are stripped unless the stream is a terminal, or ``color``
    forces them on. ``color=False`` strips them even on a terminal.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        color = _ctx_color()
    if isinstance(message, bytes):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(message + (b"\n" if nl else b""))
            buffer.flush()
        else:
            _write(file, message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = "" if message is None else str(message)
    if nl:
        text += "\n"
    if color is False or (color is None and not _isatty(file)):
        text = unstyle(text)
    _write(file, text)


def _color_code(color, background: bool) -> str:
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, str):
        name = color.lower()
        if name == "reset":
            return "49" if background else "39"
        if name not in _NAMED_COLORS:
            raise ValueError(f"Unknown color {color!r}.")
        code = _NAMED_COLORS[name]
        return str(code + 10 if background else code)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color index {color} is out of range 0-255.")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(isinstance(c, int) for c in color):
        if not all(0 <= c <= 255 for c in color):
            raise ValueError(f"RGB color {color!r} is out of range 0-255.")
        r, g, b = color
        return f"{48 if background else 38};2;{r};{g};{b}"
    raise ValueError(f"Invalid color {color!r}.")


# spec: N-000628–N-000640, N-000688
def style(text: Any, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset: bool = True) -> str:
    """Wrap ``text`` in ANSI SGR sequences. An invalid color raises ValueError."""
    codes: list[str] = []
    if fg is not None:
        codes.append(_color_code(fg, background=False))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, enabled in switches.items():
        if enabled:
            codes.append(str(_STYLE_CODES[name]))
    body = str(text)
    if not codes:
        return body
    prefix = "\x1b[" + ";".join(codes) + "m"
    return prefix + body + ("\x1b[0m" if reset else "")


# spec: N-000627
def secho(message: Any = None, file=None, nl: bool = True, err: bool = False, color=None,
          **styles) -> None:
    """Echo with styling applied in one step."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _read_line(prompt_text: str, hide: bool) -> str:
    stdin = sys.stdin
    stdout = sys.stdout
    if hide and _isatty(stdin):
        import getpass

        line = getpass.getpass(prompt_text)
        return line
    if not _isatty(stdout):
        prompt_text = unstyle(prompt_text)  # prompts keep styles only on a terminal
    stdout.write(prompt_text)
    stdout.flush()
    line = stdin.readline()
    if line == "":
        raise EOFError
    line = line.rstrip("\r\n")
    if not _isatty(stdin):
        # Input that did not come from a terminal is echoed so the transcript reads naturally.
        stdout.write("\n" if hide else line + "\n")
        stdout.flush()
    return line


# spec: N-000488–N-000491, N-000497–N-000500, N-000510–N-000512, N-000520–N-000522
def prompt(text: str, default: Any = None, hide_input: bool = False,
           confirmation_prompt: bool = False, type=None, value_proc=None, **_: Any) -> Any:
    """Ask for a value; re-asks on conversion failure until valid or end of input.

    An empty answer takes ``default`` when one is given. With
    ``confirmation_prompt`` the value is asked twice and a mismatch is rejected.
    """
    from .types import STRING, convert_type

    if value_proc is None:
        conv = convert_type(type) if type is not None else STRING
        value_proc = lambda raw: conv(raw)  # noqa: E731
    display = ""
    if default is not None and not hide_input:
        shown = default.name if isinstance(default, enum.Enum) else default
        display = f" [{shown}]"
    prompt_text = f"{text}{display}: "
    while True:
        raw = _read_line(prompt_text, hide_input)
        if raw == "" and default is not None:
            if isinstance(default, str):
                try:
                    result = value_proc(default)
                except BadParameter as exc:
                    echo(f"Error: {exc.message}", err=True)
                    continue
            else:
                result = default
        else:
            try:
                result = value_proc(raw)
            except BadParameter as exc:
                echo(f"Error: {exc.message}", err=True)
                continue
        if not confirmation_prompt:
            return result
        second = _read_line("Repeat for confirmation: ", hide_input)
        if second == raw:
            return result
        echo("Error: the two entered values do not match", err=True)


# spec: N-000501–N-000509
def confirm(text: str, default: bool = False, abort: bool = False, prompt_suffix: str = ": ",
            show_default: bool = True, err: bool = False) -> bool:
    """Ask a yes/no question. A negative answer raises Abort when ``abort`` is set."""
    suffix = " [Y/n]" if default else " [y/N]"
    question = f"{text}{suffix}{prompt_suffix}"
    while True:
        answer = _read_line(question, False).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def _read_char_raw() -> str:
    try:
        import termios
        import tty
    except ImportError:  # Windows
        import msvcrt

        return msvcrt.getwch()

    fd = None
    close_fd = False
    if _isatty(sys.stdin):
        fd = sys.stdin.fileno()
    else:
        try:
            fd = os.open("/dev/tty", os.O_RDONLY)
            close_fd = True
        except OSError:
            return sys.stdin.read(1)
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        return os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        if close_fd:
            os.close(fd)


# spec: N-000658–N-000661
def getchar(echo: bool = False) -> str:
    """Read one character. Ctrl-C raises KeyboardInterrupt; end of file raises EOFError."""
    char = _read_char_raw()
    if char == "":
        raise EOFError
    if char == "\x03":
        raise KeyboardInterrupt
    if char == "\x04":
        raise EOFError
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


# spec: N-000662–N-000663, N-000686–N-000687
def pause(info: Any = None, err: bool = False) -> None:
    """Wait for a key press in an interactive session; does nothing otherwise."""
    if not is_interactive():
        return
    message = "Press any key to continue..." if info is None else str(info)
    echo(message, err=err, nl=False)
    try:
        getchar()
    finally:
        echo("", err=err)


@contextlib.contextmanager
def _pager_process():
    command = os.environ.get("PAGER")
    if not (command and is_interactive()):
        yield None
        return
    proc = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE)
    try:
        yield proc
    finally:
        if proc.stdin and not proc.stdin.closed:
            proc.stdin.close()
        proc.wait()


# spec: N-000641–N-000648
def echo_via_pager(text_or_generator: Any, color=None) -> None:
    """Write text through a pager when interactive; otherwise to stdout."""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    chunks = [text_or_generator] if isinstance(text_or_generator, str) else text_or_generator
    with _pager_process() as proc:
        if proc is None:
            for chunk in chunks:
                echo(chunk, nl=False, color=color)
            return
        for chunk in chunks:
            data = str(chunk)
            if color is not True:
                data = unstyle(data)
            proc.stdin.write(data.encode("utf-8", "replace"))
            proc.stdin.flush()


@contextlib.contextmanager
# spec: N-000641–N-000648
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    from .types import _NonClosing

    with _pager_process() as proc:
        if proc is None:
            yield _NonClosing(sys.stdout)
            return
        stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace", write_through=True)
        try:
            yield stream
        finally:
            stream.detach()


class ProgressBar:
    """Iterable progress indicator returned by :func:`progressbar`."""

    def __init__(self, iterable, length, label, visible) -> None:
        self._iterable = iterable
        self.length = length
        self.label = label
        self.visible = visible
        self.pos = 0
        self._start = time.monotonic()

    def __iter__(self):
        if self._iterable is None:
            return
        for item in self._iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int) -> None:
        self.pos += n_steps
        if not self.visible:
            return
        width = 36
        if self.length:
            filled = min(width, int(width * self.pos / self.length))
            elapsed = time.monotonic() - self._start
            remaining = (elapsed / self.pos) * (self.length - self.pos) if self.pos else 0
            bar = "#" * filled + "-" * (width - filled)
            line = f"{self.label or ''} [{bar}] {self.pos}/{self.length} ETA {int(remaining)}s"
        else:
            line = f"{self.label or ''} {self.pos}"
        sys.stdout.write("\r" + line)
        sys.stdout.flush()


@contextlib.contextmanager
# spec: N-000649–N-000657, N-000684–N-000685
def progressbar(iterable=None, length=None, label=None, hidden: bool = False, **options: Any):
    """Context manager yielding a progress bar that wraps ``iterable``.

    Every item is still visited when there is no terminal or the bar is hidden.
    """
    if length is None and iterable is not None:
        try:
            length = len(iterable)
        except TypeError:
            length = None
    visible = (not hidden) and _isatty(sys.stdout)
    if label and not hidden and not visible:
        echo(label)
    bar = ProgressBar(iterable, length, label, visible)
    yield bar
    if visible:
        sys.stdout.write("\n")
        sys.stdout.flush()


# spec: N-000664–N-000666
def edit(text: Any = None, editor=None, env=None, require_save: bool = True,
         extension: str = ".txt", filename=None):
    """Open an editor on text or on a file. Returns saved text, or None."""
    command = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not command:
        command = "notepad" if sys.platform == "win32" else "vi"
    env_all = dict(os.environ)
    env_all.update(env or {})
    if filename is not None:
        subprocess.call(shlex.split(command) + [str(filename)], env=env_all)
        return None
    original = "" if text is None else str(text)
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(original)
        subprocess.call(shlex.split(command) + [path], env=env_all)
        with open(path, encoding="utf-8", newline="") as handle:
            saved = handle.read()
    finally:
        os.remove(path)
    if require_save and saved == original:
        return None
    return saved


# spec: N-000667–N-000671
def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or path with the default associated application. Returns a status."""
    if sys.platform == "darwin":
        argv = ["open"] + (["-R"] if locate else []) + [url]
    elif sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
            return 0
        except OSError:
            return 1
    else:
        opener = shutil.which("xdg-open")
        if opener is None:
            return 1
        argv = [opener, url]
    proc = subprocess.Popen(argv)
    if wait:
        return proc.wait()
    return 0


# spec: N-000672–N-000673
def clear() -> None:
    """Clear the terminal screen when connected to one; otherwise do nothing."""
    if not _isatty(sys.stdout):
        return
    if os.name == "nt":
        os.system("cls")
        return
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()


# spec: N-000674–N-000678
def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if force_posix:
        folder = re.sub(r"\s+", "-", app_name.lower())
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform == "win32":
        var = "APPDATA" if roaming else "LOCALAPPDATA"
        base = os.environ.get(var) or os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


# spec: N-000575–N-000577
def format_filename(filename: Any, shorten: bool = False) -> str:
    """Return a printable text form of a file name (str, bytes or path-like)."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


# spec: N-000531, N-000588
def open_file(filename: str, mode: str = "r", encoding=None, errors: str = "strict",
              lazy: bool = False, atomic: bool = False):
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    from .types import open_stream

    return open_stream(filename, mode, encoding, errors, lazy, atomic)
