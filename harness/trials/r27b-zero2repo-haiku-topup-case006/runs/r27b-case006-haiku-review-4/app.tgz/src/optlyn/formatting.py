"""Text wrapping and help-page layout helpers (PRD FP-02, FP-11; Contract section 2)."""

from __future__ import annotations

import textwrap
from typing import Iterable, List, Sequence, Tuple

DEFAULT_WRAP_WIDTH = 100  # wrap_text default (PRD FP-11)


def _rewrap_paragraph(lines: Sequence[str], width: int, initial_indent: str, subsequent_indent: str) -> List[str]:
    if lines and lines[0] == "\b":
        # A backspace-only first line keeps its own line breaks; the marker line is dropped.
        kept = [line for line in lines[1:]]
        return [
            textwrap.fill(
                line,
                width=width,
                initial_indent=initial_indent if i == 0 else subsequent_indent,
                subsequent_indent=subsequent_indent,
                break_on_hyphens=False,
            ) if line.strip() else ""
            for i, line in enumerate(kept)
        ]
    text = " ".join(part.strip() for part in lines if part.strip())
    if not text:
        return []
    return [
        textwrap.fill(
            text,
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_on_hyphens=False,
            break_long_words=True,
        )
    ]


def wrap_text(
    text: str,
    width: int = DEFAULT_WRAP_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns. Accepts any string without failing."""
    width = max(1, int(width))
    if preserve_paragraphs:
        paragraphs = _split_paragraphs(text)
    else:
        paragraphs = _split_paragraphs(text)
    out: List[str] = []
    for para in paragraphs:
        out.extend(_rewrap_paragraph(para, width, initial_indent, subsequent_indent))
        out.append("")
    if out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def _split_paragraphs(text: str) -> List[List[str]]:
    paragraphs: List[List[str]] = []
    current: List[str] = []
    for raw in text.replace("\r\n", "\n").split("\n"):
        if raw.strip() == "":
            if current:
                paragraphs.append(current)
                current = []
            continue
        if raw.strip() == "\b" and not current:
            current = ["\b"]
            continue
        current.append(raw.rstrip())
    if current:
        paragraphs.append(current)
    return paragraphs


def wrap_paragraphs(text: str, width: int, indent: str = "") -> List[str]:
    """Wrap help-style text into lines, keeping paragraph breaks."""
    lines: List[str] = []
    for para in _split_paragraphs(text):
        lines.extend(_rewrap_paragraph(para, width, indent, indent))
        lines.append("")
    while lines and lines[-1] == "":
        lines.pop()
    return lines


def format_rows(rows: Iterable[Tuple[str, str]], width: int, indent: int = 2, max_first: int = 30) -> List[str]:
    """Two-column definition list. Long first columns push the help text to the next line."""
    rows = list(rows)
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), max_first)
    help_width = max(10, width - indent - first_width - 2)
    pad = " " * indent
    out: List[str] = []
    for first, second in rows:
        if not second:
            out.append(f"{pad}{first}")
            continue
        wrapped = textwrap.wrap(" ".join(second.split()), width=help_width, break_long_words=False) or [""]
        if len(first) > first_width:
            out.append(f"{pad}{first}")
            for line in wrapped:
                out.append(f"{pad}{' ' * (first_width + 2)}{line}")
        else:
            out.append(f"{pad}{first.ljust(first_width)}  {wrapped[0]}")
            for line in wrapped[1:]:
                out.append(f"{pad}{' ' * (first_width + 2)}{line}")
    return out


def ellipsize(text: str, width: int) -> str:
    """Cut ``text`` to ``width`` characters, marking the cut with ``...``."""
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


class HelpFormatter:
    """Collects help lines; used by Command.get_help."""

    def __init__(self, width: int) -> None:
        self.width = width
        self.lines: List[str] = []

    def write(self, line: str = "") -> None:
        self.lines.append(line)

    def write_paragraphs(self, text: str, indent: str = "") -> None:
        for line in wrap_paragraphs(text, self.width - len(indent), indent):
            self.lines.append(indent + line if line else "")

    def getvalue(self) -> str:
        return "\n".join(self.lines).rstrip("\n") + "\n"
