"""Optlyn: a Command Line Interface Composition Kit.

Declare commands, groups, options and arguments with decorators; Optlyn parses the
argument list, converts values, generates help, dispatches to the callbacks and
supplies terminal helpers. Importing this package performs no I/O.
"""

from .context import Context, get_current_context
from .core import CHAIN_MARKER, Command, CommandCollection, Group
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingCommand,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .parameters import Argument, Option, Parameter
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    format_filename,
    get_app_dir,
    get_pager_file,
    getchar,
    launch,
    open_file,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .utils import ParameterSource

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
    "pass_context", "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "ParamType", "BadParameter", "Abort",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch",
    "clear", "get_app_dir", "get_current_context", "format_filename", "open_file",
    # extras
    "Argument", "ParameterSource", "CHAIN_MARKER", "OptlynError", "UsageError",
    "Exit", "FileError", "MissingParameter", "NoSuchOption", "NoSuchCommand",
    "MissingCommand", "NoArgsIsHelp", "BadOptionUsage", "BadArgumentUsage",
]
