"""Options and arguments: declaration, value sources, conversion, callbacks (PRD FP-03, FP-04, FP-07, FP-08)."""

from __future__ import annotations

import os
from typing import Any, Callable, List, Optional, Tuple as TypingTuple

from . import termui
from .exceptions import BadOptionUsage, BadParameter, MissingParameter
from .paramtypes import BOOL, INT, STRING, ParamType, Tuple, convert_type
from .utils import MISSING, ParameterSource

_TRUE_TOKENS = {"true", "1", "yes", "on", "t", "y"}
_FALSE_TOKENS = {"false", "0", "no", "off", "f", "n", ""}
_PREFIX_CHARS = "-/+"


def _is_flag_decl(decl: str) -> bool:
    return decl[:1] in _PREFIX_CHARS and len(decl) > 0


def _parse_decls(decls: List[str]) -> TypingTuple[List[str], List[str], Optional[str]]:
    flags: List[str] = []
    secondary: List[str] = []
    dest: Optional[str] = None
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise TypeError(f"Invalid parameter declaration: {decl!r}")
        if _is_flag_decl(decl):
            if "/" in decl and not decl.startswith("/"):
                on, _, off = decl.partition("/")
                flags.append(on.strip())
                secondary.append(off.strip())
            else:
                flags.append(decl)
        else:
            if dest is not None:
                raise TypeError("Only one destination name may be declared.")
            dest = decl
    return flags, secondary, dest


def _derive_dest(flags: List[str], explicit: Optional[str]) -> str:
    if explicit is not None:
        return explicit.replace("-", "_")
    longs = [f for f in flags if len(f) > 2 and f[1] == f[0]]
    candidates = longs or flags
    if not candidates:
        raise TypeError("An option needs a name or a flag declaration.")
    return candidates[0].lstrip(_PREFIX_CHARS).replace("-", "_")


class Parameter:
    """Behaviour shared by options and arguments."""

    param_type_name = "parameter"
    name: str
    type: ParamType
    nargs: int
    multiple: bool
    default: Any
    required: bool
    callback: Optional[Callable[..., Any]]
    expose_value: bool
    is_eager: bool
    hidden: bool
    deprecated: Any
    envvar: List[str]
    help: Optional[str]
    shell_complete_func: Optional[Callable[..., Any]]

    # ------------------------------------------------------------ declaration helpers

    @property
    def metavar(self) -> Optional[str]:
        """The author-supplied placeholder, or None when not given."""
        return getattr(self, "_metavar", None)

    def get_error_hint(self) -> str:
        raise NotImplementedError

    def metavar_text(self) -> Optional[str]:
        raise NotImplementedError

    def get_default(self, ctx: Any = None) -> Any:
        if callable(self.default):
            return self.default()
        return self.default

    def default_for_invoke(self, ctx: Any) -> Any:
        value = self.get_default(ctx)
        if value is None:
            return () if self.multiple else None
        return value

    def shell_complete(self, ctx: Any, incomplete: str) -> List[Any]:
        if self.shell_complete_func is not None:
            return list(self.shell_complete_func(ctx, self, incomplete))
        return self.type.shell_complete(ctx, self, incomplete)

    def is_path_like(self) -> bool:
        return self.type.is_path_like()

    # ------------------------------------------------------------ conversion

    def _type_convert(self, ctx: Any, value: Any) -> Any:
        try:
            return self.type.convert(value, self, ctx)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = self
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    def _convert_tokens(self, ctx: Any, tokens: List[str]) -> Any:
        """Convert one occurrence's tokens to its delivered shape."""
        if isinstance(self.type, Tuple):
            return self._type_convert(ctx, tuple(tokens))
        if self.nargs == 1:
            return self._type_convert(ctx, tokens[0])
        return tuple(self._type_convert(ctx, t) for t in tokens)

    def _convert_element(self, ctx: Any, element: Any) -> Any:
        """Convert one occurrence given as a Python object (a default or default-map entry)."""
        if isinstance(self.type, Tuple) or self.nargs == 1:
            return self._type_convert(ctx, element)
        if isinstance(element, (str, bytes)):
            element = [element]
        return tuple(self._type_convert(ctx, x) for x in element)

    def _convert_object(self, ctx: Any, raw: Any) -> Any:
        if self.multiple:
            if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple)):
                raise BadOptionUsage(
                    f"The default for {self.get_error_hint()} needs an iterable (sequence) default; "
                    "pass a one-element sequence for a single value.",
                    ctx=ctx,
                )
            return tuple(self._convert_element(ctx, e) for e in raw)
        return self._convert_element(ctx, raw)

    def _split_string(self, raw: str) -> List[List[str]]:
        """Split an environment or default-map string into occurrences of ``nargs`` tokens."""
        if self.nargs == 1 and not isinstance(self.type, Tuple):
            return [[raw]]
        tokens = self.type.split_envvar_value(raw)
        size = self.nargs if self.nargs > 0 else 1
        if len(tokens) % size:
            raise BadOptionUsage(
                f"{self.get_error_hint()} needs groups of {size} values; got {len(tokens)}.",
            )
        return [tokens[i:i + size] for i in range(0, len(tokens), size)]

    def _string_value(self, ctx: Any, raw: str) -> Any:
        """Value from an environment variable or a default-map string."""
        if self.multiple:
            return tuple(self._convert_tokens(ctx, group) for group in self._split_string(raw))
        groups = self._split_string(raw)
        if len(groups) != 1:
            raise BadOptionUsage(f"{self.get_error_hint()} takes exactly one value.", ctx=ctx)
        return self._convert_tokens(ctx, groups[0])

    # ------------------------------------------------------------ value sources

    def _default_map_value(self, ctx: Any) -> Any:
        raw = ctx.lookup_default(self.name)
        if raw is MISSING or raw is None:
            return MISSING
        if isinstance(raw, str):
            if self.multiple and self.nargs == 1 and not isinstance(self.type, Tuple):
                raise BadOptionUsage(
                    f"The default-map value for {self.get_error_hint()} needs an iterable (sequence) value.",
                    ctx=ctx,
                )
            if self.nargs != 1 or isinstance(self.type, Tuple):
                return self._string_value(ctx, raw)
            return self._type_convert(ctx, raw)
        return self._convert_object(ctx, raw)

    def _declared_default(self, ctx: Any) -> Any:
        raw = self.get_default(ctx)
        if raw is None:
            return MISSING
        return self._convert_object(ctx, raw)

    def _env_names(self, ctx: Any) -> List[str]:
        return list(self.envvar)

    def _env_value(self, ctx: Any) -> Any:
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            return self._value_from_env_text(ctx, raw, name)
        return MISSING

    def _value_from_env_text(self, ctx: Any, raw: str, name: str) -> Any:
        return self._string_value(ctx, raw)

    def _absent(self) -> Any:
        return () if self.multiple or self.nargs == -1 else None

    def _warn_deprecated(self, label: str) -> None:
        note = self.deprecated if isinstance(self.deprecated, str) else None
        message = f"DeprecationWarning: The {label} '{self.name}' is deprecated."
        if note:
            message += f" {note}"
        termui.echo(message, err=True)

    def _finish_value(self, ctx: Any, value: Any) -> Any:
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def process_value(self, ctx: Any, value: Any) -> Any:
        """Run the author callback (if any) and return the value to store."""
        return self._finish_value(ctx, value)


class Option(Parameter):
    """A named parameter: flags, value options, counting and repeatable options."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: Optional[List[str]] = None,
        *,
        type: Any = None,
        default: Any = None,
        required: bool = False,
        is_flag: Optional[bool] = None,
        flag_value: Any = None,
        count: bool = False,
        multiple: bool = False,
        nargs: Optional[int] = None,
        envvar: Any = None,
        allow_from_autoenv: bool = True,
        prompt: Any = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        callback: Optional[Callable[..., Any]] = None,
        is_eager: bool = False,
        expose_value: bool = True,
        hidden: bool = False,
        deprecated: Any = False,
        help: Optional[str] = None,
        metavar: Optional[str] = None,
        show_default: Any = None,
        show_envvar: bool = False,
        shell_complete: Optional[Callable[..., Any]] = None,
    ) -> None:
        flags, secondary, explicit = _parse_decls(list(param_decls or []))
        if not flags and explicit is None:
            raise TypeError("An option needs at least one flag or a destination name.")
        self.opts = flags
        self.secondary_opts = secondary
        self.name = _derive_dest(flags, explicit)
        pair = bool(secondary)
        if deprecated and required:
            raise TypeError("A deprecated option cannot also be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if nargs is not None and nargs < 1:
            raise TypeError("nargs must be a positive integer.")
        if is_flag is None:
            if pair:
                is_flag = True
            elif flag_value is not None and not count:
                is_flag = False
            elif type is BOOL or type is bool:
                is_flag = True
            elif type is None and isinstance(default, bool) and not multiple and not count:
                is_flag = True
            else:
                is_flag = False
        self.is_flag = bool(is_flag) and not count
        self.count = bool(count)
        self.multiple = bool(multiple)
        self._off_value: Any = False
        if self.is_flag:
            self.flag_value: Any = True if flag_value is None else flag_value
        else:
            self.flag_value = flag_value
        self.optional_value = (not self.is_flag) and (not self.count) and flag_value is not None

        if type is None and self.is_flag:
            ty: ParamType = BOOL
        elif type is None and self.count:
            ty = INT
        else:
            sample = default
            if self.multiple and isinstance(default, (list, tuple)) and default:
                sample = default[0]
            elif self.multiple and isinstance(default, (list, tuple)):
                sample = None
            ty = convert_type(type, sample)
        self.type = ty
        if isinstance(ty, Tuple):
            self.nargs = len(ty.types)
        else:
            self.nargs = 1 if nargs is None else nargs
        if self.is_flag or self.count:
            self.nargs = 1

        self.default = default
        self.default_is_auto = False
        if self.is_flag and default is None:
            self.default = False
            self.default_is_auto = True
        if self.count and default is None:
            self.default = 0

        self.required = bool(required)
        if isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar or [])
        self.allow_from_autoenv = bool(allow_from_autoenv)
        self.prompt_enabled = bool(prompt)
        if isinstance(prompt, str):
            self.prompt_text: Optional[str] = prompt
        elif prompt:
            self.prompt_text = self.name.replace("_", " ").capitalize()
        else:
            self.prompt_text = None
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)
        self.callback = callback
        self.is_eager = bool(is_eager)
        self.expose_value = bool(expose_value)
        self.hidden = bool(hidden)
        self.deprecated = deprecated
        self.help = help
        self._metavar = metavar
        self.show_default = show_default
        self.show_envvar = bool(show_envvar)
        self.shell_complete_func = shell_complete

    # ------------------------------------------------------------ declaration helpers

    @property
    def takes_value(self) -> bool:
        return not self.is_flag and not self.count

    @property
    def all_flags(self) -> List[str]:
        return self.opts + self.secondary_opts

    def flag_value_for(self, flag: str) -> Any:
        if flag in self.secondary_opts:
            return self._off_value
        return self.flag_value

    def get_error_hint(self) -> str:
        return " / ".join(f"'{f}'" for f in self.all_flags) or f"'{self.name}'"

    def metavar_text(self) -> Optional[str]:
        if self._metavar is not None:
            return self._metavar
        if self.is_flag or self.count:
            return None
        text = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs > 1 and not isinstance(self.type, Tuple):
            text = " ".join([text] * self.nargs)
        return text

    # ------------------------------------------------------------ env

    def _env_names(self, ctx: Any) -> List[str]:
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix:
            parts = [ctx.auto_envvar_prefix] + ctx.path_names_below_root() + [self.name]
            auto = "_".join(p.replace("-", "_") for p in parts).upper()
            names.append(auto)
        return names

    def _value_from_env_text(self, ctx: Any, raw: str, name: str) -> Any:
        if self.is_flag:
            return self._flag_from_env(ctx, raw)
        if self.count:
            return self._type_convert(ctx, raw)
        return self._string_value(ctx, raw)

    def _flag_from_env(self, ctx: Any, raw: str) -> Any:
        if raw == self.flag_value and not isinstance(self.flag_value, bool):
            return self.flag_value
        text = raw.strip().lower()
        if text in _TRUE_TOKENS:
            return self.flag_value if not isinstance(self.flag_value, bool) else True
        if text in _FALSE_TOKENS:
            return False
        if not isinstance(self.flag_value, bool) and self.flag_value is not None:
            return MISSING
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)

    # ------------------------------------------------------------ resolution

    def _value_from_cmdline(self, ctx: Any, occs: list) -> Any:
        if self.count:
            return len(occs)
        if self.is_flag:
            return occs[-1][1]
        if self.multiple:
            values = []
            for kind, payload in occs:
                if kind == "tokens":
                    values.append(self._convert_tokens(ctx, payload))
                else:
                    values.append(payload)
            return tuple(values)
        kind, payload = occs[-1]
        if kind == "tokens":
            return self._convert_tokens(ctx, payload)
        return payload

    def _prompt_default(self, ctx: Any) -> Any:
        value = self._default_map_value(ctx)
        if value is MISSING:
            value = self._declared_default(ctx)
        return value

    def _prompt(self, ctx: Any) -> Any:
        default = self._prompt_default(ctx)
        if default is MISSING:
            default = None

        def proc(raw: str) -> Any:
            value = self._type_convert(ctx, raw)
            return (value,) if self.multiple else value

        return termui.prompt(
            self.prompt_text or self.name,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=proc,
        )

    def resolve(self, ctx: Any) -> TypingTuple[Any, ParameterSource]:
        """Return ``(value, source)``; the value is MISSING only if nothing was supplied."""
        occs = ctx._cl.get(self, [])
        explicit = [o for o in occs if o[0] != "prompt"]
        if explicit:
            if self.deprecated:
                self._warn_deprecated("option")
            return self._value_from_cmdline(ctx, explicit), ParameterSource.COMMANDLINE
        if any(o[0] == "prompt" for o in occs) and self.prompt_enabled:
            return self._prompt(ctx), ParameterSource.PROMPT

        env = self._env_value(ctx)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT
        if self.prompt_enabled and self.prompt_required:
            return self._prompt(ctx), ParameterSource.PROMPT
        dm = self._default_map_value(ctx)
        if dm is not MISSING:
            return dm, ParameterSource.DEFAULT_MAP
        declared = self._declared_default(ctx)
        if declared is not MISSING:
            return declared, ParameterSource.DEFAULT
        if self.required:
            raise MissingParameter(ctx=ctx, param=self)
        return self._absent(), ParameterSource.DEFAULT

    def rank(self, source: ParameterSource) -> int:
        """Explicitness rank used to pick the winner among options sharing a destination."""
        order = {
            ParameterSource.PROMPT: 5,
            ParameterSource.COMMANDLINE: 4,
            ParameterSource.ENVIRONMENT: 3,
            ParameterSource.DEFAULT_MAP: 2,
            ParameterSource.DEFAULT: 1,
        }
        base = order.get(source, 0)
        if source is ParameterSource.DEFAULT and self.default_is_auto:
            return 0
        return base


class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: List[str],
        *,
        type: Any = None,
        default: Any = None,
        required: Optional[bool] = None,
        nargs: int = 1,
        envvar: Any = None,
        deprecated: Any = False,
        help: Optional[str] = None,
        metavar: Optional[str] = None,
        callback: Optional[Callable[..., Any]] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        hidden: bool = False,
        shell_complete: Optional[Callable[..., Any]] = None,
    ) -> None:
        decls = list(param_decls or [])
        if len(decls) != 1 or not decls[0] or decls[0][0] in _PREFIX_CHARS:
            raise TypeError("An argument takes exactly one destination name.")
        self.name = decls[0].replace("-", "_")
        self.opts: List[str] = []
        self.secondary_opts: List[str] = []
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        ty = convert_type(type, default)
        if isinstance(ty, Tuple):
            nargs = len(ty.types)
        self.type = ty
        self.nargs = nargs
        self.multiple = False
        self.default = default
        if required is None:
            required = default is None and nargs != -1
        self.required = bool(required)
        if deprecated and self.required:
            raise TypeError("A deprecated argument cannot also be required.")
        if isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar or [])
        self.allow_from_autoenv = False
        self.deprecated = deprecated
        self.help = help
        self._metavar = metavar
        self.callback = callback
        self.expose_value = bool(expose_value)
        self.is_eager = bool(is_eager)
        self.hidden = bool(hidden)
        self.shell_complete_func = shell_complete
        self.show_default = None
        self.show_envvar = False
        self.prompt_enabled = False

    @property
    def min_tokens(self) -> int:
        if self.nargs == -1:
            return 1 if self.required else 0
        return self.nargs if self.required else 0

    def get_error_hint(self) -> str:
        return f"'{self.name.upper()}'"

    def metavar_text(self) -> str:
        return self._metavar or self.name.upper()

    def resolve(self, ctx: Any) -> TypingTuple[Any, ParameterSource]:
        tokens = ctx._arg_tokens.get(self)
        if tokens:
            if self.deprecated:
                self._warn_deprecated("argument")
            if self.nargs == 1 and not isinstance(self.type, Tuple):
                value = self._type_convert(ctx, tokens[0])
            else:
                value = self._convert_tokens(ctx, tokens)
            return value, ParameterSource.COMMANDLINE
        env = self._env_value(ctx)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT
        dm = self._default_map_value(ctx)
        if dm is not MISSING:
            return dm, ParameterSource.DEFAULT_MAP
        declared = self._declared_default(ctx)
        if declared is not MISSING:
            return declared, ParameterSource.DEFAULT
        if self.required:
            raise MissingParameter(ctx=ctx, param=self)
        return self._absent(), ParameterSource.DEFAULT

    def rank(self, source: ParameterSource) -> int:
        return 0


def describe_type(param: Parameter) -> str:
    """Human-readable type name for messages and help."""
    return param.type.name


__all__ = ["Option", "Argument", "STRING", "INT", "BOOL", "ParamType", "describe_type"]
