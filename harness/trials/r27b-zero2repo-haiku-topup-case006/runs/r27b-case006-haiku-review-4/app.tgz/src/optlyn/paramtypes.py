"""Parameter types and value conversion (PRD FP-05, FP-09; Contract section 5)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import stat
import sys
import tempfile
import uuid as _uuid
from typing import Any, Callable, Iterable, List, Optional, Sequence

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types. Subclasses implement :meth:`convert`."""

    name: str = "text"

    def __call__(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        return self.convert(value, param, ctx)

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        return value

    def get_metavar(self, param: Any = None) -> Optional[str]:
        return None

    def split_envvar_value(self, rv: str) -> List[str]:
        return rv.split()

    def shell_complete(self, ctx: Any, param: Any, incomplete: str) -> List[Any]:
        return []

    def is_path_like(self) -> bool:
        return False

    def fail(self, message: str, param: Any = None, ctx: Any = None) -> None:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> int:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        raise AssertionError("unreachable")


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> float:
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)
        raise AssertionError("unreachable")


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> bool:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)
        raise AssertionError("unreachable")


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> _uuid.UUID:
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)
        raise AssertionError("unreachable")


class FuncParamType(ParamType):
    """Adapter for a plain conversion function that refuses by raising ValueError."""

    def __init__(self, func: Callable[[str], Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        if not isinstance(value, str):
            # Defaults and Python-side values are already of the right kind.
            return value
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(f"{value!r} is not valid: {exc}", param, ctx)
        raise AssertionError("unreachable")


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices: Iterable[Any], case_sensitive: bool = True) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices: List[Any] = list(choices)
            self._tokens = [m.name for m in self.choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def _norm(self, text: str, ctx: Any = None) -> str:
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if func is not None:
            text = func(text)
        return text if self.case_sensitive else text.casefold()

    def get_metavar(self, param: Any = None) -> str:
        return "{" + "|".join(self._tokens) + "}"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        for original in self.choices:
            if value is original:
                return original
        token = value.name if isinstance(value, enum.Enum) else str(value)
        wanted = self._norm(token, ctx)
        for original, tok in zip(self.choices, self._tokens):
            if self._norm(tok, ctx) == wanted:
                return original
        choices_text = ", ".join(repr(t) for t in self._tokens)
        self.fail(f"{value!r} is not one of {choices_text}.", param, ctx)
        raise AssertionError("unreachable")

    def shell_complete(self, ctx: Any, param: Any, incomplete: str) -> List[Any]:
        out = []
        for orig, tok in zip(self.choices, self._tokens):
            if tok.startswith(incomplete):
                out.append(tok)
        return out


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: Optional[Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param: Any = None) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> _dt.datetime:
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats_text = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats_text}.", param, ctx)
        raise AssertionError("unreachable")


def _range_desc(lo: Any, hi: Any, lo_open: bool, hi_open: bool) -> str:
    parts = []
    if lo is not None:
        parts.append(f"{'>' if lo_open else '>='} {lo}")
    if hi is not None:
        parts.append(f"{'<' if hi_open else '<='} {hi}")
    return " and ".join(parts) if parts else "any value"


class IntRange(IntParamType):
    name = "integer range"

    def __init__(
        self,
        min: Optional[int] = None,
        max: Optional[int] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param: Any = None) -> str:
        return "INTEGER RANGE"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> int:
        v = super().convert(value, param, ctx)
        below = above = False
        if self.min is not None:
            below = v <= self.min if self.min_open else v < self.min
        if self.max is not None:
            above = v >= self.max if self.max_open else v > self.max
        if not (below or above):
            return v
        if self.clamp:
            if below:
                v = self.min + 1 if self.min_open else self.min
            else:
                v = self.max - 1 if self.max_open else self.max
            return v
        self.fail(
            f"{v} is not in the range {_range_desc(self.min, self.max, self.min_open, self.max_open)}.",
            param,
            ctx,
        )
        raise AssertionError("unreachable")


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(
        self,
        min: Optional[float] = None,
        max: Optional[float] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param: Any = None) -> str:
        return "FLOAT RANGE"

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> float:
        v = super().convert(value, param, ctx)
        below = above = False
        if self.min is not None:
            below = v <= self.min if self.min_open else v < self.min
        if self.max is not None:
            above = v >= self.max if self.max_open else v > self.max
        if not (below or above):
            return v
        if self.clamp:
            return float(self.min) if below else float(self.max)
        self.fail(
            f"{v} is not in the range {_range_desc(self.min, self.max, self.min_open, self.max_open)}.",
            param,
            ctx,
        )
        raise AssertionError("unreachable")


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"

    def __init__(self, types: Sequence[Any]) -> None:
        self.types = [convert_type(t) for t in types]

    def get_metavar(self, param: Any = None) -> str:
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> tuple:
        if not isinstance(value, (list, tuple)):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class _NonClosing:
    """Proxy for a standard stream: closing it only flushes; the stream stays open."""

    _optlyn_file = True

    def __init__(self, stream: Any) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def __iter__(self) -> Any:
        return iter(self._stream)

    def __next__(self) -> Any:
        return next(self._stream)

    @property
    def closed(self) -> bool:
        return False

    def close(self) -> None:
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __enter__(self) -> "_NonClosing":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


class _EncodedStd:
    """Text view of a standard stream that encodes/decodes with a declared encoding."""

    _optlyn_file = True

    def __init__(self, stream: Any, encoding: str, errors: str) -> None:
        self._text = stream
        self._buf = getattr(stream, "buffer", None)
        self._enc = encoding
        self._errs = errors

    def write(self, data: Any) -> int:
        if isinstance(data, str):
            data = data.encode(self._enc, self._errs)
        self._text.flush()
        if self._buf is not None:
            self._buf.write(data)
            self._buf.flush()
        else:
            self._text.write(data.decode(self._enc, self._errs))
        return len(data)

    def read(self, size: int = -1) -> str:
        if self._buf is None:
            return self._text.read(size)
        return self._buf.read(size).decode(self._enc, self._errs)

    def readline(self) -> str:
        if self._buf is None:
            return self._text.readline()
        return self._buf.readline().decode(self._enc, self._errs)

    def __iter__(self) -> Any:
        while True:
            line = self.readline()
            if not line:
                return
            yield line

    def flush(self) -> None:
        self._text.flush()

    @property
    def closed(self) -> bool:
        return False

    def close(self) -> None:
        self.flush()

    def __enter__(self) -> "_EncodedStd":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


class _AtomicFile:
    """Writes go to a sibling temp file which replaces the target on close."""

    _optlyn_file = True

    def __init__(self, handle: Any, tmp_path: str, target: str) -> None:
        self._handle = handle
        self._tmp = tmp_path
        self._target = target
        self._done = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._handle, name)

    def __iter__(self) -> Any:
        return iter(self._handle)

    def close(self) -> None:
        if self._done:
            return
        self._done = True
        self._handle.close()
        os.replace(self._tmp, self._target)

    def __enter__(self) -> "_AtomicFile":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


def _open_real(path: str, mode: str, encoding: Optional[str], errors: str, atomic: bool) -> Any:
    if atomic and ("w" in mode or "a" in mode):
        target_dir = os.path.dirname(os.path.abspath(path))
        fd, tmp = tempfile.mkstemp(dir=target_dir, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        try:
            handle = open(tmp, mode, encoding=None if "b" in mode else encoding,
                          errors=None if "b" in mode else errors)
        except OSError:
            os.unlink(tmp)
            raise
        return _AtomicFile(handle, tmp, path)
    if "b" in mode:
        return open(path, mode)
    return open(path, mode, encoding=encoding, errors=errors)


class _LazyFile:
    """A file that opens on first I/O (used for write-mode files by default)."""

    _optlyn_file = True

    def __init__(self, path: str, mode: str, encoding: Optional[str], errors: str, atomic: bool) -> None:
        self._path = path
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._handle: Any = None

    def _open(self) -> Any:
        if self._handle is None:
            try:
                self._handle = _open_real(self._path, self._mode, self._encoding, self._errors, self._atomic)
            except OSError as exc:
                raise FileError(self._path, exc.strerror or str(exc)) from exc
        return self._handle

    def __getattr__(self, name: str) -> Any:
        return getattr(self._open(), name)

    def __iter__(self) -> Any:
        return iter(self._open())

    def close(self) -> None:
        if self._handle is not None:
            handle, self._handle = self._handle, None
            handle.close()

    def __enter__(self) -> "_LazyFile":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


def open_standard_stream(filename: str, mode: str, encoding: Optional[str], errors: str) -> Any:
    """Return a non-closing view of stdin/stdout for the ``-`` token."""
    reading = "r" in mode
    src = sys.stdin if reading else sys.stdout
    if "b" in mode:
        return _NonClosing(getattr(src, "buffer", src))
    if encoding and getattr(src, "buffer", None) is not None:
        return _EncodedStd(src, encoding, errors)
    return _NonClosing(src)


class File(ParamType):
    """Opens a file (value is an open file object); ``-`` is stdin or stdout."""

    name = "filename"

    def __init__(
        self,
        mode: str = "r",
        encoding: Optional[str] = None,
        errors: str = "strict",
        lazy: Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param: Any = None) -> str:
        return "FILENAME"

    def is_path_like(self) -> bool:
        return True

    def split_envvar_value(self, rv: str) -> List[str]:
        return rv.split(os.pathsep)

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        path = os.fspath(value) if not isinstance(value, str) else value
        if path == "-":
            return open_standard_stream(path, self.mode, self.encoding, self.errors)
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        if lazy:
            return _LazyFile(path, self.mode, self.encoding, self.errors, self.atomic)
        try:
            return _open_real(path, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as exc:
            self.fail(f"'{path}': {exc.strerror or exc}", param, ctx)
        raise AssertionError("unreachable")


class Path(ParamType):
    """Validates a filesystem path and returns it (not an open file)."""

    name = "path"

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param: Any = None) -> str:
        return "PATH"

    def is_path_like(self) -> bool:
        return True

    def split_envvar_value(self, rv: str) -> List[str]:
        return rv.split(os.pathsep)

    def _shape(self, rv: str) -> Any:
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def convert(self, value: Any, param: Any = None, ctx: Any = None) -> Any:
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        text = os.fspath(value) if not isinstance(value, str) else value
        if self.allow_dash and text == "-":
            return self._shape("-")
        rv = os.path.realpath(text) if self.resolve_path else text
        try:
            st = os.stat(rv)
        except OSError:
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
            return self._shape(rv)
        is_dir = stat.S_ISDIR(st.st_mode)
        if is_dir and not self.dir_okay:
            self.fail(f"{text!r} is a directory.", param, ctx)
        if not is_dir and not self.file_okay:
            self.fail(f"{text!r} is a file.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{text!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{text!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{text!r} is not executable.", param, ctx)
        return self._shape(rv)


# ---------------------------------------------------------------- ready-made instances

STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def convert_type(ty: Any, default: Any = None) -> ParamType:
    """Turn a declared type (instance, class, function, builtin, or None) into a ParamType.

    When ``ty`` is None the type is inferred from ``default``. A list or tuple default
    infers from its first element.
    """
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, (tuple, list)):
        return Tuple(list(ty))
    if ty is None or ty is str:
        if ty is None and default is not None:
            return _infer(default)
        return STRING
    if ty is bool:
        return BOOL
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")


def _infer(default: Any) -> ParamType:
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)):
        if default:
            return _infer(default[0])
        return STRING
    return STRING
