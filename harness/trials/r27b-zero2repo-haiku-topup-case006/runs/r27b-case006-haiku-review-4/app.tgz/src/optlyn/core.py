"""Commands, groups, command collections, parsing and dispatch (PRD FP-01, FP-06, FP-10, FP-13)."""

from __future__ import annotations

import inspect
import io
import os
import sys
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple as TypingTuple

from . import termui
from .context import Context
from .exceptions import (
    BadArgumentUsage,
    BadOptionUsage,
    Exit,
    MissingCommand,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import ellipsize, format_rows, wrap_paragraphs
from .parameters import Argument, Option
from .paramtypes import Choice
from .utils import ParameterSource, first_sentence


class _ChainMarker:
    """Value of ``ctx.invoked_subcommand`` on a chaining group (distinct from any child name)."""

    def __repr__(self) -> str:
        return "<chained subcommands>"


CHAIN_MARKER = _ChainMarker()


def derive_command_name(func_name: str) -> str:
    """Lowercase, strip a trailing _command/_cmd/_group/_grp, underscores to dashes."""
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _clean_help(text: Optional[str]) -> Optional[str]:
    if text is None:
        return None
    cut = text.find("\f")
    if cut >= 0:
        text = text[:cut]
    return text


def _default_prog_name() -> str:
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "root"


def completion_var_name(prog_name: str) -> str:
    base = os.path.basename(prog_name)
    return "_" + base.upper().replace("-", "_") + "_COMPLETE"


def _register_files(ctx: Context, value: Any) -> None:
    items = value if isinstance(value, (list, tuple)) else [value]
    for item in items:
        if item is None or item in (sys.stdin, sys.stdout, sys.stderr):
            continue
        if getattr(item, "_optlyn_file", False) or isinstance(item, io.IOBase):
            ctx.call_on_close(item.close)


def _help_callback(ctx: Context, param: Any, value: Any) -> Any:
    if not value or ctx.resilient_parsing:
        return value
    termui.echo(ctx.get_help(), nl=False)
    raise Exit(0)


def _auto_help_option(ctx: Context, author_flags: set) -> Optional[Option]:
    names = [n for n in ctx.help_option_names if n not in author_flags]
    if not names:
        return None
    return Option(
        names,
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_help_callback,
    )


class _Scanner:
    """Walks option-like tokens for one command, collecting occurrences in order."""

    def __init__(self, ctx: Context, params: List[Any]) -> None:
        self.ctx = ctx
        self.table: Dict[str, Option] = {}
        self.prefixes = {"-"}
        for param in params:
            if isinstance(param, Option):
                for flag in param.all_flags:
                    self.table.setdefault(ctx.normalize(flag), param)
                    self.prefixes.add(flag[0])
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        self.occs: List[TypingTuple[Option, tuple]] = []
        self.positionals: List[TypingTuple[str, bool]] = []
        self.error: Optional[UsageError] = None

    def is_option_token(self, tok: str) -> bool:
        return len(tok) > 1 and tok[0] in self.prefixes

    def knows(self, tok: str) -> bool:
        return self.ctx.normalize(tok.partition("=")[0]) in self.table or self.ctx.normalize(tok) in self.table

    def consume(self, tokens: List[str], i: int) -> int:
        tok = tokens[i]
        prefix = tok[0]
        key = self.ctx.normalize(tok)
        if key in self.table:
            return self._take(tokens, i, self.table[key], tok, None)
        if len(tok) > 2 and tok[1] == prefix:
            name, sep, value = tok.partition("=")
            param = self.table.get(self.ctx.normalize(name))
            if param is None:
                if self.ignore_unknown:
                    self.positionals.append((tok, True))
                    return i + 1
                raise NoSuchOption(tok, self.ctx)
            return self._take(tokens, i, param, name, value if sep else None)
        j = 1
        while j < len(tok):
            flag = prefix + tok[j]
            param = self.table.get(self.ctx.normalize(flag))
            if param is None:
                if self.ignore_unknown:
                    self.positionals.append((prefix + tok[j:], True))
                    return i + 1
                raise NoSuchOption(flag, self.ctx)
            if param.takes_value:
                rest = tok[j + 1:]
                return self._take(tokens, i, param, flag, rest if rest else None)
            self._take(tokens, i, param, flag, None)
            j += 1
        return i + 1

    def _take(self, tokens: List[str], i: int, param: Option, flag: str, inline: Optional[str]) -> int:
        ctx = self.ctx
        if param.count:
            if inline is not None:
                raise BadOptionUsage(f"Option '{flag}' does not take a value.", ctx)
            self.occs.append((param, ("count", None)))
            return i + 1
        if param.is_flag:
            if inline is not None:
                raise BadOptionUsage(f"Option '{flag}' does not take a value.", ctx)
            self.occs.append((param, ("flag", param.flag_value_for(flag))))
            return i + 1
        if param.optional_value:
            if inline is not None:
                self.occs.append((param, ("tokens", [inline])))
                return i + 1
            nxt = i + 1
            if nxt < len(tokens) and not self.is_option_token(tokens[nxt]):
                self.occs.append((param, ("tokens", [tokens[nxt]])))
                return i + 2
            self.occs.append((param, ("flag", param.flag_value)))
            return i + 1
        need = param.nargs
        vals: List[str] = [] if inline is None else [inline]
        nxt = i + 1
        while len(vals) < need and nxt < len(tokens):
            vals.append(tokens[nxt])
            nxt += 1
        if len(vals) < need:
            if param.prompt_enabled and not vals:
                self.occs.append((param, ("prompt", None)))
                return i + 1
            if need > 1:
                raise BadOptionUsage(f"Option '{flag}' requires {need} arguments.", ctx)
            raise BadOptionUsage(f"Option '{flag}' requires an argument.", ctx)
        self.occs.append((param, ("tokens", vals)))
        return nxt

    def scan(self, tokens: List[str]) -> "_Scanner":
        i = 0
        n = len(tokens)
        after_dd = False
        active = True
        try:
            while i < n:
                tok = tokens[i]
                if after_dd:
                    self.positionals.append((tok, False))
                    i += 1
                    continue
                if tok == "--":
                    after_dd = True
                    i += 1
                    continue
                if not active:
                    self.positionals.append((tok, self.is_option_token(tok)))
                    i += 1
                    continue
                if self.is_option_token(tok):
                    i = self.consume(tokens, i)
                else:
                    self.positionals.append((tok, False))
                    i += 1
                    if not self.interspersed:
                        active = False
        except UsageError as exc:
            self.error = exc
        return self


class Command:
    """A leaf command: parses its own options and arguments and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name: Optional[str] = None,
        callback: Optional[Callable[..., Any]] = None,
        params: Optional[Iterable[Any]] = None,
        *,
        help: Optional[str] = None,
        short_help: Optional[str] = None,
        epilog: Optional[str] = None,
        options_metavar: Optional[str] = "[OPTIONS]",
        context_settings: Optional[Dict[str, Any]] = None,
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: Any = False,
    ) -> None:
        if name is None and callback is not None:
            name = derive_command_name(callback.__name__)
        self.name = name
        self.callback = callback
        self.params: List[Any] = list(params or [])
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise TypeError("Only one variadic argument may be declared on a command.")
        if help is None and callback is not None and callback.__doc__:
            help = inspect.cleandoc(callback.__doc__)
        self.help = _clean_help(help)
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = bool(add_help_option)
        self.no_args_is_help = bool(no_args_is_help)
        self.hidden = bool(hidden)
        self.deprecated = deprecated

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self.main(*args, **kwargs)

    # ------------------------------------------------------------ parameters

    def _argument_params(self) -> List[Argument]:
        return [p for p in self.params if isinstance(p, Argument)]

    def _parse_params(self, ctx: Context) -> List[Any]:
        cached = getattr(ctx, "_all_params", None)
        if cached is None:
            cached = list(self.params)
            if self.add_help_option:
                author_flags = {f for p in self.params if isinstance(p, Option) for f in p.all_flags}
                auto = _auto_help_option(ctx, author_flags)
                if auto is not None:
                    cached.append(auto)
            ctx._all_params = cached
        return cached

    def get_short_help(self) -> str:
        if self.short_help:
            return self.short_help
        return first_sentence(self.help or "")

    # ------------------------------------------------------------ parsing

    def _run_eager(self, ctx: Context, occs: list, done: set) -> None:
        for param, _occ in occs:
            if param.is_eager and param not in done:
                done.add(param)
                self._process_one(ctx, param)

    def _process_one(self, ctx: Context, param: Any) -> None:
        value, source = param.resolve(ctx)
        self._finish(ctx, param, value, source)

    def _finish(self, ctx: Context, param: Any, value: Any, source: Any) -> None:
        value = param.process_value(ctx, value)
        if param.expose_value:
            ctx.params[param.name] = value
            _register_files(ctx, value)
        ctx._sources[param.name] = source or ParameterSource.DEFAULT

    def _process_params(self, ctx: Context, params: List[Any], done: set) -> None:
        for param in params:
            if param in done:
                continue
            same = [q for q in params if q.name == param.name and q not in done and q.expose_value]
            if param.expose_value and len(same) > 1:
                resolved = []
                for index, q in enumerate(same):
                    value, source = q.resolve(ctx)
                    resolved.append((q.rank(source), index, q, value, source))
                _rank, _index, winner, value, source = max(resolved, key=lambda r: (r[0], r[1]))
                done.update(same)
                self._finish(ctx, winner, value, source)
            else:
                done.add(param)
                self._process_one(ctx, param)

    def _assign_arguments(self, ctx: Context, positionals: List[TypingTuple[str, bool]]) -> List[TypingTuple[str, bool]]:
        arguments = self._argument_params()
        remaining = list(positionals)
        idx = 0
        for k, arg in enumerate(arguments):
            if arg.nargs == -1:
                reserve = sum(a.min_tokens for a in arguments[k + 1:])
                take = max(0, len(remaining) - idx - reserve)
                if take:
                    ctx._arg_tokens[arg] = [t for t, _ in remaining[idx: idx + take]]
                idx += take
                continue
            avail = len(remaining) - idx
            if avail >= arg.nargs:
                ctx._arg_tokens[arg] = [t for t, _ in remaining[idx: idx + arg.nargs]]
                idx += arg.nargs
            elif avail > 0:
                raise BadArgumentUsage(
                    f"Argument '{arg.name.upper()}' takes {arg.nargs} values.", ctx
                )
        return remaining[idx:]

    def _check_extras(self, ctx: Context, extras: List[TypingTuple[str, bool]]) -> None:
        if not extras:
            ctx.args = []
            return
        if ctx._leftover_ok:
            # A chained subcommand hands everything it did not consume to the next command.
            ctx.args = [t for t, _ in extras]
            return
        optlike = [t for t, flag in extras if flag]
        if optlike:
            raise NoSuchOption(optlike[0], ctx)
        if ctx.allow_extra_args:
            ctx.args = [t for t, _ in extras]
            return
        names = " ".join(t for t, _ in extras)
        noun = "argument" if len(extras) == 1 else "arguments"
        raise BadArgumentUsage(f"Got unexpected extra {noun} ({names})", ctx)

    def _set_client_occurrences(self, ctx: Context, scanner: _Scanner) -> None:
        ctx._cl = {}
        for param, occ in scanner.occs:
            ctx._cl.setdefault(param, []).append(occ)

    def parse_args(self, ctx: Context, args: List[str]) -> List[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self._parse_params(ctx)
        scanner = _Scanner(ctx, params).scan(args)
        self._set_client_occurrences(ctx, scanner)
        done: set = set()
        self._run_eager(ctx, scanner.occs, done)
        if scanner.error is not None:
            raise scanner.error
        extras = self._assign_arguments(ctx, scanner.positionals)
        self._check_extras(ctx, extras)
        self._process_params(ctx, params, done)
        return ctx.args

    # ------------------------------------------------------------ context & invocation

    def make_context(
        self,
        info_name: Optional[str],
        args: List[str],
        parent: Optional[Context] = None,
        leftover_ok: bool = False,
        **extra: Any,
    ) -> Context:
        settings = dict(self.context_settings)
        command_map = settings.pop("default_map", None)
        explicit_map = extra.pop("default_map", None)
        nested = None
        if parent is not None and isinstance(parent.default_map, dict):
            candidate = parent.default_map.get(info_name)
            if isinstance(candidate, dict):
                nested = candidate
        if explicit_map is not None:
            default_map = explicit_map
        elif nested is not None:
            default_map = nested
        else:
            default_map = command_map
        kwargs = dict(settings)
        kwargs.update(extra)
        ctx = Context(self, parent=parent, info_name=info_name, default_map=default_map, **kwargs)
        if parent is not None and getattr(parent.command, "chain", False) and "allow_interspersed_args" not in kwargs:
            ctx.allow_interspersed_args = False
        ctx._leftover_ok = leftover_ok
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException as exc:
            if isinstance(exc, UsageError) and exc.ctx is None:
                exc.ctx = ctx
            ctx.close()
            raise
        return ctx

    def _call(self, ctx: Context) -> Any:
        if self.callback is None:
            return None
        return self.callback(**ctx.params)

    def _warn_deprecated(self, ctx: Context) -> None:
        note = self.deprecated if isinstance(self.deprecated, str) else None
        message = f"DeprecationWarning: The command '{ctx.info_name}' is deprecated."
        if note:
            message += f" {note}"
        termui.echo(message, err=True)

    def invoke(self, ctx: Context) -> Any:
        try:
            with ctx:
                if self.deprecated:
                    self._warn_deprecated(ctx)
                return self._call(ctx)
        finally:
            ctx.close()

    def main(
        self,
        args: Optional[List[str]] = None,
        prog_name: Optional[str] = None,
        complete_var: Optional[str] = None,
        standalone_mode: bool = True,
        **extra: Any,
    ) -> Any:
        """Run the command on ``args`` (default ``sys.argv[1:]``)."""
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _default_prog_name()
        var = complete_var or completion_var_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import run_completion

            code = run_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(code)
            return code
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except Exit as exc:
                if not standalone_mode:
                    return None
                sys.exit(exc.exit_code)
            except OptlynError as exc:
                if not standalone_mode:
                    raise
                exc.show()
                sys.exit(exc.exit_code)
            except (KeyboardInterrupt, EOFError):
                if not standalone_mode:
                    raise
                sys.stderr.write("Aborted!\n")
                sys.exit(1)
        finally:
            try:
                sys.stdout.flush()
            except (OSError, ValueError):
                pass

    # ------------------------------------------------------------ help

    def _usage_subcommand_parts(self) -> List[str]:
        return []

    def get_usage(self, ctx: Context) -> str:
        parts = [ctx.command_path]
        if self.options_metavar:
            parts.append(self.options_metavar)
        for arg in self._argument_params():
            text = arg.metavar_text()
            if arg.nargs == -1:
                parts.append(f"{text}..." if arg.required else f"[{text}]...")
            elif arg.required:
                parts.append(text)
            else:
                parts.append(f"[{text}]")
        parts.extend(self._usage_subcommand_parts())
        return "Usage: " + " ".join(parts)

    def _option_rows(self, ctx: Context) -> List[TypingTuple[str, str]]:
        rows = []
        for param in self._parse_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            first = ", ".join(param.opts)
            if param.secondary_opts:
                first += "/" + ", ".join(param.secondary_opts)
            metavar = param.metavar_text()
            if metavar:
                first += " " + metavar
            bits = []
            if param.deprecated:
                bits.append("(DEPRECATED)")
            if param.help:
                bits.append(param.help)
            show = param.show_default if param.show_default is not None else ctx.show_default
            if show:
                default = param.default
                if isinstance(param.show_default, str):
                    bits.append(f"[default: {param.show_default}]")
                elif param.is_flag and not default:
                    pass  # a false flag default stays hidden (PRD FP-02)
                elif callable(default):
                    bits.append("[default: (dynamic)]")
                elif default is not None:
                    text = ", ".join(str(d) for d in default) if isinstance(default, (list, tuple)) else str(default)
                    bits.append(f"[default: {text}]")
            if param.show_envvar:
                names = param._env_names(ctx)
                if names:
                    bits.append(f"[env var: {', '.join(names)}]")
            if isinstance(param.type, Choice):
                bits.append(f"[choices: {', '.join(param.type._tokens)}]")
            rows.append((first, " ".join(bits)))
        return rows

    def _argument_rows(self, ctx: Context) -> List[TypingTuple[str, str]]:
        return [
            (arg.metavar_text(), arg.help)
            for arg in self._argument_params()
            if arg.help and not arg.hidden
        ]

    def _command_rows(self, ctx: Context, width: int) -> List[TypingTuple[str, str]]:
        return []

    def get_help(self, ctx: Context) -> str:
        width = ctx.get_terminal_width()
        lines: List[str] = [self.get_usage(ctx), ""]
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else "This command is deprecated."
            lines.extend(wrap_paragraphs(f"DEPRECATED: {note}", width))
            lines.append("")
        if self.help:
            lines.extend(wrap_paragraphs(self.help, width))
            lines.append("")
        arg_rows = self._argument_rows(ctx)
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(format_rows(arg_rows, width))
            lines.append("")
        opt_rows = self._option_rows(ctx)
        if opt_rows:
            lines.append("Options:")
            lines.extend(format_rows(opt_rows, width))
            lines.append("")
        cmd_rows = self._command_rows(ctx, width)
        if cmd_rows:
            lines.append("Commands:")
            lines.extend(format_rows(cmd_rows, width))
            lines.append("")
        if self.epilog:
            lines.extend(wrap_paragraphs(self.epilog, width))
            lines.append("")
        return "\n".join(lines).rstrip("\n") + "\n"


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name: Optional[str] = None,
        commands: Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: Optional[bool] = None,
        subcommand_metavar: Optional[str] = None,
        chain: bool = False,
        result_callback: Optional[Callable[..., Any]] = None,
        **kwargs: Any,
    ) -> None:
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands: Dict[str, Command] = {}
        self.invoke_without_command = bool(invoke_without_command)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self.result_callback_func = result_callback
        if commands:
            items = commands.values() if isinstance(commands, dict) else commands
            for cmd in items:
                self.add_command(cmd)

    # ------------------------------------------------------------ registration

    def add_command(self, cmd: Command, name: Optional[str] = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise ValueError("A command needs a name to be registered.")
        self.commands[key] = cmd

    def command(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], Command]:
        from .decorators import command as command_decorator

        def decorator(func: Callable[..., Any]) -> Command:
            cmd = command_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], "Group"]:
        from .decorators import group as group_decorator

        def decorator(func: Callable[..., Any]) -> "Group":
            grp = group_decorator(*args, **kwargs)(func)
            self.add_command(grp)
            return grp

        return decorator

    def result_callback(self) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            self.result_callback_func = func
            return func

        return decorator

    # ------------------------------------------------------------ lookup

    def list_commands(self, ctx: Context) -> List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> Optional[Command]:
        return self.commands.get(cmd_name)

    def _resolve_subcommand(self, ctx: Context, token: str) -> TypingTuple[Optional[str], Optional[Command]]:
        cmd = self.get_command(ctx, token)
        if cmd is not None:
            return token, cmd
        if ctx.token_normalize_func is None:
            return None, None
        wanted = ctx.normalize(token)
        for name in self.list_commands(ctx):
            if ctx.normalize(name) == wanted:
                found = self.get_command(ctx, name)
                if found is not None:
                    return name, found
        return None, None

    # ------------------------------------------------------------ parsing

    def _usage_subcommand_parts(self) -> List[str]:
        sm = self.subcommand_metavar or "COMMAND"
        if self.chain:
            return [f"{sm} [ARGS]...", f"[{sm} [ARGS]...]..."]
        if self.invoke_without_command:
            return [f"[{sm}]", "[ARGS]..."]
        return [sm, "[ARGS]..."]

    def parse_args(self, ctx: Context, args: List[str]) -> List[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self._parse_params(ctx)
        scanner = _Scanner(ctx, params)
        arg_params = self._argument_params()
        slots = sum(a.nargs for a in arg_params if a.nargs > 0)
        tokens = list(args)
        n = len(tokens)
        i = 0
        after_dd = False
        positionals: List[str] = []
        sub_idx: Optional[int] = None
        error: Optional[UsageError] = None
        try:
            while i < n:
                tok = tokens[i]
                if not after_dd and tok == "--":
                    after_dd = True
                    i += 1
                    continue
                if not after_dd and scanner.is_option_token(tok):
                    i = scanner.consume(tokens, i)
                    continue
                if len(positionals) < slots:
                    positionals.append(tok)
                    i += 1
                    continue
                sub_idx = i
                break
        except UsageError as exc:
            error = exc

        child_tokens: List[str] = []
        if sub_idx is not None and not error:
            if ctx.allow_interspersed_args:
                j = sub_idx + 1
                while j < n:
                    if scanner.is_option_token(tokens[j]) and scanner.knows(tokens[j]):
                        j = scanner.consume(tokens, j)
                    else:
                        child_tokens.append(tokens[j])
                        j += 1
            else:
                child_tokens = tokens[sub_idx + 1:]

        self._set_client_occurrences(ctx, scanner)
        done: set = set()
        self._run_eager(ctx, scanner.occs, done)
        if error is not None:
            raise error
        if scanner.error is not None:
            raise scanner.error

        # Group arguments take fixed-size chunks of the tokens before the subcommand name.
        pos = 0
        for arg in arg_params:
            if arg.nargs == -1:
                continue
            chunk = positionals[pos: pos + arg.nargs]
            pos += arg.nargs
            if 0 < len(chunk) < arg.nargs:
                raise BadArgumentUsage(f"Argument '{arg.name.upper()}' takes {arg.nargs} values.", ctx)
            if chunk:
                ctx._arg_tokens[arg] = chunk

        if sub_idx is None:
            ctx.args = []
            ctx.protected_args = []
            self._process_params(ctx, params, done)
            if not self.invoke_without_command:
                raise MissingCommand(ctx)
            return []

        sub_name = tokens[sub_idx]
        if self.chain:
            rest = tokens[sub_idx:]
            if self._resolve_subcommand(ctx, sub_name)[1] is None:
                raise NoSuchCommand(sub_name, ctx)
            ctx.args = rest
            ctx.protected_args = []
            self._process_params(ctx, params, done)
            return rest

        exported, cmd = self._resolve_subcommand(ctx, sub_name)
        if cmd is None:
            raise NoSuchCommand(sub_name, ctx)
        ctx._subcommand = cmd
        ctx._subcommand_name = exported
        ctx.protected_args = [exported]
        ctx.args = child_tokens
        self._process_params(ctx, params, done)
        return child_tokens

    # ------------------------------------------------------------ invocation

    def invoke(self, ctx: Context) -> Any:
        try:
            with ctx:
                if self.deprecated:
                    self._warn_deprecated(ctx)
                if self.chain:
                    return self._invoke_chain(ctx)
                cmd = ctx._subcommand
                if cmd is None:
                    ctx.invoked_subcommand = None
                    group_rv = self._call(ctx)
                    if self.result_callback_func is not None:
                        return self.result_callback_func(group_rv, **ctx.params)
                    return group_rv
                name = ctx._subcommand_name
                ctx.invoked_subcommand = name
                self._call(ctx)
                sub = cmd.make_context(name, ctx.args, parent=ctx)
                sub_rv = cmd.invoke(sub)
                if self.result_callback_func is not None:
                    return self.result_callback_func(sub_rv, **ctx.params)
                return sub_rv
        finally:
            ctx.close()

    def _invoke_chain(self, ctx: Context) -> Any:
        ctx.invoked_subcommand = CHAIN_MARKER
        self._call(ctx)
        results: List[Any] = []
        rest = list(ctx.args)
        while rest:
            token = rest[0]
            exported, cmd = self._resolve_subcommand(ctx, token)
            if cmd is None:
                raise NoSuchCommand(token, ctx)
            sub = cmd.make_context(exported, rest[1:], parent=ctx, leftover_ok=True)
            results.append(cmd.invoke(sub))
            rest = list(sub.args)
        if self.result_callback_func is not None:
            return self.result_callback_func(results, **ctx.params)
        return results

    # ------------------------------------------------------------ help

    def _command_rows(self, ctx: Context, width: int) -> List[TypingTuple[str, str]]:
        entries = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            entries.append((name, cmd.get_short_help()))
        if not entries:
            return []
        col = min(max(len(n) for n, _ in entries), 30)
        avail = max(20, width - 4 - col - 2)
        return [(name, ellipsize(short, avail)) for name, short in entries]


class CommandCollection(Group):
    """Presents the union of subcommands from several source groups under one dispatch surface."""

    def __init__(self, name: Optional[str] = None, sources: Optional[List[Group]] = None, **kwargs: Any) -> None:
        super().__init__(name=name, **kwargs)
        self.sources: List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> List[str]:
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> Optional[Command]:
        cmd = self.commands.get(cmd_name)
        if cmd is not None:
            return cmd
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
