"""Shell completion: registration scripts and suggestion streams (PRD FP-12; Contract section 8)."""

from __future__ import annotations

import os
import re
import sys
from typing import Any, List, Optional, Tuple as TypingTuple

from .context import Context
from .core import Command, Group
from .parameters import Argument, Option
from .paramtypes import Choice

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "__optlyn_path_file__"
PATH_DIR = "__optlyn_path_dir__"


def _fn_name(prog: str) -> str:
    return "_" + re.sub(r"\W", "_", os.path.basename(prog)) + "_completion"


def _var_name(prog: str) -> str:
    return "_" + os.path.basename(prog).upper().replace("-", "_") + "_COMPLETE"


def get_script(shell: str, prog: str) -> str:
    """Registration script for ``shell``; the user sources it to enable completion."""
    prog = os.path.basename(prog)
    fn = _fn_name(prog)
    var = _var_name(prog)
    if shell == "bash":
        return (
            f"{fn}() {{\n"
            f"    local words=\"${{COMP_WORDS[*]}}\"\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"$words\" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog} 2>/dev/null) )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F {fn} {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"{fn}() {{\n"
            f"    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog} 2>/dev/null)}}\")\n"
            f"    compadd -- $completions\n"
            f"}}\n"
            f"compdef {fn} {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete -c {prog} -f -a '(env COMP_WORDS=(string join \" \" -- (commandline -cp)) "
            f"COMP_CWORD=(commandline -ct) {var}=fish_complete {prog} 2>/dev/null)'\n"
        )
    if shell == "powershell":
        return (
            f"Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{\n"
            f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
            f"    $words = $commandAst.ToString()\n"
            f"    $env:COMP_WORDS = $words\n"
            f"    $env:COMP_CWORD = $words.Split(' ').Count - 1\n"
            f"    $env:{var} = 'powershell_complete'\n"
            f"    & '{prog}' 2>$null | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
            f"    Remove-Item Env:{var}\n"
            f"}}\n"
        )
    raise ValueError(f"Unsupported shell: {shell}")


def _words(shell: str) -> TypingTuple[List[str], str]:
    line = os.environ.get("COMP_WORDS", "")
    raw_index = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        words = line.split()
        args = words[1:]
        if args and raw_index and args[-1] == raw_index:
            args = args[:-1]
        return args, raw_index
    words = line.split(" ")
    try:
        cword = int(raw_index)
    except ValueError:
        cword = len(words) - 1
    args = words[1:cword]
    incomplete = words[cword] if 0 <= cword < len(words) else ""
    return args, incomplete


def _find_option(ctx: Context, cmd: Command, token: str) -> Optional[Option]:
    key = ctx.normalize(token.partition("=")[0])
    for param in cmd._parse_params(ctx):
        if isinstance(param, Option) and key in {ctx.normalize(f) for f in param.all_flags}:
            return param
    return None


def _item_fields(item: Any) -> TypingTuple[str, Optional[str], str]:
    if isinstance(item, str):
        return item, None, "plain"
    value = getattr(item, "value", str(item))
    return str(value), getattr(item, "help", None), getattr(item, "type", "plain") or "plain"


def _param_suggestions(ctx: Context, param: Any, incomplete: str) -> List[TypingTuple[str, Optional[str]]]:
    if param.shell_complete_func is not None or not param.type.is_path_like():
        out = []
        for item in param.shell_complete(ctx, incomplete):
            value, help_text, kind = _item_fields(item)
            if kind == "plain":
                out.append((value, help_text))
        return out
    return [(_path_marker(param.type, incomplete), None)]


def _path_marker(ptype: Any, incomplete: str) -> str:
    dirs_only = bool(getattr(ptype, "dir_okay", True)) and not bool(getattr(ptype, "file_okay", True))
    return f"{PATH_DIR if dirs_only else PATH_FILE} {incomplete}"


def _suggest(cli: Command, prog: str, args: List[str], incomplete: str) -> List[TypingTuple[str, Optional[str]]]:
    ctx = Context(cli, info_name=prog)
    cmd: Command = cli
    cur = ctx
    pending: Optional[Option] = None
    after_dd = False
    positional_count = 0
    for tok in args:
        if pending is not None:
            pending = None
            continue
        if tok == "--":
            after_dd = True
            continue
        if not after_dd and len(tok) > 1 and tok[0] == "-":
            param = _find_option(cur, cmd, tok)
            if param is not None and param.takes_value and "=" not in tok and not (len(tok) > 2 and tok[1] != "-"):
                pending = param
            continue
        if isinstance(cmd, Group) and positional_count == 0 and not cmd.chain:
            exported, child = cmd._resolve_subcommand(cur, tok)
            if child is not None:
                cur = Context(child, parent=cur, info_name=exported)
                cmd = child
                positional_count = 0
                continue
        positional_count += 1

    if pending is not None:
        return _param_suggestions(cur, pending, incomplete)

    results: List[TypingTuple[str, Optional[str]]] = []
    if incomplete.startswith("-"):
        for param in cmd._parse_params(cur):
            if isinstance(param, Option) and not param.hidden:
                for flag in param.all_flags:
                    if flag.startswith(incomplete):
                        results.append((flag, param.help))
        return results

    if isinstance(cmd, Group) and positional_count == 0:
        for name in cmd.list_commands(cur):
            sub = cmd.get_command(cur, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            results.append((name, sub.get_short_help() or None))

    arguments = [p for p in cmd.params if isinstance(p, Argument)]
    if positional_count < len(arguments):
        arg = arguments[positional_count]
        if arg.shell_complete_func is not None or isinstance(arg.type, Choice) or not arg.type.is_path_like():
            for value, help_text in _param_suggestions(cur, arg, incomplete):
                results.append((value, help_text))
        else:
            results.append((_path_marker(arg.type, incomplete), None))
    return results


def _render(shell: str, items: List[TypingTuple[str, Optional[str]]]) -> str:
    lines = []
    for value, help_text in items:
        if value.startswith(PATH_FILE) or value.startswith(PATH_DIR):
            lines.append(value)
        elif shell in ("zsh", "fish") and help_text:
            lines.append(f"{value}\t{help_text}")
        else:
            lines.append(value)
    return "\n".join(lines) + ("\n" if lines else "")


def run_completion(cli: Command, prog: str, instruction: str) -> int:
    """Handle a completion instruction; returns the process exit status."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        sys.stderr.write(f"Unknown completion instruction: {instruction!r}\n")
        return 1
    if action == "source":
        sys.stdout.write(get_script(shell, prog))
        sys.stdout.flush()
        return 0
    args, incomplete = _words(shell)
    items = _suggest(cli, prog, args, incomplete)
    sys.stdout.write(_render(shell, items))
    sys.stdout.flush()
    return 0
