"""The per-invocation context (PRD FP-07; Contract section 6)."""

from __future__ import annotations

import shutil
import threading
from typing import Any, Callable, Dict, List, Optional

from .exceptions import Abort, Exit
from .utils import MISSING, ParameterSource

_local = threading.local()

DEFAULT_MAX_CONTENT_WIDTH = 80


def _stack() -> List["Context"]:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent: bool = False) -> Optional["Context"]:
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true, in which
    case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """State for one invocation of one command, linked to its parent context."""

    def __init__(
        self,
        command: Any,
        parent: Optional["Context"] = None,
        info_name: Optional[str] = None,
        obj: Any = None,
        default_map: Optional[Dict[str, Any]] = None,
        terminal_width: Optional[int] = None,
        max_content_width: Optional[int] = None,
        help_option_names: Optional[List[str]] = None,
        token_normalize_func: Optional[Callable[[str], str]] = None,
        color: Optional[bool] = None,
        show_default: Optional[bool] = None,
        allow_extra_args: Optional[bool] = None,
        allow_interspersed_args: Optional[bool] = None,
        ignore_unknown_options: Optional[bool] = None,
        auto_envvar_prefix: Optional[str] = None,
        resilient_parsing: bool = False,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        p = parent
        self.obj = obj if obj is not None else (p.obj if p is not None else None)
        self.default_map = default_map if isinstance(default_map, dict) else None
        self.terminal_width = terminal_width if terminal_width is not None else (p.terminal_width if p else None)
        self.max_content_width = (
            max_content_width if max_content_width is not None else (p.max_content_width if p else None)
        )
        if help_option_names is not None:
            self.help_option_names = list(help_option_names)
        elif p is not None:
            self.help_option_names = list(p.help_option_names)
        else:
            self.help_option_names = ["--help"]
        self.token_normalize_func = (
            token_normalize_func if token_normalize_func is not None else (p.token_normalize_func if p else None)
        )
        self.color = color if color is not None else (p.color if p else None)
        self.show_default = show_default if show_default is not None else (p.show_default if p else None)
        self.auto_envvar_prefix = (
            auto_envvar_prefix if auto_envvar_prefix is not None else (p.auto_envvar_prefix if p else None)
        )
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else bool(getattr(command, "allow_extra_args", False))
        )
        self.allow_interspersed_args = (
            allow_interspersed_args
            if allow_interspersed_args is not None
            else bool(getattr(command, "allow_interspersed_args", True))
        )
        self.ignore_unknown_options = (
            ignore_unknown_options
            if ignore_unknown_options is not None
            else bool(getattr(command, "ignore_unknown_options", False))
        )
        self.resilient_parsing = resilient_parsing

        # Per-invocation state filled in during parsing and processing.
        self.params: Dict[str, Any] = {}
        self.args: List[str] = []
        self.protected_args: List[str] = []
        self.invoked_subcommand: Any = None
        self._cl: Dict[Any, list] = {}
        self._arg_tokens: Dict[Any, list] = {}
        self._sources: Dict[str, ParameterSource] = {}
        self._subcommand: Any = None
        self._leftover_ok = False
        self._close_callbacks: List[Callable[[], Any]] = []

    # ------------------------------------------------------------ tree helpers

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    @property
    def command_path(self) -> str:
        names = []
        node: Optional[Context] = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def path_names_below_root(self) -> List[str]:
        names = []
        node: Optional[Context] = self
        while node is not None and node.parent is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return list(reversed(names))

    def find_object(self, object_type: type) -> Any:
        node: Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> Any:
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # ------------------------------------------------------------ settings

    def normalize(self, token: str) -> str:
        if self.token_normalize_func is not None:
            return self.token_normalize_func(token)
        return token

    def lookup_default(self, name: str) -> Any:
        if self.default_map is not None and name in self.default_map:
            return self.default_map[name]
        return MISSING

    def get_terminal_width(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        cap = self.max_content_width if self.max_content_width is not None else DEFAULT_MAX_CONTENT_WIDTH
        try:
            cols = shutil.get_terminal_size().columns
        except OSError:
            cols = 80
        return min(cols, cap)

    def get_help_hint(self) -> Optional[str]:
        if not self.help_option_names:
            return None
        return f"Try '{self.command_path} {self.help_option_names[0]}' for help."

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_parameter_source(self, name: str) -> Optional[ParameterSource]:
        if not any(getattr(p, "name", None) == name for p in self.command.params):
            return None
        return self._sources.get(name)

    # ------------------------------------------------------------ control

    def exit(self, code: int = 0) -> None:
        raise Exit(code)

    def abort(self) -> None:
        raise Abort()

    def call_on_close(self, func: Callable[[], Any]) -> None:
        self._close_callbacks.append(func)

    def with_resource(self, cm: Any) -> Any:
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def close(self) -> None:
        """Run registered cleanups in reverse order. Safe to call more than once."""
        callbacks, self._close_callbacks = self._close_callbacks, []
        errors = []
        for func in reversed(callbacks):
            try:
                func()
            except Exception as exc:  # keep closing the rest
                errors.append(exc)
        if errors:
            raise errors[0]

    def invoke(self, callback: Any, *args: Any, **kwargs: Any) -> Any:
        """Run another command (or callable) from inside this command's callback."""
        from .core import Command  # local import avoids a cycle

        if isinstance(callback, Command):
            ctx = Context(callback, parent=self, info_name=callback.name)
            values = dict(kwargs)
            for param in callback.params:
                if param.expose_value and param.name not in values:
                    values[param.name] = param.default_for_invoke(ctx)
            ctx.params = values
            return callback.invoke(ctx)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd: Any, **kwargs: Any) -> Any:
        """Run ``cmd`` with this context's parameter values, overridden by ``kwargs``."""
        from .core import Command

        values = dict(self.params)
        values.update(kwargs)
        if isinstance(cmd, Command):
            wanted = {p.name for p in cmd.params if p.expose_value}
            values = {k: v for k, v in values.items() if k in wanted}
        return self.invoke(cmd, **values)

    # ------------------------------------------------------------ context manager

    def __enter__(self) -> "Context":
        _stack().append(self)
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)
