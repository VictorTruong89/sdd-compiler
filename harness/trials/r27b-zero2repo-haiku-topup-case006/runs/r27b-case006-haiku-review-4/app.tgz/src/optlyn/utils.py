"""Shared sentinels and small helpers used across the package."""

from __future__ import annotations

import enum
import re


class _Missing:
    """Sentinel for 'no value was produced by any source'."""

    _instance = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "MISSING"

    def __bool__(self) -> bool:
        return False


MISSING = _Missing()


class ParameterSource(enum.Enum):
    """Where the value of a parameter came from (see ``Context.get_parameter_source``)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def strip_ansi(text: str) -> str:
    """Remove ANSI CSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def first_sentence(text: str) -> str:
    """Return the first sentence of ``text`` (single line, whitespace-normalised)."""
    flat = " ".join(text.split())
    match = re.match(r"(.*?[.!?])(?:\s|$)", flat)
    return match.group(1) if match else flat


def flatten_paragraph(text: str) -> str:
    return " ".join(text.split())
