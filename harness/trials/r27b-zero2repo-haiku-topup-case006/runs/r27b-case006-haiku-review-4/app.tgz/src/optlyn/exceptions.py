"""Exception classes and their standalone exit statuses.

Exit statuses (standalone mode): 0 success/help/version, 2 usage error,
1 abort or other library-signalled error.
"""

from __future__ import annotations

import sys
from typing import Any, Optional


def _stream(file: Any = None) -> Any:
    return file if file is not None else sys.stderr


class OptlynError(Exception):
    """Base class for errors that standalone mode reports and turns into an exit."""

    exit_code: int = 1

    def __init__(self, message: str = "") -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file: Any = None) -> None:
        out = _stream(file)
        out.write(f"Error: {self.format_message()}\n")
        out.flush()


class Exit(Exception):
    """A clean stop requested by the library or the author, with an exit status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class Abort(OptlynError):
    """The user declined, or input ended, or an author aborted the run (exit 1)."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!") -> None:
        super().__init__(message)

    def show(self, file: Any = None) -> None:
        out = _stream(file)
        out.write(f"{self.format_message()}\n")
        out.flush()


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    exit_code = 1

    def __init__(self, filename: str, reason: str) -> None:
        super().__init__(f"Could not open file '{filename}': {reason}")
        self.filename = filename


class UsageError(OptlynError):
    """Incorrect use of the command line (exit 2)."""

    exit_code = 2

    def __init__(self, message: str = "", ctx: Any = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file: Any = None) -> None:
        out = _stream(file)
        ctx = self.ctx
        if ctx is not None:
            out.write(ctx.get_usage() + "\n")
            hint = ctx.get_help_hint()
            if hint:
                out.write(hint + "\n")
            out.write("\n")
        out.write(f"Error: {self.format_message()}\n")
        out.flush()


class BadParameter(UsageError):
    """A value was refused (conversion failure, range, callback refusal)."""

    def __init__(
        self,
        message: str = "",
        ctx: Any = None,
        param: Any = None,
        param_hint: Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> Optional[str]:
        if self.param_hint is not None:
            hint = self.param_hint
            if isinstance(hint, (list, tuple)):
                hint = " / ".join(f"'{h}'" for h in hint)
            return hint
        if self.param is not None:
            return self.param.get_error_hint()
        return None

    def format_message(self) -> str:
        hint = self._hint()
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self) -> str:
        hint = self._hint()
        kind = getattr(self.param, "param_type_name", "parameter")
        if hint is None:
            return self.message
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    def __init__(self, option_name: str, ctx: Any = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, missing its value)."""


class BadArgumentUsage(UsageError):
    """Positional arguments were used incorrectly."""


class NoSuchCommand(UsageError):
    def __init__(self, name: str, ctx: Any = None) -> None:
        super().__init__(f"No such command '{name}'.", ctx)
        self.command_name = name


class MissingCommand(UsageError):
    def __init__(self, ctx: Any = None) -> None:
        super().__init__("Missing command.", ctx)


class NoArgsIsHelp(UsageError):
    """Shown when a command with no-args-is-help receives no arguments.

    The help page goes to standard error and the exit status is the usage class.
    """

    def __init__(self, ctx: Any) -> None:
        super().__init__("", ctx)

    def show(self, file: Any = None) -> None:
        out = _stream(file)
        out.write(self.ctx.get_help() + "\n")
        out.flush()
