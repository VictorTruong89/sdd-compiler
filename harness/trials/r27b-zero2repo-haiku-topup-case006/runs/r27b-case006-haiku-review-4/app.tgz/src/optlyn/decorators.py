"""Declaration decorators: command, group, option, argument, and ready-made options (Contract sections 3-4)."""

from __future__ import annotations

import functools
from importlib import metadata as _metadata
from typing import Any, Callable, Optional

from . import termui
from .context import Context, get_current_context
from .core import Command, Group, _help_callback, derive_command_name
from .exceptions import Exit
from .parameters import Argument, Option


def _attach_param(func: Callable[..., Any], param: Any) -> None:
    params = getattr(func, "__optlyn_params__", None)
    if params is None:
        params = []
        func.__optlyn_params__ = params  # type: ignore[attr-defined]
    params.append(param)


def _pop_params(func: Callable[..., Any]) -> list:
    """Declarations come off the function in declaration order and are removed from it."""
    params = list(reversed(getattr(func, "__optlyn_params__", [])))
    if hasattr(func, "__optlyn_params__"):
        del func.__optlyn_params__  # type: ignore[attr-defined]
    return params


def command(name: Any = None, cls: Optional[type] = None, **attrs: Any) -> Any:
    """Turn a function into a :class:`Command` (``@command()`` or ``@command``)."""
    if callable(name) and not isinstance(name, str) and cls is None and not attrs:
        return command()(name)

    def decorator(func: Callable[..., Any]) -> Command:
        params = _pop_params(func)
        cmd_name = name if name is not None else derive_command_name(func.__name__)
        factory = cls or Command
        return factory(name=cmd_name, callback=func, params=params, **attrs)

    return decorator


def group(name: Any = None, cls: Optional[type] = None, **attrs: Any) -> Any:
    """Turn a function into a :class:`Group` (``@group()`` or ``@group``)."""
    if callable(name) and not isinstance(name, str) and cls is None and not attrs:
        return group()(name)

    def decorator(func: Callable[..., Any]) -> Group:
        params = _pop_params(func)
        grp_name = name if name is not None else derive_command_name(func.__name__)
        factory = cls or Group
        return factory(name=grp_name, callback=func, params=params, **attrs)

    return decorator


def option(*param_decls: str, cls: Optional[type] = None, **attrs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Attach an option to a function that will become a command or group."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        factory = cls or Option
        _attach_param(func, factory(list(param_decls), **attrs))
        return func

    return decorator


def argument(*param_decls: str, cls: Optional[type] = None, **attrs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Attach a positional argument to a function that will become a command or group."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        factory = cls or Argument
        _attach_param(func, factory(list(param_decls), **attrs))
        return func

    return decorator


# ------------------------------------------------------------------ ready-made options


def help_option(*param_decls: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """An extra eager help flag; it prints help and exits."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        _attach_param(func, Option(decls, **kwargs))
        return func

    return decorator


def _detect_version(package_name: str) -> str:
    try:
        return _metadata.version(package_name)
    except _metadata.PackageNotFoundError:
        pass
    mapping = _metadata.packages_distributions().get(package_name, [])
    for dist in mapping:
        try:
            return _metadata.version(dist)
        except _metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not determine the version of '{package_name}'.")


def version_option(
    version: Optional[str] = None,
    *param_decls: str,
    package_name: Optional[str] = None,
    prog_name: Optional[str] = None,
    message: Optional[str] = None,
    **kwargs: Any,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """An eager ``--version`` flag printing a version identity and exiting."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx: Context, param: Any, value: Any) -> Any:
        if not value or ctx.resilient_parsing:
            return value
        ver = version
        if ver is None:
            pkg = package_name
            if pkg is None:
                module = getattr(ctx.command.callback, "__module__", "") or ""
                pkg = module.split(".")[0] or "unknown"
            try:
                ver = _detect_version(pkg)
            except RuntimeError:
                ver = "unknown"
        prog = prog_name or ctx.find_root().info_name or "root"
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        termui.echo(text)
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        _attach_param(func, Option(decls, **kwargs))
        return func

    return decorator


def custom_version_option(
    callback_fn: Callable[[Context], str],
    *param_decls: str,
    **kwargs: Any,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """An eager version flag whose whole identity is the string ``callback_fn(ctx)`` returns."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx: Context, param: Any, value: Any) -> Any:
        if not value or ctx.resilient_parsing:
            return value
        termui.echo(callback_fn(ctx))
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        _attach_param(func, Option(decls, **kwargs))
        return func

    return decorator


def password_option(*param_decls: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """A prompting option with hidden input and a confirmation prompt."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("prompt_required", True)

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        _attach_param(func, Option(decls, **kwargs))
        return func

    return decorator


def confirmation_option(*param_decls: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """A yes-style flag: when omitted, asks; when declined, aborts. Not passed to the callback."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx: Context, param: Any, value: Any) -> Any:
        if value:
            return value
        termui.confirm(question, default=False, abort=True)
        return True

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        _attach_param(func, Option(decls, **kwargs))
        return func

    return decorator


# ------------------------------------------------------------------ callback decorators


def pass_context(func: Callable[..., Any]) -> Callable[..., Any]:
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(func)
    def new_func(*args: Any, **kwargs: Any) -> Any:
        return func(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(func: Callable[..., Any]) -> Callable[..., Any]:
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(func)
    def new_func(*args: Any, **kwargs: Any) -> Any:
        return func(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type: type, ensure: bool = False) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Build a decorator that passes the nearest ``object_type`` object from the context chain."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        def new_func(*args: Any, **kwargs: Any) -> Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return func(obj, *args, **kwargs)

        return new_func

    return decorator
