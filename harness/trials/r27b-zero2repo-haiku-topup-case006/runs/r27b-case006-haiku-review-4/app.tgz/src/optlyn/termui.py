"""Terminal helpers: echo, styling, prompts, pager, progress bar, editor, launch (PRD FP-08, FP-11)."""

from __future__ import annotations

import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable, Iterable, Iterator, Optional

from .context import get_current_context
from .exceptions import Abort, BadParameter, FileError
from .paramtypes import File, convert_type
from .utils import strip_ansi

try:  # POSIX-only; absent on Windows
    import termios as _termios
except ImportError:  # pragma: no cover - Windows
    _termios = None


# --------------------------------------------------------------------- streams


def _is_tty(stream: Any) -> bool:
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def is_interactive() -> bool:
    """A session is interactive when stdin or stdout is a terminal."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _write(stream: Any, text: str) -> None:
    try:
        stream.write(text)
    except UnicodeEncodeError:
        stream.flush()
        buf = getattr(stream, "buffer", None)
        data = text.encode("utf-8", "backslashreplace")
        if buf is not None:
            buf.write(data)
        else:
            stream.write(data.decode("utf-8"))
    stream.flush()


# --------------------------------------------------------------------- echo / styling

_COLOR_BASE = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_SWITCHES = [
    ("bold", 1), ("dim", 2), ("italic", 3), ("underline", 4), ("blink", 5),
    ("reverse", 7), ("strikethrough", 9), ("overline", 53),
]


def _color_codes(color: Any, background: bool) -> str:
    lead = "48" if background else "38"
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        if color not in _COLOR_BASE:
            raise ValueError(f"Unknown color {color!r}.")
        base = _COLOR_BASE[color] + (10 if background else 0)
        return str(base)
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color index {color} is out of range 0-255.")
        return f"{lead};5;{color}"
    if isinstance(color, (list, tuple)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{lead};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text: Any,
    fg: Any = None,
    bg: Any = None,
    bold: Optional[bool] = None,
    dim: Optional[bool] = None,
    underline: Optional[bool] = None,
    overline: Optional[bool] = None,
    italic: Optional[bool] = None,
    blink: Optional[bool] = None,
    reverse: Optional[bool] = None,
    strikethrough: Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ValueError/TypeError."""
    bits = []
    if fg is not None:
        bits.append(_color_codes(fg, False))
    if bg is not None:
        bits.append(_color_codes(bg, True))
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, code in _SWITCHES:
        if flags.get(name):
            bits.append(str(code))
    text = str(text)
    if not bits:
        return text
    out = "\x1b[" + ";".join(bits) + "m" + text
    if reset:
        out += "\x1b[0m"
    return out


def unstyle(text: str) -> str:
    return strip_ansi(text)


def echo(
    message: Any = None,
    file: Any = None,
    nl: bool = True,
    err: bool = False,
    color: Optional[bool] = None,
) -> None:
    """Write text (or bytes) to stdout, stderr, or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        file.flush()
        buf = getattr(file, "buffer", None)
        if buf is not None:
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
            file.flush()
        return
    text = str(message)
    if color is None:
        keep = _is_tty(file)
    else:
        keep = bool(color)
    if not keep:
        text = strip_ansi(text)
    if nl:
        text += "\n"
    _write(file, text)


def secho(
    message: Any = None,
    file: Any = None,
    nl: bool = True,
    err: bool = False,
    color: Optional[bool] = None,
    **styles: Any,
) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# --------------------------------------------------------------------- input


def _read_hidden_line(stream: Any) -> str:
    fd = stream.fileno()
    if _termios is None:
        return stream.readline()
    try:
        old = _termios.tcgetattr(fd)
    except _termios.error:
        return stream.readline()
    new = list(old)
    new[3] &= ~_termios.ECHO
    _termios.tcsetattr(fd, _termios.TCSADRAIN, new)
    try:
        return stream.readline()
    finally:
        _termios.tcsetattr(fd, _termios.TCSADRAIN, old)


def _read_line(text: str, hide: bool = False, err: bool = False) -> str:
    out = sys.stderr if err else sys.stdout
    if not _is_tty(out):
        text = strip_ansi(text)
    out.write(text)
    out.flush()
    stdin = sys.stdin
    if hide and _is_tty(stdin):
        line = _read_hidden_line(stdin)
    else:
        line = stdin.readline()
    if isinstance(line, bytes):
        line = line.decode("utf-8", "replace")
    if not line:
        raise Abort()
    line = line.rstrip("\r\n")
    if hide:
        out.write("\n")
    elif getattr(stdin, "_optlyn_echo", False):
        # Captured sessions record the typed line, as a terminal would show it.
        out.write(line + "\n")
    out.flush()
    return line


def _fmt_default(default: Any) -> str:
    return str(default)


def prompt(
    text: str,
    default: Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: Any = None,
    value_proc: Optional[Callable[[str], Any]] = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> Any:
    """Ask for a value. Re-asks on conversion failure; EOF raises Abort."""
    if value_proc is None:
        ptype = convert_type(type, default)
        value_proc = ptype.convert
    shown = ""
    if default is not None and show_default and not hide_input:
        shown = f" [{_fmt_default(default)}]"
    prompt_text = f"{text}{shown}{prompt_suffix}"
    while True:
        raw = _read_line(prompt_text, hide_input, err)
        if raw == "":
            if default is not None:
                return default
            continue
        try:
            value = value_proc(raw)
        except BadParameter as exc:
            echo(f"Error: {exc.format_message()}", err=True)
            continue
        if confirmation_prompt:
            second = _read_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if second != raw:
                echo("Error: the two entered values do not match", err=True)
                continue
        return value


def confirm(
    text: str,
    default: Optional[bool] = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    if default is True:
        choices = "[Y/n]"
    elif default is False:
        choices = "[y/N]"
    else:
        choices = "[y/n]"
    prompt_text = f"{text} {choices}{prompt_suffix}"
    while True:
        answer = _read_line(prompt_text, False, err).strip().lower()
        if answer == "" and default is not None:
            result = bool(default)
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal (not from a piped stdin if a TTY exists)."""
    opened = None
    fd = None
    if _termios is not None:
        try:
            opened = os.open("/dev/tty", os.O_RDONLY)
            fd = opened
        except OSError:
            fd = None
    try:
        if fd is not None:
            old = _termios.tcgetattr(fd)
            new = list(old)
            new[3] &= ~_termios.ICANON
            if not echo:
                new[3] &= ~_termios.ECHO
            new[6][_termios.VMIN] = 1
            new[6][_termios.VTIME] = 0
            _termios.tcsetattr(fd, _termios.TCSADRAIN, new)
            try:
                data = os.read(fd, 1)
            finally:
                _termios.tcsetattr(fd, _termios.TCSADRAIN, old)
            if not data:
                raise EOFError()
            char = data.decode("utf-8", "replace")
        else:
            char = sys.stdin.read(1)
            if not char:
                raise EOFError()
    finally:
        if opened is not None:
            os.close(opened)
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info: Optional[str] = None, err: bool = False) -> None:
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err)
    if not is_interactive():
        return
    try:
        getchar(True)
    except (EOFError, KeyboardInterrupt):
        pass


# --------------------------------------------------------------------- pager


class _PagerStream:
    def __init__(self, proc: Any, keep_styles: bool) -> None:
        self._proc = proc
        self._keep = keep_styles

    def write(self, text: Any) -> int:
        if isinstance(text, bytes):
            data = text
        else:
            if not self._keep:
                text = strip_ansi(text)
            data = text.encode("utf-8", "replace")
        self._proc.stdin.write(data)
        self._proc.stdin.flush()
        return len(data)

    def flush(self) -> None:
        self._proc.stdin.flush()


def _pager_command() -> Optional[str]:
    cmd = os.environ.get("PAGER", "").strip()
    return cmd or None


def _keep_styles(color: Optional[bool], stream: Any) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            return bool(ctx.color)
        return _is_tty(stream)
    return bool(color)


def echo_via_pager(text_or_generator: Any, color: Optional[bool] = None) -> None:
    if isinstance(text_or_generator, str):
        chunks: Iterable[str] = [text_or_generator]
    elif callable(text_or_generator):
        chunks = text_or_generator()
        if isinstance(chunks, str):
            chunks = [chunks]
    else:
        chunks = text_or_generator
    cmd = _pager_command()
    if is_interactive() and cmd:
        keep = _keep_styles(color, sys.stdout)
        proc = subprocess.Popen(shlex.split(cmd), stdin=subprocess.PIPE)
        stream = _PagerStream(proc, keep)
        try:
            for chunk in chunks:
                stream.write(chunk)
        except BrokenPipeError:
            pass
        finally:
            try:
                proc.stdin.close()
            except BrokenPipeError:
                pass
            proc.wait()
        return
    for chunk in chunks:
        echo(chunk, nl=False, color=color)


@contextlib.contextmanager
def get_pager_file(color: Optional[bool] = None) -> Iterator[Any]:
    cmd = _pager_command()
    if is_interactive() and cmd:
        keep = _keep_styles(color, sys.stdout)
        proc = subprocess.Popen(shlex.split(cmd), stdin=subprocess.PIPE)
        stream = _PagerStream(proc, keep)
        try:
            yield stream
        finally:
            try:
                proc.stdin.close()
            except BrokenPipeError:
                pass
            proc.wait()
        return
    from .paramtypes import _NonClosing

    yield _NonClosing(sys.stdout)


# --------------------------------------------------------------------- progress bar


def _fmt_time(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours:d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


class ProgressBar:
    """A progress bar. Iterating it visits every item, with or without a terminal."""

    def __init__(
        self,
        iterable: Any = None,
        length: Optional[int] = None,
        label: Optional[str] = None,
        hidden: bool = False,
        width: int = 36,
        **options: Any,
    ) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self._start = time.time()
        self._tty = (not hidden) and _is_tty(sys.stdout)
        if not hidden and not self._tty and label is not None:
            echo(label)

    def __enter__(self) -> "ProgressBar":
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._tty:
            sys.stdout.write("\n")
            sys.stdout.flush()

    def __iter__(self) -> Iterator[Any]:
        if self.iterable is None:
            raise TypeError("Progress bar has no iterable to iterate.")
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int, current_item: Any = None) -> None:
        self.pos += n_steps
        if self._tty:
            self._render()

    def _render(self) -> None:
        elapsed = time.time() - self._start
        parts = []
        if self.label:
            parts.append(self.label)
        if self.length:
            frac = min(1.0, self.pos / self.length)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            parts.append(f"[{bar}]")
            parts.append(f"{self.pos}/{self.length}")
            if self.pos > 0:
                remaining = elapsed / self.pos * max(0, self.length - self.pos)
                parts.append(f"eta {_fmt_time(remaining)}")
        else:
            parts.append(str(self.pos))
        sys.stdout.write("\r" + " ".join(parts))
        sys.stdout.flush()


def progressbar(
    iterable: Any = None,
    length: Optional[int] = None,
    label: Optional[str] = None,
    hidden: bool = False,
    **options: Any,
) -> ProgressBar:
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# --------------------------------------------------------------------- editor / launch / misc


def edit(
    text: Optional[str] = None,
    editor: Optional[str] = None,
    env: Optional[dict] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: Any = None,
) -> Optional[str]:
    editor_cmd = (
        editor
        or os.environ.get("VISUAL")
        or os.environ.get("EDITOR")
        or ("notepad" if os.name == "nt" else "vi")
    )
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        path = os.fspath(filename)
        subprocess.call(shlex.split(editor_cmd) + [path], env=run_env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    original = text or ""
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(original)
    try:
        subprocess.call(shlex.split(editor_cmd) + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    if sys.platform.startswith("win"):
        try:
            os.startfile(url)  # type: ignore[attr-defined]
            return 0
        except OSError:
            return 1
    if sys.platform == "darwin":
        cmd = ["open"]
        if wait:
            cmd.append("-W")
        if locate:
            cmd.append("-R")
        cmd.append(url)
    else:
        cmd = [shutil.which("xdg-open") or "xdg-open", url]
    try:
        proc = subprocess.Popen(cmd)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    if not _is_tty(sys.stdout):
        return
    if os.name == "nt":
        os.system("cls")
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") if roaming else os.environ.get("LOCALAPPDATA")
        if not base:
            base = os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = xdg if xdg else os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename: Any, shorten: bool = False) -> str:
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    out = []
    for ch in text:
        code = ord(ch)
        if 0xD800 <= code <= 0xDFFF:
            # Undecodable bytes (surrogate escapes) become visible, distinct escapes.
            out.append(f"\\x{code - 0xDC00:02x}" if 0xDC80 <= code <= 0xDCFF else f"\\u{code:04x}")
        else:
            out.append(ch)
    return "".join(out)


def open_file(
    filename: Any,
    mode: str = "r",
    encoding: Optional[str] = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> Any:
    try:
        return File(mode, encoding, errors, lazy, atomic).convert(filename)
    except BadParameter as exc:
        raise FileError(str(filename), exc.message) from exc
