"""In-process runner: invoke a command with tokens and capture output (PRD FP-14; Contract section 9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
from typing import Any, Dict, Iterator, List, Optional, Union


class _Recorder:
    """Keeps every write in order, tagged with the stream it came from."""

    def __init__(self) -> None:
        self.chunks: List[TypingChunk] = []

    def add(self, name: str, data: bytes) -> None:
        self.chunks.append((name, data))

    def bytes_for(self, name: Optional[str] = None) -> bytes:
        return b"".join(d for n, d in self.chunks if name is None or n == name)


TypingChunk = tuple


class _BufferProxy:
    def __init__(self, rec: _Recorder, name: str) -> None:
        self._rec = rec
        self._name = name

    def write(self, data: Any) -> int:
        data = bytes(data)
        self._rec.add(self._name, data)
        return len(data)

    def flush(self) -> None:
        pass

    def writable(self) -> bool:
        return True


class _StreamProxy:
    """Stands in for sys.stdout / sys.stderr during an invocation."""

    def __init__(self, rec: _Recorder, name: str, charset: str) -> None:
        self._rec = rec
        self._name = name
        self.encoding = charset
        self.errors = "strict"
        self.buffer = _BufferProxy(rec, name)

    def write(self, text: Any) -> int:
        if isinstance(text, bytes):
            data = text
        else:
            data = text.encode(self.encoding)
        self._rec.add(self._name, data)
        return len(text)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False

    def writable(self) -> bool:
        return True

    def readable(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class _InputStream:
    """Stands in for sys.stdin. Reads consume the supplied input."""

    def __init__(self, data: bytes, charset: str, echo_to: Optional[_StreamProxy]) -> None:
        self._buf = io.BytesIO(data)
        self._charset = charset
        self._echo_to = echo_to
        # Prompts echo their typed line themselves when this flag is set.
        self._optlyn_echo = echo_to is None

        class _Buffer:
            def __init__(inner, owner: "_InputStream") -> None:
                inner._owner = owner

            def read(inner, size: int = -1) -> bytes:
                return inner._owner._buf.read(size)

            def readline(inner) -> bytes:
                line = inner._owner._buf.readline()
                inner._owner._echo(line)
                return line

        self.buffer = _Buffer(self)

    def _echo(self, raw: bytes) -> None:
        if self._echo_to is not None and raw:
            self._echo_to.buffer.write(raw)

    def readline(self, size: int = -1) -> str:
        raw = self._buf.readline(size)
        self._echo(raw)
        return raw.decode(self._charset, "replace")

    def read(self, size: int = -1) -> str:
        raw = self._buf.read(size)
        self._echo(raw)
        return raw.decode(self._charset, "replace")

    def __iter__(self) -> Iterator[str]:
        while True:
            line = self.readline()
            if not line:
                return
            yield line

    def isatty(self) -> bool:
        return False

    def readable(self) -> bool:
        return True

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class _SysCapture:
    """Captures writes through the interpreter's own stream objects (default)."""

    def __init__(self, charset: str) -> None:
        self._charset = charset
        self._rec = _Recorder()

    def __enter__(self) -> Any:
        self._out = _StreamProxy(self._rec, "stdout", self._charset)
        self._err = _StreamProxy(self._rec, "stderr", self._charset)
        return self._out, self._err

    def __exit__(self, *exc: Any) -> None:
        return None

    def finish(self) -> None:
        pass

    def combined(self) -> bytes:
        return self._rec.bytes_for()

    def stdout_bytes(self) -> bytes:
        return self._rec.bytes_for("stdout")

    def stderr_bytes(self) -> bytes:
        return self._rec.bytes_for("stderr")


class _FdCapture:
    """Captures OS-level writes to descriptors 1 and 2 as well as interpreter writes."""

    def __init__(self, charset: str) -> None:
        self._charset = charset

    def __enter__(self) -> Any:
        sys.stdout.flush()
        sys.stderr.flush()
        self._out_file = tempfile.TemporaryFile()
        self._err_file = tempfile.TemporaryFile()
        self._saved = (os.dup(1), os.dup(2))
        os.dup2(self._out_file.fileno(), 1)
        os.dup2(self._err_file.fileno(), 2)
        out = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self._charset,
                               errors="strict", write_through=True)
        err = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self._charset,
                               errors="backslashreplace", write_through=True)
        self._out, self._err = out, err
        return out, err

    def __exit__(self, *exc: Any) -> None:
        return None

    def finish(self) -> None:
        for stream in (self._out, self._err):
            try:
                stream.flush()
            except (OSError, ValueError):
                pass
        os.dup2(self._saved[0], 1)
        os.dup2(self._saved[1], 2)
        os.close(self._saved[0])
        os.close(self._saved[1])
        self._stdout = self._read(self._out_file)
        self._stderr = self._read(self._err_file)
        self._out_file.close()
        self._err_file.close()

    @staticmethod
    def _read(handle: Any) -> bytes:
        handle.flush()
        handle.seek(0)
        return handle.read()

    def combined(self) -> bytes:
        # Relative order across the two descriptors is not recoverable from separate files.
        return self._stdout + self._stderr

    def stdout_bytes(self) -> bytes:
        return self._stdout

    def stderr_bytes(self) -> bytes:
        return self._stderr


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(
        self,
        output_bytes: bytes,
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        exit_code: int,
        exception: Optional[BaseException],
        charset: str,
    ) -> None:
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self._charset = charset

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self._charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command in-process with argument tokens, input and environment."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: Optional[Dict[str, Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input: Any = None, env: Optional[Dict[str, Optional[str]]] = None):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        merged = dict(self.env)
        merged.update(env or {})
        backup: Dict[str, Optional[str]] = {}
        for key, value in merged.items():
            backup[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        capture: Any = _FdCapture(self.charset) if self.capture == "fd" else _SysCapture(self.charset)
        try:
            with capture as streams:
                out, err = streams
                stdin = _InputStream(data, self.charset, out if self.echo_stdin else None)
                old = (sys.stdin, sys.stdout, sys.stderr)
                sys.stdin, sys.stdout, sys.stderr = stdin, out, err
                try:
                    yield capture
                finally:
                    sys.stdin, sys.stdout, sys.stderr = old
        finally:
            for key, value in backup.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(
        self,
        cli: Any,
        args: Union[None, List[str], str] = None,
        input: Any = None,
        env: Optional[Dict[str, Optional[str]]] = None,
        catch_exceptions: Optional[bool] = None,
        color: bool = False,
        **extra: Any,
    ) -> Result:
        catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        if args is None:
            tokens: List[str] = []
        elif isinstance(args, str):
            import shlex

            tokens = shlex.split(args)
        else:
            tokens = list(args)
        prog_name = extra.pop("prog_name", None) or (cli.name or "root")
        standalone = extra.pop("standalone_mode", True)
        exit_code = 0
        exception: Optional[BaseException] = None
        with self.isolation(input=input, env=env) as capture:
            try:
                cli.main(
                    args=tokens,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    color=color,
                    **extra,
                )
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    exit_code = 1
                if exit_code != 0:
                    exception = exc
            except Exception as exc:  # noqa: BLE001 - surfaced through the result
                if not catch:
                    raise
                exit_code = 1
                exception = exc
        capture.finish()
        result = Result(
            capture.combined(),
            capture.stdout_bytes(),
            capture.stderr_bytes(),
            exit_code,
            exception,
            self.charset,
        )
        return result

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: Optional[str] = None) -> Iterator[str]:
        """Run inside a new empty directory. Removed on exit only when no ``temp_dir`` is given."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
