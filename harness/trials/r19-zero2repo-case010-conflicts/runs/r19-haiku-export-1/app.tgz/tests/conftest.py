import json
import os

import pytest

from lingora import data


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """A packaged-resource directory with Punkt, tagger, universal-tagset and stopword files."""
    root = tmp_path / "lingora_data"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("dr\nmr\netc\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("however\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("mr\tsmith\n", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("smith\t4\nhowever\t16\nhello\t16\n", encoding="utf-8")

    tagger = root / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT", "dog": "NN", "barks": "VBZ"}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["DT", "NN", "VBZ", "JJ"]), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        json.dumps({"bias": {"JJ": 1.0}}), encoding="utf-8")

    universal = root / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\nVBZ\tVERB\nJJ\tADJ\n", encoding="utf-8")

    stop = root / "corpora" / "stopwords"
    stop.mkdir(parents=True)
    (stop / "english").write_text("the\nand\nof\n", encoding="utf-8")

    monkeypatch.setattr(data, "path", [str(root)])
    return root
