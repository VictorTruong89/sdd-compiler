import pytest

from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.metrics import (
    accuracy as list_accuracy,
    edit_distance,
    f_measure,
    jaccard_distance,
    precision,
    recall,
)
from lingora.translate import bleu

TRAIN = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "great"}, "pos"), ({"w": "awful"}, "neg")]


# spec: N-000302 N-000306 N-000307 N-000308 N-000309 N-000495 N-000496 N-000497
def test_naive_bayes_label_distribution_and_labels():
    nb = NaiveBayesClassifier.train(TRAIN)
    assert nb.classify({"w": "good"}) == "pos"
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(l) for l in dist.samples()) - 1.0) < 1e-9
    assert set(nb.labels()) == {"pos", "neg"}


# spec: N-000304 N-000305 N-000315 N-000316 N-000317
def test_naive_bayes_unseen_feature_still_returns_trained_label():
    nb = NaiveBayesClassifier.train(TRAIN)
    assert nb.classify({"zzz": 1}) in {"pos", "neg"}


# spec: N-000310 N-000311 N-000312 N-000313 N-000314
def test_decision_tree_separates_training_data():
    data = [({"a": 1, "b": 0}, "x"), ({"a": 0, "b": 1}, "y"), ({"a": 1, "b": 1}, "x"), ({"a": 0, "b": 0}, "y")]
    dt = DecisionTreeClassifier.train(data)
    for fs, label in data:
        assert dt.classify(fs) == label


# spec: N-000330 N-000331 N-000332
def test_accuracy_and_metric_helpers():
    assert accuracy(NaiveBayesClassifier.train(TRAIN), [({"w": "good"}, "pos")]) == 1.0
    assert list_accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1, 2], [1])


# spec: N-000322 N-000323 N-000324 N-000328 N-000329 N-000348
def test_edit_distance():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("", "") == 0
    assert edit_distance("abc", "abc") == 0
    assert edit_distance("a", "b", substitution_cost=2) == 2
    assert edit_distance("ca", "abc") == 3
    assert edit_distance("ca", "abc", transpositions=True) == 2


def test_jaccard_distance():
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


# spec: N-000344 N-000345 N-000346 N-000347 N-000333 N-000334
def test_precision_recall_fmeasure_none_and_refusals():
    assert precision({1, 2}, {1}) == 1.0
    assert recall({1, 2}, {1}) == 0.5
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None
    assert f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    with pytest.raises(TypeError):
        precision([1], {1})


# spec: N-000335 N-000337 N-000340 N-000341 N-000511 N-000512 N-000513
def test_bleu_identity_and_zero():
    ref = "the cat sat on the mat".split()
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([["x", "y", "z", "w"]], ref) == 0.0
    assert bleu([ref], ref, weights=[1]) == pytest.approx(1.0)
