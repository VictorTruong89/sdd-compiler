import pytest

from lingora import data
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag


# spec: N-000198
def test_default_tagger():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


# spec: N-000199 N-000200 N-000201 N-000205 N-000206
def test_unigram_with_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("dog", "VB")], [("dog", "NN")]]
    t = UnigramTagger(train, backoff=DefaultTagger("X"))
    assert t.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", "X")]
    assert UnigramTagger(train).tag(["zebra"]) == [("zebra", None)]


# spec: N-000202 N-000203 N-000204
def test_regexp_tagger_first_match_at_start():
    t = RegexpTagger([(r".*ing$", "VBG"), (r".*", "NN")])
    assert t.tag(["running", "dog"]) == [("running", "VBG"), ("dog", "NN")]


# spec: N-000207 N-000208 N-000209 N-000214 N-000219 N-000222
def test_pos_tag_recommended_english(resources):
    assert pos_tag(["the", "dog", "barks"]) == [("the", "DT"), ("dog", "NN"), ("barks", "VBZ")]


# spec: N-000215 N-000226
def test_pos_tag_universal(resources):
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


def test_pos_tag_universal_fails_without_tables(resources, monkeypatch):
    import shutil
    shutil.rmtree(resources / "taggers" / "universal_tagset")
    with pytest.raises(LookupError):
        pos_tag(["the"], tagset="universal")


# spec: N-000219 N-000220 N-000221
def test_pos_tag_refuses_string(resources):
    with pytest.raises(TypeError):
        pos_tag("the dog")


# spec: N-000222 N-000223 N-000224 N-000225
def test_pos_tag_rejects_unknown_language_and_missing_resource(resources):
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="fra")
    with pytest.raises(LookupError):
        pos_tag(["x"], lang="rus")
