import pytest

from lingora import data
from lingora.stem import (
    LancasterStemmer,
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
)


# spec: N-000149 N-000150 N-000156 N-000157 N-000158
def test_porter_lingora_defaults():
    p = PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("ties") == "tie"  # LINGORA Step 1a
    assert p.stem("a") == "a"
    assert p.stem("Running") == "run"  # lowercased by default
    assert p.stem("Running", to_lowercase=False) == "Run"  # case kept, suffix still stripped


def test_porter_original_mode_differs_on_ties():
    assert PorterStemmer(mode="ORIGINAL").stem("ties") == "ti"


# spec: N-000170 N-000171
def test_lancaster_reference_words():
    s = LancasterStemmer()
    assert s.stem("maximum") == "maxim"
    assert s.stem("presumably") == "presum"
    assert s.stem("running") == "run"


# spec: N-000178 N-000179 N-000180
def test_regexp_stemmer_removes_matches():
    s = RegexpStemmer(r"ing$")
    assert s.stem("running") == "runn"
    assert s.stem("walk") == "walk"


# spec: N-000172 N-000174 N-000175
def test_snowball_english_is_porter2():
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("ties") == "tie"
    assert s.stem("cease") == "ceas"


# spec: N-000181 N-000182
def test_snowball_rejects_unknown_language_and_names_it():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


# spec: N-000183 N-000184
def test_snowball_stopwords_need_list(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_snowball_stopword_skip(resources):
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"
    assert s.stem("running") == "run"
