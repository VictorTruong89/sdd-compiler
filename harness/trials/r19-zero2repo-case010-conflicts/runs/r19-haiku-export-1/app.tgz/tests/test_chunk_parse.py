import pytest

from lingora.chunk import RegexpParser, ne_chunk
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

TAGGED = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN")]


# spec: N-000236 N-000237 N-000238 N-000239 N-000250 N-000251
def test_chunk_rule_groups_tags_and_keeps_leaves():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert tree.label() == "S"
    assert [c.label() if isinstance(c, Tree) else c[0] for c in tree] == ["NP", "barked", "at", "NP"]
    assert tree.leaves() == TAGGED


# spec: N-000243 N-000244 N-000245
def test_chink_rule_splits_chunk():
    tree = RegexpParser("NP: {<.*>+}\n  }<VBD>{").parse(TAGGED)
    labels = [c.label() if isinstance(c, Tree) else c[0] for c in tree]
    assert labels == ["NP", "barked", "NP"]


# spec: N-000246 N-000247 N-000248 N-000249
def test_cascade_clause_sees_earlier_chunks_as_units():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}\nVP: {<NP><VBD>}").parse(TAGGED)
    assert tree[0].label() == "VP"
    assert tree[0][0].label() == "NP"


# spec: N-000252 N-000253 N-000254 N-000255 N-000256
def test_chunk_grammar_refusals_and_empty_input():
    with pytest.raises(TypeError):
        RegexpParser(42)
    assert RegexpParser("NP: {<DT>}").parse([]).label() == "S"
    assert len(RegexpParser("NP: {<DT>}").parse([])) == 0


def test_ne_chunk_fails_without_resources(monkeypatch):
    from lingora import data
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        ne_chunk(TAGGED)


GRAMMAR = """
S -> NP VP
NP -> Det N | N
VP -> V NP | V
Det -> 'the' | 'a'
N -> 'dog' | 'cat'
V -> 'saw' | 'chased'
"""


# spec: N-000264 N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
def test_chart_parser_all_trees_and_ambiguity():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the dog saw a cat".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == "the dog saw a cat".split()
    amb = CFG.fromstring('S -> S S | "a"')
    assert len(list(ChartParser(amb).parse(["a", "a", "a"]))) == 2


# spec: N-000292 N-000293 N-000294 N-000295
def test_parser_raises_for_unproduced_token_and_empty_for_underivable():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])
    assert list(ChartParser(g).parse(["dog", "dog"])) == []


# spec: N-000272 N-000273 N-000274 N-000275
def test_shift_reduce_matches_chart_on_simple_sentence():
    g = CFG.fromstring("S -> 'a' 'b'\n")
    sr = list(ShiftReduceParser(g).parse(["a", "b"]))
    ch = list(ChartParser(g).parse(["a", "b"]))
    assert sr == ch


# spec: N-000276 N-000277 N-000278 N-000279 N-000280
def test_generate_order_and_bounds():
    g = CFG.fromstring(GRAMMAR)
    sentences = [" ".join(s) for s in generate(g, depth=6, n=5)]
    assert sentences[0] == "the dog saw the dog"
    assert len(sentences) == 5


# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488 N-000489
def test_tree_construction_and_equality():
    t = Tree.fromstring("(S (NP the dog) (VP barked))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barked"])])
    assert t.leaves() == ["the", "dog", "barked"]
    assert len(t) == 2 and t[0] == Tree("NP", ["the", "dog"])
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")
    assert len(Tree("S", [])) == 0


# spec: N-000490 N-000491 N-000287
def test_pformat_lists_labels_in_preorder():
    text = Tree.fromstring("(S (NP the dog) (VP barked))").pformat()
    assert text.index("S") < text.index("NP") < text.index("VP")
    assert "dog" in text and "barked" in text
