import pytest

from lingora import data


# spec: N-000385 N-000386 N-000387
def test_path_is_mutable_and_read_at_lookup_time(tmp_path, monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        data.find("corpora/words")
    (tmp_path / "corpora").mkdir()
    (tmp_path / "corpora" / "words").write_text("a\n", encoding="utf-8")
    data.path.append(str(tmp_path))
    assert data.is_visible("corpora/words")


def test_importing_package_downloads_nothing():
    import lingora  # noqa: F401
    assert hasattr(lingora, "tokenize") and hasattr(lingora, "parse")
