import io
import sys

import pytest

from lingora import data
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


# spec: N-000089 N-000090 N-000091 N-000136
def test_wordpunct_splits_words_and_punctuation():
    assert wordpunct_tokenize("Hi, there! 3.5") == ["Hi", ",", "there", "!", "3", ".", "5"]
    assert wordpunct_tokenize("") == []
    assert wordpunct_tokenize("   \n ") == []


def test_wordpunct_spans_recover_tokens():
    text = "ab, cd"
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == ["ab", ",", "cd"]


# spec: N-000092 N-000093 N-000097 N-000098 N-000099 N-000101 N-000102 N-000103
def test_treebank_quotes_clitics_and_fused_forms():
    t = TreebankWordTokenizer()
    assert t.tokenize('"Hello," she said.') == ["``", "Hello", ",", "''", "she", "said", "."]
    assert t.tokenize("I can't go.") == ["I", "ca", "n't", "go", "."]
    assert t.tokenize("They wanna go") == ["They", "wan", "na", "go"]
    assert t.tokenize("3,000 and 3:30") == ["3,000", "and", "3:30"]


# spec: N-000104 N-000109 N-000110
def test_recommended_word_tokens_keep_cannot_and_split_double_hyphen():
    from lingora.tokenize import word_tokenize as wt
    toks = wt("I cannot go -- now.", preserve_line=True)
    assert "cannot" in toks and "--" in toks


# spec: N-000113 N-000114 N-000115
def test_whitespace_and_blankline():
    assert WhitespaceTokenizer().tokenize(" a  b\tc\n") == ["a", "b", "c"]
    assert blankline_tokenize("a\nb\n\n\n c \n\n d") == ["a\nb", "c ", "d"]


# spec: N-000116 N-000117 N-000118
def test_regexp_tokenizer_modes():
    assert RegexpTokenizer(r"\w+").tokenize("a, bb") == ["a", "bb"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b,") == ["a", "b"]
    assert RegexpTokenizer(r",", gaps=True, discard_empty=False).tokenize("a,,b,") == ["a", "", "b", ""]


# spec: N-000119 N-000120 N-000121 N-000123 N-000124 N-000125
def test_tweet_tokenizer_options():
    assert TweetTokenizer().tokenize("@User I LOVE this :) #Fun") == ["@User", "I", "LOVE", "this", ":)", "#Fun"]
    assert TweetTokenizer(preserve_case=False).tokenize("HELLO :D") == ["hello", ":D"]
    assert TweetTokenizer(strip_handles=True).tokenize("@user hi") == ["hi"]
    assert TweetTokenizer(reduce_len=True, preserve_case=False).tokenize("sooooo") == ["sooo"]
    assert TweetTokenizer().tokenize("café") == ["café"]


# spec: N-000129 N-000130 N-000131 N-000137 N-000138
def test_sentence_splitting_uses_packaged_model(resources):
    assert sent_tokenize("Hello world. This is a test! Is it? Yes.") == [
        "Hello world.", "This is a test!", "Is it?", "Yes."]
    assert sent_tokenize("Dr. Smith went home. The end.") == ["Dr. Smith went home.", "The end."]
    assert sent_tokenize("   ") == []


def test_sentence_splitting_fails_without_model(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        sent_tokenize("x. y.")
    with pytest.raises(LookupError):
        word_tokenize("x. y.")


def test_word_tokenize_with_model_and_preserve_line(resources):
    assert word_tokenize("Dr. Smith went home. \"Hi,\" he said.")[:2] == ["Dr.", "Smith"]
    assert word_tokenize("Hi there", preserve_line=True) == ["Hi", "there"]


# spec: N-000139
def test_cli_tokenize_fails_without_model(monkeypatch, capsys):
    from lingora.cli import cli
    monkeypatch.setattr(data, "path", [])
    monkeypatch.setattr(sys, "stdin", io.StringIO("a. b.\n"))
    out = io.StringIO()
    monkeypatch.setattr(sys, "stdout", out)
    assert cli.main(args=["tokenize"], standalone_mode=False) == 1
    assert out.getvalue() == ""


def test_cli_tokenize_writes_one_line_per_input(resources, monkeypatch):
    from lingora.cli import cli
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there. Bye.\n\nlast\n"))
    out = io.StringIO()
    monkeypatch.setattr(sys, "stdout", out)
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize", "--delimiter", "|"], standalone_mode=True)
    assert exc.value.code == 0
    assert out.getvalue() == "Hi|there|.|Bye|.\n\nlast\n"
