"""BLEU (FP-07)."""
# spec: N-000498 N-000499 N-000500
import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


# spec: N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342
# spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU (Papineni et al., 2002), unsmoothed unless a function is given.

    ``weights`` is one weight per n-gram order from unigrams; the default is
    equal weights on unigrams through 4-grams. ``smoothing_function`` is called
    with the list of ``(matches, possible)`` pairs per order and returns the
    list of precisions to use.
    """
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    for ref in references:
        if isinstance(ref, str) or not isinstance(ref, (list, tuple)):
            raise TypeError("each reference is a token list")
    if isinstance(hypothesis, str) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a token list")
    if weights is None:
        weights = [0.25, 0.25, 0.25, 0.25]
    weights = list(weights)
    if not weights or not all(isinstance(w, (int, float)) and not isinstance(w, bool) for w in weights):
        raise TypeError("weights must be a non-empty sequence of numbers")
    if not references:
        raise ValueError("bleu needs at least one reference token list")
    if not hypothesis:
        return 0.0  # an empty candidate scores 0
    hyp = list(hypothesis)
    refs = [list(r) for r in references]
    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        possible = max(len(hyp) - n + 1, 0)
        max_ref = Counter()
        for ref in refs:
            for gram, c in _ngrams(ref, n).items():
                if c > max_ref[gram]:
                    max_ref[gram] = c
        matches = sum(min(c, max_ref[g]) for g, c in hyp_counts.items())
        pairs.append((matches, possible))
    if smoothing_function is not None:
        precisions = list(smoothing_function(pairs))
    else:
        precisions = []
        for matches, possible in pairs:
            precisions.append(matches / possible if possible and matches else 0.0)
    if any(p <= 0 and w > 0 for p, w in zip(precisions, weights)):
        return 0.0
    log_avg = sum(w * math.log(p) for p, w in zip(precisions, weights)) / sum(weights)
    c = len(hyp)
    ref_lengths = [len(r) for r in refs]
    r = min(ref_lengths, key=lambda rl: (abs(rl - c), rl))
    bp = 1.0 if c > r else math.exp(1 - r / c)
    return bp * math.exp(log_avg)
