"""Stemmers (FP-02)."""
# spec: N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151 N-000152 N-000153 N-000154 N-000155 N-000169 N-000170 N-000171 N-000172 N-000173 N-000174 N-000175 N-000176 N-000177 N-000178 N-000179 N-000180 N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428 N-000429 N-000430 N-000431 N-000432
import re

from . import data as _data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

# spec: N-000422 N-000423 N-000424 N-000425 N-000426 N-000427
SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_VOWELS = "aeiou"


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str")


def _check_bool(name, value):
    if not isinstance(value, bool):
        raise TypeError("%s must be a bool" % name)
    return value


# ------------------------------------------------------------------ Porter
def _is_cons(w, i):
    c = w[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _is_cons(w, i - 1)
    return True


def _measure(stem):
    """Porter's m: the number of VC sequences in the stem."""
    m = 0
    prev_vowel = False
    for i in range(len(stem)):
        cons = _is_cons(stem, i)
        if prev_vowel and cons:
            m += 1
        prev_vowel = not cons
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _is_cons(w, len(w) - 1)


def _cvc(w, lingora_short=False):
    """Stem ends consonant-vowel-consonant, final consonant not w, x or y."""
    if len(w) == 2 and lingora_short:
        return (not _is_cons(w, 0)) and _is_cons(w, 1)
    if len(w) < 3:
        return False
    return (
        _is_cons(w, len(w) - 3)
        and not _is_cons(w, len(w) - 2)
        and _is_cons(w, len(w) - 1)
        and w[-1] not in "wxy"
    )


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_LINGORA = [(s, ("ble" if s == "abli" else r)) for s, r in _STEP2_ORIGINAL]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]
# Irregular-form table of the LINGORA extensions. Its entries are outside the
# specification; the table is empty in this build.
_IRREGULAR = {}


class PorterStemmer:
    """Porter stemmer.

    ``mode`` is ``"LINGORA"`` (default: the LINGORA extensions), ``"ORIGINAL"``
    (Porter 1980 as published) or ``"MARTIN"`` (the Martin Porter extensions:
    the ``logi``/``fulli`` rules, without the other LINGORA changes).
    """

    MODES = ("LINGORA", "ORIGINAL", "MARTIN")

    def __init__(self, mode="LINGORA"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._ext = mode == "LINGORA"
        self._martin = mode in ("LINGORA", "MARTIN")
        self._step2_table = _STEP2_LINGORA if self._ext else _STEP2_ORIGINAL

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        _check_bool("to_lowercase", to_lowercase)
        w = word.lower() if to_lowercase else word
        if len(w) <= 2:
            return w
        if w in _IRREGULAR:
            return _IRREGULAR[w]
        w = self._step1a(w)
        w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5(w)
        return w

    # spec: N-000156 N-000157 N-000158
    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            # LINGORA: a four-letter word ending in -ies becomes -ie rather than -i
            if self._ext and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    # spec: N-000159 N-000160 N-000161
    def _step1b(self, w):
        if self._ext and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                return w[:-1]
            return w
        for suffix in ("ed", "ing"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if not _has_vowel(stem):
                    return w
                if stem.endswith(("at", "bl", "iz")):
                    return stem + "e"
                if _double_cons(stem) and stem[-1] not in "lsz":
                    return stem[:-1]
                if _measure(stem) == 1 and _cvc(stem, lingora_short=self._ext):
                    return stem + "e"
                return stem
        return w

    # spec: N-000162
    def _step1c(self, w):
        if w.endswith("y") and len(w) > 2:
            stem = w[:-1]
            if self._ext:
                # y becomes i after a consonant that is not the first letter of the stem
                if len(stem) > 1 and _is_cons(stem, len(stem) - 1):
                    return stem + "i"
                return w
            if _has_vowel(stem):
                return stem + "i"
        return w

    # spec: N-000163 N-000164 N-000165 N-000166 N-000167
    def _step2(self, w):
        if self._ext and w.endswith("alli"):
            stem = w[:-4]
            if _measure(stem) > 0:
                return self._step2(stem + "al")
        if self._martin and w.endswith("logi"):
            # -logi -> -log, when the part before -ogi has positive measure
            if _measure(w[:-3]) > 0:
                return w[:-1]
        if self._martin and w.endswith("fulli"):
            stem = w[:-5]
            if _measure(stem) > 0:
                return stem + "ful"
        for suffix, repl in self._step2_table:
            if w.endswith(suffix):
                if _measure(w[: -len(suffix)]) > 0:
                    return w[: -len(suffix)] + repl
                return w
        return w

    # spec: N-000168
    def _step3(self, w):
        for suffix, repl in _STEP3:
            if w.endswith(suffix):
                if _measure(w[: -len(suffix)]) > 0:
                    return w[: -len(suffix)] + repl
                return w
        return w

    def _step4(self, w):
        for suffix in _STEP4:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if suffix == "ion" and not (stem and stem[-1] in "st"):
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    def _step5(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _cvc(stem, lingora_short=self._ext)):
                w = stem
        if w.endswith("ll") and _measure(w[:-1]) > 1:
            w = w[:-1]
        return w


# ----------------------------------------------------------- Snowball English
_SN_VOWELS = "aeiouy"
_SN_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_SN_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
            "exceed", "succeed"}
_SN_LI_ENDINGS = "cdeghkmnrt"


def _sn_is_vowel(w, i):
    return w[i] in _SN_VOWELS


def _sn_regions(w):
    """Return (R1, R2) start indexes; len(w) when the region is empty."""
    def region(start):
        # first non-vowel that follows a vowel, at or after index start + 1
        for i in range(start + 1, len(w)):
            if not _sn_is_vowel(w, i) and _sn_is_vowel(w, i - 1):
                return i + 1
        return len(w)

    if w.startswith("gener") or w.startswith("arsen"):
        r1 = 5
    elif w.startswith("commun"):
        r1 = 6
    else:
        r1 = region(0)
    r1 = min(r1, len(w))
    r2 = region(r1) if r1 < len(w) else len(w)
    return r1, r2


def _sn_ends_short_syllable(w):
    if len(w) == 2:
        return _sn_is_vowel(w, 0) and not _sn_is_vowel(w, 1)
    if len(w) < 3:
        return False
    return (
        not _sn_is_vowel(w, -3) and _sn_is_vowel(w, -2)
        and not _sn_is_vowel(w, -1) and w[-1] not in "wxY"
    )


def _sn_is_short(w):
    r1, _ = _sn_regions(w)
    return r1 >= len(w) and _sn_ends_short_syllable(w)


def _porter2(word):
    """Snowball English (Porter2) stemmer, for a lowercased word."""
    if len(word) <= 2:
        return word
    if word in _SN_EXC1:
        return _SN_EXC1[word]
    chars = list(word)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _SN_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)

    # step 0
    for s in ("'s'", "'s", "'"):
        if w.endswith(s):
            w = w[: -len(s)]
            break

    # step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) - 3 > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(_sn_is_vowel(w, i) for i in range(0, len(w) - 2)):
            w = w[:-1]
    if w in _SN_EXC2:
        return w.replace("Y", "y")

    # step 1b
    r1, r2 = _sn_regions(w)
    if w.endswith(("eedly", "eed")):
        s = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(s) >= r1:
            w = w[: -len(s)] + "ee"
    else:
        s = None
        for cand in ("ingly", "edly", "ing", "ed"):
            if w.endswith(cand):
                s = cand
                break
        if s and any(_sn_is_vowel(w, i) for i in range(0, len(w) - len(s))):
            w = w[: -len(s)]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                w = w[:-1]
            elif _sn_is_short(w):
                w += "e"

    # step 1c
    if len(w) > 2 and w[-1] in "yY" and not _sn_is_vowel(w, len(w) - 2):
        w = w[:-1] + "i"

    # step 2 (suffix inside R1)
    r1, r2 = _sn_regions(w)
    step2 = [
        ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
        ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
        ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"),
    ]
    matched = False
    for suffix, repl in step2:
        if w.endswith(suffix):
            matched = True
            if len(w) - len(suffix) >= r1:
                if suffix == "ogi" and not (len(w) > 3 and w[-4] == "l"):
                    break
                w = w[: -len(suffix)] + repl
            break
    if not matched and w.endswith("li") and len(w) - 2 >= r1 and len(w) > 2 and w[-3] in _SN_LI_ENDINGS:
        w = w[:-2]

    # step 3 (suffix inside R1; ative inside R2)
    r1, r2 = _sn_regions(w)
    step3 = [
        ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
        ("iciti", "ic"), ("ical", "ic"), ("ative", ""), ("ness", ""), ("ful", ""),
    ]
    for suffix, repl in step3:
        if w.endswith(suffix):
            if suffix == "ative":
                if len(w) - len(suffix) >= r2:
                    w = w[: -len(suffix)]
            elif len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + repl
            break

    # step 4 (suffix inside R2)
    r1, r2 = _sn_regions(w)
    step4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
             "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    for suffix in step4:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix == "ion" and not (len(w) > 3 and w[-4] in "st"):
                    break
                w = w[: -len(suffix)]
            break

    # step 5
    r1, r2 = _sn_regions(w)
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _sn_ends_short_syllable(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and len(w) > 1 and w[-2] == "l":
        w = w[:-1]
    return w.replace("Y", "y")


# ----------------------------------------------------------------- Lancaster
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "lu2.", "lai3y>", "lau3.", "la2.", "ll1.", "mui3.",
    "mu*2.", "msi3.", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>",
    "nee0.", "ne2+", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.",
    "ro2q>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.", "si2>",
    "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.", "ta1>",
    "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.",
    "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.",
    "vis3j>", "vie5.", "vi2>", "ylb1>", "yli3y>", "ylp0.", "yl2>", "ygo1.",
    "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>",
    "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)


def _parse_lancaster_rule(rule):
    m = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>+])", rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    suffix_rev, star, digit, append, cont = m.groups()
    return suffix_rev[::-1], bool(star), int(digit), append, cont != "."


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer:
    """Paice/Husk stemmer with the rule table of Paice (1990)."""

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        while True:
            applied = False
            for suffix, needs_intact, remove, append, cont in _LANCASTER_PARSED:
                if needs_intact and not intact:
                    continue
                if not w.endswith(suffix):
                    continue
                new = w[: len(w) - remove] + append if remove else w + append
                if remove and len(w) - remove < 2:
                    continue
                if not cont:
                    return new
                w = new
                intact = False
                applied = True
                break
            if not applied:
                return w
            if len(w) < 2:
                return w


# ------------------------------------------------------------------ regexp
class RegexpStemmer:
    """Removes every match of ``regexp`` from the word."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# ---------------------------------------------------------------- Snowball
class SnowballStemmer:
    """Snowball stemmer. Implemented languages: ``english`` (Porter2) and ``porter``.

    The other names are accepted; stemming with them raises ``NotImplementedError``.
    """

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language: %r" % (language,)
            )
        self._language = language
        self._ignore_stopwords = _check_bool("ignore_stopwords", ignore_stopwords)
        self._stopwords = frozenset()
        if ignore_stopwords:
            try:
                path = _data.find(_data.STOPWORDS.format(language=language))
            except LookupError:
                raise LookupError(
                    "stopwords list for %r is not installed" % language
                ) from None
            self._stopwords = frozenset(
                line.strip().lower() for line in _data.read_lines(path) if line.strip()
            )
        self._porter = PorterStemmer(mode="ORIGINAL") if language == "porter" else None

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if self._ignore_stopwords and w in self._stopwords:
            return w
        if self._language == "english":
            return _porter2(w)
        if self._porter is not None:
            return self._porter.stem(w, to_lowercase=False)
        raise NotImplementedError(
            "Snowball stemming for %r is not implemented in this build" % self._language
        )


# ----------------------------------------------------------- not implemented
class _NotImplementedStemmer:
    name = ""

    def __init__(self, *args, **kwargs):
        pass

    def stem(self, word):
        raise NotImplementedError("%s is not implemented in this build" % self.name)


class ARLSTem(_NotImplementedStemmer):
    name = "ARLSTem"


class ARLSTem2(_NotImplementedStemmer):
    name = "ARLSTem2"


class WordNetLemmatizer:
    """Requires the packaged WordNet resource; its lookup is not implemented here."""

    def __init__(self):
        _data.find(_data.WORDNET)

    def lemmatize(self, word):
        _check_word(word)
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")
