import sys

from .cli import cli

if __name__ == "__main__":
    cli.main(args=sys.argv[1:], standalone_mode=True)
