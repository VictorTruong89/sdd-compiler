"""Evaluation metrics (FP-07)."""
# spec: N-000318 N-000319 N-000320 N-000321 N-000498 N-000499 N-000500

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def _is_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _check_set(name, value):
    if not isinstance(value, (set, frozenset)):
        raise TypeError("%s must be a set or frozenset" % name)
    return value


# spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329
# spec: N-000503 N-000504 N-000505 N-000506 N-000348
def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Damerau-Levenshtein distance (unrestricted when ``transpositions`` is true)."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    if not _is_number(substitution_cost):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be a bool")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = [j for j in range(len(s2) + 1)]
    for i, a in enumerate(s1, start=1):
        cur = [i]
        for j, b in enumerate(s2, start=1):
            sub = 0 if a == b else substitution_cost
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub))
        prev = cur
    return prev[-1]


def _damerau(s1, s2, sub_cost):
    """Lowrance and Wagner (1975): unrestricted Damerau-Levenshtein distance."""
    maxdist = len(s1) + len(s2)
    da = {}
    d = {(-1, -1): maxdist}
    for i in range(len(s1) + 1):
        d[i, -1] = maxdist
        d[i, 0] = i
    for j in range(len(s2) + 1):
        d[-1, j] = maxdist
        d[0, j] = j
    for i in range(1, len(s1) + 1):
        db = 0
        for j in range(1, len(s2) + 1):
            k = da.get(s2[j - 1], 0)
            l = db
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub_cost
            d[i, j] = min(
                d[i - 1, j - 1] + cost,
                d[i, j - 1] + 1,
                d[i - 1, j] + 1,
                d[k - 1, l - 1] + (i - k - 1) + 1 + (j - l - 1),
            )
        da[s1[i - 1]] = i
    return d[len(s1), len(s2)]


# spec: N-000507
def jaccard_distance(label1, label2):
    """|A symmetric-difference B| / |A union B|; 0 when both sets are empty."""
    a = _check_set("label1", label1)
    b = _check_set("label2", label2)
    union = a | b
    if not union:
        return 0.0
    return len(a ^ b) / len(union)


# spec: N-000330 N-000331 N-000343 N-000501 N-000502
def accuracy(reference, test):
    """Fraction of equal positions; lists of different lengths raise ValueError."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy needs at least one position")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


# spec: N-000332 N-000344 N-000345 N-000346 N-000508 N-000509 N-000510
def precision(reference, test):
    reference = _check_set("reference", reference)
    test = _check_set("test", test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    reference = _check_set("reference", reference)
    test = _check_set("test", test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


# spec: N-000333 N-000334 N-000347
def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when no number results."""
    reference = _check_set("reference", reference)
    test = _check_set("test", test)
    if not _is_number(alpha):
        raise TypeError("alpha must be a number")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or not (reference & test):
        return None
    return 1 / (alpha / p + (1 - alpha) / r)
