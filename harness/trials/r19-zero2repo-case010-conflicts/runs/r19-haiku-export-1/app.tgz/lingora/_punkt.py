"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), applied with packaged parameters.

Only the decision procedure is implemented here; the parameters (abbreviation
types, collocations, sentence starters, orthographic context) are read from the
packaged model directory. Training is not part of this library.
"""
import os
import re
from collections import namedtuple

from . import data as _data

# Orthographic context bit set (spec: N-000402).
ORTHO_BEG_UC = 2
ORTHO_MID_UC = 4
ORTHO_UNK_UC = 8
ORTHO_BEG_LC = 16
ORTHO_MID_LC = 32
ORTHO_UNK_LC = 64

Params = namedtuple(
    "Params", "abbrev_types collocations sent_starters ortho_context"
)

_cache = {}


def _model_dir(language):
    if not re.fullmatch(r"[A-Za-z][A-Za-z\-]*", language or ""):
        raise ValueError("unsupported Punkt language name: %r" % (language,))
    try:
        return _data.find(_data.PUNKT.format(language=language))
    except LookupError:
        raise LookupError(
            "Punkt sentence models for language %r are not installed" % language
        ) from None


def _read_optional(directory, name):
    file_name = os.path.join(directory, name)
    if not os.path.exists(file_name):
        return []
    return _data.read_lines(file_name)


def load_params(language):
    """Return the Punkt parameters for ``language``; raise if the model is not visible."""
    directory = _model_dir(language)
    key = (directory, os.path.getmtime(directory))
    if key in _cache:
        return _cache[key]
    abbrev = {line.strip() for line in _read_optional(directory, "abbrev_types.txt") if line.strip()}
    starters = {line.strip() for line in _read_optional(directory, "sent_starters.txt") if line.strip()}
    collocations = set()
    for line in _read_optional(directory, "collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_optional(directory, "ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = Params(abbrev, collocations, starters, ortho)
    _cache[key] = params
    return params


_NUMBER_TYPE = re.compile(r"^[+-]?[.,]?\d[\d.,:\-/]*$")
_LEAD_PUNCT = re.compile(r"^[(\[{\"'`«“‘]+")
_TRAIL_CLOSERS = re.compile(r"[)\]}>\"'”’»]*$")
_PERIOD_FINAL = re.compile(r"\.[)\]}>\"'”’»]*$")
_ELLIPSIS_FINAL = re.compile(r"\.\.\.+[)\]}>\"'”’»]*$")
_INITIAL = re.compile(r"^[(\[{\"'`]*[^\W\d_]\.$")


class _Tok:
    __slots__ = (
        "start", "end", "text", "period_final", "ellipsis", "is_initial",
        "abbr", "type", "type_no_period", "type_no_sentperiod",
        "first_upper", "first_lower", "sentbreak",
    )


def _annotate(text, params):
    toks = []
    for m in re.finditer(r"\S+", text):
        t = _Tok()
        t.start, t.end, t.text = m.start(), m.end(), m.group(0)
        bare = _TRAIL_CLOSERS.sub("", t.text)
        t.period_final = bool(_PERIOD_FINAL.search(t.text))
        t.ellipsis = bool(_ELLIPSIS_FINAL.search(t.text))
        t.is_initial = bool(_INITIAL.match(t.text))
        core = _LEAD_PUNCT.sub("", bare)
        if t.period_final:
            no_period = core[:-1] if core.endswith(".") else core
        else:
            no_period = core
        t.type_no_period = no_period.lower()
        if _NUMBER_TYPE.match(no_period):
            t.type_no_period = "##number##"
        t.type = t.type_no_period
        t.type_no_sentperiod = t.type_no_period
        alpha = [c for c in core if c.isalpha()]
        t.first_upper = bool(alpha) and alpha[0].isupper()
        t.first_lower = bool(alpha) and alpha[0].islower()
        t.abbr = t.type_no_period in params.abbrev_types
        # first pass: sentence-final ?/! and non-abbreviated period breaks
        t.sentbreak = bool(re.search(r"[?!][)\]}>\"'”’»]*$", t.text))
        if t.period_final and not (t.abbr or t.ellipsis or t.is_initial):
            t.sentbreak = True
        toks.append(t)
    return toks


def _ortho_heuristic(tok, params):
    """True: likely sentence starter. False: not a starter. None: no evidence."""
    ctx = params.ortho_context.get(tok.type_no_sentperiod, 0)
    # capitalised at sentence starts and never capitalised inside a sentence (not a proper noun)
    if tok.first_upper and (ctx & ORTHO_BEG_UC) and not (ctx & ORTHO_MID_UC):
        return True
    if tok.first_lower and (ctx & ORTHO_MID_LC):
        return False
    return None


def _second_pass(tok1, tok2, params):
    """Return True/False to set a break, or None to keep the first-pass value."""
    if tok2 is None or not tok1.period_final:
        return None
    typ = tok1.type_no_period
    next_typ = tok2.type_no_sentperiod
    if (typ, next_typ) in params.collocations:
        return False
    if (tok1.abbr or tok1.ellipsis) and not tok1.is_initial:
        if _ortho_heuristic(tok2, params) is True:
            return True
        if tok2.first_upper and next_typ in params.sent_starters:
            return True
        return False
    if tok1.is_initial or typ == "##number##":
        if _ortho_heuristic(tok2, params) is True:
            return True
        ctx = params.ortho_context.get(next_typ, 0)
        if tok2.first_upper and not (ctx & ORTHO_MID_LC):
            return False
        return None
    return None


def split_sentences(text, params):
    """Return the sentences of ``text`` as their original substrings."""
    if not text.strip():
        return []
    toks = _annotate(text, params)
    for i, tok in enumerate(toks):
        nxt = toks[i + 1] if i + 1 < len(toks) else None
        decision = _second_pass(tok, nxt, params)
        if decision is not None:
            tok.sentbreak = decision
    sentences = []
    first = 0
    for i, tok in enumerate(toks):
        last = i == len(toks) - 1
        if tok.sentbreak or last:
            sentences.append(text[toks[first].start:tok.end])
            first = i + 1
    return sentences
