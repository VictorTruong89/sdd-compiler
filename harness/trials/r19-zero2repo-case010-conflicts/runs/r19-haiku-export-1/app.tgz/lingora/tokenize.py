"""Tokenizers (FP-01)."""
# spec: N-000030 N-000031 N-000032 N-000033 N-000081 N-000082 N-000087 N-000088 N-000126 N-000127 N-000128 N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412 N-000413
import re

from . import data as _data
from ._punkt import load_params, split_sentences

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]

_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


def _check_str(text):
    if not isinstance(text, str):
        raise TypeError("expected str, got %s" % type(text).__name__)


def _as_bool(name, value):
    if not isinstance(value, bool):
        raise TypeError("%s must be a bool" % name)
    return value


# ---------------------------------------------------------------- word/punct
# spec: N-000089 N-000090 N-000091 — word characters vs. non-word, non-space runs.
def _wordpunct_spans(text):
    return [(m.start(), m.end()) for m in _WORDPUNCT.finditer(text)]


def wordpunct_tokenize(text):
    _check_str(text)
    return [text[s:e] for s, e in _wordpunct_spans(text)]


class WordPunctTokenizer:
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        _check_str(text)
        return iter(_wordpunct_spans(text))


# ------------------------------------------------------------ Penn Treebank
_TYPO_QUOTES = "“”„‟«»‘’‚‛‹›"
_TYPO_RE = re.compile("[" + re.escape(_TYPO_QUOTES) + "]")
_CLITIC_RE = re.compile(r"""([^\s'])('(?:ll|re|ve|s|m|d)|n't)\b""", re.IGNORECASE)
_BARE_APOS_RE = re.compile(r"([^\s'])'(?=\s|$)")
_FUSED = [
    (re.compile(r"\b(d)('ye)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(gim)(me)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(gon)(na)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(got)(ta)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(lem)(me)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(more)('n)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(wan)(na)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"(?<!\w)(')(t)(is)\b", re.IGNORECASE), r"\1\2 \3"),
    (re.compile(r"(?<!\w)(')(t)(was)\b", re.IGNORECASE), r"\1\2 \3"),
]


def _treebank(text, improved):
    """Penn Treebank conventions; ``improved`` adds the recommended-tokenizer rules."""
    if improved and text.startswith('"'):
        text = " '' " + text[1:]
    s = " " + text + " "
    if improved:
        s = _TYPO_RE.sub(lambda m: " %s " % m.group(0), s)
    # starting quotes
    s = re.sub(r'([ (\[{<])"', r"\1 `` ", s)
    s = re.sub(r"(``)", r" \1 ", s)
    s = re.sub(r"([ (\[{<])('')", r"\1 `` ", s)
    # punctuation
    s = re.sub(r"([:,])([^\d])", r" \1 \2", s)
    s = re.sub(r"([:,])$", r" \1 ", s)
    if improved:
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), s)
        s = re.sub(r"\*", " * ", s)
        s = re.sub("[‒–—―]", lambda m: " %s " % m.group(0), s)
        s = re.sub(r"--", " -- ", s)
    else:
        s = re.sub(r"\.\.\.", " ... ", s)
    s = re.sub(r"[;@#$%&]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"([^.])(\.)([\]\)}>\"']*)\s*$", r"\1 \2\3 ", s)
    s = re.sub(r"[?!]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"[\]\[(){}<>]", lambda m: " %s " % m.group(0), s)
    # ending quotes
    s = s.replace('"', " '' ")
    s = re.sub(r"(\S)('')", r"\1 \2 ", s)
    s = _BARE_APOS_RE.sub(r"\1 '", s)
    s = _CLITIC_RE.sub(r"\1 \2", s)
    if not improved:
        s = re.sub(r"(?i)\b(can)(not)\b", r"\1 \2", s)
        for regexp, repl in _FUSED:
            s = regexp.sub(repl, s)
    return s.split()


# spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099
# spec: N-000100 N-000101 N-000102 N-000103
class TreebankWordTokenizer:
    def tokenize(self, text):
        _check_str(text)
        return _treebank(text, improved=False)


# spec: N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110
def _recommended_word_tokens(sentence):
    return _treebank(sentence, improved=True)


# ----------------------------------------------------------- sentence / words
def _punkt_params(language):
    return load_params(language)


# spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000137 N-000138
def sent_tokenize(text, language="english"):
    _check_str(text)
    return split_sentences(text, _punkt_params(language))


# spec: N-000086 N-000111 N-000112 N-000136 N-000137 N-000138
def word_tokenize(text, language="english", preserve_line=False):
    _check_str(text)
    _as_bool("preserve_line", preserve_line)
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language=language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_recommended_word_tokens(sentence))
    return tokens


# ------------------------------------------------------------ whitespace etc.
_WS = re.compile(r"\S+")


# spec: N-000113
class WhitespaceTokenizer:
    def tokenize(self, text):
        _check_str(text)
        return [m.group(0) for m in _WS.finditer(text)]

    def span_tokenize(self, text):
        _check_str(text)
        return iter([(m.start(), m.end()) for m in _WS.finditer(text)])


_BLANK = re.compile(r"\n\s*\n\s*")


# spec: N-000114 N-000115
def blankline_tokenize(text):
    _check_str(text)
    segments = []
    pos = 0
    for m in _BLANK.finditer(text):
        segments.append(text[pos:m.start()])
        pos = m.end()
    segments.append(text[pos:])
    return [seg for seg in segments if seg != ""]


# spec: N-000116 N-000117 N-000118 N-000405 N-000406 N-000407 N-000408
class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True):
        _as_bool("gaps", gaps)
        _as_bool("discard_empty", discard_empty)
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._regexp = re.compile(pattern)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def _spans(self, text):
        spans = []
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans

    def tokenize(self, text):
        _check_str(text)
        return [text[s:e] for s, e in self._spans(text)]

    def span_tokenize(self, text):
        _check_str(text)
        return iter(self._spans(text))


# ----------------------------------------------------------------- tweets
# spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125
_EMOTICON = r"(?::|;|=|8)[\-o*']?[)(\]\[dDpPoO/\\|]"
_URL = r"(?:https?://|www\.)\S+"
_HASHTAG = r"#\w+"
_HANDLE = r"(?<!\w)@\w+"
_NUMBER = r"[+-]?\d+(?:[.,]\d+)*"
_WORD = r"[^\W\d_]+(?:['’][^\W\d_]+)*|\w+"
_TWEET_RE = re.compile(
    "|".join(
        [
            _URL,
            "(?:" + _EMOTICON + ")",
            _HASHTAG,
            _HANDLE,
            _NUMBER,
            _WORD,
            r"[^\w\s]",
        ]
    ),
    re.UNICODE,
)
_HANDLE_STRIP = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE = re.compile(r"(.)\1{2,}", re.DOTALL)
_EMOTICON_RE = re.compile("^(?:" + _EMOTICON + ")$")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = _as_bool("preserve_case", preserve_case)
        self._reduce_len = _as_bool("reduce_len", reduce_len)
        self._strip_handles = _as_bool("strip_handles", strip_handles)

    def tokenize(self, text):
        _check_str(text)
        if self._strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_RE.findall(text)
        if not self._preserve_case:
            tokens = [t if _EMOTICON_RE.match(t) else t.lower() for t in tokens]
        return tokens
