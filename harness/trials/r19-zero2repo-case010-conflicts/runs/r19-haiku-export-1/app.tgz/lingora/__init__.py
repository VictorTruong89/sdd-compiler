"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing and reads no packaged resource.
"""
# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007 N-000008 N-000009 N-000010 N-000011 N-000012 N-000013 N-000014 N-000015 N-000016 N-000017 N-000018 N-000029 N-000030 N-000031 N-000032 N-000033 N-000034 N-000035 N-000036 N-000037 N-000038 N-000039 N-000040 N-000041 N-000042 N-000043 N-000044 N-000045 N-000046 N-000047 N-000069 N-000070 N-000071
# spec: N-000371 N-000372 N-000373 N-000374 N-000375 N-000376
# spec: N-000377 N-000378 N-000379 N-000380 N-000381 N-000382 N-000383 N-000384  (refusals raise; scores are int/float, never bool)
from . import (  # noqa: F401  (submodules are part of the public surface)
    chunk,
    classify,
    data,
    grammar,
    metrics,
    parse,
    stem,
    tag,
    tokenize,
    translate,
    tree,
)

__version__ = "0.1.0"
