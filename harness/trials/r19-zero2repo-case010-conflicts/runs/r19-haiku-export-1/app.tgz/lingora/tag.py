"""Taggers (FP-03)."""
# spec: N-000187 N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195
import json
import os
import re
from collections import Counter, defaultdict

from . import data as _data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
    return list(tokens)


class _SequentialTagger:
    backoff = None

    def _primary(self, tokens):
        raise NotImplementedError

    # spec: N-000196 N-000197 N-000205 N-000206
    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._primary(tokens)
        if self.backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self.backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, fallback):
                    tags[i] = t
        return list(zip(tokens, tags))


# spec: N-000198
class DefaultTagger(_SequentialTagger):
    def __init__(self, tag):
        self._tag = tag

    def _primary(self, tokens):
        return [self._tag for _ in tokens]


# spec: N-000199 N-000200 N-000201 N-000436 N-000437 N-000439
class UnigramTagger(_SequentialTagger):
    def __init__(self, train=None, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                counts[token][tag] += 1
        # most frequent tag; ties broken by the tag's sort order
        self._model = {
            token: sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
            for token, c in counts.items()
        }

    def _primary(self, tokens):
        return [self._model.get(t) for t in tokens]


# spec: N-000202 N-000203 N-000204 N-000438
class RegexpTagger(_SequentialTagger):
    def __init__(self, regexps, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self.backoff = backoff
        self._rules = [(re.compile(p), t) for p, t in regexps]

    def _primary(self, tokens):
        out = []
        for token in tokens:
            tag = None
            for regexp, t in self._rules:
                if regexp.match(token):
                    tag = t
                    break
            out.append(tag)
        return out


# ------------------------------------------------------- averaged perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        if not self.classes:
            return [None for _ in tokens]
        context = _START + [_normalize(w) for w in tokens] + _END
        prev, prev2 = _START[0], _START[1]
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                feats = _features(i, word, context, prev, prev2)
                tag = self.predict(feats)
            out.append(tag)
            prev2, prev = prev, tag
        return out


def _load_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _load_perceptron(lang):
    if lang == "eng":
        resource = _data.TAGGER_ENG
    elif lang == "rus":
        resource = _data.TAGGER_RUS
    else:
        raise ValueError("unsupported language for the recommended tagger: %r" % (lang,))
    try:
        directory = _data.find(resource)
    except LookupError:
        raise LookupError(
            "averaged perceptron tagger resource for %r is not installed" % lang
        ) from None
    base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
    weights = _load_json(base + ".weights.json")
    tagdict = _load_json(base + ".tagdict.json")
    classes = _load_json(base + ".classes.json")
    return _Perceptron(weights, tagdict, classes)


# Russian National Corpus part-of-speech category -> universal category.
_RUS_UNIVERSAL = {
    "S": "NOUN", "S-PRO": "PRON", "SPRO": "PRON", "A": "ADJ", "A-PRO": "DET",
    "APRO": "DET", "ANUM": "ADJ", "NUM": "NUM", "V": "VERB", "ADV": "ADV",
    "ADV-PRO": "ADV", "PR": "ADP", "CONJ": "CCONJ", "PART": "PART",
    "INTJ": "INTJ", "PRAEDIC": "ADV", "PARENTH": "X",
}


def _universal_map(tags, lang):
    if lang == "rus":
        return [_RUS_UNIVERSAL.get(t.split("=", 1)[0], "X") if t else t for t in tags]
    try:
        directory = _data.find(_data.UNIVERSAL_TAGSET)
    except LookupError:
        raise LookupError("universal tagset tables are not installed") from None
    mapping = {}
    with open(os.path.join(directory, "en-ptb.map"), encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return [mapping.get(t, t) if t else t for t in tags]


# spec: N-000433 N-000434 N-000435 N-000440 N-000441 N-000442 N-000443 N-000444 N-000445
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
# spec: N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222
# spec: N-000223 N-000224 N-000225 N-000226 N-000227
def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str):
        raise TypeError("pos_tag takes a list of tokens, not a string")
    tokens = _check_tokens(tokens)
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    tags = model.tag(tokens)
    if tagset == "universal":
        tags = _universal_map(tags, lang)
    return list(zip(tokens, tags))
