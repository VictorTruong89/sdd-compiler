"""Classifiers (FP-06)."""
# spec: N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_GAMMA = 0.5  # expected-likelihood smoothing for feature values


class ProbDist:
    """A distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probs)


def _check_featuresets(labeled):
    if isinstance(labeled, str) or not isinstance(labeled, (list, tuple)):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    if not labeled:
        raise ValueError("training needs at least one labeled featureset")
    out = []
    for pair in labeled:
        if not (isinstance(pair, (list, tuple)) and len(pair) == 2):
            raise TypeError("labeled_featuresets must be (featureset, label) pairs")
        fs, label = pair
        if not isinstance(fs, dict):
            raise TypeError("a featureset is a dict")
        out.append((dict(fs), label))
    return out


# spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
# spec: N-000315 N-000316 N-000317
class NaiveBayesClassifier:
    def __init__(self, label_counts, feature_counts, value_bins, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts  # (feat, label) -> Counter of values
        self._feature_totals = {}
        self._value_bins = value_bins  # feat -> number of distinct values seen (+1)
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_featuresets(labeled_featuresets)
        label_counts = Counter(label for _, label in data)
        feature_counts = defaultdict(Counter)
        values = defaultdict(set)
        for fs, label in data:
            for feat, value in fs.items():
                feature_counts[(feat, label)][value] += 1
                values[feat].add(value)
        bins = {feat: len(vals) + 1 for feat, vals in values.items()}
        model = cls(label_counts, feature_counts, bins, len(data))
        for (feat, label), counter in feature_counts.items():
            model._feature_totals[(feat, label)] = sum(counter.values())
        return model

    def labels(self):
        return list(self._label_counts.keys())

    def _log_joint(self, featureset):
        scores = {}
        for label, count in self._label_counts.items():
            logp = math.log(count / self._total)
            for feat, value in featureset.items():
                if feat not in self._value_bins:
                    continue  # a feature never seen in training is ignored
                n = self._feature_totals.get((feat, label), 0)
                c = self._feature_counts[(feat, label)][value] if (feat, label) in self._feature_counts else 0
                bins = self._value_bins[feat]
                logp += math.log((c + _GAMMA) / (n + _GAMMA * bins))
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset is a dict")
        logs = self._log_joint(featureset)
        top = max(logs.values())
        exps = {label: math.exp(v - top) for label, v in logs.items()}
        total = sum(exps.values())
        return ProbDist({label: v / total for label, v in exps.items()})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset is a dict")
        logs = self._log_joint(featureset)
        return max(logs.items(), key=lambda kv: (kv[1], str(kv[0])))[0]


def _entropy(counter):
    total = sum(counter.values())
    h = 0.0
    for c in counter.values():
        p = c / total
        h -= p * math.log2(p)
    return h


# spec: N-000310 N-000311 N-000312 N-000313 N-000314
class DecisionTreeClassifier:
    def __init__(self, tree):
        self._tree = tree  # ("leaf", label) or ("node", feat, {value: subtree}, default_label)

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_featuresets(labeled_featuresets)
        return cls(cls._build(data, sorted({f for fs, _ in data for f in fs}, key=str)))

    @staticmethod
    def _majority(data):
        counts = Counter(label for _, label in data)
        return sorted(counts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    @classmethod
    def _build(cls, data, features):
        labels = Counter(label for _, label in data)
        majority = cls._majority(data)
        if len(labels) == 1:
            return ("leaf", majority)
        base = _entropy(labels)
        best = None
        for feat in features:
            groups = defaultdict(list)
            for fs, label in data:
                groups[fs.get(feat)].append((fs, label))
            if len(groups) < 2:
                continue
            remainder = 0.0
            for members in groups.values():
                remainder += len(members) / len(data) * _entropy(Counter(l for _, l in members))
            gain = base - remainder
            if best is None or gain > best[0] + 1e-12:
                best = (gain, feat, groups)
        if best is None or best[0] <= 1e-12:
            return ("leaf", majority)
        _, feat, groups = best
        rest = [f for f in features if f != feat]
        children = {}
        for value, members in groups.items():
            children[value] = cls._build(members, rest)
        return ("node", feat, children, majority)

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset is a dict")
        node = self._tree
        while node[0] == "node":
            _, feat, children, default = node
            value = featureset.get(feat)
            if value in children:
                node = children[value]
            else:
                return default
        return node[1]


# spec: N-000330 N-000331 N-000343 N-000492 N-000493 N-000494 N-000495 N-000496 N-000497
def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs the classifier labels correctly."""
    if isinstance(gold, str) or not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    hits = 0
    for fs, label in gold:
        if classifier.classify(fs) == label:
            hits += 1
    return hits / len(gold)
