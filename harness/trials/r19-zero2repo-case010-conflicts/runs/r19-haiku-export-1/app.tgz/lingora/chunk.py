"""Chunking with chunk grammars and named-entity chunking (FP-04)."""
# spec: N-000258 N-000259 N-000262 N-000263 N-000264 N-000265
import bisect
import re

from . import data as _data
from .tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"
_SEP_START = "\x00"
_SEP_END = "\x01"


# ----------------------------------------------------------- tag patterns
def _element_regex(content):
    """Regex for one tag element; ``.`` matches one character of a tag."""
    out = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^\x00\x01]" if c == "." else c)
        i += 1
    return "".join(out)


def _tag_pattern_regex(pattern):
    """Compile a tag pattern such as ``<DT>?<JJ>*<NN.*>`` to a regex over encoded units."""
    parts = []
    i = 0
    text = pattern
    n = len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c != "<":
            raise ValueError("tag pattern element must be in angle brackets: %r" % pattern)
        end = text.find(">", i)
        if end < 0:
            raise ValueError("unterminated tag pattern element: %r" % pattern)
        content = text[i + 1:end]
        if content == "":
            raise ValueError("empty tag pattern element: %r" % pattern)
        i = end + 1
        element = _SEP_START + "(?:" + _element_regex(content) + ")" + _SEP_END
        quant = ""
        j = i
        while j < n and text[j].isspace():
            j += 1
        if j < n and text[j] in "?*+":
            quant = text[j]
            i = j + 1
        elif j < n and text[j] == "{":
            close = text.find("}", j)
            if close < 0:
                raise ValueError("unterminated count in tag pattern: %r" % pattern)
            quant = text[j:close + 1]
            if not re.fullmatch(r"\{\d*,?\d*\}", quant) or quant == "{}":
                raise ValueError("bad count in tag pattern: %r" % pattern)
            i = close + 1
        if quant:
            parts.append("(?:" + element + ")" + quant)
        else:
            parts.append(element)
    if not parts:
        raise ValueError("empty tag pattern: %r" % pattern)
    return re.compile("".join(parts))


def _find_matches(tags, regex):
    """Non-overlapping, non-empty matches over a run of tags, as (start, end) unit indexes."""
    encoded = "".join(_SEP_START + t + _SEP_END for t in tags)
    starts = [i for i, ch in enumerate(encoded) if ch == _SEP_START]
    out = []
    for m in regex.finditer(encoded):
        if m.end() == m.start():
            continue
        a = bisect.bisect_left(starts, m.start())
        b = bisect.bisect_left(starts, m.end())
        out.append((a, b))
    return out


# ---------------------------------------------------------------- grammar
class _Clause:
    def __init__(self, label):
        self.label = label
        self.rules = []  # list of ("chunk"|"chink", compiled regex)


def _parse_rules(text, clause, text_for_error):
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c == "{":
            end = text.find("}", i + 1)
            if end < 0:
                raise ValueError("unterminated chunk rule in %r" % text_for_error)
            clause.rules.append(("chunk", _tag_pattern_regex(text[i + 1:end])))
            i = end + 1
        elif c == "}":
            end = text.find("{", i + 1)
            if end < 0:
                raise ValueError("unterminated chink rule in %r" % text_for_error)
            clause.rules.append(("chink", _tag_pattern_regex(text[i + 1:end])))
            i = end + 1
        else:
            raise ValueError("unexpected text in chunk grammar: %r" % text_for_error)


def _parse_grammar(text):
    clauses = []
    current = None
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if raw[0] in " \t" and current is not None:
            _parse_rules(stripped, current, raw)
            continue
        m = re.match(r"^([^:{}<>]+?)\s*:(.*)$", stripped)
        if not m:
            raise ValueError("clause must begin with '<LABEL>:' : %r" % raw)
        current = _Clause(m.group(1).strip())
        clauses.append(current)
        _parse_rules(m.group(2), current, raw)
    if not clauses:
        raise ValueError("a chunk grammar needs at least one clause")
    return clauses


def _apply_clause(nodes, clause):
    created = []  # Trees built by this clause; they are barriers for its later chunk rules
    for kind, regex in clause.rules:
        if kind == "chunk":
            nodes = _chunk_rule(nodes, regex, clause.label, created)
        else:
            nodes = _chink_rule(nodes, regex, clause.label, created)
    return nodes


def _is_created(node, created):
    return any(node is c for c in created)


def _chunk_rule(nodes, regex, label, created):
    out = []
    run = []  # consecutive matchable nodes
    def flush():
        if not run:
            return
        tags = [n.label() if isinstance(n, Tree) else n[1] for n in run]
        pos = 0
        for a, b in _find_matches(tags, regex):
            out.extend(run[pos:a])
            chunk = Tree(label, run[a:b])
            created.append(chunk)
            out.append(chunk)
            pos = b
        out.extend(run[pos:])
        run.clear()

    for node in nodes:
        if isinstance(node, Tree) and _is_created(node, created):
            flush()
            out.append(node)
        else:
            run.append(node)
    flush()
    return out


def _chink_rule(nodes, regex, label, created):
    out = []
    for node in nodes:
        if not (isinstance(node, Tree) and _is_created(node, created)):
            out.append(node)
            continue
        children = list(node)
        chinked = [False] * len(children)
        i = 0
        while i < len(children):
            if isinstance(children[i], Tree):
                i += 1
                continue
            j = i
            while j < len(children) and not isinstance(children[j], Tree):
                j += 1
            for a, b in _find_matches([children[k][1] for k in range(i, j)], regex):
                for k in range(i + a, i + b):
                    chinked[k] = True
            i = j
        if not any(chinked):
            out.append(node)
            continue
        group = []
        def flush_group():
            if group:
                piece = Tree(node.label(), list(group))
                created.append(piece)
                out.append(piece)
                group.clear()
        for child, removed in zip(children, chinked):
            if removed:
                flush_group()
                out.append(child)
            else:
                group.append(child)
        flush_group()
    return out


# ------------------------------------------------------------- the parser
# spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452
# spec: N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460
# spec: N-000228 N-000229 N-000230 N-000232 N-000233 N-000234 N-000235
# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242
# spec: N-000243 N-000244 N-000245 N-000246 N-000247 N-000248 N-000249
# spec: N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256
class RegexpParser:
    """Chunk parser over a chunk grammar (text, or a list of stages)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and grammar and all(
            isinstance(g, (str, RegexpParser)) for g in grammar
        ):
            self._clauses = []
            for stage in grammar:
                if isinstance(stage, RegexpParser):
                    self._clauses.extend(stage._clauses)
                else:
                    self._clauses.extend(_parse_grammar(stage))
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        nodes = []
        for pair in tagged:
            if not (isinstance(pair, (list, tuple)) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            nodes.append((pair[0], pair[1]))
        for clause in self._clauses:
            nodes = _apply_clause(nodes, clause)
        return Tree(ROOT_LABEL, nodes)


# spec: N-000231 N-000257
def ne_chunk(tagged_tokens):
    """Named-entity chunking. Requires the packaged chunker model and English wordlist."""
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    for resource in (_data.NE_CHUNKER, _data.WORDS):
        if not _data.is_visible(resource):
            raise LookupError("named-entity chunking needs %r on lingora.data.path" % resource)
    raise NotImplementedError("the packaged named-entity model format is not implemented in this build")
