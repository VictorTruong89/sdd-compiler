"""Parsers over a context-free grammar (FP-05)."""
# spec: 
# spec: N-000260 N-000261 N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000276 N-000292 N-000293 N-000294 N-000295
from ..grammar import CFG, Nonterminal
from ..tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for token in tokens:
        if token not in known:
            raise ValueError("token %r is not produced by any production" % token)
    return list(tokens)


def _is_terminal(symbol):
    return isinstance(symbol, str) and not isinstance(symbol, Nonterminal)


class ChartParser:
    """Exhaustive parser: every parse tree the grammar assigns to the tokens.

    The span table is a least fixpoint, so empty productions and cycles are
    handled; trees are enumerated from it, cutting cycles through a symbol
    already being expanded on the same span.
    """

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
    # spec: N-000292 N-000293 N-000294 N-000295
    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        n = len(tokens)
        derives = self._span_table(tokens)
        start = self._grammar.start()
        results = []
        if (start, 0, n) in derives:
            results = list(self._trees(start, 0, n, tokens, derives, frozenset()))
        return iter(results)

    def _span_table(self, tokens):
        n = len(tokens)
        derives = set()  # (symbol, i, j)
        changed = True
        prods = self._grammar.productions()
        while changed:
            changed = False
            for p in prods:
                for i in range(n + 1):
                    for j in range(i, n + 1):
                        key = (p.lhs(), i, j)
                        if key in derives:
                            continue
                        if self._rhs_matches(p.rhs(), 0, i, j, tokens, derives):
                            derives.add(key)
                            changed = True
        return derives

    def _rhs_matches(self, rhs, k, i, j, tokens, derives):
        if k == len(rhs):
            return i == j
        sym = rhs[k]
        if _is_terminal(sym):
            return i < j and tokens[i] == sym and self._rhs_matches(rhs, k + 1, i + 1, j, tokens, derives)
        for m in range(i, j + 1):
            if (sym, i, m) in derives and self._rhs_matches(rhs, k + 1, m, j, tokens, derives):
                return True
        return False

    def _trees(self, sym, i, j, tokens, derives, active):
        key = (sym, i, j)
        if key in active:
            return
        active = active | {key}
        for p in self._grammar.productions(sym):
            for children in self._children(p.rhs(), 0, i, j, tokens, derives, active):
                yield Tree(str(sym), children)

    def _children(self, rhs, k, i, j, tokens, derives, active):
        if k == len(rhs):
            if i == j:
                yield []
            return
        sym = rhs[k]
        if _is_terminal(sym):
            if i < j and tokens[i] == sym:
                for rest in self._children(rhs, k + 1, i + 1, j, tokens, derives, active):
                    yield [sym] + rest
            return
        for m in range(i, j + 1):
            if (sym, i, m) not in derives:
                continue
            if not self._rhs_matches(rhs, k + 1, m, j, tokens, derives):
                continue
            for sub in self._trees(sym, i, m, tokens, derives, active):
                for rest in self._children(rhs, k + 1, m, j, tokens, derives, active):
                    yield [sub] + rest


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    # spec: N-000272 N-000273 N-000274 N-000275
    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        start = self._grammar.start()
        prods = self._grammar.productions()
        stack = []  # items: (symbol, tree)
        pos = 0
        empty_reduced_at = set()
        while True:
            reduced = False
            for p in prods:
                rhs = p.rhs()
                if not rhs or len(rhs) > len(stack):
                    continue
                top = stack[len(stack) - len(rhs):]
                if all(_same(sym, item[0]) for sym, item in zip(rhs, top)):
                    children = [item[1] for item in top]
                    del stack[len(stack) - len(rhs):]
                    stack.append((p.lhs(), Tree(str(p.lhs()), children)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append((tokens[pos], tokens[pos]))
                pos += 1
                continue
            # input exhausted: allow one pass of empty productions at this stack depth
            key = len(stack)
            if key not in empty_reduced_at:
                empty_reduced_at.add(key)
                empties = [p for p in prods if not p.rhs()]
                if empties:
                    p = empties[0]
                    stack.append((p.lhs(), Tree(str(p.lhs()), [])))
                    continue
            break
        if len(stack) == 1 and _same(start, stack[0][0]) and not _is_terminal(stack[0][0]):
            return iter([stack[0][1]])
        return iter([])


def _same(sym, item_sym):
    if _is_terminal(sym):
        return _is_terminal(item_sym) and sym == item_sym
    return (not _is_terminal(item_sym)) and sym == item_sym
