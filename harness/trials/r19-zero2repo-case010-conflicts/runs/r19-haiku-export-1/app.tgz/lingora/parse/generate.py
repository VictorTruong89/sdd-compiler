"""Sentence generation from a context-free grammar (FP-05)."""
# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480
from ..grammar import Nonterminal

__all__ = ["generate"]


def _is_terminal(symbol):
    return isinstance(symbol, str) and not isinstance(symbol, Nonterminal)


# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480
def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal strings) derived from ``start``.

    Expansion is leftmost, productions in written order. ``depth`` bounds the
    nesting of expanded nonterminals; ``n`` bounds how many sentences are yielded.
    """
    from ..grammar import CFG

    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool)):
        raise TypeError("depth must be an int or None")
    if n is not None and (not isinstance(n, int) or isinstance(n, bool)):
        raise TypeError("n must be an int or None")
    if start is None:
        start = grammar.start()
    elif not isinstance(start, (str, Nonterminal)):
        raise TypeError("start must be a symbol or None")
    if isinstance(start, str) and not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    return _generate(grammar, start, depth, n)


def _generate(grammar, start, depth, n):
    count = 0
    # stack of pending items: (symbol, level) where level is the nesting depth
    stack0 = [(start, 1)]
    stack = [(stack0, [])]
    while stack:
        pending, out = stack.pop()
        if not pending:
            yield list(out)
            count += 1
            if n is not None and count >= n:
                return
            continue
        sym, level = pending[0]
        rest = pending[1:]
        if _is_terminal(sym):
            stack.append((rest, out + [sym]))
            continue
        if depth is not None and level > depth:
            continue
        # push alternatives in reverse so they are popped in written order
        alternatives = grammar.productions(sym)
        for p in reversed(alternatives):
            expanded = [(s, level + 1) for s in p.rhs()]
            stack.append((expanded + rest, out))
