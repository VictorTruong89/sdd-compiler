"""Constituent trees and bracketed tree text (FP-05)."""
# spec: N-000281 N-000282 N-000283 N-000284 N-000288 N-000289 N-000290 N-000291
import re

__all__ = ["Tree"]


class Tree:
    """A labelled ordered tree. ``children`` is a list of leaves (str) or Trees."""

    # spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of children, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __iter__(self):
        return iter(self._children)

    def __getitem__(self, index):
        return self._children[index]

    # spec: N-000285
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    # spec: N-000489 N-000286
    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos]
            pos += 1
            children = []
            while pos < len(tokens) and tokens[pos] != ")":
                if tokens[pos] == "(":
                    children.append(parse_node())
                else:
                    children.append(tokens[pos])
                    pos += 1
            if pos >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            pos += 1  # ')'
            return cls(label, children)

        tree = parse_node()
        if pos != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree

    # spec: N-000490 N-000491 N-000287
    def pformat(self, indent=0, width=72):
        flat = self._flat()
        if indent + len(flat) <= width or not any(isinstance(c, Tree) for c in self._children):
            return " " * indent + flat
        lines = [" " * indent + "(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child.pformat(indent + 2, width))
            else:
                lines.append(" " * (indent + 2) + str(child))
        lines[-1] += ")"
        return "\n".join(lines)

    def _flat(self):
        parts = []
        for child in self._children:
            parts.append(child._flat() if isinstance(child, Tree) else str(child))
        if not parts:
            return "(%s)" % self._label
        return "(%s %s)" % (self._label, " ".join(parts))
