"""Context-free grammars (FP-05)."""
# spec: N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470 N-000471 N-000472 N-000473 N-000474 N-000475 N-000476
import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    """A nonterminal symbol; ``str()`` gives its name. Terminals are plain ``str``."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("nonterminal", self._name))


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        rhs = " ".join(
            repr(s) if isinstance(s, str) and not isinstance(s, Nonterminal) else str(s)
            for s in self._rhs
        )
        return "%s -> %s" % (self._lhs, rhs)


_TOKEN_RE = re.compile(r"""\s*(?:(->|\||"[^"]*"|'[^']*'|[^\s|'"]+))""")


def _parse_production_line(line):
    if "->" not in line:
        raise ValueError("production must be written 'LHS -> RHS': %r" % line)
    lhs_text, rhs_text = line.split("->", 1)
    lhs_text = lhs_text.strip()
    if not re.fullmatch(r"[A-Za-z_][\w\-]*", lhs_text):
        raise ValueError("bad left-hand side in production: %r" % line)
    lhs = Nonterminal(lhs_text)
    alternatives = [[]]
    pos = 0
    rhs_text = rhs_text.rstrip()
    while pos < len(rhs_text):
        m = _TOKEN_RE.match(rhs_text, pos)
        if not m or m.end() == pos:
            if rhs_text[pos:].strip() == "":
                break
            raise ValueError("bad right-hand side in production: %r" % line)
        pos = m.end()
        tok = m.group(1)
        if tok == "|":
            alternatives.append([])
        elif tok[0] in "\"'" and len(tok) >= 2:
            alternatives[-1].append(tok[1:-1])
        elif tok == "->":
            raise ValueError("unexpected '->' in production: %r" % line)
        else:
            if not re.fullmatch(r"[A-Za-z_][\w\-]*", tok):
                raise ValueError("bad symbol %r in production: %r" % (tok, line))
            alternatives[-1].append(Nonterminal(tok))
    return [Production(lhs, alt) for alt in alternatives]


class CFG:
    """A context-free grammar built from production text."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            productions.extend(_parse_production_line(line))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def nonterminals(self):
        return {p.lhs() for p in self._productions}

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str) and not isinstance(s, Nonterminal):
                    out.add(s)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
