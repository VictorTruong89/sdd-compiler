"""Packaged resources: the directory list and the finder.

``path`` is a mutable list of directories searched for packaged resources.
Callers may change its contents in place; every lookup reads it afresh.
Importing the package downloads nothing.
"""
# spec: N-000349 N-000386 N-000387 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402
import os

# spec: N-000385 N-000388 — initial contents: directories from the LINGORA_DATA
# environment variable (os.pathsep separated). Empty when unset.
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]

# Resource names, relative to a directory on ``path``.
# spec: N-000389 N-000390 N-000391 N-000392 N-000393 N-000394 N-000395 N-000396
PUNKT = "tokenizers/punkt_tab/{language}"
TAGGER_ENG = "taggers/averaged_perceptron_tagger_eng"
TAGGER_RUS = "taggers/averaged_perceptron_tagger_rus"
UNIVERSAL_TAGSET = "taggers/universal_tagset"
NE_CHUNKER = "chunkers/maxent_ne_chunker_tab/english_ace_multiclass"
WORDS = "corpora/words"
STOPWORDS = "corpora/stopwords/{language}"
WORDNET = "corpora/wordnet"


def find(resource):
    """Return the absolute path of ``resource`` under the first visible directory.

    Raises ``LookupError`` when no directory on ``path`` holds it.
    """
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    raise LookupError(
        "packaged resource %r is not visible on lingora.data.path" % resource
    )


def is_visible(resource):
    """True when ``resource`` can be found on ``path``."""
    try:
        find(resource)
    except LookupError:
        return False
    return True


def read_lines(resource_file):
    """Read a UTF-8 text file; each line without its terminator is one entry."""
    with open(resource_file, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]
