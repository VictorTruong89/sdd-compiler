"""Command line: ``lingora tokenize`` (FP-01)."""
# spec: N-000083 N-000084 N-000085 N-000134 N-000135 N-000139 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
import sys

from . import tokenize as _tokenize
from ._punkt import load_params

__all__ = ["cli"]

_USAGE = "usage: lingora tokenize [--language LANG] [--delimiter TEXT] [--encoding NAME]"


class _UsageError(Exception):
    pass


class _Group:
    """A command group with a click-style ``main(args, standalone_mode)`` entry."""

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        try:
            code = self._run(list(args))
        except _UsageError as exc:
            sys.stderr.write("%s\nlingora: error: %s\n" % (_USAGE, exc))
            code = 2
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args:
            raise _UsageError("a command is required (tokenize)")
        command, rest = args[0], args[1:]
        if command != "tokenize":
            raise _UsageError("no such command %r" % command)
        options = {"--language": "english", "--delimiter": " ", "--encoding": "utf-8"}
        i = 0
        while i < len(rest):
            arg = rest[i]
            name, eq, value = arg.partition("=")
            if name not in options:
                raise _UsageError("unknown option %r" % arg)
            if not eq:
                if i + 1 >= len(rest):
                    raise _UsageError("option %s needs a value" % name)
                value = rest[i + 1]
                i += 1
            options[name] = value
            i += 1
        return _tokenize_command(options)


def _read_stdin(encoding):
    """Read standard input as text, decoding bytes with ``encoding`` when a byte stream exists."""
    buffer = getattr(sys.stdin, "buffer", None)
    if buffer is not None:
        return buffer.read().decode(encoding).splitlines()
    return [line.rstrip("\r\n") for line in sys.stdin]


def _tokenize_command(options):
    language = options["--language"]
    delimiter = options["--delimiter"]
    encoding = options["--encoding"]
    stdout = sys.stdout
    try:
        # Sentence splitting is part of this path: fail before any output if the model is missing.
        load_params(language)
    except (LookupError, ValueError) as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return 1
    try:
        lines = _read_stdin(encoding)
    except (LookupError, UnicodeDecodeError) as exc:
        sys.stderr.write("lingora tokenize: cannot read input: %s\n" % exc)
        return 1
    out_lines = []
    for line in lines:
        try:
            tokens = _tokenize.word_tokenize(line, language=language)
        except (LookupError, ValueError) as exc:
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        out_lines.append(delimiter.join(tokens))
    for line in out_lines:
        stdout.write(line + "\n")
    stdout.flush()
    return 0


cli = _Group()
