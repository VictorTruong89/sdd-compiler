"""BLEU.  # spec: N-000499 N-000500"""
import math
from collections import Counter
from fractions import Fraction


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon

    def method0(self, p_n, references, hypothesis, hyp_len):
        return list(p_n)

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p
                for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [Fraction(p.numerator + 1, p.denominator + 1) if i != 0 else p
                for i, p in enumerate(p_n)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    num = sum(clipped.values())
    den = max(1, sum(counts.values()))
    return Fraction(num, den)


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    # spec: N-000511 .. N-000517
    if isinstance(references, (str, bytes)) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    for r in references:
        if isinstance(r, (str, bytes)) or not isinstance(r, (list, tuple)):
            raise TypeError("each reference must be a list of str tokens")
    if isinstance(hypothesis, (str, bytes)) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a list of str tokens")
    try:
        weights = list(weights)
    except TypeError:
        raise TypeError("weights must be a sequence of numbers")
    if not weights or any(isinstance(w, bool) or not isinstance(w, (int, float)) for w in weights):
        raise TypeError("weights must be a sequence of numbers")
    if not references:
        raise ValueError("at least one reference is required")
    p_n = [_modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    hyp_len = len(hypothesis)
    if p_n[0].numerator == 0:
        return 0.0
    ref_lens = (len(r) for r in references)
    closest = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > closest:
        bp = 1.0
    elif hyp_len == 0:
        bp = 0.0
    else:
        bp = math.exp(1 - closest / hyp_len)
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis,
                                 hyp_len=hyp_len)
    if any(p == 0 for p in p_n):
        return 0.0
    s = sum(w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(s)
