"""Classifiers.  # spec: N-000492 N-000493"""
import math
from collections import Counter, defaultdict


def _check_labeled(labeled):
    if isinstance(labeled, (str, bytes)) or not hasattr(labeled, "__iter__"):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    out = []
    for item in labeled:
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            raise ValueError("expected (featureset, label) pairs")
        fs, label = item
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
        out.append((fs, label))
    return out


class DictProbDist:
    # spec: N-000496 N-000497 N-000307 N-000308
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, sample):
        return float(self._probs.get(sample, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda s: self._probs[s])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


ProbDist = DictProbDist


class NaiveBayesClassifier:
    def __init__(self, label_counts, feature_counts, feature_values, fnames, total):
        self._label_counts = label_counts
        self._labels = list(label_counts.keys())
        self._feature_counts = feature_counts  # (label, fname) -> Counter
        self._feature_values = feature_values
        self._fnames = fnames
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        fcounts = defaultdict(Counter)
        fvalues = defaultdict(set)
        fnames = set()
        for fs, label in data:
            label_counts[label] += 1
            for fname, fval in fs.items():
                fcounts[(label, fname)][fval] += 1
                fvalues[fname].add(fval)
                fnames.add(fname)
        n = len(data)
        for label in label_counts:
            for fname in fnames:
                c = fcounts[(label, fname)]
                seen = sum(c.values())
                if n - seen or True:
                    c[None] += label_counts[label] - seen
                fvalues[fname].add(None)
        return cls(label_counts, dict(fcounts), dict(fvalues), fnames, n)

    def labels(self):
        return list(self._labels)

    def _logprobs(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        fs = {k: v for k, v in featureset.items() if k in self._fnames}
        nlab = len(self._labels)
        logp = {}
        for label in self._labels:
            lp = math.log((self._label_counts[label] + 0.5) / (self._total + nlab * 0.5))
            for fname, fval in fs.items():
                c = self._feature_counts[(label, fname)]
                bins = len(self._feature_values[fname])
                N = sum(c.values())
                lp += math.log((c.get(fval, 0) + 0.5) / (N + bins * 0.5))
            logp[label] = lp
        return logp

    def prob_classify(self, featureset):
        logp = self._logprobs(featureset)
        if not logp:
            return DictProbDist({})
        m = max(logp.values())
        total = m + math.log(sum(math.exp(v - m) for v in logp.values()))
        return DictProbDist({l: math.exp(v - total) for l, v in logp.items()})

    def classify(self, featureset):
        logp = self._logprobs(featureset)
        return max(self._labels, key=lambda l: logp[l])


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    @staticmethod
    def _majority(labels):
        return Counter(labels).most_common(1)[0][0]

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=None, depth_cutoff=100,
              support_cutoff=None, **kwargs):
        data = _check_labeled(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on an empty list")
        fnames = []
        seen = set()
        for fs, _ in data:
            for k in fs:
                if k not in seen:
                    seen.add(k)
                    fnames.append(k)
        return cls._build(data, fnames, depth_cutoff or 100, support_cutoff)

    @classmethod
    def _build(cls, data, fnames, depth, support_cutoff):
        labels = [l for _, l in data]
        majority = cls._majority(labels)
        if len(set(labels)) == 1 or not fnames or depth <= 0 or \
                (support_cutoff and len(data) < support_cutoff):
            return cls(majority)
        best = None
        for f in fnames:
            groups = defaultdict(list)
            for fs, l in data:
                groups[fs.get(f)].append(l)
            errors = sum(len(g) - Counter(g).most_common(1)[0][1] for g in groups.values())
            if best is None or errors < best[0]:
                best = (errors, f)
        f = best[1]
        groups = defaultdict(list)
        for ex in data:
            groups[ex[0].get(f)].append(ex)
        rest = [x for x in fnames if x != f]
        decisions = {v: cls._build(g, rest, depth - 1, support_cutoff) for v, g in groups.items()}
        return cls(None, f, decisions, cls(majority))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        if self._fname is None:
            return self._label
        v = featureset.get(self._fname)
        child = self._decisions.get(v)
        if child is None:
            child = self._default
        return child.classify(featureset)


def accuracy(classifier, gold):
    # spec: classifier accuracy -- fraction of gold examples labelled correctly
    gold = list(gold)
    if not gold:
        raise ZeroDivisionError("cannot compute accuracy on an empty gold list")
    correct = sum(1 for fs, l in gold if classifier.classify(fs) == l)
    return correct / len(gold)
