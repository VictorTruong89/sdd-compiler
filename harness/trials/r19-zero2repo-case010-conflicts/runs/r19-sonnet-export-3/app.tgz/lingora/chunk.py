"""Chunking.  # spec: N-000446 N-000447"""
import os
import re

from . import data
from .tree import Tree

_TAG_CHAR = r"[^{}<>]"


def _tag_pattern_to_re(pattern):
    pattern = re.sub(r"\s", "", pattern)
    out = []
    i = 0
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch == "<":
            j = pattern.find(">", i)
            if j < 0:
                raise ValueError("Bad tag pattern: %r" % pattern)
            content = pattern[i + 1:j]
            conv = []
            k = 0
            while k < len(content):
                c = content[k]
                if c == "\\" and k + 1 < len(content):
                    conv.append(content[k:k + 2])
                    k += 2
                    continue
                conv.append(_TAG_CHAR if c == "." else c)
                k += 1
            out.append("(?:<(?:%s)>)" % "".join(conv))
            i = j + 1
        elif ch in "<>{}":
            raise ValueError("Bad tag pattern: %r" % pattern)
        else:
            out.append(ch)
            i += 1
    rx = "".join(out)
    try:
        re.compile(rx)
    except re.error:
        raise ValueError("Bad tag pattern: %r" % pattern)
    return rx


class ChunkRule:
    def __init__(self, tag_pattern):
        self.pattern = tag_pattern
        self._re = re.compile("(?P<chunk>%s)(?=[^\\}]*(\\{|$))" % _tag_pattern_to_re(tag_pattern))

    def apply(self, s):
        return self._re.sub(r"{\g<chunk>}", s)


class ChinkRule:
    def __init__(self, tag_pattern):
        self.pattern = tag_pattern
        self._re = re.compile("(?P<chink>%s)(?=[^\\{]*\\})" % _tag_pattern_to_re(tag_pattern))

    def apply(self, s):
        return self._re.sub(r"}\g<chink>{", s)


class RegexpChunkParser:
    """One stage (clause) of a chunk grammar."""

    def __init__(self, rules, chunk_label="NP", root_label="S"):
        self._rules = list(rules)
        self._label = chunk_label
        self._root = root_label

    def _unit_tag(self, unit):
        if isinstance(unit, Tree):
            return str(unit.label())
        return str(unit[1])

    def parse(self, units, root_label=None):
        """`units`: list of (token, tag) pairs and/or Trees. Returns a Tree."""
        root = root_label if root_label is not None else self._root
        units = list(units)
        s = "".join("<%s>" % self._unit_tag(u) for u in units)
        for rule in self._rules:
            s = rule.apply(s)
            s = s.replace("{}", "")
        children = []
        cur = None
        idx = 0
        for m in re.finditer(r"[{}]|<[^{}<>]*>", s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    children.append(Tree(self._label, cur))
                cur = None
            else:
                u = units[idx]
                idx += 1
                (cur if cur is not None else children).append(u)
        return Tree(root, children)


_CLAUSE_RE = re.compile(r"^\s*([^\s:{}<>]+)\s*:\s*(.*)$")


def _parse_rule(text):
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        return ChunkRule(text[1:-1])
    if text.startswith("}") and text.endswith("{"):
        return ChinkRule(text[1:-1])
    raise ValueError("Illegal chunk rule: %r" % text)


def _parse_grammar(text, root_label):
    stages = []
    label = None
    rules = []
    for raw in text.split("\n"):
        line = re.sub(r"#.*", "", raw).rstrip()
        if not line.strip():
            continue
        if line[0] not in " \t":
            m = _CLAUSE_RE.match(line)
            if not m:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            if label is not None:
                stages.append(RegexpChunkParser(rules, label, root_label))
            label = m.group(1)
            rules = []
            rest = m.group(2).strip()
            if rest:
                rules.append(_parse_rule(rest))
        else:
            if label is None:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            rules.append(_parse_rule(line))
    if label is not None:
        stages.append(RegexpChunkParser(rules, label, root_label))
    return stages


def _check_tagged(tagged):
    if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
        raise TypeError("tagged tokens must be a list of (token, tag) pairs")
    out = []
    for p in tagged:
        if isinstance(p, (str, bytes)) or not isinstance(p, (tuple, list)) or len(p) != 2:
            raise ValueError("tagged tokens must be (token, tag) pairs, got %r" % (p,))
        out.append((p[0], p[1]))
    return out


class RegexpParser:
    # spec: N-000449 N-000450 N-000451 N-000453 N-000454 N-000455 N-000456
    def __init__(self, grammar, root_label="S", loop=1):
        self._root = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar, root_label)
        elif isinstance(grammar, (list, tuple)):
            for st in grammar:
                if not isinstance(st, RegexpChunkParser):
                    raise TypeError("grammar list must hold chunk-parser stages")
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages, not %s"
                            % type(grammar).__name__)

    def parse(self, tagged, trace=0):
        # spec: N-000448 N-000458 N-000459 N-000460
        units = _check_tagged(tagged)
        tree = Tree(self._root, units)
        for _ in range(max(1, self._loop)):
            for stage in self._stages:
                tree = stage.parse(list(tree), self._root)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    # spec: N-000452 N-000257
    tagged = _check_tagged(tagged_tokens)
    model = data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    if not os.path.isdir(model):
        raise LookupError("named-entity chunker model is not installed")
    data.find("corpora/words")
    # The trained maxent model's results are outside the specification; group runs of
    # proper-noun tokens as a simple named-entity approximation.
    children = []
    run = []
    for w, t in tagged:
        if t in ("NNP", "NNPS"):
            run.append((w, t))
        else:
            if run:
                children.append(Tree("NE" if binary else "ORGANIZATION", run))
                run = []
            children.append((w, t))
    if run:
        children.append(Tree("NE" if binary else "ORGANIZATION", run))
    return Tree("S", children)
