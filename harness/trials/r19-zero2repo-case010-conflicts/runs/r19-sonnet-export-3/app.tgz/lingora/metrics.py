"""Evaluation metrics.  # spec: N-000498 N-000499 N-000500"""


def _isnum(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def accuracy(reference, test):
    # spec: N-000501 N-000502 (different lengths raise; see NOTES.md)
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if len(test) == 0:
        raise ZeroDivisionError("accuracy of empty lists is undefined")
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    # spec: N-000503 .. N-000506
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    if not _isnum(substitution_cost):
        raise TypeError("substitution_cost must be a number")
    len1, len2 = len(s1), len(s2)
    lev = [[j for j in range(len2 + 1)] if i == 0 else [i] + [0] * len2 for i in range(len1 + 1)]
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            c1, c2 = s1[i - 1], s2[j - 1]
            a = lev[i - 1][j] + 1
            b = lev[i][j - 1] + 1
            c = lev[i - 1][j - 1] + (substitution_cost if c1 != c2 else 0)
            d = c + 1
            if transpositions and i > 1 and j > 1:
                if s1[i - 2] == c2 and s2[j - 2] == c1:
                    d = lev[i - 2][j - 2] + 1
            lev[i][j] = min(a, b, c, d)
    return lev[len1][len2]


def jaccard_distance(label1, label2):
    # spec: N-000507
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("label1 and label2 must be sets")
    union = len(label1 | label2)
    if union == 0:
        raise ZeroDivisionError("jaccard distance of two empty sets is undefined")
    return (union - len(label1 & label2)) / union


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test should be sets")  # spec: N-000508 N-000509


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return None  # sets share no element: no number (N-000346)
    return 1.0 / (alpha / p + (1 - alpha) / r)
