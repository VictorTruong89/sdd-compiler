"""Context-free grammars.  # spec: N-000461"""
import re


class Nonterminal:
    # spec: N-000466 N-000467 N-000468
    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    def __hash__(self):
        return hash(self._symbol)

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    # spec: N-000469 N-000470 N-000471
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return any(isinstance(s, str) for s in self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [("%r" % s if isinstance(s, str) else str(s)) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([^\s'"|]+))""")


def _parse_rhs(text, lineno):
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN_RE.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("Unable to parse grammar line %d: %r" % (lineno, text))
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._terminals.add(s)

    @classmethod
    def fromstring(cls, input):
        # spec: N-000464 N-000465
        if isinstance(input, (list, tuple)):
            lines = list(input)
        elif isinstance(input, str):
            lines = input.split("\n")
        else:
            raise TypeError("grammar text must be a str")
        prods = []
        for no, raw in enumerate(lines, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("Unable to parse grammar line %d: %r" % (no, raw))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or re.search(r"[\s'\"|]", lhs_text):
                raise ValueError("Unable to parse grammar line %d: %r" % (no, raw))
            lhs = Nonterminal(lhs_text)
            for alt in _parse_rhs(rhs_text, no):
                prods.append(Production(lhs, alt))
        if not prods:
            raise ValueError("grammar has no productions")
        return cls(prods[0].lhs(), prods)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        out = self._productions
        if lhs is not None:
            if isinstance(lhs, str):
                lhs = Nonterminal(lhs)
            out = [p for p in out if p.lhs() == lhs]
        if rhs is not None:
            out = [p for p in out if p.rhs() and p.rhs()[0] == rhs]
        return list(out)

    def terminals(self):
        return set(self._terminals)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n%s" % (
            len(self._productions), self._start,
            "\n".join("    %s" % p for p in self._productions))

    __repr__ = lambda self: "<Grammar with %d productions>" % len(self._productions)  # noqa: E731
