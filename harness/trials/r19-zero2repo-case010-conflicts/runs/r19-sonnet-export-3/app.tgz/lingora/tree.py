"""Constituent trees.  # spec: N-000481 N-000482"""


class Tree(list):
    # spec: N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or children is None:
            raise TypeError("Tree children must be a list of children, not %s"
                            % type(children).__name__)
        try:
            kids = list(children)
        except TypeError:
            raise TypeError("Tree children must be a list of children")
        list.__init__(self, kids)
        self._label = label

    __hash__ = None

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def height(self):
        h = 0
        for c in self:
            if isinstance(c, Tree):
                h = max(h, c.height())
        return h + 1

    def subtrees(self):
        yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees()

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def _flat(self, nodesep, parens):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat(nodesep, parens))
            elif isinstance(c, tuple) and len(c) == 2:
                parts.append("%s/%s" % (c[0], c[1]))
            else:
                parts.append(str(c))
        return "%s%s%s %s%s" % (parens[0], self._label, nodesep, " ".join(parts), parens[1]) \
            if parts else "%s%s%s%s" % (parens[0], self._label, nodesep, parens[1])

    def pformat(self, margin=70, indent=0, nodesep="", parens="()"):
        # spec: N-000490 N-000491 (layout is the implementer's choice)
        flat = self._flat(nodesep, parens)
        if len(flat) + indent <= margin:
            return flat
        s = "%s%s%s" % (parens[0], self._label, nodesep)
        for c in self:
            s += "\n" + " " * (indent + 2)
            if isinstance(c, Tree):
                s += c.pformat(margin, indent + 2, nodesep, parens)
            elif isinstance(c, tuple) and len(c) == 2:
                s += "%s/%s" % (c[0], c[1])
            else:
                s += str(c)
        return s + parens[1]

    @classmethod
    def fromstring(cls, s, brackets="()"):
        # spec: N-000489
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        op, cl = brackets
        pos = 0
        n = len(s)

        def skip_ws(p):
            while p < n and s[p].isspace():
                p += 1
            return p

        def parse_node(p):
            # s[p] == op
            p += 1
            p = skip_ws(p)
            start = p
            while p < n and not s[p].isspace() and s[p] not in (op, cl):
                p += 1
            label = s[start:p]
            kids = []
            while True:
                p = skip_ws(p)
                if p >= n:
                    raise ValueError("unbalanced brackets in tree text")
                ch = s[p]
                if ch == cl:
                    return cls(label, kids), p + 1
                if ch == op:
                    node, p = parse_node(p)
                    kids.append(node)
                else:
                    st = p
                    while p < n and not s[p].isspace() and s[p] not in (op, cl):
                        p += 1
                    kids.append(s[st:p])

        pos = skip_ws(pos)
        if pos >= n or s[pos] != op:
            raise ValueError("tree text must start with %r" % op)
        node, pos = parse_node(pos)
        pos = skip_ws(pos)
        if pos != n:
            raise ValueError("unexpected text after tree")
        return node
