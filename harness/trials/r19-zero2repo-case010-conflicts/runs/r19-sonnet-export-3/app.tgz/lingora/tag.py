"""Part-of-speech taggers.  # spec: N-000433 N-000434"""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)  # N-000442


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self]
        self.backoff = backoff
        if backoff is not None:
            self._taggers.extend(backoff._taggers)

    def tag(self, tokens):
        # spec: N-000196 N-000197 N-000205 N-000206
        _check_tokens(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    # spec: N-000198
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    # spec: N-000202 N-000203 N-000204 N-000438
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        if isinstance(regexps, (str, bytes)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for regexp, tag in self._regexps:
            if regexp.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = context_to_tag if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        return self._context_to_tag.get(self.context(tokens, index, history))

    def _train(self, tagged_corpus):
        fd = defaultdict(Counter)
        for sentence in tagged_corpus:
            tokens, tags = [w for w, _ in sentence], [t for _, t in sentence]
            for index in range(len(tokens)):
                ctx = self.context(tokens, index, tags[:index])
                if ctx is None:
                    continue
                fd[ctx][tags[index]] += 1
        # spec: N-000199 N-000200 N-000201 -- most frequent tag; ties go to the first seen
        for ctx, counter in fd.items():
            self._context_to_tag[ctx] = counter.most_common(1)[0][0]


class UnigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None):
        ContextTagger.__init__(self, dict(model) if model else {}, backoff)
        if train:
            if isinstance(train, (str, bytes)):
                raise TypeError("train must be a list of tagged sentences")
            self._train(train)

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None):
        ContextTagger.__init__(self, dict(model) if model else {}, backoff)
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        prev = history[index - 1] if index >= 1 else None
        return (prev, tokens[index])


class TrigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None):
        ContextTagger.__init__(self, dict(model) if model else {}, backoff)
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        t1 = history[index - 2] if index >= 2 else None
        t2 = history[index - 1] if index >= 1 else None
        return (t1, t2, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None):
        ContextTagger.__init__(self, dict(model) if model else {}, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[: self._affix_length]
        return token[self._affix_length:]


# ------------------------------------------------------------------ perceptron
class AveragedPerceptron:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = set(classes)

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


class PerceptronTagger:
    # spec: N-000207 .. N-000214
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, lang):
        base = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        prefix = os.path.join(base, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(prefix + ".weights.json", encoding="utf-8") as f:
                weights = json.load(f)
            with open(prefix + ".tagdict.json", encoding="utf-8") as f:
                self.tagdict = json.load(f)
            with open(prefix + ".classes.json", encoding="utf-8") as f:
                classes = json.load(f)
        except OSError as e:
            raise LookupError("tagger model for %r is incomplete: %s" % (lang, e))
        self.model = AveragedPerceptron(weights, classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def tag(self, tokens):
        prev, prev2 = self.START
        output = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self.model.predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output

    def _features(self, i, word, context, prev, prev2):
        i += len(self.START)
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features


_RU_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "SPRO": "PRON", "APRO": "DET",
    "ADVPRO": "ADV", "NUM": "NUM", "ANUM": "ADJ", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
    "INTJ": "X", "COM": "X", "NONLEX": ".",
}


def _load_en_ptb_map():
    base = data.find("taggers/universal_tagset")
    p = os.path.join(base, "en-ptb.map")
    if not os.path.isfile(p):
        raise LookupError("universal tagset table en-ptb.map is not installed")
    table = {}
    for line in data.read_lines(p):
        parts = line.split("\t")
        if len(parts) >= 2:
            table[parts[0]] = parts[1]
    return table


def pos_tag(tokens, tagset=None, lang="eng"):
    # spec: N-000440 N-000441 N-000442 N-000443 N-000444 N-000445
    _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("Currently, lingora pos_tag only supports English and Russian "
                         "(i.e. lang='eng' or lang='rus')")
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _load_en_ptb_map()
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, _RU_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged]
    return tagged
