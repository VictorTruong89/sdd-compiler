"""Command line.  # spec: N-000414 .. N-000420"""
import sys


class _Exit(Exception):
    def __init__(self, code):
        Exception.__init__(self, code)
        self.code = code


class Command:
    def __init__(self, name, func):
        self.name = name
        self.func = func


class Group:
    def __init__(self, name):
        self.name = name
        self.commands = {}

    def command(self, name=None):
        def deco(func):
            self.commands[name or func.__name__] = Command(name or func.__name__, func)
            return func
        return deco

    def _dispatch(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  tokenize\n")
            return 0
        cmd = self.commands.get(args[0])
        if cmd is None:
            sys.stderr.write("Error: No such command %r.\n" % args[0])
            return 2
        return cmd.func(list(args[1:]))

    def main(self, args=None, standalone_mode=True, **kwargs):
        # spec: N-000417 N-000418
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if standalone_mode:
            try:
                code = self._dispatch(args)
            except SystemExit:
                raise
            except BaseException as e:  # noqa: BLE001
                sys.stderr.write("Error: %s\n" % (e,))
                code = 1
            sys.exit(code or 0)
        code = self._dispatch(args)
        if code:
            raise _Exit(code)
        return None

    __call__ = main


cli = Group("lingora")


@cli.command("tokenize")
def _tokenize(args):
    from .tokenize import word_tokenize
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-l", "--language") and i + 1 < len(args):
            language = args[i + 1]
            i += 2
        elif a.startswith("--language="):
            language = a.split("=", 1)[1]
            i += 1
        elif a in ("-d", "--delimiter") and i + 1 < len(args):
            delimiter = args[i + 1]
            i += 2
        elif a.startswith("--delimiter="):
            delimiter = a.split("=", 1)[1]
            i += 1
        elif a in ("-e", "--encoding") and i + 1 < len(args):
            encoding = args[i + 1]
            i += 2
        elif a.startswith("--encoding="):
            encoding = a.split("=", 1)[1]
            i += 1
        else:
            sys.stderr.write("Error: unexpected argument %r\n" % a)
            return 2
    stdin = sys.stdin
    raw = getattr(stdin, "buffer", None)
    if raw is not None:
        import io
        stdin = io.TextIOWrapper(raw, encoding=encoding)
    out = sys.stdout
    for line in stdin:
        line = line.rstrip("\r\n")
        tokens = word_tokenize(line, language=language)  # raises if Punkt is missing
        out.write(delimiter.join(tokens) + "\n")
    out.flush()
    return 0


if __name__ == "__main__":
    cli.main()
