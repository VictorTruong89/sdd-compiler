"""Packaged-resource lookup.  # spec: N-000385 N-000386 N-000387 N-000388"""
import os

# spec: N-000385 -- mutable list of directory strings; contents may be replaced in place.
def _initial_path():
    out = []
    env = os.environ.get("LINGORA_DATA")
    if env:
        out.extend(p for p in env.split(os.pathsep) if p)
    out.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    out.append("/usr/share/lingora_data")
    out.append("/usr/local/share/lingora_data")
    return out


path = _initial_path()


def find(resource):
    """Return the filesystem path of `resource` found in a directory of `path`.

    Raises LookupError when it is not visible.  # spec: N-000386
    """
    for d in list(path):
        cand = os.path.join(str(d), *resource.strip("/").split("/"))
        if os.path.exists(cand):
            return cand
    raise LookupError("resource %r not found in data.path" % (resource,))


def exists(resource):
    try:
        find(resource)
        return True
    except LookupError:
        return False


def read_lines(filename):
    """Lines of a UTF-8 text file, each without its line terminator."""
    with open(filename, encoding="utf-8", newline="") as f:
        text = f.read()
    text = text.replace("\r\n", "\n")
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return lines
