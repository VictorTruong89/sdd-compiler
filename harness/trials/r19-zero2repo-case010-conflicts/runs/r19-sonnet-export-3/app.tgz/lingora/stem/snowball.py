"""Snowball stemmers.  # spec: N-000172 .. N-000177, N-000428 .. N-000431"""
import os

from .. import data
from .porter import PorterStemmer

LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
             "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
             "swedish")


def _regions(word, vowels, min_r1=0):
    """Return (r1_start, r2_start) as indices into word."""
    def after_nv(start):
        n = len(word)
        i = start
        while i < n and not (word[i] in vowels):
            i += 1
        while i < n and (word[i] in vowels):
            i += 1
        return min(i + 1, n) if i < n else n
    # first non-vowel following a vowel
    def region(start):
        n = len(word)
        i = start
        while i < n and word[i] not in vowels:
            i += 1
        while i < n and word[i] in vowels:
            i += 1
        # i now at first non-vowel after a vowel (or n)
        return i + 1 if i < n else n
    r1 = region(0)
    r1 = max(r1, min_r1) if r1 < len(word) or min_r1 else r1
    if r1 > len(word):
        r1 = len(word)
    r2 = region(r1) if r1 < len(word) else len(word)
    return r1, r2


def _longest(word, suffixes):
    best = ""
    for s in suffixes:
        if len(s) > len(best) and word.endswith(s):
            best = s
    return best


# ------------------------------------------------------------------ English
class _English:
    V = "aeiouy"
    DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    LI = "cdeghkmnrt"
    EXC1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
            "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
            "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
            "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    EXC2 = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")

    def _short_syl(self, w, i):
        # does a short syllable end at position i (exclusive end index)?
        V = self.V
        if i == 2:
            return w[0] in V and w[1] not in V
        if i >= 3:
            return (w[i - 3] not in V and w[i - 2] in V and w[i - 1] not in V
                    and w[i - 1] not in "wxY")
        return False

    def stem(self, word):
        if len(word) <= 2:
            return word
        if word in self.EXC1:
            return self.EXC1[word]
        V = self.V
        if word.startswith("'"):
            word = word[1:]
        if not word:
            return word
        w = list(word)
        if w[0] == "y":
            w[0] = "Y"
        for i in range(1, len(w)):
            if w[i] == "y" and w[i - 1] in V:
                w[i] = "Y"
        w = "".join(w)
        # regions
        def region(start):
            n = len(w)
            i = start
            while i < n and w[i] not in V:
                i += 1
            while i < n and w[i] in V:
                i += 1
            return min(i + 1, n) if i < n else n
        # note: region() above returns index after first non-vowel following a vowel
        def region_after_vowel(start):
            n = len(w)
            i = start
            while i < n and w[i] not in V:
                i += 1
            while i < n and w[i] in V:
                i += 1
            return i + 1 if i < n else n
        r1 = None
        for p in ("gener", "commun", "arsen"):
            if w.startswith(p):
                r1 = len(p)
                break
        if r1 is None:
            r1 = region_after_vowel(0)
        r2 = region_after_vowel(r1) if r1 < len(w) else len(w)

        # Step 0
        for s in ("'s'", "'s", "'"):
            if w.endswith(s):
                w = w[: -len(s)]
                break
        # Step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith("ied") or w.endswith("ies"):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith("us") or w.endswith("ss"):
            pass
        elif w.endswith("s"):
            if any(c in V for c in w[:-2]):
                w = w[:-1]
        if w in self.EXC2:
            return w.replace("Y", "y")
        # Step 1b
        suf = _longest(w, ("eedly", "eed", "ingly", "edly", "ing", "ed"))
        if suf in ("eed", "eedly"):
            if len(w) - len(suf) >= r1:
                w = w[: -len(suf)] + "ee"
        elif suf:
            stem = w[: -len(suf)]
            if any(c in V for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(self.DOUBLES):
                    w = w[:-1]
                elif r1 >= len(w) and self._short_word(w):
                    w += "e"
        # Step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in V:
            w = w[:-1] + "i"
        n = len(w)
        r1 = min(r1, n)
        r2 = min(r2, n)
        # Step 2
        suf = _longest(w, ("ization", "ational", "fulness", "ousness", "iveness", "tional",
                           "biliti", "lessli", "entli", "ation", "alism", "aliti", "ousli",
                           "iviti", "fulli", "enci", "anci", "abli", "izer", "ator", "alli",
                           "bli", "ogi", "li"))
        if suf and n - len(suf) >= r1:
            rep = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able",
                   "entli": "ent", "izer": "ize", "ization": "ize", "ational": "ate",
                   "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al", "alli": "al",
                   "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive",
                   "iviti": "ive", "biliti": "ble", "bli": "ble", "fulli": "ful",
                   "lessli": "less"}
            stem = w[: -len(suf)]
            if suf == "ogi":
                if stem.endswith("l"):
                    w = stem + "og"
            elif suf == "li":
                if stem and stem[-1] in self.LI:
                    w = stem
            else:
                w = stem + rep[suf]
        n = len(w)
        # Step 3
        suf = _longest(w, ("ational", "tional", "alize", "icate", "iciti", "ative", "ical",
                           "ness", "ful"))
        if suf and n - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf == "ative":
                if n - len(suf) >= r2:
                    w = stem
            else:
                rep = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic",
                       "iciti": "ic", "ical": "ic", "ful": "", "ness": ""}
                w = stem + rep[suf]
        n = len(w)
        # Step 4
        suf = _longest(w, ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent",
                           "ism", "ate", "iti", "ous", "ive", "ize", "ion", "al", "er", "ic"))
        if suf and n - len(suf) >= r2:
            stem = w[: -len(suf)]
            if suf == "ion":
                if stem.endswith(("s", "t")):
                    w = stem
            else:
                w = stem
        n = len(w)
        # Step 5
        if w.endswith("e"):
            if n - 1 >= r2 or (n - 1 >= r1 and not self._short_syl(w, n - 1)):
                w = w[:-1]
        elif w.endswith("l"):
            if n - 1 >= r2 and w.endswith("ll"):
                w = w[:-1]
        return w.replace("Y", "y")

    def _short_word(self, w):
        return self._short_syl(w, len(w))


# ------------------------------------------------------------------ German
class _German:
    V = "aeiouyäöü"

    def stem(self, word):
        w = word.replace("ß", "ss")
        V = self.V
        chars = list(w)
        for i in range(1, len(chars) - 1):
            if chars[i] in "uy" and chars[i - 1] in V and chars[i + 1] in V:
                chars[i] = chars[i].upper()
        w = "".join(chars)
        V2 = V + "UY"
        r1, r2 = _regions(w, V2, 3)

        # Step 1
        suf = _longest(w, ("ern", "em", "er", "en", "es", "e", "s"))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf in ("em", "ern", "er"):
                w = stem
            elif suf in ("e", "en", "es"):
                w = stem
                if w.endswith("niss"):
                    w = w[:-1]
            elif suf == "s" and stem and stem[-1] in "bdfghklmnrt":
                w = stem
        # Step 2
        suf = _longest(w, ("est", "en", "er", "st"))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf in ("en", "er", "est"):
                w = stem
            elif suf == "st" and stem and stem[-1] in "bdfghklmnt" and len(stem) >= 3:
                w = stem
        # Step 3
        suf = _longest(w, ("keit", "heit", "lich", "isch", "end", "ung", "ig", "ik"))
        if suf and len(w) - len(suf) >= r2:
            stem = w[: -len(suf)]
            if suf in ("end", "ung"):
                w = stem
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
            elif suf in ("ig", "ik", "isch"):
                if not stem.endswith("e"):
                    w = stem
            elif suf in ("lich", "heit"):
                w = stem
                for s2 in ("er", "en"):
                    if w.endswith(s2) and len(w) - 2 >= r1:
                        w = w[:-2]
                        break
            elif suf == "keit":
                w = stem
                for s2 in ("lich", "ig"):
                    if w.endswith(s2) and len(w) - len(s2) >= r2:
                        w = w[: -len(s2)]
                        break
        w = w.replace("U", "u").replace("Y", "y")
        return w.translate(str.maketrans("äöü", "aou"))


# ------------------------------------------------------------------ Dutch
class _Dutch:
    V = "aeiouyè"

    def _undouble(self, w):
        if w.endswith(("kk", "dd", "tt")):
            return w[:-1]
        return w

    def stem(self, word):
        w = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
        V = self.V
        chars = list(w)
        if chars and chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i] == "y" and chars[i - 1] in V:
                chars[i] = "Y"
        for i in range(1, len(chars) - 1):
            if chars[i] == "i" and chars[i - 1] in V and chars[i + 1] in V:
                chars[i] = "I"
        w = "".join(chars)
        V2 = V + "IY"
        r1, r2 = _regions(w, V2, 3)

        def nv(c):
            return c not in V2
        # Step 1
        suf = _longest(w, ("heden", "ene", "en", "se", "s"))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf == "heden":
                w = stem + "heid"
            elif suf in ("en", "ene"):
                if stem and nv(stem[-1]) and not stem.endswith("gem"):
                    w = self._undouble(stem)
            elif suf in ("s", "se"):
                if stem and nv(stem[-1]) and stem[-1] != "j":
                    w = stem
        # Step 2
        e_found = False
        if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and nv(w[-2]):
            w = self._undouble(w[:-1])
            e_found = True
        # Step 3a
        if w.endswith("heid") and len(w) - 4 >= r2 and not w[:-4].endswith("c"):
            w = w[:-4]
            if w.endswith("en") and len(w) - 2 >= r1 and len(w) > 2 and nv(w[-3]) \
                    and not w.endswith("gemen"[-3:] if False else "gem"):
                w = self._undouble(w[:-2])
        # Step 3b
        suf = _longest(w, ("baar", "lijk", "end", "ing", "bar", "ig"))
        if suf and len(w) - len(suf) >= r2:
            stem = w[: -len(suf)]
            if suf in ("end", "ing"):
                w = stem
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
                else:
                    w = self._undouble(w)
            elif suf == "ig":
                if not stem.endswith("e"):
                    w = stem
            elif suf == "lijk":
                w = stem
                if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and nv(w[-2]):
                    w = self._undouble(w[:-1])
            elif suf == "baar":
                w = stem
            elif suf == "bar" and e_found:
                w = stem
        # Step 4
        if len(w) >= 4 and nv(w[-1]) and w[-1] != "I" and w[-2] == w[-3] and w[-2] in "aeou" \
                and nv(w[-4]):
            w = w[:-2] + w[-1]
        return w.replace("I", "i").replace("Y", "y")


# ------------------------------------------------------------------ Scandinavian
class _Swedish:
    V = "aeiouyäåö"
    STEP1 = ("heterna", "hetens", "anden", "andes", "andet", "arens", "arnas", "ernas",
             "ornas", "arna", "erna", "orna", "ades", "aren", "heten", "heter", "ande",
             "arne", "aste", "erns", "ade", "are", "ast", "ens", "ern", "het", "ar", "er",
             "or", "as", "es", "at", "en", "a", "e")
    SEND = "bcdfghjklmnoprtvy"

    def stem(self, word):
        w = word
        r1, _ = _regions(w, self.V, 3)
        suf = _longest(w, self.STEP1 + ("s",))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf == "s":
                if stem and stem[-1] in self.SEND:
                    w = stem
            else:
                w = stem
        suf = _longest(w, ("dd", "gd", "nn", "dt", "gt", "kt", "tt"))
        if suf and len(w) - 2 >= r1:
            w = w[:-1]
        suf = _longest(w, ("fullt", "lig", "els", "lös", "ig"))
        if suf and len(w) - len(suf) >= r1:
            if suf == "lös":
                w = w[:-1]
            elif suf == "fullt":
                w = w[:-1]
            else:
                w = w[: -len(suf)]
        return w


class _Danish:
    V = "aeiouyæåø"
    STEP1 = ("erendes", "erende", "hedens", "ethed", "erede", "heden", "heder", "endes",
             "ernes", "erens", "erets", "ered", "ende", "erne", "eren", "erer", "enes",
             "heds", "eres", "eret", "hed", "ene", "ere", "ens", "ers", "ets", "en", "er",
             "es", "et", "e")
    SEND = "abcdfghjklmnoprtvyzå"

    def stem(self, word):
        w = word
        r1, _ = _regions(w, self.V, 3)
        suf = _longest(w, self.STEP1 + ("s",))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf == "s":
                if stem and stem[-1] in self.SEND:
                    w = stem
            else:
                w = stem
        if w.endswith(("gd", "dt", "gt", "kt")) and len(w) - 2 >= r1:
            w = w[:-1]
        if w.endswith("igst"):
            w = w[:-2]
        suf = _longest(w, ("elig", "løst", "lig", "els", "ig"))
        if suf and len(w) - len(suf) >= r1:
            if suf == "løst":
                w = w[:-1]
            else:
                w = w[: -len(suf)]
                if w.endswith(("gd", "dt", "gt", "kt")) and len(w) - 2 >= r1:
                    w = w[:-1]
        if len(w) >= 2 and w[-1] == w[-2] and w[-1] not in self.V and len(w) - 1 >= r1:
            w = w[:-1]
        return w


class _Norwegian:
    V = "aeiouyæåø"
    STEP1 = ("hetenes", "hetene", "hetens", "heten", "heter", "endes", "ande", "ende",
             "edes", "enes", "erte", "ane", "ene", "ede", "ens", "ers", "ets", "het", "ast",
             "ert", "en", "ar", "er", "as", "es", "et", "a", "e")
    SEND = "bcdfghjlmnoprtvyz"

    def stem(self, word):
        w = word
        r1, _ = _regions(w, self.V, 3)
        suf = _longest(w, self.STEP1 + ("s",))
        if suf and len(w) - len(suf) >= r1:
            stem = w[: -len(suf)]
            if suf == "s":
                if stem and (stem[-1] in self.SEND or
                             (stem[-1] == "k" and len(stem) > 1 and stem[-2] not in self.V)):
                    w = stem
            elif suf in ("erte", "ert"):
                w = stem + "er"
            else:
                w = stem
        if w.endswith(("dt", "vt")) and len(w) - 2 >= r1:
            w = w[:-1]
        suf = _longest(w, ("hetslov", "elov", "slov", "elig", "eig", "lig", "els", "lov", "ig"))
        if suf and len(w) - len(suf) >= r1:
            w = w[: -len(suf)]
        return w


class _Identity:
    """Languages whose algorithm is not bundled: lowercase only."""

    def stem(self, word):
        return word


_IMPL = {"english": _English, "german": _German, "dutch": _Dutch, "swedish": _Swedish,
         "danish": _Danish, "norwegian": _Norwegian}


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        # spec: N-000429 N-000430 N-000431 N-000183 N-000184
        if language not in LANGUAGES:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            p = data.find("corpora/stopwords/%s" % language)
            if not os.path.isfile(p):
                raise LookupError("stopwords list for %r is not installed" % language)
            self.stopwords = set(data.read_lines(p))
        if language == "porter":
            self._impl = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
            self._porter = True
        else:
            self._impl = _IMPL.get(language, _Identity)()
            self._porter = False

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()  # spec: N-000176
        if word in self.stopwords:  # spec: N-000177
            return word
        if self._porter:
            return self._impl.stem(word, to_lowercase=True)
        return self._impl.stem(word)

    def __repr__(self):
        return "<SnowballStemmer(%s)>" % self.language
