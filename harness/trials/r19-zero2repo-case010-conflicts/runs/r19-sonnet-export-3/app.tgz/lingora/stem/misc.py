import os
import re

from .. import data


class RegexpStemmer:
    """Remove every match of a caller pattern.  # spec: N-000178 N-000179 N-000180"""

    def __init__(self, regexp, min=0):
        if not isinstance(regexp, str):
            if hasattr(regexp, "sub"):
                self._regexp = regexp
            else:
                raise TypeError("regexp must be a str")
        else:
            self._regexp = re.compile(regexp)
        self.min = min

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if len(word) < self.min:
            return word
        return self._regexp.sub("", word)

    def __repr__(self):
        return "<RegexpStemmer: %r>" % self._regexp.pattern


class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet.  # spec: N-000432 N-000185 N-000186"""
    _SUFFIXES = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
              ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
              ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }
    _FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}

    def __init__(self):
        self._root = data.find("corpora/wordnet")
        if not os.path.isdir(self._root):
            raise LookupError("WordNet is not a directory")
        self._lemmas = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._lemmas:
            return
        name = self._FILES[pos]
        lemmas = set()
        p = os.path.join(self._root, "index." + name)
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as f:
                for line in f:
                    if line.startswith(" "):
                        continue
                    parts = line.split(" ", 1)
                    if parts and parts[0]:
                        lemmas.add(parts[0])
        exc = {}
        p = os.path.join(self._root, name + ".exc")
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], parts[1])
        self._lemmas[pos] = lemmas
        self._exc[pos] = exc

    def lemmatize(self, word, pos="n"):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if pos not in self._FILES:
            raise ValueError("pos must be one of n, v, a, r")
        data.find("corpora/wordnet")
        self._load(pos)
        if word in self._exc[pos]:
            return self._exc[pos][word]
        if word in self._lemmas[pos]:
            return word
        for suf, rep in self._SUFFIXES[pos]:
            if word.endswith(suf) and len(word) > len(suf):
                cand = word[: len(word) - len(suf)] + rep
                if cand in self._lemmas[pos]:
                    return cand
        return word


class ARLSTem:
    """Light Arabic stemmer (results outside this specification)."""
    _PREFIXES = ["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل"]
    _SUFFIXES = ["ات", "ان", "ين", "ون", "ها", "ة", "ه", "ي"]
    _DIACRITICS = re.compile("[ً-ْـ]")

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = self._DIACRITICS.sub("", word)
        for p in self._PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in self._SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[: -len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    """Second Arabic light stemmer (results outside this specification)."""
