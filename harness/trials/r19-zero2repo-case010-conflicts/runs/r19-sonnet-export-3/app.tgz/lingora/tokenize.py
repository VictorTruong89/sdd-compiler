"""Tokenizers.  # spec: N-000403 N-000404"""
import html
import re

from . import _punkt

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "NLTKWordTokenizer", "blankline_tokenize", "sent_tokenize",
           "word_tokenize", "wordpunct_tokenize", "BlanklineTokenizer"]


def _check_str(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str, not %s" % (name, type(text).__name__))


# ---------------------------------------------------------------- regexp family
class RegexpTokenizer:
    # spec: N-000116 N-000117 N-000118 N-000405 N-000406 N-000407
    def __init__(self, pattern, gaps=False, discard_empty=False, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        _check_str(pattern, "pattern")
        self._pattern = pattern
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        _check_str(text)
        if self._gaps:
            pieces = self._regexp.split(text)
            if self._discard_empty:
                pieces = [p for p in pieces if p]
            return pieces
        return self._regexp.findall(text)

    def span_tokenize(self, text):
        # spec: N-000412 N-000126 N-000127 N-000128
        _check_str(text)
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                left, right = m.span()
                if not (self._discard_empty and left == last):
                    yield (last, left)
                last = right
            if not (self._discard_empty and last == len(text)):
                yield (last, len(text))
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    # spec: N-000113
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True, discard_empty=True)


class BlanklineTokenizer(RegexpTokenizer):
    # spec: N-000114 N-000115
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True, discard_empty=True)


class WordPunctTokenizer(RegexpTokenizer):
    # spec: N-000089 N-000090 N-000091
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+", flags=re.UNICODE | re.MULTILINE | re.DOTALL)


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    # spec: N-000092 .. N-000103
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)('')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text, convert_parentheses=False, return_str=False):
        _check_str(text)
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text if return_str else text.split()


class NLTKWordTokenizer(TreebankWordTokenizer):
    """The recommended (improved Penn Treebank) word tokenizer.  # spec: N-000104..N-000110"""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒–—―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    # *cannot* is kept as one token (N-000110)
    CONTRACTIONS2 = TreebankWordTokenizer.CONTRACTIONS2[1:]


_treebank = TreebankWordTokenizer()
_recommended = NLTKWordTokenizer()


def sent_tokenize(text, language="english"):
    # spec: N-000413 N-000137 N-000138
    _check_str(text)
    model = _punkt.load_model(language)
    return model.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    # spec: N-000409 N-000410 N-000111 N-000112
    _check_str(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    out = []
    for s in sentences:
        out.extend(_recommended.tokenize(s))
    return out


# ---------------------------------------------------------------- Tweets
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""

_URLS = r"""
  (?:
  (?:
    https?:
      (?:
        /{1,3}
        |
        [a-z0-9%]
      )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    \b
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
  )
"""

_REGEXPS = (
    _URLS,
    _EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
    """,
)

_WORD_RE = re.compile("(%s)" % "|".join(_REGEXPS), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_HANDLE_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    # spec: N-000119 .. N-000125
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_str(text)
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m[0] if isinstance(m, tuple) else m for m in _WORD_RE.findall(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
