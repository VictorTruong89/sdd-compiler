from ..grammar import CFG, Nonterminal
from ..tree import Tree
from .chart import _check_tokens


class ShiftReduceParser:
    # spec: N-000272 .. N-000275
    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    @staticmethod
    def _match(rhs, items):
        for r, s in zip(rhs, items):
            if isinstance(r, str):
                if not (isinstance(s, str) and s == r):
                    return False
            else:
                if not (isinstance(s, Tree) and s.label() == str(r)):
                    return False
        return True

    def _reduce(self, stack):
        for p in self._prods:
            n = len(p.rhs())
            if len(stack) >= n and self._match(p.rhs(), stack[-n:]):
                kids = stack[-n:]
                del stack[-n:]
                stack.append(Tree(str(p.lhs()), kids))
                return True
        return False

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        stack = []
        remaining = list(tokens)
        limit = 10000 + 100 * len(remaining)
        while remaining:
            stack.append(remaining.pop(0))
            steps = 0
            while self._reduce(stack):
                steps += 1
                if steps > limit:
                    break
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])
