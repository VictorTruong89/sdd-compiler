import sys
from itertools import islice

from ..grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    # spec: N-000276 .. N-000280, N-000477 .. N-000480
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _all(grammar, [start], depth)
    if n is not None:
        it = islice(it, n)
    return it


def _all(grammar, items, depth):
    if items:
        try:
            for frag1 in _one(grammar, items[0], depth):
                for frag2 in _all(grammar, items[1:], depth):
                    yield frag1 + frag2
        except RecursionError as error:
            raise RuntimeError(
                "The grammar has rule(s) that yield infinite recursion!") from error
    else:
        yield []


def _one(grammar, lhs, depth):
    if depth > 0:
        if isinstance(lhs, Nonterminal):
            for prod in grammar.productions(lhs):
                yield from _all(grammar, prod.rhs(), depth - 1)
        else:
            yield [lhs] if lhs != "" else []
