from ..grammar import CFG, Nonterminal
from ..tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")  # spec: N-000472
    known = grammar.terminals()
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("tokens must be a list of str")
        if t not in known:
            # spec: N-000475 N-000476 N-000292 N-000293
            raise ValueError("Grammar does not cover some of the input words: %r" % (t,))


class ChartParser:
    # spec: N-000266 .. N-000271
    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar
        self._by_lhs = {}
        for p in grammar.productions():
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        active = set()
        by_lhs = self._by_lhs

        def derive(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            result = []
            for prod in by_lhs.get(sym, ()):
                for kids in seq(prod.rhs(), 0, i, j):
                    result.append(Tree(str(sym), kids))
            active.discard(key)
            memo[key] = result
            return result

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            item = rhs[k]
            if isinstance(item, str):
                if i < j and tokens[i] == item:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [item] + rest
                elif item == "" and True:
                    for rest in seq(rhs, k + 1, i, j):
                        yield [item] + rest
                return
            last = len(rhs) - k - 1
            for m in range(i, j + 1):
                trees = derive(item, i, m)
                if not trees:
                    continue
                for rest in seq(rhs, k + 1, m, j):
                    for t in trees:
                        yield [t] + rest

        return iter(derive(self._grammar.start(), 0, n))
