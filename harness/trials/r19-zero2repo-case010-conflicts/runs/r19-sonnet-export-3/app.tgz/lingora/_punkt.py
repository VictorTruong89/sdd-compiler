"""Punkt sentence-boundary detection (Kiss & Strunk 2006) over packaged parameters."""
import os
import re
import string

from . import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"^\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"^[^\W\d]+$", re.UNICODE)

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"

_WORD_RE = re.compile(
    r"""(?:
        %(Multi)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(Multi)s|
            ,(?=$|\s|%(NonWord)s|%(Multi)s)
        )
        |
        \S
    )""" % {"Multi": _MULTI, "WordStart": _WORDSTART, "NonWord": _NONWORD},
    re.UNICODE | re.VERBOSE)

_PERIOD_RE = re.compile(
    r"""[.?!]
    (?=(?P<after_tok>
        %(NonWord)s
        |
        \s+(?P<next_tok>\S+)
    ))""" % {"NonWord": _NONWORD}, re.UNICODE | re.VERBOSE)

_REALIGN = re.compile(r"""["')\]}]+?(?:\s+|(?=--)|$)""", re.MULTILINE)
_PUNCT = (";", ":", ",", ".", "!", "?")


class _Tok:
    __slots__ = ("tok", "type", "period_final", "parastart", "linestart",
                 "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktModel:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context

    # -- tokenization -------------------------------------------------
    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = _WORD_RE.findall(line)
                if not toks:
                    continue
                yield _Tok(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for t in toks[1:]:
                    yield _Tok(t)
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        if tok in (".", "?", "!"):
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            low = tok[:-1].lower()
            if low in self.abbrev_types or low.split("-")[-1] in self.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho(self, t):
        if t.tok in _PUNCT:
            return False
        oc = self.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            o = self._ortho(t2)
            if o is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (o == "unknown" and initial and t2.first_upper
                    and not (self.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_break(self, text):
        found = False
        for t in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # -- sentence slicing --------------------------------------------
    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _PERIOD_RE.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = 0
            for i in range(len(before) - 1, -1, -1):
                if before[i] in string.whitespace:
                    idx = i
                    break
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, match.start())
            if prev_match and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur
        if prev_match:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, ctx in self._contexts(text):
            if self._contains_break(ctx):
                yield (last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield (last, len(text.rstrip()))

    def spans(self, text):
        slices = list(self._slices(text))
        realign = 0
        out = []
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    out.append(s1)
                continue
            m = _REALIGN.match(text[s2[0]:s2[1]])
            if m:
                out.append((s1[0], s2[0] + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    out.append(s1)
        return out

    def tokenize(self, text):
        return [text[a:b] for a, b in self.spans(text)]


_cache = {}


def load_model(language):
    """Load the Punkt model for `language` from data.path; raise LookupError if absent."""
    if not isinstance(language, str) or not language or "/" in language or "\\" in language \
            or language in (".", ".."):
        raise LookupError("no Punkt model for language %r" % (language,))
    d = data.find("tokenizers/punkt_tab/%s" % language)
    if not os.path.isdir(d):
        raise LookupError("Punkt model for %r is not a directory" % language)
    names = ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")
    files = []
    sig = []
    for n in names:
        p = os.path.join(d, n)
        if not os.path.isfile(p):
            raise LookupError("Punkt model file %s is missing" % p)
        st = os.stat(p)
        sig.append((p, st.st_mtime_ns, st.st_size))
        files.append(p)
    sig = tuple(sig)
    hit = _cache.get(d)
    if hit and hit[0] == sig:
        return hit[1]
    abbrev = set(l for l in data.read_lines(files[0]) if l != "")
    starters = set(l for l in data.read_lines(files[1]) if l != "")
    colloc = set()
    for l in data.read_lines(files[2]):
        if l == "":
            continue
        parts = l.split("\t")
        if len(parts) >= 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for l in data.read_lines(files[3]):
        if l == "":
            continue
        parts = l.split("\t")
        if len(parts) >= 2:
            ortho[parts[0]] = int(parts[1])
    model = PunktModel(abbrev, starters, colloc, ortho)
    _cache[d] = (sig, model)
    return model
