"""Lingora Language Toolkit: pure-Python NLP library.  # spec: N-000371 N-000372"""
from . import data  # noqa: F401
from . import tree  # noqa: F401
from . import tokenize  # noqa: F401
from . import stem  # noqa: F401
from . import tag  # noqa: F401
from . import chunk  # noqa: F401
from . import grammar  # noqa: F401
from . import parse  # noqa: F401
from . import classify  # noqa: F401
from . import metrics  # noqa: F401
from . import translate  # noqa: F401

__version__ = "0.1.0"
