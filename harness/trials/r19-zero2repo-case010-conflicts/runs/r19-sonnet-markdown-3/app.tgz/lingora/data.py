"""Resource finder. ``path`` is a mutable list of directories searched for packaged resources."""
import os

path = []
_env = os.environ.get("LINGORA_DATA")
if _env:
    path.extend(p for p in _env.split(os.pathsep) if p)
path.extend([
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/app/lingora_data",
])


def find(resource):
    """Return the filesystem location of ``resource`` found under ``path``; raise LookupError."""
    for d in list(path):
        p = os.path.join(str(d), *resource.strip("/").split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as f:
        return f.read().splitlines()
