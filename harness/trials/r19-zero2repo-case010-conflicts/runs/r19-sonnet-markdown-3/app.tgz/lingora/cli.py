"""Command line interface."""
import sys

from .tokenize import word_tokenize


class _Cli:
    def main(self, args=None, standalone_mode=True):
        args = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(args)
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % (e,))
            sys.exit(1)
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] != "tokenize":
            raise ValueError("usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING]")
        language, delim, enc = "english", " ", "utf-8"
        i = 1
        while i < len(args):
            a = args[i]
            if a in ("-l", "--language") and i + 1 < len(args):
                language = args[i + 1]; i += 2
            elif a in ("-d", "--delimiter") and i + 1 < len(args):
                delim = args[i + 1]; i += 2
            elif a in ("-e", "--encoding") and i + 1 < len(args):
                enc = args[i + 1]; i += 2
            elif a.startswith("--language="):
                language = a.split("=", 1)[1]; i += 1
            elif a.startswith("--delimiter="):
                delim = a.split("=", 1)[1]; i += 1
            else:
                raise ValueError("unknown option %r" % a)
        stdin = sys.stdin
        raw = stdin.buffer.read().decode(enc) if hasattr(stdin, "buffer") else stdin.read()
        out = []
        for line in raw.splitlines():
            out.append(delim.join(word_tokenize(line, language=language)))
        if not out and raw == "":
            # still require the model so a missing Punkt model fails
            word_tokenize("", language=language)
        sys.stdout.write("".join(l + "\n" for l in out))
        sys.stdout.flush()
        return 0


cli = _Cli()
