"""Parsers."""
from ..grammar import Nonterminal
from ..tree import Tree


def _check_coverage(grammar, tokens):
    terms = set(grammar.terminals())
    missing = [t for t in tokens if t not in terms]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %s" % ", ".join(repr(m) for m in missing))


class ChartParser:
    def __init__(self, grammar, **kw):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings")
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()

        def derive_nt(nt, i, j):
            key = (nt, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            res = []
            for p in g.productions(lhs=nt):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append(tree_class(str(nt), kids))
            active.discard(key)
            memo[key] = res
            return res

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            rest_min = 0
            if isinstance(sym, Nonterminal):
                for m in range(i, j + 1):
                    for t in derive_nt(sym, i, m):
                        for tail in seq(rhs, k + 1, m, j):
                            yield [t] + tail
            else:
                if sym == "":
                    for tail in seq(rhs, k + 1, i, j):
                        yield tail
                elif i < j and tokens[i] == sym:
                    for tail in seq(rhs, k + 1, i + 1, j):
                        yield [sym] + tail

        return iter(list(derive_nt(g.start(), 0, n)))


class ShiftReduceParser:
    def __init__(self, grammar, **kw):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    def _matches(self, stack, p):
        rhs = p.rhs()
        if len(stack) < len(rhs):
            return False
        for sym, item in zip(rhs, stack[len(stack) - len(rhs):]):
            if isinstance(sym, Nonterminal):
                if not (isinstance(item, Tree) and item.label() == str(sym)):
                    return False
            else:
                if isinstance(item, Tree) or item != sym:
                    return False
        return True

    def _reduce(self, stack):
        for p in self._prods:
            if self._matches(stack, p):
                k = len(p.rhs())
                kids = stack[len(stack) - k:]
                del stack[len(stack) - k:]
                stack.append(Tree(str(p.lhs()), kids))
                return True
        return False

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings")
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        stack = []
        rest = list(tokens)
        guard = 0
        limit = 1000 + 50 * len(tokens) ** 2
        while True:
            while self._reduce(stack):
                guard += 1
                if guard > limit:
                    return iter([])
            if not rest:
                break
            stack.append(rest.pop(0))
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])


class RecursiveDescentParser(ChartParser):
    pass
