"""Constituent trees."""


class Tree(list):
    def __init__(self, label, children):
        if isinstance(children, str) or children is None:
            raise TypeError("Tree children must be a list of children, not %r" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def height(self):
        h = 1
        for c in self:
            if isinstance(c, Tree):
                h = max(h, c.height() + 1)
            else:
                h = max(h, 2)
        return h

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    @staticmethod
    def _leaf_str(c):
        if isinstance(c, tuple):
            return "/".join(str(x) for x in c)
        return str(c)

    def _inline(self):
        parts = [str(self._label)]
        for c in self:
            parts.append(c._inline() if isinstance(c, Tree) else self._leaf_str(c))
        return "(" + " ".join(parts) + ")"

    def pformat(self, margin=70, indent=0):
        s = self._inline()
        if len(s) + indent <= margin:
            return s
        out = "(" + str(self._label)
        for c in self:
            out += "\n" + " " * (indent + 2)
            if isinstance(c, Tree):
                out += c.pformat(margin, indent + 2)
            else:
                out += self._leaf_str(c)
        return out + ")"

    def pretty_print(self, **kw):
        print(self.pformat())

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        import re
        toks = re.findall(r"%s|%s|[^\s%s%s]+" % (re.escape(open_b), re.escape(close_b),
                                                 re.escape(open_b), re.escape(close_b)), s)
        if not toks:
            raise ValueError("empty tree string")
        pos = 0

        def parse_node():
            nonlocal pos
            if toks[pos] != open_b:
                raise ValueError("Expected %r at token %d" % (open_b, pos))
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in (open_b, close_b):
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("Unbalanced brackets in tree string")
                t = toks[pos]
                if t == close_b:
                    pos += 1
                    return cls(label, children)
                if t == open_b:
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos += 1

        t = parse_node()
        if pos != len(toks):
            raise ValueError("Unexpected text after tree")
        return t
