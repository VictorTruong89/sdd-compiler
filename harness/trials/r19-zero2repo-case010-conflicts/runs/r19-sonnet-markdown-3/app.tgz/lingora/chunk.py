"""Regular-expression chunking."""
import re

from .tree import Tree

ROOT = "S"


def tag_pattern2re(pattern):
    pattern = re.sub(r"\s", "", pattern)
    pattern = pattern.replace("<", "(?:<(?:").replace(">", ")>)")
    pattern = re.sub(r"(?<!\\)\.", r"[^\\{\\}<>]", pattern)
    return pattern


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        try:
            self.body = tag_pattern2re(pattern)
            if kind == "chunk":
                self.regex = re.compile("(?P<m>%s)(?=[^\\}]*(\\{|$))" % self.body)
            else:
                self.regex = re.compile("(?P<m>%s)(?=[^\\{]*\\})" % self.body)
        except re.error as e:
            raise ValueError("Bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        if self.kind == "chunk":
            s = self.regex.sub(lambda m: "\x01" + m.group("m") + "\x02" if m.group("m") else "", s)
            s = s.replace("}\x01", "").replace("\x02{", "")
            return s.replace("\x01", "{").replace("\x02", "}")
        s = self.regex.sub(lambda m: "}" + m.group("m") + "{" if m.group("m") else "", s)
        return s.replace("{}", "")


class RegexpChunkParser:
    """One clause (stage) of a chunk grammar."""

    def __init__(self, rules, chunk_label="NP", root_label=ROOT):
        self._rules = list(rules)
        self._label = chunk_label
        self._root = root_label

    def parse_items(self, items):
        def tag_of(it):
            if isinstance(it, Tree):
                return it.label()
            return it[1]

        s = "".join("<%s>" % tag_of(it) for it in items)
        for r in self._rules:
            s = r.apply(s)
        out = []
        cur = None
        idx = 0
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            g = m.group()
            if g == "{":
                cur = []
            elif g == "}":
                out.append(Tree(self._label, cur))
                cur = None
            else:
                it = items[idx]
                idx += 1
                (cur if cur is not None else out).append(it)
        return out

    def parse(self, tagged):
        return Tree(self._root, self.parse_items(list(tagged)))


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT):
        self._root = root_label
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, (RegexpChunkParser, RegexpParser)) for g in grammar):
            stages = []
            for g in grammar:
                stages.extend(g._stages if isinstance(g, RegexpParser) else [g])
            self._stages = stages
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")

    @staticmethod
    def _parse_grammar(text):
        stages = []
        label = None
        rules = []
        for raw in text.split("\n"):
            line = raw.split("#")[0].rstrip() if "#" in raw else raw.rstrip()
            if not line.strip():
                continue
            body = line.strip()
            if not line[0].isspace():
                m = re.match(r"^([^\s:{}]+)\s*:\s*(.*)$", line)
                if not m:
                    raise ValueError("Illegal chunk grammar line: %r" % raw)
                if label is not None:
                    stages.append(RegexpChunkParser(rules, label))
                label, rules = m.group(1), []
                body = m.group(2).strip()
                if not body:
                    continue
            elif label is None:
                raise ValueError("Pattern before any label: %r" % raw)
            if body.startswith("{") and body.endswith("}"):
                rules.append(_Rule("chunk", body[1:-1]))
            elif body.startswith("}") and body.endswith("{"):
                rules.append(_Rule("chink", body[1:-1]))
            else:
                raise ValueError("Illegal chunk rule: %r" % body)
        if label is not None:
            stages.append(RegexpChunkParser(rules, label))
        return stages

    def parse(self, tagged):
        items = list(tagged)
        for st in self._stages:
            items = st.parse_items(items)
        return Tree(self._root, items)


def ne_chunk(tagged_tokens, binary=False):
    from . import data
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking model evaluation is not part of this build")
