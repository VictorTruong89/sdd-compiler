"""Stemmers."""
import re

from . import data


# ================================================================ Porter
class PorterStemmer:
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.NLTK_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode
        self.pool = {}
        irregular = {
            "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
            "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
            "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
            "exceed": ["exceed"], "succeed": ["succeed"],
        }
        for stem, words in irregular.items():
            for w in words:
                self.pool[w] = stem

    vowels = frozenset("aeiou")

    def _is_consonant(self, word, i):
        if i < 0:
            i += len(word)
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3 and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1) and word[-1] not in "wxy"
        ) or (
            self.mode == self.NLTK_EXTENSIONS and len(word) == 2
            and not self._is_consonant(word, 0) and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None),
                                            ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("ied"):
            if len(word) == 4:
                return self._replace_suffix(word, "ied", "ie")
            return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def cond(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)

        def orig(stem):
            return self._contains_vowel(stem)
        return self._apply_rule_list(word, [("y", "i", cond if self.mode == self.NLTK_EXTENSIONS else orig)])

    def _step2(self, word):
        pos = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pos(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pos)
        abli = ("abli", "able", pos)
        rules = [
            ("ational", "ate", pos), ("tional", "tion", pos), ("enci", "ence", pos),
            ("anci", "ance", pos), ("izer", "ize", pos),
            abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
            ("alli", "al", pos), ("entli", "ent", pos), ("eli", "e", pos), ("ousli", "ous", pos),
            ("ization", "ize", pos), ("ation", "ate", pos), ("ator", "ate", pos),
            ("alism", "al", pos), ("iveness", "ive", pos), ("fulness", "ful", pos),
            ("ousness", "ous", pos), ("aliti", "al", pos), ("iviti", "ive", pos),
            ("biliti", "ble", pos),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pos))
            rules.append(("logi", "log", lambda stem: pos(word[:-3])))
        if self.mode == self.ORIGINAL_ALGORITHM:
            rules.append(("logi", "log", pos))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pos = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pos), ("ative", "", pos), ("alize", "al", pos),
            ("iciti", "ic", pos), ("ical", "ic", pos), ("ful", "", pos), ("ness", "", pos)])

    def _step4(self, word):
        gt1 = lambda stem: self._measure(stem) > 1  # noqa: E731
        return self._apply_rule_list(word, [
            ("al", "", gt1), ("ance", "", gt1), ("ence", "", gt1), ("er", "", gt1),
            ("ic", "", gt1), ("able", "", gt1), ("ible", "", gt1), ("ant", "", gt1),
            ("ement", "", gt1), ("ment", "", gt1), ("ent", "", gt1),
            ("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")),
            ("ou", "", gt1), ("ism", "", gt1), ("ate", "", gt1), ("iti", "", gt1),
            ("ous", "", gt1), ("ive", "", gt1), ("ize", "", gt1)])

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(stem) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"


# ================================================================ Lancaster
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.",
    "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.", "mu*2.",
    "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>",
    "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.",
    "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>",
    "ylb1>", "yli3y>", "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>",
    "ytl2.", "yrtsi5.", "zi2>", "zy1s.",
]
_LRULE_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>.])$")


class LancasterStemmer:
    def __init__(self):
        self.rule_dictionary = {}
        for r in _LANCASTER_RULES:
            m = _LRULE_RE.match(r)
            ending, intact, remove, append, cont = m.groups()
            self.rule_dictionary.setdefault(ending[0], []).append(
                (ending, bool(intact), int(remove), append, cont == ">"))

    @staticmethod
    def _acceptable(word, remove):
        if word[0] in "aeiou":
            return len(word) - remove >= 2
        return len(word) - remove >= 3 and any(c in "aeiouy" for c in word[:len(word) - remove])

    def stem(self, word):
        word = word.lower()
        if not word:
            return word
        intact = True
        while True:
            applied = False
            stop = False
            for ending, need_intact, remove, append, cont in self.rule_dictionary.get(word[-1], []):
                if not word.endswith(ending[::-1]):
                    continue
                if need_intact and not intact:
                    continue
                if not self._acceptable(word, remove):
                    continue
                word = word[:len(word) - remove] + append
                intact = False
                applied = True
                stop = not cont
                break
            if not applied or stop or not word:
                break
        return word

    def __repr__(self):
        return "<LancasterStemmer>"


# ================================================================ Regexp
class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# ================================================================ Snowball
SNOWBALL_LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
                      "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
                      "russian", "spanish", "swedish")


class _EnglishStemmer:
    V = "aeiouy"
    DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    LI = "cdeghkmnrt"
    EXC1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
            "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
            "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
            "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
    S2 = [("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
          ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
          ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
          ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
          ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"),
          ("li", "")]
    S3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
          ("iciti", "ic"), ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", "")]
    S4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti",
          "ous", "ive", "ize", "ion", "al", "er", "ic", "ou"]

    def _regions(self, w):
        n = len(w)
        if w.startswith(("gener", "arsen")):
            r1 = 5
        elif w.startswith("commun"):
            r1 = 6
        else:
            r1 = n
            for i in range(1, n):
                if w[i] not in self.V and w[i - 1] in self.V:
                    r1 = i + 1
                    break
        r2 = n
        for i in range(r1 + 1, n):
            if w[i] not in self.V and w[i - 1] in self.V:
                r2 = i + 1
                break
        return r1, r2

    def _short_syll(self, w, end=None):
        w = w if end is None else w[:end]
        n = len(w)
        if n == 2:
            return w[0] in self.V and w[1] not in self.V
        if n >= 3:
            return (w[-3] not in self.V and w[-2] in self.V and w[-1] not in self.V
                    and w[-1] not in "wxY")
        return False

    def _is_short_word(self, w, r1):
        return r1 >= len(w) and self._short_syll(w)

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        if w in self.EXC1:
            return self.EXC1[w]
        if w.startswith("'"):
            w = w[1:]
        if w.startswith("y"):
            w = "Y" + w[1:]
        w = re.sub(r"(?<=[aeiouy])y", "Y", w)
        r1, r2 = self._regions(w)
        # step 0
        for suf in ("'s'", "'s", "'"):
            if w.endswith(suf):
                w = w[:-len(suf)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith(("ied", "ies")):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith(("us", "ss")):
            pass
        elif w.endswith("s"):
            if any(c in self.V for c in w[:-2]):
                w = w[:-1]
        if w in self.EXC2:
            return w.replace("Y", "y")
        r1 = min(r1, len(w))
        r2 = min(r2, len(w))
        # step 1b
        suf = next((s for s in ("eedly", "ingly", "edly", "eed", "ing", "ed") if w.endswith(s)), None)
        if suf in ("eed", "eedly"):
            if len(w) - len(suf) >= r1:
                w = w[:-len(suf)] + "ee"
        elif suf:
            base = w[:-len(suf)]
            if any(c in self.V for c in base):
                w = base
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(self.DOUBLES):
                    w = w[:-1]
                elif self._is_short_word(w, r1):
                    w += "e"
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in self.V:
            w = w[:-1] + "i"
        # step 2
        for suf, rep in self.S2:
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    if suf == "ogi":
                        if w[:-3].endswith("l"):
                            w = w[:-3] + rep
                    elif suf == "li":
                        if len(w) >= 3 and w[-3] in self.LI:
                            w = w[:-2]
                    else:
                        w = w[:-len(suf)] + rep
                break
        # step 3
        for suf, rep in self.S3:
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    if suf == "ative":
                        if len(w) - 5 >= r2:
                            w = w[:-5]
                    else:
                        w = w[:-len(suf)] + rep
                break
        # step 4
        for suf in self.S4:
            if w.endswith(suf):
                if len(w) - len(suf) >= r2:
                    if suf == "ion":
                        if w[-4:-3] in ("s", "t") and len(w) > 3:
                            w = w[:-3]
                    else:
                        w = w[:-len(suf)]
                break
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not self._short_syll(w, len(w) - 1)):
                w = w[:-1]
        elif w.endswith("l"):
            if len(w) - 1 >= r2 and w[-2:-1] == "l":
                w = w[:-1]
        return w.replace("Y", "y")


class _PorterSnowball:
    def __init__(self):
        self._p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        return self._p.stem(w)


class _SuffixFallback:
    """Light suffix stripper used for Snowball languages without a full port."""
    SUFFIXES = {
        "german": ["ungen", "keit", "heit", "ung", "ern", "em", "er", "en", "es", "e", "s"],
        "french": ["ements", "ement", "ations", "ation", "euse", "eux", "es", "e", "s"],
        "spanish": ["amientos", "amiento", "aciones", "acion", "mente", "es", "s", "a", "o"],
        "italian": ["amente", "azione", "azioni", "i", "e", "a", "o"],
        "portuguese": ["amentos", "amento", "mente", "coes", "cao", "es", "s", "a", "o"],
        "dutch": ["heden", "heid", "en", "e", "s"],
        "swedish": ["arna", "erna", "orna", "ar", "er", "or", "en", "et", "a", "e"],
        "danish": ["erne", "ede", "er", "en", "et", "e", "s"],
        "norwegian": ["ene", "ede", "er", "en", "et", "a", "e", "s"],
        "finnish": ["ssa", "ssä", "sta", "stä", "lla", "llä", "n", "a", "ä", "t"],
        "hungarian": ["ok", "ek", "ak", "k", "t"],
        "romanian": ["ilor", "ul", "le", "i", "a", "e"],
        "russian": ["ами", "ями", "ов", "ев", "ы", "а", "я", "и", "у", "ю", "е"],
        "arabic": ["ات", "ون", "ين", "ة", "ا"],
    }

    def __init__(self, language):
        self.sufs = sorted(self.SUFFIXES.get(language, []), key=len, reverse=True)

    def stem(self, word):
        w = word.lower()
        for s in self.sufs:
            if w.endswith(s) and len(w) - len(s) >= 3:
                return w[:-len(s)]
        return w


class SnowballStemmer:
    languages = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            p = data.find("corpora/stopwords/%s" % language)
            self.stopwords = set(l.strip() for l in data.read_lines(p) if l.strip())
        if language == "english":
            self.stemmer = _EnglishStemmer()
        elif language == "porter":
            self.stemmer = _PorterSnowball()
        else:
            self.stemmer = _SuffixFallback(language)

    def stem(self, word):
        w = word.lower()
        if w in self.stopwords:
            return w
        return self.stemmer.stem(w)


# ================================================================ Arabic (outside spec; light)
class ARLSTem:
    _PREFIX = ["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف"]
    _SUFFIX = ["ات", "ان", "ون", "ين", "ها", "هم", "ة", "ه", "ي"]

    def stem(self, word):
        for p in self._PREFIX:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in self._SUFFIX:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[:-len(s)]
                break
        return word


class ARLSTem2(ARLSTem):
    pass


# ================================================================ WordNet lemmatizer
class WordNetLemmatizer:
    _SUBS = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
              ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
              ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }
    _FILES = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "r": "index.adv"}

    def __init__(self):
        import os
        self._base = data.find("corpora/wordnet")
        self._lemmas = {}
        for pos, fn in self._FILES.items():
            s = set()
            p = os.path.join(self._base, fn)
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    for line in f:
                        if line.startswith(" "):
                            continue
                        s.add(line.split(" ", 1)[0])
            self._lemmas[pos] = s

    def lemmatize(self, word, pos="n"):
        forms = [word]
        for old, new in self._SUBS.get(pos, []):
            if word.endswith(old):
                forms.append(word[:len(word) - len(old)] + new)
        cands = [f for f in forms if f in self._lemmas.get(pos, ())]
        return min(cands, key=len) if cands else word
