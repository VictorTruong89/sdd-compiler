"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


def nonterminals(symbols):
    if isinstance(symbols, str):
        symbols = symbols.replace(",", " ").split()
    return [Nonterminal(s) for s in symbols]


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        return "%s -> %s" % (self._lhs, " ".join(str(s) if isinstance(s, Nonterminal) else repr(s) for s in self._rhs))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s|'"]+))""")


def _parse_rhs(text, lineno):
    pos = 0
    text = text.rstrip()
    alts = [[]]
    while pos < len(text):
        m = _TOKEN_RE.match(text, pos)
        if not m or m.end() == pos:
            if text[pos:].strip() == "":
                break
            raise ValueError("Unable to parse grammar line %d: %r" % (lineno, text))
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3):
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)
        self._categories = set(p.lhs() for p in self._productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        if lhs is None and rhs is None:
            return list(self._productions)
        prods = self._lhs_index.get(lhs, []) if lhs is not None else self._productions
        if rhs is not None:
            prods = [p for p in prods if p.rhs() and p.rhs()[0] == rhs]
        return list(prods)

    def is_nonterminal(self, sym):
        return isinstance(sym, Nonterminal)

    def terminals(self):
        out = []
        for p in self._productions:
            for s in p.rhs():
                if not isinstance(s, Nonterminal) and s not in out:
                    out.append(s)
        return out

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + \
            "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            input = "\n".join(input)
        start = None
        prods = []
        lhs = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("%start"):
                start = Nonterminal(line.split()[1])
                continue
            if line.startswith("|") and lhs is not None:
                rhs_text = line
            else:
                m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse grammar line %d: %r" % (lineno, raw))
                lhs = Nonterminal(m.group(1))
                rhs_text = m.group(2)
                if start is None:
                    start = lhs
            if line.startswith("|") and lhs is not None:
                rhs_text = rhs_text[1:]
                alts = _parse_rhs("|" + rhs_text, lineno)[1:]
            else:
                alts = _parse_rhs(rhs_text, lineno)
            for alt in alts:
                prods.append(Production(lhs, alt))
        if start is None:
            raise ValueError("No productions in grammar")
        return cls(start, prods)


def _as_nt(sym):
    return sym if isinstance(sym, Nonterminal) else Nonterminal(sym)
