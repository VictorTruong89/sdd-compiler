"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


class TaggerI:
    backoff = None

    def tag_one(self, tokens, index, history):
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings, not a string")
        tokens = list(tokens)
        history = []
        for i in range(len(tokens)):
            history.append(self.tag_one(tokens, i, history))
        return list(zip(tokens, history))

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]

    def _choose(self, tokens, index, history):
        t = self.tag_one_primary(tokens, index, history) if hasattr(self, "tag_one_primary") else None
        return t


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        self.backoff = backoff

    def tag_one(self, tokens, index, history):
        t = self.choose_tag(tokens, index, history)
        if t is None and self.backoff is not None:
            t = self.backoff.tag_one(tokens, index, history)
        return t

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, t in self._regexps:
            if rx.match(tokens[index]):
                return t
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, train=None, model=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._model = dict(model) if model else {}
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def _train(self, tagged_sents):
        counts = defaultdict(Counter)
        for sent in tagged_sents:
            toks = [w for w, _ in sent]
            hist = []
            for i, (w, t) in enumerate(sent):
                c = self.context(toks, i, hist)
                if c is not None:
                    counts[c][t] += 1
                hist.append(t)
        for c, cnt in counts.items():
            best = max(cnt.values())
            # ties: first tag seen
            for t, n in cnt.items():
                if n == best:
                    self._model[c] = t
                    break

    def choose_tag(self, tokens, index, history):
        c = self.context(tokens, index, history)
        if c is None:
            return None
        return self._model.get(c)


class UnigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        if index == 0:
            return (None, tokens[index])
        return (history[index - 1], tokens[index])


class TrigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        p1 = history[index - 1] if index >= 1 else None
        p2 = history[index - 2] if index >= 2 else None
        return (p2, p1, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, model, backoff)

    def context(self, tokens, index, history):
        w = tokens[index]
        if len(w) < self._min_word_length:
            return None
        return w[self._affix_length:] if self._affix_length > 0 else w[self._affix_length:]


# ------------------------------------------------------------ averaged perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if not word:
        return word
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class PerceptronTagger:
    def __init__(self, lang="eng"):
        base = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        pre = os.path.join(base, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(pre + ".weights.json", encoding="utf-8") as f:
                self.weights = json.load(f)
            with open(pre + ".tagdict.json", encoding="utf-8") as f:
                self.tagdict = json.load(f)
            with open(pre + ".classes.json", encoding="utf-8") as f:
                self.classes = list(json.load(f))
        except OSError as e:
            raise LookupError("Averaged perceptron tagger files for %r missing: %s" % (lang, e))

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            t = self.tagdict.get(word)
            if not t:
                t = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, t))
            prev2 = prev
            prev = t
        return out


_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "SPRO": "PRON", "APRO": "DET",
    "ADVPRO": "ADV", "NUM": "NUM", "ANUM": "ADJ", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
    "INTJ": "X", "NONLEX": ".", "COM": "X",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, the recommended tagger supports only 'eng' and 'rus'; got %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            p = data.find("taggers/universal_tagset/en-ptb.map")
            table = {}
            for line in data.read_lines(p):
                parts = line.split("\t")
                if len(parts) == 2:
                    table[parts[0]] = parts[1]
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, _RUS_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged]
    return tagged
