"""Tokenizers."""
import html
import re

from . import data


# ---------------------------------------------------------------- regexp family
class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        out = self._regexp.findall(text)
        if out and isinstance(out[0], tuple):
            out = ["".join(g) for g in out]
        if self._discard_empty:
            out = [t for t in out if t]
        return out

    def span_tokenize(self, text):
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                s, e = m.span()
                if not (self._discard_empty and s == last):
                    yield (last, s)
                last = e
            if not (self._discard_empty and last == len(text)):
                yield (last, len(text))
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.end() == m.start():
                    continue
                yield m.span()

    def __repr__(self):
        return "RegexpTokenizer(pattern=%r, gaps=%r, discard_empty=%r)" % (
            self._pattern, self._gaps, self._discard_empty)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)

    def tokenize(self, text):
        return [t for t in RegexpTokenizer.tokenize(self, text) if t.strip()]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r'^\"'), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2 \3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r"(?i)\b(can)(?#X)(not)\b"),
                     re.compile(r"(?i)\b(d)(?#X)('ye)\b"),
                     re.compile(r"(?i)\b(gim)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(gon)(?#X)(na)\b"),
                     re.compile(r"(?i)\b(got)(?#X)(ta)\b"),
                     re.compile(r"(?i)\b(lem)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(more)(?#X)('n)\b"),
                     re.compile(r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r"(?i) ('t)(?#X)(is)\b"), re.compile(r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text, convert_parentheses=False, return_str=False):
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        pos = 0
        for tok in self.tokenize(text):
            i = text.find(tok, pos)
            if i < 0:
                # quotes were rewritten; find the original quote char
                for q in ('"', "'", "`"):
                    j = text.find(q, pos)
                    if j >= 0 and (i < 0 or j < i):
                        i = j
                if i < 0:
                    continue
                yield (i, i + 1)
                pos = i + 1
                continue
            yield (i, i + len(tok))
            pos = i + len(tok)


class NLTKWordTokenizer(TreebankWordTokenizer):
    """Improved Penn Treebank tokenizer (LINGORA's recommended word tokenizer)."""
    STARTING_QUOTES = [
        (re.compile(r"([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$"), r"\1 \2 \3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile(r"[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile(r"([»”’])"), r" \1 "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r"(?i)\b(d)(?#X)('ye)\b"),
                     re.compile(r"(?i)\b(gim)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(gon)(?#X)(na)\b"),
                     re.compile(r"(?i)\b(got)(?#X)(ta)\b"),
                     re.compile(r"(?i)\b(lem)(?#X)(me)\b"),
                     re.compile(r"(?i)\b(more)(?#X)('n)\b"),
                     re.compile(r"(?i)\b(wan)(?#X)(na)(?=\s)")]


_improved = NLTKWordTokenizer()


# ---------------------------------------------------------------- Punkt
_SENT_END = ".?!"
_NON_WORD = r"(?:[)\";}\]\*:@\'\({\[!?])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_period_context_re = re.compile(
    r"[.?!](?=(?P<after_tok>%s|\s+(?P<next_tok>\S+)))" % _NON_WORD, re.UNICODE | re.VERBOSE)
_word_re = re.compile(
    r"(%s|(?=%s)\S+?(?=\s|$|%s|%s|,(?=$|\s|%s|%s))|\S)" % (
        _MULTI, _WORD_START, _NON_WORD, _MULTI, _NON_WORD, _MULTI), re.UNICODE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"^\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"^[^\W\d]+$", re.UNICODE)

_O_BEG_UC, _O_MID_UC, _O_UNK_UC = 2, 4, 8
_O_UC = 14
_O_BEG_LC, _O_MID_LC, _O_UNK_LC = 16, 32, 64
_O_LC = 112


class _Tok:
    __slots__ = ("tok", "type", "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok):
        self.tok = tok
        self.type = "##number##" if _RE_NUMERIC.match(tok) else tok.lower()
        self.sentbreak = self.abbr = self.ellipsis = False

    @property
    def period_final(self):
        return self.tok.endswith(".")

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[:1].isupper()

    @property
    def first_lower(self):
        return self.tok[:1].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktSentenceTokenizer:
    def __init__(self, language="english"):
        self.language = language
        base = data.find("tokenizers/punkt_tab/%s" % language)
        import os

        def lines(name):
            p = os.path.join(base, name)
            if not os.path.exists(p):
                raise LookupError("Punkt model file %s missing" % p)
            return data.read_lines(p)

        self.abbrev = set(l for l in lines("abbrev_types.txt") if l)
        self.starters = set(l for l in lines("sent_starters.txt") if l)
        self.colloc = set()
        for l in lines("collocations.tab"):
            parts = l.split("\t")
            if len(parts) == 2:
                self.colloc.add((parts[0], parts[1]))
        self.ortho = {}
        for l in lines("ortho_context.tab"):
            parts = l.split("\t")
            if len(parts) == 2:
                try:
                    self.ortho[parts[0]] = int(parts[1])
                except ValueError:
                    pass

    # -- annotation
    def _first_pass(self, t):
        tok = t.tok
        if tok in _SENT_END:
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if tok[:-1].lower() in self.abbrev or tok[:-1].lower().split("-")[-1] in self.abbrev:
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho_heuristic(self, t):
        if t.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self.ortho.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _O_LC) and not (oc & _O_MID_UC):
            return True
        if t.first_lower and ((oc & _O_UC) or not (oc & _O_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        is_initial = t1.is_initial
        if (typ, next_typ) in self.colloc:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not is_initial:
            if self._ortho_heuristic(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.starters:
                t1.sentbreak = True
                return
        if is_initial or typ == "##number##":
            r = self._ortho_heuristic(t2)
            if r is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (r == "unknown" and is_initial and t2.first_upper
                    and not (self.ortho.get(next_typ, 0) & _O_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, text):
        toks = [_Tok(w) for w in _word_re.findall(text)]
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for t in self._annotate(text):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    def span_tokenize(self, text):
        last_break = 0
        prev_stop = 0
        for m in _period_context_re.finditer(text):
            before = text[prev_stop:m.start()]
            idx = max(before.rfind(c) for c in " \t\n\r\f\v") if before else -1
            if idx >= 0:
                start = prev_stop + idx + 1
            else:
                start = prev_stop
            prev_stop = m.end()
            decision = text[start:m.end()] + m.group("after_tok")
            if self._contains_sentbreak(decision):
                yield (last_break, m.end())
                if m.group("next_tok"):
                    last_break = m.start("next_tok")
                else:
                    last_break = m.end()
        yield (last_break, len(text.rstrip()))

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text) if text[s:e].strip()]


_punkt_cache = {}


def _load_punkt(language):
    # models are re-read when the data path changes; no stale caching of failures
    key = (language, tuple(data.path))
    if key not in _punkt_cache:
        _punkt_cache.clear()
        _punkt_cache[key] = PunktSentenceTokenizer(language)
    return _punkt_cache[key]


def sent_tokenize(text, language="english"):
    return _load_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    sents = [text] if preserve_line else sent_tokenize(text, language)
    out = []
    for s in sents:
        out.extend(_improved.tokenize(s))
    return out


# ---------------------------------------------------------------- Tweets
_EMOTICONS = r"""(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|</?3)"""
_URLS = r"""(?:(?:https?://|www\.)[^\s<>]*[^\s<>.,;:!?\)\]\}'"])"""
_HASHTAG = r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+|\#+[\w_]+)"""
_HANDLE = r"""(?:@[\w_]+)"""
_ARROWS = r"""(?:<{1,}[-]{1,}|[-]{1,}>{1,})"""
_WORDS = r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])|(?:[+\-]?\d+[,/.:-]\d+[+\-]?)|(?:[\w_]+)|(?:\.(?:\s*\.){1,})|(?:\S)"""
_TWEET_RE = re.compile("(%s)" % "|".join([_URLS, _EMOTICONS, _ARROWS, _HASHTAG, _HANDLE, _WORDS]), re.UNICODE)
_EMOTICON_RE = re.compile("^" + _EMOTICONS + "$")
_STRIP_HANDLE_RE = re.compile(r"(?<![A-Za-z0-9_!@#\$%&*])@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = html.unescape(text)
        if self.strip_handles:
            text = _STRIP_HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE_RE.sub(r"\1\1\1", text)
        toks = _TWEET_RE.findall(text)
        toks = [t[0] if isinstance(t, tuple) else t for t in toks]
        if not self.preserve_case:
            toks = [t if _EMOTICON_RE.match(t) else t.lower() for t in toks]
        return toks
