"""Evaluation metrics."""


def accuracy(reference, test):
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if len(reference) == 0:
        raise ValueError("Lists must not be empty.")
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    len1, len2 = len(s1), len(s2)
    d = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        d[i][0] = i
    for j in range(len2 + 1):
        d[0][j] = j
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            a, b = s1[i - 1], s2[j - 1]
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1,
                       d[i - 1][j - 1] + (0 if a == b else substitution_cost))
            if transpositions and i > 1 and j > 1 and s1[i - 2] == b and s1[i - 1] == s2[j - 2]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[len1][len2]


def jaccard_distance(label1, label2):
    union = len(label1.union(label2))
    if union == 0:
        raise ZeroDivisionError("Jaccard distance of two empty sets is undefined")
    return (union - len(label1.intersection(label2))) / union


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test should be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or p == 0 or r == 0:
        return None
    return 1.0 / (alpha / p + (1 - alpha) / r)
