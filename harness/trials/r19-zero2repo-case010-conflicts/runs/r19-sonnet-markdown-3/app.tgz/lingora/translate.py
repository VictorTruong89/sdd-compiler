"""BLEU."""
import math
import sys
from collections import Counter


def _ngrams(seq, n):
    return Counter(tuple(seq[i:i + n]) for i in range(len(seq) - n + 1))


class SmoothingFunction:
    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method0(self, p_n, references, hypothesis, hyp_len):
        return [(n, d) if n != 0 else (sys.float_info.min, d) for n, d in p_n]

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [(n if n != 0 else self.epsilon, d) for n, d in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [(n + 1, d + 1) if i != 0 else (n, d) for i, (n, d) in enumerate(p_n)]


def _modified_precision(references, hypothesis, n):
    counts = _ngrams(hypothesis, n)
    max_counts = {}
    for ref in references:
        rc = _ngrams(ref, n)
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc.get(ng, 0))
    num = sum(min(c, max_counts.get(ng, 0)) for ng, c in counts.items())
    den = max(1, sum(counts.values()))
    return num, den


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(hypothesis, str):
        raise TypeError("hypothesis must be a list of tokens")
    weights = tuple(weights)
    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0
    p_n = [_modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    if p_n[0][0] == 0:
        return 0
    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > closest:
        bp = 1.0
    else:
        bp = math.exp(1 - closest / hyp_len)
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(p_n, references, hypothesis, hyp_len)
    s = math.fsum(w * math.log(n / d) for w, (n, d) in zip(weights, p_n))
    return bp * math.exp(s)


sentence_bleu = bleu
