"""Classifiers."""
import math
from collections import Counter


def _ele_prob(count, total, bins):
    return (count + 0.5) / (total + bins * 0.5)


class ProbDist:
    def __init__(self, probs):
        self._p = dict(probs)

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def samples(self):
        return list(self._p)

    def max(self):
        return max(self._p, key=lambda s: self._p[s])

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p, 2) if p > 0 else float("-inf")


class NaiveBayesClassifier:
    def __init__(self, label_probs, feature_probs, labels):
        self._label_probs = label_probs
        self._feature_probs = feature_probs  # (label, fname) -> (Counter, N, bins)
        self._labels = list(labels)

    @classmethod
    def train(cls, labeled_featuresets):
        label_counts = Counter()
        fcounts = {}
        fvalues = {}
        fnames = []
        seen_f = set()
        for fs, label in labeled_featuresets:
            label_counts[label] += 1
            for fname, fval in fs.items():
                fcounts.setdefault((label, fname), Counter())[fval] += 1
                fvalues.setdefault(fname, set()).add(fval)
                if fname not in seen_f:
                    seen_f.add(fname)
                    fnames.append(fname)
        if not label_counts:
            raise ValueError("cannot train on an empty list")
        for label, num in label_counts.items():
            for fname in fnames:
                c = fcounts.setdefault((label, fname), Counter())
                missing = num - sum(c.values())
                if missing > 0:
                    c[None] += missing
                    fvalues[fname].add(None)
        nl = len(label_counts)
        total = sum(label_counts.values())
        label_probs = {l: _ele_prob(c, total, nl) for l, c in label_counts.items()}
        fp = {}
        for (label, fname), c in fcounts.items():
            fp[(label, fname)] = (c, sum(c.values()), len(fvalues[fname]))
        return cls(label_probs, fp, list(label_counts))

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._feature_probs for l in self._labels)}
        logp = {}
        for label in self._labels:
            lp = math.log(self._label_probs[label])
            for fname, fval in fs.items():
                key = (label, fname)
                if key in self._feature_probs:
                    c, total, bins = self._feature_probs[key]
                    lp += math.log(_ele_prob(c.get(fval, 0), total, bins))
                else:
                    lp = float("-inf")
            logp[label] = lp
        m = max(logp.values())
        exps = {l: math.exp(v - m) for l, v in logp.items()}
        z = sum(exps.values())
        return ProbDist({l: e / z for l, e in exps.items()})

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]


def _entropy(counter):
    n = sum(counter.values())
    return -sum(c / n * math.log(c / n, 2) for c in counter.values() if c)


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.0, depth_cutoff=100, support_cutoff=1, **kw):
        data = list(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on an empty list")
        names = []
        seen = set()
        for fs, _ in data:
            for k in fs:
                if k not in seen:
                    seen.add(k)
                    names.append(k)
        return cls._build(data, names, depth_cutoff)

    @staticmethod
    def _majority(data):
        c = Counter(l for _, l in data)
        best = max(c.values())
        for l, n in c.items():
            if n == best:
                return l

    @classmethod
    def _build(cls, data, names, depth):
        label = cls._majority(data)
        counts = Counter(l for _, l in data)
        if len(counts) == 1 or depth <= 0 or not names:
            return cls(label)
        base_h = _entropy(counts)
        best = None
        for fname in names:
            groups = {}
            for fs, l in data:
                groups.setdefault(fs.get(fname), []).append(l)
            if len(groups) < 2:
                continue
            err = 0
            h = 0.0
            for ls in groups.values():
                c = Counter(ls)
                err += len(ls) - max(c.values())
                h += len(ls) / len(data) * _entropy(c)
            key = (err, h)
            if best is None or key < best[0]:
                best = (key, fname)
        if best is None:
            return cls(label)
        fname = best[1]
        rest = [n for n in names if n != fname]
        groups = {}
        for ex in data:
            groups.setdefault(ex[0].get(fname), []).append(ex)
        decisions = {v: cls._build(g, rest, depth - 1) for v, g in groups.items()}
        return cls(label, fname, decisions, cls(label))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        v = featureset.get(self._fname)
        if v in self._decisions:
            return self._decisions[v].classify(featureset)
        return self._default.classify(featureset)

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        raise ValueError("gold must not be empty")
    results = classifier.classify_many([fs for fs, _ in gold])
    correct = sum(1 for r, (_, l) in zip(results, gold) if r == l)
    return correct / len(gold)
