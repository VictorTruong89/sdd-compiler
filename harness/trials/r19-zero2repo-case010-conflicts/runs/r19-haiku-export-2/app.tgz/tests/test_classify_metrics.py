"""Classifiers (FP-06) and metrics (FP-07)."""

import pytest

from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.metrics import accuracy as list_accuracy
from lingora.metrics import edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.translate import bleu

TRAIN = [
    ({"w": "good", "len": "short"}, "pos"),
    ({"w": "great", "len": "long"}, "pos"),
    ({"w": "bad", "len": "short"}, "neg"),
    ({"w": "awful", "len": "long"}, "neg"),
]


def test_naive_bayes_labels_probs_and_unseen_features():
    nb = NaiveBayesClassifier.train(TRAIN)
    assert nb.labels() == ["pos", "neg"]
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"w": "awful"}) == "neg"
    assert nb.classify({"never": 1}) in nb.labels()
    dist = nb.prob_classify({"w": "good"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert dist.prob("pos") > dist.prob("neg")


def test_decision_tree_fits_training_and_handles_unknown_values():
    dt = DecisionTreeClassifier.train(TRAIN)
    assert [dt.classify(fs) for fs, _ in TRAIN] == [lab for _, lab in TRAIN]
    assert dt.classify({"other": 1}) in ("pos", "neg")


def test_single_separating_feature_is_learned_exactly():
    data = [({"x": 1}, "a"), ({"x": 2}, "b"), ({"x": 1}, "a")]
    dt = DecisionTreeClassifier.train(data)
    assert [dt.classify(fs) for fs, _ in data] == ["a", "b", "a"]


def test_classifier_accuracy():
    assert accuracy(NaiveBayesClassifier.train(TRAIN), TRAIN) == 1.0


def test_edit_distance_costs_and_transpositions():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("a", "b", substitution_cost=2) == 2
    assert edit_distance("", "") == 0


def test_jaccard_and_set_metrics():
    assert jaccard_distance({1, 2, 3}, {2, 3, 4}) == 0.5
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == 0.5
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        precision([1], {1})


def test_list_accuracy():
    assert list_accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])


def test_bleu_identity_and_zero_unigram_match():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["zebra"]) == 0.0
    assert bleu([["a", "b", "c", "d"]], ["a", "b", "c", "d"], weights=[0.25] * 4) == pytest.approx(1.0)
