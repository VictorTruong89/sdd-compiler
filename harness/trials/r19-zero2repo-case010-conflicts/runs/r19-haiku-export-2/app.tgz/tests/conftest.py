"""Shared fixtures: a small packaged-resource tree built in a temp directory.

The real packaged models are not part of the source tree; these fixtures
write tiny model files in the layouts the specification names, and point
``lingora.data.path`` at them for the duration of a test.
"""

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """Create a resource tree and make it the only visible data directory."""
    base = str(tmp_path / "data")
    punkt = os.path.join(base, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "mr\ndr\ne.g\nst\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\n")
    _write(os.path.join(punkt, "collocations.tab"), "e.g\tor\n")
    _write(os.path.join(punkt, "ortho_context.tab"),
           "the\t2\nit\t2\nthe\t16\nthis\t32\nmr\t4\nhe\t2\nand\t64\n")

    tagger = os.path.join(base, "taggers", "averaged_perceptron_tagger_eng")
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.weights.json"),
           '{"bias": {"NN": 1.0}, "i word the": {"DT": 5.0}}')
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.tagdict.json"),
           '{"the": "DT"}')
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.classes.json"),
           '["DT", "NN", "VB"]')
    _write(os.path.join(base, "taggers", "universal_tagset", "en-ptb.map"),
           "NN\tNOUN\nDT\tDET\n")

    _write(os.path.join(base, "corpora", "stopwords", "english"), "the\na\nof\n")

    monkeypatch.setattr(data, "path", [base])
    return base


@pytest.fixture
def no_resources(monkeypatch):
    """No packaged resources visible at all."""
    monkeypatch.setattr(data, "path", [])
    return None
