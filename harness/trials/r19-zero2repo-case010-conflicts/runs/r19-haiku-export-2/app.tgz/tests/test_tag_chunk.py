"""Taggers (FP-03) and the chunker (FP-04)."""

import pytest

from lingora.chunk import RegexpParser
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree


def test_default_tagger_tags_everything():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


def test_unigram_tagger_most_frequent_and_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("dog", "NN"), ("dog", "VB")], [("the", "DT")]]
    t = UnigramTagger(train=train)
    assert t.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", None)]
    t2 = UnigramTagger(train=train, backoff=DefaultTagger("X"))
    assert t2.tag(["zebra"]) == [("zebra", "X")]


def test_regexp_tagger_first_matching_rule_wins():
    t = RegexpTagger([(r".*ing$", "VBG"), (r".*", "NN")])
    assert t.tag(["running", "dog"]) == [("running", "VBG"), ("dog", "NN")]
    assert RegexpTagger([(r"x", "X")]).tag(["abx"]) == [("abx", None)]


def test_pos_tag_requires_list_and_visible_model(resources, no_resources):
    with pytest.raises(TypeError):
        pos_tag("the dog")
    with pytest.raises(LookupError):
        pos_tag(["the"])


def test_pos_tag_english_and_universal(resources):
    assert pos_tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]
    with pytest.raises(ValueError):
        pos_tag(["the"], lang="fra")


TAGGED = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN")]


def test_chunk_rule_builds_noun_phrases():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert tree.label() == "SENT"
    assert tree[0] == Tree("NP", [("the", "DT"), ("little", "JJ"), ("dog", "NN")])
    assert tree[1] == ("barked", "VBD")
    assert tree.leaves() == TAGGED


def test_chink_rule_removes_tokens_from_chunks():
    tree = RegexpParser("NP: {<.*>+}\n    }<VBD|IN>{").parse(TAGGED)
    assert ("barked", "VBD") in list(tree)
    assert ("at", "IN") in list(tree)


def test_cascading_clauses_see_earlier_chunks():
    tree = RegexpParser("NP: {<DT><JJ>*<NN>}\nVP: {<VBD><IN>?<NP>}").parse(TAGGED)
    assert tree[1].label() == "VP"


def test_quantifier_brace_counts():
    tree = RegexpParser("NP: {<NN>{2}}").parse([("a", "NN"), ("b", "NN"), ("c", "VB")])
    assert tree[0] == Tree("NP", [("a", "NN"), ("b", "NN")])


def test_empty_tagged_list_gives_sentence_root():
    assert RegexpParser("NP: {<NN>}").parse([]) == Tree("SENT", [])


def test_bad_grammar_type_refused():
    with pytest.raises(TypeError):
        RegexpParser(5)
