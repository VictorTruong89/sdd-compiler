"""Command line (lingora.cli) and resource lookup (lingora.data)."""

import io
import subprocess
import sys

import pytest

from lingora import data
from lingora.cli import cli

ROOT = __file__.rsplit("/tests/", 1)[0]


def test_data_path_is_mutable_and_honoured(resources):
    assert data.find("tokenizers/punkt_tab/english/")
    data.path[:] = []
    assert not data.is_visible("tokenizers/punkt_tab/english/")
    with pytest.raises(LookupError):
        data.find("tokenizers/punkt_tab/english/")


def test_cli_tokenize_reads_stdin_and_writes_one_line_per_input(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello, world. It is fine!\nSecond line.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) == 0
    out = capsys.readouterr().out
    assert out == "Hello , world . It is fine !\nSecond line .\n"


def test_cli_tokenize_custom_delimiter(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("a b\n"))
    cli.main(args=["tokenize", "-d", "|"], standalone_mode=False)
    assert capsys.readouterr().out == "a|b\n"


def test_cli_tokenize_without_punkt_fails_and_writes_nothing(no_resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello world.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) != 0
    assert capsys.readouterr().out == ""


def test_cli_module_entry_point_subprocess(resources):
    import os

    env = dict(os.environ)
    env["LINGORA_DATA"] = resources
    proc = subprocess.run(
        [sys.executable, "-m", "lingora", "tokenize"],
        input="Hi there.\n", capture_output=True, text=True, cwd=ROOT, env=env,
    )
    assert proc.returncode == 0
    assert proc.stdout == "Hi there .\n"


def test_import_downloads_nothing_and_needs_no_data(no_resources):
    import importlib

    import lingora

    importlib.reload(lingora)
    from lingora.tokenize import wordpunct_tokenize

    assert wordpunct_tokenize("a b") == ["a", "b"]
