"""Tokenizer behaviour from FP-01 (spec: pack 22, Interface Contract pack 07)."""

import pytest

from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


def test_wordpunct_splits_words_and_punctuation():
    assert wordpunct_tokenize("Hi, there!") == ["Hi", ",", "there", "!"]
    assert wordpunct_tokenize("$3.88") == ["$", "3", ".", "88"]


def test_empty_and_whitespace_give_empty_lists():
    for tok in (WordPunctTokenizer(), WhitespaceTokenizer(), TweetTokenizer(), TreebankWordTokenizer()):
        assert tok.tokenize("") == []
        assert tok.tokenize("  \n\t ") == []
    assert blankline_tokenize("  \n\n ") == []


def test_span_tokenize_recovers_tokens():
    text = "ab, cd  ef"
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == ["ab", ",", "cd", "ef"]
    for (s1, e1), (s2, _) in zip(spans, spans[1:]):
        assert e1 <= s2
    assert all(isinstance(x, int) for pair in spans for x in pair)


def test_treebank_conventions():
    tok = TreebankWordTokenizer()
    assert tok.tokenize("They'll save and invest more.") == ["They", "'ll", "save", "and", "invest", "more", "."]
    assert tok.tokenize("hi, my name can't hello,") == ["hi", ",", "my", "name", "ca", "n't", "hello", ","]
    assert tok.tokenize("cannot") == ["can", "not"]
    assert tok.tokenize('He said "hi"') == ["He", "said", "``", "hi", "''"]
    assert tok.tokenize("Good cost $3.88 in New York.") == ["Good", "cost", "$", "3.88", "in", "New", "York", "."]


def test_recommended_word_tokenizer_keeps_cannot_and_splits_typographic_quotes(resources):
    tokens = word_tokenize("I cannot go. “Yes” he said.", preserve_line=True)
    assert "cannot" in tokens
    assert "“" in tokens and "”" in tokens


def test_word_tokenize_splits_sentences_first(resources):
    tokens = word_tokenize("Mr. Smith went home. It was late.")
    assert tokens[:2] == ["Mr.", "Smith"]
    assert "." in tokens


def test_sent_tokenize_uses_punkt(resources):
    text = "Mr. Smith went to Washington. He said it was fine! Did he? Yes, e.g. this works."
    sents = sent_tokenize(text)
    assert sents == [
        "Mr. Smith went to Washington.",
        "He said it was fine!",
        "Did he?",
        "Yes, e.g. this works.",
    ]


def test_missing_punkt_model_raises(no_resources):
    with pytest.raises(LookupError):
        sent_tokenize("A b.")
    with pytest.raises(LookupError):
        word_tokenize("A b.")
    # The non-model path still works.
    assert word_tokenize("A b.", preserve_line=True) == ["A", "b", "."]


def test_blankline_tokenize_segments():
    assert blankline_tokenize("a b\nc\n\n  d  \n\n\ne") == ["a b\nc", "d", "e"]


def test_regexp_tokenizer_modes():
    assert RegexpTokenizer(r"\w+").tokenize("a, b") == ["a", "b"]
    assert RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["", "a", "b", ""]
    assert RegexpTokenizer(r"\s+", gaps=True, discard_empty=True).tokenize(" a  b ") == ["a", "b"]


def test_tweet_tokenizer_defaults_and_options():
    tok = TweetTokenizer()
    assert tok.tokenize("@user I can't :) #wow http://x.com/a!!! Héllo") == [
        "@user", "I", "can't", ":)", "#wow", "http://x.com/a!!!", "Héllo"]
    lower = TweetTokenizer(preserve_case=False)
    assert lower.tokenize("HEY :D") == ["hey", ":D"]
    assert TweetTokenizer(reduce_len=True).tokenize("sooooo") == ["sooo"]
    assert TweetTokenizer(strip_handles=True).tokenize("hi @bob x") == ["hi", "x"]
