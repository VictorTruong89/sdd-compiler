"""Grammars, parsers, generator, and trees (FP-05)."""

import pytest

from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = CFG.fromstring("""
S -> NP VP
NP -> Det N | NP PP
VP -> V NP | VP PP
PP -> P NP
Det -> 'the' | 'a'
N -> 'man' | 'dog' | 'park'
V -> 'saw'
P -> 'in'
""")


def test_grammar_reader():
    assert str(GRAMMAR.start()) == "S"
    assert len(GRAMMAR.productions()) == 13
    rhs = GRAMMAR.productions(lhs="Det")[0].rhs()
    assert rhs == ("the",)
    assert GRAMMAR.productions(lhs="S")[0].rhs()[0] == GRAMMAR.productions(lhs="NP")[0].lhs()


def test_chart_parser_finds_every_tree():
    trees = list(ChartParser(GRAMMAR).parse("the man saw a dog in the park".split()))
    assert len(trees) == 2
    assert all(t.label() == "S" for t in trees)
    assert trees[0].leaves() == "the man saw a dog in the park".split()


def test_underivable_list_is_empty_but_unknown_token_raises():
    assert list(ChartParser(GRAMMAR).parse(["the", "the"])) == []
    with pytest.raises(ValueError):
        list(ChartParser(GRAMMAR).parse(["zzz"]))


def test_shift_reduce_matches_chart_on_unambiguous_sentence():
    g = CFG.fromstring("S -> A B\nA -> 'x'\nB -> 'y'")
    sr = list(ShiftReduceParser(g).parse(["x", "y"]))
    ch = list(ChartParser(g).parse(["x", "y"]))
    assert sr == ch and len(sr) == 1


def test_generator_depth_and_count():
    g = CFG.fromstring('S -> "a" S | "b"')
    assert list(generate(g, depth=4, n=5)) == [["a", "a", "a", "b"], ["a", "a", "b"], ["a", "b"], ["b"]]


def test_tree_bracketed_text_and_equality():
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert t.leaves() == ["the", "dog", "barks"]
    assert "NP" in t.pformat()


def test_tree_refuses_string_children_and_missing_children():
    with pytest.raises(TypeError):
        Tree("S", "dog")
    with pytest.raises(TypeError):
        Tree("S")
    assert len(Tree("S", [])) == 0
