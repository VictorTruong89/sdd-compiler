"""Stemmers (FP-02) and the regexp/Porter/Snowball/Lancaster entries."""

import pytest

from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer


def test_porter_known_outputs():
    p = PorterStemmer(mode="ORIGINAL_ALGORITHM")
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("relational") == "relat"
    assert p.stem("generalization") == "gener"


def test_porter_default_mode_ties_as_published_step_1a():
    assert PorterStemmer().stem("ties") == "ti"


def test_porter_case_is_kept_unless_asked():
    p = PorterStemmer()
    assert p.stem("Running") == p.stem("Running", to_lowercase=False)
    assert p.stem("Running", to_lowercase=True) == "run"


def test_porter_short_words_untouched():
    assert PorterStemmer().stem("is") == "is"
    assert PorterStemmer().stem("AB", to_lowercase=True) == "ab"


def test_snowball_english_outputs():
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("consigned") == "consign"
    assert s.stem("skies") == "sky"
    assert s.stem("communism") == "communism"


def test_snowball_rejects_unknown_language_naming_it():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_snowball_stopwords_need_the_list(no_resources):
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_snowball_stopwords_are_returned_lowercased(resources):
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"


def test_regexp_stemmer_removes_every_match():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("cats") == "cats"


def test_lancaster_lowercases_and_stems():
    assert LancasterStemmer().stem("Running") == "run"
    assert LancasterStemmer().stem("maximum") == "maxim"


def test_wordnet_lemmatizer_needs_wordnet(no_resources):
    from lingora.stem import WordNetLemmatizer

    with pytest.raises(LookupError):
        WordNetLemmatizer()
