"""LINGORA: a pure-Python natural language processing library.

Importing the package downloads nothing. Packaged resources (Punkt models,
the averaged perceptron taggers, wordlists) are looked up through
``lingora.data.path`` when a call needs them.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: F401  (packaged resource finder)
from lingora import tree  # noqa: F401
from lingora import grammar  # noqa: F401
from lingora import tokenize  # noqa: F401
from lingora import stem  # noqa: F401
from lingora import tag  # noqa: F401
from lingora import chunk  # noqa: F401
from lingora import parse  # noqa: F401
from lingora import classify  # noqa: F401
from lingora import metrics  # noqa: F401
from lingora import translate  # noqa: F401
from lingora import cli  # noqa: F401

__all__ = [
    "data", "tree", "grammar", "tokenize", "stem", "tag", "chunk",
    "parse", "classify", "metrics", "translate", "cli",
]
