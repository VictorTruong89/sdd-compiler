"""Packaged resource finder for LINGORA.

# spec: N-000385 N-000386 N-000387 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402

``path`` is a mutable list of directory strings. Resource names are relative
to one of those directories. A caller may replace the list's contents in place
at any time; every lookup goes through :func:`find`, so the current contents
are always honoured. Nothing is downloaded and nothing is cached across a
change of the list.
"""

import os

__all__ = ["path", "find", "is_visible", "read_lines", "read_text", "read_json"]


def _initial_path():
    # Implementer's choice: the initial contents come from the LINGORA_DATA
    # environment variable (os.pathsep separated). Empty when unset.
    raw = os.environ.get("LINGORA_DATA", "")
    return [p for p in raw.split(os.pathsep) if p]


#: Directories searched for packaged resources. Mutable on purpose.
path = _initial_path()


def find(resource):
    """Return the absolute path of ``resource`` under the first directory of
    :data:`path` that holds it, or raise :class:`LookupError`.

    ``resource`` is a relative name such as ``"tokenizers/punkt_tab/english/"``.
    """
    rel = resource.strip("/")
    for base in list(path):
        candidate = os.path.join(base, *rel.split("/"))
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    raise LookupError(
        "packaged resource %r is not visible in data.path %r" % (resource, list(path))
    )


def is_visible(resource):
    """Return True when :func:`find` would succeed for ``resource``."""
    try:
        find(resource)
    except LookupError:
        return False
    return True


def read_text(filepath):
    """Read a UTF-8 text file as shipped (no newline translation tricks)."""
    with open(filepath, encoding="utf-8", newline="") as handle:
        return handle.read()


def read_lines(filepath):
    """Return the lines of a UTF-8 text file without their line terminators."""
    text = read_text(filepath)
    lines = text.splitlines()
    return lines


def read_json(filepath):
    import json

    with open(filepath, encoding="utf-8") as handle:
        return json.load(handle)
