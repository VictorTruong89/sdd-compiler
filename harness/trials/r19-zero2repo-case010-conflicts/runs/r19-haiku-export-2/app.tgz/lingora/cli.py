"""Command line: ``lingora tokenize``.

# spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000135 N-000134 N-000139 N-000083 N-000084 N-000085

``cli.main(args=[...], standalone_mode=True)``. ``tokenize`` reads UTF-8 text
from standard input and writes, for each input line, one output line: the
recommended word tokenizer's tokens (with sentence splitting), joined by the
delimiter (a single space by default), ending with a newline.

Options (implementer's choice): ``--language/-l`` (default ``english``) and
``--delimiter/-d`` (default a single space).

Failure: exit status 1, an error message on standard error, and no token line
for any input. The Punkt model is checked before any input is read, so a
missing model writes nothing at all.
"""

import sys

from lingora import _punkt
from lingora.tokenize import word_tokenize

__all__ = ["cli", "main"]

_USAGE = """Usage: lingora tokenize [--language LANG] [--delimiter DELIM]

Reads UTF-8 text from standard input and writes one line of tokens per input line.
"""


class _Error(Exception):
    pass


def _write_stdout(text):
    sys.stdout.flush()
    buffer = getattr(sys.stdout, "buffer", None)
    if buffer is not None:
        buffer.write(text.encode("utf-8"))
        buffer.flush()
    else:
        sys.stdout.write(text)
        sys.stdout.flush()


def _read_stdin():
    buffer = getattr(sys.stdin, "buffer", None)
    if buffer is not None:
        raw = buffer.read()
        text = raw.decode("utf-8")
    else:
        text = sys.stdin.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [line[:-1] if line.endswith("\r") else line for line in lines]


def _tokenize_command(options):
    language = options["language"]
    delimiter = options["delimiter"]
    # Check the Punkt model first, so a failure writes no token line.
    try:
        _punkt.load_parameters(language)
    except LookupError as exc:
        raise _Error("tokenize needs the Punkt model for %r: %s" % (language, exc))
    lines = _read_stdin()
    out = []
    for line in lines:
        try:
            tokens = word_tokenize(line, language=language)
        except LookupError as exc:
            raise _Error("tokenize failed: %s" % exc)
        out.append(delimiter.join(tokens) + "\n")
    _write_stdout("".join(out))
    return 0


class _Group:
    """The ``lingora`` command group."""

    commands = ("tokenize",)

    def _parse(self, args):
        if not args or args[0] in ("-h", "--help"):
            return None, _USAGE
        command = args[0]
        if command not in self.commands:
            raise _Error("No such command %r." % command)
        options = {"language": "english", "delimiter": " "}
        i = 1
        while i < len(args):
            arg = args[i]
            if arg in ("--language", "-l", "--delimiter", "-d"):
                if i + 1 >= len(args):
                    raise _Error("option %s needs a value" % arg)
                value = args[i + 1]
                key = "language" if arg in ("--language", "-l") else "delimiter"
                options[key] = value
                i += 2
            elif arg.startswith("--language=") or arg.startswith("--delimiter="):
                key, value = arg[2:].split("=", 1)
                options[key] = value
                i += 1
            else:
                raise _Error("unexpected argument %r" % arg)
        return command, options

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            command, options = self._parse(args)
            if command is None:
                _write_stdout(options)
                code = 0
            else:
                code = _tokenize_command(options)
        except _Error as exc:
            sys.stderr.write("lingora: error: %s\n" % exc)
            code = 1 if standalone_mode else 2
        if standalone_mode:
            sys.exit(code)
        return code


cli = _Group()


def main(args=None, standalone_mode=True):
    return cli.main(args=args, standalone_mode=standalone_mode)


if __name__ == "__main__":
    cli.main()
