"""Parsers over a :class:`lingora.grammar.CFG`.

# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
# spec: N-000272 N-000273 N-000274 N-000275 N-000292 N-000293 N-000294 N-000475 N-000476
# spec: N-000473 N-000474

``ChartParser`` returns every parse tree (exhaustive). ``ShiftReduceParser``
makes one left-to-right pass without backtracking.

A token that no production produces makes ``parse`` raise ``ValueError``; a
token list the grammar does not derive yields an empty iterator. That is
the resolution of CF-000090 chosen here (the boundary rule wins).
"""

from lingora.grammar import CFG
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")
        if tok not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % tok)
    return list(tokens)


class ChartParser:
    """Exhaustive parser: every tree the grammar assigns to the tokens."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("ChartParser needs a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._all_trees(tokens))

    def _all_trees(self, tokens):
        grammar = self._grammar
        n = len(tokens)
        by_lhs = {}
        for prod in grammar.productions():
            by_lhs.setdefault(prod.lhs(), []).append(prod)
        memo_sym = {}
        memo_seq = {}
        active = set()

        def trees(sym, i, j):
            key = (sym, i, j)
            if key in memo_sym:
                return memo_sym[key]
            if key in active:  # cycle guard: a symbol cannot derive its own span
                return []
            active.add(key)
            out = []
            for prod in by_lhs.get(sym, ()):
                for children in seq(prod, 0, i, j):
                    out.append(Tree(str(sym), children))
            active.discard(key)
            memo_sym[key] = out
            return out

        def seq(prod, k, i, j):
            key = (id(prod), k, i, j)
            if key in memo_seq:
                return memo_seq[key]
            rhs = prod.rhs()
            if k == len(rhs):
                res = [[]] if i == j else []
            else:
                item = rhs[k]
                res = []
                if isinstance(item, str):
                    if item == "":
                        # An empty terminal adds no token and consumes none.
                        res = seq(prod, k + 1, i, j)
                    elif i < j and tokens[i] == item:
                        res = [[item] + rest for rest in seq(prod, k + 1, i + 1, j)]
                else:
                    for mid in range(i, j + 1):
                        subtrees = trees(item, i, mid)
                        if not subtrees:
                            continue
                        rests = seq(prod, k + 1, mid, j)
                        for t in subtrees:
                            for rest in rests:
                                res.append([t] + rest)
            memo_seq[key] = res
            return res

        return trees(grammar.start(), 0, n)


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("ShiftReduceParser needs a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._run(tokens))

    def _run(self, tokens):
        grammar = self._grammar
        start = str(grammar.start())
        # Empty productions would reduce forever on an empty stack top; skip them.
        prods = [p for p in grammar.productions() if len(p.rhs()) > 0]
        stack = []
        pos = 0
        budget = 50 * (len(tokens) + 1) * (len(prods) + 1) + 100

        def matches(item, sym):
            if isinstance(sym, str):
                return isinstance(item, str) and item == sym
            return isinstance(item, Tree) and item.label() == str(sym)

        while True:
            reduced = False
            for prod in prods:
                rhs = prod.rhs()
                size = len(rhs)
                if size > len(stack):
                    continue
                base = len(stack) - size
                if all(matches(stack[base + k], rhs[k]) for k in range(size)):
                    children = stack[base:]
                    del stack[base:]
                    stack.append(Tree(str(prod.lhs()), children))
                    reduced = True
                    budget -= 1
                    break
            if reduced:
                if budget <= 0:
                    return []  # cyclic unit productions; give up deterministically
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break

        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return [stack[0]]
        return []
