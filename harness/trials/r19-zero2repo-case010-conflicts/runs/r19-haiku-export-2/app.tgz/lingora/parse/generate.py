"""Enumerate sentences derivable from a grammar.

# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480

``generate(grammar, start=None, depth=None, n=None)`` yields sentences (lists
of terminal ``str`` tokens) in production order, up to ``n`` sentences and
with a derivation depth bound ``depth``.

Conflict note (CF-000089): the PRD says a quoted empty string contributes an
empty-string token; the Interface Contract says an empty-string terminal adds
no token. This implementation follows the Contract.
"""

from lingora.grammar import CFG, Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    if not isinstance(grammar, CFG):
        raise TypeError("generate needs a CFG")
    if n is not None and (isinstance(n, bool) or not isinstance(n, int)):
        raise TypeError("n must be an int or None")
    if depth is not None and (isinstance(depth, bool) or not isinstance(depth, int)):
        raise TypeError("depth must be an int or None")
    if start is None:
        start_sym = grammar.start()
    else:
        start_sym = start if isinstance(start, Nonterminal) else Nonterminal(start)

    limit = float("inf") if depth is None else depth
    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(prod.lhs(), []).append(prod)

    def derive_symbol(sym, budget):
        # A nonterminal expansion costs one level of depth.
        if budget <= 0:
            return
        for prod in by_lhs.get(sym, ()):
            yield from derive_seq(prod.rhs(), 0, budget - 1)

    def derive_seq(rhs, k, budget):
        if k == len(rhs):
            yield []
            return
        item = rhs[k]
        if isinstance(item, str):
            head = [item] if item != "" else []
            for rest in derive_seq(rhs, k + 1, budget):
                yield head + rest
        else:
            for first in derive_symbol(item, budget):
                for rest in derive_seq(rhs, k + 1, budget):
                    yield first + rest

    def gen():
        count = 0
        if n is not None and n <= 0:
            return
        for sentence in derive_symbol(start_sym, limit):
            yield list(sentence)
            count += 1
            if n is not None and count >= n:
                return

    return gen()
