"""Run the command line with ``python -m lingora``."""

from lingora.cli import cli

if __name__ == "__main__":
    cli.main()
