"""Context-free grammars.

# spec: N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467 N-000468
# spec: N-000469 N-000470 N-000471 N-000479 N-000480 N-000265 N-000264 N-000262

Grammar text has one production per line, written ``LHS -> RHS``. ``|``
separates alternatives, each becoming its own :class:`Production`. Unquoted
identifiers are nonterminals; single- or double-quoted text is a terminal.
Blank lines and lines starting with ``#`` are ignored.

Nonterminals are returned as :class:`Nonterminal` objects, whose ``str()`` is
the name (implementer's choice allowed by N-000468). Terminals appear in
``rhs()`` as plain ``str`` values without quotes.
"""

import re

__all__ = ["CFG", "Production", "Nonterminal"]


class Nonterminal:
    """A grammar nonterminal. Compares equal by name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        return NotImplemented

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """One alternative ``lhs -> rhs``. ``rhs`` is a tuple of Nonterminal or str."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        # A Nonterminal item is a nonterminal; a plain str item is a terminal.
        self._lhs = lhs if isinstance(lhs, Nonterminal) else Nonterminal(lhs)
        items = []
        for item in rhs:
            if isinstance(item, Nonterminal):
                items.append(item)
            elif isinstance(item, str):
                items.append(item)
            else:
                raise TypeError("rhs items must be Nonterminal or str terminal")
        self._rhs = tuple(items)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(item, str) for item in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        if not isinstance(other, Production):
            return NotImplemented
        return self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for item in self._rhs:
            parts.append(str(item) if isinstance(item, Nonterminal) else "'%s'" % item)
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]*")


def _parse_rhs_alternatives(text, lineno):
    """Split an RHS into alternatives; each alternative is a list of items."""
    alternatives = [[]]
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch == "|":
            alternatives.append([])
            i += 1
        elif ch in ("'", '"'):
            end = text.find(ch, i + 1)
            if end < 0:
                raise ValueError("line %d: unterminated quoted terminal" % lineno)
            alternatives[-1].append(text[i + 1:end])
            i = end + 1
        else:
            m = _IDENT.match(text, i)
            if not m:
                raise ValueError("line %d: unexpected character %r" % (lineno, ch))
            alternatives[-1].append(Nonterminal(m.group(0)))
            i = m.end()
    return alternatives


class CFG:
    """A context-free grammar: a start symbol and a list of productions."""

    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(start)
        self._start = start
        self._productions = list(productions)
        for prod in self._productions:
            if not isinstance(prod, Production):
                raise TypeError("productions must be Production objects")

    @classmethod
    def fromstring(cls, input):
        """Build a grammar from text. Raises ValueError on a malformed line."""
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring needs a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("line %d: expected 'LHS -> RHS'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            m = _IDENT.fullmatch(lhs_text)
            if not m:
                raise ValueError("line %d: bad left-hand side %r" % (lineno, lhs_text))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alt in _parse_rhs_alternatives(rhs_text, lineno):
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        out = self._productions
        if lhs is not None:
            out = [p for p in out if p.lhs() == (lhs if isinstance(lhs, Nonterminal) else Nonterminal(lhs))]
        return list(out)

    def nonterminals(self):
        seen = []
        for prod in self._productions:
            for sym in (prod.lhs(),):
                if sym not in seen:
                    seen.append(sym)
        return seen

    def terminals(self):
        seen = set()
        for prod in self._productions:
            for item in prod.rhs():
                if isinstance(item, str):
                    seen.add(item)
        return seen

    def __str__(self):
        return "Grammar with %d productions (start state = %s)" % (len(self._productions), self._start)

    def __repr__(self):
        return "<" + str(self) + ">"
