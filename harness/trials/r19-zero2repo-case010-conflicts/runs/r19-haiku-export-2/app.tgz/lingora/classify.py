"""Naive Bayes and decision-tree classifiers.

# spec: N-000492 N-000493 N-000494 N-000495 N-000496 N-000497 N-000295 N-000296
# spec: N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304
# spec: N-000305 N-000306 N-000307 N-000308 N-000309 N-000310 N-000311 N-000312
# spec: N-000313 N-000314 N-000315 N-000316 N-000317 N-000318

Featuresets are dicts from feature names to values; labels are any hashable
value. Naive Bayes smooths feature likelihoods with expected-likelihood
estimation (add 0.5), so no value seen under one label gets probability zero
under another.
"""

import math
from collections import Counter, defaultdict

__all__ = [
    "NaiveBayesClassifier",
    "DecisionTreeClassifier",
    "ProbDist",
    "accuracy",
]


def _check_labeled(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes)) or not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    if not labeled_featuresets:
        raise ValueError("cannot train on an empty list")
    out = []
    for pair in labeled_featuresets:
        if not isinstance(pair, tuple) or len(pair) != 2 or not isinstance(pair[0], dict):
            raise TypeError("each item must be a (featureset dict, label) pair")
        out.append((pair[0], pair[1]))
    return out


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)  # label -> float, insertion ordered

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes over featuresets."""

    # spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309

    def __init__(self, label_counts, label_order, feature_counts, feature_totals, feature_values):
        self._label_counts = label_counts
        self._labels = label_order
        self._feature_counts = feature_counts  # (label, fname, fval) -> count
        self._feature_totals = feature_totals  # (label, fname) -> examples with that feature
        self._feature_values = feature_values  # fname -> set of values seen (all labels)
        self._total = sum(label_counts.values())

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        label_order = []
        feature_counts = Counter()
        feature_totals = Counter()
        feature_values = defaultdict(set)
        for fs, label in pairs:
            if label not in label_counts:
                label_order.append(label)
            label_counts[label] += 1
            for fname, fval in fs.items():
                feature_counts[(label, fname, fval)] += 1
                feature_totals[(label, fname)] += 1
                feature_values[fname].add(fval)
        return cls(label_counts, label_order, feature_counts, feature_totals, dict(feature_values))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            score = math.log(self._label_counts[label] / self._total)
            for fname, fval in featureset.items():
                if fname not in self._feature_values:
                    continue  # never seen in training: ignored
                total = self._feature_totals.get((label, fname), 0)
                if total == 0:
                    continue  # this feature name never occurred with this label
                bins = len(self._feature_values[fname])
                count = self._feature_counts.get((label, fname, fval), 0)
                prob = (count + 0.5) / (total + 0.5 * bins)
                score += math.log(prob)
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(scores[label] - top) for label in self._labels}
        norm = sum(weights.values())
        return ProbDist({label: weights[label] / norm for label in self._labels})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        best = self._labels[0]
        for label in self._labels[1:]:
            if scores[label] > scores[best]:
                best = label
        return best


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _majority(labels):
    counts = Counter()
    order = []
    for label in labels:
        if label not in counts:
            order.append(label)
        counts[label] += 1
    best = order[0]
    for label in order[1:]:
        if counts[label] > counts[best]:
            best = label
    return best


class DecisionTreeClassifier:
    """Tree of feature tests, chosen greedily by how well each test separates the examples."""

    # spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        features = []
        for fs, _ in pairs:
            for fname in fs:
                if fname not in features:
                    features.append(fname)
        return cls(cls._build(pairs, features))

    @staticmethod
    def _build(examples, features):
        labels = [label for _, label in examples]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Leaf(majority)
        best_feature = None
        best_acc = -1.0
        for fname in features:
            groups = defaultdict(Counter)
            for fs, label in examples:
                groups[fs.get(fname)][label] += 1
            correct = sum(max(c.values()) for c in groups.values())
            acc = correct / len(examples)
            if acc > best_acc:
                best_acc = acc
                best_feature = fname
        partitions = defaultdict(list)
        for fs, label in examples:
            partitions[fs.get(best_feature)].append((fs, label))
        if len(partitions) == 1:
            return _Leaf(majority)
        remaining = [f for f in features if f != best_feature]
        children = {
            value: DecisionTreeClassifier._build(sub, remaining)
            for value, sub in partitions.items()
        }
        return _Node(best_feature, children, majority)

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs whose label the classifier gets right."""
    if isinstance(gold, (str, bytes)) or not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = 0
    for fs, label in gold:
        if classifier.classify(fs) == label:
            correct += 1
    return correct / len(gold)
