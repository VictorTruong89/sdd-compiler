"""Evaluation metrics: edit distance, Jaccard distance, accuracy, precision, recall, f-measure.

# spec: N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505
# spec: N-000506 N-000507 N-000508 N-000509 N-000510 N-000319 N-000320 N-000321
# spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329
# spec: N-000330 N-000331 N-000332 N-000333 N-000334 N-000343 N-000344 N-000345
# spec: N-000346 N-000347 N-000348

Resolutions of spec conflicts (see NOTES.md):
* CF-000008 / CF-000039 / CF-000072: accuracy on lists of different lengths raises
  ValueError (Interface Contract and two PRD claims agree).
* CF-000016 / CF-000055 / CF-000070: transpositions are the restricted
  (optimal string alignment) form: only two characters adjacent in both strings
  may be swapped, with nothing inserted or deleted between them.
* CF-000086: precision and recall refuse non-set arguments with TypeError.
"""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def accuracy(reference, test):
    if isinstance(reference, (str, bytes)) or not isinstance(reference, (list, tuple)):
        raise TypeError("reference must be a list")
    if isinstance(test, (str, bytes)) or not isinstance(test, (list, tuple)):
        raise TypeError("test must be a list")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy of empty lists is undefined")
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Minimum total cost of insertions, deletions, substitutions and (optionally)
    transpositions turning ``s1`` into ``s2``."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance needs two str arguments")
    if not _is_number(substitution_cost):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be a bool")
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            same = s1[i - 1] == s2[j - 1]
            best = min(
                d[i - 1][j] + 1,
                d[i][j - 1] + 1,
                d[i - 1][j - 1] + (0 if same else substitution_cost),
            )
            if (transpositions and i > 1 and j > 1
                    and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]):
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union| of two sets (0 when both are empty)."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance needs two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets or frozensets")


def precision(reference, test):
    """|reference ∩ test| / |test|, or None when test is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|, or None when reference is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1-alpha)/recall).

    None when either set is empty or the two sets share no element."""
    _check_sets(reference, test)
    if not _is_number(alpha) or not 0 <= alpha <= 1:
        raise ValueError("alpha must be a number between 0 and 1")
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    return 1.0 / (alpha / p + (1 - alpha) / r)
