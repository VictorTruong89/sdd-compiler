"""Stemmers and the WordNet lemmatizer.

# spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428
# spec: N-000429 N-000430 N-000431 N-000432 N-000140 N-000141 N-000142 N-000143
# spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151
# spec: N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159
# spec: N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167
# spec: N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000174 N-000175
# spec: N-000176 N-000177 N-000178 N-000179 N-000180 N-000181 N-000182 N-000183
# spec: N-000184 N-000185 N-000186

Resolutions of spec conflicts (see NOTES.md for the full list):
* CF-000073 (Step 1a): the Interface Contract says ``PorterStemmer`` applies
  Step 1a as published, so ``ties`` -> ``ti``. The LINGORA -ies -> -ie rule is
  therefore not applied in the default mode.
* CF-000091 (case): ``to_lowercase`` defaults to ``False`` (Interface Contract).

Snowball: the ``english`` (Porter2) and ``porter`` (original Porter) languages
are implemented. The other listed languages are accepted names but raise
NotImplementedError when constructed; see NOTES.md.
"""

import os
import re

from lingora import data

__all__ = [
    "PorterStemmer",
    "LancasterStemmer",
    "SnowballStemmer",
    "RegexpStemmer",
    "ARLSTem",
    "ARLSTem2",
    "WordNetLemmatizer",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str")


# ---------------------------------------------------------------------------
# Porter (1980) with the LINGORA extensions
# ---------------------------------------------------------------------------

_PORTER_IRREGULAR = {
    "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "odds": "odd", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}

_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _is_cons(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return True if i == 0 else not _is_cons(word, i - 1)
    return True


def _measure(stem):
    # Number of VC sequences in the form [C](VC){m}[V].
    m = 0
    prev_vowel = False
    for i in range(len(stem)):
        vowel = not _is_cons(stem, i)
        if prev_vowel and not vowel:
            m += 1
        prev_vowel = vowel
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _cvc(word, extended):
    """Ends consonant-vowel-consonant, final not w, x, y.

    ``extended`` adds the LINGORA rule: a two-letter vowel-consonant stem also counts."""
    if len(word) == 2 and extended:
        return (not _is_cons(word, 0)) and _is_cons(word, 1) and word[1] not in "wxy"
    if len(word) < 3:
        return False
    return (_is_cons(word, len(word) - 3) and not _is_cons(word, len(word) - 2)
            and _is_cons(word, len(word) - 1) and word[-1] not in "wxy")


class _PorterCore:
    def __init__(self, extensions):
        self.ext = extensions

    def stem(self, word):
        if word in _PORTER_IRREGULAR and self.ext:
            return _PORTER_IRREGULAR[word]
        if len(word) <= 2:
            return word
        w = self._step1a(word)
        w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5a(w)
        w = self._step5b(w)
        return w

    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            # LINGORA extension (-ies -> -ie) is disabled by the Contract's Step 1a rule.
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    def _step1b(self, w):
        if self.ext and w.endswith("ied"):
            # LINGORA: -ied -> -ie (four letters) or -i; the rest of Step 1b is skipped.
            return w[:-3] + ("ie" if len(w) == 4 else "i")
        if w.endswith("eed"):
            stem = w[:-3]
            if _measure(stem) > 0:
                return stem + "ee"
            return w
        for suffix in ("ing", "ed"):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if not _has_vowel(stem):
                    return w
                if stem.endswith(("at", "bl", "iz")):
                    return stem + "e"
                if _double_cons(stem) and stem[-1] not in "lsz":
                    return stem[:-1]
                if _measure(stem) == 1 and _cvc(stem, self.ext):
                    return stem + "e"
                return stem
        return w

    def _step1c(self, w):
        if w.endswith("y"):
            stem = w[:-1]
            if self.ext:
                if len(w) > 2 and _is_cons(w, len(w) - 2):
                    return stem + "i"
            elif _has_vowel(stem):
                return stem + "i"
        return w

    def _step2(self, w):
        if self.ext and w.endswith("alli") and _measure(w[:-4]) > 0:
            # LINGORA: -alli -> -al is tried first, and Step 2 then runs again on the result.
            return self._step2_rules(w[:-4] + "al")
        return self._step2_rules(w)

    def _step2_rules(self, w):
        rules = list(_STEP2_ORIGINAL)
        if self.ext:
            rules = [
                ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
                ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
                ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
                ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
                ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
            ]
        for suffix, repl in sorted(rules, key=lambda r: -len(r[0])):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        if self.ext and w.endswith("logi") and _measure(w[:-3]) > 0:
            return w[:-1]  # -logi -> -log
        return w

    def _step3(self, w):
        for suffix, repl in sorted(_STEP3, key=lambda r: -len(r[0])):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step4(self, w):
        for suffix in sorted(_STEP4, key=len, reverse=True):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if suffix == "ion":
                    if _measure(stem) > 1 and stem and stem[-1] in "st":
                        return stem
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    def _step5a(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _cvc(stem, self.ext)):
                return stem
        return w

    def _step5b(self, w):
        if _measure(w) > 1 and _double_cons(w) and w.endswith("l"):
            return w[:-1]
        return w


class PorterStemmer:
    """Porter's algorithm. ``mode`` selects the variant:

    * ``"LINGORA_EXTENSIONS"`` (default): the LINGORA extensions of FP-02.
    * ``"MARTIN_EXTENSIONS"``: the published algorithm with -bli, -logi, -fulli
      rules only (results of the other modes are outside the specification).
    * ``"ORIGINAL_ALGORITHM"``: the published 1980 algorithm.
    """

    MODES = ("LINGORA_EXTENSIONS", "MARTIN_EXTENSIONS", "ORIGINAL_ALGORITHM")

    # spec: N-000149 N-000150 N-000151 N-000153 N-000155 N-000156 N-000157 N-000168 N-000169
    def __init__(self, mode="LINGORA_EXTENSIONS"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._core = _PorterCore(extensions=(mode == "LINGORA_EXTENSIONS"))

    def stem(self, word, to_lowercase=False):
        _check_word(word)
        if not isinstance(to_lowercase, bool):
            raise TypeError("to_lowercase must be a bool")
        if to_lowercase:
            word = word.lower()
        if self._mode == "ORIGINAL_ALGORITHM" and len(word) <= 2:
            return word
        return self._core.stem(word)


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rules in the Paice/Husk notation: reversed ending, '*' = intact only,
# digit = letters removed, appended letters, '.' stop or '>' continue.
# Reconstructed from the published table; see NOTES.md.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "earth3>", "ef1>", "eig2ct.",
    "eir4>", "elpm4.", "em2>", "en3>", "eng2ss.", "eng1.", "ens4>", "ep3>",
    "eq2>", "es2>", "esr1.", "ev1>", "eyl3>", "fi2>", "gni3>", "gai3y.", "ga2>",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.",
    "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.",
    "lbai4y.", "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "lu2.", "lai3>",
    "lau3>", "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>",
    "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "nih3.",
    "nj1.", "nn1.", "nsi3>", "nal1.", "nid4.", "nsum4s.", "nal2.", "nsi4.",
    "pihs2>", "pp1.", "pe2>", "pirt2.", "rrem3>", "rs2>", "rs1.", "sei3y>",
    "ssen4>", "ss0.", "sis2.", "si2>", "sb1>", "sy2>", "ta2>", "tnem4.",
    "tn3>", "tl2>", "tr2>", "tt1.", "ta2>", "uiu3.", "uf2>", "ul2>", "ue2>",
    "um1.", "un2>", "ur3>", "us2>", "ut2>", "vis3j>", "vi2>", "vs2>", "vm2>",
    "wai1.", "ycn2>", "yt1.", "yr1.", "yp2>", "yl2>", "y2>", "zi2>", "zy1s.",
]


def _parse_lancaster_rule(rule):
    m = re.match(r"^([a-z]+)(\*?)(\d?)([a-z]*)([.>])$", rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    letters, intact, remove, append, term = m.groups()
    return {
        "suffix": letters[::-1],
        "intact": bool(intact),
        "remove": int(remove) if remove else 0,
        "append": append,
        "stop": term == ".",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer:
    """Paice/Husk stemmer. Lowercases the word; strips no prefix."""

    # spec: N-000170 N-000171
    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        while True:
            applied = False
            for rule in _LANCASTER_PARSED:
                if not word.endswith(rule["suffix"]):
                    continue
                if rule["intact"] and not intact:
                    continue
                remove = rule["remove"]
                if remove >= len(word):
                    continue
                remainder = word[:-remove] + rule["append"] if remove else word + rule["append"]
                min_len = 2 if remainder and remainder[0] in "aeiou" else 3
                if len(remainder) < min_len:
                    continue
                word = remainder
                intact = False
                applied = True
                if rule["stop"]:
                    return word
                break
            if not applied:
                return word


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer:
    """Removes every match of the caller's pattern from the word."""

    # spec: N-000178 N-000179 N-000180
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regex = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regex.sub("", word)


# ---------------------------------------------------------------------------
# Snowball: Porter2 (english) and the original Porter (porter)
# ---------------------------------------------------------------------------

_SNOW_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_SNOW_EXC2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_VOWELS = "aeiouy"


def _snow_v(ch):
    return ch in _VOWELS


def _region_start(w, start=0):
    for i in range(start + 1, len(w)):
        if not _snow_v(w[i]) and _snow_v(w[i - 1]):
            return i + 1
    return len(w)


def _snow_ends_short(w):
    if len(w) >= 3:
        a, b, c = w[-3], w[-2], w[-1]
        return (not _snow_v(a)) and _snow_v(b) and (not _snow_v(c)) and c not in "wxY"
    if len(w) == 2:
        return _snow_v(w[0]) and (not _snow_v(w[1])) and w[1] not in "wxY"
    return False


def _longest(w, suffixes):
    best = None
    for suf in suffixes:
        if w.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    return best


def _snowball_english(word):
    if word in _SNOW_EXC1:
        return _SNOW_EXC1[word]
    if len(word) <= 2:
        return word

    # Mark a y at the start, or after a vowel, as a consonant ('Y').
    chars = list(word)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and _snow_v(word[i - 1]):
            chars[i] = "Y"
    w = "".join(chars)

    if w.startswith(("gener", "commun", "arsen")):
        r1 = 6 if w.startswith("commun") else 5
    else:
        r1 = _region_start(w)
    r2 = _region_start(w, r1)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[:-len(suf)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith("ss") or w.endswith("us"):
        pass
    elif w.endswith("s"):
        if any(_snow_v(c) for c in w[:-2]):
            w = w[:-1]

    if w in _SNOW_EXC2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eedly", "eed")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[:-len(suf)] + "ee"
    else:
        suf = _longest(w, ("ingly", "edly", "ing", "ed"))
        if suf:
            stem = w[:-len(suf)]
            if any(_snow_v(c) for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                    w = w[:-1]
                elif r1 >= len(w) and _snow_ends_short(w):
                    w += "e"

    # Step 1c
    if w.endswith("y") and len(w) > 2 and not _snow_v(w[-2]):
        w = w[:-1] + "i"

    # Step 2 (in R1)
    s2 = {
        "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
        "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
        "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
        "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
        "ogi": "og", "fulli": "ful", "lessli": "less", "li": "",
    }
    suf = _longest(w, s2.keys())
    if suf and len(w) - len(suf) >= r1:
        stem = w[:-len(suf)]
        if suf == "ogi":
            if stem.endswith("l"):
                w = stem + "og"
        elif suf == "li":
            if stem and stem[-1] in "cdeghkmnrt":
                w = stem
        else:
            w = stem + s2[suf]

    # Step 3 (R1; ative in R2)
    s3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic",
          "iciti": "ic", "ical": "ic", "ful": "", "ness": ""}
    suf = _longest(w, list(s3.keys()) + ["ative"])
    if suf:
        start = len(w) - len(suf)
        if suf == "ative":
            if start >= r2:
                w = w[:start]
        elif start >= r1:
            w = w[:start] + s3[suf]

    # Step 4 (R2)
    s4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
          "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    suf = _longest(w, s4)
    if suf:
        start = len(w) - len(suf)
        if start >= r2:
            if suf == "ion":
                if start > 0 and w[start - 1] in "st":
                    w = w[:start]
            else:
                w = w[:start]

    # Step 5
    if w.endswith("e"):
        start = len(w) - 1
        if start >= r2 or (start >= r1 and not _snow_ends_short(w[:-1])):
            w = w[:-1]
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w.endswith("ll"):
            w = w[:-1]

    return w.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmers. ``language`` is one of SNOWBALL_LANGUAGES."""

    # spec: N-000181 N-000182 N-000183 N-000184 N-000172 N-000173 N-000174 N-000175
    # spec: N-000176 N-000177 N-000429 N-000430 N-000431
    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if not isinstance(ignore_stopwords, bool):
            raise TypeError("ignore_stopwords must be a bool")
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemming for %r is not implemented in this build" % language)
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            path = data.find("corpora/stopwords/%s" % language)  # LookupError when absent
            self._stopwords = set(w.strip().lower() for w in data.read_lines(path) if w.strip())

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self._language == "english":
            return _snowball_english(word)
        if len(word) <= 2:
            return word
        return _PorterCore(extensions=False).stem(word)


# ---------------------------------------------------------------------------
# Arabic stemmers (outside the specified results) and WordNet lemmatizer
# ---------------------------------------------------------------------------

class ARLSTem:
    """Placeholder entry point: its stemming results are outside this specification.

    ``stem`` returns the word unchanged. See NOTES.md."""

    def stem(self, word):
        _check_word(word)
        return word


class ARLSTem2(ARLSTem):
    """Placeholder entry point (see ARLSTem)."""


_WN_POS_FILES = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "s": "index.adj",
                 "r": "index.adv"}
_NOUN_RULES = [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
               ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")]


class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet index files. Requires ``corpora/wordnet``.

    Lookup is a WordNet index membership check with simple detachment rules;
    full WordNet morphy is outside this specification."""

    # spec: N-000432 N-000185 N-000186
    def __init__(self):
        self._dir = data.find("corpora/wordnet")  # LookupError when not visible
        self._index = {}

    def _lemmas(self, pos):
        key = _WN_POS_FILES.get(pos, "index.noun")
        if key not in self._index:
            names = set()
            filepath = os.path.join(self._dir, key)
            if os.path.isfile(filepath):
                for line in data.read_lines(filepath):
                    if line and not line.startswith(" "):
                        names.add(line.split(" ", 1)[0])
            self._index[key] = names
        return self._index[key]

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        lemmas = self._lemmas(pos)
        if word in lemmas:
            return word
        if pos == "n":
            for suffix, repl in _NOUN_RULES:
                if word.endswith(suffix):
                    candidate = word[:-len(suffix)] + repl
                    if candidate in lemmas:
                        return candidate
        return word
