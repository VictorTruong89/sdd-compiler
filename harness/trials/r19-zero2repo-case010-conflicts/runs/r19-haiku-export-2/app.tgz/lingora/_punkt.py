"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

# spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000137 N-000138
# spec: N-000086 N-000087 N-000088 N-000389 N-000395 N-000397 N-000398

Only the decision phase is implemented: the packaged parameters (abbreviation
types, collocations, sentence starters and orthographic context) are read from
``tokenizers/punkt_tab/<language>/`` and applied to the text. Training is not
part of LINGORA's surface.
"""

import os
import re

from lingora import data

__all__ = ["PunktParameters", "load_parameters", "sentence_spans"]

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

SENT_END_CHARS = (".", "?", "!")

# Word tokenization used before the decisions (same shape as the Punkt
# reference tokenizer): multi-character punctuation, words, or single symbols.
_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_TOKEN_RE = re.compile(
    r"(?:%(multi)s)"
    r"|(?=[^\(\"\`{\[:;&\#\*@\)}\]\-,])\S+?"
    r"(?=\s|$|%(nonword)s|%(multi)s|,(?=$|\s|%(nonword)s|%(multi)s))"
    r"|\S"
    % {"multi": _MULTI, "nonword": _NON_WORD}
)

_NUMBER_RE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS_RE = re.compile(r"\.\.+$")
_CLOSERS = frozenset(['"', "'", ")", "]", "}", "”", "’", "''"])


class PunktParameters:
    """The packaged parameters for one language."""

    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


_cache = {}


def _read_lines_or_empty(filepath):
    if not os.path.isfile(filepath):
        return []
    return data.read_lines(filepath)


def load_parameters(language):
    """Load the Punkt parameters for ``language`` (for example ``"english"``).

    Raises LookupError when the language's Punkt model directory is not visible.
    """
    if not language or "/" in language or os.sep in language or language.startswith("."):
        raise LookupError("no Punkt model for language %r" % (language,))
    base = data.find("tokenizers/punkt_tab/%s/" % language)
    if not os.path.isdir(base):
        raise LookupError("Punkt model for %r is not a directory: %s" % (language, base))
    files = [os.path.join(base, n) for n in (
        "abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")]
    stamp = tuple(
        (f, os.stat(f).st_mtime_ns, os.stat(f).st_size) if os.path.isfile(f) else (f,)
        for f in files
    )
    cached = _cache.get(base)
    if cached is not None and cached[0] == stamp:
        return cached[1]

    abbrev = set()
    for line in _read_lines_or_empty(files[0]):
        line = line.strip()
        if line:
            abbrev.add(line.lower())
    starters = set()
    for line in _read_lines_or_empty(files[1]):
        line = line.strip()
        if line:
            starters.add(line.lower())
    colloc = set()
    for line in _read_lines_or_empty(files[2]):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines_or_empty(files[3]):
        parts = line.split("\t")
        if len(parts) == 2:
            try:
                ortho[parts[0]] = int(parts[1])
            except ValueError:
                raise ValueError("bad ortho_context line: %r" % line)
    params = PunktParameters(abbrev, starters, colloc, ortho)
    _cache[base] = (stamp, params)
    return params


class _Tok:
    __slots__ = ("tok", "start", "end", "period_final", "is_ellipsis", "is_initial",
                 "first_upper", "first_lower", "type_", "type_no_period",
                 "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok, start, end):
        self.tok = tok
        self.start = start
        self.end = end
        self.period_final = tok.endswith(".")
        self.is_ellipsis = _ELLIPSIS_RE.search(tok) is not None
        self.type_ = _NUMBER_RE.sub("##number##", tok.lower())
        self.type_no_period = self.type_[:-1] if self.period_final else self.type_
        self.is_initial = self.period_final and re.fullmatch(r"[^\W\d_]", tok[:-1]) is not None
        self.first_upper = tok[:1].isupper()
        self.first_lower = tok[:1].islower()
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type_


def _ortho_heuristic(tok, params):
    """True: likely a sentence starter. False: not one. None: unsure."""
    if tok.tok in SENT_END_CHARS:
        return False
    ctx = params.ortho_context.get(tok.type_no_sentperiod, 0)
    # A capitalised word seen lower-case but never mid-sentence upper-case is not a starter.
    if tok.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
        return False
    # A lower-case word seen upper-case, or never seen mid-sentence in lower-case, starts one.
    if tok.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_MID_LC)):
        return True
    return None


def _tokenize(text):
    out = []
    for m in _TOKEN_RE.finditer(text):
        out.append(_Tok(m.group(0), m.start(), m.end()))
    return out


def sentence_spans(text, language="english"):
    """Return (start, end) character spans of the sentences of ``text``."""
    params = load_parameters(language)
    toks = _tokenize(text)
    if not toks:
        return []

    # First pass: obvious sentence ends and known abbreviations.
    for t in toks:
        if t.tok in SENT_END_CHARS:
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final:
            base = t.tok[:-1].lower()
            if base in params.abbrev_types or base.split("-")[-1] in params.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    # Second pass: decisions that look at the following token.
    for idx in range(len(toks) - 1):
        t1 = toks[idx]
        t2 = toks[idx + 1]
        if not t1.period_final:
            continue
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        if (typ, next_typ) in params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            continue
        if (t1.abbr or t1.ellipsis) and not t1.is_initial:
            if _ortho_heuristic(t2, params) is True:
                t1.sentbreak = True
                continue
            if t2.first_upper and next_typ in params.sent_starters:
                t1.sentbreak = True
                continue
        if t1.is_initial or typ == "##number##":
            if _ortho_heuristic(t2, params) is False:
                t1.sentbreak = False
                t1.abbr = True
                continue
            if t2.first_upper and next_typ in params.sent_starters:
                t1.sentbreak = True

    # Group tokens into sentences at the breaks.
    groups = []
    current = []
    for t in toks:
        current.append(t)
        if t.sentbreak:
            groups.append(current)
            current = []
    if current:
        groups.append(current)

    # Realign: closing quotes or brackets that open a group belong to the previous one.
    merged = []
    for group in groups:
        if merged:
            k = 0
            while k < len(group) and group[k].tok in _CLOSERS:
                k += 1
            if k:
                merged[-1].extend(group[:k])
                group = group[k:]
                if not group:
                    continue
        merged.append(list(group))

    return [(g[0].start, g[-1].end) for g in merged if g]
