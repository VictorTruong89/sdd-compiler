"""Word, punctuation and sentence tokenizers.

# spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410
# spec: N-000411 N-000412 N-000413 N-000081 N-000082 N-000083 N-000084 N-000085
# spec: N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093
# spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101
# spec: N-000102 N-000103 N-000104 N-000105 N-000106 N-000107 N-000108 N-000109
# spec: N-000110 N-000111 N-000112 N-000113 N-000114 N-000115 N-000116 N-000117
# spec: N-000118 N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125
# spec: N-000126 N-000127 N-000128 N-000136 N-000138 N-000139

Resolutions of spec conflicts:
* CF-000001: a straight double quote at the start of the text is the opening
  token ``( `` ) for the Penn Treebank tokenizer and the closing token ( '' )
  for the recommended word tokenizer, which the PRD lists as an improvement.
* CF-000083: *cannot* is split by the Penn Treebank tokenizer and kept whole by
  the recommended word tokenizer (its listed improvement).
* CF-000077: the regexp tokenizer's ``discard_empty`` is off by default (the
  Interface Contract), so empty pieces are kept unless the caller asks.
* CF-000054: the tweet tokenizer does not lowercase emoticons.
"""

import re

from lingora import _punkt

__all__ = [
    "wordpunct_tokenize",
    "WordPunctTokenizer",
    "TreebankWordTokenizer",
    "word_tokenize",
    "sent_tokenize",
    "WhitespaceTokenizer",
    "blankline_tokenize",
    "RegexpTokenizer",
    "TweetTokenizer",
]


def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str" % name)


def _check_bool(value, name):
    if not isinstance(value, bool):
        raise TypeError("%s must be a bool" % name)


# ---------------------------------------------------------------------------
# Word / punctuation tokenizer
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    """Maximal runs of word characters, and maximal runs of other non-space characters."""
    _check_text(text)
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer:
    # spec: N-000089 N-000090 N-000091
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in _WORDPUNCT_RE.finditer(text):
            yield (m.start(), m.end())


# ---------------------------------------------------------------------------
# Penn Treebank word tokenizer and LINGORA's recommended variant
# ---------------------------------------------------------------------------

_CLITIC_RE = re.compile(
    r"(?i)([^\s'])('ll|'re|'ve|n't|'s|'m|'d)(?=[\s.,;:!?\)\]\}\"'])")
_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_CONTRACTIONS3 = [
    re.compile(r"(?i)(\s)('t)(is)\b"),
    re.compile(r"(?i)(\s)('t)(was)\b"),
]
_TYPO_DOUBLE = re.compile(r"([«»“”„‟])")
_TYPO_SINGLE = re.compile(r"(?<![^\W\d_])[‘’‚‛]|[‘’‚‛](?![^\W\d_])")
_DASH_STAR = re.compile(r"([‒-―*])")
_POINT_RUN = re.compile(r"\.{2,}")


def _treebank(text, improved):
    if improved and text.startswith('"'):
        s = " '' " + text[1:]
    else:
        s = text
    s = " " + s + " "
    # Straight double quotes: opening after start, space or an opening bracket; closing otherwise.
    s = re.sub(r'([ (\[{<])"', r"\1 `` ", s)
    s = s.replace('"', " '' ")
    # Commas and colons unless a digit follows; ellipses; some symbols.
    s = re.sub(r"([:,])([^\d])", r" \1 \2", s)
    s = s.replace("...", " ... ")
    s = re.sub(r"[;@#$%&]", r" \g<0> ", s)
    # A point only when it ends the text, optionally followed by closing quotes or brackets.
    s = re.sub(r"([^.])(\.)([\]\)}>\"']*)\s*$", r"\1 \2\3 ", s)
    s = re.sub(r"[?!]", r" \g<0> ", s)
    # A bare apostrophe ending a word.
    s = re.sub(r"([^'])' ", r"\1 ' ", s)
    # Brackets, double hyphen.
    s = re.sub(r"[\]\[\(\)\{\}<>]", r" \g<0> ", s)
    s = s.replace("--", " -- ")
    # Ending quotes and clitics.
    s = s.replace("''", " '' ")
    s = _CLITIC_RE.sub(r"\1 \2", s)
    for regex in _CONTRACTIONS2:
        if improved and regex.pattern.startswith(r"(?i)\b(can)"):
            continue  # the recommended tokenizer keeps "cannot" whole
        s = regex.sub(r" \1 \2 ", s)
    for regex in _CONTRACTIONS3:
        s = regex.sub(r" \1 \2 \3", s)
    if improved:
        s = _TYPO_DOUBLE.sub(r" \1 ", s)
        s = _TYPO_SINGLE.sub(lambda m: " %s " % m.group(0), s)
        s = _DASH_STAR.sub(r" \1 ", s)
        s = _POINT_RUN.sub(lambda m: " %s " % m.group(0), s)
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank tokenization conventions."""

    # spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098
    # spec: N-000099 N-000100 N-000101 N-000102 N-000103
    def tokenize(self, text):
        _check_text(text)
        if not text.strip():
            return []
        return _treebank(text, improved=False)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer: the Penn Treebank conventions with
    improvements. Unless ``preserve_line`` is True, the text is first split into
    sentences with the Punkt model for ``language``."""
    _check_text(text)
    _check_bool(preserve_line, "preserve_line")
    if preserve_line:
        if not text.strip():
            return []
        return _treebank(text, improved=True)
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_treebank(sentence, improved=True))
    return tokens


# ---------------------------------------------------------------------------
# Sentence tokenizer
# ---------------------------------------------------------------------------

def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``.

    Raises LookupError when that model is not visible."""
    _check_text(text)
    if not isinstance(language, str):
        raise TypeError("language must be a str")
    spans = _punkt.sentence_spans(text, language)
    return [text[s:e] for s, e in spans]


# ---------------------------------------------------------------------------
# Whitespace, blank-line and regular-expression tokenizers
# ---------------------------------------------------------------------------

_WS_RE = re.compile(r"\S+")


class WhitespaceTokenizer:
    # spec: N-000113
    def tokenize(self, text):
        _check_text(text)
        return _WS_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in _WS_RE.finditer(text):
            yield (m.start(), m.end())


_BLANK_SEP = re.compile(r"\s*\n[^\S\n]*\n\s*")


def blankline_tokenize(text):
    """Segments: the pieces between blank-line separators, empty pieces dropped."""
    _check_text(text)
    return [piece.strip() for piece in _BLANK_SEP.split(text) if piece.strip()]


class RegexpTokenizer:
    """Token mode: the matches of ``pattern``. Gap mode: the text between matches."""

    def __init__(self, pattern, gaps=False, discard_empty=False):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        _check_bool(gaps, "gaps")
        _check_bool(discard_empty, "discard_empty")
        self._regex = re.compile(pattern)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def _spans(self, text):
        if self._gaps:
            pieces = []
            pos = 0
            for m in self._regex.finditer(text):
                pieces.append((pos, m.start()))
                pos = m.end()
            pieces.append((pos, len(text)))
            return pieces
        # Token mode: zero-width matches are not tokens (so empty text gives no tokens).
        return [m.span() for m in self._regex.finditer(text) if m.end() > m.start()]

    def tokenize(self, text):
        _check_text(text)
        out = []
        for s, e in self._spans(text):
            piece = text[s:e]
            if self._discard_empty and piece == "":
                continue
            out.append(piece)
        return out

    def span_tokenize(self, text):
        _check_text(text)
        for s, e in self._spans(text):
            if self._discard_empty and s == e:
                continue
            yield (s, e)


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = r"(?:[<>]?[:;=8][\-o*']?[)(\]\[dDpP/:}{@|\\]|[)(\]\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?|<3|</3)"
_TWEET_RE = re.compile(
    r"(%s)"
    r"|(https?://\S+)"
    r"|((?<![A-Za-z0-9_])@\w+)"
    r"|(#\w+)"
    r"|(\w+(?:['’]\w+)*)"
    r"|(\.{2,})"
    r"|([^\w\s])" % _EMOTICON
)
_EMOTICON_FULL = re.compile(_EMOTICON)
_HANDLE_STRIP = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")


class TweetTokenizer:
    """Tokenizer for short social-media text."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        _check_bool(preserve_case, "preserve_case")
        _check_bool(reduce_len, "reduce_len")
        _check_bool(strip_handles, "strip_handles")
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self._reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.DOTALL)
        out = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group(0)
            if not self._preserve_case and not _EMOTICON_FULL.fullmatch(tok):
                tok = tok.lower()
            out.append(tok)
        return out
