"""Part-of-speech taggers.

# spec: N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439 N-000440
# spec: N-000441 N-000442 N-000443 N-000444 N-000445 N-000187 N-000188 N-000189
# spec: N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000197
# spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000205
# spec: N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213
# spec: N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221
# spec: N-000222 N-000223 N-000224 N-000225 N-000226 N-000227

Sequential taggers a caller trains or configures (default, unigram,
regular-expression) with optional backoff, plus the recommended averaged
perceptron tagger (English and Russian) behind :func:`pos_tag`.

Only the default, unigram and regular-expression taggers are implemented as
the trainable taggers the PRD specifies; bigram, trigram and affix taggers
are outside the specification.
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "DefaultTagger",
    "UnigramTagger",
    "RegexpTagger",
    "pos_tag",
]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")
    return list(tokens)


def _check_backoff(backoff):
    if backoff is not None and not isinstance(backoff, _SequentialTagger):
        raise TypeError("backoff must be another tagger or None")
    return backoff


class _SequentialTagger:
    """Base class: primary tagging, then backoff for tokens left untagged."""

    backoff = None

    def choose_tag(self, tokens, index):  # pragma: no cover - overridden
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = [self.choose_tag(tokens, i) for i in range(len(tokens))]
        if self.backoff is not None and any(t is None for t in tags):
            fallback = self.backoff.tag(tokens)
            tags = [
                fallback[i][1] if tags[i] is None else tags[i]
                for i in range(len(tokens))
            ]
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    # spec: N-000198
    def __init__(self, tag):
        self._tag = tag

    def choose_tag(self, tokens, index):
        return self._tag


class UnigramTagger(_SequentialTagger):
    """Each trained word gets the tag it most often had in training."""

    # spec: N-000199 N-000200 N-000201
    def __init__(self, train=None, backoff=None):
        self.backoff = _check_backoff(backoff)
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for pair in sentence:
                if not isinstance(pair, tuple) or len(pair) != 2:
                    raise TypeError("training sentences hold (token, tag) pairs")
                word, tag = pair
                counts[word][tag] += 1
        # Counter.most_common keeps first-seen order among equal counts (tie-break).
        self._model = {w: c.most_common(1)[0][0] for w, c in counts.items()}

    def choose_tag(self, tokens, index):
        return self._model.get(tokens[index])


class RegexpTagger(_SequentialTagger):
    """Rules in the caller's order; the first rule whose pattern matches the
    token from its first character gives the tag."""

    # spec: N-000202 N-000203 N-000204
    def __init__(self, regexps, backoff=None):
        self.backoff = _check_backoff(backoff)
        self._rules = []
        for pair in regexps:
            if not isinstance(pair, tuple) or len(pair) != 2:
                raise TypeError("regexps must be (pattern, tag) pairs")
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def choose_tag(self, tokens, index):
        token = tokens[index]
        for regex, tag in self._rules:
            if regex.match(token):
                return tag
        return None


# ---------------------------------------------------------------------------
# Recommended averaged perceptron tagger (textblob-aptagger style features).
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

_LANG_RESOURCE = {
    "eng": "taggers/averaged_perceptron_tagger_eng/",
    "rus": "taggers/averaged_perceptron_tagger_rus/",
}

# Russian National Corpus part-of-speech categories -> universal tagset.
_RUS_TO_UNIVERSAL = {
    "S": "NOUN",
    "A": "ADJ",
    "ANUM": "ADJ",
    "A-PRO": "DET",
    "APRO": "DET",
    "V": "VERB",
    "ADV": "ADV",
    "ADVPRO": "ADV",
    "PRAEDIC": "ADV",
    "PRAEDIC-PRO": "ADV",
    "PR": "ADP",
    "CONJ": "CONJ",
    "PART": "PRT",
    "NUM": "NUM",
    "SPRO": "PRON",
    "INTJ": "X",
    "PARENTH": "X",
    "COM": "X",
}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


class _PerceptronModel:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


_model_cache = {}


def _load_perceptron(lang):
    resource = _LANG_RESOURCE[lang]
    base = data.find(resource)  # LookupError when not visible
    files = {
        "weights": os.path.join(base, "averaged_perceptron_tagger_%s.weights.json" % lang),
        "tagdict": os.path.join(base, "averaged_perceptron_tagger_%s.tagdict.json" % lang),
        "classes": os.path.join(base, "averaged_perceptron_tagger_%s.classes.json" % lang),
    }
    for path in files.values():
        if not os.path.isfile(path):
            raise LookupError("tagger file missing: %s" % path)
    stamp = tuple((p, os.stat(p).st_mtime_ns, os.stat(p).st_size) for p in files.values())
    cached = _model_cache.get(base)
    if cached is not None and cached[0] == stamp:
        return cached[1]
    with open(files["weights"], encoding="utf-8") as fh:
        weights = json.load(fh)
    with open(files["tagdict"], encoding="utf-8") as fh:
        tagdict = json.load(fh)
    with open(files["classes"], encoding="utf-8") as fh:
        classes = json.load(fh)
    if not classes:
        raise ValueError("tagger classes file is empty")
    loaded = (_PerceptronModel(weights, classes), tagdict)
    _model_cache[base] = (stamp, loaded)
    return loaded


def _perceptron_tag(model, tagdict, tokens):
    prev, prev2 = _START
    context = _START + [_normalize(w) for w in tokens] + _END
    tags = []
    for i, word in enumerate(tokens):
        tag = tagdict.get(word)
        if not tag:
            tag = model.predict(_features(i, word, context, prev, prev2))
        tags.append(tag)
        prev2, prev = prev, tag
    return tags


_universal_cache = {}


def _load_english_map():
    base = data.find("taggers/universal_tagset/")
    path = os.path.join(base, "en-ptb.map")
    if not os.path.isfile(path):
        raise LookupError("universal tagset table en-ptb.map is not visible")
    if path not in _universal_cache:
        mapping = {}
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) == 2:
                    mapping[parts[0]] = parts[1]
        _universal_cache[path] = mapping
    return _universal_cache[path]


def _russian_universal(tag):
    head = tag.split("=", 1)[0]
    pos = head.split(",", 1)[0]
    return _RUS_TO_UNIVERSAL.get(pos, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a list of tokens with the recommended tagger.

    ``lang`` is ``'eng'`` (default) or ``'rus'``. ``tagset`` is ``None`` (native
    tags) or ``'universal'``. Raises for a string argument, an unsupported
    ``lang`` or ``tagset``, or a missing averaged-perceptron resource.
    """
    if isinstance(tokens, (str, bytes)):
        raise TypeError("pos_tag needs a list of tokens, not a string")
    tokens = _check_tokens(tokens)
    if lang not in _LANG_RESOURCE:
        raise ValueError("pos_tag supports lang 'eng' and 'rus' only, not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model, tagdict = _load_perceptron(lang)
    tags = _perceptron_tag(model, tagdict, tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_english_map()
            tags = [mapping.get(t, "X") for t in tags]
        else:
            tags = [_russian_universal(t) for t in tags]
    return list(zip(tokens, tags))
