"""Constituent trees.

# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
# spec: N-000489 N-000490 N-000491 N-000281 N-000282 N-000283 N-000284 N-000285
# spec: N-000286 N-000287 N-000288 N-000289 N-000290 N-000291

A tree has a string label and an ordered list of children. A child is either
a ``str`` leaf or another :class:`Tree`.

Conflict note (CF-000088): the PRD says a string given as the child list is
taken as one leaf, while the Interface Contract says it makes ``Tree`` raise.
This implementation follows the Contract and raises ``TypeError``.
"""

import re

__all__ = ["Tree"]


class Tree:
    """An ordered tree with a label and immediate children."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list of children, not a string")
        if not isinstance(label, str):
            raise TypeError("Tree label must be a str")
        children = list(children)  # raises TypeError for non-iterables
        for child in children:
            if isinstance(child, tuple) and len(child) == 2:
                continue  # (token, tag) leaf of a chunk structure
            if not isinstance(child, (str, Tree)):
                raise TypeError("a child must be a str leaf, a Tree, or a (token, tag) pair")
        self._label = label
        self._children = children

    # -- accessors -------------------------------------------------------
    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    # -- comparison ------------------------------------------------------
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None  # mutable container semantics; trees compare by value

    # -- construction from bracketed text ---------------------------------
    @classmethod
    def fromstring(cls, s):
        """Parse bracketed tree text ``(<label> <child> ...)``."""
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        pos = [0]

        def parse_node():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text: %r" % s)
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text: %r" % s)
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(tokens):
                    raise ValueError("unbalanced brackets in tree text: %r" % s)
                tok = tokens[pos[0]]
                if tok == ")":
                    pos[0] += 1
                    break
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos[0] += 1
            return cls(label, children)

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after tree: %r" % s)
        return tree

    # -- printing ----------------------------------------------------------
    @staticmethod
    def _leaf_text(child):
        if isinstance(child, tuple):
            return "%s/%s" % (child[0], child[1])
        return child

    def _flat(self):
        parts = [self._label]
        for child in self._children:
            parts.append(child._flat() if isinstance(child, Tree) else self._leaf_text(child))
        return "(" + " ".join(parts) + ")"

    def pformat(self, margin=70):
        """Pretty-printed text. Layout is the implementer's choice: a node
        fits on one line when it can, otherwise children go on indented lines.
        Labels and leaves appear in left-to-right order."""
        return self._pformat(0, margin)

    def _pformat(self, indent, margin):
        flat = self._flat()
        if indent + len(flat) <= margin or not any(isinstance(c, Tree) for c in self._children):
            return flat
        pad = " " * (indent + 2)
        lines = ["(" + self._label]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(pad + child._pformat(indent + 2, margin))
            else:
                lines.append(pad + self._leaf_text(child))
        return "\n".join(lines) + ")"

    def __str__(self):
        return self._flat()

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)
