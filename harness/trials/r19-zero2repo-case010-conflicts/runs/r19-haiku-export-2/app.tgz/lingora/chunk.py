"""Chunking with chunk grammars (regular-expression chunk parser) and ne_chunk.

# spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453
# spec: N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460
# spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235
# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242 N-000243
# spec: N-000244 N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251
# spec: N-000252 N-000253 N-000254 N-000255 N-000256 N-000257

Grammar text: clauses ``<LABEL>: <pattern>`` with further patterns on
indented lines. A pattern ``{...}`` is a chunk rule; ``}...{`` is a chink rule.
Tag patterns are sequences of ``<tag-regex>`` elements with optional
quantifiers ``? * +  {m,n}  {m,}  {m}``.

Resolutions of spec conflicts:
* CF-000028 (touching matches): two matches of one rule that touch are two
  separate chunks.
* The root label is the constant ``"SENT"``, which never equals a clause label
  unless a grammar deliberately uses that label.
"""

import re
from bisect import bisect_left

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk", "SENTENCE_LABEL"]

SENTENCE_LABEL = "SENT"

# Each tag is encoded between these sentinels so a regular expression over the
# encoded string can match only whole tags, and each match starts and ends on
# a token boundary.
_OPEN = "\x00"
_CLOSE = "\x01"
_TAG_CHAR_NOT_BOUNDARY = "[^\x00\x01]"

_QUANT_BRACE = re.compile(r"\{\d*,?\d*\}")
_CLAUSE_LABEL = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]*")


def _scan_rule(text, i):
    """``text[i]`` is ``{`` (chunk) or ``}`` (chink). Return (kind, body, next_index)."""
    if text[i] == "{":
        kind, closing = "chunk", "}"
    else:
        kind, closing = "chink", "{"
    j = i + 1
    in_angle = False
    n = len(text)
    while j < n:
        c = text[j]
        if in_angle:
            if c == ">":
                in_angle = False
            j += 1
            continue
        if c == "<":
            in_angle = True
            j += 1
            continue
        if c == "{":
            m = _QUANT_BRACE.match(text, j)
            if m and m.group(0) != "{}" and any(ch.isdigit() for ch in m.group(0)):
                j = m.end()
                continue
        if c == closing:
            return kind, text[i + 1:j], j + 1
        j += 1
    raise ValueError("unterminated %s rule in chunk grammar: %r" % (kind, text[i:]))


def _parse_patterns(text, lineno):
    rules = []
    i = 0
    n = len(text)
    while i < n:
        if text[i].isspace():
            i += 1
            continue
        if text[i] not in "{}":
            raise ValueError("line %d: expected '{' or '}' but found %r" % (lineno, text[i]))
        kind, body, i = _scan_rule(text, i)
        rules.append((kind, body))
    return rules


def _parse_grammar(text):
    """Return a list of (label, rules) clauses."""
    clauses = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0].isspace():
            if not clauses:
                raise ValueError("line %d: continuation line before any clause" % lineno)
            clauses[-1][1].extend(_parse_patterns(raw.strip(), lineno))
            continue
        if ":" not in raw:
            raise ValueError("line %d: expected '<LABEL>: <pattern>'" % lineno)
        label, rest = raw.split(":", 1)
        label = label.strip()
        if not _CLAUSE_LABEL.fullmatch(label):
            raise ValueError("line %d: bad clause label %r" % (lineno, label))
        clauses.append((label, _parse_patterns(rest.strip(), lineno)))
    return clauses


def _translate_element_content(content):
    out = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        if c == ".":
            out.append(_TAG_CHAR_NOT_BOUNDARY)
        else:
            out.append(c)
        i += 1
    return "".join(out)


def _compile_tag_pattern(body):
    """Compile a tag pattern into a regular expression over encoded tags."""
    pieces = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c.isspace():
            i += 1
            continue
        if c != "<":
            raise ValueError("tag pattern element must start with '<': %r" % body)
        end = body.find(">", i + 1)
        if end < 0:
            raise ValueError("unterminated '<' in tag pattern: %r" % body)
        content = body[i + 1:end]
        i = end + 1
        quant = ""
        if i < n and body[i] in "?*+":
            quant = body[i]
            i += 1
        elif i < n and body[i] == "{":
            m = _QUANT_BRACE.match(body, i)
            if not m:
                raise ValueError("bad quantifier in tag pattern: %r" % body)
            quant = m.group(0)
            i = m.end()
        pieces.append("(?:%s(?:%s)%s)%s" % (
            _OPEN, _translate_element_content(content), _CLOSE, quant))
    try:
        return re.compile("".join(pieces))
    except re.error as exc:
        raise ValueError("bad tag pattern %r: %s" % (body, exc))


def _item_tag(item):
    if isinstance(item, Tree):
        return item.label()
    tag = item[1]
    return "" if tag is None else str(tag)


def _is_leaf(item):
    return isinstance(item, tuple)


def _find_spans(regex, tags):
    """Non-overlapping, leftmost, longest-as-regex matches over ``tags``.

    Returns a list of (start_index, end_index) over the tag positions."""
    encoded = "".join(_OPEN + t + _CLOSE for t in tags)
    starts = []  # char offset of each token's OPEN sentinel
    pos = 0
    for t in tags:
        starts.append(pos)
        pos += len(t) + 2
    starts.append(pos)

    def token_index(char_offset):
        return bisect_left(starts, char_offset)

    spans = []
    for m in regex.finditer(encoded):
        if m.end() == m.start():
            continue
        spans.append((token_index(m.start()), token_index(m.end())))
    return spans


def _validate_tagged(tagged, what):
    if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
        raise TypeError("%s must be a list of (token, tag) pairs" % what)
    out = []
    for pair in tagged:
        if not isinstance(pair, tuple) or len(pair) != 2:
            raise TypeError("%s must hold (token, tag) pairs" % what)
        out.append(pair)
    return out


class RegexpParser:
    """Chunk parser driven by a chunk grammar (text or a list of stages)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list):
            clauses = []
            for stage in grammar:
                if isinstance(stage, RegexpParser):
                    clauses.extend(stage._clauses)
                elif isinstance(stage, str):
                    clauses.extend(_parse_grammar(stage))
                else:
                    raise TypeError("chunk grammar stages must be RegexpParser objects or text")
            self._clauses = clauses
        else:
            raise TypeError("chunk grammar must be text or a list of chunk-parser stages")
        self._compiled = [
            (label, [(kind, _compile_tag_pattern(body)) for kind, body in rules])
            for label, rules in self._clauses
        ]

    def parse(self, tagged):
        tagged = _validate_tagged(tagged, "tagged tokens")
        items = list(tagged)
        for label, rules in self._compiled:
            built = set()  # ids of chunks built by this clause
            for kind, regex in rules:
                if kind == "chunk":
                    items = self._apply_chunk(items, label, regex, built)
                else:
                    items = self._apply_chink(items, label, regex, built)
        return Tree(SENTENCE_LABEL, items)

    @staticmethod
    def _apply_chunk(items, label, regex, built):
        out = []
        run = []

        def flush_run():
            if not run:
                return
            tags = [_item_tag(it) for it in run]
            spans = _find_spans(regex, tags)
            k = 0
            for a, b in spans:
                out.extend(run[k:a])
                chunk = Tree(label, run[a:b])
                built.add(id(chunk))
                out.append(chunk)
                k = b
            out.extend(run[k:])
            run.clear()

        for item in items:
            matchable = _is_leaf(item) or (isinstance(item, Tree) and id(item) not in built)
            if matchable:
                run.append(item)
            else:
                flush_run()
                out.append(item)
        flush_run()
        return out

    @staticmethod
    def _apply_chink(items, label, regex, built):
        out = []
        for item in items:
            if not (isinstance(item, Tree) and id(item) in built and item.label() == label):
                out.append(item)
                continue
            children = list(item)
            # Only leaves can be chinked; sub-chunks break matches.
            chink_flags = [False] * len(children)
            run_start = None
            segments = []
            for idx, c in enumerate(children):
                if _is_leaf(c):
                    if run_start is None:
                        run_start = idx
                else:
                    if run_start is not None:
                        segments.append((run_start, idx))
                        run_start = None
                    segments.append((idx, idx + 1))
            if run_start is not None:
                segments.append((run_start, len(children)))
            for s, e in segments:
                seg_tags = [_item_tag(c) for c in children[s:e]]
                if not all(_is_leaf(c) for c in children[s:e]):
                    continue
                for a, b in _find_spans(regex, seg_tags):
                    for k in range(s + a, s + b):
                        chink_flags[k] = True
            # Rebuild: kept children stay in chunks, chinked leaves go to root.
            kept_run = []
            for idx, c in enumerate(children):
                if chink_flags[idx]:
                    if kept_run:
                        piece = Tree(label, kept_run)
                        built.add(id(piece))
                        out.append(piece)
                        kept_run = []
                    out.append(c)
                else:
                    kept_run.append(c)
            if kept_run:
                piece = Tree(label, kept_run)
                built.add(id(piece))
                out.append(piece)
        return out


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Needs the English wordlist and the named-entity
    model; raises LookupError when either is not visible.

    The model file format is not part of the specification (FP-04: results
    with the resource present are outside it), so with both resources present
    this raises NotImplementedError.
    """
    _validate_tagged(tagged_tokens, "tagged tokens")
    data.find("corpora/words")
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass/")
    raise NotImplementedError("the named-entity chunker model is not implemented")
