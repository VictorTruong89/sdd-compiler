"""BLEU score over token lists.

# spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000335 N-000336
# spec: N-000337 N-000338 N-000339 N-000340 N-000341 N-000342

Sentence-level BLEU (Papineni et al., 2002). Resolution of CF-000087: when
``weights`` is omitted, unigrams and bigrams are weighted equally
(0.5 each) and longer n-grams are not scored (Interface Contract).

``smoothing_function`` is optional: a callable that receives the list of
(clipped_count, total_count) pairs, one per n-gram order, and returns a list
of (clipped_count, total_count) pairs of the same length.
"""

import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _check_token_list(value, name):
    if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
        raise TypeError("%s must be a list of str" % name)
    for tok in value:
        if not isinstance(tok, str):
            raise TypeError("%s must hold str tokens" % name)


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    if isinstance(references, (str, bytes)) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    if not references:
        raise ValueError("bleu needs at least one reference")
    for ref in references:
        _check_token_list(ref, "reference")
    _check_token_list(hypothesis, "hypothesis")

    if weights is None:
        weights = (0.5, 0.5)
    if isinstance(weights, (str, bytes)) or not isinstance(weights, (list, tuple)):
        raise TypeError("weights must be a sequence of numbers")
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)) or w < 0:
            raise TypeError("weights must be non-negative numbers")
    if not weights:
        raise ValueError("weights must not be empty")

    if not hypothesis:
        return 0.0

    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = max(len(hypothesis) - n + 1, 0)
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        pairs.append((clipped, total))

    if smoothing_function is not None:
        if not callable(smoothing_function):
            raise TypeError("smoothing_function must be callable")
        pairs = list(smoothing_function(list(pairs)))

    log_sum = 0.0
    for w, (num, den) in zip(weights, pairs):
        if w == 0:
            continue
        if den <= 0 or num <= 0:
            return 0.0
        log_sum += w * math.log(num / den)
    precision = math.exp(log_sum)

    c = len(hypothesis)
    closest = min(
        (len(ref) for ref in references),
        key=lambda r: (abs(r - c), r),  # equally close: the shorter one
    )
    if c > closest:
        penalty = 1.0
    else:
        penalty = math.exp(1 - closest / c)
    return float(penalty * precision)
