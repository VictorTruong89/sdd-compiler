---
name: spec-conflict-resolution
description: "How the LINGORA spec's 19 unsettled contradictions were resolved in /app (which side governs what)"
metadata:
  node_type: memory
  type: project
  originSessionId: 063913fd-87d3-4ad6-9681-02d143116ff8
  modified: 2026-11-03T12:57:18.210Z
---

The LINGORA spec export in /app/spec has 19 unsettled contradictions (CF-000001 etc.). The build resolved them with one rule:
the Interface Contract (packs 01-15) governs signatures and parameter defaults; the Full PRD (packs 16-29) governs algorithm behaviour.
Where two tokenizers are described separately (Penn Treebank vs. recommended word tokenizer), each keeps its own rule.

**Why:** the PRD itself says exact call signatures and defaults belong in the Interface Contract. Using one rule keeps the 19 choices consistent.

**How to apply:** if a hidden test or the spec changes a default, check this rule first. The full per-conflict list is in /app/NOTES.md; the per-id status is in /app/SPEC_COVERAGE.md. Notable choices that differ from the PRD text: `RegexpTokenizer` discard_empty defaults to False, BLEU weights default to (0.5, 0.5), `PorterStemmer.stem` to_lowercase defaults to False, and edit-distance transpositions are the restricted (adjacent-only) form.
