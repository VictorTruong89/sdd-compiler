"""Constituent trees (Interface Contract: ``lingora.tree``).

# spec: N-000481, N-000482, N-000483, N-000484, N-000485, N-000486, N-000487, N-000488, N-000489, N-000490, N-000491
"""

import re

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled node with an ordered list of children.

    A child is a leaf (any non-tree value, usually a token string) or a Tree.
    # spec: N-000281, N-000282, N-000283, N-000284
    """

    def __init__(self, label, children):
        # spec: N-000486, N-000487, N-000488 — a str (or any non-list) given as
        # children is refused; Tree(label, []) is a valid tree with no children.
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text ``(label child ...)``.
        # spec: N-000489, N-000286
        """
        tokens = _TOKEN_RE.findall(s)
        pos = 0

        def parse():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("bracketed tree text must start with '('")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("a tree node needs a label")
            label = tokens[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced bracketed tree text")
                tok = tokens[pos]
                if tok == ")":
                    pos += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse())
                else:
                    children.append(tok)
                    pos += 1

        tree = parse()
        if pos != len(tokens):
            raise ValueError("extra text after the tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        """Pretty-printed tree text; pre-order, one node per line when nested.
        # spec: N-000490, N-000491, N-000287
        """
        lines = []
        self._pformat_into(lines, 0)
        return "\n".join(lines)

    def _pformat_into(self, lines, depth):
        pad = "  " * depth
        if all(not isinstance(c, Tree) for c in self._children):
            body = " ".join(_leaf_text(c) for c in self._children)
            lines.append("%s(%s%s)" % (pad, self._label, (" " + body) if body else ""))
            return
        lines.append("%s(%s" % (pad, self._label))
        for child in self._children:
            if isinstance(child, Tree):
                child._pformat_into(lines, depth + 1)
            else:
                lines.append("%s  %s" % (pad, _leaf_text(child)))
        lines[-1] += ")"

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        parts = ", ".join(repr(c) for c in self._children)
        return "Tree(%r, [%s])" % (self._label, parts)

    def __str__(self):
        body = " ".join(str(c) for c in self._children)
        return "(%s%s)" % (self._label, (" " + body) if body else "")


def _leaf_text(leaf):
    return leaf if isinstance(leaf, str) else str(leaf)
