"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing. Submodules are imported on use:
``lingora.tokenize``, ``lingora.stem``, ``lingora.tag``, ``lingora.chunk``,
``lingora.grammar``, ``lingora.parse``, ``lingora.tree``, ``lingora.classify``,
``lingora.metrics``, ``lingora.translate``, ``lingora.cli`` and ``lingora.data``.
"""

__version__ = "0.1.0"
