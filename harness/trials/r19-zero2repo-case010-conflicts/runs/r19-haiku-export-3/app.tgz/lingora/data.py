"""Packaged resource finder (Interface Contract: ``lingora.data``).

# spec: N-000385, N-000386, N-000387, N-000388, N-000397, N-000398, N-000402
"""

import os

# spec: N-000385 — `data.path` is a mutable list of directories searched for
# packaged resources. Callers may replace its contents in place. The initial
# contents are an implementer's choice: the entries of the LINGORA_DATA
# environment variable (os.pathsep separated), then ~/lingora_data.
# spec: N-000388 — the initial contents are an implementer's choice.


def _initial_path():
    entries = []
    env = os.environ.get("LINGORA_DATA", "")
    entries.extend(p for p in env.split(os.pathsep) if p)
    entries.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return entries


path = _initial_path()


def find(resource):
    """Return the first existing location of ``resource`` under ``data.path``.

    ``resource`` is a path relative to a directory on ``data.path``, such as
    ``tokenizers/punkt_tab/english``. Raises ``LookupError`` if no listed
    directory holds it. An empty ``data.path`` means nothing is visible.
    # spec: N-000386, N-000387
    """
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "packaged resource %r is not installed (searched: %s)"
        % (resource, ", ".join(list(path)) or "none")
    )


def read_lines(filename):
    """Read a UTF-8 model file; each line without its terminator is one entry.
    # spec: N-000398
    """
    with open(filename, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]


# Packaged resource names (relative to a directory on data.path) that this package reads.
# spec: N-000389 — Punkt sentence model: tokenizers/punkt_tab/<language>/ (English: tokenizers/punkt_tab/english/)
# spec: N-000390 — English averaged perceptron tagger: taggers/averaged_perceptron_tagger_eng/
# spec: N-000391 — Russian averaged perceptron tagger: taggers/averaged_perceptron_tagger_rus/
# spec: N-000392 — Universal tagset tables: taggers/universal_tagset/
# spec: N-000393 — Named-entity chunker model: chunkers/maxent_ne_chunker_tab/english_ace_multiclass/
# spec: N-000394 — English wordlist: corpora/words
# spec: N-000395 — Stopwords list for a language: corpora/stopwords/<language>
# spec: N-000396 — WordNet: corpora/wordnet
RESOURCE_NAMES = {
    "punkt": "tokenizers/punkt_tab",
    "perceptron_eng": "taggers/averaged_perceptron_tagger_eng",
    "perceptron_rus": "taggers/averaged_perceptron_tagger_rus",
    "universal_tagset": "taggers/universal_tagset",
    "ne_chunker": "chunkers/maxent_ne_chunker_tab/english_ace_multiclass",
    "english_words": "corpora/words",
    "stopwords": "corpora/stopwords",
    "wordnet": "corpora/wordnet",
}
