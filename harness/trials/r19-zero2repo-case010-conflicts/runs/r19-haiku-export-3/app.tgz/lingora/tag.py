"""Part-of-speech taggers (Interface Contract: ``lingora.tag``; PRD FP-03).

# spec: N-000433, N-000434, N-000435, N-000436, N-000437, N-000438, N-000439, N-000440, N-000441, N-000442, N-000443, N-000444, N-000445
"""

import collections
import json
import os
import re

from lingora import data


class TaggerI:
    """Base class: ``tag(tokens)`` returns one ``(token, tag-or-None)`` pair per token.
    # spec: N-000196, N-000197, N-000444, N-000445, N-000435
    """

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose(self, tokens):
        """Return a list of tags (or None) for ``tokens``; subclasses override."""
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_token_list(tokens)
        if not tokens:
            return []
        tags = self._choose(tokens)
        # spec: N-000205, N-000206 — the backoff tagger is consulted only for tokens left untagged.
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                backed = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, backed):
                    tags[i] = t
        return list(zip(tokens, tags))


def _check_token_list(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
    return tokens


class DefaultTagger(TaggerI):
    """Assigns one configured tag to every token.
    # spec: N-000198
    """

    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def _choose(self, tokens):
        return [self._tag for _ in tokens]


def _train_pairs(train):
    if train is None:
        return []
    sentences = list(train)
    for sentence in sentences:
        for pair in sentence:
            if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                raise TypeError("training sentences hold (token, tag) pairs")
    return sentences


class NgramTagger(TaggerI):
    """Tags each token with the tag it most often has in training, in its n-token context.
    Trainable without a downloaded model; the protocol matches the unigram tagger.
    """

    def __init__(self, n, train=None, backoff=None, cutoff=0):
        super().__init__(backoff)
        if n < 1:
            raise ValueError("n must be at least 1")
        self._n = n
        self._model = {}
        counts = collections.defaultdict(collections.Counter)
        for sentence in _train_pairs(train):
            history = []
            for token, tag in sentence:
                key = tuple(history[-(n - 1):]) if n > 1 else ()
                counts[(key, token)][tag] += 1
                history.append(tag)
        for (key, token), tagcounts in counts.items():
            best = _most_common_tag(tagcounts)
            if best is not None:
                self._model[(key, token)] = best

    def _choose(self, tokens):
        tags = []
        for i, token in enumerate(tokens):
            key = tuple(tags[max(0, i - self._n + 1):i]) if self._n > 1 else ()
            tags.append(self._model.get((key, token)))
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(2, train, backoff, cutoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(3, train, backoff, cutoff)


class UnigramTagger(TaggerI):
    """Each word seen in training receives its most frequent training tag. Ties break
    by the smallest tag string (implementer's choice). Unseen words get no tag.
    # spec: N-000199, N-000200, N-000201, N-000202
    """

    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(backoff)
        counts = collections.defaultdict(collections.Counter)
        for sentence in _train_pairs(train):
            for token, tag in sentence:
                counts[token][tag] += 1
        self._model = {}
        for token, tagcounts in counts.items():
            best = _most_common_tag(tagcounts)
            if best is not None:
                self._model[token] = best

    def _choose(self, tokens):
        return [self._model.get(token) for token in tokens]


class RegexpTagger(TaggerI):
    """Rules are tried in order; a token takes the tag of the first pattern matching
    it from its first character. Unmatched tokens get no tag.
    # spec: N-000202, N-000203, N-000204, N-000438
    """

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def _choose(self, tokens):
        out = []
        for token in tokens:
            tag = None
            for regex, rule_tag in self._rules:
                if regex.match(token):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


class AffixTagger(TaggerI):
    """Tags each word by its prefix or suffix, learned from training.
    # spec: N-000035
    """

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        counts = collections.defaultdict(collections.Counter)
        for sentence in _train_pairs(train):
            for token, tag in sentence:
                if len(token) >= min_stem_length + abs(affix_length):
                    counts[self._affix(token)][tag] += 1
        self._model = {}
        for affix, tagcounts in counts.items():
            best = _most_common_tag(tagcounts)
            if best is not None:
                self._model[affix] = best

    def _affix(self, token):
        if self._affix_length > 0:
            return token[: self._affix_length]
        return token[self._affix_length:]

    def _choose(self, tokens):
        out = []
        for token in tokens:
            if len(token) < self._min_stem_length + abs(self._affix_length):
                out.append(None)
            else:
                out.append(self._model.get(self._affix(token)))
        return out


def _most_common_tag(tagcounts):
    if not tagcounts:
        return None
    best_count = max(tagcounts.values())
    candidates = sorted(tag for tag, count in tagcounts.items() if count == best_count)
    return candidates[0]


# ---------------------------------------------------------------------------
# Recommended averaged perceptron tagger (English and Russian)
# ---------------------------------------------------------------------------

_LANGS = {"eng": "averaged_perceptron_tagger_eng", "rus": "averaged_perceptron_tagger_rus"}
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_MODEL_CACHE = {}

# Russian National Corpus part-of-speech -> universal category (implementer's table).
_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV",
    "APRO": "DET", "SPRO": "PRON", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
    "NUM": "NUM", "INTJ": "X", "PRAEDIC": "ADV", "COM": "ADJ",
}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = collections.defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: (scores[label], label))


def _load_perceptron(lang):
    if lang not in _LANGS:
        raise ValueError("unsupported tagger language %r (supported: eng, rus)" % (lang,))
    directory = os.path.join("taggers", _LANGS[lang])
    base = data.find(directory)  # raises LookupError when the resource is not visible
    if not os.path.isdir(base):
        raise LookupError("averaged perceptron tagger resource for %r is not a directory" % lang)
    key = (lang, os.path.abspath(base))
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]

    def load(suffix):
        filename = os.path.join(base, "averaged_perceptron_tagger_%s.%s.json" % (lang, suffix))
        if not os.path.exists(filename):
            raise LookupError("averaged perceptron tagger file missing: %s" % filename)
        with open(filename, encoding="utf-8") as handle:
            return json.load(handle)

    model = _PerceptronModel(load("weights"), load("tagdict"), load("classes"))
    _MODEL_CACHE[key] = model
    return model


def _features(i, word, context, prev, prev2):
    """Feature templates of the greedy averaged perceptron tagger."""
    feats = collections.defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


def _perceptron_tag(tokens, lang):
    model = _load_perceptron(lang)
    prev, prev2 = _START
    context = _START + [_normalize(w) for w in tokens] + _END
    tags = []
    for i, word in enumerate(tokens):
        tag = model.tagdict.get(word)
        if not tag:
            features = _features(i + len(_START), word, context, prev, prev2)
            tag = model.predict(features)
        tags.append(tag)
        prev2 = prev
        prev = tag
    return tags


_UNIVERSAL_MAP_CACHE = {}


def _load_en_universal():
    base = data.find(os.path.join("taggers", "universal_tagset"))
    filename = os.path.join(base, "en-ptb.map")
    if not os.path.exists(filename):
        raise LookupError("universal tagset table en-ptb.map is not installed")
    key = os.path.abspath(filename)
    if key in _UNIVERSAL_MAP_CACHE:
        return _UNIVERSAL_MAP_CACHE[key]
    mapping = {}
    for line in data.read_lines(filename):
        parts = line.split("\t")
        if len(parts) == 2:
            mapping[parts[0]] = parts[1]
    _UNIVERSAL_MAP_CACHE[key] = mapping
    return mapping


def _to_universal(tag, lang):
    if tag is None:
        return None
    if lang == "rus":
        part = tag.split("=", 1)[0]
        return _RNC_TO_UNIVERSAL.get(part, "X")
    return _load_en_universal().get(tag, tag)


def pos_tag(tokens, tagset=None, lang="eng"):
    """LINGORA's recommended tagger (averaged perceptron), English ('eng') or Russian ('rus').

    ``tokens`` must be a list of str. ``tagset`` is None (native tags) or 'universal'.
    Raises for a str argument, an unsupported language, a missing model, or an
    unknown tagset.
    # spec: N-000207, N-000208, N-000209, N-000210, N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000219, N-000220, N-000221, N-000222, N-000223, N-000224, N-000225, N-000226, N-000227, N-000440, N-000441, N-000442, N-000443, N-000444, N-000445
    """
    if isinstance(tokens, str):
        raise TypeError("pos_tag takes a list of tokens, not a raw string")
    if lang not in _LANGS:
        raise ValueError("unsupported tagger language %r (supported: eng, rus)" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tokens = _check_token_list(tokens)
    if not tokens:
        _load_perceptron(lang)  # a missing model still fails the call
        return []
    tags = _perceptron_tag(tokens, lang)
    if tagset == "universal":
        tags = [_to_universal(t, lang) for t in tags]
    return list(zip(tokens, tags))


__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "NgramTagger",
    "RegexpTagger",
    "TaggerI",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]
