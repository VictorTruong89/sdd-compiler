"""Command line (Interface Contract: ``lingora.cli``; PRD FP-01 command-line tokenize).

    cli.main(args=['tokenize'], standalone_mode=True)

# spec: N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420, N-000135, N-000139
"""

import sys

from lingora import tokenize as _tokenize

USAGE = "usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [--encoding ENCODING]"


class _UsageError(Exception):
    pass


def _parse_tokenize_args(args):
    options = {"language": "english", "delimiter": " ", "encoding": "utf-8"}
    names = {"-l": "language", "--language": "language",
             "-d": "delimiter", "--delimiter": "delimiter",
             "--encoding": "encoding"}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in names:
            if i + 1 >= len(args):
                raise _UsageError("option %s needs a value" % arg)
            options[names[arg]] = args[i + 1]
            i += 2
        elif arg.startswith("--") and "=" in arg:
            key, value = arg.split("=", 1)
            if key not in names:
                raise _UsageError("unknown option %s" % key)
            options[names[key]] = value
            i += 1
        else:
            raise _UsageError("unexpected argument %r" % arg)
    return options


def _read_stdin(encoding):
    stream = sys.stdin
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        raw = buffer.read()
        return raw.decode(encoding)
    return stream.read()


def _write_stdout(text, encoding):
    stream = sys.stdout
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        buffer.write(text.encode(encoding))
        buffer.flush()
    else:
        stream.write(text)
        stream.flush()


def _run_tokenize(options):
    language = options["language"]
    delimiter = options["delimiter"]
    encoding = options["encoding"]
    # Check the Punkt model first: a missing model writes no token line at all.
    _tokenize._load_punkt(language)
    text = _read_stdin(encoding)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = []
    for line in lines:
        line = line[:-1] if line.endswith("\r") else line
        tokens = _tokenize.word_tokenize(line, language=language, preserve_line=False)
        out.append(delimiter.join(tokens) + "\n")
    _write_stdout("".join(out), encoding)
    return 0


class _Group:
    """The ``lingora`` command group."""

    name = "lingora"
    commands = ("tokenize",)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            code = self._dispatch(args)
        except _UsageError as exc:
            sys.stderr.write("lingora: %s\n%s\n" % (exc, USAGE))
            code = 2
        except Exception as exc:  # any failure: non-zero status, no token line for this input
            if not standalone_mode:
                raise
            sys.stderr.write("lingora: error: %s\n" % exc)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    def _dispatch(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stderr.write(USAGE + "\n")
            return 0 if args else 2
        command, rest = args[0], args[1:]
        if command not in self.commands:
            raise _UsageError("unknown command %r" % command)
        if command == "tokenize":
            return _run_tokenize(_parse_tokenize_args(rest))
        raise _UsageError("unknown command %r" % command)


cli = _Group()
