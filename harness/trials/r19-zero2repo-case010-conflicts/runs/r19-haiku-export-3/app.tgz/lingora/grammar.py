"""Context-free grammars (Interface Contract: ``lingora.grammar``; PRD FP-05).

# spec: N-000461, N-000462, N-000463, N-000464, N-000465, N-000466, N-000467, N-000468, N-000469, N-000470, N-000471, N-000479, N-000480
"""

import re


class Nonterminal:
    """A nonterminal symbol. Its ``str()`` is its name; it is not a ``str`` itself.

    It compares equal to a ``str`` holding the same name, so ``cfg.start() == 'S'``.
    # spec: N-000466, N-000467, N-000468
    """

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._name == other._name
        if isinstance(other, str):
            return self._name == other
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash(self._name)


class Production:
    """One alternative: a left-hand nonterminal and a right-hand sequence.
    # spec: N-000471, N-000469, N-000470
    """

    def __init__(self, lhs, rhs):
        self._lhs = lhs if isinstance(lhs, Nonterminal) else Nonterminal(str(lhs))
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        if not isinstance(other, Production):
            return NotImplemented
        return self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(_symbol_text(s) for s in self._rhs))


def _symbol_text(symbol):
    if isinstance(symbol, Nonterminal):
        return str(symbol)
    return '"%s"' % symbol


_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_\-']*")


def _parse_rhs(text):
    """Split a right-hand side into alternatives of symbols. ``|`` separates alternatives."""
    alternatives = [[]]
    pos = 0
    while pos < len(text):
        ch = text[pos]
        if ch.isspace():
            pos += 1
        elif ch == "|":
            alternatives.append([])
            pos += 1
        elif ch in ("'", '"'):
            end = text.find(ch, pos + 1)
            if end < 0:
                raise ValueError("unterminated quoted terminal in %r" % text)
            alternatives[-1].append(text[pos + 1 : end])
            pos = end + 1
        else:
            m = _IDENT_RE.match(text, pos)
            if not m:
                raise ValueError("unexpected %r in production %r" % (ch, text))
            alternatives[-1].append(Nonterminal(m.group(0)))
            pos = m.end()
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the first production.
    # spec: N-000461, N-000462, N-000463, N-000464, N-000465, N-000466, N-000467, N-000471, N-000264, N-000265, N-000266
    """

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(str(start))
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        """Read productions, one ``<LHS> -> <RHS>`` per line; blank lines are ignored.
        # spec: N-000464, N-000465, N-000474
        """
        if not isinstance(input, str):
            raise TypeError("a grammar is given as text")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("a production needs '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT_RE.fullmatch(lhs_text):
                raise ValueError("a left-hand side must be a nonterminal name: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alternative in _parse_rhs(rhs_text.strip()):
                productions.append(Production(lhs, alternative))
        if not productions:
            raise ValueError("a grammar needs at least one production")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        """Every terminal that some production produces."""
        out = set()
        for production in self._productions:
            for symbol in production.rhs():
                if not isinstance(symbol, Nonterminal):
                    out.add(symbol)
        return out

    def __repr__(self):
        return "<CFG start=%s with %d productions>" % (self._start, len(self._productions))
