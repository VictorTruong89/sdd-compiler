"""Parsers over a context-free grammar (Interface Contract: ``lingora.parse``; PRD FP-05).

# spec: N-000461, N-000462, N-000463, N-000472, N-000473, N-000474, N-000475, N-000476, N-000266, N-000267, N-000268, N-000269, N-000270, N-000271, N-000272, N-000273, N-000274, N-000275, N-000292, N-000293, N-000294
"""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree


def _check_tokens(tokens, grammar):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for token in tokens:
        if token not in known:
            # spec: N-000292, N-000294 — a token no production produces does not succeed.
            raise ValueError("no production of the grammar produces the token %r" % token)
    return tokens


def _as_cfg(grammar):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    return grammar


class ChartParser:
    """Exhaustive chart-style parser: returns every tree the grammar assigns to the tokens.
    # spec: N-000266, N-000267, N-000268, N-000269, N-000270, N-000271
    """

    def __init__(self, grammar):
        self._grammar = _as_cfg(grammar)

    def parse(self, tokens):
        tokens = _check_tokens(tokens, self._grammar)
        memo = {}
        in_progress = set()
        grammar = self._grammar

        def parse_symbol(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in in_progress:
                return []  # break cycles through empty or unit productions
            in_progress.add(key)
            results = []
            for production in grammar.productions():
                if production.lhs() != name:
                    continue
                for children in derive_seq(production.rhs(), 0, i, j):
                    results.append(Tree(str(name), children))
            in_progress.discard(key)
            memo[key] = results
            return results

        def derive_seq(rhs, pos, i, j):
            if pos == len(rhs):
                if i == j:
                    yield []
                return
            symbol = rhs[pos]
            if isinstance(symbol, Nonterminal):
                for k in range(i, j + 1):
                    for subtree in parse_symbol(symbol, i, k):
                        for rest in derive_seq(rhs, pos + 1, k, j):
                            yield [subtree] + rest
            else:
                if i < j and tokens[i] == symbol:
                    for rest in derive_seq(rhs, pos + 1, i + 1, j):
                        yield [symbol] + rest

        return iter(parse_symbol(grammar.start(), 0, len(tokens)))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking.
    # spec: N-000272, N-000273, N-000274, N-000275
    """

    def __init__(self, grammar):
        self._grammar = _as_cfg(grammar)

    def parse(self, tokens):
        tokens = _check_tokens(tokens, self._grammar)
        grammar = self._grammar
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        stack = []
        buffer = list(tokens)

        def matches(item, symbol):
            if isinstance(symbol, Nonterminal):
                return isinstance(item, Tree) and item.label() == str(symbol)
            return isinstance(item, str) and not isinstance(item, Tree) and item == symbol

        def reducible():
            for production in productions:
                rhs = production.rhs()
                if len(stack) >= len(rhs) and all(
                    matches(item, sym) for item, sym in zip(stack[len(stack) - len(rhs):], rhs)
                ):
                    return production
            return None

        pos = 0
        while True:
            production = reducible()
            if production is not None:
                size = len(production.rhs())
                children = stack[len(stack) - size:]
                del stack[len(stack) - size:]
                stack.append(Tree(str(production.lhs()), children))
                continue
            if pos < len(buffer):
                stack.append(buffer[pos])
                pos += 1
                continue
            break

        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(grammar.start()):
            return iter([stack[0]])
        return iter([])


__all__ = ["ChartParser", "ShiftReduceParser"]
