"""Sentence generation from a grammar (Interface Contract: ``lingora.parse.generate``; PRD FP-05).

# spec: N-000276, N-000277, N-000278, N-000279, N-000280, N-000477, N-000478, N-000479, N-000480
"""

from lingora.grammar import CFG, Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of str tokens) derived from ``start``.

    ``n`` is the maximum number of sentences (None: no limit). ``depth`` bounds the
    derivation tree height (None: no bound). ``start`` defaults to the grammar's start
    symbol. Productions are expanded in their written order. A quoted empty-string
    terminal contributes an empty-string token; an empty production contributes none.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if n is not None and (not isinstance(n, int) or isinstance(n, bool)):
        raise TypeError("n must be an int or None")
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool)):
        raise TypeError("depth must be an int or None")
    symbol = grammar.start() if start is None else start
    if not isinstance(symbol, Nonterminal):
        symbol = Nonterminal(str(symbol))
    return _generator(grammar, symbol, depth, n)


def _generator(grammar, symbol, depth, n):
    count = 0
    for sentence in _derive(grammar, symbol, depth):
        if n is not None and count >= n:
            return
        yield list(sentence)
        count += 1
        if n is not None and count >= n:
            return


def _derive(grammar, symbol, depth):
    if depth is not None and depth < 1:
        return
    child_depth = None if depth is None else depth - 1
    for production in grammar.productions():
        if production.lhs() != symbol:
            continue
        for sentence in _derive_seq(grammar, production.rhs(), 0, child_depth):
            yield sentence


def _derive_seq(grammar, rhs, pos, depth):
    if pos == len(rhs):
        yield []
        return
    symbol = rhs[pos]
    if isinstance(symbol, Nonterminal):
        for head in _derive(grammar, symbol, depth):
            for rest in _derive_seq(grammar, rhs, pos + 1, depth):
                yield head + rest
    else:
        for rest in _derive_seq(grammar, rhs, pos + 1, depth):
            yield [symbol] + rest
