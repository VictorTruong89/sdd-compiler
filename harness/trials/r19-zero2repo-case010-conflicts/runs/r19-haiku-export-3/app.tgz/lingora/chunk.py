"""Chunking (Interface Contract: ``lingora.chunk``; PRD FP-04).

# spec: N-000446, N-000447, N-000448, N-000449, N-000450, N-000451, N-000452, N-000453, N-000454, N-000455, N-000456, N-000457, N-000458, N-000459, N-000460
"""

import os
import re

from lingora import data
from lingora.tree import Tree

# The default sentence label of the chunk structure root (implementer's choice).
SENTENCE_LABEL = "S"

_QUANT_RE = re.compile(r"[?*+]|\{\d*,?\d*\}")


class _Clause:
    def __init__(self, label):
        self.label = label
        self.rules = []  # list of (kind, compiled regex) where kind is "chunk" or "chink"


def _element_regex(content):
    """Turn the text inside <...> into a regex over one whole tag."""
    out = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            out.append(content[i : i + 2])
            i += 2
            continue
        if ch == ".":
            out.append("[^<>]")
        elif ch.isspace():
            pass
        else:
            out.append(ch)
        i += 1
    return "<(?:" + "".join(out) + ")>"


def _parse_pattern(line, pos):
    """Parse one ``{...}`` chunk or ``}...{`` chink pattern starting at ``pos``.

    Returns (kind, regex_source, new_pos).
    """
    opener = line[pos]
    closer = "}" if opener == "{" else "{"
    kind = "chunk" if opener == "{" else "chink"
    pos += 1
    parts = []
    while True:
        while pos < len(line) and line[pos].isspace():
            pos += 1
        if pos >= len(line):
            raise ValueError("unterminated chunk pattern in %r" % line)
        if line[pos] == closer:
            pos += 1
            break
        if line[pos] != "<":
            raise ValueError("expected '<' in tag pattern at %r" % line[pos:])
        end = line.find(">", pos)
        if end < 0:
            raise ValueError("unterminated '<' in tag pattern")
        element = _element_regex(line[pos + 1 : end])
        pos = end + 1
        quant = ""
        while pos < len(line) and line[pos].isspace():
            pos += 1  # whitespace in a pattern is ignored
        m = _QUANT_RE.match(line, pos)
        if m:  # a brace count such as {2,3} is a quantifier, not a closer
            quant = m.group(0)
            pos = m.end()
        parts.append("(?:" + element + ")" + quant)
    return kind, "".join(parts), pos


def _parse_grammar(text):
    """Read the chunk grammar text into clauses.

    A clause starts with a line ``<LABEL>: <pattern>``; further patterns of the same
    clause are on indented lines. A grammar is one or more clauses.
    # spec: N-000453, N-000454, N-000228, N-000229, N-000230
    """
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0] not in " \t" and not raw.lstrip().startswith(("{", "}")):
            if ":" not in raw:
                raise ValueError("a chunk clause must read '<LABEL>: <pattern>': %r" % raw)
            label, rest = raw.split(":", 1)
            label = label.strip()
            if not label:
                raise ValueError("a chunk clause needs a label: %r" % raw)
            current = _Clause(label)
            clauses.append(current)
            body = rest
        else:
            if current is None:
                raise ValueError("indented pattern before any clause: %r" % raw)
            body = raw
        pos = 0
        body = body.rstrip()
        while True:
            while pos < len(body) and body[pos].isspace():
                pos += 1
            if pos >= len(body):
                break
            if body[pos] not in "{}":
                raise ValueError("a pattern starts with '{' or '}': %r" % body)
            kind, source, pos = _parse_pattern(body, pos)
            current.rules.append((kind, re.compile(source)))
    if not clauses:
        raise ValueError("a chunk grammar needs at least one clause")
    return clauses


def _units_of(items):
    """Sequence of unit tags: a token's tag, or a chunk's label."""
    tags = []
    for item in items:
        tags.append(item.label() if isinstance(item, Tree) else item[1])
    return tags


def _match_runs(regex, tags):
    """Non-overlapping, leftmost matches over a sequence of unit tags.

    Returns (start_index, end_index) pairs in unit indices; zero-length matches are skipped.
    """
    text = "".join("<%s>" % t for t in tags)
    starts = []
    offset = 0
    for t in tags:
        starts.append(offset)
        offset += len(t) + 2
    starts.append(offset)
    index_of = {s: k for k, s in enumerate(starts)}
    runs = []
    for m in regex.finditer(text):
        if m.end() == m.start():
            continue
        if m.start() not in index_of or m.end() not in index_of:
            continue
        runs.append((index_of[m.start()], index_of[m.end()]))
    return runs


def _apply_chunk(items, regex, label, clause_chunks):
    """Each match among the units becomes one chunk carrying ``label``."""
    runs = _match_runs(regex, _units_of(items))
    if not runs:
        return items
    out = []
    cursor = 0
    for start, end in runs:
        out.extend(items[cursor:start])
        chunk = Tree(label, list(items[start:end]))
        clause_chunks.append(chunk)
        out.append(chunk)
        cursor = end
    out.extend(items[cursor:])
    return out


def _apply_chink(items, regex, clause_chunks):
    """Remove matching tokens from the chunks built earlier in the same clause."""
    for chunk in list(clause_chunks):
        position = next((k for k, item in enumerate(items) if item is chunk), None)
        if position is None:
            continue
        children = list(chunk)
        runs = _match_runs(regex, _units_of(children))
        if not runs:
            continue
        replacement = []
        cursor = 0
        for start, end in runs:
            if start > cursor:
                piece = Tree(chunk.label(), children[cursor:start])
                replacement.append(piece)
                clause_chunks.append(piece)
            replacement.extend(children[start:end])  # chinked: direct children of the root
            cursor = end
        if cursor < len(children):
            piece = Tree(chunk.label(), children[cursor:])
            replacement.append(piece)
            clause_chunks.append(piece)
        clause_chunks.remove(chunk)
        items[position : position + 1] = replacement
    return items


class RegexpParser:
    """Chunk parser that applies a chunk grammar to a list of tagged tokens.
    # spec: N-000446, N-000447, N-000448, N-000449, N-000451, N-000455, N-000456, N-000458, N-000459, N-000460, N-000237, N-000238, N-000239, N-000240, N-000241, N-000242, N-000243, N-000244, N-000245, N-000246, N-000247, N-000248, N-000249, N-000250, N-000251, N-000252, N-000253, N-000254, N-000255, N-000256
    """

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._text = grammar
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, str) for g in grammar):
            self._text = "\n".join(grammar)
        else:
            raise TypeError("grammar must be a str, or a list of chunk-parser stages")
        self._clauses = _parse_grammar(self._text) if self._text.strip() else []

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            items.append((pair[0], pair[1]))
        for clause in self._clauses:
            clause_chunks = []
            for kind, regex in clause.rules:
                if kind == "chunk":
                    items = _apply_chunk(items, regex, clause.label, clause_chunks)
                else:
                    items = _apply_chink(items, regex, clause_chunks)
        return Tree(_root_label(self._clauses), items)


def _root_label(clauses):
    label = SENTENCE_LABEL
    names = {c.label for c in clauses}
    while label in names:
        label = label + "_"
    return label


_NE_MODEL = os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass")
_NE_WORDS = os.path.join("corpora", "words")


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged chunker model and the English wordlist.

    Raises LookupError when either resource is not visible. The model's file format is
    not specified, so this build raises NotImplementedError when both are present
    (see NOTES.md).
    # spec: N-000452, N-000257
    """
    data.find(_NE_MODEL)
    data.find(_NE_WORDS)
    raise NotImplementedError("the named-entity chunker model format is outside this specification")
