"""Stemmers (Interface Contract: ``lingora.stem``; PRD FP-02).

# spec: N-000421, N-000422, N-000423, N-000424, N-000425, N-000426, N-000427, N-000428, N-000429, N-000430, N-000431, N-000432
"""

import os
import re

from lingora import data

_VOWELS = "aeiou"

# ---------------------------------------------------------------------------
# Porter stemmer (original algorithm + LINGORA extensions, FP-02)
# ---------------------------------------------------------------------------

ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
NLTK_EXTENSIONS = "NLTK_EXTENSIONS"  # the LINGORA extensions; the default mode

# The small built-in irregular-forms table. Its entries are not part of the spec.
_IRREGULAR = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "idly": "idl",
    "gently": "gentl",
    "ugly": "ugli",
    "early": "earli",
    "only": "onli",
    "singly": "singl",
    "sky": "sky",
    "news": "news",
    "howe": "howe",
    "inning": "inning",
    "innings": "inning",
}


def _is_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    """Porter measure m of the form [C](VC)^m[V]."""
    m = 0
    prev_vowel = False
    seen_vowel = False
    for i in range(len(stem)):
        if _is_cons(stem, i):
            if seen_vowel and prev_vowel:
                m += 1
            prev_vowel = False
        else:
            seen_vowel = True
            prev_vowel = True
    return m


def _contains_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _cvc(word, extensions):
    """*o: stem ends consonant-vowel-consonant, last not w, x or y."""
    if len(word) >= 3:
        if (
            _is_cons(word, len(word) - 3)
            and not _is_cons(word, len(word) - 2)
            and _is_cons(word, len(word) - 1)
            and word[-1] not in "wxy"
        ):
            return True
    if extensions and len(word) == 2 and not _is_cons(word, 0) and _is_cons(word, 1):
        return True
    return False


class PorterStemmer:
    """Porter's suffix-stripping stemmer.

    The default mode is the LINGORA extensions (NLTK_EXTENSIONS). The two other
    modes exist; MARTIN_EXTENSIONS is implemented as the original algorithm, and
    their results are outside the specification.
    # spec: N-000422, N-000423, N-000424, N-000425, N-000426, N-000149, N-000150, N-000151, N-000152, N-000153, N-000154, N-000155, N-000156, N-000157, N-000158, N-000159, N-000160, N-000161, N-000162, N-000163, N-000164, N-000165, N-000166, N-000167, N-000168, N-000169
    """

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=False):
        """# spec: N-000422, N-000426, N-000427"""
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        ext = self.mode == NLTK_EXTENSIONS
        if to_lowercase:
            word = word.lower()
        if ext and word in _IRREGULAR:
            return _IRREGULAR[word]
        if len(word) <= 2:
            return word
        word = _step1a(word, ext)
        word = _step1b(word, ext)
        word = _step1c(word, ext)
        word = _step2(word, ext)
        word = _step3(word)
        word = _step4(word)
        word = _step5(word, ext)
        return word


def _step1a(word, ext):
    if word.endswith("sses"):
        return word[:-2]
    if word.endswith("ies"):
        if ext and len(word) == 4:
            return word[:-1]  # LINGORA: a four-letter -ies word becomes -ie
        return word[:-2]
    if word.endswith("ss"):
        return word
    if word.endswith("s"):
        stem = word[:-1]
        if _contains_vowel(stem):
            return stem
    return word


def _step1b(word, ext):
    if ext and word.endswith("ied"):
        if len(word) == 4:
            return word[:-1]  # -ied -> -ie
        return word[:-3] + "i"  # -ied -> -i; rest of Step 1b skipped
    if word.endswith("eed"):
        if _measure(word[:-3]) > 0:
            return word[:-1]
        return word
    suffix = None
    if word.endswith("ed") and _contains_vowel(word[:-2]):
        suffix = "ed"
    elif word.endswith("ing") and _contains_vowel(word[:-3]):
        suffix = "ing"
    if suffix is None:
        return word
    stem = word[: -len(suffix)]
    if stem.endswith(("at", "bl", "iz")):
        return stem + "e"
    if _double_cons(stem) and stem[-1] not in "lsz":
        return stem[:-1]
    if _measure(stem) == 1 and _cvc(stem, ext):
        return stem + "e"
    return stem


def _step1c(word, ext):
    if ext:
        # LINGORA: y -> i only after a consonant that is not the first letter.
        if len(word) >= 3 and word.endswith("y") and _is_cons(word, len(word) - 2):
            return word[:-1] + "i"
        return word
    if word.endswith("y") and _contains_vowel(word[:-1]):
        return word[:-1] + "i"
    return word


_STEP2_TABLE = [
    ("ational", "ate"),
    ("tional", "tion"),
    ("enci", "ence"),
    ("anci", "ance"),
    ("izer", "ize"),
    ("bli", "ble"),
    ("alli", "al"),
    ("entli", "ent"),
    ("eli", "e"),
    ("ousli", "ous"),
    ("ization", "ize"),
    ("ation", "ate"),
    ("ator", "ate"),
    ("alism", "al"),
    ("iveness", "ive"),
    ("fulness", "ful"),
    ("ousness", "ous"),
    ("aliti", "al"),
    ("iviti", "ive"),
    ("biliti", "ble"),
]
_STEP2_TABLE_ORIGINAL = [
    ("ational", "ate"),
    ("tional", "tion"),
    ("enci", "ence"),
    ("anci", "ance"),
    ("izer", "ize"),
    ("abli", "able"),
    ("alli", "al"),
    ("entli", "ent"),
    ("eli", "e"),
    ("ousli", "ous"),
    ("ization", "ize"),
    ("ation", "ate"),
    ("ator", "ate"),
    ("alism", "al"),
    ("iveness", "ive"),
    ("fulness", "ful"),
    ("ousness", "ous"),
    ("aliti", "al"),
    ("iviti", "ive"),
    ("biliti", "ble"),
]


def _step2(word, ext):
    if ext and word.endswith("alli") and _measure(word[:-4]) > 0:
        # LINGORA: -alli -> -al is tried first, then Step 2 runs again.
        return _step2(word[:-4] + "al", ext)
    if ext and word.endswith("logi"):
        # LINGORA: -logi -> -log when the part before -ogi has positive measure.
        if _measure(word[:-3]) > 0:
            return word[:-1]
        return word
    table = _STEP2_TABLE if ext else _STEP2_TABLE_ORIGINAL
    if ext:
        table = table + [("fulli", "ful")]
    for suffix, repl in sorted(table, key=lambda item: -len(item[0])):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


_STEP3_TABLE = [
    ("icate", "ic"),
    ("ative", ""),
    ("alize", "al"),
    ("iciti", "ic"),
    ("ical", "ic"),
    ("ful", ""),
    ("ness", ""),
]

_STEP4_SUFFIXES = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _step3(word):
    for suffix, repl in sorted(_STEP3_TABLE, key=lambda item: -len(item[0])):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


def _step4(word):
    for suffix in sorted(_STEP4_SUFFIXES + ["ion"], key=lambda s: -len(s)):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if suffix == "ion" and not stem.endswith(("s", "t")):
                return word
            if _measure(stem) > 1:
                return stem
            return word
    return word


def _step5(word, ext):
    if word.endswith("e"):
        stem = word[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _cvc(stem, ext)):
            return stem
    if word.endswith("ll") and _measure(word) > 1:
        return word[:-1]
    return word


# ---------------------------------------------------------------------------
# Porter2 (the Snowball English algorithm) — used for SnowballStemmer('english')
# ---------------------------------------------------------------------------

_P2_EXCEPTIONS1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_P2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_P2_EXCEPTIONS2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_P2_VOWELS = "aeiouy"
_P2_LI_ENDINGS = "cdeghkmnrt"
_P2_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")


def _p2_regions(word):
    if word.startswith("gener") or word.startswith("commun"):
        r1 = 5 if word.startswith("gener") else 6
    elif word.startswith("arsen"):
        r1 = 5
    else:
        r1 = len(word)
        for i in range(1, len(word)):
            if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _p2_short_syllable_end(word):
    if len(word) == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if len(word) >= 3:
        return (
            word[-3] not in _P2_VOWELS
            and word[-2] in _P2_VOWELS
            and word[-1] not in _P2_VOWELS
            and word[-1] not in "wxY"
        )
    return False


def _porter2(word):
    if word in _P2_EXCEPTIONS1:
        return _P2_EXCEPTIONS1[word]
    if word in _P2_INVARIANT:
        return word
    if len(word) <= 2:
        return word
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    word = "".join(chars)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if word.endswith(suffix):
            word = word[: -len(suffix)]
            break

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-3] + ("i" if len(word) > 4 else "ie")
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        stem = word[:-1]
        if any(c in _P2_VOWELS for c in stem[:-1]):
            word = stem
    if word in _P2_EXCEPTIONS2:
        return word.replace("Y", "y")

    r1, r2 = _p2_regions(word)

    # Step 1b
    if word.endswith(("eedly", "eed")):
        suffix = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suffix) >= r1:
            word = word[: -len(suffix)] + "ee"
    else:
        suffix = None
        for cand in ("ingly", "edly", "ing", "ed"):
            if word.endswith(cand):
                suffix = cand
                break
        if suffix is not None:
            stem = word[: -len(suffix)]
            if any(c in _P2_VOWELS for c in stem):
                word = stem
                if word.endswith(("at", "bl", "iz")):
                    word += "e"
                elif word.endswith(_P2_DOUBLES):
                    word = word[:-1]
                elif len(word) <= r1 and _p2_short_syllable_end(word):
                    word += "e"

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _P2_VOWELS:
        word = word[:-1] + "i"

    r1, r2 = _p2_regions(word)

    # Step 2
    step2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
        ("ational", "ate"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
        ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
        ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"),
        ("bli", "ble"), ("lessli", "less"), ("fulli", "ful"), ("ogi", "og"),
        ("li", ""),
    ]
    for suffix, repl in sorted(step2, key=lambda item: -len(item[0])):
        if word.endswith(suffix) and len(word) - len(suffix) >= r1:
            if suffix == "li":
                if len(word) >= 3 and word[-3] in _P2_LI_ENDINGS:
                    word = word[:-2]
                break
            if suffix == "ogi":
                if len(word) >= 4 and word[-4] == "l":
                    word = word[:-3] + "og"
                break
            word = word[: -len(suffix)] + repl
            break

    # Step 3
    step3 = [
        ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
        ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
    ]
    for suffix, repl in sorted(step3, key=lambda item: -len(item[0])):
        if word.endswith(suffix):
            start = len(word) - len(suffix)
            if start >= r1 and (suffix != "ative" or start >= r2):
                word = word[:start] + repl
            break

    # Step 4
    step4 = [
        "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
        "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
    ]
    for suffix in sorted(step4, key=lambda s: -len(s)):
        if word.endswith(suffix):
            start = len(word) - len(suffix)
            if start >= r2:
                if suffix == "ion" and not (start >= 1 and word[start - 1] in "st"):
                    break
                word = word[:start]
            break

    # Step 5
    if word.endswith("e"):
        start = len(word) - 1
        if start >= r2 or (start >= r1 and not _p2_short_syllable_end(word[:start])):
            word = word[:start]
    elif word.endswith("l") and len(word) - 1 >= r2 and word[-2] == "l":
        word = word[:-1]

    return word.replace("Y", "y")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk) stemmer
# ---------------------------------------------------------------------------

# Rule syntax: <ending>[*]<digit><append>(.|>)
#   ending   letters the word must end with
#   *        the rule applies only while the word is intact (not yet truncated)
#   digit    number of letters removed from the end of the word
#   append   letters appended after the removal
#   '.'      stop after applying the rule; '>' continue with the next rules
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci>.", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "earth3>", "ef1.", "eg2>",
    "ei1.", "eit2.", "eligi3>", "eligi3.", "els2.", "em2>", "ens2.", "eps2.",
    "ess2.", "ev1.", "ex2>", "eye2.", "fi1.", "fie2.", "fie3.", "fu2>",
    "gaug2>", "gis4.", "gni3.", "gn1.", "gu2.", "hee2>", "hi5.", "hoo3>",
    "hts1.", "ia1.", "is2.", "ium3.", "ied1.", "ium4.", "ju2.", "ju3>",
    "ka1.", "ke1.", "kn1.", "lb1.", "lee2>", "lf1.", "lf2>", "lk1.", "lu3>",
    "ly2.", "ma2>", "mm2.", "mo2>", "mu2.", "ni2.", "no2>", "nu2.", "ny1.",
    "pl1.", "pp1.", "ra2>", "re2>", "ri2>", "rud1>", "se3>", "sis2.", "tt1.",
    "tr1>", "ty1.", "u1.", "us2>", "uz3.", "vd2>", "vs1.", "wa2>", "we2>",
    "ya2>", "yse2.", "yth2>", "zz1.", "eb2>", "ec2>", "eh1>", "ev2>",
    "ex2>", "ium3.", "men3.", "ment2>", "ness2>", "ion3>", "sm2.", "ant2>",
    "um2.", "bly3.", "ed2.", "ing3.",
]
# NOTE: this table was reconstructed from memory of the published Paice/Husk rules and
# is approximate; see NOTES.md.
_LANCASTER_PARSED = []
for _rule in _LANCASTER_RULES:
    _m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", _rule)
    if _m:
        _LANCASTER_PARSED.append(
            (_m.group(1), _m.group(2) == "*", int(_m.group(3)), _m.group(4), _m.group(5) == ">")
        )


class LancasterStemmer:
    """Paice/Husk Lancaster stemmer. The word is lowercased first; no prefix is stripped.
    # spec: N-000170, N-000171
    """

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        changed = True
        while changed:
            changed = False
            for ending, needs_intact, remove, append, cont in _LANCASTER_PARSED:
                if needs_intact and not intact:
                    continue
                if not word.endswith(ending):
                    continue
                candidate = word[:-remove] + append if remove else word + append
                if not _lancaster_acceptable(candidate, remove):
                    continue
                word = candidate
                intact = False
                changed = cont
                break
            if not changed:
                break
        return word


def _lancaster_acceptable(candidate, remove):
    if not candidate:
        return False
    if len(candidate) < 2:
        return False
    return bool(re.match(r"^[aeiouy]", candidate)) or len(candidate) >= 3


# ---------------------------------------------------------------------------
# Snowball
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


class SnowballStemmer:
    """Snowball stemmer. ``english`` is Porter2; ``porter`` is the original Porter algorithm.

    Other listed languages are accepted by name, but their stemming algorithms
    are not implemented here: ``stem`` raises NotImplementedError (see NOTES.md).
    # spec: N-000428, N-000429, N-000430, N-000431, N-000172, N-000173, N-000174, N-000175, N-000176, N-000177, N-000147, N-000148
    """

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language: %r (supported: %s)"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = None
        if self.ignore_stopwords:
            filename = os.path.join("corpora", "stopwords", language)
            self._stopwords = {
                line.strip().lower() for line in data.read_lines(data.find(filename)) if line.strip()
            }

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self.language == "english":
            return _porter2(word)
        if self.language == "porter":
            return PorterStemmer(ORIGINAL_ALGORITHM).stem(word)
        raise NotImplementedError(
            "the Snowball %s algorithm is not implemented in this build" % self.language
        )


# ---------------------------------------------------------------------------
# Regular-expression stemmer, WordNet lemmatizer, Arabic stemmers
# ---------------------------------------------------------------------------


class RegexpStemmer:
    """Removes every match of ``regexp`` from the word; nothing else changes.
    # spec: N-000178, N-000179, N-000180
    """

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        return self._regexp.sub("", word)


class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet index files.
    Raises LookupError at construction when WordNet is not visible.
    # spec: N-000432, N-000185, N-000186
    """

    _DETACH = {
        "n": [("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"),
              ("men", "man"), ("ies", "y"), ("s", "")],
        "v": [("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
              ("ing", "e"), ("ing", ""), ("s", "")],
    }

    def __init__(self):
        self._dir = data.find(os.path.join("corpora", "wordnet"))
        self._index = {}

    def _lemmas(self, pos):
        if pos not in self._index:
            names = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "r": "index.adv"}
            filename = os.path.join(self._dir, names.get(pos, "index.noun"))
            lemmas = set()
            if os.path.exists(filename):
                for line in data.read_lines(filename):
                    if line and not line.startswith(" "):
                        lemmas.add(line.split(" ", 1)[0])
            self._index[pos] = lemmas
        return self._index[pos]

    def lemmatize(self, word, pos="n"):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        lemmas = self._lemmas(pos)
        if word in lemmas or not lemmas:
            return word
        for suffix, repl in self._DETACH.get(pos, []):
            if word.endswith(suffix):
                candidate = word[: -len(suffix)] + repl
                if candidate in lemmas:
                    return candidate
        return word


class ARLSTem:
    """Arabic light stemmer. Its stemming results are outside this specification."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is outside this specification")


class ARLSTem2(ARLSTem):
    """Arabic light stemmer 2. Its stemming results are outside this specification."""


__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]
