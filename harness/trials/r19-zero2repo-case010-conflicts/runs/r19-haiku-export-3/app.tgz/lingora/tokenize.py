"""Tokenizers (Interface Contract: ``lingora.tokenize``; PRD FP-01).

# spec: N-000403, N-000404, N-000405, N-000406, N-000407, N-000408, N-000409, N-000410, N-000411, N-000412, N-000413
"""

import os
import re

from lingora import data

# ---------------------------------------------------------------------------
# Word/punctuation tokenizer
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space characters.
    # spec: N-000089, N-000090, N-000091
    """

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _WORDPUNCT_RE.finditer(text):
            yield (match.start(), match.end())


def wordpunct_tokenize(text):
    """# spec: N-000403"""
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters.
    # spec: N-000113
    """

    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        for match in re.finditer(r"\S+", text):
            yield (match.start(), match.end())


def whitespace_tokenize(text):
    return WhitespaceTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Blank-line tokenizer
# ---------------------------------------------------------------------------

_BLANKLINE_SEP_RE = re.compile(r"\s*\n[^\S\n]*\n\s*")


def blankline_tokenize(text):
    """Segments separated by a blank line (newline, optional whitespace, newline).
    # spec: N-000114, N-000115, N-000411
    """
    _check_text(text)
    pieces = _BLANKLINE_SEP_RE.split(text)
    return [piece.strip() for piece in pieces if piece.strip()]


# ---------------------------------------------------------------------------
# Regular-expression tokenizer
# ---------------------------------------------------------------------------


class RegexpTokenizer:
    """Token mode matches the pattern; gap mode splits on it.

    ``discard_empty`` is off unless the caller passes ``discard_empty=True``
    (Interface Contract). The PRD's "on by default" wording for this option is
    recorded as a conflict in NOTES.md.
    # spec: N-000116, N-000117, N-000118, N-000405, N-000406, N-000407
    """

    def __init__(self, pattern, gaps=False, discard_empty=False, flags=0):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = re.compile(pattern, flags)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            pieces = []
            last = 0
            for match in self._pattern.finditer(text):
                pieces.append(text[last:match.start()])
                last = match.end()
            pieces.append(text[last:])
        else:
            pieces = [m.group(0) for m in self._pattern.finditer(text)]
        if self._discard_empty:
            pieces = [p for p in pieces if p]
        return pieces

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            last = 0
            for match in self._pattern.finditer(text):
                if not self._discard_empty or match.start() > last:
                    yield (last, match.start())
                last = match.end()
            if not self._discard_empty or len(text) > last:
                yield (last, len(text))
        else:
            for match in self._pattern.finditer(text):
                if not self._discard_empty or match.end() > match.start():
                    yield (match.start(), match.end())


# ---------------------------------------------------------------------------
# Penn Treebank tokenizer and LINGORA's recommended word tokenizer
# ---------------------------------------------------------------------------
# The Penn rules are applied in the published order. The "improved" rules
# implement LINGORA's recommended word tokenizer (FP-01).

_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r'([ (\[{<])"'), r"\1 `` "),
]
_STARTING_QUOTES_IMPROVED = [
    (re.compile(r'^"'), "''"),  # FP-01: a straight quote at the very start is the closing token
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r'([ (\[{<])"'), r"\1 `` "),
]
_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]
_PUNCTUATION_IMPROVED = [
    (re.compile(r"[«»“”‘’„]"), r" \g<0> "),
    (re.compile(r"\.{2,}"), r" \g<0> "),
    (re.compile(r"[‒-―*]"), r" \g<0> "),
]
_PARENS_BRACKETS = [(re.compile(r"[\]\[\(\)\{\}<>]"), r" \g<0> ")]
_DOUBLE_DASHES = [(re.compile(r"--"), r" -- ")]
_ENDING_QUOTES = [
    (re.compile(r"''"), " '' "),
    (re.compile(r'"'), " '' "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]
_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_CONTRACTIONS3 = [
    re.compile(r"(?i) ('t)(is)\b"),
    re.compile(r"(?i) ('t)(was)\b"),
]


def _penn_tokenize(text, improved):
    starting = _STARTING_QUOTES_IMPROVED if improved else _STARTING_QUOTES
    for regex, sub in starting:
        text = regex.sub(sub, text)
    text = " " + text + " "
    rules = list(_PUNCTUATION)
    if improved:
        rules = _PUNCTUATION_IMPROVED + rules
    for regex, sub in rules:
        text = regex.sub(sub, text)
    for regex, sub in _PARENS_BRACKETS + _DOUBLE_DASHES:
        text = regex.sub(sub, text)
    text = " " + text + " "
    for regex, sub in _ENDING_QUOTES:
        text = regex.sub(sub, text)
    if not improved:
        for regex in _CONTRACTIONS2:
            text = regex.sub(lambda m: " " + m.group(1) + " " + m.group(2) + " ", text)
        for regex in _CONTRACTIONS3:
            text = regex.sub(lambda m: " " + m.group(1) + " " + m.group(2) + " ", text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer (FP-01).
    # spec: N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098, N-000099, N-000100, N-000101, N-000102, N-000103
    """

    def tokenize(self, text):
        _check_text(text)
        return _penn_tokenize(text, improved=False)


def _recommended_one_line(line):
    return _penn_tokenize(line, improved=True)


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON_RE = re.compile(
    r"(?:[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]"
    r"|[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3|\(?\^_\^\)?|\(-_-\)|o_O|O_o|T_T|XD|xD)"
)
_TWEET_TOKEN_RE = re.compile(
    "|".join(
        [
            r"(?:https?://\S+|www\.\S+)",  # URLs
            r"(?<!\w)@[A-Za-z0-9_]{1,15}",  # @-handles
            r"#\w+",  # hashtags
            _EMOTICON_RE.pattern,  # emoticons
            r"\w+(?:'\w+)*",  # words, contractions
            r"\.{2,}",  # ellipsis / runs of points
            r"\S",  # any other punctuation mark, one per token
        ]
    )
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tweet-style tokenizer (FP-01).
    # spec: N-000119, N-000120, N-000121, N-000122, N-000123, N-000124, N-000125
    """

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = [t for t in _TWEET_TOKEN_RE.findall(text) if t.strip()]
        out = []
        for token in tokens:
            if _EMOTICON_RE.fullmatch(token) or self._preserve_case:
                out.append(token)
            else:
                # Emoticons are never lowercased (choice recorded in NOTES.md).
                out.append(token.lower())
        return out


# ---------------------------------------------------------------------------
# Punkt sentence tokenizer (Kiss & Strunk 2006), using packaged parameters
# ---------------------------------------------------------------------------

_ORTHO_UPPER_START = 2
_ORTHO_UPPER_INSIDE = 4
_ORTHO_UPPER_UNKNOWN = 8
_ORTHO_LOWER_START = 16
_ORTHO_LOWER_INSIDE = 32
_ORTHO_LOWER_UNKNOWN = 64
_ORTHO_UPPER_MASK = _ORTHO_UPPER_START | _ORTHO_UPPER_INSIDE | _ORTHO_UPPER_UNKNOWN
_ORTHO_LOWER_MASK = _ORTHO_LOWER_START | _ORTHO_LOWER_INSIDE | _ORTHO_LOWER_UNKNOWN

_PUNKT_CACHE = {}


class _PunktParams:
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


def _load_punkt(language):
    """Load the packaged Punkt parameters for ``language`` (``tokenizers/punkt_tab/<language>``).

    Raises LookupError when the model directory is not visible.
    # spec: N-000086, N-000129, N-000130, N-000137, N-000138
    """
    if not isinstance(language, str) or not language or os.sep in language or "/" in language:
        raise LookupError("invalid Punkt language name: %r" % (language,))
    model_dir = data.find(os.path.join("tokenizers", "punkt_tab", language))
    if not os.path.isdir(model_dir):
        raise LookupError("Punkt model for %r is not a directory: %s" % (language, model_dir))
    key = os.path.abspath(model_dir)
    if key in _PUNKT_CACHE:
        return _PUNKT_CACHE[key]

    def lines(name):
        filename = os.path.join(model_dir, name)
        if not os.path.exists(filename):
            return []
        return [line for line in data.read_lines(filename) if line.strip()]

    abbrev = {line.strip().lower() for line in lines("abbrev_types.txt")}
    starters = {line.strip().lower() for line in lines("sent_starters.txt")}
    collocations = set()
    for line in lines("collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0].strip(), parts[1].strip()))
    ortho = {}
    for line in lines("ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0].strip()] = int(parts[1].strip())
    params = _PunktParams(abbrev, collocations, starters, ortho)
    _PUNKT_CACHE[key] = params
    return params


_NUMERIC_RE = re.compile(r"[\-\.,]?\d[\d\.,\-]*")
_LEADING_PUNCT_RE = re.compile(r"^[\(\[{<\"'`]+")
_TRAILING_PUNCT_RE = re.compile(r"[\]\)}>\"'`]*$")


def _punkt_type(core):
    """Punkt type of a token: lowercased, final period removed, numbers folded."""
    if _NUMERIC_RE.fullmatch(core):
        return "##number##"
    return core.lower().rstrip(".")


def _first_alpha(word):
    stripped = _LEADING_PUNCT_RE.sub("", word)
    for ch in stripped:
        if ch.isalpha():
            return ch
        if ch.isdigit():
            return ch
    return ""


def _punkt_sentence_spans(text, params):
    tokens = []
    for match in re.finditer(r"\S+", text):
        word = match.group(0)
        core = _TRAILING_PUNCT_RE.sub("", _LEADING_PUNCT_RE.sub("", word)) or word
        tokens.append((match.start(), match.end(), word, core))

    spans = []
    if not tokens:
        return spans
    start_index = 0
    n = len(tokens)
    for i in range(n):
        start, end, word, core = tokens[i]
        if i == n - 1:
            break
        ends_sentence = core.endswith("?") or core.endswith("!")
        is_period = core.endswith(".")
        if not ends_sentence and not is_period:
            continue
        if ends_sentence:
            is_break = True
        else:
            is_break = _period_is_break(tokens, i, params)
        if is_break:
            spans.append((tokens[start_index][0], tokens[i][1]))
            start_index = i + 1
    spans.append((tokens[start_index][0], tokens[-1][1]))
    return spans


def _period_is_break(tokens, i, params):
    core = tokens[i][3]
    typ = _punkt_type(core)
    next_word = tokens[i + 1][2]
    next_core = tokens[i + 1][3]
    next_type = _punkt_type(next_core)
    first = _first_alpha(next_word)
    if (typ, next_type) in params.collocations:
        return False
    is_abbrev = typ in params.abbrev_types or (len(typ) == 1 and typ.isalpha())
    if is_abbrev and typ != "##number##":
        if first and first.islower():
            return False
        if next_type in params.sent_starters:
            return True
        ortho = params.ortho_context.get(next_type, 0)
        if ortho & _ORTHO_UPPER_START and not ortho & _ORTHO_LOWER_START:
            return True
        return False
    # A period that ends an ordinary word: a break unless the next word is lower-case.
    if first and first.islower():
        return False
    return True


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model for ``language``.
    # spec: N-000129, N-000130, N-000131, N-000132, N-000133, N-000086, N-000137
    """
    _check_text(text)
    params = _load_punkt(language)
    return [text[s:e] for s, e in _punkt_sentence_spans(text, params)]


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (an improved Penn Treebank tokenizer).

    Unless ``preserve_line`` is True, the text is first split into sentences with
    the Punkt model for ``language`` (raises LookupError when it is missing).
    # spec: N-000104, N-000105, N-000106, N-000107, N-000108, N-000109, N-000110, N-000111, N-000112, N-000085, N-000086, N-000138
    """
    _check_text(text)
    if preserve_line:
        return _recommended_one_line(text)
    tokens = []
    for sentence in sent_tokenize(text, language):
        tokens.extend(_recommended_one_line(sentence))
    return tokens


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return True


__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]
