"""Evaluation metrics (Interface Contract: ``lingora.metrics``; PRD FP-07).

# spec: N-000498, N-000499, N-000500, N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507, N-000508, N-000509, N-000510
"""


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values.

    Lists of different lengths raise ValueError (Interface Contract; FP-06/FP-07 agree).
    # spec: N-000330, N-000331, N-000343, N-000501, N-000502
    """
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        return 0.0
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Minimum total cost of edits turning ``s1`` into ``s2``.

    Insertion and deletion cost 1; substitution costs ``substitution_cost``. With
    ``transpositions=True`` two adjacent characters may be swapped for cost 1, with
    nothing inserted or deleted between them (the restricted form; see NOTES.md).
    # spec: N-000322, N-000323, N-000324, N-000325, N-000326, N-000327, N-000328, N-000329, N-000348, N-000503, N-000504, N-000505, N-000506
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str values")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    transpositions = bool(transpositions)
    rows, cols = len(s1) + 1, len(s2) + 1
    d = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        d[i][0] = i
    for j in range(cols):
        d[0][j] = j
    for i in range(1, rows):
        for j in range(1, cols):
            same = s1[i - 1] == s2[j - 1]
            best = min(
                d[i - 1][j] + 1,
                d[i][j - 1] + 1,
                d[i - 1][j - 1] + (0 if same else substitution_cost),
            )
            if transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[rows - 1][cols - 1]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union (0 for two empty sets).
    # spec: N-000507
    """
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return (len(union) - len(label1 & label2)) / len(union)


def _require_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        # spec: N-000508, N-000509, N-000345 — lists, tuples and other non-sets are refused.
        raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    """|reference ∩ test| / |test|; None when ``test`` is empty.
    # spec: N-000332, N-000344, N-000508, N-000509, N-000510
    """
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|; None when ``reference`` is empty.
    # spec: N-000332, N-000344, N-000508, N-000509, N-000510
    """
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1-alpha)/recall).

    None when either set is empty or the two sets share no element (no number results;
    the absence is distinct from 0). See NOTES.md for the conflict this resolves.
    # spec: N-000333, N-000334, N-000346, N-000347, N-000508, N-000509, N-000510
    """
    _require_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return None
    return 1.0 / (alpha / p + (1 - alpha) / r)
