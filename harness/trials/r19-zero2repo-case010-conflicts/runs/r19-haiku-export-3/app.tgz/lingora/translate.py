"""BLEU (Interface Contract: ``lingora.translate``; PRD FP-07).

# spec: N-000511, N-000512, N-000513, N-000514, N-000515, N-000516, N-000517, N-000335, N-000336, N-000337, N-000338, N-000339, N-000340, N-000341, N-000342
"""

import collections
import math


def _check_tokens(tokens, what):
    if not isinstance(tokens, (list, tuple)):
        raise TypeError("%s must be a token list (a list of str)" % what)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("%s must be a token list (a list of str)" % what)
    return list(tokens)


def _ngram_counts(tokens, n):
    return collections.Counter(tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against one or more ``references``.

    ``weights`` gives one weight per n-gram order starting from unigrams; when omitted,
    unigrams and bigrams are weighted equally and longer n-grams are not scored
    (Interface Contract; the PRD's 1-4 gram default is recorded in NOTES.md).

    The call is unsmoothed unless ``smoothing_function`` is given. That argument is a
    callable taking a list of ``(clipped_count, total_count)`` pairs, one per order, and
    returning a list of precision values (the implementer's form, see NOTES.md).
    Without smoothing, the score is 0 when any weighted order has no match.
    """
    if not isinstance(references, (list, tuple)):
        raise TypeError("references is a list of token lists")
    refs = [_check_tokens(r, "a reference") for r in references]
    hyp = _check_tokens(hypothesis, "the hypothesis")
    if not refs:
        raise ValueError("bleu needs at least one reference")
    weights = list(weights)
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights are numbers")
    if not weights:
        raise ValueError("bleu needs at least one weight")

    pairs = []
    for order in range(1, len(weights) + 1):
        hyp_counts = _ngram_counts(hyp, order)
        max_ref = collections.Counter()
        for ref in refs:
            for gram, count in _ngram_counts(ref, order).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        total = max(len(hyp) - order + 1, 0)
        pairs.append((clipped, total))

    if smoothing_function is not None:
        precisions = list(smoothing_function(pairs))
    else:
        precisions = []
        for clipped, total in pairs:
            if total == 0 or clipped == 0:
                return 0.0
            precisions.append(clipped / total)

    if len(hyp) == 0:
        return 0.0
    # Reference length closest to the candidate length (the shorter when equally close).
    closest = min((len(r) for r in refs), key=lambda length: (abs(length - len(hyp)), length))
    if len(hyp) > closest:
        brevity = 1.0
    else:
        brevity = math.exp(1 - closest / len(hyp))

    log_sum = 0.0
    for w, p in zip(weights, precisions):
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)
    return brevity * math.exp(log_sum)
