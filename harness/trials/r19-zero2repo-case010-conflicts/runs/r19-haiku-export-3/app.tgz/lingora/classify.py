"""Classifiers (Interface Contract: ``lingora.classify``; PRD FP-06).

# spec: N-000492, N-000493, N-000494, N-000495, N-000496, N-000497, N-000295, N-000296, N-000297, N-000298, N-000299, N-000300, N-000301, N-000302, N-000303, N-000304, N-000305, N-000306, N-000307, N-000308, N-000309, N-000310, N-000311, N-000312, N-000313, N-000314, N-000315, N-000316, N-000317
"""

import collections
import math


class ProbDist:
    """A probability distribution over labels. ``prob(label)`` is a float; ``samples()`` lists labels.
    # spec: N-000496, N-000497, N-000307, N-000308
    """

    def __init__(self, probabilities):
        self._probabilities = dict(probabilities)

    def prob(self, label):
        return float(self._probabilities.get(label, 0.0))

    def samples(self):
        return list(self._probabilities)

    def max(self):
        return max(self._probabilities, key=lambda label: self._probabilities[label])

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probabilities)


def _check_labeled(labeled_featuresets):
    pairs = []
    for item in labeled_featuresets:
        if not (isinstance(item, (tuple, list)) and len(item) == 2):
            raise TypeError("labeled featuresets are (featureset, label) pairs")
        featureset, label = item
        if not isinstance(featureset, dict):
            raise TypeError("a featureset is a dict from feature names to values")
        pairs.append((featureset, label))
    return pairs


def _check_featureset(featureset):
    if not isinstance(featureset, dict):
        raise TypeError("a featureset is a dict from feature names to values")
    return featureset


class NaiveBayesClassifier:
    """Naive Bayes over labeled featuresets, with add-one smoothing of feature values.
    # spec: N-000302, N-000303, N-000304, N-000305, N-000306, N-000309, N-000315, N-000316, N-000317
    """

    def __init__(self, label_counts, feature_counts, feature_values, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts
        self._feature_values = feature_values
        self._total = total
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        if not pairs:
            raise ValueError("training needs at least one labeled featureset")
        label_counts = collections.Counter()
        feature_counts = collections.defaultdict(collections.Counter)
        feature_values = collections.defaultdict(set)
        for featureset, label in pairs:
            label_counts[label] += 1
            for name, value in featureset.items():
                feature_values[name].add(value)
                feature_counts[(label, name)][value] += 1
        return cls(label_counts, feature_counts, feature_values, len(pairs))

    def labels(self):
        """The labels seen in training."""
        return list(self._labels)

    def _log_scores(self, featureset):
        featureset = _check_featureset(featureset)
        scores = {}
        for label in self._labels:
            score = math.log(self._label_counts[label] / self._total)
            label_total = self._label_counts[label]
            for name, value in featureset.items():
                if name not in self._feature_values:
                    continue  # a feature name never seen in training is ignored
                seen = self._feature_values[name]
                count = self._feature_counts[(label, name)][value]
                vocab = len(seen) + 1  # add-one smoothing, with one slot for unseen values
                score += math.log((count + 1) / (label_total + vocab))
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(score - top) for label, score in scores.items()}
        norm = sum(exps.values())
        return ProbDist({label: value / norm for label, value in exps.items()})

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = None
        for label in self._labels:  # ties keep the first trained label
            if best is None or scores[label] > scores[best]:
                best = label
        return best


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Node:
    def __init__(self, feature, default, children):
        self.feature = feature
        self.default = default
        self.children = children


def _entropy(labels):
    counts = collections.Counter(labels)
    total = len(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = collections.Counter(labels)
    best = None
    for label in labels:  # ties: the label seen first
        if best is None or counts[label] > counts[best]:
            best = label
    return best


class DecisionTreeClassifier:
    """Decision tree of feature tests; a leaf returns the majority training label.
    # spec: N-000310, N-000311, N-000312, N-000313, N-000314, N-000315, N-000316, N-000317
    """

    def __init__(self, root, labels):
        self._root = root
        self._labels = labels

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        if not pairs:
            raise ValueError("training needs at least one labeled featureset")
        features = sorted({name for fs, _ in pairs for name in fs}, key=repr)
        labels = []
        for _, label in pairs:
            if label not in labels:
                labels.append(label)
        root = cls._build(pairs, features)
        return cls(root, labels)

    @classmethod
    def _build(cls, pairs, features):
        labels = [label for _, label in pairs]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Leaf(majority)
        base = _entropy(labels)
        best_feature = None
        best_gain = 0.0
        best_groups = None
        for feature in features:
            groups = collections.defaultdict(list)
            for fs, label in pairs:
                groups[fs.get(feature)].append((fs, label))
            remainder = sum(
                len(group) / len(pairs) * _entropy([lab for _, lab in group])
                for group in groups.values()
            )
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feature, best_gain, best_groups = feature, gain, groups
        if best_feature is None:
            return _Leaf(majority)
        remaining = [f for f in features if f != best_feature]
        children = {
            value: cls._build(group, remaining) for value, group in best_groups.items()
        }
        return _Node(best_feature, majority, children)

    def classify(self, featureset):
        featureset = _check_featureset(featureset)
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.default
            node = child
        return node.label

    def labels(self):
        return list(self._labels)


def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs the classifier labels correctly.
    # spec: N-000318, N-000495, N-000494
    """
    pairs = _check_labeled(gold)
    if not pairs:
        return 0.0
    correct = sum(1 for featureset, label in pairs if classifier.classify(featureset) == label)
    return correct / len(pairs)
