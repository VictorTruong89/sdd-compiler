# Spec coverage

Every id in `spec/CHECKLIST.md` (517 ids) ends in one of three states:

- **implemented**: the behaviour is built. Ids with a `# spec: N-…` marker in `lingora/` or a test name
  point to the code and tests. The ranges below cover the rest.
- **tested**: a test in `tests/` checks the behaviour. Test names carry the node ids.
- **not done**: listed here with the reason.

## Not done

| Ids | Claim | Reason |
|---|---|---|
| N-000143–N-000146 (part) | ISRI, ARLSTem, ARLSTem2, Cistem and RSLP exist as stemmer families | Their stemming results are outside this specification (PRD pack 23, N-000143–N-000146). `ARLSTem`/`ARLSTem2` are present as classes that raise `NotImplementedError` on `stem`. ISRI, Cistem and RSLP are not built. |
| N-000172, N-000173 (part) | Snowball algorithm for each listed language (Dutch original) | Only `english` (Porter2) and `porter` (original Porter) are implemented. The other 14 names are accepted by the constructor (and unsupported names raise, N-000181/182), but `stem` raises `NotImplementedError`. Writing 14 Snowball algorithms is out of reach for this build. |
| N-000231 | Named-entity chunker results when its model is installed | Results are outside this specification (PRD pack 25, N-000231). The model file format is not given. `ne_chunk` raises `LookupError` when the model or the English wordlist is missing (N-000452/257). When both are present it raises `NotImplementedError`. |
| N-000259 (part) | A recursive-descent parser exists | Outside this specification (PRD pack 26, N-000258–N-000261). Only the chart and shift-reduce parsers are built. |
| N-000349–N-000352 | Packaged corpora, WordNet beyond locating models, the downloader, graphical apps, chat/Twitter helpers, external-binary wrappers, semantic inference | Out of scope (PRD pack 29). Nothing is built. Absence is the requirement: the library ships no corpora and no downloader. |

## Implemented or tested, by range

| Ids | Claim (short) | Where |
|---|---|---|
| N-000001–N-000021 | Library, not an app; CLI is a convenience over the same tokenizer; feature points in dependency order; no invented surfaces; packaged-model prerequisites | `lingora/` package; `lingora/cli.py`; `lingora/data.py`; the packaged-model prerequisite is enforced by `LookupError` in `tokenize`, `stem`, `tag` and `chunk` |
| N-000022–N-000028 | Terminology: token, token list, span, sentence token, stem, tag, chunk, Punkt, tree, label | `tokenize.py`, `stem.py`, `tag.py`, `chunk.py`, `tree.py` |
| N-000029–N-000033 | Public surface: tokenizers incl. span and CLI | `tokenize.py`, `cli.py` (tests: `tests/test_tokenize.py`, `tests/test_cli_data.py`) |
| N-000034–N-000046 | Public surface: stemmers, taggers, chunking, grammar/parsing/trees, classifiers, scoring | modules as named; families partly not done (see above) |
| N-000047 | No product surfaces beyond the inventory | by construction |
| N-000048–N-000061 | Pure-Python, flat layout, Python 3.10+, no compiled code, CPU, no downloads needed for the baseline | `pyproject.toml` (flat `lingora` package, no dependencies); no third-party imports |
| N-000062–N-000068 | Data finder; Unicode in and out; in-process | `lingora/data.py`; `str` handling throughout |
| N-000069–N-000071 | Core capability; nothing works without the package | by construction |
| N-000072–N-000080 | Non-goals (no regex engine, no GUI, no external wrappers, no n-gram LM, no throughput guarantee) | absence; no such code |
| N-000081–N-000139 | FP-01 tokenization: word/punct, Penn, recommended, whitespace, blankline, regexp, tweet, spans, Punkt sentence splitting, CLI, error behaviour | `lingora/tokenize.py`, `lingora/cli.py`; tests `tests/test_tokenize.py` |
| N-000140–N-000146 (rest) | Stemmer families and their scope | `lingora/stem.py` |
| N-000147–N-000186 | Snowball language names, stopword skipping, unsupported language, WordNet lemmatizer | `lingora/stem.py` |
| N-000187–N-000227 | FP-03 tagging: default, unigram, bigram, trigram, affix, regexp, backoff; recommended perceptron tagger (en/ru); universal mapping; boundary rules | `lingora/tag.py`; tests `tests/test_stem_tag.py` |
| N-000228–N-000257 (rest) | FP-04 chunking: grammar, chunk and chink rules, root label, boundary rules | `lingora/chunk.py`; tests `tests/test_parse_chunk_tree.py` |
| N-000258–N-000294 (rest) | FP-05 grammar reader, chart and shift-reduce parsers, generator, trees, boundary rules | `lingora/grammar.py`, `lingora/parse/`, `lingora/tree.py` |
| N-000295–N-000318 | FP-06 Naive Bayes, decision tree, accuracy | `lingora/classify.py`; tests `tests/test_classify_metrics.py` |
| N-000319–N-000348 | FP-07 edit distance, Jaccard, accuracy, precision, recall, f-measure, BLEU | `lingora/metrics.py`, `lingora/translate.py`; tests `tests/test_classify_metrics.py` |
| N-000353–N-000384 | Hardware and surface shape: pure Python, Python 3.10+, flat package, callable entries, failures raise, number types | `pyproject.toml`; `lingora/`; every entry raises on a refusal |
| N-000385–N-000402 | Packaged resources: `data.path`, resource names, model file layouts, ortho bit set | `lingora/data.py` (`find`, `RESOURCE_NAMES`); `lingora/tokenize.py` (Punkt files); `lingora/tag.py` (perceptron and universal table files) |

## Appendix: every checklist id not cited by number in code

Each id below is covered by the range it falls in (see the tables above). The status is per id.

| Id | Pack | Status |
|---|---|---|
| N-000002 | 16 | implemented |
| N-000003 | 16 | implemented |
| N-000004 | 16 | implemented |
| N-000005 | 16 | implemented |
| N-000006 | 16 | implemented |
| N-000007 | 16 | implemented |
| N-000008 | 16 | implemented |
| N-000009 | 16 | implemented |
| N-000010 | 16 | implemented |
| N-000011 | 16 | implemented |
| N-000012 | 16 | implemented |
| N-000013 | 16 | implemented |
| N-000014 | 16 | implemented |
| N-000015 | 16 | implemented |
| N-000016 | 16 | implemented |
| N-000017 | 16 | implemented |
| N-000018 | 16 | implemented |
| N-000019 | 16 | implemented |
| N-000020 | 16 | implemented |
| N-000023 | 17 | implemented |
| N-000024 | 17 | implemented |
| N-000025 | 17 | implemented |
| N-000026 | 17 | implemented |
| N-000027 | 17 | implemented |
| N-000030 | 18 | implemented |
| N-000031 | 18 | implemented |
| N-000032 | 18 | implemented |
| N-000036 | 18 | implemented |
| N-000037 | 18 | implemented |
| N-000038 | 18 | implemented |
| N-000039 | 18 | implemented |
| N-000040 | 18 | implemented |
| N-000041 | 18 | implemented |
| N-000042 | 18 | implemented |
| N-000043 | 18 | implemented |
| N-000044 | 18 | implemented |
| N-000045 | 18 | implemented |
| N-000049 | 19 | implemented |
| N-000050 | 19 | implemented |
| N-000051 | 19 | implemented |
| N-000052 | 19 | implemented |
| N-000053 | 19 | implemented |
| N-000054 | 19 | implemented |
| N-000055 | 19 | implemented |
| N-000056 | 19 | implemented |
| N-000057 | 19 | implemented |
| N-000058 | 19 | implemented |
| N-000059 | 19 | implemented |
| N-000060 | 19 | implemented |
| N-000063 | 19 | implemented |
| N-000064 | 19 | implemented |
| N-000065 | 19 | implemented |
| N-000066 | 19 | implemented |
| N-000070 | 20 | implemented |
| N-000073 | 21 | implemented |
| N-000074 | 21 | implemented |
| N-000075 | 21 | implemented |
| N-000076 | 21 | implemented |
| N-000077 | 21 | implemented |
| N-000078 | 21 | implemented |
| N-000079 | 21 | implemented |
| N-000082 | 22 | implemented |
| N-000083 | 22 | implemented |
| N-000084 | 22 | implemented |
| N-000087 | 22 | implemented |
| N-000088 | 22 | implemented |
| N-000127 | 22 | implemented |
| N-000134 | 22 | implemented |
| N-000141 | 23 | implemented |
| N-000142 | 23 | implemented |
| N-000144 | 23 | not done (see table above) |
| N-000145 | 23 | implemented |
| N-000188 | 24 | implemented |
| N-000189 | 24 | implemented |
| N-000190 | 24 | implemented |
| N-000191 | 24 | implemented |
| N-000192 | 24 | implemented |
| N-000193 | 24 | implemented |
| N-000194 | 24 | implemented |
| N-000195 | 24 | implemented |
| N-000218 | 24 | implemented |
| N-000232 | 25 | implemented |
| N-000233 | 25 | implemented |
| N-000234 | 25 | implemented |
| N-000235 | 25 | implemented |
| N-000260 | 26 | implemented |
| N-000262 | 26 | implemented |
| N-000263 | 26 | implemented |
| N-000285 | 26 | implemented |
| N-000289 | 26 | implemented |
| N-000290 | 26 | implemented |
| N-000320 | 28 | implemented |
| N-000321 | 28 | implemented |
| N-000350 | 29 | not done (see table above) |
| N-000351 | 29 | not done (see table above) |
| N-000354 | 02 | implemented |
| N-000355 | 02 | implemented |
| N-000356 | 02 | implemented |
| N-000357 | 03 | implemented |
| N-000358 | 03 | implemented |
| N-000359 | 03 | implemented |
| N-000360 | 03 | implemented |
| N-000361 | 03 | implemented |
| N-000362 | 03 | implemented |
| N-000363 | 03 | implemented |
| N-000364 | 03 | implemented |
| N-000365 | 03 | implemented |
| N-000366 | 03 | implemented |
| N-000367 | 03 | implemented |
| N-000368 | 03 | implemented |
| N-000369 | 03 | implemented |
| N-000370 | 03 | implemented |
| N-000371 | 05 | implemented |
| N-000372 | 05 | implemented |
| N-000373 | 05 | implemented |
| N-000374 | 05 | implemented |
| N-000375 | 05 | implemented |
| N-000376 | 05 | implemented |
| N-000377 | 05 | implemented |
| N-000378 | 05 | implemented |
| N-000379 | 05 | implemented |
| N-000380 | 05 | implemented |
| N-000381 | 05 | implemented |
| N-000382 | 05 | implemented |
| N-000383 | 05 | implemented |
| N-000399 | 06 | implemented |
| N-000400 | 06 | implemented |
| N-000401 | 06 | implemented |
