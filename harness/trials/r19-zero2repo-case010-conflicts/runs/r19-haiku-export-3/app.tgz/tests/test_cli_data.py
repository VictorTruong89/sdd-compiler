"""Command line (lingora.cli) and the packaged-resource finder (lingora.data)."""

import os
import subprocess
import sys

from lingora import data

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _run_cli(args, stdin_text, env_extra):
    env = dict(os.environ)
    env.update(env_extra)
    env["PYTHONPATH"] = ROOT
    return subprocess.run(
        [sys.executable, "-m", "lingora"] + args,
        input=stdin_text.encode("utf-8"), capture_output=True, env=env, cwd=ROOT)


def test_N_000414_cli_tokenize_writes_one_line_per_input_line(resources):  # N-000414..N-000416
    env = {"LINGORA_DATA": str(resources)}
    proc = _run_cli(["tokenize"], "Hi there. Dr. Smith went home.\n\nDid it?\n", env)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.decode("utf-8") == "Hi there . Dr. Smith went home .\n\nDid it ?\n"


def test_N_000417_cli_failure_writes_no_token_line(tmp_path):  # N-000417..N-000418, N-000139
    proc = _run_cli(["tokenize"], "Hi there.\n", {"LINGORA_DATA": str(tmp_path)})
    assert proc.returncode != 0
    assert proc.stdout == b""


def test_N_000420_cli_delimiter_option(resources):  # N-000420
    proc = _run_cli(["tokenize", "-d", "|"], "Hi, there\n", {"LINGORA_DATA": str(resources)})
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.decode("utf-8") == "Hi|,|there\n"


def test_N_000385_data_path_is_mutable_and_finds_resources(tmp_path, monkeypatch):  # N-000385..N-000388
    monkeypatch.setattr(data, "path", [])
    try:
        data.find("corpora/words")
    except LookupError:
        pass
    else:
        raise AssertionError("an empty data.path must make nothing visible")
    (tmp_path / "corpora").mkdir()
    (tmp_path / "corpora" / "words").write_text("a\nb\n")
    data.path.append(str(tmp_path))
    assert data.find("corpora/words").endswith("words")
