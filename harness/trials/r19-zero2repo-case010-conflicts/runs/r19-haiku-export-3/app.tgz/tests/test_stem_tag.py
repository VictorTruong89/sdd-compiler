"""FP-02 stemming and FP-03 tagging."""

import pytest

from lingora import data
from lingora.stem import ORIGINAL_ALGORITHM, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag


def test_N_000153_porter_original_algorithm_examples():  # N-000153
    p = PorterStemmer(ORIGINAL_ALGORITHM)
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("relational") == "relat"
    assert p.stem("generalization") == "gener"


def test_N_000158_porter_lingora_extensions():  # N-000158, N-000156
    p = PorterStemmer()
    assert p.stem("ties") == "tie"  # four-letter -ies -> -ie
    assert p.stem("ab") == "ab"  # one or two characters are never stemmed
    assert p.stem("Running") == "Run"  # case is kept (no lowercasing) but the suffix is stripped
    assert p.stem("Running", to_lowercase=True) == "run"


def test_N_000180_regexp_stemmer_removes_matches():  # N-000178..N-000180
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("walk") == "walk"


def test_N_000182_snowball_unknown_language_names_it():  # N-000181, N-000182, N-000429, N-000430
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_N_000174_snowball_english_is_porter2():  # N-000174, N-000175
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("skies") == "sky"
    assert s.stem("dying") == "die"


def test_N_000183_snowball_stopwords_need_list(monkeypatch, tmp_path):  # N-000183, N-000184, N-000431
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N_000177_snowball_stopword_skipping(resources):  # N-000177
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"  # a stopword is returned lowercased and unchanged


def test_N_000195_default_and_unigram_tagging():  # N-000198..N-000201
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    uni = UnigramTagger(train=[[("dog", "NN"), ("dog", "NN"), ("dog", "VB")]],
                        backoff=DefaultTagger("X"))
    assert uni.tag(["dog", "zzz"]) == [("dog", "NN"), ("zzz", "X")]


def test_N_000202_regexp_tagger_first_rule_wins():  # N-000202..N-000204
    tagger = RegexpTagger([(r".*ing$", "VBG"), (r".*", "NN")])
    assert tagger.tag(["running", "dog"]) == [("running", "VBG"), ("dog", "NN")]


def test_N_000442_pos_tag_rejects_raw_string():  # N-000219, N-000221, N-000442
    with pytest.raises(TypeError):
        pos_tag("the dog")


def test_N_000207_perceptron_tagging_and_universal(resources):  # N-000207..N-000217
    assert pos_tag(["the", "dog", "runs"]) == [("the", "DT"), ("dog", "NN"), ("runs", "VBZ")]
    assert pos_tag(["the", "dog", "runs"], tagset="universal") == [
        ("the", "DET"), ("dog", "NOUN"), ("runs", "VERB")]


def test_N_000224_missing_perceptron_resource_raises(resources):  # N-000224, N-000225
    with pytest.raises(LookupError):
        pos_tag(["the"], lang="rus")


def test_N_000222_unsupported_tagger_language_raises(resources):  # N-000222, N-000223
    with pytest.raises(ValueError):
        pos_tag(["the"], lang="fra")
