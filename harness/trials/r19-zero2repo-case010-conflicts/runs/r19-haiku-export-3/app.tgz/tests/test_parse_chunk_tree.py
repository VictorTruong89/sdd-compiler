"""FP-04 chunking and FP-05 grammars, parsers, generation and trees."""

import pytest

from lingora.chunk import RegexpParser
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'a' N | NP PP
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'saw' | 'ran'
PP -> P NP
P -> 'with'
"""


def test_N_000464_cfg_reading_and_start():  # N-000461..N-000471
    g = CFG.fromstring(GRAMMAR)
    assert g.start() == "S"
    assert len(g.productions()) == 12
    assert list(g.productions()[0].rhs()) == [g.productions()[0].rhs()[0], g.productions()[0].rhs()[1]]
    assert "dog" in g.terminals()


def test_N_000266_chart_parser_returns_all_trees():  # N-000266..N-000271
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the dog saw a cat with the cat".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == "the dog saw a cat with the cat".split()
    assert list(ChartParser(g).parse("dog dog".split())) == []


def test_N_000292_unknown_token_raises():  # N-000292..N-000294, N-000475
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        list(ChartParser(g).parse(["zebra"]))


def test_N_000272_shift_reduce_matches_chart_on_unambiguous():  # N-000272..N-000275
    g = CFG.fromstring('S -> A B\nA -> "x"\nB -> "y"')
    sr = list(ShiftReduceParser(g).parse(["x", "y"]))
    assert sr == list(ChartParser(g).parse(["x", "y"]))


def test_N_000276_generate_enumerates_sentences():  # N-000276..N-000280, N-000477..N-000480
    g = CFG.fromstring('S -> "a" | "b" S\n')
    assert list(generate(g, n=3)) == [["a"], ["b", "a"], ["b", "b", "a"]]
    assert len(list(generate(CFG.fromstring('S -> "a" | "b"'), n=10))) == 2


def test_N_000281_tree_construction_and_bracketed_text():  # N-000281..N-000291, N-000481..N-000489
    t = Tree.fromstring("(S (NP the dog) (VP ran))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["ran"])])
    assert t.leaves() == ["the", "dog", "ran"]
    assert len(t) == 2 and t[1].label() == "VP"
    assert Tree("S", []).leaves() == []


def test_N_000288_tree_refuses_string_children():  # N-000288..N-000291, N-000486
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")


def test_N_000490_pformat_is_preorder():  # N-000287, N-000490
    text = Tree("S", [Tree("NP", ["the", "dog"]), "ran"]).pformat()
    assert text.index("S") < text.index("NP") < text.index("dog") < text.index("ran")


def test_N_000228_chunk_rules_and_chinks():  # N-000228..N-000249
    parser = RegexpParser("""
NP: {<DT>?<JJ>*<NN.*>+}
  {<PRP>}
VP: {<VB.*><NP>}
}<VB>{""")
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("ran", "VBD"), ("home", "NN")]
    tree = parser.parse(tagged)
    assert tree.label() == "S"
    assert tree.leaves() == tagged
    assert tree[0].label() == "NP"
    assert tree[0].leaves() == tagged[:3]


def test_N_000253_chunk_grammar_type_refused():  # N-000253..N-000256
    with pytest.raises(TypeError):
        RegexpParser(42)


def test_N_000252_empty_tagged_list_gives_sentence_root():  # N-000252
    assert RegexpParser("NP: {<DT><NN>}").parse([]) == Tree("S", [])


def test_N_000243_chink_splits_chunk_and_whitespace_ignored():  # N-000243..N-000245, N-000234
    parser = RegexpParser("NP: { <DT>? <JJ>* <NN.*> + }\n    }<JJ>{")
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("ran", "VBD")]
    tree = parser.parse(tagged)
    # The chunk "the big dog" is split on the chinked adjective, which becomes a root child.
    assert tree[0].label() == "NP" and tree[0].leaves() == [("the", "DT")]
    assert tree[1] == ("big", "JJ")
    assert tree[2].label() == "NP" and tree[2].leaves() == [("dog", "NN")]
    assert tree[3] == ("ran", "VBD")
    assert tree.leaves() == tagged
