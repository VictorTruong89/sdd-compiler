"""Shared fixtures: a small packaged-resource tree built under tmp_path (never inside /app)."""

import json
import os

import pytest

from lingora import data


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """Point data.path at a fixture tree holding a tiny Punkt model, taggers and stopwords."""
    root = tmp_path / "res"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("dr\nmr\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\nhe\nshe\nit\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("the\t4\nhe\t2\n", encoding="utf-8")

    eng = root / "taggers" / "averaged_perceptron_tagger_eng"
    eng.mkdir(parents=True)
    weights = {"bias": {"NN": 1.0}, "i word the": {"DT": 3.0}, "i word dog": {"NN": 2.0},
               "i word runs": {"VBZ": 2.0}}
    (eng / "averaged_perceptron_tagger_eng.weights.json").write_text(json.dumps(weights))
    (eng / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT", "dog": "NN"}))
    (eng / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["DT", "NN", "VBZ"]))

    universal = root / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\nVBZ\tVERB\n", encoding="utf-8")

    stop = root / "corpora" / "stopwords"
    stop.mkdir(parents=True)
    (stop / "english").write_text("the\na\nof\n", encoding="utf-8")

    monkeypatch.setattr(data, "path", [str(root)])
    return root
