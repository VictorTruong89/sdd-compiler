"""FP-06 classification and FP-07 metrics."""

import pytest

from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.metrics import (
    accuracy as list_accuracy,
    edit_distance,
    f_measure,
    jaccard_distance,
    precision,
    recall,
)
from lingora.translate import bleu

TRAIN = [({"w": "good"}, "pos"), ({"w": "great"}, "pos"),
         ({"w": "bad"}, "neg"), ({"w": "awful"}, "neg")]


def test_N_000302_naive_bayes_label_and_distribution():  # N-000302..N-000309
    nb = NaiveBayesClassifier.train(TRAIN)
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"unseen_feature": 1}) in {"pos", "neg"}
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(l) for l in dist.samples()) - 1.0) < 1e-9
    assert dist.prob("neg") > dist.prob("pos")
    assert sorted(nb.labels()) == ["neg", "pos"]


def test_N_000310_decision_tree_fits_training():  # N-000310..N-000317
    dt = DecisionTreeClassifier.train(TRAIN)
    assert accuracy(dt, TRAIN) == 1.0
    assert dt.classify({"w": "bad"}) == "neg"
    assert dt.classify({"other": 3}) in {"pos", "neg"}


def test_N_000330_accuracy_positions():  # N-000330, N-000331, N-000343
    assert list_accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])


def test_N_000322_edit_distance():  # N-000322..N-000329, N-000348
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("", "") == 0
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ca", "abc", transpositions=True) == 3  # restricted form


def test_N_000507_jaccard_distance():  # N-000507
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


def test_N_000332_precision_recall_fmeasure():  # N-000332..N-000334, N-000344..N-000347
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert precision({1}, set()) is None
    assert f_measure({1}, {2}) is None  # no shared element: no number, not 0


def test_N_000345_non_set_arguments_refused():  # N-000345, N-000509
    with pytest.raises(TypeError):
        precision([1], [1])


def test_N_000335_bleu_identical_and_disjoint():  # N-000335..N-000342, N-000513..N-000516
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["zebra", "quux"]) == 0.0
    assert 0 < bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) < 1
