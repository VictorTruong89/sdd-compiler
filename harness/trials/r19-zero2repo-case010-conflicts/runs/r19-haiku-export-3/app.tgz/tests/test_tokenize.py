"""FP-01 tokenizers. Test names carry the spec node ids they verify."""

import pytest

from lingora import data
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


def test_N_000089_wordpunct_splits_words_and_punctuation():  # N-000089..N-000091
    assert wordpunct_tokenize("Hello, world! It costs $3.50.") == [
        "Hello", ",", "world", "!", "It", "costs", "$", "3", ".", "50", "."]


def test_wordpunct_spans_recover_tokens():  # N-000126..N-000128
    text = "ab, c"
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == ["ab", ",", "c"]
    assert all(a >= 0 for a, _ in spans)
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_N_000092_penn_quotes_clitics_and_fused_forms():  # N-000092..N-000103
    tok = TreebankWordTokenizer().tokenize
    assert tok('"Hello," said Mr. Smith.') == [
        "``", "Hello", ",", "''", "said", "Mr.", "Smith", "."]
    assert tok("I can't go") == ["I", "ca", "n't", "go"]
    assert tok("We're gonna win") == ["We", "'re", "gon", "na", "win"]
    assert tok("the ... end") == ["the", "...", "end"]


def test_N_000104_recommended_keeps_cannot_and_splits_quotes():  # N-000104..N-000110
    assert word_tokenize("I cannot go.", preserve_line=True) == ["I", "cannot", "go", "."]
    tokens = word_tokenize("A “quote” here", preserve_line=True)
    assert tokens == ["A", "“", "quote", "”", "here"]
    assert word_tokenize("wait -- what", preserve_line=True) == ["wait", "--", "what"]


def test_N_000113_whitespace_and_blankline():  # N-000113..N-000115
    assert WhitespaceTokenizer().tokenize("a  b\tc\n") == ["a", "b", "c"]
    assert blankline_tokenize("one\ntwo\n\n\n three\n") == ["one\ntwo", "three"]


def test_N_000116_regexp_token_and_gap_modes():  # N-000116..N-000118
    assert RegexpTokenizer(r"\w+").tokenize("a, b") == ["a", "b"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "", "b"]
    assert RegexpTokenizer(r",", gaps=True, discard_empty=True).tokenize("a,,b") == ["a", "b"]


def test_N_000119_tweet_tokenizer_rules():  # N-000119..N-000125
    tok = TweetTokenizer(preserve_case=False)
    assert tok.tokenize("OMG @bob I :) can't #Yay http://x.io/A") == [
        "omg", "@bob", "i", ":)", "can't", "#yay", "http://x.io/a"]
    assert TweetTokenizer(preserve_case=True).tokenize("Hello") == ["Hello"]
    assert TweetTokenizer(strip_handles=True).tokenize("hi@bob x") == ["hi", "@", "bob", "x"]
    assert TweetTokenizer(strip_handles=True).tokenize("hi @bob x") == ["hi", "x"]
    assert TweetTokenizer(reduce_len=True).tokenize("sooooo") == ["sooo"]


def test_N_000136_empty_and_whitespace_yield_empty_lists():  # N-000136
    assert wordpunct_tokenize("") == []
    assert TreebankWordTokenizer().tokenize("   ") == []
    assert WhitespaceTokenizer().tokenize(" \n ") == []


def test_N_000129_sent_tokenize_uses_packaged_punkt(resources):  # N-000129..N-000133
    sentences = sent_tokenize("Dr. Smith went home. The dog ran away! Yes.")
    assert sentences == ["Dr. Smith went home.", "The dog ran away!", "Yes."]


def test_N_000137_missing_punkt_raises(monkeypatch, tmp_path):  # N-000137, N-000138, N-000413
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        sent_tokenize("Hi there.")
    with pytest.raises(LookupError):
        word_tokenize("Hi there.")
    assert word_tokenize("Hi there.", preserve_line=True) == ["Hi", "there", "."]
