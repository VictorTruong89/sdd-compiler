"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from .. import data


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        self._backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), t) for rx, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, t in self._regexps:
            if rx.match(tokens[index]):
                return t
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = dict(context_to_tag) if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        return self._context_to_tag.get(ctx)


class NgramTagger(ContextTagger):
    def __init__(self, n, train=None, model=None, backoff=None, cutoff=0):
        self._n = n
        self._cutoff = cutoff
        ContextTagger.__init__(self, model, backoff)
        if train is not None:
            if model is not None:
                raise ValueError("Cannot specify both train and model")
            self._train(train)

    def context(self, tokens, index, history):
        tag_context = tuple(history[max(0, index - self._n + 1):index])
        return tag_context, tokens[index]

    def _train(self, tagged_corpus):
        fd = defaultdict(Counter)
        useful = []
        useful_set = set()
        for sentence in tagged_corpus:
            sentence = list(sentence)
            if not sentence:
                continue
            tokens = [w for w, _ in sentence]
            tags = [t for _, t in sentence]
            for index, (token, tag) in enumerate(sentence):
                ctx = self.context(tokens, index, tags[:index])
                if ctx is None:
                    continue
                fd[ctx][tag] += 1
                if self._backoff is None or tag != self._backoff.tag_one(tokens, index, tags[:index]):
                    if ctx not in useful_set:
                        useful_set.add(ctx)
                        useful.append(ctx)
        for ctx in useful:
            best_tag, hits = None, -1
            for t, c in fd[ctx].items():
                if c > hits:
                    best_tag, hits = t, c
            if hits > self._cutoff:
                self._context_to_tag[ctx] = best_tag


class UnigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 1, train, model, backoff, cutoff)

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 2, train, model, backoff, cutoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 3, train, model, backoff, cutoff)


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, model, backoff)
        if train:
            fd = defaultdict(Counter)
            for sent in train:
                for i, (w, t) in enumerate(sent):
                    c = self.context([x for x, _ in sent], i, None)
                    if c is not None:
                        fd[c][t] += 1
            for c, cnt in fd.items():
                best = max(cnt, key=cnt.get)
                if cnt[best] > cutoff:
                    self._context_to_tag[c] = best

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]


# ---------------------------------------------------------------- perceptron

START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]


def _model_dir(lang):
    return data.find("taggers/averaged_perceptron_tagger_%s" % lang, want_dir=True)


class PerceptronTagger(TaggerI):
    def __init__(self, lang="eng"):
        d = _model_dir(lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                self.weights = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                self.tagdict = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                self.classes = set(json.load(f))
        except OSError as e:
            raise LookupError("tagger model files for %r not readable: %s" % (lang, e))

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _get_features(self, i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = START
        output = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._get_features(i, word, context, prev, prev2))
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_RU_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "NUM": "NUM", "ANUM": "ADJ", "A-PRO": "PRON", "S-PRO": "PRON", "ADV-PRO": "PRON",
    "A-NUM": "NUM", "PART": "PRT", "PARENTH": "PRT", "INTJ": "X", "COM": "X",
    "NONLEX": ".", "P": "ADP", "N": "NOUN", "ADJ": "ADJ", "PRON": "PRON",
}


def _map_ru(tag):
    if tag is None:
        return None
    base = tag.split("=")[0]
    return _RU_UNIVERSAL.get(base, "X")


def _load_en_ptb():
    d = data.find("taggers/universal_tagset", want_dir=True)
    p = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(p):
        raise LookupError("universal tagset table en-ptb.map not found")
    m = {}
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\r\n")
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, NLTK pos_tag only supports English and Russian (i.e. lang='eng' or lang='rus')")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            m = _load_en_ptb()
            return [(w, m.get(t, "X") if t is not None else None) for w, t in tagged]
        return [(w, _map_ru(t)) for w, t in tagged]
    return tagged


__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger", "TrigramTagger",
           "AffixTagger", "PerceptronTagger", "pos_tag"]
