from .chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Exhaustive parser (implemented with the chart machinery)."""
