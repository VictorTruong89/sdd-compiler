from ..grammar import Nonterminal


def check_coverage(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of strings")
    tokens = list(tokens)
    terminals = set()
    for p in grammar.productions():
        for s in p.rhs():
            if isinstance(s, str):
                terminals.add(s)
    missing = [t for t in tokens if t not in terminals]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r" % (missing,))
    return tokens
