import sys
from ..tree import Tree
from ..grammar import Nonterminal
from ._util import check_coverage


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = check_coverage(self._grammar, tokens)
        return iter(self._parses(tokens, tree_class))

    def _parses(self, tokens, tree_class):
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()
        old = sys.getrecursionlimit()
        if old < 10000:
            sys.setrecursionlimit(10000)

        def nt_parses(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            result = []
            for prod in g.productions(sym):
                for kids in match(prod.rhs(), 0, i, j):
                    result.append(tree_class(str(sym), kids))
            active.discard(key)
            memo[key] = result
            return result

        def match(rhs, k, i, j):
            # yield lists of children for rhs[k:] covering tokens[i:j]
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, Nonterminal):
                last = k == len(rhs) - 1
                ends = [j] if last else range(i, j + 1)
                for e in ends:
                    for t in nt_parses(sym, i, e):
                        for rest in match(rhs, k + 1, e, j):
                            yield [t] + rest
            else:
                if sym == "":
                    for rest in match(rhs, k + 1, i, j):
                        yield rest
                elif i < j and tokens[i] == sym:
                    for rest in match(rhs, k + 1, i + 1, j):
                        yield [sym] + rest

        try:
            return list(nt_parses(g.start(), 0, n))
        finally:
            sys.setrecursionlimit(old)
