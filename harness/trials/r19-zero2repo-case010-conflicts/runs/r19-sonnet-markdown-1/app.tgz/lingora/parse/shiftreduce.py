from ..tree import Tree
from ..grammar import Nonterminal
from ._util import check_coverage


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = check_coverage(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            n = len(rhs)
            if n == 0 or len(stack) < n:
                continue
            tail = stack[-n:]
            ok = True
            for elt, r in zip(tail, rhs):
                if isinstance(r, Nonterminal):
                    if not (isinstance(elt, Tree) and elt.label() == r.symbol()):
                        ok = False
                        break
                else:
                    if not (isinstance(elt, str) and elt == r):
                        ok = False
                        break
            if ok:
                new = Tree(str(prod.lhs()), list(tail))
                del stack[-n:]
                stack.append(new)
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return [stack[0]]
        return []
