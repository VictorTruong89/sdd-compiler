"""Command-line group (a small click-like implementation, no dependencies)."""
import sys

from .tokenize import word_tokenize
from . import tokenize as _tk
from .tokenize import punkt as _punkt


class UsageError(Exception):
    pass


def _tokenize_command(args):
    language = "english"
    delimiter = " "
    encoding = "utf8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if i + 1 >= len(args):
                raise UsageError("Option %s requires an argument" % a)
            v = args[i + 1]
            if a in ("-l", "--language"):
                language = v
            elif a in ("-d", "--delimiter"):
                delimiter = v
            else:
                encoding = v
            i += 2
        elif a.startswith("--") and "=" in a:
            k, v = a.split("=", 1)
            args = args[:i] + [k, v] + args[i + 1:]
        elif a in ("--help", "-h"):
            sys.stdout.write("Usage: tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING]\n")
            return 0
        else:
            raise UsageError("Got unexpected extra argument (%s)" % a)
    # fail before reading input if the sentence model is missing
    _punkt.load_tokenizer(language)
    raw = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read().encode("utf-8")
    text = raw.decode(encoding)
    out = sys.stdout.buffer if hasattr(sys.stdout, "buffer") else None
    lines = text.splitlines()
    for line in lines:
        toks = word_tokenize(line, language)
        s = delimiter.join(toks) + "\n"
        if out is not None:
            out.write(s.encode("utf-8"))
        else:
            sys.stdout.write(s)
    if out is not None:
        out.flush()
    return 0


class Group:
    def __init__(self):
        self.commands = {"tokenize": _tokenize_command}

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        code = 0
        try:
            if not args or args[0] in ("--help", "-h"):
                sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  tokenize\n")
                code = 0 if args else 0
            elif args[0] not in self.commands:
                raise UsageError("No such command '%s'." % args[0])
            else:
                code = self.commands[args[0]](args[1:]) or 0
        except UsageError as e:
            sys.stderr.write("Error: %s\n" % e)
            code = 2
            if not standalone_mode:
                raise
        except SystemExit:
            raise
        except BaseException as e:  # failures: no token line for the failed input
            sys.stderr.write("Error: %s\n" % (e,))
            code = 1
            if not standalone_mode:
                raise
        if standalone_mode:
            sys.exit(code)
        return code

    __call__ = main


cli = Group()
