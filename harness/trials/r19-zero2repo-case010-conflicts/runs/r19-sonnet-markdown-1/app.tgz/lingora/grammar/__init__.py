"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOK = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._lhs_index.get(lhs, []))

    def is_nonterminal(self, x):
        return isinstance(x, Nonterminal)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    %s" % p for p in self._productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            input = "\n".join(input)
        productions = []
        start = None
        lhs = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|"):
                if lhs is None:
                    raise ValueError("Unable to parse line: %r" % raw)
                rhs_text = line
            else:
                if "->" not in line:
                    raise ValueError("Unable to parse line: %r" % raw)
                left, rhs_text = line.split("->", 1)
                left = left.strip()
                if not left or re.search(r"\s", left) or left[0] in "'\"":
                    raise ValueError("Unable to parse line: %r" % raw)
                lhs = Nonterminal(left)
                if start is None:
                    start = lhs
            alts = [[]]
            for tok in _TOK.findall(rhs_text):
                if tok == "|":
                    alts.append([])
                elif tok[0] in "'\"":
                    alts[-1].append(tok[1:-1])
                else:
                    alts[-1].append(Nonterminal(tok))
            if line.startswith("|"):
                alts = alts[1:] if alts and not alts[0] else alts
            for alt in alts:
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, productions)


def nonterminals(symbols):
    return [Nonterminal(s) for s in symbols.replace(",", " ").split()]


__all__ = ["CFG", "Nonterminal", "Production", "nonterminals"]
