"""Packaged-resource finder. ``path`` is a mutable list of directories."""
import os

path = []
for _p in os.environ.get("LINGORA_DATA", "").split(os.pathsep):
    if _p:
        path.append(_p)
path.extend(
    [
        os.path.join(os.path.expanduser("~"), "lingora_data"),
        "/usr/share/lingora_data",
        "/usr/local/share/lingora_data",
        os.path.join(os.path.expanduser("~"), "nltk_data"),
        "/usr/share/nltk_data",
        "/usr/local/share/nltk_data",
        "/usr/lib/nltk_data",
    ]
)


def find(resource, want_dir=None):
    """Return the filesystem path of ``resource`` found on ``path``.

    Raises LookupError if it is not visible."""
    rel = resource.strip("/")
    for d in list(path):
        cand = os.path.join(str(d), *rel.split("/"))
        if os.path.exists(cand):
            if want_dir is True and not os.path.isdir(cand):
                continue
            if want_dir is False and not os.path.isfile(cand):
                continue
            return cand
    raise LookupError("Resource %r not found on lingora.data.path" % resource)
