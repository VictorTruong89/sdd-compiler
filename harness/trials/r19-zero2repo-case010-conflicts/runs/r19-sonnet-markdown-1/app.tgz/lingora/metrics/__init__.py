"""Evaluation metrics."""
import operator


def accuracy(reference, test):
    if not hasattr(reference, "__len__") or not hasattr(test, "__len__"):
        raise TypeError("accuracy requires two lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if len(reference) == 0:
        return 0.0
    return sum(x == y for x, y in zip(reference, test)) / len(test)


def _edit_dist_init(len1, len2):
    lev = []
    for i in range(len1):
        lev.append([0] * len2)
    for i in range(len1):
        lev[i][0] = i
    for j in range(len2):
        lev[0][j] = j
    return lev


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance requires strings")
    len1 = len(s1)
    len2 = len(s2)
    lev = _edit_dist_init(len1 + 1, len2 + 1)
    for i in range(len1):
        c1 = s1[i]
        for j in range(len2):
            c2 = s2[j]
            a = lev[i][j + 1] + 1
            b = lev[i + 1][j] + 1
            c = lev[i][j] + (substitution_cost if c1 != c2 else 0)
            d = c + 1
            if transpositions and i > 0 and j > 0:
                if s1[i - 1] == c2 and s2[j - 1] == c1:
                    d = lev[i - 1][j - 1] + 1
            lev[i + 1][j + 1] = min(a, b, c, d)
    return lev[len1][len2]


def jaccard_distance(label1, label2):
    label1 = set(label1)
    label2 = set(label2)
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    return (union - len(label1 & label2)) / union


def _require_set(x, name):
    if not isinstance(x, (set, frozenset)):
        raise TypeError("%s must be a set" % name)


def precision(reference, test):
    _require_set(reference, "reference")
    _require_set(test, "test")
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _require_set(reference, "reference")
    _require_set(test, "test")
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)


__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]
