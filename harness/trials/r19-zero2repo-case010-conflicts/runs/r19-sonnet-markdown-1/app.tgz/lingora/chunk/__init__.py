"""Chunking with tag-pattern grammars."""
import re
from ..tree import Tree
from .. import data


def tag_pattern2re_pattern(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = re.sub(r"<", "(?:<(?:", p)
    p = re.sub(r">", ")>)", p)
    # '.' inside an element matches any tag character
    p = _dots(p)
    return p


def _dots(p):
    # replace unescaped '.' by a class that cannot cross tag/chunk boundaries
    out = []
    i = 0
    while i < len(p):
        c = p[i]
        if c == "\\" and i + 1 < len(p):
            out.append(p[i:i + 2])
            i += 2
            continue
        if c == ".":
            out.append(r"[^\{\}<>]")
        else:
            out.append(c)
        i += 1
    return "".join(out)


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        body = tag_pattern2re_pattern(pattern)
        try:
            if kind == "chunk":
                self.regex = re.compile(r"(?P<chunk>%s)(?=[^\}]*(\{|$))" % body)
            else:
                self.regex = re.compile(r"(?P<chink>%s)(?=[^\{]*\})" % body)
        except re.error as e:
            raise ValueError("Bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        if self.kind == "chunk":
            s = self.regex.sub(r"{\g<chunk>}", s)
        else:
            s = self.regex.sub(r"}\g<chink>{", s)
        return s.replace("{}", "")


class ChunkStage:
    """One clause: a label and an ordered list of rules."""

    def __init__(self, label, rules=None):
        self.label = label
        self.rules = list(rules or [])

    def add(self, kind, pattern):
        self.rules.append(_Rule(kind, pattern))

    def parse(self, chunk_struct, root_label="S"):
        items = list(chunk_struct)
        pieces = []
        for it in items:
            if isinstance(it, Tree):
                pieces.append(it.label())
            else:
                pieces.append(it[1])
        s = "".join("<%s>" % t for t in pieces)
        for r in self.rules:
            s = r.apply(s)
        out = []
        index = 0
        in_chunk = False
        for piece in re.split(r"[{}]", s):
            length = piece.count("<")
            sub = items[index:index + length]
            index += length
            if in_chunk:
                if sub:
                    out.append(Tree(self.label, sub))
            else:
                out.extend(sub)
            in_chunk = not in_chunk
        return Tree(root_label, out)


_LABEL_RE = re.compile(r"^\s*([^\s:{}<>]+)\s*:\s*(.*)$")


def _parse_grammar(grammar):
    stages = []
    cur = None
    for raw in grammar.split("\n"):
        line = re.sub(r"(^|\s)#.*$", "", raw).strip()
        if not line:
            continue
        m = _LABEL_RE.match(line)
        rest = line
        if m and not raw[:1].isspace() or (m and cur is None):
            cur = ChunkStage(m.group(1))
            stages.append(cur)
            rest = m.group(2).strip()
        elif cur is None:
            raise ValueError("Illegal chunk grammar line: %r" % raw)
        if not rest:
            continue
        if rest.startswith("{") and rest.endswith("}"):
            cur.add("chunk", rest[1:-1])
        elif rest.startswith("}") and rest.endswith("{"):
            cur.add("chink", rest[1:-1])
        else:
            raise ValueError("Illegal chunk pattern: %r" % rest)
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label="S", loop=1):
        self._root_label = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)):
            for st in grammar:
                if not hasattr(st, "parse"):
                    raise TypeError("grammar stages must be chunk parsers")
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")

    def parse(self, chunk_struct):
        if isinstance(chunk_struct, str):
            raise TypeError("expected a list of tagged tokens")
        items = list(chunk_struct)
        if isinstance(chunk_struct, Tree):
            items = list(chunk_struct)
        tree = Tree(self._root_label, items)
        for _ in range(self._loop):
            for st in self._stages:
                tree = st.parse(tree, self._root_label) if isinstance(st, ChunkStage) else st.parse(tree)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    label = "NE" if binary else None
    out = []
    run = []

    def flush():
        if run:
            out.append(Tree(label or "NE", list(run)))
            run.clear()

    for tok in tagged_tokens:
        if tok[1] in ("NNP", "NNPS"):
            run.append(tok)
        else:
            flush()
            out.append(tok)
    flush()
    return Tree("S", out)


__all__ = ["RegexpParser", "ne_chunk"]
