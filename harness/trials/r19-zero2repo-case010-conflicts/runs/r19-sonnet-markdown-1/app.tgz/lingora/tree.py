"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, (str, bytes)):
            raise TypeError("children should be a list of children, not a string")
        if not isinstance(children, (list, tuple)):
            try:
                children = list(children)
            except TypeError:
                raise TypeError("children should be a list")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def height(self):
        h = 1
        for c in self:
            if isinstance(c, Tree):
                h = max(h, c.height() + 1)
            else:
                h = max(h, 2)
        return h if len(self) else 1

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat())
            elif isinstance(c, tuple):
                parts.append("/".join(str(x) for x in c))
            else:
                parts.append(str(c))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        out = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                out += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            elif isinstance(c, tuple):
                out += "\n" + " " * (indent + 2) + "/".join(str(x) for x in c)
            else:
                out += "\n" + " " * (indent + 2) + str(c)
        return out + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        tokre = re.compile(r"\%s|\%s|[^\s\%s\%s]+" % (open_b, close_b, open_b, close_b))
        toks = tokre.findall(s)
        pos = 0
        if not toks or toks[0] != open_b:
            raise ValueError("Tree.fromstring: expected %r" % open_b)

        def parse(i):
            # toks[i] == open_b
            i += 1
            label = ""
            if i < len(toks) and toks[i] not in (open_b, close_b):
                label = toks[i]
                i += 1
            kids = []
            while True:
                if i >= len(toks):
                    raise ValueError("Tree.fromstring: unbalanced brackets")
                t = toks[i]
                if t == close_b:
                    return cls(label, kids), i + 1
                if t == open_b:
                    sub, i = parse(i)
                    kids.append(sub)
                else:
                    kids.append(t)
                    i += 1

        tree, end = parse(0)
        if end != len(toks):
            raise ValueError("Tree.fromstring: unexpected text after tree")
        return tree
