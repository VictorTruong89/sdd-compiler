"""Punkt sentence boundary detection using packaged parameters."""
import os
import re
import string

from .. import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


class PunktLanguageVars:
    sent_end_chars = (".", "?", "!")
    internal_punctuation = ",:;"
    re_boundary_realignment = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
    _re_non_word_chars = r"(?:[)\";}\]\*:@\'\({\[])"
    _re_multi_char_punct = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
    _word_tokenize_fmt = r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )"""
    _re_word_start = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
    _period_context_fmt = r"""
        [.?!]
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))"""

    def __init__(self):
        self._word_re = re.compile(
            self._word_tokenize_fmt % {
                "NonWord": self._re_non_word_chars,
                "MultiChar": self._re_multi_char_punct,
                "WordStart": self._re_word_start,
            }, re.UNICODE | re.VERBOSE)
        self._period_re = re.compile(
            self._period_context_fmt % {"NonWord": self._re_non_word_chars},
            re.UNICODE | re.VERBOSE)

    def word_tokenize(self, s):
        return self._word_re.findall(s)


_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "type", "period_final", "abbr", "ellipsis", "sentbreak", "parastart", "linestart")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.abbr = False
        self.ellipsis = False
        self.sentbreak = False
        self.parastart = parastart
        self.linestart = linestart

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        if self.sentbreak:
            return self.type_no_period
        return self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


def _pair_iter(iterator):
    iterator = iter(iterator)
    try:
        prev = next(iterator)
    except StopIteration:
        return
    for el in iterator:
        yield prev, el
        prev = el
    yield prev, None


class PunktSentenceTokenizer:
    def __init__(self, params=None, lang_vars=None):
        self._params = params or PunktParameters()
        self._lang_vars = lang_vars or PunktLanguageVars()

    # -- tokenization
    def tokenize(self, text, realign_boundaries=True):
        return [text[s:e] for s, e in self.span_tokenize(text, realign_boundaries)]

    def span_tokenize(self, text, realign_boundaries=True):
        slices = list(self._slices_from_text(text))
        if realign_boundaries:
            slices = list(self._realign_boundaries(text, slices))
        for s in slices:
            yield s.start, s.stop

    def _slices_from_text(self, text):
        last_break = 0
        for match, context in self._match_potential_end_contexts(text):
            if self.text_contains_sentbreak(context):
                yield slice(last_break, match.end())
                if match.group("next_tok"):
                    last_break = match.start("next_tok")
                else:
                    last_break = match.end()
        yield slice(last_break, len(text.rstrip()))

    def _realign_boundaries(self, text, slices):
        realign = 0
        for s1, s2 in _pair_iter(slices):
            s1 = slice(s1.start + realign, s1.stop)
            if not s2:
                if text[s1]:
                    yield s1
                continue
            m = self._lang_vars.re_boundary_realignment.match(text[s2])
            if m:
                yield slice(s1.start, s2.start + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1]:
                    yield s1

    @staticmethod
    def _last_ws_index(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return None

    def _match_potential_end_contexts(self, text):
        previous_slice = slice(0, 0)
        previous_match = None
        for match in self._lang_vars._period_re.finditer(text):
            before_text = text[previous_slice.stop:match.start()]
            idx = self._last_ws_index(before_text)
            if idx:
                idx += previous_slice.stop + 1
            else:
                idx = previous_slice.start
            prev_word_slice = slice(idx, match.start())
            if previous_match and previous_slice.stop <= prev_word_slice.start:
                yield (previous_match,
                       text[previous_slice] + previous_match.group() + previous_match.group("after_tok"))
            previous_match = match
            previous_slice = prev_word_slice
        if previous_match:
            yield (previous_match,
                   text[previous_slice] + previous_match.group() + previous_match.group("after_tok"))

    def text_contains_sentbreak(self, text):
        found = False
        for tok in self._annotate_tokens(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                line_toks = iter(self._lang_vars.word_tokenize(line))
                try:
                    tok = next(line_toks)
                except StopIteration:
                    continue
                yield _Tok(tok, parastart=parastart, linestart=True)
                parastart = False
            else:
                parastart = True
                continue
            for tok in line_toks:
                yield _Tok(tok)

    def _annotate_tokens(self, tokens):
        toks = []
        for t in tokens:
            self._first_pass(t)
            toks.append(t)
        for t1, t2 in _pair_iter(toks):
            self._second_pass(t1, t2)
        return toks

    def _first_pass(self, t):
        tok = t.tok
        if tok in self._lang_vars.sent_end_chars:
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if (tok[:-1].lower() in self._params.abbrev_types
                    or tok[:-1].lower().split("-")[-1] in self._params.abbrev_types):
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho_heuristic(self, t):
        if t.tok in self._lang_vars.internal_punctuation:
            return False
        ctx = self._params.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if not t2:
            return
        if not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            r = self._ortho_heuristic(t2)
            if r is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            r = self._ortho_heuristic(t2)
            if r is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (r == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return


_cache = {}


def _read_lines(path):
    with open(path, encoding="utf-8") as f:
        return [l.rstrip("\r\n") for l in f.read().split("\n")] if False else f.read().splitlines()


def load_tokenizer(language="english"):
    if not isinstance(language, str) or not language or "/" in language or "\\" in language or language.startswith("."):
        raise ValueError("invalid language %r" % (language,))
    d = data.find("tokenizers/punkt_tab/%s" % language, want_dir=True)
    names = ["abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"]
    paths = [os.path.join(d, n) for n in names]
    for p in paths:
        if not os.path.isfile(p):
            raise LookupError("Punkt model file %s is missing" % p)
    key = (d, tuple(os.stat(p).st_mtime_ns for p in paths), tuple(os.stat(p).st_size for p in paths))
    if key in _cache:
        return _cache[key]
    params = PunktParameters()
    params.abbrev_types = {l.strip() for l in _read_lines(paths[0]) if l.strip()}
    params.sent_starters = {l.strip() for l in _read_lines(paths[1]) if l.strip()}
    for l in _read_lines(paths[2]):
        parts = l.split("\t")
        if len(parts) >= 2:
            params.collocations.add((parts[0], parts[1]))
    for l in _read_lines(paths[3]):
        parts = l.split("\t")
        if len(parts) >= 2:
            try:
                params.ortho_context[parts[0]] = int(parts[1])
            except ValueError:
                pass
    tok = PunktSentenceTokenizer(params)
    _cache.clear()
    _cache[key] = tok
    return tok
