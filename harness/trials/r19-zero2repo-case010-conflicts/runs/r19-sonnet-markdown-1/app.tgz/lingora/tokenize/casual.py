import html
import re

EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
URLS = r"""
    (?:
      (?:https?://|www\.)[^\s<>]+[^\s`!()\[\]{};:'".,<>?«»“”‘’]
      |
      (?<![@\w])[a-z0-9]+(?:[.\-][a-z0-9]+)*[.](?:com|org|net|edu|gov|io|co|uk|de|fr)\b(?:/[^\s<>]*[^\s`!()\[\]{};:'".,<>?«»“”‘’])?(?!@)
    )"""
PHONE = r"""(?:(?:\+?[01][ *\-.\)]*)?(?:[\(]?\d{3}[ *\-.\)]*)?\d{3}[ *\-.\)]*\d{4})"""
REGEXPS = (
    URLS,
    PHONE,
    EMOTICONS,
    r"(?:<[^>\s]+>)",
    r"(?:[\-]+>|<[\-]+)",
    r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"(?:\.(?:\s*\.){1,})",
    r"(?:\S)",
)
WORD_RE = re.compile("(%s)" % "|".join(REGEXPS), re.VERBOSE | re.I | re.UNICODE)
EMOTICON_RE = re.compile(EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
HANDLE_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))"
)
LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False, match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        text = html.unescape(text)
        if self.strip_handles:
            text = HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = LEN_RE.sub(r"\1\1\1", text)
        safe = HANG_RE.sub(r"\1\1\1", text)
        words = WORD_RE.findall(safe)
        if not self.preserve_case:
            words = [w if EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
