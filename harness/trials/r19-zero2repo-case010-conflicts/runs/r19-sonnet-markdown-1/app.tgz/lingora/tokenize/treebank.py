import re


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [
        re.compile(r"(?i)\b(can)(?#X)(not)\b"),
        re.compile(r"(?i)\b(d)(?#X)('ye)\b"),
        re.compile(r"(?i)\b(gim)(?#X)(me)\b"),
        re.compile(r"(?i)\b(gon)(?#X)(na)\b"),
        re.compile(r"(?i)\b(got)(?#X)(ta)\b"),
        re.compile(r"(?i)\b(lem)(?#X)(me)\b"),
        re.compile(r"(?i)\b(more)(?#X)('n)\b"),
        re.compile(r"(?i)\b(wan)(?#X)(na)(?=\s)"),
    ]
    CONTRACTIONS3 = [re.compile(r"(?i) ('t)(?#X)(is)\b"), re.compile(r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        raw = self.tokenize(text)
        pos = 0
        for tok in raw:
            if tok in ("``", "''"):
                cands = [c for c in ('"', tok) if text.find(c, pos) >= 0]
                idx = min((text.find(c, pos), c) for c in cands) if cands else None
                if idx is None:
                    raise ValueError("cannot align token %r" % tok)
                s, c = idx
                yield s, s + len(c)
                pos = s + len(c)
            else:
                s = text.find(tok, pos)
                if s < 0:
                    raise ValueError("cannot align token %r" % tok)
                yield s, s + len(tok)
                pos = s + len(tok)


class NLTKWordTokenizer(TreebankWordTokenizer):
    """Improved Penn Treebank tokenizer (the recommended word tokenizer)."""

    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒–—―]"), r" \g<0> "),
    ]
    CONTRACTIONS2 = TreebankWordTokenizer.CONTRACTIONS2[1:]
