"""Tokenizers."""
import re

from .simple import (  # noqa: F401
    RegexpTokenizer, WhitespaceTokenizer, WordPunctTokenizer, BlanklineTokenizer,
    blankline_tokenize, wordpunct_tokenize, regexp_span_tokenize,
)
from .treebank import TreebankWordTokenizer, NLTKWordTokenizer  # noqa: F401
from .casual import TweetTokenizer  # noqa: F401
from .punkt import PunktSentenceTokenizer  # noqa: F401
from . import punkt as _punkt

_word_tokenizer = NLTKWordTokenizer()


def sent_tokenize(text, language="english"):
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    tok = _punkt.load_tokenizer(language)
    return tok.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sentences for t in _word_tokenizer.tokenize(s)]
