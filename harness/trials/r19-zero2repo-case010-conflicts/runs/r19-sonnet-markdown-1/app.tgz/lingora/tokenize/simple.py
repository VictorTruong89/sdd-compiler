import re


def regexp_span_tokenize(text, regexp):
    left = 0
    for m in re.finditer(regexp, text):
        right, nxt = m.span()
        if right != 0 or left != 0 or True:
            yield left, right
        left = nxt
    yield left, len(text)


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        out = self._regexp.findall(text)
        if self._discard_empty:
            out = [t for t in out if t]
        return out

    def span_tokenize(self, text):
        if self._gaps:
            for l, r in regexp_span_tokenize(text, self._regexp):
                if not (self._discard_empty and l == r):
                    yield l, r
        else:
            for m in self._regexp.finditer(text):
                s, e = m.span()
                if not (self._discard_empty and s == e):
                    yield s, e

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            self.__class__.__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)
