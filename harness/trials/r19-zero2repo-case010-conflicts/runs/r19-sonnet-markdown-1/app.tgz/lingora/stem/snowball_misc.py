"""Finnish, Hungarian, Romanian, Arabic: compact suffix-stripping stemmers."""
from .snowball_base import r1r2, longest_suffix


def finnish(word):
    word = word.lower()
    v = "aeiouyäö"
    r1, r2 = r1r2(word, v)
    # particles
    s = longest_suffix(word, ("kaan", "kään", "kin", "han", "hän", "ko", "kö", "pa", "pä"))
    if s and len(word) - len(s) >= r1 and len(word) - len(s) > 0 and word[-len(s) - 1] in "nt" + v and (
            s in ("kin", "han", "hän", "ko", "kö", "pa", "pä")):
        word = word[:-len(s)]
    s = longest_suffix(word, ("sti", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi",
                              "ine", "nsa", "nsä", "mme", "tte", "den", "tta", "ttä", "na", "nä", "ta", "tä",
                              "ia", "iä", "ja", "jä", "ssa", "n", "a", "ä", "t", "i"))
    if s and len(word) - len(s) >= r1:
        word = word[:-len(s)]
    if len(word) > r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] in "kpt":
        word = word[:-1]
    if len(word) > r1 and word[-1] in "aeiouäö":
        word = word[:-1]
    if len(word) > r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in v:
        word = word[:-1]
    return word


def hungarian(word):
    word = word.lower()
    v = "aeiouyáéíóöőúüű"
    r1, _ = r1r2(word, v)
    r1 = max(1, min(r1, len(word)))
    for sufs in (("ként", "képp", "képpen", "kor", "ban", "ben", "nak", "nek", "val", "vel", "tól", "től",
                  "ról", "ről", "ból", "ből", "hoz", "hez", "höz", "ért", "ig", "ra", "re", "ba", "be",
                  "on", "en", "ön", "at", "et", "ot", "öt", "ak", "ek", "ok", "ök", "t", "k", "n")):
        s = longest_suffix(word, sufs)
        if s and len(word) - len(s) >= r1:
            word = word[:-len(s)]
    if word and word[-1] in "áé":
        word = word[:-1] + {"á": "a", "é": "e"}[word[-1]]
    return word


def romanian(word):
    word = word.lower()
    v = "aeiouăâî"
    r1, r2 = r1r2(word, v)
    for sufs in (
        ("abilitate", "abilitati", "abilități", "ibilitate", "ivitate", "ivitati", "icitate", "icitati",
         "ității", "itate", "itati", "iune", "iuni", "atoare", "ator", "atori", "ație", "ații", "ativ",
         "ativa", "icale", "icala", "ical", "iciti", "icive", "icativ"),
        ("ismele", "ismul", "ismul", "ista", "iste", "isti", "ism", "ică", "ice", "ici", "ic", "ului",
         "ilor", "elor", "ele", "ile", "ul", "ea", "ei", "ii", "le", "a", "e", "i", "ă"),
    ):
        s = longest_suffix(word, sufs)
        if s and len(word) - len(s) >= r2:
            word = word[:-len(s)]
    return word


def arabic(word):
    import re
    word = re.sub("[ً-ْـ]", "", word)
    word = re.sub("[إأآ]", "ا", word)
    for p in ("وال", "بال", "كال", "فال", "ال", "لل"):
        if word.startswith(p) and len(word) - len(p) >= 3:
            word = word[len(p):]
            break
    for s in ("ات", "ان", "ون", "ين", "ها", "هم", "كم", "نا", "ية", "ة", "ه", "ي"):
        if word.endswith(s) and len(word) - len(s) >= 3:
            word = word[:-len(s)]
            break
    return word
