import os

from .. import data
from . import snowball_english, snowball_germanic as ger, snowball_romance as rom, snowball_russian, snowball_misc as misc
from .porter import PorterStemmer


class SnowballStemmer:
    languages = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                 "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish")

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            path = data.find("corpora/stopwords/%s" % language, want_dir=False)
            with open(path, encoding="utf-8") as f:
                self.stopwords = {l.strip() for l in f.read().splitlines() if l.strip()}
        if language == "porter":
            self._porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
            self._fn = lambda w: self._porter.stem(w)
        else:
            self._fn = {
                "english": snowball_english.stem, "german": ger.german, "dutch": ger.dutch,
                "swedish": ger.swedish, "danish": ger.danish, "norwegian": ger.norwegian,
                "spanish": rom.spanish, "french": rom.french, "italian": rom.italian,
                "portuguese": rom.portuguese, "russian": snowball_russian.stem,
                "finnish": misc.finnish, "hungarian": misc.hungarian, "romanian": misc.romanian,
                "arabic": misc.arabic,
            }[language]

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        if not word:
            return word
        return self._fn(word)
