from .snowball_base import r1r2

VOWELS = "aeiouy"
DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
LI_END = "cdeghkmnrt"
S0 = ("'s'", "'s", "'")
S1A = ("sses", "ied", "ies", "us", "ss", "s")
S1B = ("eedly", "ingly", "edly", "eed", "ing", "ed")
S2 = ("ization", "ational", "fulness", "ousness", "iveness", "tional", "biliti", "lessli", "entli", "ation",
      "alism", "aliti", "ousli", "iviti", "fulli", "enci", "anci", "abli", "izer", "ator", "alli", "bli",
      "ogi", "li")
S3 = ("ational", "tional", "alize", "icate", "iciti", "ative", "ical", "ness", "ful")
S4 = ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti", "ous", "ive", "ize",
      "ion", "al", "er", "ic")
SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
           "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
           "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
           "bias": "bias", "andes": "andes"}
S1A_EXC = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def _short_syllable_end(w):
    if len(w) >= 3 and w[-1] not in VOWELS and w[-1] not in "wxY" and w[-2] in VOWELS and w[-3] not in VOWELS:
        return True
    if len(w) == 2 and w[0] in VOWELS and w[1] not in VOWELS:
        return True
    return False


def stem(word):
    word = word.lower()
    if len(word) <= 2:
        return word
    if word in SPECIAL:
        return SPECIAL[word]
    word = word.replace("’", "'").replace("‘", "'").replace("‛", "'")
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    for i in range(1, len(word)):
        if word[i - 1] in VOWELS and word[i] == "y":
            word = word[:i] + "Y" + word[i + 1:]
    if word.startswith(("gener", "arsen")):
        r1 = 5
        r2 = len(word)
        for i in range(r1 + 1, len(word)):
            if word[i] not in VOWELS and word[i - 1] in VOWELS:
                r2 = i + 1
                break
    elif word.startswith("commun"):
        r1 = 6
        r2 = len(word)
        for i in range(r1 + 1, len(word)):
            if word[i] not in VOWELS and word[i - 1] in VOWELS:
                r2 = i + 1
                break
    else:
        r1, r2 = r1r2(word, VOWELS)

    def in_r1(suf):
        return len(word) - len(suf) >= r1

    def in_r2(suf):
        return len(word) - len(suf) >= r2

    # step 0
    for suf in S0:
        if word.endswith(suf):
            word = word[:-len(suf)]
            break
    # step 1a
    for suf in S1A:
        if word.endswith(suf):
            if suf == "sses":
                word = word[:-2]
            elif suf in ("ied", "ies"):
                if len(word) - len(suf) > 1:
                    word = word[:-2]
                else:
                    word = word[:-1]
            elif suf == "s":
                if any(c in VOWELS for c in word[:-2]):
                    word = word[:-1]
            break
    if word in ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"):
        return word.replace("Y", "y")
    # step 1b
    for suf in S1B:
        if word.endswith(suf):
            if suf in ("eed", "eedly"):
                if in_r1(suf):
                    word = word[:-len(suf)] + "ee"
            else:
                if any(c in VOWELS for c in word[:-len(suf)]):
                    word = word[:-len(suf)]
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif word.endswith(DOUBLES):
                        word = word[:-1]
                    elif r1 >= len(word) and _short_syllable_end(word):
                        word += "e"
            break
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in VOWELS:
        word = word[:-1] + "i"
    # step 2
    for suf in S2:
        if word.endswith(suf):
            if in_r1(suf):
                if suf == "tional":
                    word = word[:-2]
                elif suf in ("enci", "anci", "abli"):
                    word = word[:-1] + "e"
                elif suf == "entli":
                    word = word[:-2]
                elif suf == "izer":
                    word = word[:-1]
                elif suf == "ization":
                    word = word[:-5] + "e"
                elif suf in ("ational", "ation", "ator"):
                    word = word[:-len(suf)] + "ate"
                elif suf in ("alism", "aliti", "alli"):
                    word = word[:-len(suf)] + "al"
                elif suf == "fulness":
                    word = word[:-4]
                elif suf in ("ousli", "ousness"):
                    word = word[:-len(suf)] + "ous"
                elif suf in ("iveness", "iviti"):
                    word = word[:-len(suf)] + "ive"
                elif suf in ("biliti", "bli"):
                    word = word[:-len(suf)] + "ble"
                elif suf == "ogi":
                    if len(word) >= 4 and word[-4] == "l":
                        word = word[:-1]
                elif suf in ("fulli", "lessli"):
                    word = word[:-2]
                elif suf == "li":
                    if len(word) >= 3 and word[-3] in LI_END:
                        word = word[:-2]
            break
    # step 3
    for suf in S3:
        if word.endswith(suf):
            if in_r1(suf):
                if suf == "tional":
                    word = word[:-2]
                elif suf == "ational":
                    word = word[:-len(suf)] + "ate"
                elif suf == "alize":
                    word = word[:-3]
                elif suf in ("icate", "iciti", "ical"):
                    word = word[:-len(suf)] + "ic"
                elif suf in ("ful", "ness"):
                    word = word[:-len(suf)]
                elif suf == "ative":
                    if in_r2(suf):
                        word = word[:-5]
            break
    # step 4
    for suf in S4:
        if word.endswith(suf):
            if in_r2(suf):
                if suf == "ion":
                    if len(word) >= 4 and word[-4] in "st":
                        word = word[:-3]
                else:
                    word = word[:-len(suf)]
            break
    # step 5
    if word.endswith("e"):
        if in_r2("e") or (in_r1("e") and not _short_syllable_end(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if in_r2("l") and word[-2:-1] == "l":
            word = word[:-1]
    return word.replace("Y", "y")
