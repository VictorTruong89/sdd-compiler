"""Spanish, French, Italian, Portuguese, Romanian Snowball stemmers."""
from .snowball_base import r1r2, longest_suffix, rv_spanish

# ------------------------------------------------------------------ Spanish
ES_V = "aeiouáéíóúü"


def _strip_acc_es(w):
    return w.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")


def spanish(word):
    word = word.lower()
    r1, r2 = r1r2(word, ES_V)
    rv = rv_spanish(word, ES_V)

    def ends(sufs, region):
        s = longest_suffix(word, sufs)
        if s is None:
            return None
        return s if len(word) - len(s) >= region else None

    # step 0
    s = longest_suffix(word, ("selas", "selos", "sela", "selo", "las", "les", "los", "nos", "me", "se", "la",
                              "le", "lo"))
    if s and len(word) - len(s) >= rv:
        pre = word[:-len(s)]
        for ac, rep in (("iéndo", "iendo"), ("ándo", "ando"), ("ár", "ar"), ("ér", "er"), ("ír", "ir")):
            if pre.endswith(ac) and len(pre) - len(ac) >= rv - 0:
                word = pre[:-len(ac)] + rep
                break
        else:
            for pf in ("iendo", "ando", "ar", "er", "ir"):
                if pre.endswith(pf) and len(pre) - len(pf) >= rv:
                    word = pre
                    break
            else:
                if pre.endswith("uyendo") and len(pre) - 6 >= 0 and len(pre) - 5 >= rv:
                    word = pre
    step1 = ("anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables", "able", "ibles", "ible",
             "istas", "ista", "osos", "osas", "oso", "osa", "amientos", "amiento", "imientos", "imiento",
             "adoras", "adores", "adora", "ador", "aciones", "ación", "antes", "ante", "ancias", "ancia",
             "logías", "logía", "uciones", "ución", "encias", "encia", "amente", "mente", "idades", "idad",
             "ivas", "ivos", "iva", "ivo")
    s = longest_suffix(word, step1)
    done = False
    if s:
        start = len(word) - len(s)
        if s in ("amente",):
            if start >= r1:
                word = word[:start]
                done = True
                for suf in ("iv",):
                    if word.endswith(suf) and len(word) - 2 >= r2:
                        word = word[:-2]
                        if word.endswith("at") and len(word) - 2 >= r2:
                            word = word[:-2]
                        break
                else:
                    for suf in ("os", "ic", "ad"):
                        if word.endswith(suf) and len(word) - 2 >= r2:
                            word = word[:-2]
                            break
        elif start >= r2:
            done = True
            word = word[:start]
            if s in ("logías", "logía"):
                word += "log"
            elif s in ("uciones", "ución"):
                word += "u"
            elif s in ("encias", "encia"):
                word += "ente"
            elif s == "mente":
                for suf in ("ante", "able", "ible"):
                    if word.endswith(suf) and len(word) - 4 >= r2:
                        word = word[:-4]
                        break
            elif s in ("idades", "idad"):
                for suf in ("abil", "ic", "iv"):
                    if word.endswith(suf) and len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                        break
            elif s in ("ivas", "ivos", "iva", "ivo"):
                if word.endswith("at") and len(word) - 2 >= r2:
                    word = word[:-2]
            elif s in ("adoras", "adores", "adora", "ador", "aciones", "ación", "antes", "ante", "ancias", "ancia"):
                if word.endswith("ic") and len(word) - 2 >= r2:
                    word = word[:-2]
    if not done:
        s = longest_suffix(word, ("yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes", "ya", "ye", "yo", "yó"))
        if s and len(word) - len(s) >= rv and word[:-len(s)].endswith("u"):
            word = word[:-len(s)]
            done = True
        if not done:
            s = longest_suffix(word, (
                "arían", "arías", "arán", "arás", "aríais", "aría", "aréis", "aríamos", "aremos", "ará", "aré",
                "erían", "erías", "erán", "erás", "eríais", "ería", "eréis", "eríamos", "eremos", "erá", "eré",
                "irían", "irías", "irán", "irás", "iríais", "iría", "iréis", "iríamos", "iremos", "irá", "iré",
                "aba", "ada", "ida", "ía", "ara", "iera", "ad", "ed", "id", "ase", "iese", "aste", "iste", "an",
                "aban", "aran", "ieran", "asen", "iesen", "aron", "ieron", "ado", "ido", "ando", "iendo", "ió",
                "ar", "er", "ir", "as", "abas", "adas", "idas", "ías", "aras", "ieras", "ases", "ieses", "ís",
                "áis", "abais", "íais", "arais", "ierais", "aseis", "ieseis", "asteis", "isteis", "ados", "idos",
                "amos", "ábamos", "íamos", "imos", "áramos", "iéramos", "iésemos", "ásemos"))
            en = longest_suffix(word, ("en", "es", "éis", "emos"))
            if en and (not s or len(en) >= len(s)) and len(word) - len(en) >= rv:
                word = word[:-len(en)]
                if word.endswith("gu") and len(word) - 1 >= rv:
                    word = word[:-1]
            elif s and len(word) - len(s) >= rv:
                word = word[:-len(s)]
    # step 3
    s = longest_suffix(word, ("os", "a", "o", "á", "í", "ó"))
    if s and len(word) - len(s) >= rv:
        word = word[:-len(s)]
    else:
        s = longest_suffix(word, ("e", "é"))
        if s and len(word) - 1 >= rv:
            word = word[:-1]
            if word.endswith("gu") and len(word) - 1 >= rv:
                word = word[:-1]
    return _strip_acc_es(word)


# ------------------------------------------------------------------ French
FR_V = "aeiouyâàëéêèïîôûù"


def _fr_rv(word):
    n = len(word)
    if n >= 2 and word[0] in FR_V and word[1] in FR_V:
        return 3
    for i in range(1, n):
        if word[i] in FR_V:
            return i + 1
    return n


def french(word):
    word = word.lower()
    w = list(word)
    for i in range(len(w)):
        if w[i] in FR_V:
            prev = w[i - 1] if i > 0 else ""
            nxt = w[i + 1] if i + 1 < len(w) else ""
            if w[i] == "u":
                if prev in FR_V and nxt in FR_V and prev and nxt:
                    w[i] = "U"
                elif prev == "q":
                    w[i] = "U"
            elif w[i] == "i":
                if prev in FR_V and nxt in FR_V and prev and nxt:
                    w[i] = "I"
            elif w[i] == "y":
                if (prev and prev in FR_V) or (nxt and nxt in FR_V):
                    w[i] = "Y"
        if w[i] == "ë" or w[i] == "ï":
            w[i] = "H"
    # y handled; e between vowels with ë markers omitted
    word = "".join(w)
    word = word.replace("H", "ë") if False else word
    vow = FR_V
    r1, r2 = r1r2(word, vow)
    if word.startswith(("par", "col", "tap")):
        r1 = 3
        r2 = len(word)
        for i in range(r1 + 1, len(word)):
            if word[i] not in vow and word[i - 1] in vow:
                r2 = i + 1
                break
    rv = _fr_rv(word) if not word.startswith(("par", "col", "tap")) else 3
    if word[:2] and len(word) >= 3 and word[0] in vow and word[1] in vow:
        rv = 3
    orig = word

    def in_(pos, s):
        return len(word) - len(s) >= pos

    modified = False
    # step 1
    s1 = ("issements", "issement", "atrices", "atrice", "ateurs", "ations", "logies", "usions", "utions",
          "ements", "amment", "emment", "ances", "iqUes", "ismes", "ables", "istes", "ateur", "ation", "logie",
          "usion", "ution", "ences", "ement", "euses", "ments", "ance", "ique", "isme", "able", "iste", "ence",
          "ités", "ives", "eaux", "euse", "ment", "ifs", "ive", "eux", "aux", "ité", "if")
    s1 = tuple(s.replace("iqUes", "iques") for s in s1)
    s = longest_suffix(word, s1 + ("iques",))
    step1_done = False
    if s:
        start = len(word) - len(s)
        if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iques", "ique", "ismes", "ables", "istes"):
            if start >= r2:
                word = word[:start]
                step1_done = modified = True
        elif s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
            if start >= r2:
                word = word[:start]
                step1_done = modified = True
                if word.endswith("ic"):
                    if len(word) - 2 >= r2:
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
        elif s in ("logie", "logies"):
            if start >= r2:
                word = word[:start] + "log"
                step1_done = modified = True
        elif s in ("usion", "ution", "usions", "utions"):
            if start >= r2:
                word = word[:start] + "u"
                step1_done = modified = True
        elif s in ("ence", "ences"):
            if start >= r2:
                word = word[:start] + "ent"
                step1_done = modified = True
        elif s in ("ement", "ements"):
            if start >= rv:
                word = word[:start]
                step1_done = modified = True
                for suf in ("eus", "ativ", "iv", "abl", "iqU", "ic", "ous"):
                    pass
                if word.endswith("iv") and len(word) - 2 >= r2:
                    word = word[:-2]
                    if word.endswith("at") and len(word) - 2 >= r2:
                        word = word[:-2]
                elif word.endswith("eus"):
                    if len(word) - 3 >= r2:
                        word = word[:-3]
                    elif len(word) - 3 >= r1:
                        word = word[:-3] + "eux"
                elif word.endswith(("abl", "iqU")) and len(word) - 3 >= r2:
                    word = word[:-3]
                elif word.endswith(("ièr", "Ièr")) and len(word) - 3 >= rv:
                    word = word[:-3] + "i"
        elif s in ("ité", "ités"):
            if start >= r2:
                word = word[:start]
                step1_done = modified = True
                if word.endswith("abil"):
                    if len(word) - 4 >= r2:
                        word = word[:-4]
                    else:
                        word = word[:-2] + "l"
                elif word.endswith("ic"):
                    if len(word) - 2 >= r2:
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
                elif word.endswith("iv") and len(word) - 2 >= r2:
                    word = word[:-2]
        elif s in ("if", "ive", "ifs", "ives"):
            if start >= r2:
                word = word[:start]
                step1_done = modified = True
                if word.endswith("at") and len(word) - 2 >= r2:
                    word = word[:-2]
                    if word.endswith("ic"):
                        if len(word) - 2 >= r2:
                            word = word[:-2]
                        else:
                            word = word[:-2] + "iqU"
        elif s in ("eaux",):
            if start >= r2 or True:
                word = word[:start] + "eau"
                step1_done = modified = True
        elif s in ("aux",):
            if start >= r1:
                word = word[:start] + "al"
                step1_done = modified = True
        elif s in ("euse", "euses"):
            if start >= r2:
                word = word[:start]
                step1_done = modified = True
            elif start >= r1:
                word = word[:start] + "eux"
                step1_done = modified = True
        elif s in ("issement", "issements"):
            if start >= r1 and start > 0 and word[start - 1] not in FR_V:
                word = word[:start]
                step1_done = modified = True
        elif s in ("amment",):
            if start >= rv:
                word = word[:start] + "ant"
                step1_done = modified = True
                word_after_amment = True
        elif s in ("emment",):
            if start >= rv:
                word = word[:start] + "ent"
                step1_done = modified = True
        elif s in ("ment", "ments"):
            if start >= rv and start > 0 and word[start - 1] in FR_V:
                word = word[:start]
                step1_done = modified = True
    # step 2a
    if not step1_done or s in ("amment", "emment", "ment", "ments"):
        s2 = longest_suffix(word, (
            "issantes", "issante", "issants", "issions", "issante", "issent", "issais", "issait", "issant",
            "issiez", "issons", "irions", "iraIent", "irais", "irait", "irent", "iriez", "irons", "iront",
            "issez", "isses", "îmes", "îtes", "irai", "iras", "irez", "isse", "ies", "ira", "ie", "ir", "is",
            "it", "i", "îtes"))
        if s2 and len(word) - len(s2) >= rv and len(word) - len(s2) > 0 and word[len(word) - len(s2) - 1] not in FR_V:
            word = word[:-len(s2)]
            modified = True
            step2a = True
        else:
            step2a = False
        if not step2a:
            s3 = longest_suffix(word, (
                "eraIent", "assions", "erions", "èrent", "assent", "assiez", "erais", "erait", "eriez", "erons",
                "eront", "aIent", "antes", "asses", "ions", "erai", "eras", "erez", "âmes", "âtes", "ante",
                "ants", "asse", "ées", "era", "iez", "ais", "ait", "ant", "ée", "és", "er", "ez", "ât", "ai",
                "as", "é", "a"))
            if s3:
                start = len(word) - len(s3)
                if s3 == "ions":
                    if start >= r2:
                        word = word[:start]
                        modified = True
                elif start >= rv:
                    word = word[:start]
                    modified = True
                    if s3 in ("âmes", "âtes", "ât", "assions", "assent", "assiez", "asses", "asse") or s3.startswith("a") and False:
                        pass
                    if word.endswith("e") and s3.startswith(("â", "ass", "a", "ai", "as")) and len(s3) >= 2:
                        if len(word) - 1 >= rv:
                            word = word[:-1]
    if modified:
        # step 3
        if word.endswith("Y"):
            word = word[:-1] + "i"
        if word.endswith("ç"):
            word = word[:-1] + "c"
    else:
        # step 4
        if len(word) >= 2 and word[-1] == "s" and word[-2] not in "aiouès":
            word = word[:-1]
        s4 = longest_suffix(word, ("ion", "ier", "ière", "Ier", "Ière", "e", "ë"))
        if s4:
            start = len(word) - len(s4)
            if s4 == "ion":
                if start >= r2 and start > 0 and word[start - 1] in "st" and start >= rv:
                    word = word[:start]
            elif s4 in ("ier", "ière", "Ier", "Ière"):
                if start >= rv:
                    word = word[:start] + "i"
            elif s4 in ("e",):
                if start >= rv:
                    word = word[:start]
            elif s4 == "ë":
                if word.endswith("guë") and start >= rv:
                    word = word[:start]
    # step 5
    if word.endswith(("enn", "onn", "ett", "ell", "eill")):
        word = word[:-1]
    # step 6
    for i in range(len(word) - 1, -1, -1):
        if word[i] in "éè":
            if i == len(word) - 1 or all(c not in FR_V for c in word[i + 1:]):
                word = word[:i] + "e" + word[i + 1:]
            break
        if word[i] in FR_V:
            break
    return word.replace("I", "i").replace("U", "u").replace("Y", "y")


# ------------------------------------------------------------------ Italian
IT_V = "aeiouàèìòù"


def italian(word):
    word = word.lower()
    for a, b in zip("áéíóú", "àèìòù"):
        word = word.replace(a, b)
    word = word.replace("qu", "qU")
    w = list(word)
    for i in range(1, len(w) - 1):
        if w[i - 1] in IT_V and w[i + 1] in IT_V:
            if w[i] == "u":
                w[i] = "U"
            elif w[i] == "i":
                w[i] = "I"
    word = "".join(w)
    r1, r2 = r1r2(word, IT_V)
    rv = rv_spanish(word, IT_V)
    # attached pronouns
    s = longest_suffix(word, ("glielo", "gliela", "gliele", "glieli", "gliene", "sene", "mela", "melo", "mele",
                              "meli", "mene", "tela", "telo", "tele", "teli", "tene", "cela", "celo", "cele",
                              "celi", "cene", "vela", "velo", "vele", "veli", "vene", "gli", "ci", "la", "le",
                              "li", "lo", "mi", "ne", "si", "ti", "vi"))
    if s and len(word) - len(s) >= rv:
        pre = word[:-len(s)]
        if pre.endswith(("ando", "endo")):
            word = pre
        elif pre.endswith(("ar", "er", "ir")):
            word = pre + "e"
    orig = word
    step1 = ("atrici", "atrice", "abilità", "icità", "ivamente", "amente", "azione", "azioni", "amento",
             "amenti", "imento", "imenti", "atori", "atore", "anza", "anze", "iche", "ichi", "ismo", "ismi",
             "abile", "abili", "ibile", "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso", "osi",
             "osa", "ose", "mente", "logia", "logie", "uzione", "uzioni", "usione", "usioni", "enza", "enze",
             "ico", "ici", "ica", "ice", "ivo", "ivi", "iva", "ive", "ità", "ante", "anti", "ità")
    s = longest_suffix(word, step1)
    if s:
        st = len(word) - len(s)
        if s in ("amente",):
            if st >= r1:
                word = word[:st]
                for suf in ("iv", "os", "ic", "abil"):
                    if word.endswith(suf) and len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                        if suf == "iv" and word.endswith("at") and len(word) - 2 >= r2:
                            word = word[:-2]
                        break
        elif st >= r2:
            if s in ("logia", "logie"):
                word = word[:st] + "log"
            elif s in ("uzione", "uzioni", "usione", "usioni"):
                word = word[:st] + "u"
            elif s in ("enza", "enze"):
                word = word[:st] + "ente"
            elif s in ("ità", "icità", "abilità"):
                word = word[:st]
                for suf in ("abil", "ic", "iv"):
                    if word.endswith(suf) and len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                        break
            elif s in ("ivo", "ivi", "iva", "ive"):
                word = word[:st]
                if word.endswith("at") and len(word) - 2 >= r2:
                    word = word[:-2]
                    if word.endswith("ic") and len(word) - 2 >= r2:
                        word = word[:-2]
            else:
                word = word[:st]
    if word == orig:
        s = longest_suffix(word, (
            "erebbero", "irebbero", "assero", "assimo", "eranno", "erebbe", "eremmo", "ereste", "eresti",
            "essero", "iranno", "irebbe", "iremmo", "ireste", "iresti", "iscano", "iscono", "issero", "arono",
            "avamo", "avano", "avate", "eremo", "erete", "erono", "evamo", "evano", "evate", "iremo", "irete",
            "irono", "ivamo", "ivano", "ivate", "ammo", "ando", "asse", "assi", "emmo", "enda", "ende", "endi",
            "endo", "erai", "erei", "Yamo", "iamo", "immo", "irai", "irei", "isca", "isce", "isci", "isco",
            "ano", "are", "ata", "ate", "ati", "ato", "ava", "avi", "avo", "erà", "ere", "erò", "ete", "eva",
            "evi", "evo", "irà", "ire", "irò", "ita", "ite", "iti", "ito", "iva", "ivi", "ivo", "ono", "uta",
            "ute", "uti", "uto", "ar", "ir"))
        if s and len(word) - len(s) >= rv:
            word = word[:-len(s)]
    # vowel
    if word and word[-1] in "aeioàèìò" and len(word) - 1 >= rv:
        word = word[:-1]
        if word.endswith("i") and len(word) - 1 >= rv:
            word = word[:-1]
    elif word.endswith("i") and len(word) - 1 >= rv:
        word = word[:-1]
    if word.endswith(("ch", "gh")) and False:
        pass
    return word.replace("I", "i").replace("U", "u")


# ------------------------------------------------------------------ Portuguese
PT_V = "aeiouáéíóúâêôà"


def portuguese(word):
    word = word.lower()
    word = word.replace("ã", "a~").replace("õ", "o~")
    r1, r2 = r1r2(word, PT_V + "~")
    rv = rv_spanish(word, PT_V)
    orig = word
    step1 = ("amentos", "imentos", "amento", "imento", "adoras", "adores", "aço~es", "logias", "ências",
             "amente", "idades", "anças", "ismos", "istas", "adora", "aça~o", "antes", "ância", "logia",
             "ução", "ências", "ência", "mente", "idade", "ança", "ezas", "icos", "icas", "ismo", "ável",
             "ível", "ista", "osos", "osas", "ador", "ante", "eza", "ico", "ica", "oso", "osa", "iva", "ivo",
             "ivas", "ivos", "uço~es", "uça~o")
    s = longest_suffix(word, step1)
    if s:
        st = len(word) - len(s)
        if s == "amente":
            if st >= r1:
                word = word[:st]
                for suf in ("iv", "os", "ic", "ad"):
                    if word.endswith(suf) and len(word) - 2 >= r2:
                        word = word[:-2]
                        if suf == "iv" and word.endswith("at") and len(word) - 2 >= r2:
                            word = word[:-2]
                        break
        elif st >= r2:
            if s in ("logia", "logias"):
                word = word[:st] + "log"
            elif s in ("uça~o", "uço~es"):
                word = word[:st] + "u"
            elif s in ("ência", "ências"):
                word = word[:st] + "ente"
            elif s == "mente":
                word = word[:st]
                for suf in ("ante", "avel", "ível", "ivel"):
                    if word.endswith(suf) and len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                        break
            elif s in ("idade", "idades"):
                word = word[:st]
                for suf in ("abil", "ic", "iv"):
                    if word.endswith(suf) and len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                        break
            elif s in ("iva", "ivo", "ivas", "ivos"):
                word = word[:st]
                if word.endswith("at") and len(word) - 2 >= r2:
                    word = word[:-2]
            else:
                word = word[:st]
        elif s in ("ira", "ir"):
            pass
    if word == orig:
        s = longest_suffix(word, (
            "aríamos", "eríamos", "iríamos", "ássemos", "êssemos", "íssemos", "aríeis", "eríeis", "iríeis",
            "ásseis", "ésseis", "ísseis", "áramos", "éramos", "íramos", "ávamos", "aremos", "eremos", "iremos",
            "ariam", "eriam", "iriam", "assem", "essem", "issem", "ara~o", "era~o", "ira~o", "arias", "erias",
            "irias", "ardes", "erdes", "irdes", "asses", "esses", "isses", "astes", "estes", "istes", "áreis",
            "areis", "éreis", "ereis", "íreis", "ireis", "ávei", "ásseis", "aria", "eria", "iria", "aram",
            "eram", "iram", "avam", "arem", "erem", "irem", "asse", "esse", "isse", "aste", "este", "iste",
            "amos", "radas", "ando", "endo", "indo", "ar", "er", "ir", "as", "ou", "ei", "es", "ia", "ido",
            "ado", "ada", "ida", "ara", "era", "ira", "ava", "am", "em", "iam", "ia", "i", "o", "ia"))
        if s and len(word) - len(s) >= rv:
            word = word[:-len(s)]
            if s == "es" and False:
                pass
    # residual suffix
    s = longest_suffix(word, ("os", "a", "i", "o", "á", "í", "ó"))
    if s and len(word) - len(s) >= rv:
        word = word[:-len(s)]
    else:
        # step 5
        if word.endswith(("e", "é", "ê")) and len(word) - 1 >= rv:
            word = word[:-1]
            if word.endswith(("gu", "ci")) and len(word) - 1 >= rv:
                word = word[:-1]
        elif word.endswith("ç"):
            word = word[:-1] + "c"
    return word.replace("a~", "ã").replace("o~", "õ")
