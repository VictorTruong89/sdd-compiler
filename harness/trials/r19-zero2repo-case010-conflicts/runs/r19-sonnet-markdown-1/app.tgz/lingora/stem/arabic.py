"""Light Arabic stemmers (ARLSTem, ARLSTem2)."""
import re

_DIAC = re.compile("[ً-ْـ]")
_PREFIXES = ["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل"]
_SUFFIXES = ["ات", "ان", "ون", "ين", "ها", "هم", "كم", "نا", "تي", "ية", "ة", "ه", "ي", "ا", "ن", "ت"]


def _normalize(w):
    w = _DIAC.sub("", w)
    return re.sub("[إأآا]", "ا", w)


class ARLSTem:
    def stem(self, word):
        w = _normalize(word)
        for p in _PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in _SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[: -len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    def stem(self, word):
        return ARLSTem.stem(self, word)
