"""German, Dutch, Swedish, Danish, Norwegian Snowball stemmers."""
from .snowball_base import r1r2, longest_suffix


# ------------------------------------------------------------------ German
G_V = "aeiouyäöü"
G_S_END = "bdfghklmnrt"
G_ST_END = "bdfghklmnt"


def german(word):
    word = word.lower().replace("ß", "ss")
    w = list(word)
    for i in range(1, len(w) - 1):
        if w[i - 1] in G_V and w[i + 1] in G_V:
            if w[i] == "u":
                w[i] = "U"
            elif w[i] == "y":
                w[i] = "Y"
    word = "".join(w)
    r1, r2 = r1r2(word, G_V)
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    r1 = min(r1, len(word))
    r2 = max(r2, r1)

    def in_r1(s):
        return len(word) - len(s) >= r1

    def in_r2(s):
        return len(word) - len(s) >= r2

    s = longest_suffix(word, ("ern", "em", "er", "en", "es", "e", "s"))
    if s and in_r1(s):
        if s == "s":
            if len(word) >= 2 and word[-2] in G_S_END:
                word = word[:-1]
        else:
            word = word[:-len(s)]
            if s in ("en", "es", "e") and word.endswith("niss"):
                word = word[:-1]
    s = longest_suffix(word, ("est", "en", "er", "st"))
    if s and in_r1(s):
        if s == "st":
            if len(word) >= 6 and word[-3] in G_ST_END:
                word = word[:-2]
        else:
            word = word[:-len(s)]
    s = longest_suffix(word, ("isch", "lich", "heit", "keit", "end", "ung", "ig", "ik"))
    if s and in_r2(s):
        if s in ("end", "ung"):
            word = word[:-len(s)]
            if word.endswith("ig") and in_r2("ig") and not word.endswith("eig"):
                word = word[:-2]
        elif s in ("ig", "ik", "isch"):
            if not word[:-len(s)].endswith("e"):
                word = word[:-len(s)]
        elif s in ("lich", "heit"):
            word = word[:-len(s)]
            t = longest_suffix(word, ("er", "en"))
            if t and in_r1(t):
                word = word[:-2]
        elif s == "keit":
            word = word[:-4]
            t = longest_suffix(word, ("lich", "ig"))
            if t and in_r2(t):
                word = word[:-len(t)]
    return (word.replace("ä", "a").replace("ö", "o").replace("ü", "u")
            .replace("U", "u").replace("Y", "y"))


# ------------------------------------------------------------------ Dutch
D_V = "aeiouyè"


def _undouble(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


def dutch(word):
    word = word.lower()
    for a, b in zip("äëïöüáéíóú", "aeiouaeiou"):
        word = word.replace(a, b)
    if not word:
        return word
    if word.startswith("y"):
        word = "Y" + word[1:]
    w = list(word)
    for i in range(1, len(w)):
        if w[i - 1] in D_V and w[i] == "y":
            w[i] = "Y"
    for i in range(1, len(w) - 1):
        if w[i - 1] in D_V and w[i] == "i" and w[i + 1] in D_V:
            w[i] = "I"
    word = "".join(w)
    r1, r2 = r1r2(word, D_V)
    r1 = min(max(r1, 3), len(word))
    r2 = max(r2, r1)

    def in_r1(s):
        return len(word) - len(s) >= r1

    def in_r2(s):
        return len(word) - len(s) >= r2

    # step 1
    s = longest_suffix(word, ("heden", "ene", "en", "se", "s"))
    if s and in_r1(s):
        if s == "heden":
            word = word[:-5] + "heid"
        elif s in ("ene", "en"):
            pre = word[:-len(s)]
            if pre and pre[-1] not in D_V and not pre.endswith("gem"):
                word = _undouble(pre)
        elif s in ("se", "s"):
            pre = word[:-len(s)]
            if pre and pre[-1] not in D_V and pre[-1] != "j":
                word = pre
    # step 2
    step2 = False
    if word.endswith("e") and in_r1("e") and len(word) >= 2 and word[-2] not in D_V:
        word = _undouble(word[:-1])
        step2 = True
    # step 3a
    if word.endswith("heid") and in_r2("heid") and not word.endswith("cheid"):
        word = word[:-4]
        if word.endswith("en") and in_r1("en") and len(word) >= 3 and word[-3] not in D_V and not word[:-2].endswith("gem"):
            word = _undouble(word[:-2])
    # step 3b
    s = longest_suffix(word, ("baar", "lijk", "bar", "end", "ing", "ig"))
    if s and in_r2(s):
        if s in ("end", "ing"):
            word = word[:-3]
            if word.endswith("ig") and in_r2("ig") and not word.endswith("eig"):
                word = word[:-2]
            else:
                word = _undouble(word)
        elif s == "ig":
            if not word.endswith("eig"):
                word = word[:-2]
        elif s == "lijk":
            word = word[:-4]
            if word.endswith("e") and in_r1("e") and len(word) >= 2 and word[-2] not in D_V:
                word = _undouble(word[:-1])
        elif s == "baar":
            word = word[:-4]
        elif s == "bar" and step2:
            word = word[:-3]
    # step 4
    if (len(word) >= 4 and word[-1] not in D_V and word[-1] != "I"
            and word[-3] == word[-2] and word[-3] in "aeou" and word[-4] not in D_V):
        word = word[:-2] + word[-1]
    return word.replace("I", "i").replace("Y", "y")


# ------------------------------------------------------------------ Swedish
SV_V = "aeiouyäåö"
SV_S_END = "bcdfghjklmnoprtvy"


def _min3(word, vowels):
    r1, _ = r1r2(word, vowels)
    return min(max(r1, 3), len(word))


def swedish(word):
    word = word.lower()
    r1 = _min3(word, SV_V)

    def in_r1(s):
        return len(word) - len(s) >= r1

    s = longest_suffix(word, (
        "heterna", "hetens", "heter", "heten", "anden", "arnas", "ernas", "ornas", "andes", "andet", "arens",
        "arna", "erna", "orna", "ande", "arne", "aste", "aren", "ades", "erns", "ade", "are", "ern", "ens",
        "het", "ast", "ad", "en", "ar", "er", "or", "as", "es", "at", "a", "e", "s"))
    if s and in_r1(s):
        if s == "s":
            if len(word) >= 2 and word[-2] in SV_S_END:
                word = word[:-1]
        else:
            word = word[:-len(s)]
    s = longest_suffix(word, ("dd", "gd", "nn", "dt", "gt", "kt", "tt"))
    if s and in_r1(s):
        word = word[:-1]
    s = longest_suffix(word, ("fullt", "löst", "lig", "els", "ig"))
    if s and in_r1(s):
        if s == "fullt":
            word = word[:-1]
        elif s == "löst":
            word = word[:-1]
        else:
            word = word[:-len(s)]
    return word


# ------------------------------------------------------------------ Danish
DA_V = "aeiouyæåø"
DA_S_END = "abcdfghjklmnoprtvyzå"


def danish(word):
    word = word.lower()
    r1 = _min3(word, DA_V)

    def in_r1(s):
        return len(word) - len(s) >= r1

    s = longest_suffix(word, (
        "erendes", "erende", "hedens", "ethed", "erede", "heden", "heder", "endes", "ernes", "erens", "erets",
        "ered", "ende", "erne", "eren", "erer", "heds", "enes", "eres", "eret", "hed", "ene", "ere", "ens",
        "ers", "ets", "en", "er", "es", "et", "e", "s"))
    if s and in_r1(s):
        if s == "s":
            if len(word) >= 2 and word[-2] in DA_S_END:
                word = word[:-1]
        else:
            word = word[:-len(s)]
    s = longest_suffix(word, ("gd", "dt", "gt", "kt"))
    if s and in_r1(s):
        word = word[:-1]
    if word.endswith("igst") and in_r1("igst"):
        word = word[:-2]
    s = longest_suffix(word, ("elig", "løst", "lig", "els", "ig"))
    if s and in_r1(s):
        if s == "løst":
            word = word[:-1]
        else:
            word = word[:-len(s)]
            s2 = longest_suffix(word, ("gd", "dt", "gt", "kt"))
            if s2 and in_r1(s2):
                word = word[:-1]
    if len(word) >= 2 and len(word) > r1 and word[-1] == word[-2] and word[-1] not in DA_V and in_r1(word[-1]):
        word = word[:-1]
    return word


# ------------------------------------------------------------------ Norwegian
NO_V = "aeiouyæåø"
NO_S_END = "bcdfghjlmnoprtvyz"


def norwegian(word):
    word = word.lower()
    r1 = _min3(word, NO_V)

    def in_r1(s):
        return len(word) - len(s) >= r1

    s = longest_suffix(word, (
        "hetenes", "hetene", "hetens", "heter", "heten", "endes", "ande", "ende", "edes", "enes", "erte", "ede",
        "ane", "ene", "ens", "ers", "ets", "het", "ast", "ert", "en", "ar", "er", "as", "es", "et", "a", "e", "s"))
    if s and in_r1(s):
        if s == "s":
            pre = word[:-1]
            if pre and (pre[-1] in NO_S_END or (pre[-1] == "k" and len(pre) > 1 and pre[-2] not in NO_V)):
                word = pre
        elif s in ("erte", "ert"):
            word = word[:-len(s)] + "er"
        else:
            word = word[:-len(s)]
    s = longest_suffix(word, ("dt", "vt"))
    if s and in_r1(s):
        word = word[:-1]
    s = longest_suffix(word, ("hetslov", "eleg", "elov", "slov", "elig", "eig", "lig", "els", "lov", "leg", "ig"))
    if s and in_r1(s):
        word = word[:-len(s)]
    return word
