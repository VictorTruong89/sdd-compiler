import re

V = "аеиоуыэюя"
_PG1 = ("вшись", "вши", "в")
_PG2 = ("ившись", "ывшись", "ивши", "ывши", "ив", "ыв")
_ADJ = ("ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий", "ый", "ой", "ем", "им",
        "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
_PART1 = ("ем", "нн", "вш", "ющ", "щ")
_PART2 = ("ивш", "ывш", "ующ")
_V1 = ("ете", "йте", "нно", "ешь", "ла", "на", "ли", "ем", "ло", "но", "ет", "ют", "ны", "ть", "й", "л", "н")
_V2 = ("ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено", "ует", "уют", "ены",
       "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым", "ен", "ят", "ит", "ыт", "ую", "ю")
_NOUN = ("иями", "иях", "ями", "ами", "ией", "иям", "ием", "ие", "ье", "еи", "ии", "ей", "ой", "ий", "ям",
         "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия", "ья", "ев", "ов", "а", "е", "и", "й", "о", "у", "ы",
         "ь", "ю", "я")


def _ls(s, sufs):
    best = None
    for x in sufs:
        if s.endswith(x) and (best is None or len(x) > len(best)):
            best = x
    return best


def stem(word):
    word = word.lower().replace("ё", "е")
    rv = len(word)
    for i, c in enumerate(word):
        if c in V:
            rv = i + 1
            break
    r1 = len(word)
    for i in range(1, len(word)):
        if word[i] not in V and word[i - 1] in V:
            r1 = i + 1
            break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in V and word[i - 1] in V:
            r2 = i + 1
            break

    def strip(sufs, groupA=False):
        """Try removing a suffix in RV; groupA: must be preceded by а/я."""
        nonlocal word
        s = _ls(word, sufs)
        if s is None:
            return False
        st = len(word) - len(s)
        if st < rv:
            return False
        if groupA:
            if st == 0 or word[st - 1] not in "ая" or st - 1 < rv:
                # group-1 suffixes need the preceding а/я inside RV
                return False
        word = word[:st]
        return True

    def try_group(g1, g2):
        # group 1 (preceded by а/я) preferred match by longest; then group 2
        s1 = _ls(word, g1)
        s2 = _ls(word, g2)
        cand = []
        if s1:
            st = len(word) - len(s1)
            if st >= rv and st >= 1 and word[st - 1] in "ая" and st - 1 >= rv:
                cand.append((len(s1), s1))
        if s2:
            if len(word) - len(s2) >= rv:
                cand.append((len(s2), s2))
        return max(cand)[1] if cand else None

    def adjectival():
        nonlocal word
        s = _ls(word, _ADJ)
        if s is None or len(word) - len(s) < rv:
            return False
        base = word[:-len(s)]
        # optional participle
        saved = word
        word = base
        p = try_group(_PART1, _PART2)
        if p:
            word = word[:-len(p)]
            if not word.endswith(("а", "я")) and False:
                pass
        return True

    done = False
    s = try_group(_PG1, _PG2)
    if s:
        word = word[:-len(s)]
        done = True
    else:
        # reflexive
        r = _ls(word, ("ся", "сь"))
        if r and len(word) - len(r) >= rv:
            word = word[:-len(r)]
        if adjectival():
            pass
        else:
            v = try_group(_V1, _V2)
            if v:
                word = word[:-len(v)]
            else:
                n = _ls(word, _NOUN)
                if n and len(word) - len(n) >= rv:
                    word = word[:-len(n)]
    if word.endswith("и") and len(word) - 1 >= rv:
        word = word[:-1]
    for d in ("ость", "ост"):
        if word.endswith(d) and len(word) - len(d) >= r2:
            word = word[:-len(d)]
            break
    if word.endswith("нн") and len(word) - 1 >= rv:
        word = word[:-1]
    elif word.endswith("ь") and len(word) - 1 >= rv:
        word = word[:-1]
    else:
        for sup in ("ейше", "ейш"):
            if word.endswith(sup) and len(word) - len(sup) >= rv:
                word = word[:-len(sup)]
                if word.endswith("нн"):
                    word = word[:-1]
                break
    return word
