import os

from .. import data

_SUFFIX = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"),
          ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv", "s": "adj"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = data.find("corpora/wordnet", want_dir=True)
        self._index = {}
        self._exc = {}

    def _load(self, pos):
        pos = "a" if pos == "s" else pos
        if pos in self._index:
            return
        name = _FILES[pos]
        idx = set()
        p = os.path.join(self._dir, "index." + name)
        if not os.path.isfile(p):
            raise LookupError("WordNet file %s missing" % p)
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith(" "):
                    continue
                idx.add(line.split(" ", 1)[0])
        exc = {}
        p = os.path.join(self._dir, name + ".exc")
        if os.path.isfile(p):
            with open(p, encoding="utf-8", errors="replace") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], []).append(parts[1])
        self._index[pos] = idx
        self._exc[pos] = exc

    def lemmatize(self, word, pos="n"):
        if pos not in _FILES:
            raise ValueError("unknown pos %r" % (pos,))
        pos = "a" if pos == "s" else pos
        self._load(pos)
        idx, exc = self._index[pos], self._exc[pos]
        forms = list(exc.get(word, []))
        for suf, rep in _SUFFIX[pos]:
            if word.endswith(suf):
                forms.append(word[: len(word) - len(suf)] + rep)
        forms = [word] + forms
        res = [f for f in forms if f in idx]
        return min(res, key=len) if res else word
