"""Shared helpers for Snowball stemmers."""


def r1r2(word, vowels, start=0):
    """Return (r1_start, r2_start) as indices into word."""
    n = len(word)
    r1 = n
    for i in range(start + 1, n):
        if word[i] not in vowels and word[i - 1] in vowels:
            r1 = i + 1
            break
    r2 = n
    for i in range(r1 + 1, n):
        if word[i] not in vowels and word[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def longest_suffix(word, suffixes):
    best = None
    for s in suffixes:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def rv_spanish(word, vowels):
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
        return n
    return 3 if n >= 3 else n
