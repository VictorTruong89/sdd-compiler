"""Classifiers: Naive Bayes and decision tree."""
import math
from collections import Counter, defaultdict


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    results = [classifier.classify(fs) for fs, _ in gold]
    correct = [l == r for (_, l), r in zip(gold, results)]
    return sum(correct) / len(correct)


class ProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, sample):
        return float(self._probs.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=self._probs.get)

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist  # label -> prob
        self._feature_probdist = feature_probdist  # (label, fname) -> (dict value->count, N, bins)
        self._labels = list(label_probdist.keys())

    @staticmethod
    def train(labeled_featuresets, estimator=None):
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = []
        fnameset = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                if fname not in fnameset:
                    fnameset.add(fname)
                    fnames.append(fname)
        labels = list(label_freq.keys())
        for label in labels:
            n = label_freq[label]
            for fname in fnames:
                cnt = sum(feature_freq[label, fname].values())
                if n - cnt > 0:
                    feature_freq[label, fname][None] += n - cnt
                    feature_values[fname].add(None)
                else:
                    feature_freq[label, fname]  # ensure existence
        total = sum(label_freq.values())
        nb = len(label_freq)
        label_probs = {l: (c + 0.5) / (total + nb * 0.5) for l, c in label_freq.items()}
        fpd = {}
        for (label, fname), fd in feature_freq.items():
            fpd[label, fname] = (dict(fd), sum(fd.values()), len(feature_values[fname]))
        return NaiveBayesClassifier(label_probs, fpd)

    def labels(self):
        return list(self._labels)

    def _fprob(self, label, fname, fval):
        counts, n, bins = self._feature_probdist[label, fname]
        return (counts.get(fval, 0) + 0.5) / (n + bins * 0.5)

    def prob_classify(self, featureset):
        fs = {}
        for fname, fval in featureset.items():
            if any((l, fname) in self._feature_probdist for l in self._labels):
                fs[fname] = fval
        logprob = {}
        for label in self._labels:
            logprob[label] = math.log(self._label_probdist[label])
        for label in self._labels:
            for fname, fval in fs.items():
                if (label, fname) in self._feature_probdist:
                    logprob[label] += math.log(self._fprob(label, fname, fval))
                else:
                    logprob[label] += float("-inf")
        m = max(logprob.values())
        if m == float("-inf"):
            probs = {l: 1.0 / len(logprob) for l in logprob}
        else:
            exps = {l: math.exp(v - m) for l, v in logprob.items()}
            z = sum(exps.values())
            probs = {l: v / z for l, v in exps.items()}
        return ProbDist(probs)

    def classify(self, featureset):
        pd = self.prob_classify(featureset)
        best = None
        bp = -1.0
        for l in self._labels:
            if pd.prob(l) > bp:
                best, bp = l, pd.prob(l)
        return best

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]

    def prob_classify_many(self, featuresets):
        return [self.prob_classify(fs) for fs in featuresets]


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    if n == 0:
        return 0.0
    return -sum((v / n) * math.log2(v / n) for v in c.values())


def _most_common(labels):
    c = Counter(labels)
    best, bc = None, -1
    for l, v in c.items():  # insertion order breaks ties
        if v > bc:
            best, bc = l, v
    return best


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        out = [self._label]
        if self._decisions:
            for d in self._decisions.values():
                out.extend(d.labels())
        return out

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = 0
        for fs, label in labeled_featuresets:
            if self.classify(fs) != label:
                errors += 1
        return errors / len(labeled_featuresets)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty training set")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for n in fs:
                if n not in seen:
                    seen.add(n)
                    names.append(n)
        tree = DecisionTreeClassifier.best_stump(names, labeled_featuresets)
        tree.refine(labeled_featuresets, names, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree

    @staticmethod
    def leaf(labeled_featuresets):
        return DecisionTreeClassifier(_most_common([l for _, l in labeled_featuresets]))

    @staticmethod
    def stump(fname, labeled_featuresets):
        label = _most_common([l for _, l in labeled_featuresets])
        groups = {}
        for fs, l in labeled_featuresets:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_most_common(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(names, labeled_featuresets):
        best = DecisionTreeClassifier.leaf(labeled_featuresets)
        best_err = best.error(labeled_featuresets)
        for fname in names:
            st = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = st.error(labeled_featuresets)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, labeled_featuresets, names, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled_featuresets) <= support_cutoff:
            return
        if self._fname is None:
            return
        if depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            subset = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) == fval]
            if _entropy([l for _, l in subset]) > entropy_cutoff:
                rest = [n for n in names if n != self._fname]
                st = DecisionTreeClassifier.best_stump(rest, subset)
                st.refine(subset, rest, entropy_cutoff, depth_cutoff - 1, support_cutoff)
                self._decisions[fval] = st


__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "ProbDist"]
