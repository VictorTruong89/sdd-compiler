"""Sentence-level BLEU (Papineni et al., 2002)."""
import math
import sys
from collections import Counter


class _P:
    def __init__(self, numerator, denominator):
        self.numerator = numerator
        self.denominator = denominator

    def __float__(self):
        return self.numerator / self.denominator


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    numerator = sum(clipped.values())
    denominator = max(1, sum(counts.values()))
    return _P(numerator, denominator)


def closest_ref_length(references, hyp_len):
    ref_lens = (len(r) for r in references)
    return min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))


def brevity_penalty(closest_ref_len, hyp_len):
    if hyp_len > closest_ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest_ref_len / hyp_len)


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(hypothesis, str):
        raise TypeError("hypothesis must be a list of tokens")
    references = list(references)
    if any(isinstance(r, str) for r in references):
        raise TypeError("references must be lists of tokens")
    weights = list(weights)
    p_n = [modified_precision(references, hypothesis, i) for i, _ in enumerate(weights, start=1)]
    if len(p_n) == 0 or p_n[0].numerator == 0:
        return 0
    hyp_len = len(hypothesis)
    ref_len = closest_ref_length(references, hyp_len)
    bp = brevity_penalty(ref_len, hyp_len)
    if smoothing_function is None:
        p_n = [p if p.numerator != 0 else sys.float_info.min for p in p_n]
        p_vals = [float(p) for p in p_n]
    else:
        p_vals = [float(p) for p in smoothing_function(p_n, references, hypothesis, hyp_len)]
    s = 0.0
    for w, p in zip(weights, p_vals):
        if p > 0:
            s += w * math.log(p)
        else:
            return 0
    return bp * math.exp(s)


sentence_bleu = bleu


class SmoothingFunction:
    """A few smoothing methods; each is callable as (p_n, references, hypothesis, hyp_len)."""

    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [_P(p.numerator + self.epsilon, p.denominator) if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [_P(p.numerator + 1, p.denominator + 1) if i != 0 else p for i, p in enumerate(p_n)]
