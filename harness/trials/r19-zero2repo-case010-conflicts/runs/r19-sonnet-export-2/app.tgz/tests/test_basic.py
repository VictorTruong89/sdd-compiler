from lingora.tokenize import wordpunct_tokenize
from lingora.metrics import edit_distance, accuracy
from lingora.tree import Tree
import pytest


def test_wordpunct():
    assert wordpunct_tokenize("a, b") == ["a", ",", "b"]


def test_edit_distance():
    assert edit_distance("kitten", "sitting") == 3


def test_accuracy_len():
    with pytest.raises(ValueError):
        accuracy([1], [1, 2])


def test_tree():
    assert Tree.fromstring("(S (NP a) (VP b))") == Tree("S", [Tree("NP", ["a"]), Tree("VP", ["b"])])
