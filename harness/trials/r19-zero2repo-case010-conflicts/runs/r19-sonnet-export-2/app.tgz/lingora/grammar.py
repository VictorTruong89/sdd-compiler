"""Context-free grammars."""
import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_empty(self):
        return len(self._rhs) == 0

    def is_lexical(self):
        return all(not isinstance(s, Nonterminal) for s in self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [str(s) if isinstance(s, Nonterminal) else repr(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_RHS_TOKEN = re.compile(r"""\s*(?:'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)"|(\|)|([^\s'"|]+))""")


def _parse_rhs(text):
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _RHS_TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise ValueError("Unable to parse grammar right-hand side: %r" % text)
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(("t", re.sub(r"\\(.)", r"\1", m.group(1))))
        elif m.group(2) is not None:
            alts[-1].append(("t", re.sub(r"\\(.)", r"\1", m.group(2))))
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(("n", m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar input must be a str")
        prods = []
        start = None
        lhs = None
        for line in input.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|") and lhs is not None:
                rhs_text = line
            else:
                if "->" not in line:
                    raise ValueError("Unable to parse line: %r" % line)
                l, rhs_text = line.split("->", 1)
                l = l.strip()
                if not l or re.search(r"\s", l) or l[0] in "'\"":
                    raise ValueError("Bad left-hand side in line: %r" % line)
                lhs = Nonterminal(l)
                if start is None:
                    start = lhs
            for alt in _parse_rhs(rhs_text):
                rhs = [Nonterminal(v) if k == "n" else v for k, v in alt]
                prods.append(Production(lhs, rhs))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, prods)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if not isinstance(s, Nonterminal)}

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + \
            "".join("    %s\n" % p for p in self._productions)

    def __repr__(self):
        return "<Grammar with %d productions>" % len(self._productions)
