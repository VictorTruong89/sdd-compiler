"""Parsers."""
from ..grammar import Nonterminal
from ..tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser", "RecursiveDescentParser"]


def _check(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    missing = [t for t in tokens if t not in known]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r" % (missing,))


class ChartParser:
    def __init__(self, grammar):
        self._g = grammar

    def parse(self, tokens):
        _check(self._g, tokens)
        tokens = list(tokens)
        n = len(tokens)
        g = self._g
        memo = {}
        active = set()

        def seq(rhs, k, i, j):
            # yield lists of children covering tokens[i:j] by rhs[k:]
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, Nonterminal):
                for m in range(i, j + 1):
                    for t in nt(sym, i, m):
                        for rest in seq(rhs, k + 1, m, j):
                            yield [t] + rest
            else:
                if sym == "":
                    yield from ([[sym] + r for r in seq(rhs, k + 1, i, j)] if False else
                                seq(rhs, k + 1, i, j))
                elif i < j and tokens[i] == sym:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [sym] + rest

        def nt(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            res = []
            for p in g.productions(sym):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append(Tree(str(sym), kids))
            active.discard(key)
            memo[key] = res
            return res

        return iter(nt(g.start(), 0, n))


class ShiftReduceParser:
    def __init__(self, grammar):
        self._g = grammar

    def parse(self, tokens):
        _check(self._g, tokens)
        tokens = list(tokens)
        g = self._g
        prods = [p for p in g.productions() if p.rhs()]
        stack = []
        remaining = tokens

        def reduce_once():
            for p in prods:
                rhs = p.rhs()
                if len(stack) < len(rhs):
                    continue
                top = stack[len(stack) - len(rhs):]
                ok = True
                for s, e in zip(rhs, top):
                    if isinstance(s, Nonterminal):
                        if not (isinstance(e, Tree) and e.label() == str(s)):
                            ok = False
                            break
                    elif e != s or isinstance(e, Tree):
                        ok = False
                        break
                if ok:
                    del stack[len(stack) - len(rhs):]
                    stack.append(Tree(str(p.lhs()), top))
                    return True
            return False

        i = 0
        while i < len(remaining):
            stack.append(remaining[i])
            i += 1
            while reduce_once():
                pass
        results = []
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(g.start()):
            results.append(stack[0])
        return iter(results)


RecursiveDescentParser = ChartParser
