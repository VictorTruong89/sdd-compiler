"""Tokenizers."""
import html
import re

from .punkt import get_tokenizer

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "blankline_tokenize", "sent_tokenize", "word_tokenize",
           "wordpunct_tokenize"]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str")


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            out = []
            last = 0
            for m in self._regexp.finditer(text):
                out.append(text[last:m.start()])
                last = m.end()
            out.append(text[last:])
            if self._discard_empty:
                out = [t for t in out if t]
            return out
        return [m.group(0) for m in self._regexp.finditer(text)]

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            last = 0
            spans = []
            for m in self._regexp.finditer(text):
                spans.append((last, m.start()))
                last = m.end()
            spans.append((last, len(text)))
            return iter([s for s in spans if not (self._discard_empty and s[0] == s[1])])
        return iter([m.span() for m in self._regexp.finditer(text)])


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


_wp = WordPunctTokenizer()
_bl = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wp.tokenize(text)


def blankline_tokenize(text):
    return _bl.tokenize(text)


def _c(rs):
    return [(re.compile(a), b) for a, b in rs]


class TreebankWordTokenizer:
    STARTING_QUOTES = _c([
        (r'^\"', r"``"),
        (r"(``)", r" \1 "),
        (r"([ \(\[{<])(\"|\'{2})", r"\1 `` "),
    ])
    PUNCTUATION = _c([
        (r"([:,])([^\d])", r" \1 \2"),
        (r"([:,])$", r" \1 "),
        (r"\.\.\.", r" ... "),
        (r"[;@#$%&]", r" \g<0> "),
        (r'([^\.])(\.)([\]\)}>"\']*)\s*$', r"\1 \2\3 "),
        (r"[?!]", r" \g<0> "),
        (r"([^'])' ", r"\1 ' "),
    ])
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = _c([
        (r'"', " '' "),
        (r"(\S)(\'\')", r"\1 \2 "),
        (r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 "),
        (r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 "),
    ])
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check_text(text)
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        toks = self.tokenize(text)
        pos = 0
        out = []
        for t in toks:
            # quotes are rewritten; fall back to approximate alignment
            i = text.find(t, pos)
            if i < 0:
                q = {"``": '"', "''": '"'}.get(t)
                i = text.find(q, pos) if q else -1
                if i < 0:
                    raise ValueError("cannot align token %r" % t)
                out.append((i, i + 1))
                pos = i + 1
            else:
                out.append((i, i + len(t)))
                pos = i + len(t)
        return iter(out)


class NLTKWordTokenizer(TreebankWordTokenizer):
    STARTING_QUOTES = _c([
        (r"([«“‘„]|[`]+)", r" \1 "),
        (r'^\"', r"``"),
        (r"(``)", r" \1 "),
        (r"([ \(\[{<])(\"|\'{2})", r"\1 `` "),
        (r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", r"\1 \2"),
    ])
    PUNCTUATION = _c([
        (r"([^\.])(\.)([\]\)}>\"\'»”’ ]*)\s*$", r"\1 \2 \3 "),
        (r"([:,])([^\d])", r" \1 \2"),
        (r"([:,])$", r" \1 "),
        (r"\.{2,}", r" \g<0> "),
        (r"[;@#$%&]", r" \g<0> "),
        (r"[?!]", r" \g<0> "),
        (r"([^'])' ", r"\1 ' "),
        (r"[*]", r" \g<0> "),
        (r"[‒-―]", r" \g<0> "),
    ])
    ENDING_QUOTES = _c([
        (r"([»”’])", r" \1 "),
        (r"''", " '' "),
        (r'"', " '' "),
        (r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 "),
        (r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 "),
    ])


_nltk_wt = NLTKWordTokenizer()


def sent_tokenize(text, language="english"):
    _check_text(text)
    return get_tokenizer(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    _check_text(text)
    sents = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sents for t in _nltk_wt.tokenize(s)]


# ---- tweet tokenizer ----
_EMOTICONS = r"""(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|</?3)"""
_URLS = (r"""(?:https?:(?:/{1,3}|[a-z0-9%])|[a-z0-9.\-]+[.](?:[a-z]{2,13})/)"""
         r"""(?:[^\s()<>{}\[\]]+|\([^\s()]*?\([^\s()]+\)[^\s()]*?\)|\([^\s]+?\))+"""
         r"""(?:\([^\s()]*?\([^\s()]+\)[^\s()]*?\)|\([^\s]+?\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’])"""
         r"""|(?:(?<!@)[a-z0-9]+(?:[.\-][a-z0-9]+)*[.](?:[a-z]{2,13})\b/?(?!@))""")
_PHONE = r"""(?:(?:\+?[01][ *\-.\)]*)?(?:[\(]?\d{3}[ *\-.\)]*)?\d{3}[ *\-.\)]*\d{4})"""
_REGEXPS = (
    _URLS, _PHONE, _EMOTICONS,
    r"<[^>\s]+>",
    r"[\-]+>|<[\-]+",
    r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"(?:\.(?:\s*\.){1,})",
    r"(?:\S)",
)
_WORD_RE = re.compile("(%s)" % "|".join(_REGEXPS), re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANDLES_RE = re.compile(r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False, match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in _WORD_RE.finditer(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
