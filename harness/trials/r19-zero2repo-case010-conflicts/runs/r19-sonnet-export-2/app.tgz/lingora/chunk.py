"""Regular-expression chunking."""
import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "RegexpChunkParser", "ne_chunk"]

_IN_CHUNK = r"(?=[^\{]*\})"
_IN_STRIP = r"(?=[^\}]*(\{|$))"
_TAG_CHAR = r"[^\{\}<>]"
_TAG_PATTERN_OK = re.compile(r"^((%s|<%s+?>)*)$" % (r"([^\{\}<>]|\{\d+,?\}|\{\d*,\d+\})", r"([^\{\}<>]|\{\d+,?\}|\{\d*,\d+\})"))


def tag_pattern2re_pattern(tag_pattern):
    tp = re.sub(r"\s", "", tag_pattern)
    tp = tp.replace("<", "(?:<(?:").replace(">", ")>)")
    tp = re.sub(r"([^\\])\.", r"\1" + _TAG_CHAR, tp)
    if tp.startswith("."):
        tp = _TAG_CHAR + tp[1:]
    try:
        re.compile(tp)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (tag_pattern, e))
    return tp


class _Rule:
    def __init__(self, kind, tag_pattern):
        self.kind = kind
        body = tag_pattern2re_pattern(tag_pattern)
        if kind == "chunk":
            self._re = re.compile(r"(?P<chunk>%s)%s" % (body, _IN_STRIP))
            self._repl = r"{\g<chunk>}"
        else:
            self._re = re.compile(r"(?P<chink>%s)%s" % (body, _IN_CHUNK))
            self._repl = r"}\g<chink>{"

    def apply(self, s):
        s = self._re.sub(self._repl, s)
        return s.replace("{}", "")


def _rule_from_string(text):
    m = re.match(r"(?P<rule>(\\.|[^#])*)(?P<comment>#.*)?", text)
    rule = m.group("rule").strip()
    if len(rule) >= 2 and rule.startswith("{") and rule.endswith("}"):
        return _Rule("chunk", rule[1:-1])
    if len(rule) >= 2 and rule.startswith("}") and rule.endswith("{"):
        return _Rule("chink", rule[1:-1])
    raise ValueError("Illegal chunk pattern: %s" % text)


def _tag_of(tok):
    if isinstance(tok, Tree):
        return tok.label()
    if isinstance(tok, (tuple, list)) and len(tok) == 2:
        return tok[1]
    raise ValueError("expected (token, tag) pairs, got %r" % (tok,))


class RegexpChunkParser:
    def __init__(self, rules, chunk_label="NP", root_label="S"):
        self._rules = rules
        self._label = chunk_label
        self._root = root_label

    def parse(self, chunk_struct):
        pieces = list(chunk_struct)
        if not pieces:
            return Tree(self._root, [])
        tags = [_tag_of(t) for t in pieces]
        for t in tags:
            if not isinstance(t, str) or re.search(r"[<>{}]", t):
                raise ValueError("unsupported tag %r" % (t,))
        s = "<" + "><".join(tags) + ">"
        for r in self._rules:
            s = r.apply(s)
        out = []
        index = 0
        in_chunk = False
        for piece in re.split("[{}]", s):
            length = piece.count("<")
            sub = pieces[index:index + length]
            if in_chunk:
                out.append(Tree(self._label, sub))
            else:
                out.extend(sub)
            index += length
            in_chunk = not in_chunk
        return Tree(self._root, out)


class RegexpParser:
    def __init__(self, grammar, root_label="S", loop=1):
        self._root = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._read(grammar)
        elif isinstance(grammar, (list, tuple)) and all(hasattr(s, "parse") for s in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk parsers")

    def _read(self, grammar):
        stages = []
        rules = []
        lhs = None

        def add():
            if lhs is not None and rules:
                stages.append(RegexpChunkParser(rules, lhs, self._root))
            elif rules and lhs is None:
                raise ValueError("Rule without a chunk label")
        for line in grammar.split("\n"):
            line = line.strip()
            m = re.match(r"(?P<nt>(\\.|[^:])*)(:(?P<rule>.*))", line)
            if m:
                add()
                lhs = m.group("nt").strip()
                rules = []
                line = m.group("rule").strip()
            if line == "" or line.startswith("#"):
                continue
            rules.append(_rule_from_string(line))
        add()
        return stages

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        for t in tagged:
            if not (isinstance(t, (tuple, list)) and len(t) == 2):
                raise ValueError("expected (token, tag) pairs, got %r" % (t,))
        tree = Tree(self._root, [tuple(t) for t in tagged])
        for _ in range(self._loop):
            for st in self._stages:
                tree = st.parse(tree)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("the named-entity chunker model format is not supported")
