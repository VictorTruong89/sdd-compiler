"""Naive Bayes and decision tree classifiers."""
import math
from collections import defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "ProbDist"]


def _first_max(counts):
    best, bc = None, None
    for k, c in counts.items():
        if bc is None or c > bc:
            best, bc = k, c
    return best


def _check_training(data):
    if not isinstance(data, list):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    for item in data:
        if not (isinstance(item, (tuple, list)) and len(item) == 2 and isinstance(item[0], dict)):
            raise TypeError("each item must be a (featureset, label) pair")


class ProbDist:
    def __init__(self, logprobs):
        self._lp = dict(logprobs)
        m = max(self._lp.values()) if self._lp else 0.0
        total = m + math.log(sum(math.exp(v - m) for v in self._lp.values())) if self._lp else 0.0
        self._lp = {k: v - total for k, v in self._lp.items()}

    def prob(self, sample):
        lp = self._lp.get(sample)
        return 0.0 if lp is None else float(math.exp(lp))

    def logprob(self, sample):
        return self._lp.get(sample, float("-inf"))

    def samples(self):
        return list(self._lp.keys())

    def max(self):
        return _first_max(self._lp)


class NaiveBayesClassifier:
    def __init__(self, label_prob, feature_prob, labels):
        self._label_prob = label_prob          # label -> prob
        self._feature_prob = feature_prob      # (label, fname) -> (counts, N, bins)
        self._labels = list(labels)

    @classmethod
    def train(cls, labeled_featuresets):
        _check_training(labeled_featuresets)
        label_freq = {}
        feat = defaultdict(dict)
        values = defaultdict(set)
        fnames = set()
        for fs, label in labeled_featuresets:
            label_freq[label] = label_freq.get(label, 0) + 1
            for fname, fval in fs.items():
                d = feat[(label, fname)]
                d[fval] = d.get(fval, 0) + 1
                values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                d = feat[(label, fname)]
                missing = n - sum(d.values())
                if missing > 0:
                    d[None] = d.get(None, 0) + missing
                    values[fname].add(None)
        total = sum(label_freq.values())
        nb = len(label_freq)
        label_prob = {l: (c + 0.5) / (total + 0.5 * nb) for l, c in label_freq.items()}
        fp = {}
        for (label, fname), d in feat.items():
            fp[(label, fname)] = (d, sum(d.values()), len(values[fname]))
        return cls(label_prob, fp, label_freq.keys())

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._feature_prob for l in self._labels)}
        lp = {l: math.log(self._label_prob[l]) for l in self._labels}
        for l in self._labels:
            for fname, fval in fs.items():
                if (l, fname) in self._feature_prob:
                    d, n, bins = self._feature_prob[(l, fname)]
                    lp[l] += math.log((d.get(fval, 0) + 0.5) / (n + 0.5 * bins))
        return ProbDist(lp)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled):
        if not labeled:
            return 0.0
        return sum(1 for fs, l in labeled if self.classify(fs) != l) / len(labeled)

    @staticmethod
    def _freq(labels):
        d = {}
        for l in labels:
            d[l] = d.get(l, 0) + 1
        return d

    @staticmethod
    def _entropy(freq):
        n = sum(freq.values())
        return -sum((c / n) * math.log2(c / n) for c in freq.values() if c) if n else 0.0

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10,
              binary=False, feature_values=None, verbose=False):
        _check_training(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for k in fs:
                if k not in seen:
                    seen.add(k)
                    names.append(k)
        if feature_values is None:
            feature_values = defaultdict(list)
            for fs, _ in labeled_featuresets:
                for k, v in fs.items():
                    if v not in feature_values[k]:
                        feature_values[k].append(v)
        label_freqs = cls._freq(l for _, l in labeled_featuresets)
        best = cls(_first_max(label_freqs))
        best_err = best.error(labeled_featuresets)
        for fname in names:
            st = cls._stump(fname, labeled_featuresets)
            e = st.error(labeled_featuresets)
            if e < best_err:
                best, best_err = st, e
        best._refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff, binary, feature_values)
        return best

    @classmethod
    def _stump(cls, fname, labeled):
        label_freqs = cls._freq(l for _, l in labeled)
        freqs = defaultdict(dict)
        for fs, l in labeled:
            d = freqs[fs.get(fname)]
            d[l] = d.get(l, 0) + 1
        decisions = {v: cls(_first_max(f)) for v, f in freqs.items()}
        default = cls(_first_max(label_freqs))
        return cls(default._label, fname, decisions, default)

    def _refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff, binary, feature_values):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        cls = DecisionTreeClassifier
        for fval in feature_values[self._fname]:
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if not sub:
                continue
            if cls._entropy(cls._freq(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = cls.train(sub, entropy_cutoff, depth_cutoff, support_cutoff, binary, feature_values)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) not in self._decisions]
            if sub and cls._entropy(cls._freq(l for _, l in sub)) > entropy_cutoff:
                self._default = cls.train(sub, entropy_cutoff, depth_cutoff, support_cutoff, binary, feature_values)


def accuracy(classifier, gold):
    if not isinstance(gold, list):
        raise TypeError("gold must be a list")
    if not gold:
        return 0
    return sum(1 for fs, l in gold if classifier.classify(fs) == l) / len(gold)
