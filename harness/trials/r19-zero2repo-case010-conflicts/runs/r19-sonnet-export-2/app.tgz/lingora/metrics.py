"""Evaluation metrics."""


def accuracy(reference, test):
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if not reference:
        return 0.0
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    len1, len2 = len(s1), len(s2)
    lev = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        lev[i][0] = i
    for j in range(len2 + 1):
        lev[0][j] = j
    last_left_t = {}
    for i in range(1, len1 + 1):
        last_right_buf = 0
        for j in range(1, len2 + 1):
            last_left = last_left_t.get(s2[j - 1], 0)
            last_right = last_right_buf
            if s1[i - 1] == s2[j - 1]:
                last_right_buf = j
            a = lev[i - 1][j] + 1
            b = lev[i][j - 1] + 1
            c = lev[i - 1][j - 1] + (substitution_cost if s1[i - 1] != s2[j - 1] else 0)
            best = min(a, b, c)
            if transpositions and last_left > 0 and last_right > 0:
                d = lev[last_left - 1][last_right - 1] + (i - last_left - 1) + (j - last_right - 1) + 1
                best = min(best, d)
            lev[i][j] = best
        last_left_t[s1[i - 1]] = i
    return lev[len1][len2]


def jaccard_distance(label1, label2):
    u = len(label1.union(label2))
    if u == 0:
        return 0.0
    return (u - len(label1.intersection(label2))) / u


def _sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")


def precision(reference, test):
    _sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1.0 - alpha) / r)
