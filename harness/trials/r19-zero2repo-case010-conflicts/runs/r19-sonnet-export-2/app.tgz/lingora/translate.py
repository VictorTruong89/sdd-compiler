"""BLEU."""
import math
from collections import Counter
from fractions import Fraction
import sys


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    num = sum(min(c, max_counts.get(g, 0)) for g, c in counts.items())
    den = max(1, sum(counts.values()))
    return num, den


def _closest_ref_length(references, hyp_len):
    lens = (len(r) for r in references)
    return min(lens, key=lambda l: (abs(l - hyp_len), l))


def _brevity_penalty(ref_len, hyp_len):
    if hyp_len > ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - ref_len / hyp_len)


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if not isinstance(references, list) or not isinstance(hypothesis, list):
        raise TypeError("references and hypothesis must be lists")
    if not references:
        raise ValueError("at least one reference is required")
    for r in references:
        if isinstance(r, str):
            raise TypeError("each reference must be a token list")
    weights = tuple(weights)
    nums, dens = [], []
    for i in range(1, len(weights) + 1):
        a, b = _modified_precision(references, hypothesis, i)
        nums.append(a)
        dens.append(b)
    hyp_len = len(hypothesis)
    ref_len = _closest_ref_length(references, hyp_len)
    bp = _brevity_penalty(ref_len, hyp_len)
    if not nums or nums[0] == 0:
        return 0
    p_n = [Fraction(a, b) for a, b in zip(nums, dens)]
    if smoothing_function is None:
        p_n = [p if p.numerator != 0 else sys.float_info.min for p in p_n]
    else:
        p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    s = (w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))
