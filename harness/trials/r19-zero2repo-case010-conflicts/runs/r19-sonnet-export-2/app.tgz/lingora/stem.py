"""Stemmers."""
import os
import re

from . import data
from . import snowball_en, snowball_germanic as _g, snowball_other as _o
from .porter import PorterStemmer as _Porter, LancasterStemmer, ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer", "SnowballStemmer",
           "WordNetLemmatizer"]

ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS  # noqa


class PorterStemmer(_Porter):
    pass


def _porter_snowball(w):
    return _snow_porter.stem(w, to_lowercase=False)


_snow_porter = _Porter(ORIGINAL_ALGORITHM)

_LANGS = {
    "arabic": _o.arabic, "danish": _g.danish, "dutch": _g.dutch, "english": snowball_en.stem,
    "finnish": _o.finnish, "french": _o.french, "german": _g.german, "hungarian": _o.hungarian,
    "italian": _o.italian, "norwegian": _g.norwegian, "porter": _porter_snowball,
    "portuguese": _o.portuguese, "romanian": _o.romanian, "russian": _o.russian,
    "spanish": _o.spanish, "swedish": _g.swedish,
}


class SnowballStemmer:
    languages = tuple(sorted(_LANGS))

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in _LANGS:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            p = data.find("corpora/stopwords/%s" % language)
            if not os.path.isfile(p):
                raise LookupError("stopwords list for %r not found" % language)
            self.stopwords = set(l.strip() for l in data.read_lines(p) if l.strip())
        self.ignore_stopwords = ignore_stopwords
        self._f = _LANGS[language]

    def stem(self, word):
        word = word.lower()
        if self.ignore_stopwords and word in self.stopwords:
            return word
        return self._f(word)


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


class ARLSTem:
    """Light Arabic stemmer (basic prefix/suffix removal)."""
    def stem(self, word):
        return _o.arabic(word)


class ARLSTem2(ARLSTem):
    pass


class WordNetLemmatizer:
    _FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}
    _SUBS = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"),
              ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }

    def _load(self, pos):
        d = data.find("corpora/wordnet")
        name = self._FILES[pos]
        lemmas = set()
        fp = os.path.join(d, "index." + name)
        if os.path.isfile(fp):
            for line in data.read_lines(fp):
                if line and not line.startswith(" "):
                    lemmas.add(line.split(" ", 1)[0])
        exc = {}
        fp = os.path.join(d, name + ".exc")
        if os.path.isfile(fp):
            for line in data.read_lines(fp):
                parts = line.split()
                if len(parts) >= 2:
                    exc.setdefault(parts[0], []).append(parts[1])
        return lemmas, exc

    def lemmatize(self, word, pos="n"):
        if pos not in self._FILES:
            raise ValueError("unknown pos %r" % (pos,))
        lemmas, exc = self._load(pos)
        forms = list(exc.get(word, []))
        if word in lemmas:
            forms.append(word)
        cur = [word]
        for suf, rep in self._SUBS[pos]:
            if word.endswith(suf):
                cur.append(word[:len(word) - len(suf)] + rep)
        forms += [f for f in cur[1:] if f in lemmas]
        if not forms:
            return word
        return min(forms, key=len)
