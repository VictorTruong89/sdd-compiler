"""Command line group."""
import sys

__all__ = ["cli"]


class _Command:
    def __init__(self, name, func):
        self.name = name
        self.func = func


class _Group:
    def __init__(self):
        self.commands = {}

    def command(self, name):
        def deco(f):
            self.commands[name] = _Command(name, f)
            return f
        return deco

    def main(self, args=None, standalone_mode=True, **kwargs):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        code = 0
        try:
            if not args or args[0] not in self.commands:
                sys.stderr.write("Usage: lingora [tokenize]\n")
                code = 2
                if not standalone_mode:
                    raise SystemExit(code)
            else:
                code = self.commands[args[0]].func(args[1:]) or 0
        except SystemExit as e:
            if not standalone_mode:
                raise
            code = e.code if isinstance(e.code, int) else 1
        except Exception as e:  # failure
            sys.stderr.write("Error: %s\n" % (e,))
            if not standalone_mode:
                raise
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code


cli = _Group()


@cli.command("tokenize")
def _tokenize(argv):
    from .tokenize import word_tokenize, sent_tokenize
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-l", "--language") and i + 1 < len(argv):
            language = argv[i + 1]; i += 2
        elif a in ("-d", "--delimiter") and i + 1 < len(argv):
            delimiter = argv[i + 1]; i += 2
        elif a in ("-e", "--encoding") and i + 1 < len(argv):
            encoding = argv[i + 1]; i += 2
        else:
            sys.stderr.write("Unknown option %s\n" % a)
            return 2
    raw = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read().encode(encoding)
    text = raw.decode(encoding)
    sent_tokenize("", language)  # fail early if the Punkt model is missing
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = []
    for line in lines:
        if line.endswith("\r"):
            line = line[:-1]
        out.append(delimiter.join(word_tokenize(line, language)) + "\n")
    w = sys.stdout.buffer if hasattr(sys.stdout, "buffer") else None
    s = "".join(out)
    if w is not None:
        sys.stdout.flush()
        w.write(s.encode("utf-8"))
        w.flush()
    else:
        sys.stdout.write(s)
    return 0


if __name__ == "__main__":
    cli.main()
