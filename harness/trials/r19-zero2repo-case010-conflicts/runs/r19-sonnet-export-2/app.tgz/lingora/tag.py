"""Part-of-speech taggers."""
import json
import os
import re
from collections import defaultdict

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger", "TrigramTagger", "pos_tag"]


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag_one"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not str")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for r, t in self._regexps:
            if r.match(tokens[index]):
                return t
        return None


class _NgramTagger(SequentialBackoffTagger):
    n = 1

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        SequentialBackoffTagger.__init__(self, backoff)
        if model is not None:
            self._model = dict(model)
            return
        counts = defaultdict(dict)
        for sent in train or []:
            tokens = [w for w, _ in sent]
            tags = [t for _, t in sent]
            for i in range(len(tokens)):
                ctx = self._context(tokens, i, tags[:i])
                if ctx is None:
                    continue
                d = counts[ctx]
                d[tags[i]] = d.get(tags[i], 0) + 1
        self._model = {}
        for ctx, d in counts.items():
            best, bc = None, -1
            for t, c in d.items():
                if c > bc:
                    best, bc = t, c
            if bc > cutoff:
                self._model[ctx] = best

    def _context(self, tokens, index, history):
        if self.n == 1:
            return tokens[index]
        if index < self.n - 1:
            prev = tuple([None] * (self.n - 1 - index) + list(history))
        else:
            prev = tuple(history[index - self.n + 1:index])
        return (prev, tokens[index])

    def choose_tag(self, tokens, index, history):
        ctx = self._context(tokens, index, history)
        if ctx is None:
            return None
        return self._model.get(ctx)


class UnigramTagger(_NgramTagger):
    n = 1


class BigramTagger(_NgramTagger):
    n = 2


class TrigramTagger(_NgramTagger):
    n = 3


# ---- averaged perceptron ----
class PerceptronTagger:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, directory, lang):
        base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
        with open(base + ".weights.json", encoding="utf-8") as f:
            self.weights = json.load(f)
        with open(base + ".tagdict.json", encoding="utf-8") as f:
            self.tagdict = json.load(f)
        with open(base + ".classes.json", encoding="utf-8") as f:
            self.classes = set(json.load(f))

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1
        i += len(self.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = self.START
        out = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RU = {"A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ", "CONJ": "CONJ",
       "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT", "PART": "PRT", "PR": "ADP",
       "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON", "S": "NOUN", "S-PRO": "PRON", "V": "VERB", "SENT": ".",
       "COM": "X"}


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str; tokenize the text first")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    tagger = PerceptronTagger(d, lang)
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            m = {}
            for line in data.read_lines(os.path.join(data.find("taggers/universal_tagset"), "en-ptb.map")):
                parts = line.split("\t")
                if len(parts) >= 2:
                    m[parts[0]] = parts[1]
            tagged = [(w, m.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _RU.get(t.split("=")[0], "X")) for w, t in tagged]
    return tagged
