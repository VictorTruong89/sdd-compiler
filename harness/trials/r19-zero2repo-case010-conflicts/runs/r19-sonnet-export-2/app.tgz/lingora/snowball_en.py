"""Snowball English (Porter2) stemmer."""
VOWELS = "aeiouy"
DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
LI = "cdeghkmnrt"
SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
           "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
           "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
           "bias": "bias", "andes": "andes"}
EXC1A = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def _regions(w):
    r1 = len(w)
    for p in ("gener", "commun", "arsen"):
        if w.startswith(p):
            r1 = len(p)
            break
    else:
        for i in range(1, len(w)):
            if w[i] not in VOWELS and w[i - 1] in VOWELS:
                r1 = i + 1
                break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in VOWELS and w[i - 1] in VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _short_syllable_end(w):
    n = len(w)
    if n >= 3 and w[-1] not in VOWELS and w[-1] not in "wxY" and w[-2] in VOWELS and w[-3] not in VOWELS:
        return True
    return n == 2 and w[0] in VOWELS and w[1] not in VOWELS


def stem(word):
    if len(word) <= 2:
        return word
    w = word
    if w in SPECIAL:
        return SPECIAL[w]
    if w.startswith("'"):
        w = w[1:]
    if w.startswith("y"):
        w = "Y" + w[1:]
    chars = list(w)
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in VOWELS:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _regions(w)
    # step 0
    for s in ("'s'", "'s", "'"):
        if w.endswith(s):
            w = w[:-len(s)]
            break
    # step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(c in VOWELS for c in w[:-2]):
            w = w[:-1]
    if w in SPECIAL:
        pass
    if w in EXC1A:
        return w
    # step 1b
    if w.endswith("eedly") or w.endswith("eed"):
        s = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(s) >= r1:
            w = w[:-len(s)] + "ee"
    else:
        for s in ("ingly", "edly", "ing", "ed"):
            if w.endswith(s):
                pre = w[:-len(s)]
                if any(c in VOWELS for c in pre):
                    w = pre
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w.endswith(DOUBLES):
                        w = w[:-1]
                    elif r1 >= len(w) and _short_syllable_end(w):
                        w += "e"
                break
    # step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in VOWELS:
        w = w[:-1] + "i"
    r1 = min(r1, len(w)); r2 = min(r2, len(w))
    # step 2
    for s, rep in (("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
                   ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
                   ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
                   ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
                   ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"), ("li", "")):
        if w.endswith(s):
            if len(w) - len(s) >= r1:
                if s == "ogi":
                    if w[:-3].endswith("l"):
                        w = w[:-3] + rep
                elif s == "li":
                    if w[:-2] and w[-3] in LI:
                        w = w[:-2]
                else:
                    w = w[:-len(s)] + rep
            break
    # step 3
    for s, rep in (("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
                   ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", "")):
        if w.endswith(s):
            if len(w) - len(s) >= r1:
                if s == "ative":
                    if len(w) - len(s) >= r2:
                        w = w[:-len(s)]
                else:
                    w = w[:-len(s)] + rep
            break
    # step 4
    for s in ("ement", "ance", "ence", "able", "ible", "ment", "ent", "ant", "ism", "ate", "iti", "ous",
              "ive", "ize", "ion", "al", "er", "ic"):
        if w.endswith(s):
            if len(w) - len(s) >= r2:
                if s == "ion":
                    if w[:-3][-1:] in ("s", "t"):
                        w = w[:-3]
                else:
                    w = w[:-len(s)]
            break
    # step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _short_syllable_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w[:-1].endswith("l"):
            w = w[:-1]
    return w.replace("Y", "y")
