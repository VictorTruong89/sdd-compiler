"""Packaged resource lookup.  # spec: N-000385"""
import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
for _p in (os.path.expanduser("~/lingora_data"), "/usr/share/lingora_data", "/usr/local/share/lingora_data"):
    if os.path.isdir(_p):
        path.append(_p)


def find(resource):
    """Return the directory/file for ``resource`` found on ``data.path`` or raise LookupError."""
    for d in list(path):
        p = os.path.join(d, *resource.split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))


def available(resource):
    try:
        find(resource)
        return True
    except LookupError:
        return False


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as f:
        text = f.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [l[:-1] if l.endswith("\r") else l for l in lines]
