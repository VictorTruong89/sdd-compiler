"""Snowball stemmers: Spanish, Russian, French, Italian, Portuguese and light fallbacks."""
import unicodedata


def _longest(w, sufs, start=0):
    best = None
    for s in sufs:
        if w.endswith(s) and len(w) - len(s) >= start and (best is None or len(s) > len(best)):
            best = s
    return best


def _r1r2(w, vowels):
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r1 = i + 1
            break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def _rv_romance(w, vowels):
    n = len(w)
    if n < 2:
        return n
    if w[1] not in vowels:
        for i in range(2, n):
            if w[i] in vowels:
                return i + 1
        return n
    if w[0] in vowels and w[1] in vowels:
        for i in range(2, n):
            if w[i] not in vowels:
                return i + 1
        return n
    return 3 if n >= 3 else n


# ------------- Spanish -------------
_ES_V = "aeiouáéíóúü"


def spanish(w):
    r1, r2 = _r1r2(w, _ES_V)
    rv = _rv_romance(w, _ES_V)
    # step 0
    p = _longest(w, "me se sela selo selas selos la le lo las les los nos".split())
    if p:
        pre = w[:-len(p)]
        for s, rep in (("iéndo", "iendo"), ("ándo", "ando"), ("ár", "ar"), ("ér", "er"), ("ír", "ir")):
            if pre.endswith(s) and len(pre) - len(s) >= rv - 0 and len(pre) >= rv:
                w = pre[:-len(s)] + rep
                break
        else:
            for s in ("ando", "iendo", "ar", "er", "ir"):
                if pre.endswith(s) and len(pre) - len(s) >= 0 and len(pre) >= rv:
                    w = pre
                    break
            else:
                if pre.endswith("yendo") and pre[-6:-5] == "u" and len(pre) >= rv:
                    w = pre
    n = len(w)
    # step 1
    done = False
    suf = _longest(w, ("anza anzas ico ica icos icas ismo ismos able ables ible ibles ista istas oso osa osos osas "
                       "amiento amientos imiento imientos adora ador ación adoras adores aciones ante antes ancia ancias "
                       "logía logías ución uciones encia encias amente mente idad idades iva ivo ivas ivos").split())
    if suf:
        base = w[:-len(suf)]
        pos = len(base)
        if suf in ("anza anzas ico ica icos icas ismo ismos able ables ible ibles ista istas oso osa osos osas "
                   "amiento amientos imiento imientos").split():
            if pos >= r2:
                w = base; done = True
        elif suf in ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias"):
            if pos >= r2:
                w = base; done = True
                if w.endswith("ic") and len(w) - 2 >= r2:
                    w = w[:-2]
        elif suf in ("logía", "logías"):
            if pos >= r2:
                w = base + "log"; done = True
        elif suf in ("ución", "uciones"):
            if pos >= r2:
                w = base + "u"; done = True
        elif suf in ("encia", "encias"):
            if pos >= r2:
                w = base + "ente"; done = True
        elif suf == "amente":
            if pos >= r1:
                w = base; done = True
                if w.endswith("iv") and len(w) - 2 >= r2:
                    w = w[:-2]
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
                else:
                    for t in ("os", "ic", "ad"):
                        if w.endswith(t) and len(w) - 2 >= r2:
                            w = w[:-2]
                            break
        elif suf == "mente":
            if pos >= r2:
                w = base; done = True
                t = _longest(w, ("ante", "able", "ible"), r2)
                if t:
                    w = w[:-len(t)]
        elif suf in ("idad", "idades"):
            if pos >= r2:
                w = base; done = True
                t = _longest(w, ("abil", "ic", "iv"), r2)
                if t:
                    w = w[:-len(t)]
        elif suf in ("iva", "ivo", "ivas", "ivos"):
            if pos >= r2:
                w = base; done = True
                if w.endswith("at") and len(w) - 2 >= r2:
                    w = w[:-2]
    if not done:
        n = len(w)
        t = _longest(w, "ya ye yan yen yeron yendo yo yó yas yes yais yamos".split(), rv)
        if t and w[:-len(t)][-1:] == "u":
            w = w[:-len(t)]
            done2 = True
        else:
            done2 = False
        if not done2:
            t = _longest(w, ("arían arías arán arás aríais aría aréis aríamos aremos ará aré erían erías erán erás "
                             "eríais ería eréis eríamos eremos erá eré irían irías irán irás iríais iría iréis "
                             "iríamos iremos irá iré aba ada ida ía ara iera ad ed id ase iese aste iste an aban "
                             "ían aran ieran asen iesen aron ieron ado ido ando iendo ió ar er ir as abas adas "
                             "idas ías aras ieras ases ieses ís áis abais íais arais ierais aseis ieseis asteis "
                             "isteis ados idos amos ábamos íamos imos áramos iéramos iésemos ásemos en es éis emos").split(), rv)
            if t:
                if t in ("en", "es", "éis", "emos"):
                    w = w[:-len(t)]
                    if w.endswith("gu") and len(w) - 1 >= rv:
                        w = w[:-1]
                else:
                    w = w[:-len(t)]
    # step 3
    t = _longest(w, ("os", "a", "o", "á", "í", "ó"), rv)
    if t:
        w = w[:-len(t)]
    else:
        t = _longest(w, ("e", "é"), rv)
        if t:
            w = w[:-len(t)]
            if w.endswith("gu") and len(w) - 1 >= rv:
                w = w[:-1]
    for a, b in zip("áéíóú", "aeiou"):
        w = w.replace(a, b)
    return w


# ------------- Russian -------------
_RU_V = "аеиоуыэюя"


def _ru_end(w, sufs, rv, need_ay=False):
    best = None
    for s in sufs:
        if w.endswith(s) and (best is None or len(s) > len(best)):
            if len(w) - len(s) >= rv - 0:
                best = s
    return best


def russian(w):
    w = w.replace("ё", "е")
    rv = len(w)
    for i, ch in enumerate(w):
        if ch in _RU_V:
            rv = i + 1
            break
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in _RU_V and w[i - 1] in _RU_V:
            r1 = i + 1
            break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in _RU_V and w[i - 1] in _RU_V:
            r2 = i + 1
            break

    def grp(word, g1, g2):
        # returns new word or None
        cand = []
        for s in g1:
            if word.endswith(s) and len(word) - len(s) >= rv and word[:-len(s)][-1:] in ("а", "я") and len(word) - len(s) >= 1:
                cand.append((len(s), s))
        for s in g2:
            if word.endswith(s) and len(word) - len(s) >= rv:
                cand.append((len(s), s))
        if cand:
            return word[:-max(cand)[1].__len__()]
        return None

    def simple(word, sufs):
        s = _longest(word, sufs, rv)
        return word[:-len(s)] if s else None

    adj = "ее ие ые ое ими ыми ей ий ый ой ем им ым ом его ого ему ому их ых ую юю ая яя ою ею".split()
    part1 = "ем нн вш ющ щ".split()
    part2 = "ивш ывш ующ".split()
    verb1 = "ла на ете йте ли й л ем н ло но ет ют ны ть ешь нно".split()
    verb2 = "ила ыла ена ейте уйте ите или ыли ей уй ил ыл им ым ен ило ыло ено ят ует уют ит ыт ены ить ыть ишь ую ю".split()
    noun = "а ев ов ие ье е иями ями ами еи ии и ией ей ой ий й иям ям ием ем ам ом о у ах иях ях ы ь ю ию ью я ия ья".split()
    # step 1
    x = grp(w, ["в", "вши", "вшись"], ["ив", "ивши", "ившись", "ыв", "ывши", "ывшись"])
    if x is not None:
        w = x
    else:
        x = simple(w, ["ся", "сь"])
        if x is not None:
            w = x
        done = False
        # adjectival
        s = _longest(w, adj, rv)
        if s:
            base = w[:-len(s)]
            y = grp(base, part1, part2) if base else None
            w = y if (y is not None) else base
            done = True
        if not done:
            y = grp(w, verb1, verb2)
            if y is not None:
                w = y
                done = True
        if not done:
            y = simple(w, noun)
            if y is not None:
                w = y
    # step 2
    if w.endswith("и") and len(w) - 1 >= rv:
        w = w[:-1]
    # step 3
    s = _longest(w, ("ость", "ост"), r2)
    if s:
        w = w[:-len(s)]
    # step 4
    if w.endswith("нн") and len(w) - 1 >= rv:
        w = w[:-1]
    else:
        s = _longest(w, ("ейше", "ейш"), rv)
        if s:
            w = w[:-len(s)]
            if w.endswith("нн"):
                w = w[:-1]
        elif w.endswith("ь") and len(w) - 1 >= rv:
            w = w[:-1]
    return w


# ------------- French (condensed) -------------
_FR_V = "aeiouyâàëéêèïîôûù"


def french(w):
    c = list(w)
    for i in range(len(c)):
        if c[i] == "u" or c[i] == "i":
            if (i > 0 and c[i - 1] in _FR_V and i + 1 < len(c) and c[i + 1] in _FR_V):
                c[i] = c[i].upper()
        if c[i] == "y" and ((i > 0 and c[i - 1] in _FR_V) or (i + 1 < len(c) and c[i + 1] in _FR_V)):
            c[i] = "Y"
        if c[i] == "u" and i > 0 and c[i - 1] == "q":
            c[i] = "U"
        if c[i] == "ë":
            c[i] = "ë"
    w = "".join(c)
    v = _FR_V
    # RV
    if w[:2] in ("par", "col", "tap"):
        rv = 3
    elif len(w) > 1 and w[0] in v and w[1] in v:
        rv = 3
    else:
        rv = len(w)
        for i in range(1, len(w)):
            if w[i] in v:
                rv = i + 1
                break
    r1, r2 = _r1r2(w, v)
    orig = w

    def delete_if(w, suf, region):
        return len(w) - len(suf) >= region

    # step 1
    done = False
    suf = _longest(w, ("ances ance iqUe iqUes isme ismes able ables iste istes eux atrice ateur ation atrices "
                       "ateurs ations logie logies usion ution usions utions ence ences ement ements ité ités "
                       "if ive ifs ives euse euses ment ments amment emment issement issements aux").split())
    changed = False
    if suf:
        base = w[:-len(suf)]
        pos = len(base)
        if suf in ("ances", "ance", "iqUe", "iqUes", "isme", "ismes", "able", "ables", "iste", "istes", "eux"):
            if pos >= r2:
                w = base; changed = True
        elif suf in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("ic"):
                    w = w[:-2] if len(w) - 2 >= r2 else w[:-2] + "iqU"
        elif suf in ("logie", "logies"):
            if pos >= r2:
                w = base + "log"; changed = True
        elif suf in ("usion", "ution", "usions", "utions"):
            if pos >= r2:
                w = base + "u"; changed = True
        elif suf in ("ence", "ences"):
            if pos >= r2:
                w = base + "ent"; changed = True
        elif suf in ("ement", "ements"):
            if pos >= rv:
                w = base; changed = True
                if w.endswith("iv") and len(w) - 2 >= r2:
                    w = w[:-2]
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
                elif w.endswith("eus"):
                    if len(w) - 3 >= r2:
                        w = w[:-3]
                    elif len(w) - 3 >= r1:
                        w = w[:-3] + "eux"
                elif w.endswith("abl") or w.endswith("iqU"):
                    if len(w) - 3 >= r2:
                        w = w[:-3]
                elif w.endswith("ièr") or w.endswith("Ièr"):
                    if len(w) - 3 >= rv:
                        w = w[:-3] + "i"
        elif suf in ("ité", "ités"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("abil"):
                    w = w[:-4] if len(w) - 4 >= r2 else w[:-2] + "l"
                elif w.endswith("ic"):
                    w = w[:-2] if len(w) - 2 >= r2 else w[:-2] + "iqU"
                elif w.endswith("iv") and len(w) - 2 >= r2:
                    w = w[:-2]
        elif suf in ("if", "ive", "ifs", "ives"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("at") and len(w) - 2 >= r2:
                    w = w[:-2]
                    if w.endswith("ic"):
                        w = w[:-2] if len(w) - 2 >= r2 else w[:-2] + "iqU"
        elif suf in ("euse", "euses"):
            if pos >= r2:
                w = base; changed = True
            elif pos >= r1:
                w = base + "eux"; changed = True
        elif suf in ("ment", "ments"):
            if pos >= rv and base[-1:] in tuple(v):
                w = base; changed = True
        elif suf in ("amment",):
            if pos >= rv:
                w = base + "ant"; changed = True; done = True
        elif suf in ("emment",):
            if pos >= rv:
                w = base + "ent"; changed = True; done = True
        elif suf in ("issement", "issements"):
            if pos >= r1 and base[-1:] not in tuple(v) and base:
                w = base; changed = True
        elif suf == "aux":
            if pos >= r1:
                w = base + "al"; changed = True
    # step 2a
    if not changed or done:
        pass
    if not changed:
        t = _longest(w, ("issantes issante issants issant issaIent issait issions issons issiez issez isses "
                         "isse issent ira irai iras irez irez irons iront irais irait iriez irions irent ie "
                         "ies ir is it ît îmes îtes i").replace("issaIent", "issaient").split(), rv)
        if t and w[:-len(t)][-1:] and w[:-len(t)][-1] not in v:
            w = w[:-len(t)]
            changed = True
    if not changed:
        t = _longest(w, ("eraIent erais erait eriez erions erons eront erai eras erez era ées és ée ez er "
                         "èrent âmes âtes ât ant ante ants antes a ai as asse assent asses assiez assions "
                         "assais assait assaient ent").replace("eraIent", "eraient").split(), rv)
        if t:
            if t in ("ions",):
                pass
            base = w[:-len(t)]
            if t == "ions" and len(base) >= r2:
                w = base
            else:
                w = base
                if t in ("a", "ai", "as", "asse", "assent", "asses", "assiez", "assions", "assais", "assait", "assaient", "ât", "âmes", "âtes", "ant", "ante", "ants", "antes") and False:
                    pass
            changed = True
            if base.endswith("e") and len(base) - 1 >= rv and t.startswith("a"):
                w = base[:-1]
    # step 3
    if w.endswith("Y"):
        w = w[:-1] + "i"
    elif w.endswith("ç"):
        w = w[:-1] + "c"
    # step 4
    if w.endswith("s") and len(w) > 1 and w[-2] not in "aiouès" and len(w) - 1 >= rv:
        w = w[:-1]
    t = _longest(w, ("ion", "ier", "ière", "Ier", "Ière", "e", "ë"), rv)
    if t == "ion":
        if len(w) - 3 >= r2 and w[-4:-3] in ("s", "t"):
            w = w[:-3]
    elif t in ("ier", "ière", "Ier", "Ière"):
        w = w[:-len(t)] + "i"
    elif t in ("e",):
        w = w[:-1]
    elif t == "ë":
        if w.endswith("guë"):
            w = w[:-1]
    # step 5
    if w.endswith(("enn", "onn", "ett", "ell", "eill")):
        w = w[:-1]
    # step 6
    for i in range(len(w) - 1, -1, -1):
        if w[i] in "éè":
            if i < len(w) - 1 and all(ch not in v for ch in w[i + 1:]) and i != len(w) - 1:
                w = w[:i] + "e" + w[i + 1:]
            break
        if w[i] in v:
            break
    return w.replace("I", "i").replace("U", "u").replace("Y", "y")


# ------------- Italian (condensed) -------------
_IT_V = "aeiouàèìòù"


def italian(w):
    for a, b in zip("áéíóú", "àèìòù"):
        w = w.replace(a, b)
    c = list(w)
    for i in range(len(c)):
        if c[i] == "u" and i > 0 and c[i - 1] == "q":
            c[i] = "U"
        elif c[i] in "iu" and 0 < i < len(c) - 1 and c[i - 1] in _IT_V and c[i + 1] in _IT_V:
            c[i] = c[i].upper()
    w = "".join(c)
    v = _IT_V
    r1, r2 = _r1r2(w, v)
    rv = _rv_romance(w, v)
    p = _longest(w, "ci gli la le li lo mi ne si ti vi sene gliela gliele glieli glielo gliene mela mele meli melo mene tela tele teli telo tene cela cele celi celo cene vela vele veli velo vene".split())
    if p:
        pre = w[:-len(p)]
        if pre.endswith(("ando", "endo")) and len(pre) >= rv:
            w = pre
        elif pre.endswith(("ar", "er", "ir")) and len(pre) >= rv:
            w = pre + "e"
    changed = False
    suf = _longest(w, ("anza anze ico ici ica ice iche ichi ismo ismi abile abili ibile ibili ista iste isti istà "
                       "istè istì oso osi osa ose mente atrice atrici azione azioni atore atori logia logie uzione "
                       "uzioni usione usioni enza enze amento amenti imento imenti amente ità ivo ivi iva ive").split())
    if suf:
        base = w[:-len(suf)]
        pos = len(base)
        if suf in ("amente",):
            if pos >= r1:
                w = base; changed = True
                t = _longest(w, ("iv", "os", "ic", "abil"), r2)
                if t:
                    w = w[:-len(t)]
                    if t == "iv" and w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        elif suf in ("logia", "logie"):
            if pos >= r2:
                w = base + "log"; changed = True
        elif suf in ("uzione", "uzioni", "usione", "usioni"):
            if pos >= r2:
                w = base + "u"; changed = True
        elif suf in ("enza", "enze"):
            if pos >= r2:
                w = base + "ente"; changed = True
        elif suf in ("amento", "amenti", "imento", "imenti"):
            if pos >= rv:
                w = base; changed = True
        elif suf == "ità":
            if pos >= r2:
                w = base; changed = True
                t = _longest(w, ("abil", "ic", "iv"), r2)
                if t:
                    w = w[:-len(t)]
        elif suf in ("ivo", "ivi", "iva", "ive"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("at") and len(w) - 2 >= r2:
                    w = w[:-2]
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
        elif suf in ("azione", "azioni", "atore", "atori", "atrice", "atrici"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("ic") and len(w) - 2 >= r2:
                    w = w[:-2]
        else:
            if pos >= r2:
                w = base; changed = True
    if not changed:
        t = _longest(w, ("ammo ando ano are arono asse assero assi assimo ata ate ati ato ava avamo avano avate "
                         "avi avo emmo enda ende endi endo erà erai eranno ere erebbe erebbero erei eremmo eremo "
                         "ereste eresti erete erò erono essero ete eva evamo evano evate evi evo Yamo iamo immo "
                         "irà irai iranno ire irebbe irebbero irei iremmo iremo ireste iresti irete irò irono "
                         "isca iscano isce isci isco iscono issero ita ite iti ito iva ivamo ivano ivate ivi "
                         "ivo onoo ono uta ute uti uto ar ir").split(), rv)
        if t:
            w = w[:-len(t)]
    t = _longest(w, ("a e i o à è ì ò"[:].split()), rv)
    if t:
        w = w[:-len(t)]
        if w.endswith("i") and len(w) - 1 >= rv:
            w = w[:-1]
        if w.endswith("ch") or w.endswith("gh"):
            if len(w) - 1 >= rv:
                w = w[:-1]
    return w.replace("I", "i").replace("U", "u")


# ------------- Portuguese (condensed) -------------
_PT_V = "aeiouáéíóúâêôà"


def portuguese(w):
    w = w.replace("ã", "a~").replace("õ", "o~")
    v = _PT_V
    r1, r2 = _r1r2(w, v)
    rv = _rv_romance(w, v)
    changed = False
    suf = _longest(w, ("eza ezas ico ica icos icas ismo ismos ável ível ista istas oso osa osos osas amento amentos "
                       "imento imentos adora ador aça~o adoras adores aço~es ante antes ância logia logias ução "
                       "uções ência ências amente mente idade idades iva ivo ivas ivos ira iras").replace("aça~o", "ação").replace("aço~es", "ações").split())
    if suf:
        base = w[:-len(suf)]
        pos = len(base)
        if suf == "amente":
            if pos >= r1:
                w = base; changed = True
                t = _longest(w, ("iv", "os", "ic", "ad"), r2)
                if t:
                    w = w[:-len(t)]
                    if t == "iv" and w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        elif suf == "mente":
            if pos >= r2:
                w = base; changed = True
                t = _longest(w, ("ante", "avel", "ível"), r2)
                if t:
                    w = w[:-len(t)]
        elif suf in ("logia", "logias"):
            if pos >= r2:
                w = base + "log"; changed = True
        elif suf in ("ução", "uções"):
            if pos >= r2:
                w = base + "u"; changed = True
        elif suf in ("ência", "ências"):
            if pos >= r2:
                w = base + "ente"; changed = True
        elif suf in ("idade", "idades"):
            if pos >= r2:
                w = base; changed = True
                t = _longest(w, ("abil", "ic", "iv"), r2)
                if t:
                    w = w[:-len(t)]
        elif suf in ("iva", "ivo", "ivas", "ivos"):
            if pos >= r2:
                w = base; changed = True
                if w.endswith("at") and len(w) - 2 >= r2:
                    w = w[:-2]
        elif suf in ("ira", "iras"):
            if pos >= rv and base.endswith("e"):
                w = base[:-1] + "ir"; changed = True
        else:
            if pos >= r2:
                w = base; changed = True
                if suf in ("ação", "ações", "adora", "ador", "adoras", "adores", "ante", "antes", "ância"):
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
    if not changed:
        t = _longest(w, ("ada idas ia ara iam ado ido ar er ir as ado ando endo indo ara era ira ava iram "
                         "aram eram ariam eriam iriam asse esse isse aste este iste ei arei erei irei am em "
                         "amos emos imos ou ia ias ado ados ada adas ido idos ida idas ará erá irá ará").split(), rv)
        if t:
            w = w[:-len(t)]
    if changed or True:
        t = _longest(w, ("os", "a", "i", "o", "á", "í", "ó"), rv)
        if t:
            w = w[:-len(t)]
        t = _longest(w, ("e", "é", "ê"), rv)
        if t:
            w = w[:-len(t)]
            if w.endswith(("gu", "ci")) and len(w) - 1 >= rv:
                w = w[:-1]
        if w.endswith("ç"):
            w = w[:-1] + "c"
    return w.replace("a~", "ã").replace("o~", "õ")


# ------------- light fallbacks -------------
def _light(sufs, minlen=3):
    sufs = sorted(sufs, key=len, reverse=True)

    def f(w):
        for s in sufs:
            if w.endswith(s) and len(w) - len(s) >= minlen:
                return w[:-len(s)]
        return w
    return f


finnish = _light("ssa ssä sta stä lla llä lta ltä lle ksi ina inä a ä n t s".split(), 3)
hungarian = _light("ban ben ból ből ba be ra re on en ön hoz hez höz nak nek tól től val vel ok ek ök k t".split(), 3)
romanian = _light("ului ilor ele ei ii ul le a e i".split(), 3)
_ar_pre = ("وال", "بال", "كال", "فال", "ال", "لل", "و")
_ar_suf = ("ات", "ون", "ين", "ان", "ها", "هم", "ة", "ه", "ي")


def arabic(w):
    for p in _ar_pre:
        if w.startswith(p) and len(w) - len(p) >= 3:
            w = w[len(p):]
            break
    for s in _ar_suf:
        if w.endswith(s) and len(w) - len(s) >= 3:
            w = w[:-len(s)]
            break
    return w
