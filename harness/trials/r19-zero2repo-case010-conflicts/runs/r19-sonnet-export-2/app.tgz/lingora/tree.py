"""Constituent trees.  # spec: N-000481 N-000482"""
import re


class Tree(list):
    def __init__(self, label, children=None):
        if children is None or isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list of children")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def copy(self, deep=False):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    def height(self):
        h = 1
        for c in self:
            h = max(h, 1 + (c.height() if isinstance(c, Tree) else 1))
        return h

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            else:
                s += "\n" + " " * (indent + 2) + _leaf(c)
        return s + ")"

    def _flat(self):
        parts = []
        for c in self:
            parts.append(c._flat() if isinstance(c, Tree) else _leaf(c))
        return "(%s%s)" % (self._label, (" " + " ".join(parts)) if parts else "")

    pformat_flat = _flat

    @classmethod
    def fromstring(cls, s, brackets="()"):
        o, c = re.escape(brackets[0]), re.escape(brackets[1])
        tok = re.compile(r"%s\s*[^\s%s%s]*|%s|[^\s%s%s]+" % (o, o, c, c, o, c))
        toks = tok.findall(s)
        if not toks or not toks[0].startswith(brackets[0]):
            raise ValueError("Tree.fromstring: expected %r" % brackets[0])
        stack = []
        result = None
        for t in toks:
            if t.startswith(brackets[0]):
                stack.append((t[1:].strip(), []))
            elif t == brackets[1]:
                if not stack:
                    raise ValueError("Tree.fromstring: unexpected close")
                label, kids = stack.pop()
                node = cls(label, kids)
                if stack:
                    stack[-1][1].append(node)
                else:
                    if result is not None:
                        raise ValueError("Tree.fromstring: extra text")
                    result = node
            else:
                if not stack:
                    raise ValueError("Tree.fromstring: leaf outside tree")
                stack[-1][1].append(t)
        if stack or result is None:
            raise ValueError("Tree.fromstring: unbalanced brackets")
        return result


def _leaf(c):
    if isinstance(c, tuple) and len(c) == 2:
        return "%s/%s" % c
    return str(c)
