"""Porter stemmer (Porter 1980) with Martin / LINGORA (NLTK-style) extensions."""
import re

ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
NLTK_EXTENSIONS = "NLTK_EXTENSIONS"

_IRREGULAR = {
    "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
    "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
    "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
    "exceed": ["exceed"], "succeed": ["succeed"],
}


class PorterStemmer:
    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS):
            raise ValueError("Mode must be one of ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS")
        self.mode = mode
        self.pool = {}
        for key, forms in _IRREGULAR.items():
            for f in forms:
                self.pool[f] = key

    def _cons(self, word, i):
        if word[i] in "aeiou":
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._cons(word, i - 1)
        return True

    def _measure(self, stem):
        seq = "".join("c" if self._cons(stem, i) else "v" for i in range(len(stem)))
        return seq.count("vc")

    def _pm(self, stem):
        return self._measure(stem) > 0

    def _has_vowel(self, stem):
        return any(not self._cons(stem, i) for i in range(len(stem)))

    def _double_cons(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._cons(word, len(word) - 1)

    def _cvc(self, word):
        return ((len(word) >= 3 and self._cons(word, len(word) - 3) and not self._cons(word, len(word) - 2)
                 and self._cons(word, len(word) - 1) and word[-1] not in "wxy")
                or (self.mode == NLTK_EXTENSIONS and len(word) == 2 and not self._cons(word, 0)
                    and self._cons(word, 1)))

    @staticmethod
    def _rep(word, suffix, repl):
        return word[:len(word) - len(suffix)] + repl if suffix else word + repl

    def _apply(self, word, rules):
        for suffix, repl, cond in rules:
            if suffix == "*d" and self._double_cons(word):
                stem = word[:-2]
                if cond is None or cond(stem):
                    return stem + repl
                return word
            elif suffix != "*d" and word.endswith(suffix):
                stem = self._rep(word, suffix, "")
                if cond is None or cond(stem):
                    return stem + repl
                return word
        return word

    def _step1a(self, word):
        if self.mode == NLTK_EXTENSIONS and word.endswith("ies") and len(word) == 4:
            return self._rep(word, "ies", "ie")
        return self._apply(word, [("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == NLTK_EXTENSIONS and word.endswith("ied"):
            return self._rep(word, "ied", "ie" if len(word) == 4 else "i")
        if word.endswith("eed"):
            stem = self._rep(word, "eed", "")
            return stem + "ee" if self._measure(stem) > 0 else word
        ok = False
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._rep(word, suffix, "")
                if self._has_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        last = inter[-1]
        return self._apply(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", last, lambda s: last not in ("l", "s", "z")),
            ("", "e", lambda s: self._measure(s) == 1 and self._cvc(s)),
        ])

    def _step1c(self, word):
        if self.mode == NLTK_EXTENSIONS:
            cond = lambda s: len(s) > 1 and self._cons(s, len(s) - 1)
        else:
            cond = self._has_vowel
        return self._apply(word, [("y", "i", cond)])

    def _step2(self, word):
        pm = self._pm
        if self.mode == NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._rep(word, "alli", "")):
                return self._step2(self._rep(word, "alli", "al"))
        bli = ("bli", "ble", pm)
        abli = ("abli", "able", pm)
        rules = [("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm), ("anci", "ance", pm),
                 ("izer", "ize", pm), abli if self.mode == ORIGINAL_ALGORITHM else bli,
                 ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm), ("ousli", "ous", pm),
                 ("ization", "ize", pm), ("ation", "ate", pm), ("ator", "ate", pm), ("alism", "al", pm),
                 ("iveness", "ive", pm), ("fulness", "ful", pm), ("ousness", "ous", pm), ("aliti", "al", pm),
                 ("iviti", "ive", pm), ("biliti", "ble", pm)]
        if self.mode == NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda s: pm(word[:-3])))
        if self.mode == MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply(word, rules)

    def _step3(self, word):
        pm = self._pm
        return self._apply(word, [("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm),
                                  ("iciti", "ic", pm), ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        gt1 = lambda s: self._measure(s) > 1
        rules = [(x, "", gt1) for x in ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent")]
        rules.append(("ion", "", lambda s: self._measure(s) > 1 and s[-1:] in ("s", "t")))
        rules += [(x, "", gt1) for x in ("ou", "ism", "ate", "iti", "ous", "ive", "ize")]
        return self._apply(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = word[:-1]
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply(word, [("ll", "l", lambda s: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        for step in (self._step1a, self._step1b, self._step1c, self._step2, self._step3,
                     self._step4, self._step5a, self._step5b):
            stem = step(stem)
        return stem


_LANCASTER_RULES = """ai*2. a*1. bb1. city3s. ci2> cn1j< dd1. dei3y> deec2ss. dee1. de2> dooh4> e1> feil1v. fi2> gni3> gai3y. ga2> gg1. ht*2. hsiug5ct. hsi3> i*1. i1y> ji1d. juf1s. ju1d. jo1d. jeh1r. jrev1t. jsim2t. jn1d. j1s. lbaifi6. lbai4y. lba3> lbi3. lib2l> lc1. lufi4y. luf3> lu2. lai3> lau3> la2> ll1. mui3. mu*2. msi3> mm1. nois4j> noix4ct. noi3> nai3> na2> nee0. ne2> nn1. pihs4> pp1. re2> rae0. ra2. ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2> ssen4> ss0. suo3> su*2. s*1> s0. tacilp4y. ta2> tnem4> tne3> tna3> tpir2b. tpro2b. tcud1. tpmus2. tpec2iv. tulo2v. tsis0. tsi3> tt1. uqi3. ugo1. vis3j> vie0. vi2> ylb1> yli3y> ylp0. yl2> ygo1. yhp1. ymo1. ypo1. yti3> yte3> ytl2. yrtsi5. yra3> yro3> yfi3. ycn2t> yca3> zi2> zy1s.""".split()


class LancasterStemmer:
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        for rule in (rule_tuple or _LANCASTER_RULES):
            self.rule_dictionary.setdefault(rule[0], []).append(rule)
        self._valid = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def stem(self, word):
        word = word.lower()
        if self._strip_prefix:
            for p in ("kilo", "micro", "milli", "intra", "ultra", "mega", "nano", "pico", "pseudo"):
                if word.startswith(p):
                    word = word[len(p):]
                    break
        intact = word
        proceed = True
        while proceed:
            last = -1
            for i in range(len(word) - 1, -1, -1):
                if "a" <= word[i] <= "z":
                    last = i
                    break
            if last < 0 or word[last] not in self.rule_dictionary:
                break
            applied = False
            for rule in self.rule_dictionary[word[last]]:
                m = self._valid.match(rule)
                if not m:
                    continue
                ending, intact_flag, remove, append, cont = m.groups()
                remove = int(remove)
                if word.endswith(ending[::-1]):
                    if intact_flag:
                        if word == intact and self._acceptable(word, remove):
                            word = word[:len(word) - remove] + append
                            applied = True
                            if cont == ".":
                                proceed = False
                            break
                    elif self._acceptable(word, remove):
                        word = word[:len(word) - remove] + append
                        applied = True
                        if cont == ".":
                            proceed = False
                        break
            if not applied:
                break
        return word
