"""Punkt sentence boundary detection (Kiss & Strunk 2006)."""
import os
import re

from . import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

SENT_END_CHARS = (".", "?", "!")
_NON_WORD = r"(?:[)\";}\]\*:@\'\({\[])"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_RE = re.compile(
    r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )""" % {"MultiChar": _MULTI, "WordStart": _WORD_START, "NonWord": _NON_WORD},
    re.UNICODE | re.VERBOSE)
_PERIOD_CONTEXT_RE = re.compile(
    r"""
        [.?!]
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))""" % {"NonWord": _NON_WORD}, re.UNICODE | re.VERBOSE)
_BOUNDARY_RE = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"^\.\.+$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$")
_RE_ALPHA = re.compile(r"^[^\W\d]+$")


class _Tok:
    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        t = _RE_NUMERIC.sub("##number##", tok.lower())
        self.type = t
        self.period_final = tok.endswith(".")
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_ellipsis = bool(_RE_ELLIPSIS.match(tok))
        self.is_initial = bool(_RE_INITIAL.match(tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type


class PunktParams:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def _load(directory):
    p = PunktParams()
    def rd(name):
        fp = os.path.join(directory, name)
        if not os.path.isfile(fp):
            return []
        return data.read_lines(fp)
    p.abbrev_types = set(l for l in rd("abbrev_types.txt") if l != "")
    p.sent_starters = set(l for l in rd("sent_starters.txt") if l != "")
    for l in rd("collocations.tab"):
        parts = l.split("\t")
        if len(parts) >= 2:
            p.collocations.add((parts[0], parts[1]))
    for l in rd("ortho_context.tab"):
        parts = l.split("\t")
        if len(parts) >= 2:
            p.ortho_context[parts[0]] = int(parts[1])
    return p


def _pair_iter(items):
    it = iter(items)
    try:
        prev = next(it)
    except StopIteration:
        return
    for el in it:
        yield prev, el
        prev = el
    yield prev, None


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._p = params

    @classmethod
    def for_language(cls, language="english"):
        if not isinstance(language, str) or not language or "/" in language or "\\" in language or language.startswith("."):
            raise ValueError("invalid language %r" % (language,))
        d = data.find("tokenizers/punkt_tab/%s" % language)
        if not os.path.isdir(d):
            raise LookupError("Punkt model for %r is not a directory" % language)
        return cls(_load(d))

    # tokenisation
    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = iter(_WORD_RE.findall(line))
                try:
                    tok = next(toks)
                except StopIteration:
                    continue
                yield _Tok(tok, parastart=parastart, linestart=True)
                parastart = False
                for tok in toks:
                    yield _Tok(tok)
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        if tok in SENT_END_CHARS:
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if (tok[:-1].lower() in self._p.abbrev_types
                    or tok[:-1].lower().split("-")[-1] in self._p.abbrev_types):
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho(self, tok):
        if tok.tok in tuple(";:,.!?"):
            return False
        oc = self._p.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            s = self._ortho(t2)
            if s is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            s = self._ortho(t2)
            if s is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (s == "unknown" and initial and t2.first_upper
                    and not (self._p.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for a, b in _pair_iter(toks):
            self._second_pass(a, b)
        return toks

    def _contains_break(self, text):
        found = False
        for tok in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    def _match_contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _PERIOD_CONTEXT_RE.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = 0
            for i in range(len(before) - 1, -1, -1):
                if before[i].isspace():
                    idx = i
                    break
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, match.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, ctx in self._match_contexts(text):
            if self._contains_break(ctx):
                yield (last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        realign = 0
        for s1, s2 in _pair_iter(slices):
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _BOUNDARY_RE.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text):
        return list(self._realign(text, self._slices(text)))

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]


_cache = {}


def get_tokenizer(language):
    d = None
    try:
        d = data.find("tokenizers/punkt_tab/%s" % language) if isinstance(language, str) else None
    except LookupError:
        d = None
    if d is None:
        raise LookupError("Punkt model for language %r is not available on data.path" % (language,))
    key = (d, os.path.getmtime(d))
    if key not in _cache:
        _cache[key] = PunktSentenceTokenizer.for_language(language)
    return _cache[key]
