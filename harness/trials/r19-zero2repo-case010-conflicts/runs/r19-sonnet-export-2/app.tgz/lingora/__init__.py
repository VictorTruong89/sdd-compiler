"""Lingora Language Toolkit."""
from . import data, tree  # noqa
__version__ = "1.0"
