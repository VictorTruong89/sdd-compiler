"""Snowball stemmers: German, Dutch, Swedish, Norwegian, Danish."""


def _regions(w, vowels, min_r1=0):
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r1 = i + 1
            break
    r1 = max(r1, min_r1) if min_r1 else r1
    r1 = min(r1, len(w))
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def _longest(w, sufs, start=0):
    best = None
    for s in sufs:
        if w.endswith(s) and len(w) - len(s) >= start and (best is None or len(s) > len(best)):
            best = s
    return best


# ---------------- German ----------------
_DE_V = "aeiouyäöü"


def german(w):
    w = w.replace("ß", "ss")
    c = list(w)
    for i in range(1, len(c) - 1):
        if c[i - 1] in _DE_V and c[i + 1] in _DE_V:
            if c[i] == "u":
                c[i] = "U"
            elif c[i] == "y":
                c[i] = "Y"
    w = "".join(c)
    r1, r2 = _regions(w, _DE_V, 3)
    # step 1
    s = _longest(w, ("ern", "em", "er", "en", "es", "e", "s"), r1)
    if s in ("ern", "em", "er"):
        w = w[:-len(s)]
    elif s in ("en", "es", "e"):
        w = w[:-len(s)]
        if w.endswith("niss"):
            w = w[:-1]
    elif s == "s":
        if w[:-1][-1:] and w[-2] in "bdfghklmnrt":
            w = w[:-1]
    # step 2
    s = _longest(w, ("est", "en", "er", "st"), r1)
    if s in ("est", "en", "er"):
        w = w[:-len(s)]
    elif s == "st":
        if len(w) >= 6 and w[-3] in "bdfghklmnt":
            w = w[:-2]
    # step 3
    s = _longest(w, ("keit", "lich", "heit", "end", "ung", "isch", "ig", "ik"), r2)
    if s in ("end", "ung"):
        w = w[:-len(s)]
        if w.endswith("ig") and len(w) - 2 >= r2 and w[-3:-2] != "e":
            w = w[:-2]
    elif s in ("ig", "ik", "isch"):
        if w[-len(s) - 1:-len(s)] != "e":
            w = w[:-len(s)]
    elif s in ("lich", "heit"):
        w = w[:-len(s)]
        t = _longest(w, ("er", "en"), r1)
        if t:
            w = w[:-len(t)]
    elif s == "keit":
        w = w[:-4]
        t = _longest(w, ("lich", "ig"), r2)
        if t:
            w = w[:-len(t)]
    w = w.replace("U", "u").replace("Y", "y")
    return w.replace("ä", "a").replace("ö", "o").replace("ü", "u")


# ---------------- Dutch ----------------
_NL_V = "aeiouyè"


def _undouble_nl(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


def dutch(w):
    for a, b in zip("äëïöüáéíóú", "aeiouaeiou"):
        w = w.replace(a, b)
    if w.startswith("y"):
        w = "Y" + w[1:]
    c = list(w)
    for i in range(1, len(c)):
        if c[i] == "y" and c[i - 1] in _NL_V:
            c[i] = "Y"
    for i in range(1, len(c) - 1):
        if c[i] == "i" and c[i - 1] in _NL_V and c[i + 1] in _NL_V:
            c[i] = "I"
    w = "".join(c)
    r1, r2 = _regions(w, _NL_V + "IY", 3)
    vow = _NL_V + "IY"
    # step 1
    s = _longest(w, ("heden", "ene", "en", "se", "s"), r1)
    if s == "heden":
        w = w[:-5] + "heid"
    elif s in ("en", "ene"):
        p = w[:-len(s)]
        if p and p[-1] not in vow and not p.endswith("gem"):
            w = _undouble_nl(p)
    elif s in ("se", "s"):
        p = w[:-len(s)]
        if p and p[-1] not in vow and p[-1] != "j":
            w = p
    # step 2
    e_removed = False
    if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] not in vow:
        w = _undouble_nl(w[:-1])
        e_removed = True
    # step 3a
    if w.endswith("heid") and len(w) - 4 >= r2 and w[-5:-4] != "c":
        w = w[:-4]
        if w.endswith("en") and len(w) - 2 >= r1 and len(w) > 2 and w[-3] not in vow and not w[:-2].endswith("gem"):
            w = _undouble_nl(w[:-2])
    # step 3b
    s = _longest(w, ("lijk", "baar", "end", "ing", "ig", "bar"), r2)
    if s in ("end", "ing"):
        w = w[:-3]
        if w.endswith("ig") and len(w) - 2 >= r2 and w[-3:-2] != "e":
            w = w[:-2]
        else:
            w = _undouble_nl(w)
    elif s == "ig":
        if w[-3:-2] != "e":
            w = w[:-2]
    elif s == "lijk":
        w = w[:-4]
        if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] not in vow:
            w = _undouble_nl(w[:-1])
    elif s == "baar":
        w = w[:-4]
    elif s == "bar" and e_removed:
        w = w[:-3]
    # step 4
    if len(w) >= 4 and w[-1] not in vow and w[-1] != "I" and w[-2] == w[-3] and w[-2] in "aeou" and w[-4] not in vow:
        w = w[:-2] + w[-1]
    return w.replace("Y", "y").replace("I", "i")


# ---------------- Swedish ----------------
_SV_V = "aeiouyäåö"


def swedish(w):
    r1, _ = _regions(w, _SV_V, 3)
    s = _longest(w, ("heterna hetens heter heten anden arnas ernas ornas andes andet arens arna erna orna "
                     "ande arne aste aren ades erns ade are ern ens het ast ad en ar er or as es at a e").split(), r1)
    if s:
        w = w[:-len(s)]
    elif w.endswith("s") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] in "bcdfghjklmnoprtvy":
        w = w[:-1]
    if len(w) >= r1 + 1 and w.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")) and len(w) - 1 >= r1:
        w = w[:-1]
    s = _longest(w, ("lig", "ig", "els"), r1)
    if s:
        w = w[:-len(s)]
    elif w.endswith("löst") and len(w) - 4 >= r1:
        w = w[:-1]
    elif w.endswith("fullt") and len(w) - 5 >= r1:
        w = w[:-1]
    return w


# ---------------- Danish ----------------
_DA_V = "aeiouyæåø"


def danish(w):
    r1, _ = _regions(w, _DA_V, 3)
    s = _longest(w, ("hed ethed ered e erede ende erende ene erne ere en heden eren er heder erer heds es "
                     "endes erendes enes ernes eres ens hedens erens ers ets erets et eret").split(), r1)
    if s:
        w = w[:-len(s)]
    elif w.endswith("s") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] in "abcdfghjklmnoprtvyzå":
        w = w[:-1]
    if w.endswith("erne") is False:
        pass
    # step 2
    def s2(x):
        if len(x) - 1 >= r1 and x.endswith(("gd", "dt", "gt", "kt")):
            return x[:-1]
        return x
    w = s2(w)
    # step 3
    changed = False
    if w.endswith("igst") and len(w) - 4 >= r1:
        w = w[:-2]
    t = _longest(w, ("elig", "lig", "ig", "els"), r1)
    if t:
        w = w[:-len(t)]
        changed = True
    elif w.endswith("løst") and len(w) - 4 >= r1:
        w = w[:-1]
    if changed:
        w = s2(w)
    # step 4
    if len(w) - 1 >= r1 and len(w) >= 2 and w[-1] == w[-2] and w[-1] not in _DA_V:
        w = w[:-1]
    return w


# ---------------- Norwegian ----------------
_NO_V = "aeiouyæåø"


def norwegian(w):
    r1, _ = _regions(w, _NO_V, 3)
    s = _longest(w, ("a e ede ande ende ane ene hetene en heten ar er heter as es edes endes enes hetenes "
                     "ens hetens ers ets et het ast").split(), r1)
    if s:
        w = w[:-len(s)]
    elif w.endswith("s") and len(w) - 1 >= r1:
        if len(w) > 1 and (w[-2] in "bcdfghjlmnoprtvyz" or (w[-2] == "k" and len(w) > 2 and w[-3] not in _NO_V)):
            w = w[:-1]
    else:
        t = _longest(w, ("erte", "ert"), r1)
        if t:
            w = w[:-len(t)] + "er"
    if len(w) - 1 >= r1 and w.endswith(("dt", "vt")):
        w = w[:-1]
    t = _longest(w, ("leg", "elig", "eig", "lig", "els", "lov", "ig"), r1)
    if t:
        w = w[:-len(t)]
    return w
