"""Parsers."""
from ..grammar import Nonterminal
from ..tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser", "RecursiveDescentParser"]


def _check(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    missing = [t for t in tokens if t not in known]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r"
                         % (missing,))


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar
        self._prods = {}
        for p in grammar.productions():
            self._prods.setdefault(p.lhs(), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        _check(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        active = set()
        taint = [0]

        def sym_trees(sym, i, j):
            """Yield lists of children for symbol over [i,j)."""
            if isinstance(sym, Nonterminal):
                return [[t] for t in nt_trees(sym, i, j)]
            if sym == "":
                return [[]] if i == j else []
            if j == i + 1 and tokens[i] == sym:
                return [[sym]]
            return []

        def nt_trees(nt, i, j):
            key = (nt, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                taint[0] += 1
                return []
            active.add(key)
            before = taint[0]
            res = []
            for p in self._prods.get(nt, []):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append(tree_class(str(nt), kids))
            active.discard(key)
            if taint[0] == before:
                memo[key] = res
            return res

        def seq(rhs, k, i, j):
            if k == len(rhs):
                return [[]] if i == j else []
            out = []
            last = k == len(rhs) - 1
            ends = [j] if last else range(i, j + 1)
            for m in ends:
                for first in sym_trees(rhs[k], i, m):
                    for rest in seq(rhs, k + 1, m, j):
                        out.append(first + rest)
            return out

        return iter(nt_trees(self._grammar.start(), 0, n))


class RecursiveDescentParser(ChartParser):
    pass


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def _match(self, stack, rhs):
        k = len(rhs)
        if k == 0 or len(stack) < k:
            return False
        for s, r in zip(stack[-k:], rhs):
            if isinstance(r, Nonterminal):
                if not (isinstance(s, Tree) and s.label() == str(r)):
                    return False
            else:
                if not (isinstance(s, str) and s == r):
                    return False
        return True

    def parse(self, tokens):
        _check(self._grammar, tokens)
        stack = []
        remaining = list(tokens)
        prods = self._grammar.productions()
        while True:
            for p in prods:
                if self._match(stack, p.rhs()):
                    k = len(p.rhs())
                    kids = stack[-k:]
                    del stack[-k:]
                    stack.append(Tree(str(p.lhs()), kids))
                    break
            else:
                if remaining:
                    stack.append(remaining.pop(0))
                else:
                    break
        if (not remaining and len(stack) == 1 and isinstance(stack[0], Tree)
                and stack[0].label() == str(self._grammar.start())):
            return iter([stack[0]])
        return iter([])
