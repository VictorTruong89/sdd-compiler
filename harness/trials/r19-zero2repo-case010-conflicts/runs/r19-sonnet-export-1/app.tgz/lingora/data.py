"""Packaged-resource finder. # spec: N-000385"""
import os

# spec: N-000385 -- mutable list of directories searched for resources.
path = [
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "lingora_data"),
    os.path.join(os.path.expanduser("~"), "lingora_data"),
]
_env = os.environ.get("LINGORA_DATA")
if _env:
    path[:0] = [p for p in _env.split(os.pathsep) if p]


def find(name):
    """Return the filesystem path of resource `name` (relative to a directory
    on `path`), or None if it is not visible. Looked up on every call."""
    for base in list(path):
        cand = os.path.join(str(base), *name.strip("/").split("/"))
        if os.path.exists(cand):
            return cand
    return None


def require(name):
    p = find(name)
    if p is None:
        raise LookupError("Resource %r not found in lingora.data.path" % name)
    return p


def read_lines(filename):
    with open(filename, encoding="utf-8") as f:
        text = f.read()
    return text.splitlines()
