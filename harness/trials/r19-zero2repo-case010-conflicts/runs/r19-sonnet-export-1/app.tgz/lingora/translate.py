"""Translation metrics."""
import math
import sys
from collections import Counter
from fractions import Fraction

__all__ = ["bleu"]


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    clipped = {g: min(c, max_counts.get(g, 0)) for g, c in counts.items()}
    num = sum(clipped.values())
    den = max(1, sum(counts.values()))
    return Fraction(num, den)


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    # spec: N-000513..N-000517 (default weights follow the PRD: 4 equal orders)
    if (isinstance(references, str) or not isinstance(references, (list, tuple))
            or isinstance(hypothesis, str) or not isinstance(hypothesis, (list, tuple))):
        raise TypeError("references must be a list of token lists, hypothesis a token list")
    for r in references:
        if isinstance(r, str) or not isinstance(r, (list, tuple)):
            raise TypeError("each reference must be a list of tokens")
    if not references:
        raise ValueError("at least one reference is required")
    weights = tuple(weights)
    p_n = [_modified_precision(references, hypothesis, i) for i, _ in enumerate(weights, start=1)]
    if not p_n or p_n[0].numerator == 0:
        return 0
    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))
    if hyp_len == 0:
        return 0
    bp = 1 if hyp_len > ref_len else math.exp(1 - ref_len / hyp_len)
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    else:
        p_n = [p if p.numerator != 0 else sys.float_info.min for p in p_n]
    s = (w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))
