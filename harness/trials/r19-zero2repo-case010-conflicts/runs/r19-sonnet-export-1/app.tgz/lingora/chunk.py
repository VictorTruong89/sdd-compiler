"""Chunking."""
import os
import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

_ROOT = "S"


def _tag_pattern_to_re(pat):
    pat = re.sub(r"\s", "", pat)
    out = []
    depth = 0
    i = 0
    while i < len(pat):
        c = pat[i]
        if c == "\\" and i + 1 < len(pat):
            out.append(pat[i:i + 2])
            i += 2
            continue
        if c == "<" and depth == 0:
            depth = 1
            out.append("(<(")
        elif c == ">" and depth == 1:
            depth = 0
            out.append(")>)")
        elif c == "." and depth == 1:
            out.append("[^{}<>]")
        else:
            out.append(c)
        i += 1
    rx = "".join(out)
    try:
        re.compile(rx)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (pat, e))
    return rx


class _Rule:
    def __init__(self, kind, tag_pattern):
        self.kind = kind
        rx = _tag_pattern_to_re(tag_pattern)
        if kind == "chunk":
            self.regexp = re.compile(r"(?P<chunk>%s)(?=[^\{\}]*(\{|$))" % rx)
            self.repl = r"{\g<chunk>}"
        else:
            self.regexp = re.compile(r"(?P<chink>%s)(?=[^\{]*\})" % rx)
            self.repl = r"}\g<chink>{"

    def apply(self, s):
        return self.regexp.sub(self.repl, s)


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def parse(self, pieces):
        # pieces: list of (token,tag) pairs or Trees
        tags = []
        for p in pieces:
            if isinstance(p, Tree):
                tags.append(str(p.label()))
            else:
                tags.append(str(p[1]))
        for t in tags:
            if any(ch in t for ch in "<>{}"):
                raise ValueError("Tag %r contains illegal characters" % t)
        s = "".join("<%s>" % t for t in tags)
        for r in self.rules:
            s = r.apply(s)
        out = []
        idx = 0
        in_chunk = False
        for piece in re.split("[{}]", s):
            n = piece.count("<")
            sub = pieces[idx:idx + n]
            if in_chunk:
                if sub:
                    out.append(Tree(self.label, sub))
            else:
                out.extend(sub)
            idx += n
            in_chunk = not in_chunk
        return out


class RegexpParser:
    def __init__(self, grammar, root_label=_ROOT, loop=1):
        if isinstance(grammar, str):
            self._stages = self._read(grammar)
        elif isinstance(grammar, (list, tuple)) and all(hasattr(g, "parse") for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")
        self._root = root_label
        self._loop = loop

    @staticmethod
    def _read(text):
        stages = []
        label = None
        rules = []
        clause_re = re.compile(r"^\s*([^\s:{}]+)\s*:\s*(.*)$")

        def flush():
            if label is not None:
                stages.append(_Stage(label, rules[:]))

        for raw in text.split("\n"):
            line = raw.split("#")[0].rstrip()
            if not line.strip():
                continue
            stripped = line.strip()
            m = clause_re.match(line) if not raw[:1].isspace() or not (stripped[0] in "{}") else None
            if m and stripped[0] not in "{}":
                flush()
                label = m.group(1)
                rules = []
                rest = m.group(2).strip()
                if rest:
                    rules.append(RegexpParser._rule(rest))
            else:
                if label is None:
                    raise ValueError("Illegal chunk grammar line: %r" % raw)
                rules.append(RegexpParser._rule(stripped))
        flush()
        if not stages:
            raise ValueError("Empty chunk grammar")
        return stages

    @staticmethod
    def _rule(s):
        s = s.strip()
        if s.startswith("{") and s.endswith("}") and len(s) >= 2:
            return _Rule("chunk", s[1:-1])
        if s.startswith("}") and s.endswith("{") and len(s) >= 2:
            return _Rule("chink", s[1:-1])
        raise ValueError("Illegal chunk rule: %r" % s)

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        pieces = []
        for p in tagged:
            if isinstance(p, Tree):
                pieces.append(p)
                continue
            if not isinstance(p, (tuple, list)) or len(p) != 2:
                raise ValueError("Each item must be a (token, tag) pair")
            pieces.append(tuple(p))
        for _ in range(self._loop):
            for st in self._stages:
                pieces = st.parse(pieces)
        return Tree(self._root, pieces)


def ne_chunk(tagged_tokens, binary=False):
    ne = data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    words = data.find("corpora/words")
    if ne is None or not os.path.isdir(ne):
        raise LookupError("Named-entity chunker model not found in lingora.data.path")
    if words is None:
        raise LookupError("English wordlist not found in lingora.data.path")
    if isinstance(tagged_tokens, str):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    # The trained maximum-entropy model is not interpreted; entities are not grouped.
    return Tree(_ROOT, [tuple(t) for t in tagged_tokens])
