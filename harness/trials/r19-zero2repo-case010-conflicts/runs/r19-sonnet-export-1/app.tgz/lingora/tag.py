"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger",
           "TrigramTagger", "AffixTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def tag(self, tokens):
        _check_tokens(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            if isinstance(self._backoff, SequentialBackoffTagger):
                tag = self._backoff.tag_one(tokens, index, history)
            else:
                tag = self._backoff.tag(list(tokens))[index][1]
        return tag


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(r), t) for r, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    _N = 1

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        SequentialBackoffTagger.__init__(self, backoff)
        self._model = dict(model) if model else {}
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        return tokens[index]

    def _train(self, sents):
        counts = defaultdict(Counter)
        for sent in sents:
            toks = [w for w, _ in sent]
            hist = []
            for i, (w, t) in enumerate(sent):
                ctx = self.context(toks, i, hist)
                if ctx is not None:
                    counts[ctx][t] += 1
                hist.append(t)
        for ctx, c in counts.items():
            best = max(c.items(), key=lambda kv: (kv[1],))[0]
            # first-seen wins ties (Counter keeps insertion order)
            top = max(c.values())
            best = next(t for t, n in c.items() if n == top)
            if self._backoff is not None and False:
                pass
            self._model[ctx] = best

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._model.get(ctx)


class UnigramTagger(ContextTagger):
    pass


class BigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        prev = history[index - 1] if index > 0 and len(history) >= index else None
        if index == 0:
            prev = None
        return (prev, tokens[index])


class TrigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        p1 = history[index - 1] if index > 0 and len(history) >= index else None
        p2 = history[index - 2] if index > 1 and len(history) >= index - 1 else None
        return (p2, p1, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, model, backoff, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]


# ------------------------------------------------------ averaged perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


class PerceptronTagger:
    def __init__(self, lang):
        base = "taggers/averaged_perceptron_tagger_%s" % lang
        d = data.find(base)
        if d is None or not os.path.isdir(d):
            raise LookupError("Averaged perceptron tagger %r not found in lingora.data.path" % lang)
        stem = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(stem + ".weights.json", encoding="utf-8") as f:
                self.weights = json.load(f)
            with open(stem + ".tagdict.json", encoding="utf-8") as f:
                self.tagdict = json.load(f)
            with open(stem + ".classes.json", encoding="utf-8") as f:
                self.classes = set(json.load(f))
        except OSError as e:
            raise LookupError("Incomplete tagger model for %r: %s" % (lang, e))

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1
        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            w = self.weights.get(feat)
            if w is None or value == 0:
                continue
            for label, weight in w.items():
                scores[label] += value * weight
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [self.normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "SPRO": "PRON", "APRO": "DET",
    "ADVPRO": "ADV", "NUM": "NUM", "ANUM": "ADJ", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "INTJ": "X", "COM": "X", "NONLEX": ".", "PARENTH": "X",
    "PRAEDIC": "ADV", "PRAEDICPRO": "PRON", "A-PRO": "DET", "S-PRO": "PRON",
}


def _load_ptb_map():
    d = data.find("taggers/universal_tagset")
    fn = os.path.join(d, "en-ptb.map") if d else None
    if not fn or not os.path.isfile(fn):
        raise LookupError("Universal tagset tables not found in lingora.data.path")
    m = {}
    for line in data.read_lines(fn):
        parts = line.split("\t")
        if len(parts) == 2:
            m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, lingora pos_tag only supports English and Russian (lang='eng' or 'rus')")
    if tagset not in (None, "universal"):
        raise ValueError("Unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger(lang)
    mapping = None
    if tagset == "universal" and lang == "eng":
        mapping = _load_ptb_map()
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            tagged = [(w, mapping.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _RUS_UNIVERSAL.get(t.partition("=")[0], "X")) for w, t in tagged]
    return tagged
