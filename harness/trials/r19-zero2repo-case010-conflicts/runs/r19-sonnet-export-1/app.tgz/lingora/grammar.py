"""Context-free grammars."""
import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


def _parse_rhs(text, lineno):
    """Return list of alternatives (each a list of symbols)."""
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN_RE.match(text, pos)
        if not m or m.end() == pos:
            if text[pos:].strip() == "":
                break
            raise ValueError("Unable to parse grammar line %d: %r" % (lineno, text))
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            if isinstance(input, (list, tuple)):
                input = "\n".join(input)
            else:
                raise TypeError("grammar text must be a str")
        prods = []
        start = None
        lhs = None
        for no, raw in enumerate(input.split("\n"), 1):
            line = raw.split("#")[0] if "#" in raw and not re.search(r"""['"].*#.*['"]""", raw) else raw
            line = line.strip()
            if not line:
                continue
            if line.startswith("|"):
                if lhs is None:
                    raise ValueError("Unable to parse grammar line %d: %r" % (no, raw))
                alts = _parse_rhs(line, no)[1:]
            else:
                m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse grammar line %d: %r" % (no, raw))
                lhs = Nonterminal(m.group(1))
                if start is None:
                    start = lhs
                alts = _parse_rhs(m.group(2), no)
            for a in alts:
                prods.append(Production(lhs, a))
        if start is None:
            raise ValueError("No productions in grammar text")
        return cls(start, prods)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__
