"""Punkt sentence-boundary detection using packaged parameters."""
import os
import re
import string

from . import data

_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_UC = 14
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_LC = 112

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"

_WORD_RE = re.compile(
    r"""(
        %(Multi)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(Multi)s|
            ,(?=$|\s|%(NonWord)s|%(Multi)s)
        )
        |
        \S
    )""" % {"Multi": _MULTI, "WordStart": _WORDSTART, "NonWord": _NONWORD},
    re.UNICODE | re.VERBOSE,
)

_PERIOD_RE = re.compile(
    r"""
    [.?!]
    (?=(?P<after_tok>
        %(NonWord)s
        |
        \s+(?P<next_tok>\S+)
    ))""" % {"NonWord": _NONWORD},
    re.UNICODE | re.VERBOSE,
)

_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "parastart", "linestart", "sentbreak", "abbr", "ellipsis",
                 "period_final", "type", "first_upper", "first_lower", "is_initial")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.period_final = tok.endswith(".")
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_initial = bool(_RE_INITIAL.match(tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        if self.sentbreak:
            return self.type_no_period
        return self.type


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def load_parameters(directory):
    p = PunktParameters()

    def lines(name):
        fn = os.path.join(directory, name)
        if not os.path.isfile(fn):
            return []
        return data.read_lines(fn)

    p.abbrev_types = {l for l in lines("abbrev_types.txt") if l != ""}
    p.sent_starters = {l for l in lines("sent_starters.txt") if l != ""}
    for l in lines("collocations.tab"):
        parts = l.split("\t")
        if len(parts) == 2:
            p.collocations.add((parts[0], parts[1]))
    for l in lines("ortho_context.tab"):
        parts = l.split("\t")
        if len(parts) == 2:
            try:
                p.ortho_context[parts[0]] = int(parts[1])
            except ValueError:
                pass
    return p


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._params = params

    @classmethod
    def for_language(cls, language="english"):
        d = data.find("tokenizers/punkt_tab/%s" % language)
        if d is None or not os.path.isdir(d):
            raise LookupError(
                "Punkt model for %r not found in lingora.data.path" % (language,))
        return cls(load_parameters(d))

    # -- internals
    @staticmethod
    def _tokenize_words(text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = _WORD_RE.findall(line)
                if not toks:
                    continue
                yield _Tok(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for t in toks[1:]:
                    yield _Tok(t)
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        if tok in (".", "?", "!"):
            t.sentbreak = True
        elif _RE_ELLIPSIS.match(tok):
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            base = tok[:-1].lower()
            if base in self._params.abbrev_types or base.split("-")[-1] in self._params.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho(self, t):
        if t.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            s = self._ortho(t2)
            if s is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            s = self._ortho(t2)
            if s is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (s == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for t in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return 0

    def _potential(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for m, ctx in self._potential(text):
            if self._contains_sentbreak(ctx):
                yield (last, m.end())
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        n = len(slices)
        for k, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            if k + 1 >= n:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            s2 = slices[k + 1]
            m = _REALIGN.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text):
        for s in self._realign(text, self._slices(text)):
            yield s

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]
