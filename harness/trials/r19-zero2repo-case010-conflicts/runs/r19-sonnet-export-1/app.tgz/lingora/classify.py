"""Classifiers."""
import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "DictionaryProbDist"]


class DictionaryProbDist:
    """Probability distribution over labels."""

    def __init__(self, logprobs):
        m = max(logprobs.values()) if logprobs else 0.0
        exps = {k: math.exp(v - m) for k, v in logprobs.items()}
        total = sum(exps.values())
        self._p = {k: v / total for k, v in exps.items()}

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._p.keys())

    def max(self):
        best = None
        bp = -1.0
        for k, v in self._p.items():
            if v > bp:
                best, bp = k, v
        return best


def _check_labeled(ls):
    if isinstance(ls, (str, bytes)) or not hasattr(ls, "__iter__"):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    ls = list(ls)
    for item in ls:
        if not isinstance(item, (tuple, list)) or len(item) != 2 or not isinstance(item[0], dict):
            raise TypeError("each item must be a (featureset, label) pair with a dict featureset")
    if not ls:
        raise ValueError("cannot train on an empty list")
    return ls


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist   # label -> prob
        self._feature_probdist = feature_probdist  # (label, fname) -> (dict value->count, N, bins)
        self._labels = list(label_probdist)

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        label_freq = Counter()
        feat_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = set()
        for fs, label in labeled:
            label_freq[label] += 1
            for fname, fval in fs.items():
                feat_freq[(label, fname)][fval] += 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                c = sum(feat_freq[(label, fname)].values())
                if n - c > 0:
                    feat_freq[(label, fname)][None] += n - c
                    feature_values[fname].add(None)
        total = sum(label_freq.values())
        nl = len(label_freq)
        label_prob = {l: (c + 0.5) / (total + 0.5 * nl) for l, c in label_freq.items()}
        feat_prob = {}
        for (label, fname), cnt in feat_freq.items():
            feat_prob[(label, fname)] = (dict(cnt), sum(cnt.values()), len(feature_values[fname]))
        return cls(label_prob, feat_prob)

    def labels(self):
        return list(self._labels)

    def _fprob(self, label, fname, fval):
        cnt, n, bins = self._feature_probdist[(label, fname)]
        return (cnt.get(fval, 0) + 0.5) / (n + 0.5 * bins)

    def prob_classify(self, featureset):
        fs = dict(featureset)
        for fname in list(fs):
            if not any((l, fname) in self._feature_probdist for l in self._labels):
                del fs[fname]
        logprob = {}
        for label in self._labels:
            lp = math.log(self._label_probdist[label])
            for fname, fval in fs.items():
                if (label, fname) in self._feature_probdist:
                    lp += math.log(self._fprob(label, fname, fval))
            logprob[label] = lp
        return DictionaryProbDist(logprob)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        val = featureset.get(self._fname)
        if val in self._decisions:
            return self._decisions[val].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    @staticmethod
    def _majority(labeled):
        c = Counter(l for _, l in labeled)
        top = max(c.values())
        return next(l for l, n in c.items() if n == top)

    @classmethod
    def train(cls, labeled_featuresets, depth_cutoff=100):
        labeled = _check_labeled(labeled_featuresets)
        return cls._build(labeled, depth_cutoff)

    @classmethod
    def _build(cls, labeled, depth):
        label = cls._majority(labeled)
        if depth <= 0 or len({l for _, l in labeled}) == 1:
            return cls(label)
        fnames = []
        for fs, _ in labeled:
            for f in fs:
                if f not in fnames:
                    fnames.append(f)
        best = None
        base_ent = cls._entropy([l for _, l in labeled])
        for f in fnames:
            groups = defaultdict(list)
            for fs, l in labeled:
                groups[fs.get(f)].append((fs, l))
            if len(groups) < 2:
                continue
            err = sum(len(g) - max(Counter(l for _, l in g).values()) for g in groups.values())
            ent = sum(len(g) / len(labeled) * cls._entropy([l for _, l in g]) for g in groups.values())
            key = (err, ent)
            if best is None or key < best[0]:
                best = (key, f, groups)
        if best is None:
            return cls(label)
        _, f, groups = best
        decisions = {v: cls._build(g, depth - 1) for v, g in groups.items()}
        return cls(label, f, decisions, cls(label))

    @staticmethod
    def _entropy(labels):
        c = Counter(labels)
        n = len(labels)
        return -sum(v / n * math.log(v / n, 2) for v in c.values())


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    ok = sum(1 for fs, l in gold if classifier.classify(fs) == l)
    return ok / len(gold)
