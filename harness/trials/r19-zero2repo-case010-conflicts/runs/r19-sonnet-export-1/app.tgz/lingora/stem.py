"""Stemmers and lemmatizer."""
import os
import re

from . import data

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer",
           "RegexpStemmer", "SnowballStemmer", "WordNetLemmatizer"]


class PorterStemmer:
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("Mode must be one of the three Porter modes")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"],
                "tie": ["tying"], "news": ["news"],
                "inning": ["innings", "inning"], "outing": ["outings", "outing"],
                "canning": ["cannings", "canning"], "howe": ["howe"],
                "proceed": ["proceed"], "exceed": ["exceed"], "succeed": ["succeed"],
            }
            for k, vs in irregular.items():
                for v in vs:
                    self.pool[v] = k
        self.vowels = frozenset("aeiou")

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3
            and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS
            and len(word) == 2
            and not self._is_consonant(word, 0)
            and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [
            ("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            cond = lambda stem: len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)
        else:
            cond = self._contains_vowel
        return self._apply_rule_list(word, [("y", "i", cond)])

    def _step2(self, word):
        pm = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pm) if self.mode != self.ORIGINAL_ALGORITHM else ("abli", "able", pm)
        rules = [
            ("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm),
            ("anci", "ance", pm), ("izer", "ize", pm), bli,
            ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm),
            ("ousli", "ous", pm), ("ization", "ize", pm), ("ation", "ate", pm),
            ("ator", "ate", pm), ("alism", "al", pm), ("iveness", "ive", pm),
            ("fulness", "ful", pm), ("ousness", "ous", pm), ("aliti", "al", pm),
            ("iviti", "ive", pm), ("biliti", "ble", pm)]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda stem: pm(word[:-len("ogi")])))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm),
            ("iciti", "ic", pm), ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        m1 = lambda stem: self._measure(stem) > 1
        sfx = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent"]
        rules = [(s, "", m1) for s in sfx]
        rules.append(("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")))
        rules += [(s, "", m1) for s in ("ou", "ism", "ate", "iti", "ous", "ive", "ize")]
        return self._apply_rule_list(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        if word.endswith("ll") and self._measure(word[:-1]) > 1:
            return self._replace_suffix(word, "l", "")
        return word

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"


# ----------------------------------------------------------------- Lancaster
_LANCASTER_RULES = {
    "a": ["ia*", "a*"], 
}
# Rule syntax: <reversed ending>[*]<remove count><append string>(> | .)
_LANCASTER = {
    "a": ["ai*2.", "a*1."],
    "b": ["bb1."],
    "c": ["city3s.", "ci2>", "cn1t>"],
    "d": ["dd1.", "dei3y>", "deec2ss.", "dee1.", "de2>", "dooh4>"],
    "e": ["e1>"],
    "f": ["feil1v.", "fi2>"],
    "g": ["gni3>", "gai3y.", "ga2>", "gg1."],
    "h": ["ht*2.", "hsiug5ct.", "hsi3>"],
    "i": ["i*1.", "i1y>"],
    "j": ["ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s."],
    "l": ["lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3>",
          "lu2.", "lai3>", "lau3>", "la2>", "ll1."],
    "m": ["mui3.", "mu*2.", "msi3>", "mm1."],
    "n": ["nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1."],
    "p": ["pihs4>", "pp1."],
    "r": ["re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>"],
    "s": ["sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0."],
    "t": ["tacilp4y.", "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.",
          "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1."],
    "u": ["uqi3.", "ug1."],
    "v": ["vie3y>", "vi3>"],
    "w": ["wo1."],
    "x": ["xi2>", "xe1>"],
    "y": ["yb1.", "ycn2t>", "yfi3.", "ylp?", ],
    "z": ["zi2>", "zy1s."],
}
_LANCASTER["y"] = ["ycn2t>", "yt2>", "yb1.", "yl2>", "ylp0.", "yfi3."]
_LANCASTER_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")


class LancasterStemmer:
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = _LANCASTER
        self.strip_prefix_flag = strip_prefix_flag

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiou":
            return len(word) - remove_total >= 2
        return len(word) - remove_total >= 3 and any(c in "aeiouy" for c in word[:len(word) - remove_total] or "")

    def stem(self, word):
        word = word.lower()
        if not word:
            return word
        if self.strip_prefix_flag:
            for p in ("kilo", "micro", "milli", "intra", "ultra", "mega", "nano", "pico", "pseudo"):
                if word.startswith(p):
                    word = word[len(p):]
                    break
        original = word
        guard = 0
        while word and guard < 100:
            guard += 1
            applied = False
            stop = False
            for rule in self.rule_dictionary.get(word[-1], []):
                m = _LANCASTER_RE.match(rule)
                if not m:
                    continue
                ending, intact, rem, app, cont = m.groups()
                rem = int(rem)
                if not word.endswith(ending[::-1]):
                    continue
                if intact and word != original:
                    continue
                if not self._acceptable(word, rem):
                    continue
                word = word[:len(word) - rem] + app
                applied = True
                stop = cont != ">"
                break
            if not applied or stop:
                break
        return word

    def __repr__(self):
        return "<LancasterStemmer>"


# ------------------------------------------------------------------ Regexp
class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# ---------------------------------------------------------------- Snowball
LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
             "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
             "russian", "spanish", "swedish")


def _is_v(c):
    return c in "aeiouy"


class _EnglishStemmer:
    VOWELS = "aeiouy"
    DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    LI = "cdeghkmnrt"
    EXC1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
            "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
            "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
            "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
            "andes": "andes"}
    EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed",
            "succeed"}
    STEP2 = [("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
             ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
             ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
             ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
             ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
             ("fulli", "ful"), ("lessli", "less")]
    STEP3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
             ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", "")]
    STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate",
             "iti", "ous", "ive", "ize", "ion", "al", "er", "ic"]

    def _regions(self, w):
        n = len(w)
        r1 = n
        if w.startswith(("gener", "arsen", "commun")):
            r1 = 5 if not w.startswith("commun") else 6
        else:
            for i in range(1, n):
                if not _is_v(w[i]) and _is_v(w[i - 1]):
                    r1 = i + 1
                    break
        r2 = n
        for i in range(r1 + 1, n):
            if not _is_v(w[i]) and _is_v(w[i - 1]):
                r2 = i + 1
                break
        return r1, r2

    def _short_syllable_end(self, w):
        n = len(w)
        if n == 2:
            return _is_v(w[0]) and not _is_v(w[1])
        if n >= 3:
            return (not _is_v(w[-3]) and _is_v(w[-2]) and not _is_v(w[-1])
                    and w[-1] not in "wxY")
        return False

    def _is_short(self, w, r1):
        return r1 >= len(w) and self._short_syllable_end(w)

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        if w in self.EXC1:
            return self.EXC1[w]
        if w.startswith("'"):
            w = w[1:]
        # mark consonant y
        chars = list(w)
        if chars and chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i] == "y" and _is_v(chars[i - 1].lower()) and chars[i - 1] != "Y":
                chars[i] = "Y"
        w = "".join(chars)
        r1, r2 = self._regions(w)
        # step 0
        for s in ("'s'", "'s", "'"):
            if w.endswith(s):
                w = w[:-len(s)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith(("ied", "ies")):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith(("us", "ss")):
            pass
        elif w.endswith("s"):
            if any(_is_v(c) for c in w[:-2]):
                w = w[:-1]
        if w in self.EXC2:
            return w.replace("Y", "y")
        # step 1b
        def has_v(s):
            return any(_is_v(c) for c in s)
        if w.endswith(("eedly", "eed")):
            suf = "eedly" if w.endswith("eedly") else "eed"
            if len(w) - len(suf) >= r1:
                w = w[:-len(suf)] + "ee"
        else:
            for suf in ("ingly", "edly", "ing", "ed"):
                if w.endswith(suf) and has_v(w[:-len(suf)]):
                    w = w[:-len(suf)]
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w.endswith(self.DOUBLES):
                        w = w[:-1]
                    elif self._is_short(w, r1):
                        w += "e"
                    break
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and not _is_v(w[-2]):
            w = w[:-1] + "i"
        # step 2
        for suf, rep in sorted(self.STEP2, key=lambda x: -len(x[0])):
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    w = w[:-len(suf)] + rep
                break
        else:
            if w.endswith("ogi") and len(w) - 3 >= r1 and w[-4:-3] == "l":
                w = w[:-3] + "og"
            elif w.endswith("li") and len(w) - 2 >= r1 and len(w) > 2 and w[-3] in self.LI:
                w = w[:-2]
        # step 3
        for suf, rep in sorted(self.STEP3, key=lambda x: -len(x[0])):
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    if suf == "ative":
                        if len(w) - len(suf) >= r2:
                            w = w[:-len(suf)]
                    else:
                        w = w[:-len(suf)] + rep
                break
        # step 4
        for suf in sorted(self.STEP4, key=lambda x: -len(x)):
            if w.endswith(suf):
                if len(w) - len(suf) >= r2:
                    if suf == "ion":
                        if w[-4:-3] in ("s", "t") and len(w) > 3:
                            w = w[:-3]
                    else:
                        w = w[:-len(suf)]
                break
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not self._short_syllable_end(w[:-1])):
                w = w[:-1]
        elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
            w = w[:-1]
        return w.replace("Y", "y")


class _PorterSnowball(PorterStemmer):
    def __init__(self):
        PorterStemmer.__init__(self, PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        return PorterStemmer.stem(self, word.lower())


class _SuffixStemmer:
    """Approximate light stemmer used for languages without a full port."""
    SUFFIXES = {
        "danish": ["erende", "ethed", "heden", "ernes", "erne", "ende", "ene", "ers", "ets", "en", "er", "es", "et", "e", "s"],
        "dutch": ["heden", "ingen", "ing", "end", "ene", "en", "se", "s", "e"],
        "finnish": ["ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "ksi", "ien", "jen", "n", "t", "a", "ä"],
        "french": ["issement", "ements", "ement", "ations", "ation", "ités", "ité", "euses", "euse", "ives", "ive", "es", "s", "e", "er", "ez"],
        "german": ["ungen", "keit", "heit", "ung", "ern", "em", "er", "en", "es", "e", "s", "n"],
        "hungarian": ["ban", "ben", "val", "vel", "nak", "nek", "ok", "ek", "ak", "k", "t"],
        "italian": ["amente", "azione", "azioni", "mente", "ità", "ale", "are", "ere", "ire", "i", "e", "a", "o"],
        "norwegian": ["hetene", "heten", "ende", "ene", "ers", "ets", "er", "en", "et", "e", "s"],
        "portuguese": ["amente", "ações", "ação", "idades", "idade", "mente", "es", "as", "os", "s", "a", "o", "e"],
        "romanian": ["ilor", "ului", "elor", "ile", "ul", "le", "i", "a", "e"],
        "russian": ["ами", "ями", "ов", "ев", "ам", "ям", "ах", "ях", "ой", "ей", "ий", "ый", "ая", "яя", "ое", "ее", "ом", "ем", "а", "я", "ы", "и", "у", "ю", "о", "е", "ь"],
        "spanish": ["amente", "aciones", "ación", "idades", "idad", "mente", "es", "as", "os", "s", "a", "o", "e"],
        "swedish": ["heterna", "heter", "arna", "erna", "orna", "ande", "ade", "ar", "er", "or", "en", "et", "a", "e", "s"],
        "arabic": ["ات", "ون", "ين", "ان", "ها", "ية", "ة", "ه"],
    }

    def __init__(self, language):
        self.sfx = sorted(self.SUFFIXES[language], key=lambda s: -len(s))

    def stem(self, word):
        w = word.lower()
        for s in self.sfx:
            if w.endswith(s) and len(w) - len(s) >= 3:
                return w[:-len(s)]
        return w


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in LANGUAGES:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            p = data.find("corpora/stopwords/%s" % language)
            if p is None or not os.path.isfile(p):
                raise LookupError("Stopwords list for %r not found in lingora.data.path" % language)
            with open(p, encoding="utf-8") as f:
                self.stopwords = {l.strip() for l in f.read().splitlines() if l.strip()}
        if language == "english":
            self.stemmer = _EnglishStemmer()
        elif language == "porter":
            self.stemmer = _PorterSnowball()
        else:
            self.stemmer = _SuffixStemmer(language)

    def stem(self, word):
        w = word.lower()
        if w in self.stopwords:
            return w
        return self.stemmer.stem(w)


# ----------------------------------------------------------------- Arabic
_AR_DIAC = re.compile("[ً-ْـ]")


class ARLSTem:
    """Light Arabic stemmer (simplified)."""
    PREFIXES = ["كال", "بال", "ولل", "ال", "لل"]
    SUFFIXES = ["هما", "تما", "كما", "هم", "هن", "كم", "كن", "ها", "ات", "ون", "ين", "ان", "ية", "ة", "ه", "ي"]

    def stem(self, word):
        w = _AR_DIAC.sub("", word)
        w = re.sub("[أإآ]", "ا", w)
        for p in self.PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 2:
                w = w[len(p):]
                break
        for s in self.SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


# --------------------------------------------------------------- WordNet
class WordNetLemmatizer:
    _FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv", "s": "adj"}
    _RULES = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
              ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"),
              ("ed", ""), ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }

    def __init__(self):
        d = data.find("corpora/wordnet")
        if d is None or not os.path.isdir(d):
            raise LookupError("WordNet not found in lingora.data.path")
        self._dir = d
        self._index = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._index:
            return
        name = self._FILES[pos]
        words = set()
        fn = os.path.join(self._dir, "index." + name)
        if os.path.isfile(fn):
            with open(fn, encoding="utf-8") as f:
                for line in f:
                    if line and not line.startswith(" "):
                        words.add(line.split(" ", 1)[0])
        exc = {}
        fn = os.path.join(self._dir, name + ".exc")
        if os.path.isfile(fn):
            with open(fn, encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], []).append(parts[1])
        self._index[pos] = words
        self._exc[pos] = exc

    def lemmatize(self, word, pos="n"):
        if pos not in self._FILES:
            pos = "n"
        self._load(pos)
        words, exc = self._index[pos], self._exc[pos]
        forms = list(exc.get(word, []))
        if word in words:
            forms.append(word)
        cands = [word]
        for old, new in self._RULES.get(pos, []):
            if word.endswith(old):
                cands.append(word[:len(word) - len(old)] + new)
        forms += [c for c in cands[1:] if c in words]
        if not forms:
            return word
        return min(forms, key=len)
