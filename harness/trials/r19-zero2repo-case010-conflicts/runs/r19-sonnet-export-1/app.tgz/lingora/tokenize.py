"""Tokenizers."""
import html
import re

from .punkt import PunktSentenceTokenizer

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
           "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
           "sent_tokenize", "word_tokenize", "wordpunct_tokenize"]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=False, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty  # spec: N-000407
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        toks = self._regexp.findall(text)
        # findall with groups returns tuples; use finditer for whole matches
        toks = [m.group() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            toks = [t for t in toks if t]
        return toks

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                s, e = m.span()
                if not (self._discard_empty and s == last):
                    yield (last, s)
                last = e
            if not (self._discard_empty and last == len(text)):
                yield (last, len(text))
        else:
            for m in self._regexp.finditer(text):
                if m.end() == m.start() and self._discard_empty:
                    continue
                yield m.span()


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True, discard_empty=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True, discard_empty=True)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r"\""), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b",
        r"(?i)\b(gim)(?#X)(me)\b", r"(?i)\b(gon)(?#X)(na)\b",
        r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check_text(text)
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        r, s = self.PARENS_BRACKETS
        text = r.sub(s, text)
        r, s = self.DOUBLE_DASHES
        text = r.sub(s, text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedWordTokenizer(TreebankWordTokenizer):
    STARTING_QUOTES = [
        (re.compile("([\u00ab\u201c\u2018\u201e]|[`]+)"), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile("([^\\.])(\\.)([\\]\\)}>\"\\'\u00bb\u201d\u2019 ]*)\\s*$"), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[\u2012-\u2015]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([\u00bb\u201d\u2019])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r"\""), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_treebank = TreebankWordTokenizer()
_improved = _ImprovedWordTokenizer()


def sent_tokenize(text, language="english"):
    _check_text(text)
    return PunktSentenceTokenizer.for_language(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    _check_text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sentences for t in _improved.tokenize(s)]


# ------------------------------------------------------------------ Tweets
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
    (?:
      https?:
        (?:/{1,3}|[a-z0-9%])
      |
      [a-z0-9.\-]+[.]
        (?:[a-z]{2,13})
        /
    )
    (?:
      [^\s()<>{}\[\]]+
      |
      \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
      |
      \([^\s]+?\)
    )+
    (?:
      \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
      |
      \([^\s]+?\)
      |
      [^\s`!()\[\]{};:'".,<>?\u00ab\u00bb\u201c\u201d\u2018\u2019]
      |
      [a-z0-9]+(?:[.\-][a-z0-9]+)*[.]
        (?:[a-z]{2,13})
        \b
      /?(?!@)
    )
  |
    (?:
      [a-z0-9]+(?:[.\-][a-z0-9]+)*[.]
        (?:[a-z]{2,13})
        \b
      /?(?!@)
    )"""
_PHONE = r"""
    (?:
      (?:\+?[01][ *\-.\)]*)?
      (?:[\(]?\d{3}[ *\-.\)]*)?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_HTML_TAG = r"""<[^>\s]+>"""
_ASCII_ARROWS = r"""[\-]+>|<[\-]+"""
_USER = r"""(?:@[\w_]+)"""
_HASHTAG = r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)"""
_EMAIL = r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]"""
_WORDS = r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)"""

_WORD_RE = re.compile(
    "(%s)" % "|".join((_URLS, _PHONE, _EMOTICONS, _HTML_TAG, _ASCII_ARROWS,
                       _USER, _HASHTAG, _EMAIL, _WORDS)),
    re.VERBOSE | re.IGNORECASE | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.UNICODE)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@"
    r"(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE_RE.sub(r"\1\1\1", text)
        text = _HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in _WORD_RE.finditer(text)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.fullmatch(w) else w.lower() for w in words]
        return words
