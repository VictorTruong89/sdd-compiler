"""Constituent trees."""
import re

__all__ = ["Tree"]


class Tree(list):
    def __init__(self, label, children=None):
        if children is None:
            raise TypeError("Tree requires a list of children")
        if isinstance(children, str):
            raise TypeError("children should be a list, not a string")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def pformat(self, margin=70, indent=0):
        one = self._flat()
        if len(one) + indent <= margin or not any(isinstance(c, Tree) for c in self):
            return one
        s = "(%s" % (self._label,)
        for c in self:
            s += "\n" + " " * (indent + 2)
            if isinstance(c, Tree):
                s += c.pformat(margin, indent + 2)
            else:
                s += str(c)
        return s + ")"

    def _flat(self):
        parts = [c._flat() if isinstance(c, Tree) else str(c) for c in self]
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("fromstring expects a str")
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def parse():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("Tree.fromstring: expected '(' at token %d" % pos)
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in "()":
                label = toks[pos]
                pos += 1
            kids = []
            while True:
                if pos >= len(toks):
                    raise ValueError("Tree.fromstring: missing ')'")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, kids)
                if t == "(":
                    kids.append(parse())
                else:
                    kids.append(t)
                    pos += 1

        tree = parse()
        if pos != len(toks):
            raise ValueError("Tree.fromstring: unexpected text after tree")
        return tree
