"""Command line interface."""
import sys

from .tokenize import word_tokenize


class _Exit(Exception):
    def __init__(self, code):
        self.code = code


class _Group:
    def __init__(self, name):
        self.name = name

    def _tokenize(self, opts):
        language, delimiter, encoding = "english", " ", "utf-8"
        i = 0
        while i < len(opts):
            o = opts[i]
            if o in ("-l", "--language") and i + 1 < len(opts):
                language = opts[i + 1]
                i += 2
            elif o in ("-d", "--delimiter") and i + 1 < len(opts):
                delimiter = opts[i + 1]
                i += 2
            elif o in ("-e", "--encoding") and i + 1 < len(opts):
                encoding = opts[i + 1]
                i += 2
            else:
                raise _Exit(2)
        stream = getattr(sys.stdin, "buffer", None)
        raw = stream.read() if stream is not None else sys.stdin.read()
        text = raw.decode(encoding) if isinstance(raw, bytes) else raw
        lines = text.split("\n")
        if lines and lines[-1] == "":
            lines.pop()
        for line in lines:
            line = line.rstrip("\r")
            toks = word_tokenize(line, language)
            sys.stdout.write(delimiter.join(toks) + "\n")
        sys.stdout.flush()

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        code = 0
        try:
            if not args or args[0] != "tokenize":
                raise _Exit(2)
            self._tokenize(args[1:])
        except _Exit as e:
            code = e.code
            if code:
                sys.stderr.write("Usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING]\n")
        except Exception as e:  # failure: non-zero status, nothing for the failed input
            sys.stderr.write("Error: %s\n" % (e,))
            code = 1
        if standalone_mode:
            sys.exit(code)
        if code:
            raise RuntimeError("command failed with status %d" % code)
        return 0

    __call__ = main


cli = _Group("lingora")


def main():
    cli.main()
