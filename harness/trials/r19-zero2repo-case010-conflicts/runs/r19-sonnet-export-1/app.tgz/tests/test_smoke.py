from lingora.tokenize import wordpunct_tokenize
from lingora.metrics import edit_distance, jaccard_distance
from lingora.tree import Tree


def test_wordpunct():
    assert wordpunct_tokenize("Hi, you!") == ["Hi", ",", "you", "!"]


def test_metrics():
    assert edit_distance("kitten", "sitting") == 3
    assert jaccard_distance({1, 2}, {2, 3}) == 2 / 3


def test_tree():
    assert Tree.fromstring("(S (N a))") == Tree("S", [Tree("N", ["a"])])
