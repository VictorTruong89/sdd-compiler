"""Tests for the lingora package. Packaged resources are fabricated in temporary directories."""

import io
import json
import os
import sys

import pytest

from lingora import data
from lingora import cli as cli_module
from lingora.chunk import RegexpParser
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.grammar import CFG
from lingora.metrics import edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.metrics import accuracy as list_accuracy
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def empty_data_path(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    return data.path


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """Create a visible data directory with a Punkt model, English tagger and universal map."""
    root = tmp_path / "data"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("dr\nmr\netc\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("hello\t16\nworld\t16\nit\t16\n", encoding="utf-8")

    tagger = root / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        json.dumps({"bias": {"NN": 1.0}, "i word": {}}), encoding="utf-8"
    )
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT", "dog": "NN"}), encoding="utf-8"
    )
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["NN", "DT", "VBZ"]), encoding="utf-8"
    )
    uni = root / "taggers" / "universal_tagset"
    uni.mkdir(parents=True)
    (uni / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\nVBZ\tVERB\n", encoding="utf-8")

    monkeypatch.setattr(data, "path", [str(root)])
    return root


# ---------------------------------------------------------------- tokenizers

def test_wordpunct_basic():
    assert wordpunct_tokenize("Hello, world! 3.50") == ["Hello", ",", "world", "!", "3", ".", "50"]
    assert wordpunct_tokenize("") == []
    assert wordpunct_tokenize("  \n\t ") == []


def test_wordpunct_spans_recover_tokens():
    text = "ab, cd!"
    spans = WordPunctTokenizer().span_tokenize(text)
    assert [text[s:e] for s, e in spans] == WordPunctTokenizer().tokenize(text)


def test_treebank_contractions_and_fused_forms():
    out = TreebankWordTokenizer().tokenize("They can't gonna cannot 'tis.")
    assert "ca" in out and "n't" in out
    assert "gon" in out and "na" in out
    assert "can" in out and "not" in out
    assert out[-1] == "."


def test_treebank_quotes_and_brackets():
    out = TreebankWordTokenizer().tokenize('He said "hi" (ok)')
    assert "``" in out and "''" in out
    assert "(" in out and ")" in out


def test_whitespace_and_blankline():
    assert WhitespaceTokenizer().tokenize(" a  b\tc\n") == ["a", "b", "c"]
    assert blankline_tokenize("a\nb\n\n  c\n \n d") == ["a\nb", "c", "d"]


def test_regexp_tokenizer_modes():
    assert RegexpTokenizer(r"\w+").tokenize("x y, z") == ["x", "y", "z"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "", "b"]
    assert RegexpTokenizer(r",", gaps=True, discard_empty=True).tokenize("a,,b") == ["a", "b"]


def test_tweet_tokenizer():
    tok = TweetTokenizer()
    out = tok.tokenize("@bob Don't stop :) #yay Ça http://x.co")
    assert "Don't" in out
    assert ":)" in out and "#yay" in out and "http://x.co" in out
    lowered = TweetTokenizer(preserve_case=False).tokenize("HELLO :D")
    assert lowered == ["hello", ":D"]
    stripped = TweetTokenizer(strip_handles=True).tokenize("hi @bob there")
    assert "@bob" not in stripped
    reduced = TweetTokenizer(reduce_len=True, preserve_case=False).tokenize("noooooo")
    assert reduced == ["nooo"]


def test_sent_tokenize_requires_model(empty_data_path):
    with pytest.raises(LookupError):
        sent_tokenize("One. Two.")


def test_word_tokenize_without_split_needs_no_model(empty_data_path):
    assert word_tokenize("Hello there.", preserve_line=True) == ["Hello", "there", "."]
    with pytest.raises(LookupError):
        word_tokenize("Hello there.")


def test_sent_tokenize_with_model(resources):
    text = "Dr. Smith went home. The dog barked!  It was late."
    sents = sent_tokenize(text)
    assert sents[0] == "Dr. Smith went home."
    assert sents[1] == "The dog barked!"
    assert sents[-1] == "It was late."
    assert len(sents) == 3


def test_word_tokenize_with_model(resources):
    # A period is split off only when it ends the sentence text; "Dr." keeps its point.
    assert word_tokenize("Dr. Smith is here.") == ["Dr.", "Smith", "is", "here", "."]


# ---------------------------------------------------------------- stemmers

def test_porter_lingora_extensions():
    p = PorterStemmer()
    assert p.stem("ties") == "tie"
    assert p.stem("died") == "die"
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("a") == "a"
    assert p.stem("Running", to_lowercase=True) == "run"


def test_snowball_english_and_porter():
    eng = SnowballStemmer("english")
    assert eng.stem("generously") == "generous"
    assert eng.stem("running") == "run"
    assert SnowballStemmer("porter").stem("relational") == "relat"


def test_snowball_rejects_unknown_language():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_snowball_stopwords_need_list(empty_data_path):
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_lancaster_stems():
    assert LancasterStemmer().stem("maximum") == "maxim"


def test_regexp_stemmer():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("cats") == "cats"


# ---------------------------------------------------------------- taggers

def test_default_and_unigram_taggers():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    uni = UnigramTagger(train=[[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("dog", "VB"), ("dog", "NN")]])
    assert uni.tag(["the", "dog", "cat"]) == [("the", "DT"), ("dog", "NN"), ("cat", None)]
    backed = UnigramTagger(train=[[("the", "DT")]], backoff=DefaultTagger("NN"))
    assert backed.tag(["the", "cat"]) == [("the", "DT"), ("cat", "NN")]


def test_regexp_tagger_first_rule_wins():
    tagger = RegexpTagger([(r"\d+$", "CD"), (r".*s$", "NNS")])
    assert tagger.tag(["3", "cats", "dog"]) == [("3", "CD"), ("cats", "NNS"), ("dog", None)]


def test_pos_tag_requires_list_and_model(empty_data_path):
    with pytest.raises(TypeError):
        pos_tag("a string")
    with pytest.raises(LookupError):
        pos_tag(["the", "dog"])
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="fra")


def test_pos_tag_with_model(resources):
    assert pos_tag(["the", "dog", "xyz"])[2] == ("xyz", "NN")
    tagged = pos_tag(["the", "dog"])
    assert [t for _, t in tagged] == ["DT", "NN"]
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


# ---------------------------------------------------------------- chunking

def test_regexp_parser_chunks_and_chinks():
    grammar = "NP: {<DT>?<JJ>*<NN>}\n  }<VB.*>{"
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barks", "VBZ")]
    tree = RegexpParser(grammar).parse(tagged)
    assert tree.label() == "S"
    assert tree.leaves() == tagged
    assert isinstance(tree[0], Tree) and tree[0].label() == "NP"
    assert tree[1] == ("barks", "VBZ")


def test_regexp_parser_cascade_and_empty():
    tagged = [("the", "DT"), ("dog", "NN"), ("barks", "VBZ")]
    tree = RegexpParser("NP: {<DT><NN>}\nS: {<NP><VBZ>}").parse(tagged)
    assert tree[0].label() == "S"
    assert RegexpParser("NP: {<NN>}").parse([]).pformat() == "(S)"
    with pytest.raises(TypeError):
        RegexpParser(42)


# ---------------------------------------------------------------- grammars and trees

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'the' N PP
N -> 'dog' | 'man' | 'telescope'
PP -> P NP
VP -> V NP | VP PP
P -> 'with'
V -> 'saw'
"""


def test_chart_parser_ambiguity_and_errors():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the man saw the dog with the telescope".split()))
    assert len(trees) == 2
    assert all(t.label() == "S" and t.leaves() == "the man saw the dog with the telescope".split() for t in trees)
    assert list(ChartParser(g).parse("the dog".split())) == []
    with pytest.raises(ValueError):
        ChartParser(g).parse(["unknown"])


def test_shift_reduce_parser_agrees_on_unambiguous():
    g = CFG.fromstring("S -> NP VP\nNP -> 'the' N\nN -> 'dog'\nVP -> 'barks'")
    toks = ["the", "dog", "barks"]
    sr = list(ShiftReduceParser(g).parse(toks))
    assert sr == list(ChartParser(g).parse(toks))
    assert list(ShiftReduceParser(g).parse(["dog"])) == []


def test_generate_order_and_bounds():
    g = CFG.fromstring('S -> "a" S | "b"')
    assert list(generate(g, depth=3, n=3)) == [["a", "a", "b"], ["a", "b"], ["b"]]


def test_tree_behaviour():
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert t.leaves() == ["the", "dog", "barks"]
    assert len(t) == 2 and t[0].label() == "NP"
    assert len(Tree("X", [])) == 0
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")


# ---------------------------------------------------------------- classifiers

def test_naive_bayes_and_distribution():
    nb = NaiveBayesClassifier.train([({"w": "a"}, "x"), ({"w": "b"}, "y"), ({"w": "a", "z": 1}, "x")])
    assert nb.classify({"w": "a"}) == "x"
    assert nb.classify({"unseen": 1}) in {"x", "y"}
    dist = nb.prob_classify({"w": "b"})
    assert abs(sum(dist.prob(l) for l in nb.labels()) - 1.0) < 1e-9
    assert dist.prob("y") > 0 and dist.prob("x") > 0


def test_decision_tree_separates_training_data():
    train = [({"f": 1, "g": 0}, "A"), ({"f": 0, "g": 0}, "B"), ({"f": 1, "g": 1}, "A"), ({"f": 0, "g": 1}, "B")]
    dt = DecisionTreeClassifier.train(train)
    assert accuracy(dt, train) == 1.0
    assert dt.classify({"zzz": 3}) in {"A", "B"}


# ---------------------------------------------------------------- metrics

def test_edit_distance_and_transpositions():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("", "") == 0


def test_set_metrics():
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == 0.5
    assert precision({1}, set()) is None
    assert f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        precision([1], {1})


def test_list_accuracy_and_bleu():
    assert list_accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])
    assert bleu([["the", "cat", "is", "on", "the", "mat"]], ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu([["a", "b"]], ["c", "d"]) == 0.0


# ---------------------------------------------------------------- command line

def test_cli_tokenize_writes_lines(resources, monkeypatch, capsys):
    stdin = io.TextIOWrapper(io.BytesIO("Dr. Smith is here. Ok\n\nSecond line.\n".encode("utf-8")), encoding="utf-8")
    monkeypatch.setattr(sys, "stdin", stdin)
    status = cli_module.main(args=["tokenize"], standalone_mode=False)
    out = capsys.readouterr().out
    assert status == 0
    assert out.splitlines()[0] == "Dr. Smith is here . Ok"
    assert out.splitlines()[2] == "Second line ."


def test_cli_fails_without_model(empty_data_path, monkeypatch, capsys):
    stdin = io.TextIOWrapper(io.BytesIO(b"Hello.\n"), encoding="utf-8")
    monkeypatch.setattr(sys, "stdin", stdin)
    status = cli_module.main(args=["tokenize"], standalone_mode=False)
    assert status != 0
    assert capsys.readouterr().out == ""
