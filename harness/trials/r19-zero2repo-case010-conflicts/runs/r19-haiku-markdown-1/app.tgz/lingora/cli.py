"""Command-line group (``lingora.cli``).

``cli.main(args=['tokenize'])`` reads UTF-8 text from standard input and writes,
for every input line, the recommended word tokens of that line (with sentence
splitting) joined by the delimiter.
"""

import io
import sys

from lingora.tokenize import word_tokenize

__all__ = ["cli", "main"]

_USAGE = "usage: lingora tokenize [--language LANG] [--delimiter DELIM] [--encoding ENC]"


class _Group:
    """A minimal command group with a ``main`` entry."""

    commands = ("tokenize",)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        status = self._run(list(args))
        if standalone_mode:
            sys.exit(status)
        return status

    def _run(self, args):
        if not args or args[0] not in self.commands:
            sys.stderr.write(_USAGE + "\n")
            return 2
        language = "english"
        delimiter = " "
        encoding = "utf-8"
        i = 1
        while i < len(args):
            opt = args[i]
            if opt in ("--language", "--delimiter", "--encoding") and i + 1 < len(args):
                value = args[i + 1]
                if opt == "--language":
                    language = value
                elif opt == "--delimiter":
                    delimiter = value
                else:
                    encoding = value
                i += 2
            else:
                sys.stderr.write(_USAGE + "\n")
                return 2
        return self._tokenize(language, delimiter, encoding)

    def _tokenize(self, language, delimiter, encoding):
        try:
            stdin = io.TextIOWrapper(sys.stdin.buffer, encoding=encoding, errors="strict")
        except (AttributeError, LookupError) as exc:
            sys.stderr.write("lingora: bad input encoding: %s\n" % exc)
            return 2
        stdout = sys.stdout
        for line in stdin:
            line = line.rstrip("\r\n")
            try:
                tokens = word_tokenize(line, language=language, preserve_line=False)
            except Exception as exc:  # noqa: BLE001 - report any failure as exit status
                sys.stderr.write("lingora tokenize: %s\n" % exc)
                return 1
            stdout.write(delimiter.join(tokens) + "\n")
        stdout.flush()
        return 0


cli = _Group()


def main(args=None, standalone_mode=True):
    return cli.main(args=args, standalone_mode=standalone_mode)
