"""Tokenizers (``lingora.tokenize``), FP-01."""

import re

from lingora import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _text(value, name="text"):
    if not isinstance(value, str):
        raise TypeError("%s must be a str, not %s" % (name, type(value).__name__))
    return value


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space characters."""

    _PATTERN = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        return self._PATTERN.findall(_text(text))

    def span_tokenize(self, text):
        return [m.span() for m in self._PATTERN.finditer(_text(text))]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------- Penn Treebank

_CURLY_DOUBLE = re.compile(r"[“”„‟«»‹›]")
_CURLY_SINGLE = re.compile(r"[‘’‚‛]")
_CLITIC = re.compile(r"(?i)(?<=\w)(n't|'ll|'re|'ve|'s|'m|'d)(?=\W|$)")
_BARE_APOSTROPHE = re.compile(r"(?<=\w)'(?=\W|$)")
_OPEN_QUOTE = re.compile(r'(^|[\s(\[{<])"')
_PERIOD_END = re.compile(r"\.(?=(?:\s*(?:''|[\])}>]))*\s*$)")
_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<!\w)('t)(is|was)\b"), r"\1 \2"),
]


def _curly_single(match):
    text = match.string
    i = match.start()
    before = text[i - 1] if i > 0 else ""
    after = text[match.end()] if match.end() < len(text) else ""
    if before.isalpha() and after.isalpha():
        return match.group(0)
    return " %s " % match.group(0)


def _split_words(text, recommended):
    if recommended:
        if text.startswith('"'):
            text = " '' " + text[1:]
    text = _OPEN_QUOTE.sub(lambda m: m.group(1) + " `` ", text)
    text = text.replace('"', " '' ")
    if recommended:
        text = _CURLY_DOUBLE.sub(lambda m: " %s " % m.group(0), text)
        text = _CURLY_SINGLE.sub(_curly_single, text)
        text = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), text)
    else:
        text = text.replace("...", " ... ")
    text = _PERIOD_END.sub(" . ", text)
    text = re.sub(r"[;@#$%&?!]", lambda m: " %s " % m.group(0), text)
    text = re.sub(r"[\[\](){}<>]", lambda m: " %s " % m.group(0), text)
    text = re.sub(r"([,:])(?!\d)", r" \1 ", text)
    if recommended:
        text = re.sub(r"[‒-―*]", lambda m: " %s " % m.group(0), text)
        text = text.replace("--", " -- ")
    text = _CLITIC.sub(r" \1", text)
    text = _BARE_APOSTROPHE.sub(" '", text)
    if not recommended:
        for pattern, repl in _FUSED:
            text = pattern.sub(repl, text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenization conventions (FP-01)."""

    def tokenize(self, text):
        return _split_words(_text(text), recommended=False)

    def span_tokenize(self, text):
        raise NotImplementedError("span_tokenize is not supported by TreebankWordTokenizer")


def sent_tokenize(text, language="english"):
    """Split text into sentences with the packaged Punkt model for ``language``."""
    return _punkt.sentences(_text(text), language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    Unless ``preserve_line`` is True, the text is first split into sentences
    with Punkt for ``language``; each sentence is then tokenized.
    """
    text = _text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_split_words(sentence, recommended=True))
    return tokens


# ---------------------------------------------------------------- simple tokenizers

class WhitespaceTokenizer:
    _PATTERN = re.compile(r"\S+")

    def tokenize(self, text):
        return _text(text).split()

    def span_tokenize(self, text):
        return [m.span() for m in self._PATTERN.finditer(_text(text))]


def blankline_tokenize(text):
    """Segments separated by a blank line (newline, optional whitespace, newline)."""
    text = _text(text).strip()
    if not text:
        return []
    return [piece for piece in re.split(r"\s*\n\s*\n\s*", text) if piece]


class RegexpTokenizer:
    """Tokenize by matching a pattern (token mode) or by splitting on it (gap mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=False):
        _text(pattern, "pattern")
        self._pattern = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        if self._gaps:
            spans = []
            pos = 0
            for match in self._pattern.finditer(text):
                spans.append((pos, match.start()))
                pos = match.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._pattern.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans

    def tokenize(self, text):
        text = _text(text)
        return [text[s:e] for s, e in self._spans(text)]

    def span_tokenize(self, text):
        return self._spans(_text(text))


# ---------------------------------------------------------------- tweet tokenizer

_EMOTICON = r"(?:[:;=8][\-o\*']?[\)\]\(\[dDpP/\\\*\|3]|<3|\^_\^|\\o/)"
_URL = r"(?:https?://|www\.)\S+"
_HANDLE_STRIP = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_TWEET_PATTERN = re.compile(
    "|".join(
        [
            _EMOTICON,
            _URL,
            r"#\w+",
            r"(?<!\w)@\w+",
            r"[+-]?\d+(?:[.,]\d+)+(?!\w)",
            r"\w+(?:['’]\w+)*",
            r"\.{2,}",
            r"[^\w\s]",
        ]
    )
)
_EMOTICON_FULL = re.compile(_EMOTICON)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        text = _text(text)
        if self.strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self.reduce_len:
            text = re.sub(r"(.)\1{2,}", lambda m: m.group(1) * 3, text, flags=re.S)
        tokens = _TWEET_PATTERN.findall(text)
        if not self.preserve_case:
            tokens = [t if _EMOTICON_FULL.fullmatch(t) else t.lower() for t in tokens]
        return tokens
