"""Lingora Language Toolkit: a pure-Python natural language processing library.

Importing this package downloads nothing and needs no packaged data.
Submodules are imported on demand, for example ``from lingora.tokenize import ...``.
"""

from lingora import data

__version__ = "0.1.0"

__all__ = ["data", "__version__"]
