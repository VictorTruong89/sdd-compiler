"""Part-of-speech taggers (``lingora.tag``), FP-03."""

import re
from collections import Counter, defaultdict

from lingora import data
from lingora import _perceptron

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str, not %s" % type(tok).__name__)
    return list(tokens)


class _SequentialBackoffTagger:
    """Base class: a primary tagger with an optional backoff tagger for unassigned tokens."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialBackoffTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _primary(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._primary(tokens)
        if self._backoff is not None and any(t is None for t in tags):
            fallback = self._backoff.tag(tokens)
            tags = [
                primary if primary is not None else fallback[i][1]
                for i, primary in enumerate(tags)
            ]
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialBackoffTagger):
    """Assigns one tag to every token."""

    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def _primary(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialBackoffTagger):
    """Assigns each word the tag it most often had in training. Unseen words get no tag."""

    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        self._model = {}
        if train is not None:
            self.train(train)

    def train(self, train):
        counts = defaultdict(Counter)
        for sentence in train:
            for item in sentence:
                word, tag = item
                counts[word][tag] += 1
        for word, tag_counts in counts.items():
            # Counter preserves first-seen order, so ties go to the earlier-seen tag.
            self._model[word] = max(tag_counts.items(), key=lambda kv: kv[1])[0]

    @property
    def model(self):
        return dict(self._model)

    def _primary(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(_SequentialBackoffTagger):
    """Tags a token with the tag of the first rule whose pattern matches at its start."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        if not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def _primary(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for pattern, candidate in self._rules:
                if pattern.match(tok):
                    tag = candidate
                    break
            out.append(tag)
        return out


_TAGGER_LANGS = ("eng", "rus")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with LINGORA's recommended averaged perceptron tagger.

    ``lang`` is ``'eng'`` or ``'rus'``. ``tagset`` is ``None`` for the native tags or
    ``'universal'``. Raises when the input is not a token list, the language is not
    supported, or the packaged resource (or, for English universal tags, the
    universal tagset tables) is not visible.
    """
    tokens = _check_tokens(tokens)
    if lang not in _TAGGER_LANGS:
        raise ValueError("unsupported tagger language: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset: %r" % (tagset,))
    tagger = _perceptron.load_tagger(lang)
    universal_map = None
    if tagset == "universal":
        universal_map = _perceptron.universal_mapping(lang)
    results = tagger.tag(tokens)
    if universal_map is not None:
        results = [(tok, universal_map(tag)) for tok, tag in results]
    return results
