"""Constituent trees (``lingora.tree``)."""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN = re.compile(r"\(|\)|[^\s()]+")


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


class Tree:
    """A labelled ordered tree. Children are leaves (usually ``str``) or ``Tree`` nodes."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError(
                "Tree children must be a list of children, not %s" % type(children).__name__
            )
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text, e.g. ``(S (NP the dog) (VP barks))``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        toks = _BRACKET_TOKEN.findall(s)
        pos = 0

        def parse():
            nonlocal pos
            if pos >= len(toks) or toks[pos] != "(":
                raise ValueError("bracketed tree text: expected '(' at token %d" % pos)
            pos += 1
            if pos >= len(toks) or toks[pos] in ("(", ")"):
                raise ValueError("bracketed tree text: a node has no label")
            label = toks[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("bracketed tree text: unbalanced parentheses")
                tok = toks[pos]
                if tok == ")":
                    pos += 1
                    break
                if tok == "(":
                    children.append(parse())
                else:
                    children.append(tok)
                    pos += 1
            return cls(label, children)

        tree = parse()
        if pos != len(toks):
            raise ValueError("bracketed tree text: trailing text after the root node")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self, indent=2):
        return self._pformat(0, indent)

    def _pformat(self, level, indent):
        pad = " " * (level * indent)
        head = "(" + str(self._label)
        if all(not isinstance(c, Tree) for c in self._children):
            return pad + head + "".join(" " + _leaf_text(c) for c in self._children) + ")"
        lines = [pad + head]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child._pformat(level + 1, indent))
            else:
                lines.append(" " * ((level + 1) * indent) + _leaf_text(child))
        lines[-1] += ")"
        return "\n".join(lines)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()
