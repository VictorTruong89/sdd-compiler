"""Translation-quality scores (``lingora.translate``): sentence-level BLEU (FP-07)."""

import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    """Sentence BLEU (Papineni et al., 2002) of ``hypothesis`` against ``references``.

    ``references`` is a list of token lists, ``hypothesis`` a token list. ``weights``
    gives one weight per n-gram order from unigrams up. The default weights score
    unigrams and bigrams equally. ``smoothing_function``, if given, is a callable
    ``f(numerators, denominators) -> list of precisions``, one per order.
    """
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    if isinstance(hypothesis, str) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a token list")
    refs = [list(r) for r in references]
    hyp = list(hypothesis)
    weights = [float(w) for w in weights]
    if not weights or not hyp or not refs:
        return 0.0

    numerators = []
    denominators = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        numerators.append(clipped)
        denominators.append(total)

    if smoothing_function is None:
        precisions = []
        for num, den in zip(numerators, denominators):
            precisions.append(num / den if den else 0.0)
    else:
        precisions = list(smoothing_function(numerators, denominators))

    log_score = 0.0
    for w, p in zip(weights, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_score += w * math.log(p)

    hyp_len = len(hyp)
    ref_len = min((len(r) for r in refs), key=lambda L: (abs(L - hyp_len), L))
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / hyp_len)
    return brevity * math.exp(log_score)
