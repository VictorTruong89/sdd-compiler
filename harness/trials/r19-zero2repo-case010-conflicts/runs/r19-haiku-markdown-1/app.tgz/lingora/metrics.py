"""Evaluation metrics (``lingora.metrics``), FP-07."""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy: lists of different lengths")
    if not reference:
        return 0.0
    equal = sum(1 for a, b in zip(reference, test) if a == b)
    return equal / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Edit distance between two strings.

    Insertion and deletion cost 1. Substitution costs ``substitution_cost``.
    With ``transpositions=True`` the unrestricted Damerau-Levenshtein distance is used
    (Lowrance and Wagner, 1975), where a transposition costs 1.
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two strings")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j - 1] + sub, cur[j - 1] + 1, prev[j] + 1)
        prev = cur
    return prev[len(s2)]


def _damerau(a, b, sub_cost):
    maxdist = len(a) + len(b)
    da = {}
    d = {(-1, -1): maxdist}
    for i in range(len(a) + 1):
        d[(i, -1)] = maxdist
        d[(i, 0)] = i * 1
    for j in range(len(b) + 1):
        d[(-1, j)] = maxdist
        d[(0, j)] = j * 1
    for i in range(1, len(a) + 1):
        db = 0
        for j in range(1, len(b) + 1):
            k = da.get(b[j - 1], 0)
            ll = db
            if a[i - 1] == b[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub_cost
            d[(i, j)] = min(
                d[(i - 1, j - 1)] + cost,
                d[(i, j - 1)] + 1,
                d[(i - 1, j)] + 1,
                d[(k - 1, ll - 1)] + (i - k - 1) + 1 + (j - ll - 1),
            )
        da[a[i - 1]] = i
    return d[(len(a), len(b))]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over size of the union of two sets."""
    a = set(label1)
    b = set(label2)
    union = a | b
    if not union:
        return 0.0
    return len(a ^ b) / len(union)


def _sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")
    return reference, test


def precision(reference, test):
    reference, test = _sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    reference, test = _sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1 - alpha)/recall).

    Returns None when either set is empty or the two sets share no element.
    """
    reference, test = _sets(reference, test)
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    return 1.0 / (alpha / p + (1 - alpha) / r)
