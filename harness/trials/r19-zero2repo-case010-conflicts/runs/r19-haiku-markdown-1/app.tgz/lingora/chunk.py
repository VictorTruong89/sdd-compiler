"""Chunking (``lingora.chunk``), FP-04: regular-expression chunk parser and named-entity entry."""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk", "ChunkRule", "ChinkRule", "Clause", "SENTENCE_LABEL"]

SENTENCE_LABEL = "S"


class _Element:
    """One ``<tag-regex>`` with its quantifier."""

    __slots__ = ("pattern", "min", "max")

    def __init__(self, pattern, lo, hi):
        self.pattern = pattern
        self.min = lo
        self.max = hi


def _compile_tag_pattern(text):
    """Compile a tag pattern such as ``<DT>?<JJ>*<NN.*>+`` into a list of elements."""
    text = re.sub(r"\s+", "", text)
    elements = []
    pos = 0
    while pos < len(text):
        if text[pos] != "<":
            raise ValueError("tag pattern: expected '<' at position %d in %r" % (pos, text))
        end = text.find(">", pos + 1)
        if end < 0:
            raise ValueError("tag pattern: unclosed '<' in %r" % text)
        content = text[pos + 1:end]
        try:
            regex = re.compile("(?:%s)" % content)
        except re.error as exc:
            raise ValueError("tag pattern: bad element %r: %s" % (content, exc))
        pos = end + 1
        lo, hi = 1, 1
        if pos < len(text) and text[pos] in "?*+":
            q = text[pos]
            lo, hi = {"?": (0, 1), "*": (0, None), "+": (1, None)}[q]
            pos += 1
        elif pos < len(text) and text[pos] == "{":
            close = text.find("}", pos)
            if close < 0:
                raise ValueError("tag pattern: unclosed brace in %r" % text)
            body = text[pos + 1:close]
            m = re.fullmatch(r"(\d+)(,(\d*))?", body)
            if not m:
                raise ValueError("tag pattern: bad quantifier {%s}" % body)
            lo = int(m.group(1))
            if m.group(2) is None:
                hi = lo
            elif m.group(3) == "":
                hi = None
            else:
                hi = int(m.group(3))
            pos = close + 1
        elements.append(_Element(regex, lo, hi))
    if not elements:
        raise ValueError("tag pattern is empty")
    return elements


def _match_spans(elements, tags):
    """Leftmost-longest non-overlapping matches of ``elements`` over ``tags``.

    Returns a list of ``(start, end)`` index pairs, ``end`` exclusive, in order.
    Zero-length matches are not reported.
    """
    n = len(tags)
    spans = []
    pos = 0
    while pos < n:
        ends = _longest_end(elements, tags, pos)
        if ends is not None and ends > pos:
            spans.append((pos, ends))
            pos = ends
        else:
            pos += 1
    return spans


def _longest_end(elements, tags, start):
    positions = {start}
    n = len(tags)
    for el in elements:
        nxt = set()
        for p in positions:
            count = 0
            q = p
            if count >= el.min:
                nxt.add(q)
            while (el.max is None or count < el.max) and q < n and el.pattern.fullmatch(tags[q]):
                q += 1
                count += 1
                if count >= el.min:
                    nxt.add(q)
        positions = nxt
        if not positions:
            return None
    return max(positions)


class ChunkRule:
    """``{<tag pattern>}``: every match becomes a chunk with the clause label."""

    def __init__(self, pattern):
        self.elements = _compile_tag_pattern(pattern)
        self.pattern = pattern
        self.is_chink = False


class ChinkRule:
    """``}<tag pattern>{``: matching units are removed from the clause's chunks."""

    def __init__(self, pattern):
        self.elements = _compile_tag_pattern(pattern)
        self.pattern = pattern
        self.is_chink = True


class Clause:
    """A chunk label with its rules in written order."""

    def __init__(self, label, rules):
        if not isinstance(label, str) or not label:
            raise ValueError("clause label must be a non-empty str")
        self.label = label
        self.rules = list(rules)


def _parse_grammar(text):
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip():
            continue
        line = raw.strip()
        head = re.match(r"^([A-Za-z_][\w.\-]*)\s*:(.*)$", line)
        if head:
            current = Clause(head.group(1), [])
            clauses.append(current)
            line = head.group(2).strip()
        elif current is None:
            raise ValueError("chunk grammar: expected 'LABEL: pattern' in %r" % line)
        pos = 0
        while pos < len(line):
            ch = line[pos]
            if ch.isspace():
                pos += 1
                continue
            if ch == "{":
                close = line.find("}", pos + 1)
                if close < 0:
                    raise ValueError("chunk grammar: unclosed '{' in %r" % line)
                current.rules.append(ChunkRule(line[pos + 1:close]))
                pos = close + 1
            elif ch == "}":
                close = line.find("{", pos + 1)
                if close < 0:
                    raise ValueError("chunk grammar: unclosed '}' in %r" % line)
                current.rules.append(ChinkRule(line[pos + 1:close]))
                pos = close + 1
            else:
                raise ValueError("chunk grammar: unexpected %r in %r" % (ch, line))
    if not clauses:
        raise ValueError("chunk grammar has no clauses")
    for clause in clauses:
        if not clause.rules:
            raise ValueError("chunk clause %r has no patterns" % clause.label)
    return clauses


def _unit_tag(unit):
    if isinstance(unit, Tree):
        return unit.label()
    return unit[1]


class RegexpParser:
    """Chunk parser driven by a chunk grammar (text, or a list of ``Clause`` objects)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(c, Clause) for c in grammar):
            self._clauses = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        for item in tagged:
            if not (isinstance(item, tuple) and len(item) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
        root = list(tagged)
        for clause in self._clauses:
            root = self._apply_clause(clause, root)
        return Tree(SENTENCE_LABEL, root)

    def _apply_clause(self, clause, root):
        built = []  # chunks made by this clause, held as ids into root
        for rule in clause.rules:
            if rule.is_chink:
                root = self._apply_chink(clause, rule, root, built)
            else:
                root = self._apply_chunk(clause, rule, root, built)
        return root

    def _apply_chunk(self, clause, rule, root, built):
        built_ids = {id(c) for c in built}
        # Usable units: raw tokens and chunks of earlier clauses. Chunks made by
        # this clause are barriers.
        out = []
        pos = 0
        n = len(root)
        while pos < n:
            if isinstance(root[pos], Tree) and id(root[pos]) in built_ids:
                out.append(root[pos])
                pos += 1
                continue
            end = pos
            while end < n and not (isinstance(root[end], Tree) and id(root[end]) in built_ids):
                end += 1
            segment = root[pos:end]
            tags = [_unit_tag(u) for u in segment]
            last = 0
            for s, e in _match_spans(rule.elements, tags):
                out.extend(segment[last:s])
                chunk = Tree(clause.label, segment[s:e])
                built.append(chunk)
                out.append(chunk)
                last = e
            out.extend(segment[last:])
            pos = end
        return out

    def _apply_chink(self, clause, rule, root, built):
        out = []
        built_ids = {id(c) for c in built}
        for unit in root:
            if not (isinstance(unit, Tree) and id(unit) in built_ids):
                out.append(unit)
                continue
            children = list(unit)
            tags = [_unit_tag(c) for c in children]
            pieces = []  # list of (kind, items): kind 'chunk' or 'root'
            last = 0
            for s, e in _match_spans(rule.elements, tags):
                if s > last:
                    pieces.append(("chunk", children[last:s]))
                pieces.append(("root", children[s:e]))
                last = e
            if last < len(children):
                pieces.append(("chunk", children[last:]))
            if not any(kind == "root" for kind, _ in pieces):
                out.append(unit)
                continue
            for kind, items in pieces:
                if kind == "root":
                    out.extend(items)
                else:
                    chunk = Tree(clause.label, items)
                    built.append(chunk)
                    out.append(chunk)
            built_ids = {id(c) for c in built}
        return out


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Raises unless the packaged model and English wordlist are visible."""
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", directory=True)
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking is not implemented in this build")
