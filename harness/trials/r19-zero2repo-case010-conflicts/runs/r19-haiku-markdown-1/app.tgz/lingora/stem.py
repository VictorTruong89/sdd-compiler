"""Stemmers (``lingora.stem``), FP-02."""

import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]


def _word(value):
    if not isinstance(value, str):
        raise TypeError("word must be a str, not %s" % type(value).__name__)
    return value


# ------------------------------------------------------------------ Porter core

_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}


def _is_cons(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    m = 0
    in_vowel = False
    for i in range(len(stem)):
        if _is_cons(stem, i):
            if in_vowel:
                m += 1
                in_vowel = False
        else:
            in_vowel = True
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_cvc(stem):
    if len(stem) == 2:
        return (not _is_cons(stem, 0)) and _is_cons(stem, 1) and stem[1] not in "wxy"
    if len(stem) < 3:
        return False
    n = len(stem)
    return (
        _is_cons(stem, n - 3)
        and not _is_cons(stem, n - 2)
        and _is_cons(stem, n - 1)
        and stem[-1] not in "wxy"
    )


def _ends_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
    ("logi", "log"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _porter_step2(word, lingora):
    if lingora and word.endswith("alli"):
        stem = word[:-4]
        if _measure(stem) > 0:
            return _porter_step2(stem + "al", lingora)
    rules = _STEP2_LINGORA if lingora else _STEP2_ORIGINAL
    for suffix, repl in rules:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


def _porter(word, lingora):
    if len(word) <= 2:
        return word

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ies"):
        word = word[:-1] if (lingora and len(word) == 4) else word[:-2]
    elif word.endswith("ss"):
        pass
    elif word.endswith("s"):
        word = word[:-1]

    # Step 1b
    if lingora and word.endswith("ied"):
        word = word[:-1] if len(word) == 4 else word[:-2]
    elif word.endswith("eed"):
        if _measure(word[:-3]) > 0:
            word = word[:-1]
    else:
        stripped = None
        if word.endswith("ed") and _has_vowel(word[:-2]):
            stripped = word[:-2]
        elif word.endswith("ing") and _has_vowel(word[:-3]):
            stripped = word[:-3]
        if stripped is not None:
            word = stripped
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif _ends_double_cons(word) and word[-1] not in "lsz":
                word = word[:-1]
            elif _measure(word) == 1 and _ends_cvc(word):
                word += "e"

    # Step 1c
    if word.endswith("y") and len(word) > 1:
        stem = word[:-1]
        if lingora:
            if len(stem) >= 2 and _is_cons(stem, len(stem) - 1):
                word = stem + "i"
        elif _has_vowel(stem):
            word = stem + "i"

    # Step 2
    word = _porter_step2(word, lingora)

    # Step 3
    for suffix, repl in _STEP3:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _measure(stem) > 0:
                word = stem + repl
            break

    # Step 4
    for suffix in _STEP4:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if suffix == "ion" and not (stem.endswith("s") or stem.endswith("t")):
                break
            if _measure(stem) > 1:
                word = stem
            break

    # Step 5
    if word.endswith("e"):
        stem = word[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _ends_cvc(stem)):
            word = stem
    if word.endswith("ll") and _measure(word[:-1]) > 1:
        word = word[:-1]
    return word


class PorterStemmer:
    """Porter stemmer, default mode: Porter's algorithm with the LINGORA extensions."""

    def stem(self, word, to_lowercase=False):
        word = _word(word)
        if to_lowercase:
            word = word.lower()
        if word in _IRREGULAR:
            return _IRREGULAR[word]
        return _porter(word, lingora=True)


def _porter_original(word):
    """Porter's original 1980 algorithm (used by the Snowball ``porter`` language)."""
    word = word.lower()
    return _porter(word, lingora=False)


# ------------------------------------------------------------------ Lancaster

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3y.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "lu2.", "lai3y>", "lau3>", "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.",
    "nois4j>", "noix4ct.", "noi3y>", "nt*2t.", "ns*2t.", "nd1.", "pp1.", "re2>",
    "rae0.", "rean0.", "rc2.", "ria1.", "ri1.", "rgo5.", "rec2.", "sei3y>",
    "sis2.", "si2>", "ss0.", "suo3>", "su*2.", "s*1>", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.",
    "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>",
    "vie2>", "vi2>", "ylb1>", "yli3y>", "ylp0.", "yl2>", "ygo1.", "yhp1.",
    "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>", "yro3>",
    "yfi3.", "ycn2t>", "yca1>", "zi2>", "zy1s.",
]
_LANCASTER_PARSED = []
for _rule in _LANCASTER_RULES:
    _m = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>])", _rule)
    _LANCASTER_PARSED.append(
        (_m.group(1)[::-1], bool(_m.group(2)), int(_m.group(3)), _m.group(4), _m.group(5) == ".")
    )  # first field is the suffix as it appears in words


def _lancaster_acceptable(stem):
    if not stem:
        return False
    if stem[0] in "aeiouy":
        return len(stem) >= 2
    return len(stem) >= 3 and re.search(r"[aeiouy]", stem[1:]) is not None


class LancasterStemmer:
    """Paice/Husk (Lancaster) stemmer."""

    def stem(self, word):
        word = _word(word).lower()
        intact = True
        while True:
            applied = False
            for suffix, need_intact, remove, append, terminal in _LANCASTER_PARSED:
                if not word.endswith(suffix):
                    continue
                if need_intact and not intact:
                    continue
                if remove > len(word):
                    continue
                new = word[: len(word) - remove] + append
                if not _lancaster_acceptable(new):
                    continue
                word = new
                intact = False
                applied = True
                if terminal:
                    return word
                break
            if not applied:
                return word


# ------------------------------------------------------------------ Snowball

_SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)
_SNOWBALL_IMPLEMENTED = ("english", "porter")

_P2_EXCEPTIONS1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_P2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_P2_EXCEPTIONS2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_P2_VOWELS = "aeiouy"


def _p2_region(word, start):
    for i in range(max(start, 1), len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            return i + 1
    return len(word)


def _p2_r1(word):
    for prefix in ("gener", "commun", "arsen"):
        if word.startswith(prefix):
            return len(prefix)
    return _p2_region(word, 0)


def _p2_short(word):
    if re.search(r"(?:^|[^aeiouy])[aeiouy][^aeiouyWXY]$", word):
        return True
    return re.fullmatch(r"[aeiouy][^aeiouy]", word) is not None


def _p2_ends_in(word, suffixes):
    """Return the longest of ``suffixes`` that ``word`` ends with, or None."""
    best = None
    for suf in suffixes:
        if word.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    return best


_P2_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "ogi": "og", "fulli": "ful", "lessli": "less", "li": "",
}
_P2_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
    "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _P2_EXCEPTIONS1:
        return _P2_EXCEPTIONS1[word]
    if word in _P2_INVARIANT:
        return word
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    word = "".join(chars)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if word.endswith(suf):
            word = word[: -len(suf)]
            break

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ied") or word.endswith("ies"):
        word = word[:-2] if len(word) - 3 > 1 else word[:-1]
    elif word.endswith("us") or word.endswith("ss"):
        pass
    elif word.endswith("s"):
        if any(c in _P2_VOWELS for c in word[:-2]):
            word = word[:-1]

    if word in _P2_EXCEPTIONS2:
        return word.replace("Y", "y")

    # Step 1b
    r1 = _p2_r1(word)
    suf = _p2_ends_in(word, ("eedly", "eed"))
    if suf is not None:
        if len(word) - len(suf) >= r1:
            word = word[: -len(suf)] + "ee"
    else:
        suf = _p2_ends_in(word, ("ingly", "edly", "ing", "ed"))
        if suf is not None and any(c in _P2_VOWELS for c in word[: -len(suf)]):
            word = word[: -len(suf)]
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif _ends_double_cons(word.replace("Y", "y")) and word[-1] in "bdfgmnprt":
                word = word[:-1]
            elif _p2_r1(word) >= len(word) and _p2_short(word):
                word += "e"

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _P2_VOWELS:
        word = word[:-1] + "i"

    # Steps 2-4 use R1 and R2 of the current word.
    r1 = _p2_r1(word)
    r2 = _p2_region(word, r1)

    # Step 2
    suf = _p2_ends_in(word, _P2_STEP2)
    if suf is not None and len(word) - len(suf) >= r1:
        if suf == "li":
            if len(word) >= 3 and word[-3] in "cdeghkmnrt":
                word = word[:-2]
        elif suf == "ogi":
            if len(word) >= 4 and word[-4] == "l":
                word = word[:-3] + "og"
        else:
            word = word[: -len(suf)] + _P2_STEP2[suf]

    # Step 3
    r1 = _p2_r1(word)
    r2 = _p2_region(word, r1)
    suf = _p2_ends_in(word, list(_P2_STEP3) + ["ness"])
    if suf is not None:
        start = len(word) - len(suf)
        if suf == "ative":
            if start >= r2:
                word = word[:start]
        elif start >= r1:
            repl = _P2_STEP3.get(suf, "")
            word = word[:start] + repl

    # Step 4
    r1 = _p2_r1(word)
    r2 = _p2_region(word, r1)
    suf = _p2_ends_in(word, _P2_STEP4)
    if suf is not None:
        start = len(word) - len(suf)
        if suf == "ion":
            if start >= r2 and word[:start].endswith(("s", "t")):
                word = word[:start]
        elif start >= r2:
            word = word[:start]

    # Step 5
    r1 = _p2_r1(word)
    r2 = _p2_region(word, r1)
    if word.endswith("e"):
        if len(word) - 1 >= r2:
            word = word[:-1]
        elif len(word) - 1 >= r1 and not _p2_short(word[:-1]):
            word = word[:-1]
    elif word.endswith("ll") and len(word) - 1 >= r2:
        word = word[:-1]

    return word.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmers. ``english`` is Porter2 and ``porter`` is the original Porter algorithm."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in _SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            found = data.find("corpora/stopwords/" + language)
            with open(found, encoding="utf-8") as handle:
                self._stopwords = {line.strip().lower() for line in handle if line.strip()}
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError(
                "Snowball stemmer for language %r is not implemented in this build" % language
            )

    def stem(self, word):
        word = _word(word).lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self.language == "english":
            return _porter2(word)
        return _porter_original(word)


# ------------------------------------------------------------------ Regexp

class RegexpStemmer:
    """Removes every match of the caller's pattern from the word."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._pattern = re.compile(regexp)

    def stem(self, word):
        return self._pattern.sub("", _word(word))


# ------------------------------------------------------------------ not implemented here

class ARLSTem:
    """Arabic light stemmer. Constructible; its stemming results are outside this build."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is not implemented in this build")


class ARLSTem2(ARLSTem):
    """ARLSTem2 variant. Constructible; its stemming results are outside this build."""


class WordNetLemmatizer:
    """Requires the packaged WordNet resource; raises when it is not visible."""

    def __init__(self):
        data.find("corpora/wordnet", directory=True)

    def lemmatize(self, word):
        _word(word)
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")
