"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), as used by ``sent_tokenize``.

The packaged parameters (abbreviation types, collocations, sentence starters and
orthographic context) are read from ``tokenizers/punkt_tab/<language>/``.
The decision procedure below is a simplified version of the Punkt heuristics.
"""

import os
import re

from lingora import data

__all__ = ["load_params", "sentence_spans", "sentences"]

ORTHO_UC_START = 2
ORTHO_UC_MID = 4

_LANG_RE = re.compile(r"[A-Za-z_\-]+")
_TOKEN_RE = re.compile(r"\S+")
_PARTS_RE = re.compile(
    r"^(?P<lead>[\"'`(\[{<“‘«]*)"
    r"(?P<body>.*?)"
    r"(?P<punct>\.\.\.|[.?!]?)"
    r"(?P<close>[\"'`)\]}>”’»]*)$",
    re.S,
)
_NUMBER_RE = re.compile(r"-?[.,]?\d[\d,.\-]*")

_cache = {}


class PunktParams:
    __slots__ = ("abbrev", "starters", "collocations", "ortho")

    def __init__(self, abbrev, starters, collocations, ortho):
        self.abbrev = abbrev
        self.starters = starters
        self.collocations = collocations
        self.ortho = ortho


def _read_lines(directory, name):
    full = os.path.join(directory, name)
    if not os.path.isfile(full):
        return []
    with open(full, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]


def load_params(language):
    """Load the packaged Punkt parameters for ``language``.

    Raises ``ValueError`` for a malformed language name and ``LookupError``
    (``data.ResourceNotFound``) when the model is not visible.
    """
    if not isinstance(language, str) or not _LANG_RE.fullmatch(language):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    directory = data.find("tokenizers/punkt_tab/" + language, directory=True)
    if directory in _cache:
        return _cache[directory]
    abbrev = {line.strip().lower() for line in _read_lines(directory, "abbrev_types.txt") if line.strip()}
    starters = {line.strip().lower() for line in _read_lines(directory, "sent_starters.txt") if line.strip()}
    collocations = set()
    for line in _read_lines(directory, "collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0].strip().lower(), parts[1].strip().lower()))
    ortho = {}
    for line in _read_lines(directory, "ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0].strip().lower()] = int(parts[1].strip())
    params = PunktParams(abbrev, starters, collocations, ortho)
    _cache[directory] = params
    return params


class _Token:
    __slots__ = ("start", "end", "body", "type_", "punct", "first_upper", "first_lower")


def _tokens(text):
    out = []
    for match in _TOKEN_RE.finditer(text):
        raw = match.group(0)
        parts = _PARTS_RE.match(raw)
        body = parts.group("body")
        tok = _Token()
        tok.start, tok.end = match.span()
        tok.body = body
        tok.punct = parts.group("punct")
        if _NUMBER_RE.fullmatch(body):
            tok.type_ = "##number##"
        else:
            tok.type_ = body.lower()
        first = body[:1]
        tok.first_upper = first.isupper()
        tok.first_lower = first.islower()
        out.append(tok)
    return out


def _is_abbrev(tok, params):
    if tok.type_ in params.abbrev:
        return True
    return len(tok.body) == 1 and tok.body.isalpha()


def _break_after(tokens, params):
    """Return the indices of tokens after which a sentence ends."""
    cuts = []
    count = len(tokens)
    for i, tok in enumerate(tokens):
        if not tok.punct:
            continue
        nxt = tokens[i + 1] if i + 1 < count else None
        if nxt is None:
            cuts.append(i)
            continue
        if tok.punct in ("?", "!"):
            cuts.append(i)
            continue
        if (tok.type_, nxt.type_) in params.collocations:
            continue
        if tok.punct == "...":
            if nxt.first_upper:
                cuts.append(i)
            continue
        if _is_abbrev(tok, params):
            if nxt.first_lower:
                continue
            if nxt.type_ in params.starters:
                cuts.append(i)
                continue
            ortho = params.ortho.get(nxt.type_, 0)
            if (ortho & ORTHO_UC_START) and not (ortho & ORTHO_UC_MID):
                cuts.append(i)
            continue
        cuts.append(i)
    return cuts


def sentence_spans(text, language="english"):
    """Return ``(start, end)`` character offsets of each sentence of ``text``."""
    params = load_params(language)
    tokens = _tokens(text)
    if not tokens:
        return []
    cuts = set(_break_after(tokens, params))
    spans = []
    first = 0
    last = len(tokens) - 1
    for i in range(len(tokens)):
        if i in cuts or i == last:
            spans.append((tokens[first].start, tokens[i].end))
            first = i + 1
    return spans


def sentences(text, language="english"):
    """Return the sentences of ``text`` as strings, in order."""
    return [text[start:end] for start, end in sentence_spans(text, language)]
