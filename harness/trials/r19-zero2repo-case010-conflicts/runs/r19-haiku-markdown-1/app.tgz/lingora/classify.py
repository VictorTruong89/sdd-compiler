"""Classifiers (``lingora.classify``), FP-06: Naive Bayes and decision tree."""

import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]

_MISSING = object()


def _check_labeled(labeled):
    if isinstance(labeled, str) or not isinstance(labeled, (list, tuple)):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    pairs = []
    for item in labeled:
        if not (isinstance(item, tuple) and len(item) == 2) or not isinstance(item[0], dict):
            raise TypeError("each item must be a (featureset dict, label) pair")
        pairs.append((dict(item[0]), item[1]))
    if not pairs:
        raise ValueError("training data is empty")
    return pairs


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs.items(), key=lambda kv: kv[1])[0]

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing per feature (no zero probabilities)."""

    def __init__(self, label_counts, value_counts, with_feature, feature_values, total):
        self._label_counts = label_counts
        self._value_counts = value_counts
        self._with_feature = with_feature
        self._feature_values = feature_values
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        value_counts = defaultdict(Counter)
        with_feature = Counter()
        feature_values = defaultdict(set)
        for fs, label in pairs:
            label_counts[label] += 1
            for feat, value in fs.items():
                value_counts[(label, feat)][value] += 1
                with_feature[(label, feat)] += 1
                feature_values[feat].add(value)
        return cls(label_counts, value_counts, with_feature, feature_values, len(pairs))

    def labels(self):
        return list(self._label_counts.keys())

    def _log_joint(self, featureset):
        scores = {}
        for label, count in self._label_counts.items():
            score = math.log(count / self._total)
            for feat, value in featureset.items():
                if feat not in self._feature_values:
                    continue
                k = len(self._feature_values[feat])
                seen = self._value_counts[(label, feat)].get(value, 0)
                denom = self._with_feature.get((label, feat), 0) + k
                score += math.log((seen + 1) / denom)
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_joint(featureset)
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: v / total for label, v in exps.items()})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_joint(featureset)
        best = None
        for label in self._label_counts:
            if best is None or scores[label] > scores[best]:
                best = label
        return best


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


class _Node:
    __slots__ = ("feature", "majority", "children")

    def __init__(self, majority, feature=None, children=None):
        self.majority = majority
        self.feature = feature
        self.children = children


def _majority(labels):
    counts = Counter(labels)
    best = None
    for label in labels:
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build(examples, features):
    labels = [label for _, label in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1 or not features:
        return _Node(majority)
    base = _entropy(labels)
    best_feat = None
    best_groups = None
    best_gain = 1e-12
    for feat in features:
        groups = defaultdict(list)
        for fs, label in examples:
            groups[fs.get(feat, _MISSING)].append((fs, label))
        if len(groups) < 2:
            continue
        remainder = sum(
            len(group) / len(examples) * _entropy([lab for _, lab in group])
            for group in groups.values()
        )
        gain = base - remainder
        if gain > best_gain:
            best_gain = gain
            best_feat = feat
            best_groups = groups
    if best_feat is None:
        return _Node(majority)
    rest = [f for f in features if f != best_feat]
    children = {value: _build(group, rest) for value, group in best_groups.items()}
    return _Node(majority, feature=best_feat, children=children)


class DecisionTreeClassifier:
    """ID3-style decision tree over feature tests (information gain)."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        features = sorted({f for fs, _ in pairs for f in fs}, key=lambda f: str(f))
        return cls(_build(pairs, features))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while node.children is not None:
            value = featureset.get(node.feature, _MISSING)
            if value in node.children:
                node = node.children[value]
            else:
                return node.majority
        return node.majority


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` that ``classifier`` labels correctly."""
    if isinstance(gold, str) or not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        return 0.0
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
