"""Context-free grammars (``lingora.grammar``), FP-05."""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_IDENT = re.compile(r"[A-Za-z_][\w\-']*")
_RHS_TOKEN = re.compile(r"""\s*(?:("[^"]*"|'[^']*')|(\|)|([^\s|"']+))""")


class Nonterminal:
    """A grammar nonterminal. ``str(sym)`` is its name."""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name

    def __repr__(self):
        return "Nonterminal(%r)" % self.name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other.name == self.name

    def __hash__(self):
        return hash(("Nonterminal", self.name))


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for sym in self._rhs:
            parts.append(repr(sym) if isinstance(sym, str) else str(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


def _parse_rhs(text):
    alternatives = [[]]
    for m in _RHS_TOKEN.finditer(text):
        quoted, bar, word = m.group(1), m.group(2), m.group(3)
        if bar:
            alternatives.append([])
        elif quoted is not None:
            alternatives[-1].append(quoted[1:-1])
        else:
            alternatives[-1].append(Nonterminal(word))
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(str(start))
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line:
                continue
            lhs_text, arrow, rhs_text = line.partition("->")
            if not arrow:
                raise ValueError("grammar line has no '->': %r" % line)
            lhs_text = lhs_text.strip()
            if not _IDENT.fullmatch(lhs_text):
                raise ValueError("invalid left-hand side %r in %r" % (lhs_text, line))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for rhs in _parse_rhs(rhs_text):
                productions.append(Production(lhs, rhs))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        name = lhs.name if isinstance(lhs, Nonterminal) else str(lhs)
        return [p for p in self._productions if p.lhs().name == name]

    def nonterminals(self):
        seen = []
        for p in self._productions:
            if p.lhs() not in seen:
                seen.append(p.lhs())
        return seen

    def _terminals(self):
        terms = set()
        for p in self._productions:
            for sym in p.rhs():
                if isinstance(sym, str):
                    terms.add(sym)
        return terms

    def __repr__(self):
        return "<CFG with %d productions, start %s>" % (len(self._productions), self._start)
