"""Packaged-resource finder (``lingora.data``).

``path`` is a mutable list of directories searched for packaged resources.
Callers may replace its contents in place. An empty list means that no
packaged resource is visible.
"""

import os

__all__ = ["path", "ResourceNotFound", "find", "has"]


class ResourceNotFound(LookupError):
    """A packaged resource is not visible in any directory on ``data.path``."""


def _default_path():
    dirs = []
    for entry in os.environ.get("LINGORA_DATA", "").split(os.pathsep):
        if entry:
            dirs.append(entry)
    dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return dirs


path = _default_path()


def find(relpath, directory=False):
    """Return the full path of ``relpath`` under the first ``data.path`` entry holding it.

    With ``directory=True`` only directories count. Raises ``ResourceNotFound``
    when the resource is not visible.
    """
    for base in list(path):
        candidate = os.path.join(base, relpath)
        if directory:
            if os.path.isdir(candidate):
                return candidate
        elif os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r not found in data.path %r" % (relpath, list(path))
    )


def has(relpath, directory=False):
    """Return True when ``find`` would succeed for ``relpath``."""
    try:
        find(relpath, directory=directory)
    except ResourceNotFound:
        return False
    return True
