"""Greedy averaged perceptron tagger (textblob-aptagger feature templates).

The packaged resource ``taggers/averaged_perceptron_tagger_<lang>/`` holds three JSON files:
``*.weights.json``, ``*.tagdict.json`` and ``*.classes.json``.
"""

import json
import os
import re
from collections import defaultdict

from lingora import data

START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]

_cache = {}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _Model:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


class PerceptronTagger:
    def __init__(self, model, tagdict):
        self._model = model
        self._tagdict = tagdict

    def tag(self, tokens):
        prev, prev2 = START
        context = START + [_normalize(w) for w in tokens] + END
        out = []
        for i, word in enumerate(tokens):
            tag = self._tagdict.get(word)
            if not tag:
                feats = _features(i, word, context, prev, prev2)
                tag = self._model.predict(feats)
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


def _load_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def load_tagger(lang):
    directory = data.find("taggers/averaged_perceptron_tagger_" + lang, directory=True)
    if directory in _cache:
        return _cache[directory]
    weights = _load_json(os.path.join(directory, "averaged_perceptron_tagger_%s.weights.json" % lang))
    tagdict = _load_json(os.path.join(directory, "averaged_perceptron_tagger_%s.tagdict.json" % lang))
    classes = _load_json(os.path.join(directory, "averaged_perceptron_tagger_%s.classes.json" % lang))
    tagger = PerceptronTagger(_Model(weights, classes), tagdict)
    _cache[directory] = tagger
    return tagger


_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "SPRO": "PRON", "A": "ADJ", "A-PRO": "DET", "APRO": "DET",
    "ANUM": "ADJ", "A-NUM": "ADJ", "NUM": "NUM", "V": "VERB", "ADV": "ADV",
    "ADVPRO": "PRON", "PR": "ADP", "CONJ": "CCONJ", "PART": "PART",
    "INTJ": "INTJ", "PRAEDIC": "ADV", "PARENTH": "PART",
}


def universal_mapping(lang):
    """Return a function mapping a native tag to a universal tag."""
    if lang == "eng":
        table = _english_table()

        def english(tag):
            return table.get(tag, tag)

        return english

    def russian(tag):
        pos = tag.split("=", 1)[0]
        return _RUS_TO_UNIVERSAL.get(pos, "X")

    return russian


_english_cache = {}


def _english_table():
    if "table" in _english_cache:
        return _english_cache["table"]
    path = data.find("taggers/universal_tagset/en-ptb.map", directory=False)
    table = {}
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2 and parts[0]:
                table[parts[0]] = parts[1]
    _english_cache["table"] = table
    return table
