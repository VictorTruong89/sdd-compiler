"""Sentence generation from a grammar (``lingora.parse.generate``)."""

from lingora.grammar import CFG, Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Enumerate sentences derived from ``start`` (default: the grammar's start symbol).

    Expansion follows the productions in their written order (depth first). ``depth``
    bounds the expansion depth of each nonterminal (None for no bound); ``n`` bounds
    the number of sentences (None for no bound). Each sentence is a list of ``str``.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        symbol = grammar.start()
    elif isinstance(start, Nonterminal):
        symbol = start
    else:
        symbol = Nonterminal(str(start))
    return _generate(grammar, symbol, depth, n)


def _generate(grammar, symbol, depth, n):
    stack = [((("N", symbol, 0),))]
    count = 0
    while stack:
        if n is not None and count >= n:
            return
        form = stack.pop()
        index = None
        for i, item in enumerate(form):
            if item[0] == "N":
                index = i
                break
        if index is None:
            count += 1
            yield [item[1] for item in form]
            continue
        _, sym, d = form[index]
        if depth is not None and d >= depth:
            continue
        for prod in reversed(grammar.productions(lhs=sym)):
            new = tuple(
                ("T", item) if isinstance(item, str) else ("N", item, d + 1)
                for item in prod.rhs()
            )
            stack.append(form[:index] + new + form[index + 1:])
