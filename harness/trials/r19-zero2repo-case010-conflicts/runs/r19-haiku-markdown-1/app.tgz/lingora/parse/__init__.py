"""Parsers over a context-free grammar (``lingora.parse``), FP-05.

``ChartParser`` is exhaustive. ``ShiftReduceParser`` is a single pass without backtracking.
"""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


class _ParserBase:
    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def _check_tokens(self, tokens):
        if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
            raise TypeError("tokens must be a list of str")
        terminals = self._grammar._terminals()
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("every token must be a str")
            if tok not in terminals:
                raise ValueError("token %r is not produced by any production of the grammar" % tok)
        return list(tokens)


class ChartParser(_ParserBase):
    """Exhaustive chart parser: returns every parse tree of the token list."""

    def parse(self, tokens):
        toks = self._check_tokens(tokens)
        n = len(toks)
        productions = self._grammar.productions()
        ok = set()
        changed = True
        while changed:
            changed = False
            for prod in productions:
                lhs = prod.lhs().name
                for i in range(n + 1):
                    for j in range(i, n + 1):
                        if (lhs, i, j) in ok:
                            continue
                        if _sequence_spans(prod.rhs(), toks, i, j, ok):
                            ok.add((lhs, i, j))
                            changed = True
        start = self._grammar.start().name
        if (start, 0, n) not in ok:
            return iter([])
        trees = _trees(self._grammar, toks, ok, start, 0, n, frozenset())
        unique = []
        seen = set()
        for tree in trees:
            if tree not in seen:
                seen.add(tree)
                unique.append(tree)
        return iter(unique)


def _sequence_spans(rhs, toks, i, j, ok):
    positions = {i}
    for sym in rhs:
        nxt = set()
        if isinstance(sym, str):
            for p in positions:
                if p < j and toks[p] == sym:
                    nxt.add(p + 1)
        else:
            for p in positions:
                for q in range(p, j + 1):
                    if (sym.name, p, q) in ok:
                        nxt.add(q)
        positions = nxt
        if not positions:
            return False
    return j in positions


def _trees(grammar, toks, ok, name, i, j, stack):
    key = (name, i, j)
    if key in stack:
        return []
    inner = stack | {key}
    out = []
    for prod in grammar.productions(lhs=Nonterminal(name)):
        for children in _expand(grammar, prod.rhs(), 0, i, j, toks, ok, inner):
            out.append(Tree(name, children))
    return out


def _expand(grammar, rhs, idx, pos, j, toks, ok, stack):
    if idx == len(rhs):
        if pos == j:
            yield []
        return
    sym = rhs[idx]
    if isinstance(sym, str):
        if pos < j and toks[pos] == sym:
            for rest in _expand(grammar, rhs, idx + 1, pos + 1, j, toks, ok, stack):
                yield [sym] + rest
        return
    for q in range(pos, j + 1):
        if (sym.name, pos, q) not in ok:
            continue
        for sub in _trees(grammar, toks, ok, sym.name, pos, q, stack):
            for rest in _expand(grammar, rhs, idx + 1, q, j, toks, ok, stack):
                yield [sub] + rest


class ShiftReduceParser(_ParserBase):
    """Single left-to-right shift-reduce pass without backtracking."""

    def parse(self, tokens):
        toks = self._check_tokens(tokens)
        productions = self._grammar.productions()
        nonempty = [p for p in productions if p.rhs()]
        empties = [p for p in productions if not p.rhs()]
        stack = []
        pos = 0
        empty_tried_at = None
        while True:
            if self._reduce(stack, nonempty):
                continue
            if pos < len(toks):
                if empties and empty_tried_at != pos:
                    prod = empties[0]
                    stack.append(Tree(prod.lhs().name, []))
                    empty_tried_at = pos
                    continue
                stack.append(toks[pos])
                pos += 1
                continue
            break
        start = self._grammar.start().name
        if pos == len(toks) and len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])

    @staticmethod
    def _reduce(stack, productions):
        for prod in productions:
            rhs = prod.rhs()
            k = len(rhs)
            if len(stack) < k:
                continue
            top = stack[-k:]
            matched = True
            for sym, item in zip(rhs, top):
                if isinstance(sym, str):
                    if not (isinstance(item, str) and item == sym):
                        matched = False
                        break
                else:
                    if not (isinstance(item, Tree) and item.label() == sym.name):
                        matched = False
                        break
            if matched:
                del stack[-k:]
                stack.append(Tree(prod.lhs().name, list(top)))
                return True
        return False
