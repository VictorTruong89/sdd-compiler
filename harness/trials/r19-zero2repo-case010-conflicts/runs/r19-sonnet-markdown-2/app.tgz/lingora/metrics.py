"""Evaluation metrics."""


def accuracy(reference, test):
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        reference, test = list(reference), list(test)
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if len(reference) == 0:
        return 0
    return sum(x == y for x, y in zip(reference, test)) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    len1, len2 = len(s1), len(s2)
    d = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        d[i][0] = i
    for j in range(len2 + 1):
        d[0][j] = j
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            c1, c2 = s1[i - 1], s2[j - 1]
            best = min(
                d[i - 1][j] + 1,
                d[i][j - 1] + 1,
                d[i - 1][j - 1] + (substitution_cost if c1 != c2 else 0),
            )
            if transpositions and i > 1 and j > 1 and s1[i - 2] == c2 and c1 == s2[j - 2]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[len1][len2]


def jaccard_distance(label1, label2):
    union = len(label1.union(label2))
    return (union - len(label1.intersection(label2))) / union


def _check_sets(reference, test):
    if not (hasattr(reference, "intersection") and hasattr(test, "intersection")):
        raise TypeError("reference and test should be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference.intersection(test)) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference.intersection(test)) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0
    return 1.0 / (alpha / p + (1 - alpha) / r)
