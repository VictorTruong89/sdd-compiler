"""Regular-expression chunking."""
import re

from lingora import data
from lingora.tree import Tree

_IN_CHINK = r"(?=[^\{\}]*(\{|$))"
_IN_CHUNK = r"(?=[^\{\}]*\})"


def tag_pattern2re_pattern(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = p.replace("<", "(?:<(?:").replace(">", ")>)")
    p = re.sub(r"([^\\])\.", r"\1[^\{\}<>]", p)
    p = re.sub(r"^\.", r"[^\{\}<>]", p)
    return p


class RegexpChunkRule:
    def __init__(self, regexp, repl):
        self._regexp = re.compile(regexp)
        self._repl = repl

    def apply(self, s):
        s = self._regexp.sub(self._repl, s)
        return s.replace("{}", "")


def _chunk_rule(pat):
    return RegexpChunkRule("(?P<chunk>%s)%s" % (tag_pattern2re_pattern(pat), _IN_CHINK), r"{\g<chunk>}")


def _chink_rule(pat):
    return RegexpChunkRule("(?P<chink>%s)%s" % (tag_pattern2re_pattern(pat), _IN_CHUNK), r"}\g<chink>{")


class _Stage:
    def __init__(self, label, rules, root_label):
        self.label = label
        self.rules = rules

    def parse(self, items):
        def tag_of(it):
            return it.label() if isinstance(it, Tree) else it[1]

        tags = [tag_of(it) for it in items]
        for t in tags:
            if re.search(r"[<>{}]", str(t)):
                raise ValueError("Bad tag %r: tags may not contain <, >, { or }" % (t,))
        s = "".join("<%s>" % t for t in tags)
        for rule in self.rules:
            s = rule.apply(s)
        out = []
        idx = 0
        pieces = re.split(r"[{}]", s)
        for k, piece in enumerate(pieces):
            n = piece.count("<")
            seg = items[idx: idx + n]
            idx += n
            if k % 2 == 0:
                out.extend(seg)
            else:
                out.append(Tree(self.label, seg))
        return out


_ROOT = "S"


class RegexpParser:
    def __init__(self, grammar, root_label=_ROOT, loop=1, trace=0):
        self._root = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._read(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, _Stage) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")

    @staticmethod
    def _read(text):
        stages = []
        cur_label = None
        cur_rules = None
        for line in text.split("\n"):
            line = re.sub(r"#.*", "", line).strip()
            if not line:
                continue
            m = re.match(r"^(?P<label>[^:{}\s]+(?:\s*[^:{}\s]+)*?)\s*:(?P<rule>.*)$", line)
            if m and not line.startswith(("{", "}")):
                if cur_label is not None:
                    stages.append(_Stage(cur_label, cur_rules, _ROOT))
                cur_label = m.group("label").strip()
                cur_rules = []
                rule = m.group("rule").strip()
            else:
                if cur_label is None:
                    raise ValueError("Unable to parse grammar line: %r" % line)
                rule = line
            if rule:
                cur_rules.append(RegexpParser._parse_rule(rule))
        if cur_label is not None:
            stages.append(_Stage(cur_label, cur_rules, _ROOT))
        if not stages:
            raise ValueError("Grammar contains no clauses")
        return stages

    @staticmethod
    def _parse_rule(rule):
        rule = rule.strip()
        if rule.startswith("{") and rule.endswith("}") and len(rule) >= 2:
            return _chunk_rule(rule[1:-1])
        if rule.startswith("}") and rule.endswith("{") and len(rule) >= 2:
            return _chink_rule(rule[1:-1])
        raise ValueError("Illegal chunk pattern: %r" % rule)

    def parse(self, chunk_struct):
        items = list(chunk_struct)
        for _ in range(self._loop):
            for stage in self._stages:
                items = stage.parse(items)
        return Tree(self._root, items)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    # The packaged maximum-entropy model is not interpreted by this build;
    # tokens are returned unchunked under a sentence root.
    return Tree("S", [tuple(t) for t in tagged_tokens])
