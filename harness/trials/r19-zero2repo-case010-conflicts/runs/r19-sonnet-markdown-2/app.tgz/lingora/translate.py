"""BLEU score."""
import math
from collections import Counter
from fractions import Fraction


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return sum(clipped.values()), max(1, sum(counts.values()))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    hypothesis = list(hypothesis)
    references = [list(r) for r in references]
    p_num = Counter()
    p_den = Counter()
    for i, _ in enumerate(weights, start=1):
        p_num[i], p_den[i] = modified_precision(references, hypothesis, i)
    hyp_len = len(hypothesis)
    if p_num[1] == 0:
        return 0
    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > closest:
        bp = 1
    elif hyp_len == 0:
        bp = 0
    else:
        bp = math.exp(1 - closest / hyp_len)
    p_n = [Fraction(p_num[i], p_den[i]) for i in range(1, len(weights) + 1)]
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    else:
        p_n = [p if p.numerator != 0 else None for p in p_n]
    terms = []
    for w, p in zip(weights, p_n):
        if p is None:
            pv = 2.2250738585072014e-308
        else:
            pv = float(p)
            if pv <= 0:
                pv = 2.2250738585072014e-308
        terms.append(w * math.log(pv))
    return bp * math.exp(math.fsum(terms))
