"""Snowball English (Porter2) and Porter stemmers."""

V = "aeiouy"


def _regions(word, prefixes=()):
    r1 = len(word)
    for p in prefixes:
        if word.startswith(p):
            r1 = len(p)
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in V and word[i - 1] in V:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in V and word[i - 1] in V:
            r2 = i + 1
            break
    return r1, r2


def _short_syllable(w, start_rule=True):
    n = len(w)
    if n >= 3 and w[-1] not in V and w[-1] not in "wxY" and w[-2] in V and w[-3] not in V:
        return True
    if start_rule and n == 2 and w[0] in V and w[1] not in V:
        return True
    return False


def _mark_y(word):
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in V:
            chars[i] = "Y"
    return "".join(chars)


def _longest(word, sufs):
    best = None
    for s in sufs:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def _step1b_tail(word, r1, start_rule):
    if word.endswith(("at", "bl", "iz")):
        return word + "e"
    if word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
        return word[:-1]
    if r1 >= len(word) and _short_syllable(word, start_rule):
        return word + "e"
    return word


_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent", "izer": "ize",
    "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al",
    "alli": "al", "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive", "iviti": "ive",
    "biliti": "ble", "bli": "ble", "ogi": "og", "fulli": "ful", "lessli": "less", "li": "",
}
_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic", "ical": "ic",
    "ful": "", "ness": "", "ative": "",
}
_STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ism", "ate",
          "iti", "ous", "ive", "ize", "ion")

_SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
    "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
    "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_EXC1A = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def english_stem(word):
    if len(word) <= 2:
        return word
    if word in _SPECIAL:
        return _SPECIAL[word]
    if word.startswith("'"):
        word = word[1:]
        if len(word) <= 2:
            return word
    word = _mark_y(word)
    r1, r2 = _regions(word, ("gener", "commun", "arsen"))
    # step 0
    s = _longest(word, ("'s'", "'s", "'"))
    if s:
        word = word[: -len(s)]
    # step 1a
    s = _longest(word, ("sses", "ied", "ies", "us", "ss", "s"))
    if s == "sses":
        word = word[:-2]
    elif s in ("ied", "ies"):
        word = word[:-3] + ("i" if len(word) > 4 else "ie")
    elif s == "s":
        if any(c in V for c in word[:-2]):
            word = word[:-1]
    if word in _EXC1A:
        return word.replace("Y", "y")
    r1 = min(r1, len(word))
    r2 = min(r2, len(word))
    # step 1b
    s = _longest(word, ("eedly", "ingly", "edly", "eed", "ing", "ed"))
    if s in ("eed", "eedly"):
        if len(word) - len(s) >= r1:
            word = word[: -len(s)] + "ee"
    elif s:
        stem = word[: -len(s)]
        if any(c in V for c in stem):
            word = _step1b_tail(stem, r1, True)
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in V:
        word = word[:-1] + "i"
    r1 = min(r1, len(word))
    r2 = min(r2, len(word))
    # step 2
    s = _longest(word, _STEP2)
    if s and len(word) - len(s) >= r1:
        stem = word[: -len(s)]
        if s == "ogi":
            if stem.endswith("l"):
                word = stem + "og"
        elif s == "li":
            if stem and stem[-1] in "cdeghkmnrt":
                word = stem
        else:
            word = stem + _STEP2[s]
    # step 3
    s = _longest(word, _STEP3)
    if s and len(word) - len(s) >= r1:
        stem = word[: -len(s)]
        if s == "ative":
            if len(word) - len(s) >= r2:
                word = stem
        else:
            word = stem + _STEP3[s]
    # step 4
    s = _longest(word, _STEP4)
    if s and len(word) - len(s) >= r2:
        stem = word[: -len(s)]
        if s == "ion":
            if stem and stem[-1] in "st":
                word = stem
        else:
            word = stem
    # step 5
    if word.endswith("e"):
        stem = word[:-1]
        if len(stem) >= r2 or (len(stem) >= r1 and not _short_syllable(stem)):
            word = stem
    elif word.endswith("l") and len(word) - 1 >= r2 and word[-2:-1] == "l":
        word = word[:-1]
    return word.replace("Y", "y")


_P2 = {
    "ational": "ate", "tional": "tion", "enci": "ence", "anci": "ance", "izer": "ize", "abli": "able",
    "alli": "al", "entli": "ent", "eli": "e", "ousli": "ous", "ization": "ize", "ation": "ate",
    "ator": "ate", "alism": "al", "iveness": "ive", "fulness": "ful", "ousness": "ous", "aliti": "al",
    "iviti": "ive", "biliti": "ble",
}
_P3 = {"icate": "ic", "ative": "", "alize": "al", "iciti": "ic", "ical": "ic", "ful": "", "ness": ""}
_P4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ion", "ou", "ism",
       "ate", "iti", "ous", "ive", "ize")


def porter_stem(word):
    if len(word) <= 2:
        return word
    word = _mark_y(word)
    r1, r2 = _regions(word)
    # 1a
    s = _longest(word, ("sses", "ies", "ss", "s"))
    if s == "sses":
        word = word[:-2]
    elif s == "ies":
        word = word[:-2]
    elif s == "s":
        word = word[:-1]
    r1 = min(r1, len(word))
    r2 = min(r2, len(word))
    # 1b
    s = _longest(word, ("eed", "ed", "ing"))
    if s == "eed":
        if len(word) - 3 >= r1:
            word = word[:-1]
    elif s:
        stem = word[: -len(s)]
        if any(c in V for c in stem):
            word = _step1b_tail(stem, r1, False)
    # 1c
    if word.endswith(("y", "Y")) and any(c in V for c in word[:-1]):
        word = word[:-1] + "i"
    r1 = min(r1, len(word))
    r2 = min(r2, len(word))
    s = _longest(word, _P2)
    if s and len(word) - len(s) >= r1:
        word = word[: -len(s)] + _P2[s]
    s = _longest(word, _P3)
    if s and len(word) - len(s) >= r1:
        word = word[: -len(s)] + _P3[s]
    s = _longest(word, _P4)
    if s and len(word) - len(s) >= r2:
        stem = word[: -len(s)]
        if s == "ion":
            if stem and stem[-1] in "st":
                word = stem
        else:
            word = stem
    if word.endswith("e"):
        stem = word[:-1]
        if len(stem) >= r2 or (len(stem) >= r1 and not _short_syllable(stem, False)):
            word = stem
    if word.endswith("ll") and len(word) - 1 >= r2:
        word = word[:-1]
    return word.replace("Y", "y")
