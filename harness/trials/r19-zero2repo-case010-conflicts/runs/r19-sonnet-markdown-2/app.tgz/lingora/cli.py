"""Command line group."""
import sys

from lingora.tokenize import word_tokenize


class _Group:
    def __init__(self):
        self.commands = {"tokenize": self._tokenize}

    def main(self, args=None, standalone_mode=True, **kw):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            if not args or args[0] not in self.commands:
                raise _UsageError("Usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING] [--preserve-line]")
            rv = self.commands[args[0]](args[1:])
        except SystemExit:
            raise
        except BaseException as e:  # noqa: BLE001
            if not standalone_mode:
                raise
            code = 2 if isinstance(e, _UsageError) else 1
            print("Error: %s" % e, file=sys.stderr)
            sys.exit(code)
        if standalone_mode:
            sys.exit(0)
        return rv

    __call__ = main

    def _tokenize(self, args):
        language, delimiter, encoding, preserve = "english", " ", "utf-8", False
        i = 0
        while i < len(args):
            a = args[i]
            if a in ("-l", "--language"):
                language = args[i + 1]; i += 2
            elif a in ("-d", "--delimiter"):
                delimiter = args[i + 1]; i += 2
            elif a in ("-e", "--encoding"):
                encoding = args[i + 1]; i += 2
            elif a in ("-p", "--preserve-line"):
                preserve = True; i += 1
            else:
                raise _UsageError("Unknown option %r" % a)
        language = {"en": "english", "ru": "russian"}.get(language, language)
        stdin = sys.stdin
        if hasattr(stdin, "buffer"):
            text = stdin.buffer.read().decode(encoding)
        else:
            text = stdin.read()
        lines = text.splitlines()
        out = []
        for line in lines:
            out.append(delimiter.join(word_tokenize(line, language, preserve)))
        if out:
            sys.stdout.write("\n".join(out) + "\n")
            sys.stdout.flush()


class _UsageError(Exception):
    pass


cli = _Group()
