"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children=None):
        if children is None:
            raise TypeError("Tree requires a list of children")
        if isinstance(children, (str, bytes)):
            raise TypeError("children should be a list, not a string")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def subtrees(self):
        yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees()

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def copy(self, deep=False):
        import copy as _c
        return _c.deepcopy(self) if deep else Tree(self._label, list(self))

    def productions(self):
        from lingora.grammar import Nonterminal, Production
        rhs = [Nonterminal(c.label()) if isinstance(c, Tree) else c for c in self]
        out = [Production(Nonterminal(self._label), rhs)]
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    @classmethod
    def fromstring(cls, s, brackets="()"):
        op, cl = brackets
        toks = re.findall(r"%s|%s|[^\s%s%s]+" % (re.escape(op), re.escape(cl), re.escape(op), re.escape(cl)), s)
        if not toks or toks[0] != op:
            raise ValueError("Tree.fromstring: expected %r at start of %r" % (op, s))
        pos = 0

        def parse(pos):
            # toks[pos] == op
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in (op, cl):
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("Tree.fromstring: missing %r" % cl)
                t = toks[pos]
                if t == cl:
                    return cls(label, children), pos + 1
                if t == op:
                    child, pos = parse(pos)
                    children.append(child)
                else:
                    children.append(t)
                    pos += 1

        tree, pos = parse(0)
        if pos != len(toks):
            raise ValueError("Tree.fromstring: unexpected text after tree")
        return tree

    def _flat(self):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat())
            elif isinstance(c, tuple):
                parts.append("/".join(c))
            else:
                parts.append(str(c))
        return "(%s %s)" % (self._label, " ".join(parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            elif isinstance(c, tuple):
                s += "\n" + " " * (indent + 2) + "/".join(c)
            else:
                s += "\n" + " " * (indent + 2) + str(c)
        return s + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))
