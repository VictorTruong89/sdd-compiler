"""Tokenizers."""
import html
import re

from lingora import punkt as _punkt


class TokenizerI:
    def tokenize(self, text):
        raise NotImplementedError

    def span_tokenize(self, text):
        raise NotImplementedError


class RegexpTokenizer(TokenizerI):
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        return self._regexp.findall(text)

    def span_tokenize(self, text):
        if self._gaps:
            for left, right in self._gap_spans(text):
                if not (self._discard_empty and left == right):
                    yield left, right
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def _gap_spans(self, text):
        last = 0
        for m in self._regexp.finditer(text):
            if m.end() > m.start():
                yield last, m.start()
                last = m.end()
        yield last, len(text)

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# --------------------------------------------------------------- Treebank
class TreebankWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r) for r in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r) for r in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedWordTokenizer(TreebankWordTokenizer):
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("([‒–—―])"), r" \1 "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = TreebankWordTokenizer.CONTRACTIONS2[1:]


_improved = _ImprovedWordTokenizer()


def sent_tokenize(text, language="english"):
    return _punkt.load_tokenizer(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _improved.tokenize(sent)]


# ------------------------------------------------------------------ Tweets
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""
_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_REGEXPS = (
    _URLS,
    _PHONE,
    _EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
    """,
)
_WORD_RE = re.compile(r"(%s)" % "|".join(_REGEXPS), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_LENGTHEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_ENTITY_RE = re.compile(r"&(#?(x?))([^&;\s]+);")


def _replace_entities(text):
    def sub(m):
        try:
            return html.unescape(m.group(0))
        except Exception:
            return m.group(0)
    return _ENTITY_RE.sub(sub, text)


class TweetTokenizer(TokenizerI):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = _replace_entities(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTHEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = _WORD_RE.findall(safe)
        # findall with a single outer group returns strings
        words = [w if isinstance(w, str) else w[0] for w in words]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
