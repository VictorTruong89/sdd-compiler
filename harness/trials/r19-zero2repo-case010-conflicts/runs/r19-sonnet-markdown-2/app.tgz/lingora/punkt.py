"""Punkt sentence-boundary detection using packaged parameters."""
import os
import re
import string
from collections import defaultdict

from lingora import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

SENT_END = (".", "?", "!")
_RE_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_RE_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_RE_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_FMT = r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )"""
_PERIOD_FMT = r"""
        [%(SentEndChars)s]
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))"""
_WORD_RE = re.compile(
    _WORD_FMT % {"MultiChar": _RE_MULTI, "WordStart": _RE_WORD_START, "NonWord": _RE_NON_WORD},
    re.UNICODE | re.VERBOSE,
)
_PERIOD_RE = re.compile(
    _PERIOD_FMT % {"NonWord": _RE_NON_WORD, "SentEndChars": re.escape("".join(SENT_END))},
    re.UNICODE | re.VERBOSE,
)
_REALIGN = re.compile(r"""["\')\]}]+?(?:\s+|(?=--)|$)""", re.UNICODE)

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "type", "parastart", "linestart", "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def period_final(self):
        return self.tok.endswith(".")

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParams:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = defaultdict(int)


class PunktTokenizer:
    def __init__(self, params):
        self._params = params

    # --- word-level annotation
    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                toks = iter(_WORD_RE.findall(line))
                try:
                    tok = next(toks)
                except StopIteration:
                    continue
                yield _Tok(tok, parastart=parastart, linestart=True)
                parastart = False
                for tok in toks:
                    yield _Tok(tok)
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        p = self._params
        if tok in SENT_END:
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if tok[:-1].lower() in p.abbrev_types or tok[:-1].lower().split("-")[-1] in p.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True
        return t

    def _ortho(self, t):
        if t.tok in SENT_END:
            return False
        oc = self._params.ortho_context[t.type_no_sentperiod]
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        p = self._params
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            ss = self._ortho(t2)
            if ss is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            ss = self._ortho(t2)
            if ss is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if ss == "unknown" and initial and t2.first_upper and not (p.ortho_context[next_typ] & _ORTHO_LC):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = [self._first_pass(t) for t in tokens]
        for i, t in enumerate(toks):
            self._second(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for t in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return 0

    def _contexts(self, text):
        prev_slice = slice(0, 0)
        prev_match = None
        for match in _PERIOD_RE.finditer(text):
            before = text[prev_slice.stop:match.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice.stop + 1
            else:
                idx = prev_slice.start
            word_slice = slice(idx, match.start())
            if prev_match and prev_slice.stop <= word_slice.start:
                yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = word_slice
        if prev_match:
            yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, ctx in self._contexts(text):
            if self._contains_sentbreak(ctx):
                yield slice(last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield slice(last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for k, s1 in enumerate(slices):
            s2 = slices[k + 1] if k + 1 < len(slices) else None
            s1 = slice(s1.start + realign, s1.stop)
            if s2 is None:
                if text[s1]:
                    yield s1
                continue
            m = _REALIGN.match(text[s2])
            if m:
                yield slice(s1.start, s2.start + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1]:
                    yield s1

    def span_tokenize(self, text, realign_boundaries=True):
        sl = self._slices(text)
        if realign_boundaries:
            sl = self._realign(text, sl)
        for s in sl:
            yield (s.start, s.stop)

    def tokenize(self, text, realign_boundaries=True):
        return [text[a:b] for a, b in self.span_tokenize(text, realign_boundaries)]


_cache = {}


def _read(path):
    with open(path, encoding="utf-8") as f:
        return f.read().split("\n")


def load_params(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    files = ["abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"]
    key = [d]
    for f in files:
        p = os.path.join(d, f)
        if not os.path.isfile(p):
            raise LookupError("Punkt model file missing: %s" % p)
        st = os.stat(p)
        key.append((st.st_mtime_ns, st.st_size))
    key = tuple(key)
    if key in _cache:
        return _cache[key]
    params = PunktParams()
    for l in _read(os.path.join(d, files[0])):
        if l:
            params.abbrev_types.add(l)
    for l in _read(os.path.join(d, files[1])):
        if l:
            params.sent_starters.add(l)
    for l in _read(os.path.join(d, files[2])):
        if l:
            parts = l.split("\t")
            if len(parts) >= 2:
                params.collocations.add((parts[0], parts[1]))
    for l in _read(os.path.join(d, files[3])):
        if l:
            parts = l.split("\t")
            if len(parts) >= 2:
                params.ortho_context[parts[0]] = int(parts[1])
    _cache.clear()
    _cache[key] = params
    return params


def load_tokenizer(language="english"):
    return PunktTokenizer(load_params(language))
