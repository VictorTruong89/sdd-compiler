"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from lingora import data


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        self._backoff = backoff

    @property
    def backoff(self):
        return self._backoff

    def tag(self, tokens):
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), t) for rx, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, t in self._regexps:
            if rx.match(tokens[index]):
                return t
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = dict(model) if model else {}
        self._cutoff = cutoff
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._context_to_tag.get(ctx)

    def _train(self, corpus):
        fd = defaultdict(Counter)
        useful = set()
        for sent in corpus:
            sent = list(sent)
            tokens = [w for w, _ in sent]
            tags = [t for _, t in sent]
            for i, (_, tag) in enumerate(sent):
                ctx = self.context(tokens, i, tags[:i])
                if ctx is None:
                    continue
                fd[ctx][tag] += 1
                if self._backoff is None or tag != self._backoff.tag_one(tokens, i, tags[:i]):
                    useful.add(ctx)
        for ctx in fd:
            if ctx not in useful:
                continue
            counter = fd[ctx]
            best = max(counter, key=lambda t: counter[t])
            if counter[best] > self._cutoff:
                self._context_to_tag[ctx] = best


class UnigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        prev = history[index - 1] if index >= 1 else None
        return (prev, tokens[index])


class TrigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        p1 = history[index - 1] if index >= 1 else None
        p2 = history[index - 2] if index >= 2 else None
        return (p2, p1, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, model, backoff, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[: self._affix_length]
        return token[self._affix_length:]


# ------------------------------------------------------ perceptron tagger
START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]


class PerceptronTagger(TaggerI):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                w = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                td = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                cl = json.load(f)
        except OSError as e:
            raise LookupError("Tagger model files missing for %r: %s" % (lang, e))
        return cls(w, td, cl)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = START
        out = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RU_MAP = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "ADVPRO": "ADV", "NUM": "NUM",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "SPRO": "PRON", "APRO": "DET", "INTJ": "X", "COM": "X",
    "NONLEX": "X",
}


def _universal_map():
    p = data.find("taggers/universal_tagset/en-ptb.map")
    m = {}
    with open(p, encoding="utf-8") as f:
        for line in f.read().split("\n"):
            parts = line.split("\t")
            if len(parts) >= 2:
                m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens: expected a list of strings, got a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, only 'eng' and 'rus' are supported.")
    tokens = list(tokens)
    tagger = PerceptronTagger.load(lang)
    tagged = tagger.tag(tokens)
    if tagset is None:
        return tagged
    if tagset != "universal":
        raise ValueError("unsupported tagset %r" % (tagset,))
    if lang == "eng":
        m = _universal_map()
        return [(w, m.get(t, "X") if t is not None else None) for w, t in tagged]
    return [(w, _RU_MAP.get(t.split("=")[0], "X") if t is not None else None) for w, t in tagged]
