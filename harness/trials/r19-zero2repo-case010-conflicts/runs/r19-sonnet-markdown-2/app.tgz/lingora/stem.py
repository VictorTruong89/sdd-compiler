"""Stemmers and lemmatizer."""
import os
import re

from lingora import data
from lingora._lancaster import LancasterStemmer  # noqa: F401
from lingora._porter import PorterStemmer  # noqa: F401
from lingora import _snowball_en


class StemmerI:
    def stem(self, token):
        raise NotImplementedError


class RegexpStemmer(StemmerI):
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)

    def __repr__(self):
        return "<RegexpStemmer: %r>" % self._regexp.pattern


class SnowballStemmer(StemmerI):
    languages = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                 "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish")

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % language)
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            try:
                lines = data.read_lines("corpora/stopwords/%s" % language)
            except (LookupError, OSError) as e:
                raise LookupError("Stopwords list for language %r is not available: %s" % (language, e))
            self.stopwords = {l.strip() for l in lines if l.strip()}
        self._impl = _load_impl(language)

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self._impl(word)

    def __repr__(self):
        return "<SnowballStemmer(%s)>" % self.language


def _load_impl(language):
    if language == "english":
        return _snowball_en.english_stem
    if language == "porter":
        return _snowball_en.porter_stem
    from lingora import _snowball_other
    return _snowball_other.get(language)


# ---------------------------------------------------------------- Arabic
_AR_PREFIXES = ("وال", "بال", "كال", "فال", "لل", "ال", "و", "ف", "ب", "ك", "ل")
_AR_SUFFIXES = ("ات", "ون", "ين", "ان", "ها", "نا", "كم", "هم", "ة", "ه", "ي", "ك")
_AR_DIAC = re.compile("[ً-ْـ]")


class ARLSTem(StemmerI):
    """Light Arabic stemmer (approximation of the ARLSTem family)."""

    def stem(self, token):
        w = _AR_DIAC.sub("", token)
        for p in _AR_PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in _AR_SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[: -len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


# ------------------------------------------------------------- WordNet
_DETACH = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"),
          ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_WN_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv", "s": "adj"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = data.find("corpora/wordnet")
        self._index = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._index:
            return
        name = _WN_FILES[pos]
        words = set()
        p = os.path.join(self._dir, "index." + name)
        if not os.path.isfile(p):
            raise LookupError("WordNet file missing: %s" % p)
        with open(p, encoding="utf-8") as f:
            for line in f:
                if line.startswith(" ") or not line.strip():
                    continue
                words.add(line.split(" ", 1)[0])
        exc = {}
        pe = os.path.join(self._dir, name + ".exc")
        if os.path.isfile(pe):
            with open(pe, encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], []).append(parts[1])
        self._index[pos] = words
        self._exc[pos] = exc

    def _morphy(self, form, pos):
        self._load(pos)
        words, exc = self._index[pos], self._exc[pos]
        form = form.lower()
        out = []
        if form in exc:
            out.extend(exc[form])
        if form in words:
            out.append(form)
        cands = [form]
        for suf, rep in _DETACH[pos]:
            if form.endswith(suf):
                cands.append(form[: len(form) - len(suf)] + rep)
        for c in cands[1:]:
            if c in words and c not in out:
                out.append(c)
        return out

    def lemmatize(self, word, pos="n"):
        pos = {"noun": "n", "verb": "v", "adj": "a", "adv": "r"}.get(pos, pos)
        lemmas = self._morphy(word, pos if pos in _WN_FILES else "n")
        return min(lemmas, key=len) if lemmas else word
