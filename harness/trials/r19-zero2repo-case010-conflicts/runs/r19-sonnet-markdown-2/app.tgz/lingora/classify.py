"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict


class DictProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, sample):
        return float(self._probs.get(sample, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda s: self._probs[s])


ProbDist = DictProbDist


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist  # {label: prob}
        self._feature_probdist = feature_probdist  # {(label, fname): (counter, N, bins)}

    @staticmethod
    def train(labeled_featuresets):
        labeled_featuresets = list(labeled_featuresets)
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = set()
        for fs, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in fs.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                count = sum(feature_freq[label, fname].values()) if (label, fname) in feature_freq else 0
                if n - count > 0:
                    feature_freq[label, fname][None] += n - count
                    feature_values[fname].add(None)
        total = sum(label_freq.values())
        b = len(label_freq)
        label_probs = {l: (c + 0.5) / (total + 0.5 * b) for l, c in label_freq.items()}
        fprobs = {}
        for (label, fname), fd in feature_freq.items():
            fprobs[label, fname] = (fd, sum(fd.values()), len(feature_values[fname]))
        return NaiveBayesClassifier(label_probs, fprobs)

    def labels(self):
        return list(self._label_probdist.keys())

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        labels = self.labels()
        for fname in list(featureset):
            if not any((l, fname) in self._feature_probdist for l in labels):
                del featureset[fname]
        logp = {}
        for label in labels:
            lp = math.log(self._label_probdist[label])
            for fname, fval in featureset.items():
                if (label, fname) in self._feature_probdist:
                    fd, n, bins = self._feature_probdist[label, fname]
                    lp += math.log((fd.get(fval, 0) + 0.5) / (n + 0.5 * bins))
                else:
                    lp = float("-inf")
            logp[label] = lp
        m = max(logp.values())
        if m == float("-inf"):
            probs = {l: 1.0 / len(logp) for l in logp}
        else:
            exps = {l: math.exp(v - m) for l, v in logp.items()}
            z = sum(exps.values())
            probs = {l: v / z for l, v in exps.items()}
        return DictProbDist(probs)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]

    def show_most_informative_features(self, n=10):
        pass


def _entropy(counter):
    total = sum(counter.values())
    if not total:
        return 0.0
    return -sum((c / total) * math.log2(c / total) for c in counter.values() if c)


def _top(counter):
    best, bc = None, -1
    for k, c in counter.items():
        if c > bc:
            best, bc = k, c
    return best


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        out = [self._label]
        if self._decisions:
            for d in self._decisions.values():
                out.extend(d.labels())
        if self._default is not None:
            out.extend(self._default.labels())
        return list(dict.fromkeys(out))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]

    def error(self, labeled_featuresets):
        errors = sum(1 for fs, l in labeled_featuresets if self.classify(fs) != l)
        return errors / len(labeled_featuresets)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10, binary=False,
              feature_values=None, verbose=False):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("Cannot train a decision tree on no data")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for k in fs:
                if k not in seen:
                    seen.add(k)
                    names.append(k)
        if not names:
            return DecisionTreeClassifier(_top(Counter(l for _, l in labeled_featuresets)))
        best = None
        best_err = None
        for fname in names:
            st = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = st.error(labeled_featuresets)
            if best is None or err < best_err:
                best, best_err = st, err
        best.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return best

    @staticmethod
    def stump(fname, labeled_featuresets):
        label = _top(Counter(l for _, l in labeled_featuresets))
        freqs = {}
        for fs, l in labeled_featuresets:
            freqs.setdefault(fs.get(fname), Counter())[l] += 1
        decisions = {v: DecisionTreeClassifier(_top(c)) for v, c in freqs.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    def refine(self, labeled_featuresets, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled_featuresets) <= support_cutoff:
            return
        if self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) == fval]
            if sub and _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) not in self._decisions]
            if sub and _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(sub, entropy_cutoff, depth_cutoff, support_cutoff)


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0
    results = [classifier.classify(fs) for fs, _ in gold]
    return sum(1 for r, (_, l) in zip(results, gold) if r == l) / len(gold)
