"""Exhaustive chart-style parser."""
from lingora.grammar import Nonterminal
from lingora.tree import Tree


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse_all(tokens, tree_class))

    def _parse_all(self, tokens, tree_class):
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()
        state = {"cut": False}

        def parse_sym(sym, i, j):
            """All trees/leaves for sym spanning tokens[i:j]."""
            if isinstance(sym, str):
                return [sym] if j == i + 1 and tokens[i] == sym else []
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                state["cut"] = True
                return []
            active.add(key)
            saved = state["cut"]
            state["cut"] = False
            results = []
            for prod in g.productions(sym):
                for kids in parse_seq(prod.rhs(), 0, i, j):
                    results.append(tree_class(str(sym), kids))
            active.discard(key)
            if not state["cut"]:
                memo[key] = results
            state["cut"] = state["cut"] or saved
            return results

        def parse_seq(rhs, k, i, j):
            if k == len(rhs):
                return [[]] if i == j else []
            sym = rhs[k]
            last = k == len(rhs) - 1
            out = []
            if last:
                ends = [j]
            else:
                ends = range(i if isinstance(sym, Nonterminal) else i + 1, j + 1)
            for e in ends:
                firsts = parse_sym(sym, i, e)
                if not firsts:
                    continue
                rests = parse_seq(rhs, k + 1, e, j)
                for f in firsts:
                    for r in rests:
                        out.append([f] + r)
            return out

        trees = parse_sym(g.start(), 0, n)
        uniq = []
        for t in trees:
            if t not in uniq:
                uniq.append(t)
        return uniq
