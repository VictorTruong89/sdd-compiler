from lingora.parse.chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Exhaustive parser; shares the chart parser's results."""
