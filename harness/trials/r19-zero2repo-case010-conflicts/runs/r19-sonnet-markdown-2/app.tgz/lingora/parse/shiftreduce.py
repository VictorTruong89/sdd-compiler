"""Shift-reduce parser (single pass, no backtracking)."""
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens))

    def _match(self, stack, rhs):
        n = len(rhs)
        if n == 0 or len(stack) < n:
            return False
        for item, sym in zip(stack[-n:], rhs):
            if isinstance(sym, str):
                if not (isinstance(item, str) and item == sym):
                    return False
            else:
                if not (isinstance(item, Tree) and item.label() == str(sym)):
                    return False
        return True

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            if self._match(stack, rhs):
                n = len(rhs)
                children = stack[-n:]
                del stack[-n:]
                stack.append(Tree(str(prod.lhs()), children))
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return [stack[0]]
        return []
