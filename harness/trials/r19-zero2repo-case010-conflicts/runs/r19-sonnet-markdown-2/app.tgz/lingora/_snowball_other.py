"""Snowball stemmers for languages other than English/Porter."""


def get(language):
    raise NotImplementedError("Snowball stemmer for %r is not implemented in this build" % language)
