"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % self._symbol


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        return "%s -> %s" % (self._lhs, " ".join(repr(s) if isinstance(s, str) else str(s) for s in self._rhs))

    __repr__ = __str__


_TOKEN = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


def _split_rhs(text):
    """Split an RHS into alternatives of symbols."""
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m:
            break
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3):
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return list(self._lhs_index.get(lhs, []))

    def terminals(self):
        return set(self._terminals)

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._terminals]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r." % missing)

    @classmethod
    def fromstring(cls, input, encoding=None):
        prods = []
        start = None
        if not isinstance(input, str):
            input = "\n".join(input)
        for line in input.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\S+)\s*(?:->|→)\s*(.*)$", line)
            if not m:
                raise ValueError("Unable to parse line: %r" % line)
            lhs = Nonterminal(m.group(1))
            if start is None:
                start = lhs
            for alt in _split_rhs(m.group(2)):
                prods.append(Production(lhs, alt))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, prods)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + "\n".join(
            "    %s" % p for p in self._productions
        )

    __repr__ = __str__
