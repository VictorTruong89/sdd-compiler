"""Packaged-resource finder. ``path`` is a mutable list of directories."""
import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path += [
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/app/lingora_data",
]


def find(resource):
    """Return the filesystem path of ``resource`` or raise LookupError."""
    rel = resource.strip("/")
    for d in list(path):
        cand = os.path.join(str(d), *rel.split("/"))
        if os.path.exists(cand):
            return cand
    raise LookupError(
        "Resource %r not found in data.path directories: %r" % (resource, list(path))
    )


def read_lines(resource):
    p = find(resource)
    with open(p, encoding="utf-8") as f:
        return f.read().split("\n")
