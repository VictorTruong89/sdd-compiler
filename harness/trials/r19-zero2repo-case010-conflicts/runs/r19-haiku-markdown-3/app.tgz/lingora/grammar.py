"""Context-free grammars (FP-05)."""

import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    """A nonterminal symbol. ``str()`` is its name."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._name == other._name
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        parts = []
        for item in self._rhs:
            parts.append(str(item) if isinstance(item, Nonterminal) else repr(item))
        return "%s -> %s" % (self._lhs, " ".join(parts))


_RHS_TOKEN = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")
_LHS = re.compile(r"^\s*([^\s'\"|]+)\s*->(.*)$")


def _parse_rhs_alternatives(text):
    """Split the right-hand side text into alternatives of items."""
    alternatives = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _RHS_TOKEN.match(text, pos)
        if not m or m.end() == pos:
            if text[pos:].strip() == "":
                break
            raise ValueError("cannot read production text: %r" % text[pos:])
        pos = m.end()
        single, double, bar, bare = m.group(1), m.group(2), m.group(3), m.group(4)
        if bar:
            alternatives.append([])
        elif single is not None:
            alternatives[-1].append(single)
        elif double is not None:
            alternatives[-1].append(double)
        else:
            alternatives[-1].append(Nonterminal(bare))
    return alternatives


class CFG:
    def __init__(self, productions):
        self._productions = list(productions)
        if not self._productions:
            raise ValueError("a grammar needs at least one production")
        self._start = self._productions[0].lhs()
        self._by_lhs = {}
        for prod in self._productions:
            self._by_lhs.setdefault(prod.lhs(), []).append(prod)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring takes grammar text")
        productions = []
        for raw in input.splitlines():
            if not raw.strip():
                continue
            m = _LHS.match(raw)
            if not m:
                raise ValueError("production must read 'LHS -> RHS': %r" % raw)
            lhs = Nonterminal(m.group(1))
            for alt in _parse_rhs_alternatives(m.group(2)):
                productions.append(Production(lhs, alt))
        return cls(productions)

    def start(self):
        return self._start

    def productions(self):
        return list(self._productions)

    def productions_for(self, lhs):
        return list(self._by_lhs.get(_as_nonterminal(lhs), []))

    def terminals(self):
        out = set()
        for prod in self._productions:
            for item in prod.rhs():
                if isinstance(item, str) and item != "":
                    out.add(item)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


def _as_nonterminal(sym):
    return sym if isinstance(sym, Nonterminal) else Nonterminal(str(sym))
