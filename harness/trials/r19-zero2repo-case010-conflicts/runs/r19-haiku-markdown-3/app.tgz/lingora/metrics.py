"""Evaluation metrics (FP-07)."""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists agree."""
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs two lists of equal length")
    if not reference:
        return 0.0
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def _levenshtein(s1, s2, sub):
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else sub
            cur[j] = min(prev[j - 1] + cost, cur[j - 1] + 1, prev[j] + 1)
        prev = cur
    return prev[len(s2)]


def _damerau(s1, s2, sub):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    la, lb = len(s1), len(s2)
    maxdist = la + lb
    d = [[0] * (lb + 2) for _ in range(la + 2)]
    d[0][0] = maxdist
    for i in range(la + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(lb + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, la + 1):
        last_col = 0
        for j in range(1, lb + 1):
            k = last_row.get(s2[j - 1], 0)
            l = last_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_col = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        last_row[s1[i - 1]] = i
    return d[la + 1][lb + 1]


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Edit distance; with ``transpositions`` it is Damerau-Levenshtein."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two strings")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    return _levenshtein(s1, s2, substitution_cost)


def jaccard_distance(label1, label2):
    a = set(label1)
    b = set(label2)
    union = a | b
    if not union:
        return 0.0
    return len(a ^ b) / len(union)


def _require_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    _require_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or not (reference & test):
        return None
    if p == 0 or r == 0:
        return 0
    return 1 / (alpha / p + (1 - alpha) / r)
