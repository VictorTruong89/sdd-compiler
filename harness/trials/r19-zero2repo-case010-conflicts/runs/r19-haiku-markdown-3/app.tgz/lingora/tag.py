"""Part-of-speech taggers (FP-03)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


class _SequentialTagger:
    backoff = None

    def _tag_raw(self, tokens):
        """Return one tag (str or None) per token."""
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tag() takes a list of tokens, not a string")
        tokens = list(tokens)
        tags = list(self._tag_raw(tokens))
        if self.backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                sub = self.backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, sub):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    def __init__(self, tag, backoff=None):
        self._tag = tag
        self.backoff = backoff

    def _tag_raw(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        counts = defaultdict(Counter)
        first_seen = {}
        for sent in train or []:
            for word, tag in sent:
                counts[word][tag] += 1
                first_seen.setdefault((word, tag), len(first_seen))
        self._model = {}
        for word, ctr in counts.items():
            # most frequent tag; ties go to the tag seen first in training
            best = max(ctr.items(),
                       key=lambda kv: (kv[1], -first_seen[(word, kv[0])]))
            self._model[word] = best[0]

    def _tag_raw(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(_SequentialTagger):
    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = [(re.compile(pat), tag) for pat, tag in regexps]

    def _tag_raw(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for pat, t in self._rules:
                if pat.match(tok):
                    tag = t
                    break
            out.append(tag)
        return out


# ---------------------------------------------------- averaged perceptron

_PT_RESOURCE = {"eng": "averaged_perceptron_tagger_eng",
                "rus": "averaged_perceptron_tagger_rus"}
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            for label, weight in self.weights.get(feat, {}).items():
                scores[label] += value * weight
        return max(self.classes, key=lambda lbl: (scores[lbl], lbl))


_MODEL_CACHE = {}


def _load_perceptron(lang):
    if lang in _MODEL_CACHE:
        return _MODEL_CACHE[lang]
    if lang not in _PT_RESOURCE:
        raise ValueError("unsupported tagger language: %r" % (lang,))
    directory = data.require(os.path.join("taggers", _PT_RESOURCE[lang]))
    base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)

    def load_json(suffix):
        with open(base + suffix, encoding="utf-8") as fh:
            return json.load(fh)

    model = _PerceptronModel(
        load_json(".weights.json"),
        load_json(".tagdict.json"),
        load_json(".classes.json"),
    )
    _MODEL_CACHE[lang] = model
    return model


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


def _perceptron_tag(model, tokens):
    prev, prev2 = _START
    context = _START + [_normalize(w) for w in tokens] + _END
    out = []
    for i, word in enumerate(tokens):
        tag = model.tagdict.get(word)
        if not tag:
            feats = _features(i, word, context, prev, prev2)
            tag = model.predict(feats)
        out.append(tag)
        prev2, prev = prev, tag
    return out


# Russian National Corpus part-of-speech category -> universal tag.
_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM", "INTJ": "INTJ",
    "ANUM": "ADJ", "APRO": "DET", "SPRO": "PRON", "PRO": "PRON",
    "ADVPRO": "ADV", "PRAEDIC": "ADV", "PRED": "ADV", "PARENTH": "PRT",
    "NONLEX": "X", "INIT": "X", "ADJ": "ADJ", "NOUN": "NOUN", "VERB": "VERB",
}

_UNIVERSAL_MAP_CACHE = {}


def _load_en_ptb_map():
    if "en" in _UNIVERSAL_MAP_CACHE:
        return _UNIVERSAL_MAP_CACHE["en"]
    directory = data.require(os.path.join("taggers", "universal_tagset"))
    mapping = {}
    with open(os.path.join(directory, "en-ptb.map"), encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    _UNIVERSAL_MAP_CACHE["en"] = mapping
    return mapping


def _map_universal(lang, tag):
    if tag is None:
        return None
    if lang == "rus":
        pos = tag.split("=", 1)[0].split(",", 1)[0]
        return _RUS_TO_UNIVERSAL.get(pos, "X")
    return _load_en_ptb_map().get(tag, tag)


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a list of tokens with the averaged perceptron tagger."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag() takes a list of tokens, not a string")
    if lang not in _PT_RESOURCE:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    tokens = list(tokens)
    model = _load_perceptron(lang)
    if not tokens:
        return []
    tags = _perceptron_tag(model, tokens)
    if tagset == "universal":
        if lang == "eng":
            _load_en_ptb_map()  # raises if the universal tables are absent
        tags = [_map_universal(lang, t) for t in tags]
    elif tagset is not None:
        raise ValueError("unknown tagset: %r" % (tagset,))
    return list(zip(tokens, tags))
