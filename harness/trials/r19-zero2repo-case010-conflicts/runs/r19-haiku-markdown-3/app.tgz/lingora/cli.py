"""Command line: ``lingora tokenize`` (FP-01).

``cli.main(args=[...], standalone_mode=True)`` runs a command. In standalone
mode it ends the process with status 0 on success and 1 on failure."""

import argparse
import io
import sys

from lingora.tokenize import word_tokenize

__all__ = ["cli"]


def _input_stream(encoding):
    stdin = sys.stdin
    buffer = getattr(stdin, "buffer", None)
    if buffer is not None:
        return io.TextIOWrapper(buffer, encoding=encoding, errors="strict")
    return stdin


def _cmd_tokenize(opts):
    stream = _input_stream(opts.encoding)
    out = sys.stdout
    for raw in stream:
        line = raw.rstrip("\r\n")
        try:
            tokens = word_tokenize(line, language=opts.language, preserve_line=False)
        except Exception as exc:  # missing Punkt model or other failure
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        out.write(opts.delimiter.join(tokens) + "\n")
        out.flush()
    return 0


class _Group:
    def __init__(self):
        self._commands = {"tokenize": _cmd_tokenize}

    def _parser(self):
        parser = argparse.ArgumentParser(prog="lingora")
        sub = parser.add_subparsers(dest="command", metavar="COMMAND")
        sub.required = True
        tok = sub.add_parser("tokenize", help="tokenize each line of standard input")
        tok.add_argument("--language", default="english",
                         help="Punkt language directory name (default: english)")
        tok.add_argument("--delimiter", default=" ",
                         help="string placed between tokens (default: one space)")
        tok.add_argument("--encoding", default="utf-8",
                         help="input encoding (default: utf-8)")
        return parser

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        parser = self._parser()
        try:
            opts = parser.parse_args(list(args))
        except SystemExit as exc:
            if standalone_mode:
                raise
            return exc.code if isinstance(exc.code, int) else 2
        status = self._commands[opts.command](opts)
        if standalone_mode:
            sys.exit(status)
        return status


cli = _Group()


if __name__ == "__main__":
    cli.main()
