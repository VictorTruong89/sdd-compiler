"""Constituent trees (FP-05)."""

import re

__all__ = ["Tree"]

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled ordered tree. Children are leaves (strings or other leaf
    values such as ``(token, tag)`` pairs) or nested :class:`Tree` objects."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children, not %s"
                            % type(children).__name__)
        self._label = label
        self._children = list(children)

    # ------------------------------------------------------------ accessors
    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    # ----------------------------------------------------------- comparison
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    # ----------------------------------------------------------- formatting
    @staticmethod
    def _leaf_text(leaf):
        if isinstance(leaf, tuple) and len(leaf) == 2:
            return "%s/%s" % (leaf[0], leaf[1])
        return str(leaf)

    def pformat(self):
        parts = []
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child.pformat())
            else:
                parts.append(self._leaf_text(child))
        if not parts:
            return "(%s)" % self._label
        return "(%s %s)" % (self._label, " ".join(parts))

    def __str__(self):
        return self.pformat()

    # -------------------------------------------------------------- parsing
    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring takes bracketed text")
        tokens = _TOKEN_RE.findall(s)
        pos = [0]

        def parse_node():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in "()":
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(tokens):
                    raise ValueError("unbalanced parentheses in tree text")
                tok = tokens[pos[0]]
                if tok == ")":
                    pos[0] += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos[0] += 1

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after tree")
        return tree
