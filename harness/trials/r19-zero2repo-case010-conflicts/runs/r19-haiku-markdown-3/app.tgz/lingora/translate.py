"""Sentence-level BLEU (FP-07)."""

import math
from collections import Counter

__all__ = ["bleu"]

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=_DEFAULT_WEIGHTS, smoothing_function=None):
    """Sentence BLEU (Papineni et al., 2002).

    ``references`` is a list of token lists, ``hypothesis`` a token list.
    ``weights`` gives one weight per n-gram order starting from unigrams
    (default: equal weights on unigrams through 4-grams). Without
    ``smoothing_function`` a zero precision for a weighted order gives 0.
    ``smoothing_function(matches, total, n)`` may return a smoothed precision.
    """
    if isinstance(references, str) or isinstance(hypothesis, str):
        raise TypeError("bleu takes token lists, not strings")
    references = [list(r) for r in references]
    hyp = list(hypothesis)
    weights = [float(w) for w in weights]
    if not references:
        raise ValueError("bleu needs at least one reference")

    c = len(hyp)
    if c == 0:
        return 0.0
    ref_len = min((len(r) for r in references),
                  key=lambda rl: (abs(rl - c), rl))
    if c > ref_len:
        bp = 1.0
    else:
        bp = math.exp(1 - ref_len / c)

    log_sum = 0.0
    for n, w in enumerate(weights, start=1):
        cand = _ngrams(hyp, n)
        total = sum(cand.values())
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        matches = sum(min(count, max_ref[gram]) for gram, count in cand.items())
        if smoothing_function is not None:
            p = smoothing_function(matches, total, n)
        else:
            p = matches / total if total else 0.0
        if p <= 0:
            if w > 0:
                return 0.0
            continue
        log_sum += w * math.log(p)
    return bp * math.exp(log_sum)
