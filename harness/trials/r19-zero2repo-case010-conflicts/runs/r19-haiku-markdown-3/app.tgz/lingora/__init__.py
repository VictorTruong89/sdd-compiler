"""Lingora Language Toolkit: natural-language processing building blocks.

Importing the package downloads nothing. Packaged resources (Punkt models,
perceptron taggers, stopwords, WordNet) are looked up on ``lingora.data.path``.
"""

from lingora import data
from lingora import tokenize
from lingora import stem
from lingora import tag
from lingora import chunk
from lingora import grammar
from lingora import tree
from lingora import classify
from lingora import metrics
from lingora import translate
from lingora import parse

__all__ = [
    "chunk",
    "classify",
    "data",
    "grammar",
    "metrics",
    "parse",
    "stem",
    "tag",
    "tokenize",
    "translate",
    "tree",
]
