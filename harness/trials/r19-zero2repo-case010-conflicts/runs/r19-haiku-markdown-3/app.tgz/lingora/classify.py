"""Classifiers (FP-06): Naive Bayes and decision tree."""

import math
from collections import Counter, OrderedDict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_GAMMA = 0.5  # additive smoothing for feature-value estimates


class ProbDist:
    def __init__(self, probs):
        self._probs = OrderedDict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs.items(), key=lambda kv: kv[1])[0]

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    def __init__(self, label_counts, feature_counts, feature_values, label_feature_totals, total):
        self._label_counts = label_counts          # label -> count
        self._feature_counts = feature_counts      # (fname, label) -> Counter(value -> n)
        self._feature_values = feature_values      # fname -> set of values seen
        self._label_feature_totals = label_feature_totals  # (fname, label) -> n featuresets
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        label_counts = OrderedDict()
        feature_counts = {}
        feature_values = {}
        totals = Counter()
        n = 0
        for featureset, label in labeled_featuresets:
            n += 1
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, fval in featureset.items():
                feature_counts.setdefault((fname, label), Counter())[fval] += 1
                feature_values.setdefault(fname, set()).add(fval)
                totals[(fname, label)] += 1
        return cls(label_counts, feature_counts, feature_values, totals, n)

    def labels(self):
        return list(self._label_counts.keys())

    def _log_scores(self, featureset):
        scores = {}
        for label, count in self._label_counts.items():
            logp = math.log(count / self._total)
            for fname, fval in featureset.items():
                if fname not in self._feature_values:
                    continue
                values = self._feature_values[fname]
                seen = self._feature_counts.get((fname, label), Counter())
                denom = self._label_feature_totals.get((fname, label), 0) \
                    + _GAMMA * (len(values) + 1)
                num = seen.get(fval, 0) + _GAMMA
                logp += math.log(num / denom)
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = OrderedDict((lbl, math.exp(s - top)) for lbl, s in scores.items())
        total = sum(weights.values())
        return ProbDist((lbl, w / total) for lbl, w in weights.items())

    def classify(self, featureset):
        dist = self.prob_classify(featureset)
        best = None
        best_p = -1.0
        for label in self.labels():
            p = dist.prob(label)
            if p > best_p:
                best, best_p = label, p
        return best


# ------------------------------------------------------------ decision tree

def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = None
    best_n = -1
    for lbl in labels:  # first-seen tie-break
        if counts[lbl] > best_n:
            best, best_n = lbl, counts[lbl]
    return best


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Split:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


class DecisionTreeClassifier:
    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        examples = [(dict(fs), lbl) for fs, lbl in labeled_featuresets]
        if not examples:
            raise ValueError("cannot train a decision tree on no examples")
        features = []
        for fs, _ in examples:
            for fname in fs:
                if fname not in features:
                    features.append(fname)
        return cls(cls._build(examples, features))

    @staticmethod
    def _build(examples, features):
        labels = [lbl for _, lbl in examples]
        if len(set(labels)) == 1 or not features:
            return _Leaf(_majority(labels))

        base = _entropy(labels)
        best_feature = None
        best_gain = -1.0
        for fname in features:
            values = [fs.get(fname) for fs, _ in examples]
            if len(set(values)) < 2:
                continue
            remainder = 0.0
            groups = {}
            for (fs, lbl), v in zip(examples, values):
                groups.setdefault(v, []).append(lbl)
            for group in groups.values():
                remainder += len(group) / len(labels) * _entropy(group)
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feature, best_gain = fname, gain

        if best_feature is None:
            return _Leaf(_majority(labels))

        groups = OrderedDict()
        for fs, lbl in examples:
            groups.setdefault(fs.get(best_feature), []).append((fs, lbl))
        rest = [f for f in features if f != best_feature]
        children = {v: DecisionTreeClassifier._build(sub, rest) for v, sub in groups.items()}
        return _Split(best_feature, children, _majority(labels))

    def classify(self, featureset):
        node = self._root
        while isinstance(node, _Split):
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.default
            node = child
        return node.label


# ---------------------------------------------------------------- accuracy

def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` classified correctly."""
    gold = list(gold)
    if not gold:
        return 0.0
    correct = sum(1 for fs, lbl in gold if classifier.classify(fs) == lbl)
    return correct / len(gold)
