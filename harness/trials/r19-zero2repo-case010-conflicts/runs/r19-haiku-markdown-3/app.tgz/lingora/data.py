"""Packaged-resource finder.

``path`` is a mutable list of directories searched for packaged resources.
Callers may edit it in place. Importing the package downloads nothing.
"""

import os

_default_dirs = []
_env = os.environ.get("LINGORA_DATA", "")
if _env:
    _default_dirs.extend(p for p in _env.split(os.pathsep) if p)
_default_dirs.append(os.path.join(os.path.expanduser("~"), ".lingora", "data"))

path = _default_dirs


class ResourceNotFound(LookupError):
    """Raised when a packaged resource is not visible on ``path``."""


def find(resource):
    """Return the absolute path of ``resource`` under the first matching
    directory in ``path``, or ``None`` if no directory holds it."""
    for base in list(path):
        if not base:
            continue
        candidate = os.path.join(base, resource)
        if os.path.exists(candidate):
            return candidate
    return None


def require(resource):
    """Like :func:`find`, but raise :class:`ResourceNotFound` if absent."""
    found = find(resource)
    if found is None:
        raise ResourceNotFound(
            "packaged resource %r is not installed (searched %r)"
            % (resource, list(path))
        )
    return found
