"""Stemmers (FP-02)."""

import os
import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

_VOWELS = "aeiou"


# --------------------------------------------------------------------- Porter

_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "news": "news",
    "atlas": "atlas", "cosmos": "cosmos", "bias": "bias", "andes": "andes",
    "innings": "inning", "outings": "outing", "cannings": "canning",
}


def _p_cons(w, i):
    c = w[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _p_cons(w, i - 1)
    return True


def _p_measure(stem):
    count = 0
    seen_vowel = False
    for i in range(len(stem)):
        if _p_cons(stem, i):
            if seen_vowel:
                count += 1
                seen_vowel = False
        else:
            seen_vowel = True
    return count


def _p_has_vowel(stem):
    return any(not _p_cons(stem, i) for i in range(len(stem)))


def _p_double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _p_cons(w, len(w) - 1)


def _p_cvc(w):
    if len(w) == 2:
        return (not _p_cons(w, 0)) and _p_cons(w, 1) and w[-1] not in "wxy"
    if len(w) < 3:
        return False
    return (_p_cons(w, len(w) - 3) and not _p_cons(w, len(w) - 2)
            and _p_cons(w, len(w) - 1) and w[-1] not in "wxy")


_P_STEP2_COMMON = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("entli", "ent"), ("eli", "e"), ("ousli", "ous"),
    ("ization", "ize"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
    ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"),
    ("iviti", "ive"), ("biliti", "ble"), ("alli", "al"),
]
_P_STEP2_CLASSIC = _P_STEP2_COMMON + [("abli", "able")]
_P_STEP2_LINGORA = _P_STEP2_COMMON + [("bli", "ble")]


def _porter_step2(w, extensions):
    if not extensions:
        return _porter_replace(w, _P_STEP2_CLASSIC, lambda s: _p_measure(s) > 0)
    if w.endswith("alli") and _p_measure(w[:-4]) > 0:
        return _porter_step2(w[:-4] + "al", extensions)
    if w.endswith("fulli") and _p_measure(w[:-5]) > 0:
        return w[:-5] + "ful"
    if w.endswith("logi"):
        # -logi -> -log when the part before -ogi has positive measure
        return w[:-1] if _p_measure(w[:-3]) > 0 else w
    return _porter_replace(w, _P_STEP2_LINGORA, lambda s: _p_measure(s) > 0)
_P_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_P_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _porter_replace(w, rules, cond):
    """Apply the longest matching suffix rule; stop after the first suffix
    that matches, whether or not its condition holds."""
    for suffix, repl in sorted(rules, key=lambda r: -len(r[0])):
        if w.endswith(suffix):
            stem = w[: len(w) - len(suffix)]
            if cond(stem):
                return stem + repl
            return w
    return w


def _porter_original_steps(w, extensions):
    """Porter (1980) with optional LINGORA extensions."""
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        w = w[:-2] if not (extensions and len(w) == 4) else w[:-1]
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]

    # Step 1b
    skip_1b = False
    if extensions and w.endswith("ied"):
        w = w[:-1] if len(w) == 4 else w[:-2]
        skip_1b = True
    if not skip_1b:
        if w.endswith("eed"):
            if _p_measure(w[:-3]) > 0:
                w = w[:-1]
        else:
            stem = None
            if w.endswith("ed") and _p_has_vowel(w[:-2]):
                stem = w[:-2]
            elif w.endswith("ing") and _p_has_vowel(w[:-3]):
                stem = w[:-3]
            if stem is not None:
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif _p_double_cons(w) and w[-1] not in "lsz":
                    w = w[:-1]
                elif _p_measure(w) == 1 and _p_cvc(w):
                    w += "e"

    # Step 1c
    if w.endswith("y") and len(w) > 1:
        if extensions:
            if len(w) >= 3 and _p_cons(w, len(w) - 2):
                w = w[:-1] + "i"
        elif _p_has_vowel(w[:-1]):
            w = w[:-1] + "i"

    # Step 2
    w = _porter_step2(w, extensions)

    # Step 3
    w = _porter_replace(w, _P_STEP3, lambda s: _p_measure(s) > 0)

    # Step 4
    for suffix in sorted(_P_STEP4 + ["ion"], key=lambda s: -len(s)):
        if w.endswith(suffix):
            stem = w[: len(w) - len(suffix)]
            if suffix == "ion":
                if _p_measure(stem) > 1 and stem[-1:] in ("s", "t"):
                    w = stem
            elif _p_measure(stem) > 1:
                w = stem
            break

    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        m = _p_measure(stem)
        if m > 1 or (m == 1 and not _p_cvc(stem)):
            w = stem
    if w.endswith("ll") and _p_measure(w[:-1]) > 1:
        w = w[:-1]
    return w


class PorterStemmer:
    """Porter stemmer. The default mode is the LINGORA extensions."""

    def stem(self, word, to_lowercase=False):
        w = word.lower() if to_lowercase else word
        if w in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[w]
        if len(w) <= 2:
            return w
        return _porter_original_steps(w, extensions=True)


def _porter_classic(word):
    """Original 1980 Porter algorithm (used for the Snowball 'porter' name)."""
    if len(word) <= 2:
        return word
    return _porter_original_steps(word, extensions=False)


# ------------------------------------------------------------------- Porter2

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring",
            "proceed", "exceed", "succeed"}

_P2_VOWEL = "aeiouy"


def _p2_regions(w):
    if w.startswith("gener") or w.startswith("arsen"):
        r1 = 5
    elif w.startswith("commun"):
        r1 = 6
    else:
        r1 = len(w)
        for i in range(1, len(w)):
            if w[i] not in _P2_VOWEL and w[i - 1] in _P2_VOWEL:
                r1 = i + 1
                break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in _P2_VOWEL and w[i - 1] in _P2_VOWEL:
            r2 = i + 1
            break
    return min(r1, len(w)), min(r2, len(w))


_P2_SHORT_END = re.compile(r"[^aeiouy][aeiouy][^aeiouywxY]$")
_P2_SHORT_WHOLE = re.compile(r"^[aeiouy][^aeiouyY]$")


def _p2_short_syllable(w):
    return bool(_P2_SHORT_END.search(w) or _P2_SHORT_WHOLE.match(w))


def _p2_is_short(w, r1):
    return r1 >= len(w) and _p2_short_syllable(w)


def porter2(word):
    """Snowball English (Porter2) stemmer."""
    if len(word) <= 2:
        return word
    if word in _P2_EXC1:
        return _P2_EXC1[word]

    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWEL:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) - 3 > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(c in _P2_VOWEL for c in w[:-2]):
            w = w[:-1]
    if w in _P2_EXC2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: len(w) - len(suf)] + "ee"
    else:
        suf = None
        for cand in ("ingly", "edly", "ing", "ed"):
            if w.endswith(cand):
                suf = cand
                break
        if suf is not None:
            stem = w[: len(w) - len(suf)]
            if any(c in _P2_VOWEL for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                    w = w[:-1]
                elif _p2_is_short(w, r1 if r1 <= len(w) else len(w)):
                    w += "e"

    # Step 1c
    if len(w) >= 3 and w[-1] in "yY" and w[-2] not in _P2_VOWEL:
        w = w[:-1] + "i"

    # Step 2 (suffix must start in R1)
    step2 = [
        ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
        ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
        ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"),
    ]
    for suf, repl in sorted(step2, key=lambda r: -len(r[0])):
        if w.endswith(suf):
            if len(w) - len(suf) >= r1:
                w = w[: len(w) - len(suf)] + repl
            break
    else:
        if w.endswith("li") and len(w) - 2 >= r1 and len(w) >= 3 and w[-3] in "cdeghkmnrt":
            w = w[:-2]

    # Step 3
    step3 = [("tional", "tion"), ("ational", "ate"), ("alize", "al"),
             ("icate", "ic"), ("iciti", "ic"), ("ical", "ic"),
             ("ful", ""), ("ness", ""), ("ative", "")]
    for suf, repl in sorted(step3, key=lambda r: -len(r[0])):
        if w.endswith(suf):
            start = len(w) - len(suf)
            if start >= r1 and (suf != "ative" or start >= r2):
                w = w[:start] + repl
            break

    # Step 4 (suffix must start in R2)
    step4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
             "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    for suf in sorted(step4, key=lambda s: -len(s)):
        if w.endswith(suf):
            start = len(w) - len(suf)
            if start >= r2:
                if suf == "ion":
                    if start >= 1 and w[start - 1] in "st":
                        w = w[:start]
                else:
                    w = w[:start]
            break

    # Step 5
    if w.endswith("e"):
        start = len(w) - 1
        if start >= r2 or (start >= r1 and not _p2_short_syllable(w[:start])):
            w = w[:start]
    elif w.endswith("l") and len(w) - 1 >= r2 and w.endswith("ll"):
        w = w[:-1]

    return w.replace("Y", "y")


# ----------------------------------------------------------------- Lancaster

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3y.", "lu2.", "lai3>", "lau3>", "la2>", "ll1.",
    "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>",
    "nai3>", "na2>", "nee0.", "ne2+a", "nn1.", "pihs4>", "pp1.", "re2>",
    "rae0.", "ra2.", "ro2>", "ru2>", "rov3.", "rt1.", "rd1.", "sei3y>",
    "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.",
    "tacilp4y.", "ytic5s.", "tec2ss.", "tei2y.", "tuo2>", "tnem4>",
    "tne4>", "tna3>", "tra2>", "tym3s.", "tyl2>", "ufi6.", "ug2>",
    "uz2>", "ve1>", "vie1.", "yt2.", "yz1.",
]
_LANCASTER_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")


def _parse_lancaster(rule):
    m = _LANCASTER_RE.match(rule)
    if not m:
        return None
    letters, intact, digit, append, cont = m.groups()
    return (letters[::-1], bool(intact), int(digit), append, cont == ".")


_LANCASTER_PARSED = [r for r in (_parse_lancaster(x) for x in _LANCASTER_RULES) if r]


class LancasterStemmer:
    """Paice/Husk stemmer driven by a rule table."""

    def stem(self, word):
        w = word.lower()
        intact = True
        while True:
            for ending, need_intact, remove, append, stop in _LANCASTER_PARSED:
                if not w.endswith(ending):
                    continue
                if need_intact and not intact:
                    continue
                stem = w[: len(w) - remove] if remove else w
                if len(stem) < 2:
                    continue
                w = stem + append
                if stop:
                    return w
                intact = False
                break
            else:
                return w


# ------------------------------------------------------------------- Snowball

_SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)
_SNOWBALL_IMPLEMENTED = ("english", "porter")


def _load_stopwords(language):
    resource = os.path.join("corpora", "stopwords", language)
    found = data.find(resource)
    if found is None or not os.path.isfile(found):
        raise data.ResourceNotFound(
            "stopwords list for %r is not installed" % language)
    with open(found, encoding="utf-8") as fh:
        return {line.strip().lower() for line in fh if line.strip()}


class SnowballStemmer:
    def __init__(self, language, ignore_stopwords=False):
        if language not in _SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError(
                "Snowball stemmer for %r is not implemented in this build" % (language,))
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = _load_stopwords(language) if self.ignore_stopwords else set()

    def stem(self, word):
        low = word.lower()
        if self.ignore_stopwords and low in self._stopwords:
            return low
        if self.language == "porter":
            return _porter_classic(low)
        return porter2(low)


# ------------------------------------------------------------------- Regexp

class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a string")
        self._re = re.compile(regexp)

    def stem(self, word):
        return self._re.sub("", word)


# ----------------------------------------------------------------- WordNet

class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet index files (noun index only)."""

    _NOUN_RULES = [("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
                   ("shes", "sh"), ("men", "man"), ("ies", "y"), ("s", "")]

    def __init__(self):
        found = data.require(os.path.join("corpora", "wordnet"))
        self._nouns = None
        base = found if os.path.isdir(found) else os.path.dirname(found)
        index = os.path.join(base, "index.noun")
        if os.path.isfile(index):
            with open(index, encoding="utf-8", errors="replace") as fh:
                self._nouns = {line.split(" ", 1)[0] for line in fh
                               if line and not line.startswith(" ")}

    def lemmatize(self, word):
        if self._nouns is None:
            return word
        if word in self._nouns:
            return word
        for suffix, repl in self._NOUN_RULES:
            if word.endswith(suffix):
                cand = word[: len(word) - len(suffix)] + repl
                if cand in self._nouns:
                    return cand
        return word


# ------------------------------------------------------------- Arabic (light)

_ARABIC_PREFIXES = ("وال", "بال", "كال", "فال", "ال", "و")
_ARABIC_SUFFIXES = ("ها", "ات", "ون", "ين", "ية", "ه", "ة", "ي")


class ARLSTem:
    """Approximate light Arabic stemmer: strips common prefixes and suffixes.
    Its results are outside the specification."""

    def stem(self, word):
        w = word
        for p in _ARABIC_PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in _ARABIC_SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[: -len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    """Approximate variant of :class:`ARLSTem`; results are outside the
    specification."""
