"""Chunk parsing with chunk grammars (FP-04)."""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "SENT"
_INF = float("inf")


# ----------------------------------------------------------- tag patterns

def _parse_tag_pattern(body):
    elems = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c.isspace():
            i += 1
            continue
        if c != "<":
            raise ValueError("tag pattern element must start with '<': %r" % body)
        j = body.find(">", i)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern: %r" % body)
        content = body[i + 1:j]
        i = j + 1
        try:
            rx = re.compile("(?:%s)" % content)
        except re.error as exc:
            raise ValueError("bad tag regular expression %r: %s" % (content, exc))
        mn, mx = 1, 1
        if i < n and body[i] in "?*+":
            mn, mx = {"?": (0, 1), "*": (0, _INF), "+": (1, _INF)}[body[i]]
            i += 1
        elif i < n and body[i] == "{":
            j = body.find("}", i)
            if j < 0:
                raise ValueError("unclosed quantifier in tag pattern: %r" % body)
            spec = body[i + 1:j]
            i = j + 1
            if "," in spec:
                lo, hi = spec.split(",", 1)
                mn = int(lo) if lo.strip() else 0
                mx = int(hi) if hi.strip() else _INF
            else:
                mn = mx = int(spec)
        elems.append((rx, mn, mx))
    return elems


def _longest_match(elems, tags, start):
    """Return the end index of the longest match of ``elems`` starting at
    ``start``, or None. ``tags[k]`` is None for a unit that cannot match."""
    n = len(tags)
    best = [None]

    def rec(k, pos):
        if k == len(elems):
            if best[0] is None or pos > best[0]:
                best[0] = pos
            return
        rx, mn, mx = elems[k]
        positions = [pos]
        cur = pos
        while len(positions) - 1 < mx:
            if cur >= n or tags[cur] is None or not rx.fullmatch(tags[cur]):
                break
            cur += 1
            positions.append(cur)
        for count, p in enumerate(positions):
            if count >= mn:
                rec(k + 1, p)

    rec(0, start)
    if best[0] is None or best[0] == start:
        return None
    return best[0]


def _find_all_longest(elems, tags):
    """Left-to-right, non-overlapping, longest matches. Returns (start, end)."""
    spans = []
    i = 0
    while i < len(tags):
        if tags[i] is None:
            i += 1
            continue
        end = _longest_match(elems, tags, i)
        if end is None:
            i += 1
        else:
            spans.append((i, end))
            i = end
    return spans


# ---------------------------------------------------------------- grammar

class _Pattern:
    def __init__(self, kind, elems):
        self.kind = kind  # "chunk" or "chink"
        self.elems = elems


def _parse_grammar(text):
    clauses = []  # list of (label, [patterns])
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if raw[0] in " \t" or stripped[0] in "{}":
            if not clauses:
                raise ValueError("pattern line before any clause label: %r" % raw)
            clauses[-1][1].append(stripped)
            continue
        if ":" not in stripped:
            raise ValueError("clause line must read '<LABEL>: <pattern>': %r" % raw)
        label, rest = stripped.split(":", 1)
        label = label.strip()
        if not label:
            raise ValueError("empty chunk label: %r" % raw)
        patterns = []
        if rest.strip():
            patterns.append(rest.strip())
        clauses.append((label, patterns))

    parsed = []
    for label, patterns in clauses:
        pats = []
        for p in patterns:
            if p.startswith("{") and p.endswith("}"):
                pats.append(_Pattern("chunk", _parse_tag_pattern(p[1:-1])))
            elif p.startswith("}") and p.endswith("{"):
                pats.append(_Pattern("chink", _parse_tag_pattern(p[1:-1])))
            else:
                raise ValueError("pattern must be {...} or }...{: %r" % p)
        parsed.append((label, pats))
    return parsed


class RegexpParser:
    """Chunk parser driven by a chunk grammar (text, or a list of parsers)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and grammar and all(
                isinstance(g, (RegexpParser, str)) for g in grammar):
            self._clauses = []
            for g in grammar:
                self._clauses.extend(
                    g._clauses if isinstance(g, RegexpParser) else _parse_grammar(g))
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("parse() takes a list of (token, tag) pairs")
        # entry: [kind, payload, tag]; kind in tok | old | new
        entries = []
        for pair in tagged:
            token, tag = pair
            entries.append(["tok", (token, tag), tag])

        for label, pats in self._clauses:
            for pat in pats:
                tags = [e[2] if e[0] != "new" else None for e in entries]
                if pat.kind == "chunk":
                    entries = self._apply_chunk(entries, tags, pat.elems, label)
                else:
                    entries = self._apply_chink(entries, pat.elems, label)
            # clause finished: its chunks become single units for later clauses
            for e in entries:
                if e[0] == "new":
                    e[0] = "old"

        return Tree(ROOT_LABEL, [self._payload_leaf(e) for e in entries])

    @staticmethod
    def _payload_leaf(entry):
        return entry[1]

    @staticmethod
    def _apply_chunk(entries, tags, elems, label):
        spans = _find_all_longest(elems, tags)
        if not spans:
            return entries
        out = []
        pos = 0
        for start, end in spans:
            out.extend(entries[pos:start])
            children = [e[1] for e in entries[start:end]]
            out.append(["new", Tree(label, children), label])
            pos = end
        out.extend(entries[pos:])
        return out

    @staticmethod
    def _apply_chink(entries, elems, label):
        out = []
        for entry in entries:
            if entry[0] != "new" or entry[1].label() != label:
                out.append(entry)
                continue
            children = list(entry[1])
            child_tags = []
            for c in children:
                child_tags.append(c[1] if isinstance(c, tuple) else c.label())
            removed = [False] * len(children)
            for start, end in _find_all_longest(elems, child_tags):
                for k in range(start, end):
                    removed[k] = True
            segment = []
            for child, gone in zip(children, removed):
                if gone:
                    if segment:
                        out.append(["new", Tree(label, segment), label])
                        segment = []
                    if isinstance(child, Tree):
                        out.append(["old", child, child.label()])
                    else:
                        out.append(["tok", child, child[1]])
                else:
                    segment.append(child)
            if segment:
                out.append(["new", Tree(label, segment), label])
        return out


def ne_chunk(tagged_tokens):
    """Named-entity chunker. It requires its packaged model and the English
    wordlist; the model-driven chunking itself is not implemented here."""
    data.require("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.require("corpora/words")
    raise NotImplementedError(
        "the named-entity model is installed but its decoder is not implemented")
