"""Tokenizers (FP-01)."""

import re

from lingora import punkt as _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


# ---------------------------------------------------------------- word/punct

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    """Split into maximal runs of word characters and maximal runs of
    non-word, non-whitespace characters."""
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer:
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        for m in _WORDPUNCT_RE.finditer(text):
            yield (m.start(), m.end())


# ------------------------------------------------------------------ Treebank

_OPEN_CTX = r"(?:^|(?<=[\s(\[{<]))"

_CONTRACTION_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<![\w'])('t)(is|was)\b"), r"\1 \2"),
]

_CLITICS = [
    # n't, split from the letters before it
    (re.compile(r"(?i)([^\s'])(n't)(?!\w)"), r"\1 \2 "),
    # 's 'm 'd 'll 're 've, split from the word they follow
    (re.compile(r"(?i)(\w)('s|'m|'d|'ll|'re|'ve)(?!\w)"), r"\1 \2 "),
    # bare apostrophe ending a word
    (re.compile(r"(?<=[^\s'])'(?=\s|$|[.,;:!?)\]}\"])"), " ' "),
]

_TYPOGRAPHIC_QUOTES = re.compile(r"[“”„‟‘’‚‛«»‹›]")
_DASHES_STARS = re.compile(r"[‒-―*]")


def _treebank(text, improved):
    if not text.strip():
        return []
    s = text

    # Quote rules on the raw text; starting quotes first.
    if improved:
        s = re.sub(r"^\"", " '' ", s)  # very first character: closing token
    s = re.sub(_OPEN_CTX + r'"', " `` ", s)

    # Final point, optionally followed by closing quotes or brackets.
    s = re.sub(r"(?<![.])\.(?=[\"')\]}>]*\s*$)", " . ", s)

    # Remaining straight double quotes are closing quotes.
    s = s.replace('"', " '' ")

    if improved:
        s = _TYPOGRAPHIC_QUOTES.sub(lambda m: " %s " % m.group(0), s)
        s = _DASHES_STARS.sub(lambda m: " %s " % m.group(0), s)
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), s)
        s = s.replace("--", " -- ")
    else:
        s = s.replace("...", " ... ")
    s = re.sub(r"[;@#$%&?!]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"[\[\](){}<>]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"([:,])(?!\d)", r" \1 ", s)

    for pat, repl in _CLITICS:
        s = pat.sub(repl, s)
    if not improved:
        for pat, repl in _CONTRACTION_FUSED:
            s = pat.sub(repl, s)
    else:
        for pat, repl in _CONTRACTION_FUSED[1:]:
            s = pat.sub(repl, s)
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):
        return _treebank(text, improved=False)


def _recommended_word_tokens(text):
    return _treebank(text, improved=True)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer.

    Unless ``preserve_line`` is true, the text is first split into sentences
    with the Punkt model for ``language``; that requires the model."""
    if preserve_line:
        return _recommended_word_tokens(text)
    tokens = []
    for sent in sent_tokenize(text, language=language):
        tokens.extend(_recommended_word_tokens(sent))
    return tokens


def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (Punkt; requires the model)."""
    return _punkt.load(language).sentences_from_text(text)


# ----------------------------------------------------------- simple splitters

class WhitespaceTokenizer:
    _re = re.compile(r"\S+")

    def tokenize(self, text):
        return text.split()

    def span_tokenize(self, text):
        for m in self._re.finditer(text):
            yield (m.start(), m.end())


_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Split into segments separated by blank lines."""
    return [piece for piece in _BLANKLINE_SEP.split(text) if piece.strip()]


class RegexpTokenizer:
    """Tokenize with a caller-supplied regular expression.

    ``gaps=False`` (default): tokens are the matches.
    ``gaps=True``: tokens are the pieces between matches.
    ``discard_empty`` (default True) drops empty pieces."""

    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._pattern = re.compile(pattern)
        self.gaps = bool(gaps)
        self.discard_empty = bool(discard_empty)

    def _spans(self, text):
        if self.gaps:
            prev = 0
            for m in self._pattern.finditer(text):
                yield (prev, m.start())
                prev = m.end()
            yield (prev, len(text))
        else:
            for m in self._pattern.finditer(text):
                yield (m.start(), m.end())

    def tokenize(self, text):
        out = []
        for s, e in self._spans(text):
            if self.discard_empty and s == e:
                continue
            out.append(text[s:e])
        return out

    def span_tokenize(self, text):
        for s, e in self._spans(text):
            if self.discard_empty and s == e:
                continue
            yield (s, e)


# --------------------------------------------------------------------- tweets

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o\*']?[\)\]\(\[dDpP/:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/:\}\{@\|\\][\-o\*']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_RE = re.compile(
    r"(?P<url>(?:https?://|www\.)\S+)"
    r"|(?P<emo>" + _EMOTICON + r")"
    r"|(?P<hash>#\w+)"
    r"|(?P<handle>@\w+)"
    r"|(?P<word>\w+(?:['’]\w+)*)"
    r"|(?P<dots>\.{2,})"
    r"|(?P<other>[^\w\s])"
)
_HANDLE_STRIP = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        if self.strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE.sub(lambda m: m.group(1) * 3, text)
        out = []
        for m in _TWEET_RE.finditer(text):
            kind = m.lastgroup
            tok = m.group(0)
            if kind == "emo":
                out.append(tok)
            elif not self.preserve_case:
                out.append(tok.lower())
            else:
                out.append(tok)
        return out
