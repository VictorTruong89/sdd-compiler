"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), using packaged
parameters read from ``tokenizers/punkt_tab/<language>/``."""

import os
import re
from functools import lru_cache

from lingora import data

_SENT_END = (".", "?", "!")

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI_CHAR = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_TOKEN_RE = re.compile(
    r"(%s|(?=%s)\S+?(?=\s|$|%s|%s|,(?=$|\s|%s|%s))|\S)"
    % (_MULTI_CHAR, _WORD_START, _NON_WORD, _MULTI_CHAR, _NON_WORD, _MULTI_CHAR)
)
_BOUNDARY_REALIGN = re.compile(r"[\"')\]}]+?(?:\s+|(?=--)|$)", re.MULTILINE)
_NUMBER_TYPE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"^\.\.+$")
_INITIAL = re.compile(r"^[^\W\d]\.$")


def _get_type(tok):
    low = tok.lower()
    return "##number##" if _NUMBER_TYPE.match(low) else low


class _Tok:
    __slots__ = ("tok", "start", "end", "type", "period_final", "abbr",
                 "sentbreak", "ellipsis")

    def __init__(self, tok, start, end):
        self.tok = tok
        self.start = start
        self.end = end
        self.type = _get_type(tok)
        self.period_final = tok.endswith(".")
        self.abbr = False
        self.sentbreak = False
        self.ellipsis = bool(_ELLIPSIS.match(tok))

    @property
    def type_no_period(self):
        return self.type[:-1] if self.type.endswith(".") else self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[:1].isupper()

    @property
    def first_lower(self):
        return self.tok[:1].islower()

    @property
    def is_initial(self):
        return bool(_INITIAL.match(self.tok))


class PunktModel:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context

    # ------------------------------------------------------------ annotation
    def _ortho(self, t):
        ctx = self.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
            return False
        if t.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_LC)):
            return False
        return None

    def _first_pass(self, t):
        tok = t.tok
        if tok in _SENT_END:
            t.sentbreak = True
        elif t.ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            base = tok[:-1].lower()
            if base in self.abbrev_types or base.split("-")[-1] in self.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        if (typ, next_typ) in self.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if t1.abbr or t1.ellipsis:
            starter = self._ortho(t2)
            if starter is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return
        if t1.is_initial or typ == "##number##":
            starter = self._ortho(t2)
            if starter is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return

    def _tokens(self, text):
        toks = []
        offset = 0
        for line in text.split("\n"):
            for m in _WORD_TOKEN_RE.finditer(line):
                toks.append(_Tok(m.group(0), offset + m.start(), offset + m.end()))
            offset += len(line) + 1
        return toks

    # ------------------------------------------------------------- splitting
    def sentence_spans(self, text):
        toks = self._tokens(text)
        if not toks:
            return []
        for t in toks:
            self._first_pass(t)
        for t1, t2 in zip(toks, toks[1:] + [None]):
            self._second_pass(t1, t2)

        slices = []
        last = 0
        for i, t in enumerate(toks[:-1]):
            if t.sentbreak:
                slices.append((last, t.end))
                last = toks[i + 1].start
        slices.append((last, len(text)))
        return self._realign(text, slices)

    @staticmethod
    def _realign(text, slices):
        out = []
        realign = 0
        for idx, (s1, e1) in enumerate(slices):
            s1 = s1 + realign
            if idx + 1 == len(slices):
                if text[s1:e1]:
                    out.append((s1, e1))
                break
            s2, e2 = slices[idx + 1]
            m = _BOUNDARY_REALIGN.match(text[s2:e2])
            if m:
                out.append((s1, s2 + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1:e1]:
                    out.append((s1, e1))
        return out

    def sentences_from_text(self, text):
        sentences = []
        for s, e in self.sentence_spans(text):
            sent = text[s:e].strip()
            if sent:
                sentences.append(sent)
        return sentences


def _read_lines(path):
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


@lru_cache(maxsize=32)
def _load_dir(directory):
    def p(name):
        return os.path.join(directory, name)

    abbrev = set()
    if os.path.isfile(p("abbrev_types.txt")):
        abbrev = {l.strip() for l in _read_lines(p("abbrev_types.txt")) if l.strip()}
    starters = set()
    if os.path.isfile(p("sent_starters.txt")):
        starters = {l.strip() for l in _read_lines(p("sent_starters.txt")) if l.strip()}
    colloc = set()
    if os.path.isfile(p("collocations.tab")):
        for line in _read_lines(p("collocations.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                colloc.add((parts[0], parts[1]))
    ortho = {}
    if os.path.isfile(p("ortho_context.tab")):
        for line in _read_lines(p("ortho_context.tab")):
            parts = line.split("\t")
            if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
                ortho[parts[0]] = int(parts[1])
    return PunktModel(abbrev, starters, colloc, ortho)


def load(language="english"):
    """Return the Punkt model for ``language``; raise if it is not visible."""
    if not language or "/" in language or os.sep in language or language.startswith("."):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    resource = os.path.join("tokenizers", "punkt_tab", language)
    directory = data.require(resource)
    if not os.path.isdir(directory):
        raise data.ResourceNotFound("Punkt model %r is not a directory" % resource)
    return _load_dir(directory)
