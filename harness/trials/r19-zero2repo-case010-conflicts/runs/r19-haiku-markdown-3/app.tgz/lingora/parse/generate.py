"""Enumerate the sentences a grammar derives (FP-05)."""

from lingora.grammar import CFG, Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Yield token lists derivable from ``start`` (default: the start symbol).

    ``n`` bounds the number of sentences; ``depth`` bounds the derivation
    depth. A terminal that is the empty string contributes no token."""
    if not isinstance(grammar, CFG):
        raise TypeError("generate needs a CFG")
    start_name = str(start) if start is not None else str(grammar.start())

    def expand_nt(sym, d):
        if depth is not None and d >= depth:
            return
        for prod in grammar.productions_for(sym):
            yield from expand_seq(prod.rhs(), d + 1)

    def expand_seq(items, d):
        if not items:
            yield []
            return
        head, rest = items[0], items[1:]
        if isinstance(head, Nonterminal):
            for first in expand_nt(str(head), d):
                for tail in expand_seq(rest, d):
                    yield first + tail
        else:
            prefix = [] if head == "" else [head]
            for tail in expand_seq(rest, d):
                yield prefix + tail

    count = 0
    for sentence in expand_nt(start_name, 0):
        if n is not None and count >= n:
            return
        yield list(sentence)
        count += 1
