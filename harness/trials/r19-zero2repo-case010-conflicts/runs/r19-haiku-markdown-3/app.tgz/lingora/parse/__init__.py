"""Parsers over context-free grammars (FP-05): chart and shift-reduce."""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("parse() takes a list of token strings")
    tokens = list(tokens)
    known = grammar.terminals()
    for tok in tokens:
        if tok not in known:
            raise ValueError("token %r is not produced by any production" % (tok,))
    return tokens


def _is_terminal(item):
    return isinstance(item, str)


class ChartParser:
    """Exhaustive chart parser: returns every parse tree of the token list."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("ChartParser needs a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        n = len(tokens)
        memo = {}
        active = set()
        grammar = self._grammar

        def trees(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []  # cut cyclic derivations
            active.add(key)
            result = []
            for prod in grammar.productions_for(name):
                for children in seq(prod.rhs(), i, j):
                    result.append(Tree(name, children))
            active.discard(key)
            memo[key] = result
            return result

        def seq(items, i, j):
            if not items:
                if i == j:
                    yield []
                return
            head, rest = items[0], items[1:]
            if _is_terminal(head):
                if head == "":
                    yield from seq(rest, i, j)
                elif i < j and tokens[i] == head:
                    for tail in seq(rest, i + 1, j):
                        yield [head] + tail
                return
            for k in range(i, j + 1):
                for sub in trees(str(head), i, k):
                    for tail in seq(rest, k, j):
                        yield [sub] + tail

        return iter(trees(str(grammar.start()), 0, n))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    _STEP_LIMIT = 100000

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("ShiftReduceParser needs a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        grammar = self._grammar
        productions = [p for p in grammar.productions()
                       if any(not (_is_terminal(x) and x == "") for x in p.rhs())]
        start = str(grammar.start())

        stack = []  # entries: ("T", token) or ("N", name, Tree)
        pos = 0
        steps = 0

        def matches(entries, rhs):
            if len(entries) < len(rhs):
                return False
            for entry, item in zip(entries, rhs):
                if _is_terminal(item):
                    if entry[0] != "T" or entry[1] != item:
                        return False
                else:
                    if entry[0] != "N" or entry[1] != str(item):
                        return False
            return True

        while True:
            steps += 1
            if steps > self._STEP_LIMIT:
                return iter([])
            reduced = False
            for prod in productions:
                rhs = tuple(x for x in prod.rhs() if not (_is_terminal(x) and x == ""))
                if not rhs or len(stack) < len(rhs):
                    continue
                if matches(stack[-len(rhs):], rhs):
                    name = str(prod.lhs())
                    children = []
                    for entry in stack[-len(rhs):]:
                        children.append(entry[1] if entry[0] == "T" else entry[2])
                    del stack[-len(rhs):]
                    stack.append(("N", name, Tree(name, children)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(("T", tokens[pos]))
                pos += 1
                continue
            break

        if pos == len(tokens) and len(stack) == 1 and stack[0][0] == "N" \
                and stack[0][1] == start:
            return iter([stack[0][2]])
        return iter([])
