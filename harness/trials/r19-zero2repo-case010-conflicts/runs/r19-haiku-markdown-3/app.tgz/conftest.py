"""Root conftest: keeps the repository root on sys.path so `lingora` imports."""
