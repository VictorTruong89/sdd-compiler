"""Text classifiers (``lingora.classify``): Naive Bayes and decision tree."""

import math
from collections import Counter, defaultdict

_ELE = 0.5  # expected-likelihood-estimate smoothing constant


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda label: (self._probs[label], str(label)))

    def __getitem__(self, label):
        return self.prob(label)

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probs)


def _check_training(labeled_featuresets):
    data = list(labeled_featuresets)
    if not data:
        raise ValueError("training needs at least one labeled featureset")
    for fs, _label in data:
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict of feature names to values")
    return data


class NaiveBayesClassifier:
    """Naive Bayes over labeled featuresets, with expected-likelihood smoothing."""

    def __init__(self, label_probdist_counts, feature_counts, feature_values, label_order):
        self._label_counts = label_probdist_counts
        self._total = sum(label_probdist_counts.values())
        self._feature_counts = feature_counts          # (label, feat) -> examples with feat
        self._value_counts = feature_values[0]         # (label, feat, value) -> count
        self._value_sets = feature_values[1]           # feat -> set of values seen
        self._labels = label_order

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        label_counts = Counter()
        label_order = []
        feature_counts = Counter()
        value_counts = Counter()
        value_sets = defaultdict(set)
        for fs, label in data:
            if label not in label_counts:
                label_order.append(label)
            label_counts[label] += 1
            for feat, value in fs.items():
                feature_counts[(label, feat)] += 1
                value_counts[(label, feat, value)] += 1
                value_sets[feat].add(value)
        return cls(label_counts, feature_counts, (value_counts, value_sets), label_order)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            score = math.log(self._label_counts[label] / self._total)
            for feat, value in featureset.items():
                if feat not in self._value_sets:
                    continue  # a feature never seen in training is ignored
                bins = len(self._value_sets[feat]) + 1
                count = self._value_counts[(label, feat, value)]
                denom = self._feature_counts[(label, feat)] + _ELE * bins
                score += math.log((count + _ELE) / denom)
            scores[label] = score
        return scores

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        return max(self._labels, key=lambda label: scores[label])

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: exps[label] / total for label in self._labels})


class _Node:
    __slots__ = ("feature", "branches", "majority")

    def __init__(self, majority, feature=None, branches=None):
        self.majority = majority
        self.feature = feature
        self.branches = branches or {}


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


class DecisionTreeClassifier:
    """ID3-style decision tree: splits on the feature with the greatest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        features = []
        seen = set()
        for fs, _ in data:
            for feat in fs:
                if feat not in seen:
                    seen.add(feat)
                    features.append(feat)
        return cls(cls._build(data, features))

    @classmethod
    def _build(cls, examples, features):
        labels = [label for _, label in examples]
        majority = Counter(labels).most_common(1)[0][0] if labels else None
        if len(set(labels)) <= 1 or not features:
            return _Node(majority)
        base = _entropy(labels)
        best_feat, best_gain = None, 0.0
        for feat in features:
            groups = defaultdict(list)
            for fs, label in examples:
                groups[fs.get(feat)].append(label)
            remainder = sum(len(g) / len(labels) * _entropy(g) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feat, best_gain = feat, gain
        if best_feat is None:
            return _Node(majority)
        partition = defaultdict(list)
        for fs, label in examples:
            partition[fs.get(best_feat)].append((fs, label))
        rest = [f for f in features if f != best_feat]
        branches = {v: cls._build(sub, rest) for v, sub in partition.items()}
        return _Node(majority, best_feat, branches)

    def classify(self, featureset):
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature)
            child = node.branches.get(value)
            if child is None:
                return node.majority
            node = child
        return node.majority


def accuracy(classifier, gold):
    """Fraction of (featureset, label) pairs in *gold* that *classifier* labels correctly."""
    gold = list(gold)
    if not gold:
        return 0.0
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
