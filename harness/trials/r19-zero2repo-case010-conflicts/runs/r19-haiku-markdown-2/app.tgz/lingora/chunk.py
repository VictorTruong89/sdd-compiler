"""Chunk parsing with chunk grammars (``lingora.chunk``)."""

import re

from lingora import data
from lingora.tree import Tree

ROOT_LABEL = "S"

_QUANT = re.compile(r"\{\s*(\d*)\s*(,?)\s*(\d*)\s*\}")


class _Rule:
    kind = None

    def __init__(self, label, pattern):
        if not isinstance(label, str) or not label:
            raise ValueError("a chunk label must be a non-empty str")
        self.label = label
        self.pattern = pattern
        self.elements = _compile_tag_pattern(pattern)


class ChunkRule(_Rule):
    """A chunk stage: every match of *pattern* becomes a chunk labelled *label*."""

    kind = "chunk"


class ChinRule(_Rule):
    """A chink stage: matches of *pattern* are removed from chunks built earlier in the clause."""

    kind = "chink"


def _compile_tag_pattern(text):
    """Parse ``<tag-regex>`` elements with optional quantifiers into (regex, min, max) triples."""
    elements = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch != "<":
            raise ValueError("bad tag pattern %r at position %d" % (text, i))
        j = text.find(">", i)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern %r" % text)
        content = text[i + 1:j]
        try:
            regex = re.compile("(?:%s)" % content)
        except re.error as exc:
            raise ValueError("bad tag regex %r: %s" % (content, exc)) from None
        i = j + 1
        while i < n and text[i].isspace():
            i += 1
        mn, mx = 1, 1
        if i < n and text[i] in "?*+":
            mn, mx = {"?": (0, 1), "*": (0, None), "+": (1, None)}[text[i]]
            i += 1
        else:
            m = _QUANT.match(text, i)
            if m:
                lo, comma, hi = m.group(1), m.group(2), m.group(3)
                mn = int(lo) if lo else 0
                if comma:
                    mx = int(hi) if hi else None
                else:
                    mx = mn
                i = m.end()
        elements.append((regex, mn, mx))
    return elements


def _tag_of(unit):
    if isinstance(unit, Tree):
        return unit.label()
    return unit[1] or ""


def _ends(elements, units, start):
    """Every end index reachable by matching all elements from *start*."""
    n = len(units)

    def rec(k, pos):
        if k == len(elements):
            return {pos}
        regex, mn, mx = elements[k]
        out = set()
        cur, count = pos, 0
        if mn == 0:
            out |= rec(k + 1, cur)
        while (mx is None or count < mx) and cur < n and regex.fullmatch(_tag_of(units[cur])):
            cur += 1
            count += 1
            if count >= mn:
                out |= rec(k + 1, cur)
        return out

    return rec(0, start)


def _find_matches(elements, units):
    """Left-to-right, longest, non-overlapping non-empty matches."""
    spans = []
    i = 0
    while i < len(units):
        ends = [e for e in _ends(elements, units, i) if e > i]
        if ends:
            e = max(ends)
            spans.append((i, e))
            i = e
        else:
            i += 1
    return spans


def _apply_chunk(children, label, elements, built):
    out = []
    i = 0
    n = len(children)
    built_ids = {id(b) for b in built}
    while i < n:
        if id(children[i]) in built_ids:  # a chunk of this clause: barrier
            out.append(children[i])
            i += 1
            continue
        j = i
        while j < n and id(children[j]) not in built_ids:
            j += 1
        segment = children[i:j]
        k = 0
        for s, e in _find_matches(elements, segment):
            out.extend(segment[k:s])
            chunk = Tree(label, segment[s:e])
            built.append(chunk)
            out.append(chunk)
            k = e
        out.extend(segment[k:])
        i = j
    return out


def _apply_chink(children, label, elements, built):
    built_ids = {id(b) for b in built}
    out = []
    for child in children:
        if not (isinstance(child, Tree) and id(child) in built_ids):
            out.append(child)
            continue
        units = list(child)
        k = 0
        for s, e in _find_matches(elements, units):
            if s > k:
                piece = Tree(child.label(), units[k:s])
                built.append(piece)
                out.append(piece)
            out.extend(units[s:e])  # chinked units become children of the root
            k = e
        if k < len(units):
            piece = Tree(child.label(), units[k:])
            built.append(piece)
            out.append(piece)
    return out


def _parse_patterns(rest, label, lineno):
    """Read the ``{...}`` and ``}...{`` patterns of one grammar line."""
    rules = []
    i = 0
    n = len(rest)
    while i < n:
        ch = rest[i]
        if ch.isspace():
            i += 1
            continue
        if ch not in "{}":
            raise ValueError("grammar line %d: unexpected %r" % (lineno, ch))
        kind = ChunkRule if ch == "{" else ChinRule
        closer = "}" if ch == "{" else "{"
        i += 1
        body_start = i
        while True:
            if i >= n:
                raise ValueError("grammar line %d: unterminated pattern" % lineno)
            c = rest[i]
            if c == "<":
                j = rest.find(">", i)
                if j < 0:
                    raise ValueError("grammar line %d: unclosed '<'" % lineno)
                i = j + 1
            elif c in "?*+ \t":
                i += 1
            elif c == "{":
                m = _QUANT.match(rest, i)
                if m:  # a quantifier such as {2,3} after an element
                    i = m.end()
                    continue
                if closer == "{":  # the closing brace of a chink rule
                    break
                raise ValueError("grammar line %d: bad '{' in pattern" % lineno)
            elif c == closer:
                break
            else:
                raise ValueError("grammar line %d: unexpected %r in pattern" % (lineno, c))
        body = rest[body_start:i]
        i += 1  # consume the closing bracket
        rules.append(kind(label, body))
    return rules


class RegexpParser:
    """Chunk parser for a chunk grammar (text, or a list of ChunkRule/ChinRule stages)."""

    def __init__(self, grammar, root_label=ROOT_LABEL):
        self._root = root_label
        if isinstance(grammar, str):
            self._clauses = _clauses_from_text(grammar)
        elif isinstance(grammar, list) and all(isinstance(r, _Rule) for r in grammar):
            self._clauses = _group_rules(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")
        if not self._clauses:
            raise ValueError("chunk grammar has no clauses")

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("parse needs a list of (token, tag) pairs")
        children = []
        for item in tagged:
            if not (isinstance(item, tuple) and len(item) == 2):
                raise TypeError("each tagged token must be a (token, tag) pair")
            children.append(item)
        for label, rules in self._clauses:
            built = []
            for rule in rules:
                if rule.kind == "chunk":
                    children = _apply_chunk(children, label, rule.elements, built)
                else:
                    children = _apply_chink(children, label, rule.elements, built)
        return Tree(self._root, children)


def _group_rules(rules):
    clauses = []
    for rule in rules:
        if clauses and clauses[-1][0] == rule.label:
            clauses[-1][1].append(rule)
        else:
            clauses.append((rule.label, [rule]))
    return clauses


def _clauses_from_text(text):
    rules = []
    label = None
    for lineno, raw in enumerate(text.splitlines(), 1):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if raw[0] in " \t" or (label is not None and stripped[0] in "{}"):
            if label is None:
                raise ValueError("grammar line %d: pattern before any clause label" % lineno)
            rest = stripped
        else:
            m = re.match(r"^([^\s:{}<>]+)\s*:(.*)$", stripped)
            if not m:
                raise ValueError("grammar line %d: expected 'LABEL: pattern'" % lineno)
            label = m.group(1)
            rest = m.group(2).strip()
        rules.extend(_parse_patterns(rest, label, lineno))
    return _group_rules(rules)


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Requires the named-entity model and the English wordlist.

    Raises ``LookupError`` when either resource is not installed. The model
    itself is not implemented in this build, so present resources still raise
    ``NotImplementedError``.
    """
    data.find_dir("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("the named-entity chunker is not implemented in this build")


__all__ = ["ChinRule", "ChunkRule", "RegexpParser", "ne_chunk"]
