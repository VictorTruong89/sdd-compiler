"""LINGORA Language Toolkit: tokenizers, stemmers, taggers, chunkers, parsers, classifiers and metrics.

Importing the package downloads nothing and needs no packaged model.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: E402,F401
from lingora import tree  # noqa: E402,F401
from lingora import grammar  # noqa: E402,F401
from lingora import tokenize  # noqa: E402,F401
from lingora import stem  # noqa: E402,F401
from lingora import tag  # noqa: E402,F401
from lingora import chunk  # noqa: E402,F401
from lingora import parse  # noqa: E402,F401
from lingora import classify  # noqa: E402,F401
from lingora import metrics  # noqa: E402,F401
from lingora import translate  # noqa: E402,F401
from lingora import cli  # noqa: E402,F401
