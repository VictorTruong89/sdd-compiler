from lingora.cli import main_entry

main_entry()
