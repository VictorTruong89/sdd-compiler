"""Command line (``lingora.cli``): ``lingora tokenize`` reads lines from standard input."""

import io
import sys

from lingora import tokenize as _tokenize

USAGE = """Usage: lingora tokenize [OPTIONS]

  Tokenize each line of standard input with the recommended word tokenizer
  (sentence splitting included; requires the Punkt models for the language).

Options:
  -l, --language TEXT   Punkt language directory name (default: english)
  -d, --delimiter TEXT  Token delimiter (default: one space)
  -e, --encoding TEXT   Input/output encoding (default: the stream's encoding)
  -h, --help            Show this message and exit.
"""


def _cmd_tokenize(args, stdin, stdout, stderr):
    language = "english"
    delimiter = " "
    encoding = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-h", "--help"):
            stdout.write(USAGE)
            return 0
        if arg in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if i + 1 >= len(args):
                stderr.write("Error: option %s needs a value\n" % arg)
                return 2
            value = args[i + 1]
            if arg in ("-l", "--language"):
                language = value
            elif arg in ("-d", "--delimiter"):
                delimiter = value
            else:
                encoding = value
            i += 2
            continue
        stderr.write("Error: unknown option %r\n" % arg)
        return 2

    if encoding and hasattr(stdin, "buffer"):
        stdin = io.TextIOWrapper(stdin.buffer, encoding=encoding)
    if encoding and hasattr(stdout, "buffer"):
        stdout = io.TextIOWrapper(stdout.buffer, encoding=encoding, write_through=True)

    try:
        _tokenize.load_punkt(language)  # sentence splitting needs the model up front
    except LookupError as exc:
        stderr.write("Error: %s\n" % exc)
        return 1

    for raw in stdin:
        line = raw.rstrip("\r\n")
        try:
            tokens = _tokenize.word_tokenize(line, language=language, preserve_line=False)
        except LookupError as exc:
            stderr.write("Error: %s\n" % exc)
            return 1
        stdout.write(delimiter.join(tokens) + "\n")
    stdout.flush()
    return 0


_COMMANDS = {"tokenize": _cmd_tokenize}


class Group:
    """A command group with a ``main`` entry point, in the style of a CLI framework."""

    def __init__(self, commands):
        self._commands = dict(commands)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        code = self._dispatch(args)
        if standalone_mode:
            sys.exit(code)
        return code

    def _dispatch(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(USAGE)
            return 0 if args else 2
        name, rest = args[0], args[1:]
        command = self._commands.get(name)
        if command is None:
            sys.stderr.write("Error: no such command %r\n" % name)
            return 2
        return command(rest, sys.stdin, sys.stdout, sys.stderr)


cli = Group(_COMMANDS)


def main_entry():
    cli.main()


if __name__ == "__main__":
    main_entry()
