"""Part-of-speech taggers (``lingora.tag``)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data


class _SequentialTagger:
    """Base class: tags tokens left to right and optionally falls back to a backoff tagger."""

    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a string")
        tokens = list(tokens)
        history = []
        for i in range(len(tokens)):
            history.append(self.choose_tag(tokens, i, history))
        if self._backoff is not None and any(t is None for t in history):
            backed = self._backoff.tag(tokens)
            history = [t if t is not None else b[1] for t, b in zip(history, backed)]
        return list(zip(tokens, history))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class UnigramTagger(_SequentialTagger):
    """Assigns each trained word its most frequent training tag; unseen words get no tag."""

    def __init__(self, train=None, model=None, backoff=None):
        super().__init__(backoff)
        self._model = dict(model) if model is not None else {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for word, tag in sentence:
                    counts[word][tag] += 1
            for word, c in counts.items():
                best = max(c.items(), key=lambda kv: (kv[1], str(kv[0])))[0]
                self._model.setdefault(word, best)

    def choose_tag(self, tokens, index, history):
        return self._model.get(tokens[index])


class RegexpTagger(_SequentialTagger):
    """Tries (pattern, tag) rules in order; a rule matches a token from its first character."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        word = tokens[index]
        for regex, tag in self._rules:
            if regex.match(word):
                return tag
        return None


class NgramTagger(_SequentialTagger):
    """Tags by the previous ``n - 1`` assigned tags and the token (trained on tagged sentences)."""

    def __init__(self, n, train=None, backoff=None):
        super().__init__(backoff)
        if n < 1:
            raise ValueError("n must be at least 1")
        self._n = n
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                history = []
                for word, tag in sentence:
                    counts[(tuple(history[-(n - 1):]) if n > 1 else (), word)][tag] += 1
                    history.append(tag)
            for key, c in counts.items():
                self._model[key] = max(c.items(), key=lambda kv: (kv[1], str(kv[0])))[0]

    def choose_tag(self, tokens, index, history):
        ctx = tuple(history[-(self._n - 1):]) if self._n > 1 else ()
        return self._model.get((ctx, tokens[index]))


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_SequentialTagger):
    """Tags a token by its prefix or suffix (``affix_length`` negative for suffixes)."""

    def __init__(self, train=None, affix_length=-3, backoff=None):
        super().__init__(backoff)
        self._len = affix_length
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for word, tag in sentence:
                    counts[self._affix(word)][tag] += 1
            for key, c in counts.items():
                self._model[key] = max(c.items(), key=lambda kv: (kv[1], str(kv[0])))[0]

    def _affix(self, word):
        if self._len < 0:
            return word[self._len:] if len(word) >= -self._len else word
        return word[: self._len]

    def choose_tag(self, tokens, index, history):
        return self._model.get(self._affix(tokens[index]))


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended English and Russian tagger).
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_perceptron_cache = {}
_universal_cache = {}

_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "NUM": "NUM", "ANUM": "ADJ", "V": "VERB", "ADV": "ADV",
    "PRAEDIC": "ADV", "PARENTH": "ADV", "PREDK": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "INTJ": "X", "SPRO": "PRON", "APRO": "DET", "COM": "ADJ", "NONLEX": "X",
}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


class _PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def _predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(_features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2, prev = prev, tag
        return out


def _load_perceptron(lang):
    if lang in _perceptron_cache:
        return _perceptron_cache[lang]
    base = "averaged_perceptron_tagger_%s" % lang
    files = [base + ".weights.json", base + ".tagdict.json", base + ".classes.json"]
    model_dir = data.find_dir("taggers/" + base, files)
    with open(os.path.join(model_dir, files[0]), encoding="utf-8") as fh:
        weights = json.load(fh)
    with open(os.path.join(model_dir, files[1]), encoding="utf-8") as fh:
        tagdict = json.load(fh)
    with open(os.path.join(model_dir, files[2]), encoding="utf-8") as fh:
        classes = json.load(fh)
    tagger = _PerceptronTagger(weights, tagdict, classes)
    _perceptron_cache[lang] = tagger
    return tagger


def _universal_table(lang):
    if lang in _universal_cache:
        return _universal_cache[lang]
    if lang == "rus":
        table = None  # Russian mapping uses the part of speech before '='
    else:
        model_dir = data.find_dir("taggers/universal_tagset", ("en-ptb.map",))
        table = {}
        with open(os.path.join(model_dir, "en-ptb.map"), encoding="utf-8") as fh:
            for line in fh:
                parts = line.rstrip("\r\n").split("\t")
                if len(parts) >= 2 and parts[0]:
                    table[parts[0].strip()] = parts[1].strip()
    _universal_cache[lang] = table
    return table


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag *tokens* (a list of str) with the recommended English or Russian tagger."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag needs a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise ValueError("pos_tag supports lang 'eng' or 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tokens = list(tokens)
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("every token must be a str")
    tagger = _load_perceptron(lang)
    table = _universal_table(lang) if tagset == "universal" else None
    if tagset == "universal" and lang == "eng":
        tagged = tagger.tag(tokens)
        return [(w, table.get(t, "X")) for w, t in tagged]
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        return [(w, _RUS_TO_UNIVERSAL.get(t.split("=", 1)[0], "X")) for w, t in tagged]
    return tagged
