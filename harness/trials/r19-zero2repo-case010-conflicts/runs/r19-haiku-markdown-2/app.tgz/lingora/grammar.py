"""Context-free grammars (``lingora.grammar``)."""

import re


class Nonterminal:
    """A grammar nonterminal. ``str()`` gives its name; it is not a ``str``."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """One alternative: ``lhs -> rhs``. Terminals are ``str``; nonterminals are ``Nonterminal``."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and self._lhs == other._lhs
            and self._rhs == other._rhs
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [
            str(s) if isinstance(s, Nonterminal) else '"%s"' % s for s in self._rhs
        ]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


_ITEM = re.compile(
    r"""\s*(?:(?P<term1>'[^']*')|(?P<term2>"[^"]*")|(?P<bar>\|)|(?P<nt>[^\s'"|]+))"""
)


def _parse_alternatives(text, lineno):
    """Split the right-hand side text into alternatives of symbols."""
    alternatives = [[]]
    pos = 0
    text_stripped = text.rstrip()
    while pos < len(text_stripped):
        m = _ITEM.match(text_stripped, pos)
        if not m or m.end() == pos:
            raise ValueError("cannot read grammar line %d: %r" % (lineno, text))
        pos = m.end()
        if m.group("bar") is not None:
            alternatives.append([])
        elif m.group("nt") is not None:
            alternatives[-1].append(Nonterminal(m.group("nt")))
        else:
            quoted = m.group("term1") or m.group("term2")
            alternatives[-1].append(quoted[1:-1])
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left side of the first production."""

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if not isinstance(s, Nonterminal):
                    self._terminals.add(s)

    @classmethod
    def fromstring(cls, input):
        """Read a grammar from text with one ``LHS -> RHS`` production per line."""
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line:
                continue
            if "->" not in line:
                raise ValueError("grammar line %d has no '->': %r" % (lineno, raw))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_name = lhs_text.strip()
            if not lhs_name or re.search(r"[\s'\"|]", lhs_name):
                raise ValueError("bad left-hand side on grammar line %d" % lineno)
            lhs = Nonterminal(lhs_name)
            for alt in _parse_alternatives(rhs_text, lineno):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        result = self._productions
        if lhs is not None:
            if not isinstance(lhs, Nonterminal):
                lhs = Nonterminal(lhs)
            result = [p for p in result if p.lhs() == lhs]
        if rhs is not None:
            result = [p for p in result if p.rhs() and p.rhs()[0] == rhs]
        return list(result)

    def terminals(self):
        return set(self._terminals)

    def __repr__(self):
        return "<CFG start=%s with %d productions>" % (self._start, len(self._productions))
