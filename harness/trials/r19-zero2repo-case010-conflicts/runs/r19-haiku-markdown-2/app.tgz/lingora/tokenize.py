"""Tokenizers and sentence splitting (``lingora.tokenize``)."""

import os
import re
from collections import namedtuple

from lingora import data

# ---------------------------------------------------------------------------
# Punkt sentence tokenizer (Kiss and Strunk, 2006), driven by packaged parameters.
# ---------------------------------------------------------------------------

PUNKT_FILES = ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")
_punkt_cache = {}

PunktParams = namedtuple("PunktParams", "abbrev_types sent_starters collocations ortho_context")


def _read_lines(filename):
    with open(filename, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            if line.strip():
                yield line


def load_punkt(language="english"):
    """Load the packaged Punkt parameters for *language*; raise LookupError if absent."""
    resource = "tokenizers/punkt_tab/%s" % language
    model_dir = data.find_dir(resource, PUNKT_FILES)
    if model_dir in _punkt_cache:
        return _punkt_cache[model_dir]
    abbrev = {line.strip().lower() for line in _read_lines(os.path.join(model_dir, "abbrev_types.txt"))}
    starters = {line.strip().lower() for line in _read_lines(os.path.join(model_dir, "sent_starters.txt"))}
    colloc = set()
    for line in _read_lines(os.path.join(model_dir, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) >= 2:
            colloc.add((parts[0].strip().lower(), parts[1].strip().lower()))
    ortho = {}
    for line in _read_lines(os.path.join(model_dir, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) >= 2:
            ortho[parts[0].strip().lower()] = int(parts[1].strip())
    params = PunktParams(abbrev, starters, colloc, ortho)
    _punkt_cache[model_dir] = params
    return params


_OPENERS = "'\"([{<«“‘"
_CLOSERS = "'\")]}>»”’"
_NUMERIC = re.compile(r"^[\-\+]?[\.,]?\d[\d,\.]*$")
_END_RE = re.compile(r"^(.*?)([.?!]+)([\"')\]}>»”’]*)$")
_TOKEN_RE = re.compile(r"\S+")


def _tok_info(word, params):
    m = _END_RE.match(word)
    if m:
        core, punct = m.group(1), m.group(2)
    else:
        core, punct = word, ""
    stripped = core.lstrip(_OPENERS)
    typ = stripped.lower()
    if _NUMERIC.match(stripped):
        typ = "##number##"
    is_abbr = typ in params.abbrev_types or (len(stripped) == 1 and stripped.isalpha())
    return {
        "core": stripped,
        "typ": typ,
        "punct": punct,
        "ellipsis": "." in punct and len(punct) > 1,
        "is_abbr": is_abbr,
    }


def _next_is_sentence_start(nxt, params):
    """Orthographic/starter heuristic for an uncertain boundary (abbreviation or ellipsis)."""
    first = nxt["core"][:1]
    if not first:
        return False
    if first.islower():
        return False
    if nxt["typ"] in params.sent_starters:
        return True
    bits = params.ortho_context.get(nxt["typ"], 0)
    if bits & 2:  # upper-case at a sentence start
        return True
    if bits & 4:  # upper-case only inside a sentence
        return False
    return True


def sent_tokenize(text, language="english"):
    """Split *text* into sentences with the Punkt algorithm; raise LookupError if the model is absent."""
    params = load_punkt(language)
    if not isinstance(text, str):
        raise TypeError("sent_tokenize needs a str")
    toks = [(m.start(), m.end(), m.group()) for m in _TOKEN_RE.finditer(text)]
    if not toks:
        return []
    infos = [_tok_info(w, params) for _, _, w in toks]
    sentences = []
    start = toks[0][0]
    n = len(toks)
    for i in range(n - 1):
        info = infos[i]
        if not info["punct"]:
            continue
        boundary = False
        if "." not in info["punct"]:
            boundary = True  # '?' and '!' end sentences
        else:
            nxt = infos[i + 1]
            if (info["typ"], nxt["typ"]) in params.collocations:
                boundary = False
            elif info["ellipsis"] or info["is_abbr"]:
                boundary = _next_is_sentence_start(
                    {"core": toks[i + 1][2].lstrip(_OPENERS), "typ": nxt["typ"]}, params
                )
            else:
                boundary = True
        if boundary:
            sentences.append(text[start:toks[i][1]])
            start = toks[i + 1][0]
    sentences.append(text[start:toks[-1][1]])
    return sentences


# ---------------------------------------------------------------------------
# Penn Treebank and recommended word tokenizers.
# ---------------------------------------------------------------------------

_FUSED = [
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<!\w)'(tis)\b"), r"'t \1"),
    (re.compile(r"(?i)(?<!\w)'(twas)\b"), r"'t \1"),
]
_CANNOT = re.compile(r"(?i)\b(can)(not)\b")
_CAN_NT = re.compile(r"(?i)\b(ca)(n't)\b")


def _treebank(text, improved):
    s = text
    # Typographic quotation marks and (for the recommended tokenizer) dashes and asterisks.
    if improved:
        s = re.sub(r"[“”„‟«»‹›‚‛‘]", r" \g<0> ", s)
        s = re.sub(r"(?<!\w)’|’(?!\w)", r" \g<0> ", s)
        s = re.sub(r"[‒-―*]", r" \g<0> ", s)
        s = re.sub(r"--", r" -- ", s)
    if not improved:
        s = _CANNOT.sub(r"\1 \2", s)
    else:
        pass  # 'cannot' is kept as one token by the recommended tokenizer
    for pattern, repl in _FUSED:
        s = pattern.sub(repl, s)
    s = _CAN_NT.sub(r"\1 \2", s) if not improved else s
    # Period at the end of the text, optionally followed by closing quotes or brackets.
    s = re.sub(r"([^.])\.([\]\)}>\"']*)\s*$", r"\1 .\2 ", s)
    # Ellipses and runs of points.
    if improved:
        s = re.sub(r"\.{2,}", r" \g<0> ", s)
    else:
        s = s.replace("...", " ... ")
    # Starting quotes (opening after start, space or an opening bracket).
    if improved:
        s = re.sub(r"^\"", " '' ", s)
        s = re.sub(r"(^|[ (\[{<])\"", r"\1 `` ", s)
    else:
        s = re.sub(r"(^|[ (\[{<])\"", r"\1 `` ", s)
    s = re.sub(r"\"", " '' ", s)
    # Other punctuation split off.
    s = re.sub(r"[;@#$%&?!]", r" \g<0> ", s)
    s = re.sub(r"[\[\](){}<>]", r" \g<0> ", s)
    s = re.sub(r"([:,])(?!\d)", r" \1 ", s)
    # Clitics and n't.
    s = re.sub(r"(?i)(\S)('(?:s|m|d|ll|re|ve))\b", r"\1 \2", s)
    s = re.sub(r"(?i)(\S)(n't)\b", r"\1 \2", s)
    s = s.replace("''", " '' ")
    s = re.sub(r"([^'\s])'(?=\s|$)", r"\1 '", s)
    return s.split()


def _recommended(text, preserve_line):
    if preserve_line:
        return _treebank(text, improved=True)
    tokens = []
    for sentence in sent_tokenize(text, language="english"):
        tokens.extend(_treebank(sentence, improved=True))
    return tokens


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer."""

    def tokenize(self, text):
        return _treebank(text, improved=False)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (an improved Penn Treebank tokenizer).

    With *preserve_line* False the text is first split into sentences with the
    Punkt model for *language*; that model must be installed.
    """
    if not isinstance(text, str):
        raise TypeError("word_tokenize needs a str")
    if preserve_line:
        return _treebank(text, improved=True)
    if not isinstance(language, str):
        raise TypeError("language must be a str")
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_treebank(sentence, improved=True))
    return tokens


# ---------------------------------------------------------------------------
# Regular-expression, whitespace, blank-line, word/punctuation and tweet tokenizers.
# ---------------------------------------------------------------------------

_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Word/punctuation tokenizer: maximal runs of word characters or of non-word, non-space characters."""

    _pattern = _WORDPUNCT

    def tokenize(self, text):
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        return [(m.start(), m.end()) for m in self._pattern.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Tokens are maximal runs of non-whitespace characters."""

    _pattern = re.compile(r"\S+")

    def tokenize(self, text):
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        return [(m.start(), m.end()) for m in self._pattern.finditer(text)]


class RegexpTokenizer:
    """Tokenizer driven by a caller-supplied regular expression.

    Token mode (default): tokens are the matches. Gap mode: tokens are the pieces
    between matches. Empty pieces are dropped unless *discard_empty* is False.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._regex = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def tokenize(self, text):
        if self._gaps:
            pieces = []
            pos = 0
            for m in self._regex.finditer(text):
                pieces.append(text[pos:m.start()])
                pos = m.end()
            pieces.append(text[pos:])
        else:
            pieces = [m.group() for m in self._regex.finditer(text)]
        if self._discard_empty:
            pieces = [p for p in pieces if p]
        return pieces

    def span_tokenize(self, text):
        if self._gaps:
            spans = []
            pos = 0
            for m in self._regex.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regex.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


_SEPARATOR = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Segments of *text* separated by blank lines (empty and whitespace-only pieces dropped)."""
    pieces = []
    pos = 0
    for m in _SEPARATOR.finditer(text):
        pieces.append(text[pos:m.start()])
        pos = m.end()
    pieces.append(text[pos:])
    return [p for p in pieces if p.strip()]


_EMOTICON = (
    r"(?:[:;=8][\-o*']?[)(\[\]dDpPoO/\\|*3}{@]+|<3|\^_\^|[xX][dD]|\\o/)"
)
_URL = r"(?:https?://|www\.)\S+"
_HASHTAG = r"#\w+"
_HANDLE = r"@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])"
_NUMBER = r"[+-]?\d+(?:[.,]\d+)*"
_WORD = r"\w+(?:['’]\w+)*"
_ELLIPSIS = r"\.{2,}"
_OTHER = r"[^\w\s]"
_TWEET_RE = re.compile(
    "|".join(
        [
            "(?P<emo>%s)" % _EMOTICON,
            "(?P<url>%s)" % _URL,
            "(?P<tag>%s)" % _HASHTAG,
            "(?P<handle>%s)" % _HANDLE,
            "(?P<num>%s)" % _NUMBER,
            "(?P<word>%s)" % _WORD,
            "(?P<ell>%s)" % _ELLIPSIS,
            "(?P<other>%s)" % _OTHER,
        ]
    )
)
_HANDLE_STRIP = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REPEAT = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tokenizer for social-media text (emoticons, URLs, hashtags, handles, contractions)."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        if self._strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self._reduce_len:
            text = _REPEAT.sub(lambda m: m.group(1) * 3, text)
        tokens = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group()
            if m.lastgroup == "emo" or self._preserve_case:
                tokens.append(tok)
            else:
                tokens.append(tok.lower())
        return tokens


__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]
