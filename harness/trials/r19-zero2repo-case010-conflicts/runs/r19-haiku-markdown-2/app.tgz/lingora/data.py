"""Packaged-resource finder (``lingora.data``).

``path`` is the list of directories searched for packaged resources. Callers
may replace its contents in place. The initial contents come from the
``LINGORA_DATA`` environment variable (``os.pathsep``-separated), and are
empty when that variable is unset, so no packaged model is visible by default.
"""

import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


def find(resource):
    """Return the first existing location of *resource* under ``path``.

    Raises ``LookupError`` when no directory in ``path`` holds it.
    """
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "packaged resource %r is not installed (searched data.path=%r)"
        % (resource, list(path))
    )


def find_dir(resource, required_files=()):
    """Return a model directory that holds every file in *required_files*."""
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.isdir(candidate) and all(
            os.path.isfile(os.path.join(candidate, f)) for f in required_files
        ):
            return candidate
    raise LookupError(
        "packaged model %r is not installed (searched data.path=%r)"
        % (resource, list(path))
    )


def find_file(resource):
    """Return the first regular file named *resource* under ``path``."""
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.isfile(candidate):
            return candidate
    raise LookupError(
        "packaged file %r is not installed (searched data.path=%r)"
        % (resource, list(path))
    )
