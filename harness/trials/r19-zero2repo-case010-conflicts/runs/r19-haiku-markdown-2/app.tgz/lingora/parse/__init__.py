"""Grammar-based parsers (``lingora.parse``)."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a string")
    tokens = list(tokens)
    terminals = grammar.terminals()
    for tok in tokens:
        if tok not in terminals:
            raise ValueError("no production of the grammar produces token %r" % (tok,))
    return tokens


class ChartParser:
    """Exhaustive chart parser: returns every parse tree of the token list."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(_all_trees(self._grammar, tokens))


def _all_trees(grammar, tokens):
    by_lhs = {}
    for p in grammar.productions():
        by_lhs.setdefault(p.lhs(), []).append(p)
    n = len(tokens)
    memo = {}
    active = set()

    def trees(sym, i, j):
        key = (sym, i, j)
        if key in memo:
            return memo[key]
        if key in active:  # cyclic derivation of the same span: cut it
            return []
        active.add(key)
        out = []
        for prod in by_lhs.get(sym, []):
            for kids in seq(prod.rhs(), 0, i, j):
                out.append(Tree(sym, kids))
        active.discard(key)
        memo[key] = out
        return out

    def seq(rhs, k, pos, end):
        if k == len(rhs):
            if pos == end:
                yield []
            return
        sym = rhs[k]
        if isinstance(sym, Nonterminal):
            for e in range(pos, end + 1):
                for t in trees(sym, pos, e):
                    for rest in seq(rhs, k + 1, e, end):
                        yield [t] + rest
        elif pos < end and tokens[pos] == sym:
            for rest in seq(rhs, k + 1, pos + 1, end):
                yield [sym] + rest

    return trees(grammar.start(), 0, n)


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._run(tokens))

    def _run(self, tokens):
        grammar = self._grammar
        prods = grammar.productions()
        start = grammar.start()
        stack = []  # items: (symbol, node)
        pos = 0
        used_empty = set()
        budget = 10000 + 100 * (len(tokens) + 1)
        while budget > 0:
            budget -= 1
            reduced = False
            for index, prod in enumerate(prods):
                rhs = prod.rhs()
                k = len(rhs)
                if k == 0:
                    if (index, pos) in used_empty:
                        continue
                    used_empty.add((index, pos))
                    stack.append((prod.lhs(), Tree(prod.lhs(), [])))
                    reduced = True
                    break
                if k <= len(stack) and all(
                    stack[len(stack) - k + j][0] == rhs[j] for j in range(k)
                ):
                    kids = [item[1] for item in stack[len(stack) - k:]]
                    del stack[len(stack) - k:]
                    stack.append((prod.lhs(), Tree(prod.lhs(), kids)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append((tokens[pos], tokens[pos]))
                pos += 1
                continue
            break
        if pos == len(tokens) and len(stack) == 1 and stack[0][0] == start:
            return [stack[0][1]]
        return []


__all__ = ["ChartParser", "ShiftReduceParser"]
