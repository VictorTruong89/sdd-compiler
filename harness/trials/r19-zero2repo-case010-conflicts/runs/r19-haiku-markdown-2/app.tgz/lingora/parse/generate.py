"""Sentence generation from a grammar (``lingora.parse.generate``)."""

import itertools
import sys

from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Enumerate the token lists derived from *start* (default: the grammar's start).

    *depth* bounds the derivation depth (``None`` = unbounded); *n* bounds the
    number of sentences produced (``None`` = no limit).
    """
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _gen_one(grammar, start, depth)
    if n is None:
        return it
    return itertools.islice(it, n)


def _gen_one(grammar, item, depth):
    if isinstance(item, Nonterminal):
        if depth <= 0:
            return
        for prod in grammar.productions(lhs=item):
            yield from _gen_all(grammar, prod.rhs(), depth - 1)
    else:
        # A terminal; the empty-string terminal contributes no token.
        yield [] if item == "" else [item]


def _gen_all(grammar, items, depth):
    if not items:
        yield []
        return
    first, rest = items[0], items[1:]
    for head in _gen_one(grammar, first, depth):
        for tail in _gen_all(grammar, rest, depth):
            yield head + tail
