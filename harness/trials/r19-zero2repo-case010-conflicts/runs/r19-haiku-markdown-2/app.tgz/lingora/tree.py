"""Constituent trees (``lingora.tree``)."""

import re

_SEXP_TOKEN = re.compile(r"\(|\)|[^\s()]+")


def _leaf_text(child):
    if isinstance(child, Tree):
        return child._flat()
    if isinstance(child, tuple) and len(child) == 2:
        return "%s/%s" % (child[0], child[1])
    return str(child)


class Tree:
    """A labelled node whose children are leaves (str or tagged tokens) or trees."""

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text such as ``(S (NP I) (VP sleep))``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = _SEXP_TOKEN.findall(s)
        if not tokens:
            raise ValueError("empty tree text")
        pos = 0

        def parse():
            nonlocal pos
            if tokens[pos] != "(":
                raise ValueError("expected '(' in tree text at token %d" % pos)
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("missing node label in tree text")
            label = tokens[pos]
            pos += 1
            children = []
            while pos < len(tokens) and tokens[pos] != ")":
                if tokens[pos] == "(":
                    children.append(parse())
                else:
                    children.append(tokens[pos])
                    pos += 1
            if pos >= len(tokens):
                raise ValueError("unbalanced parentheses in tree text")
            pos += 1  # consume ')'
            return cls(label, children)

        tree = parse()
        if pos != len(tokens):
            raise ValueError("trailing text after tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def _flat(self):
        parts = [str(self._label)] + [_leaf_text(c) for c in self._children]
        return "(" + " ".join(parts) + ")"

    def pformat(self, margin=70, indent=0):
        """Pretty-printed text: pre-order, one line when it fits in *margin*."""
        flat = self._flat()
        if indent + len(flat) <= margin or not any(isinstance(c, Tree) for c in self._children):
            return flat
        pad = " " * (indent + 2)
        lines = ["(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(pad + child.pformat(margin, indent + 2))
            else:
                lines.append(pad + _leaf_text(child))
        return "\n".join(lines) + ")"

    def __str__(self):
        return self._flat()

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)
