"""Evaluation metrics (``lingora.metrics``)."""


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values.

    Lists of different lengths raise ``ValueError``. Two empty lists give 0.0.
    """
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError(
            "accuracy needs lists of equal length (got %d and %d)"
            % (len(reference), len(test))
        )
    if not reference:
        return 0.0
    matches = sum(1 for a, b in zip(reference, test) if a == b)
    return matches / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with *transpositions* the unrestricted Damerau–Levenshtein distance.

    Insertions and deletions cost 1, a substitution costs *substitution_cost*,
    and (with transpositions on) a transposition costs 1 (Lowrance and Wagner, 1975).
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance needs two str arguments")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    prev = list(range(len(s2) + 1))
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[len(s2)]


def _damerau_levenshtein(a, b, sub):
    maxdist = len(a) + len(b)
    H = {(-1, -1): maxdist}
    for i in range(len(a) + 1):
        H[(i, -1)] = maxdist
        H[(i, 0)] = i
    for j in range(len(b) + 1):
        H[(-1, j)] = maxdist
        H[(0, j)] = j
    last_row = {}
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            k = last_row.get(b[j - 1], 0)
            l = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub
            H[(i, j)] = min(
                H[(i - 1, j - 1)] + cost,
                H[(i, j - 1)] + 1,
                H[(i - 1, j)] + 1,
                H[(k - 1, l - 1)] + (i - k - 1) + 1 + (j - l - 1),
            )
        last_row[a[i - 1]] = i
    return H[(len(a), len(b))]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over the size of the union (0.0 for two empty sets)."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance needs sets")
    union = set(label1) | set(label2)
    if not union:
        return 0.0
    return len(set(label1) ^ set(label2)) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure need set or frozenset arguments")


def precision(reference, test):
    """|reference ∩ test| / |test|, or None when *test* is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(set(reference) & set(test)) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|, or None when *reference* is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(set(reference) & set(test)) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when no number results."""
    _check_sets(reference, test)
    if not reference or not test or not (set(reference) & set(test)):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)


__all__ = [
    "accuracy",
    "edit_distance",
    "jaccard_distance",
    "precision",
    "recall",
    "f_measure",
]
