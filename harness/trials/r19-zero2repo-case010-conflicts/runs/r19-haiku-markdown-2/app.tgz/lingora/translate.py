"""BLEU scoring (``lingora.translate``)."""

import math
from collections import Counter

DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU of *hypothesis* against one or more *references* (Papineni et al., 2002).

    *weights* gives one weight per n-gram order from unigrams (default: equal
    weights 0.25 on unigrams through 4-grams). Without a smoothing function, a
    candidate with no match at a weighted order scores 0.0.
    *smoothing_function*, if given, is called as ``f(numerators, denominators)``
    with two lists (one entry per order) and must return a list of precisions.
    """
    refs = [list(r) for r in references]
    hyp = list(hypothesis)
    if not refs:
        raise ValueError("bleu needs at least one reference")
    weights = list(DEFAULT_WEIGHTS if weights is None else weights)
    if not weights:
        raise ValueError("bleu needs at least one weight")
    if not hyp:
        return 0.0

    nums, dens = [], []
    for n in range(1, len(weights) + 1):
        hyp_counts = Counter(_ngrams(hyp, n))
        max_ref = Counter()
        for r in refs:
            for gram, count in Counter(_ngrams(r, n)).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(c, max_ref[g]) for g, c in hyp_counts.items())
        nums.append(clipped)
        dens.append(max(len(hyp) - n + 1, 0))

    if smoothing_function is not None:
        precisions = list(smoothing_function(nums, dens))
    else:
        precisions = []
        for num, den in zip(nums, dens):
            if num == 0 or den == 0:
                precisions.append(0.0)
            else:
                precisions.append(num / den)

    if any(w > 0 and p == 0 for w, p in zip(weights, precisions)):
        return 0.0
    log_mean = sum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0)

    c = len(hyp)
    ref_len = min((len(r) for r in refs), key=lambda L: (abs(L - c), L))
    if c > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / c)
    return brevity * math.exp(log_mean)
