"""Stemmers (``lingora.stem``)."""

import re

from lingora import data

VOWELS = "aeiou"

# ---------------------------------------------------------------------------
# Porter stemmer (Porter, 1980) with LINGORA extensions as the default mode.
# ---------------------------------------------------------------------------

_PORTER_IRREGULAR = {
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "innings": "inning",
    "inning": "inning",
    "outings": "outing",
    "outing": "outing",
    "cannings": "canning",
    "canning": "canning",
    "herring": "herring",
    "earrings": "earring",
    "proceed": "proceed",
    "exceed": "exceed",
    "succeed": "succeed",
    "news": "news",
    "howe": "howe",
}

_PORTER_MODES = {
    "lingora": "lingora",
    "martin": "martin",
    "original": "original",
    "LINGORA_EXTENSIONS": "lingora",
    "MARTIN_EXTENSIONS": "martin",
    "ORIGINAL_ALGORITHM": "original",
}


def _is_cons(word, i):
    ch = word[i]
    if ch in VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    m = 0
    seen_vowel = False
    for i in range(len(stem)):
        if _is_cons(stem, i):
            if seen_vowel:
                m += 1
                seen_vowel = False
        else:
            seen_vowel = True
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _cvc(stem, mode):
    if mode == "lingora" and len(stem) == 2 and not _is_cons(stem, 0) and _is_cons(stem, 1):
        return True
    if len(stem) < 3:
        return False
    return (
        _is_cons(stem, len(stem) - 3)
        and not _is_cons(stem, len(stem) - 2)
        and _is_cons(stem, len(stem) - 1)
        and stem[-1] not in "wxy"
    )


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _step2(word, mode):
    table = [list(x) for x in _STEP2_ORIGINAL]
    if mode in ("lingora", "martin"):
        table = [x for x in table if x[0] != "abli"]
        table.append(["bli", "ble"])
        table.append(["fulli", "ful"])
        table.append(["logi", "log"])
    if mode == "lingora" and word.endswith("alli") and _measure(word[:-4]) > 0:
        return _step2(word[:-2], mode)
    matches = [(s, r) for s, r in table if word.endswith(s)]
    if not matches:
        return word
    suffix, repl = max(matches, key=lambda x: len(x[0]))
    stem = word[: len(word) - len(suffix)]
    if suffix == "logi":
        if _measure(word[:-3]) > 0:
            return word[:-1]
        return word
    if _measure(stem) > 0:
        return stem + repl
    return word


def _porter(word, mode):
    lingora = mode == "lingora"
    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ies"):
        word = word[:-2] if not lingora or len(word) != 4 else word[:-1]
    elif word.endswith("ss"):
        pass
    elif word.endswith("s"):
        word = word[:-1]

    # Step 1b
    skip_1b = False
    if lingora and word.endswith("ied"):
        word = word[:-1] if len(word) == 4 else word[:-2]
        skip_1b = True
    if not skip_1b:
        if word.endswith("eed"):
            if _measure(word[:-3]) > 0:
                word = word[:-1]
        elif (word.endswith("ed") and _has_vowel(word[:-2])) or (
            word.endswith("ing") and _has_vowel(word[:-3])
        ):
            word = word[:-2] if word.endswith("ed") else word[:-3]
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif _double_cons(word) and word[-1] not in "lsz":
                word = word[:-1]
            elif _measure(word) == 1 and _cvc(word, mode):
                word += "e"

    # Step 1c
    if word.endswith("y"):
        stem = word[:-1]
        if lingora:
            cond = len(stem) >= 2 and _is_cons(stem, len(stem) - 1)
        else:
            cond = _has_vowel(stem)
        if cond:
            word = stem + "i"

    word = _step2(word, mode)

    # Step 3
    for suffix, repl in _STEP3:
        if word.endswith(suffix):
            stem = word[: len(word) - len(suffix)]
            if _measure(stem) > 0:
                word = stem + repl
            break

    # Step 4
    for suffix in sorted(_STEP4, key=len, reverse=True):
        if word.endswith(suffix):
            stem = word[: len(word) - len(suffix)]
            if _measure(stem) > 1:
                if suffix == "ion":
                    if stem.endswith(("s", "t")):
                        word = stem
                else:
                    word = stem
            break

    # Step 5
    if word.endswith("e"):
        stem = word[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _cvc(stem, mode)):
            word = stem
    if word.endswith("ll") and _measure(word[:-1]) > 1:
        word = word[:-1]
    return word


class PorterStemmer:
    """Porter stemmer. The default mode is LINGORA's extended algorithm.

    Modes: ``"lingora"`` (default), ``"martin"`` (Martin Porter's extensions) and
    ``"original"`` (the published 1980 algorithm). Names used by the PRD such as
    ``"LINGORA_EXTENSIONS"`` are accepted too.
    """

    def __init__(self, mode="lingora"):
        if mode not in _PORTER_MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = _PORTER_MODES[mode]

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("stem needs a str")
        if to_lowercase:
            word = word.lower()
        if word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        if len(word) <= 2:
            return word
        return _porter(word, self.mode)


# ---------------------------------------------------------------------------
# Snowball: English (Porter2) and the original Porter algorithm rendered by Snowball.
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)
_SNOWBALL_IMPLEMENTED = ("english", "porter")

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_VOWELS = "aeiouy"
_P2_LI_END = "cdeghkmnrt"
_P2_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_P2_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"), ("entli", "ent"),
    ("izer", "ize"), ("ization", "ize"), ("ational", "ate"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
    ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
]
_P2_STEP3 = [
    ("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
]
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _p2_regions(word):
    if word.startswith(("gener", "commun", "arsen")):
        prefix = 5 if word.startswith(("gener", "arsen")) else 6
        r1 = prefix
    else:
        r1 = len(word)
        for i in range(1, len(word)):
            if word[i - 1] in _P2_VOWELS and word[i] not in _P2_VOWELS:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i - 1] in _P2_VOWELS and word[i] not in _P2_VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _p2_short_syllable_at_end(word):
    if len(word) == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if len(word) >= 3:
        return (
            word[-3] not in _P2_VOWELS
            and word[-2] in _P2_VOWELS
            and word[-1] not in _P2_VOWELS
            and word[-1] not in "wxY"
        )
    return False


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if word.startswith("'"):
        word = word[1:]
    # Step 0
    for suf in ("'s'", "'s", "'"):
        if word.endswith(suf):
            word = word[: -len(suf)]
            break
    # Mark consonantal y as Y.
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    word = "".join(chars)
    r1, r2 = _p2_regions(word)

    def ends_in_region(suffix, region):
        return word.endswith(suffix) and len(word) - len(suffix) >= region

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        pre = word[:-3]
        word = pre + ("i" if len(pre) > 1 else "ie")
    elif word.endswith("s") and not word.endswith(("us", "ss")):
        pre = word[:-1]
        if any(c in _P2_VOWELS for c in pre[:-1]):
            word = pre
    if word in _P2_EXC2:
        return word.replace("Y", "y")

    # Step 1b
    if word.endswith(("eed", "eedly")):
        suf = "eed" if word.endswith("eed") else "eedly"
        if ends_in_region(suf, r1):
            word = word[: -len(suf)] + "ee"
    else:
        suf = None
        for cand in ("ingly", "edly", "ing", "ed"):
            if word.endswith(cand):
                suf = cand
                break
        if suf is not None:
            pre = word[: -len(suf)]
            if any(c in _P2_VOWELS for c in pre):
                word = pre
                if word.endswith(("at", "bl", "iz")):
                    word += "e"
                elif word.endswith(_P2_DOUBLES):
                    word = word[:-1]
                elif r1 >= len(word) and _p2_short_syllable_at_end(word):
                    word += "e"

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _P2_VOWELS:
        word = word[:-1] + "i"

    # Step 2 (R1)
    cands = [(s, r) for s, r in _P2_STEP2 if word.endswith(s)]
    if cands:
        suf, repl = max(cands, key=lambda x: len(x[0]))
        if ends_in_region(suf, r1):
            if suf == "li":
                if len(word) > 2 and word[-3] in _P2_LI_END:
                    word = word[:-2]
            elif suf == "ogi":
                if len(word) > 3 and word[-4] == "l":
                    word = word[:-3] + "og"
            else:
                word = word[: -len(suf)] + repl

    # Step 3 (R1; 'ative' in R2)
    cands = [(s, r) for s, r in _P2_STEP3 if word.endswith(s)]
    if cands:
        suf, repl = max(cands, key=lambda x: len(x[0]))
        region = r2 if suf == "ative" else r1
        if ends_in_region(suf, region):
            word = word[: -len(suf)] + repl

    # Step 4 (R2)
    cands = [s for s in _P2_STEP4 if word.endswith(s)]
    if cands:
        suf = max(cands, key=len)
        if ends_in_region(suf, r2):
            if suf == "ion":
                if len(word) > 3 and word[-4] in "st":
                    word = word[:-3]
            else:
                word = word[: -len(suf)]

    # Step 5
    if word.endswith("e"):
        if len(word) - 1 >= r2 or (
            len(word) - 1 >= r1 and not _p2_short_syllable_at_end(word[:-1])
        ):
            word = word[:-1]
    elif word.endswith("l") and len(word) - 1 >= r2 and word.endswith("ll"):
        word = word[:-1]

    return word.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmer for one language. Only ``english`` and ``porter`` are implemented."""

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language %r" % (language,))
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError(
                "the Snowball stemmer for %r is not implemented in this build" % (language,)
            )
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            path = data.find_file("corpora/stopwords/%s" % language)
            with open(path, encoding="utf-8") as fh:
                self._stopwords = {line.strip().lower() for line in fh if line.strip()}

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem needs a str")
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self.language == "english":
            return _porter2(word)
        return _porter(word, "original")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk) stemmer.
# ---------------------------------------------------------------------------

# Rule format: <suffix><digit>[<append>]<'.' | '>'>. '*' after the suffix means the
# rule applies to intact words only. '.' stops, '>' continues.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "earth3>",
]


def _parse_lancaster_rule(rule):
    m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    return m.group(1), m.group(2) == "*", int(m.group(3)), m.group(4), m.group(5)


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


def _lancaster_acceptable(stem):
    if not stem:
        return False
    if stem[0] in VOWELS:
        return len(stem) >= 2
    return len(stem) >= 3 and _has_vowel(stem)


class LancasterStemmer:
    """Paice/Husk stemmer. The rule table is partial; see NOTES.md."""

    def __init__(self, rules=None):
        self._rules = _LANCASTER_PARSED if rules is None else [_parse_lancaster_rule(r) for r in rules]

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem needs a str")
        word = word.lower()
        intact = True
        while True:
            applied = None
            for rule in self._rules:
                suffix, intact_only, count, append, _end = rule
                if intact_only and not intact:
                    continue
                if not word.endswith(suffix):
                    continue
                stem = word[: len(word) - count] + append
                if not _lancaster_acceptable(stem):
                    continue
                word = stem
                intact = False
                applied = rule
                break
            if applied is None or applied[4] == ".":
                break  # no rule applies, or a terminating rule fired
        return word


# ---------------------------------------------------------------------------
# Regular-expression stemmer and resource-gated members of the family.
# ---------------------------------------------------------------------------

class RegexpStemmer:
    """Removes every match of *regexp* from the word; nothing else changes."""

    def __init__(self, regexp):
        self._regex = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem needs a str")
        return self._regex.sub("", word)


class ARLSTem:
    """Arabic ARLSTem stemmer (outside this specification; not implemented)."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    """Arabic ARLSTem2 stemmer (outside this specification; not implemented)."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem2 is not implemented in this build")


class WordNetLemmatizer:
    """WordNet lemmatizer. Raises when the WordNet resource is not installed."""

    def __init__(self):
        data.find_dir("corpora/wordnet")
        raise NotImplementedError("the WordNet lemmatizer is not implemented in this build")

    def lemmatize(self, word):
        raise NotImplementedError("the WordNet lemmatizer is not implemented in this build")


__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]
