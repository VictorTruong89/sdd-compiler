---
name: prosecheck-build
description: State of the prosecheck build in /app (detector, hooks, spec conflict decisions); read before changing scoring, hook replies, or NOTES.md.
metadata:
  type: project
---

The prosecheck project was built from `spec/` into `/app`: `scripts/detect.py` (stdlib-only detector), five Node hooks under `hooks/` with shared code in `hooks/lib/prosecheck-core.js`, `commands/prosecheck.md`, `.cursor/rules/prosecheck.mdc`, and `NOTES.md`.

**Why:** the spec contradicts itself in about twenty places (usage stream, decisive floor, ledger size and age, stats thresholds, operand rules, env precedence). Each resolution is recorded in `/app/NOTES.md` section 1; the rule used was that the PRD governs rules and the IC governs interface and reply shapes.

**How to apply:** when changing behaviour, check NOTES.md first and keep it in sync. The guard skips anything under the plugin root, which is `/app` here, so prose saved under `/app` gets no nudge unless `CLAUDE_PLUGIN_ROOT` is set elsewhere.
