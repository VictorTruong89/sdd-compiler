#!/usr/bin/env node
'use strict';
// PostToolUse hook: scores just-saved prose files and nudges the host when a file is flagged.
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

const APPLY_PATCH_RX = /^\*\*\* (Add File|Update File|Move to):\s*(.+?)\s*$/;
const MAX_PATCH_PATHS = 16;
const PLAIN_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;

function pathsFromPayload(input) {
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const tool = String(input.tool_name || '');
  const patchBody = [ti.command, ti.input, ti.patch].find((v) => typeof v === 'string');
  if (/apply_patch/i.test(tool) || (patchBody && patchBody.includes('*** '))) {
    const out = [];
    const seen = new Set();
    for (const line of String(patchBody || '').split(/\r?\n/)) {
      const m = APPLY_PATCH_RX.exec(line);
      if (!m) continue;
      const p = m[2].trim();
      if (!p || seen.has(p)) continue;
      seen.add(p);
      out.push(p);
      if (out.length >= MAX_PATCH_PATHS) break;
    }
    return out;
  }
  if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) return [ti.notebook_path.trim()];
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) return [ti.file_path.trim()];
  return [];
}

function inPluginTree(abs) {
  const root = path.resolve(core.pluginRoot());
  const rel = path.relative(root, abs);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipForLocation(abs) {
  const segs = abs.split(/[\\/]+/);
  return segs.includes('node_modules') || segs.includes('.git') || inPluginTree(abs);
}

function lastError(stderr) {
  const lines = String(stderr || '').split('\n').map((x) => x.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const obj = JSON.parse(lines[i]);
      if (obj && typeof obj.error === 'string') return obj.error;
    } catch (e) {
      /* keep looking */
    }
  }
  return lines.length ? lines[lines.length - 1].slice(0, 160) : '';
}

function scoreOne(sid, rawPath, cwd, level, threshold, nudges) {
  const abs = path.isAbsolute(rawPath) ? rawPath : path.resolve(cwd, rawPath);
  const base = path.basename(abs);
  const lower = base.toLowerCase();
  const ext = path.extname(lower);
  const stem = lower.endsWith(ext) && ext ? lower.slice(0, -ext.length) : lower;
  if (skipForLocation(abs)) return;
  if (core.INSTRUCTION_NAMES.has(lower)) return;
  if (core.INSTRUCTION_STEMS.has(stem) && !core.PLAIN_EXT.has(ext) && !core.ARCHIVE_EXT.has(ext)) return;

  const now = Date.now();
  const record = (kind, extra) => core.appendLedger(sid, Object.assign({ ts: now, base, kind }, extra || {}));

  if (core.BINARY_EXT.has(ext)) {
    record('binary');
    return;
  }
  if (!core.PLAIN_EXT.has(ext) && !core.ARCHIVE_EXT.has(ext)) return;

  let st = null;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    st = null;
  }
  if (!st) {
    record('failed', { reason: 'cannot read file' });
    return;
  }
  if (!st.isFile()) return;

  const isArchive = core.ARCHIVE_EXT.has(ext);
  const cap = isArchive ? core.ARCHIVE_CAP : core.PLAIN_CAP;
  if (st.size > cap) {
    record('skip', { limitKb: cap / 1024 });
    return;
  }

  const res = core.runDetector(['--', abs], '', isArchive ? ARCHIVE_TIMEOUT_MS : PLAIN_TIMEOUT_MS);
  if (!res.launched) {
    record('failed', { reason: res.missing ? 'detector not found in the plugin tree' : 'Python not found' });
    return;
  }
  if (res.timedOut) {
    record('failed', { reason: 'the detector timed out' });
    return;
  }
  if (res.status !== 0) {
    const why = lastError(res.stderr);
    record('failed', { reason: why ? 'detector exited without a usable result: ' + why : 'detector exited without a usable result' });
    return;
  }
  if (!res.stdout.trim()) {
    record('failed', { reason: 'detector produced no output' });
    return;
  }
  const report = core.parseReport(res.stdout);
  if (!report) {
    record('failed', { reason: 'detector output was not a structured report' });
    return;
  }
  const sum = core.reportSummary(report);
  if (!Number.isFinite(sum.score)) {
    record('failed', { reason: 'report had no numeric score' });
    return;
  }
  const labels = sum.findings.map((f) => f.label);
  const flagged = sum.score > threshold;
  record('scored', {
    score: sum.score,
    band: sum.band,
    phrase: core.hookPhrase(sum.band),
    truncated: sum.truncated,
    flagged,
    labels: labels.slice(0, core.LABEL_CAP),
  });
  if (!flagged) return;
  const coverage = sum.truncated ? `, first ${core.WINDOW_TEXT} characters only` : '';
  nudges.push(
    `prosecheck: ${base} ${core.hookPhrase(sum.band)} (score ${sum.score}, band ${sum.band}${coverage}). ` +
    `Flagged: ${labels.slice(0, core.LABEL_CAP).join('; ') || 'none named'}. ` +
    'Fix the flagged spans in this file, keeping sentence-length variation.'
  );
}

function main() {
  const input = core.readHostJSON();
  const level = core.effectiveLevel();
  if (level === 'off' || level === 'lite') return '';
  const threshold = level === 'strict' ? 20 : 40;
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const paths = pathsFromPayload(input);
  const nudges = [];
  for (const p of paths) {
    try {
      scoreOne(sid, p, cwd, level, threshold, nudges);
    } catch (e) {
      /* a single bad path must not stop the others or fail the host */
    }
  }
  if (!nudges.length) return '';
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: nudges.join('\n'),
    },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
