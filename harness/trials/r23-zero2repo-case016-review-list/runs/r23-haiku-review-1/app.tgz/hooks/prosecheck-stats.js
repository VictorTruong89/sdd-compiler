#!/usr/bin/env node
'use strict';
// /prosecheck stats: token totals from the session transcript and, when long enough, a score of the session's own prose.
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

const MAX_SLICE = 40000;
const MIN_SLICE_FOR_SCORE = 200;

function newestTranscript() {
  const root = path.join(core.configDir(), 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 4) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(p, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mt = fs.statSync(p).mtimeMs;
          if (!best || mt > best.mt) best = { p, mt };
        } catch (e) {
          /* skip */
        }
      }
    }
  };
  walk(root, 0);
  return best ? best.p : null;
}

function statsReply(transcriptPath) {
  const level = core.effectiveLevel();
  let file = null;
  if (typeof transcriptPath === 'string' && transcriptPath.trim()) {
    file = transcriptPath.trim();
    try {
      if (!fs.statSync(file).isFile()) file = null;
    } catch (e) {
      file = null;
    }
    if (!file) {
      return `prosecheck stats: could not read the session transcript at ${transcriptPath.trim()}.\nlevel: ${level}`;
    }
  } else {
    file = newestTranscript();
    if (!file) {
      return `prosecheck stats: no session transcript found under the config projects folder.\nlevel: ${level}`;
    }
  }
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return `prosecheck stats: could not read the session transcript at ${file}.\nlevel: ${level}`;
  }
  const seen = new Map();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  let index = 0;
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : 'row-' + index;
    index += 1;
    if (seen.has(id)) continue;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const texts = Array.isArray(msg.content)
      ? msg.content.filter((c) => c && c.type === 'text' && typeof c.text === 'string').map((c) => c.text)
      : [];
    seen.set(id, texts.join('\n'));
    turns += 1;
    outputTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
  }
  const lines = [
    `prosecheck stats`,
    `level: ${level}`,
    `assistant turns: ${turns}`,
    `output tokens: ${outputTokens}`,
    `cache-read input tokens: ${cacheRead}`,
  ];
  const prose = Array.from(seen.values()).join('\n')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/~~~[\s\S]*?~~~/g, '');
  const slice = prose.slice(-MAX_SLICE).trim();
  if (slice.length > MIN_SLICE_FOR_SCORE) {
    const res = core.runDetector([], slice, 8000);
    const report = res.launched && res.status === 0 ? core.parseReport(res.stdout) : null;
    const score = report ? core.reportSummary(report).score : null;
    if (Number.isFinite(score)) lines.push(`session prose ai_tell_score: ${score}`);
  }
  return lines.join('\n');
}

module.exports = { statsReply, newestTranscript };

if (require.main === module) {
  try {
    const input = core.readHostJSON();
    const reason = statsReply(input.transcript_path);
    process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
  } catch (e) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
