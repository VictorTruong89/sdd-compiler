#!/usr/bin/env node
'use strict';
// SubagentStart hook: returns the same writing contract inside the host's subagent envelope.
const core = require('./lib/prosecheck-core.js');

try {
  core.readHostJSON();
  const level = core.effectiveLevel();
  if (level !== 'off') {
    const envelope = {
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: core.contract(level),
      },
    };
    process.stdout.write(JSON.stringify(envelope) + '\n');
  }
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
