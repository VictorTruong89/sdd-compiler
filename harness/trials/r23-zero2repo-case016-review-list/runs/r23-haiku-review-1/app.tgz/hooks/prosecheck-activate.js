#!/usr/bin/env node
'use strict';
// SessionStart hook: prints the welcome (first run only) and the writing contract for the live level.
const core = require('./lib/prosecheck-core.js');

function main() {
  core.readHostJSON();
  core.pruneLedgers();
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  const firstRun = !core.flagFileExists();
  let stored = core.readStoredLevel();
  if (!stored) {
    try {
      core.writeLevel(level);
    } catch (e) {
      /* unwritable settings folder: the contract still applies this session */
    }
  }
  const parts = [];
  if (firstRun) parts.push(core.welcomeText());
  parts.push(core.contract(level));
  return parts.join('\n\n');
}

try {
  const out = main();
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
