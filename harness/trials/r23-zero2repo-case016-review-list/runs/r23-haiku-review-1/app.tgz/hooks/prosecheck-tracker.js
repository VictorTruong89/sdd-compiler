#!/usr/bin/env node
'use strict';
// UserPromptSubmit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');
const { statsReply } = require('./prosecheck-stats.js');

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const COMMAND_RX = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/i;
const STOP_RX = /^(stop prosecheck|prosecheck off)$/i;

function block(reason) {
  return JSON.stringify({ decision: 'block', reason });
}

function helpReply(level) {
  return [
    `prosecheck level: ${level}`,
    'Code, commits, config, and chat are always left alone; prosecheck never rewrites them.',
    '/prosecheck lite - writing contract only; saved files get no scoring.',
    '/prosecheck full (default) - writing contract plus the saved-file guard, threshold 40.',
    '/prosecheck strict - writing contract plus the guard at threshold 20, with a cleanup scrub.',
    '/prosecheck off | on - off: disable the tool; on: re-enable it at full.',
    '/prosecheck status - one line showing the live level.',
    '/prosecheck show - list the files scored or skipped in this session.',
    '/prosecheck check <path> - score one file and report only; it does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - session token use and the score of this session\'s own prose.',
    '/prosecheck init - export the writing contract to AGENTS.md for agents other than Claude Code.',
    'For a deep rewrite, say "prosecheck this" or "humanize this" in plain language.',
  ].join('\n');
}

function unknownReply(word) {
  return `unknown subcommand "${word}". Valid subcommands: ${SUBCOMMANDS.join(', ')}.`;
}

function saveLevel(level) {
  try {
    core.writeLevel(level);
    return true;
  } catch (e) {
    return false;
  }
}

function setLevel(level) {
  if (!saveLevel(level)) {
    return `prosecheck could not save the level ${level}: the settings folder is not writable. The level is unchanged.`;
  }
  if (level === 'lite') return 'prosecheck set to lite: writing contract on, saved files are not scored.';
  if (level === 'full') return 'prosecheck set to full: writing contract on, saved files scored with threshold 40.';
  if (level === 'strict') return 'prosecheck set to strict: writing contract on, threshold 20, cleanup scrub on.';
  return 'prosecheck is off. Nothing is injected or scored until you run /prosecheck on.';
}

function statusReply() {
  return `prosecheck status: level ${core.effectiveLevel()}.`;
}

// ---------------------------------------------------------------- check

function cleanPathArg(arg) {
  let p = String(arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  const q = p.match(/^(['"])([\s\S]*)\1$/);
  if (q) p = q[2];
  if (p.startsWith('@')) p = p.slice(1);
  return p.trim();
}

function checkReply(arg, cwd) {
  const typed = cleanPathArg(arg);
  if (!typed) {
    return 'check needs a file path: /prosecheck check <path>. Nothing was scored.';
  }
  const abs = path.isAbsolute(typed) ? typed : path.resolve(cwd, typed);
  const base = path.basename(abs);
  const ext = path.extname(base).toLowerCase();
  let st = null;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    st = null;
  }
  if (!st) return `cannot read ${typed}. Nothing was scored.`;
  if (!st.isFile()) return `${typed} is not a file. Nothing was scored.`;
  if (core.BINARY_EXT.has(ext)) return `${base} has no readable text: PDF and RTF are not scored.`;
  const isArchive = core.ARCHIVE_EXT.has(ext);
  const cap = isArchive ? core.ARCHIVE_CAP : core.PLAIN_CAP;
  if (st.size > cap) {
    const kb = Math.round(cap / 1024);
    return `${base} is over ${kb} KB, so it was not scored.`;
  }
  const res = core.runDetector(['--', abs], '', isArchive ? 15000 : 8000);
  if (!res.launched) {
    return `${base}: detector unavailable (Python was not found), so nothing was scored.`;
  }
  if (res.missing) {
    return `${base}: detector unavailable (the bundled detector is missing), so nothing was scored.`;
  }
  if (res.timedOut) return `${base} failed: the detector timed out.`;
  if (res.status !== 0) {
    const errLine = String(res.stderr || '').split('\n').map((x) => x.trim()).filter(Boolean).pop() || '';
    let reason = '';
    try {
      const obj = JSON.parse(errLine);
      if (obj && typeof obj.error === 'string') reason = obj.error;
    } catch (e) {
      reason = errLine;
    }
    return `${base} failed to score.${reason ? ' ' + reason : ''}`;
  }
  if (!res.stdout.trim()) return `${base}: the detector gave no report.`;
  const report = core.parseReport(res.stdout);
  if (!report) return 'The detector printed text that is not a report, so there was no report to show.';
  const sum = core.reportSummary(report);
  if (!Number.isFinite(sum.score)) return 'The detector printed a report without a numeric score, so there was no report to show.';
  const lines = [];
  lines.push(`${base} - ${core.hookPhrase(sum.band)} (score ${sum.score}/100, band: ${sum.band})`);
  let conf = `confidence: ${sum.confidence}`;
  if (sum.confidence !== 'high' && sum.confidenceReason) conf += ' - ' + sum.confidenceReason;
  lines.push(conf);
  if (sum.truncated) lines.push(`coverage: first ${core.WINDOW_TEXT} characters only`);
  if (sum.findings.length) {
    const tells = sum.findings.slice(0, core.CHECK_LABEL_CAP).map((f) => `${f.label} (x${f.count})`);
    lines.push(`tells: ${tells.join('; ')}`);
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ---------------------------------------------------------------- show

function showReply(sid) {
  const records = core.readLedger(sid).slice().reverse();
  if (!records.length) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files (for example .docx) are saved; .pdf and .rtf are recorded as binary and not re-scored.';
  }
  const rows = ['Files in this session, newest first:'];
  for (const r of records) {
    const base = String(r.base || '');
    if (r.kind === 'scored') {
      const cover = r.truncated ? `, first ${core.WINDOW_TEXT} characters only` : '';
      let row = `${base} - ${r.phrase} (score ${r.score}/${r.band}${cover})`;
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, core.LABEL_CAP) : [];
      if (labels.length) {
        row += ` - ${r.flagged ? 'flagged' : 'under threshold'}: ${labels.join('; ')}`;
      }
      rows.push(row);
    } else if (r.kind === 'skip') {
      rows.push(`${base} - not scored: over ${Math.round(r.limitKb)} KB`);
    } else if (r.kind === 'binary') {
      rows.push(`${base} - not re-scored (binary file)`);
    } else {
      rows.push(`${base} - not scored: ${r.reason || 'unknown reason'}`);
    }
  }
  return rows.join('\n');
}

// ---------------------------------------------------------------- doctor

function doctorReply(form) {
  const level = core.effectiveLevel();
  const lines = ['prosecheck doctor'];
  if (level === 'off') {
    lines.push(`mode: off - not a fault of the install; run /prosecheck on to turn it back on.`);
  } else {
    lines.push(`mode: ${level} [OK]`);
  }
  const det = core.detectorPath();
  if (det) {
    lines.push('detector: bundled scripts/detect.py found [OK]');
  } else {
    lines.push('detector: bundled scripts/detect.py not found under the plugin root');
  }
  let pyLine;
  if (!det) {
    pyLine = 'python: no bundled detector to run, so nothing was scored';
  } else {
    const sample = 'Doctor check. The quick brown fox jumps over the lazy dog.';
    const res = core.runDetector([], sample, 8000);
    if (!res.launched) {
      pyLine = 'python not found on PATH; saved files are not re-scored until Python is available. Prose is still shaped by the writing contract.';
    } else {
      const report = res.status === 0 ? core.parseReport(res.stdout) : null;
      const score = report ? core.reportSummary(report).score : null;
      if (Number.isFinite(score)) {
        pyLine = 'python: the detector ran and returned a numeric score [OK]';
      } else {
        pyLine = 'python: the detector ran but its output was not a numeric score';
      }
    }
  }
  lines.push(pyLine);
  const dir = core.configDir();
  let writable = false;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    writable = true;
  } catch (e) {
    writable = false;
  }
  lines.push(writable ? `settings: folder ${dir} is writable [OK]` : `settings: folder ${dir} is not writable`);
  const checkLines = lines.slice(1);
  const allOk = checkLines.every((l) => l.includes('[OK]'));
  const modeOnlyOff = level === 'off' && checkLines.slice(1).every((l) => l.includes('[OK]'));
  let closer;
  if (allOk && level !== 'off') {
    closer = `All four checks passed, so the tool is active. Plain text is accepted up to 512 KB and archives or notebooks up to 4 MB; the detector scores the first ${core.WINDOW_TEXT} characters. Run ${form} show to see files that were only partly scanned or skipped.`;
  } else if (modeOnlyOff) {
    closer = `The install is healthy. The mode is off, so saved files are not scored while it is off. Run ${form} on to turn it back on.`;
  } else {
    closer = 'Some checks need repair: fix the faulty checks above, then run /prosecheck doctor again.';
  }
  return [...lines, closer].join('\n');
}

// ---------------------------------------------------------------- init

function initReply(form, cwd) {
  const level = core.effectiveLevel();
  if (level === 'off') {
    return `prosecheck is switched off, so nothing was written. Run ${form} on to allow the export.`;
  }
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') {
      out.push('cannot read AGENTS.md; the contract was not added to it.');
      existing = undefined;
    } else {
      existing = '';
    }
  }
  if (existing !== undefined) {
    if (existing.includes('Prose writing contract (prosecheck)')) {
      out.push('AGENTS.md already has the writing contract; it was not changed.');
    } else {
      try {
        const section = core.exportSection(level);
        let next;
        if (!existing) {
          next = section;
        } else {
          next = (existing.endsWith('\n') ? existing : existing + '\n') + '\n' + section;
        }
        fs.writeFileSync(agents, next);
        out.push('Wrote the writing contract to AGENTS.md.');
      } catch (e) {
        out.push(`cannot write AGENTS.md (${e.code || 'error'}); the contract was not added.`);
      }
    }
  }
  const ruleDest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDest)) {
    out.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    const src = path.join(core.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    try {
      if (!fs.existsSync(src)) throw Object.assign(new Error('shipped rule missing'), { code: 'ENOENT' });
      fs.mkdirSync(path.dirname(ruleDest), { recursive: true });
      fs.copyFileSync(src, ruleDest);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push(`cannot write .cursor/rules/prosecheck.mdc (${e.code || 'error'}); the rule was not created.`);
    }
  }
  return out.join('\n');
}

// ---------------------------------------------------------------- router

function route(prompt, input) {
  const trimmed = prompt.trim();
  if (STOP_RX.test(trimmed)) {
    if (!saveLevel('off')) {
      return block('prosecheck could not save the off level: the settings folder is not writable. The level is unchanged.');
    }
    return block('prosecheck is off (stop phrase received). Run /prosecheck on to turn it back on.');
  }
  const m = COMMAND_RX.exec(trimmed);
  if (!m) return null;
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const parts = rest.split(/\s+/).filter(Boolean);
  const sub = (parts[0] || '').toLowerCase();
  const arg = parts.slice(1).join(' ');
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  if (sub === '' || sub === 'help') return block(helpReply(core.effectiveLevel()));
  if (sub === 'lite' || sub === 'full' || sub === 'strict' || sub === 'off') return block(setLevel(sub));
  if (sub === 'on') {
    if (!saveLevel('full')) {
      return block('prosecheck could not save the on level: the settings folder is not writable. The level is unchanged.');
    }
    return block('prosecheck is on at level full. Scoring and the writing contract are active.');
  }
  if (sub === 'status') return block(statusReply());
  if (sub === 'show') return block(showReply(sid));
  if (sub === 'check') return block(checkReply(arg, cwd));
  if (sub === 'doctor') return block(doctorReply(form));
  if (sub === 'stats') return block(statsReply(input.transcript_path));
  if (sub === 'init') return block(initReply(form, cwd));
  return block(unknownReply(parts[0]));
}

function main() {
  const input = core.readHostJSON();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const out = route(prompt, input);
  if (out !== null) return out;
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: `prosecheck level: ${level}. Prose deliverables follow the writing contract; code, config, and commits are untouched.`,
    },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
