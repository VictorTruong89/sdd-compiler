#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With FILE, the file is read (its extension decides the extraction). With no FILE, standard
input is read as plain text. The default output is one JSON report object on standard
output. --clean prints the scrubbed text instead. --ci adds a low/high interval on the score.
Failures print one JSON object {"error": ...} as the last line of standard error.
No network, no model, no third-party packages.
"""
import sys
import os
import io
import re
import json
import math
import zipfile
import unicodedata
from collections import Counter
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}
BINARY_EXT = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score a prose file (or standard input) for AI-writing patterns. Local only.
  --clean      print the scrubbed text instead of the JSON report
  --ci         add a low/high interval on the score (needs at least four sentences)
  --           end option parsing, so FILE may begin with a dash
  -h, --help   print this usage message and exit 0
With no FILE, text is read from standard input as UTF-8.
If several files are given, only the first one is scanned.
"""

# ------------------------------------------------------------------ catalogue

LABELS = {
    1: 'AI vocabulary',
    2: 'model-dialect vocabulary',
    3: 'promotional language',
    4: 'hyphenated word-pair overuse',
    5: 'simple-yet cliche',
    6: 'stacked adjective chains',
    7: 'rule of three overuse',
    8: 'synonym cycling',
    9: 'generic character naming',
    10: 'significance inflation',
    11: 'notability name-dropping',
    12: 'vague attributions',
    13: 'article title used as proper noun',
    14: 'conservation ecosystem padding',
    15: 'false range',
    16: 'superficial -ing tail clause',
    17: 'tailing negation',
    18: 'not X, just Y framing',
    19: 'filler phrases',
    20: 'empty pivot phrase',
    21: 'outcome speculation tail',
    22: 'persuasive authority trope',
    23: 'editorial interjection',
    24: 'self-thoroughness phrase',
    25: 'question-answer rhetorical pattern',
    26: 'concrete evidence defense phrase',
    27: 'compulsive intro hook',
    28: 'meandering intro',
    29: 'prompt echo',
    30: 'diff-anchored writing',
    31: 'signposting and announcements',
    32: 'cataloguing lead-in',
    33: 'inline-header vertical list',
    34: 'mid-essay bullet injection',
    35: 'fragmented header',
    36: 'formulaic challenges section',
    37: 'transition cluster',
    38: 'compulsive conclusion phrase',
    39: 'generic positive conclusion',
    40: 'sentence-length monotony',
    41: 'mechanical sentence-length alternation',
    42: 'opener repetition',
    43: 'avoidance of fragments and run-ons',
    44: 'uniform paragraph length',
    45: 'identical paragraph structure',
    46: 'semicolon and parenthesis underuse',
    47: 'chatbot artifact',
    48: 'sycophantic tone',
    49: 'helpful-assistant register',
    50: 'knowledge-cutoff disclaimer',
    51: 'copula avoidance',
    52: 'passive voice and subjectless fragments',
    53: 'two-way passive-voice drift',
    54: 'hedge stacking',
    55: 'contraction absence',
    56: 'boldface overuse',
    57: 'emoji',
    58: 'em-dash overuse',
    59: 'title case in headings',
    60: 'curly quotation marks',
    61: 'hyphen for en dash in year range',
    62: 'invisible or zero-width characters',
    63: 'placeholder text',
    64: 'chat reference-markup leak',
    65: 'AI tracking parameter',
    66: 'mixed-script homoglyphs',
    67: 'non-standard spaces',
    68: 'trailing or stray whitespace',
    69: 'stock marketing phrase',
    70: 'decorative horizontal rules',
    71: 'degenerate repetition',
}
PARALLEL_LABEL = 'negative parallelism'
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}  # reported, weight zero
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM = {40, 44}  # score-moving rhythm kinds (41 and 55 are advice)
SHORT_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}
MODEL_DIALECT_MIN_HITS = 2  # the model-dialect family needs two hits (PRD FP-04)


def V(word):
    """A listed verb, adjective or noun with its usual inflections."""
    base = word[:-1] if word.endswith('e') else word
    return r'\b' + re.escape(base) + r'(?:e|es|ed|ing|s|d)?\b'


def W(word):
    return r'\b' + re.escape(word) + r'\b'


def ALT(words):
    return r'\b(?:' + '|'.join(re.escape(x) for x in words) + r')\b'


# Regex families. Each entry lists patterns; all are case-insensitive and multi-line,
# except inline (?-i:...) scopes that keep a capital letter significant.
REGEX = {
    1: [
        V('delve'), r'\btapestr(?:y|ies)\b', V('pivotal'), V('vibrant'), V('meticulous'),
        V('testament'), V('underscore'), V('intricate'), r'\bintricacies\b', V('interplay'),
        V('garner'), V('bolster'), V('foster'), V('showcase'), V('emphasize'), V('enduring'),
        V('enhance'), V('leverage'), V('utilize'), V('facilitate'), V('encompass'), V('harness'),
        V('holistic'), V('paradigm'), V('transformative'), V('unprecedented'), V('myriad'),
        V('plethora'), V('robust'), V('seamless'), V('navigate'), V('embark'), V('craft'),
        V('landscape'), V('journey'), V('realm'), V('multifaceted'), V('elevate'), V('empower'),
        V('unlock'), V('crucial'), r'\badditionally\b', r'\balign(?:s|ed|ing)? with\b',
        r'\bcapture the (?:essence|spirit|imagination|heart|magic)\b',
    ],
    2: [  # needs two hits in total (see MODEL_DIALECT_MIN_HITS)
        W('genuinely'), W('fascinating'), W('nuanced'), W('thoughtfully'), W('refreshingly'),
        W('strikingly'), W('compellingly'), r'\bquietly (?:powerful|profound|radical)\b',
        r'\bdeeply (?:human|personal|felt|unsettling)\b', r'\bresonates deeply\b',
        r'\bgame[- ]?chang(?:er|ers|ing)\b', V('supercharge'), V('skyrocket'),
        V('turbocharge'), V('revolutionize'), r'\bdouble down on\b', r'\bdive deep(?:er)? into\b',
        r'\bunlock (?:the )?(?:power|potential|value)\b', r'\btake (?:it|something|\w+) to the next level\b',
    ],
    3: [
        W('nestled'), W('breathtaking'), r'\bmust-visit\b', W('stunning'), W('picturesque'),
        W('charming'), W('idyllic'), r'\bvibrant community\b', r'\brich cultural heritage\b',
        r'\bin the heart of\b', r'\bworld-class\b', r'\btop-tier\b', W('unparalleled'),
        W('premier'), r'\b(?:a|the|an) leading\b', r'\besteemed organi[sz]ation\b',
        r'\bvaluable asset\b', r'\bpassion for excellence\b', r'\bproven track record\b',
        r'\bresults-oriented\b', r'\bwealth of experience\b', r'\bdynamic team\b',
        r'\bfast-paced environment\b', r'\bdeeply passionate\b', r'\bperfectly situated\b',
        r'\b(?:close|tight)-knit team\b', r'\bI am excited to (?:apply|bring)\b',
        r'\buniquely positioned to\b',
    ],
    4: [ALT([
        'cutting-edge', 'best-in-class', 'next-generation', 'results-driven', 'customer-centric',
        'user-centric', 'value-added', 'top-notch', 'state-of-the-art', 'high-performing',
        'forward-thinking', 'data-driven', 'end-to-end', 'game-changing',
    ])],
    5: [r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'],
    10: [
        r'\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
        r'\b(?:underscores?|underscoring|underscored|highlights?|highlighting|highlighted) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
        r'\breflects? a broader (?:trend|shift|pattern)\b',
        r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
        r'\bsymbolizes\b', r'\bsets the stage for\b', r'\bleft an indelible mark\b',
        r'\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b',
        r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize)\b',
    ],
    11: [
        r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) (?-i:[A-Z])[\w&\'.-]*(?:,\s*|\s+and\s+)(?-i:[A-Z])[\w&\'.-]*',
        r'\b\d[\d,.]*\s*[kKmM]?\+?\s+followers\b',
        r'\bstrong (?:online|digital|social[- ]media) presence\b',
        r'\bactive (?:online|digital|social[- ]media) presence\b',
        r'\bwidely covered\b', r'\bindependent coverage\b',
    ],
    12: [
        r'\bexperts (?:argue|believe|say|claim|note|suggest)\b',
        r'\bindustry (?:reports|observers|analysts)\b',
        r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b',
        r'\bresearchers have found\b', r'\bstudies suggest\b', r'\bit is widely believed\b',
    ],
    13: [
        r'\b(?-i:The) (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:[\w\'&:-]+ ){1,8}?(?:is|are) (?:a|an|the)\b',
    ],
    14: [
        r'\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
        r'\bconservation efforts are (?:underway|ongoing|in place)\b',
        r'\bserves? as an indicator species\b', r'\bcontributes? to biodiversity\b',
    ],
    15: [
        r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom (?:the )?humble\b[^.!?\n]{0,200}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b',
    ],
    16: [
        r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b',
    ],
    17: [  # tailing-negation form (score-moving); parallelism form is PARALLEL below
        r'[^,.!?\n]{3,60},\s+no (?:wasted motion|guessing|waste|hassle|fluff|stress|jargon)\b',
    ],
    18: [
        r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
        r'\b(?:not|isn[\'’]t|aren[\'’]t|wasn[\'’]t|weren[\'’]t) (?:just|merely) (?:an?|the )?\w+(?:,|\s*[-–—])\s*(?:it[\'’]s|it is|it was|they[\'’]re|they are|they were|that[\'’]s|but)\b',
    ],
    19: [ALT([
        'in order to', 'due to the fact that', 'at this point in time', 'in the event that',
        'has the ability to', 'it is important to note that', 'it should be mentioned that',
        'needless to say',
    ])],
    20: [
        r'\bit[\'’]s worth (?:noting|mentioning) that\b', r'\bit bears (?:noting|mentioning) that\b',
        r'\bone thing to (?:consider|keep in mind) is\b', r'\bit is interesting to note that\b',
        r'\ba key consideration is\b', r'\ba point to highlight is\b',
    ],
    21: [
        r',\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward)\b',
    ],
    22: [
        ALT(["here's the thing", 'make no mistake', 'the truth is', "let's be honest",
             'the simple fact is', 'at its core', 'what really matters', 'more than anything',
             'at the end of the day', 'the bottom line is', 'in reality', 'the real question is',
             'the heart of the matter', 'the deeper issue', 'when you get down to it',
             'when all is said and done']),
        r'\bfundamentally,',
    ],
    23: [
        r'\bit(?:[\'’]s| is) important to (?:remember|note|understand|recognize)\b',
        r'\bone must note that\b', r'\bit is worth pointing out\b',
        r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b',
    ],
    24: [
        r'\bthis (?:comprehensive (?:guide|overview|analysis)|in-depth (?:analysis|look|examination)|complete (?:guide|overview))\b',
        r'\ba thorough examination of\b', r'\beverything you need to know about\b',
    ],
    25: [
        r'\b(?:Is|Are|Can|Could|Would|Will|Should|Do|Does|Did|Have|Has|Was|Were|May|Might)\b[^?.!\n]{0,60}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]',
    ],
    26: [
        r'\bwithout concrete (?:evidence|proof)\b', r'\bdo you have concrete (?:evidence|proof)\b',
        r'\bI (?:would )?need concrete (?:evidence|examples|proof) to\b',
        r'\babsent concrete (?:proof|evidence)\b', r'\bprovide concrete (?:evidence|proof)\b',
    ],
    27: [
        r'\bin today[\'’]s (?:\w+\s+){0,2}(?:world|landscape|environment|market)\b',
        r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
        r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b',
        r'\b(?:great|exciting|big) news\s*[!:]', r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
        r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b',
    ],
    30: [
        r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
        r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
        r'\bpreviously\b[^.!?\n]{0,80}\bnow\b',
        r'\b(?:wasn[\'’]t|weren[\'’]t) there before\b',
        r'\bwe(?:[\'’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
    ],
    31: [
        r'\blet[\'’]s (?:dive|delve|explore)\b', r'\blet[\'’]s break (?:this|it) down\b',
        r'\bhere[\'’]s what you need to know\b', r'\bwithout further ado\b',
        r'\bnow let[\'’]s look at\b', r'\bbuckle up\b', r'\bstay with me\b',
        r'\bready to dive in\b',
    ],
    32: [
        r'\b(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+',
        r'^\s*These (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b',
    ],
    36: [
        r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
        r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
        r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
        r'\bfaces (?:several|many|numerous) challenges\b',
    ],
    38: [
        r'^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b',
    ],
    39: [
        r'\bthe future looks bright\b', r'\bexciting times lie ahead\b',
        r'\bjourney toward excellence\b', r'\bstep in the right direction\b',
        r'\b(?:outlook|future)(?: for [\w ]{1,40})? (?:is|looks|remains) bright\b',
        r'\bwell[- ]positioned (?:for (?:whatever comes next|the future|the road ahead))\b',
    ],
    47: [
        r'\bI hope this helps\b', r'\bCertainly!', r'\bOf course!', r'\blet me know if you\b',
        r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help[.!]',
        r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
        r'\bhere are (?:a few |some |two |three )?(?:options|drafts|versions|variations)\b',
        r'\bhere[\'’]s (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
        r'\bhere (?:is|[\'’]s) a draft\b', r'\bdepending on the (?:vibe|tone|style)\b',
        r'\bI hope (?:this email )?finds you well\b',
        r'\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
        r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
        r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked), here\b',
        r'\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b',
    ],
    48: [
        r'\byou(?:[\'’]re| are) absolutely right\b',
        r'\b(?:great|excellent|good|wonderful|fantastic|brilliant|insightful|thoughtful) (?:question|point)[!.,]',
        r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question[!.,]',
        r'\bthat[\'’]s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)[!.,]',
    ],
    50: [
        r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
        r'\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b',
        r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
        r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b',
    ],
    51: [
        r'\b(?:serves|stands|functions|acts) as\b', r'\brepresents (?:a|an|the)\b',
        r'\bmarks (?:a|an|the)\b', r'\bboasts\b',
        r'\bfeatures (?:a|an|the|\d+|several|many|numerous)\b', r'\boffers a\b', r'\brefers to\b',
    ],
    57: [r'[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B50\u2B55]'],
    63: [
        r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
        r'\[(?:company|client|person|place|source|name)(?:\s+name)?\](?![(\[])',
        r'(?-i:\[[A-Z][A-Z _-]{2,}\])(?![(\[])',
        r'\{\{[^}\n]*\}\}',
        r'(?<![A-Za-z])x{3,}(?![A-Za-z])',
        r'\blorem ipsum\b',
    ],
    64: [
        r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\w*',
        r'\bnavlist\w*', r'\u3010\d+\u2020[^\u3011\n]*\u3011',
    ],
    65: [
        r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![\w-]|\.\w)',
    ],
    69: [
        r'\bunlock(?:ing)? (?:your |the |its |their )?full potential\b',
        r'\bnavigat(?:e|ing) the complexities\b', r'\ba testament to the (?:power|importance) of\b',
        r'\bstay(?:ing)? ahead of the curve\b', r'\bturn(?:ing)? challenges into opportunities\b',
        r'\bharness(?:ing)? the power of\b', r'\bpaving the way for\b',
        r'\bsay(?:ing)? goodbye to\b', r'\bimagin(?:e|ing) a world where\b',
    ],
}
REGEX_C = {num: [re.compile(pat, re.I | re.M) for pat in pats] for num, pats in REGEX.items()}
PARALLEL = [
    r'\bit[\'’]s not (?:just|merely) (?:about|an?)\b',
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn[\'’]t just\b[^.,!?\n]{0,40}?\bit\b',
]
SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SYNONYM_RX = [[(m, re.compile(r'\b' + re.escape(m).replace(r'\ ', r'\s+') + r'(?:s|es)?\b', re.I))
               for m in cluster] for cluster in SYNONYM_CLUSTERS]
ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
ADJ_STOCK = {'vibrant', 'robust', 'seamless', 'innovative', 'comprehensive', 'dynamic', 'elegant',
             'powerful', 'bold', 'intuitive', 'cutting-edge', 'modern', 'smart', 'strong', 'fresh',
             'rich', 'deep', 'clear', 'simple', 'great', 'best', 'top', 'premier'}
CHAIN_RX = re.compile(r"\b[A-Za-z][\w'-]*(?:(?:,\s*|,?\s+and\s+|,?\s+or\s+)[A-Za-z][\w'-]*){3,}")
TRANSITION_RX = re.compile(r'(?:^|(?<=[.!?])\s+)((?-i:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably))\b', re.M)
QA_IMPERATIVE_RX = re.compile(r'^(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b', re.I)
BOLD_RX = re.compile(r'\*\*[^*\n]+?\*\*')
BOLD_HEADER_RX = re.compile(r'^\s*(?:(?:[-*+]|\d+[.)])\s+)?\*\*[^*\n]{1,80}?:\*\*|^\s*(?:(?:[-*+]|\d+[.)])\s+)?\*\*[^*\n]{1,80}\*\*:', re.M)
HR_RX = re.compile(r'^\s{0,3}([-*_])(?:\s*\1){2,}\s*$', re.M)
HEDGE_RX = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b')
FIRST_PERSON_RX = re.compile(r'\b(?:I|me|my|we|our|us)\b', re.I)
FULL_FORMS_RX = re.compile(r'\b(?:do not|does not|did not|is not|are not|was not|were not|have not|has not|will not|would not|can not|cannot|it is|I am|I have|I will|we are|we have|we will|they are|that is|there is|let us)\b', re.I)
CONTRACTED_RX = re.compile(r"\b\w+n['’]t\b|\b(?:I['’]m|I['’]ve|I['’]ll|I['’]d|we['’]re|we['’]ve|we['’]ll|it['’]s|that['’]s|there['’]s|let['’]s|they['’]re)\b", re.I)
WORD_RX = re.compile(r"(?:[^\W_]|['’\-])+")
SENT_SPLIT_RX = re.compile(r'(?<=[.!?])\s+')
BULLET_RX = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
HEADING_RX = re.compile(r'^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$')
HEADING_ANY_RX = re.compile(r'^\s{0,3}#{1,6}\s', re.M)
SMALL_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at',
               'to', 'by', 'up', 'as', 'with', 'from', 'into', 'onto', 'off', 'per', 'via', 'vs', 'over'}

# ------------------------------------------------------------------ character layer

LOOKALIKE = {
    '\u0430': 'a', '\u0441': 'c', '\u0501': 'd', '\u0435': 'e', '\u04bb': 'h', '\u0456': 'i',
    '\u0458': 'j', '\u043e': 'o', '\u0440': 'p', '\u0455': 's', '\u051d': 'w', '\u0445': 'x',
    '\u0443': 'y', '\u03bd': 'v',
    '\u0410': 'A', '\u0412': 'B', '\u0421': 'C', '\u0415': 'E', '\u041d': 'H', '\u0406': 'I',
    '\u0408': 'J', '\u041a': 'K', '\u041c': 'M', '\u041e': 'O', '\u0420': 'P', '\u0405': 'S',
    '\u0422': 'T', '\u0425': 'X',
    '\u0391': 'A', '\u0392': 'B', '\u0395': 'E', '\u0396': 'Z', '\u0397': 'H', '\u0399': 'I',
    '\u039a': 'K', '\u039c': 'M', '\u039d': 'N', '\u039f': 'O', '\u03a1': 'P', '\u03a4': 'T',
    '\u03a5': 'Y', '\u03a7': 'X', '\u03bf': 'o', '\u03c5': 'u',
    '\u0585': 'o', '\u057d': 'u', '\u0578': 'n',
}
NBSP = '\u00a0'
NNBSP = '\u202f'
LINE_SEP_CHARS = {'\u2028', '\u2029'}
NBSP_FOLLOW = set(':;!?\u00bb\u203a%\u20ac')
NBSP_PREV = set('\u00ab\u2039')
TAG_RUN_RX = re.compile(r'[\U000e0000-\U000e0fff]+')
CJK_NOSPACE_RX = re.compile(r'[\u3040-\u30ff\u31f0-\u31ff\uff66-\uff9f\u4e00-\u9fff\u3400-\u4dbf\U00020000-\U0002fa1f\uf900-\ufaff\u0e00-\u0e7f\u1000-\u109f\u1780-\u17ff]')
JOINING_RX = re.compile(r'[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff\u0900-\u0dff\u1000-\u109f\u1780-\u17ff]')
RTL_RX = re.compile(r'[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')
SYMBOL_RX = re.compile(r'[\U0001f000-\U0001faff\u2600-\u27bf]')
MONGOL_RX = re.compile(r'[\u1800-\u18af]')
KHMER_RX = re.compile(r'[\u1780-\u17ff]')
IDEO_RX = re.compile(r'[\u4e00-\u9fff\u3400-\u4dbf\U00020000-\U0002ffff\uf900-\ufaff]')
OTHER_IGNORABLE = {0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x180E}
BIDI_CODES = {0x200E, 0x200F, 0x061C} | set(range(0x202A, 0x202F)) | set(range(0x2066, 0x206A))


def _is_char(rx, ch):
    return bool(ch) and rx.match(ch) is not None


def _is_symbol(ch):
    return bool(ch) and (_is_char(SYMBOL_RX, ch) or unicodedata.category(ch) in ('So', 'Sk'))


def _invisible_removable(text, doc_rtl):
    """Per-index flags: True where the character is invisible and cleanup removes it."""
    n = len(text)
    flags = [False] * n
    tag_keep = {}
    for m in TAG_RUN_RX.finditer(text):
        start = m.start()
        before = text[start - 1] if start > 0 else ''
        keep = bool(before) and (ord(before) >= 0x1F000 or _is_symbol(before))
        if keep:
            for k in range(start, m.end()):
                tag_keep[k] = True
    for i in range(n):
        c = text[i]
        o = ord(c)
        if c in '\t\n\r':
            continue
        if 0xE0000 <= o <= 0xE0FFF:
            flags[i] = i not in tag_keep
            continue
        if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            keep = _is_symbol(prev) or _is_char(IDEO_RX, prev) or nxt == '\u20e3'
            flags[i] = not keep
            continue
        if 0x180B <= o <= 0x180D or o == 0x180F:
            prev = text[i - 1] if i > 0 else ''
            flags[i] = not _is_char(MONGOL_RX, prev)
            continue
        if o in (0x17B4, 0x17B5):
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            flags[i] = not (_is_char(KHMER_RX, prev) or _is_char(KHMER_RX, nxt))
            continue
        if o == 0x00AD:
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            flags[i] = not (prev.isalpha() and nxt.isalpha())
            continue
        if o in (0x200C, 0x200D):
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            keep = (_is_char(JOINING_RX, prev) or _is_char(JOINING_RX, nxt)
                    or _is_symbol(prev) or _is_symbol(nxt))
            flags[i] = not keep
            continue
        if o == 0x200B:
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            flags[i] = not (_is_char(CJK_NOSPACE_RX, prev) or _is_char(CJK_NOSPACE_RX, nxt))
            continue
        if o in BIDI_CODES:
            flags[i] = not doc_rtl
            continue
        cat = unicodedata.category(c)
        if cat in ('Cc', 'Cf') or o in OTHER_IGNORABLE:
            flags[i] = True
    return flags


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in NBSP_FOLLOW:
        return True
    if prev and prev in NBSP_PREV:
        return True
    return False


def homoglyph_token(token):
    """(is_homoglyph, folded) for one whitespace-delimited token."""
    if '://' in token or token.lower().startswith('www.'):
        return False, token
    has_ascii = has_look = other = False
    for ch in token:
        if ch.isalpha():
            if ch.isascii():
                has_ascii = True
            elif ch in LOOKALIKE:
                has_look = True
            else:
                other = True
    if has_look and has_ascii and not other:
        return True, ''.join(LOOKALIKE.get(ch, ch) for ch in token)
    return False, token


def scrub(text):
    """Character layer over text (line endings already normalized).

    Returns (scrubbed_text, invisible_count, nonstandard_space_count, homoglyph_count, homoglyph_samples).
    The scrubbed text has invisible characters removed, non-standard spaces normalized, and
    mixed-script lookalikes folded. Trimming is separate (trim_text)."""
    doc_rtl = RTL_RX.search(text) is not None
    flags = _invisible_removable(text, doc_rtl)
    inv = sum(1 for f in flags if f)
    out = []
    nsp = 0
    for i, c in enumerate(text):
        if flags[i]:
            continue
        if c in LINE_SEP_CHARS:
            out.append('\n')
            continue
        if c != ' ' and unicodedata.category(c) == 'Zs':
            if c in (NBSP, NNBSP) and _nbsp_kept(text, i):
                out.append(c)
            else:
                out.append(' ')
                nsp += 1
            continue
        out.append(c)
    stage = ''.join(out)
    counts = {'hg': 0}
    samples = []

    def fold(m):
        is_h, folded = homoglyph_token(m.group(0))
        if is_h:
            counts['hg'] += 1
            if len(samples) < 3:
                samples.append(m.group(0))
            return folded
        return m.group(0)

    folded = re.sub(r'\S+', fold, stage)
    return folded, inv, nsp, counts['hg'], samples


def trim_text(s):
    """Trailing spaces and tabs on every line, leading and trailing blank space, one final newline kept."""
    ended_nl = s.endswith('\n')
    body = '\n'.join(ln.rstrip(' \t') for ln in s.split('\n'))
    body = body.lstrip(' \t\n\r\f\v').rstrip()
    if ended_nl and body:
        body += '\n'
    return body


def stray_count(raw):
    """Finding 68 on the raw window: lines ending in space or tab, two or more final newlines,
    and whitespace before the first character."""
    n = 0
    for ln in raw.split('\n'):
        if ln[-1:] in (' ', '\t'):
            n += 1
    if re.search(r'\n[ \t]*\n\s*\Z', raw):
        n += 1
    if raw[:1].isspace():
        n += 1
    return n


# ------------------------------------------------------------------ extraction


def decode_bytes(b):
    if b.startswith(b'\xef\xbb\xbf'):
        return b[3:].decode('utf-8', 'replace')
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        return b.decode('utf-16', 'replace')
    return b.decode('utf-8', 'replace')


def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _clean_lines(text):
    return '\n'.join(ln for ln in (x.strip() for x in text.split('\n')) if ln)


def docx_text(z):
    root = ET.fromstring(z.read('word/document.xml'))
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for el in p.iter():
            t = _local(el.tag)
            if t == 't' and el.text:
                parts.append(el.text)
            elif t == 'tab':
                parts.append('\t')
            elif t in ('br', 'cr'):
                parts.append('\n')
        paras.append(''.join(parts))
    return _clean_lines('\n'.join(paras))


def pptx_text(z):
    names = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    out = []
    for n in names:
        root = ET.fromstring(z.read(n))
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            parts = []
            for el in p.iter():
                t = _local(el.tag)
                if t == 't' and el.text:
                    parts.append(el.text)
                elif t == 'br':
                    parts.append('\n')
            out.append(''.join(parts))
    return _clean_lines('\n'.join(out))


def xlsx_text(z):
    names = z.namelist()
    shared = []
    if 'xl/sharedStrings.xml' in names:
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root:
            if _local(si.tag) == 'si':
                shared.append(''.join(t.text or '' for t in si.iter() if _local(t.tag) == 't'))
    sheet_paths = []
    try:
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rels = {}
        if 'xl/_rels/workbook.xml.rels' in names:
            for rel in ET.fromstring(z.read('xl/_rels/workbook.xml.rels')):
                if _local(rel.tag) == 'Relationship':
                    rels[rel.get('Id')] = rel.get('Target', '')
        for sh in wb.iter():
            if _local(sh.tag) != 'sheet':
                continue
            rid = next((v for k, v in sh.attrib.items() if k.endswith('}id') or k == 'r:id'), None)
            target = rels.get(rid, '').lstrip('/')
            if target:
                if not target.startswith('xl/'):
                    target = 'xl/' + target
                sheet_paths.append(target)
    except (KeyError, ET.ParseError):
        sheet_paths = []
    if not sheet_paths:
        sheet_paths = sorted((n for n in names if re.match(r'xl/worksheets/[^/]+\.xml$', n)),
                             key=lambda n: [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', n)])
    out = []
    for sp in sheet_paths:
        if sp not in names:
            continue
        root = ET.fromstring(z.read(sp))
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            txt = ''
            if t == 's':
                v = next((x for x in c if _local(x.tag) == 'v'), None)
                raw = (v.text or '').strip() if v is not None else ''
                if re.fullmatch(r'\d+', raw) and int(raw) < len(shared):
                    txt = shared[int(raw)]
            elif t == 'inlineStr':
                txt = ''.join(x.text or '' for x in c.iter() if _local(x.tag) == 't')
            elif t == 'str':
                v = next((x for x in c if _local(x.tag) == 'v'), None)
                txt = (v.text or '') if v is not None else ''
            if txt.strip():
                out.append(txt)
    return _clean_lines('\n'.join(out))


def odf_text(root):
    lines = []
    buf = []
    count_attr = '{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c'

    def flush():
        lines.append(''.join(buf))
        buf.clear()

    def walk(el):
        t = _local(el.tag)
        if t in ('p', 'h'):
            flush()
            if el.text:
                buf.append(el.text)
            for ch in el:
                walk(ch)
                if ch.tail:
                    buf.append(ch.tail)
            flush()
            return
        if t == 's':
            try:
                n = int(el.get(count_attr, '1'))
            except ValueError:
                n = 1
            buf.append(' ' * max(0, n))
        elif t == 'tab':
            buf.append('\t')
        elif t == 'line-break':
            buf.append('\n')
        else:
            if el.text:
                buf.append(el.text)
            for ch in el:
                walk(ch)
                if ch.tail:
                    buf.append(ch.tail)

    for ch in root:
        walk(ch)
    flush()
    return _clean_lines('\n'.join(lines))


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'blockquote',
             'section', 'article', 'header', 'footer', 'pre', 'dt', 'dd', 'figcaption', 'ul', 'ol', 'table'}
    SKIP = {'script', 'style', 'head', 'nav', 'title'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip > 0:
            self.skip -= 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if self.skip == 0:
            self.parts.append(data)


def html_to_text(raw):
    p = _HTMLText()
    try:
        p.feed(raw)
        p.close()
    except Exception:
        pass
    return _clean_lines(re.sub(r'[ \t\r\f\v]+', ' ', ''.join(p.parts)))


def epub_text(z):
    names = z.namelist()
    docs = []
    try:
        container = ET.fromstring(z.read('META-INF/container.xml'))
        opf_path = None
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
        if opf_path is None:
            raise KeyError('no rootfile')
        opf = ET.fromstring(z.read(opf_path))
        base = opf_path.rsplit('/', 1)[0] + '/' if '/' in opf_path else ''
        manifest = {}
        for el in opf.iter():
            if _local(el.tag) == 'item':
                manifest[el.get('id')] = (el.get('href', ''), el.get('properties', '') or '')
        for el in opf.iter():
            if _local(el.tag) == 'itemref':
                href, props = manifest.get(el.get('idref'), ('', ''))
                if href and 'nav' not in props.split():
                    docs.append(base + href)
    except (KeyError, ET.ParseError):
        docs = []
    if not docs:
        docs = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')))
    chapters = []
    for d in docs:
        if d not in names:
            continue
        txt = html_to_text(decode_bytes(z.read(d)))
        if txt:
            chapters.append(txt)
    return _clean_lines('\n'.join(chapters))


def notebook_text(raw):
    try:
        nb = json.loads(raw)
    except (ValueError, TypeError):
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    parts = []
    for cell in nb['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            return ''
        s = s.strip()
        if s:
            parts.append(s)
    return _clean_lines('\n'.join(parts))


class ReadError(Exception):
    pass


def extract_from_bytes(data, ext):
    """Extracted prose for a file of extension ext. Raises ReadError when a zip-type file is not a zip."""
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise ReadError('not a readable zip archive')
        try:
            with z:
                if ext in ('.docx', '.docm'):
                    return docx_text(z)
                if ext in ('.pptx', '.pptm'):
                    return pptx_text(z)
                if ext in ('.xlsx', '.xlsm'):
                    return xlsx_text(z)
                if ext in ('.odt', '.odp', '.ods'):
                    return odf_text(ET.fromstring(z.read('content.xml')))
                if ext == '.epub':
                    return epub_text(z)
        except (KeyError, ET.ParseError, ValueError, zipfile.BadZipFile, RuntimeError, OSError):
            return ''
    if ext in NB_EXT:
        return notebook_text(decode_bytes(data))
    if ext in BINARY_EXT:
        return ''
    return decode_bytes(data)


def load_input(path):
    """Extracted text for path (or standard input when path is None). Raises ReadError when unreadable."""
    if path is None:
        return decode_bytes(sys.stdin.buffer.read())
    if not os.path.isfile(path):
        raise ReadError('cannot read input: %s: not a readable file' % path)
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise ReadError('cannot read input: %s: %s' % (path, exc.strerror or exc.__class__.__name__))
    ext = os.path.splitext(path)[1].lower()
    try:
        return extract_from_bytes(data, ext)
    except ReadError as exc:
        raise ReadError('cannot read input: %s: %s' % (path, exc))


# ------------------------------------------------------------------ masking


def mask_excluded(a):
    """Blank content that produces no findings: YAML front matter, fenced code, runs of two or more
    blockquote lines, markdown table rows, badge lines, and inline code spans. Lines are kept."""
    lines = a.split('\n')
    n = len(lines)
    blank = [False] * n
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(0, j + 1):
                    blank[k] = True
                break
    fence = None
    for i, ln in enumerate(lines):
        if fence is None:
            m = re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$', ln)
            if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
                fence = (m.group(1)[0], len(m.group(1)))
                blank[i] = True
        else:
            blank[i] = True
            m = re.match(r'^ {0,3}(`{3,}|~{3,})\s*$', ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
    quote = [bool(re.match(r'^\s{0,3}>', ln)) for ln in lines]
    i = 0
    while i < n:
        if quote[i]:
            j = i
            while j < n and quote[j]:
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    blank[k] = True
            i = j
        else:
            i += 1
    badge_part = re.compile(r'\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)|!\[[^\]]*\]\([^)]*\)')
    sep_rx = re.compile(r'^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*$')
    for i, ln in enumerate(lines):
        st = ln.strip()
        if (st.startswith('|') and st.count('|') >= 2) or (sep_rx.match(ln) and '|' in ln):
            blank[i] = True
        elif '![' in ln and badge_part.sub('', ln).strip() == '':
            blank[i] = True
    code_rx = re.compile(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)')
    out = []
    for i, ln in enumerate(lines):
        if blank[i]:
            out.append('')
        else:
            out.append(code_rx.sub(lambda m: ' ' * len(m.group(0)), ln))
    return '\n'.join(out)


# ------------------------------------------------------------------ analysis


def words_of(text):
    return [w for w in WORD_RX.findall(text) if any(c.isalnum() for c in w)]


def sentences_of(p):
    out = []
    for line in p.split('\n'):
        for s in SENT_SPLIT_RX.split(line.strip()):
            s = s.strip()
            if s and words_of(s):
                out.append(s)
    return out


def paragraphs_of(p):
    return [x.strip() for x in re.split(r'\n\s*\n', p) if x.strip()]


def cv(vals):
    if not vals:
        return None
    mean = sum(vals) / len(vals)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / mean


def clip(text, limit=80):
    return re.sub(r'\s+', ' ', text).strip()[:limit]


def collect_hits(p, sents, paras):
    """Return ({catalogue number: (hit_count, samples)}, (parallel_count, samples)) for the masked prose."""
    hits = {}

    def put(num, cnt, samples):
        if cnt > 0:
            pc, ps = hits.get(num, (0, []))
            hits[num] = (pc + cnt, (ps + list(samples))[:3])

    for num, rxs in REGEX_C.items():
        cnt = 0
        samples = []
        for rx in rxs:
            for m in rx.finditer(p):
                cnt += 1
                if len(samples) < 3:
                    samples.append(clip(m.group(0)))
        if num == 2 and cnt < MODEL_DIALECT_MIN_HITS:
            continue
        put(num, cnt, samples)

    # 3: three or more sentences opening with a marketing imperative
    imp = [s for s in sents if QA_IMPERATIVE_RX.match(s)]
    if len(imp) >= 3:
        put(3, len(imp), [clip(s) for s in imp[:3]])

    # 6: stacked adjective chains (four or more comma-joined words, ending in a noun)
    chains = []
    for m in CHAIN_RX.finditer(p):
        toks = [t.strip() for t in re.split(r',\s*|\s+and\s+|\s+or\s+', m.group(0)) if t.strip()]
        if len(toks) < 4:
            continue
        adj = [t for t in toks if ADJ_SUFFIX.search(t) or t.lower() in ADJ_STOCK]
        last = toks[-1]
        if adj and not (ADJ_SUFFIX.search(last) or last.lower() in ADJ_STOCK):
            chains.append(clip(m.group(0)))
    put(6, len(chains), chains[:3])

    # 8: synonym cycling (three or more members of one cluster, each used)
    cyc = 0
    cyc_samples = []
    for cluster in SYNONYM_RX:
        present = [(m, rx) for m, rx in cluster if rx.search(p)]
        if len(present) >= 3:
            for _, rx in present:
                for mm in rx.finditer(p):
                    cyc += 1
                    if len(cyc_samples) < 3:
                        cyc_samples.append(clip(mm.group(0)))
    put(8, cyc, cyc_samples)

    # 33: inline-header vertical lists
    bold_heads = [clip(m.group(0)) for m in BOLD_HEADER_RX.finditer(p)]
    put(33, len(bold_heads), bold_heads[:3])

    # 34: mid-essay bullet injection (no heading, a list-only paragraph, two or more prose paragraphs)
    if not HEADING_ANY_RX.search(p):
        list_paras = 0
        prose_paras = 0
        for para in paras:
            plines = [ln for ln in para.split('\n') if ln.strip()]
            if plines and all(BULLET_RX.match(ln) for ln in plines):
                list_paras += 1
            else:
                prose_paras += 1
        if list_paras >= 1 and prose_paras >= 2:
            put(34, list_paras, ['bulleted paragraph among prose'])

    # 35: fragmented headers
    lines = p.split('\n')
    frag = []
    for i, ln in enumerate(lines):
        hm = HEADING_RX.match(ln)
        if not hm:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(#|[-*+>|]|\d+[.)]\s)', nxt) or len(nxt.split()) > 5:
            continue
        hw = {w.lower().strip('.,:;!?') for w in hm.group(1).split()}
        nw = {w.lower().strip('.,:;!?') for w in nxt.split()}
        if hw & nw:
            frag.append(clip(ln + ' / ' + nxt))
    put(35, len(frag), frag[:3])

    # 37: transition clusters (two or more sentence-opening transitions in one paragraph)
    tc = 0
    tc_samples = []
    for para in paras:
        ms = list(TRANSITION_RX.finditer(para))
        if len(ms) >= 2:
            tc += len(ms)
            tc_samples.append(clip(ms[0].group(1)))
    put(37, tc, tc_samples[:3])

    # 40: sentence-length monotony (rhythm, score-moving)
    sl = [len(words_of(s)) for s in sents]
    if len(sl) >= 3:
        c = cv(sl)
        if c is not None and c < 0.35:
            put(40, 1, ['%d sentences of similar length' % len(sl)])

    # 41: mechanical sentence-length alternation (advice)
    if len(sl) >= 6:
        mean = sum(sl) / len(sl)
        runs = 0
        i = 0
        while i < len(sl) - 1:
            j = i
            while j + 1 < len(sl):
                d1 = sl[j + 1] - sl[j]
                if abs(d1) < 0.3 * mean or d1 == 0:
                    break
                if j > i and (sl[j] - sl[j - 1]) * d1 >= 0:
                    break
                j += 1
            if j - i + 1 >= 6:
                runs += 1
                i = j + 1
            else:
                i += 1
        put(41, runs, ['alternating sentence lengths'])

    # 42: opener repetition (advice): a paragraph of three or more sentences, three opening alike
    rep = 0
    for para in paras:
        ss = sentences_of(para)
        if len(ss) < 3:
            continue
        opens = Counter(' '.join(s.lower().split()[:2]) for s in ss if len(s.split()) >= 2)
        if opens and max(opens.values()) >= 3:
            rep += 1
    put(42, rep, ['repeated sentence openers'])

    # 44: uniform paragraph length (rhythm, score-moving)
    pl = [x for x in (len(words_of(x)) for x in paras) if x > 0]
    if len(pl) >= 4:
        c = cv(pl)
        if c is not None and c < 0.4:
            put(44, 1, ['%d paragraphs of similar length' % len(pl)])

    # 46: semicolon and parenthesis underuse (advice; documents of 300 words or more)
    if len(words_of(p)) >= 300 and ';' not in p:
        if len(re.findall(r'\([^()\n]*\)', p)) <= 1:
            put(46, 1, ['no semicolons, almost no parentheses'])

    # 54: hedge stacking (advice): sentences with two or more hedges
    hedge_n = 0
    hedge_s = []
    for s in sents:
        found = HEDGE_RX.findall(s)
        if len(found) >= 2:
            hedge_n += len(found)
            if len(hedge_s) < 3:
                hedge_s.append(clip(s))
    put(54, hedge_n, hedge_s)

    # 55: contraction absence (advice): first-person writing that writes forms out in full
    wc = len(words_of(p))
    fp = len(FIRST_PERSON_RX.findall(p))
    if wc >= 100 and fp / wc >= 0.02:
        full = len(FULL_FORMS_RX.findall(p))
        contracted = len(CONTRACTED_RX.findall(p))
        if full >= 4 and full >= 3 * contracted:
            put(55, 1, ['%d uncontracted forms' % full])

    # 56: boldface overuse
    bolds = BOLD_RX.findall(p)
    if len(bolds) >= 2:
        put(56, len(bolds), [clip(x) for x in bolds[:3]])

    # 58: em-dash overuse (advice): paragraphs with two or more em dashes
    ed = sum(1 for para in paras if para.count('\u2014') >= 2)
    put(58, ed, ['paragraph with two or more em dashes'])

    # 59: title case in headings
    tcase = []
    for ln in lines:
        hm = HEADING_RX.match(ln)
        if not hm:
            continue
        text = hm.group(1)
        ws = text.split()
        if len(ws) < 3 or text.isupper() or not text[:1].isalpha():
            continue
        major = [w for w in ws if w.lower().strip('.,:;!?()') not in SMALL_WORDS]
        caps = [w for w in major if w[:1].isalpha() and w[:1].isupper()]
        if len(major) >= 2 and len(caps) == len(major):
            tcase.append(clip(text))
    put(59, len(tcase), tcase[:3])

    # 60: curly quotation marks (advice)
    cq = re.findall('[\u201c\u201d\u2018\u2019]', p)
    put(60, len(cq), ['curly quotation mark'])

    # 61: hyphen for en dash in year ranges (advice)
    yr = []
    for m in re.finditer(r'(?<![\d-])(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)(?![\d-])', p):
        if int(m.group(1)) < int(m.group(2)):
            yr.append(m.group(0))
    put(61, len(yr), yr[:3])

    # 70: decorative horizontal rules (three or more, in a document of two dozen lines or more)
    rules = HR_RX.findall(p)
    if len(rules) >= 3 and len(lines) >= 24:
        put(70, len(rules), ['horizontal rule'])

    # 71: degenerate repetition (a fifth or more of six-word runs repeat)
    toks = [w.lower() for w in words_of(p)]
    if len(toks) >= 12:
        grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
        cnt = Counter(grams)
        repeated = sum(c for c in cnt.values() if c >= 2)
        if repeated / len(grams) >= 0.2:
            rep_list = [' '.join(g) for g, c in cnt.items() if c >= 2]
            put(71, len(rep_list), [clip(x) for x in rep_list[:3]])

    # 17 parallelism form (advice, weight zero)
    par_n = 0
    par_s = []
    for pat in PARALLEL:
        for m in re.finditer(pat, p, re.I | re.M):
            par_n += 1
            if len(par_s) < 3:
                par_s.append(clip(m.group(0)))
    return hits, (par_n, par_s)


def score_families(hits):
    return {n for n in hits if n not in ADVICE and n not in NO_DETECTOR}


def score_for(hits, wc, conf):
    """Return (score, families) from the hits on the masked prose."""
    fams = score_families(hits)
    dec = fams & DECISIVE
    raw = 0.0
    for n in fams:
        weight = 15 if n in DECISIVE else (4 if n in RHYTHM else 9)
        raw += weight * (1 + 0.1 * min(hits[n][0] - 1, 6))
    score = int(min(100, round(raw)))
    dec_floor = 0
    if len(dec) >= 2:
        dec_floor = 65
    elif len(dec) == 1 and conf in ('moderate', 'high'):
        dec_floor = 45
    if len(fams) == 1 and dec_floor == 0:
        score = min(score, 40)
    if fams and fams <= {40}:
        score = min(score, 20)
    elif fams and fams <= RHYTHM:
        score = min(score, 40)
    score = max(score, dec_floor)
    if wc < 120:
        short_n = len(fams & SHORT_FAMILIES)
        if short_n >= 3:
            score = max(score, 45)
        elif short_n >= 2:
            score = max(score, 25)
    if wc >= 400:
        if len(fams) >= 6:
            score = max(score, 45)
        elif len(fams) >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), fams


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'




def confidence_of(wc, sm_count):
    if wc < 40:
        return 'none', 'only %d words; at least 40 are needed before any confidence' % wc
    if wc < 120:
        return 'low', 'only %d words; under 120 words is too short for a firm score' % wc
    if wc < 300 and sm_count <= 1:
        return 'low', 'only %d words and a single pattern family; under 300 words that is weak evidence' % wc
    if wc < 300:
        return 'moderate', 'under 300 words; the score is a rough triage, not a verdict'
    return 'high', ''


def findings_from(hits, par):
    findings = {}
    for n in sorted(k for k in hits if isinstance(k, int)):
        cnt, samples = hits[n]
        if cnt <= 0:
            continue
        key = '%d_%s' % (n, slug(LABELS[n]))
        findings[key] = {'label': LABELS[n], 'count': int(cnt), 'samples': list(samples)[:3]}
    if par[0] > 0:
        findings['17_negative_parallelism'] = {'label': PARALLEL_LABEL, 'count': int(par[0]),
                                               'samples': list(par[1])[:3]}
    return findings


def slug(label):
    return re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')


def analyze_window(window, want_ci):
    """Full analysis of one scan window. Returns the report object."""
    a0, inv, nsp, hg, hg_samples = scrub(window)
    a = trim_text(a0)
    stray = stray_count(window)
    p = mask_excluded(a)
    wc = len(words_of(p))
    sents = sentences_of(p)
    paras = paragraphs_of(p)
    hits, par = collect_hits(p, sents, paras)
    # character layer: findings 62, 66, 67, 68
    if inv:
        hits[62] = (inv, ['invisible or zero-width characters removable by cleanup'])
    if hg:
        hits[66] = (hg, hg_samples or ['mixed-script token'])
    if nsp:
        hits[67] = (nsp, ['non-standard spaces normalized by cleanup'])
    if stray:
        hits[68] = (stray, ['trailing or stray whitespace'])
    for num in NO_DETECTOR:
        hits.pop(num, None)
    conf, reason = confidence_of(wc, len(score_families(hits)))
    score, fams = score_for(hits, wc, conf)
    report = findings_from(hits, par)
    metrics = {
        'scanned_chars': len(window),
        'truncated': False,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': inv,
        'nonstandard_spaces': nsp,
        'homoglyphs': hg,
        'word_count': wc,
        'sentence_count': len(sents),
    }
    if want_ci:
        metrics['score_ci'], metrics['score_ci_note'] = interval(sents, paras, p, wc, hits, conf)
    return report, metrics


def interval(sents, paras, p, wc, full_hits, conf):
    """Low/high interval from four contiguous sentence chunks and the whole text."""
    if len(sents) < 4:
        return None, 'too few sentences (%d) for an interval; at least four are needed' % len(sents)
    scores = []
    size = len(sents) / 4.0
    for i in range(4):
        chunk = sents[int(round(i * size)):int(round((i + 1) * size))]
        if not chunk:
            continue
        text = '\n'.join(chunk)
        cw = len(words_of(text))
        hits, _ = collect_hits(text, chunk, paragraphs_of(text))
        scores.append(score_for(hits, cw, 'none')[0])
    full = score_for(full_hits, wc, conf)[0]
    scores.append(full)
    lo = max(0, min(min(scores), full))
    hi = min(100, max(max(scores), full))
    return [lo, hi], 'low and high from four sentence chunks of the scanned prose; the point score is separate'


def make_report(text, want_ci):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    report, metrics = analyze_window(window, want_ci)
    metrics['scanned_chars'] = len(window)
    metrics['truncated'] = bool(truncated)
    report['_metrics'] = metrics
    return report


# ------------------------------------------------------------------ CLI


def fail(msg, code):
    sys.stderr.write(json.dumps({'error': msg}) + '\n')
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    want_ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == '--':
            end = True
            continue
        if arg in ('--help', '-h'):
            sys.stdout.write(USAGE)
            sys.stdout.flush()
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            want_ci = True
            continue
        if arg.startswith('-'):
            return fail('unknown option %s; see --help' % arg, 2)
        operands.append(arg)
    if len(operands) > 1:
        sys.stderr.write('detect.py: more than one file given; scanning only the first file: %s\n' % operands[0])
        sys.stderr.flush()
    path = operands[0] if operands else None
    try:
        text = load_input(path)
    except ReadError as exc:
        return fail(str(exc), 1)
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    if not text.strip():
        return fail('empty input', 1)
    if clean:
        cleaned = trim_text(scrub(text)[0])
        sys.stdout.write(cleaned)
        sys.stdout.flush()
        return 0
    report = make_report(text, want_ci)
    sys.stdout.write(json.dumps(report, indent=2, ensure_ascii=True) + '\n')
    sys.stdout.flush()
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stdin.reconfigure(encoding='utf-8')
    except (AttributeError, io.UnsupportedOperation):
        pass
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except Exception as exc:  # never print a traceback
        code = fail('internal error: %s' % exc.__class__.__name__, 1)
    sys.exit(code)
