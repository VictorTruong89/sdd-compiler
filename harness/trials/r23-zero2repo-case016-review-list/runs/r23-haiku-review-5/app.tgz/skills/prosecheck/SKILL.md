---
name: prosecheck
description: Rewrite AI-flagged prose deliverables when the user asks ("prosecheck this" or "humanize this").
---

# prosecheck rewrite

Use this only when the user asks for a deep rewrite of a prose file in plain language ("prosecheck this" or
"humanize this"). The detector reports; the host agent rewrites.

1. Run the detector on the file: `python3 scripts/detect.py <file>` (or `skills/prosecheck/scripts/detect.py`
   under the plugin root). Read the findings and their samples.
2. Rewrite only the flagged spans. Keep numbers, units, dates, proper nouns, citations, quotations, and technical
   terms exactly. Never invent facts. Keep code, config, and commit text untouched.
3. Vary sentence length. Do not replace one banned word with a synonym from the same family.
4. Save the file and stop. Do not announce the rewrite, the score, or the tool in the reply.
