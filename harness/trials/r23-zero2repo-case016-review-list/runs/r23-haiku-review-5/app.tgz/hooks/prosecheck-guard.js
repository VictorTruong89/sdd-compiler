#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
// Fires after Write, Edit, MultiEdit, NotebookEdit, and apply_patch.

const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const PATCH_PATH = /^\*\*\* (Add File|Update File|Move to):(.*)$/;
const PATCH_MAX_PATHS = 16;
const EXACT_INSTRUCTION = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
// Advice-only (weight zero) catalogue keys never count toward the flagged labels.
const ADVICE_PREFIXES = ['4_', '19_', '22_', '41_', '42_', '46_', '54_', '55_', '58_', '60_', '61_', '68_',
  '17_negative_parallelism'];
const LABEL_CAP = 5;
const PLAIN_TIMEOUT = 8000;
const ARCHIVE_TIMEOUT = 15000;

function pathsFromPatch(command) {
  const out = [];
  const seen = new Set();
  for (const line of String(command || '').split(/\r?\n/)) {
    const m = PATCH_PATH.exec(line);
    if (!m) continue;
    const p = m[2].trim();
    if (!p || seen.has(p)) continue;
    seen.add(p);
    out.push(p);
    if (out.length >= PATCH_MAX_PATHS) break;
  }
  return out;
}

function pathsFromPayload(payload) {
  const tool = String(payload.tool_name || '');
  const input = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const lower = tool.toLowerCase();
  if (lower === 'apply_patch') return pathsFromPatch(input.command);
  if (lower === 'notebookedit') {
    const p = input.notebook_path || input.file_path;
    return typeof p === 'string' ? [p] : [];
  }
  if (lower === 'write' || lower === 'edit' || lower === 'multiedit') {
    return typeof input.file_path === 'string' ? [input.file_path] : [];
  }
  return [];
}

function isSkippedLocation(abs, root) {
  const segments = abs.split(/[\\/]+/);
  if (segments.indexOf('node_modules') >= 0 || segments.indexOf('.git') >= 0) return true;
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (abs === root || abs.startsWith(rootWithSep)) return true;
  return false;
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (EXACT_INSTRUCTION.indexOf(lower) >= 0) return true;
  const ext = path.extname(lower);
  for (const stem of core.INSTRUCTION_STEMS) {
    if (lower === stem) return true;
    if (lower.startsWith(stem + '.') && core.PROSE_EXTS.indexOf(ext) < 0) return true;
  }
  return false;
}

function failReason(kind, timeoutMs, detail) {
  switch (kind) {
    case 'missing': return 'python not found';
    case 'timeout': return 'timed out after ' + Math.round(timeoutMs / 1000) + ' s';
    case 'notreport': return 'detector output was not a structured report';
    case 'noscore': return 'report had no numeric score';
    case 'nooutput': return 'no usable result from the detector';
    default: return 'detector failed: ' + (detail || 'no usable result');
  }
}

function scoreOne(rawPath, cwd, threshold, sessionId, root, nudges) {
  const abs = path.resolve(cwd, rawPath);
  const base = path.basename(abs);
  if (isSkippedLocation(abs, root)) return;
  if (isInstructionFile(base)) return;

  const ext = path.extname(abs).toLowerCase();
  const isArchive = core.ARCHIVE_EXTS.indexOf(ext) >= 0;
  const isPlain = core.PLAIN_EXTS.indexOf(ext) >= 0;
  const isBinary = core.BINARY_EXTS.indexOf(ext) >= 0;
  if (!isArchive && !isPlain && !isBinary) return;

  if (isBinary) {
    core.appendLedger(sessionId, { base, kind: 'binary' });
    return;
  }

  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    core.appendLedger(sessionId, { base, kind: 'failed', reason: 'cannot read file (not on disk)' });
    return;
  }
  if (!st.isFile()) return;

  const cap = isArchive ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
  if (st.size > cap) {
    core.appendLedger(sessionId, { base, kind: 'size', limitKb: Math.round(cap / 1024) });
    return;
  }

  const timeoutMs = isArchive ? ARCHIVE_TIMEOUT : PLAIN_TIMEOUT;
  const r = core.scanFile(abs, timeoutMs);
  if (r.kind !== 'ok') {
    core.appendLedger(sessionId, { base, kind: 'failed', reason: failReason(r.kind, timeoutMs, r.reason) });
    return;
  }

  const report = r.report;
  const m = report._metrics;
  const phrase = core.phraseFor(m.ai_tell_band);
  const labels = core.findingLabels(report)
    .filter((f) => !ADVICE_PREFIXES.some((p) => f.key === p || f.key.startsWith(p)))
    .map((f) => f.label)
    .slice(0, LABEL_CAP);
  const flagged = m.ai_tell_score > threshold;

  core.appendLedger(sessionId, {
    base,
    kind: 'scored',
    score: m.ai_tell_score,
    band: m.ai_tell_band,
    phrase,
    truncated: !!m.truncated,
    flagged,
    labels,
  });

  if (!flagged) return;
  const coverage = m.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
  nudges.push('prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band
    + coverage + '). Flagged: ' + labels.join('; ') + '. Please fix the flagged spans and keep the sentence rhythm varied.');
}

function main() {
  const payload = core.readPayload();
  const level = core.currentLevel();
  if (level !== 'full' && level !== 'strict') return;
  const threshold = level === 'strict' ? core.STRICT_THRESHOLD : core.FULL_THRESHOLD;
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const sessionId = payload.session_id;
  const root = path.resolve(core.pluginRoot());

  const paths = pathsFromPayload(payload).map((p) => String(p).trim()).filter((p) => p);
  if (!paths.length) return;

  const nudges = [];
  for (const p of paths) {
    scoreOne(p, cwd, threshold, sessionId, root, nudges);
  }
  if (!nudges.length) return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: nudges.join('\n'),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
