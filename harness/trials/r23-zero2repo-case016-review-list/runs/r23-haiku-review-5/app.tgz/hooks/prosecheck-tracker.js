#!/usr/bin/env node
'use strict';
// Prompt-submit hook: routes /prosecheck commands, handles the stop phrases,
// and otherwise adds the live-level reminder.
const core = require('./lib/core');
const cmd = require('./lib/commands');

function emitBlock(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function route(sub, parts, form, payload) {
  switch (sub) {
    case 'help':
      return cmd.helpReply(form);
    case 'lite':
    case 'full':
    case 'strict':
    case 'off':
    case 'on':
      return cmd.levelReply(sub);
    case 'status':
      return cmd.statusReply();
    case 'show':
      return cmd.showReply(payload.session_id, form);
    case 'check':
      return cmd.checkReply(parts.arg, payload.cwd);
    case 'doctor':
      return cmd.doctorReply(form);
    case 'stats':
      return cmd.statsReply(payload.transcript_path);
    case 'init':
      return cmd.initReply(form, payload.cwd);
    default:
      return cmd.unknownReply(parts.word);
  }
}

function main() {
  const payload = core.readPayload();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();

  const m = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i.exec(trimmed);
  if (m) {
    const form = m[0];
    const rest = trimmed.slice(form.length).trim();
    const word = rest.split(/\s+/)[0] || '';
    const arg = rest.slice(word.length).trim();
    const sub = word.toLowerCase() || 'help';
    emitBlock(route(sub, { word, arg }, form, payload));
    return;
  }

  if (/^(stop prosecheck|prosecheck off)$/i.test(trimmed)) {
    emitBlock(cmd.levelReply('off'));
    return;
  }

  const level = core.currentLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; '
        + 'code, config, and commits are untouched.',
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
