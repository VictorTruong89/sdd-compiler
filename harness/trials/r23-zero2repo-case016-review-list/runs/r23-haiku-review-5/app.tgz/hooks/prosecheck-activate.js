#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and the first-run welcome) in context.
const path = require('path');
const core = require('./lib/core');

function main() {
  const payload = core.readPayload();
  void payload;
  const firstRun = !core.modeFlagExists();
  const level = core.currentLevel();
  if (firstRun) core.setLevel(level);
  core.pruneLedgers();
  if (level === 'off') return;
  const det = core.detectorPath();
  const detector = det ? path.resolve(det) : 'scripts/detect.py';
  const parts = [];
  if (firstRun) parts.push(core.welcomeText(), '');
  parts.push(core.contractText(level, { detector }));
  process.stdout.write(parts.join('\n') + '\n');
}

try {
  main();
} catch (e) {
  // A hook must never fail the host session.
}
process.exitCode = 0;
