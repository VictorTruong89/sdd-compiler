#!/usr/bin/env node
'use strict';
// Stats hook: prints the session token figures and the session-prose score as plain text.
const core = require('./lib/core');
const cmd = require('./lib/commands');

try {
  const payload = core.readPayload();
  process.stdout.write(cmd.statsReply(payload.transcript_path) + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
