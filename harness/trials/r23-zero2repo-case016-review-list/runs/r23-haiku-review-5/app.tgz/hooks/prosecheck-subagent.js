#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the SubagentStart envelope.
const path = require('path');
const core = require('./lib/core');

function main() {
  core.readPayload();
  const level = core.currentLevel();
  if (level === 'off') return;
  const det = core.detectorPath();
  const detector = det ? path.resolve(det) : 'scripts/detect.py';
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.contractText(level, { detector }),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
