# prosecheck 0.9.3

A local, deterministic detector for AI-writing patterns in prose deliverables, plus an agent plugin that places a
writing contract in the session, guards saved prose files, and exposes `/prosecheck` operator commands.

- Python 3.9+ standard library only (`scripts/detect.py`). Node.js runs the hooks in `hooks/`.
- No network, no telemetry, no model. Prose only; code, config, commits, and chat are left alone.
- Specification: `spec/`. Decisions where the spec conflicts or is silent: `NOTES.md`.

## Command line

```
python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
python3 scripts/detect.py --help
```

Reads `FILE` or standard input. Prints a JSON report (findings and `_metrics`) or, with `--clean`, scrubbed text.
Supported: `.md .mdx .markdown .txt .text .rst .tex .org .adoc` (512 KB cap), `.docx .docm .pptx .pptm .xlsx .xlsm
.odt .odp .ods .epub .ipynb` (4 MB cap). Only the first 262,144 characters are scanned.

## Plugin

`hooks/hooks.json` wires the session-start, prompt-submit, subagent-start, and post-tool-use hooks. The
`/prosecheck` menu command is `commands/prosecheck.md`. Subcommands: `lite`, `full`, `strict`, `off`, `on`,
`status`, `show`, `check <file>`, `doctor`, `stats`, `init`, `help`.

`/prosecheck init` exports the contract to `./AGENTS.md` and copies `.cursor/rules/prosecheck.mdc` into the project.

## Layout

```
scripts/detect.py            detector (stdlib only)
hooks/prosecheck-*.js        hook entry points
hooks/lib/core.js            config, level, contract text, detector runner, ledger
hooks/lib/commands.js        /prosecheck replies
commands/prosecheck.md       host menu command
.cursor/rules/prosecheck.mdc shipped Cursor rule (copied by init)
skills/prosecheck/SKILL.md   bundled skill instructions for the host agent
.claude-plugin/plugin.json   plugin manifest
spec/                        specification (unchanged)
```
