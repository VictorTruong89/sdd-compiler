#!/usr/bin/env python3
"""prosecheck detector: local, deterministic AI-writing pattern scanner.

Standard library only. Usage:

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input. The default output is one
JSON report object on standard output. --clean prints scrubbed text instead.
Failures print one JSON object {"error": ...} as the last stderr line.
"""

import io
import json
import math
import posixpath
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024

PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
BINARY_EXTS = {'.pdf', '.rtf'}
PROSE_EXTS = PLAIN_EXTS | ZIP_EXTS | NOTEBOOK_EXTS

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan prose for AI-writing patterns and print a JSON report.
With no FILE, standard input is read.

  --clean     print the scrubbed text instead of the report
  --ci        add a low/high interval on the score (needs four or more sentences)
  --          end option parsing, so FILE may begin with a dash
  -h, --help  print this message and exit

Supported files: plain text (.md .mdx .markdown .txt .text .rst .tex .org .adoc),
zip documents (.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub),
and notebooks (.ipynb). Only the first 262,144 characters are scanned.
"""


class Fail(Exception):
    def __init__(self, message, code):
        Exception.__init__(self, message)
        self.message = message
        self.code = code


# ---------------------------------------------------------------- text input

def normalize_newlines(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def decode_text(data):
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', errors='replace')
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', errors='replace')
    return data.decode('utf-8', errors='replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _attr_local(el, name):
    for key, value in el.attrib.items():
        if _local(key) == name:
            return value
    return None


def _ooxml_paragraphs(root):
    """Paragraph strings from WordprocessingML or DrawingML XML."""
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for node in p.iter():
            ln = _local(node.tag)
            if ln == 't' and node.text:
                parts.append(node.text)
            elif ln == 'tab':
                parts.append('\t')
            elif ln in ('br', 'cr'):
                parts.append('\n')
        s = ''.join(parts)
        if s.strip():
            paras.append(s)
    return paras


def _extract_docx(zf):
    root = ET.fromstring(zf.read('word/document.xml'))
    return '\n'.join(_ooxml_paragraphs(root))


def _extract_pptx(zf):
    names = []
    for n in zf.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m:
            names.append((int(m.group(1)), n))
    names.sort()
    chunks = []
    for _, n in names:
        root = ET.fromstring(zf.read(n))
        chunks.extend(_ooxml_paragraphs(root))
    return '\n'.join(chunks)


def _extract_xlsx(zf):
    names = zf.namelist()
    shared = []
    if 'xl/sharedStrings.xml' in names:
        root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
        for si in root:
            if _local(si.tag) == 'si':
                shared.append(''.join(t.text or '' for t in si.iter() if _local(t.tag) == 't'))
    sheets = []
    for n in names:
        m = re.match(r'xl/worksheets/sheet(\d+)\.xml$', n)
        if m:
            sheets.append((int(m.group(1)), n))
    sheets.sort()
    cells = []
    for _, n in sheets:
        root = ET.fromstring(zf.read(n))
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            text = ''
            if kind == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = ch.text
                if v is not None and re.match(r'^\s*\d+\s*$', v):
                    idx = int(v)
                    if 0 <= idx < len(shared):
                        text = shared[idx]
            elif kind == 'inlineStr':
                text = ''.join(t.text or '' for t in c.iter() if _local(t.tag) == 't')
            elif kind == 'str':
                text = ''.join(v.text or '' for v in c if _local(v.tag) == 'v')
            if text.strip():
                cells.append(text)
    return '\n'.join(cells)


_ODF_BLOCK = {'p', 'h', 'table-row', 'page'}


def _odf_walk(el, out):
    ln = _local(el.tag)
    if ln == 's':
        count = _attr_local(el, 'c')
        try:
            n = int(count) if count else 1
        except ValueError:
            n = 1
        out.append(' ' * max(n, 0))
    elif ln == 'tab':
        out.append('\t')
    elif ln == 'line-break':
        out.append('\n')
    if el.text:
        out.append(el.text)
    for child in el:
        _odf_walk(child, out)
        if child.tail:
            out.append(child.tail)
    if ln in _ODF_BLOCK or ln == 'table-cell':
        out.append('\n')


def _extract_odf(zf):
    root = ET.fromstring(zf.read('content.xml'))
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    out = []
    _odf_walk(body, out)
    lines = [ln.strip() for ln in ''.join(out).split('\n')]
    return '\n'.join(ln for ln in lines if ln)


class _XHTMLText(HTMLParser):
    SKIP = {'script', 'style', 'head', 'nav', 'title'}
    BLOCK = {'p', 'div', 'li', 'ul', 'ol', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'td', 'th',
             'table', 'section', 'article', 'blockquote', 'pre', 'hr', 'header', 'footer',
             'figure', 'figcaption', 'br', 'dt', 'dd', 'body', 'html'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            if self.skip:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.out.append(re.sub(r'[ \t\r\n\f]+', ' ', data))


def _html_to_text(raw):
    parser = _XHTMLText()
    try:
        parser.feed(raw)
        parser.close()
    except Exception:
        pass
    lines = [re.sub(' +', ' ', ln).strip() for ln in ''.join(parser.out).split('\n')]
    return '\n'.join(ln for ln in lines if ln)


def _epub_documents(zf):
    names = zf.namelist()
    docs = None
    try:
        cont = ET.fromstring(zf.read('META-INF/container.xml'))
        rootfile = None
        for el in cont.iter():
            if _local(el.tag) == 'rootfile':
                rootfile = el.get('full-path')
                break
        if rootfile:
            base = posixpath.dirname(rootfile)
            opf = ET.fromstring(zf.read(rootfile))
            manifest = {}
            spine = []
            for el in opf.iter():
                ln = _local(el.tag)
                if ln == 'item':
                    manifest[el.get('id')] = (el.get('href') or '', el.get('properties') or '')
                elif ln == 'itemref':
                    spine.append(el.get('idref'))
            docs = []
            for idref in spine:
                if idref not in manifest:
                    continue
                href, props = manifest[idref]
                if 'nav' in props.split():
                    continue
                path = posixpath.normpath(posixpath.join(base, href)) if base else posixpath.normpath(href)
                if path in names:
                    docs.append(path)
    except Exception:
        docs = None
    if not docs:
        docs = sorted(n for n in names
                      if n.lower().endswith(('.xhtml', '.html', '.htm'))
                      and not posixpath.basename(n).lower().startswith('nav'))
    return docs


def _extract_epub(zf):
    chunks = []
    for name in _epub_documents(zf):
        raw = zf.read(name).decode('utf-8', errors='replace')
        text = _html_to_text(raw)
        if text:
            chunks.append(text)
    return '\n'.join(chunks)


def _extract_notebook(data):
    try:
        nb = json.loads(decode_text(data))
    except Exception:
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    out = []
    for cell in nb['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source')
        if isinstance(src, str):
            text = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            text = ''.join(src)
        else:
            return ''
        text = text.strip()
        if text:
            out.append(text)
    return '\n'.join(out)


def read_source(path):
    """Return the extracted prose (not yet trimmed for plain text) for a path or stdin."""
    if path is None:
        data = sys.stdin.buffer.read()
        return normalize_newlines(decode_text(data))
    import os
    if os.path.isdir(path):
        raise Fail('cannot read input: %s is a directory' % path, 1)
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise Fail('cannot read input: %s (%s)' % (path, exc.strerror or 'unreadable'), 1)
    ext = os.path.splitext(path)[1].lower()
    if ext in BINARY_EXTS:
        return ''
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise Fail('cannot read input: %s is not a readable archive' % path, 1)
        try:
            with zf:
                if ext in ('.docx', '.docm'):
                    text = _extract_docx(zf)
                elif ext in ('.pptx', '.pptm'):
                    text = _extract_pptx(zf)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _extract_xlsx(zf)
                elif ext == '.epub':
                    text = _extract_epub(zf)
                else:
                    text = _extract_odf(zf)
        except (KeyError, ET.ParseError, ValueError):
            text = ''
        return normalize_newlines(text).strip()
    if ext in NOTEBOOK_EXTS:
        return normalize_newlines(_extract_notebook(data)).strip()
    return normalize_newlines(decode_text(data))


# ------------------------------------------------------------ character layer

# Zs separators other than U+0020 (U+0020 itself is ordinary and never listed here).
ZS_SPACES = set(['\u00a0', '\u1680', '\u202f', '\u205f', '\u3000'] + [chr(c) for c in range(0x2000, 0x200B)])
ZL_ZP = set(['\u2028', '\u2029'])
BIDI_CTRL = set(chr(c) for c in [0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
                                 0x2066, 0x2067, 0x2068, 0x2069])
DEFAULT_IGNORABLE = set(chr(c) for c in [0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x180B, 0x180C, 0x180D, 0x180F])
NBSP_HOLD_BEFORE = set(':;!?\u00bb\u203a%\u20ac')
NBSP_HOLD_AFTER = set('\u00ab\u2039')

# Latin-looking letters of other scripts -> ASCII letter they imitate.
CONFUSABLE = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'ո': 'n', 'о': 'o', 'օ': 'o', 'р': 'p', 'ѕ': 's',
    'υ': 'u', 'ն': 'u', 'ѵ': 'v', 'ν': 'v', 'ԝ': 'w', 'х': 'x',
    'у': 'y', 'ү': 'y',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'Ν': 'N', 'О': 'O', 'Օ': 'O',
    'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'Υ': 'Y', 'Ζ': 'Z',
    'Τ': 'T', 'Ο': 'O', 'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Η': 'H',
    'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ρ': 'P', 'Χ': 'X',
}


def _is_cjk(ch):
    if not ch:
        return False
    o = ord(ch)
    return (0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF
            or 0x20000 <= o <= 0x2FA1F)


def _is_nospace_script(ch):
    if not ch:
        return False
    o = ord(ch)
    return (0x0E00 <= o <= 0x0EFF or 0x1780 <= o <= 0x17FF or 0x1000 <= o <= 0x109F
            or 0x3040 <= o <= 0x30FF or _is_cjk(ch))


def _is_joining(ch):
    if not ch:
        return False
    o = ord(ch)
    return (0x0590 <= o <= 0x08FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F
            or 0x1780 <= o <= 0x17FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF)


def _is_symbolish(ch):
    if not ch:
        return False
    return ord(ch) >= 0x1F000 or unicodedata.category(ch) == 'So'


def _is_rtl_char(ch):
    o = ord(ch)
    return 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF


def has_rtl(text):
    return any(_is_rtl_char(c) for c in text)


def is_invisible(ch):
    if ch in '\t\n\r':
        return False
    o = ord(ch)
    if o < 0x20 or 0x7F <= o <= 0x9F:
        return True
    if 0xE0000 <= o <= 0xE0FFF or 0xFE00 <= o <= 0xFE0F:
        return True
    if ch in DEFAULT_IGNORABLE:
        return True
    return unicodedata.category(ch) == 'Cf'


def is_kept_invisible(text, i, rtl):
    """True where FP-03 says an otherwise invisible character does a job."""
    ch = text[i]
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= o <= 0xE007F:
        return bool(prev) and (ord(prev) == 0x1F3F4 or 0xE0020 <= ord(prev) <= 0xE007F)
    if 0xE0100 <= o <= 0xE01EF:
        return _is_cjk(prev)
    if 0xFE00 <= o <= 0xFE0F:
        return _is_symbolish(prev) or _is_cjk(prev) or nxt == '\u20e3'
    if o in (0x180B, 0x180C, 0x180D, 0x180F):
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if o in (0x17B4, 0x17B5):
        return (bool(prev) and 0x1780 <= ord(prev) <= 0x17FF) or (bool(nxt) and 0x1780 <= ord(nxt) <= 0x17FF)
    if o == 0x200B:
        return _is_nospace_script(prev) or _is_nospace_script(nxt)
    if o == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if o in (0x200C, 0x200D):
        return (_is_joining(prev) or _is_joining(nxt) or _is_symbolish(prev) or _is_symbolish(nxt))
    if ch in BIDI_CTRL:
        return rtl
    return False


def is_kept_nbsp(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and unicodedata.category(prev) == 'Nd') or (nxt and unicodedata.category(nxt) == 'Nd'):
        return True
    if nxt and nxt in NBSP_HOLD_BEFORE:
        return True
    if prev and prev in NBSP_HOLD_AFTER:
        return True
    return False


_LETTER_RUN = re.compile(r'[^\W\d_]+')


def homoglyph_runs(text):
    """Spans of letter runs that mix ASCII Latin letters with confusable letters only."""
    spans = []
    for m in _LETTER_RUN.finditer(text):
        run = m.group()
        has_ascii = False
        has_conf = False
        other = False
        for c in run:
            if c.isascii():
                if c.isalpha():
                    has_ascii = True
            elif c in CONFUSABLE:
                has_conf = True
            else:
                other = True
                break
        if has_ascii and has_conf and not other:
            spans.append((m.start(), m.end()))
    return spans


def char_layer(win):
    """Return dict of spans for invisible, non-standard space, homoglyph, trailing-whitespace layers."""
    rtl = has_rtl(win)
    invisible = []
    nbsp = []
    for i, ch in enumerate(win):
        if ch == ' ' or ch == '\t' or ch == '\n':
            continue
        if is_invisible(ch):
            if not is_kept_invisible(win, i, rtl):
                invisible.append((i, i + 1))
        elif ch in ZS_SPACES:
            if ch == '\u00a0' or ch == '\u202f':
                if is_kept_nbsp(win, i):
                    continue
            nbsp.append((i, i + 1))
    trailing = []
    pos = 0
    for line in win.split('\n'):
        stripped = line.rstrip(' \t')
        if len(stripped) < len(line):
            trailing.append((pos + len(stripped), pos + len(line)))
        pos += len(line) + 1
    if win.endswith('\n\n'):
        trailing.append((len(win) - 1, len(win)))
    if win and win[0].isspace():
        trailing.append((0, 1))
    trailing = sorted(set(trailing))
    return {
        'invisible': invisible,
        'nbsp': nbsp,
        'homoglyph': homoglyph_runs(win),
        'trailing': trailing,
    }


# ------------------------------------------------------------- markdown mask

_FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
_FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
_BLOCKQUOTE = re.compile(r'^ {0,3}>')
_TABLE_ROW = re.compile(r'^\s*\|.*\|\s*$')
_BADGE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
_INLINE_CODE = re.compile(r'(`+)(?!`).+?(?<!`)\1(?!`)')


def mask_markdown(text):
    """Blank out front matter, fenced code, inline code, quotes, tables and badges.

    The result has the same length as the input, and newlines are kept.
    """
    lines = text.split('\n')
    n = len(lines)
    masked = [False] * n
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(j + 1):
                    masked[k] = True
                break
    i = 0
    while i < n:
        if masked[i]:
            i += 1
            continue
        m = _FENCE_OPEN.match(lines[i])
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            fence = m.group(2)
            ch = fence[0]
            size = len(fence)
            masked[i] = True
            j = i + 1
            while j < n:
                masked[j] = True
                cm = _FENCE_CLOSE.match(lines[j])
                if cm and cm.group(1)[0] == ch and len(cm.group(1)) >= size:
                    break
                j += 1
            i = j + 1
        else:
            i += 1
    # blockquote runs of two or more lines
    i = 0
    while i < n:
        if not masked[i] and _BLOCKQUOTE.match(lines[i]):
            j = i
            while j < n and not masked[j] and _BLOCKQUOTE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
            i = j
        else:
            i += 1
    for k in range(n):
        if masked[k]:
            continue
        if _TABLE_ROW.match(lines[k]) or _BADGE.match(lines[k]):
            masked[k] = True
    out = []
    for k, line in enumerate(lines):
        if masked[k]:
            out.append(' ' * len(line))
        else:
            out.append(_INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), line))
    return '\n'.join(out)


# --------------------------------------------------------------- analysis helpers

_WORD = re.compile(r'[^\W_](?:[^\W_]|[\'’-])*')
_SENT = re.compile(r'[^\n]+?(?:[.!?]+(?=\s|$)|$)', re.M)
_PARA = re.compile(r'(?:[^\n]|\n(?![ \t]*\n))+')


def words_in(text):
    return _WORD.findall(text)


def cv(values):
    if not values:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


def _merge(spans):
    spans = sorted(spans)
    out = []
    last_end = -1
    for s, e in spans:
        if s < last_end:
            continue
        out.append((s, e))
        last_end = e
    return out


def rx_spans(patterns, text):
    spans = []
    for p in patterns:
        for m in p.finditer(text):
            spans.append((m.start(), m.end()))
    return _merge(spans)


def _c(pattern, flags=re.I):
    return re.compile(pattern, flags)


AI_VOCAB = [_c(r"\b(?:additionally|align(?:s|ed|ing)? with|crucial(?:ly)?|delv(?:e|es|ed|ing)|tapestry|tapestries"
               r"|pivotal|vibrant|meticulous(?:ly)?|testament|underscor(?:e|es|ed|ing)|intricate|intricacies"
               r"|interplay|garner(?:s|ed|ing)?|bolster(?:s|ed|ing)?|foster(?:s|ed|ing)?"
               r"|showcas(?:e|es|ed|ing)|emphasi[sz](?:e|es|ed|ing)|enduring|enhanc(?:e|es|ed|ing)"
               r"|leverag(?:e|es|ed|ing)|utiliz(?:e|es|ed|ing)|facilitat(?:e|es|ed|ing)"
               r"|encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?|holistic(?:ally)?|paradigms?"
               r"|transformative|unprecedented|myriad|plethora|robust(?:ly|ness)?|seamless(?:ly)?"
               r"|navigat(?:e|es|ed|ing)|embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|landscapes?"
               r"|journey|journeys|journeying|realms?|multifaceted|elevat(?:e|es|ed|ing)"
               r"|empower(?:s|ed|ing)?|unlock(?:s|ed|ing)?"
               r"|captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic))\b")]

MODEL_DIALECT = [_c(r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly"
                    r"|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)"
                    r"|resonates? deeply|game[- ]?chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)"
                    r"|skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioniz(?:e|es|ed|ing)"
                    r"|double down on|dive deep(?:er)? into|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)"
                    r"|takes? [^.!?\n]{1,40}? to the next level)\b")]

PROMO = [_c(r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community"
            r"|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier"
            r"|leading (?:provider|brand|company|firm|name|edge|player)|esteemed organi[sz]ation"
            r"|valuable asset|passion for excellence|proven track record|results-oriented|wealth of experience"
            r"|dynamic team|fast-paced environment|deeply passionate|perfectly situated"
            r"|(?:close|tight)-knit team|I am excited to (?:apply|bring)|uniquely positioned to)\b")]

MARKETING_IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                         'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                         'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
                         'stop', 'start'}

SIMPLE_YET = [_c(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")]

STOCK_ADJ = {'powerful', 'seamless', 'robust', 'comprehensive', 'innovative', 'cutting-edge', 'vibrant',
             'dynamic', 'elegant', 'intuitive', 'scalable', 'modern', 'rich', 'diverse', 'meaningful',
             'valuable', 'reliable', 'secure', 'efficient', 'fast', 'smart', 'simple', 'clean', 'beautiful',
             'stunning', 'bold', 'timeless', 'sleek', 'lightweight', 'streamlined'}
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial',
              'ary', 'ory', 'ish')

SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]

SIGNIFICANCE = [
    _c(r"\b(?:stands?|serves?|stood|served) as (?:an? |the )?(?:testament|reminder|symbol|beacon|cornerstone"
       r"|bridge|gateway|hallmark)\b"),
    _c(r"\b(?:underscor|highlight)(?:es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance|enduring"
       r"|central|vital|crucial|pivotal|key)\b"),
    _c(r"\breflects? an? (?:broader|wider) (?:trend|shift|pattern)\b"),
    _c(r"\bmarks? an? (?:turning point|milestone|watershed|new chapter|new era)\b"),
    _c(r"\bsymboliz(?:es|ed|ing)\b"),
    _c(r"\bsets the stage for\b"),
    _c(r"\bleft an indelible mark\b"),
    _c(r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b"),
    _c(r"\bhas (?:shaped|sparked)\b"),
    _c(r"\bhas come to (?:define|symbolize)\b"),
]

NOTABILITY = [
    _c(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [^.!?\n]*?"
       r"(?-i:[A-Z])\w*[^.!?\n]*?(?:,| and )\s*(?-i:[A-Z])\w*"),
    _c(r"\b\d[\d,.]*\s*(?:[KMkm]\+?\s*)?(?:followers|subscribers)\b"),
    _c(r"\b(?:strong|active|growing|robust|significant) (?:online|digital|social[- ]media) presence\b"),
    _c(r"\bwidely covered\b"),
    _c(r"\bindependent coverage\b"),
]

VAGUE_ATTRIBUTION = [_c(r"\bexperts? (?:argue|believe|say|claim|note|suggest)\b"),
                     _c(r"\bindustry (?:reports|observers|analysts)\b"),
                     _c(r"\bobservers have (?:cited|noted)\b"),
                     _c(r"\bsome critics argue\b"),
                     _c(r"\bresearchers have found\b"),
                     _c(r"\bstudies suggest\b"),
                     _c(r"\bit is widely believed\b")]

ARTICLE_TITLE = [_c(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of "
                    r"(?:[\w'’-]+ ){1,10}?(?:is|are) (?:a|an|the)\b", 0)]

CONSERVATION = [_c(r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b"),
                _c(r"\bconservation efforts are (?:underway|ongoing|in place)\b"),
                _c(r"\bserves as an indicator species\b"),
                _c(r"\bcontributes to biodiversity\b")]

FALSE_RANGE = [_c(r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?"
                  r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"),
               _c(r"\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b")]

ING_TAIL = [_c(r",\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering"
               r"|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting"
               r"|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")]

TAILING_NEGATION = [_c(r",\s*no (?:guessing|wasted motion|waste|hassle|fluff|stress|jargon)\b")]
PARALLELISM = [_c(r"\bit['’]s not (?:just|merely) (?:about|an?)\b"),
               _c(r"\bnot only\b[^.!?\n]{0,40}?\bbut\b"),
               _c(r"\bdoesn['’]t just\b[^,.!?\n]{0,40}?\bit\b")]

NOT_X_JUST_Y = [_c(r"\b(?:no|not) \w+, (?:just|only|simply) \w+"),
                _c(r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t) (?:just|merely) "
                   r"(?:an? |the )?\w+\s*(?:,|—|–|--|-)\s*(?:it['’]s|it is|it was|they['’]re"
                   r"|they are|they were|that['’]s|but)\b")]

FILLER = [_c(r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to"
             r"|it is important to note that|it should be mentioned that|needless to say)\b")]

EMPTY_PIVOT = [_c(r"\bit['’]s worth (?:noting|mentioning) that\b"),
               _c(r"\bit bears (?:noting|mentioning) that\b"),
               _c(r"\bone thing to (?:consider|keep in mind) is\b"),
               _c(r"\bit is interesting to note that\b"),
               _c(r"\ba key consideration is\b"),
               _c(r"\ba point to highlight is\b")]

OUTCOME_TAIL = [_c(r",\s*(?:raising questions about|prompting reflection on|sparking debate about"
                   r"|with broader implications for|reshaping our understanding of|paving the way for"
                   r"|signaling a shift toward)\b")]

PERSUASIVE = [_c(r"\bhere['’]s the thing\b"), _c(r"\bmake no mistake\b"), _c(r"\bthe truth is\b"),
              _c(r"\blet['’]s be honest\b"), _c(r"\bthe simple fact is\b"), _c(r"\bat its core\b"),
              _c(r"\bwhat really matters\b"), _c(r"\bmore than anything\b"),
              _c(r"\bat the end of the day\b"), _c(r"\bthe bottom line is\b"), _c(r"\bin reality\b"),
              _c(r"\bfundamentally,"), _c(r"\bthe real question is\b"), _c(r"\bthe heart of the matter\b"),
              _c(r"\bthe deeper issue\b"), _c(r"\bwhen you get down to it\b"),
              _c(r"\bwhen all is said and done\b")]

INTRO_HOOK = [_c(r"\bin today['’]s (?:[\w-]+ ){0,2}?(?:world|landscape|environment|market)\b"),
              _c(r"\bin a world where\b"), _c(r"\bin an era of\b"), _c(r"\bin recent years,"),
              _c(r"\bmore than ever before\b"), _c(r"\bwe live in a (?:time|world) when\b"),
              _c(r"\b(?:great|exciting|big) news[!:]"),
              _c(r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?"),
              _c(r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")]

SELF_THOROUGH = [_c(r"\bthis comprehensive (?:guide|overview|analysis)\b"),
                 _c(r"\bthis in-depth (?:analysis|look|examination)\b"),
                 _c(r"\bthis complete (?:guide|overview)\b"),
                 _c(r"\ba thorough examination of\b"),
                 _c(r"\beverything you need to know about\b")]

CONCRETE_EVIDENCE = [_c(r"\bwithout concrete (?:evidence|proof)\b"),
                     _c(r"\bdo you have concrete (?:evidence|proof|examples)\b"),
                     _c(r"\bI (?:would )?need concrete (?:evidence|examples|proof) to\b"),
                     _c(r"\babsent concrete proof\b"),
                     _c(r"\bprovide concrete (?:evidence|proof)\b")]

DIFF_ANCHORED = [_c(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b"),
                 _c(r"\b(?:the|this)(?: (?:latest|new))? (?:update|release|version|change|patch|design)"
                    r" (?:adds|introduces|brings|delivers|includes|provides|improves)\b"),
                 _c(r"\bhas been (?:updated|refactored|improved|enhanced)\b|\bhave been (?:updated|refactored|improved|enhanced)\b"
                    r"|\b(?:has|have) been changed to\b"),
                 _c(r"\bpreviously\b[^.!?\n]*\bnow\b"),
                 _c(r"\b(?:wasn['’]t|weren['’]t) there before\b"),
                 _c(r"\bwe(?:['’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b")]

SIGNPOST = [_c(r"\blet['’]s (?:dive|delve|explore)\b"),
            _c(r"\blet['’]s break (?:this|it) down\b"),
            _c(r"\bhere['’]s what you need to know\b"),
            _c(r"\bwithout further ado\b"),
            _c(r"\bnow let['’]s look at\b"),
            _c(r"\bbuckle up\b"),
            _c(r"\bstay with me\b"),
            _c(r"\b(?:are you )?ready to dive in\b")]

CATALOG_LEADIN = [_c(r"\b(?:used|uses|employs?|employed|relied on|relies on|utilizes?|utilized) "
                     r"(?:several|various|a number of|multiple|different|many|numerous) \w+"),
                  _c(r"(?:^|(?<=[.!?])[ \t]+|\n[ \t]*)These (?:[\w-]+ )?(?:provide|offer|give|reveal|show|allow|enable|help)s? "
                     r"(?:you |us |readers )?(?:with )?(?:information|insight|understanding|details|data)\b", 0),
                  _c(r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat"
                     r"|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b")]

FORMULAIC_CHALLENGE = [_c(r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b"),
                       _c(r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b"),
                       _c(r"\bcontinues to thrive\b"),
                       _c(r"\btypical of (?:emerging|urban|modern)\b"),
                       _c(r"\bfaces (?:several|many|numerous) challenges\b")]

TRANSITION_RX = re.compile(r"(?:^|(?<=[.!?])[ \t\n]+|\n[ \t]*)(Additionally|Furthermore|Moreover|However|Nevertheless"
                           r"|Consequently|Subsequently|Notably)\b")

CONCLUSION_OPENER = _c(r"^[ \t>#*\-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all"
                       r"|in essence|ultimately)\b", re.I | re.M)

POSITIVE_CONCLUSION = [_c(r"\bthe future looks bright\b"), _c(r"\bexciting times lie ahead\b"),
                       _c(r"\bjourney toward excellence\b"), _c(r"\bstep in the right direction\b"),
                       _c(r"\b(?:outlook|future)(?: for [\w ]{1,40})? (?:is|looks|remains) bright\b"),
                       _c(r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b")]

CHATBOT = [_c(r"\bI hope this helps\b"), _c(r"\b(?:Certainly|Of course)!"), _c(r"\blet me know if you\b"),
           _c(r"\bwould you like me to\b"), _c(r"\bfeel free to (?:ask|reach out)\b"),
           _c(r"\bhappy to help(?=[.!](?:\s|$))"),
           _c(r"\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b"),
           _c(r"\bhere (?:are|['’]s) (?:a few |some |two |three )?(?:options|drafts|versions|variations)\b"),
           _c(r"\bhere (?:is|['’]s) (?:a|the) draft\b"),
           _c(r"\bdepending on the (?:vibe|tone|style)\b"),
           _c(r"\bI hope this (?:email )?finds you well\b"),
           _c(r"\bas an? (?:AI(?: assistant| language model)?|LLM|large language model|language model)\b"),
           _c(r"\bto (?:answer|address) your question\b"),
           _c(r"\bin (?:response|answer) to your question\b"),
           _c(r"\byour question (?:about|regarding|concerning)\b"),
           _c(r"\bas (?:you )?(?:requested|asked),? here\b"),
           _c(r"\bhere is (?:the )?(?:draft|first pass|revised version)\b")]

SYCOPHANCY = [_c(r"\byou(?:['’]re| are) absolutely right\b"),
              _c(r"\b(?:great|excellent|good|fantastic|wonderful|thoughtful|insightful|brilliant) (?:question|point)[!.,]"),
              _c(r"\bwhat a (?:thoughtful|great|wonderful|fantastic|excellent|brilliant) question\b"),
              _c(r"\bthat['’]s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b")]

CUTOFF = [_c(r"\bas of my (?:last )?(?:training|knowledge)\b"),
          _c(r"\bup to my (?:last )?(?:training|knowledge)\b"),
          _c(r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b"),
          _c(r"\bbased on (?:the )?available information\b"),
          _c(r"\bas of my (?:knowledge )?cutoff\b"),
          _c(r"\bmaintains a low profile\b"),
          _c(r"\bkeeps (?:his|her|their) personal life private\b")]

COPULA = [_c(r"\b(?:serves|stands|functions|acts) as\b"),
          _c(r"\brepresents an? (?:the )?"),
          _c(r"\bmarks an? (?:the )?"),
          _c(r"\bboasts\b"),
          _c(r"\bfeatures (?:an?|the|\d[\d,]*|one|two|three|four|five|several|many|numerous|multiple|various"
             r"|a number of)\b"),
          _c(r"\boffers an? "),
          _c(r"\brefers to\b")]

HEDGE = _c(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to"
           r"|somewhat|relatively|fairly|kind of|sort of)\b", 0)

FIRST_PERSON = _c(r"\b(?:I|[Ww]e|[Mm]y|[Oo]ur|[Mm]e|[Uu]s)\b", 0)
CONTRACTION = _c(r"\b[A-Za-z]+['’](?:s|t|re|ve|ll|d|m)\b")
EXPANDED = _c(r"\b(?:do not|does not|did not|is not|are not|was not|were not|it is|I am|I will|I have"
              r"|we are|we will|we have|that is|cannot|will not|can not|they are|you are|let us|should not"
              r"|would not|it has|there is)\b")

BOLD = _c(r"\*\*[^*\n]+\*\*", 0)
EMOJI = re.compile(u"[\U0001F000-\U0001FAFF☀-⛿✀-➿⭐⭕]")
EM_DASH = u"—"
CURLY = re.compile(u"[“”‘’]")
EN_RANGE = re.compile(r"(?<![\d-])(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)(?![\d-])")

MARKETING_SLOP = [_c(r"\bunlocking (?:your |the )?full potential\b"),
                  _c(r"\bnavigating the complexities\b"),
                  _c(r"\ba testament to the (?:power|importance) of\b"),
                  _c(r"\bstaying ahead of the curve\b"),
                  _c(r"\bturning challenges into opportunities\b"),
                  _c(r"\btaking (?:\w+ )?to the next level\b"),
                  _c(r"\bharnessing the power of\b"),
                  _c(r"\bpaving the way for\b"),
                  _c(r"\bsaying goodbye to\b"),
                  _c(r"\bimagining a world where\b"),
                  _c(r"\bunleash(?:ing)? the (?:full )?power\b")]

PLACEHOLDER = [_c(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,80}\](?![\(\[])"),
               _c(r"\[[^\]\n]{0,40}\b(?:name|company|client|place|source|organi[sz]ation|person)\b[^\]\n]{0,40}\]"
                  r"(?![\(\[])"),
               _c(r"\{\{[^{}\n]*\}\}", 0),
               _c(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])", 0),
               _c(r"\blorem ipsum\b")]
ALLCAPS_SLOT = re.compile(r"\[([A-Z][A-Z0-9 _-]*[A-Z])\](?![\(\[])")

CHAT_MARKUP = [_c(r"\bcite(?:turn|start|nav)\w*"), _c(r"\boai_citation\w*", 0),
               _c(r"\bcontentReference\w*", 0), _c(r"\bnavlist\w*", 0),
               _c(u"【\\d+†[^】\n]*】", 0)]

UTM = re.compile(r"utm_source=([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*)", re.I)
UTM_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
             'copilot.microsoft.com', 'poe.com'}

SIGNIFICANCE_NUM = None

DECORATIVE_RULE = re.compile(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,}|(?:- ){2,}-|(?:\* ){2,}\*)[ \t]*$", re.M)
HEADING = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$", re.M)
LIST_LINE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
SENT_SPLIT_WORDS = {'a', 'an', 'the', 'at', 'by', 'for', 'in', 'of', 'off', 'on', 'out', 'to', 'up', 'as',
                    'into', 'from', 'with', 'over', 'per', 'via', 'and', 'but', 'or', 'nor', 'so', 'yet'}
HEADLINE_STOP = {'a', 'an', 'the', 'at', 'by', 'for', 'in', 'of', 'off', 'on', 'out', 'to', 'up', 'as', 'into',
                 'from', 'with', 'over', 'per', 'via', 'and', 'but', 'or', 'nor', 'so', 'yet'}


# ------------------------------------------------------------- family table

class Ctx(object):
    pass


def _f_list(patterns):
    return lambda ctx: rx_spans(patterns, ctx.masked)


def f_ai_vocab(ctx):
    return rx_spans(AI_VOCAB, ctx.masked)


def f_model_dialect(ctx):
    return rx_spans(MODEL_DIALECT, ctx.masked)


def f_promo(ctx):
    spans = rx_spans(PROMO, ctx.masked)
    imp = []
    for s, e, text in ctx.sents:
        w = words_in(text)
        if w and w[0].lower() in MARKETING_IMPERATIVES:
            imp.append((s, e))
    if len(imp) >= 3:
        spans = _merge(spans + imp)
    return spans


def f_simple_yet(ctx):
    return rx_spans(SIMPLE_YET, ctx.masked)


def f_hyphen_pairs(ctx):
    stock = ['cutting-edge', 'state-of-the-art', 'best-in-class', 'next-generation', 'user-friendly',
             'high-quality', 'results-driven', 'data-driven', 'value-added', 'well-established',
             'time-tested', 'ever-evolving', 'ever-changing', 'forward-thinking', 'game-changing',
             'world-renowned', 'detail-oriented', 'cost-effective', 'fast-growing', 'top-notch']
    pats = [_c(r"\b" + re.escape(w) + r"\b") for w in stock]
    return rx_spans(pats, ctx.masked)


def f_stacked_adjectives(ctx):
    chain = re.compile(r"\b[A-Za-z][A-Za-z-]*(?:(?:,\s*|,?\s+and\s+|,?\s+or\s+)[A-Za-z][A-Za-z-]*){3,}\b")
    spans = []
    for m in chain.finditer(ctx.masked):
        words = [w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]*", m.group())
                 if w.lower() not in ('and', 'or')]
        if len(words) < 4:
            continue
        for w in words[:-1]:
            if w in STOCK_ADJ or w.endswith(ADJ_SUFFIX):
                spans.append((m.start(), m.end()))
                break
    return _merge(spans)


def f_synonym_cycling(ctx):
    spans = []
    for cluster in SYNONYM_CLUSTERS:
        found = []
        for member in cluster:
            pat = re.compile(r"\b" + re.escape(member) + r"(?:s|es)?\b", re.I)
            m = pat.search(ctx.masked)
            if m:
                found.append((m.start(), m.end()))
        if len(found) >= 3:
            spans.append(min(found))
    return _merge(spans)


def f_significance(ctx):
    return rx_spans(SIGNIFICANCE, ctx.masked)


def f_notability(ctx):
    return rx_spans(NOTABILITY, ctx.masked)


def f_vague(ctx):
    return rx_spans(VAGUE_ATTRIBUTION, ctx.masked)


def f_article_title(ctx):
    return rx_spans(ARTICLE_TITLE, ctx.masked)


def f_conservation(ctx):
    return rx_spans(CONSERVATION, ctx.masked)


def f_false_range(ctx):
    return rx_spans(FALSE_RANGE, ctx.masked)


def f_ing_tail(ctx):
    return rx_spans(ING_TAIL, ctx.masked)


def f_tailing_negation(ctx):
    return rx_spans(TAILING_NEGATION, ctx.masked)


def f_parallelism(ctx):
    return rx_spans(PARALLELISM, ctx.masked)


def f_not_x_just_y(ctx):
    return rx_spans(NOT_X_JUST_Y, ctx.masked)


def f_filler(ctx):
    return rx_spans(FILLER, ctx.masked)


def f_empty_pivot(ctx):
    return rx_spans(EMPTY_PIVOT, ctx.masked)


def f_outcome_tail(ctx):
    return rx_spans(OUTCOME_TAIL, ctx.masked)


def f_persuasive(ctx):
    return rx_spans(PERSUASIVE, ctx.masked)


def f_editorial(ctx):
    pats = [_c(r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize)\b"),
            _c(r"\bone must note that\b"),
            _c(r"\bit is worth pointing out\b"),
            _c(r"\bit cannot be overstated that\b"),
            _c(r"\bit must be emphasi[sz]ed that\b")]
    return rx_spans(pats, ctx.masked)


def f_self_thorough(ctx):
    return rx_spans(SELF_THOROUGH, ctx.masked)


def f_qa_pattern(ctx):
    rx = re.compile(r"(?:^|(?<=[\n.!?]\s)|(?<=\n))(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have"
                    r"|Was|Were|May|Might|Must|Shall) [^?.!\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe"
                    r"|Probably|Always)[.!]")
    return rx_spans([rx], ctx.masked)


def f_concrete_evidence(ctx):
    return rx_spans(CONCRETE_EVIDENCE, ctx.masked)


def f_intro_hook(ctx):
    return rx_spans(INTRO_HOOK, ctx.masked)


def f_diff_anchored(ctx):
    return rx_spans(DIFF_ANCHORED, ctx.masked)


def f_signpost(ctx):
    return rx_spans(SIGNPOST, ctx.masked)


def f_catalog_leadin(ctx):
    return rx_spans(CATALOG_LEADIN, ctx.masked)


def f_inline_header(ctx):
    rx = re.compile(r"^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+:\*\*|^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?"
                    r"\*\*[^*\n:]+\*\*:", re.M)
    return rx_spans([rx], ctx.masked)


def f_mid_bullets(ctx):
    if HEADING.search(ctx.masked):
        return []
    lists = []
    prose = 0
    for s, e, text in ctx.paras:
        lines = [ln for ln in text.split('\n') if ln.strip()]
        if lines and all(LIST_LINE.match(ln) for ln in lines):
            lists.append((s, e))
        else:
            prose += 1
    if lists and prose >= 2:
        return lists
    return []


def f_fragmented_header(ctx):
    lines = ctx.masked.split('\n')
    spans = []
    pos = []
    p = 0
    for ln in lines:
        pos.append(p)
        p += len(ln) + 1
    for i, ln in enumerate(lines):
        m = HEADING.match(ln)
        if not m:
            continue
        heading_words = set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", m.group(2)))
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith(('#', '|', '>')) or LIST_LINE.match(lines[j]):
            continue
        words = re.findall(r"[A-Za-z]+", nxt)
        if not words or len(words) > 4:
            continue
        if any(w.lower() in heading_words for w in words):
            spans.append((pos[j], pos[j] + len(lines[j])))
    return _merge(spans)


def f_fenced_bullets_none(ctx):
    return []


def f_transition(ctx):
    spans = []
    for s, e, text in ctx.paras:
        found = [(s + m.start(1), s + m.end(1)) for m in TRANSITION_RX.finditer(text)]
        if len(found) >= 2:
            spans.extend(found)
    return _merge(spans)


def f_conclusion(ctx):
    return [(m.start(), m.end()) for m in CONCLUSION_OPENER.finditer(ctx.masked)]


def f_positive_conclusion(ctx):
    return rx_spans(POSITIVE_CONCLUSION, ctx.masked)


def f_monotony(ctx):
    lens = [len(words_in(t)) for _, _, t in ctx.sents]
    if len(lens) < 3:
        return []
    c = cv(lens)
    if c is not None and c < 0.35:
        return [(0, len(ctx.masked))]
    return []


def f_alternation(ctx):
    lens = [len(words_in(t)) for _, _, t in ctx.sents]
    if len(lens) < 6:
        return []
    best = 0
    cur = 0
    prev_d = None
    for i in range(1, len(lens)):
        d = lens[i] - lens[i - 1]
        if prev_d is not None and abs(d) >= 5 and abs(prev_d) >= 5 and d * prev_d < 0:
            cur += 1
        elif abs(d) >= 5:
            cur = 2
        else:
            cur = 0
        best = max(best, cur)
        prev_d = d
    if best >= 6:
        return [(0, len(ctx.masked))]
    return []


def f_opener_repetition(ctx):
    spans = []
    for s, e, text in ctx.paras:
        sents = [(s + m.start(), s + m.end(), m.group()) for m in re.finditer(r"[^.!?\n]+[.!?]*", text)]
        sents = [(a, b, t) for a, b, t in sents if words_in(t)]
        if len(sents) < 3:
            continue
        groups = {}
        for a, b, t in sents:
            w = [x.lower() for x in words_in(t)[:2]]
            if len(w) == 2:
                groups.setdefault(tuple(w), []).append((a, b))
        for key, members in groups.items():
            if len(members) >= 3:
                spans.append((s, e))
                break
    return _merge(spans)


def f_uniform_paragraphs(ctx):
    counts = [len(words_in(t)) for _, _, t in ctx.paras]
    counts = [c for c in counts if c > 0]
    if len(counts) < 4:
        return []
    c = cv(counts)
    if c is not None and c < 0.4:
        return [(0, len(ctx.masked))]
    return []


def f_semicolon_underuse(ctx):
    words = words_in(ctx.masked)
    if len(words) < 300:
        return []
    if ';' in ctx.masked or ctx.masked.count('(') >= 2:
        return []
    return [(0, len(ctx.masked))]


def f_chatbot(ctx):
    return rx_spans(CHATBOT, ctx.masked)


def f_sycophancy(ctx):
    return rx_spans(SYCOPHANCY, ctx.masked)


def f_cutoff(ctx):
    return rx_spans(CUTOFF, ctx.masked)


def f_copula(ctx):
    return rx_spans(COPULA, ctx.masked)


def f_hedge(ctx):
    spans = []
    for s, e, text in ctx.sents:
        hits = [m for m in HEDGE.finditer(text)]
        if len(hits) >= 2:
            spans.append((s, e))
    return _merge(spans)


def f_contraction_absence(ctx):
    words = words_in(ctx.masked)
    if len(words) < 20:
        return []
    fp = len(FIRST_PERSON.findall(ctx.masked))
    if fp < 3 or fp / float(len(words)) < 0.02:
        return []
    if CONTRACTION.search(ctx.masked):
        return []
    if len(EXPANDED.findall(ctx.masked)) < 3:
        return []
    return [(0, len(ctx.masked))]


def f_bold(ctx):
    return rx_spans([BOLD], ctx.masked)


def f_emoji(ctx):
    return [(m.start(), m.end()) for m in EMOJI.finditer(ctx.masked)]


def f_em_dash(ctx):
    spans = []
    for s, e, text in ctx.paras:
        if text.count(EM_DASH) >= 2:
            spans.append((s, e))
    return _merge(spans)


_TITLE_MINOR = HEADLINE_STOP


def f_title_case(ctx):
    spans = []
    for m in HEADING.finditer(ctx.masked):
        text = m.group(2).strip()
        if not text or not text[0].isalpha():
            continue
        letters = [c for c in text if c.isalpha()]
        if not letters or all(c.isupper() for c in letters):
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’-]*", text)
        if len(words) < 3:
            continue
        major = [w for w in words if w.lower() not in _TITLE_MINOR]
        if len(major) < 2:
            continue
        if all(w[0].isupper() for w in major):
            spans.append((m.start(), m.end()))
    return _merge(spans)


def f_curly(ctx):
    return [(m.start(), m.end()) for m in CURLY.finditer(ctx.masked)]


def f_en_range(ctx):
    spans = []
    for m in EN_RANGE.finditer(ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            spans.append((m.start(), m.end()))
    return spans


def f_marketing_slop(ctx):
    return rx_spans(MARKETING_SLOP, ctx.masked)


def f_decorative_rules(ctx):
    rules = [(m.start(), m.end()) for m in DECORATIVE_RULE.finditer(ctx.masked)]
    if len(ctx.masked.split('\n')) < 24 or len(rules) < 3:
        return []
    return rules


def f_degenerate(ctx):
    toks = [w.lower() for w in words_in(ctx.masked)]
    if len(toks) < 6:
        return []
    grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
    counts = Counter(grams)
    repeated = sum(1 for g in grams if counts[g] > 1)
    if repeated == 0 or repeated / float(len(grams)) < 0.2:
        return []
    return [(0, len(ctx.masked))]


def f_placeholder(ctx):
    spans = rx_spans(PLACEHOLDER, ctx.masked)
    for m in ALLCAPS_SLOT.finditer(ctx.masked):
        if sum(1 for c in m.group(1) if c.isalpha()) >= 3:
            spans.append((m.start(), m.end()))
    return _merge(spans)


def f_chat_markup(ctx):
    return rx_spans(CHAT_MARKUP, ctx.masked)


def f_utm(ctx):
    spans = []
    for m in UTM.finditer(ctx.masked):
        host = re.match(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*", m.group(1)).group(0).lower()
        if host in UTM_HOSTS:
            spans.append((m.start(), m.end()))
    return spans


def f_invisible(ctx):
    return ctx.char['invisible']


def f_homoglyph(ctx):
    return ctx.char['homoglyph']


def f_nonstandard(ctx):
    return ctx.char['nbsp']


def f_trailing(ctx):
    return ctx.char['trailing']


# (key, catalogue number, label, kind, decisive, sample_mode, function)
# kind: 's' score-moving, 'a' writing advice (weight zero)
FAMILIES = [
    ('1_ai_vocabulary', 1, 'AI vocabulary', 's', False, 'excerpt', f_ai_vocab),
    ('2_model_dialect_vocabulary', 2, 'model-dialect vocabulary', 's', False, 'excerpt', f_model_dialect),
    ('3_promotional_language', 3, 'promotional language', 's', False, 'excerpt', f_promo),
    ('4_hyphenated_pair_overuse', 4, 'hyphenated word-pair overuse', 'a', False, 'excerpt', f_hyphen_pairs),
    ('5_simple_yet_cliche', 5, 'simple-yet cliche', 's', False, 'excerpt', f_simple_yet),
    ('6_stacked_adjective_chain', 6, 'stacked adjective chain', 's', False, 'excerpt', f_stacked_adjectives),
    ('8_synonym_cycling', 8, 'synonym cycling', 's', False, 'excerpt', f_synonym_cycling),
    ('10_significance_inflation', 10, 'significance inflation', 's', False, 'excerpt', f_significance),
    ('11_notability_name_dropping', 11, 'notability name-dropping', 's', False, 'excerpt', f_notability),
    ('12_vague_attribution', 12, 'vague attribution', 's', False, 'excerpt', f_vague),
    ('13_article_title_as_proper_noun', 13, 'article title used as a proper noun', 's', True, 'excerpt',
     f_article_title),
    ('14_conservation_padding', 14, 'conservation or ecosystem padding', 's', False, 'excerpt', f_conservation),
    ('15_false_range', 15, 'false range', 's', False, 'excerpt', f_false_range),
    ('16_superficial_ing_tail', 16, 'superficial -ing tail clause', 's', False, 'excerpt', f_ing_tail),
    ('17_negative_parallelism', 17, 'negative parallelism', 'a', False, 'excerpt', f_parallelism),
    ('17_tailing_negation', 17, 'tailing negation', 's', False, 'excerpt', f_tailing_negation),
    ('18_not_x_just_y', 18, 'not X, just Y framing', 's', False, 'excerpt', f_not_x_just_y),
    ('19_filler_phrase', 19, 'filler phrase', 'a', False, 'excerpt', f_filler),
    ('20_empty_pivot_phrase', 20, 'empty pivot phrase', 's', False, 'excerpt', f_empty_pivot),
    ('21_outcome_speculation_tail', 21, 'outcome-speculation tail', 's', False, 'excerpt', f_outcome_tail),
    ('22_persuasive_authority_trope', 22, 'persuasive authority trope', 'a', False, 'excerpt', f_persuasive),
    ('23_editorial_interjection', 23, 'editorial interjection', 's', False, 'excerpt', f_editorial),
    ('24_self_thoroughness_phrase', 24, 'self-thoroughness phrase', 's', False, 'excerpt', f_self_thorough),
    ('25_question_answer_pattern', 25, 'question-answer rhetorical pattern', 's', False, 'excerpt', f_qa_pattern),
    ('26_concrete_evidence_defense', 26, 'concrete-evidence defense phrase', 's', False, 'excerpt',
     f_concrete_evidence),
    ('27_compulsive_intro_hook', 27, 'compulsive intro hook', 's', False, 'excerpt', f_intro_hook),
    ('30_diff_anchored_writing', 30, 'diff-anchored writing', 's', False, 'excerpt', f_diff_anchored),
    ('31_signposting', 31, 'signposting and announcement', 's', False, 'excerpt', f_signpost),
    ('32_cataloguing_lead_in', 32, 'cataloguing lead-in', 's', False, 'excerpt', f_catalog_leadin),
    ('33_inline_header_list', 33, 'inline-header vertical list', 's', False, 'excerpt', f_inline_header),
    ('34_mid_essay_bullets', 34, 'mid-essay bullet injection', 's', False, 'excerpt', f_mid_bullets),
    ('35_fragmented_header', 35, 'fragmented header', 's', False, 'excerpt', f_fragmented_header),
    ('36_formulaic_challenges', 36, 'formulaic challenges section', 's', False, 'excerpt',
     _f_list(FORMULAIC_CHALLENGE)),
    ('37_transition_cluster', 37, 'transition-word cluster', 's', False, 'excerpt', f_transition),
    ('38_compulsive_conclusion', 38, 'compulsive conclusion opener', 's', False, 'excerpt', f_conclusion),
    ('39_generic_positive_conclusion', 39, 'generic positive conclusion', 's', False, 'excerpt',
     f_positive_conclusion),
    ('40_sentence_length_monotony', 40, 'sentence-length monotony', 's', False, 'excerpt', f_monotony),
    ('41_mechanical_alternation', 41, 'mechanical sentence-length alternation', 'a', False, 'excerpt',
     f_alternation),
    ('42_opener_repetition', 42, 'sentence-opener repetition', 'a', False, 'excerpt', f_opener_repetition),
    ('44_uniform_paragraph_length', 44, 'uniform paragraph length', 's', False, 'excerpt', f_uniform_paragraphs),
    ('46_semicolon_parenthesis_underuse', 46, 'semicolon and parenthesis underuse', 'a', False, 'excerpt',
     f_semicolon_underuse),
    ('47_chatbot_artifact', 47, 'chatbot artifact', 's', True, 'excerpt', f_chatbot),
    ('48_sycophantic_tone', 48, 'sycophantic tone', 's', True, 'excerpt', f_sycophancy),
    ('50_knowledge_cutoff_disclaimer', 50, 'knowledge-cutoff disclaimer', 's', True, 'excerpt', f_cutoff),
    ('51_copula_avoidance', 51, 'copula avoidance', 's', False, 'excerpt', f_copula),
    ('54_hedge_stacking', 54, 'hedge stacking', 'a', False, 'excerpt', f_hedge),
    ('55_contraction_absence', 55, 'contraction absence', 'a', False, 'excerpt', f_contraction_absence),
    ('56_boldface_overuse', 56, 'boldface overuse', 's', False, 'excerpt', f_bold),
    ('57_emoji', 57, 'emoji', 's', False, 'excerpt', f_emoji),
    ('58_em_dash_overuse', 58, 'em-dash overuse', 'a', False, 'excerpt', f_em_dash),
    ('59_title_case_heading', 59, 'title case in headings', 's', False, 'excerpt', f_title_case),
    ('60_curly_quotation_marks', 60, 'curly quotation marks', 'a', False, 'excerpt', f_curly),
    ('61_hyphen_for_en_dash', 61, 'hyphen used for en dash in year range', 'a', False, 'excerpt', f_en_range),
    ('62_invisible_characters', 62, 'invisible or zero-width characters', 's', True, 'codepoint', f_invisible),
    ('63_placeholder_text', 63, 'placeholder or template text', 's', True, 'excerpt', f_placeholder),
    ('64_chat_reference_markup', 64, 'chat reference markup', 's', True, 'excerpt', f_chat_markup),
    ('65_ai_tracking_parameter', 65, 'AI tracking parameter', 's', True, 'excerpt', f_utm),
    ('66_homoglyphs', 66, 'mixed-script homoglyphs', 's', True, 'excerpt', f_homoglyph),
    ('67_nonstandard_spaces', 67, 'non-standard spaces', 's', False, 'codepoint', f_nonstandard),
    ('68_trailing_whitespace', 68, 'trailing or stray whitespace', 'a', False, 'excerpt', f_trailing),
    ('69_canonical_marketing_phrase', 69, 'canonical marketing phrase', 's', False, 'excerpt',
     f_marketing_slop),
    ('70_decorative_rules', 70, 'decorative horizontal rules', 's', False, 'excerpt', f_decorative_rules),
    ('71_degenerate_repetition', 71, 'degenerate repetition', 's', False, 'excerpt', f_degenerate),
]

DECISIVE_NUMS = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM_NUMS = {40, 41, 44, 55}
SHORT_FLOOR_NUMS = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}


def band_for(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def phrase_for(band):
    return {
        'clean': 'reads clean',
        'light tells': 'reads mostly clean',
        'mixed': 'reads with some AI tells',
        'heavy tells': 'reads with heavy AI tells',
        'pervasive tells': 'reads with pervasive AI tells',
    }[band]


def excerpt(text, start, end, width=60):
    a = max(0, start - width // 2)
    b = min(len(text), end + width // 2)
    piece = text[a:b].replace('\r', ' ').replace('\n', ' ')
    prefix = u'…' if a > 0 else ''
    suffix = u'…' if b < len(text) else ''
    return prefix + piece.strip() + suffix


def _paragraph_spans(masked):
    out = []
    for m in _PARA.finditer(masked):
        text = m.group()
        if text.strip():
            out.append((m.start(), m.end(), text))
    return out


def build_ctx(win):
    ctx = Ctx()
    ctx.win = win
    ctx.masked = mask_markdown(win)
    ctx.char = char_layer(win)
    ctx.sents = []
    for m in _SENT.finditer(ctx.masked):
        t = m.group()
        if words_in(t):
            ctx.sents.append((m.start(), m.end(), t))
    ctx.paras = _paragraph_spans(ctx.masked)
    ctx.words = words_in(ctx.masked)
    return ctx


def _confidence(words, nsm):
    if words < 40:
        return 'none', 'fewer than 40 words'
    if words < 120 or (words < 300 and nsm == 1):
        if words < 120:
            return 'low', 'fewer than 120 words'
        return 'low', 'only one score-moving pattern family in fewer than 300 words'
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def score_document(ctx):
    """Return (findings, fired_info) where fired_info holds score and metrics."""
    findings = []
    fired = {}
    for key, num, label, kind, decisive, mode, fn in FAMILIES:
        spans = fn(ctx)
        if not spans:
            continue
        fired[key] = (num, label, kind, decisive, spans, mode)
        findings.append((key, num, label, spans, mode))

    sm = [v for v in fired.values() if v[2] == 's']
    sm_nums = set(v[0] for v in sm)
    sm_families = set(v[0] for v in sm)

    points = 0
    for num, label, kind, decisive, spans, mode in [(v[0], v[1], v[2], v[3], v[4], v[5]) for v in sm]:
        points += min(15 + 4 * (len(spans) - 1), 27)
    score = min(100, points)

    if len(sm_families) == 1:
        score = min(score, 40)
    if sm_nums and sm_nums <= RHYTHM_NUMS:
        score = min(score, 40)
    if sm_nums and sm_nums <= {40}:
        score = min(score, 20)

    words = len(ctx.words)
    confidence, reason = _confidence(words, len(sm_families))

    decisive_fams = set(v[0] for v in sm if v[3])
    if len(decisive_fams) >= 2:
        score = max(score, 65)
    elif len(decisive_fams) == 1 and confidence not in ('none', 'low'):
        score = max(score, 45)

    if words < 120:
        short_hits = sm_families & SHORT_FLOOR_NUMS
        if len(short_hits) >= 3:
            score = max(score, 45)
        elif len(short_hits) >= 2:
            score = max(score, 25)
    if words >= 400:
        if len(sm_families) >= 6:
            score = max(score, 45)
        elif len(sm_families) >= 5:
            score = max(score, 25)

    score = max(0, min(100, score))
    return findings, score, confidence, reason, len(sm_families)


def analyze(full_text, want_ci=False):
    truncated = len(full_text) > WINDOW
    win = full_text[:WINDOW]
    ctx = build_ctx(win)
    findings, score, confidence, reason, nsm = score_document(ctx)

    report = {}
    for key, num, label, spans, mode in findings:
        samples = []
        for s, e in spans[:3]:
            if mode == 'codepoint':
                ch = win[s] if s < len(win) else ''
                samples.append(u'U+%04X at character %d' % (ord(ch) if ch else 0, s + 1))
            else:
                src = win if mode == 'excerpt' else win
                samples.append(excerpt(src, s, e))
        report[key] = {'label': label, 'count': len(spans), 'samples': samples}

    band = band_for(score)
    metrics = {
        'scanned_chars': len(win),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': len(ctx.char['invisible']),
        'nonstandard_spaces': len(ctx.char['nbsp']),
        'homoglyphs': len(ctx.char['homoglyph']),
        'words': len(ctx.words),
        'sentences': len(ctx.sents),
    }
    if want_ci:
        low, high, note = resample_interval(win, ctx, score)
        metrics['score_ci'] = None if low is None else [low, high]
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


def resample_interval(win, ctx, point):
    """Bootstrap over sentences; deterministic seed. Returns (low, high, note)."""
    sents = [t.strip() for _, _, t in ctx.sents]
    sents = [s for s in sents if s]
    if len(sents) < 4:
        return None, None, 'too few sentences for an interval (%d; need 4)' % len(sents)
    rng = random.Random(20240601)
    rounds = 30 if len(win) <= 50000 else 8
    scores = []
    for _ in range(rounds):
        pick = [sents[rng.randrange(len(sents))] for _ in range(len(sents))]
        sub = build_ctx(' '.join(pick))
        _, s, _, _, _ = score_document(sub)
        scores.append(s)
    low = max(0, min(min(scores), point))
    high = min(100, max(max(scores), point))
    return low, high, 'bootstrap over sentences, %d resamples, fixed seed' % rounds


# ------------------------------------------------------------------- cleanup

def clean_text(text):
    text = normalize_newlines(text)
    rtl = has_rtl(text)
    fold = {}
    for s, e in homoglyph_runs(text):
        for i in range(s, e):
            fold[i] = CONFUSABLE.get(text[i], text[i])
    out = []
    for i, ch in enumerate(text):
        if ch in '\t\n':
            out.append(ch)
            continue
        if is_invisible(ch):
            if is_kept_invisible(text, i, rtl):
                out.append(ch)
            continue
        if ch in ZS_SPACES:
            if (ch == '\u00a0' or ch == '\u202f') and is_kept_nbsp(text, i):
                out.append(ch)
            else:
                out.append(' ')
            continue
        if ch in ZL_ZP:
            out.append('\n')
            continue
        out.append(fold.get(i, ch))
    s = ''.join(out)
    lines = [ln.rstrip(' \t') for ln in s.split('\n')]
    while lines and lines[0] == '':
        lines.pop(0)
    result = '\n'.join(lines).rstrip()
    if text.endswith('\n') and result:
        result += '\n'
    return result


# ------------------------------------------------------------------- CLI

def fail(message, code):
    raise Fail(message, code)


def emit_error(message, code):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    want_ci = False
    want_help = False
    operands = []
    stop = False
    for arg in argv:
        if stop:
            operands.append(arg)
            continue
        if arg == '--':
            stop = True
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            want_ci = True
        elif arg in ('-h', '--help'):
            want_help = True
        elif arg.startswith('-'):
            return emit_error('unknown option: %s (see --help)' % arg, 2)
        else:
            operands.append(arg)

    if want_help:
        sys.stdout.write(USAGE)
        sys.stdout.flush()
        return 0

    if len(operands) > 1:
        sys.stderr.write('prosecheck: %d files given; only the first is scanned: %s\n'
                         % (len(operands), operands[0]))
        sys.stderr.flush()

    path = operands[0] if operands else None
    try:
        text = read_source(path)
    except Fail as exc:
        return emit_error(exc.message, exc.code)

    if not text.strip():
        return emit_error('empty input', 1)

    if clean:
        result = clean_text(text)
        sys.stdout.buffer.write(result.encode('utf-8'))
        sys.stdout.flush()
        return 0

    report = analyze(text, want_ci)
    sys.stdout.buffer.write((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    sys.stdout.flush()
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except Fail as exc:
        code = emit_error(exc.message, exc.code)
    except BrokenPipeError:
        code = 0
    except Exception as exc:  # never print a traceback
        code = emit_error('cannot read input: internal error (%s)' % type(exc).__name__, 1)
    sys.exit(code)
