'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only; no network.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 524288; // 512 KB
const ARCHIVE_CAP = 4194304; // 4 MB
const LEDGER_KEEP = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const LEVELS = ['lite', 'full', 'strict', 'off'];
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ZIP_EXT, NB_EXT);

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* ignore */ }
  return {};
}

function validLevel(s) {
  return typeof s === 'string' && LEVELS.indexOf(s) >= 0 ? s : null;
}

function storedLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return validLevel(v);
  } catch (e) { return null; }
}

function envLevel() {
  const e = process.env.PROSECHECK_DEFAULT_MODE;
  return validLevel(typeof e === 'string' ? e.trim() : e);
}

function currentLevel() {
  return storedLevel() || envLevel() || 'full';
}

function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

// ---------------------------------------------------------------- ledger
function sanitizeId(id) {
  return String(id).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
}

function ledgerPath(sessionId) {
  const name = sessionId ? '.prosecheck-ledger-' + sanitizeId(sessionId) : '.prosecheck-ledger';
  return path.join(configDir(), name);
}

function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) return [];
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}

function appendLedger(sessionId, recs) {
  if (!recs.length) return;
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    let cur = readLedger(sessionId);
    cur = cur.concat(recs);
    cur = cur.slice(-LEDGER_KEEP);
    fs.writeFileSync(ledgerPath(sessionId), JSON.stringify(cur));
  } catch (e) { /* ignore */ }
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, f);
        try {
          const st = fs.statSync(p);
          if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------- phrases
function phraseForBand(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

// ---------------------------------------------------------------- detector
function findDetector() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  try { if (fs.statSync(a).isFile()) return a; } catch (e) { /* next */ }
  try { if (fs.statSync(b).isFile()) return b; } catch (e) { /* none */ }
  return null;
}

function findOnPath(name) {
  const PATH = process.env.PATH || '';
  const exts = process.platform === 'win32' ? ['.exe', '.cmd', '.bat', ''] : [''];
  for (const dir of PATH.split(path.delimiter)) {
    if (!dir) continue;
    for (const x of exts) {
      const p = path.join(dir, name + x);
      try {
        const st = fs.statSync(p);
        if (st.isFile()) {
          fs.accessSync(p, fs.constants.X_OK);
          return p;
        }
      } catch (e) { /* next */ }
    }
  }
  return null;
}

function findPython() {
  for (const n of ['python3', 'python', 'py']) {
    const p = findOnPath(n);
    if (p) return p;
  }
  return null;
}

// Returns {kind:'ok', report} | {kind:'nopython'} | {kind:'nodetector'} | {kind:'timeout'} |
// {kind:'nooutput', stderr, status} | {kind:'garbage'} | {kind:'noscore'} | {kind:'failed', stderr}
function runDetector(args, opts) {
  opts = opts || {};
  const det = findDetector();
  if (!det) return { kind: 'nodetector' };
  const py = findPython();
  if (!py) return { kind: 'nopython' };
  const r = cp.spawnSync(py, [det].concat(args), {
    input: opts.input,
    timeout: opts.timeout || 8000,
    maxBuffer: 256 * 1024 * 1024,
    encoding: 'utf8',
    env: process.env,
  });
  if (r.error) {
    if (r.error.code === 'ENOENT') return { kind: 'nopython' };
    if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout' };
    return { kind: 'failed', stderr: String(r.error.message || '') };
  }
  if (r.signal) return { kind: 'timeout' };
  const out = (r.stdout || '').trim();
  const err = (r.stderr || '').trim();
  if (r.status !== 0) return { kind: 'failed', stderr: errText(err), status: r.status };
  if (!out) return { kind: 'nooutput', stderr: err, status: r.status };
  let rep;
  try { rep = JSON.parse(out); } catch (e) { return { kind: 'garbage' }; }
  if (!rep || typeof rep !== 'object' || !rep._metrics ||
      typeof rep._metrics.ai_tell_score !== 'number' || !isFinite(rep._metrics.ai_tell_score)) {
    if (rep && typeof rep === 'object' && rep._metrics) return { kind: 'noscore' };
    return { kind: 'garbage' };
  }
  return { kind: 'ok', report: rep };
}

function errText(err) {
  if (!err) return '';
  const lines = err.split('\n').map((s) => s.trim()).filter(Boolean);
  const last = lines[lines.length - 1] || '';
  try {
    const o = JSON.parse(last);
    if (o && typeof o.error === 'string') return o.error;
  } catch (e) { /* plain */ }
  return last;
}

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (f && typeof f.label === 'string') out.push({ key: k, label: f.label, count: f.count | 0 });
  }
  out.sort((a, b) => b.count - a.count);
  return out;
}

function extOf(p) { return path.extname(p).toLowerCase(); }

function capFor(ext) {
  return (ZIP_EXT.indexOf(ext) >= 0 || NB_EXT.indexOf(ext) >= 0) ? ARCHIVE_CAP : PLAIN_CAP;
}

// ---------------------------------------------------------------- contract
function contract(level, opts) {
  opts = opts || {};
  const portable = !!opts.portable;
  const L = [];
  L.push('# Prose writing contract');
  L.push('');
  L.push('Scope: prose deliverables only. That means documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.');
  L.push('This contract is never for source code. It never touches code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly. No metronome rhythm, no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '. (landscape and journey are banned only in their abstract senses.)');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use an em dash at most once per paragraph.');
  L.push('- No bold for emphasis inside prose sentences.');
  L.push('- No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this contract: never announce it, never name the checker, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    L.push('After writing a prose file, run the bundled detector on that file and fix the flagged spans.');
    if (portable) {
      L.push('Resolve the detector (scripts/detect.py) from CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the prosecheck detector among the installed skills and plugins.');
    } else {
      const det = findDetector() || path.join(pluginRoot(), 'scripts', 'detect.py');
      L.push('Detector command: python3 ' + det + ' <file>');
    }
    if (level === 'full') {
      L.push('Target: the clean or light tells band (score at most 40). When the band is worse, fix the flagged spans and rescan, at most two fix passes, keeping rhythm variation.');
    } else {
      L.push('Target: the clean band (score at most 20). When the band is worse, fix the flagged spans and rescan, at most two fix passes, keeping rhythm variation.');
      L.push('Finish by passing the final text through the cleanup switch --clean so stray invisible characters and odd spaces are scrubbed.');
    }
  }
  return L.join('\n') + '\n';
}

function welcome() {
  return [
    'prosecheck is installed and on. This welcome is shown once.',
    'Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and no upload: everything runs locally.',
    'Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help.',
    '',
  ].join('\n');
}

module.exports = {
  WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, LEVELS, PROSE_EXT, PLAIN_EXT, ZIP_EXT, NB_EXT, BANNED,
  configDir, pluginRoot, flagPath, readStdinJson, validLevel, storedLevel, envLevel, currentLevel,
  writeLevel, ledgerPath, readLedger, appendLedger, pruneLedgers, phraseForBand, findDetector,
  findPython, findOnPath, runDetector, findings, extOf, capFor, contract, welcome, errText,
};
