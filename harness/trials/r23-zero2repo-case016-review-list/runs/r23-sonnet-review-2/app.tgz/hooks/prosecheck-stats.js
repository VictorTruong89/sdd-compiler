#!/usr/bin/env node
'use strict';
// stats helper: also used by the /prosecheck router.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

function newestTranscript(dir) {
  let best = null;
  let bestT = -1;
  function walk(d, depth) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestT) { bestT = t; best = p; }
        } catch (x) { /* ignore */ }
      }
    }
  }
  walk(dir, 0);
  return best;
}

function stripFences(s) {
  return s.replace(/^[ ]{0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:^[ ]{0,3}\1[`~]*[ \t]*$|(?![\s\S]))/gm, '');
}

function statsReply(payload) {
  const level = lib.currentLevel();
  let file = null;
  if (payload && typeof payload.transcript_path === 'string' && payload.transcript_path) {
    file = payload.transcript_path;
  } else {
    file = newestTranscript(path.join(lib.configDir(), 'projects'));
  }
  let raw = null;
  if (file) { try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) {
    return 'prosecheck stats: no readable transcript found.\nlevel: ' + level;
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    const s = line.trim();
    if (!s) continue;
    let o;
    try { o = JSON.parse(s); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const msg = o.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : '__anon' + (anon++);
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const out = Number(u.output_tokens) || 0;
    const cr = Number(u.cache_read_input_tokens) || 0;
    byId.set(id, { out, cr });
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  }
  let turns = 0; let outTok = 0; let crTok = 0;
  for (const v of byId.values()) { turns++; outTok += v.out; crTok += v.cr; }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + turns,
    'output tokens: ' + outTok,
    'cache-read input tokens: ' + crTok,
  ];
  let slice = stripFences(texts.join('\n'));
  slice = slice.slice(-40000).trim();
  if (slice.length > 200) {
    const r = lib.runDetector([], { input: slice, timeout: 15000 });
    if (r.kind === 'ok') lines.push('session prose ai_tell_score: ' + Math.round(r.report._metrics.ai_tell_score));
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const input = lib.readStdinJson();
    process.stdout.write(statsReply(input) + '\n');
  } catch (e) { /* never fail the host */ }
  process.exit(0);
}
