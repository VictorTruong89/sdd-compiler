#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

const MAX_PATHS = 16;
const INSTR_EXACT = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

function targetPaths(input) {
  const tool = String(input.tool_name || '').toLowerCase().replace(/[^a-z_]/g, '');
  const ti = input.tool_input;
  const out = [];
  if (tool === 'write' || tool === 'edit' || tool === 'multiedit') {
    if (ti && typeof ti.file_path === 'string' && ti.file_path.trim()) out.push(ti.file_path.trim());
  } else if (tool === 'notebookedit') {
    if (ti && typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) out.push(ti.notebook_path.trim());
    else if (ti && typeof ti.file_path === 'string' && ti.file_path.trim()) out.push(ti.file_path.trim());
  } else if (tool === 'apply_patch' || tool === 'applypatch') {
    let body = null;
    if (typeof ti === 'string') body = ti;
    else if (ti && typeof ti === 'object') {
      for (const k of ['command', 'patch', 'input']) {
        if (typeof ti[k] === 'string') { body = ti[k]; break; }
      }
    }
    for (const p of patchPaths(body)) out.push(p);
  }
  return out;
}

function skipPath(abs) {
  const parts = abs.split(/[\\/]+/);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return true;
  const root = path.resolve(lib.pluginRoot());
  const rel = path.relative(root, abs);
  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) return true;
  const name = path.basename(abs).toLowerCase();
  if (INSTR_EXACT.indexOf(name) >= 0) return true;
  const ext = path.extname(name);
  const stem = name.slice(0, name.length - ext.length);
  if (INSTR_STEMS.indexOf(stem) >= 0 && lib.PROSE_EXT.indexOf(ext) < 0) return true;
  return false;
}

function main() {
  const input = lib.readStdinJson();
  const level = lib.currentLevel();
  if (level !== 'full' && level !== 'strict') return;
  const threshold = level === 'strict' ? 20 : 40;
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const seen = [];
  for (const p of targetPaths(input)) {
    const abs = path.resolve(cwd, p);
    if (seen.indexOf(abs) < 0) seen.push(abs);
    if (seen.length >= MAX_PATHS) break;
  }
  const lines = [];
  const recs = [];
  for (const abs of seen) {
    if (skipPath(abs)) continue;
    const base = path.basename(abs);
    const ext = lib.extOf(abs);
    const now = Date.now();
    if (ext === '.pdf' || ext === '.rtf') { recs.push({ t: now, base, kind: 'binary' }); continue; }
    if (lib.PROSE_EXT.indexOf(ext) < 0) continue;
    let st;
    try { st = fs.statSync(abs); } catch (e) {
      recs.push({ t: now, base, kind: 'failed', reason: 'file not readable' });
      continue;
    }
    if (!st.isFile()) continue;
    const cap = lib.capFor(ext);
    if (st.size > cap) { recs.push({ t: now, base, kind: 'skipped', capKB: cap / 1024 }); continue; }
    const isPlain = lib.PLAIN_EXT.indexOf(ext) >= 0;
    const res = lib.runDetector([abs], { timeout: isPlain ? 8000 : 15000 });
    if (res.kind !== 'ok') {
      const reasons = {
        nopython: 'python not found',
        nodetector: 'detector not found',
        garbage: 'detector printed text that is not a structured report',
        noscore: 'report has no numeric score',
        timeout: 'detector timed out',
        nooutput: 'detector produced no output or exited without a usable result',
        failed: 'detector produced no output or exited without a usable result',
      };
      recs.push({ t: now, base, kind: 'failed', reason: reasons[res.kind] || reasons.failed });
      continue;
    }
    const m = res.report._metrics;
    const score = Math.round(m.ai_tell_score);
    const band = String(m.ai_tell_band);
    const labels = lib.findings(res.report).map((f) => f.label).slice(0, 5);
    const flagged = score > threshold;
    const truncated = m.truncated === true;
    recs.push({ t: now, base, kind: 'scored', score, band, labels, flagged, truncated });
    if (flagged) {
      const cov = truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '';
      let line = 'prosecheck: ' + base + ' ' + lib.phraseForBand(band) + ' (score ' + score + ', band ' + band + cov + ').';
      if (labels.length) line += ' Flagged: ' + labels.join('; ') + '.';
      line += ' Please fix the flagged spans, keeping sentence-length variation and every fact intact.';
      if (truncated) line += ' Only the first ' + lib.WINDOW_TXT + ' characters were scanned.';
      lines.push(line);
    }
  }
  lib.appendLedger(sid, recs);
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }));
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
