#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract in the session.
const fs = require('fs');
const lib = require('./prosecheck-lib');
try {
  lib.readStdinJson();
  lib.pruneLedgers();
  const fresh = (() => { try { fs.lstatSync(lib.flagPath()); return false; } catch (e) { return true; } })();
  const level = lib.currentLevel();
  if (lib.storedLevel() === null && fresh) lib.writeLevel(level);
  else if (lib.storedLevel() === null && !fresh) { /* invalid flag stays */ }
  if (level !== 'off') {
    let out = '';
    if (fresh) out += lib.welcome() + '\n';
    out += lib.contract(level);
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
