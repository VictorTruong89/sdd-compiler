#!/usr/bin/env node
'use strict';
// prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');
const { statsReply } = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpReply(level) {
  return [
    'prosecheck - level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables follow the contract.',
    '',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard with a lower threshold of 20, plus the cleanup scrub',
    '/prosecheck off | on - disable the tool / re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file (report only, never a rewrite)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and prose score of this session',
    '/prosecheck init - export the writing contract to ./AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripPathArg(arg) {
  let s = (arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  if (s.length >= 2 && ((s[0] === '"' && s[s.length - 1] === '"') || (s[0] === "'" && s[s.length - 1] === "'"))) {
    s = s.slice(1, -1);
  }
  if (s.startsWith('@')) s = s.slice(1);
  return s;
}

function checkReply(arg) {
  const p = stripPathArg(arg);
  if (!p) return 'check needs a file path, for example: /prosecheck check notes.md';
  let st;
  try { st = fs.statSync(p); } catch (e) { return 'cannot read ' + p; }
  if (!st.isFile()) return 'not a file: ' + p;
  const base = path.basename(p);
  const ext = lib.extOf(p);
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (this format is not scored)';
  const cap = lib.capFor(ext);
  if (st.size > cap) return base + ': not scored, over ' + (cap / 1024) + ' KB';
  const isPlain = lib.PLAIN_EXT.indexOf(ext) >= 0 || lib.PROSE_EXT.indexOf(ext) < 0;
  const r = lib.runDetector([p], { timeout: isPlain ? 8000 : 15000 });
  if (r.kind === 'nopython' || r.kind === 'nodetector') return 'detector unavailable: python or the bundled detector could not be launched';
  if (r.kind === 'timeout') return base + ': detector failed (timed out)';
  if (r.kind === 'failed') return base + ': detector failed' + (r.stderr ? ': ' + r.stderr : '');
  if (r.kind === 'nooutput') return base + ': the detector gave no report';
  if (r.kind !== 'ok') return 'the detector gave no report (output was not a report)';
  const m = r.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const lines = [];
  lines.push(base + ' - ' + lib.phraseForBand(m.ai_tell_band) + ' (score ' + score + '/100, band: ' + m.ai_tell_band + ')');
  let c = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) c += ' - ' + m.confidence_reason;
  lines.push(c);
  if (m.truncated === true) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  const f = lib.findings(r.report).slice(0, 8);
  if (f.length) lines.push('tells: ' + f.map((x) => x.label + ' (x' + x.count + ')').join('; '));
  else lines.push('tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.currentLevel();
  const root = lib.pluginRoot();
  const det = lib.findDetector();
  const checks = [];
  const modeOk = level !== 'off';
  checks.push(modeOk ? '[OK] mode: ' + level : '[off] mode: off - tool is switched off; run /prosecheck on to turn it back on');
  const detOk = !!det;
  checks.push(detOk ? '[OK] detector: bundled detector found' : '[!!] detector: bundled detector not found under the plugin root');
  let pyOk = false;
  let pyLine;
  const py = lib.findPython();
  if (!py) {
    pyLine = '[!!] python not found: saved files will not be re-scored until Python is available; prose is still shaped by the writing contract';
  } else if (!det) {
    pyLine = '[!!] python: found, but the bundled detector is missing so it could not run';
  } else {
    const r = lib.runDetector([], { input: 'A short sample sentence for the check. It reads plainly and says little.', timeout: 15000 });
    if (r.kind === 'ok') { pyOk = true; pyLine = '[OK] python ran the bundled detector and produced a numeric score'; }
    else if (r.kind === 'nopython') pyLine = '[!!] python not found: saved files will not be re-scored until Python is available; prose is still shaped by the writing contract';
    else pyLine = '[!!] python ran the bundled detector but the result was not a numeric score';
  }
  checks.push(pyLine);
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    const tmp = path.join(dir, '.prosecheck-doctor-' + process.pid);
    fs.writeFileSync(tmp, 'x');
    fs.unlinkSync(tmp);
    setOk = true;
  } catch (e) { setOk = false; }
  checks.push(setOk ? '[OK] settings folder is writable' : '[!!] settings folder is not writable');
  let closer;
  const rest = detOk && pyOk && setOk;
  if (rest && modeOk) {
    closer = 'prosecheck is active: plain text up to 512 KB and archives up to 4 MB are scored, over the first 262,144 characters. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (!rest) {
    closer = 'Please repair the faulty checks above, then run /prosecheck doctor again to confirm the fix.';
  } else {
    closer = 'The install is healthy. While the mode is off, saving files triggers no scoring, so nothing will be scored. Run ' + form + ' on to turn it back on.';
  }
  return ['prosecheck doctor'].concat(checks, [closer]).join('\n');
}

function showReply(sid) {
  const recs = lib.readLedger(sid);
  if (!recs.length) {
    return 'nothing scored yet in this session; rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const out = ['Files checked this session, newest first:'];
  for (const r of recs.slice().reverse()) {
    const base = r.base;
    if (r.kind === 'scored') {
      let b = lib.phraseForBand(r.band) + ' (score ' + r.score + '/' + r.band;
      if (r.truncated) b += ', first ' + lib.WINDOW_TXT + ' characters only';
      b += ')';
      if (r.labels && r.labels.length) {
        b += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
      out.push('  ' + base + ' - ' + b);
    } else if (r.kind === 'skipped') {
      out.push('  ' + base + ' - not scored: exceeds the ' + r.capKB + ' KB limit');
    } else if (r.kind === 'binary') {
      out.push('  ' + base + ' - binary file, not re-scored');
    } else {
      out.push('  ' + base + ' - not scored: ' + (r.reason || 'file not readable'));
    }
  }
  return out.join('\n');
}

function initReply(form) {
  const level = lib.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const msgs = [];
  const agents = path.join(process.cwd(), 'AGENTS.md');
  const MARK_START = '<!-- prosecheck:prose-contract:start -->';
  const MARK_END = '<!-- prosecheck:prose-contract:end -->';
  const body = lib.contract(level, { portable: true });
  let existing = null;
  let readFailed = false;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) {
    if (e.code !== 'ENOENT') readFailed = true;
  }
  if (readFailed) {
    msgs.push('cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.indexOf(MARK_START) >= 0 || existing.indexOf('# Prose writing contract') >= 0)) {
    msgs.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    let text = existing === null ? '' : existing;
    if (text && !text.endsWith('\n')) text += '\n';
    if (text) text += '\n';
    text += MARK_START + '\n' + body + MARK_END + '\n';
    try {
      fs.writeFileSync(agents, text);
      msgs.push('Wrote the writing contract to AGENTS.md.');
    } catch (e) {
      msgs.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const dest = path.join(process.cwd(), '.cursor', 'rules', 'prosecheck.mdc');
  let destExists = false;
  try { fs.lstatSync(dest); destExists = true; } catch (e) { destExists = false; }
  if (destExists) {
    msgs.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    try {
      const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data);
      msgs.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      msgs.push('cannot write the Cursor rule .cursor/rules/prosecheck.mdc.');
    }
  }
  return msgs.join('\n');
}

function handleCommand(form, rest, input) {
  const trimmed = rest.trim();
  const m = /^(\S+)(?:\s+([\s\S]*))?$/.exec(trimmed);
  const sub = m ? m[1].toLowerCase() : 'help';
  const arg = m && m[2] ? m[2].trim() : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  if (SUBS.indexOf(sub) < 0) {
    return 'unknown subcommand: ' + m[1] + '\nValid subcommands: ' + SUBS.join(', ') + '.';
  }
  switch (sub) {
    case 'lite': case 'full': case 'strict':
      lib.writeLevel(sub);
      return 'prosecheck level set to ' + sub + '.';
    case 'off':
      lib.writeLevel('off');
      return 'prosecheck is now off. Run /prosecheck on to re-enable it.';
    case 'on':
      lib.writeLevel('full');
      return 'prosecheck is on (full).';
    case 'status':
      return 'prosecheck level: ' + lib.currentLevel();
    case 'help':
      return helpReply(lib.currentLevel());
    case 'show': return showReply(sid);
    case 'check': return checkReply(arg);
    case 'doctor': return doctorReply(form);
    case 'stats': return statsReply(input);
    case 'init': return initReply(form);
    default: return helpReply(lib.currentLevel());
  }
}

function main() {
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const t = prompt.trim();
  const low = t.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    lib.writeLevel('off');
    block('prosecheck is now off. Run /prosecheck on to re-enable it.');
    return;
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?=\s|$)([\s\S]*)$/.exec(t);
  if (m) {
    block(handleCommand(m[1], m[2], input));
    return;
  }
  const level = lib.currentLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
