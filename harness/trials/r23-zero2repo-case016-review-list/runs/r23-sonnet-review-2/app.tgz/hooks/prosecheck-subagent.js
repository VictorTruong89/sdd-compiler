#!/usr/bin/env node
'use strict';
// subagent-start hook: the same contract, inside the SubagentStart envelope.
const lib = require('./prosecheck-lib');
try {
  lib.readStdinJson();
  const level = lib.currentLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contract(level) },
    }));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
