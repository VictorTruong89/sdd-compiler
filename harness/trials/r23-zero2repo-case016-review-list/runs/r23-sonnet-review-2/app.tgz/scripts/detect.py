#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only AI-writing pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import sys
import os
import re
import json
import math
import random
import zipfile
import unicodedata
from bisect import bisect_right
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

WINDOW = 262144
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Score prose for AI-writing patterns (local, no network).\n"
    "  --clean   print scrubbed text (invisible characters removed, spaces\n"
    "            normalized, lookalikes folded, whitespace trimmed) instead of a report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        end of options, so a file name may begin with a dash\n"
    "  FILE      the single file operand; with none, standard input is read\n"
    "  -h, --help  print this message\n"
)

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = {'.ipynb'}
MEMBER_CAP = 64 * 1024 * 1024


class ReadError(Exception):
    pass


# ----------------------------------------------------------------------------
# decoding / extraction
# ----------------------------------------------------------------------------

def decode_bytes(data):
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', errors='replace')
    if data.startswith(b'\xff\xfe\x00\x00') or data.startswith(b'\x00\x00\xfe\xff'):
        try:
            return data.decode('utf-32')
        except Exception:
            pass
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        try:
            return data.decode('utf-16')
        except Exception:
            return data[2:].decode('utf-16-le', errors='replace')
    return data.decode('utf-8', errors='replace')


def local(tag):
    if '}' in tag:
        tag = tag.split('}', 1)[1]
    if ':' in tag:
        tag = tag.split(':', 1)[1]
    return tag


def read_member(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return None
    return z.read(name)


def parse_xml(data):
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def natural_key(s):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', s)]


def ooxml_paragraph(p):
    parts = []
    for el in p.iter():
        t = local(el.tag)
        if t == 't' and el.text:
            parts.append(el.text)
        elif t == 'tab':
            parts.append('\t')
        elif t in ('br', 'cr'):
            parts.append('\n')
    return ''.join(parts)


def ooxml_paras(root):
    out = []
    for el in root.iter():
        if local(el.tag) == 'p':
            s = ooxml_paragraph(el)
            if s.strip():
                out.append(s)
    return out


def extract_docx(z):
    names = z.namelist()
    if 'word/document.xml' not in names:
        return ''
    data = read_member(z, 'word/document.xml')
    root = parse_xml(data) if data else None
    if root is None:
        return ''
    return '\n\n'.join(ooxml_paras(root))


def extract_pptx(z):
    slides = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    slides.sort(key=natural_key)
    chunks = []
    for n in slides:
        data = read_member(z, n)
        root = parse_xml(data) if data else None
        if root is None:
            continue
        paras = ooxml_paras(root)
        if paras:
            chunks.append('\n'.join(paras))
    return '\n\n'.join(chunks)


def si_text(si):
    parts = []

    def walk(el, in_ph):
        t = local(el.tag)
        if t == 'rPh':
            return
        if t == 't' and el.text:
            parts.append(el.text)
        for c in el:
            walk(c, in_ph)
    walk(si, False)
    return ''.join(parts)


def extract_xlsx(z):
    names = z.namelist()
    shared = []
    if 'xl/sharedStrings.xml' in names:
        data = read_member(z, 'xl/sharedStrings.xml')
        root = parse_xml(data) if data else None
        if root is not None:
            for el in root:
                if local(el.tag) == 'si':
                    shared.append(si_text(el))
    sheets = [n for n in names if re.match(r'xl/worksheets/[^/]+\.xml$', n)]
    sheets.sort(key=natural_key)
    lines = []
    for n in sheets:
        data = read_member(z, n)
        root = parse_xml(data) if data else None
        if root is None:
            continue
        for c in root.iter():
            if local(c.tag) != 'c':
                continue
            t = c.get('t')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'[0-9]+', v):
                    idx = int(v)
                    if idx < len(shared):
                        text = shared[idx]
            elif t == 'inlineStr':
                for ch in c:
                    if local(ch.tag) == 'is':
                        text = si_text(ch)
            elif t == 'str':
                for ch in c:
                    if local(ch.tag) == 'v':
                        text = ch.text or ''
            if text is not None and text.strip():
                lines.append(text)
    return '\n'.join(lines)


def odf_text(el, out):
    t = local(el.tag)
    if el.text:
        out.append(el.text)
    for c in el:
        ct = local(c.tag)
        if ct == 's':
            try:
                n = int(c.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c') or c.get('c') or 1)
            except Exception:
                n = 1
            out.append(' ' * max(1, min(n, 1000)))
        elif ct == 'tab':
            out.append('\t')
        elif ct == 'line-break':
            out.append('\n')
        elif ct in ('annotation', 'note', 'tracked-changes'):
            pass
        else:
            odf_text(c, out)
        if c.tail:
            out.append(c.tail)


def extract_odf(z, sep):
    if 'content.xml' not in z.namelist():
        return ''
    data = read_member(z, 'content.xml')
    root = parse_xml(data) if data else None
    if root is None:
        return ''
    paras = []

    def walk(el):
        t = local(el.tag)
        if t in ('p', 'h'):
            out = []
            odf_text(el, out)
            s = ''.join(out)
            if s.strip():
                paras.append(s)
            return
        for c in el:
            walk(c)
    walk(root)
    return sep.join(paras)


class _HtmlText(HTMLParser):
    BLOCK = {'p', 'div', 'section', 'article', 'li', 'ul', 'ol', 'tr', 'table', 'blockquote',
             'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'pre', 'header', 'footer', 'body', 'br', 'hr',
             'dd', 'dt', 'dl', 'figure', 'figcaption'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower().split(':')[-1]
        if tag in ('script', 'style', 'nav', 'head', 'title'):
            self.skip += 1
            return
        for k, v in attrs:
            if k and k.lower().endswith('type') and v and 'toc' in v.lower() and tag in ('nav', 'ol', 'ul', 'div', 'section'):
                pass
        if tag in self.BLOCK and not self.skip:
            self.parts.append('\n\n' if tag != 'br' else '\n')

    def handle_endtag(self, tag):
        tag = tag.lower().split(':')[-1]
        if tag in ('script', 'style', 'nav', 'head', 'title'):
            if self.skip:
                self.skip -= 1
            return
        if tag in self.BLOCK and not self.skip and tag != 'br':
            self.parts.append('\n\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def html_to_text(raw):
    p = _HtmlText()
    try:
        p.feed(raw)
        p.close()
    except Exception:
        pass
    text = ''.join(p.parts)
    text = re.sub(r'[ \t\r\f\v]+', ' ', text)
    text = re.sub(r' ?\n ?', '\n', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def extract_epub(z):
    names = z.namelist()
    order = []
    opf = None
    for n in names:
        if n.lower().endswith('.opf'):
            opf = n
            break
    if opf:
        data = read_member(z, opf)
        root = parse_xml(data) if data else None
        if root is not None:
            manifest = {}
            for el in root.iter():
                if local(el.tag) == 'item':
                    manifest[el.get('id')] = el.get('href')
            base = opf.rsplit('/', 1)[0] + '/' if '/' in opf else ''
            for el in root.iter():
                if local(el.tag) == 'itemref':
                    href = manifest.get(el.get('idref'))
                    if href:
                        href = href.split('#')[0]
                        full = os.path.normpath(base + href).replace('\\', '/')
                        if full in names and full not in order:
                            order.append(full)
    rest = sorted([n for n in names if re.search(r'\.(x?html?)$', n, re.I) and n not in order],
                  key=natural_key)
    chapters = []
    for n in order + rest:
        if not re.search(r'\.(x?html?)$', n, re.I):
            continue
        low = os.path.basename(n).lower()
        if low in ('nav.xhtml', 'nav.html', 'toc.xhtml', 'toc.html', 'toc.ncx'):
            continue
        data = read_member(z, n)
        if not data:
            continue
        raw = decode_bytes(data)
        if re.search(r'epub:type\s*=\s*["\']toc["\']', raw) and not re.search(r'<p[\s>]', raw):
            continue
        t = html_to_text(raw)
        if t:
            chapters.append(t)
    return '\n\n'.join(chapters)


def extract_notebook(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict):
            return ''
        if c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            return ''
        if s.strip():
            out.append(s.strip())
    return '\n\n'.join(out)


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in ZIP_EXT:
            if not zipfile.is_zipfile(path):
                raise ReadError('not a readable zip archive')
            try:
                z = zipfile.ZipFile(path)
            except Exception as e:
                raise ReadError('not a readable zip archive')
            try:
                if ext in ('.docx', '.docm'):
                    t = extract_docx(z)
                elif ext in ('.pptx', '.pptm'):
                    t = extract_pptx(z)
                elif ext in ('.xlsx', '.xlsm'):
                    t = extract_xlsx(z)
                elif ext in ('.odt', '.odp'):
                    t = extract_odf(z, '\n\n')
                elif ext == '.ods':
                    t = extract_odf(z, '\n')
                else:
                    t = extract_epub(z)
            except ReadError:
                raise
            except Exception:
                t = ''
            finally:
                z.close()
            return t.strip()
        if ext in ('.pdf', '.rtf'):
            return ''
        with open(path, 'rb') as f:
            data = f.read()
        if ext in NOTEBOOK_EXT:
            return extract_notebook(data).strip()
        return decode_bytes(data)
    except ReadError:
        raise
    except (OSError, IOError) as e:
        raise ReadError(str(e))


# ----------------------------------------------------------------------------
# character layer
# ----------------------------------------------------------------------------

NONASCII_OR_CTRL = re.compile(r'[^\x20-\x7e\t\n\r]')

VISIBLE_CF = set(list(range(0x600, 0x606)) + [0x6DD, 0x70F, 0x8E2, 0x110BD, 0x110CD])
EXTRA_INVISIBLE = set([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0, 0x00AD, 0x061C, 0xFEFF])
RTL_RANGES = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
BIDI = set([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
            0x2066, 0x2067, 0x2068, 0x2069])
NOSPACE_RANGES = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF),
                  (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF),
                  (0x20000, 0x2FFFF), (0x30000, 0x3FFFF), (0xFF66, 0xFF9F), (0x3000, 0x303F) ]
JOIN_RANGES = [(0x0590, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF),
               (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F),
               (0x1780, 0x17FF)]
CJK_RANGES = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF)]
EMOJI_RANGES = [(0x1F000, 0x1FAFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x2460, 0x24FF),
                (0x25A0, 0x27BF), (0x2900, 0x297F), (0x2B00, 0x2BFF)]
NBSPISH = (0x00A0, 0x202F)
NBSP_BEFORE = set(':;!?»›%€')
NBSP_AFTER = set('«‹')


def in_ranges(o, ranges):
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


def is_cjk(ch):
    return in_ranges(ord(ch), CJK_RANGES)


def is_emoji_or_symbol(ch):
    o = ord(ch)
    if in_ranges(o, EMOJI_RANGES) or o in (0xA9, 0xAE, 0x203C, 0x2049, 0x2122, 0x2139):
        return True
    return unicodedata.category(ch)[0] == 'S'


def is_inv_candidate(ch):
    o = ord(ch)
    if o in (9, 10, 13):
        return False
    if o < 32 or 0x7F <= o <= 0x9F:
        return True
    if o in VISIBLE_CF:
        return False
    if 0xE0000 <= o <= 0xE0FFF:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return True
    if 0x180B <= o <= 0x180F or 0x200B <= o <= 0x200F or 0x202A <= o <= 0x202E:
        return True
    if 0x2060 <= o <= 0x206F or 0xFFF9 <= o <= 0xFFFB:
        return True
    if o in EXTRA_INVISIBLE:
        return True
    if o < 0x80:
        return False
    return unicodedata.category(ch) == 'Cf'


def is_space_candidate(ch):
    o = ord(ch)
    if o < 0x80:
        return False
    c = unicodedata.category(ch)
    return c in ('Zs', 'Zl', 'Zp')


def has_rtl(text):
    for m in NONASCII_OR_CTRL.finditer(text):
        o = ord(m.group())
        if o >= 0x0590 and in_ranges(o, RTL_RANGES):
            return True
    return False


def inv_keep(text, i, rtl):
    """True when the invisible character at i does a job in its position."""
    n = len(text)
    ch = text[i]
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < n else ''
    if 0xE0000 <= o <= 0xE0FFF and not (0xE0100 <= o <= 0xE01EF):
        # emoji tag sequence: black flag, tags..., cancel tag
        j = i
        while j > 0 and 0xE0020 <= ord(text[j - 1]) <= 0xE007F:
            j -= 1
        if j == 0 or text[j - 1] != '\U0001F3F4':
            return False
        k = i
        while k < n and 0xE0020 <= ord(text[k]) <= 0xE007F:
            k += 1
        if k > 0 and ord(text[k - 1]) == 0xE007F and 0xE0020 <= o <= 0xE007F:
            return True
        return False
    if 0xE0100 <= o <= 0xE01EF:
        return bool(prev) and is_cjk(prev)
    if 0xFE00 <= o <= 0xFE0F:
        if nxt == '⃣':
            return True
        if prev and (is_cjk(prev) or is_emoji_or_symbol(prev)):
            return True
        return False
    if o == 0x200B:
        return (bool(prev) and in_ranges(ord(prev), NOSPACE_RANGES)) or \
               (bool(nxt) and in_ranges(ord(nxt), NOSPACE_RANGES))
    if o == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if o in BIDI:
        return rtl
    if 0x180B <= o <= 0x180F:
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if o in (0x17B4, 0x17B5):
        return (bool(prev) and 0x1780 <= ord(prev) <= 0x17FF) or \
               (bool(nxt) and 0x1780 <= ord(nxt) <= 0x17FF)
    if o in (0x200C, 0x200D):
        for c in (prev, nxt):
            if not c:
                continue
            co = ord(c)
            if in_ranges(co, JOIN_RANGES) and c.isalpha():
                return True
            if is_emoji_or_symbol(c):
                return True
        return False
    return False


def nbsp_keep(text, i):
    n = len(text)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < n else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in NBSP_BEFORE:
        return True
    if prev and prev in NBSP_AFTER:
        return True
    return False


def char_layer(text):
    """Returns (invisible_positions, space_positions, kept_info).
    invisible_positions: list of indexes of characters cleanup removes.
    space_positions: list of indexes of non-standard spaces cleanup normalizes."""
    inv = []
    spc = []
    rtl = None
    for m in NONASCII_OR_CTRL.finditer(text):
        i = m.start()
        ch = m.group()
        if is_inv_candidate(ch):
            o = ord(ch)
            if o in BIDI and rtl is None:
                rtl = has_rtl(text)
            if not inv_keep(text, i, bool(rtl)):
                inv.append(i)
        elif is_space_candidate(ch):
            o = ord(ch)
            if o in NBSPISH and nbsp_keep(text, i):
                continue
            spc.append(i)
    return inv, spc


LOOK = {}


def _reg(src, dst):
    for ch in src:
        LOOK[ch] = dst


for _pairs in (
    # Cyrillic lowercase
    ('а', 'a'), ('с', 'c'), ('е', 'e'), ('о', 'o'), ('р', 'p'), ('х', 'x'), ('у', 'y'),
    ('і', 'i'), ('ј', 'j'), ('ѕ', 's'), ('ԁ', 'd'), ('ԍ', 'g'), ('һ', 'h'), ('ԝ', 'w'),
    ('ո', 'n'), ('ս', 'u'), ('օ', 'o'), ('ց', 'g'), ('հ', 'h'),
    # Greek lowercase
    ('ο', 'o'), ('ν', 'v'), ('ι', 'i'), ('υ', 'u'), ('ρ', 'p'), ('χ', 'x'), ('γ', 'y'),
    # Cyrillic uppercase
    ('А', 'A'), ('В', 'B'), ('С', 'C'), ('Е', 'E'), ('Н', 'H'), ('І', 'I'), ('Ј', 'J'),
    ('К', 'K'), ('М', 'M'), ('О', 'O'), ('Р', 'P'), ('Ѕ', 'S'), ('Т', 'T'), ('Х', 'X'),
    ('У', 'Y'),
    # Greek uppercase
    ('Α', 'A'), ('Β', 'B'), ('Ε', 'E'), ('Ζ', 'Z'), ('Η', 'H'), ('Ι', 'I'), ('Κ', 'K'),
    ('Μ', 'M'), ('Ν', 'N'), ('Ο', 'O'), ('Ρ', 'P'), ('Τ', 'T'), ('Υ', 'Y'), ('Χ', 'X'),
):
    LOOK[_pairs[0]] = _pairs[1]

TOKEN_RE = re.compile(r'\S+')


def is_latin_ascii_letter(ch):
    return ('a' <= ch <= 'z') or ('A' <= ch <= 'Z')


def homoglyph_runs(text):
    """Yield (start, end) of qualifying letter runs (positions of lookalikes via LOOK)."""
    out = []
    for tm in TOKEN_RE.finditer(text):
        tok = tm.group()
        if tok.isascii():
            continue
        base = tm.start()
        i = 0
        n = len(tok)
        while i < n:
            if not tok[i].isalpha():
                i += 1
                continue
            j = i
            while j < n and tok[j].isalpha():
                j += 1
            run = tok[i:j]
            if not run.isascii():
                has_ascii = False
                has_look = False
                other = False
                for ch in run:
                    if ch.isascii():
                        if is_latin_ascii_letter(ch):
                            has_ascii = True
                    elif ch in LOOK:
                        has_look = True
                    else:
                        other = True
                if has_ascii and has_look and not other:
                    out.append((base + i, base + j))
            i = j
    return out


def cleanup_text(text):
    n = len(text)
    inv, spc = char_layer(text)
    invset = set(inv)
    spcset = set(spc)
    # character removal / normalization
    if invset or spcset:
        out = []
        last = 0
        for i in sorted(invset | spcset):
            out.append(text[last:i])
            if i in spcset:
                o = ord(text[i])
                if unicodedata.category(text[i]) in ('Zl', 'Zp'):
                    out.append('\n')
                else:
                    out.append(' ')
            last = i + 1
        out.append(text[last:])
        text = ''.join(out)
    # fold lookalikes
    runs = homoglyph_runs(text)
    if runs:
        out = []
        last = 0
        for a, b in runs:
            out.append(text[last:a])
            out.append(''.join(LOOK.get(c, c) for c in text[a:b]))
            last = b
        out.append(text[last:])
        text = ''.join(out)
    ended_lf = text.endswith('\n')
    lines = text.split('\n')
    res = []
    for ln in lines:
        if ln.endswith('\r'):
            res.append(ln[:-1].rstrip(' \t') + '\r')
        else:
            res.append(ln.rstrip(' \t'))
    # leading blank lines
    k = 0
    while k < len(res) and res[k].strip(' \t\r') == '':
        k += 1
    res = res[k:]
    body = '\n'.join(res)
    body = body.rstrip(' \t\r\n\f\v')
    if ended_lf and body:
        body += '\n'
    return body


# ----------------------------------------------------------------------------
# masking of non-prose regions
# ----------------------------------------------------------------------------

def line_starts(text):
    starts = [0]
    for m in re.finditer('\n', text):
        starts.append(m.end())
    return starts


FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
BADGE_RE = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
IMG_ONLY_RE = re.compile(r'^\s*(?:!\[[^\]\n]*\]\([^)\n]*\)\s*)+$')


def compute_mask(text):
    """Return a bytearray, 1 where the character is in a non-prose region."""
    n = len(text)
    mask = bytearray(n)
    lines = text.split('\n')
    offs = []
    pos = 0
    for ln in lines:
        offs.append(pos)
        pos += len(ln) + 1
    L = len(lines)

    def mark_lines(a, b):  # lines a..b inclusive
        s = offs[a]
        e = offs[b] + len(lines[b])
        for k in range(s, min(e, n)):
            mask[k] = 1

    # front matter
    i = 0
    if L and lines[0].rstrip() == '---':
        for j in range(1, L):
            if lines[j].rstrip() in ('---', '...'):
                mark_lines(0, j)
                i = j + 1
                break
    fenced = [False] * L
    for k in range(min(i, L)):
        fenced[k] = True
    # fences
    while i < L:
        m = FENCE_OPEN.match(lines[i].rstrip('\r'))
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            close = re.compile(r'^ {0,3}' + re.escape(ch) + '{' + str(ln) + r',}[ \t]*$')
            j = i + 1
            end = L - 1
            while j < L:
                if close.match(lines[j].rstrip('\r')):
                    end = j
                    break
                j += 1
            mark_lines(i, end)
            for k in range(i, end + 1):
                fenced[k] = True
            i = end + 1
        else:
            i += 1
    # blockquote runs, tables, badges
    i = 0
    while i < L:
        if fenced[i]:
            i += 1
            continue
        s = lines[i].lstrip(' ')
        if len(lines[i]) - len(s) <= 3 and s.startswith('>'):
            j = i
            while j + 1 < L and not fenced[j + 1] and lines[j + 1].lstrip(' ').startswith('>') \
                    and len(lines[j + 1]) - len(lines[j + 1].lstrip(' ')) <= 3:
                j += 1
            if j > i:
                mark_lines(i, j)
            i = j + 1
            continue
        st = lines[i].strip()
        if st.startswith('|') and st.count('|') >= 2:
            mark_lines(i, i)
        elif st and (BADGE_RE.match(lines[i]) or IMG_ONLY_RE.match(lines[i])):
            mark_lines(i, i)
        i += 1
    # inline code spans (not across blank lines)
    blank_pos = [m.start() for m in re.finditer(r'\n[ \t\r]*\n', text)]
    runs = []
    for m in re.finditer(r'`+', text):
        if mask[m.start()]:
            continue
        runs.append((m.start(), m.end(), m.end() - m.start()))
    bylen = {}
    for idx, r in enumerate(runs):
        bylen.setdefault(r[2], []).append(idx)
    ptrs = {}
    idx = 0
    consumed_to = -1
    from bisect import bisect_left
    while idx < len(runs):
        s, e, ln = runs[idx]
        if s < consumed_to:
            idx += 1
            continue
        lst = bylen[ln]
        p = bisect_right(lst, idx)
        found = None
        if p < len(lst):
            j = lst[p]
            # no blank line between
            b = bisect_left(blank_pos, e)
            if not (b < len(blank_pos) and blank_pos[b] < runs[j][0]):
                found = j
        if found is not None:
            a = s
            bnd = runs[found][1]
            for k in range(a, bnd):
                mask[k] = 1
            consumed_to = bnd
        idx += 1
    return mask


def apply_mask(text, mask):
    if not any(mask):
        return text
    out = []
    n = len(text)
    i = 0
    while i < n:
        if mask[i]:
            j = i
            while j < n and mask[j]:
                j += 1
            seg = text[i:j]
            out.append(''.join('\n' if c == '\n' else '§' for c in seg))
            i = j
        else:
            j = i
            while j < n and not mask[j]:
                j += 1
            out.append(text[i:j])
            i = j
    return ''.join(out)


# ----------------------------------------------------------------------------
# text helpers
# ----------------------------------------------------------------------------

WORD_RE = re.compile(r"[\w'’-]+")
SENT_SPLIT = re.compile(r'(?<=[.!?])["\'’”)\]]*\s+|\n\s*\n|\n(?=\s*(?:[-*+]\s|\d+[.)]\s|#{1,6}\s))')


def words_of(s):
    return [w for w in WORD_RE.findall(s) if any(c.isalnum() for c in w)]


def split_sentences(text):
    out = []
    for s in SENT_SPLIT.split(text):
        if s and s.strip():
            out.append(s.strip())
    return out


def split_paragraphs(text):
    return [p for p in re.split(r'\n[ \t\r]*\n', text) if p.strip()]


def cv(values):
    if not values:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return math.sqrt(var) / mean


# ----------------------------------------------------------------------------
# pattern definitions
# ----------------------------------------------------------------------------

A = "['’]"


def alt(*xs):
    return '(?:' + '|'.join(xs) + ')'


RX = {}


def rx(num, slug, label, pattern, flags=re.I):
    RX.setdefault(num, []).append((slug, label, re.compile(pattern, flags)))


AI_VOCAB = [
    r'additionally', r'align(?:s|ed|ing)?\s+with', r'crucial', r'delv(?:e|es|ed|ing)',
    r'tapestr(?:y|ies)', r'pivotal', r'vibrant', r'meticulous(?:ly)?', r'testament',
    r'underscor(?:e|es|ed|ing)', r'intricate', r'intricacies', r'interplay',
    r'garner(?:s|ed|ing)?', r'bolster(?:s|ed|ing)?', r'foster(?:s|ed|ing)?',
    r'showcas(?:e|es|ed|ing)', r'emphasiz(?:e|es|ed|ing)', r'enduring',
    r'enhanc(?:e|es|ed|ing)', r'leverag(?:e|es|ed|ing)', r'utiliz(?:e|es|ed|ing)',
    r'facilitat(?:e|es|ed|ing)', r'encompass(?:es|ed|ing)?', r'harness(?:es|ed|ing)?',
    r'holistic', r'paradigms?', r'transformative', r'unprecedented', r'myriad', r'plethora',
    r'robust', r'seamless(?:ly)?', r'navigat(?:e|es|ed|ing)', r'embark(?:s|ed|ing)?',
    r'craft(?:s|ed|ing)?', r'landscapes?', r'journeys?', r'realms?', r'multifaceted',
    r'elevat(?:e|es|ed|ing)', r'empower(?:s|ed|ing|ment)?', r'unlock(?:s|ed|ing)?',
    r'captur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic)',
]
rx(1, 'ai_vocabulary', 'AI vocabulary', r'\b' + alt(*AI_VOCAB) + r'\b')

rx(2, 'model_dialect', 'Model-dialect vocabulary',
   r'\b' + alt(
       r'genuinely', r'fascinating', r'nuanced', r'thoughtfully', r'refreshingly', r'strikingly',
       r'compellingly', r'quietly\s+(?:powerful|profound|radical)',
       r'deeply\s+(?:human|personal|felt|unsettling)', r'resonates\s+deeply',
       r'game[- ]chang(?:er|ers|ing)', r'supercharg(?:e|es|ed|ing)',
       r'skyrocket(?:s|ed|ing)?', r'turbocharg(?:e|es|ed|ing)',
       r'revolutioniz(?:e|es|ed|ing)', r'doubl(?:e|es|ed|ing)\s+down\s+on',
       r'div(?:e|es|ed|ing)\s+deep(?:er)?\s+into',
       r'unlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)',
       r'tak(?:e|es|ing)\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level',
   ) + r'\b')

rx(3, 'promotional_language', 'Promotional language',
   r'\b' + alt(
       r'nestled', r'breathtaking', r'must-visit', r'stunning', r'picturesque', r'charming',
       r'idyllic', r'vibrant\s+community', r'rich\s+cultural\s+heritage', r'in\s+the\s+heart\s+of',
       r'world-class', r'top-tier', r'unparalleled', r'premier', r'leading',
       r'esteemed\s+organi[sz]ation', r'valuable\s+asset', r'passion\s+for\s+excellence',
       r'proven\s+track\s+record', r'results-oriented', r'wealth\s+of\s+experience',
       r'dynamic\s+team', r'fast-paced\s+environment', r'deeply\s+passionate',
       r'perfectly\s+situated', r'(?:close|tight)-knit\s+team',
       r'I\s+am\s+excited\s+to\s+(?:apply|bring)', r'uniquely\s+positioned\s+to',
   ) + r'\b')

rx(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse',
   r'\b' + alt(
       r'results-driven', r'cutting-edge', r'state-of-the-art', r'best-in-class', r'data-driven',
       r'forward-thinking', r'game-changing', r'next-generation', r'end-to-end', r'high-quality',
       r'customer-centric', r'mission-critical', r'thought-provoking', r'well-rounded',
       r'detail-oriented', r'hands-on', r'fast-growing', r'ever-evolving', r'ever-changing',
       r'world-renowned', r'time-tested', r'cross-functional', r'value-added', r'future-proof',
       r'user-friendly', r'full-service', r'one-stop', r'groundbreaking', r'award-winning',
       r'tech-savvy', r'client-focused', r'team-oriented', r'self-motivated', r'highly-skilled',
   ) + r'\b')

rx(5, 'simple_yet', '"Simple yet X" cliché',
   r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')

rx(10, 'significance_inflation', 'Significance inflation',
   r'\b(?:' + alt(
       r'(?:stand(?:s|ing)?|stood|serv(?:es?|ed|ing))\s+as\s+(?:a|an|the)\s+(?:\w+\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)',
       r'(?:underscor|highlight)(?:es|ed|ing|s|e)\s+(?:its|the|their|his|her)\s+(?:\w+\s+)?(?:importance|significance|enduring|central|vital|crucial|pivotal|key)',
       r'reflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)',
       r'mark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)',
       r'symboliz(?:e|es|ed|ing)',
       r'sets?\s+the\s+stage\s+for',
       r'left\s+an\s+indelible\s+mark',
       r'play(?:s|ed|ing)?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role',
       r'has\s+(?:shaped|sparked)',
       r'has\s+come\s+to\s+(?:define|symbolize)',
   ) + r')\b')

rx(11, 'notability_name_dropping', 'Notability name-dropping',
   r'\b(?:' + alt(
       r'(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+(?-i:[A-Z][\w&.\'’-]*(?:\s+[A-Z][\w&.\'’-]*)*(?:,\s*(?:and\s+)?|\s+and\s+)[A-Z])',
       r'\d[\d,.]*\s*[kKmM]?\s+(?:followers|subscribers)',
       r'(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence',
       r'widely\s+covered', r'independent\s+coverage',
   ) + r')')

rx(12, 'vague_attributions', 'Vague attributions',
   r'\b' + alt(
       r'experts?\s+(?:argue|believe|say|claim|note|suggest)',
       r'industry\s+(?:reports|observers|analysts)',
       r'observers\s+have\s+(?:cited|noted)', r'some\s+critics\s+argue',
       r'researchers\s+have\s+found', r'studies\s+suggest', r'it\s+is\s+widely\s+believed',
   ) + r'\b')

rx(13, 'article_title_proper_noun', 'Article title treated as a proper noun',
   r'\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+[^.!?\n]{1,80}?\s+(?:is|are)\s+(?:a|an|the)\b')

rx(14, 'ecosystem_padding', 'Conservation / ecosystem padding',
   r'\b' + alt(
       r'plays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem',
       r'conservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)',
       r'serves\s+as\s+an\s+indicator\s+species', r'contributes?\s+to\s+biodiversity',
   ))

rx(15, 'false_range', 'False range',
   r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b')

rx(16, 'ing_tail', 'Superficial -ing tail clauses',
   r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')

rx(17, 'negative_parallelism', 'Negative parallelism (it\'s not just X, it\'s Y)',
   r'\bit' + A + r's\s+not\s+(?:just|merely)\s+(?:about|a|an)\b|\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b|\bdoesn' + A + r't\s+just\b[^,.\n]{0,40}?\bit\b')
rx(17, 'tailing_negation', 'Tailing negation ("..., no fluff")',
   r',\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b')

rx(18, 'not_x_just_y', '"Not X, just Y" construction',
   r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+|\b(?:not|isn' + A + r't|aren' + A + r't|wasn' + A + r't|weren' + A + r't)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+(?:,|\s*[—–-]+)\s*(?:it' + A + r's|it\s+is|it\s+was|they' + A + r're|they\s+are|they\s+were|that' + A + r's|but)\b')

rx(19, 'filler_phrases', 'Filler phrases',
   r'\b' + alt(r'in\s+order\s+to', r'due\s+to\s+the\s+fact\s+that', r'at\s+this\s+point\s+in\s+time',
               r'in\s+the\s+event\s+that', r'has\s+the\s+ability\s+to',
               r'it\s+is\s+important\s+to\s+note\s+that', r'it\s+should\s+be\s+mentioned\s+that',
               r'needless\s+to\s+say') + r'\b')

rx(20, 'empty_pivots', 'Empty pivot phrases',
   r'\b' + alt(r'it' + A + r's\s+worth\s+(?:noting|mentioning)\s+that', r'it\s+is\s+worth\s+(?:noting|mentioning)\s+that',
               r'it\s+bears\s+(?:noting|mentioning)\s+that',
               r'one\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is',
               r'it\s+is\s+interesting\s+to\s+note\s+that', r'a\s+key\s+consideration\s+is',
               r'a\s+point\s+to\s+highlight\s+is') + r'')

rx(21, 'outcome_speculation', 'Outcome-speculation tails',
   r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward)\b')

rx(22, 'authority_tropes', 'Persuasive authority tropes',
   r'\b' + alt(r'here' + A + r's\s+the\s+thing', r'make\s+no\s+mistake', r'the\s+truth\s+is',
               r'let' + A + r's\s+be\s+honest', r'the\s+simple\s+fact\s+is', r'at\s+its\s+core',
               r'what\s+really\s+matters', r'more\s+than\s+anything', r'at\s+the\s+end\s+of\s+the\s+day',
               r'the\s+bottom\s+line\s+is', r'in\s+reality', r'fundamentally,', r'the\s+real\s+question\s+is',
               r'the\s+heart\s+of\s+the\s+matter', r'the\s+deeper\s+issue', r'when\s+you\s+get\s+down\s+to\s+it',
               r'when\s+all\s+is\s+said\s+and\s+done'))

rx(23, 'editorial_interjections', 'Editorial interjections',
   r'\b' + alt(r'it' + A + r's\s+important\s+to\s+(?:remember|note|understand|recognize)',
               r'it\s+is\s+important\s+to\s+(?:remember|note|understand|recognize)',
               r'one\s+must\s+note\s+that', r'it\s+is\s+worth\s+pointing\s+out',
               r'it\s+cannot\s+be\s+overstated\s+that', r'it\s+must\s+be\s+emphasized\s+that'))

rx(24, 'self_thoroughness', 'Self-thoroughness phrases',
   r'\b' + alt(r'this\s+comprehensive\s+(?:guide|overview|analysis)',
               r'this\s+in-depth\s+(?:analysis|look|examination)',
               r'this\s+complete\s+(?:guide|overview)', r'a\s+thorough\s+examination\s+of',
               r'everything\s+you\s+need\s+to\s+know\s+about') + r'\b')

rx(26, 'concrete_evidence', '"Concrete evidence" defense phrase',
   r'\b' + alt(r'without\s+concrete\s+evidence', r'do\s+you\s+have\s+concrete\s+evidence',
               r'I\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)(?:\s+to)?',
               r'absent\s+concrete\s+proof', r'provide\s+concrete\s+evidence') + r'\b')

rx(27, 'intro_hooks', 'Compulsive intro hooks',
   r'\b' + alt(r'in\s+today' + A + r's\s+(?:[\w-]+\s+){0,2}(?:world|landscape|environment|market)',
               r'in\s+a\s+world\s+where', r'in\s+an\s+era\s+of', r'in\s+recent\s+years,',
               r'more\s+than\s+ever\s+before', r'we\s+live\s+in\s+a\s+(?:time|world)\s+when',
               r'(?:great|exciting|big)\s+news\s*[!:]',
               r'ever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]*\?',
               r'in\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world'))

rx(30, 'diff_anchored', 'Diff-anchored writing',
   r'\b' + alt(r'unlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)',
               r'(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)',
               r'(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to',
               r'previously\b[^.!?\n]{0,120}?\bnow\b',
               r'(?:wasn' + A + r't|weren' + A + r't)\s+there\s+before',
               r'we(?:' + A + r'|\s+ha)ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)'))

rx(31, 'signposting', 'Signposting and announcements',
   r'\b' + alt(r'let' + A + r's\s+(?:dive|delve|explore)', r'let' + A + r's\s+break\s+(?:this|it)\s+down',
               r'here' + A + r's\s+what\s+you\s+need\s+to\s+know', r'without\s+further\s+ado',
               r'now\s+let' + A + r's\s+look\s+at', r'buckle\s+up', r'stay\s+with\s+me',
               r'(?:are\s+you\s+)?ready\s+to\s+dive\s+in'))

rx(32, 'cataloguing_leadins', 'Cataloguing lead-ins',
   r'\b' + alt(r'(?:used|uses|employs?|employed|relied\s+on|relies\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+',
               r'(?:is|are|was|were|remains?|becomes?)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of') )
rx(32, 'cataloguing_these', 'Cataloguing lead-ins (These ...)',
   r'(?:^|(?<=[.!?]\s)|(?<=\n))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insight|insights|understanding|details|data)\b',
   re.M)

rx(33, 'inline_header_lists', 'Inline-header vertical lists',
   r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)', re.M)

rx(36, 'formulaic_challenges', 'Formulaic challenges section',
   r'\b' + alt(r'despite\s+(?:these|its|the)\s+(?:challenges|obstacles)',
               r'challenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)',
               r'continues\s+to\s+thrive', r'typical\s+of\s+(?:emerging|urban|modern)',
               r'faces\s+(?:several|many|numerous)\s+challenges'))

rx(38, 'compulsive_conclusions', 'Compulsive conclusion phrases',
   r'^[ \t#>*_-]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b', re.M | re.I)

rx(39, 'generic_positive_conclusions', 'Generic positive conclusions',
   r'\b' + alt(r'the\s+future\s+looks\s+bright', r'exciting\s+times\s+lie\s+ahead',
               r'journey\s+toward\s+excellence', r'step\s+in\s+the\s+right\s+direction',
               r'(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright',
               r'well[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)'))

rx(47, 'chatbot_artifacts', 'Chatbot artifacts',
   r'\b' + alt(
       r'I\s+hope\s+this\s+helps', r'Certainly!', r'Of\s+course!', r'let\s+me\s+know\s+if\s+you',
       r'would\s+you\s+like\s+me\s+to', r'feel\s+free\s+to\s+(?:ask|reach\s+out)',
       r'happy\s+to\s+help\s*[.!]', r'(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)',
       r'here\s+are\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)',
       r'here' + A + r's\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)',
       r'here\s+(?:is|' + A + r's)\s+a\s+draft', r'depending\s+on\s+the\s+(?:vibe|tone|style)',
       r'I\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well',
       r'as\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
       r'to\s+(?:answer|address)\s+your\s+question', r'in\s+(?:response|answer)\s+to\s+your\s+question',
       r'your\s+question\s+(?:about|regarding|concerning)',
       r'as\s+(?:you\s+)?(?:requested|asked),\s+here',
       r'here\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)')
   )

rx(48, 'sycophantic_tone', 'Sycophantic tone',
   r'\b(?:you(?:' + A + r're|\s+are)\s+absolutely\s+right|(?:great\s+question|excellent\s+point)\s*[!.,]|what\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\s*[!.,]|that' + A + r's\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\s*[!.,])')

rx(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers',
   r'\b' + alt(r'as\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)', r'up\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)',
               r'while\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)',
               r'based\s+on\s+(?:the\s+)?available\s+information', r'as\s+of\s+my\s+(?:knowledge\s+)?cutoff',
               r'maintains\s+a\s+low\s+profile', r'keeps\s+(?:his|her|their)\s+personal\s+life\s+private'))

rx(51, 'copula_avoidance', 'Copula avoidance',
   r'\b' + alt(r'(?:serves|stands|functions|acts)\s+as', r'(?:represents|marks)\s+(?:a|the)\b',
               r'boasts?', r'features\s+(?:a|an|the|\d+|several|many|numerous|various|multiple|some|two|three|four|five)',
               r'offers\s+a', r'refers\s+to') + r'\b')

rx(56, 'boldface_overuse', 'Boldface overuse', r'\*\*[^*\n]+?\*\*')

rx(57, 'emoji', 'Emojis',
   '[\U0001F000-\U0001FAFF☀-➿⭐⭕⌚⌛⏩-⏳⤴⤵⬅-⬇⬛⬜]')

rx(60, 'curly_quotes', 'Curly quotation marks', '[‘’“”]')

rx(61, 'year_range_hyphen', 'Hyphen for en dash in year ranges', r'\b(?:1[0-9]{3}|20[0-9]{2})-(?:1[0-9]{3}|20[0-9]{2})\b')

rx(63, 'placeholder_text', 'Placeholder / Mad-Libs text',
   r'\[\s*(?:(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\[\]\n]{0,60}|[^\[\]\n]{0,40}?\b(?:name|person|company|client|city|place|location|source|recipient|employer|organi[sz]ation)\b[^\[\]\n]{0,40})\](?![(\[])|\{\{[^{}\n]{1,80}\}\}|\blorem\s+ipsum\b|\b[xX]{3,}\b')
# bracketed all-caps slots handled separately in code (need exclusion of short labels)
ALLCAPS_SLOT = re.compile(r'\[([A-Z][A-Z0-9 _/-]{1,40})\](?![(\[])')
SHORT_LABEL = re.compile(r'^[A-Z]{1,2}[0-9]{0,3}$|^[A-Z][0-9]+$')

rx(64, 'chat_reference_markup', 'Chatbot reference-markup leak',
   r'\b(?:cite(?:turn|start|nav)\w*|oai_citation\w*|contentReference|navlist)|【\d+†[^】]*】', 0)
rx(64, 'chat_reference_markup', 'Chatbot reference-markup leak',
   r'(?:^|(?<=\s))(?:cite(?:turn|start|nav)\w*)', re.I)

UTM_RE = re.compile(r'utm_source=([A-Za-z0-9._-]+)', re.I)
UTM_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
             'copilot.microsoft.com', 'poe.com'}

rx(69, 'marketing_slop', 'Canonical marketing-slop phrases',
   r'\b' + alt(r'unlocking\s+(?:its\s+|their\s+|your\s+|the\s+)?full\s+potential',
               r'navigating\s+the\s+complexities', r'a\s+testament\s+to\s+the\s+(?:power|importance)',
               r'staying\s+ahead\s+of\s+the\s+curve', r'turning\s+challenges\s+into\s+opportunities',
               r'taking\s+\w+\s+to\s+the\s+next\s+level', r'harnessing\s+the\s+power\s+of',
               r'paving\s+the\s+way\s+for', r'saying\s+goodbye\s+to', r'imagining\s+a\s+world\s+where',
               r'unleashing\s+the\s+power\s+of', r'redefining\s+the\s+way', r'at\s+the\s+forefront\s+of',
               r'revolutionizing\s+the\s+way', r'embracing\s+the\s+future') )

TRANSITIONS = ('Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless',
               'Consequently', 'Subsequently', 'Notably')
IMPERATIVES = set('install join grab download try discover experience escape transform reclaim unlock elevate boost say imagine explore meet introducing upgrade claim unleash supercharge level stop start'.split())

SYN_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'organisation', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
IRREG_PLURAL = {'company': 'companies', 'technology': 'technologies', 'strategy': 'strategies',
                'study': 'studies', 'difficulty': 'difficulties', 'analysis': 'analyses',
                'hero': 'heroes', 'business': 'businesses', 'enemy': 'enemies',
                'investigation': 'investigations'}
SYN_RES = []
for _cl in SYN_CLUSTERS:
    _members = []
    for _m in _cl:
        forms = [_m]
        if _m in IRREG_PLURAL:
            forms.append(IRREG_PLURAL[_m])
        else:
            forms.append(_m + 's')
            forms.append(_m + 'es')
        _members.append((_m, re.compile(r'\b(?:' + '|'.join(re.escape(f) for f in forms) + r')\b', re.I)))
    SYN_RES.append(_members)

ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial',
              'ary', 'ory', 'ish')
STOCK_ADJ = set('stunning innovative powerful seamless sleek modern dynamic elegant robust flexible scalable reliable secure fast efficient beautiful vibrant intuitive comprehensive cutting-edge'.split())
ADJ_CHAIN = re.compile(r"\b(?:[A-Za-z-]{2,},\s+){2,}(?:and\s+)?[A-Za-z-]{2,}\s+[A-Za-z-]{2,}\b")
NOT_NOUN = set('is are was were be been am to of in on at by for with and or but the a an it its that this these those they he she we you i his her their our your not no as if so than then who whom whose which what when where why how can could will would should may might must do does did has have had'.split())


def is_adjectival(w):
    w = w.lower()
    return w in STOCK_ADJ or any(w.endswith(s) and len(w) > len(s) + 1 for s in ADJ_SUFFIX)


# ----------------------------------------------------------------------------
# families that are not plain regexes
# ----------------------------------------------------------------------------

def sample_of(m, text):
    s = m.group(0).replace('\n', ' ').strip()
    if len(s) > 80:
        s = s[:77] + '...'
    return s


def excerpt(text, m):
    a = max(0, m.start() - 24)
    b = min(len(text), m.end() + 24)
    s = text[a:b].replace('\n', ' ').replace('\r', ' ')
    if a > 0:
        s = '...' + s
    if b < len(text):
        s = s + '...'
    return s


def run_regex_family(num, text, orig):
    results = []
    for slug, label, pat in RX[num]:
        ms = list(pat.finditer(text))
        if num == 64:
            continue
        if not ms:
            continue
        if num == 1:
            samples = [excerpt(orig, m) for m in ms[:3]]
        else:
            samples = [sample_of(m, text) for m in ms[:3]]
        results.append((slug, label, len(ms), samples))
    return results


def f_chatref(text, orig):
    ms = []
    for m in re.finditer(r'\b(?:cite(?:turn|start|nav)\w*|oai_citation\w*|contentReference|navlist)|【\d+†[^】]*】', text):
        ms.append(m)
    if not ms:
        return []
    return [('chat_reference_markup', 'Chatbot reference-markup leak', len(ms), [sample_of(m, text) for m in ms[:3]])]


def f_placeholder(text, orig):
    ms = []
    pat = RX[63][0][2]
    ms.extend(pat.finditer(text))
    for m in ALLCAPS_SLOT.finditer(text):
        inner = m.group(1).strip()
        if SHORT_LABEL.match(inner):
            continue
        if re.fullmatch(r'[A-Z]{1,3}', inner):
            continue
        ms.append(m)
    if not ms:
        return []
    return [('placeholder_text', 'Placeholder / Mad-Libs text', len(ms), [sample_of(m, text) for m in ms[:3]])]


def f_utm(text, orig):
    ms = []
    for m in UTM_RE.finditer(text):
        host = m.group(1).rstrip('.').lower()
        if host in UTM_HOSTS:
            ms.append(m)
    if not ms:
        return []
    return [('ai_tracking_params', 'AI tracking parameters', len(ms), [sample_of(m, text) for m in ms[:3]])]


def f_synonym(text, orig):
    for cl in SYN_RES:
        present = []
        total = 0
        for name, pat in cl:
            c = len(pat.findall(text))
            if c:
                present.append(name)
                total += c
        if len(present) >= 3:
            return [('synonym_cycling', 'Synonym cycling', total, [', '.join(present)])]
    return []


def f_promo_imperative(sents):
    c = 0
    ex = []
    for s in sents:
        m = re.match(r"[\W_]*([A-Za-z]+)", s)
        if m and m.group(1).lower() in IMPERATIVES and m.group(1)[0].isupper():
            c += 1
            if len(ex) < 3:
                ex.append(s[:60])
    return c, ex


def f_adj_chain(text):
    hits = []
    for m in ADJ_CHAIN.finditer(text):
        s = m.group(0)
        words = re.findall(r"[A-Za-z-]+", s)
        if len(words) < 4 or words[0].lower() in ('and',):
            continue
        last = words[-1].lower()
        if last in NOT_NOUN or last.endswith('ly') or is_adjectival(last):
            continue
        chain = [w for w in words[:-1] if w.lower() != 'and']
        if not any(is_adjectival(w) for w in chain):
            continue
        if any(w.lower() in NOT_NOUN for w in chain):
            continue
        hits.append(s)
    if hits:
        return [('stacked_adjectives', 'Stacked adjective chains', len(hits), [h.replace('\n', ' ')[:80] for h in hits[:3]])]
    return []


def f_transitions(paras):
    hits = 0
    ex = []
    for p in paras:
        sents = split_sentences(p)
        c = 0
        for s in sents:
            m = re.match(r'[\W_]*([A-Za-z]+)', s)
            if m and m.group(1) in TRANSITIONS:
                c += 1
        if c >= 2:
            hits += c
            if len(ex) < 3:
                ex.append(p[:60].replace('\n', ' '))
    if hits:
        return [('transition_clusters', 'Transition cluster overuse', hits, ex)]
    return []


def f_questions(text):
    pat = re.compile(r'\b(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|Has|Have|Had|May|Might|Must|Isn' + A + r't|Aren' + A + r't|Don' + A + r't|Doesn' + A + r't|Won' + A + r't)\b[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Certainly|Sometimes)[.!](?=\s|$)')
    ms = list(pat.finditer(text))
    if ms:
        return [('question_answer', 'Question-answer rhetorical pattern', len(ms), [sample_of(m, text) for m in ms[:3]])]
    return []


def f_bullet_injection(text, paras):
    if re.search(r'^[ \t]{0,3}#{1,6}[ \t]', text, re.M):
        return []
    if re.search(r'^[^\n]+\n[ \t]{0,3}(?:=+|-+)[ \t]*$', text, re.M) and False:
        return []
    listp = 0
    prose = 0
    li = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S')
    for p in paras:
        lines = [l for l in p.split('\n') if l.strip()]
        if not lines:
            continue
        if all(li.match(l) for l in lines):
            listp += 1
        elif not all(set(l.strip()) <= set('§') for l in lines):
            prose += 1
    if listp >= 1 and prose >= 2:
        return [('bullet_injection', 'Mid-essay bullet injection', listp, ['list paragraph amid prose'])]
    return []


def f_fragment_headers(text):
    lines = text.split('\n')
    hits = []
    for i, l in enumerate(lines):
        m = re.match(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t#]*$', l)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(?:#|[-*+]\s|\d+[.)]\s|\||>|§)', nxt):
            continue
        nw = words_of(nxt)
        if not nw or len(nw) > 5:
            continue
        hw = set(w.lower() for w in words_of(m.group(1)) if len(w) > 2)
        if any(w.lower().strip("'’-") in hw for w in nw if len(w) > 2):
            hits.append(m.group(1))
    if hits:
        return [('fragmented_headers', 'Fragmented headers', len(hits), hits[:3])]
    return []


MINOR = set('a an the and but or nor for so yet at by in of on to up as off out per via vs from with into over onto upon than'.split())


def f_title_case(text):
    hits = []
    for m in re.finditer(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t#]*$', text, re.M):
        h = m.group(1).strip()
        toks = h.split()
        if len(toks) < 3:
            continue
        if not h[0].isalpha():
            continue
        letters = [c for c in h if c.isalpha()]
        if letters and all(c.isupper() for c in letters):
            continue
        major = [t for t in toks if t.strip('.,:;!?()"\'*_').lower() not in MINOR]
        if len(major) < 2:
            continue
        ok = True
        for t in major:
            a = next((c for c in t if c.isalpha()), None)
            if a is None or not a.isupper():
                ok = False
                break
        if ok:
            hits.append(h)
    if hits:
        return [('title_case_headings', 'Title case in headings', len(hits), hits[:3])]
    return []


def f_hedges(sents):
    hedge = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly|seems?\s+(?:to|like)|appears?\s+to|kind\s+of|sort\s+of)\b')
    hits = 0
    ex = []
    for s in sents:
        c = len(hedge.findall(s))
        if c >= 2:
            hits += 1
            if len(ex) < 3:
                ex.append(s[:80].replace('\n', ' '))
    if hits:
        return [('hedge_stacking', 'Hedge stacking', hits, ex)]
    return []


def f_opener_repetition(paras):
    hits = 0
    ex = []
    for p in paras:
        sents = split_sentences(p)
        if len(sents) < 3:
            continue
        counts = {}
        for s in sents:
            w = [x.lower() for x in words_of(s)[:2]]
            if len(w) == 2:
                counts[tuple(w)] = counts.get(tuple(w), 0) + 1
        for k, v in counts.items():
            if v >= 3:
                hits += 1
                if len(ex) < 3:
                    ex.append(' '.join(k))
    if hits:
        return [('opener_repetition', 'Opener repetition', hits, ex)]
    return []


def f_em_dash(paras):
    hits = 0
    ex = []
    for p in paras:
        c = p.count('—')
        if c >= 2:
            hits += c
            if len(ex) < 3:
                ex.append(p[:60].replace('\n', ' '))
    if hits:
        return [('em_dash_overuse', 'Em-dash overuse', hits, ex)]
    return []


def f_monotony(sents):
    lens = [len(words_of(s)) for s in sents]
    lens = [l for l in lens if l > 0]
    if len(lens) < 3:
        return []
    c = cv(lens)
    if c is not None and c < 0.35:
        return [('sentence_length_monotony', 'Sentence-length monotony', len(lens), ['coefficient of variation %.2f' % c])]
    return []


def f_alternation(sents):
    lens = [len(words_of(s)) for s in sents]
    lens = [l for l in lens if l > 0]
    best = 0
    i = 0
    n = len(lens)
    # runs of >=6 sentences going up and down
    start = 0
    runs = 0
    while start < n - 5:
        j = start
        while j + 2 < n and ((lens[j + 1] - lens[j]) * (lens[j + 2] - lens[j + 1]) < 0):
            j += 1
        length = j - start + 2 if j > start or (start + 1 < n) else 1
        # compute proper run length
        k = start + 1
        while k + 1 < n and ((lens[k] - lens[k - 1]) * (lens[k + 1] - lens[k]) < 0):
            k += 1
        runlen = k - start + 1
        if runlen >= 6:
            seg = lens[start:start + runlen]
            diffs = [abs(seg[x + 1] - seg[x]) for x in range(len(seg) - 1)]
            if diffs and sum(diffs) / len(diffs) >= 5 and min(diffs) >= 3:
                runs += 1
            start = start + runlen
        else:
            start += 1
    if runs:
        return [('mechanical_alternation', 'Mechanical sentence-length alternation', runs, ['alternating long/short sentences'])]
    return []


def f_uniform_paragraphs(paras):
    lens = [len(words_of(p)) for p in paras]
    lens = [l for l in lens if l > 0]
    if len(lens) < 4:
        return []
    c = cv(lens)
    if c is not None and c < 0.4:
        return [('uniform_paragraphs', 'Uniform paragraph length', len(lens), ['coefficient of variation %.2f' % c])]
    return []


def f_semicolon(text, nwords):
    if nwords < 300:
        return []
    if ';' in text:
        return []
    paren = len(re.findall(r'\([^()\n]{1,200}\)', text))
    if paren <= 1:
        return [('semicolon_paren_underuse', 'Semicolon and parenthesis underuse', 1, ['no semicolons, almost no parentheticals'])]
    return []


FIRST_PERSON = set(['i', 'me', 'my', 'mine', 'myself', 'we', 'us', 'our', 'ours', 'ourselves',
                    "i'm", "i've", "i'll", "i'd", "we're", "we've", "we'll", "we'd",
                    'i’m', 'i’ve', 'i’ll', 'i’d', 'we’re', 'we’ve', 'we’ll', 'we’d'])
UNCONTRACTED = re.compile(r'\b(?:(?:do|does|did|is|are|was|were|have|has|had|would|could|should|will|can|must)\s+not|(?:it|that|there|he|she|what|who|let)\s+is|I\s+am|(?:I|you|we|they)\s+(?:have|will|would|are|had))\b', re.I)
CONTRACTED = re.compile(r"\b\w+(?:['’](?:t|s|re|ve|ll|d|m))\b", re.I)


def f_contractions(text, wl):
    if not wl:
        return []
    fp = sum(1 for w in wl if w.lower() in FIRST_PERSON)
    if fp / len(wl) < 0.02 or fp < 2:
        return []
    un = len(UNCONTRACTED.findall(text))
    con = 0
    for m in CONTRACTED.finditer(text):
        w = m.group(0).lower().replace('’', "'")
        if w.endswith("'s") and not w.startswith(('it', 'that', 'there', 'he', 'she', 'what', 'who', 'let', 'here', 'where', 'how')):
            continue
        con += 1
    if un >= 3 and un > con:
        return [('contraction_absence', 'Contraction absence', un, ['%d full forms vs %d contractions' % (un, con)])]
    return []


def f_hr(text):
    lines = text.split('\n')
    if len(lines) < 24:
        return []
    c = 0
    for l in lines:
        s = l.strip()
        if re.fullmatch(r'(?:-[ ]*){3,}|(?:\*[ ]*){3,}|(?:_[ ]*){3,}', s) and len(l) - len(l.lstrip()) <= 3:
            c += 1
    if c >= 3:
        return [('decorative_rules', 'Decorative horizontal rules', c, ['%d horizontal rules' % c])]
    return []


def f_repetition(wl):
    w = [x.lower() for x in wl]
    n = len(w) - 5
    if n < 12:
        return []
    counts = {}
    grams = []
    for i in range(n):
        g = tuple(w[i:i + 6])
        grams.append(g)
        counts[g] = counts.get(g, 0) + 1
    rep = sum(1 for g in grams if counts[g] > 1)
    if rep >= 6 and rep / n >= 0.2:
        return [('degenerate_repetition', 'Degenerate repetition', rep, ['%.0f%% of six-word runs repeat' % (100.0 * rep / n)])]
    return []


def f_trailing_ws(text):
    c = 0
    lines = text.split('\n')
    nl = len(lines)
    for idx, l in enumerate(lines):
        body = l[:-1] if l.endswith('\r') else l
        if body != body.rstrip(' \t') and idx < nl - 1:
            c += 1
    last = lines[-1]
    lastbody = last[:-1] if last.endswith('\r') else last
    if lastbody and lastbody != lastbody.rstrip(' \t'):
        c += 1
    t = text.rstrip(' \t')
    if text.endswith('\n\n') or re.search(r'\n[ \t\r]*\n[ \t\r]*$', text):
        c += 1
    if text and text[0] in ' \t\n\r\f\v':
        c += 1
    if c:
        return [('trailing_whitespace', 'Trailing / stray whitespace', c, ['stray whitespace'])]
    return []


# ----------------------------------------------------------------------------
# scoring
# ----------------------------------------------------------------------------

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 44}
EARLY = set(range(1, 40)) | set(range(47, 52)) | {69}
BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return 'pervasive tells'


def confidence_of(nwords, nfam):
    if nwords < 40:
        return 'none', 'under 40 words: too little text for a meaningful score'
    if nwords < 120:
        return 'low', 'under 120 words: short text, score is a rough guide'
    if nwords < 300:
        if nfam <= 1:
            return 'low', 'under 300 words with only one score-moving pattern family'
        return 'moderate', 'under 300 words: moderate sample size'
    return 'high', ''


def compute_score(fam_counts, nwords):
    """fam_counts: {catalogue number: hit count} for score-moving families."""
    fams = set(fam_counts)
    conf, reason = confidence_of(nwords, len(fams))
    pts = 0
    for n, c in fam_counts.items():
        if n in DECISIVE:
            w = 22
        elif n in RHYTHM:
            w = 8
        else:
            w = 14
        pts += w + 3 * min(max(c, 1) - 1, 4)
    score = min(100, pts)
    if fams and fams <= RHYTHM:
        score = min(score, 40)
    if fams == {40}:
        score = min(score, 20)
    dec = fams & DECISIVE
    if len(fams) == 1:
        score = min(score, 40)
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf not in ('none', 'low'):
        score = max(score, 45)
    if nwords < 120:
        e = len(fams & EARLY)
        if e >= 3:
            score = max(score, 45)
        elif e >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if len(fams) >= 6:
            score = max(score, 45)
        elif len(fams) >= 5:
            score = max(score, 25)
    return int(max(0, min(100, score))), conf, reason


def collect_findings(window, wn):
    """window: normalised scan window text. Returns (findings list, nwords, nsents, char counts)."""
    mask = compute_mask(wn)
    m = apply_mask(wn, mask)
    wl = words_of(m)
    nwords = len(wl)
    paras = split_paragraphs(m)
    sents = split_sentences(m)
    findings = []  # (num, slug, label, count, samples)

    def add(num, results):
        for slug, label, count, samples in results:
            findings.append((num, slug, label, count, samples))

    for num in sorted(RX):
        if num in (63, 64):
            continue
        add(num, run_regex_family(num, m, wn))
    add(3, [])
    c, ex = f_promo_imperative(sents)
    if c >= 3:
        # merge into promotional language
        existing = [f for f in findings if f[0] == 3]
        if existing:
            f = existing[0]
            findings.remove(f)
            findings.append((3, f[1], f[2], f[3] + c, f[4] + ex[:3 - len(f[4])]))
        else:
            findings.append((3, 'promotional_language', 'Promotional language', c, ex))
    add(6, f_adj_chain(m))
    add(8, f_synonym(m, wn))
    add(25, f_questions(m))
    add(34, f_bullet_injection(m, paras))
    add(35, f_fragment_headers(m))
    add(37, f_transitions(paras))
    add(40, f_monotony(sents))
    add(41, f_alternation(sents))
    add(42, f_opener_repetition(paras))
    add(44, f_uniform_paragraphs(paras))
    add(46, f_semicolon(m, nwords))
    add(54, f_hedges(sents))
    add(55, f_contractions(m, wl))
    add(58, f_em_dash(paras))
    add(59, f_title_case(m))
    add(63, f_placeholder(m, wn))
    add(64, f_chatref(m, wn))
    add(65, f_utm(m, wn))
    add(70, f_hr(m))
    add(71, f_repetition(wl))
    add(68, f_trailing_ws(m))

    # character layer (computed on unmasked window, ignoring masked positions)
    inv, spc = char_layer(wn)
    inv = [i for i in inv if not mask[i]]
    spc = [i for i in spc if not mask[i]]
    runs = [r for r in homoglyph_runs(wn) if not mask[r[0]]]
    hg = sum(1 for a, b in runs for ch in wn[a:b] if ch in LOOK)
    if inv:
        cps = sorted(set('U+%04X' % ord(wn[i]) for i in inv))
        add(62, [('invisible_characters', 'Invisible / zero-width characters', len(inv), cps[:3])])
    if hg:
        ex = [wn[a:b] for a, b in runs[:3]]
        add(66, [('homoglyphs', 'Homoglyph / mixed-script confusables', hg, ex)])
    if spc:
        cps = sorted(set('U+%04X' % ord(wn[i]) for i in spc))
        add(67, [('nonstandard_spaces', 'Non-standard spaces', len(spc), cps[:3])])
    return findings, nwords, len(sents), (len(inv), len(spc), hg), sents


def fam_counts_of(findings):
    fc = {}
    for num, slug, label, count, samples in findings:
        if num in ADVICE:
            continue
        if num == 17 and slug == 'negative_parallelism':
            continue
        fc[num] = fc.get(num, 0) + count
    return fc


def quick_score(text):
    wn = text
    findings, nwords, ns, cl, sents = collect_findings(wn, wn)
    return compute_score(fam_counts_of(findings), nwords)[0]


def interval(sents, nsents):
    if nsents < 4:
        return None
    rng = random.Random(20240601)
    total = sum(len(s) for s in sents)
    reps = 24 if total < 20000 else (10 if total < 80000 else 4)
    scores = []
    for _ in range(reps):
        pick = [sents[rng.randrange(len(sents))] for _ in range(len(sents))]
        scores.append(quick_score(' '.join(pick)))
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
    return lo, hi


def analyze(prose, want_ci):
    truncated = len(prose) > WINDOW
    window = prose[:WINDOW]
    wn = window.replace('\r\n', '\n')
    findings, nwords, nsents, (ninv, nspc, nhg), sents = collect_findings(window, wn)
    fc = fam_counts_of(findings)
    score, conf, reason = compute_score(fc, nwords)
    report = {}
    seen_keys = set()
    for num, slug, label, count, samples in sorted(findings, key=lambda f: (f[0], f[1])):
        key = '%d_%s' % (num, slug)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        report[key] = {'label': label, 'count': int(count), 'samples': [str(s) for s in samples[:3]]}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': ninv,
        'nonstandard_spaces': nspc,
        'homoglyphs': nhg,
        'words': nwords,
        'sentences': nsents,
    }
    if want_ci:
        ci = interval(sents, nsents)
        if ci is None:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (need at least 4)'
        else:
            lo, hi = ci
            lo = min(lo, score)
            hi = max(hi, score)
            metrics['score_ci'] = [lo, hi]
            metrics['score_ci_note'] = 'resampled over sentences (24 draws, fixed seed); the point score is unchanged'
    report['_metrics'] = metrics
    return report


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def fail(msg, code):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')
    sys.stderr.flush()
    return code


def write_out(s):
    data = s.encode('utf-8', errors='replace')
    try:
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()
    except Exception:
        pass


def main(argv):
    clean = False
    ci = False
    operands = []
    dd = False
    for a in argv:
        if dd:
            operands.append(a)
        elif a == '--':
            dd = True
        elif a in ('--help', '-h'):
            write_out(USAGE)
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            return fail('unknown option: %s (see --help)' % a, 2)
        else:
            operands.append(a)
    if len(operands) >= 2:
        sys.stderr.write('note: only the first file was scanned: %s\n' % operands[0])
    try:
        if operands:
            prose = extract_file(operands[0])
        else:
            data = sys.stdin.buffer.read()
            prose = decode_bytes(data)
    except ReadError as e:
        return fail('cannot read input: %s' % e, 1)
    except Exception as e:
        return fail('cannot read input: %s' % e, 1)
    if not prose or not prose.strip():
        return fail('empty input', 1)
    if clean:
        out = cleanup_text(prose)
        write_out(out)
        return 0
    report = analyze(prose, ci)
    write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except BaseException as e:
        sys.stderr.write(json.dumps({'error': 'cannot read input: internal error: %s' % type(e).__name__}) + '\n')
        code = 1
    sys.exit(code)
