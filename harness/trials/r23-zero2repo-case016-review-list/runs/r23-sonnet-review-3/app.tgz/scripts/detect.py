#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only scan for AI-writing patterns."""
import sys
import os
import re
import io
import json
import time
import random
import unicodedata
import zipfile
import statistics
import html.parser
import xml.etree.ElementTree as ET

WINDOW = 262144
USAGE = ("usage: detect.py [--clean] [--ci] [--] [FILE]\n"
         "\n"
         "  --clean   print scrubbed text (invisible characters removed, spaces normalized,\n"
         "            lookalikes folded, whitespace trimmed) instead of the report\n"
         "  --ci      add a resampled low/high interval on the score\n"
         "  --        stop option parsing so a file name may begin with a dash\n"
         "  FILE      the single file operand; with none, standard input is read\n")

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}
MEMBER_CAP = 64 * 1024 * 1024


class CannotRead(Exception):
    pass


# --------------------------------------------------------------------------
# output helpers
# --------------------------------------------------------------------------
def out(s):
    sys.stdout.flush()
    sys.stdout.buffer.write(s.encode('utf-8', 'replace'))
    sys.stdout.buffer.flush()


def err_obj(msg):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()


# --------------------------------------------------------------------------
# decoding and extraction
# --------------------------------------------------------------------------
def decode_bytes(data):
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    if data[:3] == b'\xef\xbb\xbf':
        return data[3:].decode('utf-8', 'replace')
    return data.decode('utf-8', 'replace')


def _local(tag):
    if '}' in tag:
        return tag.rsplit('}', 1)[1]
    return tag


def _read_member(z, name):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MEMBER_CAP:
        return None
    try:
        return z.read(name)
    except Exception:
        return None


def _parse_xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def _num_key(name):
    nums = re.findall(r'\d+', name)
    return (int(nums[-1]) if nums else 0, name)


def extract_docx(z):
    root = _parse_xml(_read_member(z, 'word/document.xml'))
    if root is None:
        return ''
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        buf = []
        for el in p.iter():
            n = _local(el.tag)
            if n == 't':
                buf.append(el.text or '')
            elif n == 'tab':
                buf.append('\t')
            elif n in ('br', 'cr'):
                buf.append('\n')
        paras.append(''.join(buf))
    return '\n'.join(p for p in paras if p.strip())


def extract_pptx(z):
    names = [n for n in z.namelist() if re.match(r'^ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=_num_key)
    slides = []
    for n in names:
        root = _parse_xml(_read_member(z, n))
        if root is None:
            continue
        paras = []
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            buf = []
            for el in p.iter():
                ln = _local(el.tag)
                if ln == 't':
                    buf.append(el.text or '')
                elif ln == 'br':
                    buf.append('\n')
            s = ''.join(buf)
            if s.strip():
                paras.append(s)
        if paras:
            slides.append('\n'.join(paras))
    return '\n'.join(slides)


def _si_text(si):
    parts = []

    def walk(el, in_ph):
        for ch in el:
            ln = _local(ch.tag)
            if ln == 'rPh':
                continue
            if ln == 't':
                parts.append(ch.text or '')
            else:
                walk(ch, in_ph)
    walk(si, False)
    return ''.join(parts)


def extract_xlsx(z):
    shared = []
    root = _parse_xml(_read_member(z, 'xl/sharedStrings.xml'))
    if root is not None:
        for si in root:
            if _local(si.tag) == 'si':
                shared.append(_si_text(si))
    sheets = []
    wb = _parse_xml(_read_member(z, 'xl/workbook.xml'))
    rels = _parse_xml(_read_member(z, 'xl/_rels/workbook.xml.rels'))
    if wb is not None and rels is not None:
        rmap = {}
        for r in rels:
            rmap[r.get('Id')] = r.get('Target')
        for el in wb.iter():
            if _local(el.tag) == 'sheet':
                rid = None
                for k, v in el.attrib.items():
                    if _local(k) == 'id':
                        rid = v
                tgt = rmap.get(rid)
                if tgt:
                    tgt = tgt.lstrip('/')
                    if not tgt.startswith('xl/'):
                        tgt = 'xl/' + tgt
                    if tgt in z.namelist():
                        sheets.append(tgt)
    if not sheets:
        sheets = [n for n in z.namelist() if re.match(r'^xl/worksheets/[^/]+\.xml$', n)]
        sheets.sort(key=_num_key)
    out_sheets = []
    for sn in sheets:
        root = _parse_xml(_read_member(z, sn))
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            v = None
            isel = None
            for ch in c:
                ln = _local(ch.tag)
                if ln == 'v':
                    v = ch.text or ''
                elif ln == 'is':
                    isel = ch
            txt = None
            if t == 's':
                if v is not None and re.fullmatch(r'\d+', v.strip()):
                    idx = int(v.strip())
                    if idx < len(shared):
                        txt = shared[idx]
            elif t == 'inlineStr':
                if isel is not None:
                    txt = _si_text(isel)
            elif t == 'str':
                txt = v
            if txt is not None and txt.strip():
                cells.append(txt)
        if cells:
            out_sheets.append('\n'.join(cells))
    return '\n'.join(out_sheets)


def _odf_para(el):
    buf = []

    def walk(e):
        if e.text:
            buf.append(e.text)
        for ch in e:
            ln = _local(ch.tag)
            if ln == 's':
                c = 1
                for k, v in ch.attrib.items():
                    if _local(k) == 'c':
                        try:
                            c = max(1, int(v))
                        except ValueError:
                            c = 1
                buf.append(' ' * c)
            elif ln == 'tab':
                buf.append('\t')
            elif ln == 'line-break':
                buf.append('\n')
            elif ln in ('annotation', 'note', 'tracked-changes'):
                pass
            else:
                walk(ch)
            if ch.tail:
                buf.append(ch.tail)
    walk(el)
    return ''.join(buf)


def extract_odf(z):
    root = _parse_xml(_read_member(z, 'content.xml'))
    if root is None:
        return ''
    paras = []

    def walk(e):
        for ch in e:
            ln = _local(ch.tag)
            if ln in ('p', 'h'):
                s = _odf_para(ch)
                if s.strip():
                    paras.append(s)
            else:
                walk(ch)
    walk(root)
    return '\n'.join(paras)


BLOCK_TAGS = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr', 'blockquote',
              'section', 'article', 'ul', 'ol', 'table', 'pre', 'hr', 'dd', 'dt', 'figure',
              'figcaption', 'aside', 'header', 'footer', 'body', 'td', 'th'}
SKIP_TAGS = {'script', 'style', 'nav', 'head', 'title', 'noscript'}


class _Html(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.buf = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower().split(':')[-1]
        if tag in SKIP_TAGS:
            self.skip += 1
        if tag in BLOCK_TAGS:
            self.buf.append('\n')

    def handle_startendtag(self, tag, attrs):
        tag = tag.lower().split(':')[-1]
        if tag in BLOCK_TAGS:
            self.buf.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower().split(':')[-1]
        if tag in SKIP_TAGS and self.skip:
            self.skip -= 1
        if tag in BLOCK_TAGS:
            self.buf.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.buf.append(re.sub(r'\s+', ' ', data))


def _html_text(data):
    try:
        s = data.decode('utf-8', 'replace')
    except Exception:
        return ''
    p = _Html()
    try:
        p.feed(s)
        p.close()
    except Exception:
        pass
    lines = [ln.strip() for ln in ''.join(p.buf).split('\n')]
    return '\n'.join(ln for ln in lines if ln)


def extract_epub(z):
    names = z.namelist()
    order = []
    try:
        cont = _read_member(z, 'META-INF/container.xml')
        m = re.search(rb'full-path\s*=\s*["\']([^"\']+)["\']', cont or b'')
        if m:
            opf_name = m.group(1).decode('utf-8', 'replace')
            opf = (_read_member(z, opf_name) or b'').decode('utf-8', 'replace')
            base = opf_name.rsplit('/', 1)[0] + '/' if '/' in opf_name else ''
            manifest = {}
            for it in re.finditer(r'<(?:\w+:)?item\b([^>]*)>', opf):
                a = it.group(1)
                i = re.search(r'\bid\s*=\s*["\']([^"\']*)["\']', a)
                h = re.search(r'\bhref\s*=\s*["\']([^"\']*)["\']', a)
                if i and h:
                    manifest[i.group(1)] = h.group(1)
            for it in re.finditer(r'<(?:\w+:)?itemref\b([^>]*)>', opf):
                r = re.search(r'\bidref\s*=\s*["\']([^"\']*)["\']', it.group(1))
                if r and r.group(1) in manifest:
                    href = manifest[r.group(1)].split('#')[0]
                    from urllib.parse import unquote
                    full = base + unquote(href)
                    if full in names and full not in order:
                        order.append(full)
    except Exception:
        order = []
    rest = sorted(n for n in names if re.search(r'\.(?:xhtml|html|htm)$', n, re.I) and n not in order)
    parts = []
    for n in order + rest:
        if not re.search(r'\.(?:xhtml|html|htm)$', n, re.I):
            continue
        data = _read_member(z, n)
        if data is None:
            continue
        s = _html_text(data)
        if s.strip():
            parts.append(s)
    return '\n'.join(parts)


def extract_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            continue
        if s.strip():
            parts.append(s.strip())
    return '\n\n'.join(parts)


def load_prose(path):
    """Return extracted prose or raise CannotRead."""
    if path is None:
        data = sys.stdin.buffer.read()
        return decode_bytes(data)
    ext = os.path.splitext(path)[1].lower()
    try:
        if os.path.isdir(path):
            raise CannotRead("%s is a directory" % path)
        with open(path, 'rb') as f:
            data = f.read()
    except CannotRead:
        raise
    except Exception as e:
        raise CannotRead("%s: %s" % (path, getattr(e, 'strerror', None) or e))
    if ext in ('.pdf', '.rtf'):
        return ''
    if ext in NB_EXT:
        return extract_ipynb(data).strip()
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except Exception:
            raise CannotRead("%s is not a readable zip archive" % path)
        try:
            if ext in ('.docx', '.docm'):
                s = extract_docx(z)
            elif ext in ('.pptx', '.pptm'):
                s = extract_pptx(z)
            elif ext in ('.xlsx', '.xlsm'):
                s = extract_xlsx(z)
            elif ext in ('.odt', '.odp', '.ods'):
                s = extract_odf(z)
            else:
                s = extract_epub(z)
        except Exception:
            s = ''
        return s.strip()
    return decode_bytes(data)


# --------------------------------------------------------------------------
# character layer
# --------------------------------------------------------------------------
VISIBLE_CF = {0x0600, 0x0601, 0x0602, 0x0603, 0x0604, 0x0605, 0x06DD, 0x070F, 0x08E2, 0x110BD, 0x110CD}
FILLERS = {0x115F, 0x1160, 0x3164, 0xFFA0, 0x034F, 0x17B4, 0x17B5}
BIDI = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
        0x2066, 0x2067, 0x2068, 0x2069}


def _in(o, rs):
    for a, b in rs:
        if a <= o <= b:
            return True
    return False


NOSPACE_R = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x19E0, 0x19FF), (0x1000, 0x109F), (0xA9E0, 0xA9FF),
             (0xAA60, 0xAA7F), (0x3040, 0x30FF), (0x31F0, 0x31FF), (0xFF66, 0xFF9F), (0x1B000, 0x1B16F),
             (0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0x20000, 0x3134F), (0xF900, 0xFAFF)]
RTL_R = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
JOIN_R = [(0x0590, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF), (0x0900, 0x0DFF),
          (0x1000, 0x109F), (0x1780, 0x17FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF)]
CJK_R = [(0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0x20000, 0x3134F), (0xF900, 0xFAFF)]
MONGOL_R = [(0x1820, 0x18AF)]
KHMER_R = [(0x1780, 0x17FF)]
EMOJI_R = [(0x1F000, 0x1FAFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x2460, 0x24FF), (0x25A0, 0x27BF),
           (0x2900, 0x297F), (0x2B00, 0x2BFF), (0x3030, 0x3030), (0x303D, 0x303D), (0x3297, 0x3299)]


def _is_vs(o):
    return (0xFE00 <= o <= 0xFE0F) or (0xE0100 <= o <= 0xE01EF) or (0x180B <= o <= 0x180D) or o == 0x180F


def _is_candidate(ch):
    o = ord(ch)
    if o < 0x80:
        return (o < 0x20 and ch not in '\t\n\r') or o == 0x7F
    cat = unicodedata.category(ch)
    if cat == 'Cc':
        return True
    if cat == 'Cf':
        return o not in VISIBLE_CF
    if o in FILLERS or _is_vs(o) or 0xE0000 <= o <= 0xE0FFF:
        return True
    return False


def _sym(ch):
    if not ch:
        return False
    o = ord(ch)
    if unicodedata.category(ch)[0] == 'S':
        return True
    return _in(o, EMOJI_R) or o in (0xA9, 0xAE, 0x203C, 0x2049, 0x2122, 0x2139)


def _joiner_friendly(ch):
    if not ch:
        return False
    o = ord(ch)
    if _in(o, JOIN_R) and not _is_candidate(ch):
        return True
    if o == 0xFE0F or _sym(ch):
        return True
    return False


def has_rtl(text):
    for ch in text:
        if ord(ch) >= 0x0590 and _in(ord(ch), RTL_R) and ch.isalpha():
            return True
    return False


def invisible_indices(text):
    """Indices of characters that are invisible and do no job in position."""
    n = len(text)
    cands = []
    for i, ch in enumerate(text):
        o = ord(ch)
        if o < 0x80 and o >= 0x20 and o != 0x7F:
            continue
        if _is_candidate(ch):
            cands.append(i)
    if not cands:
        return []
    rtl = None
    removed = []
    keep_tags = set()
    # tag sequences
    i = 0
    cs = set(cands)
    tagidx = [i for i in cands if 0xE0000 <= ord(text[i]) <= 0xE0FFF and not _is_vs(ord(text[i]))]
    j = 0
    while j < len(tagidx):
        k = j
        while k + 1 < len(tagidx) and tagidx[k + 1] == tagidx[k] + 1:
            k += 1
        start = tagidx[j]
        end = tagidx[k]
        if start > 0 and text[start - 1] == '\U0001F3F4' and ord(text[end]) == 0xE007F:
            for q in range(start, end + 1):
                keep_tags.add(q)
        j = k + 1
    for i in cands:
        ch = text[i]
        o = ord(ch)
        prev = text[i - 1] if i > 0 else ''
        nxt = text[i + 1] if i + 1 < n else ''
        keep = False
        if _is_vs(o) and not (0x180B <= o <= 0x180F):
            if prev and (_sym(prev) or _in(ord(prev), CJK_R)):
                keep = True
            elif nxt == '⃣':
                keep = True
        elif 0x180B <= o <= 0x180F:
            if prev and _in(ord(prev), MONGOL_R):
                keep = True
        elif 0xE0000 <= o <= 0xE0FFF:
            keep = i in keep_tags
        elif o == 0x200B:
            keep = bool((prev and _in(ord(prev), NOSPACE_R)) or (nxt and _in(ord(nxt), NOSPACE_R)))
        elif o == 0x00AD:
            keep = bool(prev and nxt and prev.isalpha() and nxt.isalpha())
        elif o in BIDI:
            if rtl is None:
                rtl = has_rtl(text)
            keep = rtl
        elif o in (0x17B4, 0x17B5):
            keep = bool((prev and _in(ord(prev), KHMER_R) and ord(prev) not in (0x17B4, 0x17B5)) or
                        (nxt and _in(ord(nxt), KHMER_R) and ord(nxt) not in (0x17B4, 0x17B5)))
        elif o in (0x200C, 0x200D):
            keep = _joiner_friendly(prev) or _joiner_friendly(nxt)
        if not keep:
            removed.append(i)
    return removed


def space_indices(text):
    """List of (index, replacement) for non-standard spaces that get normalized."""
    res = []
    if text.isascii():
        return res
    n = len(text)
    for i, ch in enumerate(text):
        o = ord(ch)
        if o < 0x80:
            continue
        if o in (0x2028, 0x2029):
            res.append((i, '\n'))
            continue
        if unicodedata.category(ch) != 'Zs':
            continue
        if o in (0xA0, 0x202F):
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            if (prev and prev.isdecimal()) or (nxt and nxt.isdecimal()):
                continue
            if nxt and nxt in ':;!?»›%€':
                continue
            if prev and prev in '«‹':
                continue
        res.append((i, ' '))
    return res


def _mk_lookalikes():
    m = {}
    pairs = {
        # Cyrillic lowercase
        'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'ԍ': 'g', 'һ': 'h', 'і': 'i', 'ј': 'j', 'о': 'o',
        'р': 'p', 'ѕ': 's', 'ԝ': 'w', 'х': 'x', 'у': 'y', 'ӏ': 'i', 'ɑ': 'a',
        # Cyrillic uppercase
        'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I', 'Ј': 'J', 'К': 'K', 'М': 'M',
        'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'У': 'Y',
        # Greek
        'α': 'a', 'ο': 'o', 'ν': 'v', 'ρ': 'p', 'υ': 'u', 'ι': 'i', 'χ': 'x', 'γ': 'y',
        'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N',
        'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X',
        # Armenian
        'ս': 'u', 'ո': 'n', 'օ': 'o', 'ց': 'g', 'հ': 'h', 'ա': 'u', 'ԑ': 'e', 'Ս': 'U', 'Օ': 'O',
        'Ѡ': 'W',
        # Arabic presentation / letters drawn like latin
        'ه': 'o', 'ﻩ': 'o', 'ﮪ': 'o', 'ﻫ': 'o', 'ﻬ': 'o', 'ٮ': 'n',
    }
    for k, v in pairs.items():
        m[k] = v
    return m


LOOKALIKE = _mk_lookalikes()
LETTER_RUN = re.compile(r'[^\W\d_]+')


def homoglyph_runs(text):
    """List of (start, end) of letter runs meeting the homoglyph condition."""
    res = []
    if text.isascii():
        return res
    for m in LETTER_RUN.finditer(text):
        s = m.group(0)
        if s.isascii():
            continue
        has_ascii = False
        ok = True
        look = 0
        for ch in s:
            if ch.isascii():
                has_ascii = True
            elif ch in LOOKALIKE:
                look += 1
            else:
                ok = False
                break
        if ok and has_ascii and look:
            res.append((m.start(), m.end()))
    return res


def scrub(text):
    rem = set(invisible_indices(text))
    sp = dict(space_indices(text))
    hr = homoglyph_runs(text)
    fold = set()
    for a, b in hr:
        for k in range(a, b):
            if text[k] in LOOKALIKE:
                fold.add(k)
    if rem or sp or fold:
        buf = []
        for i, ch in enumerate(text):
            if i in rem:
                continue
            if i in sp:
                buf.append(sp[i])
            elif i in fold:
                buf.append(LOOKALIKE[ch])
            else:
                buf.append(ch)
        text = ''.join(buf)
    ended_nl = text.endswith('\n')
    ending = '\r\n' if text.endswith('\r\n') else '\n'
    text = re.sub(r'(?<![ \t])[ \t]+(?=\r?\n|\Z)', '', text)
    text = re.sub(r'\A(?:[ \t]*\r?\n)+', '', text)
    text = text.rstrip()
    if ended_nl and text:
        text += ending
    return text


# --------------------------------------------------------------------------
# masking of non-prose regions
# --------------------------------------------------------------------------
SEP_ROW = re.compile(r'^\s*\|?\s*:?-{1,}:?\s*(?:\|\s*:?-{1,}:?\s*)+\|?\s*$')
BADGE = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
INLINE_CODE = re.compile(r'(?<!`)(`+)(?!`)(?:(?!\n[ \t]*\n)[\s\S])+?(?<!`)\1(?!`)')


def mask_nonprose(text):
    lines = text.split('\n')
    n = len(lines)
    mask = [False] * n
    # front matter
    if n and lines[0].rstrip() == '---':
        for k in range(1, min(n, 2000)):
            if lines[k].rstrip() in ('---', '...'):
                for q in range(0, k + 1):
                    mask[q] = True
                break
    # fences
    fence = None
    for k in range(n):
        ln = lines[k].rstrip('\r')
        if fence is None:
            m = re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$', ln)
            if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
                fence = (m.group(1)[0], len(m.group(1)))
                mask[k] = True
        else:
            mask[k] = True
            m = re.match(r'^ {0,3}(`{3,}|~{3,})[ \t]*$', ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
    # blockquote runs
    k = 0
    while k < n:
        if not mask[k] and re.match(r'^ {0,3}>', lines[k]):
            j = k
            while j + 1 < n and not mask[j + 1] and re.match(r'^ {0,3}>', lines[j + 1]):
                j += 1
            if j > k:
                for q in range(k, j + 1):
                    mask[q] = True
            k = j + 1
        else:
            k += 1
    # tables
    for k in range(n):
        if mask[k]:
            continue
        ln = lines[k].rstrip('\r')
        if ln.lstrip().startswith('|') and ln.count('|') >= 2:
            mask[k] = True
        elif '-' in ln and '|' in ln and SEP_ROW.match(ln):
            mask[k] = True
            if k > 0 and '|' in lines[k - 1]:
                mask[k - 1] = True
            q = k + 1
            while q < n and '|' in lines[q] and lines[q].strip():
                mask[q] = True
                q += 1
        elif BADGE.match(ln):
            mask[k] = True
    outl = []
    for k in range(n):
        if mask[k]:
            outl.append(re.sub(r'[^\r]', ' ', lines[k]))
        else:
            outl.append(lines[k])
    t = '\n'.join(outl)
    if '`' in t:
        t = INLINE_CODE.sub(lambda m: re.sub(r'[^\n]', ' ', m.group(0)), t)
    return t


# --------------------------------------------------------------------------
# lexical helpers
# --------------------------------------------------------------------------
def infl(w):
    forms = {w}
    if w.endswith('e'):
        forms |= {w + 's', w + 'd', w[:-1] + 'ing', w[:-1] + 'ings'}
    elif w.endswith('y') and len(w) > 2 and w[-2] not in 'aeiou':
        forms |= {w[:-1] + 'ies', w[:-1] + 'ied', w + 'ing', w + 's'}
    else:
        forms |= {w + 's', w + 'es', w + 'ed', w + 'ing'}
    return forms


def alt(words):
    return '|'.join(sorted({re.escape(x) for x in words}, key=lambda x: -len(x)))


def rx(p, flags=re.I):
    return re.compile(p, flags)


WORD = re.compile(r"[^\W_](?:[^\W_]|['’-])*")


def collapse(s, limit=90):
    s = re.sub(r'\s+', ' ', s).strip()
    if len(s) > limit:
        s = s[:limit - 1] + '…'
    return s


class Ctx(object):
    pass


def split_sentences(t):
    keep = [ln for ln in t.split('\n') if not ln.lstrip().startswith('#')]
    t2 = '\n'.join(keep)
    parts = re.split(r'(?<=[.!?])["\')\]]*\s+|\n[ \t]*\n', t2)
    return [p.strip() for p in parts if WORD.search(p)]


def split_paras(t):
    return [p.strip() for p in re.split(r'\n[ \t]*\n+', t) if p.strip()]


def wcount(s):
    return len(WORD.findall(s))


def cv(vals):
    if not vals:
        return 1.0
    m = sum(vals) / float(len(vals))
    if m == 0:
        return 1.0
    return statistics.pstdev(vals) / m


# --------------------------------------------------------------------------
# families
# --------------------------------------------------------------------------
FAMS = []  # (num, slug, label, kind, fn)


def fam(num, slug, label, kind):
    def deco(fn):
        FAMS.append((num, slug, label, kind, fn))
        return fn
    return deco


def rx_family(num, slug, label, kind, patterns, flags=re.I):
    pats = [re.compile(p.replace("'", "['’]") if False else p, flags) for p in patterns]

    def fn(c):
        cnt = 0
        samples = []
        for p in pats:
            for m in p.finditer(c.t):
                if m.end() == m.start():
                    continue
                cnt += 1
                if len(samples) < 3:
                    samples.append(collapse(m.group(0)))
        return cnt, samples
    FAMS.append((num, slug, label, kind, fn))


# ---- 1 AI vocabulary
AI_STEMS = ['delve', 'tapestry', 'underscore', 'garner', 'bolster', 'foster', 'showcase', 'emphasize',
            'emphasise', 'enhance', 'leverage', 'utilize', 'utilise', 'facilitate', 'encompass', 'harness',
            'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'elevate', 'empower', 'unlock']
AI_STATIC = ['additionally', 'crucial', 'crucially', 'pivotal', 'vibrant', 'meticulous', 'meticulously',
             'testament', 'intricate', 'intricacies', 'interplay', 'enduring', 'holistic', 'holistically',
             'paradigm', 'paradigms', 'transformative', 'unprecedented', 'myriad', 'plethora', 'robust',
             'seamless', 'seamlessly', 'multifaceted', 'testaments']
_ai_forms = set(AI_STATIC)
for _s in AI_STEMS:
    _ai_forms |= infl(_s)
AI_RX = re.compile(r"\b(?:%s|align(?:s|ed|ing)? with|captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic))\b"
                   % alt(_ai_forms), re.I)


def excerpt(raw, s, e, pad=30):
    a = max(0, s - pad)
    b = min(len(raw), e + pad)
    ex = raw[a:b].replace('\r', ' ').replace('\n', ' ')
    ex = ex.strip()
    if a > 0:
        ex = '...' + ex
    if b < len(raw):
        ex = ex + '...'
    return ex


@fam(1, 'ai_vocabulary', 'AI vocabulary', 'move')
def f1(c):
    cnt = 0
    samples = []
    for m in AI_RX.finditer(c.t):
        cnt += 1
        if len(samples) < 3:
            samples.append(excerpt(c.raw, m.start(), m.end()))
    return cnt, samples


# ---- 2 model dialect
DIALECT = [
    r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b",
    r"\bquietly (?:powerful|profound|radical)\b",
    r"\bdeeply (?:human|personal|felt|unsettling)\b",
    r"\bresonat(?:es|ed|ing)? deeply\b",
    r"\bgame[- ]?chang(?:er|ers|ing)\b",
    r"\b(?:%s)\b" % alt(infl('supercharge') | infl('skyrocket') | infl('turbocharge')),
    r"\b(?:revolutioni[sz](?:e|es|ed|ing))\b",
    r"\bdoubl(?:e|es|ed|ing) down on\b",
    r"\bdiv(?:e|es|ed|ing) deep(?:er)? into\b",
    r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b",
    r"\btak(?:e|es|ing|en)\b[^.!?\n]{0,40}?\bto the next level\b",
]
rx_family(2, 'model_dialect', 'Model-dialect vocabulary', 'move', DIALECT)

# ---- 3 promotional
PROMO = [
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|world-class|top-tier|"
    r"unparalleled|premier|leading)\b",
    r"\b(?:vibrant community|rich cultural heritage|in the heart of|esteemed organi[sz]ation|valuable asset|"
    r"passion for excellence|proven track record|results-oriented|wealth of experience|dynamic team|"
    r"fast-paced environment|deeply passionate|perfectly situated|close-knit team|tight-knit team|"
    r"uniquely positioned to)\b",
    r"\bI(?:'m| am) excited to (?:apply|bring)\b",
]
IMPER = re.compile(r"(?:^|(?<=[.!?])[\"')\]]*\s+|\n)[ \t]*(?:install|join|grab|download|try|discover|experience|escape|"
                   r"transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|"
                   r"unleash|supercharge|level|stop|start)\b", re.I)
PROMO_RX = [re.compile(p, re.I) for p in PROMO]


@fam(3, 'promotional_language', 'Promotional language', 'move')
def f3(c):
    cnt = 0
    samples = []
    for p in PROMO_RX:
        for m in p.finditer(c.t):
            cnt += 1
            if len(samples) < 3:
                samples.append(collapse(m.group(0)))
    ims = list(IMPER.finditer(c.t))
    if len(ims) >= 3:
        cnt += len(ims)
        if len(samples) < 3:
            samples.append(collapse(ims[0].group(0)))
    return cnt, samples


# ---- 4 hyphenated cliches (advice)
HY = ['state-of-the-art', 'cutting-edge', 'best-in-class', 'world-class', 'results-driven', 'detail-oriented',
      'fast-paced', 'data-driven', 'forward-thinking', 'game-changing', 'mission-critical', 'next-generation',
      'end-to-end', 'results-oriented', 'well-rounded', 'user-friendly', 'customer-centric', 'cross-functional',
      'thought-provoking', 'ever-evolving', 'ever-changing', 'team-oriented', 'out-of-the-box', 'ground-breaking',
      'groundbreaking-', 'far-reaching', 'time-tested', 'ever-growing', 'full-service', 'top-notch',
      'client-focused', 'value-added', 'results-focused', 'highly-motivated', 'hard-working', 'fast-growing',
      'high-impact', 'future-proof', 'game-changer', 'thought-leader', 'win-win', 'results-proven',
      'tech-savvy', 'self-motivated', 'goal-oriented', 'people-first', 'action-oriented', 'big-picture']
rx_family(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', 'advice',
          [r"(?<![\w-])(?:%s)(?![\w-])" % alt([h for h in HY if not h.endswith('-')])])

# ---- 5
rx_family(5, 'simple_yet', '"Simple yet X" cliche', 'move',
          [r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"])

# ---- 6 stacked adjective chains
ITEM = r"[A-Za-z]+(?:-[A-Za-z]+)?"
CHAIN = re.compile(r"\b%s(?:,\s+(?:and\s+)?%s|\s+and\s+%s){3,}" % (ITEM, ITEM, ITEM))
STOCK_ADJ = set("""innovative dynamic powerful seamless robust scalable intuitive sleek modern elegant comprehensive
reliable secure efficient flexible stunning beautiful engaging vibrant rich dynamic seamless cutting-edge
thoughtful meaningful impactful transformative holistic compelling exciting immersive""".split())
ADJ_END = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial', 'ary', 'ory', 'ish')
STOP_ITEMS = {'the', 'a', 'an', 'of', 'to', 'in', 'on', 'at', 'for', 'with', 'is', 'are', 'was', 'were', 'it', 'he',
              'she', 'they', 'we', 'i', 'you', 'that', 'this', 'by', 'or', 'but', 'so', 'if', 'then', 'not'}


def _adjectival(w):
    w = w.lower()
    return w in STOCK_ADJ or (len(w) >= 4 and w.endswith(ADJ_END))


@fam(6, 'adjective_chains', 'Stacked adjective chains', 'move')
def f6(c):
    cnt = 0
    samples = []
    for m in CHAIN.finditer(c.t):
        items = [x for x in re.split(r",|\band\b|\s+", m.group(0)) if x]
        if len(items) < 4:
            continue
        if any(x.lower() in STOP_ITEMS for x in items):
            continue
        if not any(_adjectival(x) for x in items):
            continue
        cnt += 1
        if len(samples) < 3:
            samples.append(collapse(m.group(0)))
    return cnt, samples


# ---- 8 synonym cycling
CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def _plural_rx(w):
    if w.endswith('y'):
        return re.escape(w[:-1]) + r"(?:y|ies)"
    if w.endswith('is'):
        return re.escape(w[:-2]) + r"(?:is|es)"
    if w.endswith(('s', 'x', 'ch', 'sh')):
        return re.escape(w) + r"(?:es)?"
    return re.escape(w) + r"s?"


CLUSTER_RX = []
for _cl in CLUSTERS:
    CLUSTER_RX.append([(w, re.compile(r"\b%s\b" % ' '.join(_plural_rx(x) if i == len(w.split()) - 1 else re.escape(x)
                                                           for i, x in enumerate(w.split())), re.I)) for w in _cl])


@fam(8, 'synonym_cycling', 'Synonym cycling', 'move')
def f8(c):
    cnt = 0
    samples = []
    for cl in CLUSTER_RX:
        found = []
        tot = 0
        for w, r in cl:
            k = len(r.findall(c.t))
            if k:
                found.append(w)
                tot += k
        if len(found) >= 3:
            cnt += tot
            if len(samples) < 3:
                samples.append(', '.join(found))
    return cnt, samples


# ---- 10 significance inflation
rx_family(10, 'significance_inflation', 'Significance inflation', 'move', [
    r"\b(?:stands?|stood|serves?|served)\s+as\s+(?:a|an|the)?\s*(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor|highlight)(?:e|es|ed|ing|s)?\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects? a broader (?:trend|shift|pattern)\b",
    r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b",
    r"\bsymboli[sz]es\b",
    r"\bsets? the stage for\b",
    r"\bleft an indelible mark\b",
    r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b",
    r"\bhas (?:shaped|sparked)\b",
    r"\bhas come to (?:define|symbolize|symbolise)\b",
])

# ---- 11 notability
OUTLET = r"[A-Z][\w&.'-]*(?: [A-Z][\w&.'-]*)*"
rx_family(11, 'notability_name_dropping', 'Notability name-dropping', 'move', [
    r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+[^.!?\n]{0,60}?%s(?:,\s*|\s+and\s+|\s*,\s*and\s+)%s" % (OUTLET, OUTLET),
    r"\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b",
    r"\b(?:strong|active|robust|significant|notable)\s+(?:online|digital|social[- ]media)\s+presence\b",
    r"\bwidely (?:covered|cited|reported)\b",
    r"\bindependent (?:coverage|sources)\b",
], flags=0)
# case-sensitive outlet names, but we also want the insensitive stock claims
FAMS[-1] = (11, 'notability_name_dropping', 'Notability name-dropping', 'move', None)


def _f11(c):
    cnt = 0
    samples = []
    pats = [
        re.compile(r"\b(?:[Ff]eatured|[Pp]rofiled|[Cc]overed|[Cc]ited|[Mm]entioned|[Hh]ighlighted|[Ss]howcased)\s+(?:in|by)\s+[^.!?\n]{0,60}?%s(?:\s*,\s*(?:and\s+)?|\s+and\s+)%s" % (OUTLET, OUTLET)),
        re.compile(r"\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b", re.I),
        re.compile(r"\b(?:strong|active|robust|significant|notable)\s+(?:online|digital|social[- ]media)\s+presence\b", re.I),
        re.compile(r"\bwidely (?:covered|cited|reported)\b", re.I),
        re.compile(r"\bindependent (?:coverage|sources)\b", re.I),
    ]
    for p in pats:
        for m in p.finditer(c.t):
            cnt += 1
            if len(samples) < 3:
                samples.append(collapse(m.group(0)))
    return cnt, samples


FAMS[-1] = (11, 'notability_name_dropping', 'Notability name-dropping', 'move', _f11)

# ---- 12 vague attributions
rx_family(12, 'vague_attributions', 'Vague attributions', 'move', [
    r"\bexperts (?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry (?:reports|observers|analysts)\b",
    r"\bobservers have (?:cited|noted)\b",
    r"\bsome critics argue\b",
    r"\bresearchers have found\b",
    r"\bstudies suggest\b",
    r"\bit is widely believed\b",
])

# ---- 13 article title as proper noun
rx_family(13, 'article_title_proper_noun', 'Article title as proper noun', 'decisive', [
    r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of [^.!?\n]{1,80}? (?:is|are) (?:a|an|the)\b",
], flags=0)

# ---- 14
rx_family(14, 'ecosystem_padding', 'Conservation / ecosystem padding', 'move', [
    r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b",
    r"\bconservation efforts are (?:underway|ongoing|in place)\b",
    r"\bserves as an indicator species\b",
    r"\bcontributes to biodiversity\b",
])

# ---- 15
rx_family(15, 'false_ranges', 'False ranges', 'move', [
    r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b",
])

# ---- 16
rx_family(16, 'ing_tails', 'Superficial -ing tail clauses', 'move', [
    r",\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising)\b",
])

# ---- 17
rx_family(17, 'negative_parallelism', 'Negative parallelism', 'advice', [
    r"\bit's not (?:just|merely) (?:about|an?)\b",
    r"\bnot only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn't just\b[^,.!?\n]{0,40}?\bit\b",
])
rx_family(17, 'tailing_negation', 'Tailing negation', 'move', [
    r"[A-Za-z][^,.!?\n]{2,}, no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b",
])

# ---- 18
rx_family(18, 'not_x_just_y', '"Not X, just Y"', 'move', [
    r"\b(?:no|not) \w+, (?:just|only|simply) \w+",
    r"\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely)(?: (?:a|an|the))? \w+(?:,|\s*[-–—])\s*(?:it's|it is|it was|they're|they are|they were|that's|but)\b",
])

# ---- 19 filler
rx_family(19, 'filler_phrases', 'Filler phrases', 'advice', [
    r"\bin order to\b", r"\bdue to the fact that\b", r"\bat this point in time\b", r"\bin the event that\b",
    r"\bhas the ability to\b", r"\bit is important to note that\b", r"\bit should be mentioned that\b",
    r"\bneedless to say\b",
])

# ---- 20
rx_family(20, 'empty_pivots', 'Empty pivot phrases', 'move', [
    r"\bit(?:'s| is) worth (?:noting|mentioning)\b",
    r"\bit bears (?:noting|mentioning)\b",
    r"\bone thing to (?:consider|keep in mind) is\b",
    r"\bit is interesting to note\b",
    r"\ba key consideration is\b",
    r"\ba point to highlight is\b",
])

# ---- 21
rx_family(21, 'outcome_speculation', 'Outcome-speculation tails', 'move', [
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signall?ing a shift toward)\b",
])

# ---- 22 authority tropes
rx_family(22, 'authority_tropes', 'Persuasive authority tropes', 'advice', [
    r"\bhere's the thing\b", r"\bmake no mistake\b", r"\bthe truth is\b", r"\blet's be honest\b",
    r"\bthe simple fact is\b", r"\bat its core\b", r"\bwhat really matters\b", r"\bmore than anything\b",
    r"\bat the end of the day\b", r"\bthe bottom line is\b", r"\bin reality\b", r"\bfundamentally,",
    r"\bthe real question is\b", r"\bthe heart of the matter\b", r"\bthe deeper issue\b",
    r"\bwhen you get down to it\b", r"\bwhen all is said and done\b",
])

# ---- 23
rx_family(23, 'editorial_interjections', 'Editorial interjections', 'move', [
    r"\bit(?:'s| is) important to (?:remember|note|understand|recogni[sz]e)\b",
    r"\bone must note that\b", r"\bit is worth pointing out\b", r"\bit cannot be overstated that\b",
    r"\bit must be emphasi[sz]ed that\b",
])

# ---- 24
rx_family(24, 'self_thoroughness', 'Self-thoroughness phrases', 'move', [
    r"\bthis comprehensive (?:guide|overview|analysis)\b",
    r"\bthis in-depth (?:analysis|look|examination)\b",
    r"\bthis complete (?:guide|overview)\b",
    r"\ba thorough examination of\b",
    r"\beverything you need to know about\b",
])

# ---- 25
rx_family(25, 'question_answer', 'Question-answer rhetorical pattern', 'move', [
    r"(?:^|(?<=[.!?])\s+|\n)(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|Was|Were|Must|May|Might|Shall)\b[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Sometimes|Usually|Yep|Nope|Certainly)[.!](?![\w])",
], flags=re.M | re.I)

# ---- 26
rx_family(26, 'concrete_evidence', '"Concrete evidence" defense phrase', 'move', [
    r"\bwithout concrete evidence\b", r"\bdo you have concrete evidence\b",
    r"\bI (?:would )?need concrete (?:evidence|examples) to\b", r"\babsent concrete proof\b",
    r"\bprovide concrete evidence\b",
])

# ---- 27
rx_family(27, 'intro_hooks', 'Compulsive intro hooks', 'move', [
    r"\bin today's (?:\w+ ){0,2}(?:world|landscape|environment|market)\b",
    r"\bin a world where\b", r"\bin an era of\b", r"\bin recent years,", r"\bmore than ever before\b",
    r"\bwe live in a (?:time|world) when\b",
    r"\b(?:great|exciting|big) news\s*[!:]",
    r"\bever (?:wanted|wondered|dreamed|wished) to\b[^.!?\n]{0,80}\?",
    r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b",
])

# ---- 30
rx_family(30, 'diff_anchored', 'Diff-anchored writing', 'move', [
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
    r"\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b",
    r"\bpreviously\b[^.!?\n]{0,100}?\bnow\b",
    r"\b(?:wasn't|weren't) there before\b",
    r"\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b",
])

# ---- 31
rx_family(31, 'signposting', 'Signposting and announcements', 'move', [
    r"\blet's (?:dive|delve|explore)\b", r"\blet's break (?:this|it) down\b", r"\bhere's what you need to know\b",
    r"\bwithout further ado\b", r"\bnow let's look at\b", r"\bbuckle up\b", r"\bstay with me\b",
    r"\b(?:are you )?ready to dive in\b",
])

# ---- 32
rx_family(32, 'cataloguing_lead_ins', 'Cataloguing lead-ins', 'move', [
    r"\b(?:used|uses|employs?|employed|relied on|utili[sz]es)\s+(?:several|various|a number of|multiple|different|many|numerous)\s+\w+",
    r"(?:^|(?<=[.!?])\s+)These(?: \w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insights?|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains?|becomes?)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b",
], flags=re.M | re.I)

# ---- 33
rx_family(33, 'inline_header_lists', 'Inline-header vertical lists', 'move', [
    r"^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]{1,80}?(?::\*\*|\*\*:)",
], flags=re.M)


# ---- 34 mid-essay bullets
LISTLINE = re.compile(r"^\s*(?:[-*+•]|\d+[.)])\s+\S")


@fam(34, 'mid_essay_bullets', 'Mid-essay bullet injection', 'move')
def f34(c):
    if re.search(r"^ {0,3}#{1,6}\s", c.t, re.M):
        return 0, []
    lists = 0
    prose = 0
    for p in c.paras:
        lines = [ln for ln in p.split('\n') if ln.strip()]
        if not lines:
            continue
        if all(LISTLINE.match(ln) for ln in lines):
            lists += 1
        else:
            prose += 1
    if lists >= 1 and prose >= 2:
        return lists, ['bulleted paragraph amid prose']
    return 0, []


# ---- 35 fragmented headers
@fam(35, 'fragmented_headers', 'Fragmented headers', 'move')
def f35(c):
    lines = c.t.split('\n')
    cnt = 0
    samples = []
    for i, ln in enumerate(lines):
        m = re.match(r"^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$", ln)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nx = lines[j].strip()
        if nx.startswith('#') or LISTLINE.match(nx) or nx.startswith('|'):
            continue
        nw = WORD.findall(nx)
        if not nw or len(nw) > 5:
            continue
        hw = set(w.lower() for w in WORD.findall(m.group(1)) if len(w) >= 3)
        if any(w.lower() in hw for w in nw if len(w) >= 3):
            cnt += 1
            if len(samples) < 3:
                samples.append(collapse(m.group(1) + ' / ' + nx))
    return cnt, samples


# ---- 36
rx_family(36, 'formulaic_challenges', 'Formulaic challenges sections', 'move', [
    r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b",
    r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b",
    r"\bcontinues to thrive\b", r"\btypical of (?:emerging|urban|modern)\b",
    r"\bfaces (?:several|many|numerous) challenges\b",
])

# ---- 37 transitions
TRANS = re.compile(r"(?:^|(?<=[.!?])[\"')\]]*\s+)(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b", re.M)


@fam(37, 'transition_clusters', 'Transition cluster overuse', 'move')
def f37(c):
    cnt = 0
    samples = []
    for p in c.paras:
        ms = list(TRANS.finditer(p))
        if len(ms) >= 2:
            cnt += len(ms)
            if len(samples) < 3:
                samples.append(collapse(', '.join(m.group(0).strip() for m in ms)))
    return cnt, samples


# ---- 38
rx_family(38, 'compulsive_conclusions', 'Compulsive conclusion phrases', 'move', [
    r"^[ \t#>*_-]*(?:in conclusion|overall|in summary|to summarize|to summarise|to conclude|all in all|in essence|ultimately)\b",
], flags=re.M | re.I)

# ---- 39
rx_family(39, 'generic_positive_conclusions', 'Generic positive conclusions', 'move', [
    r"\bthe future looks bright\b", r"\bexciting times lie ahead\b", r"\bjourney toward excellence\b",
    r"\bstep in the right direction\b",
    r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40}?)? (?:is|looks|remains) bright\b",
    r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b",
])


# ---- 40 sentence length monotony
@fam(40, 'sentence_monotony', 'Sentence-length monotony', 'move')
def f40(c):
    L = c.slens
    if len(L) >= 3 and cv(L) < 0.35:
        return 1, ['sentence length CV %.2f over %d sentences' % (cv(L), len(L))]
    return 0, []


# ---- 41 mechanical alternation
@fam(41, 'mechanical_alternation', 'Mechanical sentence-length alternation', 'advice')
def f41(c):
    L = c.slens
    n = len(L)
    best = 0
    run = 1
    i = 1
    cnt = 0
    start = 0
    while i < n:
        d = L[i] - L[i - 1]
        ok = abs(d) >= 6 and max(L[i], L[i - 1]) >= 1.8 * max(1, min(L[i], L[i - 1]))
        if ok and i >= 2:
            d0 = L[i - 1] - L[i - 2]
            ok = (d > 0) != (d0 > 0)
        if i == 1:
            run = 2 if ok else 1
        else:
            if ok:
                run += 1
            else:
                run = 2 if abs(d) >= 6 and max(L[i], L[i - 1]) >= 1.8 * max(1, min(L[i], L[i - 1])) else 1
        if run >= 6:
            cnt += 1
            run = 1
        i += 1
    if cnt:
        return cnt, ['alternating short and long sentences']
    return 0, []


# ---- 42 opener repetition
@fam(42, 'opener_repetition', 'Opener repetition', 'advice')
def f42(c):
    cnt = 0
    samples = []
    for p in c.paras:
        ss = split_sentences(p)
        if len(ss) < 3:
            continue
        d = {}
        for s in ss:
            w = [x.lower() for x in WORD.findall(s)[:2]]
            if len(w) == 2:
                d.setdefault(' '.join(w), 0)
                d[' '.join(w)] += 1
        for k, v in d.items():
            if v >= 3:
                cnt += 1
                if len(samples) < 3:
                    samples.append('"%s" x%d' % (k, v))
    return cnt, samples


# ---- 44 uniform paragraphs
@fam(44, 'uniform_paragraphs', 'Uniform paragraph length', 'move')
def f44(c):
    ps = [p for p in c.paras if not re.match(r"^\s*#", p) and WORD.search(p)]
    L = [wcount(p) for p in ps]
    if len(L) >= 4 and cv(L) < 0.4:
        return 1, ['paragraph length CV %.2f over %d paragraphs' % (cv(L), len(L))]
    return 0, []


# ---- 46 semicolon underuse
@fam(46, 'semicolon_underuse', 'Semicolon and parenthesis underuse', 'advice')
def f46(c):
    if c.nwords < 300:
        return 0, []
    if ';' not in c.t and c.t.count('(') <= 1:
        return 1, ['no semicolons, almost no parentheses']
    return 0, []


# ---- 47 chatbot artifacts
rx_family(47, 'chatbot_artifacts', 'Chatbot artifacts', 'decisive', [
    r"\bI hope this (?:helps|email finds you well)\b",
    r"\bI hope (?:this email )?finds you well\b",
    r"\bcertainly!", r"\bof course!",
    r"\blet me know if you\b", r"\bwould you like me to\b", r"\bfeel free to (?:ask|reach out)\b",
    r"\bhappy to help(?=\s*(?:[.!?]|$))",
    r"\b(?:here|below) is (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere(?: are|'s) (?:a few|some|two|three)(?: more)? (?:options|drafts|versions|variations)\b",
    r"\bhere(?: is|'s) a draft\b",
    r"\bdepending on the (?:vibe|tone|style)\b",
    r"\bas an? (?:AI(?: language model| assistant)?|LLM|(?:large )?language model)\b",
    r"\bto (?:answer|address) your question\b", r"\bin (?:response|answer) to your question\b",
    r"\byour question (?:about|regarding|concerning)\b",
    r"\bas (?:you )?(?:requested|asked), here\b",
    r"\bhere(?: is|'s) (?:the )?(?:draft|first pass|revised version of|for your)\b",
], flags=re.I | re.M)

# ---- 48
rx_family(48, 'sycophantic_tone', 'Sycophantic tone', 'decisive', [
    r"\byou(?:'re| are) absolutely right\b",
    r"\b(?:great question|excellent point)\s*[!.,]",
    r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\s*[!.,]",
    r"\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\s*[!.,]",
])

# ---- 50
rx_family(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers', 'decisive', [
    r"\bas of my (?:last )?(?:training|knowledge|update)\b", r"\bup to my (?:last )?(?:training|knowledge)\b",
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b",
    r"\bbased on (?:the )?available information\b", r"\bas of my (?:knowledge )?cutoff\b",
    r"\bmaintains a low profile\b", r"\bkeeps (?:his|her|their) personal life private\b",
])

# ---- 51
rx_family(51, 'copula_avoidance', 'Copula avoidance', 'move', [
    r"\b(?:serves|stands|functions|acts) as\b", r"\brepresents (?:a|the)\b", r"\bmarks (?:a|the)\b",
    r"\b(?:boast|boasts|boasted|boasting)\b",
    r"\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various|some|over|more|dozens)\b",
    r"\boffers a\b", r"\brefers to\b",
])

# ---- 54 hedge stacking
HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")


@fam(54, 'hedge_stacking', 'Excessive hedging', 'advice')
def f54(c):
    cnt = 0
    samples = []
    for s in re.split(r"(?<=[.!?])\s+|\n[ \t]*\n", c.t):
        hs = HEDGE.findall(s)
        if len(hs) >= 2:
            cnt += 1
            if len(samples) < 3:
                samples.append(collapse(s))
    return cnt, samples


# ---- 55 contraction absence
FIRST = set("i i'm i've i'll i'd me my mine myself we we're we've we'll we'd our ours us ourselves".split())
FULLFORMS = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|can not|will not|would not|should not|could not|have not|has not|had not|I am|I have|I will|I would|it is|that is|we are|we have|they are|you are|there is|let us)\b", re.I)
CONTR = re.compile(r"\b\w+n't\b|\b\w+'(?:re|ve|ll|d|m)\b", re.I)


@fam(55, 'contraction_absence', 'Contraction absence', 'advice')
def f55(c):
    ws = [w.lower() for w in WORD.findall(c.t)]
    if not ws:
        return 0, []
    fp = sum(1 for w in ws if w in FIRST)
    if fp < 3 or fp / float(len(ws)) < 0.02:
        return 0, []
    full = len(FULLFORMS.findall(c.t))
    con = len(CONTR.findall(c.t))
    if full >= 3 and full > con:
        return full, ['%d full forms vs %d contractions' % (full, con)]
    return 0, []


# ---- 56 bold
rx_family(56, 'boldface', 'Boldface overuse', 'move', [r"\*\*[^*\n]+?\*\*"], flags=0)

# ---- 57 emoji
EMOJI_RX = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⭐⭕⌚⌛⏩-⏳✅❌]")


@fam(57, 'emojis', 'Emojis', 'move')
def f57(c):
    ms = EMOJI_RX.findall(c.t)
    return len(ms), ms[:3]


# ---- 58 em dash
@fam(58, 'em_dash_overuse', 'Em-dash overuse', 'advice')
def f58(c):
    cnt = 0
    samples = []
    for p in c.paras:
        k = p.count('—')
        if k >= 2:
            cnt += k
            if len(samples) < 3:
                samples.append(collapse(p, 60))
    return cnt, samples


# ---- 59 title case headings
MINOR = set("a an the and but or nor for so yet at by in of on to up as per via vs with from into onto over off out".split())


@fam(59, 'title_case_headings', 'Title case in headings', 'move')
def f59(c):
    cnt = 0
    samples = []
    for m in re.finditer(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", c.t, re.M):
        h = m.group(1).strip()
        if not h or not h[0].isalpha():
            continue
        letters = [ch for ch in h if ch.isalpha()]
        if letters and all(ch.isupper() for ch in letters):
            continue
        words = h.split()
        if len(words) < 3:
            continue
        major = []
        for w in words:
            core = re.sub(r"^[^\w]+|[^\w]+$", '', w)
            if not core or core.lower() in MINOR:
                continue
            major.append(core)
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            cnt += 1
            if len(samples) < 3:
                samples.append(collapse(h))
    return cnt, samples


# ---- 60 curly quotes
@fam(60, 'curly_quotes', 'Curly quotation marks', 'advice')
def f60(c):
    ms = re.findall("[‘’“”]", c.rawm)
    return len(ms), ms[:3]


# ---- 61 hyphen ranges
@fam(61, 'hyphen_ranges', 'Hyphen for en dash in ranges', 'advice')
def f61(c):
    cnt = 0
    samples = []
    for m in re.finditer(r"(?<![\d-])((?:1[0-9]|20)\d\d)-((?:1[0-9]|20)\d\d)(?![\d-])", c.t):
        if int(m.group(2)) > int(m.group(1)):
            cnt += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return cnt, samples


# ---- 62 invisible
@fam(62, 'invisible_characters', 'Invisible / zero-width characters', 'decisive')
def f62(c):
    idx = c.inv
    samples = []
    for i in idx[:3]:
        samples.append('U+%04X at %d' % (ord(c.raw[i]), i))
    return len(idx), samples


# ---- 63 placeholders
PH_BR = re.compile(r"\[([^\[\]\n]{1,60})\](?![(\[])")
PH_START = re.compile(r"^(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b", re.I)
PH_NAMES = re.compile(r"\b(?:name|person|company|client|place|city|location|source|recipient|manager|employer|organi[sz]ation|address|date)\b", re.I)


@fam(63, 'placeholder_text', 'Placeholder / Mad-Libs text', 'decisive')
def f63(c):
    cnt = 0
    samples = []

    def hit(s):
        nonlocal cnt
        cnt += 1
        if len(samples) < 3:
            samples.append(collapse(s))
    for m in PH_BR.finditer(c.t):
        inner = m.group(1).strip()
        if not inner:
            continue
        if PH_START.match(inner) or (PH_NAMES.search(inner) and len(inner.split()) <= 5 and not re.search(r"[.!?]$", inner)):
            hit(m.group(0))
        elif re.fullmatch(r"[A-Z][A-Z0-9 _'/-]*", inner) and len(re.findall(r"[A-Z]", inner)) >= 2 \
                and not re.fullmatch(r"[A-Za-z]{1,2}\d*", inner):
            hit(m.group(0))
    for m in re.finditer(r"\{\{[^{}\n]{1,80}\}\}", c.t):
        hit(m.group(0))
    for m in re.finditer(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])", c.t):
        hit(m.group(0))
    for m in re.finditer(r"lorem ipsum", c.t, re.I):
        hit(m.group(0))
    return cnt, samples


# ---- 64 chat markup
rx_family(64, 'chat_markup_leak', 'Chatbot reference-markup leak', 'decisive', [
    r"\bcite(?:turn|start|nav)\w*", r"\boai_citation\w*", r"contentReference", r"\bnavlist\b",
    "【\\d+†[^】\\n]*】",
])

# ---- 65 tracking
TRACK_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
               'copilot.microsoft.com', 'poe.com'}


@fam(65, 'ai_tracking_params', 'AI tracking parameters', 'decisive')
def f65(c):
    cnt = 0
    samples = []
    for m in re.finditer(r"utm_source=([A-Za-z0-9.-]*)", c.t, re.I):
        host = m.group(1).rstrip('.').lower()
        if host in TRACK_HOSTS:
            cnt += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return cnt, samples


# ---- 66 homoglyphs
@fam(66, 'homoglyphs', 'Homoglyph / mixed-script confusables', 'decisive')
def f66(c):
    samples = []
    for a, b in c.hruns[:3]:
        samples.append(c.raw[a:b])
    return c.hcount, samples


# ---- 67 spaces
@fam(67, 'nonstandard_spaces', 'Non-standard spaces', 'move')
def f67(c):
    samples = ['U+%04X at %d' % (ord(c.raw[i]), i) for i, _ in c.spaces[:3]]
    return len(c.spaces), samples


# ---- 68 trailing whitespace
@fam(68, 'trailing_whitespace', 'Trailing / stray whitespace', 'advice')
def f68(c):
    t = c.raw
    cnt = len(re.findall(r"(?<![ \t])[ \t]+(?=\r?\n|\Z)", t))
    if re.search(r"(?:\r?\n){2,}\Z", t):
        cnt += 1
    if t[:1].isspace():
        cnt += 1
    return cnt, ['trailing or leading whitespace'] if cnt else []


# ---- 69 marketing slop
rx_family(69, 'marketing_slop', 'Canonical marketing-slop phrases', 'move', [
    r"\bunlock(?:ing)? (?:the |your |their )?full potential\b", r"\bnavigat(?:e|es|ing) the complexities\b",
    r"\ba testament to the (?:power|importance)\b", r"\bstaying ahead of the curve\b",
    r"\bturning challenges into opportunities\b", r"\btaking (?:\w+ ){1,4}to the next level\b",
    r"\bharnessing the power of\b", r"\bpaving the way for\b", r"\bsaying goodbye to\b",
    r"\bimagining a world where\b", r"\bat the forefront of\b", r"\bthe power of innovation\b",
    r"\bin today's fast-paced world\b", r"\bever-evolving (?:landscape|world)\b",
])

# ---- 70 horizontal rules
HR = re.compile(r"^ {0,3}(?:-{3,}|\*{3,}|_{3,}|(?:- ){2,}-|(?:\* ){2,}\*)[ \t]*\r?$")


@fam(70, 'decorative_rules', 'Decorative horizontal rules', 'move')
def f70(c):
    lines = c.t.split('\n')
    if len(lines) < 24:
        return 0, []
    cnt = 0
    for i, ln in enumerate(lines):
        if HR.match(ln):
            if ln.lstrip().startswith('-') and i > 0 and lines[i - 1].strip() and not HR.match(lines[i - 1]) \
                    and not lines[i - 1].lstrip().startswith(('-', '*', '#', '>', '|')):
                continue  # setext underline
            cnt += 1
    if cnt >= 3:
        return cnt, ['%d horizontal rules' % cnt]
    return 0, []


# ---- 71 degenerate repetition
@fam(71, 'degenerate_repetition', 'Degenerate repetition', 'move')
def f71(c):
    ws = [w.lower() for w in WORD.findall(c.t)]
    n = len(ws) - 5
    if n < 12:
        return 0, []
    grams = {}
    keys = []
    for i in range(n):
        k = tuple(ws[i:i + 6])
        keys.append(k)
        grams[k] = grams.get(k, 0) + 1
    rep = sum(1 for k in keys if grams[k] > 1)
    if rep and rep / float(n) >= 0.2:
        ex = ' '.join(next(k for k in keys if grams[k] > 1))
        return rep, [ex]
    return 0, []


# --------------------------------------------------------------------------
# scoring
# --------------------------------------------------------------------------
BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
FLOOR_SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]


def build_ctx(text):
    c = Ctx()
    c.raw = text
    c.rawm = text
    masked = mask_nonprose(text)
    c.t = masked.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    c.paras = split_paras(c.t)
    c.words = WORD.findall(c.t)
    c.nwords = len(c.words)
    sents = split_sentences(c.t)
    c.sents = sents
    c.slens = [wcount(s) for s in sents]
    c.inv = invisible_indices(text)
    c.spaces = space_indices(text)
    hr = homoglyph_runs(text)
    c.hruns = hr
    c.hcount = sum(1 for a, b in hr for k in range(a, b) if text[k] in LOOKALIKE)
    return c


def analyze(text, want_report=True):
    c = build_ctx(text)
    findings = {}
    fired = {}  # num -> kind list
    points = 0.0
    for num, slug, label, kind, fn in FAMS:
        try:
            cnt, samples = fn(c)
        except Exception:
            cnt, samples = 0, []
        if cnt <= 0:
            continue
        findings['%d_%s' % (num, slug)] = {'label': label, 'count': int(cnt), 'samples': samples[:3]}
        if kind != 'advice':
            fired.setdefault(num, kind)
            if kind == 'decisive':
                base = 25
            elif num in (40, 44):
                base = 8
            else:
                base = 10
            points += base + 2 * min(cnt - 1, 8)
    sm = set(fired)
    nw = c.nwords
    # confidence
    if nw < 40:
        conf, reason = 'none', 'fewer than 40 words; too short for a meaningful score'
    elif nw < 120:
        conf, reason = 'low', 'fewer than 120 words; score is a weak signal'
    elif nw < 300 and len(sm) <= 1:
        conf, reason = 'low', 'under 300 words with at most one score-moving pattern family'
    elif nw < 300:
        conf, reason = 'moderate', 'under 300 words; more text would firm up the score'
    else:
        conf, reason = 'high', ''
    score = points
    if not sm:
        score = 0
    elif len(sm) == 1 and not (sm & DECISIVE):
        score = min(score, 40)
    elif sm <= {40, 44}:
        score = min(score, 40)
    if sm == {40}:
        score = min(score, 20)
    nd = len(sm & DECISIVE)
    if len(sm) == 1 and nd == 1 and conf in ('none', 'low'):
        score = min(score, 40)
    if nw < 120:
        k = len(sm & FLOOR_SHORT_SET)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if nw >= 400:
        if len(sm) >= 6:
            score = max(score, 45)
        elif len(sm) >= 5:
            score = max(score, 25)
    if nd >= 2:
        score = max(score, 65)
    elif nd == 1 and conf in ('moderate', 'high'):
        score = max(score, 45)
    score = int(max(0, min(100, round(score))))
    # keep rhythm-only caps after floors (floors can't apply to them anyway)
    metrics = {
        'scanned_chars': len(text),
        'truncated': False,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': len(c.inv),
        'nonstandard_spaces': len(c.spaces),
        'homoglyphs': c.hcount,
        'words': nw,
        'sentences': len(c.sents),
    }
    return findings, metrics, c


def interval(c, point, text):
    sents = c.sents
    if len(sents) < 4:
        return None
    rnd = random.Random(20240601)
    scores = []
    t0 = time.time()
    n = len(sents)
    for _ in range(40):
        samp = [sents[rnd.randrange(n)] for _ in range(n)]
        try:
            f, m, _c = analyze(' '.join(samp))
            scores.append(m['ai_tell_score'])
        except Exception:
            pass
        if time.time() - t0 > 2.0 and len(scores) >= 5:
            break
    if not scores:
        return None
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(round(0.95 * (len(scores) - 1)))]
    lo = min(lo, point)
    hi = max(hi, point)
    return [float(max(0, lo)), float(min(100, hi))]


def main(argv):
    clean = False
    ci = False
    operands = []
    done = False
    for a in argv:
        if done:
            operands.append(a)
        elif a == '--':
            done = True
        elif a in ('--help', '-h'):
            out(USAGE)
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            err_obj("unknown option %s (see --help)" % a)
            return 2
        else:
            operands.append(a)
    path = None
    if operands:
        path = operands[0]
        if len(operands) > 1:
            sys.stderr.write("note: %d files given; only the first file was scanned: %s\n" % (len(operands), path))
    try:
        text = load_prose(path)
    except CannotRead as e:
        err_obj("cannot read input: %s" % e)
        return 1
    except Exception as e:
        err_obj("cannot read input: %s" % e)
        return 1
    if not text.strip():
        err_obj("empty input")
        return 1
    if clean:
        out(scrub(text))
        return 0
    truncated = len(text) > WINDOW
    scan = text[:WINDOW]
    findings, metrics, c = analyze(scan)
    metrics['truncated'] = truncated
    metrics['scanned_chars'] = len(scan)
    if ci:
        iv = interval(c, metrics['ai_tell_score'], scan)
        metrics['score_ci'] = iv
        metrics['score_ci_note'] = ('resampled over sentences' if iv else
                                    'too few sentences for an interval (need at least four)')
    report = dict(sorted(findings.items(), key=lambda kv: int(kv[0].split('_', 1)[0])))
    report['_metrics'] = metrics
    out(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    return 0


if __name__ == '__main__':
    try:
        rc = main(sys.argv[1:])
    except BrokenPipeError:
        rc = 0
    except Exception as e:  # never a traceback
        err_obj("cannot read input: internal error: %s" % e)
        rc = 1
    sys.exit(rc)
