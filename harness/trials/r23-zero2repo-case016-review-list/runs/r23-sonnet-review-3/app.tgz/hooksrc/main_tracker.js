try {
  const payload = readPayload();
  const reply = routeCommand(payload);
  if (reply !== null) {
    process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }));
  } else {
    const level = currentLevel();
    if (level !== 'off') {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: {
          hookEventName: 'UserPromptSubmit',
          additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
        },
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
