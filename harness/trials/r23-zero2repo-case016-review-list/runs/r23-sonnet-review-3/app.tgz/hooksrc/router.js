// ---------------------------------------------------------------- /prosecheck command router
const MARK_BEGIN = '<!-- prosecheck:begin -->';
const MARK_END = '<!-- prosecheck:end -->';
const SECTION_TITLE = '# Prose contract';

function stripPathArg(s) {
  let p = String(s || '').trim();
  if (p.charAt(0) === '@') p = p.slice(1).trim();
  const q = p.charAt(0);
  if ((q === '"' || q === "'") && p.length >= 2 && p.charAt(p.length - 1) === q) p = p.slice(1, -1);
  else if ((q === '"' || q === "'")) {
    const end = p.indexOf(q, 1);
    if (end > 0) p = p.slice(1, end);
  }
  if (p.charAt(0) === '@' && !fs.existsSync(p)) p = p.slice(1);
  return p;
}

function levelReply(level) {
  switch (level) {
    case 'lite': return 'prosecheck level set to lite.';
    case 'full': return 'prosecheck level set to full.';
    case 'strict': return 'prosecheck level set to strict.';
    default: return 'prosecheck is now off. Saved files are not scored until it is turned back on.';
  }
}

function helpReply(level) {
  return [
    'prosecheck level: ' + level,
    '',
    'prosecheck never touches code, commits, config, or chat; it only shapes and scores prose deliverables.',
    '',
    '/prosecheck lite - turn on the writing contract, no scoring of saved files',
    '/prosecheck full - the writing contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - the saved-file guard with threshold 20, and the cleanup scrub',
    '/prosecheck off | on - disable the tool, or re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file, report only, no rewrite',
    '/prosecheck doctor - install health check',
    '/prosecheck stats - token use for the session and the score of its own prose',
    '/prosecheck init - export the writing contract to ./AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unknownReply(word) {
  return 'prosecheck: unknown subcommand "' + word + '".\nValid subcommands: ' + SUBS.join(', ') + '.';
}

function windowNote() { return 'first ' + WINDOW_TXT + ' characters only'; }

function checkReply(arg, cwd) {
  const raw = stripPathArg(arg);
  if (!raw) return 'Usage: /prosecheck check <file> - give the path of a prose file to check.';
  const file = path.resolve(cwd || process.cwd(), raw);
  const base = path.basename(file);
  let st;
  try { st = fs.statSync(file); } catch (e) { return 'prosecheck: cannot read ' + raw; }
  if (!st.isFile()) return 'prosecheck: ' + raw + ' is not a file.';
  const ext = extOf(file);
  if (ext === '.pdf' || ext === '.rtf') return 'prosecheck: ' + base + ' has no readable text for the detector (binary format).';
  const cap = capFor(ext);
  if (st.size > cap) return 'prosecheck: ' + base + ' is over ' + (cap / 1024) + ' KB and was not scored.';
  const dp = detectorPath();
  if (!dp) return 'prosecheck: detector unavailable (the bundled detector script was not found).';
  const r = runPython([dp, file], { timeout: timeoutFor(ext), cwd: pluginRoot() });
  if (r.notFound) return 'prosecheck: detector unavailable (Python could not be launched).';
  if (r.timedOut) return 'prosecheck: check of ' + base + ' failed: the detector timed out.';
  if (r.status !== 0) {
    const e = (r.stderr || '').trim();
    return 'prosecheck: check of ' + base + ' failed' + (e ? ': ' + e : ' (the detector exited with an error).');
  }
  if (!r.stdout.trim()) return 'prosecheck: ' + base + ': no report was produced by the detector.';
  const p = parseReport(r.stdout);
  if (p.kind !== 'ok') return 'prosecheck: the detector printed text that is not a report - no report to show.';
  const m = p.metrics;
  const score = Math.round(m.ai_tell_score);
  const band = typeof m.ai_tell_band === 'string' ? m.ai_tell_band : bandFor(score);
  const lines = [];
  lines.push(base + ' - ' + phraseFor(band) + ' (score ' + score + '/100, band: ' + band + ')');
  let cl = 'confidence: ' + (m.confidence || 'none');
  if (m.confidence !== 'high' && m.confidence_reason) cl += ' - ' + m.confidence_reason;
  lines.push(cl);
  if (m.truncated) lines.push('coverage: ' + windowNote() + ' (only that prefix was included)');
  const labs = labelsOf(p.report);
  if (!labs.length) lines.push('tells: none');
  else lines.push('tells: ' + labs.slice(0, 8).map(function (l) { return l.label + ' (x' + l.count + ')'; }).join('; '));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = currentLevel();
  const lines = [];
  const faults = [];
  lines.push('prosecheck health check');
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[off] mode: off - turn it back on with /prosecheck on');
  const dp = detectorPath();
  lines.push(dp ? '[OK] bundled detector present' : '[FAULT] bundled detector missing from the plugin tree');
  if (!dp) faults.push('detector');
  let pyLine;
  const probe = runPython(['--version'], { timeout: 10000 });
  if (probe.notFound) {
    pyLine = '[FAULT] python not found - prose is still shaped by the writing contract, but saved files are not re-scored until Python is available';
    faults.push('python');
  } else if (!dp) {
    pyLine = '[FAULT] python is present but could not run the bundled script (missing)';
    faults.push('python');
  } else {
    const r = runPython([dp], { input: 'This is a short plain sentence. It was written to test the install.\n', timeout: 15000, cwd: pluginRoot() });
    const pr = r.notFound ? { kind: 'notreport' } : (r.timedOut ? { kind: 'notreport' } : (r.status === 0 ? parseReport(r.stdout) : { kind: 'notreport' }));
    if (pr.kind === 'ok') pyLine = '[OK] python ran the bundled script and produced a numeric score';
    else {
      pyLine = '[FAULT] python ran but the result was not a numeric score';
      faults.push('python');
    }
  }
  lines.push(pyLine);
  let setOk = false;
  try {
    const d = configDir();
    fs.mkdirSync(d, { recursive: true });
    const probeFile = path.join(d, '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probeFile, 'x');
    fs.unlinkSync(probeFile);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings folder is writable' : '[FAULT] settings folder is not writable');
  if (!setOk) faults.push('settings');
  if (faults.length) {
    lines.push('Fix the faulty checks above, then run /prosecheck doctor again.');
  } else if (!modeOk) {
    lines.push('The install is healthy. While it is off, saving a file triggers no scoring, so no file is scored. Turn it back on with ' + form + ' on.');
  } else {
    lines.push('prosecheck is active: plain text up to 512 KB and archives up to 4 MB are scored, reading the first ' + WINDOW_TXT + ' characters. Use ' + form + ' show to see files that were only partly scanned or skipped.');
  }
  return lines.join('\n');
}

function showReply() { return null; }

function recordLine(r) {
  const base = r.base;
  if (r.kind === 'binary') return base + ' - binary file, not re-scored';
  if (r.kind === 'skipped') return base + ' - not scored: larger than the limit of ' + r.limitKb + ' KB';
  if (r.kind === 'failed') return base + ' - not scored: ' + (r.reason || 'the check failed');
  let b = phraseFor(r.band) + ' (score ' + r.score + '/' + r.band;
  if (r.truncated) b += ', ' + windowNote();
  b += ')';
  const labs = Array.isArray(r.labels) ? r.labels.slice(0, 5) : [];
  if (labs.length) b += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labs.join('; ');
  return base + ' - ' + b;
}

function showReplyFor(sessionId) {
  const recs = readLedger(sessionId);
  if (!recs.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files seen this session (newest first):'];
  for (let i = recs.length - 1; i >= 0; i--) lines.push('  ' + recordLine(recs[i]));
  return lines.join('\n');
}

function initReply(form) {
  const level = currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Turn it on with ' + form + ' on to allow the export.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readOk = true;
  let exists = false;
  try { fs.statSync(agents); exists = true; } catch (e) { exists = false; }
  if (exists) {
    try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) { readOk = false; }
  }
  if (!readOk) {
    out.push('prosecheck: cannot read AGENTS.md, so cannot write the contract there; the file was left alone.');
  } else if (existing.indexOf(MARK_BEGIN) >= 0) {
    out.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    const section = MARK_BEGIN + '\n' + contractText(level, { portable: true }) + MARK_END + '\n';
    let body = existing;
    if (body.length && !/\n$/.test(body)) body += '\n';
    if (body.length) body += '\n';
    try {
      fs.writeFileSync(agents, body + section);
      out.push('Exported the writing contract (' + level + ') to ./AGENTS.md.');
    } catch (e) {
      out.push('prosecheck: cannot write AGENTS.md; the contract was not exported.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    out.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    let rule = null;
    try { rule = fs.readFileSync(path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8'); } catch (e) { rule = null; }
    if (rule === null) rule = CURSOR_RULE_FALLBACK;
    try {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, rule);
      out.push('Copied the Cursor rule to ./.cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('prosecheck: cannot write the Cursor rule .cursor/rules/prosecheck.mdc.');
    }
  }
  return out.join('\n');
}

function findNewestTranscript() {
  const root = path.join(configDir(), 'projects');
  let best = null;
  let bestT = -1;
  function walk(d, depth) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestT) { bestT = t; best = p; }
        } catch (er) { /* ignore */ }
      }
    }
  }
  walk(root, 0);
  return best;
}

function statsReply(payload) {
  const level = currentLevel();
  let tp = null;
  if (typeof payload.transcript_path === 'string' && payload.transcript_path) tp = payload.transcript_path;
  else tp = findNewestTranscript();
  let data = null;
  if (tp) { try { data = fs.readFileSync(tp, 'utf8'); } catch (e) { data = null; } }
  if (data === null) return 'prosecheck stats: no readable session transcript was found.\nlevel: ' + level;
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of data.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const msg = o.message;
    const u = msg.usage || {};
    const rec = {
      out: typeof u.output_tokens === 'number' ? u.output_tokens : 0,
      cache: typeof u.cache_read_input_tokens === 'number' ? u.cache_read_input_tokens : 0,
    };
    const key = (typeof msg.id === 'string' && msg.id) ? msg.id : ('__anon' + (anon++));
    byId.set(key, rec);
    if (typeof msg.content === 'string') texts.push(msg.content);
    else if (Array.isArray(msg.content)) {
      for (const b of msg.content) {
        if (b && b.type === 'text' && typeof b.text === 'string') texts.push(b.text);
      }
    }
  }
  let outTok = 0, cacheTok = 0;
  byId.forEach(function (v) { outTok += v.out; cacheTok += v.cache; });
  const lines = ['prosecheck session stats', 'level: ' + level,
    'assistant turns: ' + byId.size, 'output tokens: ' + outTok, 'cache-read input tokens: ' + cacheTok];
  let prose = texts.join('\n\n');
  prose = prose.replace(/^[ ]{0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n[ ]{0,3}\1[`~]*[ \t]*(?=\n|$)|$)/gm, '');
  if (prose.length > 40000) prose = prose.slice(prose.length - 40000);
  prose = prose.trim();
  if (prose.length > 200) {
    const dp = detectorPath();
    if (dp) {
      const r = runPython([dp], { input: prose, timeout: 15000, cwd: pluginRoot() });
      if (!r.notFound && !r.timedOut && r.status === 0) {
        const p = parseReport(r.stdout);
        if (p.kind === 'ok') lines.push('session prose ai_tell_score: ' + Math.round(p.metrics.ai_tell_score));
      }
    }
  }
  return lines.join('\n');
}

// returns reply string, or null when the prompt is not a command
function routeCommand(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    storeLevel('off');
    return 'prosecheck is now off. Saved files are not scored until it is turned back on.';
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/.exec(trimmed);
  if (!m) return null;
  const form = m[1];
  const rest = (m[2] || '').trim();
  let sub = '';
  let arg = '';
  if (rest) {
    const mm = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
    sub = mm[1];
    arg = (mm[2] || '').trim();
  }
  const subl = sub.toLowerCase();
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : undefined;
  if (!subl || subl === 'help') return helpReply(currentLevel());
  if (SUBS.indexOf(subl) < 0) return unknownReply(sub);
  switch (subl) {
    case 'lite': case 'full': case 'strict': case 'off':
      if (!storeLevel(subl)) return 'prosecheck: could not store the level (settings folder not writable).';
      return levelReply(subl);
    case 'on':
      storeLevel('full');
      return 'prosecheck is on (full).';
    case 'status': return 'prosecheck level: ' + currentLevel();
    case 'show': return showReplyFor(payload.session_id);
    case 'check': return checkReply(arg, cwd);
    case 'doctor': return doctorReply(form);
    case 'stats': return statsReply(payload);
    case 'init': return initReply(form);
  }
  return helpReply(currentLevel());
}
