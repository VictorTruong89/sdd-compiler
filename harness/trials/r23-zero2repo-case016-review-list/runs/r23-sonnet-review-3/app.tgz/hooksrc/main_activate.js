try {
  readPayload();
  cleanOldLedgers();
  const existed = flagExists();
  const stored = readStoredLevel();
  const level = stored || envLevel() || 'full';
  if (level !== 'off') {
    if (!stored) storeLevel(level);
    let out = '';
    if (!existed) out += welcomeText();
    out += contractText(level, {});
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
