try {
  readPayload();
  const level = currentLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: contractText(level, {}) },
    }));
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
