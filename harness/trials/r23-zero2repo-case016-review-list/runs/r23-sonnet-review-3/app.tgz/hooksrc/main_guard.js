const INSTR_EXACT = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const ALL_PROSE = PLAIN_EXT.concat(ZIP_EXT, NB_EXT);

function normTool(n) { return String(n || '').toLowerCase().replace(/[^a-z]/g, ''); }

function patchPaths(body) {
  const res = [];
  const seen = new Set();
  for (const line of String(body).split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (!m) continue;
    const p = m[1].trim();
    if (!p || seen.has(p)) continue;
    seen.add(p);
    res.push(p);
    if (res.length >= 16) break;
  }
  return res;
}

function isInstruction(base) {
  const lb = base.toLowerCase();
  if (INSTR_EXACT.indexOf(lb) >= 0) return true;
  const ext = path.extname(lb);
  const stem = ext ? lb.slice(0, -ext.length) : lb;
  if (INSTR_STEMS.indexOf(stem) >= 0 && ALL_PROSE.indexOf(ext) < 0) return true;
  if (INSTR_STEMS.indexOf(lb) >= 0) return true;
  return false;
}

function insideRoot(file) {
  let root;
  try { root = fs.realpathSync(pluginRoot()); } catch (e) { root = path.resolve(pluginRoot()); }
  let f;
  try { f = fs.realpathSync(file); } catch (e) { f = path.resolve(file); }
  const rel = path.relative(root, f);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function handleFile(file, sessionId, threshold) {
  const base = path.basename(file);
  const parts = path.resolve(file).split(path.sep);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return null;
  if (isInstruction(base)) return null;
  if (insideRoot(file)) return null;
  const ext = extOf(file);
  const isBinary = ext === '.pdf' || ext === '.rtf';
  if (!isBinary && ALL_PROSE.indexOf(ext) < 0) return null;
  let st;
  try { st = fs.statSync(file); } catch (e) {
    addLedger(sessionId, { base: base, kind: 'failed', reason: 'the file could not be read' });
    return null;
  }
  if (!st.isFile()) return null;
  if (isBinary) { addLedger(sessionId, { base: base, kind: 'binary' }); return null; }
  const cap = capFor(ext);
  if (st.size > cap) {
    addLedger(sessionId, { base: base, kind: 'skipped', limitKb: cap / 1024 });
    return null;
  }
  const r = scoreFile(file);
  if (r.fail) { addLedger(sessionId, { base: base, kind: 'failed', reason: r.fail }); return null; }
  const m = r.metrics;
  const score = Math.round(m.ai_tell_score);
  const band = typeof m.ai_tell_band === 'string' ? m.ai_tell_band : bandFor(score);
  const labs = labelsOf(r.report).map(function (l) { return l.label; }).slice(0, 5);
  const flagged = score > threshold;
  addLedger(sessionId, { base: base, kind: 'scored', score: score, band: band, labels: labs, flagged: flagged, truncated: !!m.truncated });
  if (!flagged) return null;
  let line = 'prosecheck: ' + base + ' ' + phraseFor(band) + ' (score ' + score + ', band ' + band +
    (m.truncated ? ', first ' + WINDOW_TXT + ' characters only' : '') + '). Flagged: ' +
    (labs.length ? labs.join('; ') : 'patterns above the threshold') + '. Please fix the flagged spans in place, keeping sentence-length variation.';
  if (m.truncated) line += ' Only that prefix was included in the scan.';
  return line;
}

try {
  const payload = readPayload();
  const level = currentLevel();
  if (level === 'full' || level === 'strict') {
    const threshold = level === 'strict' ? 20 : 40;
    const tool = normTool(payload.tool_name);
    const ti = (payload.tool_input && typeof payload.tool_input === 'object') ? payload.tool_input : {};
    let paths = [];
    if (tool === 'write' || tool === 'edit' || tool === 'multiedit') {
      if (typeof ti.file_path === 'string' && ti.file_path.trim()) paths.push(ti.file_path.trim());
    } else if (tool === 'notebookedit') {
      if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) paths.push(ti.notebook_path.trim());
      else if (typeof ti.file_path === 'string' && ti.file_path.trim()) paths.push(ti.file_path.trim());
    } else if (tool === 'applypatch') {
      let body = ti.command;
      if (Array.isArray(body)) body = body.join('\n');
      if (typeof body !== 'string') body = (typeof ti.patch === 'string') ? ti.patch : (typeof ti.input === 'string' ? ti.input : '');
      paths = patchPaths(body);
    }
    const base = (typeof payload.cwd === 'string' && payload.cwd) ? payload.cwd : process.cwd();
    const lines = [];
    const seen = new Set();
    for (const p of paths.slice(0, 16)) {
      const abs = path.resolve(base, p);
      if (seen.has(abs)) continue;
      seen.add(abs);
      try {
        const l = handleFile(abs, payload.session_id, threshold);
        if (l) lines.push(l);
      } catch (e) { /* ignore */ }
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
