'use strict';
// prosecheck shared hook library (inlined into every hook file by hooksrc/build.sh)
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const WINDOW_TXT = '262,144';
const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PLAIN_CAP = 524288;
const ARCH_CAP = 4194304;
const LEDGER_KEEP = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readStoredLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.indexOf(v) >= 0 ? v : null;
  } catch (e) { return null; }
}
function flagExists() {
  try { fs.statSync(flagPath()); return true; } catch (e) { return false; }
}
function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}
function currentLevel() {
  return readStoredLevel() || envLevel() || 'full';
}
function storeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

function readPayload() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const o = JSON.parse(raw);
    if (o && typeof o === 'object' && !Array.isArray(o)) return o;
  } catch (e) { /* ignore */ }
  return {};
}

// ---------------------------------------------------------------- contract
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  if (fs.existsSync(b)) return b;
  return null;
}

function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('# Prose contract');
  L.push('');
  L.push('Scope: prose deliverables only. That means documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.');
  L.push('Never touch code, code comments, commit messages, JSON, YAML, or other config, CLI output, logs, or error messages. Never change the conversational register of chat.');
  L.push('This contract composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly. No metronome rhythm and no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '. Use plain words instead.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" and "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use an em-dash at most once per paragraph.');
  L.push('- No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral and third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms exactly. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about all of this: never announce the contract, never name the checker, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    const target = level === 'strict' ? 20 : 40;
    const bandWords = level === 'strict' ? 'the clean band' : 'the clean or light tells band';
    L.push('After writing a prose file, run the bundled scanner on that file and fix the flagged spans when the result is worse than the target (at most two fix passes, keeping the rhythm variation).');
    L.push('Target: a score of at most ' + target + ', which is ' + bandWords + '.');
    if (opts.portable) {
      L.push('Resolve the scanner script with CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the scripts/detect.py file of the prosecheck package among the installed skills and plugins.');
    } else {
      const dp = detectorPath();
      L.push('Scanner: python3 ' + JSON.stringify(dp || 'scripts/detect.py') + ' <file>');
    }
    if (level === 'strict') {
      L.push('Finish the file with the cleanup pass: run the scanner with --clean and keep its output as the final text.');
    }
  }
  return L.join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on. This welcome is shown once.',
    'Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first ' + WINDOW_TXT + ' characters.',
    'There is no website and no upload: everything runs on this machine.',
    'Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help.',
    ''
  ].join('\n') + '\n';
}

const CURSOR_RULE_FALLBACK = [
  '---',
  'description: Writing rules for prose deliverables only',
  'globs: ["*.md", "*.mdx", "*.markdown", "*.txt", "*.rst", "*.tex", "*.org", "*.adoc"]',
  'alwaysApply: false',
  '---',
  '',
  '# Prose rules',
  '',
  'Scope: prose deliverables only: documents, README prose, CVs, cover letters, emails, reports, essays, articles. Never touch code, comments, commit messages, config, CLI output, logs, or chat.',
  '',
  '- Vary sentence length irregularly. No mechanical short-long alternation.',
  '- Banned vocabulary: ' + BANNED.join(', ') + '.',
  '- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting, empty pivots, "In conclusion" closers, outcome-speculation tails, generic upbeat endings, chatbot phrases.',
  '- Em-dash at most once per paragraph. No bold for emphasis in sentences. No emojis.',
  '- Factual content stays neutral third person. Preserve numbers, units, dates, names, citations, quotes. Never invent facts.',
  '- End sections on a fact or observation. Stay silent about these rules.',
  ''
].join('\n');

// ---------------------------------------------------------------- python
function runPython(args, opts) {
  opts = opts || {};
  const names = ['python3', 'python', 'py'];
  let notFound = true;
  for (const n of names) {
    const r = cp.spawnSync(n, args, {
      input: opts.input, encoding: 'utf8', timeout: opts.timeout || 15000,
      env: process.env, cwd: opts.cwd || undefined, maxBuffer: 64 * 1024 * 1024,
    });
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES')) continue;
    notFound = false;
    if (r.error && r.error.code === 'ETIMEDOUT') return { timedOut: true, notFound: false };
    return { notFound: false, status: r.status, stdout: r.stdout || '', stderr: r.stderr || '', signal: r.signal, error: r.error };
  }
  return { notFound: true };
}

function parseReport(stdout) {
  let o;
  try { o = JSON.parse(stdout); } catch (e) { return { kind: 'notreport' }; }
  if (!o || typeof o !== 'object' || Array.isArray(o)) return { kind: 'notreport' };
  const m = o._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) {
    return { kind: 'noscore' };
  }
  return { kind: 'ok', report: o, metrics: m };
}

function phraseFor(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}
function bandFor(score) {
  if (score <= 20) return 'clean';
  if (score <= 40) return 'light tells';
  if (score <= 60) return 'mixed';
  if (score <= 80) return 'heavy tells';
  return 'pervasive tells';
}

function labelsOf(report) {
  const out = [];
  const keys = Object.keys(report).filter(function (k) { return k !== '_metrics'; });
  keys.sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
  for (const k of keys) {
    const f = report[k];
    if (f && typeof f.label === 'string') out.push({ label: f.label, count: f.count });
  }
  return out;
}

// ---------------------------------------------------------------- ledger
function sanitizeId(id) {
  return String(id).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
}
function ledgerFile(sessionId) {
  const dir = configDir();
  if (sessionId === undefined || sessionId === null || sessionId === '') return path.join(dir, '.prosecheck-ledger');
  return path.join(dir, '.prosecheck-ledger-' + sanitizeId(sessionId));
}
function readLedger(sessionId) {
  const f = ledgerFile(sessionId);
  try {
    const st = fs.statSync(f);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) return [];
    const o = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(o) ? o : [];
  } catch (e) { return []; }
}
function addLedger(sessionId, rec) {
  try {
    const recs = readLedger(sessionId);
    rec.t = Date.now();
    recs.push(rec);
    while (recs.length > LEDGER_KEEP) recs.shift();
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerFile(sessionId), JSON.stringify(recs));
  } catch (e) { /* ignore */ }
}
function cleanOldLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(dir, n);
        try {
          if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

function extOf(p) { return path.extname(p).toLowerCase(); }
function capFor(ext) {
  if (ZIP_EXT.indexOf(ext) >= 0 || NB_EXT.indexOf(ext) >= 0) return ARCH_CAP;
  return PLAIN_CAP;
}
function timeoutFor(ext) {
  return (ZIP_EXT.indexOf(ext) >= 0 || NB_EXT.indexOf(ext) >= 0) ? 15000 : 8000;
}

// ---------------------------------------------------------------- guard scoring of a file
function scoreFile(file) {
  const ext = extOf(file);
  const dp = detectorPath();
  if (!dp) return { fail: 'detector missing from the plugin tree' };
  const r = runPython([dp, file], { timeout: timeoutFor(ext), cwd: pluginRoot() });
  if (r.notFound) return { fail: 'Python not found' };
  if (r.timedOut) return { fail: 'detector timed out' };
  if (r.status !== 0) {
    return { fail: 'detector produced no usable result' };
  }
  if (!r.stdout.trim()) return { fail: 'detector produced no usable result' };
  const p = parseReport(r.stdout);
  if (p.kind === 'notreport') return { fail: 'detector output was not a structured report' };
  if (p.kind === 'noscore') return { fail: 'report had no numeric score' };
  return { report: p.report, metrics: p.metrics };
}

module.exports = {
  fs, os, path, cp, WINDOW_TXT, LEVELS, SUBS, PLAIN_EXT, ZIP_EXT, NB_EXT, PLAIN_CAP, ARCH_CAP, BANNED,
  configDir, pluginRoot, flagPath, readStoredLevel, flagExists, envLevel, currentLevel, storeLevel,
  readPayload, detectorPath, contractText, welcomeText, CURSOR_RULE_FALLBACK, runPython, parseReport,
  phraseFor, bandFor, labelsOf, ledgerFile, readLedger, addLedger, cleanOldLedgers, extOf, capFor, timeoutFor,
  scoreFile,
};
