try {
  const payload = readPayload();
  process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(payload) }));
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
