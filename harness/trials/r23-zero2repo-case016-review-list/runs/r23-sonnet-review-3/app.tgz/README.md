# prosecheck

Local detector for AI-writing patterns (Python standard library) plus Node.js plugin hooks.
Run `python3 scripts/detect.py [--clean] [--ci] [--] [FILE]`. See `NOTES.md` for decisions.
Hooks live in `hooks/` (generated from `hooksrc/` by `hooksrc/build.sh`). No build step is required.
