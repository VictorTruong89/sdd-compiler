---
name: prosecheck
description: Rewrite flagged prose so it reads less like AI output. Use when asked to "prosecheck this" or "humanize this".
---
Run `python3 scripts/detect.py FILE` from the plugin root, then rewrite only the flagged spans of prose.
Preserve numbers, units, dates, names, citations, and quotes; never invent facts; never touch code.
