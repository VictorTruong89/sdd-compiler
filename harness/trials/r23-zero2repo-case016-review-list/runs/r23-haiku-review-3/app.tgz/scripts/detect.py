#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic AI-writing pattern scanner.

Python 3.9+ standard library only. No network, no model, no randomness.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With FILE, the file is read (extension decides extraction, see FP-02).
Without FILE, standard input is read as plain text.
"""
import io
import json
import os
import posixpath
import re
import sys
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144                 # scan window, in characters (PRD FP-02)
PLAIN_CAP_BYTES = 512 * 1024    # plain-text cap, enforced by the plugin
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024

ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm',
                      '.odt', '.odp', '.ods', '.epub'])
PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst',
                        '.tex', '.org', '.adoc'])
NOTEBOOK_EXT = '.ipynb'
NON_PROSE_EXTS = frozenset(['.pdf', '.rtf'])

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores extracted prose for AI-writing patterns (71 catalogue patterns).
With FILE, scores that file; with no FILE, reads standard input (UTF-8).

  --clean     print the scrubbed text instead of the JSON report: invisible
              characters removed, non-standard spaces normalized, lookalike
              letters folded to ASCII, trailing whitespace trimmed.
  --ci        add score_ci (a low/high interval) when there are enough sentences.
  --          end option parsing, so FILE may begin with a dash.
  -h, --help  print this usage message and exit.

Supported files: .md .mdx .markdown .txt .text .rst .tex .org .adoc,
.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub, .ipynb.
Exit status: 0 success, 1 empty input or unreadable input, 2 unknown option.
"""


class InputFailure(Exception):
    """Unreadable path or unreadable archive. Message starts 'cannot read input:'."""


class EmptyInput(Exception):
    """Extracted prose is empty."""


# ---------------------------------------------------------------------------
# Decoding and extraction (FP-02)
# ---------------------------------------------------------------------------

def _normalize_newlines(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def decode_plain(data):
    if data.startswith(b'\xef\xbb\xbf'):
        text = data[3:].decode('utf-8', errors='replace')
    elif data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        text = data.decode('utf-16', errors='replace')
        if text.startswith('\ufeff'):
            text = text[1:]
    else:
        try:
            text = data.decode('utf-8')
        except UnicodeDecodeError:
            text = data.decode('utf-8', errors='replace')
    return _normalize_newlines(text)


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _parse_xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


_DOCX_RULES = {'skip': {'instrText', 'delText'}, 'para': {'p'},
               'break': {'br', 'cr'}, 'tab': {'tab'}, 'space': set(),
               'keepws': {'t'}}
_PPTX_RULES = {'skip': set(), 'para': {'p'}, 'break': {'br'}, 'tab': set(),
               'space': set(), 'keepws': {'t'}}
_ODF_RULES = {'skip': {'annotation', 'annotation-end', 'sequence-decls'},
              'para': {'p', 'h', 'table-row', 'page'},
              'break': {'line-break', 'table-cell'}, 'tab': {'tab'},
              'space': {'s'}, 'keepws': {'span'}}
_SI_RULES = {'skip': {'rPh'}, 'para': set(), 'break': {'br'}, 'tab': set(),
             'space': set(), 'keepws': {'t'}}


def _gather(el, rules, parts):
    name = _local(el.tag)
    if name in rules['skip']:
        return
    if name in rules['tab']:
        parts.append('\t')
    elif name in rules['break']:
        parts.append('\n')
    elif name in rules['space']:
        count = 1
        for key, value in el.attrib.items():
            if _local(key) == 'c':
                try:
                    count = max(0, int(value))
                except ValueError:
                    count = 1
        parts.append(' ' * count)
    keep_ws = name in rules['keepws']
    if el.text and (keep_ws or el.text.strip()):
        parts.append(el.text)
    for child in el:
        _gather(child, rules, parts)
        if child.tail and (keep_ws or child.tail.strip()):
            parts.append(child.tail)
    if name in rules['para']:
        parts.append('\n\n')


def _gather_text(el, rules):
    parts = []
    _gather(el, rules, parts)
    return ''.join(parts)


def _finish(text):
    lines = [ln.rstrip(' \t') for ln in _normalize_newlines(text).split('\n')]
    text = '\n'.join(lines)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def _zip_text(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', name)]


def _extract_docx(zf):
    root = _parse_xml(_zip_text(zf, 'word/document.xml'))
    if root is None:
        return ''
    return _finish(_gather_text(root, _DOCX_RULES))


def _extract_pptx(zf):
    names = [n for n in zf.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    slides = []
    for name in sorted(names, key=_natural_key):
        root = _parse_xml(_zip_text(zf, name))
        if root is not None:
            slides.append(_gather_text(root, _PPTX_RULES))
    return _finish('\n\n'.join(slides))


def _extract_xlsx(zf):
    shared = []
    sst = _parse_xml(_zip_text(zf, 'xl/sharedStrings.xml'))
    if sst is not None:
        for si in sst:
            if _local(si.tag) == 'si':
                shared.append(_gather_text(si, _SI_RULES))

    sheet_paths = []
    wb = _parse_xml(_zip_text(zf, 'xl/workbook.xml'))
    rels = _parse_xml(_zip_text(zf, 'xl/_rels/workbook.xml.rels'))
    if wb is not None and rels is not None:
        targets = {}
        for rel in rels:
            if _local(rel.tag) == 'Relationship':
                targets[rel.get('Id')] = rel.get('Target') or ''
        for el in wb.iter():
            if _local(el.tag) != 'sheet':
                continue
            rid = None
            for key, value in el.attrib.items():
                if _local(key) == 'id':
                    rid = value
            target = targets.get(rid)
            if not target:
                continue
            if target.startswith('/'):
                path = target.lstrip('/')
            else:
                path = posixpath.normpath(posixpath.join('xl', target))
            sheet_paths.append(path)
    if not sheet_paths:
        sheet_paths = sorted((n for n in zf.namelist()
                              if re.match(r'xl/worksheets/sheet\d+\.xml$', n)),
                             key=_natural_key)

    cells = []
    for path in sheet_paths:
        root = _parse_xml(_zip_text(zf, path))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            text = None
            if kind == 's':
                v = None
                for child in c:
                    if _local(child.tag) == 'v':
                        v = child.text
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(shared):
                        text = shared[idx]
            elif kind == 'inlineStr':
                for child in c:
                    if _local(child.tag) == 'is':
                        text = _gather_text(child, _SI_RULES)
            elif kind == 'str':
                for child in c:
                    if _local(child.tag) == 'v':
                        text = child.text
            if text and text.strip():
                cells.append(text)
    return _finish('\n'.join(cells))


def _extract_odf(zf):
    root = _parse_xml(_zip_text(zf, 'content.xml'))
    if root is None:
        return ''
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    return _finish(_gather_text(body, _ODF_RULES))


class _HtmlText(HTMLParser):
    SKIP = {'script', 'style', 'head', 'nav', 'title', 'svg'}
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'tr', 'br',
             'section', 'article', 'blockquote', 'pre', 'dt', 'dd', 'header',
             'footer', 'figcaption', 'table', 'ul', 'ol', 'hr', 'aside',
             'th', 'td'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\n\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            if self.skip:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.parts.append('\n\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)

    def text(self):
        raw = ''.join(self.parts)
        lines = [re.sub(r'\s+', ' ', ln).strip() for ln in raw.split('\n')]
        return '\n\n'.join(ln for ln in lines if ln)


def _html_to_text(data):
    parser = _HtmlText()
    try:
        parser.feed(data.decode('utf-8', errors='replace'))
        parser.close()
    except Exception:  # lenient parser; keep whatever was read
        pass
    return parser.text()


def _extract_epub(zf):
    chapters = []
    opf_path = None
    container = _parse_xml(_zip_text(zf, 'META-INF/container.xml'))
    if container is not None:
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
    if opf_path:
        opf = _parse_xml(_zip_text(zf, opf_path))
        if opf is not None:
            base = posixpath.dirname(opf_path)
            manifest = {}
            spine = []
            for el in opf.iter():
                tag = _local(el.tag)
                if tag == 'item':
                    manifest[el.get('id')] = el
                elif tag == 'itemref' and el.get('idref'):
                    spine.append(el.get('idref'))
            for idref in spine:
                item = manifest.get(idref)
                if item is None:
                    continue
                props = item.get('properties') or ''
                if 'nav' in props.split():
                    continue
                href = item.get('href') or ''
                chapters.append(posixpath.normpath(posixpath.join(base, href)))
    if not chapters:
        chapters = sorted(n for n in zf.namelist()
                          if re.search(r'\.(x?html?)$', n, re.I)
                          and 'nav' not in posixpath.basename(n).lower())
    texts = []
    for name in chapters:
        data = _zip_text(zf, name)
        if data is None:
            continue
        text = _html_to_text(data)
        if text:
            texts.append(text)
    return _finish('\n\n'.join(texts))


def extract_zip(path, data, ext):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise InputFailure('cannot read input: %s is not a readable zip archive' % path)
    try:
        with zf:
            if ext in ('.docx', '.docm'):
                return _extract_docx(zf)
            if ext in ('.pptx', '.pptm'):
                return _extract_pptx(zf)
            if ext in ('.xlsx', '.xlsm'):
                return _extract_xlsx(zf)
            if ext in ('.odt', '.odp', '.ods'):
                return _extract_odf(zf)
            if ext == '.epub':
                return _extract_epub(zf)
    except (zipfile.BadZipFile, OSError, ValueError, RuntimeError, KeyError):
        return ''
    return ''


def extract_ipynb(data):
    try:
        obj = json.loads(data.decode('utf-8', errors='replace'))
    except ValueError:
        return ''
    if not isinstance(obj, dict) or not isinstance(obj.get('cells'), list):
        return ''
    texts = []
    for cell in obj['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        texts.append(src.rstrip())
    return _finish('\n\n'.join(t for t in texts if t.strip()))


def load_input(path):
    """Return extracted prose for PATH (or stdin when PATH is None)."""
    if path is None:
        try:
            data = sys.stdin.buffer.read()
        except Exception:
            raise InputFailure('cannot read input: standard input')
        return decode_plain(data)
    if os.path.isdir(path):
        raise InputFailure('cannot read input: %s is a directory' % path)
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise InputFailure('cannot read input: %s: %s' % (path, exc.strerror or 'unreadable'))
    ext = os.path.splitext(path)[1].lower()
    if ext in NON_PROSE_EXTS:
        return ''
    if ext in ZIP_EXTS:
        return extract_zip(path, data, ext)
    if ext == NOTEBOOK_EXT:
        return extract_ipynb(data)
    return decode_plain(data)


# ---------------------------------------------------------------------------
# Character layer (FP-01 metrics, FP-03 cleanup, catalogue 62 / 66 / 67)
# ---------------------------------------------------------------------------

_TAG_LO, _TAG_HI = 0xE0000, 0xE007F
EXTRA_INVISIBLE = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0,
                   0x180B, 0x180C, 0x180D, 0x180F, 0x180E, 0xFFF0, 0xFFF1,
                   0xFFF2, 0xFFF3, 0xFFF4, 0xFFF5, 0xFFF6, 0xFFF7, 0xFFF8,
                   0x200B, 0x200C, 0x200D, 0x2060, 0x00AD, 0xFEFF, 0x061C}
BIDI_CTRL = set([0x200E, 0x200F, 0x061C] + list(range(0x202A, 0x202F)) +
                list(range(0x2066, 0x206A)))
ZS_NORMALIZED_KEEP = {0x00A0, 0x202F}
NO_SPACE_RANGES = [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1780, 0x17FF),
                   (0x1000, 0x109F), (0x3040, 0x309F), (0x30A0, 0x30FF),
                   (0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0xF900, 0xFAFF)]
JOINING_RANGES = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0700, 0x074F),
                  (0x0750, 0x077F), (0x0780, 0x07BF), (0x07C0, 0x07FF),
                  (0xFB50, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF),
                  (0x1000, 0x109F), (0x1780, 0x17FF)]
RTL_RANGES = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0700, 0x074F),
              (0x0780, 0x07BF), (0x07C0, 0x07FF), (0xFB50, 0xFDFF),
              (0xFE70, 0xFEFF)]
CJK_IDEO_RANGES = [(0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0xF900, 0xFAFF),
                   (0x20000, 0x3FFFF)]
MONGOLIAN = (0x1800, 0x18AF)
KHMER = (0x1780, 0x17FF)

# Lookalike letters of other scripts (catalogue 66) -> ASCII letter.
CONFUSABLES = {
    'а': 'a', 'с': 'c', 'е': 'e', 'і': 'i', 'ј': 'j', 'о': 'o', 'р': 'p',
    'ѕ': 's', 'у': 'y', 'х': 'x', 'һ': 'h', 'ԁ': 'd', 'ԛ': 'q', 'ԝ': 'w',
    'ѵ': 'v', 'ԍ': 'g',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I', 'Ј': 'J',
    'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X',
    'У': 'Y', 'Ԁ': 'D', 'Ԛ': 'Q', 'Ԝ': 'W', 'Ѵ': 'V',
    'ο': 'o', 'ν': 'v', 'ι': 'i', 'ρ': 'p', 'υ': 'u', 'χ': 'x', 'ϲ': 'c',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K',
    'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X',
    'օ': 'o', 'ս': 'u', 'ո': 'n', 'Օ': 'O', 'Ս': 'U', 'Ո': 'N',
}


def _in_ranges(cp, ranges):
    for lo, hi in ranges:
        if lo <= cp <= hi:
            return True
    return False


def _is_sym(ch):
    if not ch:
        return False
    cp = ord(ch)
    return unicodedata.category(ch).startswith('S') or 0x1F000 <= cp <= 0x1FAFF


def _is_cjk(ch):
    return bool(ch) and _in_ranges(ord(ch), CJK_IDEO_RANGES)


def _is_nospace(ch):
    return bool(ch) and _in_ranges(ord(ch), NO_SPACE_RANGES)


def _is_joining(ch):
    return bool(ch) and ch.isalpha() and _in_ranges(ord(ch), JOINING_RANGES)


def _is_invisible(cp):
    if cp in (0x09, 0x0A, 0x0D):
        return False
    if _TAG_LO <= cp <= _TAG_HI:
        return True
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return True
    if cp in EXTRA_INVISIBLE:
        return True
    cat = unicodedata.category(chr(cp))
    return cat in ('Cf', 'Cc')


def char_actions(text):
    """Per-character action: None (keep), 'drop', 'space' (normalize), 'nl'."""
    n = len(text)
    acts = [None] * n
    rtl = any(_in_ranges(ord(c), RTL_RANGES) for c in set(text) if ord(c) > 0x5FF)
    last_nontag = 0
    for i, ch in enumerate(text):
        cp = ord(ch)
        if cp < 0x80:
            if cp < 0x20 and cp not in (0x09, 0x0A):
                acts[i] = 'drop'
            elif cp == 0x7F:
                acts[i] = 'drop'
            last_nontag = cp
            continue
        prev = text[i - 1] if i > 0 else ''
        nxt = text[i + 1] if i + 1 < n else ''
        if _TAG_LO <= cp <= _TAG_HI:
            acts[i] = None if last_nontag == 0x1F3F4 else 'drop'
            continue
        cat = unicodedata.category(ch)
        if cat == 'Zs':
            if cp == 0x20:
                pass
            elif cp in ZS_NORMALIZED_KEEP and _nbsp_kept(prev, nxt):
                pass
            else:
                acts[i] = 'space'
        elif cp in (0x2028, 0x2029):
            acts[i] = 'nl'
        elif cat == 'Cc':
            if cp not in (0x09, 0x0A, 0x0D):
                acts[i] = 'drop'
        elif _is_invisible(cp):
            keep = False
            if cp == 0x200B:
                keep = _is_nospace(prev) or _is_nospace(nxt)
            elif cp in (0x200C, 0x200D):
                keep = (_is_joining(prev) or _is_joining(nxt)
                        or _is_sym(prev) or _is_sym(nxt))
            elif 0xFE00 <= cp <= 0xFE0F:
                keep = _is_sym(prev) or _is_cjk(prev) or nxt == '\u20e3'
            elif 0xE0100 <= cp <= 0xE01EF:
                keep = _is_cjk(prev)
            elif cp == 0x00AD:
                keep = prev.isalpha() and nxt.isalpha()
            elif cp in BIDI_CTRL:
                keep = rtl
            elif cp in (0x180B, 0x180C, 0x180D, 0x180F):
                keep = bool(prev) and MONGOLIAN[0] <= ord(prev) <= MONGOLIAN[1] and prev.isalpha()
            elif cp in (0x17B4, 0x17B5):
                keep = _in_ranges(ord(prev) if prev else 0, [KHMER]) or \
                    _in_ranges(ord(nxt) if nxt else 0, [KHMER])
            if not keep:
                acts[i] = 'drop'
        if acts[i] != 'drop':
            last_nontag = cp
    return acts


def _nbsp_kept(prev, nxt):
    if prev and prev.isdigit():
        return True
    if nxt and (nxt.isdigit() or nxt in ':;!?»›%€'):
        return True
    if prev and prev in '«‹':
        return True
    return False


_TOKEN_RE = re.compile(r'\S+')


def homoglyph_tokens(text):
    """Tokens mixing ASCII Latin letters with lookalike letters of another script."""
    found = []
    for m in _TOKEN_RE.finditer(text):
        tok = m.group()
        letters = [c for c in tok if c.isalpha()]
        if not letters:
            continue
        non_ascii = [c for c in letters if ord(c) > 127]
        if not non_ascii:
            continue
        if not any(ord(c) < 128 for c in letters):
            continue
        if all(c in CONFUSABLES for c in non_ascii):
            found.append((m.start(), m.end(), len(non_ascii)))
    return found


# ---------------------------------------------------------------------------
# Prose view (masks code, tables, blockquote runs, badges; keeps offsets)
# ---------------------------------------------------------------------------

_FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
_BADGE = re.compile(r'^(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
_INLINE_CODE = re.compile(r'(`+)(?!`).+?(?<!`)\1(?!`)')


def mask_prose(text):
    lines = text.split('\n')
    blank = [False] * len(lines)
    if lines and lines[0].rstrip() == '---':
        for j in range(1, len(lines)):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(j + 1):
                    blank[k] = True
                break
    fence = None
    for i, ln in enumerate(lines):
        if fence is None:
            m = _FENCE_OPEN.match(ln)
            if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
                fence = (m.group(2)[0], len(m.group(2)))
                blank[i] = True
        else:
            blank[i] = True
            char, size = fence
            if re.match(r'^ {0,3}' + re.escape(char) + '{' + str(size) + r',}[ \t]*$', ln):
                fence = None
    quote = [bool(re.match(r'^ {0,3}>', ln)) and not blank[i] for i, ln in enumerate(lines)]
    i = 0
    while i < len(lines):
        if quote[i]:
            j = i
            while j < len(lines) and quote[j]:
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    blank[k] = True
            i = j
        else:
            i += 1
    for i, ln in enumerate(lines):
        if blank[i]:
            continue
        s = ln.strip()
        if s.startswith('|') and s.count('|') >= 2:
            blank[i] = True
        elif _BADGE.match(s):
            blank[i] = True
    out = []
    for i, ln in enumerate(lines):
        if blank[i]:
            out.append(' ' * len(ln))
            continue
        if '`' in ln:
            ln = _INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), ln)
        out.append(ln)
    return '\n'.join(out)


_WORD = re.compile(r"[^\W_]+(?:['\u2019-][^\W_]+)*")
_SENT = re.compile(r'[^\n.!?]+[.!?]*')
_PARA = re.compile(r'(?:[^\n]|\n(?![ \t]*\n))+')


class Ctx(object):
    def __init__(self, scan, masked):
        self.scan = scan
        self.masked = masked
        self.paras = []
        for m in _PARA.finditer(masked):
            s, e = m.span()
            if masked[s:e].strip():
                self.paras.append((s, e))
        self.sents = []
        for m in _SENT.finditer(masked):
            s, e = m.span()
            words = _WORD.findall(masked[s:e])
            if not words:
                continue
            ls = masked.rfind('\n', 0, s) + 1
            le = masked.find('\n', s)
            le = len(masked) if le == -1 else le
            if masked[ls:le].lstrip().startswith('#'):
                continue
            self.sents.append((s, e, words))
        self.words = _WORD.findall(masked)

    def excerpt(self, s, e):
        a = max(0, s - 40)
        b = min(len(self.scan), e + 40)
        seg = self.scan[a:b].replace('\n', ' ')
        if len(seg) > 160:
            seg = seg[:160]
        prefix = '...' if a > 0 else ''
        suffix = '...' if b < len(self.scan) else ''
        return prefix + seg + suffix


# ---------------------------------------------------------------------------
# Pattern helpers
# ---------------------------------------------------------------------------

def _infl(word):
    if word.endswith('e'):
        return re.escape(word[:-1]) + r'(?:e|es|ed|ing|s|d)?'
    return re.escape(word) + r'(?:s|es|ed|ing)?'


def W(*words):
    return r'\b(?:' + '|'.join(_infl(w) for w in words) + r')\b'


def rx_fn(patterns, flags=re.I):
    compiled = [re.compile(p, flags) for p in patterns]

    def run(ctx):
        total = 0
        samples = []
        for comp in compiled:
            for m in comp.finditer(ctx.masked):
                total += 1
                if len(samples) < 3:
                    samples.append(ctx.excerpt(m.start(), m.end()))
        return (total, samples) if total else None
    return run


def _cv(values):
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return (var ** 0.5) / mean


def _sentence_excerpts(ctx, sents):
    out = []
    for s, e, _ in sents[:2]:
        out.append(ctx.excerpt(s, e))
    return out


# ---------------------------------------------------------------------------
# Special (non-regex) checkers
# ---------------------------------------------------------------------------

_STOCK_ADJ = {'vibrant', 'robust', 'seamless', 'comprehensive', 'dynamic',
              'powerful', 'elegant', 'intuitive', 'innovative', 'cutting-edge',
              'state-of-the-art', 'bold', 'timeless', 'stunning', 'rich', 'lush',
              'thriving', 'compelling', 'remarkable', 'exceptional', 'sleek',
              'transformative', 'unparalleled', 'breathtaking', 'passionate',
              'charming', 'idyllic', 'picturesque', 'scalable', 'reliable'}
_ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful',
               'less', 'al', 'ial', 'ary', 'ory', 'ish')
_CHAIN = re.compile(r"(?<![\w-])[A-Za-z][\w-]*(?:(?:,[ \t]*(?:and[ \t]+)?|[ \t]+and[ \t]+)[A-Za-z][\w-]*){3,}")


def _is_adjectival(word):
    w = word.lower()
    return w in _STOCK_ADJ or (len(w) > 4 and w.endswith(_ADJ_SUFFIX))


def sp_adjective_chains(ctx):
    total = 0
    samples = []
    for m in _CHAIN.finditer(ctx.masked):
        toks = [t for t in re.findall(r'[A-Za-z][\w-]*', m.group()) if t.lower() != 'and']
        if len(toks) < 4 or not any(_is_adjectival(t) for t in toks):
            continue
        total += 1
        if len(samples) < 3:
            samples.append(ctx.excerpt(m.start(), m.end()))
    return (total, samples) if total else None


_SYNONYMS = [
    [('protagonist', r'protagonists?'), ('main character', r'main characters?'),
     ('central figure', r'central figures?'), ('hero', r'heroes|hero'),
     ('heroine', r'heroines?')],
    [('company', r'compan(?:y|ies)'), ('firm', r'firms?'),
     ('organization', r'organi[sz]ations?'), ('enterprise', r'enterprises?'),
     ('business', r'business(?:es)?')],
    [('author', r'authors?'), ('writer', r'writers?'), ('novelist', r'novelists?'),
     ('scribe', r'scribes?')],
    [('report', r'reports?'), ('study', r'stud(?:y|ies)'),
     ('analysis', r'analys(?:is|es)'), ('investigation', r'investigations?'),
     ('examination', r'examinations?')],
    [('technology', r'technolog(?:y|ies)'), ('tool', r'tools?'),
     ('system', r'systems?'), ('platform', r'platforms?'),
     ('solution', r'solutions?')],
    [('technique', r'techniques?'), ('method', r'methods?'),
     ('approach', r'approach(?:es)?'), ('strategy', r'strateg(?:y|ies)'),
     ('tactic', r'tactics?')],
    [('challenge', r'challenges?'), ('obstacle', r'obstacles?'),
     ('difficulty', r'difficult(?:y|ies)'), ('hurdle', r'hurdles?'),
     ('barrier', r'barriers?')],
    [('benefit', r'benefits?'), ('advantage', r'advantages?'),
     ('upside', r'upsides?'), ('strength', r'strengths?')],
]
_SYN_COMPILED = [[(name, re.compile(r'\b(?:' + pat + r')\b', re.I)) for name, pat in cluster]
                 for cluster in _SYNONYMS]


def sp_synonym_cycling(ctx):
    total = 0
    samples = []
    for cluster in _SYN_COMPILED:
        used = 0
        hits = 0
        cluster_samples = []
        for _name, comp in cluster:
            found = list(comp.finditer(ctx.masked))
            if found:
                used += 1
                hits += len(found)
                for m in found[:1]:
                    cluster_samples.append(ctx.excerpt(m.start(), m.end()))
        if used >= 3:
            total += hits
            samples.extend(cluster_samples)
    if not total:
        return None
    return total, samples[:3]


_PROMO_IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover',
                      'experience', 'escape', 'transform', 'reclaim', 'unlock',
                      'elevate', 'boost', 'say', 'imagine', 'explore', 'meet',
                      'introducing', 'upgrade', 'claim', 'unleash', 'supercharge',
                      'level', 'stop', 'start'}
_PROMO = rx_fn([
    r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|'
    r'unparalleled|premier|world-class|top-tier|leading|esteemed organization|'
    r'valuable asset|passion for excellence|proven track record|results-oriented|'
    r'wealth of experience|dynamic team|fast-paced environment|deeply passionate|'
    r'perfectly situated|close-knit team|tight-knit team|vibrant community|'
    r'rich cultural heritage|in the heart of)\b',
    r'\bI am excited to (?:apply|bring)\b',
    r'\buniquely positioned to\b',
])


def sp_promotional(ctx):
    base = _PROMO(ctx)
    imperative = 0
    samples = []
    for s, e, words in ctx.sents:
        if words[0].lower() in _PROMO_IMPERATIVES:
            imperative += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(s, e))
    total = (base[0] if base else 0) + (imperative if imperative >= 3 else 0)
    if not total:
        return None
    merged = list(base[1]) if base else []
    merged.extend(samples)
    return total, merged[:3]


_HEADING_TITLE = re.compile(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', re.M)
_SMALL_WORDS = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by',
                'with', 'from', 'as', 'up', 'off', 'into', 'onto', 'over',
                'and', 'or', 'but', 'nor', 'so', 'yet'}


def sp_title_case(ctx):
    total = 0
    samples = []
    for m in _HEADING_TITLE.finditer(ctx.masked):
        heading = m.group(1)
        if not heading or not heading[0].isalpha():
            continue
        tokens = re.findall(r"[A-Za-z][A-Za-z'\u2019-]*", heading)
        if len(tokens) < 3:
            continue
        letters = [c for c in heading if c.isalpha()]
        if letters and all(c.isupper() for c in letters):
            continue
        major = [t for t in tokens if t.lower() not in _SMALL_WORDS]
        if len(major) >= 2 and all(t[0].isupper() for t in major):
            total += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(m.start(), m.end()))
    return (total, samples) if total else None


_BULLET = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+')


def sp_bullet_injection(ctx):
    if re.search(r'^#{1,6}[ \t]', ctx.masked, re.M):
        return None
    lists = 0
    prose = 0
    samples = []
    for s, e in ctx.paras:
        lines = [ln for ln in ctx.masked[s:e].split('\n') if ln.strip()]
        if lines and all(_BULLET.match(ln) for ln in lines):
            lists += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(s, e))
        else:
            prose += 1
    if lists >= 1 and prose >= 2:
        return lists, samples
    return None


def sp_fragmented_headers(ctx):
    lines = ctx.masked.split('\n')
    total = 0
    samples = []
    for i, ln in enumerate(lines):
        m = re.match(r'^#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', ln)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if (not nxt or re.match(r'^(?:#|[-*+>`]|\d+[.)][ \t])', nxt) or '|' in nxt
                or len(nxt.split()) > 5):
            continue
        head_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', m.group(1))}
        next_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', nxt)}
        if head_words & next_words:
            total += 1
            if len(samples) < 3:
                samples.append(m.group(1).strip() + ' / ' + nxt)
    return (total, samples) if total else None


_TRANSITION = re.compile(
    r'(?:^|(?<=[.!?][ \t])|(?<=\n))(?:Additionally|Furthermore|Moreover|However|'
    r'Nevertheless|Consequently|Subsequently|Notably)\b', re.M)


def sp_transition_cluster(ctx):
    total = 0
    samples = []
    for s, e in ctx.paras:
        hits = list(_TRANSITION.finditer(ctx.masked[s:e]))
        if len(hits) >= 2:
            total += len(hits)
            if len(samples) < 3:
                m = hits[0]
                samples.append(ctx.excerpt(s + m.start(), s + m.end()))
    return (total, samples) if total else None


def sp_length_monotony(ctx):
    if len(ctx.sents) < 3:
        return None
    cv = _cv([len(w) for _, _, w in ctx.sents])
    if cv is not None and cv < 0.35:
        return 1, _sentence_excerpts(ctx, ctx.sents)
    return None


def sp_paragraph_uniform(ctx):
    counts = []
    for s, e in ctx.paras:
        counts.append(len(_WORD.findall(ctx.masked[s:e])))
    counts = [c for c in counts if c > 0]
    if len(counts) < 4:
        return None
    cv = _cv(counts)
    if cv is not None and cv < 0.4:
        return 1, [ctx.excerpt(ctx.paras[0][0], ctx.paras[0][1])]
    return None


def sp_length_alternation(ctx):
    lens = [len(w) for _, _, w in ctx.sents]
    diffs = [lens[k + 1] - lens[k] for k in range(len(lens) - 1)]
    count = 0
    samples = []
    k = 0
    while k < len(diffs):
        if abs(diffs[k]) < 5:
            k += 1
            continue
        start = k
        k += 1
        while k < len(diffs) and abs(diffs[k]) >= 5 and (diffs[k] > 0) != (diffs[k - 1] > 0):
            k += 1
        if (k - start) + 1 >= 6:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(ctx.sents[start][0], ctx.sents[start][1]))
    return (count, samples) if count else None


def sp_opener_repetition(ctx):
    count = 0
    samples = []
    for ps, pe in ctx.paras:
        inside = [(s, e, w) for s, e, w in ctx.sents if ps <= s and e <= pe]
        if len(inside) < 3:
            continue
        openers = Counter(' '.join(w.lower() for w in words[:2]) for _, _, words in inside)
        top = openers.most_common(1)[0][1]
        if top >= 3:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(ps, pe))
    return (count, samples) if count else None


def sp_semicolon_underuse(ctx):
    if len(ctx.words) < 300 or ';' in ctx.masked:
        return None
    if ctx.masked.count('(') + ctx.masked.count(')') > 2:
        return None
    return 1, [ctx.excerpt(ctx.paras[0][0], ctx.paras[0][1])] if ctx.paras else []


_HEDGE = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|'
                    r'seems? to|seems? like|appears? to|somewhat|relatively|fairly|'
                    r'kind of|sort of)\b')


def sp_hedge_stacking(ctx):
    count = 0
    samples = []
    for s, e, _ in ctx.sents:
        if len(_HEDGE.findall(ctx.masked[s:e])) >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(s, e))
    return (count, samples) if count else None


_FIRST_PERSON = re.compile(r'\bI\b|\b(?i:we|our|us|my|me)\b')
_FULL_FORMS = re.compile(
    r"\b(?i:do not|does not|did not|is not|are not|was not|were not|will not|"
    r"would not|cannot|I am|I have|I will|I would|we are|we have|we will|"
    r"they are|you are|it is|that is|there is|let us)\b")
_CONTRACTIONS = re.compile(
    r"\b(?i:don['\u2019]t|doesn['\u2019]t|didn['\u2019]t|isn['\u2019]t|aren['\u2019]t|"
    r"wasn['\u2019]t|weren['\u2019]t|won['\u2019]t|wouldn['\u2019]t|can['\u2019]t|"
    r"I['\u2019]m|I['\u2019]ve|I['\u2019]ll|I['\u2019]d|we['\u2019]re|we['\u2019]ve|"
    r"we['\u2019]ll|they['\u2019]re|you['\u2019]re|it['\u2019]s|that['\u2019]s|"
    r"there['\u2019]s|let['\u2019]s)\b")


def sp_contraction_absence(ctx):
    words = len(ctx.words)
    if words < 50:
        return None
    first_person = len(_FIRST_PERSON.findall(ctx.masked))
    if first_person / float(words) < 0.03:
        return None
    full = len(_FULL_FORMS.findall(ctx.masked))
    contracted = len(_CONTRACTIONS.findall(ctx.masked))
    if full >= 3 and contracted / float(full + contracted) < 0.2:
        return full, [ctx.excerpt(ctx.paras[0][0], ctx.paras[0][1])] if ctx.paras else []
    return None


def sp_em_dash(ctx):
    count = 0
    samples = []
    for s, e in ctx.paras:
        if ctx.masked[s:e].count('\u2014') >= 2:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(s, e))
    return (count, samples) if count else None


def sp_year_range(ctx):
    count = 0
    samples = []
    for m in re.finditer(r'(?<!\d)(\d{4})-(\d{4})(?!\d)', ctx.masked):
        a, b = int(m.group(1)), int(m.group(2))
        if 1000 <= a < b <= 2999:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(m.start(), m.end()))
    return (count, samples) if count else None


_UTM_DOMAINS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
                'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}


def sp_utm(ctx):
    count = 0
    samples = []
    for m in re.finditer(r'utm_source=([A-Za-z0-9.\-]+)', ctx.masked, re.I):
        host = m.group(1).rstrip('.').lower()
        if host in _UTM_DOMAINS:
            count += 1
            if len(samples) < 3:
                samples.append(ctx.excerpt(m.start(), m.end()))
    return (count, samples) if count else None


def sp_char_invisible(ctx):
    count = sum(1 for a in ctx.acts if a == 'drop')
    if not count:
        return None
    samples = []
    for i, a in enumerate(ctx.acts):
        if a == 'drop' and len(samples) < 3:
            samples.append('U+%04X at character %d' % (ord(ctx.scan[i]), i + 1))
    return count, samples


def sp_char_nonstandard_space(ctx):
    count = sum(1 for a in ctx.acts if a == 'space')
    if not count:
        return None
    samples = []
    for i, a in enumerate(ctx.acts):
        if a == 'space' and len(samples) < 3:
            samples.append('U+%04X at character %d' % (ord(ctx.scan[i]), i + 1))
    return count, samples


def sp_char_homoglyph(ctx):
    if not ctx.homo:
        return None
    samples = [ctx.excerpt(s, e) for s, e, _ in ctx.homo[:3]]
    return len(ctx.homo), samples


def sp_trailing_whitespace(ctx):
    text = ctx.scan
    lines = text.split('\n')
    count = sum(1 for ln in lines if ln != ln.rstrip(' \t'))
    if text and text[0] in ' \t\n':
        count += 1
    if text.endswith('\n\n') or text.endswith(' ') or text.endswith('\t'):
        count += 1
    if not count:
        return None
    return count, ['trailing whitespace on %d line(s)' % count]


def sp_hr_decor(ctx):
    lines = ctx.masked.split('\n')
    if len(lines) < 24:
        return None
    count = 0
    samples = []
    for i, ln in enumerate(lines):
        if not re.match(r'^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$', ln):
            continue
        if i > 0 and lines[i - 1].strip():
            continue
        count += 1
        if len(samples) < 3:
            samples.append('horizontal rule at line %d' % (i + 1))
    if count >= 3:
        return count, samples
    return None


def sp_degenerate_repetition(ctx):
    tokens = [w.lower() for w in ctx.words]
    if len(tokens) < 12:
        return None
    grams = [tuple(tokens[i:i + 6]) for i in range(len(tokens) - 5)]
    counts = Counter(grams)
    positions = sum(c for c in counts.values() if c > 1)
    if not positions or positions / float(len(grams)) < 0.2:
        return None
    repeated = [g for g, c in counts.items() if c > 1]
    return len(repeated), [' '.join(repeated[0])] if repeated else []


# ---------------------------------------------------------------------------
# Family registry (catalogue numbers)
# ---------------------------------------------------------------------------

Q = "['\u2019]"  # straight or curly apostrophe

REGEX_SPECS = []


def _reg(num, slug, label, advice, fn):
    REGEX_SPECS.append((num, slug, label, advice, fn))


_reg(1, 'ai_vocabulary', 'AI vocabulary', False, rx_fn([
    W('additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
      'meticulous', 'testament', 'underscore', 'intricate', 'intricacies',
      'interplay', 'garner', 'bolster', 'foster', 'showcase', 'emphasize',
      'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass',
      'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented',
      'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark', 'craft',
      'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower',
      'unlock', 'comprehensive'),
    r'\balign(?:s|ed|ing)? with\b',
    r'\bcapture(?:s|d)? the (?:essence|spirit|imagination|heart|magic)\b',
]))
_reg(2, 'model_dialect', 'model-dialect vocabulary', False, rx_fn([
    W('genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
      'strikingly', 'compellingly', 'supercharge', 'skyrocket', 'turbocharge',
      'revolutionize'),
    r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b',
    r'\bresonat(?:e|es|ed|ing) deeply\b',
    r'\bgame[- ]chang\w*',
    r'\bdoub(?:le|les|led|ling) down on\b',
    r'\bdive deep(?:er)? into\b',
    r'\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b',
    r'\btakes? (?:\w+ ){1,4}?to the next level\b',
]))
_reg(3, 'promotional', 'promotional language', False, sp_promotional)
_reg(4, 'hyphen_pairs', 'hyphenated word-pair overuse', True, rx_fn([
    r'\b(?:cutting-edge|data-driven|results-driven|high-performing|next-generation|'
    r'best-in-class|value-added|user-centric|forward-thinking|detail-oriented|'
    r'team-oriented|mission-critical|state-of-the-art|top-notch|one-stop)\b',
]))
_reg(5, 'simple_yet', '"simple yet X" cliche', False, rx_fn([
    r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|'
    r'sophisticated|beautiful)\b',
]))
_reg(6, 'adjective_chains', 'stacked adjective chains', False, sp_adjective_chains)
_reg(8, 'synonym_cycling', 'synonym cycling', False, sp_synonym_cycling)
_reg(10, 'significance', 'significance inflation', False, rx_fn([
    r'\b(?:stands?|serves?|stood|served) as (?:an? |the )?(?:testament|reminder|symbol|'
    r'beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor|highlight)\w* (?:its|the|their|his|her) (?:importance|significance|'
    r'enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects? a broader (?:trend|shift|pattern)\b',
    r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymboliz(?:es|ed|ing|e)\b',
    r'\bsets? the stage for\b',
    r'\bleft an indelible mark\b',
    r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\bhas (?:shaped|sparked)\b',
    r'\bhas come to (?:define|symbolize)\b',
]))
_reg(11, 'notability', 'notability name-dropping', False, rx_fn([
    r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) '
    r'(?-i:[A-Z][\w&.\-]*(?: [A-Z][\w&.\-]*)*)(?:,| and) (?-i:[A-Z][\w&.\-]*)',
    r'\b[\d,.]+\s?(?:k|m|million|thousand)?\s+(?:followers|subscribers)\b',
    r'\b(?:strong|active|growing|significant) (?:online|digital|social[- ]media) presence\b',
    r'\bwidely covered\b',
    r'\bindependent coverage\b',
]))
_reg(12, 'vague_attribution', 'vague attributions', False, rx_fn([
    r'\bexperts? (?:argue|believe|say|claim|note|suggest)s?\b',
    r'\bindustry (?:reports?|observers?|analysts?)\b',
    r'\bobservers have (?:cited|noted)\b',
    r'\bsome critics argue\b',
    r'\bresearchers have found\b',
    r'\bstudies suggest\b',
    r'\bit is widely believed\b',
]))
_reg(13, 'title_as_proper_noun', 'article title used as a proper noun', False, rx_fn([
    r"(?-i:\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of) "
    r"[^.!?\n]{1,80}? (?:is|are) (?:a|an|the)\b",
], re.I))
_reg(14, 'ecosystem_padding', 'conservation / ecosystem padding', False, rx_fn([
    r'\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts are (?:underway|ongoing|in place)\b',
    r'\bserves? as an indicator species\b',
    r'\bcontributes? to biodiversity\b',
]))
_reg(15, 'false_range', 'false range', False, rx_fn([
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b'
    r'[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|'
    r'mighty|vanished|towering)\b',
    r'\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b',
]))
_reg(16, 'ing_tails', 'superficial -ing tail clause', False, rx_fn([
    r',[ \t]*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|'
    r'fostering|cultivating|encompassing|signaling|demonstrating|illustrating|'
    r'representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|'
    r'exemplifying|epitomizing)\b',
]))
_reg(17, 'negative_parallelism', 'negative parallelisms', True, rx_fn([
    r"\bit" + Q + r"s not (?:just|merely) (?:about|an?)\b",
    r'\bnot only\b(?:(?![.!?\n]).){0,40}?\bbut\b',
    r"\bdoesn" + Q + r"t just\b[^,.\n]{0,40}?\bit\b",
]))
_reg(17, 'tailing_negation', 'tailing negations', False, rx_fn([
    r'\b[^,.\n]{1,80},[ \t]*no (?:guessing|wasted motion|waste|hassle|fluff|stress|jargon)\b',
]))
_reg(18, 'not_x_just_y', '"Not X, just Y" construction', False, rx_fn([
    r'\b(?:no|not) \w+,[ \t]*(?:just|only|simply) \w+',
    r"\b(?:not|isn" + Q + r"t|aren" + Q + r"t|wasn" + Q + r"t|weren" + Q + r"t) "
    r"(?:just|merely) (?:(?:a|an|the) )?\w+(?:,[ \t]*|[ \t]*[\u2014\u2013-][ \t]*)"
    r"(?:it" + Q + r"s|it is|it was|they" + Q + r"re|they are|they were|that" + Q + r"s|but)\b",
]))
_reg(19, 'filler_phrases', 'filler phrases', True, rx_fn([
    r'\bin order to\b', r'\bdue to the fact that\b', r'\bat this point in time\b',
    r'\bin the event that\b', r'\bhas the ability to\b',
    r'\bit is important to note that\b', r'\bit should be mentioned that\b',
    r'\bneedless to say\b',
]))
_reg(20, 'empty_pivot', 'empty pivot phrase', False, rx_fn([
    r"\bit" + Q + r"s worth (?:noting|mentioning) that\b",
    r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to (?:consider|keep in mind) is\b',
    r'\bit is interesting to note that\b',
    r'\ba key consideration is\b',
    r'\ba point to highlight is\b',
]))
_reg(21, 'speculation_tail', 'outcome speculation tail', False, rx_fn([
    r',[ \t]*(?:raising questions about|prompting reflection on|sparking debate about|'
    r'with broader implications for|reshaping our understanding of|paving the way for|'
    r'signaling a shift toward)\b',
]))
_reg(22, 'persuasive_tropes', 'persuasive authority trope', True, rx_fn([
    r"\bhere" + Q + r"s the thing\b", r'\bmake no mistake\b', r'\bthe truth is\b',
    r"\blet" + Q + r"s be honest\b", r'\bthe simple fact is\b', r'\bat its core\b',
    r'\bwhat really matters\b', r'\bmore than anything\b',
    r'\bat the end of the day\b', r'\bthe bottom line is\b', r'\bin reality\b',
    r'\bfundamentally,', r'\bthe real question is\b', r'\bthe heart of the matter\b',
    r'\bthe deeper issue\b', r'\bwhen you get down to it\b',
    r'\bwhen all is said and done\b',
]))
_reg(23, 'editorial_interjection', 'editorial interjection', False, rx_fn([
    r"\bit(?:" + Q + r"s| is) important to (?:remember|note|understand|recognize)\b",
    r'\bone must note that\b',
    r'\bit is worth pointing out\b',
    r'\bit cannot be overstated that\b',
    r'\bit must be emphasi[sz]ed that\b',
]))
_reg(24, 'self_thoroughness', 'self-thoroughness phrase', False, rx_fn([
    r'\bthis (?:comprehensive (?:guide|overview|analysis)|in-depth (?:analysis|look|'
    r'examination)|complete (?:guide|overview))\b',
    r'\ba thorough examination of\b',
    r'\beverything you need to know about\b',
]))
_reg(25, 'qa_rhetorical', 'question-answer rhetorical pattern', False, rx_fn([
    r'(?-i:(?:^|(?<=[.!?]\s)|(?<=\n))(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|'
    r'Would|Should|Has|Have|Had|May|Might)\b)[^.!?\n]{0,60}\?\s*'
    r'(?i:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]',
], re.I | re.M))
_reg(26, 'concrete_evidence', '"concrete evidence" defense phrase', False, rx_fn([
    r'\bwithout concrete (?:evidence|proof)\b',
    r'\bdo you have concrete (?:evidence|proof)\b',
    r'\bI (?:would )?need concrete (?:evidence|examples) to\b',
    r'\babsent concrete proof\b',
    r'\bprovide concrete evidence\b',
]))
_reg(27, 'intro_hook', 'compulsive intro hook', False, rx_fn([
    r"\bin today" + Q + r"s(?: \w+){0,2} (?:world|landscape|environment|market)\b",
    r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
    r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b',
    r'\b(?:great|exciting|big) news\b\s*[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished to)\b[^.!?\n]*\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b',
]))
_reg(30, 'diff_anchored', 'diff-anchored writing', False, rx_fn([
    r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
    r'\b(?:the|this)(?: (?:latest|new))? (?:update|release|version|change|patch|design) '
    r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
    r'\bpreviously\b[^.!?\n]*\bnow\b',
    r"\b(?:wasn" + Q + r"t|weren" + Q + r"t) there before\b",
    r"\bwe" + Q + r"ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b",
    r'\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
]))
_reg(31, 'signposting', 'signposting and announcement', False, rx_fn([
    r"\blet" + Q + r"s (?:dive|delve|explore)\b",
    r"\blet" + Q + r"s break (?:this|it) down\b",
    r"\bhere" + Q + r"s what you need to know\b",
    r'\bwithout further ado\b',
    r"\bnow let" + Q + r"s look at\b",
    r'\bbuckle up\b', r'\bstay with me\b',
    r'\bready to dive in\b',
]))
_reg(32, 'cataloguing', 'cataloguing lead-in', False, rx_fn([
    r'\b(?:used|uses|use|employs?|employed|relied on|utilizes?)\s+(?:several|various|'
    r'a number of|multiple|different|many|numerous)\s+\w+',
    r'(?:^|(?<=[.!?]\s)|(?<=\n))(?-i:These)\s+(?:\w+\s+)?(?:provide|offer|give|reveal|'
    r'show|allow|enable|help)\s+(?:information|insights?|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:a\s+|the\s+)?(?:language|currency|'
    r'architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|'
    r'connective tissue)\s+of\b',
], re.I | re.M))
_reg(33, 'inline_header_list', 'inline-header vertical list', False, rx_fn([
    r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?(?:\*\*[^*\n]+?:\*\*|\*\*[^*\n]+?\*\*:)',
], re.I | re.M))
_reg(34, 'bullet_injection', 'mid-essay bullet injection', False, sp_bullet_injection)
_reg(35, 'fragmented_header', 'fragmented header', False, sp_fragmented_headers)
_reg(36, 'challenges_formula', 'formulaic challenges section', False, rx_fn([
    r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
    r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
    r'\bcontinues to thrive\b',
    r'\btypical of (?:emerging|urban|modern)\b',
    r'\bfaces (?:several|many|numerous) challenges\b',
]))
_reg(37, 'transition_cluster', 'transition-word cluster', False, sp_transition_cluster)
_reg(38, 'conclusion_phrase', 'compulsive conclusion phrase', False, rx_fn([
    r'^[ \t]*(?:in conclusion|overall|in summary|to summari[sz]e|to conclude|'
    r'all in all|in essence|ultimately)\b',
], re.I | re.M))
_reg(39, 'generic_positive', 'generic positive conclusion', False, rx_fn([
    r'\bthe future looks bright\b',
    r'\bexciting times lie ahead\b',
    r'\bjourney toward excellence\b',
    r'\bstep in the right direction\b',
    r'\b(?:the )?(?:outlook|future)(?: for [\w ]{1,40})? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b',
]))
_reg(40, 'length_monotony', 'sentence-length monotony', False, sp_length_monotony)
_reg(41, 'length_alternation', 'mechanical sentence-length alternation', True, sp_length_alternation)
_reg(42, 'opener_repetition', 'opener repetition', True, sp_opener_repetition)
_reg(44, 'paragraph_uniform', 'uniform paragraph length', False, sp_paragraph_uniform)
_reg(46, 'semicolon_underuse', 'semicolon and parenthesis underuse', True, sp_semicolon_underuse)
_reg(47, 'chatbot_artifact', 'chatbot artifact', False, rx_fn([
    r'\bI hope this helps\b',
    r'\b(?:certainly|of course)!',
    r'\blet me know if you\b',
    r'\bwould you like me to\b',
    r'\bfeel free to (?:ask|reach out)\b',
    r'\bhappy to help\s*[.!]',
    r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
    r'\bhere (?:are|' + Q + r's) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
    r'\bhere (?:is|' + Q + r's) a draft\b',
    r'\bdepending on the (?:vibe|tone|style)\b',
    r'\bI hope (?:this email )?finds you well\b',
    r'\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
    r'\bto (?:answer|address) your question\b',
    r'\bin (?:response|answer) to your question\b',
    r'\byour question (?:about|regarding|concerning)\b',
    r'\bas (?:you )?(?:requested|asked),? here\b',
    r'\bhere is (?:the )?(?:draft|first pass|revised version) (?:of|for your)\b',
]))
_reg(48, 'sycophancy', 'sycophantic tone', False, rx_fn([
    r"\byou(?:" + Q + r"re| are) absolutely right\b",
    r'\b(?:great|excellent|wonderful|fantastic|brilliant|thoughtful|good) (?:question|point)\s*[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
    r"\bthat" + Q + r"s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b",
]))
_reg(50, 'knowledge_cutoff', 'knowledge-cutoff disclaimer', False, rx_fn([
    r'\bas of my (?:last )?(?:training|knowledge)\b',
    r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b',
    r'\bbased on (?:the )?available information\b',
    r'\bas of my (?:knowledge )?cutoff\b',
    r'\b(?:maintains a low profile|keeps (?:his|her|their) personal life private)\b',
]))
_reg(51, 'copula_avoidance', 'copula avoidance', False, rx_fn([
    r'\b(?:serves|stands|functions|acts) as\b',
    r'\brepresents (?:a|the)\b',
    r'\bmarks (?:a|the)\b',
    r'\bboasts\b',
    r'\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various)\b',
    r'\boffers a\b',
    r'\brefers to\b',
]))
_reg(54, 'hedge_stacking', 'stacked hedging', True, sp_hedge_stacking)
_reg(55, 'contraction_absence', 'contraction absence', True, sp_contraction_absence)
_reg(56, 'boldface', 'boldface overuse', False, rx_fn([r'\*\*[^*\n]+?\*\*'], 0))
_reg(57, 'emoji', 'emoji', False, rx_fn([r'[\U0001F000-\U0001FAFF\u2600-\u27BF]'], 0))
_reg(58, 'em_dash', 'em-dash overuse', True, sp_em_dash)
_reg(59, 'title_case_heading', 'title case in headings', False, sp_title_case)
_reg(60, 'curly_quotes', 'curly quotation marks', True, rx_fn([r'[\u2018\u2019\u201C\u201D]'], 0))
_reg(61, 'en_dash_hyphen', 'hyphen used for en dash in year ranges', True, sp_year_range)
_reg(62, 'invisible_chars', 'invisible or zero-width characters', False, sp_char_invisible)
_reg(63, 'placeholder', 'placeholder text', False, rx_fn([
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
    r'\[(?=[^\]\n]*[A-Z]{3})(?-i:[A-Z][A-Z \-_]{2,})\](?![(\[])',
    r'\{\{[^}\n]*\}\}',
    r'\bx{3,}\b',
    r'\blorem ipsum\b',
]))
_reg(64, 'chat_reference', 'chat reference markup', False, rx_fn([
    r'\bcite(?:turn|start|nav)\w*',
    r'\boai_citation\w*',
    r'\bcontentReference\w*',
    r'\bnavlist\w*',
    r'\u3010\d+\u2020[^\u3011\n]{0,80}\u3011?',
], re.I))
_reg(65, 'ai_tracking_param', 'AI tracking parameter', False, sp_utm)
_reg(66, 'homoglyph', 'mixed-script lookalike letters', False, sp_char_homoglyph)
_reg(67, 'nonstandard_space', 'non-standard space', False, sp_char_nonstandard_space)
_reg(68, 'trailing_whitespace', 'trailing or stray whitespace', True, sp_trailing_whitespace)
_reg(69, 'marketing_slop', 'canonical marketing phrase', False, rx_fn([
    r'\bunlocking (?:your |its |their |the )?full potential\b',
    r'\bnavigat(?:e|es|ing|ed) the complexities\b',
    r'\ba testament to the (?:power|importance) of\b',
    r'\bstaying ahead of the curve\b',
    r'\bturning (?:challenges|obstacles) into opportunities\b',
    r'\btaking (?:\w+ )?to the next level\b',
    r'\bharness(?:ing|es|ed)? the power of\b',
    r'\bpaving the way for\b',
    r'\bsaying goodbye to\b',
    r'\bimagining a world where\b',
]))
_reg(70, 'decorative_rules', 'decorative horizontal rules', False, sp_hr_decor)
_reg(71, 'degenerate_repetition', 'degenerate repetition', False, sp_degenerate_repetition)

# Catalogue numbers that can move the score: everything machine-checked except the
# writing-advice numbers (their findings are reported but weigh nothing).
DECISIVE = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
RHYTHM = frozenset([40, 41, 44, 55])
SHORT_DOC_SET = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])
DEFAULT_WEIGHT = 10.0
DECISIVE_WEIGHT = 14.0
RHYTHM_WEIGHT = 6.0


def band_for(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def _family_weight(num):
    if num in DECISIVE:
        return DECISIVE_WEIGHT
    if num in RHYTHM:
        return RHYTHM_WEIGHT
    return DEFAULT_WEIGHT


def confidence_for(words, families):
    if words < 40:
        return 'none', 'only %d words; no confidence below 40 words' % words
    if words < 120:
        return 'low', 'fewer than 120 words (%d)' % words
    if words < 300 and len(families) == 1:
        return 'low', 'fewer than 300 words with only one score-moving family'
    if words < 300:
        return 'moderate', 'fewer than 300 words (%d)' % words
    return 'high', ''


def score_from(hits, words):
    """hits: dict catalogue number -> hit count, over score-moving findings only."""
    families = set(hits)
    raw = 0.0
    for num, count in hits.items():
        raw += _family_weight(num) * (1.0 - 0.5 ** count)
    score = int(round(raw))
    cap = 100
    if len(families) == 1:
        cap = min(cap, 40)
    if families and families <= set([40]):
        cap = min(cap, 20)
    if families and families <= set([40, 44]):
        cap = min(cap, 40)
    score = min(score, cap)
    confidence, _reason = confidence_for(words, families)
    floor = 0
    decisive = families & DECISIVE
    if len(decisive) >= 2:
        floor = max(floor, 65)
    elif len(decisive) == 1 and confidence in ('moderate', 'high'):
        floor = max(floor, 45)
    if words < 120:
        short_count = len(families & SHORT_DOC_SET)
        if short_count >= 3:
            floor = max(floor, 45)
        elif short_count >= 2:
            floor = max(floor, 25)
    elif words >= 400:
        if len(families) >= 6:
            floor = max(floor, 45)
        elif len(families) >= 5:
            floor = max(floor, 25)
    return min(100, max(score, floor))


def analyze(text, want_ci=False):
    truncated = len(text) > WINDOW
    scan = text[:WINDOW]
    acts = char_actions(scan)
    homo = homoglyph_tokens(scan)
    masked = mask_prose(scan)
    ctx = Ctx(scan, masked)
    ctx.acts = acts
    ctx.homo = homo

    findings = []
    for num, slug, label, advice, fn in REGEX_SPECS:
        result = fn(ctx)
        if result is None:
            continue
        count, samples = result
        if count <= 0:
            continue
        findings.append({'num': num, 'slug': slug, 'label': label,
                         'count': int(count), 'samples': list(samples)[:3],
                         'advice': advice})

    # Trailing whitespace is always reported as writing advice (68).
    findings.sort(key=lambda f: (f['num'], f['slug']))

    hits = {}
    for f in findings:
        if f['advice']:
            continue
        hits[f['num']] = hits.get(f['num'], 0) + f['count']

    words = len(ctx.words)
    score = score_from(hits, words)
    families = set(hits)
    confidence, reason = confidence_for(words, families)
    invisible = sum(1 for a in acts if a == 'drop')
    nonstd = sum(1 for a in acts if a == 'space')
    homo_letters = sum(n for _, _, n in homo)

    report = {}
    for f in findings:
        key = '%d_%s' % (f['num'], f['slug'])
        report[key] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}

    metrics = {
        'scanned_chars': len(scan),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_for(score),
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': invisible,
        'nonstandard_spaces': nonstd,
        'homoglyphs': homo_letters,
        'word_count': words,
        'sentence_count': len(ctx.sents),
    }
    if want_ci:
        metrics['score_ci'], metrics['score_ci_note'] = score_interval(scan, ctx.sents, score)
    report['_metrics'] = metrics
    return report


def score_interval(scan, sents, point):
    n = len(sents)
    if n < 4:
        return None, 'too few sentences (%d) for an interval; at least 4 are needed' % n
    blocks = 4
    scores = [point]
    for b in range(blocks):
        lo = b * n // blocks
        hi = (b + 1) * n // blocks
        if hi <= lo:
            continue
        chunk = scan[sents[lo][0]:sents[hi - 1][1]]
        sub = analyze(chunk, want_ci=False)
        scores.append(sub['_metrics']['ai_tell_score'])
    low = min(scores)
    high = max(scores)
    return [low, high], ('interval from %d contiguous sentence blocks, deterministic; '
                         'the point score is included in the range' % blocks)


# ---------------------------------------------------------------------------
# Cleanup (FP-03)
# ---------------------------------------------------------------------------

def fold_homoglyphs(text):
    chars = list(text)
    for start, end, _n in homoglyph_tokens(text):
        for i in range(start, end):
            if chars[i] in CONFUSABLES:
                chars[i] = CONFUSABLES[chars[i]]
    return ''.join(chars)


def clean_text(text):
    folded = fold_homoglyphs(text)
    acts = char_actions(folded)
    out = []
    for ch, act in zip(folded, acts):
        if act == 'drop':
            continue
        if act == 'space':
            out.append(' ')
        elif act == 'nl':
            out.append('\n')
        else:
            out.append(ch)
    body = ''.join(out)
    lines = [ln.rstrip(' \t') for ln in body.split('\n')]
    body = '\n'.join(lines)
    body = body.lstrip('\n')
    body = body.rstrip()
    if body and text.endswith('\n'):
        body += '\n'
    return body


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _error(message, status):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.stderr.flush()
    return status


def _write_stdout(text):
    sys.stdout.buffer.write(text.encode('utf-8', errors='replace'))
    sys.stdout.flush()


def main(argv):
    clean = False
    want_ci = False
    operands = []
    end_of_options = False
    for arg in argv:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_options = True
            continue
        if arg in ('-h', '--help'):
            _write_stdout(USAGE)
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            want_ci = True
            continue
        if arg.startswith('-'):
            return _error('unknown option %s (see --help)' % arg, 2)
        operands.append(arg)

    path = operands[0] if operands else None
    if len(operands) > 1:
        sys.stderr.write('prosecheck: scanning only the first file, %s; the other %d operand(s) were not scanned\n'
                         % (operands[0], len(operands) - 1))
    try:
        text = load_input(path)
        if not text.strip():
            raise EmptyInput()
    except EmptyInput:
        return _error('empty input', 1)
    except InputFailure as exc:
        return _error(str(exc), 1)
    except Exception as exc:  # never print a traceback
        return _error('cannot read input: %s' % type(exc).__name__, 1)

    if clean:
        _write_stdout(clean_text(text))
        return 0
    try:
        report = analyze(text, want_ci=want_ci)
    except Exception as exc:
        return _error('cannot read input: analysis failed (%s)' % type(exc).__name__, 1)
    _write_stdout(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
