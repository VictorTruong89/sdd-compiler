---
description: prosecheck: levels, check, doctor, show, init, stats, help
argument-hint: [lite|full|strict|off|on|status|show|check <file>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
