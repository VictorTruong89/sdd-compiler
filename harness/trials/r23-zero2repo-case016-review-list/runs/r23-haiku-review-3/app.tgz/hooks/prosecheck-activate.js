#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract (and, on first start, the welcome).
const core = require('../lib/prosecheck-core.js');

function main() {
  core.readInput();
  core.pruneLedgers();
  const first = !core.flagExists();
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  if (first) core.writeStoredLevel(level);
  let out = first ? core.WELCOME_TEXT + '\n\n' : '';
  out += core.contractFor(level, 'live');
  return out + '\n';
}

try {
  process.stdout.write(main());
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
