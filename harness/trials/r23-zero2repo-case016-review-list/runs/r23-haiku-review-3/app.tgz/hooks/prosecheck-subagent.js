#!/usr/bin/env node
'use strict';
// subagent-start hook: the same writing contract, inside the subagent's additionalContext.
const core = require('../lib/prosecheck-core.js');

function main() {
  core.readInput();
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.contractFor(level, 'live'),
    },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
