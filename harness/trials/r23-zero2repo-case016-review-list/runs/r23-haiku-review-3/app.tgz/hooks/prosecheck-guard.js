#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const core = require('../lib/prosecheck-core.js');

const WRITE_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch']);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const PATCH_LIMIT = 16;

function collectPaths(input) {
  const name = input.tool_name;
  if (!WRITE_TOOLS.has(name)) return [];
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const raw = [];
  if (name === 'NotebookEdit') {
    raw.push(ti.notebook_path || ti.file_path);
  } else if (name === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : '';
    const re = /^\*\*\* (Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(body)) !== null) raw.push(m[2]);
  } else {
    raw.push(ti.file_path);
  }
  const seen = new Set();
  const out = [];
  for (const value of raw) {
    if (typeof value !== 'string') continue;
    const p = value.trim();
    if (!p || seen.has(p)) continue;
    seen.add(p);
    out.push(p);
    if (out.length >= PATCH_LIMIT) break;
  }
  return out;
}

function handlePath(p, cwd, sid, level, threshold, lines) {
  const abs = path.isAbsolute(p) ? p : path.resolve(cwd || process.cwd(), p);
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const segments = abs.split(/[\\/]+/);
  if (segments.includes('node_modules') || segments.includes('.git')) return;
  const root = path.resolve(core.pluginRoot());
  if (abs === root || abs.startsWith(root + path.sep)) return;

  const lower = base.toLowerCase();
  const stem = ext ? lower.slice(0, lower.length - ext.length) : lower;
  if (INSTRUCTION_NAMES.has(lower)) return;
  if (INSTRUCTION_STEMS.has(stem) && !core.PLAIN_EXTS.includes(ext) && !core.ARCHIVE_EXTS.includes(ext)) return;

  if (core.BINARY_EXTS.includes(ext)) {
    core.appendLedger(sid, { kind: 'binary', base, t: Date.now() });
    return;
  }
  const plain = core.PLAIN_EXTS.includes(ext);
  const archive = core.ARCHIVE_EXTS.includes(ext);
  if (!plain && !archive) return;

  const fail = (reason) => core.appendLedger(sid, { kind: 'failed', base, reason, t: Date.now() });
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    fail('cannot read the file');
    return;
  }
  if (!st.isFile()) return;
  const capKB = archive ? core.ARCHIVE_CAP_KB : core.PLAIN_CAP_KB;
  if (st.size > capKB * 1024) {
    core.appendLedger(sid, { kind: 'skip', base, limitKB: capKB, t: Date.now() });
    return;
  }

  const run = core.runDetector([abs], null, archive ? core.TIMEOUT_ARCHIVE_MS : core.TIMEOUT_PLAIN_MS);
  if (run.pythonMissing) return fail('Python not found');
  if (run.timedOut) return fail('the detector timed out');
  if (run.error || run.status !== 0 || !String(run.stdout).trim()) {
    return fail('no usable result from the detector');
  }
  let report = null;
  try {
    report = JSON.parse(run.stdout);
  } catch (e) {
    return fail('the detector printed text that is not a report');
  }
  if (!report || !report._metrics || typeof report._metrics.ai_tell_score !== 'number') {
    return fail('the report has no numeric score');
  }
  const m = report._metrics;
  const score = m.ai_tell_score;
  const flagged = score > threshold;
  const labels = core.labelsOf(report).slice(0, 5).map((t) => t.label);
  core.appendLedger(sid, {
    kind: 'scored', base, phrase: core.BAND_PHRASE[m.ai_tell_band] || m.ai_tell_band,
    score, band: m.ai_tell_band, labels, flagged, truncated: !!m.truncated, t: Date.now(),
  });
  if (flagged) {
    const coverage = m.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
    const phrase = core.BAND_PHRASE[m.ai_tell_band] || m.ai_tell_band;
    lines.push('prosecheck: ' + base + ' ' + phrase + ' (score ' + score + ', band ' + m.ai_tell_band + coverage + '). ' +
      'Flagged: ' + (labels.length ? labels.join('; ') : 'score above the threshold') + '. ' +
      'Fix the flagged spans in this file, keeping the rhythm variation.');
  }
}

function main() {
  const input = core.readInput();
  const level = core.effectiveLevel();
  if (level === 'off' || level === 'lite') return '';
  const threshold = core.THRESHOLD[level];
  const sid = input.session_id;
  const paths = collectPaths(input);
  const lines = [];
  for (const p of paths) handlePath(p, input.cwd, sid, level, threshold, lines);
  if (!lines.length) return '';
  return JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
