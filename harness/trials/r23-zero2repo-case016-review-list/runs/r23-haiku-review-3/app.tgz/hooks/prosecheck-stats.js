#!/usr/bin/env node
'use strict';
// stats hook: session token figures and the score of the session's own prose.
const core = require('../lib/prosecheck-core.js');

try {
  const input = core.readInput();
  process.stdout.write(core.blockOutput(core.statsReply(input)));
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
