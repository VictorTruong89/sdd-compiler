#!/usr/bin/env node
'use strict';
// prompt-submit hook: /prosecheck command router, stop phrases, and the live-level reminder.
const core = require('../lib/prosecheck-core.js');

function main() {
  const input = core.readInput();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const routed = core.routePrompt(prompt, input);
  if (routed) return core.blockOutput(routed.reply);
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck is ' + level + ' for this session: prose deliverables follow the writing contract, while code, config, and commits are left untouched.',
    },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
