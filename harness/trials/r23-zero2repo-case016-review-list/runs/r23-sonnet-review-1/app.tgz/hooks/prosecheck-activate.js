#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
try {
  const c = require('./prosecheck-common');
  c.readStdinJson();
  const first = !c.flagExists();
  const level = c.getLevel();
  c.pruneLedgers();
  if (first || !c.readStored()) c.setLevel(level);
  if (level !== 'off') {
    const text = (first ? c.welcome() + '\n' : '') + c.contract(level) + '\n';
    process.stdout.write(text);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
