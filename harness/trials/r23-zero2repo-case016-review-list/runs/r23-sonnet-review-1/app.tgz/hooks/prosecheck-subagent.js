#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same contract inside the SubagentStart envelope.
try {
  const c = require('./prosecheck-common');
  c.readStdinJson();
  const level = c.getLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: c.contract(level) },
    }) + '\n');
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
