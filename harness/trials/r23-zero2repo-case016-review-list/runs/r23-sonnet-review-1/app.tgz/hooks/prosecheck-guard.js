#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');

const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const MAX_PATHS = 16;

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m && m[1].trim()) out.push(m[1].trim());
  }
  return out;
}

function isInside(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipped(abs, c) {
  const segs = abs.split(/[\\/]+/);
  if (segs.includes('node_modules') || segs.includes('.git')) return true;
  try {
    const root = path.resolve(c.pluginRoot());
    if (isInside(abs, root)) return true;
    try {
      if (isInside(fs.realpathSync(abs), fs.realpathSync(root))) return true;
    } catch (e) { /* ignore */ }
  } catch (e) { /* ignore */ }
  const b = path.basename(abs).toLowerCase();
  if (INSTRUCTION_NAMES.includes(b)) return true;
  const ext = path.extname(b);
  const stem = ext ? b.slice(0, -ext.length) : b;
  if (INSTRUCTION_STEMS.includes(stem) && !c.PROSE_EXTS.includes(ext)) return true;
  if (INSTRUCTION_STEMS.includes(b)) return true;
  return false;
}

function score(abs, ext, c, sid, level) {
  const base = path.basename(abs);
  const rec = { base, ts: Date.now() };
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    c.appendLedger(sid, Object.assign(rec, { kind: 'failed', reason: 'file not readable' }));
    return null;
  }
  if (!st.isFile()) return null;
  const isArch = c.ARCH_EXTS.includes(ext);
  const cap = isArch ? c.ARCHIVE_CAP : c.PLAIN_CAP;
  if (st.size > cap) {
    c.appendLedger(sid, Object.assign(rec, { kind: 'skipped', limitKB: cap / 1024 }));
    return null;
  }
  const r = c.runDetector(['--', abs], { timeout: isArch ? 15000 : 8000 });
  const fail = (reason) => {
    c.appendLedger(sid, Object.assign(rec, { kind: 'failed', reason }));
    return null;
  };
  if (r.state === 'nopython') return fail('Python not found');
  if (r.state === 'nodetector') return fail('bundled detector not found');
  if (r.state === 'timeout') return fail('detector timed out');
  if (r.status !== 0 || !r.stdout.trim()) return fail('detector produced no output or exited without a usable result');
  let rep;
  try {
    rep = JSON.parse(r.stdout);
  } catch (e) {
    return fail('detector printed text that is not a structured report');
  }
  const m = rep && rep._metrics;
  if (!m || typeof m.ai_tell_score !== 'number') return fail('report has no numeric score');
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = m.ai_tell_score > threshold;
  const labels = c.labelsOf(rep, 5).map((x) => x.label);
  c.appendLedger(sid, Object.assign(rec, {
    kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band, labels, flagged, truncated: !!m.truncated,
  }));
  if (!flagged) return null;
  const cov = m.truncated ? ', first ' + c.WINDOW_TXT + ' characters only' : '';
  const note = m.truncated ? ' Only that ' + c.WINDOW_TXT + '-character prefix was scanned.' : '';
  return 'prosecheck: ' + base + ' ' + c.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + ', band ' +
    m.ai_tell_band + cov + '). Flagged: ' + (labels.join('; ') || 'patterns') +
    '. Please fix the flagged spans, keeping sentence rhythm varied.' + note;
}

try {
  const c = require('./prosecheck-common');
  const p = c.readStdinJson();
  const level = c.getLevel();
  if (level === 'full' || level === 'strict') {
    const ti = p.tool_input && typeof p.tool_input === 'object' ? p.tool_input : {};
    const tool = typeof p.tool_name === 'string' ? p.tool_name : '';
    const paths = [];
    if (typeof ti.file_path === 'string' && ti.file_path.trim()) paths.push(ti.file_path.trim());
    if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) paths.push(ti.notebook_path.trim());
    if (!tool || /patch/i.test(tool)) {
      for (const f of ['command', 'patch', 'input']) paths.push(...patchPaths(ti[f]));
    }
    const cwd = typeof p.cwd === 'string' && p.cwd ? p.cwd : process.cwd();
    const sid = typeof p.session_id === 'string' ? p.session_id : '';
    const seen = new Set();
    const lines = [];
    for (const raw of paths) {
      const abs = path.resolve(cwd, raw);
      if (seen.has(abs)) continue;
      if (seen.size >= MAX_PATHS) break;
      seen.add(abs);
      if (skipped(abs, c)) continue;
      const ext = path.extname(abs).toLowerCase();
      if (ext === '.pdf' || ext === '.rtf') {
        c.appendLedger(sid, { base: path.basename(abs), kind: 'binary', ts: Date.now() });
        continue;
      }
      if (!c.PROSE_EXTS.includes(ext)) continue;
      const line = score(abs, ext, c, sid, level);
      if (line) lines.push(line);
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }) + '\n');
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
