'use strict';
// Shared helpers for the prosecheck plugin hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const ARCH_EXTS = ZIP_EXTS.concat(['.ipynb']);
const PROSE_EXTS = PLAIN_EXTS.concat(ARCH_EXTS);
const LEDGER_MAX = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const MARKER_BEGIN = '<!-- prosecheck:prose-contract:begin -->';
const MARKER_END = '<!-- prosecheck:prose-contract:end -->';

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}
function flagPath() {
  return path.join(configDir(), '.prosecheck-active');
}
function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}
function flagExists() {
  try {
    return fs.existsSync(flagPath());
  } catch (e) {
    return false;
  }
}
function envMode() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}
// Effective level: environment word (when valid) wins, then the stored word, then full.
function getLevel() {
  return envMode() || readStored() || 'full';
}
function setLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) {
    return false;
  }
}

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  try {
    if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

// ------------------------------------------------------------------ detector
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

// Returns {state:'nopython'|'nodetector'|'timeout'|'done', status, stdout, stderr}
function runDetector(args, opts) {
  opts = opts || {};
  const det = detectorPath();
  if (!det) return { state: 'nodetector' };
  const names = ['python3', 'python', 'py'];
  for (const name of names) {
    const r = cp.spawnSync(name, [det].concat(args), {
      input: opts.input,
      encoding: 'utf8',
      timeout: opts.timeout || 15000,
      maxBuffer: 256 * 1024 * 1024,
      windowsHide: true,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT' || r.error.code === 'EACCES') continue;
      if (r.error.code === 'ETIMEDOUT') return { state: 'timeout' };
      return { state: 'done', status: null, stdout: '', stderr: String(r.error.message || '') };
    }
    if (r.signal && r.status === null) return { state: 'timeout' };
    return { state: 'done', status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { state: 'nopython' };
}

function hookPhrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

function labelsOf(report, max) {
  const items = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (f && typeof f.label === 'string') items.push({ label: f.label, count: Number(f.count) || 0 });
  }
  items.sort((a, b) => b.count - a.count);
  return items.slice(0, max);
}

// ------------------------------------------------------------------- ledger
function sanitizeId(id) {
  return String(id).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
}
function ledgerPath(sessionId) {
  const dir = configDir();
  if (!sessionId || typeof sessionId !== 'string') return path.join(dir, '.prosecheck-ledger');
  return path.join(dir, '.prosecheck-ledger-' + sanitizeId(sessionId));
}
function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}
function appendLedger(sessionId, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const arr = readLedger(sessionId);
    arr.push(rec);
    fs.writeFileSync(ledgerPath(sessionId), JSON.stringify(arr.slice(-LEDGER_MAX)));
  } catch (e) { /* never fail the host */ }
}
function pruneLedgers() {
  try {
    const dir = configDir();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, f);
        try {
          if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ----------------------------------------------------------------- contract
const BANNED = [
  'delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape (abstract)', 'journey (abstract)', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer',
  'supercharge', 'genuinely', 'fascinating', 'nuanced',
];

function ruleLines() {
  return [
    'Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.',
    'This contract never applies to source code. It never touches code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.',
    'Vary sentence length irregularly. No metronome rhythm and no mechanical short-long alternation.',
    'Banned vocabulary: ' + BANNED.join(', ') + '.',
    'Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting ("let\'s dive in"); empty pivots ("it\'s worth noting"); "In conclusion" / "Overall" closers; outcome-speculation tails; self-thoroughness; generic upbeat endings; chatbot phrases ("I hope this helps").',
    'Use an em-dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    'Factual or encyclopedic content stays in a neutral third person. First-person or opinion content may use contractions.',
    'Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    'End sections on a fact or observation.',
    'Stay silent about all of this: never announce the contract, never name the checker, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

function detectorStep(level, portable) {
  const lines = [];
  const target = level === 'strict'
    ? 'Target: the `clean` band (score at most 20).'
    : 'Target: the `clean` or `light tells` band (score at most 40).';
  let cmd;
  if (portable) {
    lines.push('After writing a prose file, run the bundled detector on that file: `python3 <detector> <file>`, where `<detector>` is `scripts/detect.py`.');
    lines.push('Resolve the detector with `CLAUDE_PLUGIN_ROOT` when that variable is set; otherwise locate prosecheck in the installed skills or plugins folders.');
  } else {
    const det = detectorPath() || path.join(pluginRoot(), 'scripts', 'detect.py');
    lines.push('After writing a prose file, run the bundled detector on that file: `python3 ' + det + ' <file>`.');
  }
  lines.push('Fix flagged spans when the band is worse than the target (at most two fix passes, keeping rhythm variation). ' + target);
  if (level === 'strict') {
    lines.push('Finish by running the detector with `--clean` on the file and saving the scrubbed text back, so no invisible characters or odd spaces remain.');
  }
  return lines;
}

function contract(level, opts) {
  opts = opts || {};
  const portable = !!opts.portable;
  const out = ['# Writing contract (level: ' + level + ')', ''];
  out.push(...ruleLines());
  if (level === 'full' || level === 'strict') {
    out.push('');
    out.push(...detectorStep(level, portable));
  }
  return out.join('\n');
}

function exportSection(level) {
  return MARKER_BEGIN + '\n## Prose writing contract\n\n' + contract(level, { portable: true }).replace(/^# .*\n\n/, '') + '\n' + MARKER_END + '\n';
}

function welcome() {
  return [
    'prosecheck is installed and on. This notice is shown once.',
    'Saved prose is scored locally against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first ' + WINDOW_TXT + ' characters.',
    'There is no website and no upload: nothing you write leaves this machine.',
    'Try `/prosecheck doctor` to check the install, `/prosecheck check` to score a file, `/prosecheck off` to switch it off, and `/prosecheck help` for the full list.',
    '',
  ].join('\n');
}

function cursorRule() {
  const rules = ruleLines().filter((l) => !/^Stay silent/.test(l) || true);
  return [
    '---',
    'description: Prose writing contract for deliverable documents (prose files only)',
    'globs: *.md, *.mdx, *.markdown, *.txt, *.rst, *.tex, *.org, *.adoc',
    'alwaysApply: false',
    '---',
    '',
    '# Writing contract',
    '',
    ...rules,
    '',
  ].join('\n');
}

module.exports = {
  LEVELS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXTS, ZIP_EXTS, ARCH_EXTS, PROSE_EXTS,
  MARKER_BEGIN, MARKER_END, BANNED, LEDGER_MAX,
  configDir, pluginRoot, flagPath, readStored, flagExists, envMode, getLevel, setLevel, readStdinJson,
  detectorPath, runDetector, hookPhrase, labelsOf, ledgerPath, readLedger, appendLedger, pruneLedgers,
  contract, exportSection, welcome, cursorRule,
};
