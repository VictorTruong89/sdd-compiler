#!/usr/bin/env node
'use strict';
// Prompt-submit hook: /prosecheck command router and the per-prompt reminder.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function helpReply(level) {
  return [
    'prosecheck is active at level: ' + level + '.',
    '',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full - the contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard threshold 20 and the cleanup scrub',
    '/prosecheck off - disable prosecheck',
    '/prosecheck on - re-enable prosecheck at the default level',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored this session',
    '/prosecheck check <file> - score one file (report only; never rewrite it)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - session token figures and the score of the session\'s own prose',
    '/prosecheck init - export the contract to ./AGENTS.md for agents other than Claude Code',
    '',
    'prosecheck leaves code, commits, config, and chat alone: it never touches them.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripPath(arg) {
  let p = arg.trim();
  if (p.startsWith('@')) p = p.slice(1).trim();
  const m = /^(["'])(.*)\1$/s.exec(p);
  if (m) p = m[2];
  if (p.startsWith('@') && m) p = p.slice(1);
  return p;
}

function checkReply(arg) {
  if (!arg || !arg.trim()) {
    return 'Usage: /prosecheck check <file>. It scores one prose file and reports; it is a report only and never rewrites the file.';
  }
  const p = stripPath(arg);
  if (!p) return 'Usage: /prosecheck check <file>. Give the path of one prose file.';
  const abs = path.resolve(process.cwd(), p);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + p + ' (no such file or no permission)';
  }
  if (!st.isFile()) return p + ' is not a file';
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (this format is not scored)';
  const isArch = c.ARCH_EXTS.includes(ext);
  const cap = isArch ? c.ARCHIVE_CAP : c.PLAIN_CAP;
  if (st.size > cap) return base + ': over ' + (cap / 1024) + ' KB, so it was not scored';
  const r = c.runDetector(['--', abs], { timeout: isArch ? 15000 : 8000 });
  if (r.state === 'nopython' || r.state === 'nodetector') {
    return 'detector unavailable: Python or the bundled detector could not be started, so nothing was scored.';
  }
  if (r.state === 'timeout') return base + ': the detector failed (timed out)';
  if (r.status !== 0) {
    const err = (r.stderr || '').trim();
    return base + ': the detector failed' + (err ? ': ' + err : ' without a message');
  }
  if (!r.stdout.trim()) return base + ': no report came back from the detector';
  let rep;
  try { rep = JSON.parse(r.stdout); } catch (e) { rep = null; }
  const m = rep && rep._metrics;
  if (!m || typeof m.ai_tell_score !== 'number') return 'no report: the detector printed text that is not a report';
  const lines = [];
  lines.push(base + ' - ' + c.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + c.WINDOW_TXT + ' characters only');
  const items = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    items.push({ label: rep[k].label, count: rep[k].count });
  }
  items.sort((a, b) => b.count - a.count);
  lines.push(items.length
    ? 'tells: ' + items.slice(0, 8).map((x) => x.label + ' (x' + x.count + ')').join('; ')
    : 'tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = c.getLevel();
  const checks = [];
  const modeOk = level !== 'off';
  checks.push(modeOk ? '[OK] mode: ' + level : '[off] mode: off (not a fault of the install) - run /prosecheck on to re-enable');
  const det = c.detectorPath();
  checks.push(det ? '[OK] detector: bundled detector present' : '[FAIL] detector: bundled detector missing from the plugin tree');
  let pyOk = false;
  let pyMissing = false;
  const r = c.runDetector([], { input: 'A short plain sentence for the install check.', timeout: 15000 });
  if (r.state === 'nopython') {
    pyMissing = true;
    checks.push('[FAIL] python not found: the writing contract still shapes new prose, but saved files are not re-scored until Python is available');
  } else if (r.state === 'done' && r.status === 0) {
    try {
      const rep = JSON.parse(r.stdout);
      if (typeof rep._metrics.ai_tell_score === 'number') pyOk = true;
    } catch (e) { /* not numeric */ }
    checks.push(pyOk ? '[OK] python: ran the bundled detector and got a numeric score'
      : '[FAIL] python: ran, but the result was not a numeric score');
  } else {
    checks.push('[FAIL] python: could not run the bundled detector to a result');
  }
  let setOk = false;
  try {
    const dir = c.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const t = path.join(dir, '.prosecheck-doctor-' + process.pid);
    fs.writeFileSync(t, 'x');
    fs.unlinkSync(t);
    setOk = true;
  } catch (e) { setOk = false; }
  checks.push(setOk ? '[OK] settings: folder is writable' : '[FAIL] settings: folder is not writable');
  const faulty = !det || !pyOk || !setOk;
  let closer;
  if (faulty) {
    closer = 'Repair the faulty checks above (a fix is needed), then run /prosecheck doctor again.';
  } else if (!modeOk) {
    closer = 'The install is healthy, but the mode is off, so saving files triggers no scoring: nothing is scored. Turn it back on with ' + form + ' on.';
  } else {
    closer = 'prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are read, and the first ' + c.WINDOW_TXT +
      ' characters are scanned. See files that were only partly scanned or skipped with ' + form + ' show.';
  }
  return ['prosecheck doctor', ...checks, closer].join('\n');
}

function showReply(sid) {
  const rows = c.readLedger(sid);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const lines = ['prosecheck - files seen this session, newest first:'];
  for (let i = rows.length - 1; i >= 0; i--) {
    const r = rows[i];
    let body;
    if (r.kind === 'scored') {
      body = c.hookPhrase(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + c.WINDOW_TXT + ' characters only' : '') + ')';
      if (Array.isArray(r.labels) && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: over the ' + r.limitKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'check failed');
    }
    lines.push('  ' + r.base + ' - ' + body);
  }
  return lines.join('\n');
}

function agentsSection(level) {
  return c.exportSection(level);
}

function initReply(form) {
  const level = c.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so init wrote nothing. Turn it on with ' + form + ' on, then run init again.';
  }
  const cwd = process.cwd();
  const msgs = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let canWrite = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') {
      msgs.push('cannot read AGENTS.md (' + (e.code || 'error') + '), so the contract was not written');
      canWrite = false;
    }
  }
  if (canWrite) {
    if (existing.includes(c.MARKER_BEGIN)) {
      msgs.push('AGENTS.md already contains the prose contract section; it was left unchanged');
    } else {
      let sep = '';
      if (existing.length) sep = (existing.endsWith('\n') ? '' : '\n') + '\n';
      try {
        fs.writeFileSync(agents, existing + sep + agentsSection(level));
        msgs.push('wrote the ' + level + ' writing contract to ./AGENTS.md');
      } catch (e) {
        msgs.push('cannot write AGENTS.md (' + (e.code || 'error') + ')');
      }
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    msgs.push('.cursor/rules/prosecheck.mdc already exists; it was not overwritten');
  } else {
    try {
      let body = null;
      try { body = fs.readFileSync(path.join(c.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8'); } catch (e) { body = null; }
      if (body === null) body = c.cursorRule();
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, body);
      msgs.push('copied the Cursor rule to .cursor/rules/prosecheck.mdc');
    } catch (e) {
      msgs.push('cannot write .cursor/rules/prosecheck.mdc (' + (e.code || 'error') + ')');
    }
  }
  return msgs.join('\n');
}

function run() {
  const p = c.readStdinJson();
  const prompt = typeof p.prompt === 'string' ? p.prompt : '';
  const sid = typeof p.session_id === 'string' ? p.session_id : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    c.setLevel('off');
    block('prosecheck is now off. Re-enable it with /prosecheck on.');
    return;
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/.exec(trimmed);
  if (m) {
    const form = m[1];
    const rest = (m[2] || '').trim();
    const sp = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
    const word = sp ? sp[1] : 'help';
    const arg = sp && sp[2] ? sp[2] : '';
    const sub = word.toLowerCase();
    switch (sub) {
      case 'help':
        return block(helpReply(c.getLevel()));
      case 'lite':
      case 'full':
      case 'strict':
        c.setLevel(sub);
        return block('prosecheck level set to ' + sub + '.');
      case 'off':
        c.setLevel('off');
        return block('prosecheck is off. Saved files will not be scored; re-enable with /prosecheck on.');
      case 'on':
        c.setLevel('full');
        return block('prosecheck is on (full).');
      case 'status':
        return block('Current level: ' + c.getLevel() + '.');
      case 'show':
        return block(showReply(sid));
      case 'check':
        return block(checkReply(arg));
      case 'doctor':
        return block(doctorReply(form));
      case 'stats':
        return block(require('./prosecheck-stats').statsReply(p, form));
      case 'init':
        return block(initReply(form));
      default:
        return block('unknown subcommand "' + word + '". Valid subcommands: ' + SUBS.join(', ') + '.');
    }
  }
  const level = c.getLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }) + '\n');
}

try { run(); } catch (e) { /* never fail the host */ }
process.exit(0);
