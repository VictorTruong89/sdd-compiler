#!/usr/bin/env node
'use strict';
// /prosecheck stats: token figures from the session transcript plus a session-prose score.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common');

function newestTranscript(dir) {
  let best = null;
  let bestT = -1;
  const walk = (d, depth) => {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestT) { bestT = t; best = p; }
        } catch (err) { /* ignore */ }
      }
    }
  };
  walk(dir, 0);
  return best;
}

function statsReply(payload, form) {
  const level = c.getLevel();
  let tp = payload && typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null;
  if (!tp) tp = newestTranscript(path.join(c.configDir(), 'projects'));
  if (!tp) return 'No session transcript found, so there is nothing to total. level: ' + level;
  let raw;
  try {
    const st = fs.statSync(tp);
    if (!st.isFile()) throw new Error('not a file');
    raw = fs.readFileSync(tp, 'utf8');
  } catch (e) {
    return 'The session transcript could not be read, so no token totals are available. level: ' + level;
  }
  const seen = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const id = typeof m.id === 'string' && m.id ? m.id : '#' + (anon++);
    const u = m.usage && typeof m.usage === 'object' ? m.usage : {};
    const out = Number(u.output_tokens) || 0;
    const cache = Number(u.cache_read_input_tokens) || 0;
    const prev = seen.get(id) || { out: 0, cache: 0 };
    seen.set(id, { out: Math.max(prev.out, out), cache: Math.max(prev.cache, cache) });
    if (Array.isArray(m.content)) {
      for (const part of m.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    } else if (typeof m.content === 'string') {
      texts.push(m.content);
    }
  }
  let outT = 0;
  let cacheT = 0;
  for (const v of seen.values()) { outT += v.out; cacheT += v.cache; }
  const lines = [
    'prosecheck session stats',
    'level: ' + level,
    'assistant turns: ' + seen.size,
    'output tokens: ' + outT,
    'cache-read input tokens: ' + cacheT,
  ];
  const kept = [];
  let fence = null;
  for (const ln of texts.join('\n\n').split('\n')) {
    const fm = /^ {0,3}(`{3,}|~{3,})/.exec(ln);
    if (fence) {
      if (fm && fm[1][0] === fence[0] && fm[1].length >= fence.length && /^ {0,3}[`~]+\s*$/.test(ln)) fence = null;
      continue;
    }
    if (fm) { fence = fm[1]; continue; }
    kept.push(ln);
  }
  let prose = kept.join('\n');
  prose = prose.slice(-40000).trim();
  if (prose.length > 200) {
    const r = c.runDetector([], { input: prose, timeout: 15000 });
    if (r.state === 'done' && r.status === 0) {
      try {
        const rep = JSON.parse(r.stdout);
        const s = rep._metrics.ai_tell_score;
        if (typeof s === 'number') lines.push('session prose ai_tell_score: ' + s);
      } catch (e) { /* skip */ }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    process.stdout.write(statsReply(c.readStdinJson(), '/prosecheck') + '\n');
  } catch (e) { /* ignore */ }
  process.exit(0);
}
