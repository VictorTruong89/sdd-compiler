#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only AI-writing pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import sys
import os
import re
import json
import math
import random
import time
import zipfile
import unicodedata
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns (catalogue of 71, 62 machine-checked).
Prints one JSON report (findings plus _metrics) on standard output.

  --clean   print scrubbed text (invisible characters removed, odd spaces
            normalized, lookalike letters folded, whitespace trimmed)
            instead of the report
  --ci      add a resampled low/high interval on the score
  --        stop option parsing so a file name may begin with a dash
  FILE      one file operand; with none, standard input is read
  -h, --help  show this message
"""

PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NO_PROSE_EXTS = {'.pdf', '.rtf'}
MEMBER_LIMIT = 32 * 1024 * 1024


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# ----------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(b'\xef\xbb\xbf'):
        return b[3:].decode('utf-8', 'replace')
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        try:
            return b.decode('utf-16')
        except UnicodeError:
            return b.decode('utf-16', 'replace')
    return b.decode('utf-8', 'replace')


def lname(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def read_member(zf, name):
    try:
        with zf.open(name) as f:
            data = f.read(MEMBER_LIMIT + 1)
        if len(data) > MEMBER_LIMIT:
            return None
        return data
    except Exception:
        return None


def parse_xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def num_key(name):
    m = re.findall(r'\d+', name)
    return (int(m[-1]) if m else 0, name)


def docx_text(zf):
    root = parse_xml(read_member(zf, 'word/document.xml'))
    if root is None:
        return []
    paras = []

    def collect(el, out):
        for ch in el:
            n = lname(ch.tag)
            if n == 'p':
                continue
            if n == 't':
                out.append(ch.text or '')
            elif n == 'tab':
                out.append('\t')
            elif n in ('br', 'cr'):
                out.append('\n')
            else:
                collect(ch, out)

    for p in root.iter():
        if lname(p.tag) == 'p':
            out = []
            collect(p, out)
            s = ''.join(out)
            if s.strip():
                paras.append(s)
    return paras


def pptx_text(zf):
    names = [n for n in zf.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=num_key)
    paras = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        for p in root.iter():
            if lname(p.tag) == 'p':
                out = []
                for e in p.iter():
                    ln = lname(e.tag)
                    if ln == 't':
                        out.append(e.text or '')
                    elif ln == 'br':
                        out.append('\n')
                s = ''.join(out)
                if s.strip():
                    paras.append(s)
    return paras


def xlsx_text(zf):
    shared = []
    root = parse_xml(read_member(zf, 'xl/sharedStrings.xml'))
    if root is not None:
        for si in root:
            if lname(si.tag) != 'si':
                continue
            parts = []

            def walk(e):
                for c in e:
                    n = lname(c.tag)
                    if n == 'rPh':
                        continue
                    if n == 't':
                        parts.append(c.text or '')
                    else:
                        walk(c)
            walk(si)
            shared.append(''.join(parts))
    names = [n for n in zf.namelist() if re.match(r'xl/worksheets/[^/]+\.xml$', n)]
    names.sort(key=num_key)
    out = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        for c in root.iter():
            if lname(c.tag) != 'c':
                continue
            t = c.get('t')
            val = None
            if t == 'inlineStr':
                parts = []
                for e in c.iter():
                    if lname(e.tag) == 't':
                        parts.append(e.text or '')
                val = ''.join(parts)
            elif t in ('s', 'str'):
                v = None
                for e in c:
                    if lname(e.tag) == 'v':
                        v = e.text or ''
                if v is None:
                    continue
                if t == 's':
                    vs = v.strip()
                    if re.fullmatch(r'[0-9]+', vs):
                        idx = int(vs)
                        if idx < len(shared):
                            val = shared[idx]
                else:
                    val = v
            if val is not None and val.strip():
                out.append(val)
    return out


def odf_text(zf):
    root = parse_xml(read_member(zf, 'content.xml'))
    if root is None:
        return []

    def inline(el):
        out = [el.text or '']
        for ch in el:
            n = lname(ch.tag)
            if n == 's':
                try:
                    out.append(' ' * int(ch.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c') or 1))
                except ValueError:
                    out.append(' ')
            elif n == 'tab':
                out.append('\t')
            elif n == 'line-break':
                out.append('\n')
            elif n in ('p', 'h'):
                pass
            else:
                out.append(inline(ch))
            out.append(ch.tail or '')
        return ''.join(out)

    paras = []
    for e in root.iter():
        if lname(e.tag) in ('p', 'h'):
            s = inline(e)
            if s.strip():
                paras.append(s)
    return paras


BLOCK_TAGS = {'p', 'div', 'br', 'li', 'ul', 'ol', 'tr', 'td', 'th', 'table', 'blockquote', 'section',
              'article', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'pre', 'hr', 'dt', 'dd', 'figcaption',
              'header', 'footer', 'aside', 'body'}
SKIP_TAGS = {'script', 'style', 'nav', 'head', 'title'}


class HTMLText(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.lines = []
        self.buf = []
        self.skip = 0
        self.stack = []

    def flush(self):
        s = re.sub(r'\s+', ' ', ''.join(self.buf)).strip()
        self.buf = []
        if s:
            self.lines.append(s)

    def handle_starttag(self, tag, attrs):
        tag = tag.lower().split(':')[-1]
        if tag in SKIP_TAGS:
            self.skip += 1
            self.stack.append(tag)
            return
        if tag in BLOCK_TAGS:
            self.flush()

    def handle_startendtag(self, tag, attrs):
        tag = tag.lower().split(':')[-1]
        if tag in BLOCK_TAGS:
            self.flush()

    def handle_endtag(self, tag):
        tag = tag.lower().split(':')[-1]
        if tag in SKIP_TAGS:
            if tag in self.stack:
                while self.stack:
                    t = self.stack.pop()
                    self.skip = max(0, self.skip - 1)
                    if t == tag:
                        break
            return
        if tag in BLOCK_TAGS:
            self.flush()

    def handle_data(self, data):
        if not self.skip:
            self.buf.append(data)


def epub_text(zf):
    names = zf.namelist()
    order = []
    try:
        cont = parse_xml(read_member(zf, 'META-INF/container.xml'))
        opf_path = None
        if cont is not None:
            for e in cont.iter():
                if lname(e.tag) == 'rootfile' and e.get('full-path'):
                    opf_path = e.get('full-path')
                    break
        if opf_path:
            opf = parse_xml(read_member(zf, opf_path))
            base = opf_path.rsplit('/', 1)[0] + '/' if '/' in opf_path else ''
            manifest = {}
            spine = []
            navs = set()
            if opf is not None:
                for e in opf.iter():
                    ln = lname(e.tag)
                    if ln == 'item':
                        manifest[e.get('id')] = e.get('href')
                        if 'nav' in (e.get('properties') or '').split():
                            navs.add(e.get('id'))
                    elif ln == 'itemref':
                        spine.append(e.get('idref'))
                from urllib.parse import unquote
                for idr in spine:
                    href = manifest.get(idr)
                    if href and idr not in navs:
                        p = base + unquote(href.split('#')[0])
                        if p in names and p not in order:
                            order.append(p)
    except Exception:
        order = []
    rest = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')) and n not in order)
    if not order:
        order = rest
    else:
        # unlisted chapters are not dropped
        order = order + [n for n in rest if not re.search(r'(^|/)(nav|toc)\.[a-z]+$', n, re.I)]
    chapters = []
    for n in order:
        data = read_member(zf, n)
        if data is None:
            continue
        p = HTMLText()
        try:
            p.feed(decode_bytes(data))
            p.close()
        except Exception:
            pass
        p.flush()
        if p.lines:
            chapters.append('\n'.join(p.lines))
    return chapters


def ipynb_text(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            continue
        if s.strip():
            out.append(s)
    return '\n'.join(out)


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except OSError as e:
        raise Fail('cannot read input: %s' % (e.strerror or str(e)))
    if ext in NO_PROSE_EXTS:
        return ''
    if ext in ZIP_EXTS:
        try:
            import io
            zf = zipfile.ZipFile(io.BytesIO(data))
        except Exception as e:
            raise Fail('cannot read input: not a readable zip archive')
        try:
            if ext in ('.docx', '.docm'):
                parts = docx_text(zf)
            elif ext in ('.pptx', '.pptm'):
                parts = pptx_text(zf)
            elif ext in ('.xlsx', '.xlsm'):
                parts = xlsx_text(zf)
            elif ext == '.epub':
                parts = epub_text(zf)
            else:
                parts = odf_text(zf)
        except Exception:
            parts = []
        return '\n'.join(parts).strip()
    if ext == '.ipynb':
        return ipynb_text(data).strip()
    return decode_bytes(data)


# ----------------------------------------------------------- character layer

VISIBLE_CF = {0x600, 0x601, 0x602, 0x603, 0x604, 0x605, 0x6DD, 0x70F, 0x8E2, 0x890, 0x891, 0x110BD, 0x110CD}
EXTRA_INVIS = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D, 0x180E, 0x180F, 0x3164, 0xFFA0}
BIDI = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}
TAG_SEQ = re.compile('\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F')


def is_invisible(o, ch):
    if o < 0x80:
        return (o < 0x20 and o not in (9, 10, 13)) or o == 0x7F
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0xE0000 <= o <= 0xE0FFF:
        return True
    if o in EXTRA_INVIS:
        return True
    cat = unicodedata.category(ch)
    if cat == 'Cc':
        return True
    if cat == 'Cf':
        return o not in VISIBLE_CF
    return False


def in_ranges(o, rs):
    for a, b in rs:
        if a <= o <= b:
            return True
    return False


NOSPACE_R = ((0x3040, 0x30FF), (0x31F0, 0x31FF), (0xFF66, 0xFF9F), (0x4E00, 0x9FFF), (0x3400, 0x4DBF),
             (0x20000, 0x2FA1F), (0xF900, 0xFAFF), (0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F))
JOIN_R = ((0x0590, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF),
          (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF))
RTL_R = ((0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF))
CJK_R = ((0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0x20000, 0x2FA1F), (0xF900, 0xFAFF), (0x3005, 0x3007))
KHMER = (0x1780, 0x17FF)


def is_symbolish(c):
    if not c:
        return False
    o = ord(c)
    if o >= 0x1F000:
        return True
    if o in (0x203C, 0x2049, 0x3030, 0x303D, 0x3297, 0x3299):
        return True
    return unicodedata.category(c)[0] == 'S'


def keep_invisible(text, i, o, rtl, tagkeep):
    n = len(text)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < n else ''
    po = ord(prev) if prev else -1
    no = ord(nxt) if nxt else -1
    if 0xE0000 <= o <= 0xE0FFF:
        return i in tagkeep
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        if no == 0x20E3:
            return True
        if prev and (in_ranges(po, CJK_R) or is_symbolish(prev)):
            return True
        return False
    if o == 0x200B:
        return (prev and in_ranges(po, NOSPACE_R)) or (nxt and in_ranges(no, NOSPACE_R))
    if o == 0x00AD:
        return bool(prev and nxt and prev.isalpha() and nxt.isalpha())
    if o in BIDI:
        return rtl
    if 0x180B <= o <= 0x180F:
        return 0x1820 <= po <= 0x18AA
    if o in (0x17B4, 0x17B5):
        return (KHMER[0] <= po <= KHMER[1]) or (KHMER[0] <= no <= KHMER[1])
    if o in (0x200C, 0x200D):
        for c, oo in ((prev, po), (nxt, no)):
            if c and (in_ranges(oo, JOIN_R) or is_symbolish(c)):
                return True
        return False
    return False


NBSP_BEFORE = set(':;!?»›%€')
NBSP_AFTER = set('«‹')


def keep_nbsp(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt in NBSP_BEFORE and nxt:
        return True
    if prev in NBSP_AFTER and prev:
        return True
    return False


def _build_conf():
    m = {}
    cyr = {'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i', 'ј': 'j', 'о': 'o', 'р': 'p',
           'ѕ': 's', 'ѵ': 'v', 'ԝ': 'w', 'х': 'x', 'у': 'y', 'ԍ': 'g',
           'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I', 'Ј': 'J', 'К': 'K', 'М': 'M',
           'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'У': 'Y'}
    grk = {'ο': 'o', 'ν': 'v', 'ρ': 'p', 'α': 'a', 'ι': 'i', 'υ': 'u', 'χ': 'x', 'ϲ': 'c', 'ϳ': 'j',
           'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N', 'Ο': 'O',
           'Ρ': 'P', 'Τ': 'T', 'Χ': 'X', 'Υ': 'Y', 'Ζ': 'Z', 'Ϲ': 'C', 'Ϳ': 'J'}
    arm = {'օ': 'o', 'ո': 'n', 'ս': 'u', 'ց': 'g', 'հ': 'h', 'ѕ': 's', 'Օ': 'O', 'Ս': 'U', 'Ѕ': 'S'}
    arab = {'ہ': 'o', 'ھ': 'o', 'ە': 'o', '٥': 'o', 'ﻩ': 'o', 'ﻪ': 'o', 'ﻫ': 'o', 'ﻬ': 'o'}
    for d in (cyr, grk, arm, arab):
        m.update(d)
    return m


CONF = _build_conf()
TOKEN = re.compile(r'\S+')


def is_ascii_letter(c):
    return ('a' <= c <= 'z') or ('A' <= c <= 'Z')


def fold_token(tok):
    """Return (folded, count)."""
    if tok.isascii():
        return tok, 0
    for c in tok:
        if ord(c) > 127 and c.isalpha() and c not in CONF:
            return tok, 0
    out = []
    count = 0
    i = 0
    n = len(tok)
    while i < n:
        c = tok[i]
        if c.isalpha():
            j = i
            while j < n and tok[j].isalpha():
                j += 1
            run = tok[i:j]
            has_ascii = any(is_ascii_letter(x) for x in run)
            has_conf = any(x in CONF for x in run)
            if has_ascii and has_conf:
                for x in run:
                    if x in CONF:
                        out.append(CONF[x])
                        count += 1
                    else:
                        out.append(x)
            else:
                out.append(run)
            i = j
        else:
            out.append(c)
            i += 1
    return ''.join(out), count


def scrub(text):
    """Character layer. Returns (cleaned, n_invisible, n_spaces, n_homoglyph)."""
    n_inv = n_sp = 0
    if text.isascii() and not re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', text):
        return text, 0, 0, 0
    rtl = False
    for ch in text:
        if ord(ch) >= 0x590 and in_ranges(ord(ch), RTL_R):
            rtl = True
            break
    tagkeep = set()
    if '\U0001F3F4' in text:
        for m in TAG_SEQ.finditer(text):
            tagkeep.update(range(m.start() + 1, m.end()))
    out = []
    for i, ch in enumerate(text):
        o = ord(ch)
        if o < 0x80:
            if (o >= 0x20 and o != 0x7F) or o in (9, 10, 13):
                out.append(ch)
            else:
                n_inv += 1
            continue
        if is_invisible(o, ch):
            if keep_invisible(text, i, o, rtl, tagkeep):
                out.append(ch)
            else:
                n_inv += 1
            continue
        if o in (0x2028, 0x2029):
            out.append('\n')
            n_sp += 1
            continue
        if unicodedata.category(ch) == 'Zs':
            if o in (0xA0, 0x202F) and keep_nbsp(text, i):
                out.append(ch)
            else:
                out.append(' ')
                n_sp += 1
            continue
        out.append(ch)
    s = ''.join(out)
    n_h = 0
    if not s.isascii():
        def rep(m):
            nonlocal n_h
            t, c = fold_token(m.group(0))
            n_h += c
            return t
        s = TOKEN.sub(rep, s)
    return s, n_inv, n_sp, n_h


def clean_text(text):
    s, _, _, _ = scrub(text)
    ended_lf = text.endswith('\n')
    crlf = text.endswith('\r\n')
    lines = s.split('\n')
    res = []
    for ln in lines:
        cr = ln.endswith('\r')
        body = ln[:-1] if cr else ln
        body = body.rstrip(' \t')
        res.append(body + ('\r' if cr else ''))
    k = 0
    while k < len(res) and res[k].strip() == '':
        k += 1
    s = '\n'.join(res[k:])
    s = s.rstrip()
    if ended_lf:
        s += '\r\n' if crlf else '\n'
    return s


# ----------------------------------------------------------------- masking

FENCE_RE = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
BADGE_RE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
TABLE_ROW = re.compile(r'^\s*\|.*\|\s*$')
TABLE_SEP = re.compile(r'^\s*\|?\s*:?-{1,}:?\s*(?:\|\s*:?-{1,}:?\s*)+\|?\s*$')
INLINE_CODE = re.compile(r'(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)', re.S)


def mask_text(T):
    """Position-preserving: excluded regions become spaces (newlines kept)."""
    lines = T.split('\n')
    n = len(lines)
    drop = [False] * n
    # front matter
    if n > 2 and lines[0].strip() == '---' and lines[0] == '---':
        for j in range(1, n):
            if lines[j].rstrip() == '---' or lines[j].rstrip() == '...':
                for k in range(0, j + 1):
                    drop[k] = True
                break
    # fences
    i = 0
    while i < n:
        if drop[i]:
            i += 1
            continue
        m = FENCE_RE.match(lines[i])
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            j = i + 1
            end = n - 1
            while j < n:
                cm = re.match(r'^ {0,3}(' + re.escape(ch) + '{' + str(ln) + r',})[ \t]*$', lines[j])
                if cm:
                    end = j
                    break
                j += 1
            for k in range(i, end + 1):
                drop[k] = True
            i = end + 1
            continue
        i += 1
    # blockquotes (2+ consecutive)
    i = 0
    while i < n:
        if not drop[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j < n and not drop[j] and re.match(r'^ {0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    drop[k] = True
            i = j
        else:
            i += 1
    for i in range(n):
        if drop[i]:
            continue
        ln = lines[i]
        if TABLE_ROW.match(ln) or TABLE_SEP.match(ln) or BADGE_RE.match(ln):
            drop[i] = True
    # inline code on remaining text
    out = []
    kept_idx = [i for i in range(n) if not drop[i]]
    # build per-line then inline code across paragraphs
    new_lines = [(' ' * len(l)) if drop[i] else l for i, l in enumerate(lines)]
    joined = '\n'.join(new_lines)
    if '`' in joined:
        def blank(m):
            return re.sub(r'[^\n]', ' ', m.group(0))
        joined = INLINE_CODE.sub(blank, joined)
    return joined


# ------------------------------------------------------------ pattern tables

def infl(w, adj=False):
    forms = {w}
    if w.endswith('e'):
        forms |= {w + 's', w + 'd', w[:-1] + 'ing'}
    elif w.endswith('y') and len(w) > 3:
        forms |= {w[:-1] + 'ies', w[:-1] + 'ied', w + 's', w[:-1] + 'ying'}
    else:
        forms |= {w + 's', w + 'es', w + 'ed', w + 'ing'}
    if adj:
        forms.add(w + 'ly')
    return forms


def word_rx(words, adj_words=()):
    forms = set()
    for w in words:
        forms |= infl(w)
    for w in adj_words:
        forms |= infl(w, True)
    return r'\b(?:' + '|'.join(sorted((re.escape(f) for f in forms), key=len, reverse=True)) + r')\b'


AP = "[’']"
I = re.I


def C(p, flags=I):
    return re.compile(p, flags)


AI_WORDS = ['delve', 'tapestry', 'testament', 'underscore', 'intricacies', 'interplay', 'garner', 'bolster',
            'foster', 'showcase', 'emphasize', 'emphasise', 'enhance', 'leverage', 'utilize', 'utilise',
            'facilitate', 'encompass', 'harness', 'paradigm', 'myriad', 'plethora', 'navigate', 'embark',
            'craft', 'landscape', 'journey', 'realm', 'elevate', 'empower', 'unlock']
AI_ADJ = ['crucial', 'pivotal', 'vibrant', 'meticulous', 'intricate', 'enduring', 'holistic',
          'transformative', 'unprecedented', 'robust', 'seamless', 'multifaceted']
AI1 = [
    C(word_rx(AI_WORDS, AI_ADJ)),
    C(r'\badditionally\b'),
    C(r'\balign(?:s|ed|ing)? with\b'),
    C(r'\bcaptur(?:e|es|ed|ing) (?:the )?(?:essence|spirit|imagination|heart|magic)\b'),
]

FAMILY_RX = {}


def fam(num, *pats):
    FAMILY_RX.setdefault(num, []).extend(C(p) if isinstance(p, str) else p for p in pats)


fam(2,
    r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b',
    r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b',
    r'\bresonat(?:e|es|ed|ing) deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b',
    r'\b(?:supercharg|skyrocket|turbocharg|revolutioniz|revolutionis)(?:e|es|ed|ing)?\b',
    r'\bdoubl(?:e|es|ed|ing) down on\b',
    r'\bdiv(?:e|es|ed|ing) deep(?:er)? into\b',
    r'\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b',
    r'\btak(?:e|es|ing|en) [^.!?\n]{1,40}? to the next level\b')
fam(3,
    r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|unparalleled|premier|leading|world-class|top-tier|results-oriented)\b',
    r'\bvibrant community\b', r'\brich cultural heritage\b', r'\bin the heart of\b',
    r'\besteemed organi[sz]ation\b', r'\bvaluable asset\b', r'\bpassion for excellence\b',
    r'\bproven track record\b', r'\bwealth of experience\b', r'\bdynamic team\b',
    r'\bfast-paced environment\b', r'\bdeeply passionate\b', r'\bperfectly situated\b',
    r'\b(?:close|tight)-knit team\b', r'\bi am excited to (?:apply|bring)\b', r'\buniquely positioned to\b')
fam(5, r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')
fam(10,
    r'\b(?:stand|stands|stood|standing|serve|serves|served|serving) as (?:a|an) (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor(?:e|es|ed|ing)|highlight(?:s|ed|ing)?) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflect(?:s|ed|ing)? a broader (?:trend|shift|pattern)\b',
    r'\bmark(?:s|ed|ing)? a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymboli[sz](?:es|ed|ing)\b',
    r'\bset(?:s|ting)? the stage for\b',
    r'\bleft an indelible mark\b',
    r'\bpla(?:y|ys|yed|ying) a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\bhas (?:shaped|sparked)\b',
    r'\bhas come to (?:define|symboli[sz]e)\b')
fam(11,
    r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) (?-i:[A-Z][\w&.\'’-]*(?: [A-Z][\w&.\'’-]*)*(?:, (?:and )?| and )[A-Z][\w&.\'’-]*)',
    r'\b\d[\d,.]*[km]? (?:followers|subscribers)\b',
    r'\b(?:strong|active) (?:online|digital|social[- ]media) presence\b',
    r'\bwidely covered\b', r'\bindependent coverage\b')
fam(12,
    r'\bexperts (?:argue|believe|say|claim|note|suggest)\b',
    r'\bindustry (?:reports|observers|analysts)\b',
    r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b',
    r'\bresearchers have found\b', r'\bstudies suggest\b', r'\bit is widely believed\b')
fam(13,
    r'\bthe (?:list|index|compilation|collection|catalogue|catalog|guide|overview) of [^.!?\n]{1,120}? (?:is|are|was|were) (?:a|an|the)\b')
fam(14,
    r'\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts are (?:underway|ongoing|in place)\b',
    r'\bserves as an indicator species\b', r'\bcontributes? to biodiversity\b')
fam(15,
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b')
fam(16,
    r',\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')
fam('17p',
    r'\bit' + AP + r's not (?:just|merely) (?:about|an?)\b',
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn' + AP + r't just\b[^,.\n]{0,40}?\bit\b')
fam('17t', r',\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b')
fam(18,
    r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
    r'\b(?:not|isn' + AP + r't|aren' + AP + r't|wasn' + AP + r't|weren' + AP + r't) (?:just|merely)(?: (?:a|an|the))? \w+(?:,|\s*[—–-]+)\s*(?:it' + AP + r's|it is|it was|they' + AP + r're|they are|they were|that' + AP + r's|but)\b')
fam(19, r'\bin order to\b', r'\bdue to the fact that\b', r'\bat this point in time\b', r'\bin the event that\b',
    r'\bhas the ability to\b', r'\bit is important to note that\b', r'\bit should be mentioned that\b',
    r'\bneedless to say\b')
fam(20,
    r'\bit' + AP + r's worth (?:noting|mentioning) that\b', r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to (?:consider|keep in mind) is\b', r'\bit is interesting to note that\b',
    r'\ba key consideration is\b', r'\ba point to highlight is\b', r'\bit is worth (?:noting|mentioning) that\b')
fam(21,
    r',\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward|signalling a shift toward)\b')
fam(22,
    r"\bhere" + AP + r"s the thing\b", r'\bmake no mistake\b', r'\bthe truth is\b', r'\blet' + AP + r's be honest\b',
    r'\bthe simple fact is\b', r'\bat its core\b', r'\bwhat really matters\b', r'\bmore than anything\b',
    r'\bat the end of the day\b', r'\bthe bottom line is\b', r'\bin reality\b', r'\bfundamentally,',
    r'\bthe real question is\b', r'\bthe heart of the matter\b', r'\bthe deeper issue\b',
    r'\bwhen you get down to it\b', r'\bwhen all is said and done\b')
fam(23,
    r'\bit(?:' + AP + r's| is) important to (?:remember|note|understand|recognize|recognise)\b',
    r'\bone must note that\b', r'\bit is worth pointing out\b', r'\bit cannot be overstated that\b',
    r'\bit must be emphasi[sz]ed that\b')
fam(24,
    r'\bthis (?:comprehensive|in-depth|complete) (?:guide|overview|analysis|look|examination)\b',
    r'\ba thorough examination of\b', r'\beverything you need to know about\b')
fam(26,
    r'\bwithout concrete evidence\b', r'\bdo you have concrete evidence\b',
    r'\bi (?:would )?need concrete (?:evidence|examples) to\b', r'\babsent concrete proof\b',
    r'\bprovide concrete evidence\b')
fam(27,
    r'\bin today' + AP + r's (?:\w+ ){0,2}(?:world|landscape|environment|market)\b',
    r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,', r'\bmore than ever before\b',
    r'\bwe live in a (?:time|world) when\b', r'\b(?:great|exciting|big) news[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished) to\b[^.?!\n]{0,100}\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b')
fam(30,
    r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
    r'\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
    r'\bpreviously\b[^.!?\n]{0,120}?\bnow\b',
    r'\b(?:wasn' + AP + r't|weren' + AP + r't) there before\b',
    r'\bwe(?:' + AP + r've| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b')
fam(31,
    r'\blet' + AP + r's (?:dive|delve|explore)\b', r'\blet' + AP + r's break (?:this|it) down\b',
    r'\bhere' + AP + r's what you need to know\b', r'\bwithout further ado\b', r'\bnow let' + AP + r's look at\b',
    r'\bbuckle up\b', r'\bstay with me\b', r'\b(?:are you )?ready to dive in\b')
fam(32,
    r'\b(?:used|uses|employs|employed|relied on|relies on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+',
    r'(?:^|[.!?]\s+)These(?: \w+)? (?:provide|offer|give|reveal|show|allow|enable|help)s? (?:information|insights?|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b')
fam(36,
    r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
    r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
    r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
    r'\bfaces (?:several|many|numerous) challenges\b')
fam(39,
    r'\bthe future looks bright\b', r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b',
    r'\bstep in the right direction\b', r'\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40}?)? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b')
fam(47,
    r'\bi hope this helps\b', r'\bcertainly!', r'\bof course!', r'\blet me know if you\b',
    r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help[.!?]',
    r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
    r'\bhere(?:' + AP + r's| are) (?:a )?(?:few|some|two|three) (?:options|drafts|versions|variations)\b',
    r'\bhere(?:' + AP + r's| is) a draft\b', r'\bdepending on the (?:vibe|tone|style)\b',
    r'\bi hope (?:this (?:email )?)?finds you well\b',
    r'\bas an? (?:ai|llm|ai assistant|ai language model|large language model|language model)\b',
    r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
    r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked),? here\b',
    r'\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b')
fam(48,
    r'\byou(?:' + AP + r're| are) absolutely right\b',
    r'\b(?:great question|excellent point)\s*[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
    r'\bthat' + AP + r's a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b')
fam(50,
    r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b',
    r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
    r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b')
fam(51,
    r'\b(?:serves|served|serving|stands|stood|functions|functioned|acts|acted) as\b',
    r'\brepresents (?:a|the)\b', r'\bmarks (?:a|the)\b', r'\bboast(?:s|ed|ing)?\b',
    r'\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various|some|two|three|four|five|six)\b',
    r'\boffers a\b', r'\brefers to\b')
fam(57, '[\U0001F000-\U0001FAFF☀-➿⭐⭕⬛⬜⌚⌛⏩-⏳⏸-⏺⤴⤵〰〽㊗㊙]')
fam(58, '—')
fam(56, r'\*\*[^*\n]+?\*\*')
fam(60, '[‘’“”]')
fam(4,
    r'\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|data-driven|forward-thinking|game-changing|fast-paced|detail-oriented|customer-centric|mission-critical|next-generation|end-to-end|user-friendly|results-oriented|well-rounded|thought-provoking|ground-breaking|award-winning|cross-functional|value-added|full-service|one-stop|hard-working|self-motivated|team-oriented|client-focused|tech-savvy|world-class|high-impact|high-performing|action-oriented|solutions-oriented|innovation-driven)\b')
fam(69,
    r'\bunlocking (?:the |its |their |your )?(?:full )?potential\b', r'\bunlock the full potential\b',
    r'\bnavigat(?:e|es|ed|ing) the complexities\b', r'\ba testament to the (?:power|importance)\b',
    r'\bstaying ahead of the curve\b', r'\bturning challenges into opportunities\b',
    r'\btaking [^.!?\n]{1,30}? to the next level\b', r'\bharnessing the power of\b',
    r'\bpaving the way for\b', r'\bsaying goodbye to\b', r'\bimagining a world where\b',
    r'\bin the ever-evolving\b', r'\bembark on a journey\b', r'\ba rich tapestry\b',
    r'\bunleash(?:ing)? the power\b')
fam(70, r'^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$')

PH_BRACKET = re.compile(r'\[([^\[\]\n]{1,80})\](?![(\[])')
PH_WORDS = re.compile(r'^\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b', I)
PH_NAMES = re.compile(r'\b(?:name|person|company|client|city|place|source|location|organi[sz]ation|employer|recipient)\b', I)
PH_CAPS = re.compile(r'^[A-Z][A-Z0-9 _\-/]{2,}$')
PH_SHORT = re.compile(r'^(?:[A-Z]{1,2}[0-9]{0,3}|[A-Z][0-9]+(?:[,\-–]\s*[A-Z]?[0-9]+)*)$')
PH_OTHER = [re.compile(r'\{\{[^{}\n]*\}\}'), re.compile(r'(?<![A-Za-z])[xX]{3,}(?![A-Za-z])'),
            re.compile(r'\blorem ipsum\b', I)]
CHAT_MARK = [re.compile(r'\bcite(?:turn|start|nav)\w*'), re.compile(r'\boai_citation\w*'),
             re.compile(r'contentReference'), re.compile(r'\bnavlist'), re.compile(r'【\d+†[^】\n]*】')]
UTM = re.compile(r'utm_source=([A-Za-z0-9.\-]+)', I)
TRACK_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
               'copilot.microsoft.com', 'poe.com'}

WORD_RE = re.compile(r"[^\W_]+(?:['’\-][^\W_]+)*")
SENT_SPLIT = re.compile(r'(?<=[.!?])["\'”’)\]]*\s+')
HEADING_RE = re.compile(r'^ {0,3}#{1,6}[ \t]+(.*?)[ \t]*#*[ \t]*$')
LIST_RE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')

SYN_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'organisation', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def _plural(w):
    if w.endswith('y'):
        return [w, w[:-1] + 'ies']
    if w.endswith(('s', 'x', 'ch', 'sh')):
        return [w, w + 'es']
    if w == 'analysis':
        return ['analysis', 'analyses']
    return [w, w + 's']


SYN_RX = []
for cl in SYN_CLUSTERS:
    SYN_RX.append([C(r'\b(?:' + '|'.join(re.escape(f) for f in _plural(m)) + r')\b') for m in cl])

IMPERATIVES = ('install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape', 'transform',
               'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore', 'meet', 'introducing',
               'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop', 'start')

TRANSITIONS = ('Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless', 'Consequently',
               'Subsequently', 'Notably')
OPENERS_38 = re.compile(r'^[ \t#>*_\-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b', I | re.M)

CAT = {
    1: ('ai_vocabulary', 'AI vocabulary', 12), 2: ('model_dialect', 'Model-dialect vocabulary', 10),
    3: ('promotional_language', 'Promotional language', 10), 4: ('hyphenated_pairs', 'Hyphenated word-pair overuse', 0),
    5: ('simple_yet', '"Simple yet X" cliche', 8), 6: ('adjective_chains', 'Stacked adjective chains', 8),
    8: ('synonym_cycling', 'Synonym cycling', 8), 10: ('significance_inflation', 'Significance inflation', 12),
    11: ('notability_name_dropping', 'Notability name-dropping', 10), 12: ('vague_attributions', 'Vague attributions', 10),
    13: ('title_as_proper_noun', 'Article title as proper noun', 20), 14: ('ecosystem_padding', 'Conservation / ecosystem padding', 10),
    15: ('false_ranges', 'False ranges', 8), 16: ('ing_tails', 'Superficial -ing tail clauses', 10),
    '17p': ('negative_parallelism', 'Negative parallelism', 0), '17t': ('tailing_negation', 'Tailing negation', 8),
    18: ('not_x_just_y', '"Not X, just Y" construction', 10), 19: ('filler_phrases', 'Filler phrases', 0),
    20: ('empty_pivots', 'Empty pivot phrases', 10), 21: ('speculation_tails', 'Outcome speculation tails', 10),
    22: ('authority_tropes', 'Persuasive authority tropes', 0), 23: ('editorial_interjections', 'Editorial interjections', 10),
    24: ('self_thoroughness', 'Self-thoroughness phrases', 10), 25: ('question_answer', 'Question-answer rhetorical pattern', 8),
    26: ('concrete_evidence', '"Concrete evidence" defense phrase', 8), 27: ('intro_hooks', 'Compulsive intro hooks', 10),
    30: ('diff_anchored', 'Diff-anchored writing', 8), 31: ('signposting', 'Signposting and announcements', 10),
    32: ('cataloguing_leadins', 'Cataloguing lead-ins', 8), 33: ('inline_header_lists', 'Inline-header vertical lists', 6),
    34: ('bullet_injection', 'Mid-essay bullet injection', 6), 35: ('fragmented_headers', 'Fragmented headers', 6),
    36: ('formulaic_challenges', 'Formulaic challenges section', 10), 37: ('transition_clusters', 'Transition cluster overuse', 8),
    38: ('compulsive_conclusions', 'Compulsive conclusion phrases', 8), 39: ('generic_positive_conclusions', 'Generic positive conclusions', 10),
    40: ('sentence_monotony', 'Sentence-length monotony', 6), 41: ('mechanical_alternation', 'Mechanical sentence-length alternation', 0),
    42: ('opener_repetition', 'Opener repetition', 0), 44: ('uniform_paragraphs', 'Uniform paragraph length', 6),
    46: ('no_semicolons', 'Semicolon and parenthesis underuse', 0), 47: ('chatbot_artifacts', 'Chatbot artifacts', 20),
    48: ('sycophancy', 'Sycophantic / servile tone', 20), 50: ('knowledge_cutoff', 'Knowledge-cutoff disclaimers', 20),
    51: ('copula_avoidance', 'Copula avoidance', 6), 54: ('hedge_stacking', 'Excessive hedging', 0),
    55: ('contraction_absence', 'Contraction absence', 0), 56: ('boldface', 'Boldface overuse', 6),
    57: ('emojis', 'Emojis', 6), 58: ('em_dashes', 'Em-dash overuse', 0), 59: ('title_case_headings', 'Title case in headings', 5),
    60: ('curly_quotes', 'Curly quotation marks', 0), 61: ('hyphen_ranges', 'Hyphen-for-en-dash in ranges', 0),
    62: ('invisible_chars', 'Invisible / zero-width characters', 22), 63: ('placeholder_text', 'Placeholder / Mad-Libs text', 22),
    64: ('chat_markup_leak', 'Chatbot reference-markup leak', 22), 65: ('tracking_params', 'AI tracking parameters', 22),
    66: ('homoglyphs', 'Homoglyph / mixed-script confusables', 22), 67: ('nonstandard_spaces', 'Non-standard spaces', 10),
    68: ('trailing_whitespace', 'Trailing / stray whitespace', 0), 69: ('marketing_slop', 'Canonical marketing-slop phrases', 12),
    70: ('horizontal_rules', 'Decorative horizontal rules', 6), 71: ('degenerate_repetition', 'Degenerate repetition', 16),
}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
EARLY = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
STOP_NOUN = set('a an the and or but is are was were be been of in on at to for with by from as that this these those it its their his her our your my we you they he she i not no so if then than when while which who whom whose what where how also very more most can could may might will would should shall must do does did has have had'.split())
STOCK_ADJ = set('innovative scalable dynamic powerful seamless comprehensive reliable flexible efficient modern secure intuitive engaging compelling exciting stunning rich vibrant bold sleek elegant robust cutting-edge dynamic transformative holistic'.split())
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial', 'ary', 'ory', 'ish')
CHAIN_RE = re.compile(r"\b[A-Za-z][A-Za-z\-]*(?:,\s+(?:and\s+)?[A-Za-z][A-Za-z\-]*){2,}(?:\s+and\s+[A-Za-z][A-Za-z\-]*)?(?:\s+[A-Za-z][A-Za-z\-]*)?")
MINOR = set('a an the and but or nor for so yet of in on at to by up as from with into per via vs off over'.split())


def is_adj(w):
    w = w.lower()
    return w in STOCK_ADJ or (len(w) > 3 and w.endswith(ADJ_SUFFIX))


def find_chains(T):
    hits = []
    for m in CHAIN_RE.finditer(T):
        s = m.group(0)
        toks = re.findall(r"[A-Za-z][A-Za-z\-]*", s)
        # drop connectors
        words = [t for t in toks if t.lower() != 'and']
        if len(words) < 4:
            continue
        last = words[-1].lower()
        if last in STOP_NOUN or last.endswith('ly'):
            continue
        # chain words before final noun
        pre = words[:-1]
        if any(w.lower() in STOP_NOUN for w in words):
            continue
        if not any(is_adj(w) for w in pre):
            continue
        # noun: last word is not itself adjectival-only suffix chain end unless followed by noun
        if is_adj(words[-1]) and not s.rstrip().endswith(words[-1]):
            continue
        hits.append(s)
    return hits


def excerpt(T, s, e, pad=30):
    a = max(0, s - pad)
    b = min(len(T), e + pad)
    ex = T[a:b].replace('\n', ' ').strip()
    return ('...' if a > 0 else '') + ex + ('...' if b < len(T) else '')


def short(s):
    s = s.replace('\n', ' ')
    return s if len(s) <= 80 else s[:77] + '...'


def cv(vals):
    m = sum(vals) / len(vals)
    if m == 0:
        return 1.0
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / m


def split_paragraphs(M):
    return [p for p in re.split(r'\n[ \t]*\n+', M) if p.strip()]


def para_sentences(p):
    """Sentences in a paragraph, ignoring heading lines, stripping list markers."""
    lines = []
    for ln in p.split('\n'):
        if HEADING_RE.match(ln):
            continue
        lines.append(LIST_RE.sub('', ln).strip())
    out = []
    for ln in lines:
        if not ln:
            continue
        for s in SENT_SPLIT.split(ln):
            s = s.strip()
            if s and WORD_RE.search(s):
                out.append(s)
    return out


def analyze(W, light=False):
    """W: window text. Returns dict with findings (num->(count,samples)), metrics, sentences."""
    T = W.replace('\r\n', '\n').replace('\r', '\n')
    M = mask_text(T)
    F = {}

    def add(key, count, samples):
        if count > 0:
            F[key] = (count, samples[:3])

    # character layer
    if not light:
        _, n_inv, n_sp, n_h = scrub(M)
    else:
        n_inv = n_sp = n_h = 0
    if n_inv:
        add(62, n_inv, ['%d invisible character(s)' % n_inv])
    if n_sp:
        add(67, n_sp, ['%d non-standard space(s)' % n_sp])
    if n_h:
        add(66, n_h, ['%d lookalike letter(s)' % n_h])
    if not light:
        tw = 0
        samp = []
        for ln in W.split('\n'):
            body = ln[:-1] if ln.endswith('\r') else ln
            if body.endswith((' ', '\t')):
                tw += 1
                if len(samp) < 3:
                    samp.append('trailing whitespace on a line')
        if W and W[0].isspace():
            tw += 1
            samp.append('whitespace before first character')
        if W.endswith((' ', '\t')):
            tw += 1
            samp.append('whitespace at end of text')
        elif W.endswith('\n\n') or W.endswith('\n\r\n') or re.search(r'\n[ \t\r]*\n[ \t\r]*$', W) and W.endswith('\n'):
            tw += 1
            samp.append('blank lines at end of text')
        add(68, tw, samp)

    # lexical
    for m_ in AI1:
        pass
    cnt = 0
    samp = []
    for rx in AI1:
        for m in rx.finditer(M):
            cnt += 1
            if len(samp) < 3:
                samp.append(excerpt(T, m.start(), m.end()))
    add(1, cnt, samp)

    for num, rxs in FAMILY_RX.items():
        cnt = 0
        samp = []
        for rx in rxs:
            for m in rx.finditer(M):
                cnt += 1
                if len(samp) < 3:
                    samp.append(short(T[m.start():m.end()]))
        if num == 70:
            continue
        key = num
        if num == 3:
            pass
        add(key, cnt, samp)

    paras = split_paragraphs(M)
    para_sents = [para_sentences(p) for p in paras]

    # 3: marketing imperatives
    imp = 0
    for ps in para_sents:
        for s in ps:
            fw = WORD_RE.match(s)
            if fw and fw.group(0).lower() in IMPERATIVES:
                imp += 1
    if imp >= 3:
        c, sm = F.get(3, (0, []))
        add(3, c + imp, sm + ['%d imperative-opening sentences' % imp])

    # 6 chains
    ch = find_chains(M)
    add(6, len(ch), [short(x) for x in ch])

    # 8 synonym cycling
    low = M
    cyc = 0
    samp = []
    for cl, rxs in zip(SYN_CLUSTERS, SYN_RX):
        present = [cl[i] for i, rx in enumerate(rxs) if rx.search(low)]
        if len(present) >= 3:
            cyc += 1
            samp.append(', '.join(present))
    add(8, cyc, samp)

    # 25 question-answer
    qa = re.findall(r'(?:^|(?<=[.!?])\s+|\n)((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|May|Might|Must|Has|Have|Had)\b[^.!?\n]{0,80}\?)\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)\s*[.!]', M)
    add(25, len(qa), qa)

    # 33 inline-header lists
    h33 = [m.group(0).strip() for m in re.finditer(r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)', M, re.M)]
    add(33, len(h33), [short(x) for x in h33])

    # headings
    lines = M.split('\n')
    has_heading = any(HEADING_RE.match(l) for l in lines)

    # 34 bullet injection
    if not has_heading:
        listp = 0
        prose = 0
        for p in paras:
            pl = [l for l in p.split('\n') if l.strip()]
            if pl and all(LIST_RE.match(l) for l in pl):
                listp += 1
            elif pl and not any(LIST_RE.match(l) for l in pl):
                prose += 1
        if listp >= 1 and prose >= 2:
            add(34, listp, ['bulleted paragraph in a headingless essay'])

    # 35 fragmented headers & 59 title case
    f35 = []
    t59 = []
    for i, l in enumerate(lines):
        hm = HEADING_RE.match(l)
        if not hm:
            continue
        title = hm.group(1)
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j < len(lines):
            nl = lines[j].strip()
            if nl and not HEADING_RE.match(lines[j]) and not LIST_RE.match(nl) and not nl.startswith('|'):
                nw = WORD_RE.findall(nl)
                hw = {w.lower() for w in WORD_RE.findall(title)}
                if 0 < len(nw) <= 5 and any(w.lower() in hw for w in nw) and not re.search(r'[.!?]\s*$', nl) or (0 < len(nw) <= 4 and any(w.lower() in hw for w in nw)):
                    f35.append(title)
        words = [w for w in title.split() if re.search(r'[A-Za-z]', w)]
        if len(words) >= 3 and title and title[0].isalpha() and not title.isupper():
            major = [w for w in words if w.strip('.,:;!?()"\'*_').lower() not in MINOR]
            if len(major) >= 2 and all(w.lstrip('("\'*_')[:1].isupper() for w in major):
                t59.append(title)
    add(35, len(f35), f35)
    add(59, len(t59), t59)

    # 37 transitions, 42 opener repetition, 40/41 sentences
    tcount = 0
    t_samp = []
    rep42 = 0
    for ps in para_sents:
        n = 0
        for s in ps:
            s2 = s.lstrip('*_"\'“‘(')
            fw = WORD_RE.match(s2)
            if fw and fw.group(0) in TRANSITIONS:
                n += 1
                if len(t_samp) < 3:
                    t_samp.append(short(s2[:40]))
        if n >= 2:
            tcount += n
        if len(ps) >= 3:
            opens = {}
            for s in ps:
                ws = [w.lower() for w in WORD_RE.findall(s)[:2]]
                if len(ws) == 2:
                    k = ' '.join(ws)
                    opens[k] = opens.get(k, 0) + 1
            for k, v in opens.items():
                if v >= 3:
                    rep42 += 1
    add(37, tcount, t_samp)
    add(42, rep42, ['repeated sentence opener'])

    c38 = [m.group(0).strip() for m in OPENERS_38.finditer(M)]
    add(38, len(c38), c38)

    sents = [s for ps in para_sents for s in ps]
    lens = [len(WORD_RE.findall(s)) for s in sents]
    if len(lens) >= 3 and cv(lens) < 0.35:
        add(40, 1, ['sentence-length CV %.2f' % cv(lens)])
    if len(lens) >= 6:
        for a in range(0, len(lens) - 5):
            win = lens[a:a + 6]
            diffs = [win[k + 1] - win[k] for k in range(5)]
            if all(diffs[k] * diffs[k + 1] < 0 for k in range(4)) and all(abs(d) >= 5 for d in diffs) and max(win) >= 1.5 * min(win):
                add(41, 1, ['alternating sentence lengths'])
                break

    # 44 uniform paragraphs
    pw = []
    for p in paras:
        keep = [l for l in p.split('\n') if l.strip() and not HEADING_RE.match(l)]
        n = len(WORD_RE.findall('\n'.join(keep)))
        if n:
            pw.append(n)
    if len(pw) >= 4 and cv(pw) < 0.4:
        add(44, 1, ['paragraph-length CV %.2f' % cv(pw)])

    words_all = WORD_RE.findall(M)
    nwords = len(words_all)

    # 46
    if nwords >= 300 and ';' not in M and M.count('(') <= 1:
        add(46, 1, ['no semicolons, almost no parentheses'])

    # 54 hedges
    hedge = re.compile(r"\b(?-i:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
    h54 = 0
    hs = []
    for s in sents:
        hits = hedge.findall(s)
        if len(hits) >= 2:
            h54 += 1
            hs.append(short(s))
    add(54, h54, hs)

    # 55 contraction absence
    fp = len(re.findall(r"\b(?:I|me|my|mine|myself|we|our|ours|us|I[’']m|I[’']ve|I[’']ll|I[’']d)\b", M, re.I))
    if nwords and fp / nwords >= 0.02 and fp >= 3:
        full = len(re.findall(r"\b(?:do|does|did|is|are|was|were|will|would|should|could|have|has|had|can) not\b|\bcannot\b|\b(?:I|we|you|they) (?:am|are|will|have|would)\b|\b(?:it|that|there|what|he|she) is\b|\blet us\b", M, re.I))
        con = len(re.findall(r"\b\w+n[’']t\b|\b(?:I|we|you|they|he|she|it|that|there|what|who|let)[’'](?:m|re|ve|ll|d|s)\b", M, re.I))
        if full >= 3 and full > con:
            add(55, full, ['%d forms written out, %d contracted' % (full, con)])

    # 61 hyphen ranges
    r61 = [m.group(0) for m in re.finditer(r'\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b', M) if int(m.group(1)) < int(m.group(2))]
    add(61, len(r61), r61)

    # 63 placeholders
    ph = []
    for m in PH_BRACKET.finditer(M):
        c = m.group(1)
        cs = c.strip()
        if PH_WORDS.match(c) or PH_NAMES.search(c):
            ph.append(m.group(0))
        elif PH_CAPS.match(cs) and not PH_SHORT.match(cs):
            ph.append(m.group(0))
    for rx in PH_OTHER:
        ph.extend(m.group(0) for m in rx.finditer(M))
    add(63, len(ph), [short(x) for x in ph])

    # 64, 65
    cm = []
    for rx in CHAT_MARK:
        cm.extend(m.group(0) for m in rx.finditer(M))
    add(64, len(cm), [short(x) for x in cm])
    tp = []
    for m in UTM.finditer(M):
        host = m.group(1).rstrip('.').lower()
        if host in TRACK_HOSTS:
            tp.append(m.group(0))
    add(65, len(tp), tp)

    # 70 horizontal rules
    if len(lines) >= 24:
        hr = 0
        for i, l in enumerate(lines):
            if FAMILY_RX[70][0].match(l.rstrip()):
                if l.strip().startswith('-') and i > 0 and lines[i - 1].strip() and not HEADING_RE.match(lines[i - 1]) and re.fullmatch(r'-{2,}\s*', l.strip()):
                    continue
                hr += 1
        if hr >= 3:
            add(70, hr, ['%d horizontal rules' % hr])

    # 71 degenerate repetition
    if not light and nwords >= 12:
        lw = [w.lower() for w in words_all]
        if len(lw) >= 6:
            grams = {}
            order = []
            for i in range(len(lw) - 5):
                g = tuple(lw[i:i + 6])
                grams[g] = grams.get(g, 0) + 1
                order.append(g)
            rep = sum(1 for g in order if grams[g] > 1)
            if order and rep / len(order) >= 0.2:
                add(71, rep, [' '.join(g) for g in list(dict.fromkeys(g for g in order if grams[g] > 1))[:3]])

    return F, nwords, sents


def weight_of(key):
    return CAT[key][2]


def num_of(key):
    return 17 if key in ('17p', '17t') else key


def score_from(F, nwords):
    moving = {}
    for key, (count, _) in F.items():
        w = weight_of(key)
        if w > 0:
            moving[key] = w * (1 + min(count - 1, 4) * 0.25)
    nums = {num_of(k) for k in moving}
    families = set(moving)
    raw = int(round(min(100.0, sum(moving.values()))))
    nonrhythm = {k for k in families if k not in (40, 44)}
    score = raw
    if len(families) == 1:
        score = min(score, 40)
    if families and not nonrhythm:
        score = min(score, 40)
    if families == {40}:
        score = min(score, 20)
    # confidence
    if nwords < 40:
        conf, reason = 'none', 'fewer than 40 words'
    elif nwords < 120:
        conf, reason = 'low', 'fewer than 120 words'
    elif nwords < 300:
        if len(families) == 1:
            conf, reason = 'low', 'under 300 words and only one score-moving pattern family fired'
        else:
            conf, reason = 'moderate', 'fewer than 300 words'
    else:
        conf, reason = 'high', ''
    dec = {k for k in families if k in DECISIVE}
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf not in ('none', 'low'):
        score = max(score, 45)
    n = len(families)
    if nwords < 120:
        early = len({k for k in families if k in EARLY})
        if early >= 3:
            score = max(score, 45)
        elif early >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))
    return score, conf, reason


def band_of(s):
    if s <= 20:
        return 'clean'
    if s <= 40:
        return 'light tells'
    if s <= 60:
        return 'mixed'
    if s <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def build_report(text, ci=False):
    truncated = len(text) > WINDOW
    W = text[:WINDOW]
    F, nwords, sents = analyze(W)
    score, conf, reason = score_from(F, nwords)
    report = {}
    for key in sorted(F, key=lambda k: (num_of(k), str(k))):
        count, samples = F[key]
        slug, label, _ = CAT[key]
        n = num_of(key)
        if key == '17p':
            rk = '17_negative_parallelism'
        elif key == '17t':
            rk = '17_tailing_negation'
        else:
            rk = '%d_%s' % (n, slug)
        report[rk] = {'label': label, 'count': count, 'samples': samples}
    inv = F.get(62, (0,))[0]
    sp = F.get(67, (0,))[0]
    hg = F.get(66, (0,))[0]
    met = {
        'scanned_chars': len(W),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason if conf != 'high' else '',
        'patterns_flagged': len(report),
        'invisible_chars': inv,
        'nonstandard_spaces': sp,
        'homoglyphs': hg,
        'words': nwords,
        'sentences': len(sents),
    }
    if ci:
        if len(sents) >= 4:
            met['score_ci'] = interval(sents, score)
            met['score_ci_note'] = 'resampled over sentences (seeded, 5th-95th percentile)'
        else:
            met['score_ci'] = None
            met['score_ci_note'] = 'too few sentences for an interval (need at least 4)'
    report['_metrics'] = met
    return report


def interval(sents, point):
    rnd = random.Random(20240601)
    n = len(sents)
    total = sum(len(s) for s in sents)
    iters = 40 if total < 20000 else (12 if total < 100000 else 5)
    t0 = time.time()
    scores = []
    for _ in range(iters):
        if time.time() - t0 > 2.5:
            break
        pick = [sents[rnd.randrange(n)] for _ in range(n)]
        F, nw, _s = analyze(' '.join(pick), light=True)
        # structure-free resampling: rhythm and repetition kinds are artifacts of resampling
        for k in (40, 44, 41, 42, 71, 37):
            F.pop(k, None)
        sc, _c, _r = score_from(F, nw)
        scores.append(sc)
    if not scores:
        return [point, point]
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
    return [min(lo, point), max(hi, point)]


# --------------------------------------------------------------------- main

def emit_error(msg):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')
    sys.stderr.flush()


def out_bytes(s):
    sys.stdout.flush()
    sys.stdout.buffer.write(s.encode('utf-8', 'replace'))
    sys.stdout.buffer.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    opts_done = False
    for a in argv:
        if opts_done:
            operands.append(a)
        elif a == '--':
            opts_done = True
        elif a in ('-h', '--help'):
            out_bytes(USAGE)
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            emit_error('unknown option: %s (see --help)' % a)
            return 2
        else:
            operands.append(a)
    try:
        if operands:
            if len(operands) > 1:
                sys.stderr.write('note: only the first file was scanned: %s\n' % operands[0])
            text = extract_file(operands[0])
        else:
            data = sys.stdin.buffer.read()
            text = decode_bytes(data)
        if not text or not text.strip():
            raise Fail('empty input')
        if clean:
            out_bytes(clean_text(text))
            return 0
        rep = build_report(text, ci)
        out_bytes(json.dumps(rep, ensure_ascii=False, indent=2) + '\n')
        return 0
    except Fail as e:
        emit_error(e.msg)
        return e.code
    except RecursionError:
        emit_error('cannot read input: nesting too deep')
        return 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
