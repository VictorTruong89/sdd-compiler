#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const c = require('./lib/common');

const MAX_PATHS = 16;
const PATCH_LINE = /^\*\*\* (Add File|Update File|Move to):(.*)$/;

// Paths named by an apply_patch body: "*** Add File: x", "*** Update File: x", "*** Move to: x".
function patchPaths(body) {
  const out = [];
  for (const raw of String(body || '').split('\n')) {
    const m = PATCH_LINE.exec(raw.replace(/\r$/, ''));
    if (!m) continue;
    const p = m[2].trim();
    if (p && !out.includes(p)) out.push(p);
  }
  return out;
}

function pathsFromPayload(input) {
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  if (typeof ti.command === 'string' && /^\*\*\* (Add File|Update File|Move to):/m.test(ti.command)) {
    return patchPaths(ti.command).slice(0, MAX_PATHS);
  }
  const single = typeof ti.file_path === 'string' ? ti.file_path
    : (typeof ti.notebook_path === 'string' ? ti.notebook_path : '');
  return single.trim() ? [single.trim()] : [];
}

function skipForPath(abs) {
  const sep = path.sep;
  const segs = abs.split(/[\\/]/);
  if (segs.includes('node_modules') || segs.includes('.git')) return true;
  const root = c.pluginRoot();
  if (abs === root || abs.startsWith(root + sep)) return true;
  const base = path.basename(abs).toLowerCase();
  if (c.INSTRUCTION_NAMES.includes(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (c.INSTRUCTION_STEMS.includes(stem) && !c.PLAIN_EXTS.includes(ext) && !c.ZIP_EXTS.includes(ext) && ext !== c.NOTEBOOK_EXT) {
    return true;
  }
  return false;
}

function phraseFor(band) {
  return c.PHRASES[band] || band;
}

function main() {
  const input = c.readJsonStdin();
  const level = c.resolveLevel();
  if (level === 'off' || level === 'lite') return '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const threshold = c.threshold(level);

  const seen = new Set();
  const lines = [];
  for (const p of pathsFromPayload(input)) {
    const abs = path.resolve(cwd, p);
    if (seen.has(abs)) continue;
    seen.add(abs);
    if (seen.size > MAX_PATHS) break;
    if (skipForPath(abs)) continue;
    const base = path.basename(abs);
    const ext = path.extname(abs).toLowerCase();
    const isProse = c.PLAIN_EXTS.includes(ext) || c.ZIP_EXTS.includes(ext) || ext === c.NOTEBOOK_EXT;
    if (c.NO_TEXT_EXTS.includes(ext)) {
      c.appendLedger(sid, { kind: 'binary', base: base });
      continue;
    }
    if (!isProse) continue;
    let st;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      c.appendLedger(sid, { kind: 'failed', base: base, reason: 'cannot read: the file is not on disk' });
      continue;
    }
    if (!st.isFile()) continue;
    const archive = c.ZIP_EXTS.includes(ext) || ext === c.NOTEBOOK_EXT;
    const cap = archive ? c.ARCHIVE_CAP : c.PLAIN_CAP;
    if (st.size > cap) {
      c.appendLedger(sid, { kind: 'skipped', base: base, cap_kb: cap / 1024 });
      continue;
    }
    const r = c.runDetector(abs, archive ? c.ARCHIVE_TIMEOUT_MS : c.PLAIN_TIMEOUT_MS, undefined);
    let reason = null;
    switch (r.status) {
      case 'unavailable': reason = 'Python was not found'; break;
      case 'timeout': reason = 'the detector timed out'; break;
      case 'failed': reason = (r.message || 'exited without a usable result').split(abs).join(base); break;
      case 'no-output': reason = 'the detector exited without a usable result'; break;
      case 'not-report': reason = 'the detector printed text that is not a report'; break;
      case 'no-score': reason = 'the report has no numeric score'; break;
      default: break;
    }
    if (reason !== null) {
      c.appendLedger(sid, { kind: 'failed', base: base, reason: reason });
      continue;
    }
    const m = r.report._metrics;
    const labels = c.labelsOf(r.report).map(l => l.label).slice(0, 5);
    const flagged = m.ai_tell_score > threshold;
    c.appendLedger(sid, {
      kind: 'scored', base: base, score: m.ai_tell_score, band: m.ai_tell_band,
      phrase: phraseFor(m.ai_tell_band), labels: labels, flagged: flagged, truncated: !!m.truncated,
    });
    if (flagged) {
      const cov = m.truncated ? ', first ' + c.WINDOW_TXT + ' characters only' : '';
      lines.push('prosecheck: ' + base + ' ' + phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
        ', band ' + m.ai_tell_band + cov + '). Flagged: ' + labels.join('; ') +
        '. Please fix the flagged spans: rewrite those sentences with varied rhythm, then check again.');
    }
  }
  if (!lines.length) return '';
  return c.contextEnvelope('PostToolUse', lines.join('\n')) + '\n';
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  /* never fail the host */
}
process.exitCode = 0;
