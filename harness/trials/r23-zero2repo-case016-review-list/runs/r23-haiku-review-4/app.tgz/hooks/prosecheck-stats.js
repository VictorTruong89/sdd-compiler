#!/usr/bin/env node
'use strict';
// Stats hook: session token figures and the score of the session's own prose.
const c = require('./lib/common');
const cmd = require('./lib/commands');

try {
  const input = c.readJsonStdin();
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  process.stdout.write(c.blockReply(cmd.statsReply(input.transcript_path, cwd)) + '\n');
} catch (e) {
  /* never fail the host */
}
process.exitCode = 0;
