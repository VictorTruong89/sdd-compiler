#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the subagent envelope.
const c = require('./lib/common');

try {
  c.readJsonStdin();
  const level = c.resolveLevel();
  if (level !== 'off') {
    process.stdout.write(c.contextEnvelope('SubagentStart', c.contractText(level, 'live')) + '\n');
  }
} catch (e) {
  /* never fail the host */
}
process.exitCode = 0;
