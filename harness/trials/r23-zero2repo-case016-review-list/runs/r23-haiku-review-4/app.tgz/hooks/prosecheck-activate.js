#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and, once, the welcome) in context.
const fs = require('fs');
const c = require('./lib/common');

function main() {
  c.readJsonStdin();
  const flagExisted = fs.existsSync(c.flagPath());
  const stored = c.readStoredLevel();
  const level = c.resolveLevel();
  if (!stored) {
    try { c.writeStoredLevel(level); } catch (e) { /* unreadable flag: keep going */ }
  }
  c.pruneLedgers();
  if (level === 'off') return '';
  const parts = [];
  if (!flagExisted) parts.push(c.welcomeText(level));
  parts.push(c.contractText(level, 'live'));
  return parts.join('\n\n') + '\n';
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  /* a hook never fails the host session */
}
process.exitCode = 0;
