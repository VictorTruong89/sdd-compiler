#!/usr/bin/env node
'use strict';
// Prompt-submit hook: /prosecheck command router, stop phrases, and the per-prompt reminder.
const c = require('./lib/common');
const cmd = require('./lib/commands');

const VALID = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function route(input) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();

  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    c.writeStoredLevel('off');
    return c.blockReply('prosecheck is off. Nothing is placed in context or scored until you run /prosecheck on.');
  }

  const m = /^\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/i.exec(trimmed);
  if (!m) {
    const level = c.resolveLevel();
    if (level === 'off') return null;
    return c.contextEnvelope('UserPromptSubmit',
      'prosecheck is on (level: ' + level + '). Prose deliverables follow the writing contract; code, config, and commit messages are untouched.');
  }

  const form = /^\/prosecheck:prosecheck/i.test(trimmed) ? cmd.NAMESPACED : '/prosecheck';
  const rest = m[1].trim();
  const first = rest.split(/\s+/)[0] || '';
  const sub = first.toLowerCase();
  const arg = rest.slice(first.length).trim();

  if (sub === '' || sub === 'help') {
    return c.blockReply(cmd.helpReply(c.resolveLevel()));
  }
  if (sub === 'lite' || sub === 'full' || sub === 'strict') {
    c.writeStoredLevel(sub);
    if (sub === 'lite') return c.blockReply('prosecheck set to lite: writing contract on, saved files are not scored.');
    if (sub === 'full') return c.blockReply('prosecheck set to full: writing contract on, saved-file guard on with threshold 40.');
    return c.blockReply('prosecheck set to strict: writing contract on, guard threshold 20, cleanup scrub on.');
  }
  if (sub === 'off') {
    c.writeStoredLevel('off');
    return c.blockReply('prosecheck is off. Nothing is placed in context or scored until you run ' + form + ' on.');
  }
  if (sub === 'on') {
    c.writeStoredLevel('full');
    return c.blockReply('prosecheck is on at full (the default level). Saved prose is guarded with threshold 40.');
  }
  if (sub === 'status') {
    return c.blockReply('prosecheck status: level is ' + c.resolveLevel() + '.');
  }
  if (sub === 'show') return c.blockReply(cmd.showReply(sid));
  if (sub === 'check') return c.blockReply(cmd.checkReply(arg, cwd));
  if (sub === 'doctor') return c.blockReply(cmd.doctorReply(form));
  if (sub === 'stats') return c.blockReply(cmd.statsReply(input.transcript_path, cwd));
  if (sub === 'init') return c.blockReply(cmd.initReply(form, cwd));

  return c.blockReply('unknown subcommand "' + first + '". Valid subcommands: ' + VALID.join(', ') + '.');
}

try {
  const input = c.readJsonStdin();
  const out = route(input);
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  /* never fail the host */
}
process.exitCode = 0;
