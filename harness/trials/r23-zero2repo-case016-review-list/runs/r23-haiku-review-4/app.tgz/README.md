# prosecheck 0.9.3

A local detector for AI-writing patterns, with a Claude Code plugin around it.

- `scripts/detect.py`: Python 3.9+ standard-library detector. Scores a file or standard input against 71 catalogue patterns and prints a JSON report. `--clean` prints scrubbed text instead.
- `hooks/`: Node.js plugin hooks (session start, prompt router, subagent contract, saved-file guard).
- `commands/prosecheck.md`: the `/prosecheck` menu entry.
- `.cursor/rules/prosecheck.mdc`: the prose-only Cursor rule that `/prosecheck init` copies.

No network, no account, no upload. See `NOTES.md` for how specification conflicts and gaps were resolved.

```
python3 scripts/detect.py docs/essay.md
python3 scripts/detect.py --clean notes.txt
python3 scripts/detect.py --ci draft.md
```
