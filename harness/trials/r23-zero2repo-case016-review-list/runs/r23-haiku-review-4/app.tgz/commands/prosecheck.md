---
description: prosecheck: writing contract, saved-file guard, and checks for prose
argument-hint: [lite|full|strict|off|on|status|show|check <file>|doctor|stats|init|help]
---

/prosecheck $ARGUMENTS
