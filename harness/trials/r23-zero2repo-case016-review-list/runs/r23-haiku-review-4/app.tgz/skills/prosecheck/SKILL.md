---
name: prosecheck
description: Rewrite flagged prose after the prosecheck saved-file guard or /prosecheck check reports AI-writing patterns. Use only when the user asks for a deep rewrite ("prosecheck this" or "humanize this").
---

# prosecheck rewrite guidance

This skill is instructions for the host agent. The detector only reports; the rewrite is done by the agent.

1. Re-read the flagged spans named in the report. Do not change text outside them unless asked.
2. Keep every number, unit, date, proper noun, citation, quotation, and technical term exactly as written.
3. Replace stock vocabulary and stock moves with plain statements. Vary sentence length; do not alternate short and long on a fixed rhythm.
4. Do not add facts, and do not change the meaning.
5. Do not touch code, configuration, commit messages, or chat replies.
6. Do not mention prosecheck, scores, or pattern names in the rewritten document.
