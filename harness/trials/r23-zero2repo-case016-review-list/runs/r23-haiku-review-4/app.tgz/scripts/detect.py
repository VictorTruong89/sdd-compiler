#!/usr/bin/env python3
"""prosecheck detector.

Local, deterministic, standard-library-only scanner for AI-writing patterns.

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input (UTF-8). Readable prose prints
one JSON report on standard output (exit 0). With --clean, the scrubbed text is
printed instead. Failures print one JSON object {"error": ...} as the last
non-empty line of standard error and exit 1 (empty input, unreadable path) or
2 (unknown option).
"""
import sys
import os
import re
import io
import json
import posixpath
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144                      # scan window, in characters
PLAIN_CAP = 512 * 1024               # plain-text cap on disk (plugin enforces)
ARCHIVE_CAP = 4 * 1024 * 1024        # archive / notebook cap on disk (plugin enforces)
MEMBER_MAX = 64 * 1024 * 1024        # largest archive member read (implementer's choice)

ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm',
                      '.odt', '.odp', '.ods', '.epub'])
PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst',
                        '.tex', '.org', '.adoc'])
NOTEBOOK_EXT = '.ipynb'
NO_TEXT_EXTS = frozenset(['.pdf', '.rtf'])

# Decisive families (FP-01).
DECISIVE = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
# Rhythm kinds that can move the score.
RHYTHM = frozenset([40, 44])
# Families counted for the small-document floor: 1-39, 47-51, 69.
SMALL_SET = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score FILE (or standard input) for AI-writing patterns. Prose only.
  --clean      print the scrubbed text instead of the JSON report
  --ci         add a low/high interval on the score (needs at least four sentences)
  --           end option parsing; the next argument is a file name even if it begins with a dash
  FILE         one prose file (.md .txt .docx .epub .ipynb ...); omit to read standard input
  -h, --help   print this message and exit 0
"""


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# ---------------------------------------------------------------- extraction

def decode_bytes(data):
    """UTF-8 (optional BOM) or UTF-16 with BOM. The leading mark is not prose."""
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        text = data.decode('utf-16', errors='replace')
    else:
        if data[:3] == b'\xef\xbb\xbf':
            data = data[3:]
        text = data.decode('utf-8', errors='replace')
    if text[:1] == '\ufeff':
        text = text[1:]
    return text


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _parse_xml(data):
    if not data:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _zip_read(zf, name):
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MEMBER_MAX:
        return None
    try:
        return zf.read(name)
    except Exception:
        return None


def _xml_paras(root, para_tag='p', text_tags=('t',)):
    res = []
    for el in root.iter():
        if _local(el.tag) != para_tag:
            continue
        parts = []
        for d in el.iter():
            tg = _local(d.tag)
            if tg in text_tags and d.text:
                parts.append(d.text)
            elif tg == 'tab':
                parts.append('\t')
            elif tg == 'br':
                parts.append('\n')
        s = ''.join(parts)
        if s.strip():
            res.append(s)
    return res


def _sheet_paths(zf):
    names = zf.namelist()
    wb = _parse_xml(_zip_read(zf, 'xl/workbook.xml'))
    rels = _parse_xml(_zip_read(zf, 'xl/_rels/workbook.xml.rels'))
    if wb is not None and rels is not None:
        rmap = {}
        for r in rels.iter():
            if _local(r.tag) == 'Relationship':
                rmap[r.get('Id')] = r.get('Target') or ''
        out = []
        for s in wb.iter():
            if _local(s.tag) != 'sheet':
                continue
            rid = None
            for k, v in s.attrib.items():
                if k.endswith('}id') or k == 'id':
                    rid = v
            tgt = rmap.get(rid)
            if not tgt:
                continue
            if tgt.startswith('/'):
                path = tgt.lstrip('/')
            else:
                path = posixpath.normpath(posixpath.join('xl', tgt))
            if path in names:
                out.append(path)
        if out:
            return out
    sheets = [n for n in names if re.match(r'^xl/worksheets/sheet\d+\.xml$', n)]
    return sorted(sheets, key=lambda n: int(re.search(r'(\d+)', n.rsplit('/', 1)[-1]).group(1)))


def _xlsx_text(zf):
    sst = []
    root = _parse_xml(_zip_read(zf, 'xl/sharedStrings.xml'))
    if root is not None:
        for si in root.iter():
            if _local(si.tag) == 'si':
                sst.append(''.join(d.text or '' for d in si.iter() if _local(d.tag) == 't'))
    out = []
    for name in _sheet_paths(zf):
        root = _parse_xml(_zip_read(zf, name))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            v = None
            for ch in c:
                if _local(ch.tag) == 'v':
                    v = ch.text
            if t == 's':
                if v is not None and v.strip().isdigit():
                    i = int(v.strip())
                    if i < len(sst) and sst[i].strip():
                        out.append(sst[i])
            elif t == 'inlineStr':
                s = ''.join(d.text or '' for d in c.iter() if _local(d.tag) == 't')
                if s.strip():
                    out.append(s)
            elif t == 'str':
                if v and v.strip():
                    out.append(v)
    return '\n'.join(out)


def _collapse(s):
    return re.sub(r'\s+', ' ', s)


def _odf_blocks(root):
    blocks = []
    skips = ('annotation', 'annotation-end')

    def walk(e, buf):
        tg = _local(e.tag)
        if tg in skips:
            return
        if tg in ('p', 'h'):
            sub = []
            children(e, sub)
            blocks.append(''.join(sub))
            return
        if tg == 's':
            n = 1
            for k, v in e.attrib.items():
                if k.endswith('}c'):
                    try:
                        n = max(1, int(v))
                    except ValueError:
                        n = 1
            buf.append(' ' * n)
        elif tg == 'tab':
            buf.append('\t')
        elif tg == 'line-break':
            buf.append('\n')
        else:
            children(e, buf)

    def children(e, buf):
        if e.text:
            buf.append(_collapse(e.text))
        for ch in e:
            walk(ch, buf)
            if ch.tail:
                buf.append(_collapse(ch.tail))

    children(root, [])
    return [b.strip() for b in blocks if b.strip()]


_BLOCK_TAGS = frozenset(['p', 'div', 'section', 'article', 'header', 'footer', 'aside',
                         'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'ul', 'ol', 'dl', 'dt', 'dd',
                         'blockquote', 'pre', 'tr', 'table', 'figure', 'figcaption', 'hr',
                         'br', 'body', 'main'])
_SKIP_TAGS = frozenset(['script', 'style', 'nav', 'head', 'title', 'template'])


class _XhtmlText(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in _SKIP_TAGS:
            self.skip += 1
        elif tag in _BLOCK_TAGS:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in _SKIP_TAGS:
            self.skip = max(0, self.skip - 1)
        elif tag in _BLOCK_TAGS:
            self.parts.append('\n')

    def handle_data(self, data):
        if self.skip == 0:
            self.parts.append(_collapse(data))

    def text(self):
        raw = ''.join(self.parts)
        lines = [re.sub(r' +', ' ', ln).strip() for ln in raw.split('\n')]
        return '\n'.join(ln for ln in lines if ln)


def _epub_text(zf):
    names = zf.namelist()
    order = []
    container = _parse_xml(_zip_read(zf, 'META-INF/container.xml'))
    opf_path = None
    if container is not None:
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
    if opf_path and opf_path in names:
        opf = _parse_xml(_zip_read(zf, opf_path))
        base = posixpath.dirname(opf_path)
        manifest = {}
        spine = []
        if opf is not None:
            for el in opf.iter():
                t = _local(el.tag)
                if t == 'item':
                    manifest[el.get('id')] = (el.get('href') or '', el.get('properties') or '')
                elif t == 'itemref':
                    spine.append(el.get('idref'))
        for idref in spine:
            if idref not in manifest:
                continue
            href, props = manifest[idref]
            if 'nav' in props.split():
                continue
            path = posixpath.normpath(posixpath.join(base, href)) if base else posixpath.normpath(href)
            if path in names:
                order.append(path)
    if not order:
        order = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')))
    parts = []
    for name in order:
        data = _zip_read(zf, name)
        if data is None:
            continue
        p = _XhtmlText()
        try:
            p.feed(decode_bytes(data))
            p.close()
        except Exception:
            pass
        t = p.text()
        if t:
            parts.append(t)
    return '\n'.join(parts)


def _extract_zip(data, ext, path):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError, EOFError):
        raise Fail("cannot read input: %s: not a readable zip archive" % path)
    try:
        if ext in ('.docx', '.docm'):
            root = _parse_xml(_zip_read(zf, 'word/document.xml'))
            return '\n'.join(_xml_paras(root)) if root is not None else ''
        if ext in ('.pptx', '.pptm'):
            slides = [n for n in zf.namelist() if re.match(r'^ppt/slides/slide\d+\.xml$', n)]
            slides.sort(key=lambda n: int(re.search(r'(\d+)', n.rsplit('/', 1)[-1]).group(1)))
            out = []
            for n in slides:
                root = _parse_xml(_zip_read(zf, n))
                if root is not None:
                    out.extend(_xml_paras(root))
            return '\n'.join(out)
        if ext in ('.xlsx', '.xlsm'):
            return _xlsx_text(zf)
        if ext in ('.odt', '.odp', '.ods'):
            root = _parse_xml(_zip_read(zf, 'content.xml'))
            if root is None:
                return ''
            return '\n'.join(_odf_blocks(root))
        if ext == '.epub':
            return _epub_text(zf)
        return ''
    finally:
        zf.close()


def _extract_notebook(data):
    try:
        nb = json.loads(decode_bytes(data))
    except (ValueError, TypeError):
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for c in cells:
        if not isinstance(c, dict):
            return ''
        if c.get('cell_type') != 'markdown':
            continue
        src = c.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        if not isinstance(src, str):
            return ''
        if src.strip():
            parts.append(src.strip())
    return '\n'.join(parts)


def load_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as e:
        raise Fail("cannot read input: %s: %s" % (path, e.strerror or str(e)))
    if ext in ZIP_EXTS:
        return _extract_zip(data, ext, path)
    if ext == NOTEBOOK_EXT:
        return _extract_notebook(data)
    if ext in NO_TEXT_EXTS:
        return ''
    return decode_bytes(data)


# ------------------------------------------------------------- character layer

_INVIS_EXTRA = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C,
                          0x180D, 0x180E, 0x180F, 0x3164, 0xFFA0])
_RTL_RE = re.compile('[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')
_LETTER_RUN_RE = re.compile(r'[^\W\d_]+')

# Mixed-script lookalikes of the Latin letters the homoglyph rule covers.
_CONF = {}
for _cp, _ch in [
    (0x0430, 'a'), (0x0441, 'c'), (0x0501, 'd'), (0x0435, 'e'), (0x04BB, 'h'),
    (0x0456, 'i'), (0x0458, 'j'), (0x043F, 'n'), (0x043E, 'o'), (0x0440, 'p'),
    (0x0455, 's'), (0x0443, 'y'), (0x0445, 'x'), (0x0475, 'v'), (0x051D, 'w'),
    (0x04AF, 'y'), (0x0410, 'A'), (0x0412, 'B'), (0x0421, 'C'), (0x0415, 'E'),
    (0x041D, 'H'), (0x0406, 'I'), (0x0408, 'J'), (0x041A, 'K'), (0x041C, 'M'),
    (0x041E, 'O'), (0x0420, 'P'), (0x0405, 'S'), (0x0422, 'T'), (0x0425, 'X'),
    (0x0423, 'Y'), (0x04AE, 'Y'), (0x0500, 'D'), (0x0474, 'V'),
    (0x03B1, 'a'), (0x03BF, 'o'), (0x03B5, 'e'), (0x03B9, 'i'), (0x03BA, 'k'),
    (0x03BD, 'v'), (0x03C5, 'u'), (0x03C1, 'p'), (0x03C7, 'x'),
    (0x0391, 'A'), (0x0392, 'B'), (0x0395, 'E'), (0x0396, 'Z'), (0x0397, 'H'),
    (0x0399, 'I'), (0x039A, 'K'), (0x039C, 'M'), (0x039D, 'N'), (0x039F, 'O'),
    (0x03A1, 'P'), (0x03A4, 'T'), (0x03A5, 'Y'), (0x03A7, 'X'),
    (0x0555, 'O'), (0x057D, 'u')]:
    _CONF[_cp] = _ch
_CONF = {chr(k): v for k, v in _CONF.items()}
del _cp, _ch


def _is_invisible_cp(cp):
    if cp in _INVIS_EXTRA:
        return True
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return True
    if 0xE0000 <= cp <= 0xE0FFF:
        return True
    if cp < 0x20 or 0x7F <= cp <= 0x9F:
        return cp not in (9, 10, 13)
    return unicodedata.category(chr(cp)) == 'Cf'


def _in(ch, lo, hi):
    return bool(ch) and lo <= ord(ch) <= hi


def _joining(ch):
    return any(_in(ch, a, b) for a, b in [
        (0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
        (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF),
        (0xFB50, 0xFDFF), (0xFE70, 0xFEFF)])


def _symbolish(ch):
    if not ch:
        return False
    if any(_in(ch, a, b) for a, b in [(0x2600, 0x27BF), (0x1F000, 0x1FAFF), (0x2B50, 0x2B55)]):
        return True
    return unicodedata.category(ch) in ('So', 'Sk')


def _cjk(ch):
    return any(_in(ch, a, b) for a, b in [
        (0x4E00, 0x9FFF), (0x3400, 0x4DBF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F)])


def _no_space_script(ch):
    return _cjk(ch) or any(_in(ch, a, b) for a, b in [
        (0x3040, 0x30FF), (0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF)])


def _is_letter(ch):
    return bool(ch) and unicodedata.category(ch)[0] == 'L'


def _keep_invisible(cp, prv, nxt, has_rtl, prev_tag):
    """True where the character does a job in its position (FP-03)."""
    if cp == 0xAD:
        return _is_letter(prv) and _is_letter(nxt)
    if cp in (0x200C, 0x200D):
        return _joining(prv) or _joining(nxt) or _symbolish(prv) or _symbolish(nxt)
    if cp == 0x200B:
        return _no_space_script(prv) or _no_space_script(nxt)
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return has_rtl
    if cp in (0x180B, 0x180C, 0x180D, 0x180F):
        return _in(prv, 0x1800, 0x18AF)
    if cp in (0x17B4, 0x17B5):
        return _in(prv, 0x1780, 0x17FF) or _in(nxt, 0x1780, 0x17FF)
    if 0xFE00 <= cp <= 0xFE0F:
        return _symbolish(prv) or _cjk(prv) or nxt == '\u20e3'
    if 0xE0100 <= cp <= 0xE01EF:
        return _cjk(prv)
    if 0xE0000 <= cp <= 0xE007F:
        return prv == '\U0001F3F4' or prev_tag
    return False


def _keep_nbsp(prv, nxt):
    if prv and unicodedata.category(prv) == 'Nd' or nxt and unicodedata.category(nxt) == 'Nd':
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prv and prv in '«‹':
        return True
    return False


def special_chars(text):
    """List of (index, kind, keep) for invisible, non-standard-space and
    line-separator characters. kind is 'inv', 'ns' or 'sep'."""
    has_rtl = _RTL_RE.search(text) is not None
    res = []
    prev_tag = False
    n = len(text)
    for i, ch in enumerate(text):
        cp = ord(ch)
        if (0x20 <= cp < 0x7F) or cp in (9, 10, 13):
            prev_tag = False
            continue
        if cp in (0x2028, 0x2029):
            res.append((i, 'sep', False))
            prev_tag = False
            continue
        if _is_invisible_cp(cp):
            prv = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            keep = _keep_invisible(cp, prv, nxt, has_rtl, prev_tag)
            prev_tag = keep and 0xE0000 <= cp <= 0xE007F
            res.append((i, 'inv', keep))
            continue
        prev_tag = False
        if cp != 0x20 and unicodedata.category(ch) == 'Zs':
            prv = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            keep = cp in (0xA0, 0x202F) and _keep_nbsp(prv, nxt)
            res.append((i, 'ns', keep))
    return res


def _mixed_confusable_run(run):
    has_ascii_letter = False
    has_conf = False
    for c in run:
        if ord(c) < 128:
            if c.isalpha():
                has_ascii_letter = True
        elif c in _CONF:
            has_conf = True
        else:
            return False
    return has_ascii_letter and has_conf


def homoglyph_runs(text):
    count = 0
    samples = []
    for m in _LETTER_RUN_RE.finditer(text):
        if _mixed_confusable_run(m.group(0)):
            count += 1
            if len(samples) < 3:
                samples.append(m.group(0))
    return count, samples


def fold_homoglyphs(text):
    def rep(m):
        run = m.group(0)
        if _mixed_confusable_run(run):
            return ''.join(_CONF.get(c, c) for c in run)
        return run
    return _LETTER_RUN_RE.sub(rep, text)


def clean_text(text):
    """Scrubbed text (FP-03): invisible characters removed, odd spaces normalised,
    homoglyphs folded, trailing whitespace trimmed."""
    had_nl = text.endswith('\n')
    crlf_end = text.endswith('\r\n')
    actions = {}
    for i, kind, keep in special_chars(text):
        actions[i] = (kind, keep)
    out = []
    for i, ch in enumerate(text):
        a = actions.get(i)
        if a is None:
            out.append(ch)
            continue
        kind, keep = a
        if kind == 'sep':
            out.append('\n')
        elif kind == 'inv':
            if keep:
                out.append(ch)
        else:
            out.append(ch if keep else ' ')
    body = fold_homoglyphs(''.join(out))
    lines = []
    for ln in body.split('\n'):
        cr = ln.endswith('\r')
        core = (ln[:-1] if cr else ln).rstrip(' \t')
        lines.append(core + ('\r' if cr else ''))
    while lines and lines[0].strip() == '':
        lines.pop(0)
    body = '\n'.join(lines).rstrip()
    if not body:
        return ''
    if had_nl:
        body += '\r\n' if crlf_end else '\n'
    return body


def trailing_ws_count(window):
    cnt = 0
    lines = window.split('\n')
    for ln in lines:
        core = ln[:-1] if ln.endswith('\r') else ln
        if core.endswith(' ') or core.endswith('\t'):
            cnt += 1
    if window.endswith('\n\n'):
        cnt += 1
    if window[:1].isspace():
        cnt += 1
    return cnt


# ------------------------------------------------------------------ masking

_FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
_BQ = re.compile(r'^ {0,3}>')
_BADGE = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
_TABLE_DELIM = re.compile(r'^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-+:?\s*)*\|?\s*$')
_INLINE_CODE = re.compile(r'(`+)[^`\n]*?\1')


def mask_nonprose(text):
    """Blank out front matter, fenced code, inline code, blockquote runs,
    table rows and badge lines. Line structure is kept."""
    lines = text.split('\n')
    n = len(lines)
    mask = [False] * n
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() in ('---', '...'):
                for k in range(j + 1):
                    mask[k] = True
                break
    j = 0
    while j < n:
        if mask[j]:
            j += 1
            continue
        m = _FENCE_OPEN.match(lines[j])
        if m:
            fence = m.group(1)
            close = re.compile(r'^ {0,3}' + re.escape(fence[0]) + '{%d,}\\s*$' % len(fence))
            k = j + 1
            while k < n and not close.match(lines[k]):
                k += 1
            end = min(k, n - 1)
            for t in range(j, end + 1):
                mask[t] = True
            j = end + 1
            continue
        j += 1
    j = 0
    while j < n:
        if not mask[j] and _BQ.match(lines[j]):
            k = j
            while k < n and not mask[k] and _BQ.match(lines[k]):
                k += 1
            if k - j >= 2:
                for t in range(j, k):
                    mask[t] = True
            j = k
        else:
            j += 1
    for j in range(n):
        if mask[j]:
            continue
        s = lines[j].strip()
        if s.startswith('|') and s.count('|') >= 2:
            mask[j] = True
        elif '|' in s and _TABLE_DELIM.match(lines[j]):
            mask[j] = True
        elif _BADGE.match(lines[j]):
            mask[j] = True
    out = []
    for j, ln in enumerate(lines):
        if mask[j]:
            out.append('')
        else:
            out.append(_INLINE_CODE.sub(lambda mm: ' ' * len(mm.group(0)), ln))
    return '\n'.join(out)


# ------------------------------------------------------------------- helpers

WORD_RE = re.compile(r"[^\W_]+(?:['’\-]+[^\W_]+)*")


def words_list(s):
    return WORD_RE.findall(s)


def word_count(s):
    return len(WORD_RE.findall(s))


def _snip(text, s, e):
    a = max(0, s - 30)
    b = min(len(text), e + 30)
    body = re.sub(r'\s+', ' ', text[a:b]).strip()
    return ('…' if a > 0 else '') + body + ('…' if b < len(text) else '')


def _infl(word):
    if word.endswith('e'):
        stem, sufs = word[:-1], ('e', 'es', 'ed', 'ing')
    else:
        stem, sufs = word, ('', 's', 'es', 'ed', 'ing')
    return '(?:' + '|'.join(re.escape(stem + s) for s in sufs) + ')'


def _words(words):
    """Single lexical words, inflected, as a whole-word alternation."""
    return r'\b(?:' + '|'.join(_infl(w) for w in words) + r')\b'


def _ph(phrase):
    parts = []
    for w in phrase.split():
        parts.append(re.escape(w).replace("'", "['’]"))
    return r'\b' + r'\s+'.join(parts) + r'\b'


def _rx(patterns, flags=re.I):
    return [re.compile(p, flags) for p in patterns]


class Ctx(object):
    pass


def _scan(ctx, comp, min_hits=1):
    count = 0
    samples = []
    for rx in comp:
        for mt in rx.finditer(ctx.m):
            count += 1
            if len(samples) < 3:
                samples.append(_snip(ctx.m, mt.start(), mt.end()))
    if count < min_hits:
        return 0, []
    return count, samples


def _sentences(masked):
    out = []
    for block in re.split(r'\n\s*\n', masked):
        for line in block.split('\n'):
            s = line.strip()
            if not s or re.match(r'^#{1,6}\s', s):
                continue
            s = re.sub(r'^(?:[-*+]|\d+[.)])\s+', '', s)
            for part in re.split(r'(?<=[.!?])\s+', s):
                if word_count(part) > 0:
                    out.append(part.strip())
    return out


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return (var ** 0.5) / mean


# ------------------------------------------------------------------ families

FAMILIES = []   # (number, slug, label, kind, fn(ctx) -> (count, samples))


def _fam(num, slug, label, kind, fn):
    FAMILIES.append((num, slug, label, kind, fn))


def _simple(num, slug, label, patterns, kind='score', min_hits=1, flags=re.I):
    comp = _rx(patterns, flags)
    _fam(num, slug, label, kind, lambda ctx: _scan(ctx, comp, min_hits))


AI_WORDS = ['additionally', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner',
            'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage',
            'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
            'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
            'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
            'elevate', 'empower', 'unlock', 'crucial']
_simple(1, 'ai_vocabulary', 'AI vocabulary', [
    _words(AI_WORDS),
    r'\balign(?:s|ed|ing)?\s+with\b',
    r'\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b'])

_simple(2, 'model_dialect_vocabulary', 'model-dialect vocabulary', [
    r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b',
    r'\bquietly\s+(?:powerful|profound|radical)\b',
    r'\bdeeply\s+(?:human|personal|felt|unsettling)\b',
    r'\bresonates?\s+deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b',
    r'\bsupercharg(?:e|es|ed|ing)\b',
    r'\bskyrocket(?:s|ed|ing)?\b',
    r'\bturbocharg(?:e|es|ed|ing)\b',
    r'\brevolutioniz(?:e|es|ed|ing)\b',
    r'\bdouble\s+down\s+on\b',
    r'\bdive\s+deep(?:er)?\s+into\b',
    r'\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b',
    r'\btake\s+[^.!?\n]{1,60}?\s+to\s+the\s+next\s+level\b'], min_hits=2)

_simple(3, 'promotional_language', 'promotional language', [
    r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|unparalleled|premier)\b',
    r'\bvibrant\s+community\b', r'\brich\s+cultural\s+heritage\b', r'\bin\s+the\s+heart\s+of\b',
    r'\bworld-class\b', r'\btop-tier\b', r'\besteemed\s+organi[sz]ation\b',
    r'\bvaluable\s+asset\b', r'\bpassion\s+for\s+excellence\b', r'\bproven\s+track\s+record\b',
    r'\bresults-oriented\b', r'\bwealth\s+of\s+experience\b', r'\bdynamic\s+team\b',
    r'\bfast-paced\s+environment\b', r'\bdeeply\s+passionate\b', r'\bperfectly\s+situated\b',
    r'\b(?:close|tight)[- ]knit\s+(?:team|community)\b', r'\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b',
    r'\buniquely\s+positioned\s+to\b',
    r'\bleading\s+(?:provider|company|brand|firm|platform|expert|voice|authority)\b'])


def _f3_imperative(ctx):
    verbs = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
             'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
             'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
             'stop', 'start'}
    count = 0
    for s in ctx.sents:
        w = words_list(s)
        if w and w[0].lower() in verbs:
            count += 1
    if count >= 3:
        return 1, ['%d sentences open with a marketing imperative' % count]
    return 0, []


_fam(3, 'promotional_imperatives', 'promotional language', 'score', _f3_imperative)

_simple(5, 'simple_yet', "'simple yet' cliché", [
    r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'])

_STOCK_ADJ = frozenset(['vibrant', 'robust', 'seamless', 'innovative', 'dynamic', 'powerful',
                        'elegant', 'intuitive', 'comprehensive', 'cutting-edge', 'scalable',
                        'holistic', 'stunning', 'unparalleled', 'transformative', 'meticulous'])
_ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$')
_CHAIN_COMMA = re.compile(r"\b[^\W\d_][\w'\-]*(?:,\s*[^\W\d_][\w'\-]*){3,}\b")
_CHAIN_AND = re.compile(r"\b[^\W\d_][\w'\-]*(?:,\s*[^\W\d_][\w'\-]*){2},?\s+and\s+[^\W\d_][\w'\-]*\b")


def _f6(ctx):
    count = 0
    samples = []
    for rx in (_CHAIN_COMMA, _CHAIN_AND):
        for mt in rx.finditer(ctx.m):
            items = [w for w in re.findall(r"[^\W\d_][\w'\-]*", mt.group(0)) if w.lower() != 'and']
            if len(items) < 4:
                continue
            if any(w.lower() in _STOCK_ADJ or _ADJ_SUFFIX.search(w.lower()) for w in items):
                count += 1
                if len(samples) < 3:
                    samples.append(_snip(ctx.m, mt.start(), mt.end()))
    return count, samples


_fam(6, 'stacked_adjectives', 'stacked adjective chain', 'score', _f6)

_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
_CLUSTER_RX = [[(m, re.compile(r'\b' + re.escape(m).replace(r'\ ', r'\s+') + r'(?:s|es)?\b', re.I))
                for m in cl] for cl in _CLUSTERS]


def _f8(ctx):
    count = 0
    samples = []
    for cl in _CLUSTER_RX:
        found = [m for m, rx in cl if rx.search(ctx.m)]
        if len(found) >= 3:
            count += 1
            if len(samples) < 3:
                samples.append('synonyms used: ' + ', '.join(found))
    return count, samples


_fam(8, 'synonym_cycling', 'synonym cycling', 'score', _f8)

_simple(10, 'significance_inflation', 'significance inflation', [
    r'\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b',
    r'\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
    r'\bsymboli[sz]es\b',
    r'\bsets?\s+the\s+stage\s+for\b',
    r'\bleft\s+an?\s+indelible\s+mark\b',
    r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
    r'\bhas\s+(?:shaped|sparked)\b',
    r'\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b'])

_CRED_RX = re.compile(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\b([^.!?\n]*)', re.I)
_LIST_RX = re.compile(r'[A-Z]\w*[^.!?\n]*?(?:,|\band\b)\s*(?:the\s+)?[A-Z]\w*')


def _f11(ctx):
    count = 0
    samples = []
    for mt in _CRED_RX.finditer(ctx.m):
        if _LIST_RX.search(mt.group(1)):
            count += 1
            if len(samples) < 3:
                samples.append(_snip(ctx.m, mt.start(), mt.end()))
    extra = [
        r'\b\d[\d,.]*\s*[KkMm]?\s+(?:followers|subscribers)\b',
        r'\bstrong\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bactive\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bwidely\s+covered\b',
        r'\bindependent\s+(?:media\s+)?coverage\b',
    ]
    c2, s2 = _scan(ctx, _rx(extra))
    return count + c2, (samples + s2)[:3]


_fam(11, 'notability_name_dropping', 'notability name-dropping', 'score', _f11)

_simple(12, 'vague_attributions', 'vague attribution', [
    r'\bexperts?\s+(?:argue|argues|believe|believes|say|says|claim|claims|note|notes|suggest|suggests)\b',
    r'\bindustry\s+(?:reports|observers|analysts)\b',
    r'\bobservers\s+have\s+(?:cited|noted)\b',
    r'\bsome\s+critics\s+argue\b',
    r'\bresearchers\s+have\s+found\b',
    r'\bstudies\s+suggest\b',
    r'\bit\s+is\s+widely\s+believed\b'])

_fam(13, 'article_title_proper_noun', 'article title used as a proper noun', 'score',
     lambda ctx: _scan(ctx, _rx([r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:\S+ ){1,8}?is (?:a|an|the)\b'], 0)))

_simple(14, 'conservation_padding', 'conservation or ecosystem padding', [
    r'\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
    r'\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b',
    r'\bserves?\s+as\s+an?\s+indicator\s+species\b',
    r'\bcontributes?\s+to\s+biodiversity\b'])

_simple(15, 'false_range', 'false range', [
    r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b'])

_simple(16, 'ing_tail', 'superficial -ing tail clause', [
    r',\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b'])

# Catalogue 17: the parallelism form is writing advice; the tailing-negation form scores.
_simple(17, 'negative_parallelism', 'negative parallelism', [
    r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|a|an)\b",
    r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b',
    r"\bdoesn['’]t\s+just\b[^,.!?\n]{0,40}?\bit\b"], kind='advice')
_simple(17, 'tailing_negation', 'tailing negation', [
    r'\w,\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b'])

_simple(18, 'not_x_just_y', "'Not X, just Y' framing", [
    r'\b(?:no|not)\s+\w+\s*,\s*(?:just|only|simply)\s+\w+',
    r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:a\s+|an\s+|the\s+)?\w+\s*(?:,|—|–|-)\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b"])

_simple(19, 'filler_phrases', 'filler phrase', [
    r'\bin\s+order\s+to\b', r'\bdue\s+to\s+the\s+fact\s+that\b', r'\bat\s+this\s+point\s+in\s+time\b',
    r'\bin\s+the\s+event\s+that\b', r'\bhas\s+the\s+ability\s+to\b',
    r'\bit\s+is\s+important\s+to\s+note\s+that\b', r'\bit\s+should\s+be\s+mentioned\s+that\b',
    r'\bneedless\s+to\s+say\b'], kind='advice')

_simple(20, 'empty_pivot', 'empty pivot phrase', [
    r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b",
    r'\bit\s+bears\s+(?:noting|mentioning)\s+that\b',
    r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b',
    r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
    r'\ba\s+key\s+consideration\s+is\b',
    r'\ba\s+point\s+to\s+highlight\s+is\b'])

_simple(21, 'outcome_speculation', 'outcome-speculation tail', [
    r',\s*(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward)\b'])

_simple(22, 'persuasive_authority', 'persuasive authority trope', [
    r"\bhere['’]s\s+the\s+thing\b", r'\bmake\s+no\s+mistake\b', r'\bthe\s+truth\s+is\b',
    r"\blet['’]s\s+be\s+honest\b", r'\bthe\s+simple\s+fact\s+is\b', r'\bat\s+its\s+core\b',
    r'\bwhat\s+really\s+matters\b', r'\bmore\s+than\s+anything\b', r'\bat\s+the\s+end\s+of\s+the\s+day\b',
    r'\bthe\s+bottom\s+line\s+is\b', r'\bin\s+reality\b', r'\bfundamentally,',
    r'\bthe\s+real\s+question\s+is\b', r'\bthe\s+heart\s+of\s+the\s+matter\b',
    r'\bthe\s+deeper\s+issue\b', r'\bwhen\s+you\s+get\s+down\s+to\s+it\b',
    r'\bwhen\s+all\s+is\s+said\s+and\s+done\b'], kind='advice')

_simple(23, 'editorial_interjection', 'editorial interjection', [
    r"\bit(?:['’]s| is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b",
    r'\bone\s+must\s+note\s+that\b', r'\bit\s+is\s+worth\s+pointing\s+out\b',
    r'\bit\s+cannot\s+be\s+overstated\s+that\b', r'\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b'])

_simple(24, 'self_thoroughness', 'self-thoroughness phrase', [
    r'\bthis\s+(?:comprehensive\s+(?:guide|overview|analysis)|in-depth\s+(?:analysis|look|examination)|complete\s+(?:guide|overview))\b',
    r'\ba\s+thorough\s+examination\s+of\b',
    r'\beverything\s+you\s+need\s+to\s+know\s+about\b'])


def _f25(ctx):
    rx = re.compile(r'(?:^|(?<=[.!?]\s)|(?<=\n))(?:Is|Are|Can|Do|Does|Did|Will|Would|Should|Could|Has|Have|Was|Were|May|Might)\b[^.?!\n]{0,80}\?\s*(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]')
    count = 0
    samples = []
    for mt in rx.finditer(ctx.m):
        count += 1
        if len(samples) < 3:
            samples.append(_snip(ctx.m, mt.start(), mt.end()))
    return count, samples


_fam(25, 'question_answer', 'question-answer rhetorical pattern', 'score', _f25)

_simple(26, 'concrete_evidence', "'concrete evidence' defense phrase", [
    r'\bwithout\s+concrete\s+(?:evidence|proof)\b', r'\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b',
    r'\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b',
    r'\babsent\s+concrete\s+proof\b', r'\bprovide\s+concrete\s+evidence\b'])

_simple(27, 'intro_hook', 'compulsive intro hook', [
    r"\bin\s+today['’]s(?:\s+\S+){0,2}?\s+(?:world|landscape|environment|market)\b",
    r'\bin\s+a\s+world\s+where\b', r'\bin\s+an?\s+era\s+of\b', r'\bin\s+recent\s+years,',
    r'\bmore\s+than\s+ever\s+before\b', r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b',
    r'\b(?:great|exciting|big)\s+news\s*[!:]',
    r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^.\n]{0,80}\?',
    r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b'])

_simple(30, 'diff_anchored', 'diff-anchored writing', [
    r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
    r'\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced)\b',
    r'\b(?:has|have)\s+been\s+changed\s+to\b',
    r'\bpreviously\b[^.\n]*\bnow\b',
    r"\bwasn['’]t\s+there\s+before\b", r"\bweren['’]t\s+there\s+before\b",
    r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
    r'\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b'])

_simple(31, 'signposting', 'signposting and announcement', [
    r"\blet['’]s\s+(?:dive|delve|explore)\b", r"\blet['’]s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b", r'\bwithout\s+further\s+ado\b',
    r"\bnow\s+let['’]s\s+look\s+at\b", r'\bbuckle\s+up\b', r'\bstay\s+with\s+me\b',
    r'\bready\s+to\s+dive\s+in\b'])

_simple(32, 'cataloguing_leadin', 'cataloguing lead-in', [
    r'\b(?:used|uses|employs?|employed|relied\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+',
    r'(?:^|(?<=[.!?]\s)|(?<=\n))These\s+(?:[\w-]+\s+){0,2}?(?:provides?|offers?|gives?|reveals?|shows?|allows?|enables?|helps?)\s+(?:[\w-]+\s+)?(?:information|insights?|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b'])

_fam(33, 'inline_header_list', 'inline-header vertical list', 'score',
     lambda ctx: _scan(ctx, _rx([
         r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]{1,80}?:\*\*',
         r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]{1,80}\*\*:'], re.M)))


def _f34(ctx):
    if re.search(r'^#{1,6}\s', ctx.m, re.M):
        return 0, []
    lists = 0
    prose = 0
    samples = []
    for b in ctx.blocks:
        lines = [ln for ln in b.split('\n') if ln.strip()]
        if not lines:
            continue
        if all(re.match(r'^\s*(?:[-*+]|\d+[.)])\s+', ln) for ln in lines):
            lists += 1
            if len(samples) < 3:
                samples.append(_snip(b, 0, min(len(b), 60)))
        else:
            prose += 1
    if lists >= 1 and prose >= 2:
        return lists, samples
    return 0, []


_fam(34, 'mid_essay_bullets', 'mid-essay bullet injection', 'score', _f34)

_STOP = frozenset(['the', 'and', 'for', 'with', 'of', 'to', 'a', 'an', 'in', 'on', 'from', 'your'])


def _f35(ctx):
    lines = ctx.m.split('\n')
    cnt = 0
    samples = []
    for i, ln in enumerate(lines):
        mh = re.match(r'^#{1,6}\s+(.+?)\s*#*\s*$', ln)
        if not mh:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(?:#|[-*+]\s|\d+[.)]\s|\||>)', nxt):
            continue
        wds = words_list(nxt)
        if not wds or len(wds) > 5:
            continue
        head = set(w.lower() for w in words_list(mh.group(1)) if len(w) >= 3 and w.lower() not in _STOP)
        if any(len(w) >= 3 and w.lower() in head for w in wds):
            cnt += 1
            if len(samples) < 3:
                samples.append(nxt)
    return cnt, samples


_fam(35, 'fragmented_header', 'fragmented header', 'score', _f35)

_simple(36, 'formulaic_challenges', 'formulaic challenges section', [
    r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b',
    r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b',
    r'\bcontinues?\s+to\s+thrive\b',
    r'\btypical\s+of\s+(?:emerging|urban|modern)\b',
    r'\bfaces?\s+(?:several|many|numerous)\s+challenges\b'])

_TRANS_RX = re.compile(r'(?:^|(?<=[.!?])\s+|(?<=\n))(Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b')


def _f37(ctx):
    cnt = 0
    samples = []
    for b in ctx.blocks:
        hits = _TRANS_RX.findall(b)
        if len(hits) >= 2:
            cnt += 1
            if len(samples) < 3:
                samples.append(', '.join(hits))
    return cnt, samples


_fam(37, 'transition_cluster', 'transition cluster', 'score', _f37)

_simple(38, 'compulsive_conclusion', 'compulsive conclusion phrase', [
    r'^[ \t]*(?:In\s+conclusion|Overall|In\s+summary|To\s+summari[sz]e|To\s+conclude|All\s+in\s+all|In\s+essence|Ultimately)\b'],
    flags=re.I | re.M)

_simple(39, 'generic_positive_conclusion', 'generic positive conclusion', [
    r'\bthe\s+future\s+looks\s+bright\b', r'\bexciting\s+times\s+lie\s+ahead\b',
    r'\bjourney\s+toward\s+excellence\b', r'\bstep\s+in\s+the\s+right\s+direction\b',
    r'\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[\w ]+?)?\s+(?:is|looks|remains)\s+bright\b',
    r'\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b'])


def _f40(ctx):
    lens = [word_count(s) for s in ctx.sents]
    if len(lens) < 3:
        return 0, []
    cv = _cv(lens)
    if cv is not None and cv < 0.35:
        return 1, ['sentence lengths %s' % lens[:12]]
    return 0, []


_fam(40, 'sentence_length_monotony', 'sentence-length monotony', 'score', _f40)


def _f41(ctx):
    lens = [word_count(s) for s in ctx.sents]
    if len(lens) < 6:
        return 0, []
    diffs = [lens[i + 1] - lens[i] for i in range(len(lens) - 1)]
    streak = 1
    hits = 0
    for i, d in enumerate(diffs):
        if i > 0 and abs(d) >= 4 and abs(diffs[i - 1]) >= 4 and d * diffs[i - 1] < 0:
            streak += 1
        elif abs(d) >= 4:
            streak = 2
        else:
            streak = 1
        if streak == 6:
            hits += 1
    return hits, (['alternating sentence lengths'] if hits else [])


_fam(41, 'mechanical_alternation', 'mechanical sentence-length alternation', 'advice', _f41)


def _f42(ctx):
    cnt = 0
    for b in ctx.blocks:
        ss = [s for s in _sentences(b)]
        if len(ss) < 3:
            continue
        openers = Counter(' '.join(words_list(s)[:2]).lower() for s in ss)
        if openers and openers.most_common(1)[0][1] >= 3:
            cnt += 1
    return cnt, []


_fam(42, 'opener_repetition', 'opener repetition', 'advice', _f42)


def _f44(ctx):
    lens = [word_count(b) for b in ctx.blocks]
    lens = [x for x in lens if x > 0]
    if len(lens) < 4:
        return 0, []
    cv = _cv(lens)
    if cv is not None and cv < 0.4:
        return 1, ['paragraph lengths %s' % lens[:12]]
    return 0, []


_fam(44, 'uniform_paragraphs', 'uniform paragraph length', 'score', _f44)


def _f46(ctx):
    w = word_count(ctx.m)
    if w < 300:
        return 0, []
    if ';' not in ctx.m and ctx.m.count('(') <= w // 300:
        return 1, []
    return 0, []


_fam(46, 'semicolon_parenthesis', 'semicolon and parenthesis underuse', 'advice', _f46)

_simple(47, 'chatbot_artifact', 'chatbot artifact', [
    r'\bI\s+hope\s+this\s+helps\b', r'\bCertainly!', r'\bOf\s+course!',
    r'\blet\s+me\s+know\s+if\s+you\b', r'\bwould\s+you\s+like\s+me\s+to\b',
    r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b', r'\bhappy\s+to\s+help\s*[.!]',
    r'\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b',
    r'\bhere\s+(?:are|is|[\'’]s)\s+(?:(?:a\s+few|some|two|three)\s+)?(?:options|drafts|versions|variations)\b',
    r"\bhere\s+(?:is|[\'’]s)\s+(?:a\s+)?draft\b",
    r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b',
    r'\bI\s+hope\s+this\s+email\s+finds\s+you\s+well\b',
    r'\bas\s+an\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
    r'\bto\s+(?:answer|address)\s+your\s+question\b',
    r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
    r'\byour\s+question\s+(?:about|regarding|concerning)\b',
    r'\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b',
    r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)\b'],
    flags=re.I)
# Two of the chatbot phrases are case-sensitive exclamations; the rule above is case-insensitive
# except that "Certainly!" and "Of course!" also match lower case, which the spec allows.

_simple(48, 'sycophantic_tone', 'sycophantic tone', [
    r"\byou(?:['’]re| are)\s+absolutely\s+right\b",
    r'\b(?:great|excellent|fantastic|wonderful|brilliant|thoughtful)\s+(?:question|point)\s*[!.,]',
    r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic|brilliant|excellent)\s+question\b',
    r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b"])

_simple(50, 'knowledge_cutoff', 'knowledge-cutoff disclaimer', [
    r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
    r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
    r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b',
    r'\bbased\s+on\s+(?:the\s+)?available\s+information\b',
    r'\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b',
    r'\bmaintains\s+a\s+low\s+profile\b',
    r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b'])

_simple(51, 'copula_avoidance', 'copula avoidance', [
    r'\b(?:serves|stands|functions|acts)\s+as\b', r'\brepresents\s+(?:a|the)\b',
    r'\bmarks\s+(?:a|the)\b', r'\bboasts\b',
    r'\bfeatures\s+(?:an?|the|\d[\d,.]*|several|many|numerous|multiple|various|dozens|hundreds|thousands)\b',
    r'\boffers\s+an?\b', r'\brefers\s+to\b'])

_fam(54, 'hedge_stacking', 'hedge stacking', 'advice', lambda ctx: _f54(ctx))
_HEDGE_RX = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind\s+of\b|\bsort\s+of\b', re.I)


def _f54(ctx):
    cnt = 0
    for s in ctx.sents:
        if len(_HEDGE_RX.findall(s)) >= 2:
            cnt += 1
    return cnt, []


def _f55(ctx):
    words = words_list(ctx.m)
    if not words:
        return 0, []
    first = sum(1 for w in words if w in ('I', 'me', 'my', 'we', 'our', 'us', 'I’m', "I'm"))
    if first / float(len(words)) < 0.03:
        return 0, []
    full = len(re.findall(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|will not|would not|should not|could not|it is|that is|I am|I have|I will|you are|we are|they are|we have|they have|there is|let us)\b", ctx.m, re.I))
    contr = len(re.findall(r"\b\w+(?:n['’]t|['’](?:re|m|ve|ll))\b", ctx.m, re.I))
    if full >= 5 and full / float(full + contr or 1) >= 0.8:
        return 1, []
    return 0, []


_fam(55, 'contraction_absence', 'contraction absence', 'advice', _f55)

_simple(56, 'boldface_overuse', 'boldface overuse', [r'\*\*[^*\n]+?\*\*'], flags=0)

_simple(57, 'emoji', 'emoji', [
    '[\U0001F000-\U0001FAFF☀-➿⭐⭕]'], flags=0)


def _f58(ctx):
    cnt = 0
    for b in ctx.blocks:
        if b.count('—') >= 2:
            cnt += 1
    return cnt, []


_fam(58, 'em_dash_overuse', 'em-dash overuse', 'advice', _f58)

_simple(60, 'curly_quotes', 'curly quotation marks', ['[‘’“”]'], kind='advice', flags=0)

_YEAR_RX = re.compile(r'\b(\d{4})-(\d{4})\b')


def _f61(ctx):
    cnt = 0
    samples = []
    for mt in _YEAR_RX.finditer(ctx.m):
        a, b = int(mt.group(1)), int(mt.group(2))
        if 1000 <= a < b <= 2999:
            cnt += 1
            if len(samples) < 3:
                samples.append(mt.group(0))
    return cnt, samples


_fam(61, 'hyphen_en_dash_range', 'hyphen used for an en dash in a numeric range', 'advice', _f61)

_simple(63, 'placeholder_text', 'placeholder text', [
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b(?![(\[])[^\]\n]*\]',
    r'\[(?:name|company|client|product|place|city|source|author|person|address)\b(?![(\[])[^\]\n]{0,30}\]',
    r'\[(?-i:[A-Z]{2,}[A-Z0-9 _\-]*)\](?![(\[])',
    r'\{\{[^}\n]*\}\}',
    r'(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])',
    r'\blorem\s+ipsum\b'], flags=re.I)
# The all-capitals slot is case-sensitive by construction; the rest is case-insensitive.

_simple(64, 'chat_reference_markup', 'chat reference-markup leak', [
    r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\b',
    r'\bnavlist\b', r'【\d+†[^】\n]*】'], flags=re.I)

_UTM_RX = re.compile(r'utm_source=([A-Za-z0-9.\-]+)', re.I)
_AI_HOSTS = frozenset(['chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
                       'gemini.google.com', 'copilot.microsoft.com', 'poe.com'])


def _f65(ctx):
    cnt = 0
    samples = []
    for mt in _UTM_RX.finditer(ctx.m):
        host = mt.group(1).rstrip('.').lower()
        if host in _AI_HOSTS:
            cnt += 1
            if len(samples) < 3:
                samples.append(mt.group(0))
    return cnt, samples


_fam(65, 'ai_tracking_params', 'AI tracking parameter', 'score', _f65)

_simple(69, 'marketing_slop', 'canonical marketing-slop phrase', [
    r'\bunlock(?:ing)?\s+(?:your\s+|its\s+|their\s+|the\s+)?full\s+potential\b',
    r'\bnavigat(?:e|es|ing)\s+the\s+complexities\b',
    r'\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b',
    r'\bstaying\s+ahead\s+of\s+the\s+curve\b',
    r'\bturning\s+challenges\s+into\s+opportunities\b',
    r'\btaking\s+(?:something|it|your\s+\w+|\w+)\s+to\s+the\s+next\s+level\b',
    r'\bharnessing\s+the\s+power\s+of\b',
    r'\bpaving\s+the\s+way\s+for\b',
    r'\bsaying\s+goodbye\s+to\b',
    r'\bimagining\s+a\s+world\s+where\b'])


def _f70(ctx):
    lines = ctx.m.split('\n')
    hr = [ln for ln in lines if re.match(r'^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$', ln)]
    if len(hr) >= 3 and len(lines) >= 24:
        return len(hr), ['%d horizontal rules' % len(hr)]
    return 0, []


_fam(70, 'decorative_rules', 'decorative horizontal rules', 'score', _f70)


def _f71(ctx):
    toks = re.findall(r'[^\W_]+', ctx.m.lower())
    if len(toks) < 12:
        return 0, []
    grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
    cnt = Counter(grams)
    dup = sum(v for v in cnt.values() if v > 1)
    if dup / float(len(grams)) >= 0.2:
        top = max(cnt.items(), key=lambda kv: kv[1])[0]
        return dup, [' '.join(top)]
    return 0, []


_fam(71, 'degenerate_repetition', 'degenerate repetition', 'score', _f71)


_simple(4, 'hyphenated_pairs', 'hyphenated word-pair overuse', [
    r'\bcutting-edge\b', r'\bstate-of-the-art\b', r'\bgame-changing\b', r'\bnext-generation\b',
    r'\bbest-in-class\b', r'\buser-friendly\b', r'\bhigh-quality\b', r'\bvalue-driven\b',
    r'\bresults-driven\b', r'\bdata-driven\b', r'\bcustomer-centric\b', r'\bwell-crafted\b',
    r'\btime-tested\b'], kind='advice')

_MINOR_WORDS = frozenset(['a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'at',
                          'by', 'in', 'of', 'on', 'to', 'up', 'as', 'per', 'via', 'from', 'with',
                          'into', 'onto', 'over'])


def _f59(ctx):
    cnt = 0
    samples = []
    for ln in ctx.m.split('\n'):
        mh = re.match(r'^#{1,6}\s+(.+?)\s*#*\s*$', ln)
        if not mh:
            continue
        h = mh.group(1)
        wds = words_list(h)
        if len(wds) < 3 or not h[:1].isalpha() or h == h.upper():
            continue
        majors = [w for w in wds if w.lower() not in _MINOR_WORDS]
        if len(majors) < 2:
            continue
        if all(w[0].isupper() for w in majors):
            cnt += 1
            if len(samples) < 3:
                samples.append(h)
    return cnt, samples


_fam(59, 'title_case_heading', 'title case in a heading', 'score', _f59)


# -------------------------------------------------------------------- scoring

def _band(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


PHRASE = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def _score(findings, words):
    """Score from fired families (FP-01). findings: list of dicts."""
    fam_hits = {}
    for f in findings:
        if f['kind'] == 'score':
            fam_hits[f['num']] = fam_hits.get(f['num'], 0) + f['count']
    sm = set(fam_hits)
    raw = 0
    for num, hits in fam_hits.items():
        pts = 5 + 2 * min(hits, 5)
        if num in DECISIVE:
            pts += 6
        raw += pts
    if not sm:
        cap = 0
    elif sm == frozenset([40]):
        cap = 20
    elif sm <= RHYTHM or len(sm) == 1:
        cap = 40
    else:
        cap = 100
    if words < 40:
        conf = 'none'
        reason = 'fewer than 40 words'
    elif words < 120:
        conf = 'low'
        reason = 'fewer than 120 words'
    elif words < 300:
        if len(sm) == 1:
            conf = 'low'
            reason = 'fewer than 300 words with only one pattern family'
        else:
            conf = 'moderate'
            reason = 'fewer than 300 words'
    else:
        conf = 'high'
        reason = ''
    floors = []
    dec_n = len(sm & DECISIVE)
    if dec_n >= 2:
        floors.append(65)
    elif dec_n == 1 and conf in ('moderate', 'high'):
        floors.append(45)
    if words < 120:
        na = len(sm & SMALL_SET)
        if na >= 3:
            floors.append(45)
        elif na >= 2:
            floors.append(25)
    elif words >= 400:
        if len(sm) >= 6:
            floors.append(45)
        elif len(sm) >= 5:
            floors.append(25)
    score = min(raw, cap)
    if floors:
        score = max(score, max(floors))
    score = int(max(0, min(100, score)))
    return score, conf, reason, len(sm)


def _family_findings(ctx):
    out = []
    for num, slug, label, kind, fn in FAMILIES:
        count, samples = fn(ctx)
        if count:
            out.append({'num': num, 'slug': slug, 'label': label, 'kind': kind,
                        'count': int(count), 'samples': list(samples)[:3]})
    return out


def analyze(window):
    """Full analysis of one scan window. Returns a dict with findings and metrics."""
    work = window.replace('\r\n', '\n')
    masked = mask_nonprose(work)
    ctx = Ctx()
    ctx.m = masked
    ctx.blocks = [b for b in re.split(r'\n\s*\n', masked) if b.strip()]
    ctx.sents = _sentences(masked)
    words = word_count(masked)

    findings = _family_findings(ctx)

    # character layer (computed on the window, not the masked text)
    inv = 0
    inv_samples = []
    ns = 0
    ns_samples = []
    for i, kind, keep in special_chars(window):
        if keep:
            continue
        if kind == 'inv':
            inv += 1
            if len(inv_samples) < 3:
                inv_samples.append('U+%04X at character %d' % (ord(window[i]), i + 1))
        elif kind == 'ns':
            ns += 1
            if len(ns_samples) < 3:
                ns_samples.append('U+%04X at character %d' % (ord(window[i]), i + 1))
    hg, hg_samples = homoglyph_runs(window)
    tw = trailing_ws_count(window)

    if inv:
        findings.append({'num': 62, 'slug': 'invisible_characters', 'label': 'invisible or zero-width characters',
                         'kind': 'score', 'count': inv, 'samples': inv_samples})
    if hg:
        findings.append({'num': 66, 'slug': 'homoglyphs', 'label': 'mixed-script homoglyph',
                         'kind': 'score', 'count': hg, 'samples': hg_samples})
    if ns:
        findings.append({'num': 67, 'slug': 'nonstandard_spaces', 'label': 'non-standard space',
                         'kind': 'score', 'count': ns, 'samples': ns_samples})
    if tw:
        findings.append({'num': 68, 'slug': 'trailing_whitespace', 'label': 'trailing or stray whitespace',
                         'kind': 'advice', 'count': tw, 'samples': ['%d places' % tw]})

    findings.sort(key=lambda f: (f['num'], f['slug']))
    score, conf, reason, nfam = _score(findings, words)
    return {
        'findings': findings,
        'words': words,
        'score': score,
        'band': _band(score),
        'confidence': conf,
        'confidence_reason': reason,
        'invisible': inv,
        'nonstandard': ns,
        'homoglyphs': hg,
        'sentences': ctx.sents,
        'families': nfam,
    }


def _interval(window, sents):
    if len(sents) < 4:
        return None, 'too few sentences (%d) for an interval; at least 4 are needed' % len(sents)
    n = len(sents)
    parts = [sents[i * n // 4:(i + 1) * n // 4] for i in range(4)]
    subsets = list(parts)
    for i in range(4):
        rest = []
        for j in range(4):
            if j != i:
                rest.extend(parts[j])
        subsets.append(rest)
    scores = []
    for sub in subsets:
        if not sub:
            continue
        scores.append(analyze(' '.join(sub))['score'])
    if not scores:
        return None, 'too few sentences for an interval'
    lo, hi = min(scores), max(scores)
    return [lo, hi], 'interval from %d sentence subsets (quarters and leave-one-quarter-out); point score is the report score' % len(scores)


def build_report(prose, want_ci):
    window = prose[:WINDOW]
    truncated = len(prose) > WINDOW
    a = analyze(window)
    report = {}
    for f in a['findings']:
        key = '%d_%s' % (f['num'], f['slug'])
        report[key] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': a['score'],
        'ai_tell_band': a['band'],
        'confidence': a['confidence'],
        'confidence_reason': a['confidence_reason'],
        'patterns_flagged': len(a['findings']),
        'invisible_chars': a['invisible'],
        'nonstandard_spaces': a['nonstandard'],
        'homoglyphs': a['homoglyphs'],
    }
    if want_ci:
        ci, note = _interval(window, a['sentences'])
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ------------------------------------------------------------------------ CLI

def _err(msg):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')
    sys.stderr.flush()


def _write_out(text):
    sys.stdout.buffer.write(text.encode('utf-8'))
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    end_opts = False
    for a in argv:
        if end_opts:
            operands.append(a)
            continue
        if a == '--':
            end_opts = True
            continue
        if a in ('-h', '--help'):
            _write_out(USAGE)
            return 0
        if a == '--clean':
            clean = True
            continue
        if a == '--ci':
            ci = True
            continue
        if a.startswith('-'):
            _err("unknown option '%s' (see --help)" % a)
            return 2
        operands.append(a)

    if len(operands) > 1:
        sys.stderr.write('prosecheck: only the first file was scanned: %s (%d more ignored)\n'
                         % (operands[0], len(operands) - 1))
        sys.stderr.flush()

    try:
        if operands:
            prose = load_file(operands[0])
        else:
            prose = decode_bytes(sys.stdin.buffer.read())
    except Fail as e:
        _err(e.msg)
        return e.code

    if prose.strip() == '':
        _err('empty input')
        return 1

    if clean:
        _write_out(clean_text(prose[:]))
        return 0

    report = build_report(prose, ci)
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except BrokenPipeError:
        code = 0
    except Exception as exc:  # no tracebacks on the error stream
        _err('internal error: %s' % (exc,))
        code = 1
    sys.exit(code)
