---
name: prosecheck
description: Rewrite prose flagged by prosecheck, in plain language, when the user asks to "prosecheck this" or "humanize this".
---

# prosecheck rewrite guidance

This skill is instructions for the host agent. The detector never rewrites text.

1. Run the detector on the flagged file: `python3 scripts/detect.py <file>` from the plugin root, and read the findings and their samples.
2. Rewrite only the flagged spans. Keep numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly as written.
3. Vary sentence length. Replace stock vocabulary with plain words. Remove filler, signposting, and chatbot phrasing.
4. Do not add facts. Do not change code, configuration, or commit messages.
5. Run the detector again. Stop after two passes, or when the band is at the target.
