#!/usr/bin/env node
'use strict';
// Stats hook: answers "/prosecheck stats" (also reachable through the prompt-submit router).
const core = require('./lib/core');

function main() {
  const input = core.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt.trim() : '';
  if (!/^\/prosecheck(?::prosecheck)?\s+stats$/i.test(prompt)) return;
  const reply = core.statsReply(input, core.resolveLevel(), core.pluginRoot());
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
