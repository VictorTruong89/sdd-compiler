#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and the welcome on a fresh install).
const fs = require('fs');
const core = require('./lib/core');

function main() {
  core.readStdinJson();
  const root = core.pluginRoot();
  const firstRun = !fs.existsSync(core.flagPath());
  const level = core.resolveLevel();
  if (firstRun) {
    try { core.writeLevel(level); } catch (e) { /* ignore: the hook must not fail the session */ }
  }
  try { core.pruneLedgers(); } catch (e) { /* ignore */ }
  if (level === 'off') return;
  const parts = [];
  if (firstRun) parts.push(core.WELCOME);
  parts.push(core.contractFor(level, { live: true, root }));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
