#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the hook envelope.
const core = require('./lib/core');

function main() {
  core.readStdinJson();
  const level = core.resolveLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.contractFor(level, { live: true, root: core.pluginRoot() }),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
