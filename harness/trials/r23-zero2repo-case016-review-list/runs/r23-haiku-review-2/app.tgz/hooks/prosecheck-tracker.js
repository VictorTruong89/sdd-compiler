#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router, stop phrases, and the live-level reminder.
const core = require('./lib/core');

function main() {
  const input = core.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const routed = core.routeCommand(prompt, input);
  if (routed) {
    process.stdout.write(JSON.stringify({ decision: 'block', reason: routed.reply }) + '\n');
    return;
  }
  const level = core.resolveLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck live level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
