#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const core = require('./lib/core');

const PATH_CAP = 16;

function main() {
  const input = core.readStdinJson();
  const level = core.resolveLevel();
  if (level === 'off' || level === 'lite') return;
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const root = core.pluginRoot();
  const paths = [];
  for (const p of core.pathsFromPayload(input)) {
    if (!paths.includes(p)) paths.push(p);
  }
  const lines = [];
  for (const p of paths.slice(0, PATH_CAP)) {
    const line = core.guardOne(p, input, level, sid, root);
    if (line) lines.push(line);
  }
  if (lines.length === 0) return;
  const out = {
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
