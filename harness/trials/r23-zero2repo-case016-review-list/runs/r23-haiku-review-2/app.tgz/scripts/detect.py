#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage: detect.py [--clean] [--ci] [--] [FILE]
With no FILE, standard input is read. See NOTES.md for the choices made where
the specification is silent or disagrees with itself.
"""
import sys
import os
import re
import io
import json
import random
import bisect
import unicodedata
import zipfile
import zlib
import posixpath
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_EXT = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXT = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NB_EXT = frozenset(['.ipynb'])
MAX_MEMBER = 64 * 1024 * 1024
W_FAM = 14.0
K_RESAMPLE = 100

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan prose for AI-writing patterns and print one JSON report on standard output.
  --clean    print the scrubbed text instead of the report (invisible characters,
             non-standard spaces, mixed-script lookalikes, trailing whitespace)
  --ci       add a low/high interval on the score (needs at least four sentences)
  --         end option parsing, so a file name may begin with a dash
  FILE       a file to scan: .md .mdx .markdown .txt .text .rst .tex .org .adoc,
             .docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub, .ipynb.
             With no FILE, standard input is read.
  -h, --help print this message and exit
"""


class ReadError(Exception):
    pass


def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}, ensure_ascii=False) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def write_out(s):
    sys.stdout.buffer.write(s.encode('utf-8'))
    sys.stdout.flush()


# ---------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(b'\xef\xbb\xbf'):
        return b[3:].decode('utf-8', 'replace')
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        return b.decode('utf-16', 'replace')
    return b.decode('utf-8', 'replace')


def _ln(tag):
    return tag.split('}', 1)[1] if '}' in tag else tag


def _attr_local(el, name):
    for k, v in el.attrib.items():
        if _ln(k) == name:
            return v
    return None


def _tidy(text):
    return '\n'.join(l.strip() for l in text.split('\n') if l.strip())


def _runs_text(root, p_tag, t_tag, tab_tag=None, br_tag=None):
    paras = []
    cur = []
    for el in root.iter():
        t = el.tag
        if t == p_tag:
            paras.append(''.join(cur))
            cur = []
        elif t == t_tag:
            cur.append(el.text or '')
        elif tab_tag and t == tab_tag:
            cur.append('\t')
        elif br_tag and t == br_tag:
            cur.append('\n')
    paras.append(''.join(cur))
    return '\n'.join(paras)


def _member(zf, name):
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MAX_MEMBER:
        return None
    return zf.read(name)


def _xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', name)]


WML = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
DML = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
SML = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
ODT_TEXT = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'


def _odf_walk(el, out):
    name = _ln(el.tag)
    if name in ('annotation', 'annotation-end', 'desc', 'title', 'binary-data'):
        return
    if name == 's':
        try:
            n = int(_attr_local(el, 'c') or 1)
        except ValueError:
            n = 1
        out.append(' ' * max(1, min(n, 1000)))
        return
    if name == 'tab':
        out.append('\t')
        return
    if name == 'line-break':
        out.append('\n')
        return
    if el.text:
        out.append(el.text)
    for ch in el:
        _odf_walk(ch, out)
        if ch.tail:
            out.append(ch.tail)
    if name in ('p', 'h', 'table-cell', 'covered-table-cell', 'table-row'):
        out.append('\n')


class _HTMLText(HTMLParser):
    SKIP = frozenset(['script', 'style', 'nav', 'head', 'title'])
    BLOCK = frozenset(['p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
                       'blockquote', 'pre', 'article', 'header', 'footer', 'dt', 'dd',
                       'figcaption', 'table', 'ul', 'ol', 'aside'])

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag == 'br':
            self.out.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.out.append(re.sub(r'\s+', ' ', data))


def _html_text(data):
    p = _HTMLText()
    try:
        p.feed(data.decode('utf-8', 'replace'))
        p.close()
    except Exception:
        pass
    return ''.join(p.out)


def _extract_epub(zf):
    names = zf.namelist()
    chapters = []
    opf_name = None
    container = _xml(_member(zf, 'META-INF/container.xml'))
    if container is not None:
        for el in container.iter():
            if _ln(el.tag) == 'rootfile' and el.get('full-path'):
                opf_name = el.get('full-path')
                break
    if opf_name and opf_name in names:
        opf = _xml(_member(zf, opf_name))
        if opf is not None:
            base = posixpath.dirname(opf_name)
            manifest = {}
            spine = []
            for el in opf.iter():
                ln = _ln(el.tag)
                if ln == 'item' and el.get('id'):
                    manifest[el.get('id')] = el
                elif ln == 'itemref' and el.get('idref'):
                    spine.append(el.get('idref'))
            for idref in spine:
                item = manifest.get(idref)
                if item is None or 'nav' in (item.get('properties') or '').split():
                    continue
                href = posixpath.normpath(posixpath.join(base, item.get('href') or ''))
                if href in names:
                    chapters.append(href)
    if not chapters:
        chapters = [n for n in sorted(names)
                    if n.lower().endswith(('.xhtml', '.html', '.htm'))
                    and 'nav' not in posixpath.basename(n).lower()]
    parts = []
    for name in chapters:
        data = _member(zf, name)
        if data is None:
            continue
        parts.append(_tidy(_html_text(data)))
    return '\n'.join(p for p in parts if p)


def extract_zip(data, ext):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise ReadError('not a readable zip archive')
    try:
        with zf:
            names = zf.namelist()
            if ext in ('.docx', '.docm'):
                root = _xml(_member(zf, 'word/document.xml'))
                if root is None:
                    return ''
                return _tidy(_runs_text(root, WML + 'p', WML + 't', WML + 'tab', WML + 'br'))
            if ext in ('.pptx', '.pptm'):
                slides = [n for n in names if re.match(r'ppt/slides/slide\d+\.xml$', n)]
                slides.sort(key=_natural_key)
                parts = []
                for n in slides:
                    root = _xml(_member(zf, n))
                    if root is not None:
                        parts.append(_tidy(_runs_text(root, DML + 'p', DML + 't', None, DML + 'br')))
                return '\n'.join(p for p in parts if p)
            if ext in ('.xlsx', '.xlsm'):
                shared = []
                sst = _xml(_member(zf, 'xl/sharedStrings.xml'))
                if sst is not None:
                    for si in sst.iter(SML + 'si'):
                        shared.append(''.join(t.text or '' for t in si.iter(SML + 't')))
                sheets = [n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml$', n)]
                sheets.sort(key=_natural_key)
                cells = []
                for n in sheets:
                    root = _xml(_member(zf, n))
                    if root is None:
                        continue
                    for c in root.iter(SML + 'c'):
                        t = c.get('t')
                        v = c.find(SML + 'v')
                        if t == 's':
                            if v is not None and v.text and re.fullmatch(r'\s*\d+\s*', v.text):
                                idx = int(v.text)
                                if idx < len(shared):
                                    cells.append(shared[idx])
                        elif t == 'inlineStr':
                            cells.append(''.join(x.text or '' for x in c.iter(SML + 't')))
                        elif t == 'str':
                            if v is not None and v.text:
                                cells.append(v.text)
                return '\n'.join(x for x in cells if x.strip())
            if ext in ('.odt', '.odp', '.ods'):
                root = _xml(_member(zf, 'content.xml'))
                if root is None:
                    return ''
                body = None
                for el in root.iter():
                    if _ln(el.tag) == 'body':
                        body = el
                        break
                if body is None:
                    return ''
                out = []
                for ch in body:
                    _odf_walk(ch, out)
                    if ch.tail:
                        out.append(ch.tail)
                return _tidy(''.join(out))
            if ext == '.epub':
                return _extract_epub(zf)
            return ''
    except ReadError:
        raise
    except (zipfile.BadZipFile, KeyError, RuntimeError, zlib.error, OSError, ValueError, MemoryError):
        raise ReadError('not a readable zip archive')


def extract_ipynb(data):
    try:
        nb = json.loads(data.decode('utf-8', 'replace'))
    except (ValueError, RecursionError):
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        if src.strip():
            parts.append(src.strip())
    return '\n'.join(parts).strip()


def extract_text(data, ext):
    """Return the extracted prose for a file body and its (lower-case) extension."""
    if ext in ZIP_EXT:
        return extract_zip(data, ext).strip()
    if ext in NB_EXT:
        return extract_ipynb(data).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    return decode_bytes(data).strip()


# ------------------------------------------------------------ character layer

HOMO = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'ո': 'n', 'о': 'o', 'ο': 'o', 'р': 'p', 'ρ': 'p',
    'ѕ': 's', 'ն': 'u', 'υ': 'u', 'ν': 'v', 'ԝ': 'w', 'х': 'x',
    'χ': 'x', 'у': 'y', 'γ': 'y',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'Ν': 'N', 'О': 'O', 'Ο': 'O',
    'Р': 'P', 'Ρ': 'P', 'Ѕ': 'S', 'Τ': 'T', 'Т': 'T', 'Χ': 'X',
    'Х': 'X', 'Υ': 'Y', 'У': 'Y', 'Ζ': 'Z',
}
LETTER_RUN_RE = re.compile(r'[^\W\d_]+')
RTL_RE = re.compile(r'[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')
FIXED_INVIS = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0])


def _in(cp, lo, hi):
    return lo <= cp <= hi


def _is_cjk(c):
    if not c:
        return False
    cp = ord(c)
    return (_in(cp, 0x4E00, 0x9FFF) or _in(cp, 0x3400, 0x4DBF) or _in(cp, 0xF900, 0xFAFF)
            or _in(cp, 0x20000, 0x2FFFF))


def _is_emoji(c):
    if not c:
        return False
    cp = ord(c)
    return _in(cp, 0x1F000, 0x1FAFF) or _in(cp, 0x2600, 0x27BF) or cp in (0xA9, 0xAE)


def _is_symbol(c):
    return bool(c) and (_is_emoji(c) or unicodedata.category(c).startswith('S'))


def _nospace(c):
    if not c:
        return False
    cp = ord(c)
    return (_in(cp, 0x0E00, 0x0EFF) or _in(cp, 0x1000, 0x109F) or _in(cp, 0x1780, 0x17FF)
            or _in(cp, 0x3040, 0x30FF) or _is_cjk(c))


def _joining(c):
    if not c:
        return False
    cp = ord(c)
    return (_in(cp, 0x0590, 0x06FF) or _in(cp, 0x0900, 0x0DFF) or _in(cp, 0x1000, 0x109F)
            or _in(cp, 0x1780, 0x17FF))


def _keep_invisible(cp, prev, nxt, rtl):
    """True when an invisible character does a job in its position (FP-03)."""
    if _in(cp, 0xFE00, 0xFE0F):
        return _is_symbol(prev) or _is_cjk(prev) or nxt == '\u20e3'
    if _in(cp, 0xE0100, 0xE01EF):
        return _is_cjk(prev)
    if cp == 0x200B:
        return _nospace(prev) or _nospace(nxt)
    if cp == 0xAD:
        return prev.isalpha() and nxt.isalpha()
    if cp in (0x200E, 0x200F, 0x061C) or _in(cp, 0x202A, 0x202E) or _in(cp, 0x2066, 0x2069):
        return rtl
    if _in(cp, 0x180B, 0x180F):
        return _in(ord(prev) if prev else 0, 0x1800, 0x18AF)
    if cp in (0x17B4, 0x17B5):
        return _in(ord(prev) if prev else 0, 0x1780, 0x17FF) or _in(ord(nxt) if nxt else 0, 0x1780, 0x17FF)
    if cp in (0x200C, 0x200D):
        return (_joining(prev) or _joining(nxt) or _is_emoji(prev) or _is_emoji(nxt)
                or _is_symbol(prev) or _is_symbol(nxt))
    return False


def _is_invisible_cp(cp, cat):
    if cp in (9, 10, 13):
        return False
    if cat == 'Cf' or cat == 'Cc':
        return True
    if _in(cp, 0xFE00, 0xFE0F) or _in(cp, 0xE0100, 0xE01EF) or _in(cp, 0xE0000, 0xE0FFF):
        return True
    return cp in FIXED_INVIS or _in(cp, 0x180B, 0x180F)


class CharScan:
    def __init__(self):
        self.remove = set()      # invisible characters that cleanup removes
        self.zs = set()          # space separators that cleanup turns into U+0020
        self.ls = set()          # line/paragraph separators that cleanup turns into LF
        self.homo_runs = []      # (start, end) of mixed-script runs
        self.homo_chars = 0      # lookalike characters inside those runs
        self.trailing = 0


def scan_chars(s):
    cs = CharScan()
    rtl = bool(RTL_RE.search(s))
    n = len(s)
    last_vis = ''
    for i, ch in enumerate(s):
        cp = ord(ch)
        if cp < 0x80:
            if (cp < 0x20 and ch not in '\t\n\r') or cp == 0x7F:
                cs.remove.add(i)
                continue
            last_vis = ch
            continue
        cat = unicodedata.category(ch)
        is_tag = _in(cp, 0xE0000, 0xE007F)
        if is_tag or _is_invisible_cp(cp, cat):
            if is_tag:
                keep = _is_emoji(last_vis)
            else:
                nxt = s[i + 1] if i + 1 < n else ''
                keep = _keep_invisible(cp, last_vis, nxt, rtl)
            if not keep:
                cs.remove.add(i)
            continue
        if cat == 'Zs':
            if cp in (0xA0, 0x202F):
                prev = s[i - 1] if i > 0 else ''
                nxt = s[i + 1] if i + 1 < n else ''
                kept = prev.isdigit() or nxt.isdigit() or nxt in ':;!?»›%€' or prev in '«‹'
                if not kept:
                    cs.zs.add(i)
            else:
                cs.zs.add(i)
        elif cat in ('Zl', 'Zp'):
            cs.ls.add(i)
        last_vis = ch
    if any(c in HOMO for c in s):
        for m in LETTER_RUN_RE.finditer(s):
            run = m.group(0)
            if not any(c in HOMO for c in run):
                continue
            has_ascii = any(('a' <= c <= 'z') or ('A' <= c <= 'Z') for c in run)
            others = any(ord(c) > 127 and c not in HOMO and c.isalpha() for c in run)
            if has_ascii and not others:
                cs.homo_runs.append((m.start(), m.end()))
                cs.homo_chars += sum(1 for c in run if c in HOMO)
    cs.trailing = trailing_count(s)
    return cs


def trailing_count(s):
    if not s:
        return 0
    cnt = 0
    lines = s.split('\n')
    for line in lines[:-1]:
        if line.endswith((' ', '\t')):
            cnt += 1
    if lines[-1].endswith((' ', '\t')):
        cnt += 1
    if s.endswith('\n\n'):
        cnt += 1
    if s[0].isspace():
        cnt += 1
    return cnt


def cleanup_text(text):
    cs = scan_chars(text)
    homo = {}
    for a, b in cs.homo_runs:
        for i in range(a, b):
            if text[i] in HOMO:
                homo[i] = HOMO[text[i]]
    out = []
    for i, ch in enumerate(text):
        if i in cs.remove:
            continue
        if i in cs.zs:
            out.append(' ')
        elif i in cs.ls:
            out.append('\n')
        elif i in homo:
            out.append(homo[i])
        else:
            out.append(ch)
    lines = [l.rstrip(' \t') for l in ''.join(out).split('\n')]
    while lines and not lines[0].strip():
        lines.pop(0)
    body = '\n'.join(lines).rstrip()
    if text.endswith('\n') and body:
        body += '\n'
    return body


# ------------------------------------------------------------ markdown masking

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
BADGE_RE = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')


def mask_markdown(text):
    """Blank out the regions that generate no findings (FP-01)."""
    lines = text.split('\n')
    n = len(lines)
    keep = [True] * n
    start = 0
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    keep[k] = False
                start = j + 1
                break
    i = start
    while i < n:
        m = FENCE_OPEN.match(lines[i])
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            ch = fence[0]
            ln = len(fence)
            keep[i] = False
            j = i + 1
            while j < n:
                keep[j] = False
                mm = FENCE_CLOSE.match(lines[j])
                if mm and mm.group(1)[0] == ch and len(mm.group(1)) >= ln:
                    break
                j += 1
            i = j + 1
            continue
        i += 1
    out = [lines[k] if keep[k] else '' for k in range(n)]
    # blockquote runs of two or more lines, table rows, badge lines
    k = 0
    while k < n:
        if re.match(r'^\s*>', out[k]):
            j = k
            while j < n and re.match(r'^\s*>', out[j]):
                j += 1
            if j - k >= 2:
                for q in range(k, j):
                    out[q] = ''
            k = j
            continue
        k += 1
    for k in range(n):
        if re.match(r'^\s*\|', out[k]) or BADGE_RE.match(out[k]):
            out[k] = ''
    text2 = '\n'.join(out)
    text2 = re.sub(r'`[^`\n]*`', ' ', text2)
    return text2


# ------------------------------------------------------------ helpers for rules

WORD_RE = re.compile(r"[^\W_]+(?:['’-][^\W_]+)*")
SENT_RE = re.compile(r'\S.*?(?:[.!?]+(?=\s|$)|$)', re.M)
PARA_RE = re.compile(r'(?:[^\n]|\n(?!\s*\n))+')


def W(word):
    base = word[:-1] if word.endswith('e') else word
    return re.escape(base) + r'(?:e|es|ed|ing|s|d)?'


def P(phrase):
    parts = []
    for w in phrase.split():
        esc = re.escape(w)
        esc = esc.replace("'", "['’]").replace(r'\-', '[- ]')
        parts.append(esc)
    return r'\s+'.join(parts)


def snip(s):
    s = ' '.join(s.split())
    return s if len(s) <= 80 else s[:77] + '...'


def _matches(rxs, text):
    ms = []
    for rx in rxs:
        ms.extend(rx.finditer(text))
    ms.sort(key=lambda m: m.start())
    return ms


def rx_fn(pats, flags=re.I, thr=1):
    rxs = [re.compile(p, flags) for p in pats]

    def fn(ctx):
        ms = _matches(rxs, ctx.masked)
        if len(ms) < thr:
            return 0, [], []
        return len(ms), [snip(m.group(0)) for m in ms[:3]], [m.start() for m in ms]
    return fn


def _sentence_index(ctx, pos):
    idx = bisect.bisect_right(ctx.sent_starts, pos) - 1
    return max(0, idx)


class Ctx:
    pass


def build_ctx(masked, window, chars):
    c = Ctx()
    c.masked = masked
    c.window = window
    c.chars = chars
    c.sents = []
    for m in SENT_RE.finditer(masked):
        c.sents.append((m.start(), m.end(), len(WORD_RE.findall(m.group(0)))))
    c.sent_starts = [s for s, _, _ in c.sents]
    c.sent_texts = [masked[s:e] for s, e, _ in c.sents]
    c.sent_words = [w for _, _, w in c.sents]
    c.sent_lens = [w for w in c.sent_words if w > 0]
    c.words = len(WORD_RE.findall(masked))
    if re.search(r'\n\s*\n', masked):
        c.paras = [m.group(0).strip() for m in PARA_RE.finditer(masked)]
    else:
        c.paras = [l.strip() for l in masked.split('\n')]
    c.paras = [p for p in c.paras if p]
    c.para_words = [len(WORD_RE.findall(p)) for p in c.paras]
    return c


def _cv(vals):
    m = sum(vals) / len(vals)
    if m <= 0:
        return None
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return var ** 0.5 / m, m


# ------------------------------------------------------------ family rules

def fn_ai_vocab(ctx):
    words = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
             'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
             'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
             'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
             'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
             'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']
    pats = [r'\b(?:' + '|'.join([W(w) for w in words]
                                + [r'align(?:s|ed|ing)?\s+with',
                                   r'capture[sd]?\s+the\s+(?:essence|spirit|imagination|heart|magic)'])
            + r')\b']
    return rx_fn(pats)(ctx)


DIALECT_PATS = [
    r'\b(?:' + '|'.join(W(w) for w in ['genuinely', 'fascinating', 'nuanced', 'thoughtfully',
                                        'refreshingly', 'strikingly', 'compellingly', 'supercharge',
                                        'skyrocket', 'turbocharge', 'revolutionize']) + r')\b',
    r'\bquietly\s+(?:powerful|profound|radical)\b',
    r'\bdeeply\s+(?:human|personal|felt|unsettling)\b',
    r'\bresonates?\s+deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b',
    r'\bdouble\s+down\s+on\b',
    r'\bdive\s+deep(?:er)?\s+into\b',
    r'\bunlock\s+(?:the\s+)?(?:power|potential|value)\b',
    r'\btake\s+[^.!?\n]{1,60}?\s+to\s+the\s+next\s+level\b',
]
fn_dialect = rx_fn(DIALECT_PATS, thr=2)

PROMO_PHRASES = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming',
                 'idyllic', 'vibrant community', 'rich cultural heritage', 'in the heart of',
                 'world-class', 'top-tier', 'unparalleled', 'premier', 'leading',
                 'esteemed organization', 'valuable asset', 'passion for excellence',
                 'proven track record', 'results-oriented', 'wealth of experience', 'dynamic team',
                 'fast-paced environment', 'deeply passionate', 'perfectly situated',
                 'close-knit team', 'tight-knit team', 'uniquely positioned to']
PROMO_RX = [re.compile(r'\b' + P(p) + r'\b', re.I) for p in PROMO_PHRASES]
PROMO_RX.append(re.compile(r"\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b", re.I))
MARKETING_VERB_RE = re.compile(
    r'\s*(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|'
    r'elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|'
    r'stop|start)\b', re.I)


def fn_promo(ctx):
    ms = _matches(PROMO_RX, ctx.masked)
    count = len(ms)
    samples = [snip(m.group(0)) for m in ms[:3]]
    pos = [m.start() for m in ms]
    verb_idx = [st for (st, _, _), txt in zip(ctx.sents, ctx.sent_texts) if MARKETING_VERB_RE.match(txt)]
    if len(verb_idx) >= 3:
        count += len(verb_idx)
        pos = sorted(pos + verb_idx)
        samples = (samples + ['sentences opening with a marketing verb'])[:3]
    return count, samples, pos


HYPHEN_STOCK = ['cutting-edge', 'state-of-the-art', 'best-in-class', 'top-notch', 'user-friendly',
                'high-quality', 'next-generation', 'data-driven', 'customer-centric',
                'results-driven', 'forward-thinking', 'value-added', 'high-performance']
fn_hyphen = rx_fn([r'\b' + P(h) + r'\b' for h in HYPHEN_STOCK])
fn_simple_yet = rx_fn([r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|'
                       r'sophisticated|beautiful)\b'])

ADJ_STOCK = {'stunning', 'beautiful', 'elegant', 'powerful', 'seamless', 'robust', 'vibrant',
             'innovative', 'intuitive', 'reliable', 'efficient', 'scalable', 'modern', 'dynamic',
             'sleek', 'premium', 'effective', 'flexible', 'versatile', 'clear', 'concise', 'bold',
             'thoughtful', 'rich', 'lush', 'cutting-edge', 'comprehensive', 'holistic'}
ADJ_SUF = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
SEP = r"(?:\s*,\s*(?:and\s+)?|\s+and\s+)"
CHAIN_RE = re.compile(r"\b([A-Za-z][A-Za-z'’-]*" + SEP + r"[A-Za-z][A-Za-z'’-]*(?:" + SEP
                      + r"[A-Za-z][A-Za-z'’-]*){2})\s+[A-Za-z][A-Za-z'’-]*")
WORD_ONLY_RE = re.compile(r"[A-Za-z][A-Za-z'’-]*")


def fn_chains(ctx):
    count, samples, pos = 0, [], []
    for m in CHAIN_RE.finditer(ctx.masked):
        words = [w for w in WORD_ONLY_RE.findall(m.group(1)) if w.lower() != 'and']
        if any(w.lower() in ADJ_STOCK or ADJ_SUF.search(w) for w in words):
            count += 1
            pos.append(m.start())
            if len(samples) < 3:
                samples.append(snip(m.group(0)))
    return count, samples, pos


CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
CLUSTER_RX = [[re.compile(r'\b' + P(m) + r'(?:s|es)?\b', re.I) for m in cl] for cl in CLUSTERS]


def fn_cluster(ctx):
    total, samples, pos = 0, [], []
    for rxs in CLUSTER_RX:
        found = [_matches([rx], ctx.masked) for rx in rxs]
        found = [ms for ms in found if ms]
        if len(found) >= 3:
            for ms in found:
                total += len(ms)
                pos.extend(m.start() for m in ms)
                if len(samples) < 3:
                    samples.append(snip(ms[0].group(0)))
    return total, samples[:3], sorted(pos)


def fn_headings_titlecase(ctx):
    minor = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'by', 'for', 'from', 'with', 'as',
             'up', 'off', 'via', 'per', 'into', 'onto', 'over', 'and', 'but', 'or', 'nor', 'so', 'yet'}
    count, samples = 0, []
    for line in ctx.masked.split('\n'):
        m = re.match(r'^#{1,6}[ \t]+(.+?)[ \t#]*$', line)
        if not m:
            continue
        h = m.group(1).strip()
        if not h or h == h.upper() or not h[0].isalpha():
            continue
        words = h.split()
        if len(words) < 3:
            continue
        majors = [w for w in words if w.lower().strip('.,:;!?"\'()') not in minor]
        if len(majors) < 2:
            continue
        if all(w[0].isupper() for w in majors if w[0].isalpha()):
            count += 1
            if len(samples) < 3:
                samples.append(snip(h))
    return count, samples, None


def fn_bullet_injection(ctx):
    if re.search(r'(?m)^#{1,6}\s', ctx.masked):
        return 0, [], None
    bullet = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
    lists = 0
    prose = 0
    for para in ctx.paras:
        ls = [l for l in para.split('\n') if l.strip()]
        if ls and all(bullet.match(l) for l in ls):
            lists += 1
        elif not para.startswith('#'):
            prose += 1
    if lists >= 1 and prose >= 2:
        return lists, ['bulleted list paragraph among prose'], None
    return 0, [], None


def fn_fragmented_headers(ctx):
    lines = ctx.masked.split('\n')
    count, samples = 0, []
    for i, line in enumerate(lines):
        m = re.match(r'^#{1,6}\s+(.+?)\s*#*\s*$', line)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        cand = lines[j].strip()
        if re.match(r'^(?:#|[-*+]\s|\d+[.)]\s|\|)', cand):
            continue
        cw = [w.lower() for w in WORD_RE.findall(cand)]
        if not (1 <= len(cw) <= 4):
            continue
        hw = {w.lower() for w in WORD_RE.findall(m.group(1)) if len(w) >= 3}
        if hw & set(cw):
            count += 1
            if len(samples) < 3:
                samples.append(snip(cand))
    return count, samples, None


TRANS_RE = re.compile(r'(?:^|(?<=[.!?]\s))(?:Additionally|Furthermore|Moreover|However|Nevertheless|'
                      r'Consequently|Subsequently|Notably)\b', re.M)


def fn_transitions(ctx):
    count, samples = 0, []
    for para in ctx.paras:
        ms = list(TRANS_RE.finditer(para))
        if len(ms) >= 2:
            count += len(ms)
            for m in ms:
                if len(samples) < 3:
                    samples.append(snip(m.group(0)))
    return count, samples[:3], None


def fn_monotony(ctx):
    L = ctx.sent_lens
    if len(L) < 3:
        return 0, [], None
    r = _cv(L)
    if r and r[0] < 0.35:
        return 1, ['%d sentences of nearly equal length (mean %.1f words)' % (len(L), r[1])], None
    return 0, [], None


def fn_uniform_paragraphs(ctx):
    pw = ctx.para_words
    if len(pw) < 4:
        return 0, [], None
    r = _cv(pw)
    if r and r[0] < 0.4:
        return 1, ['%d paragraphs of nearly equal length' % len(pw)], None
    return 0, [], None


def fn_mechanical(ctx):
    L = ctx.sent_lens
    n = len(L)
    hits = 0
    i = 0
    while i < n - 1:
        j = i
        while j + 1 < n and abs(L[j + 1] - L[j]) >= 6 and (j == i or (L[j + 1] - L[j]) * (L[j] - L[j - 1]) < 0):
            j += 1
        if j - i + 1 >= 6:
            hits += 1
            i = j + 1
        else:
            i += 1
    return hits, (['alternating sentence lengths'] if hits else []), None


def fn_opener_repetition(ctx):
    count = 0
    for para in ctx.paras:
        sents = [s for s in re.split(r'(?<=[.!?])\s+', para) if s.strip()]
        if len(sents) < 3:
            continue
        openers = _top_count([' '.join(WORD_RE.findall(s)[:2]).lower() for s in sents])
        if openers >= 3:
            count += 1
    return count, (['repeated sentence openers'] if count else []), None


def _top_count(items):
    best = {}
    for it in items:
        if not it:
            continue
        best[it] = best.get(it, 0) + 1
    return max(best.values()) if best else 0


def fn_semicolons(ctx):
    if ctx.words < 300:
        return 0, [], None
    if ';' in ctx.masked:
        return 0, [], None
    parens = ctx.masked.count('(')
    if parens * 1000 / ctx.words < 2:
        return 1, ['no semicolons and almost no parentheses'], None
    return 0, [], None


HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|"
                      r"appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")


def fn_hedge(ctx):
    count, samples, pos = 0, [], []
    for (st, en, _), txt in zip(ctx.sents, ctx.sent_texts):
        ms = HEDGE_RE.findall(txt)
        if len(ms) >= 2:
            count += 1
            pos.append(st)
            if len(samples) < 3:
                samples.append(snip(txt))
    return count, samples, pos


FP_RE = re.compile(r"\b(?:I|we|my|our|me|us|I'm|I've|I'll|I'd)\b", re.I)
WRITTEN_RE = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|have not|has not|"
                        r"will not|would not|could not|should not|cannot|it is|that is|I am|we are|"
                        r"they are|you are|there is|let us|I have|we have|they have|I will|we will|"
                        r"I would)\b", re.I)
CONTR_RE = re.compile(r"\b(?:don['’]t|doesn['’]t|didn['’]t|isn['’]t|aren['’]t|"
                      r"wasn['’]t|weren['’]t|haven['’]t|hasn['’]t|won['’]t|"
                      r"wouldn['’]t|couldn['’]t|shouldn['’]t|can['’]t|it['’]s|"
                      r"that['’]s|I['’]m|we['’]re|they['’]re|you['’]re|"
                      r"there['’]s|let['’]s|I['’]ve|we['’]ve|they['’]ve|"
                      r"I['’]ll|we['’]ll|I['’]d)\b", re.I)


def fn_contractions(ctx):
    words = ctx.words
    if words < 40:
        return 0, [], None
    fp = len(FP_RE.findall(ctx.masked))
    if fp / words < 0.03:
        return 0, [], None
    written = len(WRITTEN_RE.findall(ctx.masked))
    contracted = len(CONTR_RE.findall(ctx.masked))
    if written >= 3 and written >= 0.8 * (written + contracted):
        return 1, ['most contractible forms written out'], None
    return 0, [], None


def fn_em_dash_paragraphs(ctx):
    count = 0
    for para in ctx.paras:
        if para.count('—') >= 2:
            count += 1
    return count, (['paragraph with two or more em dashes'] if count else []), None


def fn_year_range(ctx):
    count, samples = 0, []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            count += 1
            if len(samples) < 3:
                samples.append(snip(m.group(0)))
    return count, samples, None


def fn_decorative_rules(ctx):
    lines = ctx.masked.split('\n')
    if len(lines) < 24:
        return 0, [], None
    rule = re.compile(r'^\s*(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$')
    count = sum(1 for l in lines if rule.match(l))
    if count >= 3:
        return count, ['%d decorative rules' % count], None
    return 0, [], None


def fn_degenerate(ctx):
    toks = [t.lower() for t in re.findall(r"[^\W_]+", ctx.masked)]
    if len(toks) < 12:
        return 0, [], None
    grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
    total = len(grams)
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = sum(c for c in counts.values() if c > 1)
    if repeated == 0 or repeated / total < 0.2:
        return 0, [], None
    top = sorted(((c, g) for g, c in counts.items() if c > 1), reverse=True)[:2]
    return repeated, [snip(' '.join(g)) for _, g in top], None


def fn_invisible(ctx):
    cs = ctx.chars
    cnt = len(cs.remove)
    samples = []
    for i in sorted(cs.remove)[:3]:
        samples.append('U+%04X at character %d' % (ord(ctx.window[i]), i + 1))
    return cnt, samples, None


def fn_homoglyph(ctx):
    cs = ctx.chars
    samples = [snip(ctx.window[a:b]) for a, b in cs.homo_runs[:3]]
    return len(cs.homo_runs), samples, None


def fn_nonstandard(ctx):
    cs = ctx.chars
    samples = ['U+%04X' % ord(ctx.window[i]) for i in sorted(cs.zs)[:3]]
    return len(cs.zs), samples, None


def fn_trailing(ctx):
    return ctx.chars.trailing, (['trailing whitespace'] if ctx.chars.trailing else []), None


def build_families():
    fams = []

    def add(key, label, fn, advice=False, decisive=False):
        fams.append(Fam(key, label, fn, advice, decisive))

    add(1, 'AI vocabulary', fn_ai_vocab)
    add(2, 'model-dialect vocabulary', fn_dialect)
    add(3, 'promotional language', fn_promo)
    add(4, 'hyphenated word-pair overuse', fn_hyphen, advice=True)
    add(5, '"simple yet" cliche', fn_simple_yet)
    add(6, 'stacked adjective chains', fn_chains)
    add(8, 'synonym cycling', fn_cluster)
    add(10, 'significance inflation', rx_fn([
        r'\b(?:stands?|serves?|stood|served)\s+as\s+(?:an?\s+|the\s+)?(?:testament|reminder|symbol|beacon|'
        r'cornerstone|bridge|gateway|hallmark)s?\b',
        r'\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|'
        r'central|vital|crucial|pivotal|key)\b',
        r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b',
        r'\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
        r'\bsymbolizes\b',
        r'\bsets?\s+the\s+stage\s+for\b',
        r'\bleft\s+an?\s+indelible\s+mark\b',
        r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
        r'\bhas\s+(?:shaped|sparked)\b',
        r'\bhas\s+come\s+to\s+(?:define|symbolize)\b']))
    add(11, 'notability name-dropping', rx_fn([
        r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+[A-Z][\w&.]*'
        r'(?:,\s*(?:and\s+)?|\s+and\s+)[A-Z][\w&.]*',
        r'\bwith\s+(?:over\s+|more\s+than\s+)?\d[\d,.]*\s*[KkMm]?\s+followers\b',
        r'\bstrong\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bactive\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bwidely\s+covered\b',
        r'\bindependent\s+coverage\b'], flags=0))
    add(12, 'vague attributions', rx_fn([
        r'\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b',
        r'\bindustry\s+(?:reports|observers|analysts)\b',
        r'\bobservers\s+have\s+(?:cited|noted)\b',
        r'\bsome\s+critics\s+argue\b',
        r'\bresearchers\s+have\s+found\b',
        r'\bstudies\s+suggest\b',
        r'\bit\s+is\s+widely\s+believed\b']))
    add(13, 'article title used as a proper noun', rx_fn([
        r'\b(?-i:The)\s+(?i:list|index|compilation|collection|catalogue|guide|overview)\s+of\s+'
        r"[\w'’-]+(?:\s+[\w'’-]+){0,6}?\s+(?i:is|was)\s+(?i:a|an|the)\b"], flags=0), decisive=True)
    add(14, 'conservation padding', rx_fn([
        r'\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
        r'\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b',
        r'\bserves\s+as\s+an?\s+indicator\s+species\b',
        r'\bcontributes\s+to\s+biodiversity\b']))
    add(15, 'false range', rx_fn([
        r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?'
        r'\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b']))
    add(16, 'superficial -ing tail clause', rx_fn([
        r',\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
        r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
        r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b']))
    add('17p', 'negative parallelism', rx_fn([
        r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b",
        r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b',
        r"\bdoesn['’]t\s+just\b[^,.\n]{0,40}?\bit\b"]), advice=True)
    add('17t', 'tailing negation', rx_fn([
        r',\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b']))
    add(18, '"not X, just Y" framing', rx_fn([
        r'\b(?:no|not)\s+[\w\'’-]+,\s*(?:just|only|simply)\s+[\w\'’-]+',
        r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+"
        r"(?:a|an|the)\s+[\w'’-]+\s*(?:,|–|—|-)\s*(?:it['’]s|it\s+is|it\s+was|"
        r"they['’]re|they\s+are|they\s+were|that['’]s|but)\b"]))
    add(19, 'filler phrase', rx_fn([r'\b' + P(p) + r'\b' for p in [
        'in order to', 'due to the fact that', 'at this point in time', 'in the event that',
        'has the ability to', 'it is important to note that', 'it should be mentioned that',
        'needless to say']]), advice=True)
    add(20, 'empty pivot phrase', rx_fn([
        r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b",
        r'\bit\s+bears\s+(?:noting|mentioning)\s+that\b',
        r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b',
        r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
        r'\ba\s+key\s+consideration\s+is\b',
        r'\ba\s+point\s+to\s+highlight\s+is\b']))
    add(21, 'outcome-speculation tail', rx_fn([
        r',\s*(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|'
        r'with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|'
        r'signaling\s+a\s+shift\s+toward)\b']))
    add(22, 'persuasive authority trope', rx_fn([r'\b' + P(p) + r'\b' for p in [
        "here's the thing", 'make no mistake', 'the truth is', "let's be honest", 'the simple fact is',
        'at its core', 'what really matters', 'more than anything', 'at the end of the day',
        'the bottom line is', 'in reality', 'the real question is', 'the heart of the matter',
        'the deeper issue', 'when you get down to it', 'when all is said and done']]
        + [r'\bfundamentally,']), advice=True)
    add(23, 'editorial interjection', rx_fn([
        r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize)\b",
        r'\bone\s+must\s+note\s+that\b',
        r'\bit\s+is\s+worth\s+pointing\s+out\b',
        r'\bit\s+cannot\s+be\s+overstated\s+that\b',
        r'\bit\s+must\s+be\s+emphasized\s+that\b']))
    add(24, 'self-thoroughness phrase', rx_fn([
        r'\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b',
        r'\bthis\s+in-depth\s+(?:analysis|look|examination)\b',
        r'\bthis\s+complete\s+(?:guide|overview)\b',
        r'\ba\s+thorough\s+examination\s+of\b',
        r'\beverything\s+you\s+need\s+to\s+know\s+about\b']))
    add(25, 'question-answer rhetorical pattern', rx_fn([
        r'(?:^|(?<=[.!?]\s)|(?<=\n))(?:is|are|can|could|do|does|did|will|would|should|has|have|was|were|'
        r'may|might|must)\b[^?\n]{0,100}\?\s+(?:yes|no|absolutely|never|maybe|probably|always)[.!]'],
        flags=re.I | re.M))
    add(26, '"concrete evidence" defense phrase', rx_fn([
        r'\bwithout\s+concrete\s+(?:evidence|proof)\b',
        r'\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b',
        r'\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b',
        r'\babsent\s+concrete\s+proof\b',
        r'\bprovide\s+concrete\s+(?:evidence|proof)\b']))
    add(27, 'compulsive intro hook', rx_fn([
        r"\bin\s+today['’]s(?:\s+\w+){0,2}?\s+(?:world|landscape|environment|market)\b",
        r'\bin\s+a\s+world\s+where\b',
        r'\bin\s+an\s+era\s+of\b',
        r'\bin\s+recent\s+years,',
        r'\bmore\s+than\s+ever\s+before\b',
        r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b',
        r'\b(?:great|exciting|big)\s+news\s*[!:]',
        r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^?\n]{0,120}\?',
        r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b']))
    add(30, 'diff-anchored writing', rx_fn([
        r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
        r'\bthe\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+'
        r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\bthis\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+'
        r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b',
        r'\bpreviously\b[^.!?\n]*\bnow\b',
        r"\bwasn['’]t\s+there\s+before\b|\bweren['’]t\s+there\s+before\b",
        r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
        r'\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b']))
    add(31, 'signposting and announcement', rx_fn([
        r"\blet['’]s\s+(?:dive|delve|explore)\b",
        r"\blet['’]s\s+break\s+(?:this|it)\s+down\b",
        r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b",
        r'\bwithout\s+further\s+ado\b',
        r"\bnow\s+let['’]s\s+look\s+at\b",
        r'\bbuckle\s+up\b',
        r'\bstay\s+with\s+me\b',
        r'\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b']))
    add(32, 'cataloguing lead-in', rx_fn([
        r'\b(?:used|uses|use|employs?|employed|relied\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|'
        r'multiple|different|many|numerous)\s+\w+',
        r'(?:^|(?<=[.!?]\s)|(?<=\n))(?-i:These)(?:\s+\w+)?\s+(?:provides?|offers?|gives?|reveals?|shows?|'
        r'allows?|enables?|helps?)\s+(?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|an?\s+)?(?:language|currency|architecture|'
        r'heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b']))
    add(33, 'inline-header vertical list', rx_fn([
        r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?(?:\*\*[^*\n]*:\*\*|\*\*[^*\n]+\*\*:)'], flags=re.M))
    add(34, 'mid-essay bullet injection', fn_bullet_injection)
    add(35, 'fragmented header', fn_fragmented_headers)
    add(36, 'formulaic challenges section', rx_fn([
        r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b',
        r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b',
        r'\bcontinues\s+to\s+thrive\b',
        r'\btypical\s+of\s+(?:emerging|urban|modern)\b',
        r'\bfaces\s+(?:several|many|numerous)\s+challenges\b']))
    add(37, 'transition cluster', fn_transitions)
    add(38, 'compulsive conclusion opener', rx_fn([
        r'^\s*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|'
        r'in\s+essence|ultimately)\b'], flags=re.I | re.M))
    add(39, 'generic positive conclusion', rx_fn([
        r'\bthe\s+future\s+looks\s+bright\b',
        r'\bexciting\s+times\s+lie\s+ahead\b',
        r'\bjourney\s+toward\s+excellence\b',
        r'\bstep\s+in\s+the\s+right\s+direction\b',
        r'\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[\w ]+?)?\s+(?:is|looks|remains)\s+bright\b',
        r'\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b']))
    add(40, 'sentence-length monotony', fn_monotony)
    add(41, 'mechanical sentence-length alternation', fn_mechanical, advice=True)
    add(42, 'opener repetition', fn_opener_repetition, advice=True)
    add(44, 'uniform paragraph length', fn_uniform_paragraphs)
    add(46, 'semicolon and parenthesis underuse', fn_semicolons, advice=True)
    add(47, 'chatbot artifact', rx_fn([
        r'\bI\s+hope\s+this\s+helps\b',
        r'\bCertainly!',
        r'\bOf\s+course!',
        r'\blet\s+me\s+know\s+if\s+you\b',
        r'\bwould\s+you\s+like\s+me\s+to\b',
        r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b',
        r'\bhappy\s+to\s+help\s*(?:[.!]|$)',
        r'\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b',
        r"\bhere\s+(?:are|['’]s|is)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
        r"\bhere\s+(?:is|['’]s)\s+(?:a\s+)?draft\b",
        r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b',
        r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b',
        r'\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b',
        r'\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
        r'\bto\s+(?:answer|address)\s+your\s+question\b',
        r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
        r'\byour\s+question\s+(?:about|regarding|concerning)\b',
        r'\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b'], flags=0), decisive=True)
    add(48, 'sycophantic tone', rx_fn([
        r"\byou(?:['’]re| are)\s+absolutely\s+right\b",
        r'\b(?:great|excellent)\s+(?:question|point)\s*[!.,]',
        r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b',
        r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b"]),
        decisive=True)
    add(50, 'knowledge-cutoff disclaimer', rx_fn([
        r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
        r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
        r'\bwhile\s+(?:specific\s+)?details\s+(?:are|is)\s+(?:limited|scarce|not\s+(?:extensively\s+|widely\s+)?documented)',
        r'\bbased\s+on\s+(?:the\s+)?available\s+information\b',
        r'\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b',
        r'\bmaintains\s+a\s+low\s+profile\b',
        r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b']), decisive=True)
    add(51, 'copula avoidance', rx_fn([
        r'\b(?:serves|stands|functions|acts)\s+as\b',
        r'\brepresents\s+(?:a|the)\b',
        r'\bmarks\s+(?:a|the)\b',
        r'\bboasts\b',
        r'\bfeatures\s+(?:an?|the|\d+|several|many|numerous|multiple|two|three|four|five|six|seven|eight|nine|ten)\b',
        r'\boffers\s+an?\b',
        r'\brefers\s+to\b']))
    add(54, 'hedge stacking', fn_hedge, advice=True)
    add(55, 'contraction absence', fn_contractions, advice=True)
    add(56, 'boldface overuse', rx_fn([r'\*\*[^*\n]+?\*\*'], flags=0, thr=3))
    add(57, 'emoji', rx_fn([r'[\U0001F000-\U0001FAFF\u2600-\u27bf]'], flags=0))
    add(58, 'em-dash overuse', fn_em_dash_paragraphs, advice=True)
    add(59, 'title case in headings', fn_headings_titlecase)
    add(60, 'curly quotation marks', rx_fn([r'[“”‘’]'], flags=0), advice=True)
    add(61, 'hyphen for en dash in year range', fn_year_range, advice=True)
    add(62, 'invisible or zero-width characters', fn_invisible, decisive=True)
    add(63, 'placeholder text', rx_fn([
        r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
        r'\[[A-Z][A-Z _]{2,}\](?![(\[])',
        r'\{\{[^}\n]*\}\}',
        r'(?<![A-Za-z])x{3,}(?![A-Za-z])',
        r'\blorem\s+ipsum\b'], flags=re.I), decisive=True)
    add(64, 'chat reference markup', rx_fn([
        r'\bcite(?:turn|start|nav)\w*',
        r'\boai_citation\w*',
        r'contentReference',
        r'navlist',
        r'【\d+†[^】\n]*】'], flags=re.I), decisive=True)
    add(65, 'AI tracking parameter', fn_utm, decisive=True)
    add(66, 'mixed-script homoglyphs', fn_homoglyph, decisive=True)
    add(67, 'non-standard spaces', fn_nonstandard)
    add(68, 'trailing whitespace', fn_trailing, advice=True)
    add(69, 'canonical marketing phrase', rx_fn([
        r'\bunlocking\s+(?:your\s+|the\s+)?full\s+potential\b',
        r'\bnavigating\s+the\s+complexities\b',
        r'\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b',
        r'\bstaying\s+ahead\s+of\s+the\s+curve\b',
        r'\bturning\s+challenges\s+into\s+opportunities\b',
        r'\btaking\s+\w+\s+to\s+the\s+next\s+level\b',
        r'\bharnessing\s+the\s+power\s+of\b',
        r'\bpaving\s+the\s+way\s+for\b',
        r'\bsaying\s+goodbye\s+to\b',
        r'\bimagining\s+a\s+world\s+where\b']))
    add(70, 'decorative horizontal rules', fn_decorative_rules)
    add(71, 'degenerate repetition', fn_degenerate)
    return fams


def fn_utm(ctx):
    hosts = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
             'copilot.microsoft.com', 'poe.com'}
    count, samples = 0, []
    for m in re.finditer(r'utm_source=((?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,})', ctx.masked, re.I):
        if m.group(1).lower() in hosts:
            count += 1
            if len(samples) < 3:
                samples.append(snip(m.group(0)))
    return count, samples, None


class Fam:
    def __init__(self, key, label, fn, advice, decisive):
        self.key = key
        self.label = label
        self.fn = fn
        self.advice = advice
        self.decisive = decisive
        self.num = int(re.match(r'\d+', str(key)).group(0))
        self.slug = re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')
        self.rhythm = self.num in (40, 44)
        self.short = (1 <= self.num <= 39) or (47 <= self.num <= 51) or self.num == 69


FAM_LIST = build_families()
FAMS = {f.key: f for f in FAM_LIST}
RHYTHM_KEYS = frozenset(k for k, f in FAMS.items() if f.rhythm)


# ------------------------------------------------------------ scoring

def band_for(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


HOOK_PHRASE = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def confidence(words, n):
    if words < 40:
        return 'none', 'fewer than 40 words'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300:
        if n <= 1:
            return 'low', 'under 300 words with only one pattern family fired'
        return 'moderate', 'under 300 words'
    return 'high', ''


def compute_score(counts, words):
    """Return (score, confidence, reason) from per-family hit counts (FP-01 rules)."""
    moving = {k: c for k, c in counts.items() if c > 0 and not FAMS[k].advice}
    keys = set(moving)
    n = len(keys)
    raw = 0.0
    for k, c in moving.items():
        raw += W_FAM * min(1.0, 0.45 + 0.2 * (c - 1))
    score = int(min(100, round(raw)))
    dec = [k for k in keys if FAMS[k].decisive]
    conf, reason = confidence(words, n)
    if keys and keys <= RHYTHM_KEYS:
        score = min(score, 40)
    if keys and keys <= {40}:
        score = min(score, 20)
    if n == 1 and not (len(dec) == 1 and conf in ('moderate', 'high')):
        score = min(score, 40)
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf in ('moderate', 'high'):
        score = max(score, 45)
    if words < 120:
        short = sum(1 for k in keys if FAMS[k].short)
        if short >= 3:
            score = max(score, 45)
        elif short >= 2:
            score = max(score, 25)
    if words >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), conf, reason


def interval(ctx, results):
    n = len(ctx.sents)
    if n < 4:
        return None, 'too few sentences (%d) for an interval; four are needed' % n
    const = {}
    sparse = [dict() for _ in range(n)]
    for key, (count, _s, pos) in results.items():
        if pos is None:
            const[key] = count
        else:
            for p in pos:
                d = sparse[_sentence_index(ctx, p)]
                d[key] = d.get(key, 0) + 1
    rng = random.Random(20240601)
    scores = []
    for _ in range(K_RESAMPLE):
        counts = dict(const)
        words = 0
        for _i in range(n):
            i = rng.randrange(n)
            words += ctx.sent_words[i]
            for k, c in sparse[i].items():
                counts[k] = counts.get(k, 0) + c
        scores.append(compute_score(counts, words)[0])
    scores.sort()
    lo = scores[int(0.05 * (K_RESAMPLE - 1))]
    hi = scores[int(0.95 * (K_RESAMPLE - 1))]
    return [lo, hi], ('bootstrap over %d sentences, %d resamples, 5th to 95th percentile'
                      % (n, K_RESAMPLE))


def analyze(text, ci):
    window = text[:WINDOW]
    truncated = len(text) > WINDOW
    chars = scan_chars(window)
    masked = mask_markdown(window)
    ctx = build_ctx(masked, window, chars)
    results = {}
    for f in FAM_LIST:
        count, samples, pos = f.fn(ctx)
        if count > 0:
            results[f.key] = (count, samples, pos)
    counts = {k: v[0] for k, v in results.items()}
    score, conf, reason = compute_score(counts, ctx.words)
    report = {}
    for f in sorted(FAM_LIST, key=lambda f: (f.num, str(f.key))):
        if f.key not in results:
            continue
        count, samples, _pos = results[f.key]
        report['%d_%s' % (f.num, f.slug)] = {
            'label': f.label,
            'count': int(count),
            'samples': list(samples[:3]),
        }
    metrics = {
        'scanned_chars': len(window),
        'truncated': bool(truncated),
        'ai_tell_score': int(score),
        'ai_tell_band': band_for(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(results),
        'invisible_chars': len(chars.remove),
        'nonstandard_spaces': len(chars.zs),
        'homoglyphs': chars.homo_chars,
        'words': ctx.words,
        'sentences': len(ctx.sents),
    }
    if ci:
        ivl, note = interval(ctx, results)
        metrics['score_ci'] = ivl
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ------------------------------------------------------------ command line

def main(argv):
    clean = False
    ci = False
    operands = []
    end = False
    for a in argv:
        if end:
            operands.append(a)
            continue
        if a == '--':
            end = True
            continue
        if a in ('-h', '--help'):
            write_out(USAGE)
            return 0
        if a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            fail("unknown option '%s'; see --help" % a, 2)
        else:
            operands.append(a)
    path = None
    if operands:
        path = operands[0]
        if len(operands) > 1:
            sys.stderr.write('note: %d file operands given; only the first file was scanned: %s\n'
                             % (len(operands), path))
        try:
            with open(path, 'rb') as fh:
                data = fh.read()
        except OSError as e:
            fail('cannot read input: %s: %s' % (path, e.strerror or type(e).__name__), 1)
        ext = os.path.splitext(path)[1].lower()
    else:
        data = sys.stdin.buffer.read()
        ext = ''
    try:
        text = extract_text(data, ext)
    except ReadError as e:
        fail('cannot read input: %s: %s' % (path or '<stdin>', e), 1)
    text = text.replace('\r\n', '\n')
    if not text.strip():
        fail('empty input', 1)
    if clean:
        write_out(cleanup_text(text))
        return 0
    report = analyze(text, ci)
    write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except Exception as exc:  # never print a traceback
        fail('internal error: %s' % type(exc).__name__, 1)
    sys.exit(code)
