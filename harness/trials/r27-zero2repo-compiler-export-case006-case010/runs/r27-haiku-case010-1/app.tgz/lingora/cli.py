"""Command line (``lingora.cli``).

``cli.main(args=[...], standalone_mode=True)``.  The ``tokenize`` command reads
UTF-8 text from standard input and writes, for each input line, its recommended
word tokenizer tokens (with sentence splitting, so it needs the Punkt model for the
language) joined by the delimiter.

Exit status: 0 on success, 1 on a failed tokenization (no token line is written for
the failing input), 2 on a usage error.  Options beyond these are the
implementer's choice: ``--language``, ``--delimiter``, ``--encoding``.
"""

import argparse
import io
import sys

from .tokenize import word_tokenize

# spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000134 N-000135 N-000139

__all__ = ["cli", "Group"]

EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_USAGE = 2


class _ArgumentError(Exception):
    pass


class _TokenizeParser(argparse.ArgumentParser):
    def error(self, message):
        raise _ArgumentError(message)


# spec: N-000083 N-000414 N-000415
def _read_stdin(encoding):
    stream = sys.stdin
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        return buffer.read().decode(encoding)
    return stream.read()


# spec: N-000083 N-000084 N-000085 N-000134 N-000135 N-000139 N-000414 N-000415
# spec: N-000416 N-000417 N-000418 N-000419 N-000420
def _tokenize_command(options):
    text = _read_stdin(options.encoding)
    lines = text.splitlines()
    out = sys.stdout
    for line in lines:
        try:
            tokens = word_tokenize(line, language=options.language)
        except Exception as exc:  # any failure: report, write nothing for this line
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return EXIT_FAILURE
        out.write(options.delimiter.join(tokens) + "\n")
    out.flush()
    return EXIT_OK


# spec: N-000414 N-000417 N-000418 N-000419 N-000420 N-000139
class Group:
    """A command group: ``main(args=None, standalone_mode=True)``."""

    def __init__(self, commands):
        self._commands = commands

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        code = self._run(args)
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write("usage: lingora COMMAND [OPTIONS]\n\ncommands: %s\n" % ", ".join(sorted(self._commands)))
            return EXIT_OK
        name = args[0]
        if name not in self._commands:
            sys.stderr.write("lingora: unknown command %r\n" % name)
            return EXIT_USAGE
        parser = _TokenizeParser(prog="lingora " + name)
        parser.add_argument("--language", default="english")
        parser.add_argument("--delimiter", default=" ")
        parser.add_argument("--encoding", default="utf-8")
        try:
            options = parser.parse_args(args[1:])
        except _ArgumentError as exc:
            sys.stderr.write("lingora %s: %s\n" % (name, exc))
            return EXIT_USAGE
        except SystemExit as exc:
            return int(exc.code or 0)
        try:
            return self._commands[name](options)
        except (LookupError, OSError) as exc:
            sys.stderr.write("lingora %s: %s\n" % (name, exc))
            return EXIT_FAILURE


cli = Group({"tokenize": _tokenize_command})
