"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing and needs no model.  Submodules:
``tokenize``, ``stem``, ``tag``, ``chunk``, ``grammar``, ``parse``, ``tree``,
``classify``, ``metrics``, ``translate``, ``cli`` and the resource finder ``data``.
"""

# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007 N-000008
# spec: N-000009 N-000010 N-000011 N-000012 N-000013 N-000014 N-000015 N-000016
# spec: N-000017 N-000018 N-000019 N-000020 N-000021 N-000029 N-000047 N-000069
# spec: N-000070 N-000071
# spec: N-000371 N-000372 N-000373 N-000374 N-000375 N-000376 N-000377 N-000378
# spec: N-000379 N-000380 N-000381 N-000382 N-000383 N-000384 N-000023 N-000032
# spec: N-000034 N-000035 N-000036 N-000037 N-000038 N-000039 N-000040 N-000041
# spec: N-000042 N-000043 N-000044 N-000045 N-000046
__version__ = "0.1.0"

from . import data  # noqa: E402,F401  (resource finder; no I/O at import time)

__all__ = ["data", "__version__"]
