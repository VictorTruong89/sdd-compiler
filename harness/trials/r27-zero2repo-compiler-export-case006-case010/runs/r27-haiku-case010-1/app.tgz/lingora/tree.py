"""Constituent trees (``lingora.tree``), FP-05.

A :class:`Tree` is a list subclass: its items are its immediate children, each a
``str`` leaf or another :class:`Tree`.  Two trees are equal when their labels and
children are equal, recursively.
"""

import re

# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488 N-000489 N-000490 N-000491
# spec: N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289 N-000290 N-000291

# spec: N-000040 N-000041 N-000042 N-000043
__all__ = ["Tree"]

# spec: N-000489
_BRACKET_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000281 N-000282 N-000283
# spec: N-000284 N-000287
class Tree(list):
    """A labelled tree. ``Tree(label, children)``; ``children`` must be a list."""

    # spec: N-000486 N-000487 N-000488 N-000288 N-000289 N-000290 N-000291
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError(
                "Tree children must be a list of children, not %s" % type(children).__name__
            )
        super().__init__(children)
        self._label = label

    def label(self):
        return self._label

    # spec: N-000282 N-000283
    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    # spec: N-000285 N-000286
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    # spec: N-000287 N-000490 N-000491
    def pformat(self, indent=0):
        pad = "  " * indent
        if all(not isinstance(child, Tree) for child in self):
            inner = " ".join(str(child) for child in self)
            return "%s(%s%s%s)" % (pad, self._label, " " if self else "", inner)
        lines = ["%s(%s" % (pad, self._label)]
        for child in self:
            if isinstance(child, Tree):
                lines.append(child.pformat(indent + 1))
            else:
                lines.append("%s  %s" % (pad, child))
        lines[-1] += ")"
        return "\n".join(lines)

    @classmethod
    # spec: N-000286 N-000489
    def fromstring(cls, s):
        """Build a tree from bracketed text ``(label child ...)``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be str")
        tokens = _BRACKET_TOKEN_RE.findall(s)
        position = [0]

        def parse_node():
            if position[0] >= len(tokens) or tokens[position[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            position[0] += 1
            if position[0] >= len(tokens) or tokens[position[0]] in "()":
                raise ValueError("missing label in bracketed tree text")
            label = tokens[position[0]]
            position[0] += 1
            children = []
            while position[0] < len(tokens) and tokens[position[0]] != ")":
                if tokens[position[0]] == "(":
                    children.append(parse_node())
                else:
                    children.append(tokens[position[0]])
                    position[0] += 1
            if position[0] >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            position[0] += 1
            return cls(label, children)

        tree = parse_node()
        if position[0] != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree
