"""Classifiers (``lingora.classify``), FP-06.

``NaiveBayesClassifier`` learns label priors and smoothed per-feature value
probabilities (additive 0.5 smoothing).  ``DecisionTreeClassifier`` grows a full
tree on feature tests, choosing at each node the feature whose per-value majority
labels classify the examples reaching that node best.
"""

import math
from collections import Counter, defaultdict

# spec: N-000492 N-000493 N-000494 N-000495 N-000496 N-000497
# spec: N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303
# spec: N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000310 N-000311 N-000312
# spec: N-000313 N-000314 N-000315 N-000316 N-000317

# spec: N-000044 N-000045
__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_SMOOTHING = 0.5


# spec: N-000494 N-000495
def _check_labeled(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes, dict)):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    items = list(labeled_featuresets)
    for pair in items:
        if not (isinstance(pair, tuple) and len(pair) == 2):
            raise TypeError("each item must be a (featureset, label) pair")
        if not isinstance(pair[0], dict):
            raise TypeError("a featureset must be a dict")
        hash(pair[1])
    return items


# spec: N-000496 N-000497
class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


# spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
# spec: N-000492 N-000493 N-000494 N-000495
class NaiveBayesClassifier:
    """Naive Bayes over featuresets (dict of feature name to value)."""

    def __init__(self, label_counts, feature_counts, feature_values, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts
        self._feature_values = feature_values
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        items = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        feature_counts = defaultdict(Counter)  # (label, fname) -> Counter(value)
        feature_values = defaultdict(set)
        for featureset, label in items:
            label_counts[label] += 1
            for fname, fval in featureset.items():
                feature_counts[(label, fname)][fval] += 1
                feature_values[fname].add(fval)
        return cls(label_counts, feature_counts, feature_values, len(items))

    def labels(self):
        return list(self._label_counts)

    # spec: N-000315 N-000316 N-000317 N-000304 N-000305
    def _log_scores(self, featureset):
        labels = list(self._label_counts)
        scores = {}
        for label in labels:
            prior = (self._label_counts[label] + _SMOOTHING) / (
                self._total + _SMOOTHING * len(labels)
            )
            score = math.log(prior)
            for fname, fval in featureset.items():
                if fname not in self._feature_values:
                    continue
                counts = self._feature_counts.get((label, fname), Counter())
                n = sum(counts.values())
                bins = len(self._feature_values[fname]) + 1
                p = (counts.get(fval, 0) + _SMOOTHING) / (n + _SMOOTHING * bins)
                score += math.log(p)
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(score - top) for label, score in scores.items()}
        norm = sum(exps.values())
        return ProbDist({label: value / norm for label, value in exps.items()})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        return max(scores, key=lambda label: (scores[label], str(label)))


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for label in labels:  # first-seen tie break, deterministic
        if counts[label] == best:
            return label


class _Node:
    __slots__ = ("feature", "children", "default", "label")

    def __init__(self, label=None, feature=None, children=None, default=None):
        self.label = label
        self.feature = feature
        self.children = children or {}
        self.default = default


# spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
class DecisionTreeClassifier:
    """Decision tree over featuresets; a missing feature is its own branch value (None)."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        items = _check_labeled(labeled_featuresets)
        if not items:
            raise ValueError("cannot train a decision tree on no examples")
        features = sorted({fname for fs, _ in items for fname in fs})
        return cls(cls._grow(items, features))

    @classmethod
    def _grow(cls, examples, features):
        labels = [label for _, label in examples]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Node(label=majority)
        best_feature = None
        best_score = -1
        for fname in features:
            by_value = defaultdict(list)
            for fs, label in examples:
                by_value[fs.get(fname)].append(label)
            if len(by_value) < 2:
                continue
            correct = sum(Counter(group).most_common(1)[0][1] for group in by_value.values())
            if correct > best_score:
                best_score = correct
                best_feature = fname
        if best_feature is None:
            return _Node(label=majority)
        remaining = [f for f in features if f != best_feature]
        groups = defaultdict(list)
        for fs, label in examples:
            groups[fs.get(best_feature)].append((fs, label))
        children = {
            value: cls._grow(group, remaining) for value, group in groups.items()
        }
        return _Node(feature=best_feature, children=children, default=majority)

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


# spec: N-000296 N-000297
def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs classified with their label."""
    pairs = _check_labeled(gold)
    if not pairs:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for featureset, label in pairs if classifier.classify(featureset) == label)
    return correct / len(pairs)
