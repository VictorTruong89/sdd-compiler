"""Tokenizers (``lingora.tokenize``).

Implements FP-01 (word, punctuation and sentence tokenization).

Decisions taken where the specification disagrees with itself (see NOTES.md):

* A straight double quote at the very start of the text is an opening quote
  (``) for the Penn Treebank tokenizer and a closing quote ('') for the
  recommended word tokenizer (the PRD's stated improvement).
* ``cannot`` is split by the Penn Treebank tokenizer and kept whole by the
  recommended tokenizer.
* ``RegexpTokenizer`` and the sentence-splitting empty-discard default to
  "discard empty pieces" (PRD behaviour; the interface's "off unless True"
  is overridden).
* The tweet tokenizer keeps emoticons un-lowercased.
"""

import re

from . import data as _data

# spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412 N-000413

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
    "PunktSentenceTokenizer",
]


# spec: N-000403 N-000404 N-000411
def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be str, not %s" % (name, type(text).__name__))


# spec: N-000409 N-000410
def _check_bool(value, name):
    if not isinstance(value, bool):
        raise TypeError("%s must be bool, not %s" % (name, type(value).__name__))


# ---------------------------------------------------------------------------
# Word/punctuation tokenizer
# ---------------------------------------------------------------------------

# spec: N-000089 N-000090 N-000091 N-000126 N-000127 N-000128 N-000136
# spec: N-000081 N-000082 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091
# spec: N-000136
_WORD_PUNCT_RE = re.compile(r"\w+|[^\w\s]+")


# spec: N-000022 N-000031 N-000089 N-000090 N-000091 N-000126 N-000127 N-000128
# spec: N-000136
class WordPunctTokenizer:
    """Split on the boundary between word and non-word characters."""

    def tokenize(self, text):
        _check_text(text)
        return _WORD_PUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _WORD_PUNCT_RE.finditer(text):
            yield (match.start(), match.end())


# spec: N-000030
def wordpunct_tokenize(text):
    """Word/punctuation tokenizer; needs no model."""
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Penn Treebank style word tokenization
# ---------------------------------------------------------------------------

_TYPOGRAPHIC_QUOTES_RE = re.compile("([\u201c\u201d\u201e\u00ab\u00bb\u2018\u2019])")
_FUSED_CONTRACTIONS = [
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
    re.compile(r"(?i) ('t)(is)\b"),
    re.compile(r"(?i) ('t)(was)\b"),
]
_CANNOT_RE = re.compile(r"(?i)\b(can)(not)\b")


def _treebank_tokenize(text, improved):
    """Shared Penn Treebank conventions; ``improved`` selects the recommended variant."""
    if improved:
        text = _TYPOGRAPHIC_QUOTES_RE.sub(r" \1 ", text)
        # A straight double quote at the very start is the closing-quote token.
        text = re.sub(r'^"', " '' ", text)
    else:
        text = re.sub(r'^"', " `` ", text)
    # After a space or an opening bracket a straight double quote opens.
    text = re.sub(r'([ \(\[\{<])"', r"\1 `` ", text)
    # Final point, optionally followed by closing quotes or brackets.
    text = re.sub(
        r'(^|[^.])\.([\]\)\}>"\']*)\s*$',
        lambda m: m.group(1) + " . " + m.group(2) + " ",
        text,
    )
    text = text.replace('"', " '' ")
    text = text.replace("''", " '' ")
    if improved:
        text = re.sub(r"\.{2,}", lambda m: " " + m.group(0) + " ", text)
    else:
        text = re.sub(r"\.\.\.", " ... ", text)
    text = re.sub(r"[;@#$%&?!]", lambda m: " " + m.group(0) + " ", text)
    text = re.sub(r"[\]\[\(\)\{\}<>]", lambda m: " " + m.group(0) + " ", text)
    text = re.sub(r"([:,])(?!\d)", r" \1 ", text)
    if improved:
        text = text.replace("--", " -- ")
        text = re.sub("[\u2012-\u2015*]", lambda m: " " + m.group(0) + " ", text)
    text = " " + text + " "
    # Clitics and bare apostrophes that end a word.
    text = re.sub(r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 ", text)
    text = re.sub(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 ", text)
    if not improved:
        text = _CANNOT_RE.sub(r" \1 \2 ", text)
    for regexp in _FUSED_CONTRACTIONS:
        text = regexp.sub(r" \1 \2 ", text)
    return text.split()


# spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099
# spec: N-000100 N-000101 N-000102 N-000103
class TreebankWordTokenizer:
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):
        _check_text(text)
        return _treebank_tokenize(text, improved=False)


# spec: N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111
# spec: N-000112
class _RecommendedWordTokenizer:
    """LINGORA's recommended word tokenizer, applied to one delimited line."""

    def tokenize(self, text):
        _check_text(text)
        return _treebank_tokenize(text, improved=True)


# ---------------------------------------------------------------------------
# Whitespace, blank-line and regular-expression tokenizers
# ---------------------------------------------------------------------------


# spec: N-000086 N-000087 N-000113 N-000136 N-000126
class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters."""

    _RE = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        for match in self._RE.finditer(text):
            yield (match.start(), match.end())


_BLANKLINE_SPLIT_RE = re.compile(r"\s*\n\s*\n\s*")


# spec: N-000114 N-000115
def blankline_tokenize(text):
    """Split into segments separated by blank lines; empty pieces are dropped."""
    _check_text(text)
    pieces = (piece.strip() for piece in _BLANKLINE_SPLIT_RE.split(text))
    return [piece for piece in pieces if piece]


# spec: N-000116 N-000117 N-000118 N-000405 N-000406 N-000407 N-000033
class RegexpTokenizer:
    """Tokenize by a caller-supplied regular expression.

    ``gaps=False`` (default): tokens are the matches of ``pattern``.
    ``gaps=True``: the pattern matches separators and tokens are the gaps.
    ``discard_empty`` (default True) drops empty pieces.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be str")
        _check_bool(gaps, "gaps")
        _check_bool(discard_empty, "discard_empty")
        self._pattern = pattern
        self._regexp = re.compile(pattern)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def _pieces(self, text):
        if not self._gaps:
            return [m.group(0) for m in self._regexp.finditer(text)]
        pieces = []
        position = 0
        for match in self._regexp.finditer(text):
            pieces.append(text[position:match.start()])
            position = match.end()
        pieces.append(text[position:])
        return pieces

    def tokenize(self, text):
        _check_text(text)
        pieces = self._pieces(text)
        if self._discard_empty:
            pieces = [piece for piece in pieces if piece]
        return pieces

    def span_tokenize(self, text):
        _check_text(text)
        if not self._gaps:
            for match in self._regexp.finditer(text):
                if match.end() > match.start() or not self._discard_empty:
                    yield (match.start(), match.end())
            return
        position = 0
        for match in self._regexp.finditer(text):
            if match.start() > position or not self._discard_empty:
                yield (position, match.start())
            position = match.end()
        if position < len(text) or not self._discard_empty:
            yield (position, len(text))


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON_RE = re.compile(r"[:;=8][\-o]?[)(\]\[dDpP/\\*3]|<3|\^_\^", re.IGNORECASE)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_TWEET_TOKEN_RE = re.compile(
    "|".join(
        [
            r"(?:[:;=8][\-o]?[)(\]\[dDpP/\\*3]|<3|\^_\^)",  # emoticons
            r"https?://\S+|www\.\S+",  # URLs
            r"(?<!\w)@[A-Za-z0-9_]{1,15}",  # @-handles
            r"#\w+",  # hashtags
            r"\w+(?:['\-_]\w+)*",  # words, with internal apostrophes or dashes
            r"\.{2,}",  # ellipses
            r"\S",  # any other single non-space character
        ]
    ),
    re.IGNORECASE,
)
_REDUCE_LEN_RE = re.compile(r"(.)\1{2,}")


# spec: N-000065 N-000066 N-000067 N-000119 N-000120 N-000121 N-000122 N-000123
# spec: N-000124 N-000125
class TweetTokenizer:
    """Tokenizer for short informal text (emoticons, URLs, hashtags, handles)."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        _check_bool(preserve_case, "preserve_case")
        _check_bool(reduce_len, "reduce_len")
        _check_bool(strip_handles, "strip_handles")
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE_LEN_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_TOKEN_RE.findall(text)
        if not self._preserve_case:
            tokens = [
                tok if _EMOTICON_RE.fullmatch(tok) else tok.lower() for tok in tokens
            ]
        return tokens


# ---------------------------------------------------------------------------
# Punkt sentence tokenizer
# ---------------------------------------------------------------------------

_ORTHO_UC_START = 2
_ORTHO_UC_MID = 4
_ORTHO_UC_UNK = 8
_ORTHO_LC_START = 16
_ORTHO_LC_MID = 32
_ORTHO_LC_UNK = 64
_ORTHO_LC_ANY = _ORTHO_LC_START | _ORTHO_LC_MID | _ORTHO_LC_UNK

_NUMBER_RE = re.compile(r"^-?[.,]?\d[\d,.\-]*\.?$")
_OPEN_CLOSE_CHARS = "\"'()[]{}<>“”‘’«»"


class _PunktParams:
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


def _load_params(model_dir):
    import os

    def read(name):
        full = os.path.join(model_dir, name)
        if not os.path.exists(full):
            return []
        return [line for line in _data.read_lines(full) if line.strip()]

    abbrev = {line.strip().lower() for line in read("abbrev_types.txt")}
    starters = {line.strip().lower() for line in read("sent_starters.txt")}
    collocations = set()
    for line in read("collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0].strip().lower(), parts[1].strip().lower()))
    ortho = {}
    for line in read("ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            try:
                ortho[parts[0].strip().lower()] = int(parts[1])
            except ValueError:
                continue
    return _PunktParams(abbrev, collocations, starters, ortho)


class _Token:
    __slots__ = (
        "start",
        "end",
        "core",
        "type",
        "type_no_period",
        "period_final",
        "ellipsis",
        "is_initial",
        "first_upper",
        "sentbreak",
        "abbr",
    )

    def __init__(self, start, end, raw):
        self.start = start
        self.end = end
        core = raw.strip(_OPEN_CLOSE_CHARS)
        self.core = core
        self.period_final = core.endswith(".")
        self.ellipsis = bool(re.search(r"\.\.+$", core))
        lowered = core.lower()
        if _NUMBER_RE.match(lowered):
            typ = "##number##"
        else:
            typ = lowered
        self.type = typ
        self.type_no_period = typ[:-1] if self.period_final else typ
        self.is_initial = bool(re.fullmatch(r"[^\W\d_]", self.type_no_period))
        self.first_upper = bool(core) and core[0].isupper()
        self.sentbreak = False
        self.abbr = False


# spec: N-000028 N-000129 N-000130 N-000131 N-000132 N-000133
class PunktSentenceTokenizer:
    """Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

    Built from a packaged model directory with ``abbrev_types.txt``,
    ``sent_starters.txt``, ``collocations.tab`` and ``ortho_context.tab``.
    """

    def __init__(self, params):
        self._params = params

    @classmethod
    def from_directory(cls, model_dir):
        return cls(_load_params(model_dir))

    def _ortho_heuristic(self, tok):
        """Return True (sentence starter), False (not), or "unknown"."""
        ctx = self._params.ortho_context.get(tok.type_no_period, 0)
        if tok.first_upper:
            if ctx & _ORTHO_UC_MID and not (ctx & _ORTHO_LC_ANY):
                return False
            if ctx & _ORTHO_LC_ANY and not (ctx & _ORTHO_UC_MID):
                return True
            return "unknown"
        if tok.core[:1].islower():
            return False
        return "unknown"

    def _tokens(self, text):
        tokens = []
        for match in re.finditer(r"\S+", text):
            tokens.append(_Token(match.start(), match.end(), match.group(0)))
        return tokens

    def _first_pass(self, tok):
        core = tok.core
        if core.rstrip(_OPEN_CLOSE_CHARS).endswith(("?", "!")):
            tok.sentbreak = True
        elif tok.period_final and not core.endswith(".."):
            stem = tok.type_no_period
            if stem in self._params.abbrev_types or stem.split("-")[-1] in self._params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _second_pass(self, tok1, tok2):
        if tok2 is None or not (tok1.period_final or tok1.ellipsis):
            return
        typ = tok1.type_no_period
        next_typ = tok2.type_no_period
        tok_is_initial = tok1.is_initial
        if (typ, next_typ) in self._params.collocations:
            tok1.sentbreak = False
            tok1.abbr = True
            return
        if (tok1.abbr or tok1.ellipsis) and not tok_is_initial:
            starter = self._ortho_heuristic(tok2)
            if starter is True:
                tok1.sentbreak = True
                return
            if tok2.first_upper and next_typ in self._params.sent_starters:
                tok1.sentbreak = True
                return
        if tok_is_initial or typ == "##number##":
            starter = self._ortho_heuristic(tok2)
            if starter is False:
                tok1.sentbreak = False
                tok1.abbr = True
                return
            if (
                starter == "unknown"
                and tok_is_initial
                and tok2.first_upper
                and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC_ANY)
            ):
                tok1.sentbreak = False
                tok1.abbr = True

    def span_tokenize(self, text):
        """Yield ``(start, end)`` offsets of each sentence."""
        _check_text(text)
        tokens = self._tokens(text)
        for tok in tokens:
            self._first_pass(tok)
        for index, tok in enumerate(tokens):
            nxt = tokens[index + 1] if index + 1 < len(tokens) else None
            self._second_pass(tok, nxt)
        if not tokens:
            return
        first = 0
        for index, tok in enumerate(tokens):
            if tok.sentbreak:
                yield (tokens[first].start, tok.end)
                first = index + 1
        if first < len(tokens):
            yield (tokens[first].start, tokens[-1].end)

    def tokenize(self, text):
        _check_text(text)
        return [text[start:end] for start, end in self.span_tokenize(text)]


# spec: N-000137 N-000138 N-000408 N-000413
def _punkt_for(language):
    if not isinstance(language, str) or not language:
        raise TypeError("language must be a non-empty str")
    model_dir = _data.find_dir("tokenizers/punkt_tab/%s" % language)
    return PunktSentenceTokenizer.from_directory(model_dir)


# spec: N-000129 N-000133 N-000408 N-000413 N-000137 N-000138
def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``."""
    _check_text(text)
    return _punkt_for(language).tokenize(text)


# spec: N-000086 N-000087 N-000088 N-000109 N-000110 N-000111 N-000112 N-000409
# spec: N-000410 N-000411
# spec: N-000032
def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    With ``preserve_line=False`` the text is first split into sentences (this needs
    the Punkt model for ``language``); with ``preserve_line=True`` it is treated as
    one already-delimited line.
    """
    _check_text(text)
    _check_bool(preserve_line, "preserve_line")
    tokenizer = _RecommendedWordTokenizer()
    if preserve_line:
        return tokenizer.tokenize(text)
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(tokenizer.tokenize(sentence))
    return tokens
