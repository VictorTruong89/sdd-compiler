"""Context-free grammars (``lingora.grammar``), FP-05.

Grammar text: one production per line, ``LHS -> RHS``.  ``|`` separates
alternatives; an unquoted identifier is a nonterminal, a single- or double-quoted
text is a terminal.  The start symbol is the left-hand side of the first production.
"""

import re

# spec: N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470 N-000471
# spec: N-000264 N-000265

__all__ = ["CFG", "Nonterminal", "Production"]


# spec: N-000466 N-000467 N-000468
class Nonterminal:
    """A grammar nonterminal. ``str(symbol)`` is its name; it is not a ``str``."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __hash__(self):
        return hash(("Nonterminal", self._name))


# spec: N-000469 N-000470 N-000471
class Production:
    """``lhs -> rhs``; ``rhs()`` is a tuple of ``Nonterminal`` or terminal ``str``."""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            str(sym) if isinstance(sym, Nonterminal) else repr(sym) for sym in self._rhs
        ) or "")


_IDENT_RE = re.compile(r"[A-Za-z_][\w\-]*")
_TOKEN_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|([A-Za-z_][\w\-]*)|(\|))""")


# spec: N-000464 N-000465
def _parse_rhs(text):
    """Return a list of alternatives, each a list of symbols."""
    alternatives = [[]]
    position = 0
    text = text.strip()
    while position < len(text):
        match = _TOKEN_RE.match(text, position)
        if not match or match.end() == position:
            if text[position:].strip() == "":
                break
            raise ValueError("cannot parse grammar text near %r" % text[position:position + 20])
        position = match.end()
        dq, sq, ident, bar = match.groups()
        if bar:
            alternatives.append([])
        elif dq is not None:
            alternatives[-1].append(dq)
        elif sq is not None:
            alternatives[-1].append(sq)
        else:
            alternatives[-1].append(Nonterminal(ident))
    return alternatives


# spec: N-000461 N-000462 N-000463 N-000465 N-000464
class CFG:
    """A context-free grammar built from productions."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be str")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production without '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT_RE.fullmatch(lhs_text):
                raise ValueError("invalid left-hand side %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alternative in _parse_rhs(rhs_text):
                productions.append(Production(lhs, alternative))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    # spec: N-000471
    def productions(self, lhs=None, rhs_first=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def nonterminals(self):
        return {p.lhs() for p in self._productions}

    def terminals(self):
        out = set()
        for production in self._productions:
            for symbol in production.rhs():
                if isinstance(symbol, str):
                    out.add(symbol)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
