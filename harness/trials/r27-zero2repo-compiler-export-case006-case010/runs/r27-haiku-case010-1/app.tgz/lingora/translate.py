"""Translation-quality scoring (``lingora.translate``): sentence-level BLEU (FP-07)."""

import math
from collections import Counter

# spec: N-000498 N-000499 N-000500 N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
# spec: N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342

__all__ = ["bleu"]

DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


# spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000335
# spec: N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342
def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` against ``references`` (lists of token lists).

    ``weights`` gives one weight per n-gram order from unigrams; the default is equal
    weights on unigrams through 4-grams.  The score is 0 when a weighted order has no
    match, unless ``smoothing_function(matches, totals)`` is given; it returns the
    smoothed precision for each order.
    """
    if weights is None:
        weights = DEFAULT_WEIGHTS
    weights = list(weights)
    if not weights:
        raise ValueError("weights must not be empty")
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")
    if not isinstance(references, list) or not isinstance(hypothesis, list):
        raise TypeError("references must be a list of token lists; hypothesis a token list")
    references = [list(ref) for ref in references]
    hypothesis = list(hypothesis)
    if not references:
        raise ValueError("at least one reference is required")
    if not hypothesis:
        return 0.0

    matches = []
    totals = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                max_ref[gram] = max(max_ref[gram], count)
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        matches.append(clipped)
        totals.append(total)

    if smoothing_function is not None:
        precisions = list(smoothing_function(matches, totals))
    else:
        precisions = []
        for clipped, total in zip(matches, totals):
            if total == 0 or clipped == 0:
                return 0.0
            precisions.append(clipped / total)

    log_avg = 0.0
    for w, p in zip(weights, precisions):
        if p <= 0:
            return 0.0
        log_avg += w * math.log(p)

    hyp_len = len(hypothesis)
    ref_lens = [len(ref) for ref in references]
    closest = min(ref_lens, key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > closest:
        brevity = 1.0
    else:
        brevity = math.exp(1 - closest / hyp_len)
    return brevity * math.exp(log_avg)
