"""Evaluation metrics (``lingora.metrics``), FP-07."""

# spec: N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329
# spec: N-000330 N-000331 N-000332 N-000333 N-000334 N-000343 N-000344 N-000345 N-000346 N-000347 N-000348
# spec: N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507
# spec: N-000508 N-000509 N-000510

# spec: N-000046
__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


# spec: N-000318 N-000330 N-000331 N-000343 N-000501 N-000502
def accuracy(reference, test):
    """Fraction of equal positions. Lists of different lengths raise ``ValueError``."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy needs non-empty lists")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


# spec: N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325 N-000326
# spec: N-000327 N-000328 N-000329 N-000348 N-000503 N-000504 N-000505 N-000506
def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance, optionally with adjacent transpositions.

    With ``transpositions=True`` two adjacent characters may be swapped at cost 1
    and nothing may be inserted or deleted between them (optimal string alignment;
    the interface's rule, see NOTES.md).
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("s1 and s2 must be str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be bool")
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s1[i - 1] == s2[j - 1]:
                cost = 0
            else:
                cost = substitution_cost
            best = min(
                d[i - 1][j] + 1,
                d[i][j - 1] + 1,
                d[i - 1][j - 1] + cost,
            )
            if (
                transpositions
                and i > 1
                and j > 1
                and s1[i - 1] == s2[j - 2]
                and s1[i - 2] == s2[j - 1]
            ):
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


# spec: N-000507
def jaccard_distance(label1, label2):
    """|symmetric difference| / |union| of two sets (0 when both are empty)."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("label1 and label2 must be sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


# spec: N-000508 N-000509
def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets or frozensets")


# spec: N-000332 N-000344 N-000345 N-000346 N-000347 N-000510
def precision(reference, test):
    """|reference & test| / |test|; ``None`` when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


# spec: N-000332 N-000344 N-000345
def recall(reference, test):
    """|reference & test| / |reference|; ``None`` when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


# spec: N-000333 N-000334 N-000346 N-000347 N-000510
def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; ``None`` when no number results."""
    _check_sets(reference, test)
    if isinstance(alpha, bool) or not isinstance(alpha, (int, float)):
        raise TypeError("alpha must be a number")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return None if not (reference & test) else 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
