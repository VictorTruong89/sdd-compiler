"""Packaged-resource finder (``lingora.data``).

# spec: N-000385 N-000386 N-000387 N-000388 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402

``path`` is a mutable list of directories searched for packaged resources.
Its initial contents come from the ``LINGORA_DATA`` environment variable
(``os.pathsep`` separated); it is empty when that variable is unset.  Importing
the package never downloads anything.
"""

import os

# spec: N-000385 N-000386 N-000387 N-000388 N-000397 N-000398 N-000399 N-000400
# spec: N-000401 N-000402
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


# spec: N-000057 N-000058 N-000063 N-000064
# spec: N-000389 N-000390 N-000391 N-000392 N-000393 N-000394 N-000395 N-000396
def find(resource):
    """Return the absolute path of ``resource`` in the first ``path`` entry holding it.

    Raises ``LookupError`` when no listed directory contains the resource.
    """
    for directory in list(path):
        if not isinstance(directory, str):
            continue
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "packaged resource %r is not visible in lingora.data.path" % (resource,)
    )


# spec: N-000059 N-000060 N-000061 N-000062
def find_dir(resource):
    """Like :func:`find`, but the resource must be a directory."""
    for directory in list(path):
        if not isinstance(directory, str):
            continue
        candidate = os.path.join(directory, resource)
        if os.path.isdir(candidate):
            return candidate
    raise LookupError(
        "packaged resource directory %r is not visible in lingora.data.path"
        % (resource,)
    )


# spec: N-000398 N-000399 N-000400
def read_lines(filename):
    """Read a UTF-8 text file; each line without its terminator is one entry."""
    with open(filename, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]
