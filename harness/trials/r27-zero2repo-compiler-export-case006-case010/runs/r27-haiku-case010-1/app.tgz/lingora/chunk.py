"""Chunking (``lingora.chunk``), FP-04.

A chunk grammar is text with clauses ``LABEL: pattern``; patterns in braces are
chunk rules (``{<DT>?<NN>*}``), patterns written ``}...{`` are chink rules.
Clauses and rules apply in written order.  A later clause sees an earlier chunk as
one unit whose tag is the chunk's label.

Decision (see NOTES.md): touching matches of one rule stay separate chunks; the
joining sentence of FP-04 is not applied.
"""

import re

from . import data as _data
from .tree import Tree

# spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453 N-000454 N-000455
# spec: N-000456 N-000457 N-000458 N-000459 N-000460
# spec: N-000228 N-000229 N-000230 N-000232 N-000233 N-000234 N-000235 N-000236 N-000237 N-000238
# spec: N-000239 N-000240 N-000241 N-000242 N-000243 N-000244 N-000245 N-000246 N-000247 N-000248
# spec: N-000249 N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256 N-000257 N-000231

# spec: N-000037 N-000038 N-000039
__all__ = ["ChinRule", "ChunkRule", "RegexpParser", "ne_chunk"]

# spec: N-000228 N-000229 N-000230 N-000456 N-000457
DEFAULT_SENTENCE_LABEL = "SENT"

_TAG_ELEMENT_RE = re.compile(r"<([^>]*)>(\?|\*|\+|\{\d*,?\d*\})?")
_ELEMENT_BODY = r"(?:<[^>]*>(?:\?|\*|\+|\{\d*,?\d*\})?|\s)*"
_RULE_RE = re.compile(r"\{(%s)\}|\}(%s)\{" % (_ELEMENT_BODY, _ELEMENT_BODY))
# spec: N-000453 N-000454
_CLAUSE_RE = re.compile(r"^([A-Za-z_][\w.\-]*)\s*:\s*(.*)$")


# spec: N-000027 N-000232 N-000233 N-000234 N-000235
def _compile_tag_pattern(pattern):
    """Compile a tag pattern to a regular expression over encoded items."""
    compact = re.sub(r"\s+", "", pattern)
    if not compact:
        raise ValueError("empty tag pattern")
    pieces = []
    position = 0
    while position < len(compact):
        match = _TAG_ELEMENT_RE.match(compact, position)
        if not match or match.end() == position:
            raise ValueError("invalid tag pattern near %r" % compact[position:position + 10])
        position = match.end()
        content, quant = match.group(1), match.group(2) or ""
        content = re.sub(r"(?<!\\)\.", r"[^\\x00\\x01]", content)
        element = "\x00(?:%s)\x01" % content
        if quant:
            element = "(?:%s)%s" % (element, quant)
        pieces.append(element)
    return re.compile("".join(pieces))


class _Stage:
    kind = None

    def __init__(self, label, pattern):
        if not isinstance(label, str) or not label:
            raise TypeError("chunk label must be a non-empty str")
        if not isinstance(pattern, str):
            raise TypeError("tag pattern must be str")
        self.label = label
        self.pattern = pattern
        self._regexp = _compile_tag_pattern(pattern)

    def __repr__(self):
        return "%s(%r, %r)" % (type(self).__name__, self.label, self.pattern)


# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242
class ChunkRule(_Stage):
    """Chunk every match of the tag pattern among the current units."""


# spec: N-000243 N-000244 N-000245
class ChinRule(_Stage):
    """Remove matching units from chunks of the same clause label."""


def _tag_of(item):
    if isinstance(item, Tree):
        return item.label()
    tag = item[1]
    return "" if tag is None else str(tag)


def _encode(items):
    """Return the encoded string and the start/end offset of each item."""
    parts = []
    starts = []
    ends = []
    position = 0
    for item in items:
        encoded = "\x00%s\x01" % _tag_of(item)
        starts.append(position)
        position += len(encoded)
        ends.append(position)
        parts.append(encoded)
    return "".join(parts), starts, ends


def _find_matches(regexp, items):
    """Non-empty, non-overlapping leftmost matches as ``(first, last_exclusive)`` item ranges."""
    encoded, starts, ends = _encode(items)
    start_index = {pos: idx for idx, pos in enumerate(starts)}
    end_index = {pos: idx + 1 for idx, pos in enumerate(ends)}
    out = []
    for match in regexp.finditer(encoded):
        if match.end() == match.start():
            continue
        first = start_index.get(match.start())
        last = end_index.get(match.end())
        if first is None or last is None:
            continue
        out.append((first, last))
    return out


# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242
def _apply_chunk_rule(rule, items):
    matches = _find_matches(rule._regexp, items)
    out = []
    cursor = 0
    for first, last in matches:
        out.extend(items[cursor:first])
        out.append(Tree(rule.label, list(items[first:last])))
        cursor = last
    out.extend(items[cursor:])
    return out


# spec: N-000243 N-000244 N-000245
def _apply_chink_rule(rule, items):
    out = []
    for item in items:
        if not (isinstance(item, Tree) and item.label() == rule.label):
            out.append(item)
            continue
        children = list(item)
        matched = set()
        for first, last in _find_matches(rule._regexp, children):
            matched.update(range(first, last))
        segment = []
        for index, child in enumerate(children):
            if index in matched:
                if segment:
                    out.append(Tree(rule.label, segment))
                    segment = []
                out.append(child)
            else:
                segment.append(child)
        if segment:
            out.append(Tree(rule.label, segment))
    return out


# spec: N-000025 N-000026 N-000453 N-000454
def _parse_grammar_text(text):
    stages = []
    clause_label = None
    for raw in text.splitlines():
        if "#" in raw:
            raw = raw[: raw.index("#")]
        if not raw.strip():
            continue
        if raw[0].isspace():
            if clause_label is None:
                raise ValueError("pattern line before any clause: %r" % raw)
            pattern_text = raw.strip()
        else:
            match = _CLAUSE_RE.match(raw.strip())
            if not match:
                raise ValueError("invalid chunk grammar clause: %r" % raw)
            clause_label = match.group(1)
            pattern_text = match.group(2).strip()
        position = 0
        for rule in _RULE_RE.finditer(pattern_text):
            leftover = pattern_text[position:rule.start()].strip()
            if leftover:
                raise ValueError("unexpected text in chunk grammar: %r" % leftover)
            position = rule.end()
            if rule.group(1) is not None:
                stages.append(ChunkRule(clause_label, rule.group(1)))
            else:
                stages.append(ChinRule(clause_label, rule.group(2)))
        if pattern_text[position:].strip():
            raise ValueError("unexpected text in chunk grammar: %r" % pattern_text[position:])
    return stages


# spec: N-000448
def _check_tagged(tagged):
    if isinstance(tagged, str):
        raise TypeError("tagged tokens must be a list of (token, tag) pairs, not a str")
    items = list(tagged)
    for item in items:
        if not (isinstance(item, tuple) and len(item) == 2):
            raise TypeError("each item must be a (token, tag) pair")
    return items


# spec: N-000246 N-000247 N-000248 N-000249 N-000448 N-000449 N-000450 N-000451
# spec: N-000455 N-000456 N-000457 N-000458 N-000459 N-000460
class RegexpParser:
    """Chunk parser built from a chunk grammar (text, or a list of stage objects)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._stages = _parse_grammar_text(grammar)
        elif isinstance(grammar, list):
            for stage in grammar:
                if not isinstance(stage, (ChunkRule, ChinRule)):
                    raise TypeError("list grammars must hold ChunkRule or ChinRule stages")
            self._stages = list(grammar)
        else:
            raise TypeError("chunk grammar must be str or a list of stages")

    # spec: N-000250 N-000251 N-000252 N-000458
    def parse(self, tagged):
        items = list(_check_tagged(tagged))
        for stage in self._stages:
            if isinstance(stage, ChinRule):
                items = _apply_chink_rule(stage, items)
            else:
                items = _apply_chunk_rule(stage, items)
        return Tree(DEFAULT_SENTENCE_LABEL, items)


# spec: N-000231 N-000257 N-000452
def ne_chunk(tagged_tokens):
    """Named-entity chunking.

    Requires the packaged named-entity chunker model and the English wordlist to be
    visible.  The packaged maximum-entropy model is not loaded; the result groups
    runs of proper nouns (``NNP``/``NNPS``) into ``NE`` chunks.  See NOTES.md.
    """
    _data.find_dir("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    _data.find("corpora/words")
    items = _check_tagged(tagged_tokens)
    return RegexpParser([ChunkRule("NE", "<NNP.*>+")]).parse(items)
