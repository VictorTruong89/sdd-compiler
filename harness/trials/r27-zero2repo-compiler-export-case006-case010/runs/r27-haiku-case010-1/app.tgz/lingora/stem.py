"""Stemmers (``lingora.stem``), FP-02.

Decisions where the specification disagrees with itself (see NOTES.md):

* ``PorterStemmer`` defaults to the LINGORA extensions (FP-02), so ``ties``
  stems to ``tie``, not ``ti``.
* ``to_lowercase`` defaults to True (PRD: the word is lowercased first).
* Snowball implements ``english`` (Porter2) and ``porter`` (original Porter)
  fully; the other listed languages are accepted by the constructor and raise
  ``NotImplementedError`` when stemming (not done, see NOTES.md).
"""

import os
import re

from . import data as _data

# spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428 N-000429 N-000430 N-000431 N-000432

# spec: N-000023 N-000140 N-000141 N-000142 N-000034
__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

# spec: N-000147 N-000148 N-000428
SNOWBALL_LANGUAGES = (
    "arabic",
    "danish",
    "dutch",
    "english",
    "finnish",
    "french",
    "german",
    "hungarian",
    "italian",
    "norwegian",
    "porter",
    "portuguese",
    "romanian",
    "russian",
    "spanish",
    "swedish",
)


# spec: N-000152
def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be str, not %s" % type(word).__name__)


def _check_bool(value, name):
    if not isinstance(value, bool):
        raise TypeError("%s must be bool, not %s" % (name, type(value).__name__))


# ---------------------------------------------------------------------------
# Porter
# ---------------------------------------------------------------------------

# spec: N-000155
_PORTER_IRREGULAR = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "idly": "idl",
    "gently": "gentl",
    "ugly": "ugli",
    "early": "earli",
    "only": "onli",
    "singly": "singl",
    "sky": "sky",
    "news": "news",
    "howe": "howe",
    "atlas": "atlas",
    "cosmos": "cosmos",
    "bias": "bias",
    "andes": "andes",
}

_PORTER_MODES = ("ORIGINAL_ALGORITHM", "MARTIN_EXTENSIONS", "NLTK_EXTENSIONS")


def _cons(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return i == 0 or not _cons(word, i - 1)
    return True


def _measure(stem):
    """Porter's measure m: the number of VC sequences in ``stem``."""
    n = len(stem)
    i = 0
    while True:
        if i >= n:
            return 0
        if not _cons(stem, i):
            break
        i += 1
    i += 1
    m = 0
    while True:
        while True:
            if i >= n:
                return m
            if _cons(stem, i):
                break
            i += 1
        i += 1
        m += 1
        while True:
            if i >= n:
                return m
            if not _cons(stem, i):
                break
            i += 1
        i += 1


def _has_vowel(stem):
    return any(not _cons(stem, i) for i in range(len(stem)))


# spec: N-000161
def _ends_cvc(stem, extensions):
    n = len(stem)
    if n >= 3:
        return (
            _cons(stem, n - 3)
            and not _cons(stem, n - 2)
            and _cons(stem, n - 1)
            and stem[-1] not in "wxy"
        )
    if n == 2 and extensions:
        # LINGORA extension: a two-letter stem of a vowel then a consonant.
        return (not _cons(stem, 0)) and _cons(stem, 1) and stem[1] not in "wxy"
    return False


def _ends_double_consonant(word):
    return len(word) >= 2 and word[-1] == word[-2] and _cons(word, len(word) - 1)


# spec: N-000149 N-000150 N-000151 N-000152 N-000153 N-000154 N-000157 N-000421
# spec: N-000422 N-000424 N-000425
class PorterStemmer:
    """Porter's suffix-stripping stemmer (FP-02).

    ``mode`` is one of ``'NLTK_EXTENSIONS'`` (the default, LINGORA extensions),
    ``'MARTIN_EXTENSIONS'`` or ``'ORIGINAL_ALGORITHM'``.
    """

    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    _STEP2 = [
        ("ational", "ate"),
        ("tional", "tion"),
        ("enci", "ence"),
        ("anci", "ance"),
        ("izer", "ize"),
        ("ization", "ize"),
        ("ation", "ate"),
        ("ator", "ate"),
        ("alism", "al"),
        ("iveness", "ive"),
        ("fulness", "ful"),
        ("ousness", "ous"),
        ("aliti", "al"),
        ("iviti", "ive"),
        ("biliti", "ble"),
        ("entli", "ent"),
        ("eli", "e"),
        ("ousli", "ous"),
    ]
    _STEP2_EXT = [
        ("alli", "al"),
        ("fulli", "ful"),
        ("bli", "ble"),
        ("logi", "log"),
    ]
    _STEP3 = [
        ("icate", "ic"),
        ("ative", ""),
        ("alize", "al"),
        ("iciti", "ic"),
        ("ical", "ic"),
        ("ful", ""),
        ("ness", ""),
    ]
    _STEP4 = [
        "al",
        "ance",
        "ence",
        "er",
        "ic",
        "able",
        "ible",
        "ant",
        "ement",
        "ment",
        "ent",
        "ion",
        "ou",
        "ism",
        "ate",
        "iti",
        "ous",
        "ive",
        "ize",
    ]

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in _PORTER_MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._ext = mode == self.NLTK_EXTENSIONS
        self._martin = mode != self.ORIGINAL_ALGORITHM

    # spec: N-000154 N-000156
    def stem(self, word, to_lowercase=True):
        _check_word(word)
        _check_bool(to_lowercase, "to_lowercase")
        if to_lowercase:
            word = word.lower()
        if self._ext and word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        if self._martin and len(word) <= 2:
            return word
        word = self._step1a(word)
        word = self._step1b(word)
        word = self._step1c(word)
        word = self._step2(word)
        word = self._step3(word)
        word = self._step4(word)
        word = self._step5(word)
        return word

    # Step 1a
    # spec: N-000158
    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if self._ext and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    # Step 1b
    # spec: N-000159 N-000160
    def _step1b(self, w):
        if self._ext and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                return w[:-1]
            return w
        for suffix in ("ed", "ing"):
            if w.endswith(suffix) and _has_vowel(w[: -len(suffix)]):
                return self._step1b_cleanup(w[: -len(suffix)])
        return w

    def _step1b_cleanup(self, w):
        if w.endswith(("at", "bl", "iz")):
            return w + "e"
        if _ends_double_consonant(w) and w[-1] not in "lsz":
            return w[:-1]
        if _measure(w) == 1 and _ends_cvc(w, self._ext):
            return w + "e"
        return w

    # Step 1c
    # spec: N-000162
    def _step1c(self, w):
        if not w.endswith("y"):
            return w
        stem = w[:-1]
        if self._ext:
            if len(stem) >= 2 and _cons(stem, len(stem) - 1):
                return stem + "i"
            return w
        if _has_vowel(stem):
            return stem + "i"
        return w

    # Step 2
    # spec: N-000163 N-000164 N-000165 N-000166 N-000167 N-000168 N-000169
    def _step2(self, w):
        rules = list(self._STEP2)
        if self._martin:
            rules += self._STEP2_EXT if self._ext else [("logi", "log"), ("bli", "ble")]
        rules.sort(key=lambda rule: -len(rule[0]))
        for suffix, repl in rules:
            if not w.endswith(suffix):
                continue
            stem = w[: -len(suffix)]
            if suffix == "logi":
                if _measure(w[:-3]) > 0:
                    return w[:-1]
                return w
            if _measure(stem) > 0:
                if suffix == "alli" and self._ext:
                    return self._step2(stem + "al")
                if suffix == "bli" and not self._ext:
                    return w
                return stem + repl
            return w
        return w

    # Step 3
    def _step3(self, w):
        for suffix, repl in self._STEP3:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    # Step 4
    def _step4(self, w):
        for suffix in sorted(self._STEP4, key=len, reverse=True):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if suffix == "ion" and not stem.endswith(("s", "t")):
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    # Step 5
    def _step5(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _ends_cvc(stem, self._ext)):
                w = stem
        if _measure(w) > 1 and w.endswith("ll"):
            w = w[:-1]
        return w


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rule syntax: reversed suffix letters, optional '*' (applies only while the word
# is intact), a digit giving the number of letters removed, optional replacement
# letters, then '.' (stop) or '>' (continue).
_LANCASTER_RULES = """
ai*2. a*1. bb1. city3s. ci2> cn1t> dd1. dei3y> deec2ss. dee1. de2> dooh4> e1>
feil1v. fi2> gni3> gai3y. ga2> gg1. ht*2. hsiug5ct. hsi3> i*1. i1y> j1d. juf1s.
lbaifi6. lbai4y. lba3> lbi3. lib2l> lc1. lufi4y. lu2. lai3y> lau3> la2> ll1.
mui3. mu*2. msi3> mm1. nois4j> noix4ct. noi3> nai3> na2> nee0. ne2> nn1. pihs4>
pp1. re2> rae0. ra2. ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2> ss0. suo3>
su*2. s*1> s0 tacilp4y. ta2> tnem4> tne3> tna3> tpir2b. tpro2b. tcud1. tpmus2.
tpec2iv. tulo2v. tsis0. tsi3> tt1. uqi3. ugo1. vis3j> vie0. vi2> ylb1> yli3y>
ylp0. yl2> ygo1. yhp1. ymo1. ypo1. yti3> yte3> ytl2. yrtsi5. yra3> yro3> yfi3.
ycn2t> yca3> zi2> zy1s.
"""

_LANCASTER_RULE_RE = re.compile(r"^([a-z]+)(\*?)([0-9])([a-z]*)([.>])$")


def _parse_lancaster_rules(text):
    rules = []
    for token in text.split():
        match = _LANCASTER_RULE_RE.match(token)
        if not match:
            # Rules with a removal count of 0 and no letters, e.g. "s0".
            match = re.match(r"^([a-z]+)(\*?)([0-9])([a-z]*)([.>]?)$", token)
            if not match:
                continue
            terminator = match.group(5) or "."
        else:
            terminator = match.group(5)
        suffix = match.group(1)[::-1]
        rules.append(
            (suffix, match.group(2) == "*", int(match.group(3)), match.group(4), terminator)
        )
    return rules


_LANCASTER_PARSED = _parse_lancaster_rules(_LANCASTER_RULES)


def _lancaster_acceptable(word):
    if not word:
        return False
    if word[0] in "aeiouy":
        return len(word) > 1
    return len(word) > 2 and _has_vowel(word)


# spec: N-000170 N-000171 N-000423
class LancasterStemmer:
    """Paice/Husk stemmer driven by a rule table (FP-02).

    The rule table is a reconstruction of the published table: it contains the
    rules listed in ``_LANCASTER_RULES``; see NOTES.md.
    """

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        for _ in range(100):
            for suffix, intact_only, removal, append, terminator in _LANCASTER_PARSED:
                if intact_only and not intact:
                    continue
                if not word.endswith(suffix):
                    continue
                if removal > len(word):
                    continue
                candidate = word[: len(word) - removal] + append
                if not _lancaster_acceptable(candidate):
                    continue
                word = candidate
                if terminator == ".":
                    return word
                intact = False
                break
            else:
                return word
        return word


# ---------------------------------------------------------------------------
# Snowball (Porter2 for english; original Porter for porter)
# ---------------------------------------------------------------------------

_PORTER2_EXCEPTIONS = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "idly": "idl",
    "gently": "gentl",
    "ugly": "ugli",
    "early": "earli",
    "only": "onli",
    "singly": "singl",
    "sky": "sky",
    "news": "news",
    "howe": "howe",
    "atlas": "atlas",
    "cosmos": "cosmos",
    "bias": "bias",
    "andes": "andes",
}
_P2_VOWELS = "aeiouy"


def _p2_region(word, start):
    """Start index of the region after the first non-vowel that follows a vowel."""
    for i in range(max(start, 1), len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            return i + 1
    return len(word)


def _p2_short_syllable_end(word):
    """True when ``word`` ends in a short syllable (Porter2 definition)."""
    if len(word) == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if len(word) >= 3:
        return (
            word[-3] not in _P2_VOWELS
            and word[-2] in _P2_VOWELS
            and word[-1] not in _P2_VOWELS
            and word[-1] not in "wxY"
        )
    return False


_P2_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
    ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
    ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
    ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("fulli", "ful"), ("lessli", "less"), ("ogi", "og"),
]
_P2_STEP3 = [
    ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
    ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
]
_P2_STEP3_R2 = {"ative"}
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]
_P2_LI_ENDINGS = "cdeghkmnrt"


# spec: N-000172 N-000174 N-000175 N-000176
def _porter2(word):
    if word in _PORTER2_EXCEPTIONS:
        return _PORTER2_EXCEPTIONS[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)

    r1 = len(w)
    for prefix in ("gener", "commun", "arsen"):
        if w.startswith(prefix):
            r1 = len(prefix)
            break
    else:
        r1 = _p2_region(w, 0)
    r2 = _p2_region(w, r1)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[: -len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(ch in _P2_VOWELS for ch in w[:-2]):
            w = w[:-1]

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if any(ch in _P2_VOWELS for ch in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt":
                        w = w[:-1]
                    elif r1 >= len(w) and _p2_short_syllable_end(w):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    # Step 2
    matched = False
    for suffix, repl in sorted(_P2_STEP2, key=lambda rule: -len(rule[0])):
        if w.endswith(suffix):
            matched = True
            if len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + repl
            break
    if not matched and w.endswith("ogi") and len(w) >= 4 and w[-4] == "l" and len(w) - 3 >= r1:
        w = w[:-3] + "og"
        matched = True
    if not matched and w.endswith("li") and len(w) - 2 >= r1 and len(w) >= 3 and w[-3] in _P2_LI_ENDINGS:
        w = w[:-2]

    # Step 3
    for suffix, repl in sorted(_P2_STEP3, key=lambda rule: -len(rule[0])):
        if w.endswith(suffix):
            region = r2 if suffix in _P2_STEP3_R2 else r1
            if len(w) - len(suffix) >= region:
                w = w[: -len(suffix)] + repl
            break

    # Step 4
    for suffix in sorted(_P2_STEP4, key=len, reverse=True):
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix != "ion" or (len(w) >= 4 and w[-4] in "st"):
                    w = w[: -len(suffix)]
            break

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


# spec: N-000172 N-000173 N-000174 N-000175 N-000176 N-000177 N-000181 N-000182
# spec: N-000183 N-000184 N-000429 N-000430
class SnowballStemmer:
    """Snowball stemmers for the languages named in FP-02.

    ``english`` is Porter2 and ``porter`` is the original Porter algorithm.  The
    other supported names are accepted; stemming with them is not implemented.
    """

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language %r; supported: %s"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        _check_bool(ignore_stopwords, "ignore_stopwords")
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            self._stopwords = _load_stopwords(language)
        if language == "english":
            self._impl = _porter2
        elif language == "porter":
            self._impl = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
        else:
            self._impl = None

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self._impl is None:
            raise NotImplementedError(
                "Snowball stemming for %r is not implemented in this build" % self._language
            )
        if self._language == "porter":
            return self._impl.stem(word, to_lowercase=False)
        if self._language == "english":
            return self._impl(word)
        return self._impl.stem(word)


# spec: N-000183 N-000184 N-000431
def _load_stopwords(language):
    resource = "corpora/stopwords/%s" % language
    try:
        found = _data.find(resource)
    except LookupError:
        raise LookupError(
            "stopwords list for %r is not visible in lingora.data.path" % language
        )
    if os.path.isdir(found):
        raise LookupError("stopwords list for %r is not a file" % language)
    return {line.strip() for line in _data.read_lines(found) if line.strip()}


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------


# spec: N-000178 N-000179 N-000180 N-000426
class RegexpStemmer:
    """Remove every match of ``regexp`` from the word; nothing else changes."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# ---------------------------------------------------------------------------
# WordNet lemmatizer
# ---------------------------------------------------------------------------

_MORPHY_RULES = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
          ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
}
_MORPHY_RULES["r"] = _MORPHY_RULES["a"]


# spec: N-000185 N-000186 N-000432
class WordNetLemmatizer:
    """Lemmatizer backed by the packaged WordNet resource (``corpora/wordnet``).

    Lemma candidates come from the WordNet index files and morphological
    suffix rules.  Raises ``LookupError`` when WordNet is not visible.
    """

    def __init__(self):
        self._dir = _data.find_dir("corpora/wordnet")
        self._index = {}

    def _lemmas(self, pos):
        if pos not in self._index:
            names = set()
            index_file = os.path.join(self._dir, "index.%s" % {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}[pos])
            if os.path.exists(index_file):
                for line in _data.read_lines(index_file):
                    if line and not line.startswith(" "):
                        names.add(line.split(" ", 1)[0])
            self._index[pos] = names
        return self._index[pos]

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        if pos not in _MORPHY_RULES:
            raise ValueError("unknown part of speech %r" % (pos,))
        lemmas = self._lemmas(pos)
        if word in lemmas:
            return word
        for suffix, repl in _MORPHY_RULES[pos]:
            if word.endswith(suffix) and len(word) > len(suffix):
                candidate = word[: -len(suffix)] + repl
                if candidate in lemmas:
                    return candidate
        return word


# ---------------------------------------------------------------------------
# Not implemented families (named in the import surface)
# ---------------------------------------------------------------------------


# spec: N-000143 N-000144 N-000145 N-000146
class ARLSTem:
    """Arabic light stemmer (ARLSTem). Not implemented; see NOTES.md."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2:
    """Arabic light stemmer v2 (ARLSTem2). Not implemented; see NOTES.md."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem2 is not implemented in this build")
