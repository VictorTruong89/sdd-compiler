"""Part-of-speech taggers (``lingora.tag``), FP-03.

Sequential taggers: default, unigram, bigram, trigram, affix and regular-expression
taggers, each with optional backoff.  The recommended tagger is a greedy averaged
perceptron (textblob-aptagger feature templates) that reads a packaged English or
Russian resource.
"""

import json
import os
import re
from collections import Counter, defaultdict

from . import data as _data

# spec: N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439 N-000440 N-000441 N-000442 N-000443 N-000444 N-000445

# spec: N-000035 N-000036
__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "NgramTagger",
    "RegexpTagger",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]

# spec: N-000187 N-000188 N-000189 N-000196 N-000197 N-000205 N-000206
# spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204


# spec: N-000435 N-000442
def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be str, not %s" % type(tok).__name__)
    return tokens


# spec: N-000024 N-000196 N-000197 N-000205 N-000206
class TaggerI:
    """Common behaviour: tag a token list and apply backoff for untagged tokens."""

    backoff = None

    def choose_tag(self, tokens, index, history):  # pragma: no cover - overridden
        return None

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._tag_list(tokens)
        if self.backoff is not None and any(t is None for t in tags):
            fallback = self.backoff.tag(tokens)
            tags = [
                own if own is not None else fallback[i][1]
                for i, own in enumerate(tags)
            ]
        return list(zip(tokens, tags))

    def _tag_list(self, tokens):
        tags = []
        for index in range(len(tokens)):
            tags.append(self.choose_tag(tokens, index, tags))
        return tags


# spec: N-000198
class DefaultTagger(TaggerI):
    """Assign one configured tag to every token."""

    def __init__(self, tag):
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


# spec: N-000202 N-000203 N-000204 N-000438
class RegexpTagger(TaggerI):
    """Tag by the first matching regular expression (applied at the token start)."""

    def __init__(self, regexps, backoff=None):
        if not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))
        self.backoff = backoff

    def choose_tag(self, tokens, index, history):
        token = tokens[index]
        for regexp, tag in self._rules:
            if regexp.match(token):
                return tag
        return None


# spec: N-000187 N-000188 N-000189 N-000436 N-000437
class NgramTagger(TaggerI):
    """Context tagger: the most frequent tag for (token, previous tags) in training."""

    def __init__(self, n, train=None, backoff=None, cutoff=0):
        self._n = n
        self._context_counts = defaultdict(Counter)
        self.backoff = backoff
        self._cutoff = cutoff
        if train:
            self.train(train)

    def train(self, train):
        for sentence in train:
            history = []
            for token, tag in sentence:
                key = (token, tuple(history[-(self._n - 1):]) if self._n > 1 else ())
                self._context_counts[key][tag] += 1
                history.append(tag)

    def choose_tag(self, tokens, index, history):
        key = (tokens[index], tuple(history[-(self._n - 1):]) if self._n > 1 else ())
        counts = self._context_counts.get(key)
        if not counts:
            return None
        return _most_common(counts)


# spec: N-000199 N-000200 N-000201 N-000436 N-000437
class UnigramTagger(NgramTagger):
    """Each word gets the tag it most often had in training; unseen words get none."""

    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(1, train=None, backoff=backoff, cutoff=cutoff)
        self._word_counts = defaultdict(Counter)
        if train:
            self.train(train)

    def train(self, train):
        for sentence in train:
            for token, tag in sentence:
                self._word_counts[token][tag] += 1

    def choose_tag(self, tokens, index, history):
        counts = self._word_counts.get(tokens[index])
        if not counts:
            return None
        return _most_common(counts)


class BigramTagger(NgramTagger):
    """Context tagger with the previous tag as context."""

    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(2, train=train, backoff=backoff, cutoff=cutoff)


class TrigramTagger(NgramTagger):
    """Context tagger with the two previous tags as context."""

    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(3, train=train, backoff=backoff, cutoff=cutoff)


# spec: N-000187 N-000189
class AffixTagger(TaggerI):
    """Tag by the most frequent tag for a word's prefix or suffix of a fixed length."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        self._length = affix_length
        self._min_stem = min_stem_length
        self._affix_counts = defaultdict(Counter)
        self.backoff = backoff
        if train:
            self.train(train)

    def _affix(self, word):
        if len(word) < self._min_stem:
            return None
        if self._length > 0:
            return word[: self._length]
        return word[self._length:]

    def train(self, train):
        for sentence in train:
            for token, tag in sentence:
                affix = self._affix(token)
                if affix is not None:
                    self._affix_counts[affix][tag] += 1

    def choose_tag(self, tokens, index, history):
        affix = self._affix(tokens[index])
        if affix is None:
            return None
        counts = self._affix_counts.get(affix)
        if not counts:
            return None
        return _most_common(counts)


def _most_common(counts):
    """Most frequent tag; ties broken alphabetically so results are deterministic."""
    best = max(counts.values())
    return sorted(tag for tag, count in counts.items() if count == best)[0]


# ---------------------------------------------------------------------------
# Averaged perceptron (recommended tagger)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(index, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    index += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[index])
    add("i-1 tag+i word", prev, context[index])
    add("i-1 word", context[index - 1])
    add("i-1 suffix", context[index - 1][-3:])
    add("i-2 word", context[index - 2])
    add("i+1 word", context[index + 1])
    add("i+1 suffix", context[index + 1][-3:])
    add("i+2 word", context[index + 2])
    return features


class _PerceptronModel:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            for label, weight in self.weights.get(feat, {}).items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: (scores[label], label))


_PERCEPTRON_CACHE = {}


# spec: N-000224 N-000225 N-000443
def _load_perceptron(lang):
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language %r; the recommended tagger supports 'eng' and 'rus'" % (lang,))
    base = "taggers/averaged_perceptron_tagger_%s" % lang
    folder = _data.find_dir(base)
    weights_file = os.path.join(folder, "averaged_perceptron_tagger_%s.weights.json" % lang)
    tagdict_file = os.path.join(folder, "averaged_perceptron_tagger_%s.tagdict.json" % lang)
    classes_file = os.path.join(folder, "averaged_perceptron_tagger_%s.classes.json" % lang)
    for needed in (weights_file, tagdict_file, classes_file):
        if not os.path.exists(needed):
            raise LookupError("averaged perceptron tagger file %s is not installed" % needed)
    key = (weights_file, tagdict_file, classes_file, os.path.getmtime(weights_file))
    if key not in _PERCEPTRON_CACHE:
        with open(weights_file, encoding="utf-8") as handle:
            weights = json.load(handle)
        with open(tagdict_file, encoding="utf-8") as handle:
            tagdict = json.load(handle)
        with open(classes_file, encoding="utf-8") as handle:
            classes = json.load(handle)
        _PERCEPTRON_CACHE[key] = (_PerceptronModel(weights, set(classes)), tagdict)
    return _PERCEPTRON_CACHE[key]


# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212
def _perceptron_tag(tokens, lang):
    model, tagdict = _load_perceptron(lang)
    prev, prev2 = _START
    output = []
    context = _START + [_normalize(w) for w in tokens] + _END
    for index, word in enumerate(tokens):
        tag = tagdict.get(word)
        if not tag:
            features = _features(index, word, context, prev, prev2)
            tag = model.predict(features)
        output.append(tag)
        prev2 = prev
        prev = tag
    return output


_UNIVERSAL_CACHE = {}


# spec: N-000215 N-000226 N-000227
def _load_en_universal_map():
    folder = _data.find_dir("taggers/universal_tagset")
    mapping_file = os.path.join(folder, "en-ptb.map")
    if not os.path.exists(mapping_file):
        raise LookupError("universal tagset table en-ptb.map is not installed")
    if mapping_file not in _UNIVERSAL_CACHE:
        table = {}
        for line in _data.read_lines(mapping_file):
            parts = line.split("\t")
            if len(parts) == 2:
                table[parts[0].strip()] = parts[1].strip()
        _UNIVERSAL_CACHE[mapping_file] = table
    return _UNIVERSAL_CACHE[mapping_file]


# Russian National Corpus part-of-speech categories -> universal tagset.
# spec: N-000213 N-000214 N-000216
_RNC_TO_UNIVERSAL = {
    "S": "NOUN",
    "V": "VERB",
    "A": "ADJ",
    "ANUM": "ADJ",
    "ADV": "ADV",
    "PR": "ADP",
    "CONJ": "CONJ",
    "PART": "PRT",
    "NUM": "NUM",
    "APRO": "DET",
    "SPRO": "PRON",
    "ADVPRO": "ADV",
    "INTJ": "X",
    "COM": "ADJ",
}


# spec: N-000217 N-000218
def _map_russian(tag):
    if tag is None:
        return None
    head = tag.split("=")[0]
    return _RNC_TO_UNIVERSAL.get(head, "X")


# spec: N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000219 N-000220
# spec: N-000221 N-000222 N-000223 N-000440 N-000441 N-000443 N-000444 N-000445
def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with LINGORA's recommended perceptron tagger.

    ``lang`` is ``'eng'`` (default) or ``'rus'``. ``tagset`` is ``None`` (native
    tags) or ``'universal'``.
    """
    tokens = _check_tokens(tokens)
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language %r" % (lang,))
    tags = _perceptron_tag(tokens, lang)
    if tagset == "universal":
        if lang == "eng":
            table = _load_en_universal_map()
            tags = [table.get(tag, tag) if tag is not None else None for tag in tags]
        else:
            tags = [_map_russian(tag) for tag in tags]
    return list(zip(tokens, tags))
