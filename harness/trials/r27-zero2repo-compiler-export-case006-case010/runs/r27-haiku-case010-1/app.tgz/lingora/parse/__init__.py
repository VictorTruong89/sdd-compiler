"""Parsers (``lingora.parse``), FP-05.

:class:`ChartParser` is exhaustive; :class:`ShiftReduceParser` is a single
left-to-right pass without backtracking.  Both raise ``ValueError`` when the token
list holds a token that no production produces.
"""

from ..grammar import CFG, Nonterminal
from ..tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


# spec: N-000262 N-000263 N-000292 N-000293 N-000294 N-000472 N-000475 N-000476
def _check_grammar_and_tokens(grammar, tokens):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    terminals = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be str")
        if tok not in terminals:
            raise ValueError("token %r is not produced by any production" % (tok,))
    return tokens


def _is_match(item, symbol):
    if isinstance(symbol, str):
        return isinstance(item, str) and item == symbol
    return isinstance(item, Tree) and item.label() == str(symbol)


# spec: N-000258 N-000259 N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
# spec: N-000473 N-000474
class ChartParser:
    """Exhaustive parser: every tree the grammar assigns to the tokens.

    Unit or epsilon cycles are cut, so each derivation is returned at most once per
    span it is found in.
    """

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_grammar_and_tokens(self._grammar, tokens)
        memo = {}
        results = self._trees(self._grammar.start(), 0, len(tokens), tokens, memo, frozenset())
        return iter(list(results))

    def _trees(self, symbol, i, j, tokens, memo, active):
        key = (str(symbol), i, j)
        if key in memo:
            return memo[key]
        if key in active:
            return []
        inner_active = active | {key}
        trees = []
        for production in self._grammar.productions():
            if production.lhs() != symbol:
                continue
            for children in self._sequences(production.rhs(), 0, i, j, tokens, memo, inner_active):
                trees.append(Tree(str(symbol), children))
        memo[key] = trees
        return trees

    def _sequences(self, rhs, k, pos, end, tokens, memo, active):
        if k == len(rhs):
            return [[]] if pos == end else []
        symbol = rhs[k]
        if isinstance(symbol, str):
            if symbol == "":
                return self._sequences(rhs, k + 1, pos, end, tokens, memo, active)
            if pos < end and tokens[pos] == symbol:
                return [[symbol] + rest for rest in self._sequences(rhs, k + 1, pos + 1, end, tokens, memo, active)]
            return []
        out = []
        for mid in range(pos, end + 1):
            subtrees = self._trees(symbol, pos, mid, tokens, memo, active)
            if not subtrees:
                continue
            rests = self._sequences(rhs, k + 1, mid, end, tokens, memo, active)
            for subtree in subtrees:
                for rest in rests:
                    out.append([subtree] + rest)
        return out


# spec: N-000260 N-000272 N-000273 N-000274 N-000275
class ShiftReduceParser:
    """One left-to-right shift-reduce pass without backtracking."""

    _STEP_LIMIT = 100000

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar
        self._rules = []
        for production in grammar.productions():
            rhs = [sym for sym in production.rhs() if sym != ""]
            if rhs:
                self._rules.append((production.lhs(), rhs))

    def parse(self, tokens):
        tokens = _check_grammar_and_tokens(self._grammar, tokens)
        stack = []
        position = 0
        steps = 0
        while True:
            steps += 1
            if steps > self._STEP_LIMIT:
                return iter([])
            reduced = False
            for lhs, rhs in self._rules:
                size = len(rhs)
                if size > len(stack):
                    continue
                top = stack[len(stack) - size:]
                if all(_is_match(item, sym) for item, sym in zip(top, rhs)):
                    del stack[len(stack) - size:]
                    stack.append(Tree(str(lhs), list(top)))
                    reduced = True
                    break
            if reduced:
                continue
            if position < len(tokens):
                stack.append(tokens[position])
                position += 1
                continue
            break
        start = str(self._grammar.start())
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


__all__ += ["Nonterminal"]
