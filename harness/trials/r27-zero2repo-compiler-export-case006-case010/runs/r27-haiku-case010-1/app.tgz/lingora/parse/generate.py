"""Sentence generation from a grammar (``lingora.parse.generate``), FP-05."""

import itertools

from ..grammar import CFG, Nonterminal

# spec: N-000472 N-000477 N-000478 N-000479 N-000480
# spec: N-000276 N-000277 N-000278 N-000279 N-000280

__all__ = ["generate"]


# spec: N-000276 N-000277 N-000278 N-000279
def _gen_symbol(grammar, symbol, depth):
    if depth is not None and depth <= 0:
        return
    for production in grammar.productions():
        if production.lhs() != symbol:
            continue
        child_depth = None if depth is None else depth - 1
        for sentence in _gen_sequence(grammar, production.rhs(), 0, child_depth):
            yield sentence


# spec: N-000280
def _gen_sequence(grammar, rhs, k, depth):
    if k == len(rhs):
        yield []
        return
    symbol = rhs[k]
    if isinstance(symbol, str):
        head = [symbol] if symbol != "" else []
        for rest in _gen_sequence(grammar, rhs, k + 1, depth):
            yield head + rest
        return
    for first in _gen_symbol(grammar, symbol, depth):
        for rest in _gen_sequence(grammar, rhs, k + 1, depth):
            yield first + rest


# spec: N-000472 N-000477 N-000478 N-000479 N-000480
def generate(grammar, start=None, depth=None, n=None):
    """Enumerate sentences derived from ``grammar``.

    ``start`` is a symbol (or its name) or ``None`` for the start symbol; ``depth``
    bounds the derivation depth; ``n`` bounds the number of sentences.  Each
    sentence is a list of terminal ``str`` tokens; an empty-string terminal adds no
    token.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool)):
        raise TypeError("depth must be an int or None")
    if n is not None and (not isinstance(n, int) or isinstance(n, bool)):
        raise TypeError("n must be an int or None")
    sentences = _gen_symbol(grammar, start, depth)
    if n is None:
        return sentences
    if n < 0:
        raise ValueError("n must be non-negative")
    return itertools.islice(sentences, n)
