"""FP-05 grammars, parsers, generation and trees; FP-06 classifiers; FP-07 metrics."""

import pytest

from lingora.grammar import CFG, Nonterminal
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'a' N
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'chased' | 'slept'
"""


def test_cfg_reads_productions_and_symbols():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert not isinstance(g.start(), str)
    rhs_of_first = g.productions()[0].rhs()
    assert all(isinstance(sym, Nonterminal) for sym in rhs_of_first)
    terminal_rhs = [sym for p in g.productions() for sym in p.rhs() if isinstance(sym, str)]
    assert "the" in terminal_rhs and "dog" in terminal_rhs
    assert len(g.productions()) == 9


def test_chart_parser_all_parses_and_root():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the dog chased a cat".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == "the dog chased a cat".split()


def test_chart_parser_ambiguity_and_empty_result():
    amb = CFG.fromstring('S -> S S | "x"')
    assert len(list(ChartParser(amb).parse(["x", "x", "x"]))) == 2
    assert list(ChartParser(CFG.fromstring(GRAMMAR)).parse(["dog", "the"])) == []


def test_unknown_token_raises_distinct_from_empty():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])
    with pytest.raises(ValueError):
        ShiftReduceParser(g).parse(["zebra"])


def test_shift_reduce_matches_chart_on_unambiguous_sentence():
    g = CFG.fromstring("S -> NP VP\nNP -> 'dogs'\nVP -> 'bark'")
    chart = list(ChartParser(g).parse(["dogs", "bark"]))
    shift = list(ShiftReduceParser(g).parse(["dogs", "bark"]))
    assert chart == shift and len(shift) == 1


def test_generator_order_limits_and_empty_terminal():
    g = CFG.fromstring("S -> 'a' S | 'b' | ''")
    sents = list(generate(g, depth=3))
    assert ["b"] in sents
    assert ["a", "b"] in sents
    assert [] in sents  # the empty terminal adds no token
    assert len(list(generate(g, depth=3, n=2))) == 2


def test_tree_construction_and_equality():
    t = Tree("S", [Tree("NP", ["the", "dog"]), "x"])
    assert t.label() == "S"
    assert len(t) == 2 and t[1] == "x"
    assert t.leaves() == ["the", "dog", "x"]
    assert Tree.fromstring("(S (NP the dog) x)") == t
    assert Tree("S", []) != Tree("T", [])
    assert Tree("S", []) == Tree("S", [])
    assert "S" in t.pformat() and "dog" in t.pformat()


def test_tree_refuses_string_or_missing_children():
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")


def test_classifiers_naive_bayes_and_tree():
    from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy

    data = [({"a": 1, "b": "x"}, "pos"), ({"a": 0, "b": "y"}, "neg"),
            ({"a": 1, "b": "y"}, "pos"), ({"a": 0, "b": "x"}, "neg")]
    nb = NaiveBayesClassifier.train(data)
    assert nb.labels() == ["pos", "neg"]
    assert nb.classify({"a": 1, "b": "x"}) == "pos"
    dist = nb.prob_classify({"a": 0})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert nb.classify({"never": 1}) in {"pos", "neg"}
    assert accuracy(nb, data) == 1.0
    dt = DecisionTreeClassifier.train(data)
    assert [dt.classify(f) for f, _ in data] == [label for _, label in data]
    assert dt.classify({}) in {"pos", "neg"}


def test_metrics():
    import lingora.metrics as M
    from lingora.translate import bleu

    assert M.edit_distance("kitten", "sitting") == 3
    assert M.edit_distance("", "") == 0
    assert M.edit_distance("ab", "ba", transpositions=True) == 1
    assert M.edit_distance("ab", "ba") == 2
    assert M.jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert M.accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        M.accuracy([1], [1, 2])
    assert M.precision({1, 2}, {2, 3}) == 0.5
    assert M.recall({1, 2}, {2, 3}) == 0.5
    assert M.precision({1}, set()) is None
    assert M.f_measure({1}, {2}) is None
    assert M.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    with pytest.raises(TypeError):
        M.precision([1], {1})
    ref = ["the", "cat", "is", "on", "the", "mat"]
    hyp = ["the", "cat", "sat", "on", "the", "mat"]
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert 0 < bleu([ref], hyp, weights=(1,)) < 1
    assert bleu([ref], hyp) == 0.0  # no 3-gram or 4-gram match, unsmoothed
