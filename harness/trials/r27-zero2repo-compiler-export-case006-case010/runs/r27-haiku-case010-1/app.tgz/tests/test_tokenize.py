"""FP-01 word, punctuation and sentence tokenization (and the packaged-model gate)."""

import io
import sys

import pytest

from lingora import tokenize as T
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


def test_wordpunct_splits_words_and_punctuation():
    assert wordpunct_tokenize("Hello, world! It costs $3.50...") == [
        "Hello", ",", "world", "!", "It", "costs", "$", "3", ".", "50", "...",
    ]


def test_wordpunct_spans_recover_tokens():
    text = "a, bc  d!"
    tokens = WordPunctTokenizer().tokenize(text)
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == tokens
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_empty_and_whitespace_give_empty_lists(no_data):
    for text in ("", "   \n\t "):
        assert wordpunct_tokenize(text) == []
        assert WhitespaceTokenizer().tokenize(text) == []
        assert TreebankWordTokenizer().tokenize(text) == []
        assert word_tokenize(text, preserve_line=True) == []
        assert blankline_tokenize(text) == []


def test_treebank_conventions():
    tokens = TreebankWordTokenizer().tokenize('"Hi," she said; I can\'t go, cannot. Dogs\' bone gonna')
    assert tokens[:2] == ["``", "Hi"]
    assert "," in tokens and "can" in tokens and "n't" in tokens
    assert "can" in tokens and "not" in tokens  # cannot is split by Treebank
    assert "gon" in tokens and "na" in tokens
    assert "'" in tokens  # bare apostrophe ending a word


def test_treebank_final_point_is_split_only_at_end():
    assert TreebankWordTokenizer().tokenize("Go home.") == ["Go", "home", "."]
    assert TreebankWordTokenizer().tokenize("e.g. this") == ["e.g.", "this"]


def test_recommended_tokenizer_keeps_cannot_and_splits_dashes(no_data):
    tokens = word_tokenize("cannot stop--now — really**", preserve_line=True)
    assert "cannot" in tokens
    assert "--" in tokens
    assert "—" in tokens
    assert "*" in tokens


def test_recommended_start_quote_is_closing_token(no_data):
    tokens = word_tokenize('"Hi there"', preserve_line=True)
    assert tokens[0] == "''"


def test_regexp_tokenizer_token_and_gap_modes():
    assert RegexpTokenizer(r"\w+").tokenize("a, b") == ["a", "b"]
    assert RegexpTokenizer(r",\s*", gaps=True).tokenize("a, b,,c") == ["a", "b", "c"]
    assert RegexpTokenizer(r",\s*", gaps=True, discard_empty=False).tokenize("a,,b") == ["a", "", "b"]


def test_tweet_tokenizer_options():
    t = TweetTokenizer()
    assert t.tokenize("@bob LOVE :) http://x.io #Fun don't") == [
        "@bob", "LOVE", ":)", "http://x.io", "#Fun", "don't",
    ]
    assert TweetTokenizer(preserve_case=False).tokenize("LOVE :D") == ["love", ":D"]
    assert TweetTokenizer(strip_handles=True).tokenize("@bob hi") == ["hi"]
    assert TweetTokenizer(reduce_len=True).tokenize("nooooo") == ["nooo"]
    assert TweetTokenizer(preserve_case=False).tokenize("Café NAÏVE") == ["café", "naïve"]


def test_blankline_tokenize_segments():
    assert blankline_tokenize("a\nb\n\n\n c \n") == ["a\nb", "c"]


def test_whitespace_spans():
    assert list(WhitespaceTokenizer().span_tokenize(" ab  c")) == [(1, 3), (5, 6)]


def test_sentence_tokenizer_requires_punkt_model(no_data):
    with pytest.raises(LookupError):
        sent_tokenize("One sentence.")
    with pytest.raises(LookupError):
        word_tokenize("One sentence.")


def test_sentence_tokenizer_with_model(lingora_data):
    text = "Mr. Smith went home. He slept! The dog barked."
    assert sent_tokenize(text) == [
        "Mr. Smith went home.",
        "He slept!",
        "The dog barked.",
    ]
    assert sent_tokenize("A single sentence") == ["A single sentence"]
    assert sent_tokenize("") == []


def test_recommended_word_tokenizer_with_sentence_splitting(lingora_data):
    tokens = word_tokenize("Mr. Smith went home. He slept.")
    assert tokens == ["Mr.", "Smith", "went", "home", ".", "He", "slept", "."]


def test_cli_tokenize_writes_tokens_per_line(lingora_data, monkeypatch, capsys):
    from lingora.cli import cli

    monkeypatch.setattr(sys, "stdin", io.StringIO("He slept. Done.\nAnother line.\n"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    out = capsys.readouterr().out
    assert code == 0
    assert out == "He slept . Done .\nAnother line .\n"


def test_cli_tokenize_fails_without_model(no_data, monkeypatch, capsys):
    from lingora.cli import cli

    monkeypatch.setattr(sys, "stdin", io.StringIO("He slept.\n"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    assert code != 0
    assert capsys.readouterr().out == ""


def test_cli_standalone_exits_with_status(lingora_data, monkeypatch, capsys):
    from lingora.cli import cli

    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi.\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize", "--delimiter", "|"])
    assert info.value.code == 0
    assert capsys.readouterr().out == "Hi|.\n"
