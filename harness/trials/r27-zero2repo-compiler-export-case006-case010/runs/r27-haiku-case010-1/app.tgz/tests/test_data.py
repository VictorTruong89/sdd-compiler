"""Packaged-resource finder and import behaviour (spec/packs/06, pack 19)."""

import importlib
import subprocess
import sys

from lingora import data


def test_import_needs_no_data(no_data):
    importlib.import_module("lingora")
    from lingora import tokenize
    assert tokenize.wordpunct_tokenize("a b") == ["a", "b"]


def test_path_is_mutable_list_and_searched(resources, monkeypatch):
    assert isinstance(data.path, list)
    monkeypatch.setattr(data, "path", [])
    try:
        data.find("corpora/words")
        raise AssertionError("expected LookupError")
    except LookupError:
        pass
    data.path.append(resources)
    assert data.find("corpora/words").endswith("words")


def test_package_imports_in_subprocess_without_downloads():
    code = "import lingora, lingora.tokenize, lingora.parse, lingora.cli; print('ok')"
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd="/app")
    assert out.returncode == 0 and out.stdout.strip() == "ok"
