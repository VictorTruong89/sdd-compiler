"""FP-02 stemming."""

import pytest

from lingora.stem import (
    LancasterStemmer,
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
    WordNetLemmatizer,
)


def test_porter_default_mode_extensions():
    p = PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("ties") == "tie"  # LINGORA extension: four-letter -ies -> -ie
    assert p.stem("died") == "die"  # -ied with four letters -> -ie
    assert p.stem("studied") == "studi"
    assert p.stem("happy") == "happi"
    assert p.stem("relational") == "relat"
    assert p.stem("generalization") == "gener"


def test_porter_lowercases_by_default_and_short_words_pass_through():
    p = PorterStemmer()
    assert p.stem("Running") == "run"
    assert p.stem("Running", to_lowercase=False) == "Run"  # case kept, so "ing" is not matched
    assert p.stem("is") == "is"
    assert p.stem("a") == "a"


def test_lancaster_stemmer():
    l = LancasterStemmer()
    assert l.stem("maximum") == "maxim"
    assert l.stem("presumably") == "presum"
    assert l.stem("running") == "run"


def test_snowball_english_and_porter():
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("skies") == "sky"
    assert s.stem("cried") == "cri"
    assert SnowballStemmer("porter").stem("generously") == "gener"


def test_snowball_unsupported_language_names_request():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_snowball_stopwords_require_list(no_data):
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_snowball_stopwords_skip(lingora_data):
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"
    assert s.stem("running") == "run"


def test_snowball_stopwords_list_for_other_language_does_not_satisfy(lingora_data):
    with pytest.raises(LookupError):
        SnowballStemmer("french", ignore_stopwords=True)


def test_regexp_stemmer_only_removes_matches():
    r = RegexpStemmer("ing$")
    assert r.stem("running") == "runn"
    assert r.stem("cat") == "cat"


def test_wordnet_lemmatizer_requires_wordnet(no_data):
    with pytest.raises(LookupError):
        WordNetLemmatizer()


def test_wordnet_lemmatizer_with_index(lingora_data):
    lem = WordNetLemmatizer()
    assert lem.lemmatize("dogs") == "dog"
    assert lem.lemmatize("cat") == "cat"
