"""FP-03 tagging and FP-04 chunking."""

import pytest

from lingora import tag as TG
from lingora.chunk import ChunkRule, RegexpParser, ne_chunk
from lingora.tag import AffixTagger, DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree


def test_default_tagger_tags_everything():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


def test_unigram_tagger_most_frequent_and_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("dog", "VB")], [("dog", "NN")]]
    tagger = UnigramTagger(train=train, backoff=DefaultTagger("XX"))
    assert tagger.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", "XX")]
    assert UnigramTagger(train=train).tag(["zebra"]) == [("zebra", None)]


def test_regexp_tagger_first_rule_matches_at_start():
    tagger = RegexpTagger([(r"\d+$", "CD"), (r".*ing$", "VBG"), (r".*", "NN")])
    assert tagger.tag(["3", "running", "cat"]) == [("3", "CD"), ("running", "VBG"), ("cat", "NN")]
    assert RegexpTagger([(r"cat", "NN")]).tag(["bobcat"]) == [("bobcat", None)]


def test_affix_and_ngram_taggers_follow_train_then_tag():
    from lingora.tag import BigramTagger, TrigramTagger

    train = [[("a", "DT"), ("cat", "NN")]]
    assert BigramTagger(train=train).tag(["a", "cat"]) == [("a", "DT"), ("cat", "NN")]
    assert TrigramTagger(train=train).tag(["a", "cat"])[0] == ("a", "DT")
    assert AffixTagger(train=[[("running", "VBG"), ("sing", "VBG")]], affix_length=-3).tag(["jogging"]) == [("jogging", "VBG")]


def test_pos_tag_rejects_strings_and_unknown_language(lingora_data):
    with pytest.raises(TypeError):
        pos_tag("the dog")
    with pytest.raises(ValueError):
        pos_tag(["the"], lang="fra")


def test_pos_tag_perceptron_english(lingora_data):
    assert pos_tag(["the", "dog", "barked"]) == [("the", "DT"), ("dog", "NN"), ("barked", "VBD")]
    assert pos_tag([]) == []


def test_pos_tag_universal_mapping(lingora_data):
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


def test_pos_tag_missing_model_fails(no_data):
    with pytest.raises(LookupError):
        pos_tag(["the"])


def test_pos_tag_russian_universal_by_part_of_speech(monkeypatch, tmp_path):
    import json
    from lingora import data

    folder = tmp_path / "taggers" / "averaged_perceptron_tagger_rus"
    folder.mkdir(parents=True)
    (folder / "averaged_perceptron_tagger_rus.weights.json").write_text(json.dumps({"bias": {"S=m": 1.0}}), encoding="utf-8")
    (folder / "averaged_perceptron_tagger_rus.tagdict.json").write_text("{}", encoding="utf-8")
    (folder / "averaged_perceptron_tagger_rus.classes.json").write_text(json.dumps(["S=m"]), encoding="utf-8")
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    assert pos_tag(["дом"], lang="rus") == [("дом", "S=m")]
    assert pos_tag(["дом"], tagset="universal", lang="rus") == [("дом", "NOUN")]


def test_regexp_chunk_grammar_chunks_and_chinks():
    tagged = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("the", "DT"), ("cat", "NN")]
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(tagged)
    assert isinstance(tree, Tree)
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NP", "NP"]
    assert tree.leaves() == tagged  # chunking never drops or reorders tokens
    chink = RegexpParser("NP: {<.*>+}\n    }<VBD>{").parse(tagged)
    assert any(isinstance(c, tuple) and c[1] == "VBD" for c in chink)


def test_chunk_cascade_uses_earlier_chunk_label():
    tagged = [("a", "DT"), ("dog", "NN"), ("barked", "VBD")]
    tree = RegexpParser("NP: {<DT><NN>}\nVP: {<NP><VBD>}").parse(tagged)
    assert [c.label() for c in tree] == ["VP"]


def test_empty_chunk_input_gives_sentence_root():
    tree = RegexpParser("NP: {<DT>}").parse([])
    assert len(tree) == 0


def test_chunk_grammar_refused_when_not_text_or_stages():
    with pytest.raises(TypeError):
        RegexpParser(42)
    with pytest.raises(TypeError):
        RegexpParser([("NP", "x")])
    stages = [ChunkRule("NP", "<DT><NN>")]
    assert RegexpParser(stages).parse([("a", "DT"), ("b", "NN")]).leaves() == [("a", "DT"), ("b", "NN")]


def test_ne_chunk_requires_model_and_wordlist(no_data):
    with pytest.raises(LookupError):
        ne_chunk([("Ann", "NNP")])


def test_ne_chunk_groups_proper_nouns(lingora_data):
    tree = ne_chunk([("Ann", "NNP"), ("Smith", "NNP"), ("ran", "VBD")])
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NE"]
