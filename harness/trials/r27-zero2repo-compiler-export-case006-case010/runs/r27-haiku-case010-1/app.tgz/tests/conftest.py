"""Shared fixtures: a small packaged-resource tree written into a temp directory.

The resources are synthetic, minimal versions of the packaged models; they exercise
the file formats of the specification (see spec/packs/06).
"""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture(scope="session")
def resources(tmp_path_factory):
    root = str(tmp_path_factory.mktemp("lingora_data"))

    punkt = os.path.join(root, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "mr\nmrs\ndr\netc\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\n")
    _write(os.path.join(punkt, "collocations.tab"), "u.s.\tgovt\n")
    # bit set: 2 UC start, 4 UC mid, 8 UC unknown, 16 LC start, 32 LC mid, 64 LC unknown
    _write(
        os.path.join(punkt, "ortho_context.tab"),
        "the\t50\nhe\t50\nsmith\t4\ndog\t32\nwent\t48\n",
    )

    tagger = os.path.join(root, "taggers", "averaged_perceptron_tagger_eng")
    weights = {
        "bias": {"NN": 0.1},
        "i word the": {"DT": 5.0},
        "i suffix dog": {"NN": 3.0},
        "i word barked": {"VBD": 4.0},
        "i-1 tag DT": {"NN": 1.0},
    }
    _write(
        os.path.join(tagger, "averaged_perceptron_tagger_eng.weights.json"),
        json.dumps(weights),
    )
    _write(
        os.path.join(tagger, "averaged_perceptron_tagger_eng.tagdict.json"),
        json.dumps({"the": "DT", "barked": "VBD"}),
    )
    _write(
        os.path.join(tagger, "averaged_perceptron_tagger_eng.classes.json"),
        json.dumps(["DT", "NN", "VBD", "IN", "NNP"]),
    )
    _write(
        os.path.join(root, "taggers", "universal_tagset", "en-ptb.map"),
        "DT\tDET\nNN\tNOUN\nVBD\tVERB\nIN\tADP\nNNP\tNOUN\n",
    )

    _write(os.path.join(root, "corpora", "stopwords", "english"), "the\na\nof\n")
    _write(os.path.join(root, "corpora", "stopwords", "german"), "der\ndie\n")
    _write(os.path.join(root, "corpora", "words"), "dog\ncat\n")
    os.makedirs(os.path.join(root, "corpora", "wordnet"), exist_ok=True)
    _write(
        os.path.join(root, "corpora", "wordnet", "index.noun"),
        "  This line is a comment\ndog n 1 0 1 1 1 1 1 1\ncat n 1 0 1 1 1 1 1 1\n",
    )
    os.makedirs(os.path.join(root, "chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"), exist_ok=True)
    return root


@pytest.fixture
def lingora_data(resources, monkeypatch):
    """Make ``resources`` the only visible data directory for one test."""
    monkeypatch.setattr(data, "path", [resources])
    return resources


@pytest.fixture
def no_data(monkeypatch):
    monkeypatch.setattr(data, "path", [])
