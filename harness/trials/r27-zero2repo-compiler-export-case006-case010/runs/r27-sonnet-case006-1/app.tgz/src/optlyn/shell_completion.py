"""Shell completion."""
import os
import re
import shlex

from .core import Argument, Command, Group, Option, ParameterSource
from .utils import echo


class CompletionItem:
    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __repr__(self):
        return f"CompletionItem({self.value!r}, type={self.type!r}, help={self.help!r})"


_BASH = r"""%(complete_func)s() {
    local IFS=$'\n'
    local response

    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(complete_var)s=bash_complete $1)

    for completion in $response; do
        IFS=',' read type value <<< "$completion"

        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done

    return 0
}

%(complete_func)s_setup() {
    complete -o nosort -F %(complete_func)s %(prog_name)s
}

%(complete_func)s_setup;
"""

_ZSH = r"""#compdef %(prog_name)s

%(complete_func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog_name)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(complete_var)s=zsh_complete %(prog_name)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(complete_func)s "$@"
else
    compdef %(complete_func)s %(prog_name)s
fi
"""

_FISH = r"""function %(complete_func)s;
    set -l response (env %(complete_var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog_name)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog_name)s --arguments "(%(complete_func)s)";
"""

_POWERSHELL = r"""Register-ArgumentCompleter -Native -CommandName %(prog_name)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $env:COMP_WORDS = $commandAst
    $env:COMP_WORDS = $env:COMP_WORDS.replace('\\', '/')
    $incompleteCommand = $commandAst.ToString()

    $myCursorPosition = $cursorPosition
    if ($myCursorPosition -gt $incompleteCommand.Length) {
        $myCursorPosition = $incompleteCommand.Length
    }
    $env:COMP_CWORD = @($incompleteCommand.substring(0, $myCursorPosition).Split(" ") | Where-Object { $_ -ne "" }).Length
    if ( $wordToComplete.Length -gt 0) { $env:COMP_CWORD -= 1 }

    $env:%(complete_var)s = "powershell_complete"

    %(prog_name)s | ForEach-Object {
        $type, $value, $help = $_.Split(":", 3)
        $help = if ($help) { $help } else { $value }

        switch ($type) {
            "dir" {
                New-Object -TypeName System.Management.Automation.CompletionResult -ArgumentList $wordToComplete, $wordToComplete, "ParameterValue", $wordToComplete
            }
            "file" {
                New-Object -TypeName System.Management.Automation.CompletionResult -ArgumentList $wordToComplete, $wordToComplete, "ParameterValue", $wordToComplete
            }
            "plain" {
                New-Object -TypeName System.Management.Automation.CompletionResult -ArgumentList $value, $value, "ParameterValue", $help
            }
        }
    }

    $env:%(complete_var)s = ""
    $env:COMP_WORDS = ""
    $env:COMP_CWORD = ""
}
"""


def split_arg_string(s):
    try:
        lex = shlex.shlex(s, posix=True)
        lex.whitespace_split = True
        lex.commenters = ""
        out = []
        try:
            for token in lex:
                out.append(token)
        except ValueError:
            out.append(lex.token)
        return out
    except Exception:
        return s.split()


class ShellComplete:
    name = ""
    source_template = ""

    def __init__(self, cli, ctx_args, prog_name, complete_var):
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self):
        safe = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
        return f"_{safe}_completion"

    def source_vars(self):
        return {"complete_func": self.func_name, "complete_var": self.complete_var,
                "prog_name": self.prog_name}

    def source(self):
        return self.source_template % self.source_vars()

    def get_completion_args(self):
        raise NotImplementedError

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, dict(self.ctx_args), self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item):
        raise NotImplementedError

    def complete(self):
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        return "\n".join(self.format_completion(item) for item in completions)


class BashComplete(ShellComplete):
    name = "bash"
    source_template = _BASH

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        cword = int(os.environ.get("COMP_CWORD", "0"))
        args = cwords[1:cword]
        try:
            incomplete = cwords[cword]
        except IndexError:
            incomplete = ""
        return args, incomplete

    def format_completion(self, item):
        return f"{item.type},{item.value}"


class ZshComplete(BashComplete):
    name = "zsh"
    source_template = _ZSH

    def format_completion(self, item):
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class FishComplete(ShellComplete):
    name = "fish"
    source_template = _FISH

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        incomplete = os.environ.get("COMP_CWORD", "")
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item):
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


class PowerShellComplete(BashComplete):
    name = "powershell"
    source_template = _POWERSHELL

    def format_completion(self, item):
        return f"{item.type}:{item.value}:{item.help if item.help else ''}"


_registry = {"bash": BashComplete, "zsh": ZshComplete, "fish": FishComplete,
             "powershell": PowerShellComplete}


def add_completion_class(cls, name=None):
    _registry[name or cls.name] = cls


def get_completion_class(shell):
    return _registry.get(shell)


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    shell, _, instr = instruction.partition("_")
    comp_cls = get_completion_class(shell)
    if comp_cls is None or instr not in ("source", "complete"):
        echo(f"Shell completion is not supported for {instruction!r}.", err=True)
        return 1
    comp = comp_cls(cli, ctx_args, prog_name, complete_var)
    if instr == "source":
        echo(comp.source())
    else:
        echo(comp.complete())
    return 0


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args["resilient_parsing"] = True
    with cli.make_context(prog_name, list(args), **ctx_args) as ctx:
        args = ctx.protected_args + ctx.args
        while args:
            command = ctx.command
            if isinstance(command, Group):
                if not command.chain:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    with cmd.make_context(name, args, parent=ctx, resilient_parsing=True) as sub:
                        ctx = sub
                        args = ctx.protected_args + ctx.args
                else:
                    sub_ctx = ctx
                    while args:
                        name, cmd, args = command.resolve_command(ctx, args)
                        if cmd is None:
                            return ctx
                        with cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                              allow_interspersed_args=False,
                                              resilient_parsing=True) as sub_sub:
                            args = sub_sub.args
                        sub_ctx = sub_sub
                    ctx = sub_ctx
                    args = [*ctx.protected_args, *ctx.args]
            else:
                break
    return ctx


def _start_of_option(ctx, value):
    if not value:
        return False
    return value[0] in ctx._opt_prefixes or value[0] in "-"


def _resolve_incomplete(ctx, args, incomplete):
    if "--" in args:
        return _argument_for(ctx, incomplete)
    # value of an option?
    params = [p for p in ctx.command.get_params(ctx)
              if isinstance(p, Option) and not p.is_flag and not p.count]
    for idx in range(len(args) - 1, -1, -1):
        arg = args[idx]
        if not _start_of_option(ctx, arg):
            continue
        for p in params:
            if arg in p.opts or arg in p.secondary_opts:
                given = len(args) - idx - 1
                if given < p.nargs:
                    return p, incomplete
        break
    if incomplete and _start_of_option(ctx, incomplete):
        return ctx.command, incomplete
    return _argument_for(ctx, incomplete)


def _argument_for(ctx, incomplete):
    for p in ctx.command.get_params(ctx):
        if not isinstance(p, Argument):
            continue
        value = ctx.params.get(p.name)
        if (p.nargs == -1
                or ctx.get_parameter_source(p.name) is not ParameterSource.COMMANDLINE
                or (p.nargs > 1 and isinstance(value, (tuple, list)) and len(value) < p.nargs)):
            return p, incomplete
    return ctx.command, incomplete
