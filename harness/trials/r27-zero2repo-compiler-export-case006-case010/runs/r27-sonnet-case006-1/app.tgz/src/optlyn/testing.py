"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        yield
        stream._paused = False


class _TeeBytes(io.BytesIO):
    def __init__(self, combined):
        super().__init__()
        self._combined = combined

    def write(self, b):
        self._combined.write(bytes(b))
        return super().write(b)


class _NamedText(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kw):
        super().__init__(buffer, **kw)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = getattr(input, "buffer", None)
        if rv is None:
            rv = input
        if isinstance(rv.read(0), str):
            rv = io.BytesIO(input.read().encode(charset))
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        combined = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            fd_state = self._start_fd_capture()
            out_buf = _FdTee(1, combined, fd_state["tmp1"])
            err_buf = _FdTee(2, combined, fd_state["tmp2"])
        else:
            out_buf = _TeeBytes(combined)
            err_buf = _TeeBytes(combined)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, out_buf)
        sys.stdin = text_input = _NamedText(bytes_input, name="<stdin>", mode="r",
                                            encoding=self.charset)
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = _NamedText(out_buf, name="<stdout>", mode="w", encoding=self.charset,
                                write_through=True)
        sys.stderr = _NamedText(err_buf, name="<stderr>", mode="w", encoding=self.charset,
                                errors="backslashreplace", write_through=True)

        def _read_line():
            line = text_input.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        @_pause_echo_wrap(echo_input)
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            val = _read_line()
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        @_pause_echo_wrap(echo_input)
        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            return _read_line()

        @_pause_echo_wrap(echo_input)
        def _getchar(echo=False):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_buf, err_buf, combined, fd_state)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            if fd_state is not None:
                self._stop_fd_capture(fd_state)

    def _start_fd_capture(self):
        import tempfile as tf
        sys.__stdout__ and sys.__stdout__.flush() if False else None
        for s in (sys.stdout, sys.stderr):
            try:
                s.flush()
            except Exception:
                pass
        st = {"saved1": os.dup(1), "saved2": os.dup(2),
              "tmp1": tf.TemporaryFile(), "tmp2": tf.TemporaryFile()}
        os.dup2(st["tmp1"].fileno(), 1)
        os.dup2(st["tmp2"].fileno(), 2)
        return st

    def _stop_fd_capture(self, st):
        os.dup2(st["saved1"], 1)
        os.dup2(st["saved2"], 2)
        os.close(st["saved1"])
        os.close(st["saved2"])
        st["tmp1"].close()
        st["tmp2"].close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            out_buf, err_buf, combined, fd_state = streams
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if fd_state is not None:
                    stdout = _read_tmp(fd_state["tmp1"])
                    stderr = _read_tmp(fd_state["tmp2"])
                    if stdout == bytes(out_buf.recorded) and stderr == bytes(err_buf.recorded):
                        output = combined.getvalue()
                    else:
                        output = stdout + stderr
                else:
                    stdout = out_buf.getvalue()
                    stderr = err_buf.getvalue()
                    output = combined.getvalue()
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr,
                      output_bytes=output, return_value=return_value, exit_code=exit_code,
                      exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _read_tmp(f):
    f.flush()
    f.seek(0)
    return f.read()


class _FdTee(io.RawIOBase):
    """Writes interpreter output through to a real descriptor and records it."""

    def __init__(self, fd, combined, tmp):
        super().__init__()
        self._fd = fd
        self._combined = combined
        self.recorded = bytearray()

    def writable(self):
        return True

    def fileno(self):
        return self._fd

    def write(self, b):
        b = bytes(b)
        self._combined.write(b)
        self.recorded += b
        os.write(self._fd, b)
        return len(b)

    def flush(self):
        pass

    def getvalue(self):
        return bytes(self.recorded)


def _pause_echo_wrap(stream):
    def deco(f):
        def wrapper(*a, **k):
            with _pause_echo(stream):
                return f(*a, **k)
        return wrapper
    return deco
