"""Interactive terminal helpers."""
import getpass
import itertools
import math
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from .exceptions import Abort, OptlynException, UsageError
from .globals_ import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, isatty, strip_ansi, style

visible_prompt_func = input
hidden_prompt_func = getpass.getpass
_getchar = None


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(str(c) for c in type.choices)})"
    if default is not None and show_default:
        prompt = f"{prompt} [{default if not isinstance(default, (list, tuple)) else ', '.join(map(str, default))}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False,
           show_choices=True):
    def prompt_func(t):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(t.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    p = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(p)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    p = _build_prompt(text, prompt_suffix, show_default,
                      "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(p.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ------------------------------------------------------------------- keyboard

def _unix_getchar(echo_):
    import termios
    import tty
    if sys.stdin is not None and isatty(sys.stdin):
        fd = sys.stdin.fileno()
        own = False
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        own = True
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
            ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if own:
            os.close(fd)
    return ch


def getchar(echo=False):
    f = _getchar if _getchar is not None else _unix_getchar
    ch = f(echo)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "\x1a":
        raise EOFError()
    return ch


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not is_interactive():
        if info:
            echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---------------------------------------------------------------------- pager

def _gen(text_or_generator):
    if isinstance(text_or_generator, str):
        it = [text_or_generator]
    elif callable(text_or_generator):
        r = text_or_generator()
        it = [r] if isinstance(r, str) else r
    else:
        it = text_or_generator
    for el in it:
        yield el if isinstance(el, str) else str(el)


def _pager_cmd():
    return (os.environ.get("PAGER") or "").strip()


def _keep_color(color, stream):
    if color is None:
        return isatty(stream)
    return bool(color)


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    gen = itertools.chain(_gen(text_or_generator), ["\n"])
    stdout = sys.stdout
    cmd = _pager_cmd()
    if not is_interactive() or not cmd:
        keep = _keep_color(color, stdout)
        for chunk in gen:
            if not keep:
                chunk = strip_ansi(chunk)
            stdout.write(chunk)
        stdout.flush()
        return
    keep = True if color is None else bool(color)
    env = dict(os.environ)
    if keep and "less" in cmd and "LESS" not in env:
        env["LESS"] = "-R"
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env, text=True,
                            errors="replace")
    try:
        for chunk in gen:
            if not keep:
                chunk = strip_ansi(chunk)
            try:
                proc.stdin.write(chunk)
                proc.stdin.flush()
            except (BrokenPipeError, OSError):
                break
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


class _PlainWriter:
    def __init__(self, stream, keep):
        self._s = stream
        self._keep = keep

    def write(self, text):
        if not self._keep:
            text = strip_ansi(text)
        return self._s.write(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        self._s.flush()

    def isatty(self):
        return isatty(self._s)

    def writable(self):
        return True


@contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout
    cmd = _pager_cmd()
    if not is_interactive() or not cmd:
        w = _PlainWriter(stdout, _keep_color(color, stdout))
        try:
            yield w
        finally:
            stdout.flush()
        return
    keep = True if color is None else bool(color)
    env = dict(os.environ)
    if keep and "less" in cmd and "LESS" not in env:
        env["LESS"] = "-R"
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env, text=True,
                            errors="replace")
    w = _PlainWriter(proc.stdin, keep)
    try:
        yield w
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


# --------------------------------------------------------------- progress bar

class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                 empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s",
                 info_sep="  ", width=36, file=None, color=None, update_min_steps=1):
        self.iterable = iterable
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = (length is not None) if show_percent is None else show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.width = width
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._rendered_any = False

    @property
    def is_hidden(self):
        return self.hidden or not isatty(self.file)

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            elapsed = time.time() - self.start
            if self.pos <= 0:
                return 0.0
            return (elapsed / self.pos) * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            secs = t % 60
            mins = (t // 60) % 60
            hrs = (t // 3600) % 24
            days = t // 86400
            s = f"{hrs:02}:{mins:02}:{secs:02}"
            return f"{days}d {s}" if days else s
        return ""

    @property
    def eta_known(self):
        return self.length is not None and not self.finished

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        else:
            bar = self.empty_char * self.width
        return bar

    def format_progress_line(self):
        info = []
        if self.show_pos:
            info.append(self.format_pos())
        if self.show_percent:
            info.append(self.format_pct())
        if self.show_eta and self.eta_known:
            info.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info.append(item_info)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                     "info": self.info_sep.join(info)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not isatty(self.file):
            if self._last_line != self.label:
                self._last_line = self.label
                if self.label:
                    echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        clear = "\r" + " " * 0
        echo(f"\r{line}", file=self.file, nl=False, color=self.color)
        self._last_line = line

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True

    def render_finish(self):
        if not self.hidden and isatty(self.file):
            echo(file=self.file)

    def __enter__(self):
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.render_finish()

    def __iter__(self):
        self.render_progress()
        return self._generator()

    def _generator(self):
        try:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.update(1)
        finally:
            self.finish()

    def __next__(self):
        return next(iter(self))


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ------------------------------------------------------------ editor / launch

def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    def get_editor():
        if editor is not None:
            return editor
        for key in ("VISUAL", "EDITOR"):
            rv = os.environ.get(key)
            if rv:
                return rv
        for e in ("sensible-editor", "vim", "nano"):
            if shutil.which(e) is not None:
                return e
        return "vi"

    def edit_file(fn):
        ed = get_editor()
        environ = None
        if env:
            environ = os.environ.copy()
            environ.update(env)
        try:
            c = subprocess.Popen(f"{ed} {shlex.quote(fn)}", env=environ, shell=True)
            code = c.wait()
            if code != 0:
                raise OptlynException(f"{ed}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{ed}: Editing failed: {e}") from e

    if filename is not None:
        edit_file(filename)
        return None
    text = text or ""
    binary = isinstance(text, bytes)
    if not binary and text and not text.endswith("\n"):
        text += "\n"
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        data = text if binary else text.replace("\n", os.linesep).encode("utf-8-sig")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        st = os.stat(name)
        stamp = (st.st_mtime_ns, st.st_size)
        edit_file(name)
        st2 = os.stat(name)
        if require_save and (st2.st_mtime_ns, st2.st_size) == stamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if binary:
            return rv
        return rv.decode("utf-8-sig").replace(os.linesep, "\n")
    finally:
        os.unlink(name)


def launch(url, wait=False, locate=False):
    def unquote(u):
        if u.startswith("file://"):
            from urllib.parse import unquote as uq
            return uq(u[7:])
        return u

    url = os.fspath(url)
    if sys.platform == "darwin":
        args = ["open"]
        if wait:
            args.append("-W")
        if locate:
            args.append("-R")
        args.append(unquote(url))
        with open(os.devnull, "w") as null:
            return subprocess.Popen(args, stderr=null).wait()
    try:
        if locate:
            target = os.path.dirname(unquote(url)) or "."
        else:
            target = unquote(url)
        c = subprocess.Popen(["xdg-open", target])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
