"""Declaration decorators."""
import inspect
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option, _UNSET
from .exceptions import DeclarationError
from .globals_ import get_current_context
from .utils import echo

_ATTR = "__optlyn_params__"


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _ATTR):
            setattr(f, _ATTR, [])
        getattr(f, _ATTR).append(param)


def command(name=None, cls=None, **attrs):
    func = None
    if callable(name):
        func = name
        name = None
        assert cls is None, "Use 'command(cls=cls)(callable)' to specify a class."
        assert not attrs, "Use 'command(**kwargs)(callable)' to provide arguments."
    if cls is None:
        cls = Command

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        kw = dict(attrs)
        params = kw.pop("params", None)
        params = list(params) if params is not None else []
        decorated = getattr(f, _ATTR, None)
        if decorated is not None:
            delattr(f, _ATTR)
            params.extend(reversed(decorated))
        if kw.get("help") is None:
            doc = inspect.getdoc(f)
            if doc is not None:
                doc = doc.partition("\f")[0]
            kw["help"] = doc
        cmd_name = name
        if cmd_name is None:
            cmd_name = f.__name__.lower().replace("_", "-")
            left, sep, suffix = cmd_name.rpartition("-")
            if sep and suffix in {"command", "cmd", "group", "grp"}:
                cmd_name = left
        cmd = cls(name=cmd_name, callback=f, params=params, **kw)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(cls=cls, **attrs)(name)
    return command(name, cls, **attrs)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)


def _guess_package(depth=2):
    try:
        frame = sys._getframe(depth)
        mod = frame.f_globals.get("__name__")
        if mod:
            return mod.partition(".")[0]
    except Exception:
        pass
    return None


def _lookup_version(package_name):
    import importlib.metadata as md
    try:
        return md.version(package_name)
    except md.PackageNotFoundError:
        pass
    try:
        dists = md.packages_distributions().get(package_name)
    except Exception:
        dists = None
    if dists:
        try:
            return md.version(dists[0])
        except md.PackageNotFoundError:
            pass
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        package_name = _guess_package(2)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        package_version = version
        if package_version is None:
            if package_name is None:
                raise RuntimeError("Could not determine the package to detect its version.")
            package_version = _lookup_version(package_name)
            if package_version is None:
                raise RuntimeError(f"{package_name!r} is not installed. "
                                   "Try passing 'package_name' instead.")
        echo(message % {"prog": prog_name or ctx.find_root().info_name,
                        "package": package_name, "version": package_version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)
