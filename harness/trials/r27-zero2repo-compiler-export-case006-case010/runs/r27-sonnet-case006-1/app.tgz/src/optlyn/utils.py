"""Echo, styling and file helpers."""
import io
import os
import re
import sys
import tempfile

from .exceptions import FileError
from .globals_ import resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError):
    """Invalid color value."""


def strip_ansi(value):
    return _ansi_re.sub("", value)


def unstyle(text):
    """Remove ANSI styling sequences from text."""
    return strip_ansi(text)


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Color out of range: {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool)
                                      and 0 <= c <= 255 for c in color):
            raise ColorError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    try:
        return str(_ansi_colors[color] + offset)
    except (KeyError, TypeError):
        raise ColorError(f"Unknown color {color!r}") from None


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences."""
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24),
                         (overline, 53, 55), (italic, 3, 23), (blink, 5, 25),
                         (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def _is_ascii_encoding(enc):
    if not enc:
        return False
    try:
        import codecs
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write message to stdout/stderr/file, handling styles and encodings."""
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    color = resolve_color_default(color)
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    if _is_ascii_encoding(getattr(file, "encoding", None)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
        out = out.encode("ascii", "backslashreplace").decode("ascii")
    file.write(out)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    """Make a filename printable and strictly UTF-8 encodable."""
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, (bytes, bytearray)):
        filename = bytes(filename).decode(sys.getfilesystemencoding() or "utf-8",
                                          "surrogateescape")
    if shorten and isinstance(filename, bytes):
        filename = filename.decode("utf-8", "surrogateescape")
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name, roaming=True, force_posix=False):
    plat = sys.platform

    def posixify(name):
        return "-".join(name.split()).lower()

    if plat.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + posixify(app_name))
    if plat == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, posixify(app_name))


# ---------------------------------------------------------------- file helpers

class _NonClosingText(io.TextIOWrapper):
    def close(self):
        try:
            self.flush()
        except Exception:
            pass

    def __del__(self):
        pass


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    """Open a file or '-' ; returns (stream, should_close)."""
    if isinstance(filename, (bytes, bytearray)):
        is_dash = bytes(filename) == b"-"
    else:
        is_dash = os.fspath(filename) == "-"
    if is_dash:
        if "w" in mode:
            std = sys.stdout
            if "b" in mode:
                return (getattr(std, "buffer", std), False)
            if encoding is not None and hasattr(std, "buffer"):
                std.flush()
                return (_NonClosingText(std.buffer, encoding=encoding, errors=errors,
                                        write_through=True), False)
            return (std, False)
        std = sys.stdin
        if "b" in mode:
            return (getattr(std, "buffer", std), False)
        if encoding is not None and hasattr(std, "buffer"):
            return (_NonClosingText(std.buffer, encoding=encoding, errors=errors), False)
        return (std, False)
    if not atomic:
        kw = {} if "b" in mode else {"encoding": encoding, "errors": errors}
        return (open(filename, mode, **kw), True)
    if "r" in mode or "x" in mode or "a" in mode or "w" not in mode:
        if "r" in mode and "+" not in mode:
            kw = {} if "b" in mode else {"encoding": encoding, "errors": errors}
            return (open(filename, mode, **kw), True)
        raise ValueError("Atomic writes only make sense with 'w'-mode.")
    real = os.fspath(filename)
    if isinstance(real, bytes):
        real = os.fsdecode(real)
    d = os.path.dirname(os.path.abspath(real))
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".__atomic-write")
    kw = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    f = open(fd, mode, **kw)
    return (_AtomicFile(f, tmp, real), True)


class _AtomicFile:
    def __init__(self, f, tmp, real):
        self._f = f
        self._tmp = tmp
        self._real = real
        self.closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.remove(self._tmp)
            except OSError:
                pass
        else:
            os.replace(self._tmp, self._real)
        self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


class LazyFile:
    """File that opens on first use."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file {format_filename(self.name)!r} {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file (or '-' for a standard stream)."""
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_binary_stream(name):
    s = getattr(sys, name)
    return getattr(s, "buffer", s)


def get_text_stream(name, encoding=None, errors="strict"):
    return getattr(sys, name)
