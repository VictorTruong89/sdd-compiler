"""Thread-local stack of invocation contexts."""
import threading

_local = threading.local()


def push_context(ctx):
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context():
    _local.stack.pop()


def get_current_context(silent=False):
    """Return the context current on the calling thread."""
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError):
        if not silent:
            raise RuntimeError("There is no active context.") from None
    return None


def resolve_color_default(color=None):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None
