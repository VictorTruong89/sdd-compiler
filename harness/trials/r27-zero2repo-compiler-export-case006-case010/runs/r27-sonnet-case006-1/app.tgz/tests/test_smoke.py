import optlyn as o
from optlyn.testing import CliRunner


def test_group_help_and_run():
    @o.group()
    def cli():
        """Top."""

    @cli.command()
    @o.option("-n", type=int, default=2)
    def sub(n):
        o.echo(f"n={n}")

    r = CliRunner()
    assert r.invoke(cli, ["--help"]).exit_code == 0
    assert r.invoke(cli, []).exit_code == 2
    res = r.invoke(cli, ["sub", "-n", "5"])
    assert res.exit_code == 0 and "n=5" in res.output
    assert r.invoke(cli, ["nope"]).exit_code == 2


def test_clamp_and_choice():
    t = o.IntRange(1, 5, clamp=True)
    assert t.convert("9") == 5
    c = o.Choice(["a", "B"], case_sensitive=False)
    assert c.convert("b") == "B"
