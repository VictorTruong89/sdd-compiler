from lingora import metrics, tokenize
from lingora.tree import Tree


def test_wordpunct():
    assert tokenize.wordpunct_tokenize("Hi, you!") == ["Hi", ",", "you", "!"]


def test_metrics():
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.f_measure({1}, {2}) is None


def test_tree():
    assert Tree.fromstring("(S (NP a))") == Tree("S", [Tree("NP", ["a"])])
