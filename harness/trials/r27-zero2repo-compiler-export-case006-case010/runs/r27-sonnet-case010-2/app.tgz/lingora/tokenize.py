"""Tokenizers.  # spec: N-000403"""
import os
import re

from . import data

# --------------------------------------------------------------------------
# simple tokenizers


class RegexpTokenizer:
    # spec: N-000116 N-000117 N-000118 N-000407 (discard_empty off by default)
    def __init__(self, pattern, gaps=False, discard_empty=False, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        return self._regexp.findall(text) if self._regexp.groups == 0 else \
            [m.group() for m in self._regexp.finditer(text)]

    def span_tokenize(self, text):
        if self._gaps:
            for left, right in _spans_from_gaps(self._regexp, text):
                if not self._discard_empty or right > left:
                    yield left, right
        else:
            for m in self._regexp.finditer(text):
                yield m.span()


def _spans_from_gaps(regexp, text):
    last = 0
    for m in regexp.finditer(text):
        yield last, m.start()
        last = m.end()
    yield last, len(text)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True, discard_empty=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True, discard_empty=True)


_wordpunct = WordPunctTokenizer()
_whitespace = WhitespaceTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# --------------------------------------------------------------------------
# Penn Treebank


class _PTB:
    CONTRACTIONS2 = [r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
                     r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
                     r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)"]
    CONTRACTIONS3 = [r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b"]


def _compile(pairs):
    return [(re.compile(a), b) for a, b in pairs]


_PARENS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
_DASHES = (re.compile(r"--"), r" -- ")

_PTB_START = _compile([
    (r"^\"", r"``"),
    (r"(``)", r" \1 "),
    (r"([ \(\[{<])(\"|\'{2})", r"\1 `` "),
])
_PTB_PUNCT = _compile([
    (r"([:,])([^\d])", r" \1 \2"),
    (r"([:,])$", r" \1 "),
    (r"\.\.\.", r" ... "),
    (r"[;@#$%&]", r" \g<0> "),
    (r'([^\.])(\.)([\]\)}>"\']*)\s*$', r"\1 \2 \3 "),
    (r"[?!]", r" \g<0> "),
    (r"([^'])' ", r"\1 ' "),
])
_END_QUOTES = _compile([
    (r'"', " '' "),
    (r"(\S)(\'\')", r"\1 \2 "),
    (r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 "),
    (r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 "),
])

# improved variant
_NLTK_START = _compile([
    (r"([«“‘„]|[`]+)", r" \1 "),
    # spec: N-000106 -- a straight double quote at the very start becomes the closing token
    (r"^\"", r" '' "),
    (r"(``)", r" \1 "),
    (r"([ \(\[{<])(\"|\'{2})", r"\1 `` "),
    (r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", r"\1 \2"),
])
_NLTK_PUNCT = _compile([
    (r"([^\.])(\.)([\]\)}>\"\']*)\s*$", r"\1 \2 \3 "),
    (r"([:,])([^\d])", r" \1 \2"),
    (r"([:,])$", r" \1 "),
    (r"\.{2,}", r" \g<0> "),
    (r"[;@#$%&]", r" \g<0> "),
    (r"[?!]", r" \g<0> "),
    (r"([^'])' ", r"\1 ' "),
    (r"[*]", r" \g<0> "),
    (r"[‒-―]", r" \g<0> "),
    (r"[»”’]", r" \g<0> "),
])
_NLTK_ENDING = _compile([
    (r'"', " '' "),
    (r"(\S)(\'\')", r"\1 \2 "),
    (r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 "),
    (r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 "),
])


def _ptb_tokenize(text, start, punct, ending, c2):
    for rx, sub in start:
        text = rx.sub(sub, text)
    for rx, sub in punct:
        text = rx.sub(sub, text)
    text = _PARENS[0].sub(_PARENS[1], text)
    text = _DASHES[0].sub(_DASHES[1], text)
    text = " " + text + " "
    for rx, sub in ending:
        text = rx.sub(sub, text)
    for pat in c2:
        text = re.sub(pat, r" \1 \2 ", text)
    for pat in _PTB.CONTRACTIONS3:
        text = re.sub(pat, r" \1 \2 ", text)
    return text.split()


class TreebankWordTokenizer:
    def tokenize(self, text):
        return _ptb_tokenize(text, _PTB_START, _PTB_PUNCT, _END_QUOTES, _PTB.CONTRACTIONS2)


class _ImprovedWordTokenizer:
    # spec: N-000110 cannot kept as one token
    def tokenize(self, text):
        return _ptb_tokenize(text, _NLTK_START, _NLTK_PUNCT, _NLTK_ENDING, _PTB.CONTRACTIONS2[1:])


_improved = _ImprovedWordTokenizer()


# --------------------------------------------------------------------------
# Tweet tokenizer

_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]                     # eyes
      [\-o\*\']?                 # optional nose
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      [\-o\*\']?                 # optional nose
      [:;=8]                     # eyes
      [<>]?
      |
      </?3                       # heart
    )"""
_URLS = r"""(?:https?:(?:/{1,3}|[a-z0-9%])|[a-z0-9.\-]+[.](?:[a-z]{2,13})/)(?:[^\s()<>{}\[\]]+|\([^\s()]*?\([^\s()]+\)[^\s()]*?\)|\([^\s]+?\))+(?:\([^\s()]*?\([^\s()]+\)[^\s()]*?\)|\([^\s]+?\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’])|(?:(?<!@)[a-z0-9]+(?:[.\-][a-z0-9]+)*[.](?:[a-z]{2,13})\b/?(?!@))"""
_PHONE = r"""(?:(?:\+?[01][ *\-.\)]*)?(?:[\(]?\d{3}[ *\-.\)]*)?\d{3}[ *\-.\)]*\d{4})"""
_WORDS = [
    _URLS,
    _PHONE,
    _EMOTICONS,
    r"<[^>\s]+>",
    r"[\-]+>|<[\-]+",
    r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_]",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"\.(?:\s*\.){1,}",
    r"(?:\S)",
]
_WORD_RE = re.compile("(%s)" % "|".join(_WORDS), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANDLE_RE = re.compile(r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){1,15})(?![A-Za-z0-9_]*@)")
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False, match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if self.reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.DOTALL)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        text = text.replace("&amp;", "&") if False else text
        words = _WORD_RE.findall(text)
        words = [w[0] if isinstance(w, tuple) else w for w in words]
        if not self.preserve_case:
            # spec: N-000125 -- emoticons keep their case
            words = [w if _EMOTICON_RE.fullmatch(w) else w.lower() for w in words]
        return words


# --------------------------------------------------------------------------
# Punkt

_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_UC = 14
_ORTHO_LC = 112

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_TOK_RE = re.compile(
    r"""(?:
        %(M)s
        |
        (?=%(WS)s)\S+?
        (?=
            \s|
            $|
            %(NW)s|%(M)s|
            ,(?=$|\s|%(NW)s|%(M)s)
        )
        |
        \S
    )""" % {"M": _MULTI, "WS": _WORDSTART, "NW": _NONWORD}, re.UNICODE | re.VERBOSE)
_PERIOD_RE = re.compile(
    r"""[.?!]
    (?=(?P<after_tok>
        %s
        |
        \s+(?P<next_tok>\S+)
    ))""" % _NONWORD, re.UNICODE | re.VERBOSE)
_REALIGN_RE = re.compile(r"""["\')\]}]+?(?:\s+|(?=--)|$)""", re.UNICODE)
_NUMERIC_RE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS_RE = re.compile(r"^\.\.+$")
_INITIAL_RE = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_ALPHA_RE = re.compile(r"^[^\W\d]+$", re.UNICODE)
_NONPUNCT_RE = re.compile(r"[^\W\d]", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "type", "period_final", "sentbreak", "abbr", "ellipsis",
                 "first_upper", "first_lower", "type_no_period", "type_no_sentperiod",
                 "is_initial")

    def __init__(self, tok):
        self.tok = tok
        self.type = "##number##" if _NUMERIC_RE.match(tok) else tok.lower()
        self.period_final = tok.endswith(".")
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.first_upper = bool(tok) and tok[0].isupper()
        self.first_lower = bool(tok) and tok[0].islower()
        self.type_no_period = self.type[:-1] if len(self.type) > 1 and self.type[-1] == "." else self.type
        self.type_no_sentperiod = self.type_no_period
        self.is_initial = bool(_INITIAL_RE.match(tok))


class _PunktParams:
    def __init__(self, abbrev, starters, colloc, ortho):
        self.abbrev_types = abbrev
        self.sent_starters = starters
        self.collocations = colloc
        self.ortho_context = ortho


_param_cache = {}


def _load_params(language):
    d = data.require("tokenizers/punkt_tab/%s" % language)
    files = ["abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"]
    key = [d]
    for f in files:
        p = os.path.join(d, f)
        if not os.path.isfile(p):
            raise LookupError("Punkt model file missing: %s" % p)
        st = os.stat(p)
        key.append((st.st_mtime_ns, st.st_size))
    key = tuple(key)
    if key in _param_cache:
        return _param_cache[key]

    def lines(f):
        return data.read_lines(os.path.join(d, f))

    abbrev = set(l for l in lines(files[0]) if l != "")
    starters = set(l for l in lines(files[1]) if l != "")
    colloc = set()
    for l in lines(files[2]):
        parts = l.split("\t")
        if len(parts) >= 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for l in lines(files[3]):
        parts = l.split("\t")
        if len(parts) >= 2:
            ortho[parts[0]] = int(parts[1])
    params = _PunktParams(abbrev, starters, colloc, ortho)
    _param_cache.clear()
    _param_cache[key] = params
    return params


class _Punkt:
    def __init__(self, params):
        self.p = params

    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = _WORD_TOK_RE.findall(line)
                if not toks:
                    continue
                for t in toks:
                    yield _Tok(t)
                parastart = False
            else:
                parastart = True

    def _first_pass(self, t):
        tok = t.tok
        if tok in (".", "?", "!"):
            t.sentbreak = True
        elif _ELLIPSIS_RE.match(tok):
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            if tok[:-1].lower() in self.p.abbrev_types or \
                    tok[:-1].lower().split("-")[-1] in self.p.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True
        t.type_no_sentperiod = t.type_no_period if t.sentbreak else t.type

    def _ortho(self, t):
        if t.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self.p.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self.p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            s = self._ortho(t2)
            if s is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            s = self._ortho(t2)
            if s is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if s == "unknown" and initial and t2.first_upper and \
                    not (self.p.ortho_context.get(next_typ, 0) & _ORTHO_LC):
                t1.sentbreak = False
                t1.abbr = True

    def _contains_break(self, context):
        toks = list(self._tokenize_words(context))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = -1
            for i in range(len(before) - 1, -1, -1):
                if before[i].isspace():
                    idx = i
                    break
            if idx > 0 or (idx == 0 and False):
                start = idx + prev_slice[1] + 1
            elif idx == 0:
                # NLTK treats index 0 as falsy
                start = prev_slice[0]
            else:
                start = prev_slice[0]
            cur = (start, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + \
                    prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + \
                prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for m, ctx in self._contexts(text):
            if self._contains_break(ctx):
                yield (last, m.end())
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        yield (last, len(text.rstrip()))

    def sentences(self, text):
        slices = list(self._slices(text))
        out = []
        realign = 0
        for i, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            if i + 1 >= len(slices):
                if text[s1[0]:s1[1]]:
                    out.append(text[s1[0]:s1[1]])
                continue
            s2 = slices[i + 1]
            m = _REALIGN_RE.match(text[s2[0]:s2[1]])
            if m:
                out.append(text[s1[0]:s2[0] + len(m.group(0).rstrip())])
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    out.append(text[s1[0]:s1[1]])
        return out


def sent_tokenize(text, language="english"):
    params = _load_params(language)
    return _Punkt(params).sentences(text)


def word_tokenize(text, language="english", preserve_line=False):
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    out = []
    for s in sentences:
        out.extend(_improved.tokenize(s))
    return out
