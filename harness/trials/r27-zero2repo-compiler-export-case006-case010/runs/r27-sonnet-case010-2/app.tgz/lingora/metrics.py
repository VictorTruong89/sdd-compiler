"""Evaluation metrics.  # spec: N-000498"""


def accuracy(reference, test):
    # spec: N-000502 N-000343 N-000318 (different lengths raise)
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("reference and test must be lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if not reference:
        return 0.0
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    # spec: N-000503 N-000504 N-000505 N-000506 (adjacent-only transposition)
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + sub)
            if (transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2]
                    and s1[i - 2] == s2[j - 1]):
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def jaccard_distance(label1, label2):
    union = len(label1.union(label2))
    if union == 0:
        return 0.0
    return (union - len(label1.intersection(label2))) / union


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test should be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        # spec: N-000346 (disjoint sets give no number)
        return None
    return 1.0 / (alpha / p + (1 - alpha) / r)
