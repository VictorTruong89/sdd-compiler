"""Command line.  # spec: N-000414"""
import sys

from . import tokenize as _tok


class UsageError(Exception):
    pass


def _read_stdin(encoding):
    stream = sys.stdin
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf.read().decode(encoding)
    text = stream.read()
    return text if isinstance(text, str) else text.decode(encoding)


def _write(text, encoding):
    out = sys.stdout
    enc = (getattr(out, "encoding", None) or "").lower().replace("-", "")
    if enc == encoding.lower().replace("-", "") or getattr(out, "buffer", None) is None:
        out.write(text)
        out.flush()
    else:
        out.flush()
        out.buffer.write(text.encode(encoding))
        out.buffer.flush()


def _tokenize_command(argv):
    language, delimiter, encoding = "english", " ", "utf-8"
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding") and i + 1 < len(argv):
            v = argv[i + 1]
            if a in ("-l", "--language"):
                language = v
            elif a in ("-d", "--delimiter"):
                delimiter = v
            else:
                encoding = v
            i += 2
        elif a.startswith("--language="):
            language = a.split("=", 1)[1]; i += 1
        elif a.startswith("--delimiter="):
            delimiter = a.split("=", 1)[1]; i += 1
        elif a.startswith("--encoding="):
            encoding = a.split("=", 1)[1]; i += 1
        else:
            raise UsageError("unexpected argument %r" % a)
    text = _read_stdin(encoding)
    for line in text.splitlines():
        toks = _tok.word_tokenize(line, language)
        _write(delimiter.join(toks) + "\n", encoding)


class Group:
    def __init__(self):
        self.commands = {"tokenize": _tokenize_command}

    def main(self, args=None, standalone_mode=True, **kwargs):
        # spec: N-000417 N-000418 N-000419
        argv = list(sys.argv[1:] if args is None else args)
        try:
            if not argv or argv[0] in ("-h", "--help"):
                if standalone_mode:
                    sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\n"
                                     "Commands:\n  tokenize  Tokenize text from stdin, one line per line.\n")
                    sys.exit(0)
                return None
            cmd = self.commands.get(argv[0])
            if cmd is None:
                raise UsageError("No such command %r." % argv[0])
            cmd(argv[1:])
        except SystemExit:
            raise
        except BaseException as e:
            if not standalone_mode:
                raise
            if isinstance(e, KeyboardInterrupt):
                sys.stderr.write("Aborted!\n")
                sys.exit(1)
            sys.stderr.write("Error: %s\n" % (e,))
            sys.exit(2 if isinstance(e, UsageError) else 1)
        if standalone_mode:
            sys.exit(0)
        return None

    __call__ = main


cli = Group()


if __name__ == "__main__":
    cli.main()
