"""BLEU.  # spec: N-000499 N-000500"""
import math
import sys
from collections import Counter


class Fraction:
    """Unnormalised fraction (numerator / denominator)."""

    def __init__(self, numerator, denominator):
        self.numerator = numerator
        self.denominator = denominator

    def __float__(self):
        return self.numerator / self.denominator

    def __truediv__(self, o):
        return float(self) / o

    def __rtruediv__(self, o):
        return o / float(self)


class SmoothingFunction:
    """A few smoothing methods; each takes (p_n, references, hypothesis, hyp_len)."""

    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method0(self, p_n, references=None, hypothesis=None, hyp_len=None):
        return [p if p.numerator != 0 else sys.float_info.min for p in p_n]

    def method1(self, p_n, references=None, hypothesis=None, hyp_len=None):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p
                for p in p_n]

    def method2(self, p_n, references=None, hypothesis=None, hyp_len=None):
        return [Fraction(p.numerator + 1, p.denominator + 1) if i != 0 else p
                for i, p in enumerate(p_n)]


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    clipped = {g: min(c, max_counts.get(g, 0)) for g, c in counts.items()}
    return sum(clipped.values()), max(1, sum(counts.values()))


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    weights = tuple(weights)
    num = {}
    den = {}
    for i in range(1, len(weights) + 1):
        num[i], den[i] = _modified_precision(references, hypothesis, i)
    hyp_len = len(hypothesis)
    ref_lens = (len(r) for r in references)
    closest = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > closest:
        bp = 1
    elif hyp_len == 0:
        bp = 0
    else:
        bp = math.exp(1 - closest / hyp_len)
    if num.get(1, 0) == 0:
        return 0
    p_n = [Fraction(num[i], den[i]) for i in range(1, len(weights) + 1)]
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    s = math.fsum(w * math.log(float(p)) for w, p in zip(weights, p_n))
    return bp * math.exp(s)
