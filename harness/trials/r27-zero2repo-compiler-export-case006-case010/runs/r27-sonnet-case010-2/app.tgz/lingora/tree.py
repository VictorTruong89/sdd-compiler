"""Constituent trees.  # spec: N-000481"""


class Tree(list):
    def __init__(self, label, children):
        if isinstance(children, str) or not isinstance(children, (list, tuple)):
            raise TypeError("children should be a list, not %s" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees(filter)

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def copy(self, deep=False):
        import copy as _c
        return _c.deepcopy(self) if deep else Tree(self._label, list(self))

    def productions(self):
        return [(self._label, tuple(c._label if isinstance(c, Tree) else c for c in self))]

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def pformat(self, margin=70, indent=0):
        flat = self._flat()
        if len(flat) + indent < margin:
            return flat
        s = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            else:
                s += "\n" + " " * (indent + 2) + str(c)
        return s + ")"

    def _flat(self):
        parts = []
        for c in self:
            parts.append(c._flat() if isinstance(c, Tree) else str(c))
        return "(%s%s)" % (self._label, (" " + " ".join(parts)) if parts else "")

    def pprint(self, **kw):
        print(self.pformat(**kw))

    def pretty_print(self, **kw):
        print(self.pformat(**kw))

    @classmethod
    def fromstring(cls, s, brackets="()"):
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        op, cl = brackets
        import re
        tokens = re.findall(r"%s|%s|[^\s%s%s]+" % (re.escape(op), re.escape(cl),
                                                     re.escape(op), re.escape(cl)), s)
        if not tokens:
            raise ValueError("empty tree text")
        pos = 0

        def parse():
            nonlocal pos
            if tokens[pos] != op:
                raise ValueError("expected %r" % op)
            pos += 1
            if pos < len(tokens) and tokens[pos] not in (op, cl):
                label = tokens[pos]
                pos += 1
            else:
                label = ""
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced brackets in tree text")
                t = tokens[pos]
                if t == cl:
                    pos += 1
                    return cls(label, children)
                if t == op:
                    children.append(parse())
                else:
                    children.append(t)
                    pos += 1

        t = parse()
        if pos != len(tokens):
            raise ValueError("extra text after tree")
        return t
