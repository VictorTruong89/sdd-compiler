"""Regexp stemmer, WordNet lemmatizer, Arabic light stemmers."""
import os
import re

from .. import data


class RegexpStemmer:
    # spec: N-000178 N-000179 N-000180
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


_SUBST = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    # spec: N-000432 -- raises at construction when WordNet is missing
    def __init__(self):
        root = data.require("corpora/wordnet")
        if not os.path.isdir(root):
            raise LookupError("WordNet resource is not a directory: %s" % root)
        self._lemmas = {}
        self._exc = {}
        for pos, name in _FILES.items():
            lemmas = set()
            idx = os.path.join(root, "index." + name)
            if os.path.isfile(idx):
                with open(idx, encoding="utf-8") as f:
                    for line in f:
                        if line.startswith(" ") or not line.strip():
                            continue
                        lemmas.add(line.split(" ", 1)[0])
            elif not os.path.isdir(root):
                raise LookupError("WordNet index missing")
            self._lemmas[pos] = lemmas
            exc = {}
            ep = os.path.join(root, name + ".exc")
            if os.path.isfile(ep):
                with open(ep, encoding="utf-8") as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 2:
                            exc[parts[0]] = parts[1:]
            self._exc[pos] = exc
        if not any(self._lemmas.values()) and not any(self._exc.values()):
            raise LookupError("WordNet resource holds no index files: %s" % root)

    def _morphy(self, form, pos):
        lemmas = self._lemmas[pos]
        subs = _SUBST[pos]

        def apply(forms):
            return [f[:len(f) - len(o)] + n for f in forms for o, n in subs if f.endswith(o)]

        def filt(forms):
            res = []
            for f in forms:
                if f in lemmas and f not in res:
                    res.append(f)
            return res

        if form in self._exc[pos]:
            return filt([form] + self._exc[pos][form])
        forms = apply([form])
        results = filt([form] + forms)
        if results:
            return results
        while forms:
            forms = apply(forms)
            results = filt(forms)
            if results:
                return results
        return []

    def lemmatize(self, word, pos="n"):
        if pos not in _FILES:
            raise ValueError("unknown part of speech %r" % (pos,))
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word


class ARLSTem:
    """Light Arabic stemmer (results outside the specification)."""
    _prefixes = ["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل"]
    _suffixes = ["ات", "ون", "ين", "ان", "ها", "ية", "ة", "ه", "ي", "ك", "ا"]

    def stem(self, word):
        w = re.sub(r"[ً-ْـ]", "", word)
        w = re.sub("[إأآ]", "ا", w)
        for p in self._prefixes:
            if w.startswith(p) and len(w) - len(p) >= 2:
                w = w[len(p):]
                break
        for s in self._suffixes:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass
