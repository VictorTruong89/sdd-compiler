"""Snowball stemmers.  # spec: N-000172 N-000428

English (Porter2), porter, german, dutch, swedish, norwegian, danish, russian,
spanish, french, italian and portuguese follow the published Snowball
algorithms; finnish, hungarian, romanian and arabic are lighter approximations.
"""
import os

from .. import data
from .porter import PorterStemmer

SUPPORTED = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
             "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
             "russian", "spanish", "swedish")


def _longest(word, sufs):
    best = None
    for s in sufs:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def _r1r2(word, vowels, min_r1=0):
    def region(start):
        for i in range(start + 1, len(word)):
            if word[i] not in vowels and word[i - 1] in vowels:
                return i + 1
        return len(word)
    r1 = region(0)
    r1 = max(r1, min_r1) if min_r1 and r1 < len(word) else r1
    r2 = len(word)
    if r1 < len(word):
        r2 = region(r1 - 1) if r1 > 0 else region(0)
        # region(r1-1) scans from r1: need a non-vowel after a vowel within [r1:]
        r2 = len(word)
        for i in range(r1 + 1, len(word)):
            if word[i] not in vowels and word[i - 1] in vowels:
                r2 = i + 1
                break
    return r1, r2


class _Base:
    vowels = ""

    def stem(self, word):
        raise NotImplementedError


# ---------------------------------------------------------------- English
class EnglishStemmer(_Base):
    vowels = "aeiouy"
    _exc1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
             "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
             "only": "onli", "singly": "singl", "sky": "sky", "news": "news", "howe": "howe",
             "atlas": "atlas", "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    _exc2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}

    def _short_syl(self, w, i=None):
        # does w end (at length i) with a short syllable
        if i is None:
            i = len(w)
        v = self.vowels
        if i == 2:
            return w[0] in v and w[1] not in v
        if i >= 3:
            return (w[i - 3] not in v and w[i - 2] in v and w[i - 1] not in v + "wxY")
        return False

    def stem(self, word):
        word = word.lower()
        if len(word) <= 2:
            return word
        if word in self._exc1:
            return self._exc1[word]
        if word.startswith("'"):
            word = word[1:]
        v = self.vowels
        chars = list(word)
        if chars and chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i] == "y" and chars[i - 1] in v:
                chars[i] = "Y"
        w = "".join(chars)
        # regions
        r1 = len(w)
        for pre in ("gener", "commun", "arsen"):
            if w.startswith(pre):
                r1 = len(pre)
                break
        else:
            for i in range(1, len(w)):
                if w[i] not in v and w[i - 1] in v:
                    r1 = i + 1
                    break
        r2 = len(w)
        for i in range(r1 + 1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                r2 = i + 1
                break

        def regions(w):
            return min(r1, len(w)), min(r2, len(w))

        # step 0
        for s in ("'s'", "'s", "'"):
            if w.endswith(s):
                w = w[:-len(s)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith("ied") or w.endswith("ies"):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith("us") or w.endswith("ss"):
            pass
        elif w.endswith("s"):
            if any(c in v for c in w[:-2]):
                w = w[:-1]
        if w in self._exc2:
            return w.replace("Y", "y")
        # step 1b
        a, b = regions(w)
        s = _longest(w, ("eedly", "eed", "ingly", "edly", "ing", "ed"))
        if s in ("eed", "eedly"):
            if len(w) - len(s) >= a:
                w = w[:-len(s)] + "ee"
        elif s:
            base = w[:-len(s)]
            if any(c in v for c in base):
                w = base
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                    w = w[:-1]
                elif self._short_word(w, r1 if False else None):
                    w += "e"
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in v:
            w = w[:-1] + "i"
        a, b = self._rr(w)
        # step 2
        s2 = ["ization", "ational", "fulness", "ousness", "iveness", "tional", "biliti", "lessli",
              "entli", "ation", "alism", "aliti", "ousli", "iviti", "fulli", "enci", "anci",
              "abli", "izer", "ator", "alli", "bli", "ogi", "li"]
        s = _longest(w, s2)
        if s and len(w) - len(s) >= a:
            base = w[:-len(s)]
            rep = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able",
                   "entli": "ent", "izer": "ize", "ization": "ize", "ational": "ate",
                   "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al", "alli": "al",
                   "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive",
                   "iviti": "ive", "biliti": "ble", "bli": "ble", "fulli": "ful",
                   "lessli": "less"}
            if s == "ogi":
                if base.endswith("l"):
                    w = base + "og"
            elif s == "li":
                if base and base[-1] in "cdeghkmnrt":
                    w = base
            else:
                w = base + rep[s]
        a, b = self._rr(w)
        # step 3
        s = _longest(w, ["ational", "tional", "alize", "icate", "iciti", "ative", "ical",
                         "ness", "ful"])
        if s and len(w) - len(s) >= a:
            base = w[:-len(s)]
            if s == "ative":
                if len(w) - len(s) >= b:
                    w = base
            else:
                w = base + {"ational": "ate", "tional": "tion", "alize": "al", "icate": "ic",
                            "iciti": "ic", "ical": "ic", "ness": "", "ful": ""}[s]
        a, b = self._rr(w)
        # step 4
        s = _longest(w, ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism",
                         "ate", "iti", "ous", "ive", "ize", "ion", "al", "er", "ic"])
        if s and len(w) - len(s) >= b:
            base = w[:-len(s)]
            if s == "ion":
                if base.endswith(("s", "t")):
                    w = base
            else:
                w = base
        a, b = self._rr(w)
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= b or (len(w) - 1 >= a and not self._short_syl(w[:-1])):
                w = w[:-1]
        elif w.endswith("l"):
            if len(w) - 1 >= b and w.endswith("ll"):
                w = w[:-1]
        return w.replace("Y", "y")

    def _rr(self, w):
        v = self.vowels
        r1 = len(w)
        for pre in ("gener", "commun", "arsen"):
            if w.startswith(pre):
                r1 = len(pre)
                break
        else:
            for i in range(1, len(w)):
                if w[i] not in v and w[i - 1] in v:
                    r1 = i + 1
                    break
        r2 = len(w)
        for i in range(r1 + 1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                r2 = i + 1
                break
        return r1, r2

    def _short_word(self, w, _):
        a, _b = self._rr(w)
        return a >= len(w) and self._short_syl(w)


class PorterSnowball(_Base):
    def __init__(self):
        self._p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        return self._p.stem(word.lower())


# ---------------------------------------------------------------- German
class GermanStemmer(_Base):
    vowels = "aeiouyäöü"

    def stem(self, word):
        word = word.lower().replace("ß", "ss")
        v = self.vowels
        ch = list(word)
        for i in range(1, len(ch) - 1):
            if ch[i - 1] in v and ch[i + 1] in v:
                if ch[i] == "u":
                    ch[i] = "U"
                elif ch[i] == "y":
                    ch[i] = "Y"
        w = "".join(ch)
        r1, r2 = _r1r2(w, v, 3)
        # step 1
        s = _longest(w, ["ern", "em", "er", "en", "es", "e", "s"])
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s == "s":
                if base and base[-1] in "bdfghklmnrt":
                    w = base
            else:
                w = base
                if s in ("en", "es", "e") and w.endswith("niss"):
                    w = w[:-1]
        # step 2
        s = _longest(w, ["est", "en", "er", "st"])
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s == "st":
                if base and base[-1] in "bdfghklmnt" and len(base) >= 4:
                    w = base
            else:
                w = base
        # step 3
        s = _longest(w, ["keit", "heit", "lich", "isch", "end", "ung", "ig", "ik"])
        if s and len(w) - len(s) >= r2:
            base = w[:-len(s)]
            if s in ("end", "ung"):
                w = base
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
            elif s in ("ig", "ik", "isch"):
                if not base.endswith("e"):
                    w = base
            elif s in ("lich", "heit"):
                w = base
                t = _longest(w, ["er", "en"])
                if t and len(w) - len(t) >= r1:
                    w = w[:-len(t)]
            elif s == "keit":
                w = base
                t = _longest(w, ["lich", "ig"])
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
        w = w.replace("U", "u").replace("Y", "y")
        return w.translate(str.maketrans("äöü", "aou"))


# ---------------------------------------------------------------- Dutch
class DutchStemmer(_Base):
    vowels = "aeiouyè"

    def _undouble(self, w):
        if w.endswith(("kk", "dd", "tt")):
            return w[:-1]
        return w

    def stem(self, word):
        word = word.lower()
        word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
        v = self.vowels
        if not word:
            return word
        ch = list(word)
        if ch[0] == "y":
            ch[0] = "Y"
        for i in range(1, len(ch)):
            if ch[i - 1] in v:
                if ch[i] == "y":
                    ch[i] = "Y"
                elif ch[i] == "i" and i + 1 < len(ch) and ch[i + 1] in v:
                    ch[i] = "I"
        w = "".join(ch)
        r1, r2 = _r1r2(w, v, 3)
        # step 1
        if w.endswith("heden") and len(w) - 5 >= r1:
            w = w[:-5] + "heid"
        else:
            s = _longest(w, ["ene", "en", "se", "s"])
            if s and len(w) - len(s) >= r1:
                base = w[:-len(s)]
                if s in ("en", "ene"):
                    if base and base[-1] not in v and not base.endswith("gem"):
                        w = self._undouble(base)
                else:
                    if base and base[-1] not in v and base[-1] != "j":
                        w = base
        # step 2
        e_ending = False
        if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] not in v:
            w = self._undouble(w[:-1])
            e_ending = True
        # step 3a
        if w.endswith("heid") and len(w) - 4 >= r2 and not w[:-4].endswith("c"):
            w = w[:-4]
            if w.endswith("en") and len(w) - 2 >= r1 and len(w) > 2 and w[-3] not in v \
                    and not w[:-2].endswith("gem"):
                w = self._undouble(w[:-2])
        # step 3b
        s = _longest(w, ["baar", "lijk", "end", "ing", "bar", "ig"])
        if s:
            base = w[:-len(s)]
            if s in ("end", "ing") and len(base) >= r2:
                w = base
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
                else:
                    w = self._undouble(w)
            elif s == "ig" and len(base) >= r2 and not base.endswith("e"):
                w = base
            elif s == "lijk" and len(base) >= r2:
                w = base
                if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] not in v:
                    w = self._undouble(w[:-1])
            elif s == "baar" and len(base) >= r2:
                w = base
            elif s == "bar" and len(base) >= r2 and e_ending:
                w = base
        # step 4
        if len(w) >= 4 and w[-1] not in v and w[-1] != "I" and w[-2] == w[-3] and \
                w[-2] in "aeou" and w[-4] not in v:
            w = w[:-2] + w[-1]
        return w.replace("I", "i").replace("Y", "y")


# ---------------------------------------------------------------- Scandinavian
def _scand(vowels, w):
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r1 = i + 1
            break
    return max(r1, 3) if r1 < len(w) or len(w) >= 3 and r1 < 3 else r1


class SwedishStemmer(_Base):
    vowels = "aeiouyäåö"

    def stem(self, word):
        w = word.lower()
        v = self.vowels
        r1 = _scand(v, w)
        r1 = min(r1, len(w))
        s = _longest(w, ["heterna", "hetens", "heter", "heten", "anden", "arnas", "ernas", "ornas",
                         "andes", "arens", "andet", "arna", "erna", "orna", "ande", "arne",
                         "aste", "aren", "ades", "erns", "ade", "are", "ern", "ens", "het",
                         "ast", "ad", "en", "ar", "er", "or", "as", "es", "at", "a", "e", "s"])
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s == "s":
                if base and base[-1] in "bcdfghjklmnoprtvy":
                    w = base
            else:
                w = base
        if len(w) - 2 >= r1 and w.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")):
            w = w[:-1]
        if w.endswith("fullt") and len(w) - 5 >= r1 or w.endswith("fullt") and len(w) - 1 >= r1:
            w = w[:-1]
        elif w.endswith("löst") and len(w) - 1 >= r1:
            w = w[:-1]
        else:
            s = _longest(w, ["lig", "els", "ig"])
            if s and len(w) - len(s) >= r1:
                w = w[:-len(s)]
        return w


class NorwegianStemmer(_Base):
    vowels = "aeiouyæåø"

    def stem(self, word):
        w = word.lower()
        v = self.vowels
        r1 = min(_scand(v, w), len(w))
        s = _longest(w, ["hetenes", "hetene", "heten", "heter", "endes", "ande", "ende", "ede",
                         "ane", "ene", "ens", "ers", "ets", "erte", "ert", "ast", "het",
                         "en", "ar", "er", "as", "es", "et", "a", "e", "s"])
        # (a) list per Snowball Norwegian
        a_list = ["a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar",
                  "er", "heter", "as", "es", "edes", "endes", "enes", "hetenes", "ens",
                  "hetens", "ers", "ets", "et", "het", "ast"]
        s = _longest(w, a_list + ["s", "erte", "ert"])
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s in ("erte", "ert"):
                w = base + "er"
            elif s == "s":
                if base and (base[-1] in "bcdfghjlmnoprtvyz" or
                             (base[-1] == "k" and len(base) > 1 and base[-2] not in v)):
                    w = base
            else:
                w = base
        if len(w) - 2 >= r1 and w.endswith(("dt", "vt")):
            w = w[:-1]
        s = _longest(w, ["hetslov", "eleg", "elig", "elov", "slov", "leg", "eig", "lig", "els",
                         "lov", "ig"])
        if s and len(w) - len(s) >= r1:
            w = w[:-len(s)]
        return w


class DanishStemmer(_Base):
    vowels = "aeiouyæåø"

    def stem(self, word):
        w = word.lower()
        v = self.vowels
        r1 = min(_scand(v, w), len(w))
        s = _longest(w, ["erendes", "hedens", "erende", "erens", "erets", "ethed", "endes",
                         "enes", "ernes", "erede", "heden", "heder", "erer", "heds", "ender" if False else "ende",
                         "ered", "eren", "eret", "eres", "ene", "erne", "ere", "ens", "ers",
                         "ets", "hed", "ende", "en", "er", "es", "et", "e", "s"])
        if s and len(w) - len(s) >= r1:
            base = w[:-len(s)]
            if s == "s":
                if base and base[-1] in "abcdfghjklmnoprtvyzå":
                    w = base
            else:
                w = base
        if len(w) - 2 >= r1 and w.endswith(("gd", "dt", "gt", "kt")):
            w = w[:-1]
        if w.endswith("igst") and len(w) - 4 >= r1:
            w = w[:-2]
        s = _longest(w, ["elig", "lig", "els", "ig"])
        if s and len(w) - len(s) >= r1:
            w = w[:-len(s)]
            if len(w) - 2 >= r1 and w.endswith(("gd", "dt", "gt", "kt")):
                w = w[:-1]
        elif w.endswith("løst") and len(w) - 1 >= r1:
            w = w[:-1]
        if len(w) >= r1 + 1 and len(w) >= 2 and w[-1] == w[-2] and w[-1] not in v:
            w = w[:-1]
        return w


# ---------------------------------------------------------------- Russian
class RussianStemmer(_Base):
    vowels = "аеиоуыэюя"
    _pg1 = ("вшись", "вши", "в")
    _pg2 = ("ившись", "ывшись", "ивши", "ывши", "ив", "ыв")
    _refl = ("ся", "сь")
    _adj = ("ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий", "ый",
            "ой", "ем", "им", "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
    _part1 = ("ем", "нн", "вш", "ющ", "щ")
    _part2 = ("ивш", "ывш", "ующ")
    _verb1 = ("ете", "йте", "нно", "ла", "на", "ли", "ем", "ло", "но", "ет", "ют", "ны", "ть",
              "ешь", "й", "л", "н")
    _verb2 = ("ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено",
              "ует", "уют", "ены", "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым",
              "ен", "ят", "ит", "ыт", "ую", "ю")
    _noun = ("иями", "ями", "ами", "иям", "иях", "ией", "ием", "ией", "ие", "ье", "ев", "ов",
             "еи", "ии", "ей", "ой", "ий", "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия",
             "ья", "а", "е", "и", "й", "о", "у", "ы", "ь", "ю", "я")

    def _rm(self, w, rv, sufs, group_a=False):
        s = _longest(w, sufs)
        if s is None:
            return None
        base = w[:-len(s)]
        if len(base) < rv:
            # suffix must lie in RV
            return None
        if group_a:
            if not base or base[-1] not in "ая" or len(base) - 1 < rv - 0 and False:
                return None
        return base

    def stem(self, word):
        w = word.lower().replace("ё", "е")
        v = self.vowels
        rv = len(w)
        for i, c in enumerate(w):
            if c in v:
                rv = i + 1
                break
        r1 = len(w)
        for i in range(1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                r1 = i + 1
                break
        r2 = len(w)
        for i in range(r1 + 1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                r2 = i + 1
                break

        def try_group(w, g1, g2):
            for suf in sorted(g1, key=len, reverse=True):
                if w.endswith(suf) and len(w) - len(suf) >= rv:
                    base = w[:-len(suf)]
                    if base and base[-1] in "ая":
                        return base
            for suf in sorted(g2, key=len, reverse=True):
                if w.endswith(suf) and len(w) - len(suf) >= rv:
                    return w[:-len(suf)]
            return None

        def plain(w, sufs):
            s = _longest(w, sufs)
            if s and len(w) - len(s) >= rv:
                return w[:-len(s)]
            return None

        # step 1
        r = None
        for suf in sorted(self._pg2, key=len, reverse=True):
            pass
        pg = try_group(w, self._pg1, self._pg2)
        # the group1 / group2 distinction: pg1 needs preceding а/я, pg2 doesn't
        if pg is not None:
            w = pg
        else:
            t = plain(w, self._refl)
            if t is not None:
                w = t
            adj = plain(w, self._adj)
            done = False
            if adj is not None:
                w = adj
                p = try_group(w, self._part1, self._part2)
                if p is not None:
                    w = p
                done = True
            if not done:
                vb = try_group(w, self._verb1, self._verb2)
                if vb is not None:
                    w = vb
                    done = True
            if not done:
                nn = plain(w, self._noun)
                if nn is not None:
                    w = nn
        # step 2
        if w.endswith("и") and len(w) - 1 >= rv:
            w = w[:-1]
        # step 3
        for suf in ("ость", "ост"):
            if w.endswith(suf) and len(w) - len(suf) >= r2:
                w = w[:-len(suf)]
                break
        # step 4
        if w.endswith("нн") and len(w) - 1 >= rv:
            w = w[:-1]
        else:
            for suf in ("ейше", "ейш"):
                if w.endswith(suf) and len(w) - len(suf) >= rv:
                    w = w[:-len(suf)]
                    if w.endswith("нн"):
                        w = w[:-1]
                    break
            else:
                if w.endswith("ь") and len(w) - 1 >= rv:
                    w = w[:-1]
        return w


# ---------------------------------------------------------------- Spanish
class SpanishStemmer(_Base):
    vowels = "aeiouáéíóúü"

    def _rv(self, w):
        v = self.vowels
        if len(w) < 2:
            return len(w)
        if w[1] not in v:
            for i in range(2, len(w)):
                if w[i] in v:
                    return i + 1
            return len(w)
        if w[0] in v and w[1] in v:
            for i in range(2, len(w)):
                if w[i] not in v:
                    return i + 1
            return len(w)
        return min(3, len(w))

    def stem(self, word):
        w = word.lower()
        v = self.vowels
        r1, r2 = _r1r2(w, v)
        rv = self._rv(w)
        # step 0
        s = _longest(w, ["selas", "selos", "sela", "selo", "las", "les", "los", "nos", "me", "se",
                         "la", "le", "lo"])
        if s and len(w) - len(s) >= rv:
            base = w[:-len(s)]
            t = _longest(base, ["iéndo", "ándo", "ár", "ér", "ír", "iendo", "ando", "ar", "er",
                                "ir", "yendo"])
            if t and len(base) - len(t) >= rv:
                if t in ("iendo", "ando", "ar", "er", "ir"):
                    w = base
                elif t == "yendo":
                    if base[:-5].endswith("u"):
                        w = base
                else:
                    acc = {"iéndo": "iendo", "ándo": "ando", "ár": "ar", "ér": "er", "ír": "ir"}
                    w = base[:-len(t)] + acc[t]
        # step 1
        removed = False
        s = _longest(w, ["anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able",
                         "ables", "ible", "ibles", "ista", "istas", "oso", "osa", "osos", "osas",
                         "amiento", "amientos", "imiento", "imientos", "adora", "ador", "ación",
                         "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias",
                         "logía", "logías", "ución", "uciones", "encia", "encias", "amente",
                         "mente", "idad", "idades", "iva", "ivo", "ivas", "ivos"])
        if s:
            base = w[:-len(s)]
            pos = len(base)
            if s in ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able",
                     "ables", "ible", "ibles", "ista", "istas", "oso", "osa", "osos", "osas",
                     "amiento", "amientos", "imiento", "imientos"):
                if pos >= r2:
                    w = base
                    removed = True
            elif s in ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes",
                       "ancia", "ancias"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logía", "logías"):
                if pos >= r2:
                    w = base + "log"
                    removed = True
            elif s in ("ución", "uciones"):
                if pos >= r2:
                    w = base + "u"
                    removed = True
            elif s in ("encia", "encias"):
                if pos >= r2:
                    w = base + "ente"
                    removed = True
            elif s == "amente":
                if pos >= r1:
                    w = base
                    removed = True
                    if w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
                    else:
                        t = _longest(w, ["os", "ic", "ad"])
                        if t and len(w) - len(t) >= r2:
                            w = w[:-len(t)]
            elif s == "mente":
                if pos >= r2:
                    w = base
                    removed = True
                    t = _longest(w, ["ante", "able", "ible"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
            elif s in ("idad", "idades"):
                if pos >= r2:
                    w = base
                    removed = True
                    t = _longest(w, ["abil", "ic", "iv"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
            elif s in ("iva", "ivo", "ivas", "ivos"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        if not removed:
            done = False
            s = _longest(w, ["yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes", "ya",
                             "ye", "yo", "yó"])
            if s and len(w) - len(s) >= rv and w[:-len(s)].endswith("u"):
                w = w[:-len(s)]
                done = True
            if not done:
                s = _longest(w, [
                    "aríamos", "eríamos", "iríamos", "iéramos", "iésemos", "aríais", "eríais",
                    "iríais", "arías", "arían", "arías", "aremos", "eremos", "iremos", "ábamos",
                    "áramos", "ásemos", "aréis", "eréis", "iréis", "abais", "arais", "aseis",
                    "íamos", "ierais", "ieseis", "asteis", "isteis", "erían", "erías", "irían",
                    "irías", "aría", "ería", "iría", "ieron", "ieran", "iesen", "iendo", "ando",
                    "aban", "aran", "asen", "arán", "arás", "erán", "erás", "irán", "irás",
                    "ados", "idos", "amos", "imos", "emos", "éis", "áis", "íais", "abas", "adas",
                    "idas", "ías", "aras", "ieras", "ases", "ieses", "aste", "iste", "aron",
                    "ado", "ido", "ían", "ase", "iese", "iera", "aba", "ada", "ida", "ara",
                    "ará", "aré", "erá", "eré", "irá", "iré", "ían", "ías", "ió", "ar", "er",
                    "ir", "as", "ís", "en", "es", "ía", "an", "ad", "ed", "id"])
                if s and len(w) - len(s) >= rv:
                    base = w[:-len(s)]
                    if s in ("en", "es", "éis", "emos"):
                        w = base
                        if w.endswith("gu"):
                            w = w[:-1]
                    else:
                        w = base
        # step 3
        s = _longest(w, ["os", "a", "o", "á", "í", "ó"])
        if s and len(w) - len(s) >= rv:
            w = w[:-len(s)]
        else:
            s = _longest(w, ["e", "é"])
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
                if w.endswith("gu") and len(w) - 1 >= rv:
                    w = w[:-1]
        return w.translate(str.maketrans("áéíóú", "aeiou"))


# ---------------------------------------------------------------- French
class FrenchStemmer(_Base):
    vowels = "aeiouyâàëéêèïîôûù"

    def stem(self, word):
        w = word.lower()
        v = self.vowels
        ch = list(w)
        n = len(ch)
        for i in range(n):
            if ch[i] == "u" and i > 0 and ch[i - 1] == "q":
                ch[i] = "U"
            elif ch[i] in "iu" and i > 0 and i + 1 < n and w[i - 1] in v and w[i + 1] in v:
                ch[i] = ch[i].upper()
            elif ch[i] == "y" and ((i > 0 and w[i - 1] in v) or (i + 1 < n and w[i + 1] in v)):
                ch[i] = "Y"
        w = "".join(ch)
        n = len(w)
        vw = v
        # RV
        if w.startswith(("par", "col", "tap")):
            rv = 3
        elif len(w) >= 2 and w[0] in vw and w[1] in vw:
            rv = 3
        else:
            rv = n
            for i in range(1, n):
                if w[i] in vw:
                    rv = i + 1
                    break
        rv = min(rv, n)
        r1, r2 = _r1r2(w, vw)

        def R(w):  # recompute boundaries
            return r1, r2, rv

        orig = w
        # step 1
        step1_done = False
        step2a_needed = False
        s = _longest(w, ["issements", "issement", "atrices", "atrice", "ateurs", "ations",
                         "ateur", "ation", "logies", "logie", "usions", "utions", "usion",
                         "ution", "ements", "ement", "ences", "ence", "ances", "iqUes", "ance",
                         "iqUe", "ismes", "ables", "istes", "isme", "able", "iste", "eux",
                         "ités", "ité", "ives", "ifs", "ive", "if", "euses", "euse", "eaux",
                         "aux", "amment", "emment", "ments", "ment"])
        if s:
            base = w[:-len(s)]
            pos = len(base)
            if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes",
                     "ables", "istes"):
                if pos >= r2:
                    w = base
                    step1_done = True
            elif s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
                if pos >= r2:
                    w = base
                    step1_done = True
                    if w.endswith("ic"):
                        if len(w) - 2 >= r2:
                            w = w[:-2]
                        else:
                            w = w[:-2] + "iqU"
            elif s in ("logie", "logies"):
                if pos >= r2:
                    w = base + "log"
                    step1_done = True
            elif s in ("usion", "ution", "usions", "utions"):
                if pos >= r2:
                    w = base + "u"
                    step1_done = True
            elif s in ("ence", "ences"):
                if pos >= r2:
                    w = base + "ent"
                    step1_done = True
            elif s in ("ement", "ements"):
                if pos >= rv:
                    w = base
                    step1_done = True
                    if w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
                    elif w.endswith("eus"):
                        if len(w) - 3 >= r2:
                            w = w[:-3]
                        elif len(w) - 3 >= r1:
                            w = w[:-3] + "eux"
                    elif w.endswith("abl") and len(w) - 3 >= r2:
                        w = w[:-3]
                    elif w.endswith("iqU") and len(w) - 3 >= r2:
                        w = w[:-3]
                    elif w.endswith(("ièr", "Ièr")) and len(w) - 3 >= rv:
                        w = w[:-3] + "i"
            elif s in ("ité", "ités"):
                if pos >= r2:
                    w = base
                    step1_done = True
                    if w.endswith("abil"):
                        if len(w) - 4 >= r2:
                            w = w[:-4]
                        else:
                            w = w[:-2] + "l"
                    elif w.endswith("ic"):
                        if len(w) - 2 >= r2:
                            w = w[:-2]
                        else:
                            w = w[:-2] + "iqU"
                    elif w.endswith("iv") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("if", "ive", "ifs", "ives"):
                if pos >= r2:
                    w = base
                    step1_done = True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("ic"):
                            if len(w) - 2 >= r2:
                                w = w[:-2]
                            else:
                                w = w[:-2] + "iqU"
            elif s == "eaux":
                w = base + "eau"
                step1_done = True
            elif s == "aux":
                if pos >= r1:
                    w = base + "al"
                    step1_done = True
            elif s in ("euse", "euses"):
                if pos >= r2:
                    w = base
                    step1_done = True
                elif pos >= r1:
                    w = base + "eux"
                    step1_done = True
            elif s in ("issement", "issements"):
                if pos >= r1 and base and base[-1] not in vw:
                    w = base
                    step1_done = True
            elif s == "amment":
                if pos >= rv:
                    w = base + "ant"
                    step1_done = True
                    step2a_needed = True
            elif s == "emment":
                if pos >= rv:
                    w = base + "ent"
                    step1_done = True
                    step2a_needed = True
            elif s in ("ment", "ments"):
                if pos >= rv and base and base[-1] in vw:
                    w = base
                    step1_done = True
                    step2a_needed = True
        if not step1_done or step2a_needed:
            # step 2a
            s = _longest(w, ["issantes", "issaIent", "issions", "issante", "issants", "iraIent",
                             "issais", "issait", "issant", "issent", "issiez", "issons", "irions",
                             "issez", "isses", "irais", "irait", "irent", "iriez", "irons",
                             "iront", "isse", "irai", "iras", "ira", "ies", "ir", "îmes", "îtes",
                             "ît", "ie", "is", "it", "i"])
            done2a = False
            if s and len(w) - len(s) >= rv:
                base = w[:-len(s)]
                if base and base[-1] not in vw:
                    w = base
                    done2a = True
            if not done2a:
                s = _longest(w, ["assions", "assiez", "assent", "asses", "antes", "erions",
                                 "eraIent", "erais", "erait", "eriez", "erons", "eront", "ions",
                                 "èrent", "âmes", "âtes", "asse", "ants", "ante", "ais",
                                 "ait", "ant", "ées", "erai", "eras", "erez", "era", "ez",
                                 "iez", "er", "ée", "és", "é", "âtes", "ât", "ai", "as", "a",
                                 "aIent"])
                if s and len(w) - len(s) >= rv or (s == "ions" and len(w) - 4 >= r2):
                    base = w[:-len(s)]
                    if s == "ions":
                        if len(base) >= r2:
                            w = base
                    elif s in ("assions", "assiez", "assent", "asses", "asse", "ants", "ante",
                               "antes", "ant", "ais", "ait", "ai", "as", "a", "ât", "âmes",
                               "âtes", "aIent"):
                        w = base
                        if w.endswith("e") and len(w) - 1 >= rv:
                            w = w[:-1]
                    else:
                        w = base
            elif not step1_done:
                pass
        # step 3
        if w.endswith("Y"):
            w = w[:-1] + "i"
        elif w.endswith("ç"):
            w = w[:-1] + "c"
        # step 4
        changed = False
        if w.endswith("s") and len(w) > 1 and w[-2] not in "aiouèsUI" and not w.endswith("ss"):
            w = w[:-1]
        s = _longest(w, ["ière", "Ière", "ier", "Ier", "ion", "e"])
        if s == "ion":
            if len(w) - 3 >= r2 and len(w) > 3 and w[-4] in "st" and len(w) - 3 >= rv:
                w = w[:-3]
        elif s in ("ière", "Ière", "ier", "Ier"):
            if len(w) - len(s) >= rv:
                w = w[:-len(s)] + "i"
        elif s == "e":
            if len(w) - 1 >= rv:
                w = w[:-1]
        # step 5
        for suf in ("enn", "onn", "ett", "ell", "eill"):
            if w.endswith(suf):
                w = w[:-1]
                break
        # step 6
        for i in range(len(w) - 1, -1, -1):
            if w[i] in "éè":
                if i + 1 < len(w) and w[i + 1:] and all(c not in vw for c in w[i + 1:]):
                    w = w[:i] + "e" + w[i + 1:]
                break
            if w[i] in vw:
                break
        w = w.replace("I", "i").replace("U", "u").replace("Y", "y")
        return w


# ---------------------------------------------------------------- Italian
class ItalianStemmer(_Base):
    vowels = "aeiouàèìòù"

    def stem(self, word):
        w = word.lower()
        w = w.translate(str.maketrans("áéíóú", "àèìòù"))
        w = w.replace("qu", "qU")
        v = self.vowels
        ch = list(w)
        for i in range(1, len(ch) - 1):
            if ch[i] in "iu" and w[i - 1] in v and w[i + 1] in v:
                ch[i] = ch[i].upper()
        w = "".join(ch)
        n = len(w)
        r1, r2 = _r1r2(w, v)
        # RV
        if n < 2:
            rv = n
        elif w[1] not in v:
            rv = next((i + 1 for i in range(2, n) if w[i] in v), n)
        elif w[0] in v and w[1] in v:
            rv = next((i + 1 for i in range(2, n) if w[i] not in v), n)
        else:
            rv = min(3, n)
        # step 0
        s = _longest(w, ["gliela", "gliele", "glieli", "glielo", "gliene", "sene", "mela", "mele",
                         "meli", "melo", "mene", "tela", "tele", "teli", "telo", "tene", "cela",
                         "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo", "vene",
                         "gli", "ci", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi"])
        if s:
            base = w[:-len(s)]
            t = _longest(base, ["ando", "endo", "ar", "er", "ir"])
            if t and len(base) - len(t) >= rv:
                if t in ("ar", "er", "ir"):
                    w = base[:-len(t)] + t + "e"
                else:
                    w = base
        # step 1
        removed = False
        s = _longest(w, ["abilità", "icità", "ività", "ità", "atrice", "atrici", "azione",
                         "azioni", "atore", "atori", "amente", "amenti", "amento", "imento",
                         "imenti", "logia", "logie", "uzione", "uzioni", "usione", "usioni",
                         "enza", "enze", "mente", "anza", "anze", "iche", "ichi", "ismo", "ismi",
                         "abile", "abili", "ibile", "ibili", "ista", "iste", "isti", "istà",
                         "istè", "istì", "oso", "osi", "osa", "ose", "ico", "ici", "ica", "ice",
                         "ivo", "ivi", "iva", "ive"])
        if s:
            base = w[:-len(s)]
            pos = len(base)
            if s in ("anza", "anze", "iche", "ichi", "ismo", "ismi", "abile", "abili", "ibile",
                     "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso", "osi",
                     "osa", "ose", "ico", "ici", "ica", "ice", "amento", "amenti", "imento",
                     "imenti"):
                if pos >= r2:
                    w = base
                    removed = True
            elif s in ("azione", "azioni", "atore", "atori", "atrice", "atrici"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logia", "logie"):
                if pos >= r2:
                    w = base + "log"
                    removed = True
            elif s in ("uzione", "uzioni", "usione", "usioni"):
                if pos >= r2:
                    w = base + "u"
                    removed = True
            elif s in ("enza", "enze"):
                if pos >= r2:
                    w = base + "ente"
                    removed = True
            elif s in ("amente",):
                if pos >= r1:
                    w = base
                    removed = True
                    t = _longest(w, ["iv", "os", "ic", "abil"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
                        if t == "iv" and w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
            elif s in ("mente",):
                pass
            elif s in ("ità", "abilità", "icità", "ività"):
                if pos >= r2:
                    w = base
                    removed = True
                    t = _longest(w, ["abil", "ic", "iv"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
            elif s in ("ivo", "ivi", "iva", "ive"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
                        if w.endswith("ic") and len(w) - 2 >= r2:
                            w = w[:-2]
        if not removed:
            s = _longest(w, [
                "erebbero", "irebbero", "assero", "assimo", "eranno", "erebbe", "eremmo",
                "ereste", "eresti", "essero", "iranno", "irebbe", "iremmo", "ireste", "iresti",
                "iscano", "iscono", "issero", "arono", "avamo", "avano", "avate", "eremo",
                "erete", "erono", "evamo", "evano", "evate", "iremo", "irete", "irono", "ivamo",
                "ivano", "ivate", "ammo", "ando", "asse", "assi", "emmo", "enda", "ende",
                "endi", "endo", "erai", "erei", "Yamo", "iamo", "immo", "irai", "irei", "isca",
                "isce", "isci", "isco", "ano", "are", "ata", "ate", "ati", "ato", "ava", "avi",
                "avo", "erà", "ere", "erò", "ete", "eva", "evi", "evo", "irà", "ire", "irò",
                "ita", "ite", "iti", "ito", "iva", "ivi", "ivo", "ono", "uta", "ute", "uti",
                "uto", "ar", "ir"])
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
        # step 3a
        if w and w[-1] in "aeiouàèìòù" and len(w) - 1 >= rv:
            w = w[:-1]
            if w.endswith("i") and len(w) - 1 >= rv:
                w = w[:-1]
        if w.endswith(("ch", "gh")) and len(w) - 1 >= rv:
            w = w[:-1]
        return w.replace("I", "i").replace("U", "u")


# ---------------------------------------------------------------- Portuguese
class PortugueseStemmer(_Base):
    vowels = "aeiouáéíóúâêô"

    def stem(self, word):
        w = word.lower().replace("ã", "a~").replace("õ", "o~")
        v = self.vowels
        n = len(w)
        r1, r2 = _r1r2(w, v)
        if n < 2:
            rv = n
        elif w[1] not in v:
            rv = next((i + 1 for i in range(2, n) if w[i] in v), n)
        elif w[0] in v and w[1] in v:
            rv = next((i + 1 for i in range(2, n) if w[i] not in v), n)
        else:
            rv = min(3, n)
        removed = False
        s = _longest(w, ["amentos", "imentos", "amento", "imento", "adoras", "adores", "aço~es",
                         "logias", "ências", "amente", "idades", "ismos", "istas", "adora",
                         "aça~o", "antes", "ância", "logia", "ência", "mente", "idade", "ismo",
                         "ista", "ante", "ável", "ível", "icos", "icas", "ador", "oso", "osa",
                         "osos", "osas", "ivo", "iva", "ivos", "ivas", "ico", "ica", "eza",
                         "ezas", "uça~o", "uço~es", "ância"])
        if s:
            base = w[:-len(s)]
            pos = len(base)
            if s in ("ismo", "ismos", "ista", "istas", "ável", "ível", "ico", "ica", "icos",
                     "icas", "oso", "osa", "osos", "osas", "amento", "amentos", "imento",
                     "imentos", "eza", "ezas", "ante", "antes", "ância"):
                if pos >= r2:
                    w = base
                    removed = True
            elif s in ("adora", "ador", "adoras", "adores", "aça~o", "aço~es"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("ic") and len(w) - 2 >= r2:
                        w = w[:-2]
            elif s in ("logia", "logias"):
                if pos >= r2:
                    w = base + "log"
                    removed = True
            elif s in ("uça~o", "uço~es"):
                if pos >= r2:
                    w = base + "u"
                    removed = True
            elif s in ("ência", "ências"):
                if pos >= r2:
                    w = base + "ente"
                    removed = True
            elif s == "amente":
                if pos >= r1:
                    w = base
                    removed = True
                    t = _longest(w, ["iv", "os", "ic", "ad"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
                        if t == "iv" and w.endswith("at") and len(w) - 2 >= r2:
                            w = w[:-2]
            elif s == "mente":
                if pos >= r2:
                    w = base
                    removed = True
                    t = _longest(w, ["ante", "avel", "ível"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
            elif s in ("idade", "idades"):
                if pos >= r2:
                    w = base
                    removed = True
                    t = _longest(w, ["abil", "ic", "iv"])
                    if t and len(w) - len(t) >= r2:
                        w = w[:-len(t)]
            elif s in ("iva", "ivo", "ivas", "ivos"):
                if pos >= r2:
                    w = base
                    removed = True
                    if w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        if not removed:
            s = _longest(w, [
                "aríamos", "eríamos", "iríamos", "ássemos", "êssemos", "íssemos", "aríeis",
                "eríeis", "iríeis", "áramos", "éramos", "íramos", "ávamos", "aremos", "eremos",
                "iremos", "ariam", "eriam", "iriam", "assem", "essem", "issem", "ara~o", "era~o",
                "ira~o", "arias", "erias", "irias", "ardes", "erdes", "irdes", "asses", "esses",
                "isses", "astes", "estes", "istes", "áreis", "areis", "éreis", "ereis", "íreis",
                "ireis", "áveis", "íamos", "armos", "ermos", "irmos", "aria", "eria", "iria",
                "asse", "esse", "isse", "aste", "este", "iste", "arei", "erei", "irei", "aram",
                "eram", "iram", "avam", "arem", "erem", "irem", "ando", "endo", "indo", "adas",
                "idas", "arás", "aras", "erás", "eras", "irás", "avas", "ares", "eres", "ires",
                "íeis", "ados", "idos", "ámos", "amos", "emos", "imos", "iras", "ada", "ida",
                "ará", "ara", "erá", "era", "irá", "ava", "iam", "ado", "ido", "ias", "ais",
                "eis", "ira", "ia", "ei", "am", "em", "ar", "er", "ir", "as", "es", "is", "eu",
                "iu", "ou"])
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
                if s in ("ou",) and False:
                    pass
        # residual
        s = _longest(w, ["os", "a", "i", "o", "á", "í", "ó"])
        if s and len(w) - len(s) >= rv:
            w = w[:-len(s)]
        else:
            s = _longest(w, ["e", "é", "ê"])
            if s and len(w) - len(s) >= rv:
                w = w[:-len(s)]
                if w.endswith(("gu", "ci")) and len(w) - 1 >= rv:
                    w = w[:-1] if w.endswith("gu") or w.endswith("ci") else w
            elif w.endswith("ç"):
                w = w[:-1] + "c"
        return w.replace("a~", "ã").replace("o~", "õ")


# ---------------------------------------------------------------- approximations
class _SuffixStemmer(_Base):
    """Light longest-suffix stripper used for languages without a full port."""
    suffixes = ()
    vowels = ""
    minstem = 3

    def stem(self, word):
        w = word.lower()
        for _ in range(2):
            s = _longest(w, self.suffixes)
            if s and len(w) - len(s) >= self.minstem:
                w = w[:-len(s)]
            else:
                break
        return w


class FinnishStemmer(_SuffixStemmer):
    vowels = "aeiouyäö"
    suffixes = ("kaan", "kään", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle",
                "ksi", "ine", "han", "hän", "pa", "pä", "ko", "kö", "nsa", "nsä", "mme", "nne",
                "den", "tten", "ien", "jen", "ja", "jä", "ta", "tä", "na", "nä", "a", "ä", "n",
                "t", "i", "s")


class HungarianStemmer(_SuffixStemmer):
    vowels = "aeiouyáéíóöőúüű"
    suffixes = ("ságok", "ségek", "ságot", "séget", "nak", "nek", "ban", "ben", "val", "vel",
                "ból", "ből", "tól", "től", "ról", "ről", "hoz", "hez", "höz", "ért", "ig", "on",
                "en", "ön", "ak", "ek", "ok", "ök", "at", "et", "ot", "öt", "ra", "re", "ba",
                "be", "ul", "ül", "k", "t")


class RomanianStemmer(_SuffixStemmer):
    vowels = "aeiouăâî"
    suffixes = ("ărilor", "urilor", "elor", "ilor", "ului", "ările", "ărie", "uri", "ele", "ile",
                "ul", "ua", "ei", "ii", "le", "lor", "ea", "ia", "a", "e", "i", "ă")


class ArabicStemmer(_Base):
    def stem(self, word):
        from .misc import ARLSTem
        return ARLSTem().stem(word)


_STEMMERS = {
    "arabic": ArabicStemmer, "danish": DanishStemmer, "dutch": DutchStemmer,
    "english": EnglishStemmer, "finnish": FinnishStemmer, "french": FrenchStemmer,
    "german": GermanStemmer, "hungarian": HungarianStemmer, "italian": ItalianStemmer,
    "norwegian": NorwegianStemmer, "porter": PorterSnowball, "portuguese": PortugueseStemmer,
    "romanian": RomanianStemmer, "russian": RussianStemmer, "spanish": SpanishStemmer,
    "swedish": SwedishStemmer,
}


class SnowballStemmer:
    languages = SUPPORTED

    def __init__(self, language, ignore_stopwords=False):
        # spec: N-000429 N-000430 -- message contains the requested name
        if language not in _STEMMERS:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.ignore_stopwords = ignore_stopwords
        self.stopwords = set()
        if ignore_stopwords:
            # spec: N-000431 -- the list for *this* language must be visible
            name = "english" if language == "porter" else language
            path = data.require("corpora/stopwords/" + name)
            if not os.path.isfile(path):
                raise LookupError("stopwords list not found: %s" % path)
            with open(path, encoding="utf-8") as f:
                self.stopwords = set(l.strip() for l in f.read().splitlines())
        self.stemmer = _STEMMERS[language]()

    def stem(self, word):
        low = word.lower()
        if self.ignore_stopwords and low in self.stopwords:
            return low
        return self.stemmer.stem(low)
