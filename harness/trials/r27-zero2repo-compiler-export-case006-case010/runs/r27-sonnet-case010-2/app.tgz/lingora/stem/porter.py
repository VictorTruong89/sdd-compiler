"""Porter stemmer (LINGORA-extension default mode).  # spec: N-000153"""


class PorterStemmer:
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("Mode must be one of PorterStemmer.NLTK_EXTENSIONS, "
                             "PorterStemmer.MARTIN_EXTENSIONS, or PorterStemmer.ORIGINAL_ALGORITHM")
        self.mode = mode
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "skies": "sky", "sky": "sky", "dying": "die", "lying": "lie", "tying": "tie",
                "news": "news", "innings": "inning", "inning": "inning", "outings": "outing",
                "outing": "outing", "cannings": "canning", "canning": "canning",
                "howe": "howe", "proceed": "proceed", "exceed": "exceed", "succeed": "succeed",
            }
            self.pool = irregular
        else:
            self.pool = {}
        self.vowels = frozenset("aeiou")

    # -- helpers ----------------------------------------------------------
    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return (len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1))

    def _ends_cvc(self, word):
        return ((len(word) >= 3 and self._is_consonant(word, len(word) - 3)
                 and not self._is_consonant(word, len(word) - 2)
                 and self._is_consonant(word, len(word) - 1)
                 and word[-1] not in ("w", "x", "y"))
                or (self.mode == self.NLTK_EXTENSIONS and len(word) == 2
                    and not self._is_consonant(word, 0) and self._is_consonant(word, 1)))

    def _replace_suffix(self, word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    # -- steps ------------------------------------------------------------
    def _step1a(self, word):
        # spec: N-000424 -- Step 1a as published: "ies" -> "i" (ties -> ti)
        if word.endswith("ies"):
            return self._replace_suffix(word, "ies", "i")
        return self._apply_rule_list(word, [
            ("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        rule_2_or_3_succeeded = False
        intermediate = word
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(stem):
                    intermediate = stem
                    rule_2_or_3_succeeded = True
                break
        if not rule_2_or_3_succeeded:
            return word
        return self._apply_rule_list(intermediate, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", intermediate[-1], lambda stem: intermediate[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def nltk_condition(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)

        def original_condition(stem):
            return self._contains_vowel(stem)

        return self._apply_rule_list(word, [
            ("y", "i", nltk_condition if self.mode == self.NLTK_EXTENSIONS else original_condition)])

    def _step2(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and self._has_positive_measure(
                    self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli_rule = ("bli", "ble", self._has_positive_measure)
        abli_rule = ("abli", "able", self._has_positive_measure)
        rules = [
            ("ational", "ate", self._has_positive_measure),
            ("tional", "tion", self._has_positive_measure),
            ("enci", "ence", self._has_positive_measure),
            ("anci", "ance", self._has_positive_measure),
            ("izer", "ize", self._has_positive_measure),
            abli_rule if self.mode == self.ORIGINAL_ALGORITHM else bli_rule,
            ("alli", "al", self._has_positive_measure),
            ("entli", "ent", self._has_positive_measure),
            ("eli", "e", self._has_positive_measure),
            ("ousli", "ous", self._has_positive_measure),
            ("ization", "ize", self._has_positive_measure),
            ("ation", "ate", self._has_positive_measure),
            ("ator", "ate", self._has_positive_measure),
            ("alism", "al", self._has_positive_measure),
            ("iveness", "ive", self._has_positive_measure),
            ("fulness", "ful", self._has_positive_measure),
            ("ousness", "ous", self._has_positive_measure),
            ("aliti", "al", self._has_positive_measure),
            ("iviti", "ive", self._has_positive_measure),
            ("biliti", "ble", self._has_positive_measure),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", self._has_positive_measure))
            rules.append(("logi", "log", lambda stem: self._has_positive_measure(word[:-3])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", self._has_positive_measure))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm),
            ("iciti", "ic", pm), ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        def m1(stem):
            return self._measure(stem) > 1
        return self._apply_rule_list(word, [
            ("al", "", m1), ("ance", "", m1), ("ence", "", m1), ("er", "", m1), ("ic", "", m1),
            ("able", "", m1), ("ible", "", m1), ("ant", "", m1), ("ement", "", m1),
            ("ment", "", m1), ("ent", "", m1),
            ("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")),
            ("ou", "", m1), ("ism", "", m1), ("ate", "", m1), ("iti", "", m1),
            ("ous", "", m1), ("ive", "", m1), ("ize", "", m1)])

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [
            ("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=False):
        # spec: N-000425 N-000426 -- to_lowercase defaults to False
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem.lower() in self.pool:
            return self.pool[stem.lower()]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem
