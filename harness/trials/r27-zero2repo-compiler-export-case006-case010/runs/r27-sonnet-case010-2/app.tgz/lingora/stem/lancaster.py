"""Lancaster (Paice/Husk) stemmer.  # spec: N-000170 N-000171"""
import re

_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.",
    "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.", "mu*2.",
    "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>",
    "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.",
    "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>",
    "yli3y>", "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.",
    "yrtsi5.", "yra3>", "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)
_PARSE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")
_VOWELS = "aeiouy"


class LancasterStemmer:
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        for rule in (rule_tuple or _RULES):
            m = _PARSE.match(rule)
            ending = m.group(1)[::-1]
            entry = (ending, bool(m.group(2)), int(m.group(3)), m.group(4), m.group(5))
            self.rule_dictionary.setdefault(m.group(1)[0], []).append(entry)

    def _acceptable(self, word, remove_total):
        if word[0] in _VOWELS:
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return any(c in _VOWELS for c in word[1:len(word) - remove_total]) or \
                word[1] in _VOWELS
        return False

    def stem(self, word):
        word = word.lower()
        if not word:
            return word
        intact = True
        while True:
            if not word or word[-1] not in self.rule_dictionary:
                break
            applied = False
            stop = False
            for ending, intact_flag, remove, append, cont in self.rule_dictionary[word[-1]]:
                if not word.endswith(ending):
                    continue
                if intact_flag and not intact:
                    continue
                if not self._acceptable(word, remove):
                    continue
                if remove:
                    new = word[:-remove] + append
                else:
                    new = word + append
                if cont == ".":
                    stop = True
                word = new
                intact = False
                applied = True
                break
            if not applied or stop:
                break
        return word
