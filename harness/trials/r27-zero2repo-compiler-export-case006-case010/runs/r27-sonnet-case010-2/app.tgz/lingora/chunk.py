"""Chunking.  # spec: N-000446"""
import re

from . import data
from .tree import Tree

SENTENCE_LABEL = "S"


def _tag_pattern_to_re(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = p.replace("<", "(?:<(?:").replace(">", ")>)")
    p = re.sub(r"(?<!\\)\.", r"[^\{\}<>]", p)
    return p


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        body = _tag_pattern_to_re(pattern)
        if kind == "chunk":
            self.regexp = re.compile(r"(?P<c>%s)(?=[^\}]*(\{|$))" % body)
            self.repl = r"{\g<c>}"
        else:
            self.regexp = re.compile(r"(?P<c>%s)(?=[^\{]*\})" % body)
            self.repl = r"}\g<c>{"

    def apply(self, s):
        s = self.regexp.sub(self.repl, s)
        return s.replace("{}", "")


class RegexpChunkParser:
    """One cascade stage: ordered chunk/chink rules producing one label."""

    def __init__(self, rules, chunk_label="NP", root_label=SENTENCE_LABEL):
        self._rules = rules
        self._label = chunk_label
        self._root = root_label

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("expected a list of tagged tokens")
        items = list(tagged)
        return self._parse_items(items)

    def _tag_of(self, item):
        if isinstance(item, Tree):
            return item.label()
        return item[1]

    def _parse_items(self, items):
        s = "".join("<%s>" % self._tag_of(it) for it in items)
        for r in self._rules:
            s = r.apply(s)
        # rebuild
        children = []
        idx = 0
        current = None
        for tok in re.findall(r"\{|\}|<[^<>{}]*>", s):
            if tok == "{":
                current = []
            elif tok == "}":
                if current:
                    children.append(Tree(self._label, current))
                current = None
            else:
                it = items[idx]
                idx += 1
                (current if current is not None else children).append(it)
        return Tree(self._root, children)


class RegexpParser:
    def __init__(self, grammar, root_label=SENTENCE_LABEL, loop=1):
        # spec: N-000449 N-000450 N-000451
        self._root = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(
                isinstance(g, RegexpChunkParser) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def _parse_grammar(self, text):
        stages = []
        label = None
        rules = []

        def flush():
            if label is not None:
                stages.append(RegexpChunkParser(rules, label, self._root))

        for line in text.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(?P<label>[^:{}\s][^:{}]*?)\s*:\s*(?P<rule>.*)$", line)
            if m and not line.startswith(("{", "}")):
                flush()
                label = m.group("label").strip()
                rules = []
                rule = m.group("rule").strip()
            else:
                if label is None:
                    raise ValueError("Illegal chunk pattern: %s" % line)
                rule = line
            if rule:
                rules.extend(self._parse_rule(rule))
        flush()
        if not stages:
            pass
        return stages

    def _parse_rule(self, rule):
        rule = rule.split("#")[0].strip() if "#" in rule else rule
        if rule.startswith("{") and rule.endswith("}") and "}" not in rule[1:-1] and "{" not in re.sub(r"\{\d*,?\d*\}", "", rule[1:-1]):
            return [_Rule("chunk", rule[1:-1])]
        if rule.startswith("}") and rule.endswith("{"):
            return [_Rule("chink", rule[1:-1])]
        raise ValueError("Illegal chunk pattern: %s" % rule)

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("expected a list of tagged tokens")
        tree = Tree(self._root, list(tagged))
        if not self._stages:
            return tree
        for _ in range(self._loop):
            for stage in self._stages:
                tree = stage._parse_items(list(tree))
        return tree


def ne_chunk(tagged_tokens, binary=False):
    # spec: N-000452 -- needs the NE model and the English wordlist
    data.require("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.require("corpora/words")
    if isinstance(tagged_tokens, str):
        raise TypeError("expected a list of tagged tokens")
    # The trained maxent model's results are outside this specification;
    # entities are not recognised, tokens pass through unchunked.
    return Tree(SENTENCE_LABEL, [tuple(t) for t in tagged_tokens])
