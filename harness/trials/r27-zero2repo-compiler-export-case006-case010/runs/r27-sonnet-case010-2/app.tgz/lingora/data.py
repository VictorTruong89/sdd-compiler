"""Packaged resource finder.  # spec: N-000385 N-000386 N-000387 N-000388"""
import os

_here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Mutable list of directories searched for packaged resources.
path = [
    os.path.join(_here, "lingora_data"),
    os.path.join(os.path.expanduser("~"), "lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
]


def find(resource):
    """Return the first existing path of `resource` on data.path, or None."""
    for d in list(path):
        p = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(p):
            return p
    return None


def require(resource):
    p = find(resource)
    if p is None:
        raise LookupError("packaged resource %r not found in data.path" % resource)
    return p


def read_lines(filepath):
    with open(filepath, encoding="utf-8", newline="") as f:
        text = f.read()
    return text.splitlines() if text else []
