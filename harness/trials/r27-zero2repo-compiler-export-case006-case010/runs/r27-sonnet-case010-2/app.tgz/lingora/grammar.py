"""Context-free grammars.  # spec: N-000461"""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __hash__(self):
        return hash(self._symbol)

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s|'"]+))""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        if lhs is not None and not isinstance(lhs, Nonterminal):
            lhs = Nonterminal(lhs)
        out = list(self._productions)
        if lhs is not None:
            out = [p for p in out if p.lhs() == lhs]
        return out

    def terminals(self):
        return set(self._terminals)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            if isinstance(input, (list, tuple)):
                input = "\n".join(input)
            else:
                raise TypeError("grammar text must be a str")
        prods = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
            if not m:
                raise ValueError("Unable to parse line: %r" % raw)
            lhs = Nonterminal(m.group(1))
            if start is None:
                start = lhs
            rest = m.group(2)
            alts = [[]]
            pos = 0
            rest = rest.rstrip()
            while pos < len(rest):
                mm = _TOKEN.match(rest, pos)
                if not mm or mm.end() == pos:
                    if rest[pos:].strip() == "":
                        break
                    raise ValueError("Unable to parse right-hand side: %r" % rest)
                pos = mm.end()
                if mm.group(1) is not None:
                    alts[-1].append(mm.group(1))
                elif mm.group(2) is not None:
                    alts[-1].append(mm.group(2))
                elif mm.group(3):
                    alts.append([])
                else:
                    alts[-1].append(Nonterminal(mm.group(4)))
            for a in alts:
                prods.append(Production(lhs, a))
        if start is None:
            raise ValueError("grammar text holds no productions")
        return cls(start, prods)
