"""Parsers.  # spec: N-000461"""
from ..grammar import CFG, Nonterminal
from ..tree import Tree
from .generate import generate  # noqa: F401


def _check(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    terms = grammar.terminals()
    missing = [t for t in tokens if t not in terms]
    if missing:
        # spec: N-000475
        raise ValueError("Grammar does not cover some of the input words: %r."
                         % ", ".join(repr(t) for t in missing))


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._by_lhs = {}
        for p in grammar.productions():
            self._by_lhs.setdefault(str(p.lhs()), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        _check(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        active = set()

        def sym_trees(sym, i, j):
            if isinstance(sym, str):
                if sym == "":
                    return [""] if i == j else []
                return [sym] if j == i + 1 and tokens[i] == sym else []
            key = (str(sym), i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            res = []
            for p in self._by_lhs.get(str(sym), []):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append(Tree(str(p.lhs()), [k for k in kids if k != "" or False]))
            active.discard(key)
            memo[key] = res
            return res

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            if k == len(rhs) - 1:
                for t in sym_trees(rhs[k], i, j):
                    yield [t]
                return
            for mid in range(i, j + 1):
                firsts = sym_trees(rhs[k], i, mid)
                if not firsts:
                    continue
                for rest in seq(rhs, k + 1, mid, j):
                    for f in firsts:
                        yield [f] + rest

        start = self._grammar.start()
        return iter(sym_trees(start, 0, n))


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    def _match(self, stack, rhs):
        if len(rhs) > len(stack):
            return False
        for s, r in zip(stack[len(stack) - len(rhs):], rhs):
            if isinstance(r, str):
                if s != r or isinstance(s, Tree):
                    return False
            else:
                if not isinstance(s, Tree) or s.label() != str(r):
                    return False
        return True

    def _reduce(self, stack):
        for p in self._prods:
            if self._match(stack, p.rhs()):
                n = len(p.rhs())
                children = stack[len(stack) - n:]
                del stack[len(stack) - n:]
                stack.append(Tree(str(p.lhs()), children))
                return True
        return False

    def parse(self, tokens):
        _check(self._grammar, tokens)
        stack = []
        remaining = list(tokens)
        while self._reduce(stack):
            pass
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and \
                stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])
