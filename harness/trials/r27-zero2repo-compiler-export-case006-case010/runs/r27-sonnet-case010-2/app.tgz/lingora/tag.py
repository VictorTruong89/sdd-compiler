"""Taggers.  # spec: N-000433"""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self.backoff = backoff

    def tag(self, tokens):
        _check_tokens(tokens)
        tokens = list(tokens)
        out = [(tok, self.choose_tag(tokens, i, None)) for i, tok in enumerate(tokens)]
        if self.backoff is not None and any(t is None for _, t in out):
            fallback = self.backoff.tag(tokens)
            out = [(tok, t if t is not None else fallback[i][1]) for i, (tok, t) in enumerate(out)]
        return out

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    # spec: N-000198
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class UnigramTagger(SequentialBackoffTagger):
    # spec: N-000199 N-000200 N-000201
    def __init__(self, train=None, model=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        if model is not None:
            self._model = dict(model)
        else:
            counts = defaultdict(Counter)
            for sent in (train or []):
                for tok, tag in sent:
                    counts[tok][tag] += 1
            self._model = {tok: c.most_common(1)[0][0] for tok, c in counts.items()}

    def choose_tag(self, tokens, index, history):
        return self._model.get(tokens[index])


class RegexpTagger(SequentialBackoffTagger):
    # spec: N-000202 N-000203 N-000204
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), tag) for rx, tag in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


# ---------------------------------------------------------------- perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights, self.tagdict, self.classes = weights, tagdict, classes

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


def _load_perceptron(lang):
    d = data.require("taggers/averaged_perceptron_tagger_%s" % lang)
    base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
    try:
        with open(base + ".weights.json", encoding="utf-8") as f:
            weights = json.load(f)
        with open(base + ".tagdict.json", encoding="utf-8") as f:
            tagdict = json.load(f)
        with open(base + ".classes.json", encoding="utf-8") as f:
            classes = json.load(f)
    except OSError as e:
        raise LookupError("averaged perceptron tagger resource incomplete: %s" % e)
    return _Perceptron(weights, tagdict, classes)


_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "NUM": "NUM", "ANUM": "ADJ", "APRO": "DET", "SPRO": "PRON", "ADVPRO": "ADV",
    "PART": "PRT", "INTJ": "X", "NONLEX": ".", "COM": "X",
}


def _load_universal_map():
    d = data.require("taggers/universal_tagset")
    p = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(p):
        raise LookupError("universal tagset table en-ptb.map not found")
    m = {}
    for line in data.read_lines(p):
        parts = line.split("\t")
        if len(parts) >= 2:
            m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    # spec: N-000440..N-000443
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, the recommended tagger supports only 'eng' and 'rus'")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    model = _load_perceptron(lang)
    umap = None
    if tagset == "universal" and lang == "eng":
        umap = _load_universal_map()
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            tagged = [(w, umap.get(t, "X") if t is not None else None) for w, t in tagged]
        else:
            tagged = [(w, _RUS_UNIVERSAL.get(t.split("=")[0], "X") if t is not None else None)
                      for w, t in tagged]
    return tagged
