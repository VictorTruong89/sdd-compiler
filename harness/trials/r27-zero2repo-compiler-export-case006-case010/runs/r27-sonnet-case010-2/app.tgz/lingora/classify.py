"""Classifiers.  # spec: N-000492"""
import math
from collections import Counter, defaultdict


class DictionaryProbDist:
    def __init__(self, prob_dict, log=False, normalize=False):
        d = dict(prob_dict)
        if normalize:
            if log:
                m = max(d.values())
                if m == float("-inf"):
                    d = {k: 1.0 / len(d) for k in d}
                else:
                    e = {k: math.exp(v - m) for k, v in d.items()}
                    t = sum(e.values())
                    d = {k: v / t for k, v in e.items()}
            else:
                t = sum(d.values())
                d = {k: (v / t if t else 1.0 / len(d)) for k, v in d.items()}
        elif log:
            d = {k: math.exp(v) for k, v in d.items()}
        self._d = d

    def prob(self, sample):
        return float(self._d.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def max(self):
        return max(self._d, key=lambda k: self._d[k])

    def samples(self):
        return list(self._d.keys())

    def __iter__(self):
        return iter(self._d)


def _ele(freq, bins):
    n = sum(freq.values())
    return {k: (c + 0.5) / (n + 0.5 * bins) for k, c in freq.items()}, n, bins


class _ELE:
    def __init__(self, freq, bins=None):
        self.freq = dict(freq)
        self.bins = len(self.freq) if bins is None else bins
        self.n = sum(self.freq.values())

    def prob(self, s):
        return (self.freq.get(s, 0) + 0.5) / (self.n + 0.5 * self.bins)

    def logprob(self, s):
        return math.log(self.prob(s))


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist.freq.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            ns = label_freq[label]
            for fname in fnames:
                count = sum(feature_freq[label, fname].values())
                if ns - count > 0:
                    feature_freq[label, fname][None] += ns - count
                    feature_values[fname].add(None)
        label_pd = _ELE(label_freq)
        feature_pd = {}
        for (label, fname), freq in feature_freq.items():
            feature_pd[label, fname] = _ELE(freq, bins=len(feature_values[fname]))
        return cls(label_pd, feature_pd)

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        for fname in list(featureset):
            if not any((label, fname) in self._feature_probdist for label in self._labels):
                del featureset[fname]
        logprob = {}
        for label in self._labels:
            logprob[label] = self._label_probdist.logprob(label)
        for label in self._labels:
            for fname, fval in featureset.items():
                pd = self._feature_probdist.get((label, fname))
                if pd is not None:
                    logprob[label] += pd.logprob(fval)
                else:
                    logprob[label] += float("-inf")
        return DictionaryProbDist(logprob, normalize=True, log=True)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum((v / n) * math.log2(v / n) for v in c.values()) if n else 0.0


def _max_label(labels):
    c = Counter()
    for l in labels:
        c[l] += 1
    best, bc = None, -1
    for k, v in c.items():
        if v > bc:
            best, bc = k, v
    return best


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        out = [self._label]
        for d in (self._decisions or {}).values():
            out.extend(d.labels())
        return list(dict.fromkeys(out))

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]

    def error(self, labeled):
        if not labeled:
            return 0.0
        return sum(1 for fs, l in labeled if self.classify(fs) != l) / len(labeled)

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(_max_label(l for _, l in labeled))

    @staticmethod
    def stump(fname, labeled):
        label = _max_label(l for _, l in labeled)
        groups = {}
        for fs, l in labeled:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_max_label(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in fnames:
            st = DecisionTreeClassifier.stump(fname, labeled)
            e = st.error(labeled)
            if e < best_err:
                best_err, best = e, st
        return best

    def refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100,
              support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        fnames = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    fnames.append(f)
        tree = cls.best_stump(fnames, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    results = [classifier.classify(fs) for fs, _ in gold]
    return sum(1 for r, (_, l) in zip(results, gold) if r == l) / len(gold)
