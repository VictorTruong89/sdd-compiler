"""Terminal interaction helpers."""
import contextlib
import getpass
import inspect
import io
import itertools
import os
import shlex
import subprocess
import sys
import time
import math

from .exceptions import Abort, UsageError, OptlynException, DeclarationError
from .globals import resolve_color_default
from .types import Choice, convert_type
from . import utils
from .utils import echo, isatty, strip_ansi, is_interactive

visible_prompt_func = input
hidden_prompt_func = getpass.getpass

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise DeclarationError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise DeclarationError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise DeclarationError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c <= 255
                                  for c in color):
            raise DeclarationError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    raise DeclarationError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# ---- prompts ------------------------------------------------------------------

def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type._names()))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and hasattr(default, "value") and not isinstance(default, str):
        try:
            return default.name
        except Exception:
            pass
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    full = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(full)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    full = _build_prompt(text, prompt_suffix, show_default,
                         "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(full.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---- single character input ----------------------------------------------------

def _posix_getchar(echo_=False):
    import termios
    import tty
    f = None
    try:
        f = open("/dev/tty")
        fd = f.fileno()
    except OSError:
        fd = sys.stdin.fileno()
        f = None
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and sys.stdout.isatty():
                sys.stdout.write(ch)
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if f is not None:
            f.close()
    return ch


_getchar = _posix_getchar


def getchar(echo=False):
    ch = _getchar(echo)
    if ch in ("\x03", "\x04"):
        if ch == "\x03":
            raise KeyboardInterrupt()
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not is_interactive():
        echo(info, err=err)
        return
    try:
        echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---- pager --------------------------------------------------------------------

def _pager_command():
    return os.environ.get("PAGER", "").strip()


def _resolve_pager_cmd():
    cmd = _pager_command()
    if cmd:
        return cmd
    import shutil
    for c in ("less", "more"):
        if shutil.which(c):
            return c
    return ""


class _PagerStream:
    def __init__(self, proc, encoding, strip):
        self.proc = proc
        self.encoding = encoding
        self.strip = strip

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if self.strip:
            text = strip_ansi(text)
        try:
            self.proc.stdin.write(text.encode(self.encoding, "replace"))
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass
        return len(text)

    def flush(self):
        try:
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def isatty(self):
        return False

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout
    cmd = _resolve_pager_cmd() if is_interactive() else ""
    if not cmd:
        yield utils.KeepOpenFile(stdout)
        try:
            stdout.flush()
        except Exception:
            pass
        return
    env = dict(os.environ)
    if color is None and os.path.basename(cmd.split()[0]) == "less" and not any(
            a in cmd for a in ("-r", "-R")):
        env.setdefault("LESS", "-R")
        color = True
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    enc = getattr(stdout, "encoding", None) or "utf-8"
    try:
        yield _PagerStream(proc, enc, strip=not color)
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        items = [text_or_generator]
    else:
        items = iter(text_or_generator)
    chunks = (c if isinstance(c, str) else (c.decode("utf-8", "replace") if isinstance(c, bytes)
                                             else str(c)) for c in items)
    with get_pager_file(color=color) as f:
        interactive_pager = isinstance(f, _PagerStream)
        last = ""
        for chunk in chunks:
            if interactive_pager:
                f.write(chunk)
            else:
                echo(chunk, file=f, nl=False, color=color)
            last = chunk
        if not last.endswith("\n"):
            if interactive_pager:
                f.write("\n")
            else:
                echo(file=f, color=color)


# ---- progress bar --------------------------------------------------------------

class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None,
                 width=36, show_eta=True, show_percent=None, show_pos=False, fill_char="#",
                 empty_char="-", item_show_func=None, update_min_steps=1, color=None, **_ignored):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        elif length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.iter = iter(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file if file is not None else sys.stdout
        self.width = width
        self.show_eta = show_eta
        self.show_percent = length is not None if show_percent is None else show_percent
        self.show_pos = show_pos
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.item_show_func = item_show_func
        self.color = color
        self.pos = 0
        self.finished = False
        self.start = time.time()
        self.is_tty = isatty(self.file)
        self._label_printed = False
        self._last_line = ""
        self.current_item = None

    # progress
    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is None or self.finished:
            return 0.0
        elapsed = time.time() - self.start
        if self.pos <= 0:
            return 0.0
        return elapsed / self.pos * (self.length - self.pos)

    def format_eta(self):
        if self.length is None:
            return ""
        t = int(self.eta)
        s = t % 60
        m = (t // 60) % 60
        h = t // 3600
        return f"{h:d}:{m:02d}:{s:02d}"

    def format_bar(self):
        if self.length is not None:
            n = int(self.pct * self.width)
            return self.fill_char * n + self.empty_char * (self.width - n)
        return self.empty_char * self.width

    def render_progress(self):
        if self.hidden:
            return
        if not self.is_tty:
            if not self._label_printed:
                self._label_printed = True
                if self.label:
                    echo(self.label, file=self.file, nl=True, color=self.color)
            return
        parts = []
        if self.label:
            parts.append(self.label)
        parts.append(f"[{self.format_bar()}]")
        if self.show_percent:
            parts.append(f"{int(self.pct * 100):3d}%")
        if self.show_pos:
            parts.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_eta and self.length is not None:
            parts.append(self.format_eta())
        if self.item_show_func and self.current_item is not None:
            parts.append(str(self.item_show_func(self.current_item)))
        line = "  ".join(parts)
        pad = " " * max(len(self._last_line) - len(line), 0)
        self._last_line = line
        echo("\r" + line + pad, file=self.file, nl=False, color=self.color)

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True

    def render_finish(self):
        if self.hidden or not self.is_tty:
            return
        self.render_progress()
        echo(file=self.file, color=self.color)

    def __enter__(self):
        self.render_progress()
        return self

    def __exit__(self, *exc):
        self.render_finish()

    def __iter__(self):
        if not self.hidden and not self.is_tty:
            self.render_progress()
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finished = True

    def __next__(self):
        raise TypeError("Use iteration over the progress bar")


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---- editor / launch ------------------------------------------------------------

def _default_editor():
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    import shutil
    for ed in ("sensible-editor", "vim", "nano"):
        if shutil.which(ed):
            return ed
    return "vi"


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = editor or _default_editor()
    environ = None
    if env is not None:
        environ = dict(os.environ)
        environ.update(env)

    def run(path):
        cmd = f"{editor} {shlex.quote(path)}"
        try:
            rv = subprocess.Popen(cmd, env=environ, shell=True).wait()
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if rv != 0:
            raise OptlynException(f"{editor}: Editing failed")

    if filename is not None:
        run(os.fspath(filename))
        return None
    import tempfile
    if not text:
        data = b""
    elif isinstance(text, (bytes, bytearray)):
        data = bytes(text)
    else:
        if not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        ts = os.path.getmtime(name) - 2
        os.utime(name, (ts, ts))
        before = os.path.getmtime(name)
        run(name)
        if require_save and os.path.getmtime(name) == before:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, (bytes, bytearray)):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    target = os.fspath(url) if not isinstance(url, str) else url
    if locate and "://" not in target:
        target = os.path.dirname(os.path.abspath(target)) or "."
    try:
        return subprocess.call(["xdg-open", target])
    except OSError:
        return 127
