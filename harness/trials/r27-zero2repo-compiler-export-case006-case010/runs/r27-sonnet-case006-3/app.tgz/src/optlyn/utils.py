"""Stream helpers: echo, file opening, misc."""
import codecs
import io
import os
import re
import sys
import tempfile
import random
import string

from .globals import get_current_context, resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def is_interactive():
    """Interactive session: stdin or stdout is a terminal."""
    return isatty(sys.stdin) or isatty(sys.stdout)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _find_binary_writer(stream):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    color = resolve_color_default(color)
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    ascii_only = False
    if enc:
        try:
            ascii_only = codecs.lookup(enc).name == "ascii"
        except LookupError:
            pass
    if ascii_only:
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary = _find_binary_writer(file)
        if binary is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    file.flush()


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win") and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.path.expanduser("~/.config"), _posixify(app_name))


# ---- standard stream accessors ------------------------------------------------

class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _text_stream(name, encoding, errors):
    stream = getattr(sys, name)
    if encoding is None and errors in (None, "strict"):
        return stream
    enc = getattr(stream, "encoding", None)
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    if encoding is not None:
        try:
            if enc and codecs.lookup(enc).name == codecs.lookup(encoding).name and errors in (None, "strict"):
                return stream
        except LookupError:
            pass
    stream.flush() if hasattr(stream, "flush") else None
    return _NonClosingTextIOWrapper(buf, encoding=encoding or enc or "utf-8",
                                    errors=errors or "strict", line_buffering=True)


def get_text_stdin(encoding=None, errors=None):
    return _text_stream("stdin", encoding, errors)


def get_text_stdout(encoding=None, errors=None):
    return _text_stream("stdout", encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _text_stream("stderr", encoding, errors)


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", sys.stdin)


def get_binary_stdout():
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_binary_stderr():
    return getattr(sys.stderr, "buffer", sys.stderr)


def get_binary_stream(name):
    return {"stdin": get_binary_stdin, "stdout": get_binary_stdout, "stderr": get_binary_stderr}[name]()


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": get_text_stdin, "stdout": get_text_stdout, "stderr": get_text_stderr}[name](
        encoding, errors)


# ---- file objects --------------------------------------------------------------

class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.remove(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename in ("-", b"-"):
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        kw = {} if binary else {"encoding": encoding, "errors": errors}
        return open(filename, mode, **kw), True
    if "r" in mode or "x" in mode or "a" in mode or "+" in mode:
        raise ValueError("Atomic writes only make sense with 'w'-mode.")
    import stat
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    while True:
        tmp = os.path.join(os.path.dirname(os.path.abspath(filename)),
                           f".__atomic-write{''.join(random.choices(string.ascii_lowercase, k=8))}")
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else stat.S_IMODE(perm))
            break
        except FileExistsError:
            continue
    kw = {} if binary else {"encoding": encoding, "errors": errors}
    f = open(fd, mode, **kw)
    return _AtomicFile(f, tmp, os.path.abspath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors, atomic)
        elif "r" in mode:
            self.open()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            self._f, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                     self.errors, self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        return self._f

    def close(self):
        if self._f is not None and self.should_close:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()
        elif self._f is not None:
            try:
                self._f.flush()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper
