"""Exceptions."""
import sys


class DeclarationError(TypeError, ValueError):
    """Invalid combination of declaration keywords."""


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        echo(f"Error: {self.format_message()}", file=file)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        color = None
        hint = ""
        if self.ctx is not None and self.ctx.command.get_help_option(self.ctx) is not None:
            hint = (f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' "
                    "for help.\n")
        if self.ctx is not None:
            color = self.ctx.color
            echo(f"{self.ctx.get_usage()}\n{hint}", file=file, color=color)
        echo(f"Error: {self.format_message()}", file=file, color=color)


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        echo(self.format_message(), file=file, color=self.ctx.color)


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        if isinstance(hint, (list, tuple)):
            hint = " / ".join(f"'{h}'" for h in hint)
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        if isinstance(hint, (list, tuple)):
            hint = " / ".join(f"'{h}'" for h in hint)
        ptype = self.param_type
        if ptype is None and self.param is not None:
            ptype = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = f"{msg}. {extra}" if msg else extra
        s = "Missing"
        if ptype:
            s += f" {ptype}"
        if hint:
            s += f" {hint}"
        s += "."
        if msg:
            s += f" {msg}"
        return s


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        return f"{self.message} Did you mean {', '.join(sorted(self.possibilities))}?"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        from .utils import format_filename
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = format_filename(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


class Abort(RuntimeError):
    """Abort the program (standalone: exit status 1)."""


class Exit(RuntimeError):
    __slots__ = ("exit_code",)

    def __init__(self, code=0):
        self.exit_code = code
        super().__init__(code)
