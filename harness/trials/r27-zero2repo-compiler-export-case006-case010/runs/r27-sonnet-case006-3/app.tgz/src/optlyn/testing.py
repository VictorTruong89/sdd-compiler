"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils
from .utils import _NonClosingTextIOWrapper


class _TeeBuffer(io.BytesIO):
    def __init__(self, mix):
        super().__init__()
        self._mix = mix

    def write(self, b):
        self._mix.write(b)
        return super().write(b)

    def close(self):
        pass


class _Mix(io.BytesIO):
    def close(self):
        pass


class _Stream(io.TextIOWrapper):
    def __init__(self, buffer, name, **kw):
        super().__init__(buffer, **kw)
        self._name = name

    @property
    def name(self):
        return self._name

    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


class _EchoingStdin(io.BytesIO):
    def __init__(self, data, out):
        super().__init__(data)
        self._out = out
        self.paused = False

    def _echo(self, rv):
        if not self.paused:
            self._out.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(super().read(n))

    def read1(self, n=-1):
        return self._echo(super().read1(n))

    def readline(self, n=-1):
        return self._echo(super().readline(n))

    def readlines(self, hint=-1):
        return [self._echo(x) for x in super().readlines(hint)]

    def __iter__(self):
        return iter(self._echo(x) for x in super().__iter__())


class _FdStream:
    """Text stream that reports a real fd and tees into the shared mix."""

    def __init__(self, fd, mix, charset, name, errors="strict"):
        self._fd = fd
        self._mix = mix
        self.written = bytearray()
        raw = self

        class _Raw(io.RawIOBase):
            def writable(self):
                return True

            def fileno(self_inner):
                return fd

            def write(self_inner, b):
                b = bytes(b)
                os.write(fd, b)
                mix.write(b)
                raw.written.extend(b)
                return len(b)

        self.raw = _Raw()
        self.buffer = io.BufferedWriter(self.raw, buffer_size=8192)
        self.stream = _Stream(self.buffer, name, encoding=charset, errors=errors, line_buffering=False,
                              write_through=False)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = f" {self.exception!r}" if self.exception else ""
        return f"<{type(self).__name__}{exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_visible, old_hidden = termui.visible_prompt_func, termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi
        old_forced = formatting.FORCED_WIDTH
        mix = _Mix()
        fd_state = None
        if self.capture == "fd":
            sys.stdout.flush()
            sys.stderr.flush()
            t1 = tempfile.TemporaryFile()
            t2 = tempfile.TemporaryFile()
            saved = (os.dup(1), os.dup(2))
            os.dup2(t1.fileno(), 1)
            os.dup2(t2.fileno(), 2)
            out_s = _FdStream(1, mix, self.charset, "<stdout>")
            err_s = _FdStream(2, mix, self.charset, "<stderr>", errors="backslashreplace")
            fd_state = (t1, t2, saved, out_s, err_s)
            out_stream, err_stream = out_s.stream, err_s.stream
            out_buf = err_buf = None
        else:
            out_buf = _TeeBuffer(mix)
            err_buf = _TeeBuffer(mix)
            out_stream = _Stream(out_buf, "<stdout>", encoding=self.charset, write_through=True)
            err_stream = _Stream(err_buf, "<stderr>", encoding=self.charset,
                                 errors="backslashreplace", write_through=True)
        if self.echo_stdin:
            bytes_in = _EchoingStdin(data, out_stream.buffer if fd_state is None else mix)
        else:
            bytes_in = io.BytesIO(data)
        stdin = _Stream(bytes_in, "<stdin>", encoding=self.charset)
        stdin.mode = "r"

        def visible_input(prompt=None):
            if self.echo_stdin and hasattr(bytes_in, "paused"):
                bytes_in.paused = True
            try:
                sys.stdout.write(prompt or "")
                line = stdin.readline()
            finally:
                if self.echo_stdin and hasattr(bytes_in, "paused"):
                    bytes_in.paused = False
            if not line:
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = stdin.readline()
            if not line:
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo_):
            ch = stdin.read(1)
            if echo_ and ch:
                sys.stdout.write(ch)
                sys.stdout.flush()
            return ch

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        sys.stdin, sys.stdout, sys.stderr = stdin, out_stream, err_stream
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        full_env = self.make_env(env)
        old_env = {}
        try:
            for key, value in full_env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_stream, err_stream, mix, fd_state)
        finally:
            try:
                out_stream.flush()
                err_stream.flush()
            except Exception:
                pass
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func, termui.hidden_prompt_func = old_visible, old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced
            self._buffers = (out_buf, err_buf, mix)
            if fd_state is not None:
                t1, t2, saved, out_s, err_s = fd_state
                os.dup2(saved[0], 1)
                os.dup2(saved[1], 2)
                os.close(saved[0])
                os.close(saved[1])

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        exception = None
        exit_code = 0
        return_value = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as streams:
            out_stream, err_stream, mix, fd_state = streams
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None)
            if prog_name is None:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or [], prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if fd_state is None:
                    out_b = streams[0].buffer.getvalue()
                    err_b = streams[1].buffer.getvalue()
                    mixed = mix.getvalue()
                else:
                    t1, t2, saved, out_s, err_s = fd_state
                    t1.flush()
                    t2.flush()
                    t1.seek(0)
                    t2.seek(0)
                    out_b = t1.read()
                    err_b = t2.read()
                    py = bytes(out_s.written) + bytes(err_s.written)
                    if out_b == bytes(out_s.written) and err_b == bytes(err_s.written):
                        mixed = mix.getvalue()
                    else:
                        mixed = out_b + err_b
                    t1.close()
                    t2.close()
        return Result(self, out_b, err_b, mixed, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
