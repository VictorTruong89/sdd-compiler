"""Decorators."""
import inspect
import re
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option, Parameter
from .globals import get_current_context
from .utils import echo

_SUFFIX_RE = re.compile(r"_(?:command|cmd|group|grp)$")


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def _make_command(f, name, attrs, cls):
    if isinstance(f, Command):
        raise TypeError("Attempted to convert a callback into a command twice.")
    params = list(reversed(getattr(f, "__optlyn_params__", [])))
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    if attrs.get("help") is None:
        doc = inspect.getdoc(f)
        if doc is not None:
            doc = doc.partition("\f")[0]
        attrs["help"] = doc
    if name is None:
        name = re.sub(r"-(?:command|cmd|group|grp)$", "", f.__name__.lower().replace("_", "-"))
    cmd = cls(name=name, callback=f, params=params, **attrs)
    return cmd


def command(name=None, cls=None, **attrs):
    if cls is None:
        cls = Command

    def decorator(f):
        cmd = _make_command(f, name, dict(attrs), cls)
        cmd.__doc__ = f.__doc__
        return cmd

    if callable(name):
        f, name = name, None
        return decorator(f)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(None, cls, **attrs)(name)
    return command(name, cls, **attrs)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if value and not ctx.resilient_parsing:
            echo(ctx.get_help(), color=ctx.color)
            ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)


def _detect_package(depth=2):
    frame = inspect.currentframe()
    try:
        f = frame
        for _ in range(depth):
            f = f.f_back if f is not None else None
        g = f.f_globals if f is not None else None
    finally:
        del frame
    if g is None:
        return None
    pkg = g.get("__name__")
    if pkg == "__main__":
        pkg = g.get("__package__")
    if pkg:
        pkg = pkg.partition(".")[0]
    return pkg


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        package_name = _detect_package(2)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name, version
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata as md
            try:
                version = md.version(package_name)
            except md.PackageNotFoundError:
                dists = md.packages_distributions().get(package_name)
                if dists:
                    try:
                        version = md.version(dists[0])
                    except md.PackageNotFoundError:
                        version = None
                if version is None:
                    raise RuntimeError(
                        f"{package_name!r} is not installed. Try passing 'package_name' instead."
                    ) from None
        if version is None:
            raise RuntimeError("Could not determine the version for the version option; "
                               "pass 'version' or 'package_name'.")
        echo(message % {"prog": prog_name, "package": package_name, "version": version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
