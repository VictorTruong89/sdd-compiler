from optlyn import (Choice, IntRange, argument, command, echo, group, option, pass_context)
from optlyn.testing import CliRunner


def test_AC_basic_command_and_help():
    @command()
    @option("--count", type=int, default=1, help="How many.")
    def hello_cmd(count):
        """Say hello."""
        echo(f"n={count}")

    r = CliRunner()
    assert hello_cmd.name == "hello"
    res = r.invoke(hello_cmd, ["--count", "3"])
    assert res.exit_code == 0 and res.output == "n=3\n"
    res = r.invoke(hello_cmd, ["--help"])
    assert res.exit_code == 0 and "--count COUNT" in res.output and "Say hello." in res.output


def test_AC_group_no_args_is_usage_failure():
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        echo("sub")

    r = CliRunner()
    res = r.invoke(cli, [])
    assert res.exit_code == 2 and "sub" in res.output
    assert r.invoke(cli, ["sub"]).output == "sub\n"
    assert r.invoke(cli, ["nope"]).exit_code == 2


def test_AC_clamp_and_choice():
    @command()
    @option("--n", type=IntRange(0, 10, clamp=True))
    @option("--c", type=Choice(["a", "B"], case_sensitive=False))
    def c(n, c):
        echo(f"{n} {c}")

    assert CliRunner().invoke(c, ["--n", "99", "--c", "b"]).output == "10 B\n"
