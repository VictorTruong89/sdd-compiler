"""CPU baseline profile and packaging. spec: N-000357 N-000358 N-000362 N-000363 N-000364 N-000368 N-000369 N-000370"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_N_000357_import_from_source_tree_and_tokenize_without_downloads(tmp_path):
    # A fresh interpreter, no LINGORA_DATA, no network: the baseline tokenization must run.
    env = dict(os.environ)
    env.pop("LINGORA_DATA", None)
    env["HOME"] = str(tmp_path)  # no ~/lingora_data either
    code = "import lingora; from lingora.tokenize import wordpunct_tokenize as w; print(w('Hello, world!'))"
    out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
    assert out.returncode == 0, out.stderr
    assert out.stdout.strip() == "['Hello', ',', 'world', '!']"


def test_N_000368_flat_pure_python_layout_and_metadata():  # spec: N-000368 N-000369 N-000370 N-000360
    assert os.path.isfile(os.path.join(ROOT, "lingora", "__init__.py"))
    assert os.path.isfile(os.path.join(ROOT, "pyproject.toml"))
    compiled = [f for f in os.listdir(os.path.join(ROOT, "lingora")) if f.endswith((".so", ".pyd"))]
    assert compiled == []


def test_N_000362_no_external_dependencies_declared():  # spec: N-000364 N-000365 N-000366 N-000367
    text = open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8").read()
    assert 'requires-python = ">=3.10"' in text
    assert "dependencies = []" in text

# spec: N-000353 N-000354 N-000355 N-000356 N-000359 N-000361
