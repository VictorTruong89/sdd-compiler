import pytest

from lingora import chunk, classify, metrics, tag, translate
from lingora.tree import Tree


def test_N_000198_default_unigram_regexp_backoff():  # spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000205
    train = [[("a", "DT"), ("cat", "NN")], [("a", "DT"), ("dog", "NN")], [("run", "VB"), ("run", "NN"), ("run", "NN")]]
    uni = tag.UnigramTagger(train)
    assert uni.tag(["a", "run", "zebra"]) == [("a", "DT"), ("run", "NN"), ("zebra", None)]
    rx = tag.RegexpTagger([(r".*s$", "NNS")], backoff=tag.DefaultTagger("X"))
    assert rx.tag(["cats", "go"]) == [("cats", "NNS"), ("go", "X")]
    assert tag.DefaultTagger("N").tag([]) == []
    with pytest.raises(TypeError):
        tag.pos_tag("not a list")


def test_N_000228_chunk_grammar():  # spec: N-000228 N-000236 N-000239 N-000243 N-000246 N-000252
    tagged = [("the", "DT"), ("dog", "NN"), ("barks", "VBZ")]
    t = chunk.RegexpParser("NP: {<DT>?<NN>}").parse(tagged)
    assert t.label() == "S"
    assert t[0] == Tree("NP", [("the", "DT"), ("dog", "NN")]) and t[1] == ("barks", "VBZ")
    assert chunk.RegexpParser("S: {<.*>}").parse([]).leaves() == []


def test_N_000253_chunk_grammar_refused():  # spec: N-000253 N-000254 N-000256
    with pytest.raises(TypeError):
        chunk.RegexpParser(42)


def test_N_000492_naive_bayes_and_tree():  # spec: N-000492 N-000493 N-000494 N-000496 N-000307 N-000308 N-000309 N-000315
    train = [({"w": "good"}, "pos"), ({"w": "fine"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "awful"}, "neg")]
    nb = classify.NaiveBayesClassifier.train(train)
    assert nb.classify({"w": "good"}) == "pos" and nb.classify({"w": "awful"}) == "neg"
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert sorted(nb.labels()) == ["neg", "pos"]
    assert nb.classify({"unseen": 1}) in ("pos", "neg")
    dt = classify.DecisionTreeClassifier.train(train)
    assert dt.classify({"w": "fine"}) == "pos" and dt.classify({"zzz": 1}) in ("pos", "neg")
    assert classify.accuracy(dt, train) == 1.0


def test_N_000498_metrics():  # spec: N-000501 N-000502 N-000503 N-000505 N-000507 N-000509 N-000510
    assert metrics.accuracy([1, 2], [1, 3]) == 0.5
    with pytest.raises(ValueError):
        metrics.accuracy([1], [1, 2])
    assert metrics.edit_distance("kitten", "sitting") == 3
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("", "") == 0
    assert metrics.jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert metrics.precision({1, 2}, {2, 3}) == 0.5 and metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert metrics.precision({1}, set()) is None and metrics.f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        metrics.precision([1], {1})


def test_N_000511_bleu():  # spec: N-000511 N-000512 N-000513 N-000516 N-000335 N-000339
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert translate.bleu(ref, list(ref[0])) == pytest.approx(1.0)
    assert 0.0 < translate.bleu(ref, ["the", "cat", "sat"]) < 1.0
    assert translate.bleu(ref, ["x", "y"]) == 0.0  # no unigram match
    assert translate.bleu(ref, ["the", "cat", "is", "on", "the", "mat", "x"]) < 1.0
