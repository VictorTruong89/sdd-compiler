import io
import sys

import pytest

from lingora import cli, data


def test_N_000414_cli_tokenize_writes_one_line_per_input(monkeypatch, tmp_path, capsys):  # spec: N-000414 N-000415 N-000416
    base = tmp_path / "tokenizers" / "punkt_tab" / "english"
    base.mkdir(parents=True)
    (base / "abbrev_types.txt").write_text("", encoding="utf-8")
    (base / "sent_starters.txt").write_text("", encoding="utf-8")
    (base / "collocations.tab").write_text("", encoding="utf-8")
    (base / "ortho_context.tab").write_text("", encoding="utf-8")
    monkeypatch.setitem(data.__dict__, "path", [str(tmp_path)])
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n\nBye now\n"))
    with pytest.raises(SystemExit) as exc:
        cli.cli.main(args=["tokenize"])
    assert exc.value.code == 0
    assert capsys.readouterr().out == "Hi there .\n\nBye now\n"


def test_N_000417_cli_failure_without_model(monkeypatch, capsys):  # spec: N-000417 N-000418 N-000139
    monkeypatch.setitem(data.__dict__, "path", [])
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n"))
    with pytest.raises(SystemExit) as exc:
        cli.cli.main(args=["tokenize"])
    assert exc.value.code != 0
    assert capsys.readouterr().out == ""


def test_N_000385_data_path_is_mutable_list():  # spec: N-000385 N-000386 N-000387
    assert isinstance(data.path, list)
    data.path[:] = []
    assert data.find("corpora/words") is None
    with pytest.raises(data.ResourceNotFoundError):
        data.require("corpora/words")
