"""Tokenizer tests. spec ids in test names follow the checklist."""
import pytest

from lingora import data
from lingora import tokenize as tk


@pytest.fixture
def punkt_dir(tmp_path, monkeypatch):
    base = tmp_path / "tokenizers" / "punkt_tab" / "english"
    base.mkdir(parents=True)
    (base / "abbrev_types.txt").write_text("mr\ndr\netc\n", encoding="utf-8")
    (base / "sent_starters.txt").write_text("the\nhe\nshe\n", encoding="utf-8")
    (base / "collocations.tab").write_text("mr\tsmith\n", encoding="utf-8")
    (base / "ortho_context.tab").write_text("hello\t16\nworld\t16\nsmith\t76\nthe\t2\nhe\t2\n", encoding="utf-8")
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    monkeypatch.setitem(data.__dict__, "path", [str(tmp_path)])
    return tmp_path


@pytest.fixture
def no_model(monkeypatch):
    monkeypatch.setitem(data.__dict__, "path", [])


def test_N_000089_wordpunct_runs():  # spec: N-000089 N-000090 N-000091
    assert tk.wordpunct_tokenize("Hello, world!  It's 3.5 ok") == [
        "Hello", ",", "world", "!", "It", "'", "s", "3", ".", "5", "ok"]


def test_N_000126_span_tokenize_slices_back():  # spec: N-000126 N-000127 N-000128
    text = "a, bc d"
    spans = tk.WordPunctTokenizer().span_tokenize(text)
    assert [text[s:e] for s, e in spans] == tk.WordPunctTokenizer().tokenize(text)
    assert all(isinstance(s, int) and isinstance(e, int) for s, e in spans)
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_N_000136_empty_and_whitespace_yield_empty():  # spec: N-000136
    for fn in (tk.wordpunct_tokenize, tk.TreebankWordTokenizer().tokenize,
               tk.WhitespaceTokenizer().tokenize, tk.blankline_tokenize,
               tk.TweetTokenizer().tokenize, tk.RegexpTokenizer(r"\w+").tokenize):
        assert fn("") == []
        assert fn("  \n\t ") == []


def test_N_000092_treebank_quotes_and_punct():  # spec: N-000093 N-000094 N-000096 N-000097 N-000099 N-000100
    t = tk.TreebankWordTokenizer().tokenize
    assert t('"Good muffins cost $3.88 in New York," he said.') == [
        "``", "Good", "muffins", "cost", "$", "3.88", "in", "New", "York", ",", "''", "he", "said", "."]
    assert t("a,b 3,000 x:y") == ["a", ",", "b", "3,000", "x", ":", "y"]
    assert t("wait...") == ["wait", "..."]


def test_N_000101_treebank_clitics_and_fused():  # spec: N-000101 N-000102 N-000103
    t = tk.TreebankWordTokenizer().tokenize
    assert t("I can't and we'll go John's") == ["I", "ca", "n't", "and", "we", "'ll", "go", "John", "'s"]
    assert t("gonna cannot") == ["gon", "na", "can", "not"]


def test_N_000105_recommended_keeps_cannot_and_splits_dashes():  # spec: N-000106 N-000107 N-000108 N-000109 N-000110
    rt = lambda s: tk._treebank_core(s, recommended=True)
    assert rt("cannot") == ["cannot"]
    assert rt("a—b *x* wait..... go -- now") == [
        "a", "—", "b", "*", "x", "*", "wait", ".....", "go", "--", "now"]
    assert rt('"hi"') == ["''", "hi", "''"]


def test_N_000113_whitespace_and_blankline():  # spec: N-000113 N-000114 N-000115
    assert tk.WhitespaceTokenizer().tokenize(" a\tb\n c ") == ["a", "b", "c"]
    assert tk.blankline_tokenize("a b\n\n  c\n\n\n d\ne") == ["a b", "c", "d\ne"]


def test_N_000116_regexp_token_and_gap_modes():  # spec: N-000116 N-000117 N-000118
    assert tk.RegexpTokenizer(r"\d+").tokenize("a1b22") == ["1", "22"]
    assert tk.RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["", "a", "b", ""]
    assert tk.RegexpTokenizer(r"\s+", gaps=True, discard_empty=True).tokenize(" a  b ") == ["a", "b"]


def test_N_000119_tweet_tokenizer():  # spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125
    tw = tk.TweetTokenizer
    assert tw().tokenize("don't stop :) #Fun http://x.io") == ["don't", "stop", ":)", "#Fun", "http://x.io"]
    assert tw(preserve_case=False).tokenize("HELLO :D") == ["hello", ":D"]
    assert tw(strip_handles=True).tokenize("@bob hi a@b.c") == ["hi", "a", "@b", ".", "c"]
    assert tw(reduce_len=True).tokenize("nooooo") == ["nooo"]
    assert "café" in tw().tokenize("café")


def test_N_000413_sent_tokenize_requires_model(no_model):  # spec: N-000413 N-000137 N-000138
    with pytest.raises(LookupError):
        tk.sent_tokenize("Hi there.")
    with pytest.raises(LookupError):
        tk.word_tokenize("Hi there.")
    assert tk.word_tokenize("Hi there.", preserve_line=True) == ["Hi", "there", "."]


def test_N_000129_sent_tokenize_with_model(punkt_dir):  # spec: N-000129 N-000130 N-000131 N-000132 N-000133
    text = "Hello world. Mr. Smith went home. He slept. Dr. Jones said etc. then left."
    assert tk.sent_tokenize(text) == [
        "Hello world.", "Mr. Smith went home.", "He slept.", "Dr. Jones said etc. then left."]


def test_N_000111_word_tokenize_splits_sentences(punkt_dir):  # spec: N-000111 N-000112 N-000085
    assert tk.word_tokenize("Hello world. It is fine.") == ["Hello", "world", ".", "It", "is", "fine", "."]
