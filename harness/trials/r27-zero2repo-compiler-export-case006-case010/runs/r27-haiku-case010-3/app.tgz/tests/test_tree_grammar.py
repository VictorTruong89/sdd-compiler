import pytest

from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'a' N
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'chased' | 'slept'
"""


def test_N_000483_tree_basics():  # spec: N-000481 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
    t = Tree("S", [Tree("NP", ["a"]), "b"])
    assert t.label() == "S" and len(t) == 2 and t[1] == "b"
    assert t.leaves() == ["a", "b"]
    assert list(t) == [Tree("NP", ["a"]), "b"]
    assert Tree("X", []) == Tree("X", []) and len(Tree("X", [])) == 0
    with pytest.raises(TypeError):
        Tree("X", "abc")
    with pytest.raises(TypeError):
        Tree("X")


def test_N_000489_bracketed_round_trip():  # spec: N-000489 N-000286 N-000287 N-000289
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert t.leaves() == ["the", "dog", "barks"]
    text = t.pformat()
    assert text.index("S") < text.index("NP") < text.index("VP") and "barks" in text


def test_N_000266_chart_parser_all_trees():  # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the dog chased a cat".split()))
    assert len(trees) == 1 and trees[0].label() == "S"
    assert trees[0].leaves() == "the dog chased a cat".split()
    assert list(ChartParser(g).parse("dog the".split())) == []
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])


def test_N_000272_shift_reduce_agrees_on_unambiguous():  # spec: N-000272 N-000273 N-000274 N-000275
    g = CFG.fromstring(GRAMMAR)
    sr = list(ShiftReduceParser(g).parse("the dog slept".split()))
    ch = list(ChartParser(g).parse("the dog slept".split()))
    assert sr == ch and len(sr) == 1


def test_N_000276_generate_order_and_bound():  # spec: N-000276 N-000277 N-000278 N-000279 N-000477 N-000478
    g = CFG.fromstring(GRAMMAR)
    sents = list(generate(g, n=3))
    assert sents == [
        ["the", "dog", "chased", "the", "dog"],
        ["the", "dog", "chased", "the", "cat"],
        ["the", "dog", "chased", "a", "dog"],
    ]
    assert len(list(generate(g, depth=3))) == 0


def test_N_000264_grammar_objects():  # spec: N-000264 N-000265 N-000466 N-000469 N-000471 N-000480
    g = CFG.fromstring("S -> 'a' N | ''\nN -> 'b'")
    prods = g.productions()
    assert len(prods) == 3
    assert str(g.start()) == "S"
    rhs = prods[0].rhs()
    assert rhs[0] == "a" and not isinstance(rhs[1], str) and str(rhs[1]) == "N"
    assert list(generate(g, n=5)) == [["a", "b"], []]
