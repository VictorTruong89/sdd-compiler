"""Regular-expression chunking over tagged tokens, driven by a chunk grammar.

spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453
spec: N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460 N-000228
spec: N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235 N-000236
spec: N-000237 N-000238 N-000239 N-000240 N-000241 N-000242 N-000243 N-000244
spec: N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251 N-000252
spec: N-000253 N-000254 N-000255 N-000256 N-000257
"""

import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "ChunkRule", "ChinkRule", "ne_chunk", "DEFAULT_ROOT_LABEL"]

DEFAULT_ROOT_LABEL = "S"  # spec: N-000456 (implementer's choice)

_NE_MODEL = "chunkers/maxent_ne_chunker_tab/english_ace_multiclass"
_NE_WORDS = "corpora/words"


class ChunkRule:
    """A chunk rule: every match of ``tag_pattern`` among unchunked tokens becomes a chunk."""

    def __init__(self, label, tag_pattern):
        self.label = label
        self.regex = compile_tag_pattern(tag_pattern)

    kind = "chunk"


class ChinkRule(ChunkRule):
    """A chink rule: matches of ``tag_pattern`` are removed from chunks built by its clause."""

    kind = "chink"


class RegexpParser:
    """Chunk parser. ``grammar`` is chunk-grammar text or a list of ChunkRule/ChinkRule stages."""

    def __init__(self, grammar):  # spec: N-000449 N-000450 N-000451
        if isinstance(grammar, str):
            self._clauses = parse_grammar_text(grammar)
        elif isinstance(grammar, list):
            self._clauses = _clauses_from_stages(grammar)
        else:
            raise TypeError("chunk grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):  # spec: N-000455..N-000460
        """Return a Tree rooted at the sentence label; leaves are the input (token, tag) pairs."""
        if isinstance(tagged, str):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        pairs = []
        for item in tagged:
            if not (isinstance(item, tuple) and len(item) == 2):
                raise TypeError("tagged tokens must be (token, tag) pairs")
            pairs.append(item)
        kids = list(pairs)
        for label, rules in self._clauses:
            kids = _apply_clause(kids, label, rules)
        return Tree(DEFAULT_ROOT_LABEL, kids)


def ne_chunk(tagged_tokens):  # spec: N-000452 N-000257
    """Named-entity chunking. Raises unless the packaged NE model and wordlist are visible."""
    if isinstance(tagged_tokens, str):
        raise TypeError("tagged tokens must be a list of (token, tag) pairs")
    data.require(_NE_MODEL)
    data.require(_NE_WORDS)
    raise NotImplementedError("named-entity chunking is not implemented in this build (see NOTES.md)")


# ---------------------------------------------------------------------------
# Clause application
# ---------------------------------------------------------------------------
def _apply_clause(kids, label, rules):
    built = set()  # ids of chunk Trees created by this clause
    for rule in rules:
        if rule.kind == "chunk":
            kids = _apply_chunk_rule(kids, label, rule, built)
        else:
            kids = _apply_chink_rule(kids, label, rule, built)
    return kids


def _match_spans(tags, regex):
    """Non-overlapping, left-to-right, longest matches over a run of tags.

    Each match is returned as (start, end) token indexes; empty matches are skipped.
    """
    text = "".join("<%s>" % t for t in tags)
    offsets = []
    pos = 0
    for t in tags:
        offsets.append(pos)
        pos += len(t) + 2
    offsets.append(pos)
    index_of = {off: k for k, off in enumerate(offsets)}
    spans = []
    for m in regex.finditer(text):
        if m.start() == m.end():
            continue
        if m.start() not in index_of or m.end() not in index_of:
            continue
        spans.append((index_of[m.start()], index_of[m.end()]))
    return spans


def _apply_chunk_rule(kids, label, rule, built):
    out = []
    for start, end in _runs_with_gaps(kids):
        if isinstance(start, Tree):
            out.append(start)
            continue
        run = kids[start:end]
        tags = [pair[1] for pair in run]
        spans = _merge_touching(_match_spans(tags, rule.regex))
        pos = 0
        for s, e in spans:
            out.extend(run[pos:s])
            chunk = Tree(label, run[s:e])
            built.add(id(chunk))
            out.append(chunk)
            pos = e
        out.extend(run[pos:])
    return out


def _runs_with_gaps(kids):
    """Yield (index, end) for runs of tokens; a Tree child yields (Tree, None)."""
    i = 0
    n = len(kids)
    while i < n:
        if isinstance(kids[i], Tree):
            yield kids[i], None
            i += 1
            continue
        j = i
        while j < n and not isinstance(kids[j], Tree):
            j += 1
        yield i, j
        i = j


def _merge_touching(spans):
    merged = []
    for s, e in spans:  # chunks that touch, with no token between them, are joined
        if merged and merged[-1][1] == s:
            merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    return merged


def _apply_chink_rule(kids, label, rule, built):
    out = []
    for child in kids:
        if isinstance(child, Tree) and id(child) in built:
            tags = [pair[1] for pair in child if not isinstance(pair, Tree)]
            chinked = [False] * len(tags)
            for s, e in _match_spans(tags, rule.regex):
                for k in range(s, e):
                    chinked[k] = True
            if not any(chinked):
                out.append(child)
                continue
            piece = []
            for k, pair in enumerate(child):
                if chinked[k]:
                    if piece:
                        new = Tree(label, piece)
                        built.add(id(new))
                        out.append(new)
                        piece = []
                    out.append(pair)
                else:
                    piece.append(pair)
            if piece:
                new = Tree(label, piece)
                built.add(id(new))
                out.append(new)
        else:
            out.append(child)
    return out


# ---------------------------------------------------------------------------
# Grammar text
# ---------------------------------------------------------------------------
_LABEL_LINE = re.compile(r"^\s*([^\s:{}<>]+)\s*:\s*(.*)$")


def parse_grammar_text(text):
    """Return a list of (label, [rules]) clauses from chunk-grammar text."""
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indented = raw[0] in " \t"
        if current is None or not indented:
            m = _LABEL_LINE.match(raw)
            if not m:
                raise ValueError("chunk grammar clause must start with '<LABEL>: <pattern>': %r" % raw)
            current = (m.group(1), [])
            clauses.append(current)
            body = m.group(2)
        else:
            body = raw.strip()
        for kind, pat in _split_rules(body):
            rule_cls = ChunkRule if kind == "chunk" else ChinkRule
            current[1].append(rule_cls(current[0], pat))
    for label, rules in clauses:
        if not rules:
            raise ValueError("chunk clause %r has no patterns" % label)
    return [(label, rules) for label, rules in clauses]


def _clauses_from_stages(stages):
    clauses = []
    for stage in stages:
        if not isinstance(stage, ChunkRule):
            raise TypeError("chunk-parser stages must be ChunkRule or ChinkRule objects")
        if clauses and clauses[-1][0] == stage.label:
            clauses[-1][1].append(stage)
        else:
            clauses.append((stage.label, [stage]))
    return clauses


def _scan_body(text, i, terminator):
    """Return the index of ``terminator`` that closes a pattern body starting at ``i``."""
    n = len(text)
    while i < n:
        c = text[i]
        if c == "<":
            j = text.find(">", i)
            if j < 0:
                raise ValueError("unterminated tag element in chunk grammar")
            i = j + 1
            continue
        if c == "{" and _QUANT.match(text, i):
            j = text.find("}", i)
            i = j + 1
            continue
        if c == terminator:
            return i
        if c in "{}":
            raise ValueError("unexpected %r in chunk pattern" % c)
        i += 1
    raise ValueError("unterminated chunk pattern")


_QUANT = re.compile(r"\{\d*(,\d*)?\}")


def _split_rules(body):
    rules = []
    text = re.sub(r"\s+", "", body)
    i = 0
    while i < len(text):
        c = text[i]
        if c == "{":
            end = _scan_body(text, i + 1, "}")
            rules.append(("chunk", text[i + 1:end]))
            i = end + 1
        elif c == "}":
            end = _scan_body(text, i + 1, "{")
            rules.append(("chink", text[i + 1:end]))
            i = end + 1
        else:
            raise ValueError("chunk pattern must be {...} or }...{: %r" % body)
    return rules


# ---------------------------------------------------------------------------
# Tag patterns: <regex> elements with optional quantifiers, compiled to a regex
# over the string "<tag1><tag2>..." in which each element matches one whole tag.
# ---------------------------------------------------------------------------
def compile_tag_pattern(pattern):
    if not isinstance(pattern, str):
        raise TypeError("tag pattern must be a str")
    text = re.sub(r"\s+", "", pattern)
    out = []
    i = 0
    n = len(text)
    while i < n:
        if text[i] != "<":
            raise ValueError("tag pattern element must be written <...>: %r" % pattern)
        j = i + 1
        content = []
        while j < n and text[j] != ">":
            if text[j] == "\\" and j + 1 < n:
                content.append(text[j:j + 2])
                j += 2
                continue
            content.append("[^<>]" if text[j] == "." else text[j])
            j += 1
        if j >= n:
            raise ValueError("unterminated tag element in %r" % pattern)
        i = j + 1
        quant = ""
        if i < n and text[i] in "?*+":
            quant = text[i]
            i += 1
        elif i < n and text[i] == "{":
            k = text.find("}", i)
            if k < 0:
                raise ValueError("unterminated quantifier in %r" % pattern)
            quant = text[i:k + 1]
            i = k + 1
        out.append("(?:<(?:%s)>)%s" % ("".join(content), quant))
    return re.compile("".join(out))

# spec: N-000025 N-000026 N-000027 N-000037 N-000039 N-000393 N-000394
