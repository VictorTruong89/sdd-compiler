"""BLEU score over token lists (Papineni et al., 2002), sentence level.

spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
spec: N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342
"""

import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):  # spec: N-000514 N-000515
    """Sentence BLEU of ``hypothesis`` against ``references`` (lists of token lists).

    ``weights``: one weight per n-gram order starting from unigrams; the
    default weights unigrams and bigrams equally. Unsmoothed unless
    ``smoothing_function(numerators, denominators) -> list of precisions`` is given.
    """
    if not isinstance(references, list) or not all(isinstance(r, list) for r in references):
        raise TypeError("references must be a list of token lists")
    if not isinstance(hypothesis, list):
        raise TypeError("hypothesis must be a token list")
    weights = list(weights)
    if not weights:
        raise ValueError("weights must not be empty")
    max_n = len(weights)
    hyp_len = len(hypothesis)
    if hyp_len == 0 or not references:
        return 0.0
    numerators, denominators = [], []
    for n in range(1, max_n + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in references:
            for gram, cnt in _ngrams(ref, n).items():
                if cnt > max_ref[gram]:
                    max_ref[gram] = cnt
        clipped = sum(min(cnt, max_ref[gram]) for gram, cnt in hyp_counts.items())
        numerators.append(clipped)
        denominators.append(total)
    if smoothing_function is not None:
        precisions = list(smoothing_function(numerators, denominators))
    else:
        precisions = [(num / den) if den else 0.0 for num, den in zip(numerators, denominators)]
    if any(p <= 0 for p, w in zip(precisions, weights) if w > 0):
        return 0.0
    log_avg = sum(w * math.log(p) for p, w in zip(precisions, weights) if w > 0)
    # Brevity penalty against the reference length closest to the candidate length.
    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > closest:
        bp = 1.0
    else:
        bp = math.exp(1 - closest / hyp_len)
    return bp * math.exp(log_avg)
