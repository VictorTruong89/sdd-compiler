"""Tokenizers: words, punctuation, sentences, spans.

spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410
spec: N-000411 N-000412 N-000413 N-000081 N-000086 N-000087 N-000088 N-000089
spec: N-000090 N-000091 N-000092 N-000093 N-000094 N-000095 N-000096 N-000097
spec: N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104 N-000105
spec: N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000113
spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121
spec: N-000122 N-000123 N-000124 N-000125 N-000126 N-000127 N-000128 N-000136
spec: N-000137 N-000138 N-000082 N-000088
"""

import re

from . import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str" % name)


# ---------------------------------------------------------------------------
# Word/punctuation tokenizer (spec: N-000089..N-000091)
# ---------------------------------------------------------------------------
_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    _check_text(text)
    return _WORDPUNCT.findall(text)


class WordPunctTokenizer:
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):  # spec: N-000126..N-000128
        _check_text(text)
        return [(m.start(), m.end()) for m in _WORDPUNCT.finditer(text)]


# ---------------------------------------------------------------------------
# Penn Treebank conventions (spec: N-000092..N-000103)
# ---------------------------------------------------------------------------
_OPEN_DOUBLE_AFTER = re.compile(r"([ (\[{<])''")
_SEMI_ETC = re.compile(r"[;@#$%&?!]")
_BRACKETS = re.compile(r"[\]\[\(\)\{\}<>]")
_COMMA_COLON = re.compile(r"([,:])(?!\d)")
_ELLIPSIS = re.compile(r"\.\.\.")
_FINAL_PERIOD = re.compile(r"(?<!\.)\.(?=[\]\)\}>\"']*\s*$)")

_FUSED2 = {
    "cannot": ("can", "not"),
    "d'ye": ("d", "'ye"),
    "gimme": ("gim", "me"),
    "gonna": ("gon", "na"),
    "gotta": ("got", "ta"),
    "lemme": ("lem", "me"),
    "more'n": ("more", "'n"),
    "wanna": ("wan", "na"),
}
_FUSED3 = {"'tis": ("'t", "is"), "'twas": ("'t", "was")}
_CLITIC = re.compile(r"(?i)^(.+?)(n't|'ll|'re|'ve|'s|'m|'d)$")


def _split_fused(token, keep_cannot):
    low = token.lower()
    table = dict(_FUSED2)
    table.update(_FUSED3)
    if keep_cannot:
        table.pop("cannot", None)
    if low in table:
        a, b = table[low]
        return [token[: len(a)], token[len(a):]]
    return None


def _split_clitic(token):
    if len(token) > 3 and token.lower().endswith("n't"):
        return [token[:-3], token[-3:]]
    m = _CLITIC.match(token)
    if m and m.group(1):
        return [m.group(1), m.group(2)]
    if len(token) > 1 and token.endswith("'") and not token.endswith("''"):
        return [token[:-1], "'"]
    return None


def _treebank_core(text, recommended):
    """Shared Penn Treebank pipeline; ``recommended`` enables LINGORA's improvements."""
    # Starting quotes. Opening '' (after a space or bracket) is converted first so
    # that the quote tokens inserted below are not converted again.
    text = _OPEN_DOUBLE_AFTER.sub(lambda m: m.group(1) + " `` ", text)
    if recommended:
        text = re.sub(r'\A"', " '' ", text)  # recommended: a leading straight quote closes
        text = re.sub(r'(?<=[ (\[{<])"', " `` ", text)
    else:
        text = re.sub(r'(^|[ (\[{<])"', lambda m: m.group(1) + " `` ", text)
    # Punctuation.
    if recommended:
        text = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), text)
    else:
        text = _ELLIPSIS.sub(" ... ", text)
    text = _FINAL_PERIOD.sub(" . ", text)
    text = _COMMA_COLON.sub(lambda m: " %s " % m.group(1), text)
    text = _SEMI_ETC.sub(lambda m: " %s " % m.group(0), text)
    # Parentheses and brackets.
    text = _BRACKETS.sub(lambda m: " %s " % m.group(0), text)
    if recommended:
        text = re.sub(r"[\u2012-\u2015*]", lambda m: " %s " % m.group(0), text)
        text = re.sub("[\u00ab\u00bb\u201c\u201d\u201e\u201f\u2018\u2019\u201a\u201b]", lambda m: " %s " % m.group(0), text)
        text = re.sub(r"--", lambda m: " -- ", text)
    # Ending quotes.
    text = text.replace("''", " '' ")
    text = text.replace('"', " '' ")
    tokens = []
    for raw in text.split():
        pieces = _split_fused(raw, keep_cannot=recommended)
        if pieces is None:
            pieces = _split_clitic(raw)
        if pieces is None:
            tokens.append(raw)
        else:
            tokens.extend(p for p in pieces if p)
    return tokens


class TreebankWordTokenizer:
    def tokenize(self, text):  # spec: N-000092
        _check_text(text)
        return _treebank_core(text, recommended=False)


# ---------------------------------------------------------------------------
# Recommended word tokenizer and sentence tokenizer (spec: N-000104..N-000112)
# ---------------------------------------------------------------------------
def sent_tokenize(text, language="english"):  # spec: N-000129..N-000133
    _check_text(text)
    params = _punkt.load_parameters(language)
    return _punkt.split_sentences(text, params)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer; splits sentences first unless ``preserve_line``."""  # spec: N-000111 N-000112
    _check_text(text)
    if preserve_line:
        return _treebank_core(text, recommended=True)
    tokens = []
    for sent in sent_tokenize(text, language):
        tokens.extend(_treebank_core(sent, recommended=True))
    return tokens


# ---------------------------------------------------------------------------
# Whitespace and blank-line (spec: N-000113..N-000115)
# ---------------------------------------------------------------------------
class WhitespaceTokenizer:
    _RE = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return self._RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [(m.start(), m.end()) for m in self._RE.finditer(text)]


_BLANKLINE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    _check_text(text)
    return [piece for piece in _BLANKLINE.split(text) if piece.strip() != ""]


# ---------------------------------------------------------------------------
# Regular-expression tokenizer (spec: N-000116..N-000118)
# ---------------------------------------------------------------------------
class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=False):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._re = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard = bool(discard_empty)

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            pieces = []
            pos = 0
            for m in self._re.finditer(text):
                pieces.append(text[pos:m.start()])
                pos = m.end()
            pieces.append(text[pos:])
        else:
            pieces = [m.group(0) for m in self._re.finditer(text)]
        if self._discard:
            pieces = [p for p in pieces if p != ""]
        return pieces

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            spans = []
            pos = 0
            for m in self._re.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._re.finditer(text)]
        if self._discard:
            spans = [s for s in spans if s[1] > s[0]]
        return spans


# ---------------------------------------------------------------------------
# Tweet tokenizer (spec: N-000119..N-000125)
# ---------------------------------------------------------------------------
_EMOTICON = r"(?:[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]|<3)"
_TWEET_TOKEN = re.compile(
    r"(" + _EMOTICON + r")"
    r"|(https?://\S+|www\.\S+)"
    r"|([#@]\w+)"
    r"|(\.{2,})"
    r"|([+\-]?\d+(?:[.,]\d+)*)"
    r"|(\w+(?:['\u2019\-]\w+)*)"
    r"|(\S)"
)
_HANDLE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REPEAT = re.compile(r"(.)\1{3,}", re.S)
_EMOTICON_FULL = re.compile(_EMOTICON)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve = bool(preserve_case)
        self._reduce = bool(reduce_len)
        self._strip = bool(strip_handles)

    def tokenize(self, text):  # spec: N-000119..N-000125
        _check_text(text)
        if self._strip:
            text = _HANDLE.sub(" ", text)
        if self._reduce:
            text = _REPEAT.sub(lambda m: m.group(1) * 3, text)
        out = []
        for m in _TWEET_TOKEN.finditer(text):
            tok = m.group(0)
            if _EMOTICON_FULL.fullmatch(tok):
                out.append(tok)  # emoticons keep their case
            elif self._preserve:
                out.append(tok)
            else:
                out.append(tok.lower())
        return out

# spec: N-000022 N-000030 N-000033 N-000066 N-000067 N-000084 N-000031
