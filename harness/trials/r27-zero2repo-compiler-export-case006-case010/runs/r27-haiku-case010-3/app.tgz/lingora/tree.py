"""Constituent trees: ``Tree(label, children)`` and bracketed tree text.

spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
spec: N-000489 N-000490 N-000491 N-000281 N-000282 N-000283 N-000284 N-000285
spec: N-000286 N-000287 N-000288 N-000289 N-000290 N-000291
"""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN = re.compile(r"\(|\)|[^\s()]+")


def _leaf_text(leaf):
    """A tagged leaf ``(token, tag)`` prints as ``(tag token)``; other leaves print as text."""
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "(%s %s)" % (leaf[1], leaf[0])
    return str(leaf)


class Tree:
    """A labelled node. Children are ``str`` leaves or ``Tree`` nodes, in order."""

    def __init__(self, label, children):  # spec: N-000486 N-000487 N-000488
        if isinstance(children, (str, bytes)):
            raise TypeError("children must be a list of children, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of children")
        self._label = label
        self._children = list(children)

    # -- structure ---------------------------------------------------------
    def label(self):  # spec: N-000483
        return self._label

    def leaves(self):  # spec: N-000283
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __iter__(self):  # spec: N-000483
        return iter(self._children)

    def __len__(self):  # spec: N-000284
        return len(self._children)

    def __getitem__(self, index):  # spec: N-000284
        return self._children[index]

    # -- comparison --------------------------------------------------------
    def __eq__(self, other):  # spec: N-000285
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    # -- text --------------------------------------------------------------
    @classmethod
    def fromstring(cls, s):  # spec: N-000489 N-000286
        """Build a tree from bracketed text ``(<label> <child> ...)``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        toks = _BRACKET_TOKEN.findall(s)
        pos = 0

        def fail(msg):
            raise ValueError("malformed bracketed tree text: %s" % msg)

        def parse_node():
            nonlocal pos
            if pos >= len(toks) or toks[pos] != "(":
                fail("expected '('")
            pos += 1
            if pos >= len(toks) or toks[pos] in ("(", ")"):
                fail("expected a label")
            label = toks[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    fail("missing ')'")
                tok = toks[pos]
                if tok == ")":
                    pos += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos += 1

        tree = parse_node()
        if pos != len(toks):
            fail("text after the closing ')'")
        return tree

    def _flat(self):
        parts = [child._flat() if isinstance(child, Tree) else _leaf_text(child) for child in self._children]
        if not parts:
            return "(%s)" % self._label
        return "(%s %s)" % (self._label, " ".join(parts))

    def pformat(self, margin=70):  # spec: N-000287 N-000490
        """Pretty-printed bracketed text: pre-order, one child per line when long."""
        return self._pformat(0, margin)

    def _pformat(self, indent, margin):
        flat = self._flat()
        has_subtree = any(isinstance(c, Tree) for c in self._children)
        if indent + len(flat) <= margin or not has_subtree:
            return flat
        lines = ["(%s" % self._label]
        pad = " " * (indent + 2)
        for child in self._children:
            if isinstance(child, Tree):
                sub = child._pformat(indent + 2, margin).split("\n")
            else:
                sub = [_leaf_text(child)]
            lines.append(pad + sub[0])
            lines.extend(sub[1:])  # continuation lines already carry absolute indent
        lines[-1] += ")"
        return "\n".join(lines)

    def __str__(self):
        return self._flat()

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

# spec: N-000040 N-000041 N-000042 N-000043
