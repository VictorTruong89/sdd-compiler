"""Packaged-resource finder for LINGORA.

``path`` is a mutable list of directories searched for packaged resources.
Callers may replace its contents in place; every lookup reads the list at call
time. An empty list means no packaged resource is visible.

spec: N-000385 N-000386 N-000387 N-000388 N-000397 N-000398 N-000402
"""

import os

__all__ = ["path", "ResourceNotFoundError", "find", "require", "read_lines", "read_text"]


class ResourceNotFoundError(LookupError):
    """A packaged resource that a path needs is not visible on ``path``."""


def _initial_path():
    # Implementer's choice (N-000385): the LINGORA_DATA environment variable
    # (os.pathsep separated) and ~/lingora_data. Nothing is downloaded.
    dirs = [d for d in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if d]
    dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return dirs


path = _initial_path()  # spec: N-000385


def _check_rel(rel):
    if not rel or rel.startswith("/") or ".." in rel.split("/"):
        raise ValueError("invalid resource name: %r" % (rel,))


def find(rel):
    """Return the first existing location of resource ``rel``, or None. spec: N-000386"""
    _check_rel(rel)
    for base in list(path):
        candidate = os.path.join(base, *rel.split("/"))
        if os.path.exists(candidate):
            return candidate
    return None


def require(rel):
    """Return the location of resource ``rel``; raise ResourceNotFoundError if absent."""
    found = find(rel)
    if found is None:
        raise ResourceNotFoundError(
            "packaged resource %r is not visible in data.path" % (rel,)
        )
    return found


def read_lines(rel):
    """Read a UTF-8 text resource; each line without its terminator is one entry."""  # spec: N-000398
    with open(require(rel), encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


def read_text(rel):
    with open(require(rel), encoding="utf-8") as fh:
        return fh.read()
