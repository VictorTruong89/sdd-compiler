"""Command line: ``lingora tokenize`` reads text on stdin and writes one token line per input line.

spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000134 N-000135
spec: N-000139 N-000032 N-000083
"""

import argparse
import sys

from .tokenize import word_tokenize

__all__ = ["cli", "Group"]


class Group:
    """A command group. ``main(args=..., standalone_mode=True)`` runs a subcommand."""

    prog = "lingora"

    def main(self, args=None, standalone_mode=True):  # spec: N-000414 N-000417
        if args is None:
            args = sys.argv[1:]
        parser = self._parser()
        try:
            ns = parser.parse_args(list(args))
        except SystemExit as exc:
            code = exc.code if isinstance(exc.code, int) else 2
            if standalone_mode:
                sys.exit(code)
            return code
        code = ns.func(ns)
        if standalone_mode:
            sys.exit(code)
        return code

    def _parser(self):
        parser = argparse.ArgumentParser(prog=self.prog)
        sub = parser.add_subparsers(dest="command", required=True)
        tok = sub.add_parser("tokenize", help="tokenize each line of standard input")
        tok.add_argument("--language", default="english", help="Punkt language directory name")  # spec: N-000420
        tok.add_argument("--delimiter", default=" ", help="token delimiter (default: a space)")
        tok.add_argument("--encoding", default="utf-8", help="input and output encoding")
        tok.set_defaults(func=_tokenize_command)
        return parser


def _tokenize_command(ns):
    """Return 0 on success, 1 when a line cannot be tokenized (no line is written for it)."""
    try:
        stdin = sys.stdin
        for raw in stdin:
            line = raw.rstrip("\r\n")
            try:
                tokens = word_tokenize(line, language=ns.language, preserve_line=False)
            except Exception as exc:  # spec: N-000139 - missing Punkt models end the run
                sys.stderr.write("lingora: %s\n" % exc)
                return 1
            sys.stdout.write(ns.delimiter.join(tokens) + "\n")
        sys.stdout.flush()
        return 0
    except KeyboardInterrupt:
        return 130


cli = Group()

# spec: N-000084
