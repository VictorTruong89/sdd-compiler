"""Evaluation metrics: edit distance, Jaccard, accuracy, precision, recall, f-measure.

spec: N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505
spec: N-000506 N-000507 N-000508 N-000509 N-000510 N-000319 N-000320 N-000321
spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329
spec: N-000330 N-000331 N-000332 N-000333 N-000334 N-000343 N-000344 N-000345
spec: N-000346 N-000347 N-000348
"""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def accuracy(reference, test):  # spec: N-000501 N-000502 N-000330 N-000343
    """Fraction of positions at which two equal-length lists hold equal values."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        return 0.0
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):  # spec: N-000503..N-000506
    """Levenshtein distance; with ``transpositions`` an adjacent swap costs 1.

    A transposition needs its two characters adjacent in both strings and
    nothing inserted or deleted between them (optimal string alignment).
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def jaccard_distance(label1, label2):  # spec: N-000507
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")  # spec: N-000509


def precision(reference, test):  # spec: N-000332 N-000344 N-000345 N-000346
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):  # spec: N-000332 N-000347 N-000345
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):  # spec: N-000333 N-000334 N-000346
    """Weighted harmonic mean of precision and recall; None when no number results."""
    _check_sets(reference, test)
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    return 1.0 / (alpha / p + (1 - alpha) / r)

# spec: N-000046
