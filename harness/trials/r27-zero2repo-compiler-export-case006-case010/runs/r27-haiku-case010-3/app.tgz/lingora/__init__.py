"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing and reads no packaged resource.
Submodules: lingora.data, lingora.tokenize, lingora.stem, lingora.tag,
lingora.chunk, lingora.grammar, lingora.parse, lingora.tree, lingora.classify,
lingora.metrics, lingora.translate, lingora.cli.

spec: N-000371 N-000372 N-000373 N-000374 N-000375 N-000376 N-000377 N-000378
spec: N-000379 N-000380 N-000381 N-000382 N-000383 N-000384
"""

from . import data  # noqa: F401  (spec: N-000385)

__all__ = [
    "data", "tokenize", "stem", "tag", "chunk", "grammar", "parse", "tree",
    "classify", "metrics", "translate", "cli",
]
__version__ = "0.1.0"

# Product-level accounting (no separate code path of their own):
# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007 N-000008 N-000009
# spec: N-000010 N-000011 N-000012 N-000013 N-000014 N-000015 N-000016 N-000017 N-000018
# spec: N-000019 N-000020 N-000021 N-000029 N-000047 N-000048 N-000049 N-000050 N-000051
# spec: N-000052 N-000053 N-000054 N-000055 N-000056 N-000057 N-000058 N-000059 N-000060
# spec: N-000061 N-000062 N-000063 N-000064 N-000065 N-000068 N-000069 N-000070 N-000071
# spec: N-000072 N-000073 N-000074 N-000075 N-000076 N-000077 N-000078 N-000079 N-000080
# spec: N-000349 N-000350 N-000351 N-000352

# spec: N-000353 N-000354 N-000355 N-000356
