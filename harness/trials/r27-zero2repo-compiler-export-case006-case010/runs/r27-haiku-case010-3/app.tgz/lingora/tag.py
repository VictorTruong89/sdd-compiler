"""Part-of-speech taggers: sequential taggers the caller trains, and the recommended
averaged-perceptron tagger for English and Russian.

spec: N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439 N-000440
spec: N-000441 N-000442 N-000443 N-000444 N-000445 N-000196 N-000197 N-000198
spec: N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206
spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
spec: N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222
spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000187 N-000188 N-000189
spec: N-000190 N-000191 N-000192 N-000193 N-000194 N-000195
"""

import json
import re
from collections import Counter, defaultdict

from . import data

__all__ = [
    "DefaultTagger",
    "UnigramTagger",
    "RegexpTagger",
    "NgramTagger",
    "BigramTagger",
    "TrigramTagger",
    "AffixTagger",
    "pos_tag",
]

RUSSIAN_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "ADVPRO": "ADV",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM", "APRO": "DET",
    "SPRO": "PRON", "INTJ": "X", "PRAEDIC": "ADV", "PARENTH": "X", "COM": "X", "NONLEX": "X",
}


def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str, got %r" % (tok,))
    return tokens


class _TaggerBase:
    """Tags a whole token list; a backoff tagger fills the tokens left untagged."""

    backoff = None

    def _tag_list(self, tokens):  # returns list of tags or None
        raise NotImplementedError

    def tag(self, tokens):  # spec: N-000444 N-000445 N-000196 N-000197
        tokens = _check_tokens(tokens)
        if not tokens:
            return []
        tags = self._tag_list(tokens)
        if self.backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self.backoff.tag(tokens)  # spec: N-000205 N-000206
                for i in missing:
                    tags[i] = fallback[i][1]
        return list(zip(tokens, tags))


class DefaultTagger(_TaggerBase):  # spec: N-000198
    def __init__(self, tag):
        self._tag = tag

    def _tag_list(self, tokens):
        return [self._tag for _ in tokens]


class UnigramTagger(_TaggerBase):  # spec: N-000199 N-000200 N-000201
    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for pair in sentence:
                word, tag = pair
                counts[word][tag] += 1
        self._model = {}
        for word, cnt in counts.items():
            # Ties: the tag seen first in training wins (Counter keeps insertion order).
            self._model[word] = cnt.most_common(1)[0][0]

    def _tag_list(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(_TaggerBase):  # spec: N-000202 N-000203 N-000204
    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def _tag_list(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for regex, rule_tag in self._rules:
                if regex.match(tok):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


class NgramTagger(_TaggerBase):
    """Context tagger: the tag of a word given the preceding ``n - 1`` tags."""

    def __init__(self, n, train=None, backoff=None):
        self._n = n
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in (train or []):
            history = ()
            for word, tag in sentence:
                counts[(history, word)][tag] += 1
                history = (history + (tag,))[-(n - 1):] if n > 1 else ()
        self._model = {key: cnt.most_common(1)[0][0] for key, cnt in counts.items()}

    def _tag_list(self, tokens):
        out = []
        history = ()
        for tok in tokens:
            tag = self._model.get((history, tok))
            out.append(tag)
            history = (history + ((tag,) if tag is not None else (None,)))[-(self._n - 1):] if self._n > 1 else ()
        return out


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_TaggerBase):
    """Tags by the word's prefix or suffix seen in training."""

    def __init__(self, train=None, affix_length=-3, backoff=None):
        self.backoff = backoff
        self._len = affix_length
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for word, tag in sentence:
                if len(word) >= abs(affix_length):
                    counts[self._affix(word)][tag] += 1
        self._model = {a: cnt.most_common(1)[0][0] for a, cnt in counts.items()}

    def _affix(self, word):
        if self._len < 0:
            return word[self._len:]
        return word[: self._len]

    def _tag_list(self, tokens):
        return [self._model.get(self._affix(t)) if len(t) >= abs(self._len) else None for t in tokens]


# ---------------------------------------------------------------------------
# Averaged perceptron (recommended tagger)
# ---------------------------------------------------------------------------
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


_perceptron_cache = {}


def _load_perceptron(lang):
    if lang in _perceptron_cache:
        return _perceptron_cache[lang]
    base = "taggers/averaged_perceptron_tagger_%s" % lang
    prefix = "%s/averaged_perceptron_tagger_%s" % (base, lang)
    data.require(base)  # ResourceNotFoundError when the resource is absent
    weights = json.loads(data.read_text(prefix + ".weights.json"))
    tagdict = json.loads(data.read_text(prefix + ".tagdict.json"))
    classes = json.loads(data.read_text(prefix + ".classes.json"))
    model = _Perceptron(weights, tagdict, list(classes))
    _perceptron_cache[lang] = model
    return model


def _perceptron_tag(model, tokens):
    prev, prev2 = _START
    output = []
    context = _START + [_normalize(w) for w in tokens] + _END
    for i, word in enumerate(tokens):
        tag = model.tagdict.get(word)
        if not tag:
            tag = model.predict(_features(i, word, context, prev, prev2))
        output.append(tag)
        prev2 = prev
        prev = tag
    return output


def _universal_table():
    rel = "taggers/universal_tagset/en-ptb.map"
    table = {}
    for line in data.read_lines(rel):
        parts = line.split("\t")
        if len(parts) == 2:
            table[parts[0]] = parts[1]
    return table


def pos_tag(tokens, tagset=None, lang="eng"):  # spec: N-000440 N-000441 N-000442 N-000443
    """Tag a token list with the recommended tagger for ``lang`` ('eng' or 'rus')."""
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for the recommended tagger: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    if not tokens:
        return []
    tags = _perceptron_tag(model, tokens)
    if tagset == "universal":
        if lang == "eng":
            table = _universal_table()  # raises if the universal tagset tables are absent
            tags = [table.get(t, "X") for t in tags]
        else:
            tags = [RUSSIAN_TO_UNIVERSAL.get(t.split("=")[0], "X") for t in tags]  # spec: N-000216
    return list(zip(tokens, tags))

# spec: N-000024 N-000025 N-000035 N-000036 N-000390 N-000391 N-000392 N-000400 N-000401
