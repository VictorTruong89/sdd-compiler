"""Shared checks for parsers."""

from ..grammar import Nonterminal


def check_tokens(grammar, tokens):
    """Return ``tokens`` as a list of str; raise if one no production produces.

    spec: N-000472 N-000475 N-000476 N-000292 N-000294
    """
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    tokens = list(tokens)
    terminals = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str, got %r" % (tok,))
        if tok not in terminals:
            raise ValueError("no production produces the token %r" % tok)
    return tokens


def productions_by_lhs(grammar):
    table = {}
    for prod in grammar.productions():
        table.setdefault(str(prod.lhs()), []).append(prod)
    return table


def is_nonterminal(sym):
    return isinstance(sym, Nonterminal)
