"""Enumerate sentences a CFG derives.

spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480
"""

from itertools import count

from ..grammar import Nonterminal

__all__ = ["generate"]

_MAX_ITERATIVE_DEPTH = 60


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of str) derivable from ``start``.

    ``n``: maximum number of sentences (None: no limit).
    ``depth``: derivation depth bound (None: no bound).
    ``start``: a symbol or str (None: the grammar's start symbol).
    Expansion follows production order, depth first. Terminals that are the
    empty string add no token. With ``n`` and no ``depth`` the bound is
    increased step by step so that recursive grammars still yield sentences.
    """
    if start is None:
        start_sym = grammar.start()
    else:
        start_sym = start if isinstance(start, Nonterminal) else Nonterminal(start)
    if n is not None and (isinstance(n, bool) or not isinstance(n, int)):
        raise TypeError("n must be an int or None")
    if depth is not None and (isinstance(depth, bool) or not isinstance(depth, int)):
        raise TypeError("depth must be an int or None")
    return _generate(grammar, start_sym, depth, n)


def _generate(grammar, start_sym, depth, n):
    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(str(prod.lhs()), []).append(prod)

    def dfs(form, used, bound, out):
        for idx, sym in enumerate(form):
            if isinstance(sym, Nonterminal):
                break
        else:
            out.append([s for s in form if isinstance(s, str) and s != ""])
            return
        if bound is not None and used >= bound:
            return
        for prod in by_lhs.get(str(sym), []):
            dfs(list(form[:idx]) + list(prod.rhs()) + list(form[idx + 1:]), used + 1, bound, out)
            if len(out) > _SAFETY_LIMIT:
                return

    if depth is not None or n is None:
        out = []
        dfs([start_sym], 0, depth, out)
        if n is not None:
            out = out[:n]
        for sent in out:
            yield sent
        return

    # n given, no depth: plain depth-first order if the search space is finite
    # (within the budget); otherwise deepen the bound step by step.
    try:
        out = []
        _dfs_budget(by_lhs, [start_sym], out, _EXPANSION_BUDGET)
    except _BudgetExceeded:
        out = None
    if out is not None:
        for sent in out[:n]:
            yield sent
        return

    seen = set()
    produced = 0
    for bound in count(1):
        out = []
        dfs([start_sym], 0, bound, out)
        for sent in out:
            key = tuple(sent)
            if key in seen:
                continue
            seen.add(key)
            yield sent
            produced += 1
            if produced >= n:
                return
        if bound >= _MAX_ITERATIVE_DEPTH:
            return


_SAFETY_LIMIT = 200000
_EXPANSION_BUDGET = 20000


class _BudgetExceeded(Exception):
    pass


def _dfs_budget(by_lhs, form, out, budget):
    """Unbounded depth-first expansion that gives up after ``budget`` expansions."""
    counter = [0]

    def walk(form):
        for idx, sym in enumerate(form):
            if isinstance(sym, Nonterminal):
                break
        else:
            out.append([s for s in form if isinstance(s, str) and s != ""])
            return
        for prod in by_lhs.get(str(sym), []):
            counter[0] += 1
            if counter[0] > budget:
                raise _BudgetExceeded()
            walk(list(form[:idx]) + list(prod.rhs()) + list(form[idx + 1:]))

    walk(form)
