"""Exhaustive chart parser: every tree the grammar assigns to a token list.

spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000473 N-000474
spec: N-000475 N-000476 N-000292 N-000293 N-000294
"""

from ..tree import Tree
from ._common import check_tokens, productions_by_lhs

__all__ = ["ChartParser"]


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000473 N-000474 N-000475 N-000476
        """Return an iterator over the parse trees of ``tokens``.

        A token that no production produces raises here, before any iteration.
        Derivations that revisit the same (symbol, span) on one path are cut,
        so grammars with cycles yield finitely many trees.
        """
        tokens = check_tokens(self._grammar, tokens)
        return iter(_all_trees(self._grammar, tokens))


def _all_trees(grammar, tokens):
    by_lhs = productions_by_lhs(grammar)
    n = len(tokens)
    memo = {}
    state = {"cut": False}

    def trees(sym, i, j, stack):
        key = (sym, i, j)
        if key in memo:
            return memo[key]
        if key in stack:
            state["cut"] = True
            return []
        stack.add(key)
        saved_cut = state["cut"]
        state["cut"] = False
        out = []
        for prod in by_lhs.get(sym, []):
            for kids in seq(prod.rhs(), i, j, stack):
                out.append(Tree(sym, kids))
        stack.discard(key)
        if not state["cut"]:
            memo[key] = out
        state["cut"] = saved_cut or state["cut"]
        return out

    def seq(rhs, i, j, stack):
        if not rhs:
            return [[]] if i == j else []
        first, rest = rhs[0], rhs[1:]
        results = []
        if isinstance(first, str):
            if first == "":
                return seq(rest, i, j, stack)
            if i < j and tokens[i] == first:
                for kids in seq(rest, i + 1, j, stack):
                    results.append([first] + kids)
            return results
        for k in range(i, j + 1):
            subs = trees(str(first), i, k, stack)
            if not subs:
                continue
            tails = seq(rest, k, j, stack)
            for sub in subs:
                for tail in tails:
                    results.append([sub] + tail)
        return results

    start = str(grammar.start())
    return trees(start, 0, n, set())
