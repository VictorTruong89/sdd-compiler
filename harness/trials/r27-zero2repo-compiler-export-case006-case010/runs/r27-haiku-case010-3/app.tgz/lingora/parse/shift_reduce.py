"""Single-pass shift-reduce parser without backtracking.

spec: N-000272 N-000273 N-000274 N-000275
"""

from ..tree import Tree
from ._common import check_tokens

__all__ = ["ShiftReduceParser"]


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000272 N-000273 N-000274 N-000275
        """Return an iterator over at most one tree (the parse the pass completes).

        Empty productions are not used by this parser: a reduction needs a
        non-empty right-hand side on top of the stack.
        """
        tokens = check_tokens(self._grammar, tokens)
        return iter(_run(self._grammar, tokens))


def _matches(items, rhs):
    for item, sym in zip(items, rhs):
        if isinstance(sym, str):
            if not (isinstance(item, str) and item == sym):
                return False
        else:
            if not (isinstance(item, Tree) and item.label() == str(sym)):
                return False
    return True


def _run(grammar, tokens):
    prods = [p for p in grammar.productions() if len(p.rhs()) > 0]
    start = str(grammar.start())
    stack = []
    pos = 0
    unit_reductions = 0
    limit = 2 * len(prods) + 2
    while True:
        reduced = False
        for prod in prods:
            k = len(prod.rhs())
            if len(stack) >= k and _matches(stack[-k:], prod.rhs()):
                if k == 1:
                    unit_reductions += 1
                    if unit_reductions > limit:
                        continue  # break unit-production cycles
                kids = stack[-k:]
                del stack[-k:]
                stack.append(Tree(str(prod.lhs()), kids))
                reduced = True
                break
        if reduced:
            continue
        if pos < len(tokens):
            stack.append(tokens[pos])
            pos += 1
            unit_reductions = 0
            continue
        break
    if pos == len(tokens) and len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
        return [stack[0]]
    return []
