"""Context-free grammars read from text.

spec: N-000461 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470
spec: N-000471 N-000479 N-000480 N-000264 N-000265 N-000268 N-000270
"""

import re

__all__ = ["Nonterminal", "Production", "CFG"]

_TOKEN = re.compile(r'"[^"]*"|\'[^\']*\'|\||[^\s|"\']+')
_IDENT = re.compile(r"^[^\s\"'|]+$")


class Nonterminal:
    """A nonterminal symbol. ``str()`` gives its name."""  # spec: N-000467 N-000468

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """One alternative ``lhs -> rhs``; rhs items are ``str`` terminals or Nonterminals."""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):  # spec: N-000469 N-000470
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [("'%s'" % s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


class CFG:
    """A context-free grammar. ``CFG.fromstring`` reads one production per line."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._terminals = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str) and sym != "":
                    self._terminals.add(sym)

    @classmethod
    def fromstring(cls, input):  # spec: N-000461 N-000464 N-000465
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production has no '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or not _IDENT.match(lhs_text) or lhs_text[0] in "'\"":
                raise ValueError("invalid left-hand side: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alt in _split_alternatives(rhs_text):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):  # spec: N-000466
        return self._start

    def productions(self):  # spec: N-000471
        return list(self._productions)

    def terminals(self):
        return set(self._terminals)

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


def _split_alternatives(rhs_text):
    alternatives = [[]]
    for tok in _TOKEN.findall(rhs_text):
        if tok == "|":
            alternatives.append([])
        elif tok[0] in "\"'" and len(tok) >= 2:
            alternatives[-1].append(tok[1:-1])
        else:
            alternatives[-1].append(Nonterminal(tok))
    return alternatives

# spec: N-000040 N-000041
