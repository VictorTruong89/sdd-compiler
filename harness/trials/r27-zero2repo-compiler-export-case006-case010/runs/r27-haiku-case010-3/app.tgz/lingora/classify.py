"""Naive Bayes and decision-tree classifiers over labeled featuresets.

spec: N-000492 N-000493 N-000494 N-000495 N-000496 N-000497 N-000295 N-000296
spec: N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304
spec: N-000305 N-000306 N-000307 N-000308 N-000309 N-000310 N-000311 N-000312
spec: N-000313 N-000314 N-000315 N-000316 N-000317 N-000318
"""

import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]

_GAMMA = 0.5  # Lidstone smoothing for feature-value estimates


class ProbDist:
    """A distribution over labels: ``prob(label)`` (float) and ``samples()``."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):  # spec: N-000496
        return float(self._probs.get(label, 0.0))

    def samples(self):  # spec: N-000497
        return list(self._probs.keys())

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_labeled(labeled):
    out = []
    for pair in labeled:
        featureset, label = pair
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        out.append((featureset, label))
    return out


class NaiveBayesClassifier:
    def __init__(self, label_counts, feature_counts, feature_values, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts  # (label, fname, fval) -> count
        self._feature_totals = defaultdict(int)  # (label, fname) -> count
        for (label, fname, _fval), cnt in feature_counts.items():
            self._feature_totals[(label, fname)] += cnt
        self._feature_values = feature_values  # fname -> set of values seen
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):  # spec: N-000492 N-000302 N-000303
        labeled = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        feature_counts = Counter()
        feature_values = defaultdict(set)
        for featureset, label in labeled:
            label_counts[label] += 1
            for fname, fval in featureset.items():
                feature_counts[(label, fname, fval)] += 1
                feature_values[fname].add(fval)
        return cls(label_counts, feature_counts, feature_values, len(labeled))

    def labels(self):  # spec: N-000309
        return list(self._label_counts.keys())

    def _log_scores(self, featureset):
        scores = {}
        for label, lcount in self._label_counts.items():
            score = math.log(lcount / self._total)
            for fname, fval in featureset.items():
                if fname not in self._feature_values:
                    continue  # spec: N-000305
                k = len(self._feature_values[fname])
                num = self._feature_counts.get((label, fname, fval), 0) + _GAMMA
                den = self._feature_totals.get((label, fname), 0) + _GAMMA * k
                score += math.log(num / den)
            scores[label] = score
        return scores

    def classify(self, featureset):  # spec: N-000306 N-000315 N-000316 N-000317
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        return max(scores, key=lambda lab: (scores[lab], repr(lab)))

    def prob_classify(self, featureset):  # spec: N-000307 N-000308
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {lab: math.exp(s - top) for lab, s in scores.items()}
        z = sum(exps.values())
        return ProbDist({lab: v / z for lab, v in exps.items()})


_ABSENT = object()


class _Node:
    __slots__ = ("majority", "feature", "children")

    def __init__(self, majority, feature=None, children=None):
        self.majority = majority
        self.feature = feature
        self.children = children or {}


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    # Ties: the label that appears first in the list among the most frequent ones.
    for lab in labels:
        if counts[lab] == best:
            return lab


def _build(examples, features):
    labels = [lab for _, lab in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1 or not features:
        return _Node(majority)
    best = None
    for fname in features:
        groups = defaultdict(list)
        for fs, lab in examples:
            groups[fs.get(fname, _ABSENT)].append((fs, lab))
        correct = 0  # examples classified correctly by majority label per branch
        for grp in groups.values():
            maj = _majority([lab for _, lab in grp])
            correct += sum(1 for _, lab in grp if lab == maj)
        if best is None or correct > best[0]:
            best = (correct, fname, groups)
    _, fname, groups = best
    if len(groups) == 1:
        return _Node(majority)
    rest = [f for f in features if f != fname]
    children = {}
    for val, grp in groups.items():
        children[val] = _build(grp, rest)
    return _Node(majority, fname, children)


def _walk(node, featureset):
    while node.feature is not None:
        val = featureset.get(node.feature, _ABSENT)
        child = node.children.get(val)
        if child is None:
            break  # spec: N-000315 - unseen branch: the node's majority label
        node = child
    return node.majority


class DecisionTreeClassifier:
    def __init__(self, root):
        self._root = root
        self._labels = []

    @classmethod
    def train(cls, labeled_featuresets):  # spec: N-000493 N-000310..N-000313
        labeled = _check_labeled(labeled_featuresets)
        if not labeled:
            raise ValueError("cannot train a decision tree on no examples")
        features = []
        for fs, _ in labeled:
            for fname in fs:
                if fname not in features:
                    features.append(fname)
        root = _build(labeled, features)
        clf = cls(root)
        clf._labels = list(dict.fromkeys(lab for _, lab in labeled))
        return clf

    def classify(self, featureset):  # spec: N-000306 N-000315
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        return _walk(self._root, featureset)


def accuracy(classifier, gold):  # spec: N-000497 N-000310 (classifier accuracy)
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    gold = _check_labeled(gold)
    if not gold:
        return 0.0
    hits = sum(1 for fs, lab in gold if classifier.classify(fs) == lab)
    return hits / len(gold)

# spec: N-000044 N-000045
