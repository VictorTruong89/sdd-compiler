"""Stemmers: Porter (with LINGORA extensions), Lancaster, Snowball, regexp, lemmatizer.

spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428
spec: N-000429 N-000430 N-000431 N-000432 N-000140 N-000141 N-000142 N-000143
spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151
spec: N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159
spec: N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167
spec: N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000174 N-000175
spec: N-000176 N-000177 N-000178 N-000179 N-000180 N-000181 N-000182 N-000183
spec: N-000184 N-000185 N-000186
"""

import re

from . import data

__all__ = [
    "PorterStemmer",
    "LancasterStemmer",
    "SnowballStemmer",
    "RegexpStemmer",
    "WordNetLemmatizer",
    "ARLSTem",
    "ARLSTem2",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)

_VOWELS = "aeiou"

# Irregular forms table (LINGORA's built-in table; entries are implementer's choice).
_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}


# ---------------------------------------------------------------------------
# Porter
# ---------------------------------------------------------------------------
class PorterStemmer:
    """Porter's algorithm. ``mode`` is 'lingora' (default), 'original' or 'martin'."""

    ORIGINAL_ALGORITHM = "original"
    MARTIN_EXTENSIONS = "martin"
    LINGORA_EXTENSIONS = "lingora"

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.LINGORA_EXTENSIONS):
            raise ValueError("unknown Porter mode: %r" % (mode,))
        self._mode = mode

    def stem(self, word, to_lowercase=False):  # spec: N-000422 N-000426 N-000427
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if to_lowercase:
            word = word.lower()
        lingora = self._mode == self.LINGORA_EXTENSIONS
        if lingora:
            key = word.lower()
            if key in _IRREGULAR:  # spec: N-000155
                return _IRREGULAR[key]
            if len(word) <= 2:  # spec: N-000156 N-000157
                return word
            return _porter(word, True)
        if len(word) <= 2:
            return word
        return _porter(word, False)


def _is_cons(w, i):
    c = w[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _is_cons(w, i - 1)
    return True


def _measure(stem):
    n = len(stem)
    i = 0
    while i < n and _is_cons(stem, i):
        i += 1
    m = 0
    while True:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            return m
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_cvc(stem, lingora):
    if lingora and len(stem) == 2 and not _is_cons(stem, 0) and _is_cons(stem, 1):
        return True  # spec: N-000161
    if len(stem) < 3:
        return False
    if not (_is_cons(stem, -3) and not _is_cons(stem, -2) and _is_cons(stem, -1)):
        return False
    return stem[-1] not in "wxy"


def _double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _is_cons(w, len(w) - 1)


_STEP2 = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("logi", "log"), ("fulli", "ful"),
]
_STEP2_ORIGINAL = [("abli", "able") if s == "bli" else (s, r) for s, r in _STEP2 if s not in ("logi", "fulli")]
_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize"]


def _porter(word, lingora):
    w = word
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        w = w[:-1] if (lingora and len(w) == 4) else w[:-2]  # spec: N-000158
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]

    # Step 1b
    skip_1b = False
    if lingora and w.endswith("ied"):  # spec: N-000159 N-000160
        w = w[:-3] + ("ie" if len(w) == 4 else "i")
        skip_1b = True
    if not skip_1b:
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                w = w[:-1]
        elif (w.endswith("ed") and _has_vowel(w[:-2])) or (w.endswith("ing") and _has_vowel(w[:-3])):
            w = w[:-2] if w.endswith("ed") else w[:-3]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif _double_cons(w) and w[-1] not in "lsz":
                w = w[:-1]
            elif _measure(w) == 1 and _ends_cvc(w, lingora):
                w += "e"

    # Step 1c (spec: N-000162)
    if w.endswith("y") and len(w) > 1:
        if lingora:
            if len(w) >= 3 and _is_cons(w, len(w) - 2):
                w = w[:-1] + "i"
        elif _has_vowel(w[:-1]):
            w = w[:-1] + "i"

    # Step 2 (spec: N-000163..N-000167)
    if lingora and w.endswith("alli") and _measure(w[:-4]) > 0:
        w = w[:-2]
        w = _step2(w, _STEP2)
    else:
        w = _step2(w, _STEP2 if lingora else _STEP2_ORIGINAL)

    # Step 3
    w = _rule_list(w, _STEP3)
    # Step 4
    for suf in _STEP4:
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if _measure(stem) > 1 and (suf != "ion" or stem[-1:] in ("s", "t")):
                w = stem
            break
    # Step 5a
    if w.endswith("e"):
        stem = w[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _ends_cvc(stem, lingora)):
            w = stem
    # Step 5b
    if _measure(w) > 1 and w.endswith("ll"):
        w = w[:-1]
    return w


def _step2(w, rules):
    for suf, rep in rules:
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if _measure(stem) > 0:
                return stem + rep
            return w
    return w


def _rule_list(w, rules):
    for suf, rep in rules:
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if _measure(stem) > 0:
                return stem + rep
            return w
    return w


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk). Partial rule table; see NOTES.md.
# ---------------------------------------------------------------------------
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.",
    "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.",
    "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3y.",
    "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3y.", "lo2l.",
]


def _parse_lancaster_rule(rule):
    terminator = rule[-1]
    body = rule[:-1]
    m = re.match(r"^([a-z]+)(\*?)(\d)(.*)$", body)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    suffix = m.group(1)[::-1]
    intact = m.group(2) == "*"
    remove = int(m.group(3))
    append = m.group(4)
    return suffix, intact, remove, append, terminator == ">"


class LancasterStemmer:
    """Paice/Husk stemmer over the packaged rule table (partial; see NOTES.md)."""

    def __init__(self):
        self._rules = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]

    def stem(self, word):  # spec: N-000170 N-000171
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        while True:
            applied = None
            for suffix, need_intact, remove, append, cont in self._rules:
                if need_intact and not intact:
                    continue
                if not word.endswith(suffix):
                    continue
                remaining = word[:-remove] if remove else word
                if not remaining:
                    continue
                needed = 2 if remaining[0] in _VOWELS else 3
                if len(remaining) < needed:
                    continue
                applied = (remaining + append, cont)
                break
            if applied is None:
                return word
            word, cont = applied
            intact = False
            if not cont:
                return word


# ---------------------------------------------------------------------------
# Snowball: English (Porter2) and the original Porter rendering. Other
# languages are validated but their algorithms are not implemented (NOTES.md).
# ---------------------------------------------------------------------------
_E2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl",
}
_E2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_E2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_E2_STEP2 = ["ization", "ational", "fulness", "ousness", "iveness", "tional", "biliti", "lessli",
             "entli", "ation", "alism", "aliti", "ousli", "iviti", "fulli", "enci", "anci",
             "abli", "izer", "ator", "alli", "bli", "ogi", "li"]
_E2_STEP2_MAP = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "fulli": "ful", "lessli": "less",
}
_E2_STEP3 = [("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
             ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", "")]
_E2_STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate",
             "iti", "ous", "ive", "ize", "al", "er", "ic", "ion"]
_E2_VOWELS = "aeiouy"


def _e2_regions(w):
    r1 = len(w)
    for prefix, length in (("gener", 5), ("commun", 6), ("arsen", 5)):
        if w.startswith(prefix):
            r1 = length
            break
    else:
        for i in range(1, len(w)):
            if w[i] not in _E2_VOWELS and w[i - 1] in _E2_VOWELS:
                r1 = i + 1
                break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in _E2_VOWELS and w[i - 1] in _E2_VOWELS:
            r2 = i + 1
            break
    return min(r1, len(w)), min(r2, len(w))


def _e2_short_syllable(w):
    if len(w) == 2:
        return w[0] in _E2_VOWELS and w[1] not in _E2_VOWELS
    if len(w) >= 3:
        return (w[-3] not in _E2_VOWELS and w[-2] in _E2_VOWELS and w[-1] not in _E2_VOWELS
                and w[-1] not in "wxY")
    return False


def _longest_suffix(w, suffixes):
    best = None
    for suf in suffixes:
        if w.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    return best


def _porter2(word):
    if word in _E2_EXC1:
        return _E2_EXC1[word]
    if word in _E2_INVARIANT:
        return word
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in "aeiou":
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _e2_regions(w)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(c in _E2_VOWELS for c in w[:-2]):
            w = w[:-1]
    if word in _E2_EXC2:
        return word.replace("Y", "y")
    # Step 1b
    if w.endswith(("eed", "eedly")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        suf = _longest_suffix(w, ("ed", "edly", "ing", "ingly"))
        if suf and any(c in _E2_VOWELS for c in w[: -len(suf)]):
            w = w[: -len(suf)]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif _double_letter(w):
                w = w[:-1]
            elif _e2_regions(w)[0] >= len(w) and _e2_short_syllable(w):
                w += "e"
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _E2_VOWELS:
        w = w[:-1] + "i"
    # Step 2 (within R1)
    suf = _longest_suffix(w, _E2_STEP2)
    if suf is not None and len(w) - len(suf) >= r1:
        stem = w[: -len(suf)]
        if suf == "ogi":
            if stem.endswith("l"):
                w = stem + "og"
        elif suf == "li":
            if stem and stem[-1] in "cdeghkmnrt":
                w = stem
        else:
            w = stem + _E2_STEP2_MAP[suf]
    # Step 3 (within R1, and R2 for ful/ness/ative)
    for suf, rep in _E2_STEP3:
        if w.endswith(suf):
            start = len(w) - len(suf)
            if start >= r1 and (suf not in ("ful", "ness", "ative") or start >= r2):
                w = w[:start] + rep
            break
    # Step 4 (within R2)
    suf = _longest_suffix(w, _E2_STEP4)
    if suf is not None and len(w) - len(suf) >= r2:
        if suf != "ion" or (len(w) > 3 and w[-4] in "st"):
            w = w[: -len(suf)]
    # Step 5
    if w.endswith("e"):
        start = len(w) - 1
        if start >= r2 or (start >= r1 and not _e2_short_syllable(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w.endswith("ll"):
        w = w[:-1]
    return w.replace("Y", "y")


def _double_letter(w):
    return len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt"


_SNOWBALL_IMPLEMENTED = {"english", "porter"}


class SnowballStemmer:
    """Snowball stemmer for a language name from SNOWBALL_LANGUAGES."""

    def __init__(self, language, ignore_stopwords=False):  # spec: N-000429 N-000431
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        self._language = language
        self._ignore = bool(ignore_stopwords)
        self._stopwords = None
        if self._ignore:
            # spec: N-000183 N-000184 - the stopwords list must be visible for this language.
            self._stopwords = set(w.lower() for w in data.read_lines("corpora/stopwords/%s" % language)
                                  if w.strip())

    def stem(self, word):  # spec: N-000176 N-000177
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = word.lower()
        if self._ignore and w in self._stopwords:
            return w
        if self._language == "english":
            return _porter2(w)
        if self._language == "porter":
            return PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM).stem(w)
        raise NotImplementedError(
            "the Snowball algorithm for %r is not implemented in this build" % self._language
        )


# ---------------------------------------------------------------------------
# Regexp stemmer (spec: N-000178..N-000180)
# ---------------------------------------------------------------------------
class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._re = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        return self._re.sub("", word)


# ---------------------------------------------------------------------------
# Families listed in FP-02 whose stemming results are outside this specification.
# ---------------------------------------------------------------------------
class ARLSTem:
    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    pass


class WordNetLemmatizer:
    """Requires the packaged WordNet resource (spec: N-000432, N-000185)."""

    def __init__(self):
        data.require("corpora/wordnet")

    def lemmatize(self, word):
        data.require("corpora/wordnet")
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")

# spec: N-000023 N-000024 N-000034
# spec: N-000395 N-000396
