"""Punkt sentence-boundary detection (Kiss and Strunk, 2006) using packaged parameters.

Parameters come from ``tokenizers/punkt_tab/<language>/``: ``abbrev_types.txt``,
``sent_starters.txt``, ``collocations.tab`` and ``ortho_context.tab``.

spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000386 N-000389 N-000413
"""

import re

from . import data

__all__ = ["PunktParameters", "load_parameters", "split_sentences"]

# Bit set of orthographic observations (spec: N-000402).
UC_START = 2
UC_MID = 4
UC_UNK = 8
LC_START = 16
LC_MID = 32
LC_UNK = 64

_OPENERS = "\"'([{<`«“‘„"
_CLOSERS = "\"')]}>»”’"
_NUMERIC = re.compile(r"^-?[.,]?\d[\d,.\-]*\.?$")
_INITIAL = re.compile(r"[^\W\d]\.")
_NON_WORD_BLANKLINE = re.compile(r"\n\s*\n")


class PunktParameters:
    def __init__(self, abbrev_types=(), collocations=(), sent_starters=(), ortho_context=None):
        self.abbrev_types = set(t.lower() for t in abbrev_types)
        self.collocations = set(tuple(c) for c in collocations)
        self.sent_starters = set(s.lower() for s in sent_starters)
        self.ortho_context = dict(ortho_context or {})


def _language_dir(language):
    if not isinstance(language, str) or not language or "/" in language or "\\" in language or language.startswith("."):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    return "tokenizers/punkt_tab/%s" % language


def load_parameters(language):
    """Load the packaged Punkt parameters; raise if the model is not visible."""
    base = _language_dir(language)
    data.require(base)  # ResourceNotFoundError when the model is absent

    def lines(name):
        if data.find("%s/%s" % (base, name)) is None:
            return []
        return [ln for ln in data.read_lines("%s/%s" % (base, name)) if ln.strip() != ""]

    abbrev = lines("abbrev_types.txt")
    starters = lines("sent_starters.txt")
    colloc = []
    for ln in lines("collocations.tab"):
        parts = ln.split("\t")
        if len(parts) == 2:
            colloc.append((parts[0].lower(), parts[1].lower()))
    ortho = {}
    for ln in lines("ortho_context.tab"):
        parts = ln.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0].lower()] = int(parts[1])
    return PunktParameters(abbrev, colloc, starters, ortho)


class _Tok:
    __slots__ = ("start", "end", "core", "typ", "period_final", "ellipsis", "is_initial",
                 "is_numeric", "first_upper", "first_lower", "sentbreak", "abbr", "parastart")

    def __init__(self, text, start, end):
        self.start = start
        self.end = end
        raw = text[start:end]
        self.core = raw.strip("".join(sorted(set(_OPENERS + _CLOSERS))))
        core = self.core
        self.ellipsis = core.endswith("..")
        self.period_final = core.endswith(".") and not self.ellipsis
        base = core[:-1] if self.period_final else core
        self.typ = base.lower()
        self.is_numeric = bool(_NUMERIC.match(core))
        self.is_initial = bool(_INITIAL.fullmatch(core))
        head = core[:1]
        self.first_upper = head.isupper()
        self.first_lower = head.islower()
        self.sentbreak = False
        self.abbr = False
        self.parastart = False

    @property
    def type_key(self):
        return "##number##" if self.is_numeric else self.typ


def _tokenize(text):
    toks = [_Tok(text, m.start(), m.end()) for m in re.finditer(r"\S+", text)]
    # A blank line before a token starts a new paragraph.
    for k in range(1, len(toks)):
        between = text[toks[k - 1].end:toks[k].start]
        if _NON_WORD_BLANKLINE.search(between):
            toks[k].parastart = True
    return toks


def _ortho(params, tok):
    """Orthographic evidence that ``tok`` starts a sentence: True, False or None."""
    ctx = params.ortho_context.get(tok.typ, 0)
    if tok.first_upper:
        if (ctx & UC_START) and not (ctx & LC_MID):
            return True
        if (ctx & LC_MID) and not (ctx & UC_MID):
            return False
        return None
    if tok.first_lower:
        return False
    return None


def _first_pass(params, tok):
    if tok.core[-1:] in ("?", "!"):
        tok.sentbreak = True
    elif tok.ellipsis:
        tok.abbr = True  # decided by the second pass
    elif tok.period_final:
        head = tok.typ
        last_part = head.split("-")[-1]
        if head in params.abbrev_types or last_part in params.abbrev_types:
            tok.abbr = True
        else:
            tok.sentbreak = True


def _second_pass(params, tok, nxt):
    if nxt is None or not (tok.period_final or tok.ellipsis):
        return
    typ = tok.typ
    next_typ = nxt.type_key
    if (typ, next_typ) in params.collocations:
        tok.sentbreak = False
        tok.abbr = True
        return
    if (tok.abbr or tok.ellipsis) and not tok.is_initial:
        if _ortho(params, nxt) is True:
            tok.sentbreak = True
            return
        if nxt.first_upper and next_typ in params.sent_starters:
            tok.sentbreak = True
            return
    if tok.is_initial or tok.is_numeric:
        starter = _ortho(params, nxt)
        if starter is True:
            tok.sentbreak = True
        elif starter is False:
            tok.sentbreak = False
            tok.abbr = True
        elif nxt.first_upper and next_typ in params.sent_starters:
            tok.sentbreak = True
        else:
            tok.sentbreak = False


def split_sentences(text, params):
    """Return the sentences of ``text`` as substrings of the original text."""
    toks = _tokenize(text)
    if not toks:
        return []
    for tok in toks:
        _first_pass(params, tok)
    for k, tok in enumerate(toks):
        _second_pass(params, tok, toks[k + 1] if k + 1 < len(toks) else None)
    sentences = []
    group_start = 0
    for k, tok in enumerate(toks):
        last = k == len(toks) - 1
        break_here = last or tok.sentbreak or toks[k + 1].parastart
        if break_here:
            sentences.append(text[toks[group_start].start:tok.end])
            group_start = k + 1
    return sentences

# spec: N-000028 N-000389 N-000399
