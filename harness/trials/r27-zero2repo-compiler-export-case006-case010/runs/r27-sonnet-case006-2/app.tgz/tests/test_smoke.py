import optlyn as o
from optlyn.testing import CliRunner


def test_basic_group():
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--count", default=1)
    def hello(count):
        o.echo(f"hi {count}")

    r = CliRunner().invoke(cli, ["hello", "--count", "3"])
    assert r.exit_code == 0 and r.output == "hi 3\n"
    assert CliRunner().invoke(cli, []).exit_code == 2
    assert CliRunner().invoke(cli, ["nope"]).exit_code == 2
