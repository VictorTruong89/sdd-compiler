import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils
from .core import Command


class _Tee(io.RawIOBase):
    def __init__(self, *targets):
        self.targets = targets

    def writable(self):
        return True

    def write(self, b):
        b = bytes(b)
        for t in self.targets:
            t.write(b)
        return len(b)

    def flush(self):
        pass


class _FdStream(io.RawIOBase):
    """Writes interpreter output to a real descriptor and to the mixed buffer."""

    def __init__(self, fd, mixed, tmp):
        self.fd = fd
        self.mixed = mixed
        self.tmp = tmp
        self.expected = 0

    def writable(self):
        return True

    def fileno(self):
        return self.fd

    def sync(self):
        # bytes written directly to the descriptor by someone else
        try:
            pos = os.lseek(self.fd, 0, os.SEEK_CUR)
            if pos > self.expected:
                data = os.pread(self.tmp.fileno(), pos - self.expected, self.expected)
                self.mixed.write(data)
                self.expected = pos
        except OSError:
            pass

    def write(self, b):
        b = bytes(b)
        self.sync()
        self.mixed.write(b)
        view = memoryview(b)
        while view:
            n = os.write(self.fd, view)
            view = view[n:]
        self.expected += len(b)
        return len(b)

    def flush(self):
        pass


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes,
                 return_value, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False,
                 catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        old_visible, old_hidden, old_getchar = (termui.visible_prompt_func,
                                                termui.hidden_prompt_func, termui._getchar)
        old_strip = utils.should_strip_ansi
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)

        bytes_input = io.BytesIO(data)
        text_input = _NamedTextIOWrapper(bytes_input, name="<stdin>", mode="r",
                                         encoding=self.charset)
        out_bytes, err_bytes, mixed = io.BytesIO(), io.BytesIO(), io.BytesIO()
        saved_fds = None
        tmp_out = tmp_err = None
        if self.capture == "fd":
            sys.stdout.flush()
            sys.stderr.flush()
            tmp_out = tempfile.TemporaryFile()
            tmp_err = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(tmp_out.fileno(), 1)
            os.dup2(tmp_err.fileno(), 2)
            stdout_raw = _FdStream(1, mixed, tmp_out)
            stderr_raw = _FdStream(2, mixed, tmp_err)
        else:
            stdout_raw = _Tee(out_bytes, mixed)
            stderr_raw = _Tee(err_bytes, mixed)
        sys.stdout = _NamedTextIOWrapper(stdout_raw, name="<stdout>", mode="w",
                                         encoding=self.charset, write_through=True)
        sys.stderr = _NamedTextIOWrapper(stderr_raw, name="<stderr>", mode="w",
                                         encoding=self.charset, errors="backslashreplace",
                                         write_through=True)
        stdin_obj = text_input
        if self.echo_stdin:
            stdin_obj = _EchoingStdin(text_input, sys.stdout)
        sys.stdin = stdin_obj

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            try:
                val = next(_lines(text_input)).rstrip("\r\n")
            except StopIteration as e:
                raise EOFError() from e
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            try:
                return next(_lines(text_input)).rstrip("\r\n")
            except StopIteration as e:
                raise EOFError() from e

        def _getchar(echo_):
            char = text_input.read(1)
            if echo_:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if self.capture == "fd":
                yield (out_bytes, err_bytes, mixed, tmp_out, tmp_err)
            else:
                yield (out_bytes, err_bytes, mixed, None, None)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if saved_fds is not None:
                stdout_raw.sync()
                stderr_raw.sync()
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                for tmp, dest, written in ((tmp_out, out_bytes, None), (tmp_err, err_bytes, None)):
                    tmp.seek(0)
                    dest.write(tmp.read())
                    tmp.close()
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            out_bytes, err_bytes, mixed, tmp_out, tmp_err = streams
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or [], prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if self.capture != "fd":
                    stdout_bytes = out_bytes.getvalue()
                    stderr_bytes = err_bytes.getvalue()
                    output_bytes = mixed.getvalue()
        if self.capture == "fd":
            stdout_bytes = out_bytes.getvalue()
            stderr_bytes = err_bytes.getvalue()
            output_bytes = mixed.getvalue()
        return Result(runner=self, stdout_bytes=stdout_bytes, stderr_bytes=stderr_bytes,
                      output_bytes=output_bytes, return_value=return_value,
                      exit_code=exit_code, exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _lines(stream):
    # a single-line reader that works on both text wrappers and echoing proxies
    line = stream.readline()
    if line == "":
        return iter(())
    return iter([line])
