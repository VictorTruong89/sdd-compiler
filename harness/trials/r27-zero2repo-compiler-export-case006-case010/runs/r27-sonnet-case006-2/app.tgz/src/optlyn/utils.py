import codecs
import io
import os
import re
import sys

from .exceptions import FileError
from .formatting import strip_ansi
from .globals_ import resolve_color_default


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _is_ascii_stream(stream):
    enc = getattr(stream, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def _binary_of(stream):
    try:
        buf = stream.buffer
        buf.write  # noqa
        return buf
    except Exception:
        return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _binary_of(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = out.decode("utf-8", "replace")
    color = resolve_color_default(color)
    from . import utils as _u
    if _u.should_strip_ansi(file, color):
        out = strip_ansi(out)
    if _is_ascii_stream(file):
        binary = _binary_of(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary = _binary_of(file)
        if binary is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            binary.write(out.encode("utf-8"))
    try:
        file.flush()
    except Exception:
        pass


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError):
    pass


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise ColorError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    try:
        r, g, b = color
    except Exception:
        raise ColorError(f"Unknown color {color!r}") from None
    for c in (r, g, b):
        if isinstance(c, bool) or not isinstance(c, int) or not 0 <= c <= 255:
            raise ColorError(f"Unknown color {color!r}")
    return f"{38 + offset};2;{r:d};{g:d};{b:d}"


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for flag, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24),
                          (overline, 53, 55), (italic, 3, 23), (blink, 5, 25),
                          (reverse, 7, 27), (strikethrough, 9, 29)):
        if flag is not None:
            bits.append(f"\033[{on if flag else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def get_text_stdout(encoding=None, errors=None):
    return _wrap_text_stream(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _wrap_text_stream(sys.stderr, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    return _wrap_text_stream(sys.stdin, encoding, errors)


def get_binary_stdout():
    return _binary_or_self(sys.stdout)


def get_binary_stderr():
    return _binary_or_self(sys.stderr)


def get_binary_stdin():
    return _binary_or_self(sys.stdin)


def _binary_or_self(stream):
    b = _binary_of(stream) if not hasattr(stream, "mode") or True else None
    if b is not None:
        return b
    return stream


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
        except Exception:
            pass
        try:
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _wrap_text_stream(stream, encoding, errors):
    cur = getattr(stream, "encoding", None)
    if encoding is None or (cur and codecs.lookup(cur).name == codecs.lookup(encoding).name
                            and (errors is None or errors == getattr(stream, "errors", None))):
        return stream
    buf = _binary_of(stream) if stream is not sys.stdin else getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(buf, encoding, errors or "strict",
                                    line_buffering=True)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in ["w", "a", "x"]):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=None if binary else encoding,
                    errors=None if binary else errors), True
    if "a" in mode:
        raise ValueError("Appending to an existing file is not supported, because that would involve an expensive `copy`-operation to a temporary file. Open the file in normal `w`-mode and copy explicitly if that's what you're after.")
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import tempfile
    fd, tmp_filename = tempfile.mkstemp(dir=os.path.dirname(filename) or ".",
                                        prefix=".__atomic-write")
    f = open(fd, mode, encoding=None if binary else encoding,
             errors=None if binary else errors)
    return _AtomicFile(f, tmp_filename, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict",
                 atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True

    def __getattr__(self, name):
        if name.startswith("__") or name == "_f":
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False,
              atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_app_dir(app_name, roaming=True, force_posix=False):
    home = os.path.expanduser("~")
    if sys.platform == "win32" and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or home
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(home, "." + re.sub(r"\s+", "-", app_name.lower()))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    return os.path.join(home, ".config", re.sub(r"\s+", "-", app_name.lower()))
