import contextlib
import inspect
import io
import itertools
import math
import os
import shlex
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort, OptlynException, UsageError
from .formatting import strip_ansi
from .globals_ import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, isatty, _wrap_text_stream


def _default_visible_input(prompt=""):
    return input(prompt)


def _default_hidden_input(prompt=""):
    import getpass
    return getpass.getpass(prompt)


visible_prompt_func = _default_visible_input
hidden_prompt_func = _default_hidden_input
_getchar = None


def _build_prompt(text, suffix, show_default=False, default=None,
                  show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(type._name(c) for c in type.choices)})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    import enum
    if isinstance(default, enum.Enum):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False,
           type=None, value_proc=None, prompt_suffix=": ", show_default=True,
           err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default,
                                show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ",
            show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


# ---------------------------------------------------------------- pager

class _PagerStream:
    def __init__(self, proc, color, encoding):
        self.proc = proc
        self.color = color
        self.encoding = encoding
        self.closed = False

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        if not self.color:
            text = strip_ansi(text)
        try:
            self.proc.stdin.write(text.encode(self.encoding, "replace"))
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass
        return len(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        try:
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def isatty(self):
        return False

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            self.proc.stdin.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                self.proc.wait()
                break
            except KeyboardInterrupt:
                pass


class _PlainStream:
    def __init__(self, stream, color):
        self.stream = stream
        self.color = color

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        echo(text, file=self.stream, nl=False, color=self.color)
        return len(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        try:
            self.stream.flush()
        except Exception:
            pass

    def isatty(self):
        return isatty(self.stream)

    def close(self):
        self.flush()


def _find_pager_command():
    cmd = (os.environ.get("PAGER") or "").strip()
    if cmd:
        return cmd
    import shutil
    for c in ("less", "more"):
        if shutil.which(c):
            return c
    return None


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    color = resolve_color_default(color)
    cmd = _find_pager_command() if _interactive() else None
    if not cmd:
        stream = _PlainStream(stdout, color)
        try:
            yield stream
        finally:
            stream.flush()
        return
    env = dict(os.environ)
    base = os.path.basename(cmd.split()[0]) if cmd.split() else ""
    if color is None and base == "less":
        color = True
    if base == "less":
        env.setdefault("LESS", "-R")
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    enc = getattr(stdout, "encoding", None) or "utf-8"
    stream = _PagerStream(proc, bool(color), enc)
    try:
        yield stream
    finally:
        stream.close()


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    if inspect.isgeneratorfunction(text_or_generator) or (
            callable(text_or_generator) and not isinstance(text_or_generator, str)):
        i = text_or_generator()
    elif isinstance(text_or_generator, str):
        i = [text_or_generator]
    else:
        i = iter(text_or_generator)
    if isinstance(i, str):
        i = [i]
    gen = (el if isinstance(el, str) else str(el) for el in i)
    with get_pager_file(color) as f:
        for chunk in itertools.chain(gen, ["\n"]):
            f.write(chunk)
            f.flush()


# ------------------------------------------------------------ progressbar

class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 hidden=False, show_eta=True, show_percent=None, show_pos=False,
                 item_show_func=None, label=None, file=None, color=None,
                 update_min_steps=1, width=36):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._last_line = None
        self.is_hidden = hidden or not isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.hidden or not isatty(self.file):
            return
        self.file.write("\n")
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label,
            "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits),
        }).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self._last_line != self.label:
                self._last_line = self.label
                if self.label:
                    echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=self.file, nl=False, color=self.color)
        self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        self._completed_intervals += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False,
                show_eta=True, show_percent=None, show_pos=False,
                item_show_func=None, fill_char="#", empty_char="-",
                bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                width=36, file=None, color=None, update_min_steps=1, **options):
    return ProgressBar(iterable=iterable, length=length, hidden=hidden,
                       show_eta=show_eta, show_percent=show_percent,
                       show_pos=show_pos, item_show_func=item_show_func,
                       fill_char=fill_char, empty_char=empty_char,
                       bar_template=bar_template, info_sep=info_sep, file=file,
                       label=label, width=width, color=color,
                       update_min_steps=update_min_steps)


# --------------------------------------------------------------- getchar etc

def _getchar_impl(echo_=False):
    try:
        import termios
        import tty
    except ImportError:
        return sys.stdin.read(1)
    if isatty(sys.stdin):
        fd = sys.stdin.fileno()
        close = None
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        close = fd
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
            ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if close is not None:
            os.close(close)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def getchar(echo=False):
    f = _getchar if _getchar is not None else _getchar_impl
    return f(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    interactive = _interactive()
    if info:
        echo(info, nl=False, err=err)
    if not interactive:
        return
    try:
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt",
         filename=None):
    if editor is None:
        editor = (os.environ.get("VISUAL") or os.environ.get("EDITOR"))
        if not editor:
            import shutil
            for c in ("vim", "nano", "vi"):
                if shutil.which(c):
                    editor = c
                    break
            else:
                editor = "vi"
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            c = subprocess.Popen(f"{editor} {shlex.quote(path)}", env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{editor}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e

    if filename is not None:
        run(filename)
        return None
    if text is None:
        text = ""
    if isinstance(text, (bytes, bytearray)):
        data = bytes(text)
    else:
        data = text.replace("\n", os.linesep).encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.utime(name, (0, 0))
        stamp = os.path.getmtime(name)
        run(name)
        if require_save and os.path.getmtime(name) == stamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    import subprocess as sp
    if sys.platform == "darwin":
        args = ["open"]
        if wait:
            args.append("-W")
        if locate:
            args.append("-R")
        args.append(url)
        with open(os.devnull, "w") as null:
            return sp.Popen(args, stderr=null).wait()
    try:
        if locate:
            url = os.path.dirname(url) or "."
        c = sp.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        try:
            c.wait(timeout=2)
        except sp.TimeoutExpired:
            pass
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
