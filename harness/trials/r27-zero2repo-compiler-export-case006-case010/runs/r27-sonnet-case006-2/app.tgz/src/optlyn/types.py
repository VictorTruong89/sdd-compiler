import enum
import os
import pathlib
import stat
import typing as t
import uuid
from datetime import datetime

from .exceptions import BadParameter, DeclarationError
from .utils import LazyFile, format_filename, open_stream, KeepOpenFile


class ParamType:
    is_composite = False
    arity = 1
    name = "param"
    envvar_list_splitter = None

    def to_info_dict(self):
        return {"param_type": self.name}

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param, ctx):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "func")
        self.func = func

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            enc = getattr(__import__("sys").stdin, "encoding", None)
            for e in (enc, __import__("sys").getfilesystemencoding(), "utf-8"):
                if not e:
                    continue
                try:
                    return value.decode(e)
                except UnicodeError:
                    pass
            return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=None):
        self.is_enum = isinstance(choices, type) and issubclass(choices, enum.Enum)
        if self.is_enum:
            self.choices = list(choices)
        else:
            self.choices = list(choices)
        if case_sensitive is None:
            case_sensitive = not self.is_enum
        self.case_sensitive = case_sensitive

    def _name(self, choice):
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def _normalize(self, ctx, text):
        if ctx is not None and ctx.token_normalize_func is not None:
            text = ctx.token_normalize_func(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def get_metavar(self, param):
        return "[" + "|".join(self._name(c) for c in self.choices) + "]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._name(c) for c in self.choices)

    def convert(self, value, param, ctx):
        normed_value = self._normalize(ctx, self._name(value) if isinstance(value, enum.Enum) else str(value))
        for choice in self.choices:
            if self._normalize(ctx, self._name(choice)) == normed_value:
                return choice
        choices_str = ", ".join(repr(self._name(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        inc = incomplete if self.case_sensitive else incomplete.casefold()
        out = []
        for c in self.choices:
            n = self._name(c)
            if (n if self.case_sensitive else n.casefold()).startswith(inc):
                out.append(CompletionItem(n))
        return out

    def __repr__(self):
        return f"Choice({[self._name(c) for c in self.choices]})"


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def get_metavar(self, param):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param, ctx):
        if isinstance(value, datetime):
            return value
        result = None
        for fmt in self.formats:
            try:
                result = datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        if result is not None:
            return result
        formats_str = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats_str}.", param, ctx)


class _NumberParamTypeBase(ParamType):
    _number_class = None

    def convert(self, value, param, ctx):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def convert(self, value, param, ctx):
        if isinstance(value, float) and not value.is_integer():
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)
        return super().convert(value, param, ctx)

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False,
                 clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (rv <= self.min if self.min_open else rv < self.min)
        gt_max = self.max is not None and (rv >= self.max if self.max_open else rv > self.max)
        if self.clamp:
            if lt_min:
                return self._number_class(self.min)
            if gt_max:
                return self._number_class(self.max)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def __repr__(self):
        return f"{type(self).__name__}({self.min}, {self.max})"


class IntRange(_NumberRangeBase):
    name = "integer range"
    _number_class = int

    def convert(self, value, param, ctx):
        if isinstance(value, float) and not value.is_integer():
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        return _NumberRangeBase.convert(self, value, param, ctx)


class FloatRange(_NumberRangeBase):
    name = "float range"
    _number_class = float

    def __init__(self, min=None, max=None, min_open=False, max_open=False,
                 clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if min is not None and max is not None and min > max:
            raise DeclarationError("'min' must not be greater than 'max'.")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if value in {False, True}:
            return bool(value)
        norm = str(value).strip().lower()
        if norm in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if norm in {"0", "false", "f", "no", "n", "off"}:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None,
                 atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        value_ = value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors,
                              atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding,
                                          self.errors, atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(_safecall(f.close))
                else:
                    ctx.call_on_close(_safecall(f.flush))
            else:
                pass
            if not should_close:
                return KeepOpenFile(f)
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value_)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        return [CompletionItem(incomplete, type="file")]


def _safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True,
                 writable=False, readable=True, resolve_path=False,
                 allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param, ctx):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(os.path.expanduser(rv))
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.title()} {format_filename(value)!r} does not exist.", param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not writable.", param, ctx)
            if self.executable and not os.access(value, os.X_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not executable.", param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return f"<{' '.join(ty.name for ty in self.types)}>"

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
            else:
                ty = None
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if guessed_type:
        return STRING
    if ty is uuid.UUID:
        return UUID
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
