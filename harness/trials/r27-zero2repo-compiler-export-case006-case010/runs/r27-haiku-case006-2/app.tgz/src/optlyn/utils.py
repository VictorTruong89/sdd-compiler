"""File, path and application-directory helpers.

# spec: N-000528 N-000529 N-000531 N-000532 N-000533 N-000534 N-000535 N-000536
# spec: N-000537 N-000538 N-000539 N-000540 N-000541 N-000542 N-000543 N-000544
# spec: N-000545 N-000546 N-000547 N-000575 N-000576 N-000577 N-000588 N-000589
# spec: N-000590 N-000674 N-000675 N-000676 N-000677 N-000678 N-001006 N-001007
# spec: N-001008 N-001009
"""

from __future__ import annotations

import io
import os
import re
import sys
import tempfile
import uuid

from .exceptions import FileError


class _KeepOpen:
    """Proxy for a standard stream: ``close()`` flushes instead of closing."""

    def __init__(self, stream) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self) -> None:
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass


class AtomicFile:
    """Writes to a temporary sibling and replaces the target on close."""

    def __init__(self, f, tmp_name: str, target: str) -> None:
        self._f = f
        self._tmp = tmp_name
        self._target = target
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def __iter__(self):
        return iter(self._f)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)


class LazyFile:
    """Opens its file on first I/O. Open failures raise :class:`FileError`."""

    def __init__(self, filename, mode, encoding, errors, atomic) -> None:
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f = None

    @property
    def name(self):
        return self._filename

    @property
    def mode(self):
        return self._mode

    def _open(self):
        if self._f is None:
            try:
                self._f = _real_open(self._filename, self._mode, self._encoding, self._errors, self._atomic)
            except OSError as e:
                raise FileError(self._filename, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self) -> None:
        if self._f is not None:
            self._f.close()
            self._f = None


def _real_open(filename, mode, encoding, errors, atomic):
    if "b" in mode:
        if "w" in mode and atomic:
            return _atomic_open(filename, mode, None, None)
        return open(filename, mode)
    if "w" in mode and atomic:
        return _atomic_open(filename, mode, encoding, errors)
    return open(filename, mode, encoding=encoding, errors=errors)


def _atomic_open(filename, mode, encoding, errors):
    directory = os.path.dirname(os.path.abspath(filename))
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=f".{os.path.basename(filename)}.", suffix=".tmp")
    os.close(fd)
    f = open(tmp, mode, encoding=encoding, errors=errors) if encoding or errors else open(tmp, mode)
    return AtomicFile(f, tmp, filename)


def _std_stream(filename: str, mode: str, encoding, errors):
    """Return the standard stream for ``-``. It is never closed by callers."""
    if "r" in mode:
        stream = sys.stdin
    else:
        stream = sys.stdout
    if "b" in mode:
        return _KeepOpen(stream.buffer)
    if encoding:
        wrapper = io.TextIOWrapper(stream.buffer, encoding=encoding, errors=errors, write_through=True)
        return _KeepOpen(wrapper)
    return _KeepOpen(stream)


def open_file(filename, mode: str = "r", encoding=None, errors: str = "strict", lazy: bool = False, atomic: bool = False):
    """Open a file, or a standard stream for ``-``.

    # spec: N-001006 N-001007 N-001008 N-001009 N-000528
    """
    if isinstance(filename, os.PathLike):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if filename == "-":
        return _std_stream(filename, mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _real_open(filename, mode, encoding, errors, atomic)


_SURROGATE_RE = re.compile("[\udc80-\udcff]")


def format_filename(filename, shorten: bool = False) -> str:
    """Return a printable, strictly UTF-8 encodable text form of a filename.

    # spec: N-000575 N-000576 N-000577
    """
    if isinstance(filename, os.PathLike):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename.rstrip("/\\")) or filename
    # Undecodable bytes arrive as lone surrogates; escape them so the text encodes.
    return _SURROGATE_RE.sub(lambda m: "\\x%02x" % (ord(m.group(0)) - 0xDC00), filename)


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``.

    # spec: N-000674 N-000675 N-000676 N-000677 N-000678 N-001005 N-001003 N-001004
    """
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") if roaming else os.environ.get("LOCALAPPDATA")
        if not base:
            base = os.path.join(os.path.expanduser("~"), "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + folder)
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return os.path.join(xdg, folder)
    return os.path.join(home, ".config", folder)


def unique_name(prefix: str = "optlyn") -> str:
    return f"{prefix}-{uuid.uuid4().hex}"
