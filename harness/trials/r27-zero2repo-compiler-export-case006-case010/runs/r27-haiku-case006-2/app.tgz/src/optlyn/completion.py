"""Shell completion: registration scripts and suggestion output.

# spec: N-001013 N-001014 N-001015 N-001016 N-001017 N-001018 N-001019 N-001020
# spec: N-001021 N-001022 N-001023 N-001024 N-001025 N-001026 N-001027 N-001028
# spec: N-001031 N-001032 N-001033 N-001034 N-001035 N-001036 N-001037
# spec: N-000689 N-000690 N-000691 N-000692 N-000693 N-000694 N-000695 N-000696
# spec: N-000697 N-000698 N-000699 N-000700 N-000701 N-000702 N-000703 N-000704
# spec: N-000705 N-000706 N-000707 N-000708 N-000709 N-000710 N-000711 N-000712
# spec: N-000713 N-000714 N-000715
"""

from __future__ import annotations

import os
import re
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion: a value, optional help, and a type ("plain" for values)."""

    def __init__(self, value, help=None, type="plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _var_name(prog_name: str) -> str:
    # spec: N-001013
    base = os.path.basename(prog_name)
    return "_" + base.upper().replace("-", "_") + "_COMPLETE"


def handle_completion(cli, prog_name: str, complete_var=None) -> None:
    """Handle the completion environment variable if it is set; exits when handled."""
    var = complete_var or _var_name(prog_name)
    raw = os.environ.get(var)
    if not raw:
        return
    if raw.endswith("_source") and raw[: -len("_source")] in SHELLS:
        shell = raw[: -len("_source")]
        sys.stdout.write(generate_script(shell, prog_name, var) + "\n")
        sys.stdout.flush()
        sys.exit(0)
    if raw.endswith("_complete") and raw[: -len("_complete")] in SHELLS:
        shell = raw[: -len("_complete")]
        comp_words = os.environ.get("COMP_WORDS", "")
        comp_cword = os.environ.get("COMP_CWORD", "")
        items = complete(cli, prog_name, shell, comp_words, comp_cword)
        sep = "\t" if shell in ("zsh", "fish") else "\t"
        lines = []
        for item in items:
            line = f"{item.type},{item.value}"
            if shell in ("zsh", "fish") and item.help:
                line += sep + " ".join(str(item.help).split())
            lines.append(line)
        if lines:
            sys.stdout.write("\n".join(lines) + "\n")
        sys.stdout.flush()
        sys.exit(0)
    sys.stderr.write(f"Error: unrecognized completion instruction {raw!r}.\n")
    sys.exit(1)


def generate_script(shell: str, prog_name: str, var: str) -> str:
    """Registration script for ``shell``. # spec: N-001022 N-001023 N-000690 N-000691"""
    prog = os.path.basename(prog_name)
    ident = re.sub(r"\W", "_", prog)
    if shell == "bash":
        return (
            f"_{ident}_completion() {{\n"
            "    local IFS=$'\\n'\n"
            "    local item\n"
            "    COMPREPLY=()\n"
            f"    local -a items\n"
            f"    items=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog} ) )\n"
            "    for item in \"${items[@]}\"; do\n"
            "        case \"$item\" in\n"
            "            plain,*) COMPREPLY+=(\"${item#plain,}\") ;;\n"
            "            file,*|dir,*) compopt -o default ;;\n"
            "        esac\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -o default -F _{ident}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{ident}_completion() {{\n"
            "    local -a items values\n"
            f"    items=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})}}\")\n"
            "    local item\n"
            "    for item in \"${items[@]}\"; do\n"
            "        case \"$item\" in\n"
            "            plain,*) values+=(\"${${item#plain,}%%$'\\t'*}\") ;;\n"
            "            file,*) _files ;;\n"
            "            dir,*) _files -/ ;;\n"
            "        esac\n"
            "    done\n"
            "    (( ${#values} )) && compadd -- \"${values[@]}\"\n"
            "}\n"
            f"compdef _{ident}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"function _{ident}_completion\n"
            f"    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})\n"
            "    for item in $response\n"
            "        echo $item\n"
            "    end\n"
            "end\n"
            f"complete -c {prog} -f -a '(_{ident}_completion)'\n"
        )
    if shell == "powershell":
        return (
            f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
            "    param($wordToComplete, $commandAst, $cursorPosition)\n"
            "    $env:COMP_WORDS = $commandAst.ToString()\n"
            "    $env:COMP_CWORD = $wordToComplete\n"
            f"    $env:{var} = 'powershell_complete'\n"
            f"    {prog} | ForEach-Object {{\n"
            "        $kind, $value = $_ -split ',', 2\n"
            "        if ($kind -eq 'plain') {\n"
            "            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)\n"
            "        }\n"
            "    }\n"
            f"    Remove-Item Env:{var} -ErrorAction SilentlyContinue\n"
            "}\n"
        )
    raise ValueError(f"Unknown shell {shell!r}.")


def _as_items(values):
    items = []
    for v in values or []:
        if isinstance(v, CompletionItem):
            items.append(v)
        elif hasattr(v, "value"):
            items.append(CompletionItem(v.value, getattr(v, "help", None), getattr(v, "type", "plain")))
        else:
            items.append(CompletionItem(str(v)))
    return items


def _param_items(ctx, param, incomplete):
    # spec: N-000706 N-000707 N-000708 N-000709 N-000710 N-000711 N-001031 N-001036 N-001037
    if getattr(param, "shell_complete", None) is not None:
        return _as_items(param.shell_complete(ctx, param, incomplete))
    ptype = param.type
    kind = None
    if hasattr(ptype, "shell_complete_kind"):
        kind = ptype.shell_complete_kind()
    if kind is not None:
        return [CompletionItem(incomplete, type=kind)]
    return _as_items(ptype.shell_complete(ctx, param, incomplete))


def _option_names(cmd, ctx, incomplete):
    # spec: N-000694 N-000695 N-000696 N-000697 N-000698 N-000699 N-000700
    from .core import Option

    items = []
    seen = set()
    for param in cmd.get_params(ctx):
        if not isinstance(param, Option) or param.hidden:
            continue
        for name in param.opts + param.secondary_opts:
            if name.startswith(incomplete) and name not in seen:
                seen.add(name)
                items.append(CompletionItem(name, help=param.help))
    return items


def _find_subcommand(group, ctx, name):
    if name is None:
        return None
    cmd = group.get_command(ctx, name)
    if cmd is None or cmd.hidden:
        return None
    return cmd


def complete(cli, prog_name: str, shell: str, comp_words: str, comp_cword: str):
    """Return the suggestions for the incomplete command line. # spec: N-001016 N-001017 N-001018 N-001019 N-001020 N-000694 N-000712"""
    from .core import Argument, Group, Option

    words = comp_words.split(" ") if comp_words else [prog_name]
    if shell == "fish":
        incomplete = comp_cword or ""
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(comp_cword)
        except (TypeError, ValueError):
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        args = [w for w in words[1:cword] if w != ""]

    # Walk down through groups to the command being completed.
    cmd = cli
    pos = 0
    info = prog_name
    while isinstance(cmd, Group):
        ctx = cmd.make_context(info, [], resilient_parsing=True)
        idx = None
        for k in range(pos, len(args)):
            if not args[k].startswith("-"):
                idx = k
                break
        if idx is None:
            break
        sub = _find_subcommand(cmd, ctx, args[idx])
        if sub is None:
            break
        cmd = sub
        info = args[idx]
        pos = idx + 1

    rest = args[pos:]
    ctx = cmd.make_context(info, rest, resilient_parsing=True)

    if isinstance(cmd, Group) and not incomplete.startswith("-"):
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str()))
        return items

    # A pending option that wants a value.
    if rest and not incomplete.startswith("-"):
        last = rest[-1]
        for param in cmd.params:
            if isinstance(param, Option) and last in (param.opts + param.secondary_opts):
                if not param.is_flag:
                    return _param_items(ctx, param, incomplete)

    if incomplete.startswith("-") or (not isinstance(cmd, Group) and incomplete == ""
                                      and not any(isinstance(p, Argument) for p in cmd.params)):
        if incomplete.startswith("-"):
            return _option_names(cmd, ctx, incomplete)
        return []

    # Positional argument completion.
    positional = [t for t in rest if not t.startswith("-")]
    arguments = [p for p in cmd.params if isinstance(p, Argument)]
    if len(positional) < len(arguments):
        param = arguments[len(positional)]
        return [i for i in _param_items(ctx, param, incomplete)
                if i.type != "plain" or i.value.startswith(incomplete)]
    return []
