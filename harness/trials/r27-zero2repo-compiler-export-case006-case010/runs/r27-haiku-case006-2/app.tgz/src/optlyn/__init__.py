"""Optlyn: composable command line interfaces with as little code as necessary.

# spec: N-000791 N-000792 N-000793 N-000795 N-000796 N-000797 N-000798 N-000799
# spec: N-000800 N-000801 N-000802
"""

from . import formatting as formatting
from . import testing as testing
from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    ParameterSource,
    command,
    confirmation_option,
    custom_version_option,
    argument,
    group,
    help_option,
    make_pass_decorator,
    option,
    password_option,
    pass_context,
    pass_obj,
    version_option,
)
from .core import Parameter
from .exceptions import Abort, BadParameter, Exit, FileError, MissingParameter, OptlynException, UsageError
from ._state import get_current_context
from .formatting import wrap_text
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    get_binary_stderr,
    get_binary_stdin,
    get_binary_stdout,
    get_text_stderr,
    get_text_stdin,
    get_text_stdout,
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, get_app_dir, open_file

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "Argument",
    "ParamType", "BadParameter", "Abort", "UsageError", "MissingParameter", "Exit",
    "FileError", "OptlynException", "ParameterSource",
    # parameter types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
    "get_binary_stdin", "get_binary_stdout", "get_binary_stderr",
    "get_text_stdin", "get_text_stdout", "get_text_stderr",
    # formatting
    "wrap_text",
    "testing",
]
