"""Text wrapping and help-page layout.

# spec: N-000679 N-000680 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138
# spec: N-000803 N-000827 N-000828 N-000829 N-000831 N-000832 N-000833 N-000834
# spec: N-000835 N-000836 N-000837 N-000838 N-000839 N-000840 N-000842 N-000843
# spec: N-000844 N-000845
"""

from __future__ import annotations

import contextlib
import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80
MAX_CONTENT_WIDTH = 100


def _safe_width(width, initial_indent, subsequent_indent):
    width = max(int(width), 1)
    return max(width, len(initial_indent) + 1, len(subsequent_indent) + 1)


def wrap_text(text, width: int = 78, initial_indent: str = "", subsequent_indent: str = "",
              preserve_paragraphs: bool = False) -> str:
    """Wrap ``text`` to ``width`` columns. Accepts any string.

    # spec: N-000679 N-000997
    """
    text = "" if text is None else str(text)
    width = _safe_width(width, initial_indent, subsequent_indent)
    wrapper = textwrap.TextWrapper(
        width=width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=True,
        break_on_hyphens=False,
        replace_whitespace=True,
        drop_whitespace=True,
    )
    if not preserve_paragraphs:
        words = text.split()
        return wrapper.fill(" ".join(words)) if words else ""

    out = []
    for para in _split_paragraphs(text):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            # Backspace paragraph: keep its own line breaks; drop the marker line.
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln.strip() if i == 0 else subsequent_indent + ln.strip()
                                  for i, ln in enumerate(kept)))
            continue
        flat = " ".join(line.strip() for line in lines if line.strip())
        if flat:
            out.append(wrapper.fill(flat))
    return "\n\n".join(out)


def _split_paragraphs(text: str):
    paras, current = [], []
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if line.strip() == "":
            if current:
                paras.append("\n".join(current))
                current = []
        else:
            current.append(line)
    if current:
        paras.append("\n".join(current))
    return paras


class HelpFormatter:
    """Accumulates help text for a command or group."""

    def __init__(self, width: int = 78, indent_increment: int = 2) -> None:
        self.width = width
        self.indent_increment = indent_increment
        self.indent = 0
        self.buffer: list[str] = []

    def write(self, text: str) -> None:
        self.buffer.append(text)

    def getvalue(self) -> str:
        return "".join(self.buffer)

    def write_usage(self, prog: str, args: str = "", prefix: str = "Usage: ") -> None:
        usage_prefix = f"{prefix}{prog} "
        if not args:
            self.write(f"{usage_prefix.rstrip()}\n")
            return
        text = wrap_text(args, width=self.width, initial_indent=usage_prefix,
                         subsequent_indent=" " * len(usage_prefix))
        self.write(f"{text}\n")

    def write_paragraph(self) -> None:
        if self.buffer:
            self.write("\n")

    def write_text(self, text: str) -> None:
        indent = " " * self.indent
        width = self.width - len(indent)
        wrapped = wrap_text(text, width=width, initial_indent=indent, subsequent_indent=indent,
                            preserve_paragraphs=True)
        if wrapped:
            self.write(f"{wrapped}\n")

    def write_heading(self, heading: str) -> None:
        self.write(f"{' ' * self.indent}{heading}:\n")

    @contextlib.contextmanager
    def section(self, name: str):
        self.write_paragraph()
        self.write_heading(name)
        self.indent += self.indent_increment
        try:
            yield
        finally:
            self.indent -= self.indent_increment

    def write_dl(self, rows, col_max: int = 30, col_spacing: int = 2) -> None:
        rows = [(str(a), "" if b is None else str(b)) for a, b in rows]
        if not rows:
            return
        indent = " " * self.indent
        first_width = min(max(len(a) for a, _ in rows), col_max) + col_spacing
        second_width = max(self.width - self.indent - first_width, 10)
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}\n")
                continue
            if len(first) + col_spacing <= first_width:
                lead = f"{indent}{first.ljust(first_width)}"
                first_line_prefix = ""
            else:
                self.write(f"{indent}{first}\n")
                lead = " " * (len(indent) + first_width)
                first_line_prefix = ""
            body = wrap_text(second, width=second_width, preserve_paragraphs=True)
            lines = body.split("\n")
            pad = " " * (len(indent) + first_width)
            self.write(f"{lead}{first_line_prefix}{lines[0]}\n")
            for line in lines[1:]:
                self.write(f"{pad}{line}\n" if line.strip() else "\n")
