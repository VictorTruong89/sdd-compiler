"""Parameter types and value conversion.

# spec: N-000936 N-000937 N-000938 N-000939 N-000940 N-000941 N-000942 N-000943
# spec: N-000944 N-000945 N-000946 N-000947 N-000948 N-000949 N-000332 N-000333
# spec: N-000334 N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341
# spec: N-000342 N-000343 N-000344 N-000345 N-000346 N-000347 N-000348 N-000349
# spec: N-000350 N-000351 N-000352 N-000353 N-000354 N-000355 N-000356 N-000357
# spec: N-000358 N-000359 N-000360 N-000361 N-000362 N-000363 N-000364 N-000365
# spec: N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000372 N-000373
# spec: N-000374 N-000381 N-000382 N-000383 N-000548 N-000549 N-000550 N-000551
# spec: N-000552 N-000553 N-000554 N-000555 N-000556 N-000557 N-000558 N-000559
# spec: N-000560 N-000561 N-000562 N-000563 N-000564 N-000565 N-000566 N-000567
# spec: N-000568 N-000569 N-000570 N-000571 N-000572 N-000573 N-000574 N-000578
# spec: N-000579 N-000583 N-000584 N-000585 N-000586 N-000587
"""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib as _pathlib
import uuid as _uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`.
    """

    name = "text"
    #: Separator used when splitting environment values for multi-value use.
    envvar_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return self.name.upper()

    def split_envvar_value(self, rv: str) -> list:
        if self.envvar_splitter is not None:
            return [part for part in rv.split(self.envvar_splitter) if part != ""]
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration.

    # spec: N-000348 N-000349 N-000350 N-000351 N-000352 N-000382 N-000383
    """

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._tokens = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def _normalize(self, value, ctx):
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if func is not None:
            value = func(value)
        return value

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice:
                return choice
        if not isinstance(value, str):
            value = str(value)
        normed = self._normalize(value, ctx)
        for choice, token in zip(self.choices, self._tokens):
            cand = self._normalize(token, ctx)
            if cand == normed or (not self.case_sensitive and cand.casefold() == normed.casefold()):
                return choice
        options = ", ".join(repr(t) for t in self._tokens)
        self.fail(f"{value!r} is not {'one of ' if len(self._tokens) != 1 else ''}{options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    """Parses a date-time. Formats are tried in order; the first success wins.

    # spec: N-000353 N-000354 N-000355 N-000356 N-000357
    """

    name = "datetime"

    def __init__(self, formats=None) -> None:
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the format{'s' if len(self.formats) != 1 else ''} " + ", ".join(self.formats) + ".", param, ctx)


class _RangeMixin:
    def _range_text(self):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"

    def _check(self, value, param, ctx):
        if self.min is not None:
            if value < self.min or (self.min_open and value == self.min):
                if self.clamp:
                    return self.min + 1 if self.min_open and self._is_int else self.min
                self.fail(f"{value} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if value > self.max or (self.max_open and value == self.max):
                if self.clamp:
                    return self.max - 1 if self.max_open and self._is_int else self.max
                self.fail(f"{value} is not in the range {self._range_text()}.", param, ctx)
        return value


class IntRange(_RangeMixin, _IntType):
    """An integer within an optional range. # spec: N-000358 N-000359 N-000360 N-000361 N-000362"""

    name = "integer range"
    _is_int = True

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = _IntType.convert(self, value, param, ctx)
        return self._check(value, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    """A float within an optional range. Clamp is refused when a bound is open.

    # spec: N-000363 N-000364 N-000365
    """

    name = "float range"
    _is_int = False

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        if clamp and ((min_open and min is not None) or (max_open and max is not None)):
            raise ValueError("FloatRange: clamp is only allowed when both bounds are closed.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = _FloatType.convert(self, value, param, ctx)
        return self._check(value, param, ctx)


def _as_type(ty):
    return convert_type(ty)


class Tuple(ParamType):
    """A fixed-length product of inner types. # spec: N-000366"""

    name = "tuple"

    def __init__(self, types) -> None:
        self.types = [_as_type(t) for t in types]

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, str) or len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    """An open file. ``-`` is stdin for reading and stdout for writing.

    # spec: N-000532 N-000533 N-000534 N-000535 N-000536 N-000537 N-000538 N-000539
    """

    name = "filename"
    envvar_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported File mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def convert(self, value, param, ctx):
        from .utils import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        filename = os.fspath(value)
        try:
            f = open_file(filename, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except OSError as e:
            self.fail(f"'{filename}': {e.strerror or e}", param, ctx)
        if filename != "-" and ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete_kind(self):
        return "file"


class Path(ParamType):
    """A filesystem path (not an open file). # spec: N-000548 N-000549 N-000573"""

    name = "path"
    envvar_splitter = os.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def convert(self, value, param, ctx):
        value = os.fspath(value)
        if not (self.allow_dash and value == "-"):
            if self.resolve_path:
                value = os.path.abspath(os.path.realpath(value))
            exists = os.path.exists(value)
            if not exists:
                if self.exists:
                    self.fail(f"{value!r} does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(value):
                    self.fail(f"{value!r} is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(value):
                    self.fail(f"{value!r} is a directory.", param, ctx)
                if self.readable and not os.access(value, os.R_OK):
                    self.fail(f"{value!r} is not readable.", param, ctx)
                if self.writable and not os.access(value, os.W_OK):
                    self.fail(f"{value!r} is not writable.", param, ctx)
                if self.executable and not os.access(value, os.X_OK):
                    self.fail(f"{value!r} is not executable.", param, ctx)
        if self.path_type is None or self.path_type is str:
            return value
        if self.path_type is _pathlib.Path:
            return _pathlib.Path(value)
        return self.path_type(value)

    def shell_complete_kind(self):
        if not self.file_okay and self.dir_okay:
            return "dir"
        return "file"


_BUILTIN_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def _infer_type(default):
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, str):
        return STRING
    if isinstance(default, (list, tuple)) and default:
        return _infer_type(default[0])
    if default is None:
        return STRING
    return UNPROCESSED


def convert_type(ty, default=None) -> ParamType:
    """Turn a user-supplied ``type=`` value into a :class:`ParamType`.

    # spec: N-000330 N-000331 N-000337 N-000346 N-000347
    """
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        return _infer_type(default)
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty in _BUILTIN_MAP:
        return _BUILTIN_MAP[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
