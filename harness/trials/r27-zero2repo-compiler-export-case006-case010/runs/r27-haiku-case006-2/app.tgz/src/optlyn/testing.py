"""In-process runner: invoke commands with tokens and capture their output.

# spec: N-001038 N-001039 N-001040 N-001041 N-001042 N-001043 N-001044
# spec: N-000736 N-000737 N-000738 N-000739 N-000740 N-000741 N-000742 N-000743
# spec: N-000744 N-000745 N-000746 N-000747 N-000748 N-000749 N-000750 N-000751
# spec: N-000752 N-000753 N-000754 N-000755 N-000756 N-000757 N-000758 N-000759
# spec: N-000760 N-000761 N-000762 N-000763
"""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile


class _Mixed:
    """Shared, ordered record of everything written to stdout and stderr."""

    def __init__(self) -> None:
        self.data = bytearray()


class _CaptureBytes(io.RawIOBase):
    def __init__(self, sink: bytearray, mixed: _Mixed) -> None:
        self._sink = sink
        self._mixed = mixed

    def writable(self):
        return True

    def write(self, b):
        data = bytes(b)
        self._sink.extend(data)
        self._mixed.data.extend(data)
        return len(data)


class _CaptureStream(io.TextIOBase):
    """Text stream whose writes are recorded as bytes in order."""

    def __init__(self, charset: str, sink: bytearray, mixed: _Mixed) -> None:
        self._charset = charset
        self._sink = sink
        self._mixed = mixed
        self._binary = io.BufferedWriter(_CaptureBytes(sink, mixed))

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "strict"

    @property
    def buffer(self):
        return self._binary

    def writable(self):
        return True

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, s):
        data = str(s).encode(self._charset, "replace")
        self._binary.write(data)
        self._binary.flush()
        return len(s)

    def flush(self):
        self._binary.flush()


class _InputStream(io.TextIOBase):
    """Standard input fed from the runner's ``input`` value."""

    _optlyn_runner = True

    def __init__(self, data: bytes, charset: str, echo_stdin: bool, output: _CaptureStream) -> None:
        self._text = data.decode(charset, "replace")
        self._pos = 0
        self._echo = echo_stdin
        self._output = output
        self._optlyn_echo_reads = echo_stdin

    @property
    def encoding(self):
        return "utf-8"

    @property
    def buffer(self):
        return self

    def isatty(self):
        return False

    def readable(self):
        return True

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def read(self, size=-1):
        if size is None or size < 0:
            chunk = self._text[self._pos:]
        else:
            chunk = self._text[self._pos:self._pos + size]
        self._pos += len(chunk)
        if self._echo and chunk:
            self._output.write(chunk)
        return chunk

    def readline(self, size=-1):
        if self._pos >= len(self._text):
            return ""
        end = self._text.find("\n", self._pos)
        end = len(self._text) if end == -1 else end + 1
        line = self._text[self._pos:end]
        self._pos = end
        if self._echo:
            self._output.write(line)
        return line

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if line == "":
            raise StopIteration
        return line


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, mixed: bytes,
                 return_value, exit_code: int, exception, exc_info=None) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = mixed
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code!r}>"


class CliRunner:
    """Invoke commands in-process. # spec: N-001038 N-001039"""

    def __init__(self, charset: str = "utf-8", env=None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color: bool = False):
        mixed = _Mixed()
        out_sink = bytearray()
        err_sink = bytearray()
        stdout = _CaptureStream(self.charset, out_sink, mixed)
        stderr = _CaptureStream(self.charset, err_sink, mixed)
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        stdin = _InputStream(data, self.charset, self.echo_stdin, stdout)

        env_overrides = dict(self.env)
        env_overrides.update(env or {})
        saved_env = {}
        for key, value in env_overrides.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield (out_sink, err_sink, mixed)
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            stdout.flush()
            stderr.flush()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color: bool = False,
               **extra) -> Result:
        """Run ``cli`` with ``args`` and capture the outcome. # spec: N-001040 N-001041 N-001042 N-001043"""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = shlex.split(args)
        args = [] if args is None else list(args)
        extra.setdefault("color", color)
        prog_name = extra.pop("prog_name", None) or (getattr(cli, "name", None) or "root")
        standalone = extra.pop("standalone_mode", True)

        exception = None
        exit_code = 0
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (out_sink, err_sink, mixed):
            try:
                return_value = cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
                exit_code = 0
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()

        return Result(
            runner=self,
            stdout_bytes=bytes(out_sink),
            stderr_bytes=bytes(err_sink),
            mixed=bytes(mixed.data),
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory for the duration of the block.

        When no parent is given the directory is removed on exit.
        # spec: N-001044 N-000744 N-000745 N-000746 N-000747
        """
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield os.path.abspath(path)
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
