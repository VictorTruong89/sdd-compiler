"""Thread-local stack of active invocation contexts.

# spec: N-000978 N-000979 N-000980 N-000477 N-000478 N-000479
"""

from __future__ import annotations

import threading

_local = threading.local()


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx) -> None:
    _stack().append(ctx)


def pop_context() -> None:
    stack = _stack()
    if stack:
        stack.pop()


def get_current_context(silent: bool = False):
    """Return the context current on this thread.

    # spec: N-000978 N-000979 N-000980
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
