"""Core: invocation context, parameters, parser, commands, groups, decorators.

Spec ids are cited beside the code that satisfies them.
"""

from __future__ import annotations

import difflib
import enum
import errno
import functools
import inspect
import os
import re
import shutil
import sys

from . import paramtypes as pt
from ._state import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynException,
    UsageError,
)
from .formatting import DEFAULT_MAX_CONTENT_WIDTH, HelpFormatter
from .termui import confirm, echo, prompt

__all__ = [
    "Context", "Parameter", "Option", "Argument", "Command", "Group", "CommandCollection",
    "ParameterSource", "command", "group", "option", "argument", "pass_context", "pass_obj",
    "make_pass_decorator", "help_option", "version_option", "custom_version_option",
    "password_option", "confirmation_option", "get_current_context",
]

_TRUE_WORDS = {"true", "1", "yes", "on", "t", "y"}
_FALSE_WORDS = {"false", "0", "no", "off", "f", "n"}

# Marker stored in the parser output for an option given without a value that prompts.
_NEEDS_PROMPT = object()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Five distinct sources.

    # spec: N-000463 N-000464 N-000465 N-000466 N-000243 N-000245
    """

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Lower rank = more explicit source.
_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}


def _wrap_width(ctx) -> int:
    # spec: N-000133 N-000134 N-000135 N-000680
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    max_cw = ctx.max_content_width if ctx.max_content_width is not None else DEFAULT_MAX_CONTENT_WIDTH
    cols = shutil.get_terminal_size().columns
    return max(min(cols, max_cw) - 2, 20)


class Context:
    """Per-invocation state. # spec: N-000950 N-000951 N-000952 N-000953 N-000954 N-000955 N-000956 N-000957 N-000958 N-000959 N-000960 N-000961 N-000962 N-000963 N-000964 N-000965 N-000966 N-000967 N-000968 N-000969 N-000970 N-000971 N-000972 N-000973 N-000974"""

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 allow_extra_args=None, allow_interspersed_args=None, ignore_unknown_options=None,
                 help_option_names=None, token_normalize_func=None, color=None, show_default=None,
                 resilient_parsing=False, meta=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        if parent is not None:
            if obj is None:
                obj = parent.obj
            if auto_envvar_prefix is None:
                auto_envvar_prefix = parent.auto_envvar_prefix
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if default_map is None and info_name is not None and parent.default_map is not None:
                nested = parent.default_map.get(info_name)
                default_map = nested if isinstance(nested, dict) else None
        if help_option_names is None:
            help_option_names = ["--help"]
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        if ignore_unknown_options is None:
            ignore_unknown_options = command.ignore_unknown_options

        self.obj = obj
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width
        self.allow_extra_args = allow_extra_args
        self.allow_interspersed_args = allow_interspersed_args
        self.ignore_unknown_options = ignore_unknown_options
        self.help_option_names = list(help_option_names)
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = show_default
        self.resilient_parsing = resilient_parsing
        self.meta = {} if meta is None else meta

        self.params: dict = {}
        self.args: list = []
        self.protected_args: list = []
        self.invoked_subcommand = None
        self._parameter_source: dict = {}
        self._close_callbacks: list = []
        self._depth = 0

    # -- naming -------------------------------------------------------------
    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if rv else parent_path
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    # -- objects ------------------------------------------------------------
    def find_object(self, object_type):
        """# spec: N-000975 N-000976 N-000977 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439 N-000440 N-000441 N-000442 N-000443"""
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    # -- defaults and sources -----------------------------------------------
    def lookup_default(self, name, call: bool = True):
        """# spec: N-000450 N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460 N-000461 N-000462"""
        if self.default_map is None:
            return None
        value = self.default_map.get(name)
        if call and callable(value):
            return value()
        return value

    def get_parameter_source(self, name):
        """None for an undeclared name; otherwise one of the five sources.

        # spec: N-000463 N-000464 N-000465 N-000466
        """
        declared = {p.name for p in self.command.params}
        if name not in declared:
            return None
        return self._parameter_source.get(name, ParameterSource.DEFAULT)

    # -- control ------------------------------------------------------------
    def fail(self, message: str):
        raise UsageError(message, self)

    def abort(self):
        """# spec: N-000964 N-000963 N-000973"""
        raise Abort()

    def exit(self, code: int = 0):
        """Author clean stop. # spec: N-000716 N-000717 N-000718"""
        raise Exit(code)

    def with_resource(self, context_manager):
        """# spec: N-000470 N-000472 N-000473"""
        value = context_manager.__enter__()
        self.call_on_close(lambda: context_manager.__exit__(None, None, None))
        return value

    def call_on_close(self, func):
        self._close_callbacks.append(func)
        return func

    def close(self) -> None:
        while self._close_callbacks:
            callback = self._close_callbacks.pop()
            callback()

    def invoke(self, callback, /, *args, **kwargs):
        """Run a callback or another command from inside a callback.

        # spec: N-000471 N-000472 N-000473 N-000474 N-000475 N-000476
        """
        ctx = self
        if isinstance(callback, Command):
            other = callback
            callback = other.callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.get_default(ctx)
        if callback is None:
            return None
        with ctx:
            return callback(*args, **kwargs)

    def forward(self, cmd, /, **kwargs):
        kwargs = {**self.params, **kwargs}
        return self.invoke(cmd, **kwargs)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def make_formatter(self) -> HelpFormatter:
        return HelpFormatter(width=_wrap_width(self))

    # -- context manager protocol -------------------------------------------
    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()
        return False


# ---------------------------------------------------------------------------
# Declaration helpers
# ---------------------------------------------------------------------------

def _is_prefixed(decl: str) -> bool:
    return bool(decl) and not (decl[0].isalnum() or decl[0] == "_")


def _is_long(name: str) -> bool:
    return len(name) >= 3 and name[0] == name[1]


def _check_flag_name(name: str) -> None:
    # spec: N-000188 N-000193 N-000226
    if len(name) < 2 or not _is_prefixed(name):
        raise ValueError(f"Invalid option name {name!r}.")
    if not _is_long(name) and len(name) != 2:
        raise ValueError("Multi-character short names are not supported.")


def _parse_option_decls(decls):
    """Split declarations into (dest, opts, secondary opts). # spec: N-000178 N-000179 N-000194 N-000195"""
    opts, secondary = [], []
    dest = None
    for decl in decls:
        if not isinstance(decl, str) or decl == "":
            raise TypeError(f"Invalid parameter declaration {decl!r}.")
        if not _is_prefixed(decl):
            if dest is not None:
                raise TypeError("Only one destination name may be given.")
            dest = decl
            continue
        idx = decl.find("/", 1)
        if idx != -1:
            on, off = decl[:idx], decl[idx + 1:]
            _check_flag_name(on)
            _check_flag_name(off)
            opts.append(on)
            secondary.append(off)
            continue
        _check_flag_name(decl)
        opts.append(decl)
    if dest is None:
        pick = next((o for o in opts if _is_long(o)), None)
        if pick is None and opts:
            pick = opts[0]
        if pick is None:
            raise TypeError("Could not determine a destination name for the parameter.")
        dest = pick.lstrip("-/+").replace("-", "_")
    return dest, opts, secondary


class Parameter:
    """Common behaviour of options and arguments.

    # spec: N-000921 N-000922 N-000923
    """

    is_argument = False
    param_type_name = "parameter"

    def __init__(self, name, *, type=None, required=False, default=None, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, help=None, hidden=False,
                 show_default=None, show_envvar=False):
        self.name = name
        if nargs is None:
            nargs = 1
        if not isinstance(nargs, int) or isinstance(nargs, bool) or nargs == 0 or nargs < -1:
            raise ValueError("nargs must be a positive integer (or -1 for an argument).")
        if nargs == -1 and not self.is_argument:
            raise ValueError("nargs=-1 is only allowed for arguments.")
        self.type = pt.convert_type(type, default)
        if isinstance(self.type, pt.Tuple) and nargs == 1:
            nargs = len(self.type.types)
        self.nargs = nargs
        self.multiple = multiple
        self.default = default
        self.required = required
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar = None
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar

    # -- introspection ------------------------------------------------------
    @property
    def _per_occurrence_tuple(self) -> bool:
        return self.nargs > 1

    @property
    def _variadic(self) -> bool:
        return self.nargs == -1

    def get_error_hint(self, ctx) -> str:
        raise NotImplementedError

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)

    def get_default(self, ctx):
        """# spec: N-000182 N-000183 N-000184 N-000185 N-000186 N-000187"""
        value = self.default
        if callable(value):
            value = value()
        return value

    # -- value sources ------------------------------------------------------
    def _env_value(self, ctx, raw: str, name: str):
        tokens = None
        if self.multiple or self.nargs != 1:
            tokens = self.type.split_envvar_value(raw)
        if tokens is None:
            return raw
        if self.multiple or self._variadic:
            if self._per_occurrence_tuple:
                n = self.nargs
                return [tuple(tokens[i:i + n]) for i in range(0, len(tokens) - n + 1, n)]
            return tokens
        return tuple(tokens[:self.nargs])

    def value_from_envvar(self, ctx):
        """# spec: N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000309 N-000310 N-000313 N-000314 N-000315 N-000316 N-000317"""
        names = list(self.envvar or [])
        if self._auto_envvar_allowed(ctx):
            names.append(self._auto_envvar_name(ctx))
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self._env_value(ctx, raw, name)
            if value is not None:
                return value
        return None

    def _auto_envvar_allowed(self, ctx) -> bool:
        return False

    def _auto_envvar_name(self, ctx) -> str:
        return ""

    def prompt_for_value(self, ctx, default=None):
        return default

    def _convert_one(self, ctx, occ):
        if isinstance(self.type, pt.Tuple):
            return self.type.convert(occ, self, ctx)
        if self._per_occurrence_tuple:
            return tuple(self.type.convert(x, self, ctx) for x in occ)
        return self.type.convert(occ, self, ctx)

    def _convert_value(self, ctx, value, source):
        """Convert a raw value (scalar occurrence or list of occurrences)."""
        if self.is_flag_like:
            return value
        if source in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP) and isinstance(value, str):
            if self.multiple and not self._variadic:
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default, not a string.", ctx)
            if self._variadic:
                value = [value]
            elif self._per_occurrence_tuple:
                tokens = self.type.split_envvar_value(value)
                value = tuple(tokens[:self.nargs])
        if self.multiple or self._variadic:
            if value is None:
                return ()
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx)
            return tuple(self._convert_one(ctx, occ) for occ in value)
        if value is None:
            return None
        return self._convert_one(ctx, value)

    @property
    def is_flag_like(self) -> bool:
        return False

    def _is_missing(self, result) -> bool:
        if result is None:
            return True
        if (self.multiple or self._variadic) and result == ():
            return True
        return False

    def process_value(self, ctx, value, source):
        """Convert, check required, run the callback. # spec: N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261 N-000262 N-000263"""
        if source is ParameterSource.PROMPT:
            if self.multiple or self._variadic:
                if value is None:
                    result = ()
                elif isinstance(value, list):
                    result = tuple(value)
                else:
                    result = (value,)
            else:
                result = value
        else:
            result = self._convert_value(ctx, value, source)
        if self.required and self._is_missing(result):
            raise MissingParameter(ctx=ctx, param=self)
        if self.deprecated and source is ParameterSource.COMMANDLINE:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The {self.param_type_name} {self._deprecated_name()!r} "
                 f"is deprecated. {note}".rstrip(), err=True)
        if self.callback is not None:
            result = self.callback(ctx, self, result)
        return result

    def _deprecated_name(self) -> str:
        return self.name

    def handle_parse_result(self, ctx, occ, leftover):
        raise NotImplementedError


def _store_param(ctx, param, value, source) -> None:
    """Record a value and its source. Feature-switch options sharing a destination:
    the more explicit source wins; equal sources let the later one win.

    # spec: N-000246 N-000247 N-000248 N-000249
    """
    if not param.expose_value:
        return
    name = param.name
    prev = ctx._parameter_source.get(name)
    if name in ctx.params and prev is not None and _RANK[prev] < _RANK[source]:
        return
    ctx.params[name] = value
    ctx._parameter_source[name] = source


class Option(Parameter):
    """An option. # spec: N-000881 N-000882 N-000883 N-000884 N-000885 N-000886 N-000887 N-000888 N-000889 N-000890 N-000891 N-000892 N-000893 N-000894 N-000895 N-000896 N-000897 N-000898 N-000899 N-000900 N-000901 N-000902 N-000903 N-000904 N-000905 N-000906 N-000907 N-000908 N-000909"""

    param_type_name = "option"

    def __init__(self, param_decls=None, *, show_default=None, prompt=None, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None, count=False,
                 allow_from_autoenv=True, help=None, hidden=False, show_envvar=False, type=None,
                 required=False, default=None, callback=None, nargs=None, multiple=False,
                 metavar=None, expose_value=True, is_eager=False, envvar=None, shell_complete=None,
                 deprecated=False):
        decls = list(param_decls or [])
        name, opts, secondary = _parse_option_decls(decls)
        if not opts and not secondary:
            raise TypeError("An option needs at least one flag name.")
        self.opts = opts
        self.secondary_opts = secondary
        if count:
            is_flag = True
        if secondary:
            is_flag = True
        if is_flag is None:
            is_flag = False
        self._is_flag = bool(is_flag)
        self.count = bool(count)
        if self._is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        self.is_optional_value = (not self._is_flag) and flag_value is not None
        if self._is_flag:
            if type is None:
                type = pt.INT if count else pt.BOOL
            if nargs not in (None, 1):
                raise ValueError("A flag cannot take more than one value.")
            nargs = 1
            if default is None and not count:
                default = False
            if count and default is None:
                default = 0
        if deprecated and required:
            raise ValueError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        self.prompt = prompt if (prompt is True or (isinstance(prompt, str) and prompt)) else None
        self.prompt_required = prompt_required
        self.confirmation_prompt = confirmation_prompt
        self.hide_input = hide_input
        self.allow_from_autoenv = allow_from_autoenv
        super().__init__(name, type=type, required=required, default=default, callback=callback,
                         nargs=nargs, multiple=multiple, metavar=metavar, expose_value=expose_value,
                         is_eager=is_eager, envvar=envvar, shell_complete=shell_complete,
                         deprecated=deprecated, help=help, hidden=hidden, show_default=show_default,
                         show_envvar=show_envvar)
        if self._is_flag and self.nargs != 1:
            raise ValueError("A flag cannot take more than one value.")

    @property
    def is_flag(self) -> bool:
        return self._is_flag

    @property
    def is_flag_like(self) -> bool:
        return self._is_flag

    @property
    def is_bool_flag(self) -> bool:
        return self._is_flag and isinstance(self.flag_value, bool) and not self.count

    def _auto_envvar_allowed(self, ctx) -> bool:
        return self.allow_from_autoenv and ctx.auto_envvar_prefix is not None

    def _auto_envvar_name(self, ctx) -> str:
        # spec: N-000444 N-000445 N-000446 N-000447 N-000448 N-000449
        chain = []
        node = ctx
        while node is not None and node.parent is not None:
            chain.append(node.info_name or "")
            node = node.parent
        parts = [ctx.auto_envvar_prefix] + list(reversed(chain)) + [self.name]
        return "_".join(p.replace("-", "_") for p in parts if p).upper()

    def _env_value(self, ctx, raw: str, name: str):
        # spec: N-000234 N-000235 N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242
        if self._is_flag:
            if self.count:
                return None
            text = raw.strip().lower()
            if isinstance(self.flag_value, bool):
                if text in _TRUE_WORDS:
                    return True
                if text in _FALSE_WORDS or text == "":
                    return False
                raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
            if raw == str(self.flag_value):
                return self.flag_value
            if text in _TRUE_WORDS:
                return self.flag_value
            if text in _FALSE_WORDS:
                return False
            return None
        return super()._env_value(ctx, raw, name)

    def get_error_hint(self, ctx) -> str:
        return " / ".join(repr(x) for x in self.opts + self.secondary_opts)

    def _deprecated_name(self) -> str:
        return (self.opts + self.secondary_opts or [self.name])[0]

    def _flag_occurrence(self, off: bool):
        if self.count:
            return True
        if off:
            return False
        return self.flag_value

    def make_metavar(self):
        # spec: N-000139 N-000140 N-000141 N-000142 N-000143 N-000144
        if self.metavar is not None:
            return self.metavar
        if self._is_flag:
            return None
        return self.type.get_metavar(self)

    def prompt_for_value(self, ctx, default=None):
        """# spec: N-000488 N-000489 N-000490 N-000491 N-000492 N-000493 N-000494 N-000495 N-000496 N-000497 N-000498 N-000499 N-000500"""
        if callable(default):
            default = default()
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if self._is_flag:
            return confirm(text, default=bool(default))

        def value_proc(v):
            if self.nargs > 1 and isinstance(v, str):
                tokens = self.type.split_envvar_value(v)
                if len(tokens) != self.nargs:
                    raise BadParameter(f"Takes {self.nargs} values.", ctx=ctx, param=self)
                v = tuple(tokens)
            return self._convert_one(ctx, v)

        return prompt(text, default=default, hide_input=self.hide_input,
                      confirmation_prompt=self.confirmation_prompt, value_proc=value_proc)

    def _prompt_occurrence(self, ctx):
        return self.prompt_for_value(ctx, None)

    def consume_value(self, ctx, occ):
        """Return (value, source). # spec: N-000205 N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225"""
        raws = occ.get(self)
        if raws:
            if self.count:
                return len(raws), ParameterSource.COMMANDLINE
            source = ParameterSource.COMMANDLINE
            if self.multiple:
                values = []
                for r in raws:
                    if r is _NEEDS_PROMPT:
                        values.append(self._prompt_occurrence(ctx))
                        source = ParameterSource.PROMPT
                    else:
                        values.append(r)
                return values, source
            last = raws[-1]
            if last is _NEEDS_PROMPT:
                return self._prompt_occurrence(ctx), ParameterSource.PROMPT
            return last, source

        value = self.value_from_envvar(ctx)
        if value is not None:
            source = ParameterSource.ENVIRONMENT
        else:
            value = ctx.lookup_default(self.name)
            if value is not None:
                source = ParameterSource.DEFAULT_MAP
            else:
                value = self.get_default(ctx)
                source = ParameterSource.DEFAULT

        if (self.prompt is not None and not ctx.resilient_parsing
                and source in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP)
                and (self.prompt_required or self.required)):
            return self.prompt_for_value(ctx, value), ParameterSource.PROMPT
        if self.count and value is None:
            value = 0
        return value, source

    def handle_parse_result(self, ctx, occ, leftover):
        value, source = self.consume_value(ctx, occ)
        result = self.process_value(ctx, value, source)
        _store_param(ctx, self, result, source)
        return result

    def get_help_record(self, ctx):
        # spec: N-000837 N-000838 N-000839 N-000840 N-000841 N-000842 N-000843 N-000844
        names = ", ".join(self.opts)
        if self.secondary_opts:
            names = f"{names}/{', '.join(self.secondary_opts)}"
        metavar = self.make_metavar()
        first = f"{names} {metavar}" if metavar else names
        parts = []
        help_text = self.help or ""
        if self.deprecated:
            help_text = ("(DEPRECATED) " + help_text).strip()
        if help_text:
            parts.append(help_text)
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show and not (self._is_flag and self.default is False) and self.default is not None:
            if isinstance(show, str):
                parts.append(f"[default: {show}]")
            elif callable(self.default):
                parts.append("[default: (dynamic)]")
            else:
                value = self.default
                if isinstance(value, (list, tuple)):
                    value = ", ".join(str(v) for v in value)
                parts.append(f"[default: {value}]")
        if self.show_envvar and self.envvar:
            parts.append(f"[env var: {', '.join(self.envvar)}]")
        return first, " ".join(parts)


class Argument(Parameter):
    """A positional argument. # spec: N-000285 N-000286 N-000287 N-000288 N-000289 N-000290 N-000291 N-000292 N-000293 N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000910 N-000911 N-000912"""

    is_argument = True
    param_type_name = "argument"

    def __init__(self, param_decls=None, *, required=None, nargs=1, type=None, default=None,
                 callback=None, metavar=None, expose_value=True, is_eager=False, envvar=None,
                 shell_complete=None, deprecated=False, help=None, hidden=False, multiple=False):
        decls = list(param_decls or [])
        if len(decls) != 1 or not isinstance(decls[0], str) or _is_prefixed(decls[0]):
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if nargs is None:
            nargs = 1
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise ValueError("A deprecated argument cannot be required.")
        super().__init__(name, type=type, required=required, default=default, callback=callback,
                         nargs=nargs, multiple=False, metavar=metavar, expose_value=expose_value,
                         is_eager=is_eager, envvar=envvar, shell_complete=shell_complete,
                         deprecated=deprecated, help=help, hidden=hidden)

    def get_error_hint(self, ctx) -> str:
        return repr(self.name)

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def make_placeholder(self) -> str:
        meta = self.make_metavar()
        if self.nargs > 1:
            meta = " ".join([meta] * self.nargs)
        if self._variadic:
            meta = f"{meta}..."
        if not self.required:
            meta = f"[{meta}]"
        return meta

    @property
    def is_flag_like(self) -> bool:
        return False

    def get_help_record(self, ctx):
        first = self.make_metavar()
        return first, self.help or ""

    def consume_value(self, ctx, occ, leftover=None):
        raw = None
        source = ParameterSource.COMMANDLINE
        if leftover:
            if self._variadic:
                raw = [tok for tok, _ in leftover]
                del leftover[:]
            elif self.nargs == 1:
                raw = leftover.pop(0)[0]
            elif len(leftover) >= self.nargs:
                raw = tuple(tok for tok, _ in leftover[:self.nargs])
                del leftover[:self.nargs]
            else:
                raise BadArgumentUsage(f"Argument {self.name!r} takes {self.nargs} values.", ctx)
        if raw is None:
            value = self.value_from_envvar(ctx)
            if value is not None:
                return value, ParameterSource.ENVIRONMENT
            value = ctx.lookup_default(self.name)
            if value is not None:
                return value, ParameterSource.DEFAULT_MAP
            return self.get_default(ctx), ParameterSource.DEFAULT
        return raw, source

    def handle_parse_result(self, ctx, occ, leftover):
        value, source = self.consume_value(ctx, occ, leftover)
        result = self.process_value(ctx, value, source)
        _store_param(ctx, self, result, source)
        return result

    def _auto_envvar_allowed(self, ctx) -> bool:
        return False

    def _env_value(self, ctx, raw, name):
        return Parameter._env_value(self, ctx, raw, name)

    def _is_missing(self, result) -> bool:
        return result is None or (self._variadic and result == ())


# ---------------------------------------------------------------------------
# Option parser
# ---------------------------------------------------------------------------

class _OptionParser:
    """Tokenises option-shaped and positional tokens. # spec: N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000196 N-000197 N-000198 N-000199 N-000268 N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000283 N-000284"""

    def __init__(self, ctx, options) -> None:
        self.ctx = ctx
        self.allow_interspersed_args = ctx.allow_interspersed_args
        self.ignore_unknown_options = ctx.ignore_unknown_options
        self._normalize = ctx.token_normalize_func or (lambda s: s)
        self._map = {}
        self._prefixes = {"-"}
        for opt in options:
            for name in opt.opts:
                self._add(name, opt, False)
            for name in opt.secondary_opts:
                self._add(name, opt, True)

    def _add(self, name, opt, off):
        self._prefixes.add(name[0])
        self._map.setdefault(self._normalize(name), (opt, off))

    def _shaped(self, arg: str) -> bool:
        return len(arg) > 1 and arg[0] in self._prefixes

    def _lookup(self, token: str):
        return self._map.get(self._normalize(token))

    def _suggest(self, token: str):
        return difflib.get_close_matches(token, list(self._map.keys()), n=3, cutoff=0.6)

    def _take(self, opt, args, i, first, display):
        if opt.is_optional_value:
            if opt.prompt is not None and first is None and (i >= len(args) or self._shaped(args[i])):
                return _NEEDS_PROMPT, i
            if first is not None:
                return first, i
            if i < len(args) and not self._shaped(args[i]):
                return args[i], i + 1
            return opt.flag_value, i
        n = opt.nargs
        vals = [] if first is None else [first]
        while len(vals) < n and i < len(args):
            vals.append(args[i])
            i += 1
        if len(vals) < n:
            if opt.prompt is not None and not vals:
                return _NEEDS_PROMPT, i
            if n == 1:
                raise BadOptionUsage(f"Option {display!r} requires an argument.", self.ctx)
            raise BadOptionUsage(f"Option {display!r} requires {n} arguments.", self.ctx)
        return (vals[0] if n == 1 else tuple(vals)), i

    def parse_args(self, args):
        occ: dict = {}
        order: list = []
        leftover: list = []

        def record(opt, value):
            if opt not in occ:
                occ[opt] = []
                order.append(opt)
            occ[opt].append(value)

        i = 0
        n = len(args)
        literal = False
        while i < n:
            arg = args[i]
            i += 1
            if literal:
                leftover.append((arg, False))
                continue
            if arg == "--":
                literal = True
                continue
            if not self._shaped(arg):
                leftover.append((arg, False))
                if not self.allow_interspersed_args:
                    leftover.extend((a, False) for a in args[i:])
                    break
                continue
            if _is_long(arg) or arg[1] == arg[0]:
                name, eq, val = arg.partition("=")
                hit = self._lookup(name)
                if hit is None:
                    if self.ignore_unknown_options:
                        leftover.append((arg, True))
                        continue
                    raise NoSuchOption(name, self.ctx, self._suggest(name))
                opt, off = hit
                if opt.is_flag:
                    if eq:
                        raise BadOptionUsage(f"Option {name!r} does not take a value.", self.ctx)
                    record(opt, opt._flag_occurrence(off))
                    continue
                value, i = self._take(opt, args, i, val if eq else None, name)
                record(opt, value)
                continue
            prefix = arg[0]
            chars = arg[1:]
            j = 0
            while j < len(chars):
                token = prefix + chars[j]
                hit = self._lookup(token)
                if hit is None:
                    if self.ignore_unknown_options:
                        leftover.append((prefix + chars[j:], True))
                        break
                    raise NoSuchOption(token, self.ctx, self._suggest(token))
                opt, off = hit
                if opt.is_flag:
                    record(opt, opt._flag_occurrence(off))
                    j += 1
                    continue
                rest = chars[j + 1:]
                value, i = self._take(opt, args, i, rest or None, token)
                record(opt, value)
                break
        return occ, order, leftover


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def _show_help(ctx, param, value):
    # spec: N-000929 N-000155 N-000157 N-000158
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _detect_prog_name() -> str:
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "root"


class Command:
    """A leaf command. # spec: N-000850 N-000851 N-000852 N-000853 N-000854 N-000855 N-000856 N-000857 N-000858 N-000859 N-000860 N-000861"""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- text ---------------------------------------------------------------
    def get_help_text(self) -> str:
        # spec: N-000114 N-000115 N-000116 N-000117 N-000122 N-000124
        if self.help is not None:
            return self.help.replace("\f", "")
        doc = inspect.getdoc(self.callback) if self.callback is not None else None
        if doc:
            return doc.split("\f", 1)[0]
        return ""

    def get_short_help_str(self, limit: int = 45) -> str:
        # spec: N-000122 N-000123 N-000124 N-000843
        if self.short_help:
            text = self.short_help
        else:
            para = self.get_help_text().strip().split("\n\n")[0]
            text = " ".join(para.split())
            m = re.search(r"[.!?](\s|$)", text)
            if m:
                text = text[:m.start() + 1]
        if len(text) > limit:
            text = text[:limit - 3].rstrip() + "..."
        if self.deprecated:
            text = "(Deprecated) " + text
        return text

    # -- params -------------------------------------------------------------
    def get_help_option_names(self, ctx):
        used = set()
        for p in self.params:
            if isinstance(p, Option):
                used.update(p.opts + p.secondary_opts)
        return [n for n in ctx.help_option_names if n not in used]

    def get_help_option(self, ctx):
        # spec: N-000155 N-000156 N-000157 N-000159 N-000160 N-000176 N-000177
        if not self.add_help_option:
            return None
        names = self.get_help_option_names(ctx)
        if not names:
            return None
        return Option(names, is_flag=True, expose_value=False, is_eager=True,
                      help="Show this message and exit.", callback=_show_help)

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    def get_usage(self, ctx) -> str:
        formatter = ctx.make_formatter()
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        return formatter.getvalue().rstrip("\n")

    def collect_usage_pieces(self, ctx):
        # spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000828 N-000829 N-000830 N-000831
        rv = []
        if any(isinstance(p, Option) and not p.hidden for p in self.get_params(ctx)) and self.options_metavar:
            rv.append(self.options_metavar)
        for p in self.params:
            if isinstance(p, Argument):
                rv.append(p.make_placeholder())
        return rv

    # -- parsing ------------------------------------------------------------
    def parse_args(self, ctx, args):
        """# spec: N-000283 N-000284 N-000304 N-000305 N-000306 N-000307 N-000308 N-000321 N-000322 N-000323 N-000324 N-000325"""
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, [p for p in params if isinstance(p, Option)])
        try:
            occ, order, leftover = parser.parse_args(args)
        except OptlynException:
            if not ctx.resilient_parsing:
                raise
            # Resilient parsing (shell completion) tolerates partial command lines.
            occ, order, leftover = {}, [], [(tok, False) for tok in args]
        order_index = {opt: idx for idx, opt in enumerate(order)}
        indexed = sorted(
            enumerate(params),
            key=lambda ip: (not ip[1].is_eager, order_index.get(ip[1], len(order)), ip[0]),
        )
        for _, param in indexed:
            if ctx.resilient_parsing:
                try:
                    param.handle_parse_result(ctx, occ, leftover)
                except OptlynException:
                    pass
            else:
                param.handle_parse_result(ctx, occ, leftover)
        if leftover and not ctx.resilient_parsing:
            if not ctx.allow_extra_args:
                extra = ", ".join(repr(tok) for tok, _ in leftover)
                ctx.fail(f"Got unexpected extra argument(s) ({extra})")
            if any(shaped for _, shaped in leftover) and not ctx.ignore_unknown_options:
                bad = next(tok for tok, shaped in leftover if shaped)
                raise NoSuchOption(bad, ctx, [])
        ctx.args = [tok for tok, _ in leftover]
        return ctx.args

    def make_context(self, info_name, args, parent=None, **extra) -> Context:
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        self.parse_args(ctx, list(args))
        return ctx

    def invoke(self, ctx):
        """# spec: N-000083 N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094 N-000095 N-000096"""
        if self.deprecated:
            msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if isinstance(self.deprecated, str):
                msg += " " + self.deprecated
            echo(msg, err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run the command as a program. # spec: N-000854 N-000855 N-000856 N-000857 N-000858 N-000860 N-000097 N-000098 N-000099 N-000100 N-000716 N-000719 N-000723 N-000726 N-000728 N-000730"""
        from .completion import handle_completion

        args = sys.argv[1:] if args is None else list(args)
        if prog_name is None:
            prog_name = _detect_prog_name()
        handle_completion(self, prog_name, complete_var)
        try:
            with self.make_context(prog_name, args, **extra) as ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
        except (EOFError, KeyboardInterrupt) as e:
            echo(file=sys.stderr)
            if not standalone_mode:
                raise Abort() from e
            echo("Aborted!", err=True)
            sys.exit(1)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynException as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except OSError as e:
            if e.errno == errno.EPIPE:
                sys.exit(1)
            raise
        return None

    # -- help ---------------------------------------------------------------
    def get_help(self, ctx) -> str:
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def format_help(self, ctx, formatter):
        # spec: N-000827 N-000828 N-000829 N-000831 N-000832 N-000834 N-000835 N-000836 N-000837 N-000846 N-000847
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        self.format_description(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_description(self, ctx, formatter):
        text = self.get_help_text()
        if self.deprecated:
            text = ("(Deprecated) " + text).strip()
        if text.strip():
            formatter.write_paragraph()
            formatter.indent = 2
            formatter.write_text(text)
            formatter.indent = 0

    def format_arguments(self, ctx, formatter):
        rows = [p.get_help_record(ctx) for p in self.params
                if isinstance(p, Argument) and not p.hidden and p.help]
        if rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        # spec: N-000837 N-000838 N-000839 N-000840 N-000841 N-000842
        rows = [p.get_help_record(ctx) for p in self.get_params(ctx)
                if isinstance(p, Option) and not p.hidden]
        if rows:
            with formatter.section("Options"):
                formatter.write_dl(rows)

    def format_commands(self, ctx, formatter):
        return None

    def format_epilog(self, ctx, formatter):
        # spec: N-000844 N-000126 N-000125
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)


class Group(Command):
    """A command that dispatches to named subcommands. # spec: N-000862 N-000863 N-000864 N-000865 N-000866 N-000867 N-000868 N-000869 N-000870 N-000871 N-000872 N-000873 N-000874 N-000875 N-000876 N-000877 N-000388 N-000389 N-000390 N-000391 N-000392 N-000393"""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands: dict = {}
        if commands:
            items = commands.items() if isinstance(commands, dict) else [(c.name, c) for c in commands]
            for cmd_name, cmd in items:
                self.add_command(cmd, cmd_name)

    # -- registration -------------------------------------------------------
    def add_command(self, cmd, name=None):
        """# spec: N-000869 N-000870 N-000871 N-000612 N-000613 N-000614"""
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("A group cannot be attached beneath a chaining group.")
        key = name or cmd.name
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        """# spec: N-000872"""
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def group(self, *args, **kwargs):
        """# spec: N-000873"""
        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def result_callback(self):
        """# spec: N-000874 N-000875 N-000597 N-000598 N-000599 N-000600 N-000601 N-000602"""
        def decorator(f):
            self._result_callback = f
            return f
        return decorator

    # -- lookup -------------------------------------------------------------
    def list_commands(self, ctx) -> list:
        """# spec: N-000876 N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000421"""
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        """# spec: N-000877 N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000421"""
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, args):
        """# spec: N-000429 N-000430 N-000431 N-000432 N-000398 N-000399 N-000400"""
        cmd_name = args[0]
        if ctx.token_normalize_func is not None:
            cmd_name = ctx.token_normalize_func(args[0])
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None:
            ctx.fail(f"No such command {cmd_name!r}.")
        return cmd_name, cmd, args[1:]

    # -- parsing and invocation --------------------------------------------
    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = list(rest)
            ctx.args = []
        elif rest:
            ctx.protected_args = rest[:1]
            ctx.args = rest[1:]
        else:
            ctx.protected_args = []
            ctx.args = []
        return ctx.args

    def _process_result(self, ctx, value):
        # spec: N-000597 N-000598 N-000599 N-000600 N-000601 N-000602
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def invoke(self, ctx):
        """# spec: N-000391 N-000392 N-000393 N-000394 N-000395 N-000403 N-000404 N-000405 N-000411 N-000412 N-000597 N-000603 N-000604 N-000605 N-000606 N-000607 N-000608 N-000609 N-000610 N-000615 N-000616 N-000617"""
        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = Command.invoke(self, ctx)
                    return self._process_result(ctx, [] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            cmd_name, cmd, args = self.resolve_command(ctx, args)
            ctx.invoked_subcommand = cmd_name
            Command.invoke(self, ctx)
            sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
            with sub_ctx:
                return self._process_result(ctx, sub_ctx.command.invoke(sub_ctx))

        with ctx:
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx, allow_extra_args=True,
                                           allow_interspersed_args=False)
                contexts.append(sub_ctx)
                args = sub_ctx.args
            ctx.invoked_subcommand = "*" if contexts else None
            Command.invoke(self, ctx)
            results = []
            for sub_ctx in contexts:
                with sub_ctx:
                    results.append(sub_ctx.command.invoke(sub_ctx))
            return self._process_result(ctx, results)

    # -- help ---------------------------------------------------------------
    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        meta = self.subcommand_metavar
        if self.chain:
            unit = (meta or "COMMAND") + " [ARGS]..."
            rv.append(f"{unit} [{unit}]...")
        else:
            rv.append(meta or ("[COMMAND]" if self.invoke_without_command else "COMMAND"))
            rv.append("[ARGS]...")
        return rv

    def format_commands(self, ctx, formatter):
        # spec: N-000842 N-000843 N-000426 N-000427
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str()))
        if rows:
            with formatter.section("Commands"):
                formatter.write_dl(rows)


class CommandCollection(Group):
    """Presents the union of subcommands from several source groups.

    # spec: N-000878 N-000879 N-000880 N-000422 N-000423 N-000424 N-000425
    """

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> list:
        names = set(self.commands)
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------

def _param_memo(f, param) -> None:
    # spec: N-000178 N-000179 N-000180 N-000181
    if isinstance(f, Command):
        f.params.append(param)
        return
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _consume_params(f) -> list:
    params = list(getattr(f, "__optlyn_params__", []))
    params.reverse()
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _default_command_name(f) -> str:
    # spec: N-000079 N-000080 N-000081 N-000082
    name = f.__name__.lower().replace("_", "-")
    left, sep, suffix = name.rpartition("-")
    if sep and suffix in {"command", "cmd", "group", "grp"}:
        name = left
    return name


def command(name=None, cls=None, **attrs):
    """Declare a command from a function. # spec: N-000850 N-000851 N-000852 N-000853 N-000079"""
    if callable(name):
        return command(None, cls, **attrs)(name)
    cls = cls or Command

    def decorator(f):
        cmd_name = name if name is not None else _default_command_name(f)
        params = _consume_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Declare a group from a function. # spec: N-000862 N-000863 N-000864"""
    if callable(name):
        return group(None, cls, **attrs)(name)
    cls = cls or Group

    def decorator(f):
        grp_name = name if name is not None else _default_command_name(f)
        params = _consume_params(f)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function or command. # spec: N-000881 N-000882 N-000883 N-000884"""
    cls = cls or Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an argument to a function or command. # spec: N-000910 N-000911 N-000912"""
    cls = cls or Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def pass_context(f):
    """# spec: N-000975"""
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """# spec: N-000976"""
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure: bool = False):
    """# spec: N-000977 N-000442"""
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type "
                                   f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. # spec: N-000924 N-000929"""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def _detect_version(name: str) -> str:
    # spec: N-000930 N-000931 N-000162 N-000164
    import importlib.metadata as md

    try:
        return md.version(name)
    except md.PackageNotFoundError:
        pass
    try:
        dists = md.packages_distributions().get(name, [])
    except Exception:
        dists = []
    if dists:
        return md.version(dists[0])
    raise RuntimeError(f"Could not determine the version for {name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag. # spec: N-000925 N-000930 N-000931 N-000162 N-000163 N-000164 N-000165 N-000166 N-000169"""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        root = ctx.find_root()
        prog = prog_name or root.info_name
        ver = version
        if ver is None:
            ver = _detect_version(package_name or root.info_name or "")
        msg = message or "%(prog)s, version %(version)s"
        echo(msg % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs["callback"] = callback

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager version flag whose text is returned by ``callback(ctx)``. # spec: N-000926 N-000932 N-000167 N-000168"""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def _callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs["callback"] = _callback

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option. # spec: N-000927 N-000510 N-000511 N-000512"""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def _confirmation_callback(ctx, param, value):
    if not value:
        ctx.abort()


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that prompts when omitted and aborts on refusal. # spec: N-000928 N-000513 N-000514 N-000515 N-000516 N-000517 N-000518 N-000519"""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("callback", _confirmation_callback)

    def decorator(f):
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator
