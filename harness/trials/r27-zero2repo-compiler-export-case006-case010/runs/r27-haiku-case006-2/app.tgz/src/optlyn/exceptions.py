"""Exceptions used by Optlyn.

# spec: N-000807 N-000808 N-000809 N-000810 N-000811 N-000933 N-000934 N-000935
# spec: N-000716 N-000719 N-000723 N-000726 N-000735
"""

from __future__ import annotations


class OptlynException(Exception):
    """Base class for errors that are reported to the user with an exit status."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self) -> None:
        from .termui import echo

        echo(f"Error: {self.format_message()}", err=True)


class UsageError(OptlynException):
    """Incorrect usage: exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            names = self.ctx.help_option_names
            if names:
                echo(f"Try '{self.ctx.command_path} {names[0]}' for help.", err=True)
        echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A parameter value was refused. Usage error.

    # spec: N-000933 N-000934 N-000935
    """

    def __init__(self, message, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint is None:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied. Usage error."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self) -> str:
        if self.message:
            return self.message
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        kind = "argument" if self.param is not None and self.param.is_argument else "option"
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An unknown option was given. Usage error."""

    def __init__(self, option_name: str, ctx=None, possibilities=None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name
        self.possibilities = possibilities or []

    def format_message(self) -> str:
        msg = self.message
        if self.possibilities:
            if len(self.possibilities) == 1:
                msg += f" Did you mean {self.possibilities[0]}?"
            else:
                msg += " Did you mean one of " + ", ".join(self.possibilities) + "?"
        return msg


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoArgsIsHelpError(UsageError):
    """No arguments were given where the command shows help instead. Usage error."""

    def __init__(self, ctx) -> None:
        super().__init__("No arguments given.", ctx)

    def show(self) -> None:
        from .termui import echo

        echo(self.ctx.get_help(), err=True)


class FileError(OptlynException):
    """A file could not be opened at first I/O. General error (not usage)."""

    exit_code = 1

    def __init__(self, filename, message: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


class Abort(RuntimeError):
    """The user (or the author) aborted the program. Exit status 1.

    # spec: N-000723 N-000724 N-000725
    """


class Exit(RuntimeError):
    """An author clean stop with a status code. Carries ``exit_code``."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
