"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch.

# spec: N-000981 N-000982 N-000983 N-000984 N-000985 N-000986 N-000987 N-000988
# spec: N-000989 N-000990 N-000991 N-000992 N-000993 N-000994 N-000995 N-000996
# spec: N-000997 N-000998 N-000999 N-001000 N-001001 N-001002 N-001010 N-001011
# spec: N-001012 N-000618 N-000619 N-000620 N-000621 N-000622 N-000623 N-000624
# spec: N-000625 N-000626 N-000627 N-000628 N-000629 N-000630 N-000631 N-000632
# spec: N-000633 N-000634 N-000635 N-000636 N-000637 N-000638 N-000639 N-000640
# spec: N-000641 N-000642 N-000643 N-000644 N-000645 N-000646 N-000647 N-000648
# spec: N-000649 N-000650 N-000651 N-000652 N-000653 N-000654 N-000655 N-000656
# spec: N-000657 N-000658 N-000659 N-000660 N-000661 N-000662 N-000663 N-000664
# spec: N-000665 N-000666 N-000667 N-000668 N-000669 N-000670 N-000671 N-000672
# spec: N-000673 N-000681 N-000682 N-000683 N-000684 N-000685 N-000686 N-000687
# spec: N-000688 N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507
# spec: N-000508 N-000509 N-000510 N-000511 N-000512 N-000524 N-000525 N-000526
"""

from __future__ import annotations

import codecs
import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from ._state import get_current_context
from .exceptions import Abort, OptlynException

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLOR_CODES = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_SWITCH_CODES = [
    ("bold", 1), ("dim", 2), ("italic", 3), ("underline", 4), ("blink", 5),
    ("reverse", 7), ("strikethrough", 9), ("overline", 53),
]


def _isatty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def is_interactive() -> bool:
    """Return True when stdin or stdout is a terminal.

    # spec: N-001012
    """
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _current_color():
    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _write_text(stream, text: str) -> None:
    encoding = (getattr(stream, "encoding", None) or "").lower()
    try:
        is_ascii = encoding and codecs.lookup(encoding).name == "ascii"
    except LookupError:
        is_ascii = False
    if is_ascii:
        _write_bytes(stream, text.encode("utf-8"))
        return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        _write_bytes(stream, text.encode("utf-8"))


def _write_bytes(stream, data: bytes) -> None:
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        stream.flush()
        buf.write(data)
        buf.flush()
    else:
        stream.write(data.decode("utf-8", "replace"))


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences. # spec: N-000640 N-000628"""
    return _ANSI_RE.sub("", text)


def _color_code(color, bg: bool) -> str:
    if isinstance(color, str):
        name = color
        if name == "reset":
            return "49" if bg else "39"
        if name in _COLOR_CODES:
            return str(_COLOR_CODES[name] + (10 if bg else 0))
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{48 if bg else 38};5;{color}"
        raise ValueError(f"Color number {color} is out of range 0-255.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        r, g, b = color
        return f"{48 if bg else 38};2;{r};{g};{b}"
    raise TypeError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True) -> str:
    """Wrap ``text`` in ANSI SGR sequences. # spec: N-000628 N-000629 N-000630 N-000631 N-000632 N-000633 N-000634 N-000635 N-000636 N-000637 N-000638 N-000639 N-000640"""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    flags = {"bold": bold, "dim": dim, "underline": underline, "overline": overline,
             "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough}
    for name, code in _SWITCH_CODES:
        if flags.get(name):
            bits.append(str(code))
    text = str(text)
    if not bits:
        return text
    prefix = f"\x1b[{';'.join(bits)}m"
    return prefix + text + ("\x1b[0m" if reset else "")


def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None):
    """Write text or bytes to stdout (or stderr). Styles are kept only on a terminal
    or when ``color`` forces them.

    # spec: N-000618 N-000619 N-000621 N-000623 N-000624 N-000681 N-000682 N-000683
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        color = _current_color()
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        _write_bytes(file, data)
        file.flush()
        return
    if message is None:
        message = ""
    message = str(message)
    keep = color if color is not None else _isatty(file)
    if not keep:
        message = unstyle(message)
    if nl:
        message += "\n"
    _write_text(file, message)
    file.flush()


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles):
    """echo() with styling applied. # spec: N-000628"""
    if message is not None and not isinstance(message, bytes):
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _strip_for(color, stream):
    keep = color if color is not None else _isatty(stream)
    return (lambda s: s) if keep else unstyle


class _PagerStream:
    """A writable text stream that feeds a destination chunk by chunk."""

    def __init__(self, stream, color, close_stream: bool) -> None:
        self._stream = stream
        self._filter = _strip_for(color, stream)
        self._close_stream = close_stream

    def write(self, text):
        text = self._filter(str(text))
        _write_text(self._stream, text)
        self._stream.flush()
        return len(text)

    def flush(self):
        self._stream.flush()

    def close(self):
        if self._close_stream:
            self._stream.close()


def _pager_command():
    return os.environ.get("PAGER") or "less"


@contextlib.contextmanager
def get_pager_file(color=None):
    """Context manager yielding a writable text stream fed through the pager.

    # spec: N-000641 N-000642 N-000643 N-000644 N-001010 N-001011
    """
    if is_interactive():
        try:
            proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
        except OSError:
            proc = None
        if proc is not None and proc.stdin is not None:
            stream = _PagerStream(_ProcStdin(proc.stdin), color, close_stream=True)
            try:
                yield stream
            finally:
                stream.close()
                proc.wait()
            return
    yield _PagerStream(sys.stdout, color, close_stream=False)


class _ProcStdin:
    """Text adapter over a pager's binary stdin."""

    def __init__(self, binary) -> None:
        self._binary = binary
        self.encoding = "utf-8"

    def write(self, text):
        self._binary.write(text.encode("utf-8"))

    def flush(self):
        self._binary.flush()

    def close(self):
        self._binary.close()

    def isatty(self):
        return False


def echo_via_pager(text_or_generator, color=None):
    """Write text through a pager when interactive. # spec: N-000641 N-000642 N-000643 N-000645 N-000646 N-000647 N-000648"""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as out:
        for chunk in chunks:
            out.write(chunk)
            out.flush()


class ProgressBar:
    """Wraps an iterable or a length and shows progress on a terminal.

    # spec: N-000649 N-000650 N-000651 N-000652 N-000653 N-000654 N-000655 N-000656
    # spec: N-000657 N-000684 N-000685
    """

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.options = options
        self.pos = 0
        self.start = time.time()
        self.is_tty = _isatty(sys.stdout) and not hidden
        self._finished = False

    def __enter__(self):
        self.start = time.time()
        if self.label and not self.hidden and not self.is_tty:
            echo(self.label)
        return self

    def __exit__(self, *exc):
        self.finish()
        return False

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("Iterating a progress bar needs an iterable.")
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self.render_progress()

    def _eta(self) -> str:
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self.start
        remaining = max(self.length - self.pos, 0) * (elapsed / self.pos)
        return f"  {int(remaining)}s"

    def render_progress(self) -> None:
        if self.hidden or not self.is_tty:
            return
        label = f"{self.label}  " if self.label else ""
        if self.length:
            width = 30
            filled = min(int(width * self.pos / self.length), width)
            bar = "#" * filled + "-" * (width - filled)
            text = f"\r{label}[{bar}] {self.pos}/{self.length}{self._eta()}"
        else:
            text = f"\r{label}{self.pos}"
        _write_text(sys.stdout, text)
        sys.stdout.flush()

    def finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        if self.is_tty:
            self.render_progress()
            _write_text(sys.stdout, "\n")
            sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options) -> ProgressBar:
    """Return a progress bar (a context manager and iterable). # spec: N-000649"""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def _is_runner_stream(stream) -> bool:
    return bool(getattr(stream, "_optlyn_runner", False))


def _read_line(prompt_text: str, hide_input: bool = False, err: bool = False, echo_input: bool = True) -> str:
    echo(prompt_text, nl=False, err=err)
    stdin = sys.stdin
    if hide_input and _isatty(stdin):
        import getpass

        try:
            value = getpass.getpass("")
        except EOFError:
            raise EOFError()
        echo(None, err=err)
        return value
    line = stdin.readline()
    if line == "":
        echo(None, err=err)
        raise EOFError("No input available.")
    value = line.rstrip("\r\n")
    if hide_input:
        echo(None, err=err)
    elif echo_input and not _isatty(stdin) and not getattr(stdin, "_optlyn_echo_reads", False):
        echo(value, err=err)
    return value


def prompt(text, default=None, hide_input: bool = False, confirmation_prompt: bool = False,
           type=None, value_proc=None, prompt_suffix: str = ": ", show_default: bool = True,
           err: bool = False, show_choices: bool = True):
    """Ask for a value and return it converted. Re-asks on conversion failure.

    # spec: N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509
    # spec: N-000510 N-000511 N-000512 N-000520 N-000521 N-000522
    """
    from .paramtypes import convert_type

    ptype = convert_type(type, default)
    if value_proc is None:
        def value_proc(v):
            return ptype.convert(v, None, None)

    shown = default() if callable(default) else default
    default_text = None
    if show_default and shown is not None:
        default_text = str(shown)

    while True:
        label = text
        if default_text is not None:
            label = f"{text} [{default_text}]"
        label += prompt_suffix
        value = _read_line(label, hide_input=hide_input, err=err)
        if not value:
            if shown is None:
                continue
            value = shown
        elif confirmation_prompt:
            again = _read_line("Repeat for confirmation" + prompt_suffix, hide_input=hide_input, err=err)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return value_proc(value)
        except OptlynException as e:
            echo(f"Error: {e.message}", err=True)
            continue


def confirm(text, default: bool = False, abort: bool = False, prompt_suffix: str = ": ",
            show_default: bool = True, err: bool = False) -> bool:
    """Ask a yes/no question. # spec: N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509"""
    hint = ("Y/n" if default else "y/N") if show_default else ""
    label = f"{text} [{hint}]" if hint else text
    label += prompt_suffix
    while True:
        answer = _read_line(label, err=err).strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "":
            result = default
            break
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal. # spec: N-000658 N-000659 N-000660 N-000661"""
    stream = sys.stdin
    if _is_runner_stream(stream):
        ch = stream.read(1)
        if ch == "":
            raise EOFError()
        if echo:
            _write_text(sys.stdout, ch)
        return ch
    try:
        import termios
        import tty
    except ImportError:
        try:
            import msvcrt  # type: ignore

            ch = msvcrt.getwch()
        except ImportError as e:
            raise EOFError("No terminal available.") from e
        if ch == "\x03":
            raise KeyboardInterrupt()
        if ch == "\x1a":
            raise EOFError()
        return ch

    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError as e:
        raise EOFError("No controlling terminal available.") from e
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        os.close(fd)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        _write_text(sys.stdout, ch)
    return ch


def pause(info=None, err: bool = False) -> None:
    """Print a message and wait for a key when interactive; never block otherwise.

    # spec: N-000662 N-000663 N-000686 N-000687
    """
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    if is_interactive():
        try:
            getchar()
        except EOFError:
            pass
    echo(None, err=err)


def edit(text=None, editor=None, env=None, require_save: bool = True, extension: str = ".txt",
         filename=None):
    """Open an editor. Returns the saved text, or None.

    # spec: N-000664 N-000665 N-000666
    """
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not editor:
            editor = "notepad" if sys.platform == "win32" else "vi"
    env_full = dict(os.environ)
    if env:
        env_full.update(env)
    original = text or ""
    if filename is None:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(original)
        try:
            cmd = shlex.split(editor, posix=os.name != "nt") + [path]
            subprocess.call(cmd, env=env_full)
            with open(path, encoding="utf-8", newline="") as f:
                result = f.read()
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
        if require_save and result == original:
            return None
        return result
    cmd = shlex.split(editor, posix=os.name != "nt") + [os.fspath(filename)]
    subprocess.call(cmd, env=env_full)
    return None


def launch(url, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or path with the default application. # spec: N-000667 N-000668 N-000669 N-000670 N-000671"""
    url = os.fspath(url) if hasattr(url, "__fspath__") else str(url)
    if sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    if sys.platform == "darwin":
        args = ["open"]
        if locate:
            args.append("-R")
    else:
        args = ["xdg-open"]
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the terminal; does nothing when stdout is not a terminal. # spec: N-000672 N-000673"""
    if not _isatty(sys.stdout):
        return
    _write_text(sys.stdout, "\x1b[2J\x1b[3J\x1b[H")
    sys.stdout.flush()


def _binary(stream):
    buf = getattr(stream, "buffer", None)
    return buf if buf is not None else stream


def get_binary_stdin():
    """Binary standard input. # spec: N-000618 N-000620"""
    return _binary(sys.stdin)


def get_binary_stdout():
    """Binary standard output. # spec: N-000618 N-000620"""
    return _binary(sys.stdout)


def get_binary_stderr():
    """Binary standard error. # spec: N-000618 N-000620"""
    return _binary(sys.stderr)


def get_text_stdin(encoding=None, errors=None):
    """Text standard input. # spec: N-000618 N-000620"""
    return sys.stdin


def get_text_stdout(encoding=None, errors=None):
    """Text standard output. # spec: N-000618 N-000620"""
    return sys.stdout


def get_text_stderr(encoding=None, errors=None):
    """Text standard error. # spec: N-000618 N-000620"""
    return sys.stderr
