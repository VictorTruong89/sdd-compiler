"""Groups, nesting, chaining, context objects, invocation and result callbacks."""

import pytest

import optlyn
from optlyn import (
    Command, CommandCollection, Context, argument, command, group, option, pass_context,
    pass_obj, make_pass_decorator, testing,
)


def run(cli, args, **kw):
    return testing.CliRunner().invoke(cli, args, **kw)


@group()
@option("--verbose", is_flag=True)
def cli(verbose):
    """Top group."""
    optlyn.echo(f"group verbose={verbose}")


@cli.command()
@argument("name")
def hello(name):
    """Say hi to someone."""
    optlyn.echo(f"hi {name}")


@cli.group("sub")
def sub():
    """A nested group."""
    optlyn.echo("sub ran")


@sub.command("leaf")
@option("--n", type=int, default=1)
def leaf(n):
    optlyn.echo(f"leaf {n}")


def test_group_runs_callback_before_child():
    # spec: N-000391 N-000392 N-000393 N-000394
    r = run(cli, ["--verbose", "hello", "bob"])
    assert r.exit_code == 0
    assert r.output == "group verbose=True\nhi bob\n"


def test_group_options_must_precede_subcommand_child_options_follow():
    # spec: N-000394 N-000396 N-000397
    r = run(cli, ["hello", "--verbose", "bob"])
    assert r.exit_code == 2  # --verbose belongs to nothing after hello


def test_nested_groups_outside_in():
    # spec: N-000398 N-000399 N-000400
    r = run(cli, ["sub", "leaf", "--n", "5"])
    assert r.exit_code == 0
    assert r.output == "group verbose=False\nsub ran\nleaf 5\n"


def test_skipping_middle_group_is_unknown_command():
    # spec: N-000400 N-000429
    r = run(cli, ["leaf"])
    assert r.exit_code == 2
    assert "No such command" in r.output


def test_no_args_shows_help_as_usage_failure():
    # spec: N-000170 N-000172 N-000388 N-000406
    r = run(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.output


def test_help_before_subcommand_is_group_help_and_skips_child():
    # spec: N-000396 N-000397 N-000391
    r = run(cli, ["--help", "hello", "x"])
    assert r.exit_code == 0
    assert "Commands:" in r.output
    assert "hi bob" not in r.output and "hi x" not in r.output


def test_help_after_subcommand_is_child_help():
    r = run(cli, ["hello", "--help"])
    assert r.exit_code == 0
    assert "Say hi to someone." in r.output


def test_group_help_lists_children_with_short_help():
    # spec: N-000122 N-000842 N-000843
    r = run(cli, ["--help"])
    assert "hello" in r.output
    assert "Say hi to someone." in r.output
    assert "sub" in r.output


def test_missing_command_message_without_help_page():
    # spec: N-000429 N-000431
    @group(invoke_without_command=False, no_args_is_help=False)
    def g():
        pass

    r = run(g, ["--x"])
    # An option that is not declared is an error before the missing-command check.
    assert r.exit_code == 2
    r = run(g, [])
    # no_args_is_help False, no command -> Missing command error
    assert r.exit_code == 2
    assert "Missing command" in r.output


def test_invoke_without_command_runs_callback_and_invoked_subcommand_none():
    # spec: N-000403 N-000405
    seen = []

    @group(invoke_without_command=True)
    @pass_context
    def g(ctx):
        seen.append(ctx.invoked_subcommand)

    @g.command()
    def child():
        seen.append("child")

    assert run(g, []).exit_code == 0
    assert seen == [None]
    seen.clear()
    assert run(g, ["child"]).exit_code == 0
    assert seen == ["child", "child"]


def test_result_callback_gets_return_value():
    # spec: N-000874 N-000875 N-000597 N-000598
    @group()
    def g():
        pass

    @g.result_callback()
    def done(value, **params):
        optlyn.echo(f"result={value}")

    @g.command()
    def compute():
        return 7

    r = run(g, ["compute"])
    assert r.output == "result=7\n"


def test_chaining_group_runs_each_subcommand_in_order():
    # spec: N-000593 N-000597 N-000603 N-000604
    @group(chain=True)
    def pipeline():
        pass

    @pipeline.result_callback()
    def results(values):
        optlyn.echo(f"values={values}")

    @pipeline.command()
    @argument("x")
    def add(x):
        optlyn.echo(f"add {x}")
        return f"A{x}"

    @pipeline.command()
    @argument("x")
    def mul(x):
        optlyn.echo(f"mul {x}")
        return f"M{x}"

    r = run(pipeline, ["add", "1", "mul", "2"])
    assert r.exit_code == 0
    assert r.output == "add 1\nmul 2\nvalues=['A1', 'M2']\n"


def test_chain_cannot_attach_group():
    # spec: N-000612 N-000613 N-000614
    @group(chain=True)
    def pipeline():
        pass

    with pytest.raises(RuntimeError):
        @pipeline.group()
        def nested():
            pass


def test_standalone_off_chain_returns_list():
    # spec: N-000603 N-000604
    @group(chain=True)
    def pipeline():
        pass

    @pipeline.command()
    def one():
        return 1

    @pipeline.command()
    def two():
        return 2

    assert pipeline.main(["one", "two"], standalone_mode=False) == [1, 2]


def test_command_collection_union_and_dispatch():
    # spec: N-000422 N-000423 N-000424 N-000425
    a = Command("alpha", callback=lambda: optlyn.echo("A"))
    b = Command("beta", callback=lambda: optlyn.echo("B"))
    ga = optlyn.Group("ga", commands={"alpha": a})
    gb = optlyn.Group("gb", commands={"beta": b})
    coll = CommandCollection("coll", sources=[ga, gb])
    assert coll.list_commands(None) == ["alpha", "beta"]
    assert run(coll, ["beta"]).output == "B\n"
    assert run(coll, ["alpha"]).output == "A\n"


def test_hidden_command_is_not_listed_but_invocable():
    # spec: N-000426 N-000427 N-000153 N-000154
    @group()
    def g():
        pass

    @g.command(hidden=True)
    def secret():
        optlyn.echo("secret!")

    assert "secret" not in run(g, ["--help"]).output
    assert run(g, ["secret"]).output == "secret!\n"


def test_add_command_with_explicit_name_and_lazy_get_command():
    # spec: N-000401 N-000402 N-000413 N-000416 N-000417 N-000418 N-000419
    class Lazy(optlyn.Group):
        def get_command(self, ctx, name):
            if name == "lazy":
                return Command("lazy", callback=lambda: optlyn.echo("loaded"))
            return None

        def list_commands(self, ctx):
            return ["lazy"]

    g = Lazy("g")
    g.add_command(Command("other", callback=lambda: optlyn.echo("o")), name="renamed")
    assert run(g, ["lazy"]).output == "loaded\n"
    assert run(g, ["renamed"]).exit_code == 2  # renamed is not on the Lazy listing


def test_context_object_passing_and_ensure():
    # spec: N-000434 N-000435 N-000436 N-000439 N-000442
    class Config:
        def __init__(self):
            self.name = "default"

    @group()
    def g():
        pass

    @g.command()
    @make_pass_decorator(Config, ensure=True)
    def show(config):
        optlyn.echo(config.name)

    seen = {}

    @group()
    @pass_obj
    def root(obj):
        seen["obj"] = obj

    @root.command()
    @make_pass_decorator(Config)
    def find(cfg):
        optlyn.echo(f"found {cfg.name}")

    r = run(root, ["find"], obj=Config())
    assert isinstance(seen["obj"], Config)
    assert r.exit_code == 0
    assert r.output == "found default\n"

    r = run(g, ["show"])
    assert r.exit_code == 0
    assert r.output == "default\n"


def test_ensure_creates_object_when_missing():
    class Thing:
        pass

    @command()
    @make_pass_decorator(Thing, ensure=True)
    def cli(thing):
        optlyn.echo(type(thing).__name__)

    assert run(cli, []).output == "Thing\n"


def test_invoke_another_command_with_values():
    # spec: N-000471 N-000472 N-000473
    @command()
    @option("--n", default=1, type=int)
    def inner(n):
        optlyn.echo(f"inner {n}")

    @command()
    def outer():
        ctx = optlyn.get_current_context()
        ctx.invoke(inner, n=9)

    assert run(outer, []).output == "inner 9\n"


def test_forward_passes_current_params():
    @command()
    @option("--n", default=2, type=int)
    def inner(n):
        optlyn.echo(f"inner {n}")

    @command()
    @option("--n", default=4, type=int)
    def outer(n):
        optlyn.get_current_context().forward(inner)

    assert run(outer, ["--n", "6"]).output == "inner 6\n"


def test_with_resource_closed_when_invocation_ends():
    # spec: N-000467 N-000482
    closed = []

    class Res:
        def __enter__(self):
            return "value"

        def __exit__(self, *exc):
            closed.append(True)

    @command()
    def cli():
        ctx = optlyn.get_current_context()
        optlyn.echo(ctx.with_resource(Res()))

    r = run(cli, [])
    assert r.output == "value\n"
    assert closed == [True]


def test_get_current_context_silent_and_raising():
    # spec: N-000978 N-000979 N-000980
    assert optlyn.get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        optlyn.get_current_context()


def test_context_default_map_nests_under_subcommand_name():
    # spec: N-000450 N-000459 N-000460
    seen = {}

    @group()
    def g():
        pass

    @g.command()
    @option("--name")
    def child(name):
        seen["name"] = name

    run(g, ["child"], default_map={"child": {"name": "nested"}})
    assert seen["name"] == "nested"
    run(g, ["child"], default_map={"name": "top-level-ignored"})
    assert seen["name"] is None


def test_token_normalize_func_applies_to_option_and_command():
    # spec: N-000468 N-000469 N-000470
    @command(context_settings={"token_normalize_func": lambda s: s.lower()})
    @option("--flag", is_flag=True)
    def cli(flag):
        optlyn.echo(flag)

    assert run(cli, ["--FLAG"]).output == "True\n"
    assert run(cli, ["--other"]).exit_code == 2
