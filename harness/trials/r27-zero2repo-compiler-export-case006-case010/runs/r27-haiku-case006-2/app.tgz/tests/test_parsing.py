"""Options, arguments, flags, env vars, defaults and usage errors."""

import optlyn
from optlyn import Choice, Context, IntRange, Path, command, option, argument, testing
from optlyn.core import ParameterSource


def run(cli, args, **kw):
    return testing.CliRunner().invoke(cli, args, **kw)


def test_short_flag_stacking_and_counting():
    # spec: N-000188 N-000191 N-000207 N-000208
    @command()
    @option("-v", count=True)
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    def cli(v, a, b):
        optlyn.echo(f"{v} {a} {b}")

    r = run(cli, ["-vvv", "-ab"])
    assert r.exit_code == 0
    assert r.output == "3 True True\n"
    r = run(cli, [])
    assert r.output == "0 False False\n"


def test_value_attached_to_stack_and_equals_form():
    # spec: N-000188 N-000189
    @command()
    @option("-n", type=int)
    @option("--name")
    def cli(n, name):
        optlyn.echo(f"{n}|{name}")

    assert run(cli, ["-n5", "--name=bob"]).output == "5|bob\n"
    assert run(cli, ["-n", "7", "--name", "x y"]).output == "7|x y\n"


def test_double_dash_ends_options():
    # spec: N-000304 N-000305 N-000306
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def cli(flag, rest):
        optlyn.echo(f"{flag}|{list(rest)}")

    r = run(cli, ["--", "--flag", "x"])
    assert r.exit_code == 0
    assert r.output == "False|['--flag', 'x']\n"


def test_unknown_option_is_usage_error_and_does_not_run():
    # spec: N-000101 N-000268 N-000735
    ran = []

    @command()
    @option("--known")
    def cli(known):
        ran.append(True)

    r = run(cli, ["--nope"])
    assert r.exit_code == 2
    assert ran == []
    assert "No such option" in r.output


def test_missing_required_option_names_option():
    # spec: N-000200 N-000201 N-000735
    @command()
    @option("--token", required=True)
    def cli(token):
        pass

    r = run(cli, [])
    assert r.exit_code == 2
    assert "Missing option '--token'" in r.output


def test_missing_value_is_usage_error():
    # spec: N-000275
    @command()
    @option("--name")
    def cli(name):
        pass

    r = run(cli, ["--name"])
    assert r.exit_code == 2


def test_multi_value_option_nargs_and_repeat():
    # spec: N-000209 N-000210 N-000219 N-000220
    @command()
    @option("--pair", nargs=2, type=int)
    @option("--tag", multiple=True)
    def cli(pair, tag):
        optlyn.echo(f"{pair}|{tag}")

    r = run(cli, ["--pair", "1", "2", "--tag", "a", "--tag", "b"])
    assert r.output == "(1, 2)|('a', 'b')\n"
    r = run(cli, ["--pair", "1"])
    assert r.exit_code == 2


def test_repeatable_omitted_is_empty_tuple():
    # spec: N-000211 N-000917
    seen = {}

    @command()
    @option("--tag", multiple=True)
    def cli(tag):
        seen["tag"] = tag

    run(cli, [])
    assert seen["tag"] == ()


def test_omitted_value_is_none_and_flag_default_false():
    # spec: N-000914 N-000915 N-000202
    seen = {}

    @command()
    @option("--name")
    @option("--force", is_flag=True)
    def cli(name, force):
        seen.update(name=name, force=force)

    run(cli, [])
    assert seen == {"name": None, "force": False}


def test_flag_on_off_pair():
    # spec: N-000205 N-000206
    seen = {}

    @command()
    @option("--shout/--no-shout", default=False)
    def cli(shout):
        seen["shout"] = shout

    run(cli, ["--shout"])
    assert seen["shout"] is True
    run(cli, ["--no-shout"])
    assert seen["shout"] is False


def test_optional_value_option():
    # spec: N-000221 N-000222 N-000223 N-000224 N-000225
    seen = []

    @command()
    @option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def cli(opt):
        seen.append(opt)

    run(cli, [])
    run(cli, ["--opt"])
    run(cli, ["--opt", "val"])
    assert seen == ["DEF", "FLAG", "val"]


def test_default_callable_only_when_no_value():
    # spec: N-000184 N-000185 N-000186
    calls = []

    def make():
        calls.append(1)
        return "made"

    @command()
    @option("--x", default=make)
    def cli(x):
        optlyn.echo(x)

    assert run(cli, ["--x", "given"]).output == "given\n"
    assert calls == []
    assert run(cli, []).output == "made\n"
    assert calls == [1]


def test_type_inferred_from_default():
    # spec: N-000182 N-000183
    @command()
    @option("--n", default=3)
    def cli(n):
        optlyn.echo(repr(n + 1))

    assert run(cli, ["--n", "9"]).output == "10\n"


def test_choice_delivers_original_object_case_insensitive():
    # spec: N-000348 N-000349 N-000382
    @command()
    @option("--c", type=Choice(["Red", "Blue"], case_sensitive=False))
    def cli(c):
        optlyn.echo(c)

    assert run(cli, ["--c", "red"]).output == "Red\n"
    r = run(cli, ["--c", "green"])
    assert r.exit_code == 2


def test_int_conversion_failure_names_parameter():
    # spec: N-000375 N-000376 N-000380
    @command()
    @option("--count", type=int)
    def cli(count):
        pass

    r = run(cli, ["--count", "x"])
    assert r.exit_code == 2
    assert "'--count'" in r.output


def test_int_range_clamp_and_refuse():
    # spec: N-000358 N-000359 N-000360
    @command()
    @option("--n", type=IntRange(1, 5, clamp=True))
    def cli(n):
        optlyn.echo(n)

    assert run(cli, ["--n", "9"]).output == "5\n"
    assert run(cli, ["--n", "0"]).output == "1\n"
    @command()
    @option("--n", type=IntRange(1, 5))
    def strict(n):
        pass

    assert run(strict, ["--n", "9"]).exit_code == 2


def test_argument_required_optional_variadic():
    # spec: N-000285 N-000287 N-000291 N-000293 N-000294 N-000296
    seen = {}

    @command()
    @argument("src")
    @argument("dst", required=False)
    @argument("more", nargs=-1)
    def cli(src, dst, more):
        seen.update(src=src, dst=dst, more=more)

    run(cli, ["a"])
    assert seen == {"src": "a", "dst": None, "more": ()}
    run(cli, ["a", "b", "c", "d"])
    assert seen == {"src": "a", "dst": "b", "more": ("c", "d")}


def test_extra_arguments_are_usage_error_unless_allowed():
    # spec: N-000323 N-000105 N-000109
    @command()
    @argument("a")
    def cli(a):
        pass

    assert run(cli, ["x", "y"]).exit_code == 2

    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def lenient(a):
        optlyn.echo(a)

    r = run(lenient, ["x", "y"])
    assert r.exit_code == 0
    assert r.output == "x\n"


def test_env_var_fills_option_and_argument():
    # spec: N-000227 N-000309 N-000312 N-000313
    @command()
    @option("--name", envvar="OPT_NAME_X")
    @argument("pos", envvar="ARG_POS_X", required=False)
    def cli(name, pos):
        optlyn.echo(f"{name}|{pos}")

    r = run(cli, [], env={"OPT_NAME_X": "fromenv", "ARG_POS_X": "p"})
    assert r.output == "fromenv|p\n"
    r = run(cli, ["--name", "cli"], env={"OPT_NAME_X": "fromenv"})
    assert r.output == "cli|None\n"
    r = run(cli, [], env={"OPT_NAME_X": ""})
    assert r.output == "None|None\n"


def test_bool_env_values():
    # spec: N-000234 N-000235 N-000236 N-000237
    @command()
    @option("--debug/--no-debug", envvar="DBG_FLAG_X")
    def cli(debug):
        optlyn.echo(debug)

    assert run(cli, [], env={"DBG_FLAG_X": "YES"}).output == "True\n"
    assert run(cli, [], env={"DBG_FLAG_X": " off "}).output == "False\n"
    r = run(cli, [], env={"DBG_FLAG_X": "maybe"})
    assert r.exit_code == 2


def test_env_list_first_set_wins():
    # spec: N-000227 N-000228
    @command()
    @option("--v", envvar=["FIRST_X", "SECOND_X"])
    def cli(v):
        optlyn.echo(v)

    assert run(cli, [], env={"FIRST_X": "a", "SECOND_X": "b"}).output == "a\n"
    assert run(cli, [], env={"SECOND_X": "b"}).output == "b\n"


def test_auto_envvar_prefix_for_options():
    # spec: N-000444 N-000445 N-000446
    @command()
    @option("--level")
    def cli(level):
        optlyn.echo(level)

    r = run(cli, [], env={"MYAPP_LEVEL": "high"}, prog_name="cli", **{"auto_envvar_prefix": "MYAPP"})
    assert r.output == "high\n"


def test_default_map_fills_and_command_line_wins():
    # spec: N-000450 N-000451 N-000452 N-000455
    @command()
    @option("--name")
    @option("--n", type=int)
    def cli(name, n):
        optlyn.echo(f"{name}|{n}")

    r = run(cli, [], default_map={"name": "mapped", "n": 4})
    assert r.output == "mapped|4\n"
    r = run(cli, ["--name", "cmd"], default_map={"name": "mapped"})
    assert r.output == "cmd|None\n"


def test_parameter_source_reporting():
    # spec: N-000463 N-000464 N-000465 N-000466
    seen = {}

    @command()
    @option("--a")
    @option("--b", envvar="B_SRC_X")
    @option("--c", default="d")
    @option("--e")
    def cli(a, b, c, e):
        ctx = optlyn.get_current_context()
        seen["a"] = ctx.get_parameter_source("a")
        seen["b"] = ctx.get_parameter_source("b")
        seen["c"] = ctx.get_parameter_source("c")
        seen["e"] = ctx.get_parameter_source("e")
        seen["zzz"] = ctx.get_parameter_source("zzz")

    run(cli, ["--a", "1"], env={"B_SRC_X": "2"})
    assert seen["a"] is ParameterSource.COMMANDLINE
    assert seen["b"] is ParameterSource.ENVIRONMENT
    assert seen["c"] is ParameterSource.DEFAULT
    assert seen["zzz"] is None
    assert len({ParameterSource.COMMANDLINE, ParameterSource.ENVIRONMENT, ParameterSource.DEFAULT_MAP,
                ParameterSource.DEFAULT, ParameterSource.PROMPT}) == 5


def test_param_callback_can_replace_or_refuse():
    # spec: N-000250 N-000251 N-000252 N-000254
    def upper(ctx, param, value):
        return value.upper()

    def refuse(ctx, param, value):
        raise optlyn.BadParameter("nope", ctx=ctx, param=param)

    @command()
    @option("--name", callback=upper)
    def cli(name):
        optlyn.echo(name)

    assert run(cli, ["--name", "abc"]).output == "ABC\n"

    ran = []

    @command()
    @option("--name", callback=refuse)
    def strict(name):
        ran.append(1)

    r = run(strict, ["--name", "x"])
    assert r.exit_code == 2
    assert ran == []


def test_hidden_parameter_still_parsed_not_passed():
    # spec: N-000264 N-000265
    seen = {}

    @command()
    @option("--secret", expose_value=False, is_flag=True)
    @option("--x")
    def cli(x, **kw):
        seen["kw"] = kw
        seen["x"] = x

    r = run(cli, ["--secret", "--x", "1"])
    assert r.exit_code == 0
    assert seen == {"kw": {}, "x": "1"}


def test_path_type_checks(tmp_path):
    # spec: N-000583 N-000584 N-000587
    f = tmp_path / "f.txt"
    f.write_text("x")

    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cli(p):
        optlyn.echo(p)

    assert run(cli, [str(f)]).output == f"{f}\n"
    assert run(cli, [str(tmp_path / "missing")]).exit_code == 2
    assert run(cli, [str(tmp_path)]).exit_code == 2


def test_eager_help_wins_over_missing_required():
    # spec: N-000929 N-000250
    @command()
    @option("--must", required=True)
    def cli(must):
        pass

    r = run(cli, ["--help"])
    assert r.exit_code == 0
    assert "Usage:" in r.output


def test_no_args_is_help_for_leaf_is_usage_error():
    # spec: N-000175 N-000174
    @command(no_args_is_help=True)
    @option("--x")
    def cli(x):
        pass

    r = run(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.output


def test_context_settings_help_names():
    # spec: N-000155 N-000157
    @command(context_settings={"help_option_names": ["-h"]})
    def cli():
        pass

    assert run(cli, ["-h"]).exit_code == 0
    assert run(cli, ["-h"]).output.startswith("Usage:")
    assert run(cli, ["--help"]).exit_code == 2


def test_command_name_derivation():
    # spec: N-000079 N-000080 N-000081 N-000082
    @command()
    def my_tool_cmd():
        pass

    @command("explicit")
    def other_thing():
        pass

    assert my_tool_cmd.name == "my-tool"
    assert other_thing.name == "explicit"


def test_deprecated_command_warns_and_runs():
    # spec: N-000086 N-000087 N-000089
    ran = []

    @command(deprecated="use new")
    def old():
        ran.append(1)

    r = run(old, [])
    assert r.exit_code == 0
    assert ran == [1]
    assert "deprecated" in r.stderr.lower()
    assert "use new" in r.stderr


def test_context_stop_and_abort_exit_codes():
    # spec: N-000716 N-000717 N-000723 N-000724
    @command()
    def stop():
        optlyn.get_current_context().exit(3)

    assert run(stop, []).exit_code == 3

    @command()
    def boom():
        optlyn.get_current_context().abort()

    r = run(boom, [])
    assert r.exit_code == 1
    assert "Aborted!" in r.stderr


def test_standalone_off_returns_value_and_raises():
    # spec: N-000730 N-000728
    @command()
    def cli():
        return 42

    assert cli.main([], standalone_mode=False) == 42

    @command()
    @option("--n", type=int)
    def strict(n):
        pass

    try:
        strict.main(["--n", "x"], standalone_mode=False)
    except optlyn.UsageError:
        pass
    else:
        raise AssertionError("expected a UsageError")
