"""Prompts, confirmation, parameter types, files, terminal helpers, completion."""

import datetime
import os
import uuid

import pytest

import optlyn
from optlyn import (
    BOOL, Choice, DateTime, File, FloatRange, INT, IntRange, Path, STRING, Tuple, UUID,
    argument, command, confirmation_option, option, password_option, testing,
)
from optlyn.completion import complete, generate_script
from optlyn.core import Group


def run(cli, args, **kw):
    return testing.CliRunner().invoke(cli, args, **kw)


# -- prompts -------------------------------------------------------------------

def test_prompt_option_asks_when_omitted_and_reads_input():
    # spec: N-000488 N-000492 N-000493
    @command()
    @option("--name", prompt=True)
    def cli(name):
        optlyn.echo(f"got {name}")

    r = run(cli, [], input="Alice\n")
    assert r.exit_code == 0
    assert "Name: " in r.output
    assert "got Alice" in r.output


def test_prompt_not_asked_when_supplied_on_command_line():
    # spec: N-000489
    @command()
    @option("--name", prompt=True)
    def cli(name):
        optlyn.echo(f"got {name}")

    r = run(cli, ["--name", "bob"], input="ignored\n")
    assert r.output == "got bob\n"


def test_prompt_uses_default_on_empty_answer():
    # spec: N-000497 N-000500
    @command()
    @option("--color", prompt=True, default="blue")
    def cli(color):
        optlyn.echo(color)

    r = run(cli, [], input="\n")
    assert r.output.splitlines()[-1] == "blue"


def test_prompt_reasks_on_conversion_failure():
    # spec: N-000520 N-000521
    @command()
    @option("--n", prompt=True, type=int)
    def cli(n):
        optlyn.echo(n)

    r = run(cli, [], input="abc\n42\n")
    assert r.output.strip().splitlines()[-1] == "42"
    assert "not a valid integer" in r.output


def test_eof_during_prompt_is_abort():
    # spec: N-000524
    @command()
    @option("--n", prompt=True)
    def cli(n):
        pass

    r = run(cli, [], input="")
    assert r.exit_code == 1
    assert "Aborted!" in r.stderr


def test_password_option_hidden_and_confirmed():
    # spec: N-000510 N-000511 N-000512
    @command()
    @password_option()
    def cli(password):
        optlyn.echo(f"pw={password}")

    r = run(cli, [], input="s3cret\ns3cret\n")
    assert r.exit_code == 0
    assert "pw=s3cret" in r.output
    # Hidden input is not echoed back.
    assert "s3cret" not in r.output.replace("pw=s3cret", "")


def test_password_mismatch_asks_pair_again():
    @command()
    @password_option()
    def cli(password):
        optlyn.echo(f"pw={password}")

    r = run(cli, [], input="a\nb\nsame\nsame\n")
    assert r.exit_code == 0
    assert "pw=same" in r.output
    assert "do not match" in r.stderr


def test_confirmation_option_flag_skips_question():
    # spec: N-000513 N-000514
    ran = []

    @command()
    @confirmation_option("--yes")
    def cli():
        ran.append(1)

    r = run(cli, ["--yes"], input="")
    assert r.exit_code == 0
    assert ran == [1]


def test_confirmation_declined_aborts_without_running():
    # spec: N-000515 N-000518 N-000519
    ran = []

    @command()
    @confirmation_option(prompt="Really?")
    def cli():
        ran.append(1)

    r = run(cli, [], input="n\n")
    assert r.exit_code == 1
    assert ran == []
    r = run(cli, [], input="y\n")
    assert r.exit_code == 0
    assert ran == [1]


def test_standalone_confirm_and_prompt_helpers():
    # spec: N-000501 N-000502 N-000503 N-000504
    @command()
    def cli():
        ok = optlyn.confirm("Sure?")
        optlyn.echo(f"ok={ok}")
        n = optlyn.prompt("Number", type=int)
        optlyn.echo(f"n={n}")

    r = run(cli, [], input="YES\n7\n")
    assert "ok=True" in r.output
    assert "n=7" in r.output


def test_confirm_empty_takes_default_and_abort_flag():
    @command()
    def cli():
        optlyn.confirm("Go?", default=True)
        optlyn.echo("went")

    assert "went" in run(cli, [], input="\n").output


# -- types ---------------------------------------------------------------------

def test_choice_error_message_and_ok():
    @command()
    @argument("c", type=Choice(["a", "b"]))
    def cli(c):
        optlyn.echo(c)

    assert run(cli, ["b"]).output == "b\n"
    assert run(cli, ["z"]).exit_code == 2


def test_datetime_default_formats_and_custom():
    # spec: N-000353 N-000354 N-000356
    @command()
    @option("--when", type=DateTime())
    def cli(when):
        optlyn.echo(repr(when))

    assert run(cli, ["--when", "2024-01-02"]).output == "datetime.datetime(2024, 1, 2, 0, 0)\n"
    assert run(cli, ["--when", "2024-01-02T03:04:05"]).output == "datetime.datetime(2024, 1, 2, 3, 4, 5)\n"
    assert run(cli, ["--when", "2024-01-02 03:04:05"]).exit_code == 0
    assert run(cli, ["--when", "nope"]).exit_code == 2

    @command()
    @option("--when", type=DateTime(["%d/%m/%Y"]))
    def custom(when):
        optlyn.echo(repr(when))

    assert run(custom, ["--when", "02/01/2024"]).exit_code == 0
    assert run(custom, ["--when", "2024-01-02"]).exit_code == 2


def test_float_range_clamp_with_open_bound_refused():
    # spec: N-000381
    with pytest.raises(ValueError):
        FloatRange(0, 1, min_open=True, clamp=True)
    assert FloatRange(0, 1, clamp=True).convert(5.0, None, None) == 1.0


def test_intrange_open_bound_clamp_adjacent():
    # spec: N-000362
    r = IntRange(1, 5, min_open=True, clamp=True)
    assert r.convert(1, None, None) == 2
    assert IntRange(1, 5, max_open=True, clamp=True).convert(9, None, None) == 4


def test_tuple_type_option():
    # spec: N-000366
    @command()
    @option("--point", type=Tuple([str, int]))
    def cli(point):
        optlyn.echo(repr(point))

    assert run(cli, ["--point", "x", "3"]).output == "('x', 3)\n"


def test_uuid_and_bool_types():
    @command()
    @option("--id", type=UUID)
    @option("--flag", type=BOOL)
    def cli(id, flag):
        optlyn.echo(f"{id}|{flag}")

    u = uuid.uuid4()
    assert run(cli, ["--id", str(u), "--flag", "yes"]).output == f"{u}|True\n"
    assert run(cli, ["--id", "nope"]).exit_code == 2


def test_path_and_file_types(tmp_path):
    # spec: N-000532 N-000533 N-000548
    target = tmp_path / "out.txt"

    @command()
    @argument("dest", type=File("w"))
    def writer(dest):
        dest.write("hello")

    r = run(writer, [str(target)])
    assert r.exit_code == 0
    assert target.read_text() == "hello"

    @command()
    @argument("src", type=File("r"))
    def reader(src):
        optlyn.echo(src.read().upper())

    assert run(reader, [str(target)]).output == "HELLO\n"
    r = run(reader, [str(tmp_path / "missing.txt")])
    assert r.exit_code == 2
    assert "missing.txt" in r.output


def test_lazy_write_file_not_truncated_when_unused(tmp_path):
    # spec: N-000537 N-000538 N-000580
    target = tmp_path / "keep.txt"
    target.write_text("original")

    @command()
    @option("--out", type=File("w"))
    def cli(out):
        pass

    run(cli, ["--out", str(target)])
    assert target.read_text() == "original"


def test_dash_is_stdin_for_file_type():
    # spec: N-000532 N-000546
    @command()
    @argument("src", type=File("r"))
    def cli(src):
        optlyn.echo(src.read().strip())

    assert run(cli, ["-"], input="piped\n").output == "piped\n"


def test_envvar_path_list_split_on_pathsep(tmp_path):
    # spec: N-000574 N-000233
    @command()
    @option("--dirs", type=Path(file_okay=False), multiple=True, envvar="DIRS_X")
    def cli(dirs):
        optlyn.echo(len(dirs))

    r = run(cli, [], env={"DIRS_X": os.pathsep.join(["a", "b", "c"])})
    assert r.output == "3\n"


def test_format_filename_and_get_app_dir(monkeypatch, tmp_path):
    # spec: N-000575 N-000576 N-000674 N-000676
    assert optlyn.format_filename("a/b.txt", shorten=True) == "b.txt"
    assert optlyn.format_filename(b"\xff.txt").encode("utf-8") == b"\\xff.txt"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert optlyn.get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")
    monkeypatch.delenv("XDG_CONFIG_HOME")
    d = optlyn.get_app_dir("My  App", force_posix=True)
    assert d.endswith("." + "my-app")


# -- terminal helpers -----------------------------------------------------------

def test_echo_strips_styles_on_non_terminal_and_keeps_when_forced():
    # spec: N-000623 N-000624 N-000681 N-000682
    @command()
    def cli():
        optlyn.echo(optlyn.style("hi", fg="red", bold=True))

    r = run(cli, [])
    assert "\x1b[" not in r.output
    r = run(cli, [], color=True)
    assert "\x1b[" in r.output


def test_style_codes_and_invalid_color():
    # spec: N-000628 N-000629 N-000639
    s = optlyn.style("x", fg="red")
    assert s.startswith("\x1b[31m") and s.endswith("\x1b[0m")
    assert optlyn.style("x", bg="red") != optlyn.style("x", fg="red")
    assert optlyn.style("x", fg=200).startswith("\x1b[38;5;200m")
    assert optlyn.style("x", fg=(1, 2, 3)).startswith("\x1b[38;2;1;2;3m")
    with pytest.raises(TypeError):
        optlyn.style("x", fg="octarine")
    assert optlyn.unstyle(optlyn.style("abc", italic=True)) == "abc"


def test_secho_and_err_channel():
    @command()
    def cli():
        optlyn.secho("to err", err=True)
        optlyn.echo("to out")

    r = run(cli, [])
    assert r.stdout == "to out\n"
    assert r.stderr == "to err\n"
    assert r.output == "to err\nto out\n"


def test_pause_non_interactive_does_not_block():
    # spec: N-000662 N-000663 N-000686
    @command()
    def cli():
        optlyn.pause("Press it")

    r = run(cli, [], input="")
    assert r.exit_code == 0


def test_progressbar_visits_every_item_without_terminal():
    # spec: N-000649 N-000684 N-000685
    seen = []

    @command()
    def cli():
        with optlyn.progressbar([1, 2, 3], label="work") as bar:
            for item in bar:
                seen.append(item)

    r = run(cli, [])
    assert seen == [1, 2, 3]
    assert "work" in r.output


def test_hidden_progressbar_prints_nothing():
    @command()
    def cli():
        with optlyn.progressbar(range(2), label="quiet", hidden=True) as bar:
            list(bar)

    assert run(cli, []).output == ""


def test_echo_via_pager_non_interactive_writes_all_chunks():
    # spec: N-000641 N-000645 N-000646
    @command()
    def cli():
        optlyn.echo_via_pager(lambda: iter(["a\n", "b\n"]))

    assert run(cli, []).output == "a\nb\n"


def test_wrap_text_and_help_width_limit():
    # spec: N-000679
    assert optlyn.wrap_text("one two three four", width=9) == "one two\nthree\nfour"
    assert optlyn.wrap_text("") == ""


def test_clear_does_nothing_without_terminal():
    @command()
    def cli():
        optlyn.clear()

    assert run(cli, []).output == ""


def test_edit_and_launch_exist():
    assert callable(optlyn.edit) and callable(optlyn.launch)


# -- completion ------------------------------------------------------------------

@command()
@option("--color", type=Choice(["red", "green"]))
@option("--out", type=Path(file_okay=True))
@argument("target")
def tool(color, out, target):
    pass


def test_complete_choice_values_for_option():
    # spec: N-000694 N-000700
    items = complete(tool, "tool", "bash", "tool --color r", "2")
    assert [i.value for i in items] == ["red"]


def test_complete_option_names_after_dash():
    # spec: N-000696 N-000698 N-000699 N-000700
    items = complete(tool, "tool", "bash", "tool --co", "1")
    assert [i.value for i in items] == ["--color"]
    items = complete(tool, "tool", "bash", "tool --", "1")
    values = [i.value for i in items]
    assert "--color" in values and "--help" in values and "--out" in values
    # Empty token: options are not listed until a dash has been typed.
    items = complete(tool, "tool", "bash", "tool ", "1")
    assert all(not i.value.startswith("-") for i in items)


def test_path_request_entries_for_path_option():
    # spec: N-001023 N-001027 N-001028
    items = complete(tool, "tool", "bash", "tool --out sr", "2")
    assert items[0].type == "file" and items[0].value == "sr"


def test_completion_script_contains_variable_and_program():
    # spec: N-001022 N-001013 N-000690
    script = generate_script("bash", "my-tool", "_MY_TOOL_COMPLETE")
    assert "_MY_TOOL_COMPLETE=bash_complete" in script
    assert "complete -o default" in script and "my-tool" in script


def test_source_and_complete_via_environment(capsys):
    # spec: N-000701 N-000703 N-000714
    env = {"_TOOL_COMPLETE": "bash_source"}
    r = run(tool, [], env=env)
    assert r.exit_code == 0
    assert "complete" in r.output

    env = {"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": "tool --color r", "COMP_CWORD": "2"}
    r = run(tool, [], env=env)
    assert r.exit_code == 0
    assert "plain,red" in r.output

    r = run(tool, [], env={"_TOOL_COMPLETE": "bogus_thing"})
    assert r.exit_code != 0
    assert "Usage" not in r.output


def test_completion_ignored_for_other_name():
    # spec: N-000692 N-000693
    r = run(tool, ["x"], env={"_OTHER_COMPLETE": "bash_source"})
    assert r.exit_code == 0
    assert r.output == ""
