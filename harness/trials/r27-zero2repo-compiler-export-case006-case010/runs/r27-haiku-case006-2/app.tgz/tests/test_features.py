"""Version/help flags, feature switches, help text rules, runner helpers, deprecations."""

import os

import optlyn
from optlyn import argument, command, custom_version_option, group, help_option, option, testing, version_option


def run(cli, args, **kw):
    return testing.CliRunner().invoke(cli, args, **kw)


def test_feature_switch_options_share_destination():
    # spec: N-000246 N-000249 N-000178
    @command()
    @option("--fast", "mode", flag_value="fast", is_flag=True)
    @option("--slow", "mode", flag_value="slow", is_flag=True)
    def cli(mode):
        optlyn.echo(mode)

    assert run(cli, ["--fast"]).output == "fast\n"
    assert run(cli, ["--slow"]).output == "slow\n"


def test_help_flag_is_eager_before_other_eager_flags():
    # spec: N-000168 N-000169
    @command()
    @custom_version_option(lambda ctx: "v9.9")
    def cli():
        pass

    r = run(cli, ["--help", "--version"])
    assert r.exit_code == 0
    assert "Usage:" in r.output
    assert "v9.9" not in r.output
    r = run(cli, ["--version", "--help"])
    assert r.output == "v9.9\n"


def test_custom_version_option_prints_exact_string():
    # spec: N-000846 N-000847 N-000932
    @command()
    @custom_version_option(lambda ctx: f"tool {ctx.command.name} 1.2")
    def cli():
        pass

    r = run(cli, ["--version"], )
    assert r.exit_code == 0
    assert r.output == "tool cli 1.2\n"


def test_version_option_with_explicit_version():
    # spec: N-000930
    @command()
    @version_option("3.4.5", prog_name="mytool")
    def cli():
        pass

    r = run(cli, ["--version"])
    assert r.exit_code == 0
    assert "3.4.5" in r.output and "mytool" in r.output


def test_version_option_detects_from_installed_distribution():
    # spec: N-000931 N-000162
    @command()
    @version_option(package_name="pytest")
    def cli():
        pass

    import importlib.metadata as md

    r = run(cli, ["--version"])
    assert r.exit_code == 0
    assert md.version("pytest") in r.output


def test_help_text_form_feed_truncates_docstring():
    # spec: N-000114 N-000115 N-000116 N-000117
    @command()
    def cli():
        """Shown text.

        \f
        hidden tail
        """

    out = run(cli, ["--help"]).output
    assert "Shown text." in out
    assert "hidden tail" not in out
    assert "\f" not in out


def test_help_option_name_overridden_and_metavar_override():
    # spec: N-000139 N-000143 N-000830
    @command()
    @option("--size", metavar="BYTES", type=int, help="Size.")
    @argument("src", metavar="SOURCE")
    @argument("dst", required=False)
    def cli(size, src, dst):
        pass

    out = run(cli, ["--help"]).output
    assert "--size BYTES" in out
    assert "SOURCE" in out
    assert "[DST]" in out


def test_integer_option_metavar_is_type_name():
    @command()
    @option("--count", type=int)
    def cli(count):
        pass

    assert "--count INTEGER" in run(cli, ["--help"]).output


def test_show_default_hides_false_flag_and_shows_true():
    # spec: N-000146 N-000147 N-000148 N-000149 N-000150
    @command()
    @option("--off", is_flag=True, show_default=True)
    @option("--on", is_flag=True, default=True, show_default=True)
    @option("--count", default=3, show_default=True, type=int)
    def cli(off, on, count):
        pass

    out = run(cli, ["--help"]).output
    off_line = next(l for l in out.splitlines() if "--off" in l)
    on_line = next(l for l in out.splitlines() if "--on" in l)
    assert "default" not in off_line
    assert "[default: True]" in on_line
    assert "[default: 3]" in out


def test_show_envvar_in_help():
    @command()
    @option("--token", envvar="TOKEN_HELP_X", show_envvar=True)
    def cli(token):
        pass

    assert "TOKEN_HELP_X" in run(cli, ["--help"]).output


def test_deprecated_option_warns_only_when_supplied():
    # spec: N-000266 N-000267 N-000280
    @command()
    @option("--old", deprecated=True, default="x")
    def cli(old):
        optlyn.echo(old)

    r = run(cli, [])
    assert "deprecated" not in r.stderr.lower()
    r = run(cli, ["--old", "y"])
    assert r.exit_code == 0
    assert "deprecated" in r.stderr.lower()


def test_deprecated_option_cannot_be_required():
    try:
        option("--x", deprecated=True, required=True)(lambda: None)
    except (ValueError, TypeError):
        pass
    else:
        raise AssertionError("expected declaration error")


def test_deprecated_argument_cannot_be_required_without_default():
    import pytest

    # The refusal happens when the decorator is applied (declaration time).
    with pytest.raises(ValueError):
        @command()
        @argument("x", deprecated=True, required=True)
        def cli(x):
            pass


def test_group_help_shows_deprecated_mark():
    @group()
    def g():
        pass

    @g.command(deprecated=True)
    def old():
        """Old thing."""

    out = run(g, ["--help"]).output
    assert "(Deprecated)" in out


def test_isolated_filesystem_creates_and_restores_cwd(tmp_path):
    # spec: N-001044 N-000744 N-000745
    runner = testing.CliRunner()
    before = os.getcwd()
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        assert os.getcwd() == path
        with open("f.txt", "w") as f:
            f.write("data")
        assert os.path.exists(os.path.join(path, "f.txt"))
    assert os.getcwd() == before
    assert os.path.exists(path)  # parent given: left in place


def test_runner_env_unset_and_restore(monkeypatch):
    # spec: N-001038
    monkeypatch.setenv("KEEP_ME_X", "orig")

    @command()
    def cli():
        optlyn.echo(f"{os.environ.get('KEEP_ME_X')}|{os.environ.get('NEW_X')}")

    r = run(cli, [], env={"KEEP_ME_X": None, "NEW_X": "n"})
    assert r.output == "None|n\n"
    assert os.environ["KEEP_ME_X"] == "orig"
    assert "NEW_X" not in os.environ


def test_runner_result_stdout_stderr_and_bytes():
    # spec: N-001039 N-001040 N-001041 N-001042
    @command()
    def cli():
        optlyn.echo("out-text")
        optlyn.echo("err-text", err=True)

    r = run(cli, [])
    assert r.stdout == "out-text\n"
    assert r.stderr == "err-text\n"
    assert r.stdout_bytes == b"out-text\n"
    assert r.stderr_bytes == b"err-text\n"
    assert r.output == "out-text\nerr-text\n"
    assert r.exception is None


def test_runner_catches_exception_and_can_propagate():
    @command()
    def cli():
        raise ValueError("boom")

    r = run(cli, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, ValueError)
    try:
        testing.CliRunner(catch_exceptions=False).invoke(cli, [])
    except ValueError:
        pass
    else:
        raise AssertionError("expected propagation")


def test_runner_input_echoed_for_visible_prompts_only():
    # spec: N-000525 N-000526 N-000527
    @command()
    def cli():
        name = optlyn.prompt("Name")
        secret = optlyn.prompt("Pin", hide_input=True)
        optlyn.echo(f"{name}/{secret}")

    r = run(cli, [], input="ann\n1234\n")
    assert "Name: ann" in r.output
    # The hidden answer is not echoed by the prompt (only the author's final echo shows it).
    assert "Pin: 1234" not in r.output
    assert "Pin: \n" in r.output
    assert r.output.count("1234") == 1


def test_echo_stdin_mode_echoes_reads():
    @command()
    def cli():
        optlyn.echo(optlyn.prompt("Q"))

    r = testing.CliRunner(echo_stdin=True).invoke(cli, [], input="hello\n")
    assert r.output.count("hello") == 2


def test_nested_program_prog_name_and_usage_line():
    # spec: N-000058 N-000061
    @group()
    def tool():
        pass

    @tool.command()
    def sub():
        pass

    r = run(tool, ["sub", "--bogus"])
    assert "Usage: tool sub" in r.output
    assert "Try 'tool sub --help' for help." in r.output
