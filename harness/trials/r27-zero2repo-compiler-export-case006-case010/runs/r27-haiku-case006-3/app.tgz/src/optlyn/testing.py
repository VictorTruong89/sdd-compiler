"""In-process runner: ``optlyn.testing.CliRunner``.

# spec: N-001038, N-001039, N-001040, N-001041, N-001042, N-001043, N-001044
# spec: N-000736, N-000737, N-000738, N-000739, N-000740, N-000741, N-000742
# spec: N-000743, N-000744, N-000745, N-000746, N-000747, N-000748, N-000749
# spec: N-000750, N-000751, N-000752, N-000753, N-000754, N-000755, N-000756
# spec: N-000757, N-000758, N-000759, N-000760, N-000761, N-000762, N-000763
"""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
from typing import Any



class _Recorder:
    """Records writes from both streams in order."""

    def __init__(self, charset: str) -> None:
        self.charset = charset
        self.events: list[tuple[str, bytes]] = []

    def record(self, tag: str, data: bytes) -> None:
        self.events.append((tag, data))


class _CaptureBuffer(io.RawIOBase):
    def __init__(self, recorder: _Recorder, tag: str) -> None:
        self._recorder = recorder
        self._tag = tag

    def writable(self) -> bool:
        return True

    def write(self, data) -> int:
        data = bytes(data)
        self._recorder.record(self._tag, data)
        return len(data)

    def flush(self) -> None:
        pass


class _CaptureStream(io.TextIOBase):
    """Text stream whose writes are recorded (no real file descriptor)."""

    def __init__(self, recorder: _Recorder, tag: str) -> None:
        self._recorder = recorder
        self._tag = tag
        self.buffer = _CaptureBuffer(recorder, tag)
        self._encoding = recorder.charset

    @property
    def encoding(self) -> str:
        return self._encoding

    @property
    def errors(self) -> str:
        return "replace"

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, text) -> int:
        if isinstance(text, bytes):
            text = text.decode(self._encoding, "replace")
        self._recorder.record(self._tag, text.encode(self._encoding, "replace"))
        return len(text)

    def flush(self) -> None:
        pass


class _RunnerInput(io.TextIOBase):
    """Standard input for an invocation. Reads consume the supplied data."""

    def __init__(self, data: bytes, charset: str, echo_stdin: bool, recorder: _Recorder) -> None:
        self._data = io.BytesIO(data)
        self._charset = charset
        self.echo_stdin = echo_stdin
        self._recorder = recorder
        # Visible prompts echo their typed line unless every read is echoed.
        self._optlyn_echo_prompts = not echo_stdin

    @property
    def encoding(self) -> str:
        return self._charset

    def readable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def readline(self, size: int = -1) -> str:
        raw = self._data.readline(size) if size is not None and size >= 0 else self._data.readline()
        text = raw.decode(self._charset, "replace")
        if self.echo_stdin and text:
            self._recorder.record("stdout", text.encode(self._charset, "replace"))
        return text

    def read(self, size: int = -1) -> str:
        raw = self._data.read() if size is None or size < 0 else self._data.read(size)
        text = raw.decode(self._charset, "replace")
        if self.echo_stdin and text:
            self._recorder.record("stdout", text.encode(self._charset, "replace"))
        return text


class Result:
    """Outcome of an invocation.

    # spec: N-001039, N-001040, N-001041, N-001042, N-001043, N-000739, N-000740
    """

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command in-process with argument tokens and capture its output.

    # spec: N-001038, N-001039, N-001042, N-000736, N-000737, N-000738
    """

    def __init__(
        self,
        charset: str = "utf-8",
        env=None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.capture = capture

    def get_default_prog_name(self, cli) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Work in a new empty directory. Yields its path.

        # spec: N-001044, N-000744, N-000745, N-000746, N-000747
        """
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)

    @contextlib.contextmanager
    def _env(self, overrides):
        saved = {}
        for key, value in (overrides or {}).items():
            saved[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        try:
            yield
        finally:
            for key, old in saved.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def _run(self, cli, args, stdin, stdout, stderr, env_overrides, catch_exceptions,
             prog_name, standalone, extra):
        """Run the command with the given streams. Returns (exit_code, exception)."""
        exception: BaseException | None = None
        exit_code = 0
        with self._env(env_overrides):
            old_streams = (sys.stdin, sys.stdout, sys.stderr)
            sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
            try:
                try:
                    rv = cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
                    if not standalone:
                        exit_code = rv if isinstance(rv, int) and not isinstance(rv, bool) else 0
                except SystemExit as e:
                    code = e.code
                    if code is None:
                        exit_code = 0
                    elif isinstance(code, int):
                        exit_code = code
                    else:
                        stderr.write(str(code) + "\n")
                        exit_code = 1
                except Exception as e:  # noqa: BLE001 - captured as the result
                    exit_code = 1
                    exception = e
                    if not catch_exceptions:
                        raise
            finally:
                sys.stdin, sys.stdout, sys.stderr = old_streams
        return exit_code, exception

    def _invoke_fd(self, cli, args, data, env_overrides, catch_exceptions, color, prog_name, standalone, extra):
        """Descriptor capture: OS-level writes to fds 1 and 2 are captured too.

        The interpreter streams report a real file descriptor. Output is returned
        as standard output followed by standard error (the two cannot be
        interleaved exactly when they go to separate descriptors).
        """
        import tempfile

        stdin = _RunnerInput(data, self.charset, self.echo_stdin, _Recorder(self.charset))
        with tempfile.TemporaryFile() as out_f, tempfile.TemporaryFile() as err_f:
            sys.stdout.flush()
            sys.stderr.flush()
            saved_out = os.dup(1)
            saved_err = os.dup(2)
            os.dup2(out_f.fileno(), 1)
            os.dup2(err_f.fileno(), 2)
            stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                      errors="replace", line_buffering=True)
            stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                      errors="replace", line_buffering=True)
            try:
                exit_code, exception = self._run(cli, args, stdin, stdout, stderr, env_overrides,
                                                 catch_exceptions, prog_name, standalone, extra)
            finally:
                stdout.flush()
                stderr.flush()
                os.dup2(saved_out, 1)
                os.dup2(saved_err, 2)
                os.close(saved_out)
                os.close(saved_err)
            out_f.seek(0)
            err_f.seek(0)
            stdout_bytes = out_f.read()
            stderr_bytes = err_f.read()
        return Result(self, stdout_bytes, stderr_bytes, stdout_bytes + stderr_bytes, exit_code, exception)

    def invoke(
        self,
        cli,
        args=None,
        input=None,
        env=None,
        catch_exceptions=None,
        color: bool = False,
        **extra: Any,
    ) -> Result:
        """Run ``cli`` with ``args`` and capture everything it writes.

        # spec: N-001038, N-001039, N-001040, N-001041, N-000741, N-000742, N-000743
        # spec: N-000748, N-000749, N-000750, N-000758, N-000759, N-000760, N-000761
        # spec: N-000756, N-000757
        """
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        else:
            args = list(args)
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)

        env_overrides = dict(self.env)
        env_overrides.update(env or {})
        extra.setdefault("color", color)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)

        if self.capture == "fd":
            return self._invoke_fd(cli, args, data, env_overrides, catch_exceptions, color, prog_name, standalone, extra)

        recorder = _Recorder(self.charset)
        stdin = _RunnerInput(data, self.charset, self.echo_stdin, recorder)
        stdout = _CaptureStream(recorder, "stdout")
        stderr = _CaptureStream(recorder, "stderr")

        exit_code, exception = self._run(cli, args, stdin, stdout, stderr, env_overrides,
                                         catch_exceptions, prog_name, standalone, extra)

        stdout_bytes = b"".join(d for tag, d in recorder.events if tag == "stdout")
        stderr_bytes = b"".join(d for tag, d in recorder.events if tag == "stderr")
        output_bytes = b"".join(d for _, d in recorder.events)
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception)
