"""File and standard-stream helpers shared by the File type and ``open_file``.

# spec: N-000528, N-000529, N-000530, N-000531, N-000532, N-000533, N-000534
# spec: N-000535, N-000536, N-000537, N-000538, N-000539, N-000540, N-000541
# spec: N-000542, N-000543, N-000544, N-000545, N-000546, N-000547, N-000578
# spec: N-000579, N-000580, N-000581, N-000582, N-000588, N-000589, N-000590
# spec: N-000772, N-000663, N-000745
"""

from __future__ import annotations

import os
import sys
import tempfile

from .exceptions import FileError


class NonClosingStream:
    """Proxy for a standard stream whose ``close()`` does not close the stream.

    # spec: N-000546, N-000547, N-000588, N-000589, N-000590, N-000646, N-000648
    """

    def __init__(self, stream) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __setattr__(self, name, value):
        setattr(self._stream, name, value)

    def __iter__(self):
        return iter(self._stream)

    def close(self) -> None:
        try:
            self._stream.flush()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def std_stream(name: str, mode: str):
    """Return ``sys.stdin``/``sys.stdout`` for the mode, text or binary.

    # spec: N-000532, N-000772
    """
    if "r" in mode:
        stream = sys.stdin
    else:
        stream = sys.stdout
    if "b" in mode:
        stream = getattr(stream, "buffer", stream)
    return NonClosingStream(stream)


class AtomicFile:
    """Writes to a temporary sibling and replaces the target on close.

    # spec: N-000544, N-000545
    """

    def __init__(self, f, tmp_name: str, target: str) -> None:
        self._f = f
        self._tmp = tmp_name
        self._target = target
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def open_real(path: str, mode: str, encoding=None, errors="strict", atomic=False):
    """Open ``path`` now. Raises OSError on failure.

    # spec: N-000535, N-000536, N-000537, N-000543, N-000544, N-000545
    """
    text_mode = "b" not in mode
    kwargs = {}
    if text_mode:
        kwargs["encoding"] = encoding
        kwargs["errors"] = errors
    if atomic and "w" in mode:
        directory = os.path.dirname(os.path.abspath(path))
        fd, tmp = tempfile.mkstemp(
            dir=directory, prefix="." + os.path.basename(path) + ".", suffix=".tmp"
        )
        f = os.fdopen(fd, mode, **kwargs)
        return AtomicFile(f, tmp, path)
    return open(path, mode, **kwargs)


class LazyFile:
    """Opens its file on the first I/O operation.

    # spec: N-000537, N-000538, N-000539, N-000540, N-000578, N-000579, N-000580, N-000581, N-000582
    """

    def __init__(self, path: str, mode: str, encoding=None, errors="strict", atomic=False) -> None:
        self._path = path
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f = None
        self._closed = False

    def _open(self):
        if self._f is None:
            try:
                self._f = open_real(
                    self._path, self._mode, self._encoding, self._errors, self._atomic
                )
            except OSError as e:
                raise FileError(
                    f"Could not open file {self._path!r}: {e.strerror or e}"
                ) from e
        return self._f

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        if self._f is not None and not self._closed:
            self._closed = True
            self._f.close()


def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file or a standard stream for the ``-`` token.

    # spec: N-000528, N-000529, N-000530, N-000531, N-000532, N-000533, N-000534
    # spec: N-000535, N-000536, N-000537, N-000538, N-000539, N-000540, N-000541
    """
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    if filename == "-":
        return std_stream("-", mode)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return open_real(filename, mode, encoding, errors, atomic)
