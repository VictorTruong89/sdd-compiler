"""Exceptions and exit-status classes.

# spec: N-000807, N-000808, N-000809, N-000810, N-000811, N-000719, N-000720
# spec: N-000721, N-000722, N-000723, N-000724, N-000725, N-000726, N-000727
# spec: N-000728, N-000729, N-000730, N-000731, N-000732, N-000733, N-000734, N-000735
"""

from __future__ import annotations


class DeclarationError(TypeError, ValueError):
    """Raised when an invalid combination of keywords is declared.

    # spec: N-000282, N-000909, N-000912, N-000381, N-000325, N-000613
    """


class OptlynError(Exception):
    """Base class for errors that the library signals to the user.

    Subclasses carry the process exit status used in standalone mode.
    """

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self) -> None:
        from .termui import echo

        echo(f"Error: {self.format_message()}", err=True)


class Exit(Exception):
    """Author clean stop (or intentional help/version) with a status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class Abort(OptlynError):
    """Abort indication (declined confirmation, EOF, interrupt, author abort).

    # spec: N-000723, N-000724, N-000725, N-000524, N-000519
    """

    exit_code = 1

    def __init__(self, message: str = "Aborted!") -> None:
        super().__init__(message)

    def show(self) -> None:
        from .termui import echo

        echo(self.message, err=True)


class FileError(OptlynError):
    """General (non-usage) error, e.g. a lazy file that fails at first I/O.

    # spec: N-000726, N-000727, N-000581, N-000582
    """

    exit_code = 1


class UsageError(OptlynError):
    """Incorrect command-line usage. Exit status 2.

    # spec: N-000719, N-000720, N-000721, N-000722, N-000375, N-000376
    """

    exit_code = 2

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self) -> None:
        from .termui import echo

        ctx = self.ctx
        if ctx is not None:
            echo(ctx.get_usage(), err=True)
            echo(
                f"Try '{ctx.command_path} {ctx.help_option_names[0]}' for help.",
                err=True,
            )
            echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A value was refused. Raised from callbacks, types, or conversion functions.

    # spec: N-000933, N-000934, N-000935, N-000949, N-000375, N-000376, N-000380
    """

    def __init__(self, message="", ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value.

    # spec: N-000321, N-000322, N-000200, N-000201
    """

    def format_message(self) -> str:
        hint = None
        if self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if self.param is not None and self.param.param_kind == "argument":
            return f"Missing argument {hint}."
        return f"Missing option {hint}."


class NoSuchOption(UsageError):
    """An unknown option token was used.

    # spec: N-000268, N-000269, N-000274
    """

    def __init__(self, option_name: str, ctx=None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example it lacks its value).

    # spec: N-000275, N-000279
    """


class BadArgumentUsage(UsageError):
    """Positional arguments were used incorrectly.

    # spec: N-000323, N-000322
    """


class NoSuchCommand(UsageError):
    """An unknown subcommand name was given.

    # spec: N-000429, N-000431
    """

    def __init__(self, name: str, ctx=None) -> None:
        super().__init__(f"No such command {name!r}.", ctx)
        self.name = name


class MissingCommand(UsageError):
    """A group was invoked without a subcommand name.

    # spec: N-000430, N-000431, N-000432
    """

    def __init__(self, ctx=None) -> None:
        super().__init__("Missing command.", ctx)


class NoArgsIsHelp(UsageError):
    """No arguments were given and the command shows help as a usage failure.

    # spec: N-000170, N-000171, N-000173, N-000174, N-000175, N-000406, N-000410
    """

    def show(self) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), err=True)
