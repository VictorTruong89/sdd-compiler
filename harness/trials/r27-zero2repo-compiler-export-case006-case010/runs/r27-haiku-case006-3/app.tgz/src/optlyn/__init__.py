"""Optlyn: compose command line interfaces with as little code as necessary.

The package root exports the declaration decorators, classes, parameter types,
and terminal helpers described in the Interface Contract.

# spec: N-000791, N-000792, N-000793, N-000794, N-000795, N-000796, N-000797
# spec: N-000798, N-000799, N-000800, N-000801, N-000802, N-000778, N-000779
# Product overview, terminology and public surface (packs 14-16):
# spec: N-000001, N-000002, N-000003, N-000005, N-000006, N-000007, N-000008
# spec: N-000009, N-000010, N-000015, N-000016, N-000017, N-000018, N-000019
# spec: N-000020, N-000021, N-000022, N-000023, N-000024, N-000025, N-000026
# spec: N-000027, N-000028, N-000029, N-000030, N-000031, N-000032, N-000033
# spec: N-000034, N-000035, N-000036, N-000037, N-000038, N-000039, N-000040
# spec: N-000041, N-000042, N-000043, N-000044
# Non-functional constraints (pack 17):
# spec: N-000045, N-000046, N-000047, N-000048, N-000049, N-000050, N-000051
# spec: N-000052, N-000053, N-000056, N-000057, N-000058
# spec: N-000059, N-000060, N-000061, N-000062, N-000063, N-000064, N-000065
# spec: N-000066, N-000067, N-000068
"""

from __future__ import annotations

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    password_option,
    pass_context,
    pass_obj,
    version_option,
)
from .exceptions import Abort, BadParameter, DeclarationError, Exit, FileError, MissingParameter, OptlynError, UsageError
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from ._context import get_current_context
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .termui import get_app_dir
from .termui import format_filename, open_file

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Argument",
    "Parameter",
    "ParamType",
    "ParameterSource",
    "BadParameter",
    "MissingParameter",
    "UsageError",
    "Abort",
    "Exit",
    "FileError",
    "OptlynError",
    "DeclarationError",
    # types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
]
