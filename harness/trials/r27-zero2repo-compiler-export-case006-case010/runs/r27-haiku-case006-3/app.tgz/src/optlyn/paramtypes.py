"""Parameter types and conversion.

# spec: N-000936, N-000937, N-000938, N-000939, N-000940, N-000941, N-000942
# spec: N-000943, N-000944, N-000945, N-000946, N-000947, N-000948, N-000949
# spec: N-000330, N-000331, N-000332, N-000333, N-000334, N-000335, N-000336
# spec: N-000337, N-000338, N-000339, N-000340, N-000341, N-000342, N-000343
# spec: N-000344, N-000345, N-000346, N-000347, N-000348, N-000349, N-000350
# spec: N-000351, N-000352, N-000353, N-000354, N-000355, N-000356, N-000357
# spec: N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364
# spec: N-000365, N-000366, N-000367, N-000368, N-000369, N-000370, N-000371
# spec: N-000372, N-000373, N-000374, N-000375, N-000376, N-000377, N-000378
# spec: N-000379, N-000380, N-000381, N-000382, N-000383
# spec: N-000583, N-000584, N-000585, N-000586, N-000587, N-000548, N-000549
# spec: N-000550, N-000551, N-000552, N-000553, N-000554, N-000555, N-000556
# spec: N-000557, N-000558, N-000559, N-000560, N-000561, N-000562, N-000563
# spec: N-000564, N-000565, N-000566, N-000567, N-000568, N-000569, N-000570
# spec: N-000571, N-000572, N-000573, N-000574, N-000575, N-000576, N-000577
# spec: N-000912, N-000714, N-000703
"""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid
from typing import Any, Iterable

from ._files import open_stream
from .exceptions import BadParameter, DeclarationError


class ParamType:
    """Base class for parameter types.

    A subclass sets ``name`` and implements :meth:`convert`.

    # spec: N-000370, N-000371, N-000372, N-000373, N-000374
    """

    name = "text"
    #: separator used when splitting an environment value for this type
    envvar_separator: str | None = None
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message: str, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None) -> str:
        return self.name.upper()

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        return []

    def split_envvar(self, raw: str) -> list[str]:
        if self.envvar_separator is not None:
            return [part for part in raw.split(self.envvar_separator)]
        return raw.split()

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    """Unicode text (the default).

    # spec: N-000332
    """

    name = "string"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    """Pass-through: the raw token is delivered unchanged.

    # spec: N-000369
    """

    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    """Integers only.

    # spec: N-000333, N-000334, N-000335, N-000336
    """

    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, bool):
            return int(value)
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    """Floating-point numbers.

    # spec: N-000337, N-000338
    """

    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


BOOL_TRUE = frozenset(["1", "true", "t", "yes", "y", "on"])
BOOL_FALSE = frozenset(["0", "false", "f", "no", "n", "off"])


class BoolParamType(ParamType):
    """Booleans from text: true/false words, case-insensitive.

    # spec: N-000339, N-000340, N-000341, N-000342, N-000343, N-000344, N-000345
    """

    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in BOOL_TRUE:
            return True
        if text in BOOL_FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    """UUID text to a ``uuid.UUID``.

    # spec: N-000346, N-000347
    """

    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class FuncParamType(ParamType):
    """Wraps a conversion function that refuses by raising ``ValueError``.

    # spec: N-000885, N-000370, N-000374
    """

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"
        self.name = self.name.replace("_", " ").lower() if self.name != "<lambda>" else "text"

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration.

    # spec: N-000348, N-000349, N-000350, N-000351, N-000352, N-000382, N-000383
    """

    name = "choice"

    def __init__(self, choices: Iterable[Any], case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._pairs = [(member.name, member) for member in choices]
        else:
            self._pairs = [(str(choice), choice) for choice in choices]
        self.choices = [orig for _, orig in self._pairs]

    def get_metavar(self, param=None) -> str:
        return "[" + "|".join(name for name, _ in self._pairs) + "]"

    def convert(self, value, param=None, ctx=None):
        for _, orig in self._pairs:
            if value is orig or (not isinstance(value, str) and value == orig):
                return orig
        if isinstance(value, enum.Enum):
            value = value.name
        text = str(value)
        probe = text if self.case_sensitive else text.casefold()
        for name, orig in self._pairs:
            candidate = name if self.case_sensitive else name.casefold()
            if probe == candidate:
                return orig
        choices_text = ", ".join(repr(name) for name, _ in self._pairs)
        self.fail(f"{value!r} is not one of {choices_text}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        from .shell_completion import CompletionItem

        out = []
        for name, _ in self._pairs:
            cand = name
            if self.case_sensitive:
                ok = cand.startswith(incomplete)
            else:
                ok = cand.casefold().startswith(incomplete.casefold())
            if ok:
                out.append(CompletionItem(cand))
        return out


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    """Parses text into a naive ``datetime.datetime``.

    # spec: N-000353, N-000354, N-000355, N-000356, N-000357
    """

    name = "datetime"

    def __init__(self, formats=None) -> None:
        # The author's list replaces the default list (it does not extend it).
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip() if not isinstance(value, str) else value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class _RangeMixin:
    def _range_text(self) -> str:
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def _check_bounds(self, value, param, ctx, base_type, adjust_low, adjust_high):
        if self.min is not None:
            if value < self.min or (self.min_open and value == self.min):
                if self.clamp:
                    return adjust_low()
                self.fail(f"{value} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if value > self.max or (self.max_open and value == self.max):
                if self.clamp:
                    return adjust_high()
                self.fail(f"{value} is not in the range {self._range_text()}.", param, ctx)
        return value


class IntRange(_RangeMixin, IntParamType):
    """Integers within an optional range.

    # spec: N-000358, N-000359, N-000360, N-000361, N-000362, N-000940
    """

    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = bool(min_open) and min is not None
        self.max_open = bool(max_open) and max is not None
        self.clamp = bool(clamp)
        if min is not None and max is not None and min > max:
            raise DeclarationError("IntRange: min is greater than max.")

    def convert(self, value, param=None, ctx=None):
        v = IntParamType.convert(self, value, param, ctx)

        def low():
            # Open bound: the adjacent integer inside the range.
            return self.min + 1 if self.min_open else self.min

        def high():
            return self.max - 1 if self.max_open else self.max

        return self._check_bounds(v, param, ctx, int, low, high)


class FloatRange(_RangeMixin, FloatParamType):
    """Floats within an optional range.

    # spec: N-000363, N-000364, N-000365, N-000381, N-000943
    """

    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = bool(min_open) and min is not None
        self.max_open = bool(max_open) and max is not None
        self.clamp = bool(clamp)
        if self.clamp and (self.min_open or self.max_open):
            # Clamp is only allowed when both bounds are closed (PRD FP-05).
            raise DeclarationError("FloatRange: clamp is not allowed when a bound is open.")
        if min is not None and max is not None and min > max:
            raise DeclarationError("FloatRange: min is greater than max.")

    def convert(self, value, param=None, ctx=None):
        v = FloatParamType.convert(self, value, param, ctx)
        return self._check_bounds(
            v, param, ctx, float, lambda: self.min, lambda: self.max
        )


def convert_type(ty) -> ParamType:
    """Turn a user-supplied ``type=`` value into a ParamType instance.

    # spec: N-000885, N-000937, N-000938
    """
    if ty is None:
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if issubclass(ty, ParamType):
            return ty()
        if ty is str:
            return STRING
        if ty is int:
            return INT
        if ty is float:
            return FLOAT
        if ty is bool:
            return BOOL
        if ty is _uuid.UUID:
            return UUID
    if callable(ty):
        return FuncParamType(ty)
    raise DeclarationError(f"Unsupported parameter type: {ty!r}")


class Tuple(ParamType):
    """A fixed-length product of inner types.

    # spec: N-000366, N-000938
    """

    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [convert_type(t) for t in types]
        if not self.types:
            raise DeclarationError("Tuple requires at least one type.")

    @property
    def arity(self) -> int:
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, tuple) and len(value) == len(self.types):
            return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))
        if isinstance(value, (list, tuple)) and len(value) != len(self.types):
            self.fail(f"Takes {len(self.types)} values but {len(value)} were given.", param, ctx)
        self.fail(f"{value!r} is not a valid tuple.", param, ctx)


class FileParamType(ParamType):
    """Opens a file; the value is an open file object.

    # spec: N-000367, N-000528, N-000529, N-000530, N-000531, N-000532, N-000533
    # spec: N-000534, N-000535, N-000536, N-000537, N-000538, N-000539, N-000540
    # spec: N-000541, N-000542, N-000543, N-000544, N-000545, N-000546, N-000547
    # spec: N-000574, N-000578, N-000579, N-000580, N-000581, N-000582, N-000945
    """

    name = "filename"
    envvar_separator = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding=None,
        errors: str = "strict",
        lazy=None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"File mode must be one of r, w, rb, wb, not {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        path = os.fspath(value) if not isinstance(value, str) else value
        reading = "r" in self.mode
        lazy = self.lazy if self.lazy is not None else (not reading)
        if path == "-":
            return open_stream("-", self.mode, self.encoding, self.errors)
        try:
            f = open_stream(
                path,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"Could not open file {path!r}: {e.strerror or e}", param, ctx)
        if ctx is not None and hasattr(f, "close"):
            ctx.call_on_close(f.close)
        return f


class PathParamType(ParamType):
    """Validates a filesystem path; the value is the path.

    # spec: N-000368, N-000548, N-000549, N-000550, N-000551, N-000552, N-000553
    # spec: N-000554, N-000555, N-000556, N-000557, N-000558, N-000559, N-000560
    # spec: N-000561, N-000562, N-000563, N-000564, N-000565, N-000566, N-000567
    # spec: N-000568, N-000569, N-000570, N-000571, N-000572, N-000573, N-000583
    # spec: N-000584, N-000585, N-000586, N-000587, N-000574, N-000946, N-000947, N-000948
    """

    name = "path"
    envvar_separator = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type=None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        if self.allow_dash and value == "-":
            return self._result("-")
        rv = os.fspath(value) if not isinstance(value, str) else value
        if self.resolve_path:
            # Symlinks resolved to the real target; a leading tilde is not expanded.
            rv = os.path.realpath(rv)
        exists = os.path.exists(rv)
        if not exists:
            if self.exists:
                self.fail(f"{rv!r} does not exist.", param, ctx)
        else:
            if not self.file_okay and os.path.isfile(rv):
                self.fail(f"{rv!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(rv):
                self.fail(f"{rv!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{rv!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{rv!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{rv!r} is not executable.", param, ctx)
        return self._result(rv)

    def _result(self, rv: str):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def shell_complete(self, ctx, param, incomplete: str) -> list:
        from .shell_completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


File = FileParamType
Path = PathParamType

STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BUILTIN_TYPE_NAMES = {
    StringParamType: "string",
}


def infer_type_from_default(default) -> ParamType:
    """Infer a parameter type from a default value (used when no type is given).

    # spec: N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000188
    """
    if default is None or callable(default):
        return STRING
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)) and default:
        return infer_type_from_default(default[0])
    return STRING
