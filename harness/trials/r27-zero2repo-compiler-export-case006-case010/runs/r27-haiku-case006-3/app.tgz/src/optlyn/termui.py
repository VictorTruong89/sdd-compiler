"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch.

# spec: N-000981, N-000982, N-000983, N-000984, N-000985, N-000986, N-000987
# spec: N-000988, N-000989, N-000990, N-000991, N-000992, N-000993, N-000994
# spec: N-000995, N-000996, N-000997, N-000998, N-000999, N-001000, N-001001
# spec: N-001002, N-001003, N-001004, N-001005, N-001006, N-001007, N-001008
# spec: N-001010, N-001011, N-001012, N-000618, N-000619, N-000620, N-000621
# spec: N-000622, N-000623, N-000624, N-000625, N-000626, N-000627, N-000628
# spec: N-000629, N-000630, N-000631, N-000632, N-000633, N-000634, N-000635
# spec: N-000636, N-000637, N-000638, N-000639, N-000640, N-000641, N-000642
# spec: N-000643, N-000644, N-000645, N-000646, N-000647, N-000648, N-000649
# spec: N-000650, N-000651, N-000652, N-000653, N-000654, N-000655, N-000656
# spec: N-000657, N-000658, N-000659, N-000660, N-000661, N-000662, N-000663
# spec: N-000664, N-000665, N-000666, N-000667, N-000668, N-000669, N-000670
# spec: N-000671, N-000672, N-000673, N-000674, N-000675, N-000676, N-000677
# spec: N-000678, N-000679, N-000680, N-000681, N-000682, N-000683, N-000684
# spec: N-000685, N-000686, N-000687, N-000688, N-000501, N-000502, N-000503
# spec: N-000504, N-000505, N-000506, N-000507, N-000508, N-000509, N-000484
# spec: N-000485, N-000486, N-000487, N-000513, N-000514, N-000515, N-000516
# spec: N-000517, N-000518, N-000519, N-000524, N-000525, N-000526, N-000527
"""

from __future__ import annotations

import contextlib
import getpass
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from ._context import get_current_context
from .exceptions import Abort, BadParameter, DeclarationError

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_FG = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
    "reset": 39,
}
_BG = {name: code + 10 for name, code in _FG.items() if name != "reset"}
_BG["reset"] = 49


def _is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _should_strip(stream, color) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences, leaving other text unchanged.

    # spec: N-000640
    """
    return _ANSI_RE.sub("", text)


def _color_code(value, background: bool) -> str:
    table = _BG if background else _FG
    prefix = "48" if background else "38"
    if isinstance(value, str):
        if value not in table:
            raise TypeError(f"Unknown color {value!r}.")
        return str(table[value])
    if isinstance(value, bool):
        raise TypeError(f"Invalid color {value!r}.")
    if isinstance(value, int):
        if not 0 <= value <= 255:
            raise TypeError(f"Color number out of range: {value}.")
        return f"{prefix};5;{value}"
    if isinstance(value, (tuple, list)) and len(value) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in value
    ):
        return f"{prefix};2;{value[0]};{value[1]};{value[2]}"
    raise TypeError(f"Invalid color {value!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
) -> str:
    """Wrap ``text`` in ANSI styling codes.

    # spec: N-000628, N-000629, N-000630, N-000631, N-000632, N-000633, N-000634
    # spec: N-000635, N-000636, N-000637, N-000638, N-000639, N-000986, N-000990
    """
    bits: list[str] = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    switches = [
        (bold, "1", "22"),
        (dim, "2", "22"),
        (italic, "3", "23"),
        (underline, "4", "24"),
        (blink, "5", "25"),
        (reverse, "7", "27"),
        (strikethrough, "9", "29"),
        (overline, "53", "55"),
    ]
    for flag, on, off in switches:
        if flag is True:
            bits.append(on)
        elif flag is False:
            bits.append(off)
    text = str(text)
    if not bits:
        return text
    prefix = "\x1b[" + ";".join(bits) + "m"
    return prefix + text + ("\x1b[0m" if reset else "")


def _write_text(stream, text: str) -> None:
    encoding = getattr(stream, "encoding", None) or "utf-8"
    try:
        text.encode(encoding)
    except (UnicodeEncodeError, LookupError):
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()
            return
    stream.write(text)


def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Write text (or bytes) to stdout, stderr, or ``file``.

    # spec: N-000619, N-000620, N-000621, N-000622, N-000623, N-000624, N-000625
    # spec: N-000626, N-000627, N-000681, N-000682, N-000683
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buf = getattr(file, "buffer", None)
        file.flush()
        if buf is not None:
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
            file.flush()
        return
    text = str(message)
    if _should_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    file.flush()


_echo = echo


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    """Echo styled text in one step.

    # spec: N-000628, N-000641
    """
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _interactive() -> bool:
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _read_line(hidden: bool = False) -> str:
    stream = sys.stdin
    if stream is None:
        raise Abort()
    if hidden and _is_tty(stream):
        try:
            return getpass.getpass("")
        except EOFError as e:
            raise Abort() from e
    line = stream.readline()
    if line == "" or line is None:
        raise Abort()
    return line.rstrip("\r\n")


def _visible_read(hidden: bool) -> str:
    line = _read_line(hidden=hidden)
    if not hidden:
        # Runner input echoes what was typed into the captured output.
        if getattr(sys.stdin, "_optlyn_echo_prompts", False):
            echo(line)
    return line


def prompt(
    text,
    default=None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
):
    """Ask for a value and return it converted. Re-asks on conversion failure.

    # spec: N-000488, N-000489, N-000490, N-000491, N-000501, N-000510, N-000511
    # spec: N-000512, N-000520, N-000521, N-000522, N-000523, N-000524
    # spec: N-000988
    """
    from .paramtypes import convert_type, infer_type_from_default

    if type is not None:
        ptype = convert_type(type)
    else:
        ptype = infer_type_from_default(default)
    while True:
        shown = text
        if default is not None and show_default and not hide_input:
            shown = f"{text} [{default}]"
        echo(shown + prompt_suffix, nl=False, err=err)
        value = _visible_read(hide_input)
        if value == "" and default is not None:
            value = default
        try:
            converted = ptype.convert(value, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)
            continue
        if confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, nl=False, err=err)
            second = _visible_read(True)
            if second != value and not (value == default and second == ""):
                echo("Error: The two entered values do not match.", err=True)
                continue
        return converted


def confirm(
    text,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. Returns a bool; may abort on "no".

    # spec: N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507
    # spec: N-000508, N-000509, N-000513, N-000514, N-000515, N-000516, N-000517
    # spec: N-000518, N-000519, N-000524
    """
    if show_default:
        hint = "[Y/n]" if default else "[y/N]"
        shown = f"{text} {hint}"
    else:
        shown = text
    while True:
        echo(shown + prompt_suffix, nl=False, err=err)
        value = _visible_read(False).strip().lower()
        if value == "":
            answer = default
        elif value in ("y", "yes"):
            answer = True
        elif value in ("n", "no"):
            answer = False
        else:
            echo("Error: invalid input", err=True)
            continue
        break
    if not answer and abort:
        raise Abort()
    return answer


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal (the controlling terminal if any).

    # spec: N-000658, N-000659, N-000660, N-000661
    """
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
    except (ImportError, OSError):
        fd = None
    if fd is not None:
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    else:
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        _echo(ch, nl=False)
    return ch


def pause(info=None, err: bool = False) -> None:
    """Print a message and wait for a key when interactive; never block otherwise.

    # spec: N-000662, N-000663, N-000686, N-000687
    """
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    if _interactive():
        try:
            getchar()
        except EOFError:
            pass
    echo("", err=err)


def clear() -> None:
    """Clear the screen when attached to a terminal; otherwise do nothing.

    # spec: N-000672, N-000673
    """
    if _is_tty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


class ProgressBar:
    """Iterable progress bar. Iterating yields the original items.

    # spec: N-000649, N-000650, N-000651, N-000652, N-000653, N-000654, N-000655
    # spec: N-000656, N-000657, N-000684, N-000685
    """

    def __init__(self, iterable, length, label, hidden, file=None, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = bool(hidden)
        self.pos = 0
        self.start = time.time()
        self.file = file or sys.stdout
        self.is_tty = (not self.hidden) and _is_tty(self.file)
        self.options = options

    def __enter__(self):
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label, file=self.file)
        self._render()
        return self

    def __exit__(self, *exc) -> None:
        if self.is_tty:
            echo("", file=self.file)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self._render()

    def _render(self) -> None:
        if not self.is_tty:
            return
        elapsed = time.time() - self.start
        width = 30
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(width * frac)
            bar = "#" * filled + "-" * (width - filled)
            remaining = (elapsed / self.pos) * (self.length - self.pos) if self.pos else 0
            eta = f" eta {int(remaining)}s"
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length}{eta}"
        else:
            text = f"\r{self.label} {self.pos}"
        self.file.write(text)
        self.file.flush()


def progressbar(iterable=None, length=None, label=None, hidden: bool = False, **options):
    """Return a progress bar context manager.

    # spec: N-000649, N-000657
    """
    return ProgressBar(iterable, length, label, hidden, **options)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager when interactive.

    # spec: N-000641, N-000642, N-000645, N-000646, N-000648
    """
    if _interactive() and os.environ.get("PAGER"):
        cmd = shlex.split(os.environ["PAGER"])
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True)
        try:
            yield proc.stdin
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            proc.wait()
    else:
        from ._files import NonClosingStream

        yield NonClosingStream(sys.stdout)


def echo_via_pager(text_or_generator, color=None) -> None:
    """Write text through a pager when interactive; otherwise to stdout.

    # spec: N-000641, N-000642, N-000643, N-000644, N-000645, N-000646, N-000647
    # spec: N-000648
    """
    if callable(text_or_generator):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    with get_pager_file(color) as out:
        for chunk in chunks:
            out.write(chunk)
            if hasattr(out, "flush"):
                out.flush()


def edit(
    text=None,
    editor=None,
    env=None,
    require_save: bool = True,
    extension: str = ".txt",
    filename=None,
):
    """Open an editor on text or a file. Returns the saved text, or None.

    # spec: N-000664, N-000665, N-000666
    # spec: N-000993, N-000994, N-000995, N-000996, N-000997, N-000998, N-000999
    """
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor_cmd:
        editor_cmd = "notepad" if sys.platform.startswith("win") else "vi"
    run_env = dict(os.environ)
    if env:
        run_env.update(env)

    def run(path: str) -> None:
        args = shlex.split(editor_cmd) + [path]
        subprocess.call(args, env=run_env)

    if filename is not None:
        run(os.fspath(filename))
        return None

    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        original = text or ""
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(original)
        mtime_before = os.path.getmtime(path)
        run(path)
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
        if require_save and result == original and os.path.getmtime(path) == mtime_before:
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or path with the default application. Returns a status value.

    # spec: N-000667, N-000668, N-000669, N-000670, N-000671
    # spec: N-001000, N-001001, N-001002
    """
    target = url
    if locate and os.path.exists(url):
        target = os.path.dirname(os.path.abspath(url)) if os.path.isfile(url) else url
    if sys.platform.startswith("win"):
        os.startfile(target)  # type: ignore[attr-defined]
        return 0
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    try:
        proc = subprocess.Popen([opener, target])
    except OSError:
        return 1
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for an application.

    # spec: N-000674, N-000675, N-000676, N-000677, N-000678, N-001003, N-001004, N-001005, N-001006
    """
    home = os.path.expanduser("~")
    if force_posix:
        folder = "." + _unix_folder(app_name)
        return os.path.join(home, folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, _unix_folder(app_name))


def _unix_folder(app_name: str) -> str:
    return re.sub(r"\s+", "-", app_name.lower())


def format_filename(filename, shorten: bool = False) -> str:
    """Return printable text for a path that may not be Unicode.

    # spec: N-000575, N-000576, N-000577
    """
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def open_file(
    filename,
    mode: str = "r",
    encoding=None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
):
    """Open a file, or a standard stream for ``-``.

    # spec: N-000528, N-000529, N-000530, N-000531, N-000532, N-000533, N-000534
    # spec: N-000535, N-000536, N-000537, N-000538, N-000539, N-000540, N-000541
    # spec: N-000542, N-000543, N-000544, N-000545, N-000546, N-000547, N-000588
    # spec: N-000589, N-000590, N-000679
    """
    from ._files import open_stream

    if mode not in ("r", "w", "rb", "wb"):
        raise DeclarationError(f"Unsupported mode {mode!r}.")
    return open_stream(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)


def get_text_stream(name: str):
    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    return stream
