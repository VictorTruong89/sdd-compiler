"""Shell completion: registration scripts and suggestion output.

# spec: N-001013, N-001014, N-001015, N-001016, N-001017, N-001018, N-001019
# spec: N-001020, N-001021, N-001022, N-001023, N-001024, N-001025, N-001026
# spec: N-001027, N-001028, N-001029, N-001030, N-001031, N-001032, N-001033
# spec: N-001034, N-001035, N-001036, N-001037, N-000689, N-000690, N-000691
# spec: N-000692, N-000693, N-000694, N-000695, N-000696, N-000697, N-000698
# spec: N-000699, N-000700, N-000701, N-000702, N-000703, N-000704, N-000705
# spec: N-000706, N-000707, N-000708, N-000709, N-000710, N-000711, N-000712
# spec: N-000713, N-000714, N-000715
"""

from __future__ import annotations

import os

from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "__optlyn_path_file__"
PATH_DIR = "__optlyn_path_dir__"


class CompletionItem:
    """A suggestion: a value, its help text, and its type ("plain" for values)."""

    def __init__(self, value, help=None, type="plain") -> None:
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _script(shell: str, prog: str, var: str) -> str:
    if shell == "bash":
        func = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"{func}() {{\n"
            f"    local response completion\n"
            f"    response=$(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete \"$1\")\n"
            f"    COMPREPLY=()\n"
            f"    local IFS=$'\\n'\n"
            f"    for completion in $response; do\n"
            f"        case \"$completion\" in\n"
            f"            {PATH_FILE}*|{PATH_DIR}*) compopt -o default ;;\n"
            f"            *) COMPREPLY+=(\"${{completion%%$'\\t'*}}\") ;;\n"
            f"        esac\n"
            f"    done\n"
            f"}}\n"
            f"complete -o default -F {func} {prog}\n"
        )
    if shell == "zsh":
        func = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"#compdef {prog}\n"
            f"{func}() {{\n"
            f"    local -a response\n"
            f"    response=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}\")\n"
            f"    _describe 'values' response\n"
            f"}}\n"
            f"compdef {func} {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"\"(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})\"\n"
        )
    # powershell
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete.Length\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{\n"
        f"        [System.Management.Automation.CompletionResult]::new($_, $_, "
        f"'ParameterValue', $_)\n"
        f"    }}\n"
        f"    Remove-Item Env:{var}\n"
        f"}}\n"
    )


def _split_words(shell: str):
    words_text = os.environ.get("COMP_WORDS", "")
    words = [w for w in words_text.split(" ") if w != ""]
    raw_cword = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = raw_cword
        args = words[1:]
        if incomplete and args and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        cword = int(raw_cword)
    except ValueError:
        cword = len(words)
    incomplete = words[cword] if 0 <= cword < len(words) else ""
    args = words[1:cword] if cword > 0 else []
    return args, incomplete


def _walk(cli, prog: str, args: list[str]):
    """Descend into subcommands named on the line. Returns (command, ctx, rest)."""
    from .core import Context

    ctx = Context(cli, info_name=prog)
    cmd = cli
    rest: list[str] = []
    i = 0
    while i < len(args):
        tok = args[i]
        if getattr(cmd, "is_group", False) and not tok.startswith("-"):
            child = cmd.get_command(ctx, tok)
            if child is not None:
                ctx = Context(child, parent=ctx, info_name=tok)
                cmd = child
                rest = []
                i += 1
                continue
        rest.append(tok)
        i += 1
    return cmd, ctx, rest


def _expects_value(cmd, ctx, args: list[str]):
    """If the last token is an option waiting for its value, return that option."""
    if not args:
        return None
    last = args[-1]
    if not last.startswith("-") or "=" in last:
        return None
    from .core import Option

    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and last in p.opts and not p.is_flag:
            return p
    return None


def _complete(cli, prog: str, args: list[str], incomplete: str) -> list[CompletionItem]:
    from .core import Argument, Option

    cmd, ctx, rest = _walk(cli, prog, args)
    params = cmd.get_params(ctx)
    options = [p for p in params if isinstance(p, Option) and not p.hidden]
    waiting = _expects_value(cmd, ctx, rest)
    if waiting is not None:
        return _value_items(ctx, waiting, incomplete)
    if incomplete.startswith("-"):
        out: list[CompletionItem] = []
        for p in options:
            for name in p.get_flag_names(ctx):
                if name.startswith(incomplete):
                    out.append(CompletionItem(name, help=p.help))
        return out

    if getattr(cmd, "is_group", False):
        out = []
        for name in sorted(cmd.list_commands(ctx)):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            out.append(CompletionItem(name, help=child.get_short_help_str()))
        return out

    positional = [t for t in rest if not t.startswith("-")]
    arguments = [p for p in params if isinstance(p, Argument)]
    index = len(positional)
    if index < len(arguments):
        return _type_items(ctx, arguments[index], incomplete)
    return []


def _value_items(ctx, param, incomplete: str) -> list[CompletionItem]:
    return _type_items(ctx, param, incomplete)


def _type_items(ctx, param, incomplete: str) -> list[CompletionItem]:
    if param.shell_complete is not None:
        found = param.shell_complete(ctx, param, incomplete)
    else:
        found = param.type.shell_complete(ctx, param, incomplete)
    out: list[CompletionItem] = []
    for item in found or []:
        if isinstance(item, CompletionItem):
            out.append(item)
        elif isinstance(item, str):
            out.append(CompletionItem(item))
        else:
            out.append(
                CompletionItem(
                    getattr(item, "value", str(item)),
                    help=getattr(item, "help", None),
                    type=getattr(item, "type", "plain") or "plain",
                )
            )
    return out


def _render(items: list[CompletionItem], shell: str, incomplete: str) -> list[str]:
    lines: list[str] = []
    for item in items:
        if item.type == "file":
            lines.append(f"{PATH_FILE}\t{incomplete}")
            continue
        if item.type == "dir":
            lines.append(f"{PATH_DIR}\t{incomplete}")
            continue
        if item.type != "plain":
            continue
        if item.help and shell == "zsh":
            lines.append(f"{item.value}:{item.help}".replace("\n", " "))
        elif item.help and shell == "fish":
            lines.append(f"{item.value}\t{item.help}".replace("\n", " "))
        else:
            lines.append(item.value)
    return lines


def run(cli, prog: str, instruction: str, args, extra) -> int:
    """Handle the completion environment variable. Returns the exit status.

    # spec: N-001022, N-001023, N-001024, N-001025, N-001026, N-001027, N-001028
    # spec: N-001021, N-000701, N-000702, N-000703, N-000704, N-000714, N-000715
    """
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    var = "_" + prog.replace("-", "_").upper() + "_COMPLETE"
    if action == "source":
        echo(_script(shell, prog, var), nl=False)
        return 0
    cword_args, incomplete = _split_words(shell)
    items = _complete(cli, prog, cword_args, incomplete)
    for line in _render(items, shell, incomplete):
        echo(line)
    return 0
