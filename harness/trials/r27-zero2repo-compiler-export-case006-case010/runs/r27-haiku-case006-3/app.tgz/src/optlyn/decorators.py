"""Declaration decorators: command, group, option, argument, and ready-made options.

# spec: N-000850, N-000851, N-000852, N-000853, N-000862, N-000863, N-000864
# spec: N-000881, N-000882, N-000883, N-000884, N-000909, N-000910, N-000911
# spec: N-000912, N-000924, N-000925, N-000926, N-000927, N-000928, N-000929
# spec: N-000930, N-000931, N-000932, N-000975, N-000976, N-000977
# spec: N-000079, N-000080, N-000081, N-000082, N-000095, N-000096, N-000180
# spec: N-000484, N-000484, N-000485, N-000486, N-000487, N-000513, N-000516
# spec: N-000110, N-000114, N-000115, N-000116, N-000117, N-000162, N-000163
# spec: N-000164, N-000165, N-000166, N-000167, N-000168, N-000169, N-000155
# spec: N-000156, N-000157, N-000158, N-000159, N-000160, N-000161, N-000176
"""

from __future__ import annotations

import functools
import importlib.metadata as _md
import inspect
from typing import Callable

from ._context import get_current_context
from .core import Argument, Command, Group, Option, Parameter
from .exceptions import DeclarationError, Exit
from .formatting import process_help_text
from .termui import confirm, echo

_PARAMS_ATTR = "__optlyn_params__"
_NAME_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach(f, param: Parameter) -> None:
    params = list(getattr(f, _PARAMS_ATTR, []))
    params.append(param)
    setattr(f, _PARAMS_ATTR, params)


def _pop_params(f) -> list[Parameter]:
    params = list(getattr(f, _PARAMS_ATTR, []))
    if hasattr(f, _PARAMS_ATTR):
        delattr(f, _PARAMS_ATTR)
    # Decorators apply bottom-up; declarations read top-down.
    return list(reversed(params))


def _default_name(fname: str) -> str:
    """Derive a command name from a function name.

    # spec: N-000079, N-000080, N-000081
    """
    name = fname.lower()
    for suffix in _NAME_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _build_command(f, name, cls, attrs, is_group, register_on):
    params = _pop_params(f)
    if name is None:
        name = _default_name(f.__name__)
    attrs = dict(attrs)
    if "help" in attrs and attrs["help"] is not None:
        help_text = attrs.pop("help").replace("\f", "")
    else:
        attrs.pop("help", None)
        help_text = process_help_text(inspect.cleandoc(f.__doc__) if f.__doc__ else "")
    if cls is None:
        cls = Group if is_group else Command
    if not issubclass(cls, Command):
        raise DeclarationError("cls must be a Command subclass.")
    cmd = cls(name=name, callback=f, params=params, help=help_text, **attrs)
    if register_on is not None:
        register_on.add_command(cmd)
    return cmd


def _make_decorator(is_group: bool, name, cls, register_on, attrs):
    def decorator(f):
        return _build_command(f, name, cls, attrs, is_group, register_on)

    return decorator


def command(name=None, cls=None, _register_on=None, **attrs):
    """Declare a command from a function.

    # spec: N-000850, N-000851, N-000852, N-000853, N-000855, N-000856
    """
    if callable(name) and not isinstance(name, str):
        f = name
        return _build_command(f, None, cls, attrs, False, _register_on)
    return _make_decorator(False, name, cls, _register_on, attrs)


def group(name=None, cls=None, _register_on=None, **attrs):
    """Declare a group from a function.

    # spec: N-000862, N-000863, N-000864, N-000865, N-000866, N-000867, N-000868
    """
    if callable(name) and not isinstance(name, str):
        f = name
        return _build_command(f, None, cls, attrs, True, _register_on)
    return _make_decorator(True, name, cls, _register_on, attrs)


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function it decorates.

    # spec: N-000881, N-000882, N-000883, N-000884, N-000909
    """
    option_cls = cls or Option

    def decorator(f):
        _attach(f, option_cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function it decorates.

    # spec: N-000910, N-000911, N-000912
    """
    arg_cls = cls or Argument

    def decorator(f):
        _attach(f, arg_cls(list(param_decls), **attrs))
        return f

    return decorator


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    raise Exit(0)


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. Prints help and exits.

    # spec: N-000929, N-000155, N-000156, N-000176
    """
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        opt = Option(
            decls,
            is_flag=True,
            expose_value=False,
            is_eager=True,
            callback=_help_callback,
            **kwargs,
        )
        _attach(f, opt)
        return f

    return decorator


def _detect_version(package_name: str | None) -> str:
    """Version of an installed distribution, falling back to the import name.

    # spec: N-000162, N-000163, N-000164, N-000165, N-000166
    """
    if package_name is None:
        return "unknown"
    try:
        return _md.version(package_name)
    except _md.PackageNotFoundError:
        pass
    try:
        dists = _md.packages_distributions().get(package_name, [])
    except Exception:
        dists = []
    for dist in dists:
        try:
            return _md.version(dist)
        except _md.PackageNotFoundError:
            continue
    return "unknown"


def version_option(
    version=None,
    *param_decls,
    package_name=None,
    prog_name=None,
    message=None,
    **kwargs,
):
    """Eager version flag printing a version identity and exiting.

    # spec: N-000924, N-000930, N-000931, N-000167, N-000168, N-000169
    """
    if version is None and package_name is None:
        frame = inspect.currentframe()
        caller = frame.f_back if frame is not None else None
        module = caller.f_globals.get("__name__", "") if caller is not None else ""
        package_name = module.split(".")[0] or None
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx is None:
            return
        ver = version if version is not None else _detect_version(package_name)
        root = ctx
        while root.parent is not None:
            root = root.parent
        prog = prog_name or root.info_name
        text = message if message is not None else "%(prog)s, version %(version)s"
        echo(text % {"prog": prog, "version": ver}, color=ctx.color)
        raise Exit(0)

    def decorator(f):
        _attach(
            f,
            Option(
                decls,
                is_flag=True,
                expose_value=False,
                is_eager=True,
                callback=callback,
                **kwargs,
            ),
        )
        return f

    return decorator


def custom_version_option(callback_fn: Callable, *param_decls, **kwargs):
    """Eager version flag whose identity is the string returned by ``callback_fn(ctx)``.

    # spec: N-000932, N-000167, N-000168, N-000169
    """
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx is None:
            return
        echo(callback_fn(ctx), color=ctx.color)
        raise Exit(0)

    def decorator(f):
        _attach(
            f,
            Option(
                decls,
                is_flag=True,
                expose_value=False,
                is_eager=True,
                callback=callback,
                **kwargs,
            ),
        )
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option.

    # spec: N-000925, N-000484, N-000485, N-000486, N-000487
    """
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A confirmation flag: asks when omitted, aborts when declined.

    # spec: N-000928, N-000513, N-000514, N-000515, N-000516, N-000517, N-000518
    # spec: N-000519
    """
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, abort=True)
        return value

    def decorator(f):
        _attach(
            f,
            Option(
                decls,
                is_flag=True,
                expose_value=False,
                callback=callback,
                **kwargs,
            ),
        )
        return f

    return decorator


def pass_context(f):
    """Pass the current context as the first argument.

    # spec: N-000975, N-000976
    """

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first argument.

    # spec: N-000977, N-000434, N-000435, N-000436, N-000437, N-000438
    """

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        ctx = get_current_context()
        return f(ctx.obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure: bool = False):
    """Build a decorator passing the nearest object of ``object_type``.

    # spec: N-000976, N-000977, N-000439, N-000440, N-000441, N-000442, N-000443
    """

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator
