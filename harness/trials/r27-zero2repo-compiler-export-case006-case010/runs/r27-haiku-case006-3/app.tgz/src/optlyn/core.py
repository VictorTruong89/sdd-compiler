"""Core model: contexts, parameters, the argument parser, commands and groups.

# spec: N-000850, N-000851, N-000852, N-000853, N-000854, N-000855, N-000856
# spec: N-000857, N-000858, N-000859, N-000860, N-000861, N-000862, N-000863
# spec: N-000864, N-000865, N-000866, N-000867, N-000868, N-000869, N-000870
# spec: N-000871, N-000872, N-000873, N-000874, N-000875, N-000876, N-000877
# spec: N-000878, N-000879, N-000880, N-000881, N-000882, N-000883, N-000884
# spec: N-000885, N-000886, N-000887, N-000888, N-000889, N-000890, N-000891
# spec: N-000892, N-000893, N-000894, N-000895, N-000896, N-000897, N-000898
# spec: N-000899, N-000900, N-000901, N-000902, N-000903, N-000904, N-000905
# spec: N-000906, N-000907, N-000908, N-000909, N-000910, N-000911, N-000912
# spec: N-000913, N-000914, N-000915, N-000916, N-000917, N-000918, N-000919
# spec: N-000920, N-000921, N-000922, N-000923, N-000933, N-000934, N-000935
# spec: N-000950, N-000951, N-000952, N-000953, N-000954, N-000955, N-000956
# spec: N-000957, N-000958, N-000959, N-000960, N-000961, N-000962, N-000963
# spec: N-000964, N-000965, N-000966, N-000967, N-000968, N-000969, N-000970
# spec: N-000971, N-000972, N-000973, N-000974, N-000975, N-000976, N-000977
# spec: N-000434, N-000435, N-000436, N-000437, N-000438, N-000439, N-000440
# spec: N-000441, N-000442, N-000443, N-000463, N-000464, N-000465, N-000466
# spec: N-000467, N-000468, N-000469, N-000470, N-000471, N-000472, N-000473
# spec: N-000474, N-000475, N-000476, N-000480, N-000481, N-000482, N-000483
# spec: N-000450, N-000451, N-000452, N-000453, N-000454, N-000455, N-000456
# spec: N-000457, N-000458, N-000459, N-000460, N-000461, N-000462
# spec: N-000444, N-000445, N-000446, N-000447, N-000448, N-000449
# spec: N-000243, N-000244, N-000245, N-000246, N-000247, N-000248, N-000249
# spec: N-000250, N-000251, N-000252, N-000253, N-000254, N-000255, N-000256
# spec: N-000257, N-000258, N-000259, N-000260, N-000261, N-000262, N-000263
# spec: N-000264, N-000265, N-000266, N-000267, N-000283, N-000284
# spec: N-000178, N-000179, N-000180, N-000181, N-000182, N-000183, N-000184
# spec: N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191
# spec: N-000192, N-000193, N-000194, N-000195, N-000196, N-000197, N-000198
# spec: N-000199, N-000200, N-000201, N-000202, N-000203, N-000204, N-000205
# spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000211, N-000212
# spec: N-000213, N-000214, N-000215, N-000216, N-000217, N-000218, N-000219
# spec: N-000220, N-000221, N-000222, N-000223, N-000224, N-000225, N-000226
# spec: N-000227, N-000228, N-000229, N-000230, N-000231, N-000232, N-000233
# spec: N-000234, N-000235, N-000236, N-000237, N-000238, N-000239, N-000240
# spec: N-000241, N-000242, N-000268, N-000269, N-000270, N-000271, N-000272
# spec: N-000273, N-000274, N-000275, N-000276, N-000277, N-000278, N-000279
# spec: N-000280, N-000281, N-000282
# spec: N-000285, N-000286, N-000287, N-000288, N-000289, N-000290, N-000291
# spec: N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298
# spec: N-000299, N-000300, N-000301, N-000302, N-000303, N-000304, N-000305
# spec: N-000306, N-000307, N-000308, N-000309, N-000310, N-000311, N-000312
# spec: N-000313, N-000314, N-000315, N-000316, N-000317, N-000318, N-000319
# spec: N-000320, N-000321, N-000322, N-000323, N-000324, N-000325, N-000326
# spec: N-000327, N-000328, N-000329
# spec: N-000384, N-000385, N-000386, N-000387, N-000388, N-000389, N-000390
# spec: N-000391, N-000392, N-000393, N-000394, N-000395, N-000396, N-000397
# spec: N-000398, N-000399, N-000400, N-000401, N-000402, N-000403, N-000404
# spec: N-000405, N-000406, N-000407, N-000408, N-000409, N-000410, N-000411
# spec: N-000412, N-000413, N-000414, N-000415, N-000416, N-000417, N-000418
# spec: N-000419, N-000420, N-000421, N-000422, N-000423, N-000424, N-000425
# spec: N-000426, N-000427, N-000428, N-000429, N-000430, N-000431, N-000432
# spec: N-000433, N-000079, N-000080, N-000081, N-000082, N-000083, N-000084
# spec: N-000085, N-000086, N-000087, N-000088, N-000089, N-000090, N-000091
# spec: N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
# spec: N-000099, N-000100, N-000101, N-000102, N-000103, N-000104, N-000105
# spec: N-000106, N-000107, N-000108, N-000109, N-000593, N-000594, N-000595
# spec: N-000596, N-000597, N-000598, N-000599, N-000600, N-000601, N-000602
# spec: N-000603, N-000604, N-000605, N-000606, N-000607, N-000608, N-000609
# spec: N-000610, N-000611, N-000612, N-000613, N-000614, N-000615, N-000616
# spec: N-000617, N-000716, N-000717, N-000718, N-000728, N-000729, N-000730
# spec: N-000731, N-000732, N-000733
# Help page layout, exit statuses and output channels (Command.format_help, main):
# spec: N-000803, N-000804, N-000805, N-000806, N-000812, N-000813, N-000814
# spec: N-000815, N-000816, N-000817, N-000818, N-000819, N-000820, N-000821
# spec: N-000823, N-000825, N-000826, N-000827, N-000828, N-000829, N-000831
# spec: N-000832, N-000833, N-000834, N-000835, N-000836, N-000837, N-000838
# spec: N-000839, N-000840, N-000842, N-000843, N-000844, N-000846, N-000847, N-000849
# spec: N-000118, N-000119, N-000120, N-000125, N-000126, N-000127, N-000128
# spec: N-000129, N-000130, N-000131, N-000132, N-000139, N-000140, N-000141
# spec: N-000142, N-000143, N-000144, N-000145, N-000146, N-000147, N-000148
# spec: N-000149, N-000150, N-000151, N-000152, N-000153, N-000154
# spec: N-000764, N-000765, N-000769, N-000770, N-000771, N-000773, N-000774
# spec: N-000591, N-000592, N-000766, N-000767, N-000768
# spec: N-000174, N-000175, N-000732, N-000733, N-000718, N-000716
# Implementer's-choice decisions, taken as stated in the code:
# spec: N-000790, N-000822, N-000824, N-000830, N-000841, N-000845, N-000848
# spec: N-000802, N-000811, N-001037
"""

from __future__ import annotations

import contextlib
import enum
import os
import re
import shutil
import sys
from typing import Any, Callable

from ._context import pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingCommand,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import make_default_short_help, process_help_text, wrap_text
from .paramtypes import (
    BOOL,
    BOOL_FALSE,
    BOOL_TRUE,
    INT,
    Tuple,
    convert_type,
    infer_type_from_default,
)
from .termui import echo

PREFIX_CHARS = "-/+"
_CHAIN = object()  # invoked_subcommand value for chain mode (neither None nor a name)
_NOVALUE = object()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from.

    # spec: N-000463, N-000464, N-000465, N-000466
    """

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

# Settings inherited from the parent context.
_INHERITED = (
    "obj",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
)

_DEFAULT_MAX_CONTENT_WIDTH = 80


def _warn_deprecated(text: str) -> None:
    echo(f"DeprecationWarning: {text}", err=True)


def _envname(prefix: str, dest: str) -> str:
    parts = [p for p in (prefix, dest) if p]
    return "_".join(p.replace("-", "_").upper() for p in parts)


class Context:
    """The state of one invocation of a command.

    # spec: N-000950, N-000951, N-000952, N-000953, N-000954, N-000955, N-000956
    # spec: N-000957, N-000958, N-000959, N-000960, N-000961, N-000962, N-000963
    # spec: N-000964, N-000965, N-000966, N-000967, N-000968, N-000969, N-000970
    # spec: N-000971, N-000972, N-000973, N-000974, N-000975, N-000976, N-000977
    """

    def __init__(
        self,
        command: "Command",
        parent: "Context | None" = None,
        info_name: str | None = None,
        _chain_child: bool = False,
        **settings,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self._chain_child = _chain_child
        self.params: dict[str, Any] = {}
        self.args: list[str] = []
        self.invoked_subcommand = None
        self._protected_name: str | None = None
        self._child_args: list[str] = []
        self._chain_tail: list[str] | None = None
        self._leftover_tail: list[str] | None = None
        self._sources: dict[str, ParameterSource] = {}
        self._exit_stack = contextlib.ExitStack()
        self._closed = False

        merged: dict[str, Any] = {}
        if parent is not None:
            for key in _INHERITED:
                merged[key] = getattr(parent, key)
        merged.update(command.context_settings or {})
        merged.update({k: v for k, v in settings.items() if v is not None})
        self._settings = merged

        self.obj = merged.get("obj")
        self.terminal_width = merged.get("terminal_width")
        self.max_content_width = merged.get("max_content_width", _DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = list(merged.get("help_option_names") or ["--help"])
        self.token_normalize_func = merged.get("token_normalize_func")
        self.color = merged.get("color")
        self.show_default = merged.get("show_default", False)
        self.allow_extra_args = merged.get("allow_extra_args", command.allow_extra_args)
        self.ignore_unknown_options = merged.get(
            "ignore_unknown_options", command.ignore_unknown_options
        )
        self.allow_interspersed_args = merged.get(
            "allow_interspersed_args", command.allow_interspersed_args
        )

        if "auto_envvar_prefix" in merged:
            self.auto_envvar_prefix = merged["auto_envvar_prefix"]
        elif parent is not None and parent.auto_envvar_prefix:
            self.auto_envvar_prefix = (
                f"{parent.auto_envvar_prefix}_{info_name}" if info_name else parent.auto_envvar_prefix
            )
        else:
            self.auto_envvar_prefix = None

        if "default_map" in merged:
            self.default_map = merged["default_map"]
        elif parent is not None and isinstance(parent.default_map, dict):
            child = parent.default_map.get(info_name)
            self.default_map = child if isinstance(child, dict) else None
        else:
            self.default_map = None

    # -- identity -----------------------------------------------------
    @property
    def command_path(self) -> str:
        if self.parent is not None and self.parent.command_path:
            return f"{self.parent.command_path} {self.info_name}"
        return self.info_name or ""

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        pop_context(self)

    # -- objects ------------------------------------------------------
    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- sources ------------------------------------------------------
    def get_parameter_source(self, name: str):
        """Return the source of a declared parameter, or None if undeclared.

        # spec: N-000463, N-000464, N-000465, N-000466
        """
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._sources.get(name)

    def exposed_params(self) -> dict[str, Any]:
        return {
            p.name: self.params.get(p.name)
            for p in self.command.get_params(self)
            if p.expose_value
        }

    # -- resources ----------------------------------------------------
    def with_resource(self, cm):
        """Enter ``cm`` and return its value; it is closed when the context closes.

        # spec: N-000467, N-000482, N-000483, N-000615, N-000616, N-000617
        """
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, fn: Callable[[], Any]) -> None:
        self._exit_stack.callback(fn)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    # -- control ------------------------------------------------------
    def exit(self, code: int = 0):
        """Author clean stop.

        # spec: N-000716, N-000717, N-000718
        """
        raise Exit(code)

    def abort(self):
        """Author abort.

        # spec: N-000725
        """
        raise Abort()

    def fail(self, message: str):
        raise UsageError(message, ctx=self)

    def invoke(self, callback, *args, **kwargs):
        """Run another command or a plain callable from inside a callback.

        # spec: N-000471, N-000472, N-000473, N-000474, N-000475, N-000476
        """
        if isinstance(callback, Command):
            return self._invoke_command(callback, kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd: "Command", **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)

    def _invoke_command(self, cmd: "Command", values: dict):
        sub = Context(cmd, parent=self, info_name=cmd.name)
        try:
            with sub:
                for p in cmd.get_params(sub):
                    if p.name in values:
                        sub.params[p.name] = values[p.name]
                    else:
                        sub.params[p.name] = p.default_for_invoke(sub)
                    sub._sources[p.name] = ParameterSource.COMMANDLINE
                kwargs = {p.name: sub.params[p.name] for p in cmd.get_params(sub) if p.expose_value}
                for key, val in values.items():
                    if key not in kwargs and key not in sub.params:
                        kwargs[key] = val
                if cmd.callback is None:
                    return None
                return cmd.callback(**kwargs)
        finally:
            sub.close()

    # -- help ---------------------------------------------------------
    def help_width(self) -> int:
        if self.terminal_width is not None:
            return int(self.terminal_width)
        auto = shutil.get_terminal_size((_DEFAULT_MAX_CONTENT_WIDTH, 24)).columns
        return min(auto, int(self.max_content_width))

    def get_usage(self) -> str:
        return self.command.format_usage(self)

    def get_help(self) -> str:
        return self.command.format_help(self)


# ----------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------


def _split_decls(decls):
    """Split declarations into (destination, flag names, secondary flag names).

    # spec: N-000881, N-000882, N-000883, N-000194, N-000195, N-000226
    """
    dest = None
    opts: list[str] = []
    secondary: list[str] = []
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise DeclarationError(f"Invalid parameter declaration: {decl!r}")
        if decl[0] in PREFIX_CHARS:
            if "/" in decl[1:]:
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        else:
            if dest is not None:
                raise DeclarationError("Only one destination name may be declared.")
            dest = decl
    if dest is None and opts:
        longs = [o for o in opts if o[:2] in ("--", "//", "++")]
        chosen = (longs or opts)[0]
        dest = chosen.lstrip("".join(PREFIX_CHARS)).replace("-", "_")
    return dest, opts, secondary


def _ensure_ident(name: str) -> str:
    return re.sub(r"\W", "_", name)


class Parameter:
    """Base class for options and arguments.

    # spec: N-000921, N-000922, N-000923
    """

    param_kind = "parameter"

    def __init__(
        self,
        name,
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        deprecated=False,
        help=None,
        hidden=False,
        shell_complete=None,
        allow_from_autoenv=True,
    ) -> None:
        self.name = name
        self.default = default
        self.required = bool(required)
        self.callback = callback
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = bool(expose_value)
        self.is_eager = bool(is_eager)
        self.deprecated = bool(deprecated)
        self.help = help
        self.hidden = bool(hidden)
        self.shell_complete = shell_complete
        self.allow_from_autoenv = bool(allow_from_autoenv)
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar else None
        self.nargs = nargs
        self.type = convert_type(type) if type is not None else None

    # -- shape --------------------------------------------------------
    @property
    def arity(self) -> int:
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        return self.nargs

    def _inner_types(self):
        if isinstance(self.type, Tuple):
            return self.type.types
        return [self.type] * self.nargs

    @property
    def _is_multi(self) -> bool:
        return self.multiple or self.nargs == -1

    def get_error_hint(self, ctx) -> str:
        raise NotImplementedError

    def _raw_default(self, ctx=None):
        d = self.default
        if callable(d):
            d = d()
        return d

    # -- conversion ---------------------------------------------------
    def _convert_one(self, ctx, raw):
        """Convert one occurrence (a token, or a tuple of tokens for nargs > 1)."""
        if self.arity == 1 and not isinstance(self.type, Tuple):
            return self.type.convert(raw, self, ctx)
        inner = self._inner_types()
        if not isinstance(raw, (tuple, list)):
            raw = (raw,)
        if len(raw) != len(inner):
            raise BadOptionUsage(
                f"Option {self.get_error_hint(ctx)} takes {len(inner)} values.", ctx=ctx
            )
        return tuple(t.convert(v, self, ctx) for t, v in zip(inner, raw))

    def _convert_flag(self, ctx, raw):
        if raw is None:
            return None
        return self.type.convert(raw, self, ctx)

    def _split_items(self, raw: str) -> list:
        return self.type.split_envvar(raw)

    def _chunk(self, parts: list, size: int) -> list:
        if size == 1:
            return parts
        if len(parts) % size:
            raise BadParameter(
                f"Expected a multiple of {size} values, got {len(parts)}.", ctx=None, param=self
            )
        return [tuple(parts[i : i + size]) for i in range(0, len(parts), size)]

    # -- envvars ------------------------------------------------------
    def _env_names(self, ctx) -> list[str]:
        names = list(self.envvar or [])
        if (
            self.param_kind == "option"
            and ctx is not None
            and ctx.auto_envvar_prefix
            and self.allow_from_autoenv
        ):
            auto = _envname(ctx.auto_envvar_prefix, self.name)
            if auto not in names:
                names.append(auto)
        return names

    def _env_lookup(self, ctx):
        for name in self._env_names(ctx):
            value = os.environ.get(name)
            if value:  # absent or truly empty means "not supplying a value"
                return name, value
        return None

    # -- defaults -----------------------------------------------------
    def _default_map_raw(self, ctx):
        dm = ctx.default_map if ctx is not None else None
        if isinstance(dm, dict) and self.name in dm:
            return dm[self.name]
        return _NOVALUE

    def _from_default_map(self, ctx, raw):
        """The default map overrides declared defaults; strings split per arity.

        # spec: N-000450, N-000451, N-000452, N-000453, N-000454, N-000455, N-000456
        # spec: N-000457, N-000458, N-000459, N-000460, N-000461, N-000462
        """
        if raw is None:
            return None
        if self._is_multi:
            if isinstance(raw, str):
                if self.multiple and self.arity == 1 and self.nargs != -1:
                    raise BadOptionUsage(
                        f"Option {self.get_error_hint(ctx)} needs an iterable (sequence) default; "
                        "a string is not accepted.",
                        ctx=ctx,
                    )
                items = self._chunk(self._split_items(raw), self.arity if self.multiple else 1)
            elif isinstance(raw, (list, tuple)):
                items = list(raw)
            else:
                raise BadOptionUsage(
                    f"Option {self.get_error_hint(ctx)} needs an iterable (sequence) default.",
                    ctx=ctx,
                )
            if self.nargs == -1:
                return tuple(self.type.convert(i, self, ctx) for i in items)
            return tuple(self._convert_one(ctx, i) for i in items)
        if self.arity > 1 and isinstance(raw, str):
            parts = self._split_items(raw)
            return self._convert_one(ctx, tuple(parts))
        return self._convert_one(ctx, raw)

    def _from_default(self, ctx):
        raw = self._raw_default(ctx)
        if raw is None:
            return self._empty_value()
        if self._is_multi:
            return self._from_default_map(ctx, raw)
        return self._convert_one(ctx, raw)

    def _empty_value(self):
        if self._is_multi:
            return ()
        return None

    def default_for_invoke(self, ctx):
        raw = self._raw_default(ctx)
        if raw is not None:
            return raw
        if self.is_flag_like():
            return False
        return () if self._is_multi else None

    def is_flag_like(self) -> bool:
        return False

    # -- callbacks ----------------------------------------------------
    def _finish(self, ctx, value):
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value



class Option(Parameter):
    """A named parameter. Declared with flag names such as ``--verbose``.

    # spec: N-000881, N-000884, N-000885, N-000886, N-000887, N-000888, N-000889
    # spec: N-000890, N-000891, N-000892, N-000893, N-000894, N-000895, N-000896
    # spec: N-000897, N-000898, N-000899, N-000900, N-000901, N-000902, N-000903
    # spec: N-000904, N-000905, N-000906, N-000907, N-000908, N-000909, N-000926
    # spec: N-000927, N-000929, N-000275, N-000276, N-000277, N-000278, N-000279
    """

    param_kind = "option"

    def __init__(
        self,
        param_decls=(),
        type=None,
        default=None,
        required=False,
        is_flag=None,
        flag_value=None,
        count=False,
        multiple=False,
        nargs=None,
        envvar=None,
        allow_from_autoenv=True,
        prompt=None,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        callback=None,
        is_eager=False,
        expose_value=True,
        hidden=False,
        deprecated=False,
        help=None,
        metavar=None,
        show_default=None,
        show_envvar=None,
        shell_complete=None,
    ) -> None:
        dest, opts, secondary = _split_decls(param_decls)
        if dest is None and not opts:
            raise DeclarationError("An option needs at least one flag name or a destination.")
        if dest is None:
            dest = _ensure_ident(dest or "")
        super().__init__(
            name=dest,
            type=None,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs or 1,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            shell_complete=shell_complete,
            allow_from_autoenv=allow_from_autoenv,
        )
        self.opts = opts
        self.secondary_opts = secondary
        self.count = bool(count)
        self._dynamic_help = False

        if is_flag is None:
            is_flag = bool(secondary) or self.count or type is bool or isinstance(default, bool)
            if flag_value is not None and not isinstance(flag_value, bool) and not secondary:
                is_flag = False if not self.count else is_flag
        self.is_flag = bool(is_flag) or self.count
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        self.optional_value = (not self.is_flag) and flag_value is not None

        if nargs is not None and nargs < 1:
            raise DeclarationError("nargs must be a positive integer.")
        if self.is_flag and nargs not in (None, 1):
            raise DeclarationError("A flag cannot take several values.")

        # Type: explicit, else inferred.
        if type is not None:
            self.type = convert_type(type)
        elif self.count:
            self.type = INT
        elif self.is_flag:
            self.type = BOOL if (flag_value is None or isinstance(flag_value, bool)) else infer_type_from_default(flag_value)
        else:
            self.type = infer_type_from_default(default if default is not None else flag_value)

        if isinstance(self.type, Tuple):
            if nargs not in (None, self.type.arity):
                raise DeclarationError("nargs must match the length of the Tuple type.")
            self.nargs = self.type.arity

        self.prompt = prompt
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)
        self.show_default = show_default
        self.show_envvar = show_envvar

        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if self.is_flag and self.prompt and self.required:
            # A required flag cannot be prompted for meaningfully.
            pass

    def is_flag_like(self) -> bool:
        return self.is_flag

    def get_flag_names(self, ctx=None) -> list[str]:
        return list(self.opts) + list(self.secondary_opts)

    def get_error_hint(self, ctx) -> str:
        return "'" + " / ".join(self.opts or [self.name]) + "'"

    def usage_name(self) -> str:
        return " / ".join(self.opts or [self.name])

    # -- resolution ---------------------------------------------------
    def resolve(self, ctx, res):
        """Return (value, source, explicit_default) for this option.

        # spec: N-000243, N-000244, N-000245, N-000221, N-000222, N-000223, N-000224
        # spec: N-000225, N-000200, N-000201, N-000202, N-000203, N-000204, N-000205
        # spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000211, N-000212
        # spec: N-000213, N-000214, N-000215, N-000216, N-000217, N-000218, N-000219
        # spec: N-000220, N-000227, N-000228, N-000229, N-000230, N-000231, N-000232
        # spec: N-000233, N-000234, N-000235, N-000236, N-000237, N-000238, N-000239
        # spec: N-000240, N-000241, N-000242, N-000488, N-000489, N-000490, N-000491
        # spec: N-000492, N-000493, N-000494, N-000495, N-000496, N-000497, N-000498
        # spec: N-000499, N-000500, N-000510, N-000511, N-000512, N-000520, N-000521
        # spec: N-000522, N-000523
        """
        occs = res.occurrences(self)
        explicit = self.default is not None
        if occs and self.prompt is not None and occs[-1].no_value:
            return self._prompt(ctx, self._raw_default(ctx)), ParameterSource.PROMPT, explicit
        if occs:
            return self._from_cmdline(ctx, occs), ParameterSource.COMMANDLINE, explicit

        env = self._from_env(ctx)
        if env is not _NOVALUE:
            return env, ParameterSource.ENVIRONMENT, explicit

        dm = self._default_map_raw(ctx)
        if self.prompt is not None and (self.prompt_required or self.required):
            prompt_default = dm if dm is not _NOVALUE else self._raw_default(ctx)
            return self._prompt(ctx, prompt_default), ParameterSource.PROMPT, explicit
        if dm is not _NOVALUE:
            return self._from_default_map(ctx, dm), ParameterSource.DEFAULT_MAP, explicit
        return self._from_default_declared(ctx), ParameterSource.DEFAULT, explicit

    def _from_cmdline(self, ctx, occs):
        if self.count:
            return len(occs)
        if self.is_flag:
            return self._convert_flag(ctx, occs[-1].raw)
        if self.multiple:
            return tuple(self._convert_one(ctx, o.raw) for o in occs)
        return self._convert_one(ctx, occs[-1].raw)

    def _from_env(self, ctx):
        found = self._env_lookup(ctx)
        if found is None:
            return _NOVALUE
        _, raw = found
        if self.is_flag and not self.count:
            value = self._env_flag(ctx, raw)
            if value is _NOVALUE:
                return _NOVALUE
            return self._convert_flag(ctx, value)
        if self.count:
            return INT.convert(raw, self, ctx)
        if self.multiple:
            parts = self._split_items(raw)
            items = self._chunk(parts, self.arity) if self.arity > 1 else parts
            return tuple(self._convert_one(ctx, i) for i in items)
        if self.arity > 1:
            parts = self._split_items(raw)
            if len(parts) != self.arity:
                raise BadParameter(
                    f"Expected {self.arity} values in the environment, got {len(parts)}.",
                    ctx=ctx,
                    param=self,
                )
            return self._convert_one(ctx, tuple(parts))
        return self._convert_one(ctx, raw)

    def _env_flag(self, ctx, raw: str):
        """Interpret an environment value for a flag. Returns _NOVALUE to mean unset.

        # spec: N-000234, N-000235, N-000236, N-000237, N-000238, N-000239, N-000240, N-000241, N-000242
        """
        if raw == "":
            return _NOVALUE
        fv = self.flag_value
        if fv is not None and not isinstance(fv, bool) and raw == str(fv):
            return fv
        text = raw.strip().lower()
        is_bool_flag = isinstance(fv, bool) or fv is None
        if not is_bool_flag:
            if text in BOOL_TRUE:
                return True
            if text in BOOL_FALSE:
                return False
            return _NOVALUE
        if text == "":
            return False
        if text in BOOL_TRUE:
            return True
        if text in BOOL_FALSE:
            return False
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)

    def _from_default_declared(self, ctx):
        raw = self._raw_default(ctx)
        if raw is None:
            if self.count:
                return 0
            if self.is_flag:
                return False
            return self._empty_value()
        if self.is_flag:
            return self._convert_flag(ctx, raw)
        if self.count:
            return INT.convert(raw, self, ctx)
        if self.multiple:
            if isinstance(raw, str) or not isinstance(raw, (list, tuple)):
                raise BadOptionUsage(
                    f"Option {self.get_error_hint(ctx)} needs an iterable (sequence) default; "
                    "a string is not accepted.",
                    ctx=ctx,
                )
            return tuple(self._convert_one(ctx, r) for r in raw)
        return self._convert_one(ctx, raw)

    def _prompt(self, ctx, default):
        from .termui import prompt as _prompt_fn

        text = self.prompt_text
        if not text:
            text = self.name.replace("_", " ").capitalize()
        if callable(default):
            default = default()
        value = _prompt_fn(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if self.multiple:
            return (value,)
        return value


class Argument(Parameter):
    """A positional parameter.

    # spec: N-000285, N-000286, N-000287, N-000288, N-000289, N-000290, N-000291
    # spec: N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298
    # spec: N-000299, N-000300, N-000301, N-000302, N-000303, N-000304, N-000305
    # spec: N-000306, N-000307, N-000308, N-000309, N-000310, N-000311, N-000312
    # spec: N-000313, N-000314, N-000315, N-000316, N-000317, N-000318, N-000319
    # spec: N-000320, N-000910, N-000911, N-000912, N-000325, N-000326, N-000327
    # spec: N-000328, N-000329
    """

    param_kind = "argument"

    def __init__(
        self,
        param_decls=(),
        type=None,
        default=None,
        required=None,
        nargs=None,
        envvar=None,
        deprecated=False,
        help=None,
        metavar=None,
        callback=None,
        expose_value=True,
        hidden=False,
        is_eager=False,
        shell_complete=None,
    ) -> None:
        dest = None
        for decl in param_decls:
            if not isinstance(decl, str) or not decl or decl[0] in PREFIX_CHARS:
                raise DeclarationError("An argument takes a single destination name.")
            if dest is not None:
                raise DeclarationError("An argument takes a single destination name.")
            dest = decl
        if dest is None:
            raise DeclarationError("An argument needs a destination name.")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise DeclarationError("nargs must be a positive integer or -1.")
        if required is None:
            required = (default is None) if nargs != -1 else False
        super().__init__(
            name=dest,
            type=None,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            shell_complete=shell_complete,
            allow_from_autoenv=False,
        )
        if type is not None:
            self.type = convert_type(type)
        else:
            self.type = infer_type_from_default(default)
        if isinstance(self.type, Tuple):
            if nargs not in (1, self.type.arity):
                raise DeclarationError("nargs must match the length of the Tuple type.")
            self.nargs = self.type.arity
        if deprecated and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        self.deprecated = bool(deprecated)

    def get_error_hint(self, ctx) -> str:
        return "'" + self.name.upper() + "'"

    def placeholder(self) -> str:
        base = self.metavar or self.name.upper()
        if self.nargs == -1:
            return f"{base}..." if self.required else f"[{base}]..."
        if self.nargs == 1:
            return base if self.required else f"[{base}]"
        inner = " ".join([base] * self.nargs)
        return inner if self.required else f"[{inner}]"

    def resolve(self, ctx, tokens):
        """Return (value, source, explicit_default) for this argument.

        # spec: N-000309, N-000310, N-000311, N-000312, N-000313, N-000314, N-000315
        # spec: N-000316, N-000317, N-000321, N-000322, N-000323, N-000324
        """
        if tokens:
            if self.nargs == -1:
                value = tuple(self.type.convert(t, self, ctx) for t in tokens)
            elif self.nargs == 1 and not isinstance(self.type, Tuple):
                value = self.type.convert(tokens[0], self, ctx)
            else:
                value = self._convert_one(ctx, tuple(tokens))
            return value, ParameterSource.COMMANDLINE, self.default is not None

        if self.envvar:
            found = self._env_lookup(ctx)
            if found is not None:
                _, raw = found
                if self.nargs == 1 and not isinstance(self.type, Tuple):
                    return self.type.convert(raw, self, ctx), ParameterSource.ENVIRONMENT, False
                parts = self._split_items(raw)
                if self.nargs == -1:
                    return tuple(self.type.convert(p, self, ctx) for p in parts), ParameterSource.ENVIRONMENT, False
                return self._convert_one(ctx, tuple(parts)), ParameterSource.ENVIRONMENT, False

        dm = self._default_map_raw(ctx)
        if dm is not _NOVALUE:
            return self._from_default_map(ctx, dm), ParameterSource.DEFAULT_MAP, False

        raw = self._raw_default(ctx)
        if raw is not None:
            return self._from_default(ctx), ParameterSource.DEFAULT, self.default is not None
        if self.required:
            raise MissingParameter(ctx=ctx, param=self)
        return self._empty_value(), ParameterSource.DEFAULT, False


# ----------------------------------------------------------------------
# Parsing
# ----------------------------------------------------------------------


class _Occ:
    __slots__ = ("index", "raw", "no_value")

    def __init__(self, index, raw, no_value=False) -> None:
        self.index = index
        self.raw = raw
        self.no_value = no_value


class _ParseResult:
    def __init__(self) -> None:
        self.occ: dict[int, list[_Occ]] = {}
        self.first: dict[int, int] = {}
        self.pos: list[tuple[int, str, bool]] = []
        self.consumed: set[int] = set()

    def occurrences(self, param) -> list[_Occ]:
        return self.occ.get(id(param), [])

    def add(self, param, index, raw, no_value=False):
        self.occ.setdefault(id(param), []).append(_Occ(index, raw, no_value))
        self.first.setdefault(id(param), index)


def _build_flag_map(ctx, options):
    norm = ctx.token_normalize_func or (lambda s: s)
    flag_map: dict[str, tuple] = {}
    prefixes = set()
    for p in options:
        for i, name in enumerate(p.opts):
            key = norm(name)
            flag_map.setdefault(key, (p, "primary"))
            prefixes.add(name[0])
        for name in p.secondary_opts:
            key = norm(name)
            flag_map.setdefault(key, (p, "secondary"))
            prefixes.add(name[0])
    return flag_map, prefixes or set(PREFIX_CHARS[:1])


def _parse(ctx, args, flag_map, prefixes, interspersed, positional_limit, ignore_unknown):
    """Parse option tokens. Returns a _ParseResult.

    # spec: N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000196
    # spec: N-000197, N-000198, N-000199, N-000268, N-000270, N-000271, N-000272
    # spec: N-000273, N-000304, N-000305, N-000306, N-000283, N-000284
    """
    norm = ctx.token_normalize_func or (lambda s: s)
    res = _ParseResult()
    n = len(args)
    state = {"dd": False, "stopped": False, "known_only": False, "npos": 0}

    def opt_like(tok: str) -> bool:
        return len(tok) > 1 and tok[0] in prefixes

    def take_value(i, param, attached):
        """Consume a value-taking option at i. Returns the number of tokens used."""
        if param.optional_value:
            if attached is not None:
                res.add(param, i, attached)
                res.consumed.add(i)
                return 1
            if i + 1 < n and not opt_like(args[i + 1]) and args[i + 1] != "--":
                res.add(param, i, args[i + 1])
                res.consumed.update((i, i + 1))
                return 2
            res.add(param, i, param.flag_value, no_value=True)
            res.consumed.add(i)
            return 1
        need = param.arity
        toks: list = []
        if attached is not None:
            toks.append(attached)
        j = i + 1
        while len(toks) < need and j < n:
            toks.append(args[j])
            j += 1
        if len(toks) < need:
            what = "an argument" if need == 1 else f"{need} arguments"
            raise BadOptionUsage(
                f"Option {param.get_error_hint(ctx)} requires {what}.", ctx=ctx
            )
        res.add(param, i, toks[0] if need == 1 else tuple(toks))
        res.consumed.update(range(i, j))
        return j - i

    def apply(i, param, kind, attached):
        if param.is_flag:
            if attached is not None:
                raise BadOptionUsage(
                    f"Option {param.get_error_hint(ctx)} does not take a value.", ctx=ctx
                )
            if param.count:
                res.add(param, i, 1)
            elif kind == "secondary":
                res.add(param, i, False)
            else:
                res.add(param, i, param.flag_value)
            res.consumed.add(i)
            return 1
        return take_value(i, param, attached)

    def try_option(i, known_only):
        """Return tokens used, or None when the token is not an option here."""
        tok = args[i]
        if norm(tok) in flag_map:
            param, kind = flag_map[norm(tok)]
            return apply(i, param, kind, None)
        p = tok[0]
        if tok[:2] == p * 2:
            name, eq, attached = tok.partition("=")
            ent = flag_map.get(norm(name))
            if ent is None:
                if known_only or ignore_unknown:
                    return None
                raise NoSuchOption(name, ctx=ctx)
            return apply(i, ent[0], ent[1], attached if eq else None)
        chars = tok[1:]
        for j, ch in enumerate(chars):
            name = p + ch
            ent = flag_map.get(norm(name))
            if ent is None:
                if known_only or ignore_unknown:
                    if j == 0:
                        return None
                    # The unknown rest of the stack stays as a leftover token.
                    res.pos.append((i, p + chars[j:], False))
                    res.consumed.add(i)
                    return 1
                raise NoSuchOption(name, ctx=ctx)
            param, kind = ent
            if param.is_flag:
                apply(i, param, kind, None)
                continue
            rest = chars[j + 1 :]
            return apply(i, param, kind, rest or None)
        return 1

    i = 0
    while i < n:
        tok = args[i]
        if state["dd"]:
            res.pos.append((i, tok, True))
            i += 1
            continue
        if state["stopped"]:
            res.pos.append((i, tok, False))
            i += 1
            continue
        if tok == "--":
            state["dd"] = True
            res.consumed.add(i)
            i += 1
            continue
        if not opt_like(tok):
            res.pos.append((i, tok, False))
            state["npos"] += 1
            if not interspersed:
                state["stopped"] = True
            elif positional_limit is not None and state["npos"] >= positional_limit:
                state["known_only"] = True
            i += 1
            continue
        used = try_option(i, state["known_only"])
        if used is None:
            res.pos.append((i, tok, False))
            i += 1
        else:
            i += used
    return res


def _bind_arguments(arguments, tokens, ctx):
    """Bind positional tokens to arguments in declaration order.

    Arguments that receive no tokens map to ``None`` (or ``[]`` for variadic
    ones); whether that is an error is decided when the value is resolved, so
    that environment and default-map sources can still satisfy them.

    # spec: N-000285, N-000291, N-000292, N-000293, N-000294, N-000295, N-000296
    # spec: N-000321, N-000322, N-000323
    """
    assign: dict[int, list[str] | None] = {}
    rest = list(tokens)
    for j, arg in enumerate(arguments):
        later_required = sum(b.nargs for b in arguments[j + 1 :] if b.required and b.nargs > 0)
        if arg.nargs == -1:
            take = max(len(rest) - later_required, 0)
            assign[id(arg)] = [t for _, t, _ in rest[:take]]
            rest = rest[take:]
            continue
        need = arg.nargs
        if len(rest) >= need and len(rest) - later_required >= need:
            assign[id(arg)] = [t for _, t, _ in rest[:need]]
            rest = rest[need:]
        else:
            assign[id(arg)] = None
            if arg.required and rest and len(rest) < need and later_required == 0:
                raise BadArgumentUsage(
                    f"Argument {arg.name.upper()} takes {need} values.", ctx=ctx
                )
    return assign, rest


# ----------------------------------------------------------------------
# Commands and groups
# ----------------------------------------------------------------------


class Command:
    """A leaf command: options, arguments and a callback.

    # spec: N-000850, N-000854, N-000855, N-000856, N-000857, N-000858, N-000859
    # spec: N-000860, N-000861, N-000079, N-000080, N-000081, N-000090, N-000091
    # spec: N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
    # spec: N-000099, N-000100, N-000101, N-000102, N-000103, N-000104
    # spec: N-000110, N-000111, N-000112, N-000113, N-000114, N-000115, N-000116
    # spec: N-000117, N-000176, N-000177
    """

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False
    is_group = False

    def __init__(
        self,
        name=None,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params: list[Parameter] = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = bool(add_help_option)
        self.no_args_is_help = bool(no_args_is_help)
        self.hidden = bool(hidden)
        self.deprecated = deprecated
        self.allow_extra_args = self.__class__.allow_extra_args

    # -- parameter list -----------------------------------------------
    def get_params(self, ctx) -> list[Parameter]:
        params = list(self.params)
        if self.add_help_option:
            names = list(ctx.help_option_names) if ctx is not None else ["--help"]
            claimed = set()
            if ctx is not None:
                norm = ctx.token_normalize_func or (lambda s: s)
                for p in params:
                    if isinstance(p, Option):
                        claimed.update(norm(n) for n in p.get_flag_names(ctx))
            remaining = [n for n in names if (ctx is None or (ctx.token_normalize_func or (lambda s: s))(n) not in claimed)]
            if remaining:
                params.append(_make_help_option(remaining))
        return params

    # -- usage / help -------------------------------------------------
    def _is_chain(self) -> bool:
        return False

    def format_usage(self, ctx) -> str:
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for p in self.get_params(ctx):
            if isinstance(p, Argument) and not p.hidden:
                pieces.append(p.placeholder())
        if self.is_group:
            pieces.append(self._subcommand_placeholder())
        return "Usage: " + " ".join(pieces)

    def _subcommand_placeholder(self) -> str:
        return "COMMAND [ARGS]..."

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help:
            return self.short_help
        return make_default_short_help(process_help_text(self.help), limit)

    def format_help(self, ctx) -> str:
        width = ctx.help_width()
        params = self.get_params(ctx)
        out: list[str] = [self.format_usage(ctx)]
        desc = process_help_text(self.help)
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            desc = (desc + "\n\n" if desc else "") + "(Deprecated)" + (f" {note}" if note else "")
        if desc:
            out.append("")
            out.append(wrap_text(desc, width=width))
        args = [p for p in params if isinstance(p, Argument) and not p.hidden]
        if any(a.help for a in args):
            out.append("")
            out.append("Positional arguments:")
            rows = [(a.placeholder(), a.help or "") for a in args if a.help]
            out.extend(_format_rows(rows, width))
        opts = [p for p in params if isinstance(p, Option) and not p.hidden]
        if opts:
            out.append("")
            out.append("Options:")
            rows = [(_option_names_display(o), _option_help(o, ctx)) for o in opts]
            out.extend(_format_rows(rows, width))
        if self.is_group:
            rows = []
            for cname in sorted(self.list_commands(ctx)):
                cmd = self.get_command(ctx, cname)
                if cmd is None or cmd.hidden:
                    continue
                rows.append((cname, cmd.get_short_help_str()))
            if rows:
                out.append("")
                out.append("Commands:")
                out.extend(_format_rows(rows, width))
        if self.epilog:
            out.append("")
            out.append(wrap_text(self.epilog, width=width))
        return "\n".join(out) + "\n"

    # -- context and parsing ------------------------------------------
    def make_context(self, info_name, args, parent=None, _chain_child=False, **extra) -> Context:
        ctx = Context(self, info_name=info_name, parent=parent, _chain_child=_chain_child, **extra)
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx: Context, args: list[str]) -> None:
        """Parse and process this command's parameters into ``ctx.params``.

        # spec: N-000243, N-000249, N-000250, N-000251, N-000252, N-000253, N-000254
        # spec: N-000255, N-000256, N-000257, N-000258, N-000259, N-000260, N-000261
        # spec: N-000262, N-000263, N-000264, N-000265, N-000266, N-000267
        # spec: N-000167, N-000168, N-000169, N-000170, N-000171, N-000172, N-000173
        """
        if not args and self.no_args_is_help:
            raise NoArgsIsHelp(ctx=ctx, message="Show help.")
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        flag_map, prefixes = _build_flag_map(ctx, options)
        interspersed = bool(ctx.allow_interspersed_args) and not ctx._chain_child
        limit = (len(arguments) + 1) if self.is_group else None
        res = _parse(
            ctx,
            args,
            flag_map,
            prefixes,
            interspersed,
            limit,
            bool(ctx.ignore_unknown_options),
        )

        entries: list[tuple] = []
        # Eager parameters first, in the order the user typed them.
        eager = [p for p in options if p.is_eager]
        eager.sort(key=lambda p: res.first.get(id(p), 1 << 30))
        for p in eager:
            self._process_option(ctx, p, res, entries)

        assign, rest = _bind_arguments(arguments, res.pos, ctx)
        for p in options:
            if not p.is_eager:
                self._process_option(ctx, p, res, entries)
        for a in arguments:
            tokens = assign.get(id(a))
            self._process_argument(ctx, a, tokens, entries)
        _settle_winners(ctx, entries)

        if self.is_group:
            self._settle_group(ctx, args, rest, res)
            return
        if ctx._chain_child:
            ctx._leftover_tail = _tail(args, res, rest[0][0]) if rest else []
            return
        if rest:
            extra = [t for _, t, _ in rest]
            for _, tok, lit in rest:
                if not lit and len(tok) > 1 and tok[0] in prefixes:
                    raise NoSuchOption(tok, ctx=ctx)
            if not ctx.allow_extra_args:
                raise BadArgumentUsage(
                    f"Got unexpected extra argument{'s' if len(extra) > 1 else ''} ({', '.join(extra)})",
                    ctx=ctx,
                )
        ctx.args = [t for _, t, _ in rest]

    def _settle_group(self, ctx, args, rest, res):
        if not rest:
            ctx._protected_name = None
            ctx._child_args = []
            ctx._chain_tail = []
            return
        idx, name, _ = rest[0]
        ctx._protected_name = name
        ctx._child_args = [args[j] for j in range(idx + 1, len(args)) if j not in res.consumed]
        ctx._chain_tail = [args[j] for j in range(idx, len(args)) if j not in res.consumed]

    def _process_option(self, ctx, p: Option, res, entries):
        if p.deprecated and res.occurrences(p):
            _warn_deprecated(f"The option '{p.usage_name()}' is deprecated.")
        value, source, explicit = p.resolve(ctx, res)
        if p.required and source is ParameterSource.DEFAULT and (value is None or value == ()):
            raise MissingParameter(ctx=ctx, param=p)
        value = p._finish(ctx, value)
        entries.append((p, value, source, explicit))
        ctx.params[p.name] = value
        ctx._sources[p.name] = source

    def _process_argument(self, ctx, a: Argument, tokens, entries):
        if a.deprecated and tokens:
            _warn_deprecated(f"The argument '{a.name.upper()}' is deprecated.")
        value, source, explicit = a.resolve(ctx, tokens)
        value = a._finish(ctx, value)
        entries.append((a, value, source, explicit))
        ctx.params[a.name] = value
        ctx._sources[a.name] = source

    # -- invocation ---------------------------------------------------
    def invoke(self, ctx: Context):
        """Run the callback with the converted values.

        # spec: N-000083, N-000084, N-000085, N-000086, N-000087, N-000088, N-000089
        # spec: N-000090, N-000096, N-000098, N-000099, N-000100
        """
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            _warn_deprecated(
                f"The command {ctx.command_path or self.name!r} is deprecated."
                + (f" {note}" if note else "")
            )
        if self.callback is None:
            return None
        kwargs = ctx.exposed_params()
        with ctx:
            return self.callback(**kwargs)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run this command as a program.

        # spec: N-000854, N-000855, N-000856, N-000857, N-000858, N-000859, N-000860
        # spec: N-000716, N-000719, N-000723, N-000726, N-000728, N-000729, N-000731
        # spec: N-000692, N-000693, N-000701, N-000702, N-000703, N-000704, N-000705
        # spec: N-000714, N-000715
        """
        from . import shell_completion

        args = list(sys.argv[1:]) if args is None else list(args)
        if prog_name is None:
            prog_name = _detect_prog_name()
        if complete_var is None:
            complete_var = "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction is not None:
            code = shell_completion.run(self, prog_name, instruction, args, extra)
            if standalone_mode:
                sys.exit(code)
            return code

        try:
            ctx = self.make_context(prog_name, args, **extra)
            try:
                with ctx:
                    rv = self.invoke(ctx)
            finally:
                ctx.close()
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as e:
            if not standalone_mode:
                return e.exit_code
            sys.exit(e.exit_code)
        except Abort as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(1)
        except UsageError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except KeyboardInterrupt:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def get_command(self, ctx, name):
        return None

    def list_commands(self, ctx):
        return []


def _tail(args, res, first_index):
    return [args[j] for j in range(first_index, len(args)) if j not in res.consumed]


def _detect_prog_name() -> str:
    if sys.argv and sys.argv[0]:
        base = os.path.basename(sys.argv[0])
        if base.endswith(".py"):
            base = base[:-3]
        if base == "-m" or base == "__main__.py":
            return "python"
        return base or "main"
    return "main"


def _settle_winners(ctx, entries) -> None:
    """When several parameters share a destination, the most explicit one wins.

    # spec: N-000246, N-000247, N-000248, N-000249, N-000766, N-000767, N-000768
    """
    by_name: dict[str, list] = {}
    for index, (p, value, source, explicit) in enumerate(entries):
        by_name.setdefault(p.name, []).append((index, p, value, source, explicit))
    for name, group in by_name.items():
        if len(group) == 1:
            continue
        def key(item):
            index, _, _, source, explicit = item
            tier = _SOURCE_RANK[source]
            return (tier, 1 if (source is ParameterSource.DEFAULT and explicit) else 0, index)
        winner = max(group, key=key)
        ctx.params[name] = winner[2]
        ctx._sources[name] = winner[3]


def _option_names_display(o: Option) -> str:
    if o.secondary_opts:
        return ", ".join(o.opts) + " / " + ", ".join(o.secondary_opts)
    text = ", ".join(o.opts)
    if not o.is_flag:
        text += " " + _metavar_for(o)
    return text


def _metavar_for(o: Option) -> str:
    if o.metavar:
        return o.metavar
    if o.optional_value:
        return "[" + o.type.get_metavar(o) + "]"
    return o.type.get_metavar(o)


def _option_help(o: Option, ctx) -> str:
    parts = []
    if o.deprecated:
        parts.append("(Deprecated)")
    if o.help:
        parts.append(o.help)
    show_default = o.show_default if o.show_default is not None else ctx.show_default
    if show_default:
        if isinstance(show_default, str):
            parts.append(f"[default: {show_default}]")
        elif not (o.is_flag and not o.default):
            raw = o.default
            if raw is not None and not callable(raw):
                if isinstance(raw, (list, tuple)):
                    shown = ", ".join(str(x) for x in raw)
                else:
                    shown = str(raw)
                parts.append(f"[default: {shown}]")
    show_env = o.show_envvar
    if show_env is None:
        show_env = False
    if show_env:
        names = o._env_names(ctx)
        if names:
            parts.append(f"[env var: {', '.join(names)}]")
    return " ".join(parts)


def _format_rows(rows, width: int) -> list[str]:
    if not rows:
        return []
    col = min(max(len("  " + left) for left, _ in rows), 30) + 2
    text_width = max(width - col, 20)
    lines: list[str] = []
    for left, right in rows:
        head = "  " + left
        helplines = wrap_text(right, width=text_width).splitlines() if right else []
        if not helplines:
            lines.append(head)
            continue
        if len(head) <= col - 1:
            lines.append(head.ljust(col) + helplines[0])
            rest = helplines[1:]
        else:
            lines.append(head)
            rest = helplines
        for hl in rest:
            lines.append(" " * col + hl)
    return lines


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    raise Exit(0)


def _make_help_option(names: list[str]) -> Option:
    opt = Option(
        ["_optlyn_help_"],
        is_flag=True,
        expose_value=False,
        is_eager=True,
        callback=_help_callback,
        help="Show this message and exit.",
        type=None,
    )
    opt.name = "_optlyn_help_"
    opt.opts = list(names)
    opt.secondary_opts = []
    return opt


class Group(Command):
    """A command that dispatches to named subcommands.

    # spec: N-000862, N-000863, N-000864, N-000865, N-000866, N-000867, N-000868
    # spec: N-000869, N-000870, N-000871, N-000872, N-000873, N-000874, N-000875
    # spec: N-000876, N-000877, N-000388, N-000389, N-000390, N-000391, N-000392
    # spec: N-000393, N-000394, N-000395, N-000396, N-000397, N-000398, N-000399
    # spec: N-000400, N-000401, N-000402, N-000403, N-000404, N-000405, N-000406
    # spec: N-000407, N-000408, N-000409, N-000410, N-000411, N-000412, N-000413
    # spec: N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420
    # spec: N-000421, N-000426, N-000427, N-000428, N-000433, N-000597, N-000598
    # spec: N-000599, N-000600, N-000601, N-000602, N-000603, N-000604, N-000605
    """

    allow_interspersed_args = False
    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ) -> None:
        super().__init__(name, **kwargs)
        if isinstance(commands, dict):
            self.commands = dict(commands)
        else:
            self.commands = {}
            for cmd in commands or []:
                self.add_command(cmd)
        self.invoke_without_command = bool(invoke_without_command)
        if no_args_is_help is None:
            no_args_is_help = not self.invoke_without_command
        self.no_args_is_help = bool(no_args_is_help)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback

    def _is_chain(self) -> bool:
        return self.chain

    def _subcommand_placeholder(self) -> str:
        if self.subcommand_metavar is not None:
            return self.subcommand_metavar
        if self.chain:
            return "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        if self.invoke_without_command:
            return "[COMMAND] [ARGS]..."
        return "COMMAND [ARGS]..."

    def add_command(self, cmd: Command, name: str | None = None) -> None:
        """Register ``cmd`` under ``name`` (or its own name).

        # spec: N-000869, N-000870, N-000871, N-000613, N-000614
        """
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise DeclarationError("A subcommand needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        return _command(*args, **kwargs, _register_on=self)

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        return _group(*args, **kwargs, _register_on=self)

    def result_callback(self, replace: bool = False):
        """Decorator registering the result callback. # spec: N-000874, N-000875

        # spec: N-000597, N-000598, N-000599, N-000600, N-000601, N-000602
        """

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name: str):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name: str) -> Command:
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx=ctx)
        return cmd

    def invoke(self, ctx: Context):
        """Dispatch to the named subcommand (or to the chain).

        # spec: N-000391, N-000392, N-000393, N-000403, N-000404, N-000405, N-000411
        # spec: N-000412, N-000429, N-000430, N-000431, N-000432, N-000605, N-000606
        """
        if self.chain:
            return self._invoke_chain(ctx)
        name = ctx._protected_name
        if name is None:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = Command.invoke(self, ctx)
                if self._result_callback is not None:
                    return ctx.invoke(self._result_callback, rv, **ctx.exposed_params())
                return rv
            raise MissingCommand(ctx=ctx)
        cmd = self.resolve_command(ctx, name)
        ctx.invoked_subcommand = name
        Command.invoke(self, ctx)
        sub = cmd.make_context(name, ctx._child_args, parent=ctx)
        try:
            rv = cmd.invoke(sub)
        finally:
            sub.close()
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, rv, **ctx.exposed_params())
        return rv

    def _invoke_chain(self, ctx: Context):
        """Run every subcommand on the line in order.

        # spec: N-000593, N-000594, N-000595, N-000596, N-000603, N-000604
        # spec: N-000607, N-000608, N-000609, N-000610, N-000611, N-000612
        """
        tail = list(ctx._chain_tail or [])
        if not tail:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                Command.invoke(self, ctx)
                if self._result_callback is not None:
                    ctx.invoke(self._result_callback, [], **ctx.exposed_params())
                return []
            raise MissingCommand(ctx=ctx)
        ctx.invoked_subcommand = _CHAIN
        Command.invoke(self, ctx)
        results = []
        while tail:
            name = tail[0]
            cmd = self.resolve_command(ctx, name)
            sub = cmd.make_context(name, tail[1:], parent=ctx, _chain_child=True)
            try:
                rv = cmd.invoke(sub)
                tail = list(sub._leftover_tail or [])
            finally:
                sub.close()
            results.append(rv)
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.exposed_params())
        return results


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface.

    # spec: N-000878, N-000879, N-000880, N-000422, N-000423, N-000424, N-000425
    """

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx) -> list[str]:
        names: set[str] = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name: str):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# Public re-export for typing in decorators and tests.
__all__ = [
    "Command",
    "CommandCollection",
    "Context",
    "Group",
    "Option",
    "Argument",
    "Parameter",
    "ParameterSource",
]
