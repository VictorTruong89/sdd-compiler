"""Text wrapping and help-text helpers.

# spec: N-000679, N-000680, N-000133, N-000134, N-000135, N-000136, N-000137, N-000138
# spec: N-000122, N-000123, N-000124, N-000843
"""

from __future__ import annotations

import re
import textwrap

DEFAULT_WIDTH = 78
MAX_SHORT_HELP = 45
_BACKSPACE = "\b"


def wrap_text(
    text: str,
    width: int = DEFAULT_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap ``text`` to ``width`` columns. Accepts any string.

    Single newlines inside a paragraph are not preserved as hard breaks. A
    paragraph whose first line is only a backspace is not rewrapped: its line
    breaks are kept and the backspace line is removed.

    # spec: N-000133, N-000134, N-000135, N-000136, N-000137, N-000138, N-001009
    """
    if not isinstance(text, str):
        text = str(text)
    width = max(int(width), 1)
    paragraphs = re.split(r"\n\s*\n", text.strip("\n"))
    out: list[str] = []
    for para in paragraphs:
        if not para.strip():
            continue
        lines = para.split("\n")
        if lines[0].strip() == _BACKSPACE:
            # Keep the author's line breaks; drop the backspace line.
            chunk = "\n".join(
                initial_indent + ln.rstrip() if i == 0 else subsequent_indent + ln.rstrip()
                for i, ln in enumerate(lines[1:])
            )
        else:
            chunk = textwrap.fill(
                " ".join(ln.strip() for ln in lines),
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
            )
        out.append(chunk)
    return "\n\n".join(out)


def make_default_short_help(text: str, max_length: int = MAX_SHORT_HELP) -> str:
    """Return the first sentence of ``text``, cut with ``...`` to ``max_length``.

    # spec: N-000122, N-000123, N-000124, N-000842, N-000843
    """
    if not text:
        return ""
    first_para = re.split(r"\n\s*\n", text.strip())[0]
    flat = " ".join(first_para.split())
    match = re.search(r"[.!?](\s|$)", flat)
    sentence = flat[: match.end()].strip() if match else flat
    sentence = sentence.rstrip(".!?").rstrip() if match else sentence
    if len(sentence) > max_length:
        sentence = sentence[: max_length - 3].rstrip() + "..."
    return sentence


def process_help_text(text: str | None) -> str:
    """Normalize a docstring: dedent it and truncate at a form feed.

    # spec: N-000114, N-000115, N-000116, N-000117
    """
    if not text:
        return ""
    if "\f" in text:
        text = text.split("\f", 1)[0]
    return text
