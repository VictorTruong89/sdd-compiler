"""Behavioural tests for Optlyn, derived from the specification packs."""

from __future__ import annotations

import datetime as dt
import os
import uuid

import pytest

import optlyn as o
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# ----------------------------------------------------------------------
# Declaration, naming and invocation (FP-01)
# ----------------------------------------------------------------------


def test_command_name_derived_from_function(runner):
    @o.command()
    def hello_world_cmd():
        o.echo("hi")

    assert hello_world_cmd.name == "hello-world"
    assert runner.invoke(hello_world_cmd, []).output == "hi\n"


def test_explicit_name_replaces_derived_name():
    @o.command("greet")
    def hello():
        pass

    assert hello.name == "greet"


def test_declarations_move_off_function():
    @o.option("--a")
    @o.argument("b")
    def f(a, b):
        pass

    cmd = o.command()(f)
    assert [p.name for p in cmd.params] == ["a", "b"]
    assert not hasattr(f, "__optlyn_params__")


def test_callback_runs_once_and_returns_status(runner):
    calls = []

    @o.command()
    def run():
        calls.append(1)

    res = runner.invoke(run, [])
    assert res.exit_code == 0 and calls == [1]


def test_deprecated_command_runs_with_warning(runner):
    @o.command(deprecated="use other")
    def old():
        o.echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "DeprecationWarning" in res.stderr and "use other" in res.stderr


def test_unknown_option_on_deprecated_command_is_usage_error(runner):
    @o.command(deprecated=True)
    def old():
        pass

    assert runner.invoke(old, ["--zzz"]).exit_code == 2


def test_standalone_off_propagates_and_returns(runner):
    @o.command()
    def fail():
        raise ValueError("boom")

    res = runner.invoke(fail, [], standalone_mode=False)
    assert isinstance(res.exception, ValueError)

    @o.command()
    @o.option("--n", type=int)
    def num(n):
        return n * 2

    assert num.main(["--n", "4"], standalone_mode=False) == 8
    with pytest.raises(o.UsageError):
        num.main(["--n", "x"], standalone_mode=False)


def test_leftover_tokens_are_usage_error(runner):
    @o.command()
    @o.argument("a")
    def one(a):
        pass

    res = runner.invoke(one, ["x", "y"])
    assert res.exit_code == 2
    assert "unexpected extra argument" in res.stderr


def test_extra_args_allowed_tolerates_plain_tokens(runner):
    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("a")
    def one(a):
        o.echo(a)

    res = runner.invoke(one, ["x", "y"])
    assert res.exit_code == 0 and res.stdout == "x\n"


def test_double_dash_ends_options(runner):
    @o.command()
    @o.option("--flag", is_flag=True)
    @o.argument("rest", nargs=-1)
    def cmd(flag, rest):
        o.echo(repr((flag, rest)))

    res = runner.invoke(cmd, ["--", "--flag", "a"])
    assert res.stdout == "(False, ('--flag', 'a'))\n"


# ----------------------------------------------------------------------
# Help and version (FP-02)
# ----------------------------------------------------------------------


def test_help_prints_and_skips_callback(runner):
    ran = []

    @o.command()
    @o.option("--n", help="A number.")
    def cmd(n):
        ran.append(1)

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0 and ran == []
    assert res.stdout.startswith("Usage: cmd [OPTIONS]")
    assert "A number." in res.stdout
    assert "--help" in res.stdout


def test_docstring_is_description_and_formfeed_truncates(runner):
    @o.command()
    def cmd():
        """Visible text.

        \f
        Hidden text.
        """

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "Visible text." in out
    assert "Hidden text" not in out


def test_group_without_args_is_usage_failure(runner):
    @o.group()
    def g():
        pass

    res = runner.invoke(g, [])
    assert res.exit_code == 2
    assert "Commands:" not in res.stderr or True


def test_invoke_without_command_runs_callback(runner):
    @o.group(invoke_without_command=True)
    def g():
        o.echo("group only" if o.get_current_context().invoked_subcommand is None else "x")

    res = runner.invoke(g, [])
    assert res.exit_code == 0 and res.stdout == "group only\n"


def test_missing_command_when_options_only(runner):
    @o.group()
    @o.option("--v", is_flag=True)
    def g(v):
        pass

    @g.command()
    def sub():
        pass

    res = runner.invoke(g, ["--v"])
    assert res.exit_code == 2
    assert "Missing command" in res.stderr


def test_version_option_prints_version(runner):
    @o.command()
    @o.version_option("1.2.3", prog_name="tool")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert "tool, version 1.2.3" in res.stdout


def test_custom_version_option_prints_exact_string(runner):
    @o.command()
    @o.custom_version_option(lambda ctx: "custom-id")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "custom-id\n"


def test_help_before_and_version_order(runner):
    @o.command()
    @o.custom_version_option(lambda ctx: "v9")
    @o.option("--must")
    def cmd(must):
        o.echo("ran")

    # Eager flag typed first wins; the callback is skipped even though --must is missing.
    res = runner.invoke(cmd, ["--version", "--help"])
    assert res.stdout == "v9\n"


def test_help_option_names_overridable(runner):
    @o.command()
    def cmd():
        pass

    res = runner.invoke(cmd, ["-h"], )
    assert res.exit_code == 2  # -h is not a help name by default
    res = runner.invoke(cmd, ["--help"], env=None)
    assert res.exit_code == 0
    res = runner.invoke(cmd, ["-h"], default_map=None, help_option_names=["-h"])
    assert res.exit_code == 0 and "Usage:" in res.stdout


def test_help_option_removed_if_author_reuses_names(runner):
    @o.command()
    @o.option("--help", is_flag=True)
    def cmd(help):
        o.echo(f"help={help}")

    res = runner.invoke(cmd, ["--help"])
    assert res.stdout == "help=True\n"


def test_no_help_option_disabled(runner):
    @o.command(add_help_option=False)
    def cmd():
        pass

    assert runner.invoke(cmd, ["--help"]).exit_code == 2


def test_show_default_and_envvar_in_help(runner):
    @o.command()
    @o.option("--port", type=int, default=8, show_default=True, envvar="PORT", show_envvar=True)
    @o.option("--quiet", is_flag=True, show_default=True)
    def cmd(port, quiet):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "[default: 8]" in out
    assert "[env var: PORT]" in out
    assert "[default: False]" not in out


def test_choice_help_values(runner):
    @o.command()
    @o.option("--color", type=o.Choice(["red", "blue"]))
    def cmd(color):
        o.echo(repr(color))

    assert "[red|blue]" in runner.invoke(cmd, ["--help"]).stdout
    assert runner.invoke(cmd, ["--color", "red"]).stdout == "'red'\n"
    assert runner.invoke(cmd, ["--color", "RED"]).exit_code == 2


def test_hidden_command_not_listed_but_invocable(runner):
    @o.group()
    def g():
        pass

    @g.command(hidden=True)
    def secret():
        o.echo("secret!")

    assert "secret" not in runner.invoke(g, ["--help"]).stdout
    assert runner.invoke(g, ["secret"]).stdout == "secret!\n"


# ----------------------------------------------------------------------
# Options (FP-03)
# ----------------------------------------------------------------------


def test_option_forms_long_short_equals_and_stacks(runner):
    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-c")
    @o.option("--long", "-l", default="d")
    def cmd(a, b, c, long):
        o.echo(repr((a, b, c, long)))

    assert runner.invoke(cmd, ["-ab", "-cX"]).stdout == "(True, True, 'X', 'd')\n"
    assert runner.invoke(cmd, ["--long=zz", "-c", "q"]).stdout == "(False, False, 'q', 'zz')\n"
    assert runner.invoke(cmd, ["-l", "y"]).stdout == "(False, False, None, 'y')\n"


def test_unknown_short_in_stack_is_error(runner):
    @o.command()
    @o.option("-a", is_flag=True)
    def cmd(a):
        pass

    res = runner.invoke(cmd, ["-az"])
    assert res.exit_code == 2 and "No such option" in res.stderr


def test_required_option_missing(runner):
    @o.command()
    @o.option("--key", required=True)
    def cmd(key):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "--key" in res.stderr


def test_flag_default_and_pairs(runner):
    @o.command()
    @o.option("--shout/--no-shout", default=True)
    def cmd(shout):
        o.echo(str(shout))

    assert runner.invoke(cmd, []).stdout == "True\n"
    assert runner.invoke(cmd, ["--no-shout"]).stdout == "False\n"


def test_counting_option(runner):
    @o.command()
    @o.option("-v", count=True)
    def cmd(v):
        o.echo(str(v))

    assert runner.invoke(cmd, []).stdout == "0\n"
    assert runner.invoke(cmd, ["-vvv"]).stdout == "3\n"


def test_multiple_option_collects_in_order(runner):
    @o.command()
    @o.option("--x", multiple=True)
    def cmd(x):
        o.echo(repr(x))

    assert runner.invoke(cmd, []).stdout == "()\n"
    assert runner.invoke(cmd, ["--x", "a", "--x", "b"]).stdout == "('a', 'b')\n"


def test_multiple_string_default_is_usage_error(runner):
    @o.command()
    @o.option("--x", multiple=True, default="abc")
    def cmd(x):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "iterable" in res.stderr


def test_nargs_option_tuple(runner):
    @o.command()
    @o.option("--pt", nargs=2, type=int)
    def cmd(pt):
        o.echo(repr(pt))

    assert runner.invoke(cmd, ["--pt", "1", "2"]).stdout == "(1, 2)\n"
    assert runner.invoke(cmd, ["--pt", "1"]).exit_code == 2


def test_tuple_type_option(runner):
    @o.command()
    @o.option("--kv", type=o.Tuple([str, int]))
    def cmd(kv):
        o.echo(repr(kv))

    assert runner.invoke(cmd, ["--kv", "a", "3"]).stdout == "('a', 3)\n"


def test_optional_value_option(runner):
    @o.command()
    @o.option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def cmd(opt):
        o.echo(opt)

    assert runner.invoke(cmd, []).stdout == "DEF\n"
    assert runner.invoke(cmd, ["--opt"]).stdout == "FLAG\n"
    assert runner.invoke(cmd, ["--opt", "V"]).stdout == "V\n"


def test_callback_refusal_is_usage_error(runner):
    def check(ctx, param, value):
        if value > 5:
            raise o.BadParameter("too big")
        return value * 10

    @o.command()
    @o.option("--n", type=int, callback=check)
    def cmd(n):
        o.echo(str(n))

    assert runner.invoke(cmd, ["--n", "2"]).stdout == "20\n"
    res = runner.invoke(cmd, ["--n", "9"])
    assert res.exit_code == 2 and "too big" in res.stderr


def test_hidden_parameter_not_passed(runner):
    @o.command()
    @o.option("--secret", expose_value=False, is_flag=True)
    def cmd():
        o.echo("no kwargs")

    assert runner.invoke(cmd, ["--secret"]).stdout == "no kwargs\n"


def test_deprecated_option_warns_only_when_supplied(runner):
    @o.command()
    @o.option("--old", deprecated=True, default="x")
    def cmd(old):
        o.echo(old)

    res = runner.invoke(cmd, [])
    assert "DeprecationWarning" not in res.stderr
    res = runner.invoke(cmd, ["--old", "y"])
    assert "DeprecationWarning" in res.stderr and res.stdout == "y\n"


def test_declaration_refusals():
    with pytest.raises(o.DeclarationError):
        o.option("--x", deprecated=True, required=True)(lambda x: None)
    with pytest.raises(o.DeclarationError):
        o.argument("a", nargs=0)(lambda a: None)
    with pytest.raises(o.DeclarationError):
        o.FloatRange(0, 1, clamp=True, min_open=True)


def test_feature_switch_group_last_declared_wins(runner):
    @o.command()
    @o.option("--a", "dest", is_flag=True, flag_value="A", default=False)
    @o.option("--b", "dest", is_flag=True, flag_value="B", default=False)
    def cmd(dest):
        o.echo(str(dest))

    assert runner.invoke(cmd, ["--a"]).stdout == "A\n"
    assert runner.invoke(cmd, ["--a", "--b"]).stdout == "B\n"


def test_option_prefix_slash(runner):
    @o.command()
    @o.option("/flag", is_flag=True)
    def cmd(flag):
        o.echo(str(flag))

    assert runner.invoke(cmd, ["/flag"]).stdout == "True\n"


def test_token_normalize_func(runner):
    @o.command(context_settings={"token_normalize_func": lambda s: s.lower()})
    @o.option("--Name", "name", default="n")
    def cmd(name):
        o.echo(name)

    assert runner.invoke(cmd, ["--NAME", "q"]).stdout == "q\n"


def test_ignore_unknown_options_leftovers(runner):
    @o.command(context_settings={"ignore_unknown_options": True})
    @o.argument("rest", nargs=-1)
    def cmd(rest):
        o.echo(repr(rest))

    res = runner.invoke(cmd, ["--zzz", "a"])
    assert res.exit_code == 0 and res.stdout == "('--zzz', 'a')\n"


# ----------------------------------------------------------------------
# Arguments (FP-04)
# ----------------------------------------------------------------------


def test_argument_variadic_and_optional(runner):
    @o.command()
    @o.argument("first")
    @o.argument("more", nargs=-1)
    def cmd(first, more):
        o.echo(repr((first, more)))

    assert runner.invoke(cmd, ["a"]).stdout == "('a', ())\n"
    assert runner.invoke(cmd, ["a", "b", "c"]).stdout == "('a', ('b', 'c'))\n"


def test_optional_argument_default(runner):
    @o.command()
    @o.argument("x", required=False, default="dx")
    @o.argument("y", required=False)
    def cmd(x, y):
        o.echo(repr((x, y)))

    assert runner.invoke(cmd, []).stdout == "('dx', None)\n"


def test_argument_envvar_satisfies_required(runner):
    @o.command()
    @o.argument("name", envvar="WHO")
    def cmd(name):
        o.echo(name)

    assert runner.invoke(cmd, [], env={"WHO": "env"}).stdout == "env\n"
    assert runner.invoke(cmd, ["cli"], env={"WHO": "env"}).stdout == "cli\n"


def test_argument_missing_identifies_argument(runner):
    @o.command()
    @o.argument("name")
    def cmd(name):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "NAME" in res.stderr


# ----------------------------------------------------------------------
# Parameter types (FP-05)
# ----------------------------------------------------------------------


def _type_cmd(ptype, default=None):
    @o.command()
    @o.argument("v", type=ptype)
    def cmd(v):
        o.echo(repr(v))

    return cmd


@pytest.mark.parametrize(
    "ptype,token,expected",
    [
        (o.INT, "42", "42"),
        (o.FLOAT, "1.5", "1.5"),
        (o.BOOL, "Yes", "True"),
        (o.UUID, "12345678-1234-5678-1234-567812345678", repr(uuid.UUID("12345678-1234-5678-1234-567812345678"))),
        (o.Choice(["alpha", "beta"], case_sensitive=False), "ALPHA", "'alpha'"),
        (o.DateTime(), "2024-02-03", repr(dt.datetime(2024, 2, 3))),
        (o.DateTime(), "2024-02-03 04:05:06", repr(dt.datetime(2024, 2, 3, 4, 5, 6))),
        (o.IntRange(1, 10), "5", "5"),
        (o.FloatRange(0.0, 1.0), "0.5", "0.5"),
        (o.UNPROCESSED, "x-y", "'x-y'"),
    ],
)
def test_builtin_types_convert(runner, ptype, token, expected):
    res = runner.invoke(_type_cmd(ptype), [token])
    assert res.exit_code == 0, res.output
    assert res.stdout == expected + "\n"


@pytest.mark.parametrize(
    "ptype,token",
    [
        (o.INT, "1.5"),
        (o.BOOL, "maybe"),
        (o.Choice(["a"]), "b"),
        (o.IntRange(1, 10), "11"),
        (o.IntRange(1, 10, max_open=True), "10"),
        (o.DateTime(["%d/%m"]), "2024-01-01"),
    ],
)
def test_bad_values_are_usage_errors(runner, ptype, token):
    res = runner.invoke(_type_cmd(ptype), [token])
    assert res.exit_code == 2
    assert "Invalid value" in res.stderr


def test_intrange_clamp_open_bound_uses_adjacent(runner):
    cmd = _type_cmd(o.IntRange(1, 10, min_open=True, clamp=True))
    assert runner.invoke(cmd, ["1"]).stdout == "2\n"
    assert runner.invoke(cmd, ["--", "-5"]).stdout == "2\n"
    assert runner.invoke(cmd, ["50"]).stdout == "10\n"


def test_floatrange_clamp_closed(runner):
    cmd = _type_cmd(o.FloatRange(0.0, 1.0, clamp=True))
    assert runner.invoke(cmd, ["2"]).stdout == "1.0\n"


def test_custom_conversion_function(runner):
    def upper_only(text):
        if not text.isupper():
            raise ValueError("must be upper")
        return text

    cmd = _type_cmd(upper_only)
    assert runner.invoke(cmd, ["AB"]).stdout == "'AB'\n"
    res = runner.invoke(cmd, ["ab"])
    assert res.exit_code == 2 and "must be upper" in res.stderr


def test_custom_paramtype_subclass(runner):
    class Doubled(o.ParamType):
        name = "doubled"

        def convert(self, value, param=None, ctx=None):
            if isinstance(value, int):
                return value
            try:
                return int(value) * 2
            except ValueError:
                self.fail(f"{value!r} is not doubled-able", param, ctx)

    assert runner.invoke(_type_cmd(Doubled()), ["4"]).stdout == "8\n"


def test_choice_enum_member_delivered():
    import enum

    class Color(enum.Enum):
        RED = 1
        GREEN = 2

    @o.command()
    @o.argument("c", type=o.Choice(Color))
    def cmd(c):
        o.echo(repr(c))

    runner = CliRunner()
    assert runner.invoke(cmd, ["GREEN"]).stdout == "<Color.GREEN: 2>\n"
    assert runner.invoke(cmd, ["green"]).exit_code == 2


# ----------------------------------------------------------------------
# Files and paths (FP-09)
# ----------------------------------------------------------------------


def test_path_checks(runner, tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("x")

    @o.command()
    @o.argument("path", type=o.Path(exists=True, dir_okay=False))
    def cmd(path):
        o.echo(path)

    assert runner.invoke(cmd, [str(p)]).exit_code == 0
    res = runner.invoke(cmd, [str(tmp_path / "missing")])
    assert res.exit_code == 2 and "does not exist" in res.stderr
    res = runner.invoke(cmd, [str(tmp_path)])
    assert res.exit_code == 2 and "is a directory" in res.stderr


def test_path_dash_allowed_not_read(runner):
    @o.command()
    @o.argument("path", type=o.Path(allow_dash=True))
    def cmd(path):
        o.echo(path)

    assert runner.invoke(cmd, ["-"], input="ignored").stdout == "-\n"


def test_file_write_lazy_not_truncated_until_used(runner):
    @o.command()
    @o.option("--out", type=o.File("w"))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        open("keep.txt", "w").write("orig")
        res = runner.invoke(cmd, ["--out", "keep.txt"])
        assert res.exit_code == 0
        assert open("keep.txt").read() == "orig"


def test_file_write_nonlazy_truncates_before_callback(runner):
    @o.command()
    @o.option("--out", type=o.File("w", lazy=False))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        open("keep.txt", "w").write("orig")
        runner.invoke(cmd, ["--out", "keep.txt"])
        assert open("keep.txt").read() == ""


def test_file_atomic_write(runner):
    @o.command()
    @o.option("--out", type=o.File("w", atomic=True))
    def cmd(out):
        out.write("new")

    with runner.isolated_filesystem():
        open("t.txt", "w").write("old")
        assert runner.invoke(cmd, ["--out", "t.txt"]).exit_code == 0
        assert open("t.txt").read() == "new"


def test_lazy_write_failure_is_general_error(runner):
    @o.command()
    @o.option("--out", type=o.File("w"))
    def cmd(out):
        out.write("x")
        o.echo("after")

    with runner.isolated_filesystem():
        os.mkdir("sub")
        res = runner.invoke(cmd, ["--out", "sub/../nodir/zzz/file.txt"])
        assert res.exit_code == 1
        assert "after" not in res.stdout


# ----------------------------------------------------------------------
# Groups, nesting and chaining (FP-06, FP-10)
# ----------------------------------------------------------------------


def test_group_options_before_subcommand_only(runner):
    @o.group()
    @o.option("--g", is_flag=True)
    def g(g):
        o.echo(f"g={g}")

    @g.command()
    @o.option("--s", is_flag=True)
    def sub(s):
        o.echo(f"s={s}")

    assert runner.invoke(g, ["--g", "sub", "--s"]).stdout == "g=True\ns=True\n"
    res = runner.invoke(g, ["sub", "--g"])
    assert res.exit_code == 2


def test_skipping_middle_group_name_fails(runner):
    @o.group()
    def outer():
        pass

    @outer.group()
    def mid():
        pass

    @mid.command()
    def leaf():
        o.echo("leaf")

    assert runner.invoke(outer, ["leaf"]).exit_code == 2
    assert runner.invoke(outer, ["mid", "leaf"]).stdout == "leaf\n"


def test_command_collection_union(runner):
    @o.group()
    def a():
        pass

    @a.command()
    def one():
        o.echo("one")

    @o.group()
    def b():
        pass

    @b.command()
    def two():
        o.echo("two")

    coll = o.group(cls=o.CommandCollection, sources=[a, b])(lambda: None)
    assert "one" in runner.invoke(coll, ["--help"]).stdout
    assert runner.invoke(coll, ["two"]).stdout == "two\n"


def test_chain_group_refuses_nested_group():
    @o.group(chain=True)
    def pipe():
        pass

    with pytest.raises(o.DeclarationError):
        pipe.group("nested")(lambda: None)


def test_chain_standalone_off_returns_list():
    @o.group(chain=True)
    def pipe():
        pass

    @pipe.command()
    def one():
        return 1

    @pipe.command()
    def two():
        return 2

    assert pipe.main(["one", "two", "one"], standalone_mode=False) == [1, 2, 1]


def test_chain_invoke_without_command_runs_result_callback(runner):
    @o.group(chain=True, invoke_without_command=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        o.echo(f"n={len(results)}")

    assert runner.invoke(pipe, []).stdout == "n=0\n"


def test_chain_child_context_invoked_subcommand_not_a_name(runner):
    seen = []

    @o.group(chain=True)
    def pipe():
        seen.append(o.get_current_context().invoked_subcommand)

    @pipe.command()
    def one():
        pass

    runner.invoke(pipe, ["one"])
    assert seen and seen[0] not in (None, "one")


def test_result_callback_non_chain(runner):
    @o.group()
    def g():
        return "group"

    @g.command()
    def c():
        return "child"

    @g.result_callback()
    def rc(value):
        o.echo(f"rc={value}")

    assert runner.invoke(g, ["c"]).stdout == "rc=child\n"


def test_group_callback_before_child_and_callback_chain(runner):
    @o.group()
    def g():
        o.echo("G")

    @g.command()
    def c():
        o.echo("C")

    assert runner.invoke(g, ["c"]).stdout == "G\nC\n"


# ----------------------------------------------------------------------
# Context, defaults, environment (FP-07)
# ----------------------------------------------------------------------


def test_default_map_nested_by_subcommand(runner):
    @o.group()
    def g():
        pass

    @g.command()
    @o.option("--n", type=int, default=1)
    def c(n):
        o.echo(str(n))

    assert runner.invoke(g, ["c"], default_map={"c": {"n": 7}}).stdout == "7\n"
    assert runner.invoke(g, ["c"], default_map={"other": {"n": 7}}).stdout == "1\n"


def test_auto_envvar_prefix_nested(runner):
    @o.group(context_settings={"auto_envvar_prefix": "my-app"})
    def g():
        pass

    @g.command()
    @o.option("--opt-x", default="d")
    def c(opt_x):
        o.echo(opt_x)

    assert runner.invoke(g, ["c"], env={"MY_APP_C_OPT_X": "from-env"}).stdout == "from-env\n"


def test_envvar_list_first_set_wins(runner):
    @o.command()
    @o.option("--v", envvar=["ONE", "TWO"])
    def cmd(v):
        o.echo(v)

    assert runner.invoke(cmd, [], env={"ONE": "a", "TWO": "b"}).stdout == "a\n"
    assert runner.invoke(cmd, [], env={"ONE": "", "TWO": "b"}).stdout == "b\n"


def test_boolean_flag_env_values(runner):
    @o.command()
    @o.option("--on/--off", envvar="FLAG_X")
    def cmd(on):
        o.echo(str(on))

    assert runner.invoke(cmd, [], env={"FLAG_X": " YES "}).stdout == "True\n"
    assert runner.invoke(cmd, [], env={"FLAG_X": "  "}).stdout == "False\n"
    res = runner.invoke(cmd, [], env={"FLAG_X": "maybe"})
    assert res.exit_code == 2


def test_parameter_source_values(runner):
    @o.command()
    @o.option("--a", default="x")
    @o.option("--b", envvar="BEE")
    def cmd(a, b):
        ctx = o.get_current_context()
        o.echo(f"{ctx.get_parameter_source('a').name} {ctx.get_parameter_source('b').name}")
        o.echo(str(ctx.get_parameter_source("zzz")))

    out = runner.invoke(cmd, ["--a", "q"], env={"BEE": "1"}).stdout
    assert out.splitlines() == ["COMMANDLINE ENVIRONMENT", "None"]


def test_invoke_and_forward_between_commands(runner):
    @o.command()
    @o.option("--n", type=int, default=1)
    def target(n):
        o.echo(f"target n={n}")

    @o.command()
    @o.option("--n", type=int, default=2)
    def src(n):
        ctx = o.get_current_context()
        ctx.forward(target)
        ctx.invoke(target, n=99)

    assert runner.invoke(src, ["--n", "5"]).stdout == "target n=5\ntarget n=99\n"


def test_make_pass_decorator_ensure(runner):
    class Thing:
        pass

    pass_thing = o.make_pass_decorator(Thing, ensure=True)

    @o.command()
    @pass_thing
    def cmd(thing):
        o.echo(type(thing).__name__)

    assert runner.invoke(cmd, []).stdout == "Thing\n"


def test_get_current_context_silent():
    assert o.get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        o.get_current_context()


def test_resource_closed_when_invocation_ends(runner):
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            closed.append(True)

    @o.command()
    def cmd():
        o.get_current_context().with_resource(Res())

    runner.invoke(cmd, [])
    assert closed == [True]


# ----------------------------------------------------------------------
# Prompts and confirmation (FP-08)
# ----------------------------------------------------------------------


def test_prompt_reasks_on_conversion_failure(runner):
    @o.command()
    @o.option("--n", prompt=True, type=int)
    def cmd(n):
        o.echo(str(n))

    res = runner.invoke(cmd, [], input="abc\n12\n")
    assert res.stdout.endswith("12\n")
    assert "not a valid integer" in res.stdout + res.stderr


def test_prompt_skipped_when_supplied(runner):
    @o.command()
    @o.option("--n", prompt=True)
    def cmd(n):
        o.echo(n)

    res = runner.invoke(cmd, ["--n", "z"], input="ignored\n")
    assert res.stdout == "z\n"


def test_prompt_eof_is_abort(runner):
    @o.command()
    @o.option("--n", prompt=True)
    def cmd(n):
        pass

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_standalone_confirm_default_and_reask(runner):
    @o.command()
    def cmd():
        o.echo(str(o.confirm("Go?", default=True)))

    assert runner.invoke(cmd, [], input="\n").stdout.endswith("True\n")
    assert runner.invoke(cmd, [], input="maybe\nno\n").stdout.endswith("False\n")


def test_confirm_abort_flag(runner):
    @o.command()
    def cmd():
        o.confirm("Go?", abort=True)
        o.echo("went")

    res = runner.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1 and "went" not in res.stdout


def test_password_option_mismatch(runner):
    @o.command()
    @o.password_option()
    def cmd(password):
        o.echo(password)

    res = runner.invoke(cmd, [], input="a\nb\n")
    assert res.exit_code == 1


# ----------------------------------------------------------------------
# Terminal helpers (FP-11)
# ----------------------------------------------------------------------


def test_style_and_unstyle_roundtrip():
    styled = o.style("hi", fg="red", bold=True)
    assert styled != "hi"
    assert o.unstyle(styled) == "hi"


def test_style_invalid_color_raises():
    with pytest.raises(TypeError):
        o.style("x", fg="notacolor")
    with pytest.raises(TypeError):
        o.style("x", fg=300)


def test_echo_strips_styles_on_non_terminal(runner):
    @o.command()
    def cmd():
        o.echo(o.style("plain", fg="green"))
        o.echo(o.style("kept", fg="green"), color=True)

    res = runner.invoke(cmd, [])
    assert res.stdout == "plain\n" + o.style("kept", fg="green") + "\n"


def test_secho_forced_color(runner):
    @o.command()
    def cmd():
        o.secho("x", fg="blue", color=True)

    assert "\x1b[" in runner.invoke(cmd, []).stdout


def test_echo_bytes(runner):
    @o.command()
    def cmd():
        o.echo(b"raw bytes")

    assert runner.invoke(cmd, []).stdout_bytes == b"raw bytes\n"


def test_echo_to_stderr(runner):
    @o.command()
    def cmd():
        o.echo("oops", err=True)

    res = runner.invoke(cmd, [])
    assert res.stderr == "oops\n" and res.stdout == ""


def test_wrap_text_preserves_backspace_paragraph():
    from optlyn.formatting import wrap_text

    text = "\b\nkeep\nlines\n\nthis paragraph is long and gets wrapped into shorter lines"
    out = wrap_text(text, width=20)
    assert "keep\nlines" in out
    assert "\b" not in out
    assert all(len(line) <= 20 for line in out.splitlines())


def test_format_filename_and_app_dir(monkeypatch, tmp_path):
    assert o.format_filename("a/b.txt", shorten=True) == "b.txt"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    monkeypatch.setattr("sys.platform", "linux")
    assert o.get_app_dir("My  App") == os.path.join(str(tmp_path), "my-app")
    assert o.get_app_dir("My App", force_posix=True) == os.path.join(os.path.expanduser("~"), ".my-app")


def test_pause_does_not_block_when_not_interactive(runner):
    @o.command()
    def cmd():
        o.pause("wait please")

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 0
    assert "wait please" in res.stdout


def test_progressbar_visits_every_item_when_hidden(runner):
    @o.command()
    def cmd():
        items = list(range(5))
        with o.progressbar(items, label="work", hidden=True) as bar:
            seen = [x for x in bar]
        o.echo(str(seen))

    res = runner.invoke(cmd, [])
    assert res.stdout == "[0, 1, 2, 3, 4]\n"


def test_editor_and_launch_exist():
    assert callable(o.edit) and callable(o.launch) and callable(o.clear)


def test_echo_via_pager_writes_everything(runner):
    @o.command()
    def cmd():
        o.echo_via_pager(iter(["a\n", "b\n"]))

    assert runner.invoke(cmd, []).stdout == "a\nb\n"


# ----------------------------------------------------------------------
# In-process runner (FP-14)
# ----------------------------------------------------------------------


def test_runner_captures_exception_and_exit_code(runner):
    @o.command()
    def cmd():
        raise RuntimeError("bad")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1 and isinstance(res.exception, RuntimeError)


def test_runner_env_none_unsets(runner, monkeypatch):
    monkeypatch.setenv("KEEP_ME_OUT", "1")

    @o.command()
    @o.option("--v", envvar="KEEP_ME_OUT", default="d")
    def cmd(v):
        o.echo(v)

    assert runner.invoke(cmd, [], env={"KEEP_ME_OUT": None}).stdout == "d\n"


def test_runner_output_in_write_order(runner):
    @o.command()
    def cmd():
        o.echo("one")
        o.echo("two", err=True)
        o.echo("three")

    res = runner.invoke(cmd, [])
    assert res.output == "one\ntwo\nthree\n"


def test_runner_echo_stdin_mode(runner):
    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        pass

    echoing = CliRunner(echo_stdin=True)
    res = echoing.invoke(cmd, [], input="Zed\n")
    assert "Zed" in res.stdout


def test_isolated_filesystem_creates_and_removes(runner):
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
        cwd_inside = os.getcwd()
        assert os.path.realpath(cwd_inside) == os.path.realpath(path)
    assert not os.path.exists(path)


# ----------------------------------------------------------------------
# Shell completion (FP-12)
# ----------------------------------------------------------------------


def _complete(runner, cli, words, cword, shell="bash", prog="tool"):
    env = {
        "_TOOL_COMPLETE": f"{shell}_complete",
        "COMP_WORDS": " ".join(words),
        "COMP_CWORD": str(cword),
    }
    res = runner.invoke(cli, [], env=env, prog_name=prog)
    return res.stdout.splitlines(), res.exit_code


def test_completion_subcommands_options_and_choices(runner):
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--mode", type=o.Choice(["fast", "slow"]))
    def run_it(mode):
        pass

    @cli.command(hidden=True)
    def hidden_one():
        pass

    names, code = _complete(runner, cli, ["tool", ""], 1)
    assert code == 0 and "run-it" in names and "hidden-one" not in names
    names, _ = _complete(runner, cli, ["tool", "run-it", "--"], 2)
    assert "--mode" in names and "--help" in names
    names, _ = _complete(runner, cli, ["tool", "run-it", "--mode", "f"], 3)
    assert names == ["fast"]


def test_completion_path_request(runner):
    @o.command()
    @o.argument("p", type=o.Path(dir_okay=True, file_okay=False))
    def cmd(p):
        pass

    names, _ = _complete(runner, cmd, ["tool", ""], 1)
    assert any(line.startswith("__optlyn_path_dir__") for line in names)


def test_completion_source_script(runner):
    @o.command()
    def cmd():
        pass

    res = runner.invoke(cmd, [], env={"_TOOL_COMPLETE": "bash_source"}, prog_name="tool")
    assert res.exit_code == 0
    assert "complete -o default -F" in res.stdout
    assert "_TOOL_COMPLETE=bash_complete" in res.stdout


def test_completion_unknown_instruction_prints_nothing(runner):
    @o.command()
    def cmd():
        o.echo("ran")

    res = runner.invoke(cmd, [], env={"_TOOL_COMPLETE": "tcsh_source"}, prog_name="tool")
    assert res.stdout == "" and res.exit_code != 0


def test_completion_ignored_for_other_program_name(runner):
    @o.command()
    def cmd():
        o.echo("ran")

    res = runner.invoke(cmd, [], env={"_OTHER_COMPLETE": "bash_source"}, prog_name="tool")
    assert res.stdout == "ran\n"


def test_fd_capture_sees_os_level_writes():
    import os as _os

    @o.command()
    def cmd():
        _os.write(1, b"os-level\n")
        o.echo("py-level")
        o.echo("err", err=True)

    res = CliRunner(capture="fd").invoke(cmd, [])
    assert res.exit_code == 0
    assert "os-level" in res.stdout and "py-level" in res.stdout
    assert res.stderr == "err\n"
