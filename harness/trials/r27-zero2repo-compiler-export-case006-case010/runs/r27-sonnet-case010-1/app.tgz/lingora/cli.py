"""Command line.  # spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420"""
import io
import sys


class UsageError(Exception):
    pass


class _Group:
    def __init__(self):
        self.commands = {"tokenize": self._tokenize}

    def main(self, args=None, standalone_mode=True, prog_name="lingora"):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            self._dispatch(args)
        except SystemExit:
            raise
        except BaseException as e:  # failure
            if not standalone_mode:
                raise
            if isinstance(e, KeyboardInterrupt):
                print("Aborted!", file=sys.stderr)
                sys.exit(1)
            code = 2 if isinstance(e, UsageError) else 1
            print("Error: %s" % (e,), file=sys.stderr)
            sys.exit(code)
        if standalone_mode:
            sys.exit(0)
        return 0

    __call__ = main

    def _dispatch(self, args):
        if not args:
            raise UsageError("Missing command. Available: " + ", ".join(self.commands))
        cmd = args[0]
        if cmd not in self.commands:
            raise UsageError("No such command %r." % cmd)
        self.commands[cmd](args[1:])

    def _tokenize(self, args):
        language, delimiter, encoding = "english", " ", "utf-8"
        i = 0
        while i < len(args):
            a = args[i]
            if a in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
                if i + 1 >= len(args):
                    raise UsageError("Option %s requires an argument." % a)
                v = args[i + 1]
                i += 2
            elif a.startswith("--") and "=" in a:
                a, v = a.split("=", 1)
                i += 1
            else:
                raise UsageError("Unexpected argument %r." % a)
            if a in ("-l", "--language"):
                language = v
            elif a in ("-d", "--delimiter"):
                delimiter = v
            elif a in ("-e", "--encoding"):
                encoding = v
            else:
                raise UsageError("No such option: %s" % a)
        from .tokenize import word_tokenize, get_sent_tokenizer
        get_sent_tokenizer(language)  # fail early when the Punkt model is missing
        stdin = sys.stdin
        if hasattr(stdin, "buffer"):
            stream = io.TextIOWrapper(stdin.buffer, encoding=encoding, newline=None)
        else:
            stream = stdin
        for line in stream:
            line = line.rstrip("\r\n")
            out = delimiter.join(word_tokenize(line, language=language))
            sys.stdout.write(out + "\n")
        sys.stdout.flush()


cli = _Group()

if __name__ == "__main__":
    cli.main()
