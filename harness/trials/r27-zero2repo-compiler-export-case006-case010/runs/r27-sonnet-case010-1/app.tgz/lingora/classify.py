"""Classifiers.  # spec: N-000492 N-000493"""
import math
from collections import Counter, OrderedDict


class DictionaryProbDist:
    """Probability distribution over labels.  # spec: N-000496 N-000497"""

    def __init__(self, logprobs):
        self._keys = list(logprobs)
        if logprobs:
            m = max(logprobs.values())
            tot = m + math.log(sum(math.exp(v - m) for v in logprobs.values()))
            self._p = {k: math.exp(v - tot) for k, v in logprobs.items()}
        else:
            self._p = {}

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._keys)

    def max(self):
        return max(self._keys, key=lambda k: self._p[k])


class NaiveBayesClassifier:
    def __init__(self, label_logprob, feature_logprob, labels):
        self._label_logprob = label_logprob      # label -> log P(label)
        self._feature = feature_logprob          # (label, fname) -> (counter, N, bins)
        self._labels = list(labels)
        self._fnames = {f for (_, f) in feature_logprob}

    @classmethod
    def train(cls, labeled_featuresets):
        # spec: N-000302 N-000303
        labeled_featuresets = list(labeled_featuresets)
        label_freq = OrderedDict()
        feat = {}
        values = {}
        fnames = OrderedDict()
        for fs, label in labeled_featuresets:
            label_freq[label] = label_freq.get(label, 0) + 1
            for fname, fval in fs.items():
                feat.setdefault((label, fname), Counter())[fval] += 1
                values.setdefault(fname, set()).add(fval)
                fnames[fname] = True
        n_label = {l: c for l, c in label_freq.items()}
        for label in label_freq:
            for fname in fnames:
                c = feat.setdefault((label, fname), Counter())
                missing = label_freq[label] - sum(c.values())
                if missing > 0:
                    c[None] += missing
                    values[fname].add(None)
        total = sum(label_freq.values())
        nl = len(label_freq)
        label_logprob = {l: math.log((c + 0.5) / (total + 0.5 * nl)) for l, c in label_freq.items()}
        feature = {}
        for (label, fname), c in feat.items():
            feature[(label, fname)] = (c, sum(c.values()), len(values[fname]))
        return cls(label_logprob, feature, list(label_freq))

    def labels(self):
        # spec: N-000309
        return list(self._labels)

    def _flp(self, label, fname, fval):
        c, n, bins = self._feature[(label, fname)]
        return math.log((c.get(fval, 0) + 0.5) / (n + 0.5 * bins))

    def prob_classify(self, featureset):
        # spec: N-000304 N-000305 N-000307 N-000308
        lp = {}
        for label in self._labels:
            s = self._label_logprob[label]
            for fname, fval in featureset.items():
                if fname in self._fnames:
                    s += self._flp(label, fname, fval)
            lp[label] = s
        return DictionaryProbDist(lp)

    def classify(self, featureset):
        # spec: N-000306
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]


def _entropy(counter):
    n = sum(counter.values())
    if n == 0:
        return 0.0
    return -sum((c / n) * math.log(c / n, 2) for c in counter.values() if c)


def _max_label(labels):
    c = Counter()
    for l in labels:
        c[l] += 1
    return c.most_common(1)[0][0]  # ties: first seen


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions

    def classify(self, featureset):
        # spec: N-000312 N-000313 N-000315 N-000316 N-000317
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]

    @staticmethod
    def _stump(fname, data):
        label = _max_label(l for _, l in data)
        groups = OrderedDict()
        for fs, l in data:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_max_label(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    def _error(self, data):
        errs = sum(1 for fs, l in data if self.classify(fs) != l)
        return errs / len(data)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        # spec: N-000310 N-000311 N-000314
        data = list(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on an empty list")
        names = OrderedDict()
        for fs, _ in data:
            for f in fs:
                names[f] = True
        best = None
        best_err = 1.0
        for f in names:
            st = cls._stump(f, data)
            e = st._error(data)
            if best is None or e < best_err:
                best, best_err = st, e
        if best is None:
            best = cls(_max_label(l for _, l in data))
        best._refine(data, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return best

    def _refine(self, data, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(data) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in data if fs.get(self._fname) == fval]
            if _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)


def accuracy(classifier, gold):
    # spec: N-000494 N-000495
    gold = list(gold)
    if not gold:
        return 0.0
    ok = sum(1 for fs, l in gold if classifier.classify(fs) == l)
    return ok / len(gold)
