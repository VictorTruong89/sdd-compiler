"""Sentence-level BLEU.  # spec: N-000500 N-000335"""
import math
import sys
from collections import Counter
from fractions import Fraction


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def _modified_precision(references, hypothesis, n):
    # spec: N-000336
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())))


def _closest_ref_length(references, hyp_len):
    # spec: N-000339
    lens = (len(r) for r in references)
    return min(lens, key=lambda rl: (abs(rl - hyp_len), rl))


def _brevity_penalty(closest, hyp_len):
    if hyp_len > closest:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method0(self, p_n, *a, **k):
        return [p if p.numerator != 0 else sys.float_info.min for p in p_n]

    def method1(self, p_n, *a, **k):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, *a, **k):
        return [Fraction(p.numerator + 1, p.denominator + 1) if i != 0 else p for i, p in enumerate(p_n)]


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    # spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000337 N-000338 N-000340 N-000341 N-000342
    weights = tuple(weights)
    p_n = [_modified_precision(references, hypothesis, i) for i, _ in enumerate(weights, start=1)]
    if not p_n or p_n[0].numerator == 0:
        return 0
    hyp_len = len(hypothesis)
    bp = _brevity_penalty(_closest_ref_length(references, hyp_len), hyp_len)
    if smoothing_function is None:
        p_new = SmoothingFunction().method0(p_n)
    else:
        try:
            p_new = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
        except TypeError:
            p_new = smoothing_function(p_n)
    s = math.fsum(w * math.log(float(p)) for w, p in zip(weights, p_new))
    return bp * math.exp(s)
