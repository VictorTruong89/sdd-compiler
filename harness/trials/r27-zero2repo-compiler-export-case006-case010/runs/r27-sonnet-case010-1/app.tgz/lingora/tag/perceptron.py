"""Averaged perceptron tagger (textblob-aptagger).  # spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214"""
import json
import os
from collections import defaultdict

from .. import data

_CACHE = {}
START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1
        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            w = self.weights.get(feat)
            if w is None or value == 0:
                continue
            for label, weight in w.items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = START
        out = []
        context = START + [self.normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


def load(lang):
    # spec: N-000390 N-000391 N-000400 N-000224 N-000225
    d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
    files = [base + s for s in (".weights.json", ".tagdict.json", ".classes.json")]
    for f in files:
        if not os.path.isfile(f):
            raise data.ResourceNotFound("missing tagger file %s" % f)
    key = tuple((f, os.stat(f).st_mtime_ns, os.stat(f).st_size) for f in files)
    if key in _CACHE:
        return _CACHE[key]
    loaded = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            loaded.append(json.load(fh))
    t = PerceptronTagger(*loaded)
    _CACHE.clear()
    _CACHE[key] = t
    return t
