"""Taggers.  # spec: N-000433 N-000434"""
from .sequential import (DefaultTagger, RegexpTagger, UnigramTagger, BigramTagger, TrigramTagger,  # noqa: F401
                         AffixTagger, SequentialBackoffTagger)
from .perceptron import PerceptronTagger  # noqa: F401
from . import perceptron as _perceptron
from .. import data as _data

_RU_UNIVERSAL = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ", "CONJ": "CONJ",
    "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT", "PART": "PRT", "PR": "ADP",
    "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON", "S": "NOUN", "S-PRO": "PRON", "V": "VERB", "COM": "X",
}


def _en_map():
    import os
    d = _data.find("taggers/universal_tagset")
    f = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(f):
        raise _data.ResourceNotFound("universal tagset table en-ptb.map not found")
    m = {}
    for line in _data.read_lines(f):
        parts = line.split("\t")
        if len(parts) >= 2:
            m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    # spec: N-000440 N-000441 N-000442 N-000443 N-000219 N-000220 N-000221 N-000222 N-000223 N-000226 N-000227
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("language %r is not supported (use 'eng' or 'rus')" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tokens = list(tokens)
    tagger = _perceptron.load(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            m = _en_map()
            tagged = [(w, None if t is None else m.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, None if t is None else _RU_UNIVERSAL.get(t.split("=")[0], "X"))
                      for w, t in tagged]
    return tagged
