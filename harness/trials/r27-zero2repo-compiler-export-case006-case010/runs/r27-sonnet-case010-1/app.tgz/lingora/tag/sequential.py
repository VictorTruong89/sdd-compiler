import re
from collections import Counter, OrderedDict


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]


class SequentialBackoffTagger(TaggerI):
    """Base: a tagger consulting an optional backoff tagger.  # spec: N-000205 N-000206 N-000439"""

    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag_one") and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self] + (getattr(backoff, "_taggers", [backoff]) if backoff is not None else [])
        self.backoff = backoff

    def tag(self, tokens):
        # spec: N-000196 N-000197 N-000444 N-000445
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a str")
        tokens = list(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    # spec: N-000198
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    # spec: N-000202 N-000203 N-000204 N-000438
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), tag) for rx, tag in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = dict(context_to_tag or {})

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._context_to_tag.get(ctx)

    def _train(self, train, cutoff=0):
        counts = OrderedDict()
        for sent in train or []:
            tokens = [w for w, _ in sent]
            history = []
            for i, (w, t) in enumerate(sent):
                ctx = self.context(tokens, i, history)
                history.append(t)
                if ctx is None:
                    continue
                counts.setdefault(ctx, Counter())[t] += 1
        for ctx, fd in counts.items():
            best, n = fd.most_common(1)[0]  # ties: first seen
            if n > cutoff:
                self._context_to_tag[ctx] = best


class UnigramTagger(ContextTagger):
    # spec: N-000199 N-000200 N-000201 N-000436 N-000437
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        prev = history[index - 1] if index >= 1 else None
        return (prev, tokens[index])


class TrigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        p1 = history[index - 1] if index >= 1 else None
        p2 = history[index - 2] if index >= 2 else None
        return (p2, p1, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]
