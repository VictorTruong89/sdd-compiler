"""Chunking.  # spec: N-000446 N-000447"""
import os
import re

from .. import data
from ..tree import Tree

ROOT_LABEL = "S"  # spec: N-000456 N-000457

_IN_CHINK = r"(?=[^\}]*(\{|$))"
_IN_CHUNK = r"(?=[^\{]*\})"


def tag_pattern2re_pattern(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    depth = 0
    for ch in p:
        if ch == "<":
            depth += 1
            if depth > 1:
                raise ValueError("Bad tag pattern: %r" % tag_pattern)
        elif ch == ">":
            depth -= 1
            if depth < 0:
                raise ValueError("Bad tag pattern: %r" % tag_pattern)
    if depth != 0:
        raise ValueError("Bad tag pattern: %r" % tag_pattern)
    p = p.replace("<", "(?:<(?:").replace(">", ")>)")
    p = re.sub(r"(?<!\\)\.", r"[^\\{\\}<>]", p)
    try:
        re.compile(p)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (tag_pattern, e))
    return p


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        pat = tag_pattern2re_pattern(pattern)
        if kind == "chunk":
            self._re = re.compile(r"(?P<chunk>%s)%s" % (pat, _IN_CHINK))
            self._repl = r"{\g<chunk>}"
        else:
            self._re = re.compile(r"(?P<chunk>%s)%s" % (pat, _IN_CHUNK))
            self._repl = r"}\g<chunk>{"

    def apply(self, s):
        s = self._re.sub(self._repl, s)
        return re.sub(r"\{\}", "", s)

    @staticmethod
    def fromstring(text):
        m = re.match(r"(?P<rule>(\\.|[^#])*)(?P<comment>#.*)?", text)
        rule = m.group("rule").strip()
        if not rule:
            raise ValueError("Empty chunk pattern")
        if rule[0] == "{" and rule[-1] == "}":
            return _Rule("chunk", rule[1:-1])
        if rule[0] == "}" and rule[-1] == "{":
            return _Rule("chink", rule[1:-1])
        raise ValueError("Illegal chunk pattern: %s" % rule)


def _tag_of(tok):
    if isinstance(tok, Tree):
        return tok.label()
    return tok[1]


class RegexpChunkParser:
    """One clause of a chunk grammar.  # spec: N-000246 N-000247 N-000248 N-000249"""

    def __init__(self, rules, chunk_label="NP", root_label=ROOT_LABEL):
        self._rules = rules
        self._chunk_label = chunk_label
        self._root_label = root_label

    def parse(self, tagged):
        pieces = list(tagged.children() if hasattr(tagged, "children") else tagged)
        if not pieces:
            return Tree(self._root_label, [])
        tags = []
        for tok in pieces:
            t = _tag_of(tok)
            if not isinstance(t, str) or re.search(r"[<>{}]", t):
                raise ValueError("Bad tag: %r" % (t,))
            tags.append(t)
        s = "<" + "><".join(tags) + ">"
        for r in self._rules:
            s = r.apply(s)
        tree = Tree(self._root_label, [])
        idx = 0
        in_chunk = False
        for piece in re.split("[{}]", s):
            n = piece.count("<")
            sub = pieces[idx:idx + n]
            if in_chunk:
                tree.append(Tree(self._chunk_label, sub))
            else:
                tree.extend(sub)
            idx += n
            in_chunk = not in_chunk
        return tree


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT_LABEL):
        # spec: N-000449 N-000450 N-000451 N-000253 N-000254 N-000255 N-000256
        self._root_label = root_label
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)):
            for st in grammar:
                if not hasattr(st, "parse"):
                    raise TypeError("grammar stages must be chunk parsers")
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def _parse_grammar(self, text):
        # spec: N-000453 N-000454 N-000459 N-000460
        stages = []
        lhs = None
        rules = []

        def flush():
            if lhs is not None or rules:
                stages.append(RegexpChunkParser(rules, lhs, self._root_label))
        for line in text.split("\n"):
            line = line.strip()
            m = re.match(r"(?P<nonterminal>(\\.|[^:])*)(:(?P<rule>.*))", line)
            if m:
                flush()
                lhs = m.group("nonterminal").strip()
                rules = []
                line = m.group("rule").strip()
            if line == "" or line.startswith("#"):
                continue
            if lhs is None:
                raise ValueError("Grammar rule without a label: %r" % line)
            rules.append(_Rule.fromstring(line))
        flush()
        return stages

    def parse(self, tagged):
        # spec: N-000448 N-000455 N-000458 N-000250 N-000251 N-000252
        if isinstance(tagged, str):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        tagged = list(tagged)
        tree = Tree(self._root_label, tagged)
        for st in self._stages:
            tree = st.parse(tree)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    # spec: N-000452 N-000257
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    if isinstance(tagged_tokens, str):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    # The named-entity model's behaviour is outside the specification: with
    # the resources present, no entity is recognised and a flat tree results.
    return Tree(ROOT_LABEL, list(tagged_tokens))
