"""Constituent trees.  # spec: N-000481 N-000482"""
import re


class Tree(list):
    # spec: N-000483 N-000484 N-000485 N-000486 N-000487 N-000488
    def __init__(self, label, children):
        if isinstance(children, str):
            raise TypeError("Tree children must be a list of children, not a string")
        if children is None or not hasattr(children, "__iter__"):
            raise TypeError("Tree children must be a list of children")
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def pos(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.pos())
            else:
                out.append(c)
        return out

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees(filter)

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._label, tuple(self)))

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    def _flat(self, nodesep="", parens="()"):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat(nodesep, parens))
            elif isinstance(c, tuple):
                parts.append("/".join(str(x) for x in c))
            else:
                parts.append(str(c))
        return "%s%s%s %s%s" % (parens[0], self._label, nodesep, " ".join(parts), parens[1])

    def pformat(self, margin=70, indent=0, nodesep="", parens="()"):
        # spec: N-000490 N-000491 N-000287
        s = self._flat(nodesep, parens)
        if len(s) + indent < margin:
            return s
        s = "%s%s%s" % (parens[0], self._label, nodesep)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2, nodesep, parens)
            elif isinstance(c, tuple):
                s += "\n" + " " * (indent + 2) + "/".join(str(x) for x in c)
            else:
                s += "\n" + " " * (indent + 2) + str(c)
        return s + parens[1]

    @classmethod
    def fromstring(cls, s, brackets="()"):
        # spec: N-000489 N-000286
        op, cl = brackets
        tok = re.compile(r"\%s|\%s|[^\s\%s\%s]+" % (op, cl, op, cl))
        tokens = tok.findall(s)
        pos = 0
        if not tokens or tokens[0] != op:
            raise ValueError("Tree.fromstring: expected %r" % op)

        def parse(i):
            # tokens[i] == op
            i += 1
            label = ""
            if i < len(tokens) and tokens[i] not in (op, cl):
                label = tokens[i]
                i += 1
            children = []
            while True:
                if i >= len(tokens):
                    raise ValueError("Tree.fromstring: missing %r" % cl)
                t = tokens[i]
                if t == cl:
                    return cls(label, children), i + 1
                if t == op:
                    ch, i = parse(i)
                    children.append(ch)
                else:
                    children.append(t)
                    i += 1

        t, end = parse(0)
        if end != len(tokens):
            raise ValueError("Tree.fromstring: extra text after tree")
        return t
