"""Snowball: English (Porter2), Porter, German, Dutch, Swedish, Norwegian, Danish."""
from ._util import r1r2, longest, entries_by_len
from .porter import PorterStemmer

# ---------------------------------------------------------------- english
_EXC1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
         "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
         "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
         "bias": "bias", "andes": "andes"}
_EXC2 = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")
_EV = "aeiouy"
_STEP2 = [("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"), ("entli", "ent"),
          ("izer", "ize"), ("ization", "ize"), ("ational", "ate"), ("ation", "ate"), ("ator", "ate"),
          ("alism", "al"), ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
          ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
          ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", "")]
_STEP2 = sorted(_STEP2, key=lambda x: len(x[0]), reverse=True)
_STEP3 = sorted([("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
                 ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", "")], key=lambda x: len(x[0]), reverse=True)
_STEP4 = entries_by_len(["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
                         "ism", "ate", "iti", "ous", "ive", "ize", "ion"])


def _short_syl(w):
    if len(w) == 2:
        return w[0] in _EV and w[1] not in _EV
    if len(w) >= 3:
        return w[-1] not in _EV and w[-1] not in "wxY" and w[-2] in _EV and w[-3] not in _EV
    return False


def stem_english(word):
    word = word.lower()
    if len(word) <= 2:
        return word
    if word in _EXC1:
        return _EXC1[word]
    if word.startswith("'"):
        word = word[1:]
    if len(word) <= 2:
        return word
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(chars)):
        if chars[i - 1] in _EV and chars[i] == "y":
            chars[i] = "Y"
    word = "".join(chars)
    if word.startswith(("gener", "arsen")):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1, _ = r1r2(word, _EV)
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _EV and word[i - 1] in _EV:
            r2 = i + 1
            break

    def in_r1(suf):
        return len(word) - len(suf) >= r1

    def in_r2(suf):
        return len(word) - len(suf) >= r2

    # Step 0
    for s in ("'s'", "'s", "'"):
        if word.endswith(s):
            word = word[:-len(s)]
            break
    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-2] if len(word) > 4 else word[:-1]
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        if any(c in _EV for c in word[:-2]):
            word = word[:-1]
    if word in _EXC2:
        return word
    # Step 1b
    suf = longest(word, ("eedly", "ingly", "edly", "eed", "ing", "ed"))
    if suf:
        if suf in ("eed", "eedly"):
            if in_r1(suf):
                word = word[:-len(suf)] + "ee"
        else:
            pre = word[:-len(suf)]
            if any(c in _EV for c in pre):
                word = pre
                if word.endswith(("at", "bl", "iz")):
                    word += "e"
                elif word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                    word = word[:-1]
                elif len(word) - 0 <= max(r1, 0) and _short_syl(word):
                    word += "e"
    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _EV:
        word = word[:-1] + "i"
    # Step 2
    for s, rep in _STEP2:
        if word.endswith(s):
            if s == "ogi" and not word[:-3].endswith("l"):
                continue
            if s == "li" and not (len(word) > 2 and word[-3] in "cdeghkmnrt"):
                continue
            if in_r1(s):
                word = word[:-len(s)] + rep
            break
    # Step 3
    for s, rep in _STEP3:
        if word.endswith(s):
            if s == "ative":
                if in_r2(s):
                    word = word[:-len(s)]
            elif in_r1(s):
                word = word[:-len(s)] + rep
            break
    # Step 4
    for s in _STEP4:
        if word.endswith(s):
            if s == "ion":
                if in_r2(s) and word[:-3].endswith(("s", "t")):
                    word = word[:-3]
                    break
                continue
            if in_r2(s):
                word = word[:-len(s)]
            break
    # Step 5
    if word.endswith("e"):
        if in_r2("e") or (in_r1("e") and not _short_syl(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if in_r2("l") and word[-2:-1] == "l":
            word = word[:-1]
    return word.replace("Y", "y")


_porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)


def stem_porter(word):
    return _porter.stem(word.lower())


# ---------------------------------------------------------------- german
_GV = "aeiouyäöü"


def stem_german(word):
    word = word.lower().replace("ß", "ss")
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i - 1] in _GV and word[i + 1] in _GV:
            if word[i] == "u":
                chars[i] = "U"
            elif word[i] == "y":
                chars[i] = "Y"
    word = "".join(chars)
    r1, r2 = r1r2(word, _GV)
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    if r1 > len(word):
        r1 = len(word)
    r2 = max(r2, r1)

    def in_r(suf, r):
        return len(word) - len(suf) >= r

    # Step 1
    s = longest(word, ("ern", "em", "er", "e", "en", "es", "s"))
    if s and in_r(s, r1):
        if s in ("ern", "em", "er"):
            word = word[:-len(s)]
        elif s in ("e", "en", "es"):
            word = word[:-len(s)]
            if word.endswith("niss"):
                word = word[:-1]
        elif s == "s" and len(word) > 1 and word[-2] in "bdfghklmnrt":
            word = word[:-1]
    # Step 2
    s = longest(word, ("en", "er", "est", "st"))
    if s and in_r(s, r1):
        if s in ("en", "er", "est"):
            word = word[:-len(s)]
        elif s == "st" and len(word) >= 6 and word[-3] in "bdfghklmnt":
            word = word[:-2]
    # Step 3
    s = longest(word, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
    if s and in_r(s, r2):
        if s in ("end", "ung"):
            word = word[:-len(s)]
            if word.endswith("ig") and in_r("ig", r2) and word[-3:-2] != "e":
                word = word[:-2]
        elif s in ("ig", "ik", "isch"):
            if word[-len(s) - 1:-len(s)] != "e":
                word = word[:-len(s)]
        elif s in ("lich", "heit"):
            word = word[:-len(s)]
            t = longest(word, ("er", "en"))
            if t and in_r(t, r1):
                word = word[:-len(t)]
        elif s == "keit":
            word = word[:-4]
            t = longest(word, ("lich", "ig"))
            if t and in_r(t, r2):
                word = word[:-len(t)]
    word = word.replace("U", "u").replace("Y", "y")
    return word.replace("ä", "a").replace("ö", "o").replace("ü", "u")


# ---------------------------------------------------------------- dutch
_DV = "aeiouyè"


def _undouble(word):
    return word[:-1] if word.endswith(("kk", "dd", "tt")) else word


def stem_dutch(word):
    word = word.lower()
    for a, b in (("ä", "a"), ("á", "a"), ("ë", "e"), ("é", "e"), ("í", "i"), ("ï", "i"),
                 ("ö", "o"), ("ó", "o"), ("ü", "u"), ("ú", "u")):
        word = word.replace(a, b)
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(word)):
        if word[i - 1] in _DV and word[i] == "y":
            chars[i] = "Y"
    word = "".join(chars)
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i - 1] in _DV and word[i] == "i" and word[i + 1] in _DV:
            chars[i] = "I"
    word = "".join(chars)
    r1, r2 = r1r2(word, _DV)
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    r2 = max(r2, r1)
    if len(word) == 0:
        return word

    def in_r(suf, r):
        return len(word) - len(suf) >= r

    def valid_en(w, suf):
        pre = w[:-len(suf)]
        return len(pre) > 0 and pre[-1] not in _DV and not pre.endswith("gem")

    def step_en(word):
        s = longest(word, ("en", "ene"))
        if s and in_r(s, r1) and valid_en(word, s):
            word = _undouble(word[:-len(s)])
        return word

    # Step 1
    s = longest(word, ("heden", "ene", "en", "se", "s"))
    if s and in_r(s, r1):
        if s == "heden":
            word = word[:-5] + "heid"
        elif s in ("en", "ene"):
            if valid_en(word, s):
                word = _undouble(word[:-len(s)])
        else:
            pre = word[:-len(s)]
            if pre and pre[-1] not in _DV and pre[-1] != "j":
                word = pre
    # Step 2
    step2 = False

    def do_step2(word):
        if word.endswith("e") and len(word) - 1 >= r1 and len(word) > 1 and word[-2] not in _DV:
            return _undouble(word[:-1]), True
        return word, False
    word, step2 = do_step2(word)
    # Step 3a
    if word.endswith("heid") and len(word) - 4 >= r2 and word[-5:-4] != "c":
        word = word[:-4]
        if word.endswith("en") and len(word) - 2 >= r1 and valid_en(word, "en"):
            word = _undouble(word[:-2])
    # Step 3b
    s = longest(word, ("end", "ing", "ig", "lijk", "baar", "bar"))
    if s and in_r(s, r2):
        if s in ("end", "ing"):
            word = word[:-3]
            if word.endswith("ig") and len(word) - 2 >= r2 and word[-3:-2] != "e":
                word = word[:-2]
            else:
                word = _undouble(word)
        elif s == "ig":
            if word[-3:-2] != "e":
                word = word[:-2]
        elif s == "lijk":
            word = word[:-4]
            word, _ = do_step2(word)
        elif s == "baar":
            word = word[:-4]
        elif s == "bar" and step2:
            word = word[:-3]
    # Step 4
    if (len(word) >= 4 and word[-1] not in _DV and word[-1] != "I" and word[-2] == word[-3]
            and word[-2] in "aeou" and word[-4] not in _DV):
        word = word[:-2] + word[-1]
    return word.replace("Y", "y").replace("I", "i")


# ---------------------------------------------------------------- scandinavian
def _scand(word, vowels, step1, s_end, step2, step3, r1_min=3, repl=None, k_rule=False, repl1=None):
    word = word.lower()
    r1 = r1r2(word, vowels)[0]
    r1 = max(r1, r1_min) if len(word) >= r1_min else len(word)

    def in_r1(suf):
        return len(word) - len(suf) >= r1
    return word, r1, in_r1


_SW_STEP1 = ["a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are", "aste", "en",
             "anden", "aren", "heten", "ern", "ar", "er", "or", "as", "arnas", "ernas", "ornas", "es", "ades",
             "andes", "ens", "arens", "hetens", "erns", "at", "andet", "het", "ast"]


def stem_swedish(word):
    v = "aeiouyäåö"
    word = word.lower()
    r1 = r1r2(word, v)[0]
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    s = longest(word, _SW_STEP1 + ["s"])
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) > 1 and word[-2] in "bcdfghjklmnoprtvy":
                word = word[:-1]
        else:
            word = word[:-len(s)]
    s = longest(word, ("dd", "gd", "nn", "dt", "gt", "kt", "tt"))
    if s and len(word) - len(s) >= r1:
        word = word[:-1]
    s = longest(word, ("lig", "ig", "els", "löst", "fullt"))
    if s and len(word) - len(s) >= r1:
        if s in ("lig", "ig", "els"):
            word = word[:-len(s)]
        elif s == "löst":
            word = word[:-1]
        else:
            word = word[:-1]
    return word


_DA_STEP1 = ["hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en", "heden",
             "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes", "ernes", "eres", "ens",
             "hedens", "erens", "ers", "ets", "erets", "et", "eret"]


def stem_danish(word):
    v = "aeiouyæåø"
    word = word.lower()
    r1 = r1r2(word, v)[0]
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    s = longest(word, _DA_STEP1 + ["s"])
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) > 1 and word[-2] in "abcdfghjklmnoprtvyzå":
                word = word[:-1]
        else:
            word = word[:-len(s)]

    def step2(word):
        s = longest(word, ("gd", "dt", "gt", "kt"))
        if s and len(word) - len(s) >= r1:
            return word[:-1]
        return word
    word = step2(word)
    if word.endswith("igst") and len(word) - 4 >= r1:
        word = word[:-2]
    s = longest(word, ("elig", "lig", "ig", "els", "løst"))
    if s and len(word) - len(s) >= r1:
        if s == "løst":
            word = word[:-1]
        else:
            word = step2(word[:-len(s)])
    if len(word) - 1 >= r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in v:
        word = word[:-1]
    return word


_NO_STEP1 = ["a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er", "heter",
             "as", "es", "edes", "endes", "enes", "hetenes", "ens", "hetens", "ers", "ets", "et", "het", "ast"]


def stem_norwegian(word):
    v = "aeiouyæåø"
    word = word.lower()
    r1 = r1r2(word, v)[0]
    r1 = max(r1, 3) if len(word) >= 3 else len(word)
    s = longest(word, _NO_STEP1 + ["s", "erte", "ert"])
    if s and len(word) - len(s) >= r1:
        if s == "s":
            if len(word) > 1 and (word[-2] in "bcdfghjlmnoprtvyz"
                                  or (word[-2] == "k" and len(word) > 2 and word[-3] not in v)):
                word = word[:-1]
        elif s in ("erte", "ert"):
            word = word[:-len(s)] + "er"
        else:
            word = word[:-len(s)]
    s = longest(word, ("dt", "vt"))
    if s and len(word) - len(s) >= r1:
        word = word[:-1]
    s = longest(word, ("hetslov", "eleg", "elov", "slov", "elig", "eig", "leg", "lig", "els", "lov", "ig"))
    if s and len(word) - len(s) >= r1:
        word = word[:-len(s)]
    return word
