"""Porter stemmer.  # spec: N-000149 N-000150 N-000151 N-000153"""

_IRREGULAR = {
    "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
    "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
    "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
    "exceed": ["exceed"], "succeed": ["succeed"],
}


class PorterStemmer:
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("Mode must be one of PorterStemmer.NLTK_EXTENSIONS, "
                             "PorterStemmer.MARTIN_EXTENSIONS, or PorterStemmer.ORIGINAL_ALGORITHM")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            for key, vals in _IRREGULAR.items():
                for v in vals:
                    self.pool[v] = key

    def _is_consonant(self, word, i):
        if word[i] in "aeiou":
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        seq = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return seq.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        # spec: N-000161
        return (
            len(word) >= 3 and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1) and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS and len(word) == 2
            and not self._is_consonant(word, 0) and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        # Step 1a as published (ties -> ti); see NOTES.md (CF-000073).  # spec: N-000424
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None),
                                            ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS and word.endswith("ied"):
            # spec: N-000159 N-000160
            if len(word) == 4:
                return self._replace_suffix(word, "ied", "ie")
            return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = word
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def nltk_cond(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)

        def orig_cond(stem):
            return self._contains_vowel(stem)
        return self._apply_rule_list(word, [("y", "i", nltk_cond if self.mode == self.NLTK_EXTENSIONS else orig_cond)])

    def _step2(self, word):
        pm = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pm) if self.mode == self.NLTK_EXTENSIONS else ("abli", "able", pm)
        rules = [("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm), ("anci", "ance", pm),
                 ("izer", "ize", pm), bli, ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm),
                 ("ousli", "ous", pm), ("ization", "ize", pm), ("ation", "ate", pm), ("ator", "ate", pm),
                 ("alism", "al", pm), ("iveness", "ive", pm), ("fulness", "ful", pm), ("ousness", "ous", pm),
                 ("aliti", "al", pm), ("iviti", "ive", pm), ("biliti", "ble", pm)]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda stem: pm(word[:-3])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm),
                                            ("iciti", "ic", pm), ("ical", "ic", pm), ("ful", "", pm),
                                            ("ness", "", pm)])

    def _step4(self, word):
        gt1 = lambda stem: self._measure(stem) > 1
        sufs = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent"]
        rules = [(s, "", gt1) for s in sufs]
        rules.append(("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")))
        rules += [(s, "", gt1) for s in ["ou", "ism", "ate", "iti", "ous", "ive", "ize"]]
        return self._apply_rule_list(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=False):
        # spec: N-000152 N-000154 N-000155 N-000156 N-000157 N-000422 N-000423 N-000425 N-000426
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and word.lower() in self.pool:
            return self.pool[word.lower()]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        for step in (self._step1a, self._step1b, self._step1c, self._step2, self._step3,
                     self._step4, self._step5a, self._step5b):
            stem = step(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"
