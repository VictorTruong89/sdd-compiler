"""Snowball: Spanish, French, Italian, Portuguese, Russian."""
from ._util import r1r2, longest, entries_by_len


def _rv_romance(word, vowels):
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
        return n
    return 3 if n >= 3 else n


def _strip_acute(word, table):
    for a, b in table:
        word = word.replace(a, b)
    return word


# ---------------------------------------------------------------- spanish
_SV = "aeiouáéíóúü"
_ES_PRON = ["me", "se", "sela", "selo", "selas", "selos", "la", "le", "lo", "las", "les", "los", "nos"]
_ES_S1 = {
    "r2del": ["anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible", "ibles",
              "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos", "imiento", "imientos"],
    "ic": ["adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias"],
}
_ES_Y = ["ya", "ye", "yan", "yen", "yeron", "yendo", "yo", "yó", "yas", "yes", "yais", "yamos"]
_ES_V2A = ["en", "es", "éis", "emos"]
_ES_V2B = """arían arías arán arás aríais aría aréis aríamos aremos ará aré erían erías erán erás eríais ería eréis
eríamos eremos erá eré irían irías irán irás iríais iría iréis iríamos iremos irá iré aba ada ida ía ara iera ad ed
id ase iese aste iste an aban ían aran ieran asen iesen aron ieron ado ido ando iendo ió ar er ir as abas adas idas
ías aras ieras ases ieses ís áis abais íais arais ierais aseis ieseis asteis isteis ados idos amos ábamos íamos imos
áramos iéramos iésemos ásemos""".split()


def stem_spanish(word):
    word = word.lower()
    r1, r2 = r1r2(word, _SV)
    rv = _rv_romance(word, _SV)

    def ok(w, suf, r):
        return len(w) - len(suf) >= r

    # Step 0
    s = longest(word, _ES_PRON)
    if s and ok(word, s, rv):
        pre = word[:-len(s)]
        for a, b in (("iéndo", "iendo"), ("ándo", "ando"), ("ár", "ar"), ("ér", "er"), ("ír", "ir")):
            if pre.endswith(a) and ok(pre, a, rv):
                word = pre[:-len(a)] + b
                break
        else:
            for a in ("iendo", "ando", "ar", "er", "ir"):
                if pre.endswith(a) and ok(pre, a, rv):
                    word = pre
                    break
            else:
                if pre.endswith("yendo") and pre[-6:-5] == "u" and ok(pre, "yendo", rv):
                    word = pre
    orig = word
    # Step 1
    sufs = (_ES_S1["r2del"] + _ES_S1["ic"] + ["logía", "logías", "ución", "uciones", "encia", "encias",
            "amente", "mente", "idad", "idades", "iva", "ivo", "ivas", "ivos"])
    s = longest(word, sufs)
    done = False
    if s:
        if s in _ES_S1["r2del"] and ok(word, s, r2):
            word = word[:-len(s)]
            done = True
        elif s in _ES_S1["ic"] and ok(word, s, r2):
            word = word[:-len(s)]
            if word.endswith("ic") and ok(word, "ic", r2):
                word = word[:-2]
            done = True
        elif s in ("logía", "logías") and ok(word, s, r2):
            word = word[:-len(s)] + "log"
            done = True
        elif s in ("ución", "uciones") and ok(word, s, r2):
            word = word[:-len(s)] + "u"
            done = True
        elif s in ("encia", "encias") and ok(word, s, r2):
            word = word[:-len(s)] + "ente"
            done = True
        elif s == "amente" and ok(word, s, r1):
            word = word[:-6]
            done = True
            if word.endswith("iv") and ok(word, "iv", r2):
                word = word[:-2]
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
            else:
                for t in ("os", "ic", "ad"):
                    if word.endswith(t) and ok(word, t, r2):
                        word = word[:-len(t)]
                        break
        elif s == "mente" and ok(word, s, r2):
            word = word[:-5]
            done = True
            t = longest(word, ("ante", "able", "ible"))
            if t and ok(word, t, r2):
                word = word[:-len(t)]
        elif s in ("idad", "idades") and ok(word, s, r2):
            word = word[:-len(s)]
            done = True
            t = longest(word, ("abil", "ic", "iv"))
            if t and ok(word, t, r2):
                word = word[:-len(t)]
        elif s in ("iva", "ivo", "ivas", "ivos") and ok(word, s, r2):
            word = word[:-len(s)]
            done = True
            if word.endswith("at") and ok(word, "at", r2):
                word = word[:-2]
    if not done:
        # Step 2a
        s = longest(word, _ES_Y)
        succ = False
        if s and ok(word, s, rv) and word[:-len(s)].endswith("u"):
            word = word[:-len(s)]
            succ = True
        if not succ:
            sufs2 = entries_by_len(_ES_V2A + _ES_V2B)
            s = longest(word, sufs2)
            if s and ok(word, s, rv):
                word = word[:-len(s)]
                if s in _ES_V2A and word.endswith("gu"):
                    word = word[:-1]
    # Residual
    s = longest(word, ("os", "a", "o", "á", "í", "ó", "e", "é"))
    if s and ok(word, s, rv):
        if s in ("e", "é"):
            word = word[:-1]
            if word.endswith("gu") and ok(word, "u", rv):
                word = word[:-1]
        else:
            word = word[:-len(s)]
    return _strip_acute(word, (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")))


# ---------------------------------------------------------------- french
_FV = "aeiouyâàëéêèïîôûù"


def stem_french(word):
    word = word.lower()
    chars = list(word)
    n = len(word)
    for i in range(n):
        c = word[i]
        prev_v = i > 0 and word[i - 1] in _FV
        next_v = i + 1 < n and word[i + 1] in _FV
        if c in "ui" and prev_v and next_v:
            chars[i] = c.upper()
        elif c == "y" and (prev_v or next_v):
            chars[i] = "Y"
        elif c == "u" and i > 0 and word[i - 1] == "q":
            chars[i] = "U"
    word = "".join(chars)
    if len(word) >= 3 and word[:3].lower() in ("par", "col", "tap"):
        rv = 3
    else:
        rv = len(word)
        if len(word) > 1 and word[0] in _FV and word[1] in _FV:
            rv = 3 if len(word) >= 3 else len(word)
        else:
            for i in range(1, len(word)):
                if word[i] in _FV:
                    rv = i + 1
                    break
    r1, r2 = r1r2(word, _FV)

    def ok(w, suf, r):
        return len(w) - len(suf) >= r

    state = {"w": word}

    def W():
        return state["w"]

    def setw(x):
        state["w"] = x

    s1 = ["ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes", "ables", "istes",
          "atrice", "ateur", "ation", "atrices", "ateurs", "ations", "logie", "logies", "usion", "ution",
          "usions", "utions", "ence", "ences", "ement", "ements", "ité", "ités", "if", "ive", "ifs", "ives",
          "eaux", "aux", "euse", "euses", "issement", "issements", "amment", "emment", "ment", "ments"]
    word0 = word
    s = longest(word, s1)
    altered = False
    step2a_needed = True
    if s:
        w = word
        if s in ("ance", "iqUe", "isme", "able", "iste", "eux", "ances", "iqUes", "ismes", "ables", "istes"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                altered = True
        elif s in ("atrice", "ateur", "ation", "atrices", "ateurs", "ations"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                altered = True
                if word.endswith("ic"):
                    if ok(word, "ic", r2):
                        word = word[:-2]
                    else:
                        word = word[:-2] + "iqU"
        elif s in ("logie", "logies"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "log"
                altered = True
        elif s in ("usion", "ution", "usions", "utions"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "u"
                altered = True
        elif s in ("ence", "ences"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "ent"
                altered = True
        elif s in ("ement", "ements"):
            if ok(w, s, rv):
                word = w[:-len(s)]
                altered = True
                if word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and ok(word, "at", r2):
                        word = word[:-2]
                elif word.endswith("eus"):
                    if ok(word, "eus", r2):
                        word = word[:-3]
                    elif ok(word, "eus", r1):
                        word = word[:-3] + "eux"
                elif word.endswith(("abl", "iqU")) and ok(word, "abl", r2):
                    word = word[:-3]
                elif word.endswith(("ièr", "Ièr")) and ok(word, "ièr", rv):
                    word = word[:-3] + "i"
        elif s in ("ité", "ités"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                altered = True
                if word.endswith("abil"):
                    word = word[:-4] if ok(word, "abil", r2) else word[:-4] + "abl"
                elif word.endswith("ic"):
                    word = word[:-2] if ok(word, "ic", r2) else word[:-2] + "iqU"
                elif word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
        elif s in ("if", "ive", "ifs", "ives"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                altered = True
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
                    if word.endswith("ic"):
                        word = word[:-2] if ok(word, "ic", r2) else word[:-2] + "iqU"
        elif s == "eaux":
            word = w[:-1]
            altered = True
        elif s == "aux":
            if ok(w, s, r1):
                word = w[:-3] + "al"
                altered = True
        elif s in ("euse", "euses"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                altered = True
            elif ok(w, s, r1):
                word = w[:-len(s)] + "eux"
                altered = True
        elif s in ("issement", "issements"):
            pre = w[:-len(s)]
            if ok(w, s, r1) and pre and pre[-1] not in _FV:
                word = pre
                altered = True
        elif s == "amment":
            if ok(w, s, rv):
                word = w[:-6] + "ant"
                altered = True
                step2a_needed = True
        elif s == "emment":
            if ok(w, s, rv):
                word = w[:-6] + "ent"
                altered = True
        elif s in ("ment", "ments"):
            pre = w[:-len(s)]
            if pre and pre[-1] in _FV and ok(pre, pre[-1], rv):
                word = pre
                altered = True
        if altered and s not in ("amment", "emment", "ment", "ments"):
            step2a_needed = False
        elif altered:
            step2a_needed = True
        else:
            step2a_needed = True
    # Step 2a
    changed2 = False
    if step2a_needed:
        sufs = ["îmes", "ît", "îtes", "i", "ie", "ies", "ir", "ira", "irai", "iraIent", "irais", "irait", "iras",
                "irent", "irez", "iriez", "irions", "irons", "iront", "is", "issaIent", "issais", "issait",
                "issant", "issante", "issantes", "issants", "isse", "issent", "isses", "issez", "issiez",
                "issions", "issons", "it"]
        s = longest(word, sufs)
        if s and ok(word, s, rv):
            pre = word[:-len(s)]
            if pre and pre[-1] not in _FV and pre[-1] != "H":
                word = pre
                changed2 = True
        if not changed2:
            s2b = ["ions", "é", "ée", "ées", "és", "èrent", "er", "era", "erai", "eraIent", "erais", "erait",
                   "eras", "erez", "eriez", "erions", "erons", "eront", "ez", "iez",
                   "âmes", "ât", "âtes", "a", "ai", "aIent", "ais", "ait", "ant", "ante", "antes", "ants", "as",
                   "asse", "assent", "asses", "assiez", "assions"]
            s = longest(word, s2b)
            if s and ok(word, s, rv):
                if s == "ions":
                    if ok(word, s, r2):
                        word = word[:-4]
                        changed2 = True
                elif s in ("âmes", "ât", "âtes", "a", "ai", "aIent", "ais", "ait", "ant", "ante", "antes",
                           "ants", "as", "asse", "assent", "asses", "assiez", "assions"):
                    word = word[:-len(s)]
                    if word.endswith("e") and ok(word, "e", rv):
                        word = word[:-1]
                    changed2 = True
                else:
                    word = word[:-len(s)]
                    changed2 = True
    if altered or changed2:
        # Step 3
        if word.endswith("Y"):
            word = word[:-1] + "i"
        elif word.endswith("ç"):
            word = word[:-1] + "c"
    else:
        # Step 4: residual suffix
        if word.endswith("s") and len(word) > 1 and word[-2] not in "aiouès":
            word = word[:-1]
        s = longest(word, ("ier", "ière", "Ier", "Ière", "ion", "e", "ë"))
        if s and ok(word, s, rv):
            if s in ("ier", "ière", "Ier", "Ière"):
                word = word[:-len(s)] + "i"
            elif s == "e":
                word = word[:-1]
            elif s == "ion":
                if ok(word, s, r2) and word[:-3].endswith(("s", "t")):
                    word = word[:-3]
            elif s == "ë":
                if word.endswith("guë"):
                    word = word[:-1]
    # Step 5
    for t in ("enn", "onn", "ett", "ell", "eill"):
        if word.endswith(t):
            word = word[:-1]
            break
    # Step 6
    for i in range(len(word) - 1, -1, -1):
        if word[i] in "éè":
            if all(c not in _FV for c in word[i + 1:]) and i < len(word) - 1:
                word = word[:i] + "e" + word[i + 1:]
            break
    return word.replace("I", "i").replace("U", "u").replace("Y", "y").replace("H", "")


# ---------------------------------------------------------------- italian
_IV = "aeiouàèìòù"


def stem_italian(word):
    word = word.lower()
    word = _strip_acute(word, (("á", "à"), ("é", "è"), ("í", "ì"), ("ó", "ò"), ("ú", "ù")))
    chars = list(word)
    n = len(word)
    for i in range(n):
        if word[i] == "u" and i > 0 and word[i - 1] == "q":
            chars[i] = "U"
        elif word[i] in "ui" and 0 < i < n - 1 and word[i - 1] in _IV and word[i + 1] in _IV:
            chars[i] = word[i].upper()
    word = "".join(chars)
    r1, r2 = r1r2(word, _IV)
    rv = _rv_romance(word, _IV)

    def ok(w, suf, r):
        return len(w) - len(suf) >= r

    pron = ["ci", "gli", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi", "sene", "gliela", "gliele", "glieli",
            "glielo", "gliene", "mela", "mele", "meli", "melo", "mene", "tela", "tele", "teli", "telo", "tene",
            "cela", "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo", "vene"]
    s = longest(word, pron)
    if s and ok(word, s, rv):
        pre = word[:-len(s)]
        t = longest(pre, ("ando", "endo", "ar", "er", "ir"))
        if t and ok(pre, t, rv):
            word = pre if t in ("ando", "endo") else pre[:-2] + "e"
    s1 = ["anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi", "abile", "abili", "ibile",
          "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso", "osi", "osa", "ose", "mente",
          "atrice", "atrici", "ante", "anti", "azione", "azioni", "atore", "atori", "logia", "logie", "uzione",
          "uzioni", "usione", "usioni", "enza", "enze", "amente", "ità", "ivo", "ivi", "iva", "ive"]
    s = longest(word, s1)
    done = False
    if s:
        w = word
        if s in ("anza", "anze", "ico", "ici", "ica", "ice", "iche", "ichi", "ismo", "ismi", "abile", "abili",
                 "ibile", "ibili", "ista", "iste", "isti", "istà", "istè", "istì", "oso", "osi", "osa", "ose",
                 "mente", "ante", "anti"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
        elif s in ("atrice", "atrici", "azione", "azioni", "atore", "atori"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
                if word.endswith("ic") and ok(word, "ic", r2):
                    word = word[:-2]
        elif s in ("logia", "logie"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "log"
                done = True
        elif s in ("uzione", "uzioni", "usione", "usioni"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "u"
                done = True
        elif s in ("enza", "enze"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "ente"
                done = True
        elif s == "amente":
            if ok(w, s, r1):
                word = w[:-6]
                done = True
                if word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and ok(word, "at", r2):
                        word = word[:-2]
                else:
                    t = longest(word, ("os", "ic", "abil"))
                    if t and ok(word, t, r2):
                        word = word[:-len(t)]
        elif s == "ità":
            if ok(w, s, r2):
                word = w[:-3]
                done = True
                t = longest(word, ("abil", "ic", "iv"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("ivo", "ivi", "iva", "ive"):
            if ok(w, s, r2):
                word = w[:-3]
                done = True
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
                    if word.endswith("ic") and ok(word, "ic", r2):
                        word = word[:-2]
    if not done:
        verbs = """ammo ando ano are arono asse assero assi assimo ata ate ati ato ava avamo avano avate avi avo
emmo enda ende endi endo erà erai eranno ere erebbe erebbero erei eremmo eremo ereste eresti erete erò erono essero
ete eva evamo evano evate evi evo Yamo iamo immo irà irai iranno ire irebbe irebbero irei iremmo iremo ireste iresti
irete irò irono isca iscano isce isci isco iscono issero ita ite iti ito iva ivamo ivano ivate ivi ivo ono uta ute
uti uto ar ir""".split()
        s = longest(word, verbs)
        if s and ok(word, s, rv):
            word = word[:-len(s)]
    s = longest(word, ("a", "e", "i", "o", "à", "è", "ì", "ò"))
    if s and ok(word, s, rv):
        word = word[:-1]
        if word.endswith("i") and ok(word, "i", rv):
            word = word[:-1]
    for t, r in (("ch", "c"), ("gh", "g")):
        if word.endswith(t) and ok(word, t, rv):
            word = word[:-2] + r
            break
    return word.replace("I", "i").replace("U", "u")


# ---------------------------------------------------------------- portuguese
_PV = "aeiouáéíóúâêô"


def stem_portuguese(word):
    word = word.lower().replace("ã", "a~").replace("õ", "o~")
    r1, r2 = r1r2(word, _PV)
    rv = _rv_romance(word, _PV)

    def ok(w, suf, r):
        return len(w) - len(suf) >= r

    s1 = ["eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista", "istas", "oso",
          "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "adora", "ador", "aça", "aço",
          "adoras", "adores", "aças", "aços", "ante", "antes", "ância", "logia", "logias", "ução", "uções",
          "ência", "ências", "amente", "mente", "idade", "idades", "iva", "ivo", "ivas", "ivos", "ira", "iras"]
    s = longest(word, s1)
    done = False
    if s:
        w = word
        if s in ("eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista", "istas",
                 "oso", "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "ante", "antes", "ância"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
        elif s in ("adora", "ador", "aça", "aço", "adoras", "adores", "aças", "aços"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
                if word.endswith("ic") and ok(word, "ic", r2):
                    word = word[:-2]
        elif s in ("logia", "logias"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "log"
                done = True
        elif s in ("ução", "uções"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "u"
                done = True
        elif s in ("ência", "ências"):
            if ok(w, s, r2):
                word = w[:-len(s)] + "ente"
                done = True
        elif s == "amente":
            if ok(w, s, r1):
                word = w[:-6]
                done = True
                if word.endswith("iv") and ok(word, "iv", r2):
                    word = word[:-2]
                    if word.endswith("at") and ok(word, "at", r2):
                        word = word[:-2]
                else:
                    t = longest(word, ("os", "ic", "ad"))
                    if t and ok(word, t, r2):
                        word = word[:-len(t)]
        elif s == "mente":
            if ok(w, s, r2):
                word = w[:-5]
                done = True
                t = longest(word, ("ante", "avel", "ível"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("idade", "idades"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
                t = longest(word, ("abil", "ic", "iv"))
                if t and ok(word, t, r2):
                    word = word[:-len(t)]
        elif s in ("iva", "ivo", "ivas", "ivos"):
            if ok(w, s, r2):
                word = w[:-len(s)]
                done = True
                if word.endswith("at") and ok(word, "at", r2):
                    word = word[:-2]
        elif s in ("ira", "iras"):
            pre = w[:-len(s)]
            if ok(w, s, rv) and pre.endswith("e"):
                word = pre + "ir"
                done = True
    if not done:
        verbs = """ada ida ia aria eria iria ará ara erá era irá ava asse esse isse aste este iste ei arei erei irei
am iam ariam eriam iriam aram eram iram avam em arem erem irem assem essem issem ado ido ando endo indo ara~o
era~o ira~o ar er ir as adas idas ias arias erias irias arás aras erás eras irás avas es ardes erdes irdes ares
eres ires asses esses isses astes estes istes is ais eis íeis aríeis eríeis iríeis áreis areis éreis ereis íreis
ireis ásseis ésseis ísseis áveis ados idos ámos amos íamos aríamos eríamos iríamos áramos éramos íramos ávamos
emos aremos eremos iremos ássemos êssemos íssemos imos armos ermos irmos eu iu ou ira iras""".split()
        s = longest(word, verbs)
        if s and ok(word, s, rv):
            word = word[:-len(s)]
            done = True
    if done:
        if word.endswith("i") and ok(word, "i", rv) and word[-2:-1] == "c":
            word = word[:-1]
    else:
        s = longest(word, ("os", "a", "i", "o", "á", "í", "ó"))
        if s and ok(word, s, rv):
            word = word[:-len(s)]
    s = longest(word, ("e", "é", "ê"))
    if s and ok(word, s, rv):
        word = word[:-1]
        if word.endswith(("gu", "ci")) and ok(word, "u", rv):
            word = word[:-1]
    elif word.endswith("ç"):
        pass
    word = word.replace("ç", "c")
    return word.replace("a~", "ã").replace("o~", "õ")


# ---------------------------------------------------------------- russian
_RV = "аеиоуыэюя"
_RU_PERF1 = ["вшись", "вши", "в"]
_RU_PERF2 = ["ившись", "ывшись", "ивши", "ывши", "ив", "ыв"]
_RU_ADJ = ["ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий", "ый", "ой", "ем", "им",
           "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею"]
_RU_PART1 = ["ем", "нн", "вш", "ющ", "щ"]
_RU_PART2 = ["ивш", "ывш", "ующ"]
_RU_VERB1 = ["нно", "ете", "йте", "ешь", "ла", "на", "ли", "ло", "но", "ет", "ют", "ны", "ть", "ем", "й", "л", "н"]
_RU_VERB2 = ["ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено", "ует", "уют", "ены",
             "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым", "ен", "ят", "ит", "ыт", "ую", "ю"]
_RU_NOUN = ["иями", "иях", "ями", "ами", "ией", "иям", "ием", "ией", "ие", "ье", "еи", "ии", "ей", "ой", "ий",
            "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия", "ев", "ов", "а", "е", "и", "й", "о", "у", "ы",
            "ь", "ю", "я"]


def stem_russian(word):
    word = word.lower().replace("ё", "е")
    rv = len(word)
    for i, c in enumerate(word):
        if c in _RV:
            rv = i + 1
            break
    # R2
    r1 = len(word)
    for i in range(1, len(word)):
        if word[i] not in _RV and word[i - 1] in _RV:
            r1 = i + 1
            break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _RV and word[i - 1] in _RV:
            r2 = i + 1
            break

    def ok(w, suf, r):
        return len(w) - len(suf) >= r

    def strip_group(w, g1, g2):
        s = longest(w, g1 + g2)
        if s and ok(w, s, rv):
            if s in g1:
                pre = w[:-len(s)]
                if pre.endswith(("а", "я")):
                    return pre
                # try shorter group-1 candidates? (none apply)
                return None
            return w[:-len(s)]
        return None

    prefix = word[:rv]
    tail = word[rv:]
    w = word
    res = strip_group(w, _RU_PERF1, _RU_PERF2)
    if res is None:
        # remove reflexive
        for s in ("ся", "сь"):
            if w.endswith(s) and ok(w, s, rv):
                w = w[:-2]
                break
        # adjectival
        a = longest(w, _RU_ADJ)
        done = False
        if a and ok(w, a, rv):
            w2 = w[:-len(a)]
            pr = strip_group(w2, _RU_PART1, _RU_PART2)
            w = pr if pr is not None else w2
            done = True
        if not done:
            r = strip_group(w, _RU_VERB1, _RU_VERB2)
            if r is not None:
                w = r
                done = True
        if not done:
            n = longest(w, _RU_NOUN)
            if n and ok(w, n, rv):
                w = w[:-len(n)]
    else:
        w = res
    # step 2
    if w.endswith("и") and ok(w, "и", rv):
        w = w[:-1]
    # step 3
    if w.endswith("ость") and ok(w, "ость", r2):
        w = w[:-4]
    elif w.endswith("ост") and ok(w, "ост", r2):
        w = w[:-3]
    # step 4
    if w.endswith("ейше") and ok(w, "ейше", rv):
        w = w[:-4]
    elif w.endswith("ейш") and ok(w, "ейш", rv):
        w = w[:-3]
    if w.endswith("нн"):
        w = w[:-1]
    elif w.endswith("ь") and ok(w, "ь", rv):
        w = w[:-1]
    return w
