"""Stemmers.  # spec: N-000421"""
import os
import re

from .. import data
from .porter import PorterStemmer  # noqa: F401
from .lancaster import LancasterStemmer  # noqa: F401
from . import snowball_a as _a, snowball_b as _b, snowball_c as _c

_LANGS = {
    "arabic": _c.stem_arabic, "danish": _a.stem_danish, "dutch": _a.stem_dutch, "english": _a.stem_english,
    "finnish": _c.stem_finnish, "french": _b.stem_french, "german": _a.stem_german,
    "hungarian": _c.stem_hungarian, "italian": _b.stem_italian, "norwegian": _a.stem_norwegian,
    "porter": _a.stem_porter, "portuguese": _b.stem_portuguese, "romanian": _c.stem_romanian,
    "russian": _b.stem_russian, "spanish": _b.stem_spanish, "swedish": _a.stem_swedish,
}


class SnowballStemmer:
    languages = tuple(sorted(_LANGS))  # spec: N-000428

    def __init__(self, language, ignore_stopwords=False):
        # spec: N-000429 N-000430 N-000431 N-000181 N-000182 N-000183 N-000184 N-000147 N-000148
        if language not in _LANGS:
            raise ValueError("The language %r is not supported. Supported languages: %s"
                             % (language, ", ".join(sorted(_LANGS))))
        self.language = language
        self._fn = _LANGS[language]
        self.stopwords = set()
        if ignore_stopwords:
            self.stopwords = self._load_stopwords(language)

    @staticmethod
    def _load_stopwords(language):
        path = data.find("corpora/stopwords/%s" % language)
        if not os.path.isfile(path):
            raise data.ResourceNotFound("stopwords list for %r not found" % language)
        return {w.strip() for w in data.read_lines(path) if w.strip()}

    def stem(self, word):
        # spec: N-000176 N-000177
        w = word.lower()
        if w in self.stopwords:
            return w
        return self._fn(word)


class RegexpStemmer:
    # spec: N-000178 N-000179 N-000180 N-000427
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


_AR_STOP_PREFIX = ("وال", "بال", "كال", "فال", "ال", "لل")


class ARLSTem:
    """Arabic light stemmer (simplified).  Results are outside the specification."""

    def stem(self, word):
        return _c.stem_arabic(word)


class ARLSTem2(ARLSTem):
    pass


class WordNetLemmatizer:
    """WordNet lemmatizer reading `corpora/wordnet`.  # spec: N-000432 N-000185"""

    _SUFFIXES = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
              ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }
    _FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv", "s": "adj"}

    def __init__(self):
        self._dir = data.find("corpora/wordnet")

    def _lemmas(self, pos):
        d = data.find("corpora/wordnet")
        names = set()
        exc = {}
        idx = os.path.join(d, "index." + self._FILES[pos])
        if os.path.isfile(idx):
            for line in data.read_lines(idx):
                if line and not line.startswith(" "):
                    names.add(line.split(" ")[0])
        ex = os.path.join(d, self._FILES[pos] + ".exc")
        if os.path.isfile(ex):
            for line in data.read_lines(ex):
                parts = line.split()
                if len(parts) >= 2:
                    exc.setdefault(parts[0], []).append(parts[1])
        return names, exc

    def lemmatize(self, word, pos="n"):
        data.find("corpora/wordnet")
        if pos not in self._FILES:
            pos = "n"
        names, exc = self._lemmas(pos)
        cands = [word]
        if word in exc:
            cands = exc[word] + cands
        for suf, rep in self._SUFFIXES.get(pos, []):
            if word.endswith(suf):
                cands.append(word[:len(word) - len(suf)] + rep)
        found = [c for c in cands if c in names]
        if found:
            return min(found, key=len)
        return word


__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer", "SnowballStemmer",
           "WordNetLemmatizer"]
