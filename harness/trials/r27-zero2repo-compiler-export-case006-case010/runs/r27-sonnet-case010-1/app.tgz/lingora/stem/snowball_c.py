"""Snowball: Romanian, Hungarian, Finnish, Arabic.

These four are simplified renderings (the main suffix-removal steps of the
published algorithms, not every sub-rule); see NOTES.md.
"""
from ._util import r1r2, longest, entries_by_len

# ---------------------------------------------------------------- romanian
_ROV = "aeiouăâî"


def stem_romanian(word):
    word = word.lower()
    chars = list(word)
    for i in range(1, len(word) - 1):
        if word[i - 1] in _ROV and word[i + 1] in _ROV:
            if word[i] == "u":
                chars[i] = "U"
            elif word[i] == "i":
                chars[i] = "I"
    word = "".join(chars)
    r1, r2 = r1r2(word, _ROV)

    def ok(w, s, r):
        return len(w) - len(s) >= r
    # Step 0
    s = longest(word, ("ul", "ului"))
    if s and ok(word, s, r1):
        word = word[:-len(s)]
    elif word.endswith("aua"):
        word = word[:-1]
    elif word.endswith(("ele", "elor")) :
        word = word[:word.rfind("e")] + "ea" if word.endswith("ele") else word[:-4] + "ea"
    elif word.endswith(("iile", "iilor", "ilor", "iua", "iei", "ii")):
        for t in ("iilor", "iile", "ilor", "iua", "iei", "ii"):
            if word.endswith(t):
                word = word[:-len(t)] + "i"
                break
    elif word.endswith("ile") and not word.endswith("abile"):
        word = word[:-3] + "i"
    elif word.endswith("atei"):
        word = word[:-2]
    # Step 2 (standard suffix removal)
    sufs = entries_by_len(["ism", "isme", "ist", "ista", "iste", "isti", "istă", "iști", "ariu", "ării", "aria",
                           "ățiune", "ățiuni", "atoare", "ator", "atori", "itate", "itati", "ităţi", "ităţii",
                           "ivă", "iva", "ive", "ivi", "ibil", "abil", "abila", "abile", "abili", "os", "oasa",
                           "oasă", "oase", "oși", "ică", "ice", "ici", "ic", "ant", "ante", "anți", "ent",
                           "ente", "enți", "ar", "are", "ări", "ător", "ătoare", "ători"])
    s = longest(word, sufs)
    if s and ok(word, s, r2):
        word = word[:-len(s)]
    else:
        v = longest(word, entries_by_len(["are", "ere", "ire", "ând", "ind", "eau", "ea", "ai", "ați", "ați", "am",
                                          "ară", "ără", "ase", "asem", "ați", "ez", "ezi", "eze", "ează",
                                          "esc", "ești", "ește", "im", "it", "ite", "iți", "ată", "ate", "ați",
                                          "at", "ut", "uta", "ute", "uți", "ui", "ul", "i", "a", "e", "ă"]))
        rv = len(word)
        for i, c in enumerate(word):
            if i > 0 and c in _ROV:
                rv = i + 1
                break
        if v and ok(word, v, rv):
            word = word[:-len(v)]
    return word.replace("U", "u").replace("I", "i")


# ---------------------------------------------------------------- hungarian
_HV = "aáeéiíoóöőuúüű"


def stem_hungarian(word):
    word = word.lower()
    r1 = len(word)
    for i in range(1, len(word)):
        if word[i] not in _HV and word[i - 1] in _HV:
            r1 = i + 1
            break
    if r1 < len(word) and False:
        pass

    def ok(w, s):
        return len(w) - len(s) >= r1
    # case endings
    cases = entries_by_len(["ban", "ben", "ba", "be", "ra", "re", "nak", "nek", "val", "vel", "tól", "től", "ról",
                            "ről", "ból", "ből", "hoz", "hez", "höz", "nál", "nél", "ig", "at", "et", "ot", "öt",
                            "ért", "kor", "ul", "ül", "ként", "án", "én", "ban", "ben", "on", "en", "ön", "n", "t"])
    s = longest(word, cases)
    if s and ok(word, s):
        word = word[:-len(s)]
        if word.endswith("á"):
            word = word[:-1] + "a"
        elif word.endswith("é"):
            word = word[:-1] + "e"
    # plural
    if word.endswith("k") and ok(word, "k"):
        word = word[:-1]
        if word.endswith("á"):
            word = word[:-1] + "a"
        elif word.endswith("é"):
            word = word[:-1] + "e"
    # owner/possessive
    s = longest(word, entries_by_len(["unk", "ünk", "nk", "juk", "jük", "uk", "ük", "m", "d", "ja", "je", "a", "e"]))
    if s and ok(word, s):
        word = word[:-len(s)]
        if word.endswith("á"):
            word = word[:-1] + "a"
        elif word.endswith("é"):
            word = word[:-1] + "e"
    return word


# ---------------------------------------------------------------- finnish
_FIV = "aeiouyäö"


def stem_finnish(word):
    word = word.lower()
    r1, r2 = r1r2(word, _FIV)

    def ok(w, s, r):
        return len(w) - len(s) >= r
    # Step 1: particles
    s = longest(word, ["kin", "kaan", "kään", "ko", "kö", "han", "hän", "pa", "pä", "ka", "kä"])
    if s and ok(word, s, r1) and word[:-len(s)][-1:] in "nts" and s in ("han", "hän", "pa", "pä", "ka", "kä") \
            or (s in ("kin", "kaan", "kään", "ko", "kö") and s and ok(word, s, r1)):
        word = word[:-len(s)]
    # Step 2: possessives
    s = longest(word, ["si", "ni", "nsa", "nsä", "mme", "nne", "an", "än"])
    if s and ok(word, s, r1):
        word = word[:-len(s)]
    # Step 3: cases
    cases = entries_by_len(["hXn", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi", "ine",
                            "ta", "tä", "na", "nä", "a", "ä", "n"])
    s = longest(word, cases)
    if s and ok(word, s, r1):
        word = word[:-len(s)]
    # Step 5: plural / vowels
    if word.endswith("t") and ok(word, "t", r1):
        word = word[:-1]
    if len(word) - 1 >= r1 and word[-1] in _FIV:
        word = word[:-1]
    # tidy: doubled consonant
    if len(word) - 1 >= r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in _FIV:
        word = word[:-1]
    return word


# ---------------------------------------------------------------- arabic
_AR_DIAC = "ًٌٍَُِّْـ"
_AR_PREFIXES = entries_by_len(["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل", "س"])
_AR_SUFFIXES = entries_by_len(["ات", "ان", "ين", "ون", "ها", "هم", "هن", "كم", "نا", "تم", "ية", "ة", "ه", "ي", "ك", "ا"])


def stem_arabic(word):
    for c in _AR_DIAC:
        word = word.replace(c, "")
    for a in "أإآ":
        word = word.replace(a, "ا")
    word = word.replace("ى", "ي")
    for p in _AR_PREFIXES:
        if word.startswith(p) and len(word) - len(p) >= 3:
            word = word[len(p):]
            break
    for s in _AR_SUFFIXES:
        if word.endswith(s) and len(word) - len(s) >= 3:
            word = word[:-len(s)]
            break
    return word
