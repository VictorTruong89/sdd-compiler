def r1r2(word, vowels, start1=0):
    """Return (r1_start, r2_start) indices (standard definitions)."""
    r1 = len(word)
    for i in range(max(1, 1), len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r1 = i + 1
            break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def longest(word, sufs):
    best = None
    for s in sufs:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def entries_by_len(sufs):
    return sorted(sufs, key=len, reverse=True)
