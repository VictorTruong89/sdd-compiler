"""Packaged-resource lookup.  # spec: N-000385 N-000386 N-000387 N-000388"""
import os

# Mutable list of directories searched for resources; callers may replace the
# contents in place.  Initial contents are the implementer's choice.
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "lingora_data"))


class ResourceNotFound(LookupError):
    pass


def find(name):
    """Return the filesystem path of resource `name` or raise ResourceNotFound.

    Only the directories currently listed in `path` are consulted.
    """
    # spec: N-000386
    for d in list(path):
        p = os.path.join(str(d), *name.strip("/").split("/"))
        if os.path.exists(p):
            return p
    raise ResourceNotFound("resource %r not found in data.path" % (name,))


def read_lines(filepath):
    """Entries of a UTF-8 text file: each line without its terminator."""
    # spec: N-000398
    with open(filepath, encoding="utf-8", newline="") as f:
        text = f.read()
    return text.splitlines() if text else []
