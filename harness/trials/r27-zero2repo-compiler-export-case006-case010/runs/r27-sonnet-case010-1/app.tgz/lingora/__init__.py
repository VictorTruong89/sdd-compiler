"""Lingora Language Toolkit: a pure-Python NLP library."""
# spec: N-000372
__version__ = "0.1.0"

from . import data  # noqa: F401  (cheap; downloads nothing)  # spec: N-000374

__all__ = ["data", "tokenize", "stem", "tag", "chunk", "grammar", "parse",
           "tree", "classify", "metrics", "translate", "cli"]
