"""Tokenizers.  # spec: N-000403 N-000404"""
from .regexp import (RegexpTokenizer, WhitespaceTokenizer, WordPunctTokenizer, BlanklineTokenizer,  # noqa: F401
                     blankline_tokenize, wordpunct_tokenize, regexp_span_tokenize)
from .treebank import TreebankWordTokenizer, NLTKWordTokenizer
from .tweet import TweetTokenizer  # noqa: F401
from . import punkt

_improved = NLTKWordTokenizer()


def sent_tokenize(text, language="english"):
    # spec: N-000137 N-000138 N-000413
    return get_sent_tokenizer(language).tokenize(text)


def get_sent_tokenizer(language="english"):
    return punkt.get_tokenizer(language)


def word_tokenize(text, language="english", preserve_line=False):
    # spec: N-000086 N-000087 N-000088 N-000111 N-000112 N-000409 N-000410
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    return [tok for s in sentences for tok in _improved.tokenize(s)]


__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "blankline_tokenize", "sent_tokenize", "word_tokenize",
           "wordpunct_tokenize"]
