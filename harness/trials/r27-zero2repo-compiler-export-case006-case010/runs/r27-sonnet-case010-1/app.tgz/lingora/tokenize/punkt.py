"""Punkt sentence-boundary detection with packaged parameters.  # spec: N-000129 N-000130 N-000131 N-000132 N-000133"""
import os
import re
import string
from collections import defaultdict

from .. import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

SENT_END_CHARS = (".", "?", "!")
_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_RE = re.compile(r"""(
    %(MultiChar)s
    |
    (?=%(WordStart)s)\S+?
    (?=
        \s|
        $|
        %(NonWord)s|%(MultiChar)s|
        ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
    )
    |
    \S
)""" % {"MultiChar": _MULTI, "WordStart": _WORD_START, "NonWord": _NON_WORD}, re.UNICODE | re.VERBOSE)
_PERIOD_RE = re.compile(r"""
    [%s]
    (?=(?P<after_tok>
        %s
        |
        \s+(?P<next_tok>\S+)
    ))""" % (re.escape("".join(SENT_END_CHARS)), _NON_WORD), re.UNICODE | re.VERBOSE)
_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"^\.\.+$")
_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)
_ALPHA = re.compile(r"^[^\W\d]+$", re.UNICODE)


class _Tok:
    __slots__ = ("tok", "type", "period_final", "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok):
        self.tok = tok
        self.type = _NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type if self.sentbreak else self.type_no_period

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = defaultdict(int)


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._params = params

    # --- word tokenisation -------------------------------------------------
    def _tokenize_words(self, text):
        for line in text.split("\n"):
            if line.strip():
                for tok in _WORD_RE.findall(line):
                    yield _Tok(tok)

    def _first_pass(self, tok):
        t = tok.tok
        if t in SENT_END_CHARS:
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            base = t[:-1].lower()
            if base in self._params.abbrev_types or base.split("-")[-1] in self._params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context[tok.type_no_sentperiod]
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            o = self._ortho(t2)
            if o is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (o == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context[next_typ] & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, text):
        toks = list(self._tokenize_words(text))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for t in self._annotate(text):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # --- slicing -----------------------------------------------------------
    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return 0

    def _contexts(self, text):
        prev_slice = slice(0, 0)
        prev_match = None
        for match in _PERIOD_RE.finditer(text):
            before = text[prev_slice.stop:match.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice.stop + 1
            else:
                idx = prev_slice.start
            pw = slice(idx, match.start())
            if prev_match and prev_slice.stop <= pw.start:
                yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = pw
        if prev_match:
            yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, context in self._contexts(text):
            if self._contains_sentbreak(context):
                yield slice(last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield slice(last, len(text.rstrip()))

    @staticmethod
    def _pairs(it):
        it = iter(it)
        try:
            prev = next(it)
        except StopIteration:
            return
        for el in it:
            yield prev, el
            prev = el
        yield prev, None

    def _realign(self, text, slices):
        realign = 0
        for s1, s2 in self._pairs(slices):
            s1 = slice(s1.start + realign, s1.stop)
            if not s2:
                if text[s1]:
                    yield s1
                continue
            m = _REALIGN.match(text[s2])
            if m:
                yield slice(s1.start, s2.start + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1]:
                    yield s1

    def span_tokenize(self, text, realign_boundaries=True):
        slices = self._slices(text)
        if realign_boundaries:
            slices = self._realign(text, slices)
        for s in slices:
            yield s.start, s.stop

    def tokenize(self, text, realign_boundaries=True):
        return [text[a:b] for a, b in self.span_tokenize(text, realign_boundaries)]


def _entries(path):
    return [l for l in data.read_lines(path) if l != ""]


def load_params(language):
    # spec: N-000389 N-000399 N-000402 N-000413 N-000408
    if (not isinstance(language, str) or not language or "/" in language or "\\" in language
            or language in (".", "..") or os.sep in language):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    d = data.find("tokenizers/punkt_tab/%s" % language)
    p = PunktParameters()
    for fn in ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"):
        if not os.path.isfile(os.path.join(d, fn)):
            raise data.ResourceNotFound("Punkt model file %s missing for %r" % (fn, language))
    p.abbrev_types = set(_entries(os.path.join(d, "abbrev_types.txt")))
    p.sent_starters = set(_entries(os.path.join(d, "sent_starters.txt")))
    for l in _entries(os.path.join(d, "collocations.tab")):
        parts = l.split("\t")
        if len(parts) >= 2:
            p.collocations.add((parts[0], parts[1]))
    for l in _entries(os.path.join(d, "ortho_context.tab")):
        parts = l.split("\t")
        if len(parts) >= 2:
            p.ortho_context[parts[0]] = int(parts[1])
    return p


def get_tokenizer(language="english"):
    # Loaded on each call so changes of data.path take effect.
    return PunktSentenceTokenizer(load_params(language))
