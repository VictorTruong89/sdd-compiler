import re

EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""

URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""

PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""

REGEXPS = (
    URLS,
    PHONE,
    EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}""",
    r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
    """,
)

WORD_RE = re.compile(r"(%s)" % "|".join(REGEXPS), re.VERBOSE | re.I | re.UNICODE)
EMOTICON_RE = re.compile(EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
LENGTHENING_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tweet-aware tokenizer.  # spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125 N-000065 N-000066 N-000067"""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if self.strip_handles:
            text = HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = LENGTHENING_RE.sub(r"\1\1\1", text)
        safe = HANG_RE.sub(r"\1\1\1", text)
        words = WORD_RE.findall(safe)
        if not self.preserve_case:
            words = [w if EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
