import re


def regexp_span_tokenize(s, regexp):
    left = 0
    for m in re.finditer(regexp, s):
        right, nxt = m.span()
        if right != 0:
            yield left, right
        left = nxt
    yield left, len(s)


class RegexpTokenizer:
    """Regular-expression tokenizer.  # spec: N-000116 N-000117 N-000118 N-000405 N-000406 N-000407"""

    def __init__(self, pattern, gaps=False, discard_empty=False, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            pieces = self._regexp.split(text)
            if self._discard_empty:
                pieces = [t for t in pieces if t]
            return pieces
        return self._regexp.findall(text)

    def span_tokenize(self, text):
        # spec: N-000412 N-000126 N-000127 N-000128
        if self._gaps:
            for left, right in regexp_span_tokenize(text, self._regexp):
                if not (self._discard_empty and left == right):
                    yield left, right
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    # spec: N-000113
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True, discard_empty=True)


class WordPunctTokenizer(RegexpTokenizer):
    # spec: N-000089 N-000090 N-000091
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    # spec: N-000114 N-000115
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True, discard_empty=True)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)
