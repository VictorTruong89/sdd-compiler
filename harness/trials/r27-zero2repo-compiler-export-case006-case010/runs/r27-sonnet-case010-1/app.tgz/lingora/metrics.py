"""Evaluation metrics.  # spec: N-000498 N-000499"""


def accuracy(reference, test):
    # spec: N-000330 N-000501 N-000502 N-000343 N-000318
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if len(reference) == 0:
        return 0.0
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    # spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329 N-000348 N-000503 N-000504 N-000505 N-000506
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + sub)
            if (transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2]
                    and s1[i - 2] == s2[j - 1]):
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def jaccard_distance(label1, label2):
    # spec: N-000507
    return (len(label1.union(label2)) - len(label1.intersection(label2))) / len(label1.union(label2))


def _need_sets(reference, test):
    # spec: N-000508 N-000509
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")


def precision(reference, test):
    _need_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _need_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    # spec: N-000333 N-000334 N-000510
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0
    return 1.0 / (alpha / p + (1 - alpha) / r)
