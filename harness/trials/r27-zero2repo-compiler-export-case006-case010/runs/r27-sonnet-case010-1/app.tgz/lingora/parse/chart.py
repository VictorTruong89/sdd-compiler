import sys
from ..grammar import Nonterminal, CFG
from ..tree import Tree


def _check_tokens(tokens):
    # spec: N-000472
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    return list(tokens)


class ChartParser:
    """Exhaustive parser.  # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000473"""

    def __init__(self, grammar):
        self._grammar = grammar
        self._by_lhs = {}
        for p in grammar.productions():
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = _check_tokens(tokens)
        self._grammar.check_coverage(tokens)  # spec: N-000475 N-000476 N-000292 N-000293 N-000294
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        n = len(tokens)
        by_lhs = self._by_lhs
        visiting = set()

        def seq(rhs, k, i, j):
            # yield lists of children deriving tokens[i:j] from rhs[k:]
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, Nonterminal):
                for e in range(i, j + 1):
                    for t in nt(sym, i, e):
                        for rest in seq(rhs, k + 1, e, j):
                            yield [t] + rest
            else:
                if sym == "":
                    return
                if i < j and tokens[i] == sym:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [sym] + rest

        def nt(sym, i, j):
            key = (sym, i, j)
            if key in visiting:
                return
            visiting.add(key)
            try:
                for p in by_lhs.get(sym, ()):
                    for ch in seq(p.rhs(), 0, i, j):
                        yield Tree(str(sym), ch)
            finally:
                visiting.discard(key)

        start = self._grammar.start()
        yield from nt(start, 0, n)


class RecursiveDescentParser(ChartParser):
    pass


class ShiftReduceParser:
    """Single-pass shift-reduce parser.  # spec: N-000272 N-000273 N-000274 N-000275"""

    def __init__(self, grammar):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    @staticmethod
    def _match(item, sym):
        if isinstance(sym, Nonterminal):
            return isinstance(item, Tree) and item.label() == str(sym)
        return isinstance(item, str) and item == sym

    def parse(self, tokens):
        tokens = _check_tokens(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for p in self._prods:
            rhs = p.rhs()
            k = len(rhs)
            if len(stack) >= k and all(self._match(stack[len(stack) - k + i], rhs[i]) for i in range(k)):
                children = stack[len(stack) - k:]
                del stack[len(stack) - k:]
                stack.append(Tree(str(p.lhs()), children))
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while True:
            while self._reduce(stack):
                pass
            if remaining:
                stack.append(remaining.pop(0))
            else:
                break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            yield stack[0]
