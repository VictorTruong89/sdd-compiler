"""Sentence generation from a grammar.  # spec: N-000463"""
import itertools
import sys
from ..grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    # spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _all(grammar, [start], depth)
    if n is not None:
        it = itertools.islice(it, n)
    return it


def _all(grammar, items, depth):
    if items:
        try:
            for f1 in _one(grammar, items[0], depth):
                for f2 in _all(grammar, items[1:], depth):
                    yield f1 + f2
        except RecursionError as e:
            raise RuntimeError("The grammar has rule(s) that yield infinite recursion!") from e
    else:
        yield []


def _one(grammar, sym, depth):
    if depth > 0:
        if isinstance(sym, Nonterminal):
            for prod in grammar.productions(sym):
                yield from _all(grammar, prod.rhs(), depth - 1)
        else:
            yield [sym] if sym != "" else []
