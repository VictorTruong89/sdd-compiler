"""Context-free grammars.  # spec: N-000461"""
import re


class Nonterminal:
    """A grammar nonterminal symbol (deliberately not a str).  # spec: N-000466 N-000467 N-000468 N-000470"""

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        return False

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __lt__(self, other):
        return str(self) < str(other)

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return str(self._symbol)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        # spec: N-000469
        return self._rhs

    def is_lexical(self):
        return all(not isinstance(s, Nonterminal) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_RHS_TOKEN = re.compile(r"""\s*(?:('[^']*')|("[^"]*")|(\|)|([^\s|'"]+))""")


def _parse_rhs(text):
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _RHS_TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise ValueError("Unable to parse grammar right-hand side: %r" % text)
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1)[1:-1])
        elif m.group(2) is not None:
            alts[-1].append(m.group(2)[1:-1])
        elif m.group(3) is not None:
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lex = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._lex.add(s)

    @classmethod
    def fromstring(cls, input):
        # spec: N-000464 N-000465 N-000264 N-000265
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        prods = []
        start = None
        last_lhs = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|") and last_lhs is not None:
                lhs, rest = last_lhs, line
            else:
                m = re.match(r"^(\S+?)\s*(?:->|→)(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse grammar line: %r" % raw)
                lhs, rest = Nonterminal(m.group(1)), m.group(2)
            last_lhs = lhs
            if start is None:
                start = lhs
            if line.startswith("|") and rest is line:
                rest = line[1:]
                alts = _parse_rhs(rest)
            else:
                alts = _parse_rhs(rest)
            for alt in alts:
                prods.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, prods)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        # spec: N-000471
        ps = list(self._productions)
        if lhs is not None:
            if isinstance(lhs, str):
                lhs = Nonterminal(lhs)
            ps = [p for p in ps if p.lhs() == lhs]
        if rhs is not None:
            ps = [p for p in ps if rhs in p.rhs()]
        return ps

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._lex]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r."
                             % ", ".join(repr(t) for t in missing))

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__
