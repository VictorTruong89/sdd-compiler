import io
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from lingora import data, metrics
from lingora.chunk import RegexpParser
from lingora.classify import NaiveBayesClassifier, DecisionTreeClassifier, accuracy
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.stem import PorterStemmer, SnowballStemmer
from lingora.tokenize import wordpunct_tokenize, TweetTokenizer, word_tokenize, sent_tokenize
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def punkt(tmp_path):
    d = tmp_path / "tokenizers" / "punkt_tab" / "english"
    d.mkdir(parents=True)
    (d / "abbrev_types.txt").write_text("dr\nmr\n")
    (d / "sent_starters.txt").write_text("the\n")
    (d / "collocations.tab").write_text("")
    (d / "ortho_context.tab").write_text("smith\t2\n")
    old = list(data.path)
    data.path[:] = [str(tmp_path)]
    yield
    data.path[:] = old


def test_wordpunct():
    assert wordpunct_tokenize("Hi, you_1!") == ["Hi", ",", "you_1", "!"]
    assert wordpunct_tokenize("  ") == []


def test_tweet():
    assert TweetTokenizer(preserve_case=False, strip_handles=True).tokenize("@bob Hello :-)") == ["hello", ":-)"]


def test_sent_missing_model():
    old = list(data.path)
    data.path[:] = []
    try:
        with pytest.raises(Exception):
            sent_tokenize("Hi.")
    finally:
        data.path[:] = old


def test_sent(punkt):
    assert sent_tokenize("Hello there. Dr. Smith left.") == ["Hello there.", "Dr. Smith left."]
    assert word_tokenize("Hi there. Bye.") == ["Hi", "there", ".", "Bye", "."]


def test_stem():
    assert PorterStemmer().stem("running") == "run"
    assert SnowballStemmer("english").stem("generously") == "generous"
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_chunk_and_tree():
    t = RegexpParser("NP: {<DT>?<NN>}").parse([("the", "DT"), ("dog", "NN"), ("ran", "VB")])
    assert t[0].label() == "NP" and t[1] == ("ran", "VB")
    assert Tree.fromstring("(S (NP a) (VP b))") == Tree("S", [Tree("NP", ["a"]), Tree("VP", ["b"])])
    with pytest.raises(TypeError):
        Tree("S", "abc")


def test_parse():
    g = CFG.fromstring("S -> NP VP\nNP -> 'I'\nVP -> 'run'")
    assert len(list(ChartParser(g).parse(["I", "run"]))) == 1
    assert list(ShiftReduceParser(g).parse(["run", "I"])) == []
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zzz"])


def test_classify():
    train = [({"a": 1}, "x"), ({"a": 0}, "y")] * 3
    nb = NaiveBayesClassifier.train(train)
    assert nb.classify({"a": 1}) == "x"
    assert abs(sum(nb.prob_classify({"a": 1}).prob(l) for l in nb.labels()) - 1) < 1e-9
    assert accuracy(DecisionTreeClassifier.train(train), train) == 1.0


def test_metrics():
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("ab", "ba") == 2
    assert metrics.precision({1}, set()) is None
    with pytest.raises(TypeError):
        metrics.precision([1], {1})
    with pytest.raises(ValueError):
        metrics.accuracy([1], [1, 2])
    assert bleu([["a", "b", "c"]], ["a", "b", "c"]) == pytest.approx(1.0)


def test_cli(punkt, monkeypatch, capsys):
    from lingora.cli import cli
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n"))
    with pytest.raises(SystemExit) as e:
        cli.main(args=["tokenize"])
    assert e.value.code == 0
    assert capsys.readouterr().out == "Hi there .\n"
