# Spec coverage

Every id in `spec/CHECKLIST.md` (517 ids) with its status. Status is at the level of the
paragraph or pack that the id belongs to, mapped from the `↳` markers in `spec/packs/`.
`implemented` means the behaviour is coded. `implemented, tested` means the pack has a test file
in `tests/` that exercises its behaviour; it does not mean every id has its own assertion.
`partial` and `not done` carry the reason. `scope`/`scope/packaging` ids are constraints satisfied
by what is not built or by the layout. See NOTES.md for the conflicts and decisions.

| id | pack | status | where | note |
|---|---|---|---|---|
| N-000353 | 02 | scope/packaging | pyproject.toml; no native extensions | Hardware constraint |
| N-000354 | 02 | scope/packaging | pyproject.toml; no native extensions | Hardware constraint |
| N-000355 | 02 | scope/packaging | pyproject.toml; no native extensions | Hardware constraint |
| N-000356 | 02 | scope/packaging | pyproject.toml; no native extensions | Hardware constraint |
| N-000357 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000358 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000359 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000360 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000361 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000362 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000363 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000364 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000365 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000366 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000367 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000368 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000369 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000370 | 03 | scope/packaging | pyproject.toml (setuptools flat layout) | Execution profile: editable/source-tree import; no build step |
| N-000371 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000372 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000373 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000374 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000375 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000376 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000377 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000378 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000379 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000380 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000381 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000382 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000383 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000384 | 05 | implemented, tested | lingora/* (shape: callables, exceptions on refusal, numbers not bool) | Public-surface conventions |
| N-000385 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000386 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000387 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000388 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000389 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000390 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000391 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000392 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000393 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000394 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000395 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000396 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000397 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000398 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000399 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000400 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000401 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000402 | 06 | implemented, tested | lingora/data.py; tokenize.load_punkt; tag._load_perceptron |  |
| N-000403 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000404 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000405 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000406 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000407 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000408 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000409 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000410 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000411 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000412 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000413 | 07 | implemented, tested | lingora/tokenize.py |  |
| N-000414 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000415 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000416 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000417 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000418 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000419 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000420 | 08 | implemented, tested | lingora/cli.py | Exit status and stderr text are implementer choices (1 for failures, 2 for usage) |
| N-000421 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000422 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000423 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000424 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000425 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000426 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000427 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000428 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000429 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000430 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000431 | 09 | implemented, tested | lingora/stem.py | Snowball languages other than english/porter not implemented (see below) |
| N-000432 | 09 | partial | lingora/stem.py | WordNet lemmatizer success path not implemented; refusal path implemented |
| N-000433 | 10 | implemented, tested | lingora/tag.py |  |
| N-000434 | 10 | implemented, tested | lingora/tag.py |  |
| N-000435 | 10 | implemented, tested | lingora/tag.py |  |
| N-000436 | 10 | implemented, tested | lingora/tag.py |  |
| N-000437 | 10 | implemented, tested | lingora/tag.py |  |
| N-000438 | 10 | implemented, tested | lingora/tag.py |  |
| N-000439 | 10 | implemented, tested | lingora/tag.py |  |
| N-000440 | 10 | implemented, tested | lingora/tag.py |  |
| N-000441 | 10 | implemented, tested | lingora/tag.py |  |
| N-000442 | 10 | implemented, tested | lingora/tag.py |  |
| N-000443 | 10 | implemented, tested | lingora/tag.py |  |
| N-000444 | 10 | implemented, tested | lingora/tag.py |  |
| N-000445 | 10 | implemented, tested | lingora/tag.py |  |
| N-000446 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000447 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000448 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000449 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000450 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000451 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000452 | 11 | partial | lingora/chunk.py | ne_chunk refusal path implemented; success path not implemented (see N-000231) |
| N-000453 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000454 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000455 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000456 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000457 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000458 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000459 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000460 | 11 | implemented, tested | lingora/chunk.py |  |
| N-000461 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000462 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000463 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000464 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000465 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000466 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000467 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000468 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000469 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000470 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000471 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000472 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000473 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000474 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000475 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000476 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000477 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000478 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000479 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000480 | 12 | implemented, tested | lingora/grammar.py; lingora/parse/ |  |
| N-000481 | 13 | implemented, tested | lingora/tree.py |  |
| N-000482 | 13 | implemented, tested | lingora/tree.py |  |
| N-000483 | 13 | implemented, tested | lingora/tree.py |  |
| N-000484 | 13 | implemented, tested | lingora/tree.py |  |
| N-000485 | 13 | implemented, tested | lingora/tree.py |  |
| N-000486 | 13 | implemented, tested | lingora/tree.py |  |
| N-000487 | 13 | implemented, tested | lingora/tree.py |  |
| N-000488 | 13 | implemented, tested | lingora/tree.py |  |
| N-000489 | 13 | implemented, tested | lingora/tree.py |  |
| N-000490 | 13 | implemented, tested | lingora/tree.py |  |
| N-000491 | 13 | implemented, tested | lingora/tree.py |  |
| N-000492 | 14 | implemented, tested | lingora/classify.py |  |
| N-000493 | 14 | implemented, tested | lingora/classify.py |  |
| N-000494 | 14 | implemented, tested | lingora/classify.py |  |
| N-000495 | 14 | implemented, tested | lingora/classify.py |  |
| N-000496 | 14 | implemented, tested | lingora/classify.py |  |
| N-000497 | 14 | implemented, tested | lingora/classify.py |  |
| N-000498 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000499 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000500 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000501 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000502 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000503 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000504 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000505 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000506 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000507 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000508 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000509 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000510 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000511 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000512 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000513 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000514 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000515 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000516 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000517 | 15 | implemented, tested | lingora/metrics.py; lingora/translate.py | ne_chunk etc. not here |
| N-000001 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000002 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000003 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000004 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000005 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000006 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000007 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000008 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000009 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000010 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000011 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000012 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000013 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000014 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000015 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000016 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000017 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000018 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000019 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000020 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000021 | 16 | scope | product scope (no code) | Product overview: feature points define scope |
| N-000022 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000023 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000024 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000025 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000026 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000027 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000028 | 17 | implemented, tested | terms used throughout lingora/ | Terminology |
| N-000029 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000030 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000031 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000032 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000033 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000034 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000035 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000036 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000037 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000038 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000039 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000040 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000041 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000042 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000043 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000044 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000045 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000046 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000047 | 18 | implemented, tested | public surface listed in lingora/* | Surface inventory; ISRI/Cistem/RSLP/Affix/recursive-descent not built (see below) |
| N-000048 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000049 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000050 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000051 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000052 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000053 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000054 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000055 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000056 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000057 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000058 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000059 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000060 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000061 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000062 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000063 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000064 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000065 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000066 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000067 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000068 | 19 | scope/packaging | pure Python; data finder in lingora/data.py | Non-functional constraints |
| N-000069 | 20 | implemented, tested | lingora/* | Core capability statement |
| N-000070 | 20 | implemented, tested | lingora/* | Core capability statement |
| N-000071 | 20 | implemented, tested | lingora/* | Core capability statement |
| N-000072 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000073 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000074 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000075 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000076 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000077 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000078 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000079 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000080 | 21 | scope | not built (non-goals) | Non-goals: nothing built for these |
| N-000081 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000082 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000083 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000084 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000085 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000086 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000087 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000088 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000089 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000090 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000091 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000092 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000093 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000094 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000095 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000096 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000097 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000098 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000099 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000100 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000101 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000102 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000103 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000104 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000105 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000106 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000107 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000108 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000109 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000110 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000111 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000112 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000113 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000114 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000115 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000116 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000117 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000118 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000119 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000120 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000121 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000122 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000123 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000124 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000125 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000126 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000127 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000128 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000129 | 22 | partial | lingora/tokenize.py | Punkt: simplified decision rules (abbreviation, collocation, sentence-starter, orthographic) on packaged parameters; no training; not a faithful Kiss & Strunk implementation |
| N-000130 | 22 | partial | lingora/tokenize.py | Punkt uses packaged parameters only (no training) |
| N-000131 | 22 | partial | lingora/tokenize.py | Punkt simplified (see N-000129) |
| N-000132 | 22 | partial | lingora/tokenize.py | Punkt simplified (see N-000129) |
| N-000133 | 22 | partial | lingora/tokenize.py | Punkt simplified (see N-000129) |
| N-000134 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000135 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000136 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000137 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000138 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000139 | 22 | implemented, tested | lingora/tokenize.py | Punkt decision rules simplified (see below) |
| N-000140 | 23 | partial | lingora/stem.py | ISRI, Cistem, RSLP, ARLSTem/ARLSTem2 not implemented (results outside spec); ARLSTem stubs raise NotImplementedError |
| N-000141 | 23 | partial | lingora/stem.py | ISRI, Cistem, RSLP, ARLSTem not implemented (results outside spec) |
| N-000142 | 23 | partial | lingora/stem.py | WordNet lemmatizer: gate only (raises LookupError without WordNet; NotImplementedError with it) |
| N-000143 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000144 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000145 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000146 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000147 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000148 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000149 | 23 | partial | lingora/stem.py | Martin extensions mode not implemented; original and LINGORA modes implemented |
| N-000150 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000151 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000152 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000153 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000154 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000155 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000156 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000157 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000158 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000159 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000160 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000161 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000162 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000163 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000164 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000165 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000166 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000167 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000168 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000169 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000170 | 23 | partial | lingora/stem.py | Lancaster: engine per Paice/Husk; rule table reproduced from memory, unverified and likely incomplete |
| N-000171 | 23 | partial | lingora/stem.py | Lancaster table unverified (see N-000170) |
| N-000172 | 23 | partial | lingora/stem.py | Snowball: english (Porter2) and porter implemented; the other 14 languages are refused with NotImplementedError |
| N-000173 | 23 | not done | lingora/stem.py | Dutch Snowball algorithm not implemented |
| N-000174 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000175 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000176 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000177 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000178 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000179 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000180 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000181 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000182 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000183 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000184 | 23 | implemented, tested | lingora/stem.py | Lancaster rule table unverified (see below) |
| N-000185 | 23 | partial | lingora/stem.py | WordNet reading not implemented; refusal path implemented |
| N-000186 | 23 | partial | lingora/stem.py | WordNet reading not implemented; refusal path implemented |
| N-000187 | 24 | partial | lingora/tag.py | Affix tagger not implemented; default, unigram, regexp, bigram and trigram implemented |
| N-000188 | 24 | partial | lingora/tag.py | Affix tagger not implemented |
| N-000189 | 24 | partial | lingora/tag.py | Bigram and trigram implemented; affix not implemented |
| N-000190 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000191 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000192 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000193 | 24 | implemented | lingora/tag.py | Universal mapping for English requires en-ptb.map; mapping table from packaged file |
| N-000194 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000195 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000196 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000197 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000198 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000199 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000200 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000201 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000202 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000203 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000204 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000205 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000206 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000207 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000208 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000209 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000210 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000211 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000212 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000213 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000214 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000215 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000216 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000217 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000218 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000219 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000220 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000221 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000222 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000223 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000224 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000225 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000226 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000227 | 24 | implemented, tested | lingora/tag.py | Perceptron features and file formats from memory; verify against real resources |
| N-000228 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000229 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000230 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000231 | 25 | not done | lingora/chunk.py | Named-entity chunker: model format not specified; ne_chunk raises NotImplementedError when the resources are present |
| N-000232 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000233 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000234 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000235 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000236 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000237 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000238 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000239 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000240 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000241 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000242 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000243 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000244 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000245 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000246 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000247 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000248 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000249 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000250 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000251 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000252 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000253 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000254 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000255 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000256 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000257 | 25 | implemented, tested | lingora/chunk.py |  |
| N-000258 | 26 | partial | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py | Recursive-descent parser not implemented (results outside spec) |
| N-000259 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000260 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000261 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000262 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000263 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000264 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000265 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000266 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000267 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000268 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000269 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000270 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000271 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000272 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000273 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000274 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000275 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000276 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000277 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000278 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000279 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000280 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000281 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000282 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000283 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000284 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000285 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000286 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000287 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000288 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000289 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000290 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000291 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000292 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000293 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000294 | 26 | implemented, tested | lingora/grammar.py; lingora/parse/; lingora/parse/generate.py; lingora/tree.py |  |
| N-000295 | 27 | implemented, tested | lingora/classify.py |  |
| N-000296 | 27 | implemented, tested | lingora/classify.py |  |
| N-000297 | 27 | implemented, tested | lingora/classify.py |  |
| N-000298 | 27 | implemented, tested | lingora/classify.py |  |
| N-000299 | 27 | implemented, tested | lingora/classify.py |  |
| N-000300 | 27 | implemented, tested | lingora/classify.py |  |
| N-000301 | 27 | implemented, tested | lingora/classify.py |  |
| N-000302 | 27 | implemented, tested | lingora/classify.py |  |
| N-000303 | 27 | implemented, tested | lingora/classify.py |  |
| N-000304 | 27 | implemented, tested | lingora/classify.py |  |
| N-000305 | 27 | implemented, tested | lingora/classify.py |  |
| N-000306 | 27 | implemented, tested | lingora/classify.py |  |
| N-000307 | 27 | implemented, tested | lingora/classify.py |  |
| N-000308 | 27 | implemented, tested | lingora/classify.py |  |
| N-000309 | 27 | implemented, tested | lingora/classify.py |  |
| N-000310 | 27 | implemented, tested | lingora/classify.py |  |
| N-000311 | 27 | implemented, tested | lingora/classify.py |  |
| N-000312 | 27 | implemented, tested | lingora/classify.py |  |
| N-000313 | 27 | implemented, tested | lingora/classify.py |  |
| N-000314 | 27 | implemented, tested | lingora/classify.py |  |
| N-000315 | 27 | implemented, tested | lingora/classify.py |  |
| N-000316 | 27 | implemented, tested | lingora/classify.py |  |
| N-000317 | 27 | implemented, tested | lingora/classify.py |  |
| N-000318 | 27 | implemented, tested | lingora/classify.py |  |
| N-000319 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000320 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000321 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000322 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000323 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000324 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000325 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000326 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000327 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000328 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000329 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000330 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000331 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000332 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000333 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000334 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000335 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000336 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000337 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000338 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000339 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000340 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000341 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000342 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000343 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000344 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000345 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000346 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000347 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000348 | 28 | implemented, tested | lingora/metrics.py; lingora/translate.py |  |
| N-000349 | 29 | scope | not built (outside this specification) | Outside-spec surfaces: not built |
| N-000350 | 29 | scope | not built (outside this specification) | Outside-spec surfaces: not built |
| N-000351 | 29 | scope | not built (outside this specification) | Outside-spec surfaces: not built |
| N-000352 | 29 | scope | not built (outside this specification) | Outside-spec surfaces: not built |
