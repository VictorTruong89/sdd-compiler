"""Context-free grammars (FP-05). # spec: N-000461..N-000471, interface N-000461..N-000471

Nonterminals are ``Nonterminal`` objects whose ``str()`` is the name (the
implementer's choice allowed by N-000468). Terminals are ``str`` values equal
to the quoted text, without quotes.
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_TOKEN = re.compile(r"""'[^']*'|"[^"]*"|\|""" + r"|[^\s|'\"]+")
_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]*")


class Nonterminal:
    """A grammar nonterminal. ``str(nt)`` is its name."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = str(name)

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    """One alternative: ``lhs -> rhs``. # spec: N-000471"""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        parts = []
        for sym in self._rhs:
            parts.append(repr(sym) if isinstance(sym, str) else str(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))


class CFG:
    """A context-free grammar built from production text. # spec: N-000461..N-000467"""

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        """Read productions, one ``LHS -> RHS`` per line. # spec: N-000464, N-000465, N-000266"""
        if not isinstance(input, str):
            raise TypeError("grammar text must be str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production without '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT.fullmatch(lhs_text):
                raise ValueError("bad left-hand side: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            for alternative in _split_alternatives(rhs_text):
                productions.append(Production(lhs, alternative))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        """All productions, in written order (optionally filtered by lhs/rhs)."""
        out = []
        for prod in self._productions:
            if lhs is not None and prod.lhs() != _as_nt(lhs):
                continue
            if rhs is not None and prod.rhs() and prod.rhs()[0] != rhs:
                continue
            out.append(prod)
        return out

    def terminals(self):
        return {sym for prod in self._productions for sym in prod.rhs() if isinstance(sym, str)}


def _as_nt(sym):
    return sym if isinstance(sym, Nonterminal) else Nonterminal(sym)


def _split_alternatives(rhs_text):
    alternatives = [[]]
    for tok in _TOKEN.findall(rhs_text):
        if tok == "|":
            alternatives.append([])
        elif tok[0] in "'\"":
            alternatives[-1].append(tok[1:-1])
        elif _IDENT.fullmatch(tok):
            alternatives[-1].append(Nonterminal(tok))
        else:
            raise ValueError("bad symbol in production: %r" % tok)
    return alternatives
