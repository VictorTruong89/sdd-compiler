"""Text classifiers (FP-06). # spec: N-000295..N-000318, interface: N-000492..N-000497

Featuresets are ``dict`` objects from feature names to values; labels are any
hashable values. Training data is a list of ``(featureset, label)`` pairs.
"""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    data = list(labeled_featuresets)
    if not data:
        raise ValueError("training data is empty")
    for pair in data:
        featureset, _label = pair
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
    return data


class ProbDist:
    """A probability distribution over labels. # spec: N-000496, N-000497"""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing over each feature's observed values.

    # spec: N-000302..N-000309, N-000492..N-000495
    """

    def __init__(self, labels, priors, value_counts, label_totals, feature_values):
        self._labels = labels
        self._priors = priors
        self._value_counts = value_counts  # (label, feature) -> Counter(value -> count)
        self._label_totals = label_totals  # (label, feature) -> total count with a value
        self._feature_values = feature_values  # feature -> set of observed values

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        label_count = Counter()
        value_counts = defaultdict(Counter)
        feature_values = defaultdict(set)
        labels = []
        for featureset, label in data:
            if label not in label_count:
                labels.append(label)
            label_count[label] += 1
            for feat, value in featureset.items():
                value_counts[(label, feat)][value] += 1
                feature_values[feat].add(value)
        total = len(data)
        priors = {lab: label_count[lab] / total for lab in labels}
        label_totals = {key: sum(c.values()) for key, c in value_counts.items()}
        return cls(labels, priors, dict(value_counts), label_totals, dict(feature_values))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for lab in self._labels:
            score = math.log(self._priors[lab])
            for feat, value in featureset.items():
                if feat not in self._feature_values:
                    continue  # features never seen in training are ignored
                counts = self._value_counts.get((lab, feat), Counter())
                denom = self._label_totals.get((lab, feat), 0) + len(self._feature_values[feat]) + 1
                # Add-one smoothing: unseen values under this label keep a non-zero probability.
                score += math.log((counts.get(value, 0) + 1) / denom)
            scores[lab] = score
        return scores

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        return max(self._labels, key=lambda lab: scores[lab])

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {lab: math.exp(s - top) for lab, s in scores.items()}
        norm = sum(weights.values())
        return ProbDist({lab: w / norm for lab, w in weights.items()})


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for lab in labels:  # ties resolved by first appearance
        if counts[lab] == best:
            return lab


class DecisionTreeClassifier:
    """Decision tree (ID3-style information gain over feature values). # spec: N-000310..N-000318"""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        features = sorted({f for fs, _ in data for f in fs}, key=str)
        return cls(cls._build(data, features))

    @classmethod
    def _build(cls, data, features):
        labels = [lab for _, lab in data]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Leaf(majority)
        base = _entropy(labels)
        best_feat, best_gain, best_groups = None, 0.0, None
        for feat in features:
            groups = defaultdict(list)
            for fs, lab in data:
                groups[fs.get(feat)].append((fs, lab))
            remainder = sum(len(g) / len(data) * _entropy([lab for _, lab in g]) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feat, best_gain, best_groups = feat, gain, groups
        if best_feat is None:
            return _Leaf(majority)
        rest = [f for f in features if f != best_feat]
        children = {value: cls._build(group, rest) for value, group in best_groups.items()}
        return _Node(best_feat, children, majority)

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.default  # a value unseen at this node: the node's majority label
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs classified correctly. # spec: N-000301..N-000303"""
    pairs = list(gold)
    if not pairs:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = sum(1 for featureset, label in pairs if classifier.classify(featureset) == label)
    return correct / len(pairs)
