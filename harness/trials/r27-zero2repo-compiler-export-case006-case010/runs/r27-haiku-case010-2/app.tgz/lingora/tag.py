"""Part-of-speech taggers (FP-03).

# spec: N-000187..N-000227 (FP-03), interface: N-000433..N-000445
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data as _data

__all__ = [
    "DefaultTagger",
    "NgramTagger",
    "RegexpTagger",
    "UnigramTagger",
    "BigramTagger",
    "TrigramTagger",
    "pos_tag",
]


def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not str")  # spec: N-000442
    tokens = list(tokens)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str")
    return tokens


def _check_backoff(backoff):
    if backoff is not None and not hasattr(backoff, "tag"):
        raise TypeError("backoff must be a tagger or None")


class _SequentialTagger:
    """Base class: primary tagging, then the backoff for unassigned tokens. # spec: N-000205, N-000206"""

    backoff = None

    def _primary(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._primary(tokens)
        if self.backoff is not None and any(t is None for t in tags):
            fallback = self.backoff.tag(tokens)
            tags = [t if t is not None else fb[1] for t, fb in zip(tags, fallback)]
        return [(tok, t) for tok, t in zip(tokens, tags)]  # spec: N-000196, N-000197


class DefaultTagger(_SequentialTagger):
    """Assigns one tag to every token. # spec: N-000198, N-000433, N-000434, N-000435"""

    def __init__(self, tag, backoff=None):
        if tag is not None and not isinstance(tag, str):
            raise TypeError("tag must be str or None")
        _check_backoff(backoff)
        self._tag = tag
        self.backoff = backoff

    def _primary(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    """Most frequent training tag per word. # spec: N-000199..N-000201, N-000436, N-000437"""

    def __init__(self, train=None, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            for pair in sentence:
                word, tag = pair
                counts[word][tag] += 1
        # Ties broken by the tag string (implementer's choice; spec N-000200).
        self._model = {w: max(c.items(), key=lambda kv: (kv[1], str(kv[0])))[0] for w, c in counts.items()}

    def _primary(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class NgramTagger(_SequentialTagger):
    """Context tagger over the previous ``n-1`` assigned tags. Bigram/trigram variants below."""

    def __init__(self, n, train=None, backoff=None):
        _check_backoff(backoff)
        if n < 2:
            raise ValueError("n must be at least 2")
        self._n = n
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            history = ()
            for word, tag in sentence:
                counts[(history, word)][tag] += 1
                history = (history + (tag,))[-(n - 1):]
        self._model = {k: max(c.items(), key=lambda kv: (kv[1], str(kv[0])))[0] for k, c in counts.items()}

    def _primary(self, tokens):
        tags = []
        history = ()
        for tok in tokens:
            tag = self._model.get((history, tok))
            tags.append(tag)
            if tag is not None:
                history = (history + (tag,))[-(self._n - 1):]
            else:
                history = ()
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; the first pattern matching at the token's start wins. # spec: N-000202..N-000204, N-000438, N-000439"""

    def __init__(self, regexps, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        self._rules = []
        for pair in regexps:
            pattern, tag = pair
            if not isinstance(pattern, str) or not isinstance(tag, str):
                raise TypeError("each rule is a (pattern, tag) pair of str")
            self._rules.append((re.compile(pattern), tag))

    def _primary(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for rx, t in self._rules:
                if rx.match(tok):
                    tag = t
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------------------
# Averaged perceptron (recommended English and Russian taggers)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_CACHE = {}


def _normalise(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


class _AveragedPerceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for tag, weight in self.weights[feat].items():
                scores[tag] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalise(w) for w in tokens] + _END
        output = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = _features(i, word, context, prev, prev2)
                tag = self.predict(features)
            output.append(tag)
            prev2, prev = prev, tag
        return output


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


def _load_perceptron(lang):
    # spec: N-000399, N-000400, N-000401 (weights, tagdict and classes files)
    if lang in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[lang]
    directory = _data.require("taggers/averaged_perceptron_tagger_%s" % lang, "dir")
    base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)

    def load(suffix):
        path = base + "." + suffix + ".json"
        if not os.path.isfile(path):
            raise LookupError("packaged resource file not found: %s" % path)
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)

    model = _AveragedPerceptron(load("weights"), load("tagdict"), load("classes"))
    _PERCEPTRON_CACHE[lang] = model
    return model


_RUS_UNIVERSAL = {  # spec: N-000218 - the table is the implementer's choice.
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "NUM": "NUM", "APRO": "DET", "SPRO": "PRON", "ANUM": "ADJ",
    "INTJ": "X", "PRAEDIC": "ADV", "PARENTH": "PRT",
}


def _universal_map(tags, lang):
    if lang == "eng":
        # LookupError when the table is absent: the mapping does not take place (N-000226).
        table_path = _data.require("taggers/universal_tagset/en-ptb.map", "file")
        table = {}
        with open(table_path, encoding="utf-8") as handle:
            for line in handle:
                parts = line.split()
                if len(parts) == 2:
                    table[parts[0]] = parts[1]
        return [table.get(t, t) for t in tags]
    return [_RUS_UNIVERSAL.get(t.split("=", 1)[0], t.split("=", 1)[0]) for t in tags]  # spec: N-000216, N-000217


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the recommended tagger. # spec: N-000213..N-000227, N-000440..N-000445

    ``lang`` is ``'eng'`` (default) or ``'rus'``; ``tagset`` is None (native) or ``'universal'``.
    """
    tokens = _check_tokens(tokens)  # refuses a raw string (N-000442)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for pos_tag: %r" % (lang,))  # spec: N-000443
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset: %r" % (tagset,))
    model = _load_perceptron(lang)
    tags = model.tag(tokens) if tokens else []
    if tagset == "universal":
        tags = _universal_map(tags, lang)
    return list(zip(tokens, tags))
