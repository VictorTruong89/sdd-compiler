"""Parsers over a context-free grammar (FP-05).

# spec: N-000266..N-000276, N-000292..N-000294
"""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not str")
    tokens = list(tokens)
    terminals = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str")
        # spec: N-000292..N-000294 - a token no production produces makes the call raise.
        if tok not in terminals:
            raise ValueError("token %r is not produced by any production" % tok)
    return tokens


class ChartParser:
    """Exhaustive chart-style parser: every tree the grammar assigns. # spec: N-000266..N-000271, N-000473..N-000476"""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        memo = {}
        active = set()
        grammar = self._grammar

        def match(rhs, k, i, j):
            """Child lists covering tokens[i:j] with rhs[k:]."""
            if k == len(rhs):
                return [[]] if i == j else []
            sym = rhs[k]
            if isinstance(sym, str):
                if sym == "":
                    return match(rhs, k + 1, i, j)
                if i < j and tokens[i] == sym:
                    return [[tokens[i]] + rest for rest in match(rhs, k + 1, i + 1, j)]
                return []
            out = []
            for m in range(i, j + 1):
                subtrees = trees_for(str(sym), i, m)
                if not subtrees:
                    continue
                rests = match(rhs, k + 1, m, j)
                for sub in subtrees:
                    for rest in rests:
                        out.append([sub] + rest)
            return out

        def trees_for(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in active:  # cycle guard for unit/empty-production loops
                return []
            active.add(key)
            results = []
            for prod in grammar.productions(lhs=name):
                for children in match(prod.rhs(), 0, i, j):
                    results.append(Tree(name, children))
            active.discard(key)
            memo[key] = results
            return results

        return iter(trees_for(str(grammar.start()), 0, len(tokens)))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking. # spec: N-000272..N-000275, N-000474..N-000476"""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar
        # Empty productions would reduce forever; the pass uses non-empty ones only.
        self._prods = [p for p in grammar.productions() if len(p) > 0]

    @staticmethod
    def _matches(items, rhs):
        for item, sym in zip(items, rhs):
            if isinstance(sym, str):
                if not (isinstance(item, str) and item == sym):
                    return False
            else:
                if not (isinstance(item, Tree) and item.label() == str(sym)):
                    return False
        return True

    @staticmethod
    def _signature(stack):
        # Future decisions depend only on labels and tokens, so a repeated signature
        # since the last shift means the reductions are looping (e.g. S -> S).
        return tuple(("T", item.label()) if isinstance(item, Tree) else ("s", item) for item in stack)

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        stack = []
        pos = 0
        seen = {()}
        while True:
            reduced = False
            for prod in self._prods:
                n = len(prod)
                if len(stack) >= n and self._matches(stack[len(stack) - n:], prod.rhs()):
                    new_stack = stack[:len(stack) - n] + [Tree(str(prod.lhs()), list(stack[len(stack) - n:]))]
                    signature = self._signature(new_stack)
                    if signature in seen:
                        continue
                    seen.add(signature)
                    stack = new_stack
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                seen = {self._signature(stack)}
                continue
            break
        start = str(self._grammar.start())
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])
