"""Generate sentences from a grammar. # spec: N-000276..N-000280, N-000477..N-000480"""

from lingora.grammar import CFG, Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Yield token lists derivable from ``start`` (default: the grammar's start symbol). # spec: N-000276..N-000280


    ``depth`` bounds the derivation depth (None: no bound); ``n`` bounds the
    number of sentences (None: no bound). Productions are expanded in their
    written order (depth-first, leftmost). An empty terminal adds no token.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool)):
        raise TypeError("depth must be int or None")
    if n is not None and (not isinstance(n, int) or isinstance(n, bool)):
        raise TypeError("n must be int or None")
    start_sym = grammar.start() if start is None else start
    if not isinstance(start_sym, Nonterminal):
        start_sym = Nonterminal(start_sym)
    return _generate(grammar, start_sym, depth, n)


def _generate(grammar, start_sym, depth, n):
    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(str(prod.lhs()), []).append(prod)
    # A form is a tuple of (symbol, derivation depth); symbols are str terminals or Nonterminals.
    stack = [((start_sym, 0),)]
    produced = 0
    while stack:
        form = stack.pop()
        index = None
        for k, (sym, _d) in enumerate(form):
            if isinstance(sym, Nonterminal):
                index = k
                break
        if index is None:
            if n is not None and produced >= n:
                return
            produced += 1
            yield [sym for sym, _d in form if sym != ""]
            if n is not None and produced >= n:
                return
            continue
        sym, d = form[index]
        if depth is not None and d + 1 > depth:
            continue  # this branch cannot be expanded within the depth bound
        prefix = form[:index]
        rest = form[index + 1:]
        # Push in reverse so the first written production is expanded first.
        for prod in reversed(by_lhs.get(str(sym), [])):
            expansion = tuple((s, d + 1) for s in prod.rhs())
            stack.append(prefix + expansion + rest)
