"""Constituent trees (FP-05). # spec: N-000281..N-000291, interface N-000481..N-000491

A ``Tree`` is a labelled, ordered list of children; a child is a leaf (a token
string, or a ``(token, tag)`` pair in chunk structures) or another ``Tree``.
"""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN = re.compile(r"\(|\)|[^\s()]+")


class Tree(list):
    """A labelled tree. ``Tree(label, children)``; ``children`` must be a list."""

    def __init__(self, label, children):
        # spec: N-000486..N-000488 - a str or a missing child list is refused.
        if not isinstance(children, list):
            raise TypeError("children must be a list, not %s" % type(children).__name__)
        super().__init__(children)
        self._label = label

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __eq__(self, other):
        # spec: N-000285 - equal labels and pairwise-equal children, recursively.
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list(self) == list(other)

    def __ne__(self, other):
        return not self.__eq__(other)

    __hash__ = None

    def __repr__(self):
        def one_line(node):
            if not isinstance(node, Tree):
                return _leaf_text(node)
            inner = " ".join(one_line(c) for c in node)
            return "(%s %s)" % (node.label(), inner) if inner else "(%s)" % node.label()

        return one_line(self)

    def pformat(self):
        """Pretty-printed form, labels and leaves in pre-order. # spec: N-000287, N-000490"""
        return _pformat(self, 0)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text. # spec: N-000286, N-000489"""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be str")
        tokens = _BRACKET_TOKEN.findall(s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in "()":
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced brackets in tree text")
                tok = tokens[pos]
                if tok == ")":
                    pos += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos += 1

        tree = parse_node()
        if pos != len(tokens):
            raise ValueError("trailing text after tree")
        return tree


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


def _pformat(node, indent):
    if not isinstance(node, Tree):
        return _leaf_text(node)
    if all(not isinstance(c, Tree) for c in node):
        return "(" + str(node.label()) + "".join(" " + _leaf_text(c) for c in node) + ")"
    pad = " " * (indent + 2)
    parts = ["(" + str(node.label())]
    for child in node:
        parts.append("\n" + pad + _pformat(child, indent + 2))
    return "".join(parts) + ")"
