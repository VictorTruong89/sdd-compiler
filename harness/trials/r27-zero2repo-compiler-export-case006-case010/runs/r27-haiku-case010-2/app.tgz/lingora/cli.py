"""Command line (FP-01 command). # spec: N-000414..N-000420, interface: N-000414..N-000420

``cli.main(args=['tokenize'])`` reads UTF-8 text from standard input and writes one
line per input line: the recommended word tokens (with sentence splitting), joined
by the delimiter (a single space by default). Implemented with the standard library
only, so no third-party command-line package is required.
"""

import io
import sys

from lingora import data as _data  # noqa: F401  (resource lookup happens in tokenize)
from lingora import tokenize as _tokenize

__all__ = ["cli"]

USAGE = "usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER]"


def _utf8_stream(stream):
    """Return a UTF-8 text view of ``stream``; the caller must detach a returned wrapper."""
    buffer = getattr(stream, "buffer", None)
    if buffer is None or getattr(stream, "encoding", "").lower() == "utf-8":
        return stream, False
    return io.TextIOWrapper(buffer, encoding="utf-8"), True


class _CommandLine:
    """Program entry. ``main`` ends the process when ``standalone_mode`` is true."""

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(USAGE + "\n")
            return 0 if args else 2
        if args[0] != "tokenize":
            sys.stderr.write("unknown command: %s\n%s\n" % (args[0], USAGE))
            return 2
        language = "english"
        delimiter = " "
        rest = args[1:]
        i = 0
        while i < len(rest):
            opt = rest[i]
            if opt in ("-l", "--language", "-d", "--delimiter") and i + 1 < len(rest):
                if opt in ("-l", "--language"):
                    language = rest[i + 1]
                else:
                    delimiter = rest[i + 1]
                i += 2
            else:
                sys.stderr.write("bad option: %s\n%s\n" % (opt, USAGE))
                return 2
        return self._tokenize(language, delimiter)

    def _tokenize(self, language, delimiter):
        # spec: N-000414..N-000420
        # Check the Punkt model before reading or writing anything (N-000139).
        try:
            _tokenize.load_punkt(language)
        except LookupError as exc:
            sys.stderr.write("lingora: %s\n" % exc)
            return 1
        source, source_wrapped = _utf8_stream(sys.stdin)
        sink, sink_wrapped = _utf8_stream(sys.stdout)
        try:
            for raw in source:
                line = raw.rstrip("\r\n")
                try:
                    tokens = _tokenize.word_tokenize(line, language=language, preserve_line=False)
                except (LookupError, ValueError, TypeError) as exc:
                    sys.stderr.write("lingora: %s\n" % exc)
                    return 1  # no token line is written for the failed input
                sink.write(delimiter.join(tokens) + "\n")
                sink.flush()
            return 0
        finally:
            # Detach wrappers so the process's own standard streams stay open.
            if source_wrapped:
                source.detach()
            if sink_wrapped:
                sink.flush()
                sink.detach()


cli = _CommandLine()
