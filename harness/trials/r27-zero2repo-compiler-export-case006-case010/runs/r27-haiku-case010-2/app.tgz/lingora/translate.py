"""BLEU scoring (FP-07). # spec: N-000335..N-000342, N-000511..N-000517, interface N-000498..N-000500

Tokens are compared exactly as given.
"""

import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against ``references`` (lists of token lists). # spec: N-000511..N-000517

    ``weights`` gives one weight per n-gram order from unigrams; the default is
    equal weights on unigrams through 4-grams (PRD FP-07). Unsmoothed unless
    ``smoothing_function(matches, totals) -> precisions`` is given.
    """
    if not isinstance(references, list) or not references:
        raise TypeError("references must be a non-empty list of token lists")
    refs = []
    for ref in references:
        if not isinstance(ref, list) or not all(isinstance(t, str) for t in ref):
            raise TypeError("each reference must be a list of str")
        refs.append(ref)
    if not isinstance(hypothesis, list) or not all(isinstance(t, str) for t in hypothesis):
        raise TypeError("hypothesis must be a list of str")
    if weights is None:
        weights = [0.25, 0.25, 0.25, 0.25]  # spec: N-000338 (PRD default)
    weights = [float(w) for w in weights]
    if not weights:
        raise ValueError("weights must not be empty")
    max_n = len(weights)

    matches, totals = [], []
    for n in range(1, max_n + 1):
        cand = _ngrams(hypothesis, n)
        total = sum(cand.values())
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count  # clip by the maximum count in any one reference
        clipped = sum(min(count, max_ref[gram]) for gram, count in cand.items())
        matches.append(clipped)
        totals.append(total)

    if smoothing_function is not None:
        precisions = list(smoothing_function(matches, totals))
    else:
        if matches[0] == 0:  # spec: N-000341 - no unigram match scores 0
            return 0.0
        precisions = []
        for m, t in zip(matches, totals):
            precisions.append(m / t if t else 0.0)
        for w, p in zip(weights, precisions):
            if w > 0 and p == 0:  # spec: N-000342 - unsmoothed zero order gives 0
                return 0.0

    log_sum = 0.0
    for w, p in zip(weights, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)
    score = math.exp(log_sum)

    c = len(hypothesis)
    if c == 0:
        return 0.0
    # spec: N-000339 - reference length closest to the candidate length (shorter on ties).
    r = min((len(ref) for ref in refs), key=lambda L: (abs(L - c), L))
    brevity = 1.0 if c > r else math.exp(1 - r / c)
    return score * brevity
