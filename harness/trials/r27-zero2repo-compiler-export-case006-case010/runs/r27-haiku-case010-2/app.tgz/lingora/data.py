"""Data finder for packaged resources.

``data.path`` is a mutable list of directories searched for packaged
resources.  Callers may change its contents in place (``data.path[:] = ...``)
after importing the package; every lookup below reads the list at call time.

# spec: N-000385, N-000386, N-000387, N-000388, N-000389..N-000402
"""

import os
import sys


def _initial_paths():
    # spec: N-000385 - the initial contents are the implementer's choice.
    paths = []
    env = os.environ.get("LINGORA_DATA", "")
    paths.extend(p for p in env.split(os.pathsep) if p)
    paths.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    paths.append(os.path.join(sys.prefix, "share", "lingora"))
    return paths


# spec: N-000385 (mutable list of directory strings)
path = _initial_paths()


def locate(resource, kind="any"):
    """Return the first existing location of ``resource`` on ``path``, or None.

    ``resource`` is a relative name such as ``tokenizers/punkt_tab/english``.
    ``kind`` is ``"dir"``, ``"file"`` or ``"any"``.
    """
    parts = [p for p in resource.split("/") if p]
    for base in list(path):
        candidate = os.path.join(base, *parts)
        if kind in ("dir", "any") and os.path.isdir(candidate):
            return candidate
        if kind in ("file", "any") and os.path.isfile(candidate):
            return candidate
    return None


def require(resource, kind="any"):
    """Like :func:`locate`, but raise ``LookupError`` naming the resource."""
    found = locate(resource, kind)
    if found is None:
        raise LookupError("packaged resource not found: %s" % resource)
    return found
