"""Evaluation metrics (FP-07). # spec: N-000322..N-000348, interface: N-000498..N-000510

Every score or distance is an ``int`` or ``float``, never a ``bool``.
"""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def _check_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("%s must be a number" % name)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance, or unrestricted Damerau–Levenshtein with ``transpositions=True``.

    Insertion and deletion cost 1; substitution costs ``substitution_cost``.
    # spec: N-000322..N-000329, N-000348
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance arguments must be str")
    _check_number(substitution_cost, "substitution_cost")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub)
        prev = cur
    return prev[len(s2)]


def _damerau_levenshtein(a, b, sub_cost):
    """Unrestricted Damerau–Levenshtein distance (Lowrance and Wagner, 1975). # spec: N-000325..N-000327"""
    la, lb = len(a), len(b)
    maxdist = la + lb
    d = [[0] * (lb + 2) for _ in range(la + 2)]
    d[0][0] = maxdist
    for i in range(la + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(lb + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, la + 1):
        last_match_col = 0
        for j in range(1, lb + 1):
            i1 = last_row.get(b[j - 1], 0)
            j1 = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[a[i - 1]] = i
    result = d[la + 1][lb + 1]
    return result


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over the size of the union. # spec: N-000507, N-000331"""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance arguments must be sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def accuracy(reference, test):
    """Fraction of equal positions; lists of different lengths are refused. # spec: N-000330, N-000343, N-000501, N-000502"""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy arguments must be lists")
    if len(reference) != len(test):
        raise ValueError("accuracy: lists of different lengths")
    if not reference:
        raise ValueError("accuracy of empty lists is undefined")
    return sum(1 for r, t in zip(reference, test) if r == t) / len(reference)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        # spec: N-000345 - lists, tuples and other non-set collections are refused.
        raise TypeError("precision/recall/f_measure arguments must be sets")


def precision(reference, test):
    """|reference ∩ test| / |test|, or None when the test set is empty. # spec: N-000332, N-000344..N-000347, N-000508..N-000510"""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|, or None when the reference set is empty. # spec: N-000332, N-000344..N-000347, N-000508..N-000510"""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when no number results. # spec: N-000333, N-000334, N-000346"""
    _check_sets(reference, test)
    _check_number(alpha, "alpha")
    if not reference or not test or not (reference & test):
        return None  # spec: N-000346 - no shared element or an empty set: no number
    p = len(reference & test) / len(test)
    r = len(reference & test) / len(reference)
    if p == 0 or r == 0:
        return 0
    return 1 / (alpha / p + (1 - alpha) / r)
