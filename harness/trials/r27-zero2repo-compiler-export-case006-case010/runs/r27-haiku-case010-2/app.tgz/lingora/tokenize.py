"""Tokenizers (FP-01) and the Punkt sentence tokenizer.

# spec: N-000081..N-000139 (FP-01), interface: N-000403..N-000413
"""

import os
import re

from lingora import data as _data

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]

_OPENERS = "\"'([{<“‘«"
_CLOSERS = "\"')]}>»”’"


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be str, not %s" % type(text).__name__)


# ---------------------------------------------------------------------------
# Punkt parameters and sentence splitting
# ---------------------------------------------------------------------------

class PunktParameters:
    """Packaged Punkt parameters for one language. # spec: N-000129, N-000130"""

    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


_PARAM_CACHE = {}
_NUMBER_RE = re.compile(r"[-.,]*\d[-.,\d]*")


def _read_lines(path):
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.rstrip("\r\n") != ""]


def load_punkt(language="english"):
    """Load the packaged Punkt model for ``language``; raise LookupError if absent.

    # spec: N-000389, N-000398, N-000399, N-000402 (packaged Punkt files)
    """
    directory = _data.require("tokenizers/punkt_tab/%s" % language, "dir")
    cached = _PARAM_CACHE.get(directory)
    if cached is not None:
        return cached
    abbrev = {line.strip().lower() for line in _read_lines(os.path.join(directory, "abbrev_types.txt"))}
    starters = {line.strip().lower() for line in _read_lines(os.path.join(directory, "sent_starters.txt"))}
    collocations = set()
    for line in _read_lines(os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, starters, collocations, ortho)
    _PARAM_CACHE[directory] = params
    return params


_ORTHO_UC_START = 2


def _is_break(core, next_word, params):
    """Decide whether the period-final token ``core`` ends a sentence."""
    if core[-1] in "?!":
        return True
    typ = core.rstrip(".").lstrip(_OPENERS).lower()
    abbrev_like = (
        typ == ""
        or typ in params.abbrev_types
        or "." in typ  # an acronym such as U.S. (its final period is the boundary candidate)
        or (len(typ) == 1 and typ.isalpha())
        or bool(_NUMBER_RE.fullmatch(typ))
    )
    if not abbrev_like:
        return True
    # Abbreviation, initial, number or ellipsis: a break needs a sentence-start signal.
    next_core = next_word.lstrip(_OPENERS).rstrip(_CLOSERS + ".?!,;:")
    next_type = next_core.lower()
    if not next_core or not next_core[0].isupper():
        return False
    if (typ, next_type) in params.collocations:
        return False
    if next_type in params.sent_starters:
        return True
    ortho = params.ortho_context.get(next_type, 0)
    return bool(ortho & _ORTHO_UC_START) and not (ortho & 32)


def _split_sentences(text, params):
    tokens = [(m.start(), m.end(), m.group()) for m in re.finditer(r"\S+", text)]
    if not tokens:
        return []
    sentences = []
    first = 0
    for k, (_start, end, word) in enumerate(tokens):
        core = word.rstrip(_CLOSERS)
        if not core or core[-1] not in ".?!":
            continue
        if k == len(tokens) - 1 or _is_break(core, tokens[k + 1][2], params):
            sentences.append(text[tokens[first][0]:end])
            first = k + 1
    if first < len(tokens):
        sentences.append(text[tokens[first][0]:tokens[-1][1]])
    return sentences


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``.

    Raises LookupError when the Punkt model is not visible.
    # spec: N-000129..N-000133, N-000137, N-000408, N-000411, N-000413
    """
    _check_text(text)
    params = load_punkt(language)
    return _split_sentences(text, params)


# ---------------------------------------------------------------------------
# Word/punctuation, Penn Treebank and recommended word tokenizers
# ---------------------------------------------------------------------------

_FUSED = {
    "cannot": 3,   # can + not
    "d'ye": 1,     # d + 'ye
    "gimme": 3,    # gim + me
    "gonna": 3,    # gon + na
    "gotta": 3,    # got + ta
    "lemme": 3,    # lem + me
    "more'n": 4,   # more + 'n
    "wanna": 3,    # wan + na
    "'tis": 2,     # 't + is
    "'twas": 2,    # 't + was
}


def _penn(text, improved=False):
    s = text
    if improved:
        # spec: N-000105, N-000106 - a straight quote at the very start is the closing token.
        s = re.sub(r'^"', " '' ", s)
        s = re.sub(r"([“”„‟])", r" \1 ", s)  # spec: N-000105
        # Single typographic quotes split off only when not inside a word (don’t stays whole).
        s = re.sub(r"(?<!\w)[‘’‚‛]|[‘’‚‛](?!\w)", lambda m: " %s " % m.group(), s)
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(), s)  # spec: N-000108
        s = re.sub(r"([‒-―*])", r" \1 ", s)  # spec: N-000107
        s = s.replace("--", " -- ")  # spec: N-000109
    # spec: N-000094..N-000096 - opening quote after start/space/opening bracket.
    s = re.sub(r'(^|[\s(\[{<])"', r"\1 `` ", s)
    s = s.replace('"', " '' ")
    if not improved:
        s = re.sub(r"\.\.\.", " ... ", s)  # spec: N-000098
    s = re.sub(r"([;@#$%&?!])", r" \1 ", s)  # spec: N-000097
    s = re.sub(r"([\[\](){}<>])", r" \1 ", s)  # spec: N-000098
    s = re.sub(r"([:,])(?!\d)", r" \1 ", s)  # spec: N-000099
    # spec: N-000100 - a point splits only when it ends the text (plus closers).
    s = re.sub(r"\.((?:['\"\]\)}>]|\s)*)$", lambda m: " ." + m.group(1), s)
    # spec: N-000101 - clitics.
    s = re.sub(r"(?i)([^\s])('s|'m|'d|'ll|'re|'ve)\b", r"\1 \2", s)
    s = re.sub(r"(?i)([^\s])(n't)\b", r"\1 \2", s)
    s = re.sub(r"([^\s'])(')(?=\s|$)", r"\1 \2", s)
    out = []
    for token in s.split():
        key = token.lower()
        # spec: N-000102, N-000110 - fused forms split, except cannot in the recommended tokenizer.
        if key in _FUSED and not (improved and key == "cannot"):
            k = _FUSED[key]
            out.append(token[:k])
            out.append(token[k:])
        else:
            out.append(token)
    return out


def wordpunct_tokenize(text):
    """Word/punctuation tokenizer. # spec: N-000089..N-000091, N-000403, N-000404, N-000411"""
    _check_text(text)
    return re.findall(r"\w+|[^\w\s]+", text)


class WordPunctTokenizer:
    """# spec: N-000089..N-000091, N-000126..N-000128"""

    _pattern = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        _check_text(text)
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in self._pattern.finditer(text):
            yield (m.start(), m.end())


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer. # spec: N-000092..N-000103, N-000405"""

    def tokenize(self, text):
        _check_text(text)
        return _penn(text, improved=False)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer. # spec: N-000104..N-000112, N-000137, N-000409, N-000410, N-000413

    With ``preserve_line=False`` the text is first split into sentences with
    the Punkt model for ``language`` (LookupError if that model is missing).
    """
    _check_text(text)
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_penn(sentence, improved=True))
    return tokens


class WhitespaceTokenizer:
    """# spec: N-000113, N-000126..N-000128, N-000411"""

    _pattern = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in self._pattern.finditer(text):
            yield (m.start(), m.end())


_BLANK_SEP = re.compile(r"\s*\n[ \t\r\f\v]*\n\s*")


def blankline_tokenize(text):
    """Split on blank lines. # spec: N-000114, N-000115, N-000411"""
    _check_text(text)
    pieces = _BLANK_SEP.split(text)
    return [p.strip() for p in pieces if p.strip() != ""]


class RegexpTokenizer:
    """Regular-expression tokenizer. # spec: N-000116..N-000118, N-000405..N-000407, N-000412"""

    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be str")
        self._regex = re.compile(pattern)
        self.pattern = pattern
        self.gaps = bool(gaps)
        # spec: N-000118 - empty pieces are dropped unless discarding is turned off;
        # the PRD's default (on) is used. See NOTES.md.
        self.discard_empty = bool(discard_empty)

    def _spans(self, text):
        if self.gaps:
            spans = []
            pos = 0
            for m in self._regex.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regex.finditer(text)]
        if self.discard_empty:
            spans = [(s, e) for (s, e) in spans if e > s]
        return spans

    def tokenize(self, text):
        _check_text(text)
        return [text[s:e] for (s, e) in self._spans(text)]

    def span_tokenize(self, text):
        _check_text(text)
        for span in self._spans(text):
            yield span


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]"
    r"|[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?|<3)"
)
_TWEET_RE = re.compile(
    r"(?P<emo>" + _EMOTICON + r")"
    r"|(?P<url>(?:https?://|www\.)[^\s<>]+)"
    r"|(?P<html><[^>\s]+>)"
    r"|(?P<handle>@\w+)"
    r"|(?P<hash>\#\w+)"
    r"|(?P<word>\w+(?:['’]\w+)*)"
    r"|(?P<dots>\.{2,})"
    r"|(?P<punct>[^\w\s])"
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")  # spec: N-000123


class TweetTokenizer:
    """Tweet-style tokenizer. # spec: N-000119..N-000125, N-000066, N-000067, N-000406, N-000407

    ``preserve_case`` is on by default (PRD); when off, tokens are lowercased
    except emoticons.
    """

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.S)  # spec: N-000124
        tokens = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group()
            if not self.preserve_case and m.lastgroup != "emo":
                tok = tok.lower()  # spec: N-000125
            tokens.append(tok)
        return tokens
