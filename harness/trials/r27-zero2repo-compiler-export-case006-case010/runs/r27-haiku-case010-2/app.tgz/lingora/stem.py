"""Stemmers (FP-02).

# spec: N-000140..N-000186 (FP-02), interface: N-000421..N-000432
"""

import re

from lingora import data as _data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)  # spec: N-000428, N-000147


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be str, not %s" % type(word).__name__)


# ---------------------------------------------------------------------------
# Porter (original, and the LINGORA extensions used as the default mode)
# ---------------------------------------------------------------------------

_IRREGULAR = {  # spec: N-000155 - the table's entries are outside the spec.
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "innings": "inning", "outings": "outing",
    "cannings": "canning", "proceed": "proceed", "exceed": "exceed",
    "succeed": "succeed", "news": "news", "howe": "howe",
}

_VOWELS_PORTER = "aeiou"


def _cons(w, i):
    c = w[i]
    if c in _VOWELS_PORTER:
        return False
    if c == "y":
        return i == 0 or not _cons(w, i - 1)
    return True


def _measure(stem):
    shape = "".join("c" if _cons(stem, i) else "v" for i in range(len(stem)))
    return len(re.findall("vc", shape))


def _has_vowel(stem):
    return any(not _cons(stem, i) for i in range(len(stem)))


def _double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _cons(w, len(w) - 1)


def _cvc(w, lingora):
    # spec: N-000161 - the *o condition also holds for a two-letter vowel+consonant stem.
    n = len(w)
    if lingora and n == 2:
        return (not _cons(w, 0)) and _cons(w, 1) and w[1] not in "wxy"
    if n < 3:
        return False
    return _cons(w, n - 3) and not _cons(w, n - 2) and _cons(w, n - 1) and w[-1] not in "wxy"


_STEP2_ORIG = {
    "ational": "ate", "tional": "tion", "enci": "ence", "anci": "ance",
    "izer": "ize", "abli": "able", "alli": "al", "entli": "ent", "eli": "e",
    "ousli": "ous", "ization": "ize", "ation": "ate", "ator": "ate",
    "alism": "al", "iveness": "ive", "fulness": "ful", "ousness": "ous",
    "aliti": "al", "iviti": "ive", "biliti": "ble",
}
_STEP2_LINGORA = dict(_STEP2_ORIG)
del _STEP2_LINGORA["abli"]
_STEP2_LINGORA.update({"bli": "ble", "fulli": "ful", "logi": "log"})  # spec: N-000165..N-000167

_STEP3 = {"icate": "ic", "ative": "", "alize": "al", "iciti": "ic", "ical": "ic", "ful": "", "ness": ""}
_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize"]


def _replace_longest(word, table, min_measure_check):
    best = None
    for suffix in table:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    if best is None:
        return word, False
    stem = word[: len(word) - len(best)]
    if min_measure_check(stem):
        return stem + table[best], True
    return word, True


def _porter(word, lingora):
    """Porter stemmer. ``lingora`` selects the LINGORA extensions (spec FP-02)."""
    if len(word) <= 2:  # spec: N-000156, N-000157
        return word
    if lingora and word in _IRREGULAR:  # spec: N-000154, N-000155
        return _IRREGULAR[word]
    w = word
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        if lingora and len(w) == 4:  # spec: N-000158
            w = w[:-1]
        else:
            w = w[:-2]
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]
    # Step 1b
    skip_1b = False
    if lingora and w.endswith("ied"):  # spec: N-000159, N-000160
        w = w[:-1] if len(w) == 4 else w[:-2]
        skip_1b = True
    if not skip_1b:
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                w = w[:-1]
        elif (w.endswith("ed") and _has_vowel(w[:-2])) or (w.endswith("ing") and _has_vowel(w[:-3])):
            w = w[:-2] if w.endswith("ed") else w[:-3]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif _double_cons(w) and w[-1] not in "lsz":
                w = w[:-1]
            elif _measure(w) == 1 and _cvc(w, lingora):
                w += "e"
    # Step 1c
    if w.endswith("y") and len(w) >= 2:
        if lingora:
            # spec: N-000162 - y becomes i after a consonant that is not the first letter.
            if len(w) >= 3 and _cons(w, len(w) - 2):
                w = w[:-1] + "i"
        elif _has_vowel(w[:-1]):
            w = w[:-1] + "i"
    # Step 2 (spec: N-000163, N-000164 - alli is tried first in LINGORA mode)
    if lingora and w.endswith("alli") and _measure(w[:-4]) > 0:
        w = w[:-1]
        w, _ = _replace_longest(w, _STEP2_LINGORA, lambda s: _measure(s) > 0)
    else:
        table = _STEP2_LINGORA if lingora else _STEP2_ORIG
        w, _ = _replace_longest(w, table, lambda s: _measure(s) > 0)
    # Step 3
    w, _ = _replace_longest(w, _STEP3, lambda s: _measure(s) > 0)
    # Step 4
    for suffix in sorted(_STEP4, key=len, reverse=True):
        if w.endswith(suffix):
            stem = w[: len(w) - len(suffix)]
            if suffix == "ion":
                if stem.endswith(("s", "t")) and _measure(stem) > 1:
                    w = stem
            elif _measure(stem) > 1:
                w = stem
            break
    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _cvc(stem, lingora)):
            w = stem
    if w.endswith("ll") and _measure(w[:-1]) > 1:
        w = w[:-1]
    return w


# ---------------------------------------------------------------------------
# Porter2 (Snowball English), used by SnowballStemmer('english')
# ---------------------------------------------------------------------------

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_P2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_VOWELS = "aeiouy"
_P2_LI = "cdeghkmnrt"


def _p2_is_vowel(w, i):
    return w[i] in _P2_VOWELS  # 'Y' (marked consonant y) is not in this set


def _p2_region_start(w, start):
    for i in range(max(start, 1), len(w)):
        if not _p2_is_vowel(w, i) and _p2_is_vowel(w, i - 1):
            return i + 1
    return len(w)


def _p2_short(w):
    if len(w) == 2:
        return _p2_is_vowel(w, 0) and not _p2_is_vowel(w, 1)
    if len(w) >= 3:
        return (not _p2_is_vowel(w, -3)) and _p2_is_vowel(w, -2) and (not _p2_is_vowel(w, -1)) and w[-1] not in "wxY"
    return False


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if word in _P2_INVARIANT:
        return word
    w = word
    if w.startswith("'"):
        w = w[1:]
    if w.startswith("y"):
        w = "Y" + w[1:]
    w = "".join("Y" if (c == "y" and i > 0 and _p2_is_vowel(w, i - 1)) else c for i, c in enumerate(w))
    if word.startswith(("gener", "commun", "arsen")):
        r1 = 5 if word.startswith(("gener", "arsen")) else 6
    else:
        r1 = _p2_region_start(w, 0)
    r2 = _p2_region_start(w, r1)
    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        stem = w[:-3]
        w = stem + ("i" if len(stem) > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s") and _has_vowel_p2(w[:-2]):
        w = w[:-1]
    if w in _P2_EXC2:
        return w.replace("Y", "y")
    # Step 1b
    if w.endswith(("eed", "eedly")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if _has_vowel_p2(stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif _double_cons_p2(w):
                        w = w[:-1]
                    elif r1 >= len(w) and _p2_short(w):
                        w += "e"
                break
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and not _p2_is_vowel(w, len(w) - 2):
        w = w[:-1] + "i"
    # Step 2 (only inside R1)
    s2 = {
        "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
        "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
        "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
        "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
        "fulli": "ful", "lessli": "less", "ogi": "og", "li": "",
    }
    best = None
    for suf in s2:
        if w.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    if best is not None and len(w) - len(best) >= r1:
        stem = w[: -len(best)]
        if best == "ogi":
            if stem.endswith("l"):
                w = stem + s2[best]
        elif best == "li":
            if stem and stem[-1] in _P2_LI:
                w = stem
        else:
            w = stem + s2[best]
    # Step 3 (R1 / R2)
    s3 = {"tional": ("tion", 1), "ational": ("ate", 1), "alize": ("al", 1), "icate": ("ic", 1),
          "iciti": ("ic", 1), "ical": ("ic", 1), "ful": ("", 1), "ness": ("", 1), "ative": ("", 2)}
    best = None
    for suf in s3:
        if w.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    if best is not None:
        repl, need = s3[best]
        start = len(w) - len(best)
        region = r1 if need == 1 else r2
        if start >= region:
            w = w[:start] + repl
    # Step 4 (R2)
    s4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    best = None
    for suf in s4:
        if w.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    if best is not None and len(w) - len(best) >= r2:
        stem = w[: -len(best)]
        if best != "ion" or stem.endswith(("s", "t")):
            w = stem
    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short(stem)):
            w = stem
    elif w.endswith("l") and len(w) - 1 >= r2 and w.endswith("ll"):
        w = w[:-1]
    return w.replace("Y", "y")


def _has_vowel_p2(stem):
    return any(_p2_is_vowel(stem, i) for i in range(len(stem)))


def _double_cons_p2(w):
    return len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt"


class PorterStemmer:
    """Porter stemmer. ``mode`` is ``"lingora"`` (default) or ``"original"``.

    # spec: N-000149..N-000169, N-000422, N-000424, N-000426, N-000427
    """

    def __init__(self, mode="lingora"):
        if mode not in ("lingora", "original"):
            raise NotImplementedError("Porter mode %r is not implemented" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        if to_lowercase:
            word = word.lower()  # spec: N-000154
        return _porter(word, self.mode == "lingora")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# spec: N-000170, N-000171 - rule table reproduced from the published Paice/Husk
# table (not verified against the original document; see NOTES.md).
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci>", "cn1t>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.",
    "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.",
    "lba3y.", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3y.", "lu2.", "lai3y>",
    "lau3>", "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.",
    "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "pe2>",
    "rae0.", "rei3>", "rn1.", "ra2>", "sei3y>", "ssen4>", "ss0.", "sei2>", "sis2.",
    "si2>", "ssaug4.", "tnem4>", "tn2>", "tse4.", "ta2>", "ui3.", "ua2.", "ub1.",
    "ud1.", "ue1>", "ug1.", "um1.", "un2>", "ur2>", "us2>", "uy3>", "ve1>", "vi3>",
    "v1>", "wh2>", "yt2>", "yoo1.", "yi2>", "yr2>", "yw3>", "yr2.", "zi2>", "zy2>",
]


def _lancaster_parse(rule):
    action = rule[-1]
    body = rule[:-1].replace("*", "")
    m = re.fullmatch(r"([a-z]+)(\d*)([a-z]*)", body)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    suffix = m.group(1)[::-1]  # the table writes suffixes reversed
    remove = int(m.group(2)) if m.group(2) else len(suffix)
    return {
        "suffix": suffix,
        "remove": remove,
        "append": m.group(3),
        "intact": "*" in rule,
        "terminal": action == ".",
    }


_LANCASTER_PARSED = [_lancaster_parse(r) for r in _LANCASTER_RULES]


def _lancaster_acceptable(word):
    if not word:
        return False
    if word[0] in "aeiouy":
        return len(word) > 1
    return len(word) > 2 and re.search("[aeiouy]", word) is not None


class LancasterStemmer:
    """Paice/Husk stemmer. # spec: N-000170..N-000171, N-000421"""

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        changed = True
        while changed:
            changed = False
            for rule in _LANCASTER_PARSED:
                if not word.endswith(rule["suffix"]):
                    continue
                if rule["intact"] and not intact:
                    continue
                new = word[: len(word) - rule["remove"]] + rule["append"]
                if not _lancaster_acceptable(new):
                    continue
                word = new
                intact = False
                changed = True
                if rule["terminal"]:
                    return word
                break
        return word


# ---------------------------------------------------------------------------
# Snowball, regular-expression stemmer, lemmatizer
# ---------------------------------------------------------------------------

class SnowballStemmer:
    """Snowball stemmer. # spec: N-000172..N-000177, N-000181..N-000184, N-000423, N-000428..N-000431"""

    _IMPLEMENTED = ("english", "porter")

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in self._IMPLEMENTED:
            raise NotImplementedError("Snowball algorithm for %r is not implemented" % (language,))
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = frozenset()
        if self.ignore_stopwords:
            # spec: N-000183, N-000184 - the list for this language only.
            path = _data.require("corpora/stopwords/%s" % language, "file")
            with open(path, encoding="utf-8") as handle:
                self._stopwords = frozenset(line.strip().lower() for line in handle if line.strip())

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        lowered = word.lower()
        if self.ignore_stopwords and lowered in self._stopwords:
            return lowered  # spec: N-000177
        if self.language == "english":
            return _porter2(lowered)
        return _porter(lowered, lingora=False)


class RegexpStemmer:
    """Removes every match of ``regexp`` from the word. # spec: N-000178..N-000180, N-000425"""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be str")
        self._regex = re.compile(regexp)
        self.regexp = regexp

    def stem(self, word):
        _check_word(word)
        return self._regex.sub("", word)


class WordNetLemmatizer:
    """WordNet lemmatizer. Requires the WordNet resource. # spec: N-000185, N-000186, N-000432

    The WordNet database reader is not implemented; with the resource visible
    construction raises NotImplementedError rather than returning wrong lemmas.
    """

    def __init__(self):
        _data.require("corpora/wordnet", "any")  # LookupError when WordNet is absent
        raise NotImplementedError("WordNet database reading is not implemented")

    def lemmatize(self, word):
        _check_word(word)
        raise NotImplementedError("WordNet database reading is not implemented")


class ARLSTem:
    """Arabic light stemmer. Exists in the product; its results are outside this spec."""

    def stem(self, word):
        _check_word(word)
        raise NotImplementedError("ARLSTem is not implemented")


class ARLSTem2(ARLSTem):
    """Arabic light stemmer 2. Exists in the product; its results are outside this spec."""
