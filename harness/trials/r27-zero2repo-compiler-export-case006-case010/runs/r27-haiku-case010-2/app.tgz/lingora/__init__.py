"""LINGORA: a pure-Python natural language processing library.

Submodules are imported on demand, e.g. ``from lingora import tokenize``.
Importing the package downloads nothing.
"""

__version__ = "0.1.0"

__all__ = [
    "chunk",
    "classify",
    "cli",
    "data",
    "grammar",
    "metrics",
    "parse",
    "stem",
    "tag",
    "tokenize",
    "translate",
    "tree",
]
