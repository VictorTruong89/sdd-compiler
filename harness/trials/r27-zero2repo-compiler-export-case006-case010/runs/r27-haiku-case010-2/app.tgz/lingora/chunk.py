"""Chunking with chunk grammars (FP-04).

# spec: N-000228..N-000257 (FP-04), interface: N-000446..N-000460
"""

import re

from lingora import data as _data
from lingora.tree import Tree

__all__ = ["RegexpParser", "Stage", "ChunkRule", "ChinkRule", "ne_chunk"]

_INF = float("inf")
_SENTENCE_LABEL = "S"  # spec: N-000456 - the spelling is the implementer's choice.
_QUANT_BRACE = re.compile(r"\{\s*(\d+\s*(,\s*\d*\s*)?|,\s*\d+\s*)\}")


class ChunkRule:
    """A chunk rule ``{...}``: ``elements`` is a compiled tag pattern."""

    kind = "chunk"

    def __init__(self, elements, text):
        self.elements = elements
        self.text = text


class ChinkRule(ChunkRule):
    """A chink rule ``}...{``."""

    kind = "chink"


class Stage:
    """One clause: a chunk label and its rules, applied in written order."""

    def __init__(self, label, rules=None):
        self.label = label
        self.rules = list(rules or [])


def _compile_tag_pattern(body):
    """Compile a tag pattern into (regex, min, max) elements. # spec: N-000232..N-000235, N-000453, N-000454"""
    s = re.sub(r"\s+", "", body)
    if not s:
        raise ValueError("empty tag pattern")
    elements = []
    i = 0
    while i < len(s):
        if s[i] != "<":
            raise ValueError("tag pattern element must start with '<': %r" % s)
        j = s.find(">", i)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern: %r" % s)
        content = s[i + 1:j]
        if not content:
            raise ValueError("empty tag element in tag pattern: %r" % s)
        i = j + 1
        lo, hi = 1, 1
        if i < len(s):
            c = s[i]
            if c == "?":
                lo, hi = 0, 1
                i += 1
            elif c == "*":
                lo, hi = 0, _INF
                i += 1
            elif c == "+":
                lo, hi = 1, _INF
                i += 1
            elif c == "{":
                m = re.match(r"\{(\d*)(,?)(\d*)\}", s[i:])
                if not m or (m.group(1) == "" and m.group(3) == ""):
                    raise ValueError("bad quantifier in tag pattern: %r" % s)
                lo = int(m.group(1)) if m.group(1) else 0
                if m.group(2) == "":
                    hi = lo
                else:
                    hi = int(m.group(3)) if m.group(3) else _INF
                i += m.end()
        elements.append((re.compile("(?:%s)" % content), lo, hi))
    return elements


def _parse_patterns(text):
    """Read the ``{...}`` and ``}...{`` patterns on one line. # spec: N-000453, N-000454"""
    rules = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c == "{":
            j = i + 1
            while j < n:
                if text[j] == "{" and _QUANT_BRACE.match(text, j):
                    j = _QUANT_BRACE.match(text, j).end()
                    continue
                if text[j] == "}":
                    break
                j += 1
            if j >= n:
                raise ValueError("unclosed '{' in chunk grammar: %r" % text)
            body = text[i + 1:j]
            rules.append(ChunkRule(_compile_tag_pattern(body), body))
            i = j + 1
        elif c == "}":
            j = i + 1
            while j < n:
                if text[j] == "{" and not _QUANT_BRACE.match(text, j):
                    break
                j += 1
            if j >= n:
                raise ValueError("unclosed '}' in chunk grammar: %r" % text)
            body = text[i + 1:j]
            rules.append(ChinkRule(_compile_tag_pattern(body), body))
            i = j + 1
        else:
            raise ValueError("unexpected text in chunk grammar: %r" % text)
    return rules


def _parse_grammar(text):
    stages = []
    current = None
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if raw[:1] not in (" ", "\t"):
            if ":" not in stripped:
                raise ValueError("clause must start with '<LABEL>:': %r" % stripped)
            label, rest = stripped.split(":", 1)
            label = label.strip()
            if not label:
                raise ValueError("empty clause label")
            current = Stage(label)
            stages.append(current)
            current.rules.extend(_parse_patterns(rest))
        else:
            if current is None:
                raise ValueError("indented pattern before any clause")
            current.rules.extend(_parse_patterns(stripped))
    if not stages:
        raise ValueError("chunk grammar has no clauses")
    for stage in stages:
        if not stage.rules:
            raise ValueError("clause %r has no patterns" % stage.label)
    return stages


def _match_ends(elements, tags, start, blocked):
    """Set of end positions of matches of ``elements`` starting at ``start``."""
    positions = {start}
    n = len(tags)
    for rx, lo, hi in elements:
        nxt = set()
        for p in positions:
            cur = p
            k = 0
            if lo == 0:
                nxt.add(cur)
            while k < hi and cur < n and not blocked[cur] and rx.fullmatch(tags[cur]) is not None:
                cur += 1
                k += 1
                if k >= lo:
                    nxt.add(cur)
        positions = nxt
        if not positions:
            return set()
    return positions


def _find_matches(elements, tags, blocked):
    """Leftmost-longest, non-overlapping matches as (start, end) pairs. # spec: N-000236"""
    matches = []
    i = 0
    n = len(tags)
    while i < n:
        if blocked[i]:
            i += 1
            continue
        ends = _match_ends(elements, tags, i, blocked)
        ends.discard(i)
        if ends:
            end = max(ends)
            matches.append((i, end))
            i = end
        else:
            i += 1
    return matches


class _Chunk:
    """A chunk under construction. ``clause`` is the index of the clause that built it."""

    __slots__ = ("label", "children", "clause", "rule")

    def __init__(self, label, children, clause, rule):
        self.label = label
        self.children = children
        self.clause = clause
        self.rule = rule


def _tag_of(unit):
    return unit.label if isinstance(unit, _Chunk) else unit[1]


def _apply_chunk_rule(units, rule, label, clause, rule_index):
    blocked = [isinstance(u, _Chunk) and u.clause == clause for u in units]
    tags = [_tag_of(u) for u in units]
    out = []
    pos = 0
    new_chunks = []
    for start, end in _find_matches(rule.elements, tags, blocked):
        out.extend(units[pos:start])
        chunk = _Chunk(label, units[start:end], clause, rule_index)
        new_chunks.append(len(out))
        out.append(chunk)
        pos = end
    out.extend(units[pos:])
    # Touching chunks from different rules of the same clause are joined. # spec: N-000242
    new_set = set(new_chunks)
    result = []
    for idx, unit in enumerate(out):
        if idx in new_set and result and isinstance(result[-1], _Chunk) \
                and result[-1].clause == clause and result[-1].rule != rule_index \
                and result[-1].label == label:
            result[-1].children.extend(unit.children)
            continue
        result.append(unit)
    return result


def _apply_chink_rule(units, rule, clause):
    out = []
    for unit in units:
        if not (isinstance(unit, _Chunk) and unit.clause == clause):
            out.append(unit)
            continue
        children = unit.children
        blocked = [isinstance(c, _Chunk) for c in children]
        tags = [_tag_of(c) for c in children]
        chinked = [False] * len(children)
        for s, e in _find_matches(rule.elements, tags, blocked):
            for k in range(s, e):
                chinked[k] = True
        piece = []
        for child, gone in zip(children, chinked):
            if gone:
                if piece:
                    out.append(_Chunk(unit.label, piece, clause, unit.rule))
                    piece = []
                out.append(child)  # chinked tokens become direct children of the root
            else:
                piece.append(child)
        if piece:
            out.append(_Chunk(unit.label, piece, clause, unit.rule))
    return out


def _to_tree(unit):
    if isinstance(unit, _Chunk):
        return Tree(unit.label, [_to_tree(c) for c in unit.children])
    return unit


class RegexpParser:
    """Chunk parser driven by a chunk grammar. # spec: N-000446..N-000460, N-000455..N-000460

    ``grammar`` is text, or a list of ``Stage`` objects. Anything else raises TypeError.
    """

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, Stage) for s in grammar):
            if not grammar:
                raise ValueError("empty list of chunk-parser stages")
            self._stages = list(grammar)
        else:
            # spec: N-000449..N-000451 - not text and not a list of stages is refused.
            raise TypeError("grammar must be str or a list of chunk-parser stages")
        labels = {s.label for s in self._stages}
        self.root_label = _SENTENCE_LABEL
        while self.root_label in labels:  # the root label differs from every clause label
            self.root_label = "_" + self.root_label

    def parse(self, tagged):
        """Chunk a list of (token, tag) pairs into a ``Tree`` rooted at the sentence label."""
        if isinstance(tagged, str):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        units = []
        for pair in tagged:
            token, tag = pair
            if not isinstance(token, str) or not isinstance(tag, str):
                raise TypeError("each element must be a (token, tag) pair of str")
            units.append((token, tag))
        for clause_index, stage in enumerate(self._stages):
            for rule_index, rule in enumerate(stage.rules):
                if rule.kind == "chunk":
                    units = _apply_chunk_rule(units, rule, stage.label, clause_index, rule_index)
                else:
                    units = _apply_chink_rule(units, rule, clause_index)
        return Tree(self.root_label, [_to_tree(u) for u in units])


def ne_chunk(tagged_tokens):
    """Named-entity chunker. # spec: N-000452, N-000231, N-000257

    The model and wordlist must be visible (LookupError otherwise). Reading the
    packaged model format is not implemented, so with both present this raises
    NotImplementedError instead of returning chunks.
    """
    _data.require("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", "dir")
    _data.require("corpora/words", "file")
    raise NotImplementedError("named-entity model reading is not implemented")
