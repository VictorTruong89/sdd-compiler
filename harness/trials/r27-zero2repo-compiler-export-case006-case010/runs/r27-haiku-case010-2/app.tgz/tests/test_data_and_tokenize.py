"""Tests for the data finder and tokenizers (FP-01). # spec: N-000081..N-000139"""

import pytest

from lingora import data
from lingora import tokenize as tk


def test_N_000385_data_path_is_mutable_list(resources):
    assert isinstance(data.path, list)
    assert data.locate("tokenizers/punkt_tab/english", "dir") is not None


def test_N_000388_empty_path_hides_every_resource(no_resources):
    assert data.locate("tokenizers/punkt_tab/english", "dir") is None
    with pytest.raises(LookupError):
        data.require("corpora/stopwords/english", "file")


def test_N_000089_word_punct_runs_and_whitespace_never_token():
    assert tk.wordpunct_tokenize("Hello, world!  It's 3.5$.") == [
        "Hello", ",", "world", "!", "It", "'", "s", "3", ".", "5", "$."]


def test_N_000136_empty_and_blank_strings_yield_empty_lists():
    assert tk.wordpunct_tokenize("") == []
    assert tk.wordpunct_tokenize("  \n\t ") == []
    assert tk.WhitespaceTokenizer().tokenize(" \t") == []
    assert tk.TreebankWordTokenizer().tokenize("   ") == []


def test_N_000126_span_tokenize_slices_back_to_tokens():
    text = "a  bb, c"
    tokens = tk.WordPunctTokenizer().tokenize(text)
    spans = list(tk.WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == tokens
    assert all(isinstance(s, int) and isinstance(e, int) for s, e in spans)
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_N_000092_treebank_quotes_clitics_and_fused_forms():
    out = tk.TreebankWordTokenizer().tokenize('He said "hi", and can\'t go gonna.')
    assert out == ["He", "said", "``", "hi", "''", ",", "and", "ca", "n't", "go",
                   "gon", "na", "."]


def test_N_000102_treebank_splits_cannot_recommended_keeps_it():
    assert tk.TreebankWordTokenizer().tokenize("cannot") == ["can", "not"]
    assert tk.word_tokenize("cannot", preserve_line=True) == ["cannot"]


def test_N_000098_ellipsis_and_point_only_at_end():
    assert tk.TreebankWordTokenizer().tokenize("Wait... U.S. policy.") == [
        "Wait", "...", "U.S.", "policy", "."]


def test_N_000116_regexp_token_and_gap_modes():
    assert tk.RegexpTokenizer(r"\d+").tokenize("a12b3") == ["12", "3"]
    assert tk.RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["a", "b"]
    assert tk.RegexpTokenizer(r"\s+", gaps=True, discard_empty=False).tokenize(" a b") == ["", "a", "b"]


def test_N_000114_blankline_segments():
    assert tk.blankline_tokenize("a b\n\n  c\nd\n\n\n e") == ["a b", "c\nd", "e"]


def test_N_000119_tweet_tokenizer_handles_case_emoticons_and_stripping():
    t = tk.TweetTokenizer()
    assert t.tokenize("@bob I LOVE this :) don't") == ["@bob", "I", "LOVE", "this", ":)", "don't"]
    lower = tk.TweetTokenizer(preserve_case=False)
    assert lower.tokenize("LOVE :D") == ["love", ":D"]
    stripped = tk.TweetTokenizer(strip_handles=True)
    assert stripped.tokenize("hi @bob ok") == ["hi", "ok"]
    assert t.tokenize("hi@bob") == ["hi", "@bob"]  # an @ continuing a word is not a handle
    reduced = tk.TweetTokenizer(reduce_len=True)
    assert reduced.tokenize("sooooo") == ["sooo"]


def test_N_000129_sent_tokenize_uses_packaged_punkt(resources):
    sents = tk.sent_tokenize("Mr. Jones went home. It was late! Done.", "english")
    assert sents == ["Mr. Jones went home.", "It was late!", "Done."]
    assert tk.sent_tokenize("   ") == []


def test_N_000137_missing_punkt_makes_sentence_paths_fail(no_resources):
    with pytest.raises(LookupError):
        tk.sent_tokenize("One. Two.")
    with pytest.raises(LookupError):
        tk.word_tokenize("One. Two.")
    assert tk.word_tokenize("One. Two.", preserve_line=True)  # no model needed


def test_N_000111_word_tokenize_splits_sentences_then_tokens(resources):
    assert tk.word_tokenize("Hi there. Bye.") == ["Hi", "there", ".", "Bye", "."]


def test_N_000105_typographic_quotes_are_tokens_and_dashes_split():
    out = tk.word_tokenize("say “ok”—now", preserve_line=True)
    assert out == ["say", "“", "ok", "”", "—", "now"]
