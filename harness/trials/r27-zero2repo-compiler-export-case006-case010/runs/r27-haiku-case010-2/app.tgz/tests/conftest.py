"""Shared fixtures. Packaged resources are synthetic files written to tmp_path."""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


@pytest.fixture
def resources(tmp_path):
    """Point ``data.path`` at a temp directory holding a tiny synthetic model set."""
    saved = list(data.path)
    base = tmp_path / "lingora_data"
    punkt = base / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("mr\ndr\netc\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\nit\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("J.\tSmith\n", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("smith\t4\nthe\t18\nit\t18\n", encoding="utf-8")

    tagger = base / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    weights = {"bias": {"NN": 1.0}, "i word dog": {"NN": 2.0}, "i word runs": {"VBZ": 2.0}}
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(json.dumps(weights), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(json.dumps({"the": "DT"}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(json.dumps(["DT", "NN", "VBZ"]), encoding="utf-8")

    universal = base / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\nVBZ\tVERB\n", encoding="utf-8")

    stop = base / "corpora" / "stopwords"
    stop.mkdir(parents=True)
    (stop / "english").write_text("the\nand\nof\n", encoding="utf-8")

    data.path[:] = [str(base)]
    try:
        yield base
    finally:
        data.path[:] = saved


@pytest.fixture
def no_resources(tmp_path):
    """``data.path`` pointing at an empty directory: no packaged resource is visible."""
    saved = list(data.path)
    data.path[:] = [str(tmp_path / "empty")]
    try:
        yield
    finally:
        data.path[:] = saved
