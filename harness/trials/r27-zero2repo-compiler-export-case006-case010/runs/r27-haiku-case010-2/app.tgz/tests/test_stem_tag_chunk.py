"""Stemmers (FP-02), taggers (FP-03), chunking (FP-04). # spec: N-000140..N-000257"""

import pytest

from lingora import chunk, stem, tag


def test_N_000153_porter_default_lingora_mode_extensions():
    p = stem.PorterStemmer()
    assert p.stem("ties") == "tie"                   # Step 1a LINGORA extension
    assert p.stem("TIES") == "tie"                   # lowercased first by default
    assert p.stem("TIES", to_lowercase=False) == "TIES"  # no lowercasing, no suffix match
    assert p.stem("tied") == "tie"                   # four letters ending -ied
    assert p.stem("carried") == "carri"              # longer -ied becomes -i
    assert p.stem("happy") == "happi"
    assert p.stem("running") == "run"
    assert p.stem("a") == "a" and p.stem("is") == "is"  # 1-2 letters never stemmed
    assert p.stem("dying") == "die"                  # irregular table hit


def test_N_000149_porter_original_mode_has_no_extensions():
    p = stem.PorterStemmer(mode="original")
    assert p.stem("ties") == "ti"
    assert p.stem("happy") == "happi"


def test_N_000162_porter_step1c_requires_consonant_not_first_letter():
    p = stem.PorterStemmer()
    assert p.stem("by") == "by"
    assert p.stem("sky") == "ski"


def test_N_000172_snowball_english_porter2():
    s = stem.SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("fairly") == "fair"
    assert s.stem("running") == "run"
    assert s.stem("cries") == "cri"
    assert s.stem("skies") == "sky"
    assert s.stem("news") == "news"


def test_N_000181_unsupported_snowball_language_names_request():
    with pytest.raises(ValueError, match="klingon"):
        stem.SnowballStemmer("klingon")


def test_N_000183_stopword_skipping_needs_that_language_list(no_resources):
    with pytest.raises(LookupError):
        stem.SnowballStemmer("english", ignore_stopwords=True)


def test_N_000177_stopwords_returned_unchanged(resources):
    s = stem.SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"
    assert s.stem("running") == "run"


def test_N_000170_lancaster_lowercases_and_stems_common_words():
    lan = stem.LancasterStemmer()
    assert lan.stem("Maximum") == "maxim"
    assert lan.stem("running") == "run"


def test_N_000178_regexp_stemmer_only_removes_matches():
    assert stem.RegexpStemmer("ing$").stem("running") == "runn"
    assert stem.RegexpStemmer("ing$").stem("walks") == "walks"


def test_N_000185_wordnet_lemmatizer_requires_resource(no_resources):
    with pytest.raises(LookupError):
        stem.WordNetLemmatizer()


def test_N_000096_stemmers_treat_input_as_one_token():
    assert stem.PorterStemmer().stem("running fast") == "running fast"


def test_N_000090_unigram_most_frequent_then_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("run", "VB")], [("run", "NN")], [("run", "NN")]]
    uni = tag.UnigramTagger(train=train, backoff=tag.DefaultTagger("UNK"))
    assert uni.tag(["the", "run", "zebra"]) == [("the", "DT"), ("run", "NN"), ("zebra", "UNK")]
    bare = tag.UnigramTagger(train=train)
    assert bare.tag(["zebra"]) == [("zebra", None)]


def test_N_000198_default_tagger_tags_everything():
    assert tag.DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert tag.DefaultTagger("NN").tag([]) == []


def test_N_000202_regexp_tagger_first_match_wins():
    rt = tag.RegexpTagger([(r".*ing$", "VBG"), (r".*", "NN")])
    assert rt.tag(["running", "dog"]) == [("running", "VBG"), ("dog", "NN")]


def test_N_000442_pos_tag_refuses_raw_string(resources):
    with pytest.raises(TypeError):
        tag.pos_tag("the dog")


def test_N_000443_pos_tag_rejects_unknown_language_and_missing_model(resources, no_resources):
    with pytest.raises(ValueError):
        tag.pos_tag(["x"], lang="fra")


def test_N_000224_missing_perceptron_resource_fails(no_resources):
    with pytest.raises(LookupError):
        tag.pos_tag(["the"])


def test_N_000207_recommended_tagger_and_universal_mapping(resources):
    assert tag.pos_tag(["the", "dog", "runs"]) == [("the", "DT"), ("dog", "NN"), ("runs", "VBZ")]
    assert tag.pos_tag(["the", "dog", "runs"], tagset="universal") == [
        ("the", "DET"), ("dog", "NOUN"), ("runs", "VERB")]


def test_N_000226_universal_mapping_fails_without_tables(resources):
    import os
    os.remove(os.path.join(str(resources), "taggers", "universal_tagset", "en-ptb.map"))
    with pytest.raises(LookupError):
        tag.pos_tag(["the"], tagset="universal")


def test_N_000228_chunk_rules_and_root_label():
    cp = chunk.RegexpParser("NP: {<DT>?<JJ>*<NN>}")
    out = cp.parse([("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("ran", "VBD")])
    assert out.label() == "S"
    assert out[0] == ("ran", "VBD") or out[0].label() == "NP"
    assert out[0].label() == "NP"
    assert out[0].leaves() == [("the", "DT"), ("big", "JJ"), ("dog", "NN")]
    assert out[1] == ("ran", "VBD")


def test_N_000236_chunk_rule_touching_matches_stay_separate():
    cp = chunk.RegexpParser("NP: {<NN>}")
    out = cp.parse([("a", "NN"), ("b", "NN")])
    assert [c.label() for c in out] == ["NP", "NP"]


def test_N_000243_chink_removes_tokens_and_splits_chunk():
    cp = chunk.RegexpParser("NP: {<.*>+}\n    }<VBD>{")
    out = cp.parse([("the", "DT"), ("dog", "NN"), ("ran", "VBD"), ("home", "NN")])
    assert out[0].label() == "NP" and out[0].leaves() == [("the", "DT"), ("dog", "NN")]
    assert out[1] == ("ran", "VBD")
    assert out[2].label() == "NP" and out[2].leaves() == [("home", "NN")]


def test_N_000246_later_clause_sees_chunks_as_units():
    cp = chunk.RegexpParser("NP: {<DT><NN>}\nVP: {<NP><VBD>}")
    out = cp.parse([("the", "DT"), ("dog", "NN"), ("ran", "VBD")])
    assert len(out) == 1 and out[0].label() == "VP"
    assert out[0][0].label() == "NP"


def test_N_000251_chunking_keeps_every_leaf_in_order():
    cp = chunk.RegexpParser("NP: {<NN>+}")
    tagged = [("a", "DT"), ("b", "NN"), ("c", "NN"), ("d", "VB")]
    assert cp.parse(tagged).leaves() == tagged


def test_N_000252_empty_input_gives_empty_sentence():
    out = chunk.RegexpParser("NP: {<NN>}").parse([])
    assert out.label() == "S" and len(out) == 0


def test_N_000253_chunk_grammar_of_wrong_type_is_refused():
    with pytest.raises(TypeError):
        chunk.RegexpParser(42)


def test_N_000257_ne_chunk_needs_model_and_wordlist(no_resources):
    with pytest.raises(LookupError):
        chunk.ne_chunk([("Paris", "NNP")])
