"""Tree refusals and the command line. # spec: N-000414..N-000420"""

import io
import os
import sys

import pytest

from lingora.cli import cli


def test_N_000414_tokenize_command_writes_one_line_per_input(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there. Bye now.\nSecond line.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) == 0
    out = capsys.readouterr().out.splitlines()
    assert out == ["Hi there . Bye now .", "Second line ."]


def test_N_000417_cli_delimiter_option(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("a b\n"))
    assert cli.main(args=["tokenize", "-d", "|"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "a|b\n"


def test_N_000139_cli_fails_without_punkt_and_writes_nothing(no_resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    assert code != 0
    assert capsys.readouterr().out == ""


def test_N_000417_standalone_mode_exits_with_status(no_resources, monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO("x\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize"])
    assert info.value.code != 0
