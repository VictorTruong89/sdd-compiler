"""Grammars and parsers (FP-05), classifiers (FP-06), metrics (FP-07). # spec: N-000258..N-000348"""

import pytest

from lingora import classify, metrics
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import bleu
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | NP PP
VP -> V NP | VP PP
PP -> P NP
N -> 'dog' | 'cat' | 'man'
V -> 'saw'
P -> 'with'
"""


def test_N_000464_grammar_reader_start_and_alternatives():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions(lhs="NP")) == 2
    rhs = g.productions(lhs="N")[0].rhs()
    assert rhs == ("dog",) and isinstance(rhs[0], str)
    nt = g.productions(lhs="S")[0].rhs()[0]
    assert not isinstance(nt, str) and str(nt) == "NP"


def test_N_000266_chart_parser_finds_every_parse():
    trees = list(ChartParser(CFG.fromstring(GRAMMAR)).parse("the dog saw the cat with the man".split()))
    assert len(trees) == 2
    for t in trees:
        assert t.label() == "S"
        assert t.leaves() == "the dog saw the cat with the man".split()


def test_N_000266_chart_parser_no_parse_is_empty_iterator():
    assert list(ChartParser(CFG.fromstring(GRAMMAR)).parse(["dog", "dog"])) == []


def test_N_000292_token_outside_grammar_raises():
    with pytest.raises(ValueError):
        list(ChartParser(CFG.fromstring(GRAMMAR)).parse(["zebra"]))
    with pytest.raises(ValueError):
        list(ShiftReduceParser(CFG.fromstring(GRAMMAR)).parse(["zebra"]))


def test_N_000272_shift_reduce_matches_chart_on_unambiguous_sentence():
    g = CFG.fromstring(GRAMMAR)
    toks = "the dog saw the cat".split()
    sr = list(ShiftReduceParser(g).parse(toks))
    ch = list(ChartParser(g).parse(toks))
    assert len(sr) == 1 and sr[0] == ch[0]


def test_N_000276_generate_bounded_by_n_and_depth():
    g = CFG.fromstring('S -> "a" S | ""')
    assert list(generate(g, depth=4, n=4)) == [["a", "a", "a"], ["a", "a"], ["a"], []]


def test_N_000281_tree_building_and_refusals():
    t = Tree("S", ["a", Tree("NP", ["b"])])
    assert len(t) == 2 and t[0] == "a" and t.leaves() == ["a", "b"]
    assert Tree("S", []) != Tree("S", ["x"])
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")


def test_N_000286_bracketed_tree_text_round_trip():
    t = Tree.fromstring("(S (NP the dog) (VP barked))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barked"])])
    assert t.pformat().splitlines()[0] == "(S"
    assert t.leaves() == ["the", "dog", "barked"]


def test_N_000289_empty_child_list_is_a_valid_tree():
    t = Tree("S", [])
    assert t.label() == "S" and len(t) == 0


def test_N_000301_naive_bayes_classifies_and_distributes():
    train = [({"w": "a", "p": 1}, "x"), ({"w": "b", "p": 0}, "y"),
             ({"w": "a", "p": 0}, "x"), ({"w": "c", "p": 1}, "y")]
    nb = classify.NaiveBayesClassifier.train(train)
    assert nb.labels() == ["x", "y"]
    assert nb.classify({"w": "a"}) == "x"
    dist = nb.prob_classify({"w": "b"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert nb.classify({"never": 1}) in ("x", "y")  # no shared feature still gets a trained label


def test_N_000310_decision_tree_separates_training_data():
    train = [({"w": "a"}, "x"), ({"w": "b"}, "y"), ({"w": "a"}, "x")]
    dt = classify.DecisionTreeClassifier.train(train)
    assert [dt.classify(f) for f, _ in train] == ["x", "y", "x"]
    assert dt.classify({"zzz": 1}) in ("x", "y")


def test_N_000303_classifier_accuracy_is_fraction_of_gold():
    train = [({"w": "a"}, "x"), ({"w": "b"}, "y")]
    nb = classify.NaiveBayesClassifier.train(train)
    assert classify.accuracy(nb, [({"w": "a"}, "x"), ({"w": "b"}, "x")]) == 0.5


def test_N_000322_edit_distance_levenshtein_and_transposition():
    assert metrics.edit_distance("kitten", "sitting") == 3
    assert metrics.edit_distance("ab", "ba") == 2
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("", "") == 0
    assert metrics.edit_distance("ca", "abc", transpositions=True) == 2


def test_N_000330_accuracy_and_list_length_refusal():
    assert metrics.accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        metrics.accuracy([1, 2], [1])


def test_N_000332_jaccard_precision_recall_and_none_results():
    assert metrics.jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert metrics.precision({1, 2}, {2, 3}) == 0.5
    assert metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.precision({1}, set()) is None
    assert metrics.recall(set(), {1}) is None
    assert metrics.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert metrics.f_measure({1}, {2}) is None


def test_N_000345_precision_refuses_lists():
    with pytest.raises(TypeError):
        metrics.precision([1], {1})


def test_N_000333_f_measure_alpha_weights_harmonic_mean():
    v = metrics.f_measure({1, 2, 3, 4}, {1, 2})
    p, r = 1.0, 0.5
    assert v == pytest.approx(1 / (0.5 / p + 0.5 / r))


def test_N_000335_bleu_identical_and_zero_cases():
    ref = ["the", "cat", "sat", "on", "the", "mat"]
    assert bleu([ref], list(ref)) == pytest.approx(1.0)
    assert bleu([ref], ["the", "cat"]) == 0.0           # short candidate, no 3-gram/4-gram match
    assert bleu([["a", "b", "c", "d"]], ["a", "b", "x", "d"]) == 0.0


def test_N_000340_bleu_compares_tokens_exactly():
    assert bleu([["The", "cat"]], ["the", "cat"]) != pytest.approx(1.0)


def test_N_000266_cyclic_and_epsilon_grammars_terminate():
    g = CFG.fromstring('S -> S | "a" | A\nA -> "" | "a" A')
    assert len(list(ChartParser(g).parse(["a"]))) >= 1
    assert list(ChartParser(g).parse([])) != []
    sr = list(ShiftReduceParser(g).parse(["a"]))
    assert len(sr) <= 1


def test_N_000276_generator_bounded_by_depth_for_left_recursion():
    g = CFG.fromstring('S -> S "b" | "a"')
    assert list(generate(g, depth=3)) == [["a", "b", "b"], ["a", "b"], ["a"]]
