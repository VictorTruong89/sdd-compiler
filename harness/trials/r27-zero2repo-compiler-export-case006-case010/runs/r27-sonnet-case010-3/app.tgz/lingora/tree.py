"""Constituent trees."""


class Tree(list):
    def __init__(self, label, children):  # children is required  # spec: N-000487
        if isinstance(children, str):
            raise TypeError("children should be a list, not a string")  # spec: N-000486
        if not isinstance(children, (list, tuple)):
            try:
                children = list(children)
            except TypeError:
                raise TypeError("children must be a list of children")
        super().__init__(children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        toks = []
        cur = ""
        for ch in s:
            if ch in (open_b, close_b):
                if cur:
                    toks.append(cur)
                    cur = ""
                toks.append(ch)
            elif ch.isspace():
                if cur:
                    toks.append(cur)
                    cur = ""
            else:
                cur += ch
        if cur:
            toks.append(cur)
        pos = 0

        def parse():
            nonlocal pos
            if pos >= len(toks) or toks[pos] != open_b:
                raise ValueError("Tree.fromstring: expected %r" % open_b)
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in (open_b, close_b):
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("Tree.fromstring: missing %r" % close_b)
                t = toks[pos]
                if t == close_b:
                    pos += 1
                    return cls(label, children)
                if t == open_b:
                    children.append(parse())
                else:
                    children.append(t)
                    pos += 1

        if not toks:
            raise ValueError("Tree.fromstring: empty string")
        if toks[0] != open_b:
            # a bare leaf is wrapped like a one-node tree is not valid
            raise ValueError("Tree.fromstring: expected %r" % open_b)
        t = parse()
        if pos != len(toks):
            raise ValueError("Tree.fromstring: extra text after tree")
        return t

    @staticmethod
    def _leaf_str(c):
        if isinstance(c, tuple) and len(c) == 2:
            return "%s/%s" % c
        return str(c)

    def pformat(self, margin=70, indent=0):
        flat = self._flat()
        if len(flat) + indent <= margin or not any(isinstance(c, Tree) for c in self):
            return flat
        parts = ["(%s" % (self._label,)]
        for c in self:
            if isinstance(c, Tree):
                parts.append("\n" + " " * (indent + 2) + c.pformat(margin, indent + 2))
            else:
                parts.append("\n" + " " * (indent + 2) + self._leaf_str(c))
        return "".join(parts) + ")"

    def _flat(self):
        return "(%s%s)" % (
            self._label,
            "".join(" " + (c._flat() if isinstance(c, Tree) else self._leaf_str(c)) for c in self),
        )

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()
