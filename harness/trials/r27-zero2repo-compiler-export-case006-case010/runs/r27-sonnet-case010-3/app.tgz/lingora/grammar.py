"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        return False

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)


def is_nonterminal(x):
    return isinstance(x, Nonterminal)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_empty(self):
        return len(self._rhs) == 0

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(x) if isinstance(x, str) else str(x) for x in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            lines = list(input)
        else:
            lines = input.splitlines()
        # join continuation lines starting with '|'
        logical = []
        for line in lines:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("|") and logical:
                logical[-1] += " " + s
            else:
                logical.append(s)
        productions = []
        start = None
        for line in logical:
            m = re.match(r"^(\S+?)\s*(?:->|=>)\s*(.*)$", line)
            if not m:
                raise ValueError("Unable to parse production: %r" % line)
            lhs = Nonterminal(m.group(1))
            if start is None:
                start = lhs
            rest = m.group(2)
            alts = [[]]
            pos = 0
            rest = rest.rstrip()
            while pos < len(rest):
                tm = _TOKEN_RE.match(rest, pos)
                if not tm or tm.end() == pos:
                    if rest[pos:].strip() == "":
                        break
                    raise ValueError("Unable to parse right-hand side: %r" % rest)
                pos = tm.end()
                if tm.group(1) is not None:
                    alts[-1].append(tm.group(1))
                elif tm.group(2) is not None:
                    alts[-1].append(tm.group(2))
                elif tm.group(3) is not None:
                    alts.append([])
                else:
                    alts[-1].append(Nonterminal(tm.group(4)))
            for alt in alts:
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        return {x for p in self._productions for x in p.rhs() if isinstance(x, str)}

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__
