"""Snowball English (Porter2)."""
_V = "aeiouy"
_SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
            "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
            "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
            "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
_KEEP2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_STEP2 = [("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
          ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
          ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
          ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
          ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"), ("li", "")]
_STEP3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
          ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", "")]
_STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti", "ous",
          "ive", "ize", "ion", "al", "er", "ic"]


def _regions(w):
    n = len(w)
    r1 = n
    for pre in ("gener", "commun", "arsen"):
        if w.startswith(pre):
            r1 = len(pre)
            break
    else:
        for i in range(1, n):
            if w[i] not in _V and w[i - 1] in _V:
                r1 = i + 1
                break
    r2 = n
    for i in range(r1 + 1, n):
        if w[i] not in _V and w[i - 1] in _V:
            r2 = i + 1
            break
    return r1, r2


def _short_syllable_end(w):
    n = len(w)
    if n == 2:
        return w[0] in _V and w[1] not in _V
    if n >= 3:
        return w[-2] in _V and w[-1] not in _V and w[-1] not in "wxY" and w[-3] not in _V
    return False


def stem_english(word):
    w = word.lower()
    if len(w) <= 2:
        return w
    if w in _SPECIAL:
        return _SPECIAL[w]
    if w.startswith("'"):
        w = w[1:]
    if w.startswith("y"):
        w = "Y" + w[1:]
    w = w[:1] + "".join("Y" if (c == "y" and w[i] in _V) else c for i, c in enumerate(w[1:]))
    r1, r2 = _regions(w)
    # step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[:-len(suf)]
            break
    # step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(c in _V for c in w[:-2]):
            w = w[:-1]
    if w in _KEEP2:
        return w.replace("Y", "y")
    # step 1b
    done = False
    for suf in ("eedly", "eed"):
        if w.endswith(suf):
            if len(w) - len(suf) >= r1:
                w = w[:-len(suf)] + "ee"
            done = True
            break
    if not done:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                base = w[:-len(suf)]
                if any(c in _V for c in base):
                    w = base
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w.endswith(_DOUBLES):
                        w = w[:-1]
                    elif _short_syllable_end(w) and r1 >= len(w):
                        w += "e"
                break
    # step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _V:
        w = w[:-1] + "i"
    # step 2
    for suf, rep in _STEP2:
        if w.endswith(suf):
            if len(w) - len(suf) >= r1:
                base = w[:-len(suf)]
                if suf == "ogi":
                    if base.endswith("l"):
                        w = base + rep
                elif suf == "li":
                    if base and base[-1] in "cdeghkmnrt":
                        w = base
                else:
                    w = base + rep
            break
    # step 3
    for suf, rep in _STEP3:
        if w.endswith(suf):
            if len(w) - len(suf) >= r1:
                if suf == "ative":
                    if len(w) - len(suf) >= r2:
                        w = w[:-len(suf)]
                else:
                    w = w[:-len(suf)] + rep
            break
    # step 4
    for suf in _STEP4:
        if w.endswith(suf):
            if len(w) - len(suf) >= r2:
                base = w[:-len(suf)]
                if suf == "ion":
                    if base.endswith(("s", "t")):
                        w = base
                else:
                    w = base
            break
    # step 5
    if w.endswith("e"):
        base = w[:-1]
        if len(base) >= r2 or (len(base) >= r1 and not _short_syllable_end(base)):
            w = base
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w[-2:-1] == "l":
            w = w[:-1]
    return w.replace("Y", "y")
