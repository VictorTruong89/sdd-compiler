"""Snowball stemmers: German, Dutch, Swedish, Norwegian, Danish."""


def _r1r2(w, vowels, min_r1=0):
    n = len(w)
    r1 = n
    for i in range(1, n):
        if w[i] not in vowels and w[i - 1] in vowels:
            r1 = i + 1
            break
    if r1 < min_r1:
        r1 = min(min_r1, n)
    r2 = n
    for i in range(r1 + 1, n):
        if w[i] not in vowels and w[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def _longest(w, sufs):
    best = None
    for s in sufs:
        if w.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


# ----------------------------------------------------------------- German
_DE_V = "aeiouyäöü"


def stem_german(word):
    w = word.lower().replace("ß", "ss")
    chars = list(w)
    for i in range(1, len(chars) - 1):
        if chars[i] in "uy" and chars[i - 1] in _DE_V and chars[i + 1] in _DE_V:
            chars[i] = chars[i].upper()
    w = "".join(chars)
    r1, r2 = _r1r2(w, _DE_V + "UY".lower() if False else _DE_V, 3)
    # uppercase U/Y are non-vowels for region computation
    # step 1
    suf = _longest(w, ["em", "ern", "er", "e", "en", "es", "s"])
    if suf and len(w) - len(suf) >= r1:
        base = w[:-len(suf)]
        if suf in ("em", "ern", "er"):
            w = base
        elif suf in ("e", "en", "es"):
            w = base
            if w.endswith("niss"):
                w = w[:-1]
        elif suf == "s" and base and base[-1] in "bdfghklmnrt":
            w = base
    # step 2
    suf = _longest(w, ["en", "er", "est", "st"])
    if suf and len(w) - len(suf) >= r1:
        base = w[:-len(suf)]
        if suf != "st":
            w = base
        elif base and base[-1] in "bdfghklmnt" and len(base) >= 4 - 0 and len(base) - 1 >= 3:
            w = base
    # step 3
    suf = _longest(w, ["end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"])
    if suf and len(w) - len(suf) >= r2:
        base = w[:-len(suf)]
        if suf in ("end", "ung"):
            w = base
            if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                w = w[:-2]
        elif suf in ("ig", "ik", "isch"):
            if not base.endswith("e"):
                w = base
        elif suf in ("lich", "heit"):
            w = base
            for s2 in ("er", "en"):
                if w.endswith(s2) and len(w) - 2 >= r1:
                    w = w[:-2]
                    break
        elif suf == "keit":
            w = base
            for s2 in ("lich", "ig"):
                if w.endswith(s2) and len(w) - len(s2) >= r2:
                    w = w[:-len(s2)]
                    break
    w = w.replace("U", "u").replace("Y", "y")
    return w.translate(str.maketrans("äöü", "aou"))


# ----------------------------------------------------------------- Swedish
_SV_V = "aeiouyäåö"
_SV1 = ["a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are", "aste", "en",
        "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as", "arnas", "ernas", "ornas",
        "es", "ades", "andes", "ens", "arens", "hetens", "erns", "at", "andet", "het", "ast"]


def stem_swedish(word):
    w = word.lower()
    r1, _ = _r1r2(w, _SV_V, 3)
    suf = _longest(w, _SV1 + ["s"])
    if suf and len(w) - len(suf) >= r1:
        base = w[:-len(suf)]
        if suf != "s":
            w = base
        elif base and base[-1] in "bcdfghjklmnoprtvy":
            w = base
    if len(w) - 2 >= r1 and w.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")):
        w = w[:-1]
    suf = _longest(w, ["lig", "ig", "els", "lös", "fullt"])
    if suf and len(w) - len(suf) >= r1:
        if suf in ("lig", "ig", "els"):
            w = w[:-len(suf)]
        elif suf == "lös":
            w = w[:-1]
        elif suf == "fullt":
            w = w[:-1]
    return w


# ----------------------------------------------------------------- Norwegian
_NO_V = "aeiouyæåø"
_NO1 = ["a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er", "heter",
        "as", "ena", "enes", "erte", "ert", "ets", "et", "s"]


def stem_norwegian(word):
    w = word.lower()
    r1, _ = _r1r2(w, _NO_V, 3)
    suf = _longest(w, _NO1)
    if suf and len(w) - len(suf) >= r1:
        base = w[:-len(suf)]
        if suf in ("erte", "ert"):
            w = base + "er"
        elif suf == "s":
            if base and (base[-1] in "bcdfghjlmnoprtvyz" or (base[-1] == "k" and len(base) > 1 and base[-2] not in _NO_V)):
                w = base
        elif suf in ("ets", "et"):
            w = base
        else:
            w = base
    if len(w) - 1 >= r1 and w.endswith(("dt", "vt")):
        w = w[:-1]
    suf = _longest(w, ["leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov", "elov", "slov", "hetslov"])
    if suf and len(w) - len(suf) >= r1:
        w = w[:-len(suf)]
    return w


# ----------------------------------------------------------------- Danish
_DA_V = "aeiouyæåø"
_DA1 = ["hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en", "heden",
        "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes", "ernes", "eres", "ens",
        "hedens", "erens", "ers", "ets", "erets", "et", "eret", "s"]


def stem_danish(word):
    w = word.lower()
    r1, _ = _r1r2(w, _DA_V, 3)
    suf = _longest(w, _DA1)
    if suf and len(w) - len(suf) >= r1:
        base = w[:-len(suf)]
        if suf == "s":
            if base and base[-1] in "abcdfghjklmnoprtvyzå":
                w = base
        else:
            w = base
    if len(w) - 1 >= r1 and w.endswith(("gd", "dt", "gt", "kt")):
        w = w[:-1]
    if w.endswith("igst") and len(w) - 2 >= r1:
        w = w[:-2]
    suf = _longest(w, ["ig", "lig", "elig", "els"])
    if suf and len(w) - len(suf) >= r1:
        w = w[:-len(suf)]
        if len(w) - 1 >= r1 and len(w) >= 2 and w[-1] == w[-2] and w[-1] not in _DA_V:
            w = w[:-1]
    elif w.endswith("løst") and len(w) - 1 >= r1:
        w = w[:-1]
    if len(w) > r1 and len(w) >= 2 and w[-1] == w[-2] and w[-1] not in _DA_V:
        w = w[:-1]
    return w


# ----------------------------------------------------------------- Dutch
_NL_V = "aeiouyè"


def _undouble(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


def stem_dutch(word):
    w = word.lower()
    w = w.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
    chars = list(w)
    for i, c in enumerate(chars):
        if c == "y" and (i == 0 or chars[i - 1] in _NL_V):
            chars[i] = "Y"
    for i in range(1, len(chars) - 1):
        if chars[i] == "i" and chars[i - 1] in _NL_V and chars[i + 1] in _NL_V:
            chars[i] = "I"
    w = "".join(chars)
    r1, r2 = _r1r2(w, _NL_V, 3)

    def en_ending(base):
        return bool(base) and base[-1] not in _NL_V and not base.endswith("gem")

    # step 1
    if w.endswith("heden") and len(w) - 5 >= r1:
        w = w[:-5] + "heid"
    else:
        suf = _longest(w, ["en", "ene", "s", "se"])
        if suf and len(w) - len(suf) >= r1:
            base = w[:-len(suf)]
            if suf in ("en", "ene") and en_ending(base):
                w = _undouble(base)
            elif suf in ("s", "se") and base and base[-1] not in _NL_V and base[-1] != "j":
                w = base
    # step 2
    e_removed = False
    if w.endswith("e") and len(w) - 1 >= r1 and len(w) >= 2 and w[-2] not in _NL_V:
        w = _undouble(w[:-1])
        e_removed = True
    # step 3a
    if w.endswith("heid") and len(w) - 4 >= r2 and not w[:-4].endswith("c"):
        w = w[:-4]
        if w.endswith("en") and len(w) - 2 >= r1 and en_ending(w[:-2]):
            w = _undouble(w[:-2])
    # step 3b
    suf = _longest(w, ["end", "ing", "ig", "lijk", "baar", "bar"])
    if suf and len(w) - len(suf) >= r2 or (suf == "bar" and e_removed and len(w) - 3 >= r2):
        base = w[:-len(suf)]
        if suf in ("end", "ing"):
            w = base
            if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                w = w[:-2]
            else:
                w = _undouble(w)
        elif suf == "ig":
            if not base.endswith("e"):
                w = base
        elif suf == "lijk":
            w = base
            if w.endswith("e") and len(w) - 1 >= r1 and len(w) >= 2 and w[-2] not in _NL_V:
                w = _undouble(w[:-1])
        elif suf == "baar":
            w = base
        elif suf == "bar" and e_removed:
            w = base
    # step 4
    if len(w) >= 4 and w[-1] not in _NL_V and w[-1] != "I" and w[-4] not in _NL_V and \
            w[-3:-1] in ("aa", "ee", "oo", "uu") and w[-4] != "I" and w[-3] not in _NL_V:
        w = w[:-2] + w[-1]
    return w.replace("I", "i").replace("Y", "y")
