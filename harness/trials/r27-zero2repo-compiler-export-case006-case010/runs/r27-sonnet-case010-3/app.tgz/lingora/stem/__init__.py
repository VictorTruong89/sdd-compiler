"""Stemmers and lemmatizer."""
import re

from .. import data as _data
from .lancaster import LancasterStemmer
from .porter import PorterStemmer
from . import snowball_en, snowball_misc

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
           "SnowballStemmer", "WordNetLemmatizer"]


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if isinstance(regexp, str):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


class SnowballStemmer:
    languages = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                 "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
                 "swedish")

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            # raises LookupError when the stopword list is not visible
            lines = _data.read_lines("corpora/stopwords/%s" % language)
            self.stopwords = {ln.strip().lower() for ln in lines if ln.strip()}
        self.ignore_stopwords = ignore_stopwords
        if language == "porter":
            self._porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
        self._fn = {
            "english": snowball_en.stem_english,
            "german": snowball_misc.stem_german,
            "dutch": snowball_misc.stem_dutch,
            "swedish": snowball_misc.stem_swedish,
            "norwegian": snowball_misc.stem_norwegian,
            "danish": snowball_misc.stem_danish,
        }.get(language)

    def stem(self, word):
        w = word.lower()
        if self.ignore_stopwords and w in self.stopwords:
            return w
        if self.language == "porter":
            return self._porter.stem(w, to_lowercase=True)
        if self._fn is None:
            return w  # language without a bundled algorithm: returned lowercased
        return self._fn(w)


class ARLSTem:
    """Light Arabic stemmer (results are outside the specification)."""
    _diac = re.compile("[ً-ْـ]")
    _pre = ("وال", "بال", "كال", "فال", "ال", "لل")
    _suf = ("ات", "ون", "ين", "ان", "ها", "ية", "ه", "ة", "ي")

    def stem(self, word):
        w = self._diac.sub("", word)
        w = re.sub("[إأآ]", "ا", w)
        for p in self._pre:
            if w.startswith(p) and len(w) - len(p) >= 2:
                w = w[len(p):]
                break
        for s in self._suf:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


class WordNetLemmatizer:
    _EXC = {"n": "noun.exc", "v": "verb.exc", "a": "adj.exc", "r": "adv.exc"}
    _IDX = {"n": "index.noun", "v": "index.verb", "a": "index.adj", "r": "index.adv"}
    _RULES = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
              ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
              ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }

    def __init__(self):
        self._root = _data.find("corpora/wordnet")  # raises LookupError when absent
        self._cache = {}

    def _load(self, pos):
        if pos in self._cache:
            return self._cache[pos]
        import os
        idx = set()
        exc = {}
        p = os.path.join(self._root, self._IDX[pos])
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                for line in f:
                    if not line.startswith(" "):
                        idx.add(line.split(" ", 1)[0])
        p = os.path.join(self._root, self._EXC[pos])
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], []).append(parts[1])
        self._cache[pos] = (idx, exc)
        return idx, exc

    def lemmatize(self, word, pos="n"):
        if pos not in self._EXC:
            pos = "n"
        idx, exc = self._load(pos)
        forms = [word]
        if word in exc:
            forms = exc[word]
        else:
            for old, new in self._RULES[pos]:
                if word.endswith(old):
                    forms.append(word[:len(word) - len(old)] + new)
        found = [f for f in forms if f in idx]
        return min(found, key=len) if found else word
