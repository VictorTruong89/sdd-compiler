"""Parsers over context-free grammars."""
from ..grammar import Nonterminal
from ..tree import Tree


def _check(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str")
    tokens = list(tokens)
    known = grammar.terminals()
    for t in tokens:
        if t not in known:
            raise ValueError("Grammar does not cover some of the input words: %r" % (t,))
    return tokens


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = _check(self._grammar, tokens)
        g = self._grammar
        memo = {}
        active = set()
        n = len(tokens)
        by_lhs = {}
        for p in g.productions():
            by_lhs.setdefault(p.lhs(), []).append(p)

        def parses(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            out = []
            for prod in by_lhs.get(sym, []):
                for kids in seq(prod.rhs(), 0, i, j):
                    out.append(tree_class(str(sym), kids))
            active.discard(key)
            memo[key] = out
            return out

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            item = rhs[k]
            if isinstance(item, str):
                if item == "":
                    yield from seq(rhs, k + 1, i, j)
                elif i < j and tokens[i] == item:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [item] + rest
                return
            for m in range(i, j + 1):
                subs = parses(item, i, m)
                if not subs:
                    continue
                for rest in seq(rhs, k + 1, m, j):
                    for s in subs:
                        yield [s] + rest

        result = parses(g.start(), 0, n)
        return iter(list(result))


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = _check(self._grammar, tokens)
        prods = self._grammar.productions()
        stack = []
        remaining = list(tokens)

        def matches(item, sym):
            if isinstance(sym, str):
                return isinstance(item, str) and item == sym
            return isinstance(item, Tree) and item.label() == str(sym)

        def reduce_once():
            for p in prods:
                rhs = p.rhs()
                k = len(rhs)
                if k == 0 or len(stack) < k:
                    continue
                if all(matches(stack[len(stack) - k + x], rhs[x]) for x in range(k)):
                    kids = stack[len(stack) - k:]
                    del stack[len(stack) - k:]
                    stack.append(Tree(str(p.lhs()), kids))
                    return True
            return False

        while True:
            while reduce_once():
                pass
            if not remaining:
                break
            stack.append(remaining.pop(0))
        start = str(self._grammar.start())
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


class RecursiveDescentParser(ChartParser):
    pass
