"""Generate sentences from a grammar."""
import itertools
import sys

from ..grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _all(grammar, [start], depth)
    if n is not None:
        it = itertools.islice(it, n)
    return it


def _all(grammar, items, depth):
    if items:
        try:
            for f1 in _one(grammar, items[0], depth):
                for f2 in _all(grammar, items[1:], depth):
                    yield f1 + f2
        except RecursionError as e:
            raise RuntimeError("The grammar has rule(s) that yield infinite recursion.") from e
    else:
        yield []


def _one(grammar, lhs, depth):
    if depth > 0:
        if isinstance(lhs, Nonterminal):
            for prod in grammar.productions(lhs):
                yield from _all(grammar, prod.rhs(), depth - 1)
        elif lhs == "":
            yield []  # empty-string terminal adds no token  # spec: N-000480
        else:
            yield [lhs]
