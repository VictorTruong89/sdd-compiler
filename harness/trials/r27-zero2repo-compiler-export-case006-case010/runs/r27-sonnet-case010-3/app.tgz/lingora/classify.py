"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict


class ProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda k: self._probs[k])


class NaiveBayesClassifier:
    def __init__(self, label_prior, feature_probdist, labels):
        self._label_prior = label_prior  # label -> prob
        self._fp = feature_probdist  # (label, fname) -> (counts, N, bins)
        self._labels = list(labels)

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        feat_freq = defaultdict(Counter)
        values = defaultdict(set)
        fnames = set()
        for fs, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in fs.items():
                feat_freq[(label, fname)][fval] += 1
                values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            for fname in fnames:
                cnt = sum(feat_freq[(label, fname)].values())
                missing = label_freq[label] - cnt
                if missing > 0:
                    feat_freq[(label, fname)][None] += missing
                    values[fname].add(None)
        total = sum(label_freq.values())
        nl = len(label_freq)
        prior = {l: (c + 0.5) / (total + 0.5 * nl) for l, c in label_freq.items()}
        fp = {}
        for key, counter in feat_freq.items():
            fp[key] = (counter, sum(counter.values()), len(values[key[1]]))
        return cls(prior, fp, list(label_freq.keys()))

    def labels(self):
        return list(self._labels)

    def _logprob(self, key, fval):
        counter, n, bins = self._fp[key]
        return math.log((counter.get(fval, 0) + 0.5) / (n + 0.5 * bins))

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._fp for l in self._labels)}
        logp = {}
        for label in self._labels:
            logp[label] = math.log(self._label_prior[label])
        for label in self._labels:
            for fname, fval in fs.items():
                logp[label] += self._logprob((label, fname), fval)
        m = max(logp.values())
        exps = {l: math.exp(v - m) for l, v in logp.items()}
        z = sum(exps.values())
        return ProbDist({l: e / z for l, e in exps.items()})

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum((v / n) * math.log2(v / n) for v in c.values()) if n else 0.0


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled):
        if not labeled:
            return 0.0
        wrong = sum(1 for fs, l in labeled if self.classify(fs) != l)
        return wrong / len(labeled)

    @staticmethod
    def stump(fname, labeled):
        label_freqs = Counter(l for _, l in labeled)
        freqs = defaultdict(Counter)
        for fs, l in labeled:
            freqs[fs.get(fname)][l] += 1
        decisions = {v: DecisionTreeClassifier(c.most_common(1)[0][0]) for v, c in freqs.items()}
        default = label_freqs.most_common(1)[0][0]
        return DecisionTreeClassifier(default, fname, decisions)

    @staticmethod
    def best_stump(fnames, labeled):
        label_freqs = Counter(l for _, l in labeled)
        best = DecisionTreeClassifier(label_freqs.most_common(1)[0][0])
        best_err = best.error(labeled)
        for fname in fnames:
            s = DecisionTreeClassifier.stump(fname, labeled)
            e = s.error(labeled)
            if e < best_err:
                best, best_err = s, e
        return best

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled = list(labeled_featuresets)
        if not labeled:
            raise ValueError("cannot train on an empty training set")
        fnames = []
        seen = set()
        for fs, _ in labeled:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    fnames.append(f)
        tree = cls.best_stump(fnames, labeled)
        tree._refine(labeled, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree

    def _refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if sub and _entropy(l for _, l in sub) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is None and False:
            pass


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        raise ValueError("gold is empty")
    ok = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return ok / len(gold)
