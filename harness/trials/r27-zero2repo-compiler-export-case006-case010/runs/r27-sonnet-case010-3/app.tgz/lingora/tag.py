"""Taggers."""
import json
import re
from collections import Counter, defaultdict

from . import data as _data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger", "TrigramTagger",
           "AffixTagger", "pos_tag", "PerceptronTagger"]


class SequentialTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag_one") and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a str")
        tagged = []
        for i, tok in enumerate(tokens):
            tagged.append((tok, self.tag_one(tokens, i, [t for _, t in tagged])))
        return tagged

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            if hasattr(self._backoff, "tag_one"):
                tag = self._backoff.tag_one(tokens, index, history)
            else:
                tag = self._backoff.tag(tokens[: index + 1])[-1][1]
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialTagger):
    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class _ContextTagger(SequentialTagger):
    def __init__(self, train=None, backoff=None, cutoff=0):
        super().__init__(backoff)
        self._model = {}
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def _train(self, sents):
        counts = defaultdict(Counter)
        for sent in sents:
            toks = [w for w, _ in sent]
            hist = []
            for i, (w, t) in enumerate(sent):
                ctx = self.context(toks, i, hist)
                if ctx is not None:
                    counts[ctx][t] += 1
                hist.append(t)
        for ctx, c in counts.items():
            self._model[ctx] = c.most_common(1)[0][0]

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._model.get(ctx)


class UnigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        if index == 0:
            return (None, tokens[index])
        return (history[index - 1] if index - 1 < len(history) else None, tokens[index])


class TrigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        h = history
        return (h[index - 2] if index >= 2 and index - 2 < len(h) else None,
                h[index - 1] if index >= 1 and index - 1 < len(h) else None, tokens[index])


class AffixTagger(_ContextTagger):
    def __init__(self, train=None, backoff=None, affix_length=-3, min_stem_length=2):
        self._n = affix_length
        self._min = min_stem_length
        super().__init__(train, backoff)

    def context(self, tokens, index, history):
        t = tokens[index]
        if len(t) < self._min + abs(self._n):
            return None
        return t[self._n:] if self._n < 0 else t[: self._n]


# ----------------------------------------------------------- perceptron
class PerceptronTagger:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, lang="eng"):
        base = "taggers/averaged_perceptron_tagger_%s/averaged_perceptron_tagger_%s" % (lang, lang)
        self.weights = json.loads(_data.read_text(base + ".weights.json"))
        self.tagdict = json.loads(_data.read_text(base + ".tagdict.json"))
        self.classes = json.loads(_data.read_text(base + ".classes.json"))

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(self.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = self.START
        out = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "NUM": "NUM", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "INTJ": "X", "COM": "X", "NONLEX": ".", "S-PRO": "PRON", "A-PRO": "DET",
    "ADV-PRO": "ADV", "A-NUM": "ADJ", "SPRO": "PRON", "APRO": "DET", "ANUM": "ADJ", "ADVPRO": "ADV",
}
_cache = {}


def _tagger(lang):
    key = (lang, tuple(map(str, _data.path)))
    if key not in _cache:
        _cache[key] = PerceptronTagger(lang)
    return _cache[key]


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in ("eng", "rus"):
        raise ValueError("Currently, only 'eng' and 'rus' are supported")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagged = _tagger(lang).tag(list(tokens))
    if tagset == "universal":
        if lang == "rus":
            return [(w, _RUS_UNIVERSAL.get(t.split("=")[0], "X") if t is not None else None)
                    for w, t in tagged]
        table = {}
        for line in _data.read_lines("taggers/universal_tagset/en-ptb.map"):
            parts = line.split("\t")
            if len(parts) >= 2:
                table[parts[0]] = parts[1]
        return [(w, table.get(t, "X") if t is not None else None) for w, t in tagged]
    return tagged
