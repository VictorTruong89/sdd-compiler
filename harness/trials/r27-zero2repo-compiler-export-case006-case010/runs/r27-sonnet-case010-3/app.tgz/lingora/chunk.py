"""Chunking."""
import re

from . import data as _data
from .tree import Tree

__all__ = ["RegexpParser", "RegexpChunkParser", "ne_chunk"]


def _tag_pattern_to_regex(pat):
    pat = re.sub(r"\s", "", pat)
    if not re.fullmatch(r"(?:<[^<>]*>(?:[?*+]|\{\d*,?\d*\})?)+", pat):
        raise ValueError("Bad tag pattern: %r" % pat)
    pat = pat.replace("<", "(?:<(?:").replace(">", ")>)")
    pat = re.sub(r"(?<!\\)\.", r"[^{}<>]", pat)
    return pat


class RegexpChunkParser:
    """One clause: ordered chunk/chink rules for one label."""

    def __init__(self, rules, chunk_label="NP", root_label="S"):
        self._rules = rules  # list of (kind, regex)
        self._label = chunk_label
        self._root = root_label

    def parse(self, tagged):
        children = list(tagged)
        for c in children:
            if not isinstance(c, Tree) and not (isinstance(c, (tuple, list)) and len(c) == 2):
                raise ValueError("chunk parser input must be (token, tag) pairs")
        tags = [c.label() if isinstance(c, Tree) else c[1] for c in children]
        s = "".join("<%s>" % t for t in tags)
        for kind, rx in self._rules:
            if kind == "chunk":
                s = re.sub(r"(?P<chunk>%s)(?=[^\}]*(\{|$))" % rx, r"{\g<chunk>}", s)
            else:
                s = re.sub(r"(?P<chink>%s)(?=[^\{]*\})" % rx, r"}\g<chink>{", s)
            s = s.replace("{}", "")
        out = []
        cur = None
        idx = 0
        for m in re.finditer(r"[{}]|<[^<>{}]*>", s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                out.append(Tree(self._label, cur))
                cur = None
            else:
                child = children[idx]
                idx += 1
                (cur if cur is not None else out).append(child)
        return Tree(self._root, out)


def _parse_grammar(grammar, root_label):
    stages = []
    label = None
    rules = []

    def flush():
        if label is not None:
            stages.append(RegexpChunkParser(rules, label, root_label))

    for raw in grammar.split("\n"):
        line = re.sub(r"(?<!\\)#.*$", "", raw)
        if not line.strip():
            continue
        if line[0] not in " \t":
            m = re.match(r"^(\w+)\s*:\s*(.*)$", line)
            if not m:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            flush()
            label, rules = m.group(1), []
            body = m.group(2).strip()
        else:
            if label is None:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            body = line.strip()
        if not body:
            continue
        if body.startswith("{") and body.endswith("}"):
            rules.append(("chunk", _tag_pattern_to_regex(body[1:-1])))
        elif body.startswith("}") and body.endswith("{"):
            rules.append(("chink", _tag_pattern_to_regex(body[1:-1])))
        else:
            raise ValueError("Illegal chunk rule: %r" % body)
    flush()
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label="S", loop=1):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar, root_label)
        elif isinstance(grammar, (list, tuple)) and all(hasattr(g, "parse") for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of chunk parser stages")
        self._root = root_label
        self._loop = loop

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        chunk = Tree(self._root, list(tagged))
        for _ in range(self._loop):
            for stage in self._stages:
                chunk = stage.parse(list(chunk))
        return chunk


def ne_chunk(tagged_tokens, binary=False):
    _data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    _data.find("corpora/words")
    # Entity recognition results are outside the specification: no entities are marked.
    return Tree("S", list(tagged_tokens))
