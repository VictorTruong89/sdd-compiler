"""Command line."""
import sys


class _Group:
    def __init__(self):
        self.commands = {}

    def command(self, name):
        def deco(fn):
            self.commands[name] = fn
            return fn
        return deco

    def main(self, args=None, prog_name="lingora", standalone_mode=True, **kwargs):
        argv = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(argv)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        except BaseException as e:  # failure: report on stderr, non-zero status
            try:
                sys.stderr.write("Error: %s\n" % (e,))
            except Exception:
                pass
            code = 1
        if standalone_mode:
            sys.exit(code)
        if code:
            raise RuntimeError("command failed with status %s" % code)
        return None

    __call__ = main

    def _run(self, argv):
        if not argv or argv[0] in ("-h", "--help"):
            sys.stdout.write("Usage: lingora [OPTIONS] COMMAND\n\nCommands:\n  tokenize\n")
            return 0 if argv else 2
        cmd = self.commands.get(argv[0])
        if cmd is None:
            sys.stderr.write("Error: No such command %r.\n" % argv[0])
            return 2
        return cmd(argv[1:])


cli = _Group()


@cli.command("tokenize")
def _tokenize(argv):
    language, delimiter, encoding = "english", " ", "utf8"
    i = 0
    while i < len(argv):
        a = argv[i]
        key, val = (a.split("=", 1) + [None])[:2] if a.startswith("--") else (a, None)
        if key in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if val is None:
                i += 1
                if i >= len(argv):
                    sys.stderr.write("Error: option %s requires an argument\n" % key)
                    return 2
                val = argv[i]
            if key in ("-l", "--language"):
                language = val
            elif key in ("-d", "--delimiter"):
                delimiter = val
            else:
                encoding = val
        else:
            sys.stderr.write("Error: no such option: %s\n" % a)
            return 2
        i += 1
    from .tokenize import word_tokenize, _get_punkt
    stdin = sys.stdin
    raw = stdin.buffer.read() if hasattr(stdin, "buffer") else stdin.read()
    text = raw.decode(encoding) if isinstance(raw, bytes) else raw
    _get_punkt(language)  # fails when the Punkt model is missing, before any output
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = []
    for line in lines:
        if line.endswith("\r"):
            line = line[:-1]
        out.append(delimiter.join(word_tokenize(line, language)) + "\n")
    sys.stdout.write("".join(out))
    sys.stdout.flush()
    return 0
