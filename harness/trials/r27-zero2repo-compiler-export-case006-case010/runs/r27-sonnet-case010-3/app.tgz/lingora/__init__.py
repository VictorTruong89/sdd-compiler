"""Lingora Language Toolkit: a pure-Python NLP library. Importing downloads nothing."""
from . import data  # noqa: F401

__version__ = "0.1.0"
