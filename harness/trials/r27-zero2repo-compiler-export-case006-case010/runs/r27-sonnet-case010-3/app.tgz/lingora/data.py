"""Packaged-resource locator.  # spec: N-000385 N-000386 N-000387 N-000388"""
import os

# Mutable list of directories searched for resources (callers may replace its contents in place).
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path += [
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
]


def find(resource):
    """Return the full path of `resource` found in a directory on `path`, else raise LookupError."""
    for d in list(path):
        p = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("resource %r not found on lingora.data.path" % (resource,))


def read_text(resource_file):
    with open(find(resource_file), encoding="utf-8", newline="") as f:
        return f.read()


def read_lines(resource_file):
    """Lines without their terminators (blank lines kept)."""
    text = read_text(resource_file)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [ln[:-1] if ln.endswith("\r") else ln for ln in lines]
