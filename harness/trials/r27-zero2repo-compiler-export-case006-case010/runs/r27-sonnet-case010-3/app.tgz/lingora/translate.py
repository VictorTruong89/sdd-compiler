"""BLEU."""
import math
import sys
from collections import Counter


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    num = sum(min(c, max_counts.get(g, 0)) for g, c in counts.items())
    den = max(1, sum(counts.values()))
    return num, den


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon

    def method0(self, p_n, *a, **k):
        return [(n / d) if n != 0 else sys.float_info.min for n, d in p_n]

    def method1(self, p_n, *a, **k):
        return [((n + self.epsilon) / d) if n == 0 else n / d for n, d in p_n]

    def method2(self, p_n, *a, **k):
        return [(n + 1) / (d + 1) if i > 0 else n / d for i, (n, d) in enumerate(p_n)]


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("hypothesis and references must be token lists")
    weights = tuple(weights)
    nums, dens = [], []
    for i in range(1, len(weights) + 1):
        n, d = _modified_precision(references, hypothesis, i)
        nums.append(n)
        dens.append(d)
    hyp_len = len(hypothesis)
    ref_lens = [len(r) for r in references]
    ref_len = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl)) if ref_lens else 0
    if hyp_len > ref_len:
        bp = 1.0
    elif hyp_len == 0:
        bp = 0.0
    else:
        bp = math.exp(1 - ref_len / hyp_len)
    if not nums or nums[0] == 0:
        return 0
    pairs = list(zip(nums, dens))
    if smoothing_function is None:
        p_n = [(n / d) if n != 0 else sys.float_info.min for n, d in pairs]
    else:
        try:
            from fractions import Fraction
            frs = [Fraction(n, d, _normalize=False) for n, d in pairs]
        except TypeError:
            from fractions import Fraction
            frs = [Fraction(n, d) for n, d in pairs]
        try:
            p_n = smoothing_function(frs, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
        except TypeError:
            p_n = smoothing_function(frs)
        p_n = [float(p) for p in p_n]
    s = math.fsum(w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(s)
