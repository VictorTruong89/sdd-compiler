"""Tokenizers."""
import html
import re

from . import data as _data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "blankline_tokenize", "sent_tokenize", "word_tokenize",
           "wordpunct_tokenize", "PunktSentenceTokenizer"]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=False, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        if self._gaps:
            toks = self._regexp.split(text)
            if self._discard_empty:
                toks = [t for t in toks if t]
            return toks
        return self._regexp.findall(text) if self._regexp.groups == 0 else [m.group(0) for m in self._regexp.finditer(text)]

    def span_tokenize(self, text):
        if self._gaps:
            for left, right in self._gap_spans(text):
                if not self._discard_empty or right > left:
                    yield left, right
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def _gap_spans(self, text):
        last = 0
        for m in self._regexp.finditer(text):
            yield last, m.start()
            last = m.end()
        yield last, len(text)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s+", gaps=True, discard_empty=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s*\n\s*\n\s*", gaps=True, discard_empty=True)


_wp = WordPunctTokenizer()
_bl = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wp.tokenize(text)


def blankline_tokenize(text):
    return _bl.tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedWordTokenizer(TreebankWordTokenizer):
    """The recommended word tokenizer: Treebank conventions plus improvements."""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        # a straight double quote at the very start is NOT given the opening form (spec N-000106)
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]


_improved = _ImprovedWordTokenizer()


# ---------------------------------------------------------------- Punkt
_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_TOK_RE = re.compile(
    r"""(
    %(M)s
    |
    (?=%(WS)s)\S+?
    (?=
        \s|
        $|
        %(NW)s|%(M)s|
        ,(?=$|\s|%(NW)s|%(M)s)
    )
    |
    \S
    )""" % {"M": _MULTI, "WS": _WORDSTART, "NW": _NONWORD}, re.UNICODE | re.VERBOSE)
_PERIOD_CTX_RE = re.compile(
    r"""\S*[.?!](?=(?P<after_tok>%(NW)s|\s+(?P<next_tok>\S+)))""" % {"NW": _NONWORD},
    re.UNICODE | re.VERBOSE)
_BOUNDARY_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"\.\.+$")
_INITIAL = re.compile(r"[^\W\d]\.$")
_ALPHA = re.compile(r"[^\W\d]+$")


class _Tok:
    __slots__ = ("tok", "type", "period_final", "first_upper", "first_lower", "parastart", "linestart",
                 "sentbreak", "abbr", "ellipsis", "is_initial", "is_ellipsis")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = self.abbr = self.ellipsis = False
        self.is_initial = bool(_INITIAL.match(tok))
        self.is_ellipsis = bool(_ELLIPSIS.match(tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def _load_punkt(language):
    base = "tokenizers/punkt_tab/%s/" % language
    p = PunktParameters()
    for line in _data.read_lines(base + "abbrev_types.txt"):
        if line:
            p.abbrev_types.add(line)
    for line in _data.read_lines(base + "sent_starters.txt"):
        if line:
            p.sent_starters.add(line)
    for line in _data.read_lines(base + "collocations.tab"):
        if line:
            parts = line.split("\t")
            if len(parts) >= 2:
                p.collocations.add((parts[0], parts[1]))
    for line in _data.read_lines(base + "ortho_context.tab"):
        if line:
            parts = line.split("\t")
            if len(parts) >= 2:
                p.ortho_context[parts[0]] = int(parts[1])
    return p


class PunktSentenceTokenizer:
    def __init__(self, params=None, language="english"):
        self._params = params if params is not None else _load_punkt(language)

    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = iter(_WORD_TOK_RE.findall(line))
                try:
                    tok = next(toks)
                except StopIteration:
                    continue
                yield _Tok(tok, parastart=parastart, linestart=True)
                parastart = False
                for tok in toks:
                    yield _Tok(tok)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in (".", "?", "!"):
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            ab = self._params.abbrev_types
            if t[:-1].lower() in ab or t[:-1].lower().split("-")[-1] in ab:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        is_initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not is_initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if is_initial or typ == "##number##":
            ss = self._ortho(t2)
            if ss is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (ss == "unknown" and is_initial and t2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _contains_sentbreak(self, text):
        toks = list(self._tokenize_words(text))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws(s):
        for i in range(len(s) - 1, -1, -1):
            if s[i].isspace():
                return i
        return None

    def _potential_ends(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_CTX_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = self._last_ws(before)
            if idx:
                pw = (prev_slice[1] + idx + 1, m.start())
            else:
                pw = prev_slice
            if prev_match and prev_slice[1] <= pw[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = pw
        if prev_match:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for m, ctx in self._potential_ends(text):
            if self._contains_sentbreak(ctx):
                yield (last, m.end())
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _BOUNDARY_REALIGN.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text, realign_boundaries=True):
        slices = self._slices(text)
        if realign_boundaries:
            slices = self._realign(text, slices)
        return list(slices)

    def tokenize(self, text, realign_boundaries=True):
        return [text[a:b] for a, b in self.span_tokenize(text, realign_boundaries)]


_punkt_cache = {}


def _get_punkt(language):
    key = (language, tuple(map(str, _data.path)))
    if key not in _punkt_cache:
        _punkt_cache[key] = PunktSentenceTokenizer(language=language)
    return _punkt_cache[key]


def sent_tokenize(text, language="english"):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return _get_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _improved.tokenize(sent)]


# ---------------------------------------------------------------- Tweets
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""
_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_WORD_RE = re.compile(
    "(%s)" % "|".join((
        _URLS, _PHONE, _EMOTICONS, r"<[^>\s]+>", r"[\-]+>|<[\-]+", r"(?:@[\w_]+)",
        r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
        r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
    """)), re.VERBOSE | re.IGNORECASE | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.IGNORECASE | re.UNICODE)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_LENGTH_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTH_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = _WORD_RE.findall(safe)
        words = [w[0] if isinstance(w, tuple) else w for w in words]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
