"""Behavioural tests for Optlyn, grouped by feature point."""

import enum
import os
import pathlib
import uuid

import pytest

import optlyn
from optlyn import (
    Abort, BadParameter, Choice, Command, CommandCollection, Context, DateTime, File,
    FloatRange, Group, IntRange, Path, Tuple, UUID, ParameterSource, argument, command,
    confirmation_option, custom_version_option, echo, get_current_context, group,
    help_option, make_pass_decorator, option, pass_context, pass_obj, password_option,
    secho, style, unstyle, version_option, format_filename, get_app_dir, open_file,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


def run(cli, args, **kw):
    return CliRunner().invoke(cli, args, **kw)


# ---- FP-01 / FP-13: declaration, naming, exit statuses -------------------------

def test_default_name_strips_suffix():
    @command()
    def hello_world_cmd():
        echo("hi")
    assert hello_world_cmd.name == "hello-world"


def test_explicit_name_only_accepts_that_name():
    @command("greet")
    def say_hi():
        echo("hi")
    r = run(say_hi, [])
    assert r.exit_code == 0 and "hi" in r.output
    assert run(say_hi, ["--help"]).exit_code == 0


def test_success_exit_zero_and_runs_once():
    calls = []

    @command()
    def c():
        calls.append(1)
    r = run(c, [])
    assert r.exit_code == 0 and calls == [1]


def test_unknown_option_is_usage_error_and_callback_not_run():
    calls = []

    @command()
    @option("--x")
    def c(x):
        calls.append(x)
    r = run(c, ["--nope"])
    assert r.exit_code == 2 and calls == []
    assert "--nope" in r.output


def test_extra_args_rejected_unless_allowed():
    @command()
    @argument("a")
    def c(a):
        echo(a)
    r = run(c, ["x", "y"])
    assert r.exit_code == 2
    assert "unexpected extra argument" in r.output


def test_allow_extra_args_tolerates_plain_tokens():
    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def c(a):
        echo(f"a={a}")
    r = run(c, ["x", "y", "z"])
    assert r.exit_code == 0 and "a=x" in r.output


def test_allow_extra_args_option_shaped_leftover_is_error():
    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def c(a):
        echo(a)
    r = run(c, ["x", "--weird"])
    assert r.exit_code == 2


def test_deprecated_command_runs_and_warns():
    @command(deprecated="use other")
    def old():
        echo("ran")
    r = run(old, [])
    assert r.exit_code == 0 and "ran" in r.stdout
    assert "DeprecationWarning" in r.stderr and "use other" in r.stderr


def test_abort_exit_one_and_author_exit_status():
    @command()
    def a():
        raise Abort()
    r = run(a, [])
    assert r.exit_code == 1 and "Aborted!" in r.stderr

    @command()
    def b():
        get_current_context().exit(7)
    assert run(b, []).exit_code == 7


def test_standalone_off_returns_value_and_raises():
    @command()
    def c():
        return 42
    assert c.main([], standalone_mode=False) == 42
    @command()
    @option("--n", type=int)
    def d(n):
        pass
    with pytest.raises(BadParameter):
        d.main(["--n", "x"], standalone_mode=False)


# ---- FP-02: help ---------------------------------------------------------------

def test_help_prints_page_and_skips_callback():
    calls = []

    @command()
    @option("--count", type=int, default=3, help="How many.", show_default=True)
    def c(count):
        """Do the thing.

        Long text.
        """
        calls.append(count)
    r = run(c, ["--help"])
    assert r.exit_code == 0 and calls == []
    assert "Usage: c [OPTIONS]" in r.stdout
    assert "Do the thing." in r.stdout and "Long text" not in r.stdout.split("Options:")[0].split("Do the thing.")[0]
    assert "--count INTEGER" in r.stdout and "[default: 3]" in r.stdout


def test_formfeed_truncates_docstring():
    @command()
    def c():
        """Visible.\f hidden part"""
    r = run(c, ["--help"])
    assert "Visible." in r.stdout and "hidden" not in r.stdout and "\f" not in r.stdout


def test_group_without_args_is_usage_failure_with_help():
    @group()
    def g():
        pass
    @g.command()
    def sub():
        pass
    r = run(g, [])
    assert r.exit_code == 2
    assert "Usage: g" in r.output and "Commands:" in r.output


def test_hidden_command_omitted_from_help_but_invocable():
    @group()
    def g():
        pass
    @g.command(hidden=True)
    def secret():
        echo("secret ran")
    assert "secret" not in run(g, ["--help"]).stdout
    assert "secret ran" in run(g, ["secret"]).stdout


def test_help_option_name_can_be_replaced():
    @command()
    def c():
        pass
    ctx_settings = {"help_option_names": ["-h"]}
    c.context_settings.update(ctx_settings)
    assert run(c, ["-h"]).exit_code == 0
    assert "Show this message" in run(c, ["-h"]).stdout


def test_version_option_eager_and_first_wins():
    calls = []

    @command()
    @version_option("9.8.7", prog_name="tool")
    @option("--req", required=True)
    def c(req):
        calls.append(req)
    r = run(c, ["--version"])
    assert r.exit_code == 0 and "9.8.7" in r.stdout and calls == []
    r = run(c, ["--help", "--version"])
    assert "Usage" in r.stdout and "9.8.7" not in r.stdout
    r = run(c, ["--version", "--help"])
    assert "9.8.7" in r.stdout and "Usage" not in r.stdout


def test_custom_version_option_prints_exactly():
    @command()
    @custom_version_option(lambda ctx: "custom identity")
    def c():
        pass
    r = run(c, ["--version"])
    assert r.stdout == "custom identity\n"


def test_wrap_text_rewraps_and_keeps_backspace_paragraph():
    text = "one two\nthree four\n\n\b\nkeep\n  lines"
    out = wrap_text(text, width=100)
    assert "one two three four" in out
    assert "keep\n  lines" in out and "\b" not in out


# ---- FP-03: options -----------------------------------------------------------

def test_flag_and_pair_and_count():
    @command()
    @option("--shout/--no-shout", default=False)
    @option("-v", "--verbose", count=True)
    @option("--force", "-f", is_flag=True, default=True)
    def c(shout, verbose, force):
        echo(f"{shout} {verbose} {force}")
    assert "False 0 True" in run(c, []).stdout
    assert "True 2 True" in run(c, ["--shout", "-vv"]).stdout
    assert "False 0 True" in run(c, ["--no-shout"]).stdout
    assert "True 0 True" in run(c, ["--shout", "--force"]).stdout


def test_flag_default_true_present_is_true():
    @command()
    @option("--on", is_flag=True, default=True)
    def c(on):
        echo(f"on={on}")
    assert "on=True" in run(c, []).stdout
    assert "on=True" in run(c, ["--on"]).stdout


def test_stacked_short_flags_and_value_attached():
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def c(a, b, n):
        echo(f"{a} {b} {n}")
    assert "True True 3" in run(c, ["-abn3"]).stdout
    assert "True False 4" in run(c, ["-a", "-n", "4"]).stdout


def test_double_dash_ends_options():
    @command()
    @option("--x", is_flag=True)
    @argument("rest", nargs=-1)
    def c(x, rest):
        echo(f"x={x} rest={rest}")
    r = run(c, ["--", "--x", "y"])
    assert "x=False rest=('--x', 'y')" in r.stdout


def test_required_option_missing_is_usage_error():
    @command()
    @option("--name", required=True)
    def c(name):
        echo(name)
    r = run(c, [])
    assert r.exit_code == 2 and "--name" in r.output


def test_multi_value_option_fixed_nargs():
    @command()
    @option("--pair", nargs=2, type=int)
    def c(pair):
        echo(repr(pair))
    assert "(1, 2)" in run(c, ["--pair", "1", "2"]).stdout
    assert run(c, ["--pair", "1"]).exit_code == 2


def test_tuple_type_option():
    @command()
    @option("--point", type=Tuple([str, int]))
    def c(point):
        echo(repr(point))
    assert "('a', 3)" in run(c, ["--point", "a", "3"]).stdout


def test_optional_value_option():
    @command()
    @option("--mode", is_flag=False, flag_value="fast", default="slow")
    def c(mode):
        echo(mode)
    assert "slow" in run(c, []).stdout
    assert "fast" in run(c, ["--mode"]).stdout
    assert "turbo" in run(c, ["--mode", "turbo"]).stdout


def test_missing_value_is_usage_error():
    @command()
    @option("--x")
    def c(x):
        pass
    assert run(c, ["--x"]).exit_code == 2


def test_non_slash_prefix_declared():
    @command()
    @option("/f", is_flag=True)
    @option("+p", "--plus", is_flag=True)
    def c(f, plus):
        echo(f"{f} {plus}")
    assert "True False" in run(c, ["/f"]).stdout
    assert "False True" in run(c, ["+p"]).stdout


def test_option_callback_refuses_and_replaces():
    def cb(ctx, param, value):
        if value < 0:
            raise BadParameter("must be non-negative")
        return value * 10
    @command()
    @option("--n", type=int, callback=cb)
    def c(n):
        echo(n)
    assert "30" in run(c, ["--n", "3"]).stdout
    r = run(c, ["--n", "-1"])
    assert r.exit_code == 2 and "must be non-negative" in r.output


def test_feature_switch_group_explicit_wins():
    @command()
    @option("--fast", "mode", flag_value="fast", is_flag=True, default=False)
    @option("--slow", "mode", flag_value="slow", is_flag=True)
    def c(mode):
        echo(mode)
    assert "fast" in run(c, ["--fast"]).stdout


# ---- FP-03 environment ---------------------------------------------------------

def test_envvar_fills_option_and_first_set_wins():
    @command()
    @option("--token", envvar=["TOK_A", "TOK_B"])
    def c(token):
        echo(token)
    assert "b" in run(c, [], env={"TOK_A": None, "TOK_B": "b"}).stdout
    assert "a" in run(c, [], env={"TOK_A": "a", "TOK_B": "b"}).stdout
    assert run(c, [], env={"TOK_A": "", "TOK_B": None}).stdout == "\n"  # None is echoed as empty


def test_envvar_flag_values():
    @command()
    @option("--on", envvar="ON_FLAG", is_flag=True)
    def c(on):
        echo(f"on={on}")
    assert "on=True" in run(c, [], env={"ON_FLAG": " yes "}).stdout
    assert "on=False" in run(c, [], env={"ON_FLAG": "  "}).stdout
    r = run(c, [], env={"ON_FLAG": "maybe"})
    assert r.exit_code == 2


def test_auto_envvar_prefix_nested_path():
    @group(context_settings={"auto_envvar_prefix": "MYAPP"})
    def g():
        pass
    @g.command()
    @option("--level", type=int)
    def sub(level):
        echo(f"level={level}")
    r = run(g, ["sub"], env={"MYAPP_SUB_LEVEL": "5"})
    assert "level=5" in r.stdout


def test_auto_envvar_top_level_option():
    @command(context_settings={"auto_envvar_prefix": "app-x"})
    @option("--level", type=int, required=True)
    def c(level):
        echo(f"level={level}")
    assert "level=7" in run(c, [], env={"APP_X_LEVEL": "7"}).stdout


def test_default_map_and_source_inspection():
    seen = {}
    @command()
    @option("--name", default="dflt")
    @option("--other")
    def c(name, other):
        ctx = get_current_context()
        seen["name"] = ctx.get_parameter_source("name")
        seen["other"] = ctx.get_parameter_source("other")
        seen["undeclared"] = ctx.get_parameter_source("nope")
        echo(f"{name}")
    r = run(c, [], catch_exceptions=False, **{"default_map": {"name": "mapped"}})
    assert "mapped" in r.stdout and seen["name"] is ParameterSource.DEFAULT_MAP
    run(c, ["--name", "cli"])
    assert seen["name"] is ParameterSource.COMMANDLINE
    run(c, [])
    assert seen["name"] is ParameterSource.DEFAULT and seen["undeclared"] is None


def test_default_map_applies_by_subcommand_name():
    @group()
    def g():
        pass
    @g.command()
    @option("--v", default="x")
    def sub(v):
        echo(v)
    r = CliRunner().invoke(g, ["sub"], default_map={"sub": {"v": "from-map"}})
    assert "from-map" in r.stdout
    r = CliRunner().invoke(g, ["sub"], default_map={"other": {"v": "nope"}})
    assert "x" in r.stdout


def test_default_map_string_split_for_multiple_refused():
    @command()
    @option("--t", multiple=True)
    def c(t):
        pass
    r = CliRunner().invoke(c, [], default_map={"t": "a b"})
    assert r.exit_code == 2 and "iterable" in r.output


def test_bare_string_default_on_repeatable_refused():
    @command()
    @option("--t", multiple=True, default="abc")
    def c(t):
        pass
    r = run(c, [])
    assert r.exit_code == 2 and "iterable" in r.output


def test_default_callable_invoked():
    @command()
    @option("--n", type=int, default=lambda: 41)
    def c(n):
        echo(n + 1)
    assert "42" in run(c, []).stdout


def test_deprecated_option_warns_only_when_supplied():
    @command()
    @option("--old", deprecated=True, default="d")
    def c(old):
        echo(old)
    assert "DeprecationWarning" not in run(c, []).stderr
    r = run(c, ["--old", "x"])
    assert "DeprecationWarning" in r.stderr and "x" in r.stdout


def test_deprecated_option_refuses_required_and_prompt():
    with pytest.raises(ValueError):
        option("--x", deprecated=True, required=True)(lambda x: None)
    with pytest.raises(ValueError):
        option("--x", deprecated=True, prompt=True)(lambda x: None)


# ---- FP-04 arguments ----------------------------------------------------------

def test_arguments_bind_in_order_and_variadic():
    @command()
    @argument("src")
    @argument("dst", required=False, default="out")
    @argument("extra", nargs=-1)
    def c(src, dst, extra):
        echo(f"{src}|{dst}|{extra}")
    assert "a|out|()" in run(c, ["a"]).stdout
    assert "a|b|('c', 'd')" in run(c, ["a", "b", "c", "d"]).stdout


def test_missing_required_argument_names_it():
    @command()
    @argument("src")
    def c(src):
        pass
    r = run(c, [])
    assert r.exit_code == 2 and "src" in r.output


def test_argument_after_double_dash_and_option_like():
    @command()
    @argument("a")
    def c(a):
        echo(a)
    assert "--zz" in run(c, ["--", "--zz"]).stdout


def test_argument_envvar_explicit_only():
    @command()
    @argument("v", envvar="ARG_V")
    def c(v):
        echo(v)
    assert "from-env" in run(c, [], env={"ARG_V": "from-env"}).stdout
    assert "cli" in run(c, ["cli"], env={"ARG_V": "from-env"}).stdout


# ---- FP-05 types --------------------------------------------------------------

def test_int_rejects_fraction_and_inferred_from_default():
    @command()
    @option("--n", default=1)
    def c(n):
        echo(repr(n))
    assert "2" in run(c, ["--n", "2"]).stdout
    r = run(c, ["--n", "1.5"])
    assert r.exit_code == 2 and "--n" in r.output


def test_float_bool_uuid_types():
    @command()
    @option("--f", type=float, default=1.0)
    @option("--b", type=optlyn.BOOL)
    @option("--u", type=UUID)
    def c(f, b, u):
        echo(f"{type(f).__name__} {b} {type(u).__name__}")
    out = run(c, ["--f", "2.5", "--b", "YES", "--u", str(uuid.uuid4())]).stdout
    assert "float True UUID" in out
    assert run(c, ["--b", "maybe"]).exit_code == 2


class Color(enum.Enum):
    RED = 1
    BLUE = 2


def test_choice_returns_original_member_and_case_rules():
    @command()
    @option("--c", type=Choice(Color), default=Color.RED)
    def c(c):
        echo(repr(c))
    assert "Color.BLUE" in run(c, ["--c", "BLUE"]).stdout
    assert run(c, ["--c", "blue"]).exit_code == 2

    @command()
    @option("--x", type=Choice(["a", "b"], case_sensitive=False))
    def d(x):
        echo(repr(x))
    assert "'a'" in run(d, ["--x", "A"]).stdout


def test_choice_help_lists_values():
    @command()
    @option("--x", type=Choice(["alpha", "beta"]))
    def c(x):
        pass
    assert "[alpha|beta]" in run(c, ["--help"]).stdout


def test_datetime_formats_and_custom_replace():
    @command()
    @option("--when", type=DateTime())
    def c(when):
        echo(when.isoformat())
    assert "2024-02-03T00:00:00" in run(c, ["--when", "2024-02-03"]).stdout
    assert "2024-02-03T04:05:06" in run(c, ["--when", "2024-02-03 04:05:06"]).stdout
    assert run(c, ["--when", "nope"]).exit_code == 2

    @command()
    @option("--when", type=DateTime(["%d/%m/%Y"]))
    def d(when):
        echo(when.isoformat())
    assert "2024-02-03" in run(d, ["--when", "03/02/2024"]).stdout
    assert run(d, ["--when", "2024-02-03"]).exit_code == 2


def test_int_range_clamp_and_refuse():
    @command()
    @option("--n", type=IntRange(0, 10, clamp=True))
    def c(n):
        echo(n)
    assert "10" in run(c, ["--n", "99"]).stdout
    assert "0" in run(c, ["--n", "-5"]).stdout

    @command()
    @option("--n", type=IntRange(0, 10, max_open=True, clamp=True))
    def d(n):
        echo(n)
    assert "9" in run(d, ["--n", "10"]).stdout

    @command()
    @option("--n", type=IntRange(1, 3))
    def e(n):
        pass
    assert run(e, ["--n", "9"]).exit_code == 2


def test_float_range_clamp_open_bound_declaration_error():
    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)
    FloatRange(0.0, 1.0, clamp=True)


def test_custom_type_and_function_type():
    class Upper(optlyn.ParamType):
        name = "upper"
        def convert(self, value, param, ctx):
            if isinstance(value, str):
                return value.upper()
            return value

    @command()
    @option("--u", type=Upper())
    def c(u):
        echo(u)
    assert "ABC" in run(c, ["--u", "abc"]).stdout

    def positive(s):
        v = int(s)
        if v <= 0:
            raise ValueError("not positive")
        return v

    @command()
    @option("--p", type=positive)
    def d(p):
        echo(p)
    assert "4" in run(d, ["--p", "4"]).stdout
    r = run(d, ["--p", "-1"])
    assert r.exit_code == 2 and "not positive" in r.output


# ---- FP-06 groups -------------------------------------------------------------

def test_group_callback_runs_before_child_and_nesting():
    order = []
    @group()
    def top():
        order.append("top")
    @top.group()
    def mid():
        order.append("mid")
    @mid.command()
    def leaf():
        order.append("leaf")
        echo("leaf-out")
    r = run(top, ["mid", "leaf"])
    assert r.exit_code == 0 and order == ["top", "mid", "leaf"]
    r = run(top, ["mid"])
    assert r.exit_code == 2 and "Usage: top mid" in r.output


def test_group_options_before_subcommand_only():
    @group()
    @option("--gopt")
    def g(gopt):
        echo(f"g={gopt}")
    @g.command()
    @option("--sopt")
    def sub(sopt):
        echo(f"s={sopt}")
    r = run(g, ["--gopt", "1", "sub", "--sopt", "2"])
    assert "g=1" in r.stdout and "s=2" in r.stdout


def test_missing_command_and_unknown_command_messages():
    @group(invoke_without_command=True)
    def g():
        echo("group only")
    assert "group only" in run(g, []).stdout

    @group(no_args_is_help=False)
    def h():
        pass
    @h.command()
    def sub():
        pass
    r = run(h, [])
    assert r.exit_code == 2 and "Missing command" in r.output
    r = run(h, ["zzz"])
    assert r.exit_code == 2 and "No such command" in r.output


def test_command_collection_union():
    @group()
    def a():
        pass
    @group()
    def b():
        pass
    @a.command()
    def one():
        echo("one")
    @b.command()
    def two():
        echo("two")
    coll = CommandCollection(name="all", sources=[a, b])
    assert "one" in run(coll, ["one"]).stdout
    assert "two" in run(coll, ["two"]).stdout
    assert "one" in run(coll, ["--help"]).stdout and "two" in run(coll, ["--help"]).stdout


def test_custom_group_lazy_resolution():
    class Lazy(Group):
        def list_commands(self, ctx):
            return ["dyn"]
        def get_command(self, ctx, name):
            if name != "dyn":
                return None
            @command()
            def dyn():
                echo("dynamic")
            return dyn
    lazy = Lazy(name="lazy")
    assert "dynamic" in run(lazy, ["dyn"]).stdout
    assert "No such command" in run(lazy, ["other"]).output


def test_chain_group_results_and_result_callback():
    @group(chain=True)
    def pipeline():
        pass
    @pipeline.result_callback()
    def done(results):
        echo(f"results={results}")
    @pipeline.command()
    @argument("x", type=int)
    def add(x):
        return x + 1
    @pipeline.command()
    @argument("x", type=int)
    def mul(x):
        return x * 2
    r = run(pipeline, ["add", "1", "mul", "5"])
    assert "results=[2, 10]" in r.stdout
    assert pipeline.main(["add", "1", "mul", "5"], standalone_mode=False) == [2, 10]


def test_chain_refuses_nested_group():
    @group(chain=True)
    def p():
        pass
    with pytest.raises(RuntimeError):
        p.add_command(group(name="inner")(lambda: None))


def test_group_invoke_without_command_result_callback_gets_group_return():
    @group(invoke_without_command=True)
    def g():
        return "from-group"
    @g.result_callback()
    def cb(value):
        echo(f"cb={value}")
    assert "cb=from-group" in run(g, []).stdout


# ---- FP-07: context ------------------------------------------------------------

def test_obj_inherit_and_pass_decorators():
    class Cfg:
        def __init__(self):
            self.name = None

    @group()
    @pass_obj
    def g(obj):
        obj.name = "root"
    @g.command()
    @make_pass_decorator(Cfg, ensure=True)
    def sub(cfg):
        echo(f"cfg={cfg.name}")
    @g.command()
    @pass_context
    def ctxcmd(ctx):
        echo(f"obj={ctx.obj}")
    cfg = Cfg()
    r = CliRunner().invoke(g, ["sub"], obj=cfg)
    assert r.exit_code == 0 and "cfg=root" in r.stdout


def test_pass_context_sees_obj():
    @group()
    def g():
        pass

    @g.command()
    @pass_context
    def ctxcmd(ctx):
        echo(f"obj={ctx.obj}")

    r = CliRunner().invoke(g, ["ctxcmd"], obj="X")
    assert "obj=X" in r.stdout


def test_invoke_and_forward_between_commands():
    @command()
    @option("--a", default="A")
    def target(a):
        echo(f"target a={a}")
    @command()
    @option("--a", default="src")
    def source(a):
        ctx = get_current_context()
        ctx.forward(target)
        ctx.invoke(target, a="explicit")
    r = run(source, [])
    assert "target a=src" in r.stdout and "target a=explicit" in r.stdout


def test_resource_closed_when_invocation_finishes(tmp_path):
    path = tmp_path / "f.txt"
    @command()
    @argument("out", type=File("w"))
    def c(out):
        out.write("hello")
    r = run(c, [str(path)])
    assert r.exit_code == 0
    assert path.read_text() == "hello"


def test_context_manager_makes_context_current_on_thread():
    cmd = Command("x")
    ctx = Context(cmd)
    assert get_current_context(silent=True) is None
    with ctx:
        assert get_current_context() is ctx
    with pytest.raises(RuntimeError):
        get_current_context()


# ---- FP-08: prompts -----------------------------------------------------------

def test_option_prompt_reads_stdin_and_skips_when_supplied():
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(f"hi {name}")
    r = run(c, [], input="bob\n")
    assert r.exit_code == 0 and "hi bob" in r.stdout
    r = run(c, ["--name", "al"], input="ignored\n")
    assert "hi al" in r.stdout and "ignored" not in r.stdout


def test_prompt_default_used_on_empty_line_and_reasks_on_error():
    @command()
    @option("--n", type=int, prompt=True, default=5)
    def c(n):
        echo(f"n={n}")
    r = run(c, [], input="\n")
    assert "n=5" in r.stdout
    r = run(c, [], input="abc\n7\n")
    assert "n=7" in r.stdout and "Error" in r.output


def test_prompt_eof_is_abort():
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(name)
    r = run(c, [], input="")
    assert r.exit_code == 1 and "Aborted" in r.stderr


def test_password_option_confirmation_mismatch_reasks():
    @command()
    @password_option()
    def c(password):
        echo(f"pw={password}")
    r = run(c, [], input="a\nb\nsecret\nsecret\n")
    assert "pw=secret" in r.stdout


def test_confirmation_option_declined_aborts_accepted_runs():
    @command()
    @confirmation_option(prompt="Really?")
    def c():
        echo("ran")
    assert "ran" not in run(c, [], input="n\n").stdout
    assert run(c, [], input="n\n").exit_code == 1
    assert "ran" in run(c, [], input="y\n").stdout
    r = run(c, ["--yes"], input="")
    assert "ran" in r.stdout


def test_standalone_confirm_and_prompt():
    @command()
    def c():
        echo(repr(optlyn.confirm("ok?")))
        echo(repr(optlyn.prompt("val", type=int)))
    r = run(c, [], input="maybe\nyes\n42\n")
    assert "True" in r.stdout and "42" in r.stdout


def test_hidden_input_not_echoed_visible_is_echoed():
    @command()
    @option("--secret", prompt=True, hide_input=True)
    def c(secret):
        echo("done")
    r = run(c, [], input="topsecret\n")
    assert "topsecret" not in r.output and "done" in r.stdout


# ---- FP-09 files and paths ----------------------------------------------------

def test_file_read_missing_is_usage_error(tmp_path):
    @command()
    @argument("f", type=File("r"))
    def c(f):
        pass
    r = run(c, [str(tmp_path / "missing.txt")])
    assert r.exit_code == 2 and "missing.txt" in r.output


def test_lazy_write_not_truncated_unless_used(tmp_path):
    target = tmp_path / "keep.txt"
    target.write_text("original")
    @command()
    @option("--out", type=File("w"), default="-", required=False)
    def c(out):
        pass
    @command()
    @argument("f", type=File("w"))
    def d(f):
        pass
    assert run(d, [str(target)]).exit_code == 0
    assert target.read_text() == "original"  # lazy write never used: not truncated
    target.write_text("keep")
    @command()
    @option("--f", type=File("w", lazy=False))
    def e(f):
        pass
    run(e, ["--f", str(target)])
    assert target.read_text() == ""


def test_dash_stdout_is_not_closed_and_stdin_reads(tmp_path):
    @command()
    @argument("f", type=File("r"))
    def c(f):
        echo(f.read().upper())
    r = run(c, ["-"], input="piped text")
    assert "PIPED TEXT" in r.stdout


def test_path_checks(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("x")
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def c(p):
        echo(f"path={p}")
    assert "path=" in run(c, [str(f)]).stdout
    assert run(c, [str(tmp_path / "nope")]).exit_code == 2
    assert run(c, [str(tmp_path)]).exit_code == 2

    @command()
    @argument("p", type=Path(allow_dash=True))
    def d(p):
        echo(f"got={p}")
    assert "got=-" in run(d, ["-"]).stdout


def test_path_type_object_and_resolve(tmp_path):
    @command()
    @argument("p", type=Path(path_type=pathlib.Path))
    def c(p):
        echo(type(p).__name__)
    assert "PosixPath" in run(c, ["x"]).stdout or "Path" in run(c, ["x"]).stdout


def test_format_filename_keeps_distinct_names():
    assert format_filename("a.txt") == "a.txt"
    assert format_filename(b"\xff") != format_filename(b"\xfe")
    format_filename(b"\xff").encode("utf-8", "strict")


# ---- FP-11 terminal helpers ----------------------------------------------------

def test_echo_strips_styles_when_not_terminal_and_color_forced():
    @command()
    def c():
        echo(style("hi", fg="red"))
    assert "\x1b[" not in run(c, []).stdout
    @command()
    def d():
        echo(style("hi", fg="red"))
    assert "\x1b[" in run(d, [], color=True).stdout


def test_style_colors_and_invalid():
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", fg="red") != style("x", fg="bright_red")
    assert style("x", fg=200) and style("x", fg=(1, 2, 3))
    with pytest.raises(TypeError):
        style("x", fg="nope")
    with pytest.raises(TypeError):
        style("x", fg=(1, 2, 300))
    assert unstyle(style("hello", bold=True)) == "hello"


def test_echo_to_stderr_and_ascii_stream():
    @command()
    def c():
        echo("to-err", err=True)
        echo("ünï")
    r = run(c, [])
    assert "to-err" in r.stderr and "ünï" in r.stdout


def test_progressbar_visits_every_item_without_tty():
    seen = []
    @command()
    def c():
        with optlyn.progressbar(range(5), label="work") as bar:
            for i in bar:
                seen.append(i)
        with optlyn.progressbar(range(3), hidden=True) as bar2:
            for i in bar2:
                seen.append(i)
    r = run(c, [])
    assert seen == [0, 1, 2, 3, 4, 0, 1, 2]
    assert "work" in r.stdout


def test_pause_and_clear_do_not_block_in_tests():
    @command()
    def c():
        optlyn.pause("wait")
        optlyn.clear()
        echo("end")
    r = run(c, [])
    assert r.exit_code == 0 and "end" in r.stdout


def test_app_dir_lookup(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/xdg-test")
    assert get_app_dir("My App").replace("\\", "/") == "/tmp/xdg-test/my-app"
    assert get_app_dir("My App", force_posix=True).endswith("/.my-app")


def test_wrap_text_with_backspace_and_no_fail():
    assert wrap_text("") == ""
    wrap_text("\x00 weird ☃ text")


# ---- FP-14 runner ---------------------------------------------------------------

def test_runner_isolated_filesystem_and_result_fields(tmp_path):
    @command()
    @argument("name", type=File("w"))
    def c(name):
        name.write("data")
        echo("written")
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as d:
        r = runner.invoke(c, ["out.txt"])
        assert r.exit_code == 0
        assert (pathlib.Path(d) / "out.txt").read_text() == "data"
    assert r.stdout.strip() == "written"
    assert r.stdout_bytes == b"written\n"
    assert r.output == "written\n"


def test_runner_catches_exceptions_and_can_propagate():
    @command()
    def boom():
        raise ValueError("bad")
    r = run(boom, [])
    assert r.exit_code == 1 and isinstance(r.exception, ValueError)
    with pytest.raises(ValueError):
        CliRunner().invoke(boom, [], catch_exceptions=False)


def test_runner_env_unset_and_echo_stdin_prompt():
    os.environ["OPTLYN_TEST_KEEP"] = "1"
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(name)
    @command()
    def e():
        echo(os.environ.get("OPTLYN_TEST_KEEP", "unset"))
    try:
        assert "unset" in run(e, [], env={"OPTLYN_TEST_KEEP": None}).stdout
        assert "1" == os.environ["OPTLYN_TEST_KEEP"]
        r = CliRunner(echo_stdin=True).invoke(c, [], input="zed\n")
        assert "zed" in r.stdout
    finally:
        del os.environ["OPTLYN_TEST_KEEP"]


def test_runner_fd_capture_separates_streams():
    @command()
    def c():
        echo("out")
        echo("err", err=True)
    r = CliRunner(capture="fd").invoke(c, [])
    assert "out" in r.stdout and "err" in r.stderr
