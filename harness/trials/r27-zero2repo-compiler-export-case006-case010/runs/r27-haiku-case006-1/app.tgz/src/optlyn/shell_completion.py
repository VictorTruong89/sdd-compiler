"""Shell completion: registration scripts and suggestion output for bash, zsh, fish and PowerShell."""

from __future__ import annotations

import os
import sys
import typing as t

from .core import Argument, Command, Context, Group, Option
from .param_types import CompletionItem, Path, File

SHELLS = ("bash", "zsh", "fish", "powershell")
PREFIX_CHARS = ("-", "/", "+")


def _func_name(prog: str) -> str:
    return "_" + "".join(c if c.isalnum() else "_" for c in prog) + "_completion"


def _var_name(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


# spec: N-000701–N-000702, N-001013–N-001022 (registration scripts)
def _script(shell: str, prog: str, complete_var: str) -> str:
    fn = _func_name(prog)
    if shell == "bash":
        return f"""{fn}() {{
    local IFS=$'\\n'
    local response item kind value
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete {prog} 2>/dev/null)
    COMPREPLY=()
    for item in $response; do
        kind="${{item%%$'\\t'*}}"
        value="${{item#*$'\\t'}}"
        value="${{value%%$'\\t'*}}"
        case "$kind" in
            dir) COMPREPLY+=($(compgen -d -- "$value"));;
            file) COMPREPLY+=($(compgen -f -- "$value"));;
            *) COMPREPLY+=("$value");;
        esac
    done
    return 0
}}
complete -o default -F {fn} {prog}
"""
    if shell == "zsh":
        return f"""#compdef {prog}
{fn}() {{
    local -a response
    local item kind value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog} 2>/dev/null)}}")
    for item in $response; do
        kind="${{item%%$'\\t'*}}"
        value="${{item#*$'\\t'}}"
        if [[ "$kind" == "dir" ]]; then _path_files -/; elif [[ "$kind" == "file" ]]; then _path_files;
        else compadd -- "${{value%%$'\\t'*}}"; fi
    done
}}
compdef {fn} {prog}
"""
    if shell == "fish":
        return f"""function {fn}
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {complete_var}=fish_complete {prog} 2>/dev/null)
    for item in $response
        set -l parts (string split \\t -- $item)
        if test "$parts[1]" = "dir"
            __fish_complete_directories $parts[2]
        else if test "$parts[1]" = "file"
            __fish_complete_path $parts[2]
        else
            printf '%s\\t%s\\n' $parts[2] $parts[3]
        end
    end
end
complete -c {prog} -f -a '({fn})'
"""
    if shell == "powershell":
        return f"""Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $Env:COMP_WORDS = $commandAst.ToString()
    $Env:COMP_CWORD = $wordToComplete
    $Env:{complete_var} = 'powershell_complete'
    {prog} | ForEach-Object {{
        $parts = $_ -split "`t"
        [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
    }}
    Remove-Item Env:{complete_var}
}}
"""
    raise ValueError(shell)


def _looks_like_option(tok: str) -> bool:
    return len(tok) > 1 and tok[0] in PREFIX_CHARS


def _find_option(cmd: Command, ctx: Context, name: str) -> t.Optional[Option]:
    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and (name in p.opts or name in p.secondary_opts):
            return p
    return None


def _visible_options(cmd: Command, ctx: Context) -> t.List[Option]:
    return [p for p in cmd.get_params(ctx) if isinstance(p, Option) and not p.hidden]


def _param_items(param: t.Any, ctx: Context, incomplete: str) -> t.List[CompletionItem]:
    if param is not None and getattr(param, "_shell_complete", None) is not None:
        out = []
        for item in param._shell_complete(ctx, param, incomplete) or []:
            if isinstance(item, CompletionItem):
                out.append(item)
            elif isinstance(item, str):
                out.append(CompletionItem(item))
            else:
                out.append(CompletionItem(item.value, getattr(item, "help", None), getattr(item, "type", "plain")))
        return out
    ptype = param.type if param is not None else None
    if ptype is None:
        return []
    if isinstance(ptype, Path):
        return [CompletionItem(incomplete, None, "dir" if (not ptype.file_okay and ptype.dir_okay) else "file")]
    if isinstance(ptype, File):
        return [CompletionItem(incomplete, None, "file")]
    return list(ptype.shell_complete(ctx, param, incomplete))


# spec: N-000694–N-000700, N-000712–N-000713, N-001023–N-001030 (suggestions)
def get_suggestions(cli: Command, prog: str, args: t.List[str], incomplete: str) -> t.List[CompletionItem]:
    """Compute suggestions for ``incomplete`` given the already-typed ``args`` (no program name)."""
    cmd: Command = cli
    ctx = Context(cli, info_name=prog)
    pending: t.Optional[Option] = None
    positional = 0
    after_dashdash = False
    i = 0
    while i < len(args):
        tok = args[i]
        last = i == len(args) - 1
        if not after_dashdash and tok == "--":
            after_dashdash = True
            i += 1
            continue
        if not after_dashdash and _looks_like_option(tok):
            name = tok.split("=", 1)[0]
            opt = _find_option(cmd, ctx, name)
            if opt is not None and not opt.is_flag and "=" not in tok:
                if last:
                    pending = opt
                    break
                i += 2
                continue
            i += 1
            continue
        if isinstance(cmd, Group):
            sub = cmd.get_command(ctx, tok)
            if sub is not None:
                ctx = Context(sub, info_name=tok, parent=ctx)
                cmd = sub
                positional = 0
                i += 1
                continue
        positional += 1
        i += 1

    if pending is not None:
        return _param_items(pending, ctx, incomplete)

    if incomplete[:1] in PREFIX_CHARS and incomplete and not after_dashdash:
        out = []
        for opt in _visible_options(cmd, ctx):
            for name in opt.opts + opt.secondary_opts:
                if name.startswith(incomplete):
                    out.append(CompletionItem(name, opt.help))
        return out

    out = []
    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            out.append(CompletionItem(name, sub.get_short_help_str(limit=45)))
    args_params = [p for p in cmd.get_params(ctx) if isinstance(p, Argument) and not p.hidden]
    if positional < len(args_params):
        out.extend(_param_items(args_params[positional], ctx, incomplete))
    return out


# spec: N-000692–N-000693, N-000703–N-000705, N-000714–N-000715 (modes, unknown instruction)
def handle_completion(cli: Command, prog_name: str, complete_var: str, instruction: str) -> None:
    """Handle a completion request selected by the ``complete_var`` environment variable."""
    shell, _, action = instruction.rpartition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        sys.stderr.write(f"Unsupported completion instruction: {instruction!r}\n")
        sys.exit(1)
    if action == "source":
        sys.stdout.write(_script(shell, prog_name, complete_var))
        sys.stdout.flush()
        return
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        words = os.environ.get("COMP_WORDS", "").split()
        if words and words[-1] == incomplete:
            words = words[:-1]
        args = words[1:]
    else:
        words = os.environ.get("COMP_WORDS", "").split()
        try:
            idx = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            idx = len(words)
        incomplete = words[idx] if idx < len(words) else ""
        args = words[1:idx]
    items = get_suggestions(cli, prog_name, args, incomplete)
    lines = []
    for item in items:
        help_text = (item.help or "").replace("\t", " ").replace("\n", " ")
        if shell in ("zsh", "fish"):
            lines.append(f"{item.type}\t{item.value}\t{help_text}")
        else:
            lines.append(f"{item.type}\t{item.value}\t")
    sys.stdout.write("\n".join(lines) + ("\n" if lines else ""))
    sys.stdout.flush()
