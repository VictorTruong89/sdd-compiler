"""Parameter types: built-in conversions, custom types and type inference."""

from __future__ import annotations

import datetime as dt
import enum
import os
import pathlib
import re
import stat
import typing as t
import uuid

from .exceptions import BadParameter
from .utils import open_file, format_filename


class CompletionItem:
    """A shell completion suggestion with optional help and kind."""

    __slots__ = ("value", "help", "type")

    def __init__(self, value: str, help: t.Optional[str] = None, type: str = "plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _current_ctx() -> t.Any:
    from ._state import get_current_context

    return get_current_context(silent=True)


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and override ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value

    def get_metavar(self, param: t.Any) -> t.Optional[str]:
        return None

    def split_envvar_value(self, rv: str) -> t.List[str]:
        return rv.split()

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[CompletionItem]:
        return []

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


# spec: N-000332 (string type)
class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


# spec: N-000369 (pass-through)
class UnprocessedParamType(ParamType):
    """Pass-through: the raw token is delivered unchanged."""

    name = "text"


_INT_RE = re.compile(r"^\s*[+-]?[0-9]+\s*$")


# spec: N-000333–N-000336 (integer)
class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        if isinstance(value, str) and _INT_RE.match(value):
            return int(value)
        self.fail(f"{value!r} is not a valid integer.", param, ctx)


# spec: N-000337–N-000338 (float)
class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


BOOL_TRUE = ("1", "true", "t", "yes", "y", "on")
BOOL_FALSE = ("0", "false", "f", "no", "n", "off")


# spec: N-000339–N-000345 (boolean)
class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        if isinstance(value, str):
            low = value.strip().lower()
            if low in BOOL_TRUE:
                return True
            if low in BOOL_FALSE:
                return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


# spec: N-000346–N-000347 (UUID)
class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


# spec: N-000348–N-000352, N-000382–N-000383 (choice: original object delivered)
class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _token(choice: t.Any) -> str:
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param):
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice:
                return choice
        if isinstance(value, enum.Enum):
            value = value.name
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        normalize = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        token = str(value)
        if normalize is not None:
            token = normalize(token)
        for choice in self.choices:
            candidate = self._token(choice)
            if normalize is not None:
                candidate = normalize(candidate)
            if self.case_sensitive:
                matched = token == candidate
            else:
                matched = token.casefold() == candidate.casefold()
            if matched:
                return choice
        names = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not {'one of' if len(self.choices) != 1 else 'one of'} {names}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [
            CompletionItem(self._token(c))
            for c in self.choices
            if self._token(c).startswith(incomplete)
        ]


DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


# spec: N-000353–N-000357 (date-time formats)
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param, ctx):
        if isinstance(value, dt.datetime):
            return value
        text = str(value)
        for fmt in self.formats:
            try:
                return dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.", param, ctx)


def _describe_range(lo, hi, lo_open, hi_open) -> str:
    parts = []
    if lo is not None:
        parts.append(f"x {'>' if lo_open else '>='} {lo}")
    if hi is not None:
        parts.append(f"x {'<' if hi_open else '<='} {hi}")
    return " and ".join(parts) or "any value"


# spec: N-000358–N-000362 (integer range; clamp to adjacent integer for open bound)
class IntRange(ParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        if (min_open and min is None) or (max_open and max is None):
            raise ValueError("An open bound needs a value.")

    def convert(self, value, param, ctx):
        v = INT.convert(value, param, ctx)
        lo_bad = self.min is not None and (v < self.min or (self.min_open and v == self.min))
        hi_bad = self.max is not None and (v > self.max or (self.max_open and v == self.max))
        if lo_bad:
            if not self.clamp:
                self.fail(f"{v} is not in the range {_describe_range(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
            v = self.min + 1 if self.min_open else self.min
        if hi_bad:
            if not self.clamp:
                self.fail(f"{v} is not in the range {_describe_range(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
            v = self.max - 1 if self.max_open else self.max
        return v


# spec: N-000363–N-000365, N-000381 (float range; clamp only with closed bounds)
class FloatRange(ParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        if (min_open and min is None) or (max_open and max is None):
            raise ValueError("An open bound needs a value.")
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only allowed when both bounds are closed.")

    def convert(self, value, param, ctx):
        v = FLOAT.convert(value, param, ctx)
        if self.min is not None and v < self.min:
            if not self.clamp:
                self.fail(f"{v} is not in the range {_describe_range(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
            return float(self.min)
        if self.max is not None and v > self.max:
            if not self.clamp:
                self.fail(f"{v} is not in the range {_describe_range(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
            return float(self.max)
        if (self.min is not None and self.min_open and v == self.min) or (
            self.max is not None and self.max_open and v == self.max
        ):
            self.fail(f"{v} is not in the range {_describe_range(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        return v


# spec: N-000366 (tuple)
class Tuple(ParamType):
    """A fixed-length product of types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [convert_type(ty) for ty in types]

    def get_metavar(self, param):
        return " ".join(ty.name.upper() for ty in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, (str, bytes)) or not isinstance(value, (tuple, list)):
            self.fail(f"Expected a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(ty.convert(v, param, ctx) for ty, v in zip(self.types, value))


class FuncParamType(ParamType):
    """A conversion function that refuses invalid input by raising ValueError."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param, ctx):
        if not isinstance(value, (str, bytes)):
            return value
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


# spec: N-000367, N-000532–N-000545, N-000578–N-000582 (file type)
class File(ParamType):
    """Opens a file; the delivered value is an open file object."""

    name = "filename"

    def __init__(
        self,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: t.Optional[str] = "strict",
        lazy: t.Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_envvar_value(self, rv: str) -> t.List[str]:
        return rv.split(os.pathsep)

    def get_metavar(self, param):
        return "FILENAME"

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        ctx = ctx if ctx is not None else _current_ctx()
        try:
            f = open_file(value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror or e}", param, ctx)
        if value != "-" and ctx is not None:
            ctx.call_on_close(f.close)
        return f


# spec: N-000368, N-000548–N-000573, N-000583–N-000587 (path type)
class Path(ParamType):
    """Validates a filesystem path and delivers the path (not an open file)."""

    name = "path"

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Optional[type] = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv: str) -> t.List[str]:
        return rv.split(os.pathsep)

    def get_metavar(self, param):
        return "PATH"

    def _deliver(self, rv: str) -> t.Any:
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        if self.path_type is None or self.path_type is str:
            return rv
        return self.path_type(rv)

    def convert(self, value, param, ctx):
        ctx = ctx if ctx is not None else _current_ctx()
        if isinstance(value, pathlib.PurePath):
            value = str(value)
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if self.allow_dash and value == "-":
            return self._deliver("-")
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(os.path.abspath(rv))
        try:
            st = os.stat(rv)
        except OSError:
            st = None
        if st is None:
            if self.exists:
                self.fail(f"{format_filename(value)!r} does not exist.", param, ctx)
            return self._deliver(rv)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{format_filename(value)!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{format_filename(value)!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{format_filename(value)!r} is not executable.", param, ctx)
        return self._deliver(rv)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (not self.file_okay and self.dir_okay) else "file"
        return [CompletionItem(incomplete, None, kind)]


# Ready-made instances.
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BUILTIN = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


# spec: N-000370–N-000374 (custom and function types)
def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Return a ParamType for ``ty``; infer one from ``default`` when ``ty`` is None."""
    if ty is None:
        return infer_type(default)
    if isinstance(ty, ParamType):
        return ty
    if ty in _BUILTIN:
        return _BUILTIN[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")


# spec: N-000182–N-000187 (type inferred from default)
def infer_type(default: t.Any) -> ParamType:
    """Infer the type from a default value (STRING when nothing applies)."""
    if default is None or callable(default):
        return STRING
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)):
        return infer_type(default[0]) if default else STRING
    return STRING
