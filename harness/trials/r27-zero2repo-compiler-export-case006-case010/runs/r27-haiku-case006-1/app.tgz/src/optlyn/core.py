"""Core model: invocation contexts, parameters, the argument parser, and commands/groups."""

from __future__ import annotations

import difflib
import enum
import inspect
import os
import shutil
import sys
import typing as t
from contextlib import ExitStack

from . import _state
from . import termui
from .exceptions import (
    OptlynError,
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    UsageError,
)
from .formatting import wrap_text, write_definition_list
from .param_types import BOOL, INT, Tuple, ParamType, convert_type


class _Missing:
    """Sentinel: no value was supplied from a source."""

    def __repr__(self) -> str:
        return "MISSING"


MISSING: t.Any = _Missing()
_FLAG_MARK = object()  # an optional-value option was given without a value
_PROMPT_MARK = object()  # a prompting option was given without a value

PREFIX_CHARS = ("-", "/", "+")
DEFAULT_MAX_CONTENT_WIDTH = 80
DEFAULT_HELP_OPTION_NAMES = ["--help"]
TRUE_VALUES = ("1", "true", "t", "yes", "y", "on")
FALSE_VALUES = ("0", "false", "f", "no", "n", "off")


class ParameterSource(enum.Enum):
    """Where a parameter's value came from (see ``Context.get_parameter_source``)."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Lower rank = more explicit. Used to pick the winner of a feature-switch group.
SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}


def _clean_help(text: str, explicit: bool) -> str:
    if explicit:
        text = text.replace("\f", "")
    else:
        text = text.split("\f", 1)[0]
    return inspect.cleandoc(text)


# spec: N-000434–N-000443 (context chain, author object), N-000950–N-000980 (context members)
class Context:
    """The per-invocation state: parsed values, linkage to parents, settings and resources."""

    def __init__(
        self,
        command: "Command",
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        auto_envvar_prefix: t.Optional[str] = None,
        default_map: t.Optional[t.Mapping[str, t.Any]] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        help_option_names: t.Optional[t.Sequence[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        allow_extra_args: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        resilient_parsing: bool = False,
        **extra: t.Any,
    ) -> None:
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params: t.Dict[str, t.Any] = {}
        self.args: t.List[str] = []
        self.protected_args: t.List[str] = []
        self.invoked_subcommand: t.Any = None
        self.extra = extra
        self.resilient_parsing = resilient_parsing
        self._sources: t.Dict[str, ParameterSource] = {}
        self._dest_rank: t.Dict[str, tuple] = {}
        self._exit_stack = ExitStack()
        self._depth = 0

        if parent is not None:
            if obj is None:
                obj = parent.obj
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if auto_envvar_prefix is None and parent.auto_envvar_prefix is not None and info_name:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
            if default_map is None and isinstance(parent.default_map, dict) and info_name is not None:
                default_map = parent.default_map.get(info_name)

        self.obj = obj
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width if max_content_width is not None else DEFAULT_MAX_CONTENT_WIDTH
        self.help_option_names = list(help_option_names) if help_option_names is not None else list(DEFAULT_HELP_OPTION_NAMES)
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default)
        self.allow_extra_args = command.allow_extra_args if allow_extra_args is None else bool(allow_extra_args)
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None else bool(allow_interspersed_args)
        )
        self.ignore_unknown_options = bool(ignore_unknown_options)

    # -- activation -------------------------------------------------------

    def __enter__(self) -> "Context":
        self._depth += 1
        _state.push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb) -> None:
        self._depth -= 1
        _state.pop_context()
        if self._depth == 0:
            self.close()

    # spec: N-000467, N-000482–N-000483 (resources closed when the invocation ends)
    def close(self) -> None:
        """Run the close callbacks registered on this context (files, resources)."""
        stack = self._exit_stack
        self._exit_stack = ExitStack()
        stack.close()

    def call_on_close(self, f: t.Callable[[], t.Any]) -> t.Callable[[], t.Any]:
        self._exit_stack.callback(f)
        return f

    def with_resource(self, cm: t.ContextManager) -> t.Any:
        """Enter ``cm`` now; it is exited when this context closes."""
        return self._exit_stack.enter_context(cm)

    # -- tree -------------------------------------------------------------

    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}".strip()
        return rv

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: t.Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    # -- control ----------------------------------------------------------

    def fail(self, message: str) -> t.NoReturn:
        raise UsageError(message, self)

    def abort(self) -> t.NoReturn:
        raise Abort()

    # spec: N-000716–N-000718 (author clean stop with a status)
    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    # spec: N-000471–N-000476 (invoke and forward another command)
    def invoke(self, callback: t.Any, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Call a callable, or run a command, from inside this context."""
        if isinstance(callback, Command):
            other = callback
            func = other.callback
            sub = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.default_for_invoke(sub)
            ctx = sub
        else:
            func = callback
            ctx = self
        with ctx:
            if func is None:
                return None
            return func(*args, **kwargs)

    def forward(self, cmd: "Command", **kwargs: t.Any) -> t.Any:
        """Run ``cmd`` with this context's values, overridden by ``kwargs``."""
        return self.invoke(cmd, **{**self.params, **kwargs})

    # -- lookups ----------------------------------------------------------

    # spec: N-000450–N-000462 (default map; an entry for another subcommand does not apply)
    def lookup_default(self, name: str, call: bool = True) -> t.Any:
        if not isinstance(self.default_map, dict) or name not in self.default_map:
            return MISSING
        value = self.default_map[name]
        if call and callable(value):
            value = value()
        return value

    # spec: N-000463–N-000466 (five distinct sources; undeclared name has none)
    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        if name not in {p.name for p in self.command.get_params(self)}:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    # spec: N-000133–N-000138 (wrap width; max content width caps auto-detected width only)
    def get_wrap_width(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        detected = shutil.get_terminal_size(fallback=(80, 24)).columns
        return max(min(detected, self.max_content_width) - 2, 10)

    def __repr__(self) -> str:
        return f"<Context {self.command_path!r}>"


# spec: N-000921–N-000923 (parameter objects expose name and metavar)
class Parameter:
    """Common behaviour of options and arguments."""

    param_type_name = "parameter"
    is_flag = False
    count = False
    optional_value = False
    flag_value: t.Any = None
    prompt: t.Any = False
    prompt_required = False
    hide_input = False
    confirmation_prompt = False
    show_envvar = False
    _auto_default = False

    def __init__(
        self,
        name: str,
        opts: t.Sequence[str] = (),
        secondary_opts: t.Sequence[str] = (),
        type: t.Any = None,
        required: bool = False,
        default: t.Any = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        nargs: t.Optional[int] = None,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
        deprecated: t.Any = False,
        hidden: bool = False,
        help: t.Optional[str] = None,
        show_default: t.Any = None,
        allow_from_autoenv: bool = True,
    ) -> None:
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary_opts)
        self.required = required
        self.default = default
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar: t.Optional[t.List[str]] = list(envvar) if envvar is not None else None
        self._shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.show_default = show_default
        self.allow_from_autoenv = allow_from_autoenv
        self.nargs = 1 if nargs is None else nargs
        if self.nargs == 0 or self.nargs < -1:
            raise ValueError("nargs must be a positive integer, or -1 for a variadic parameter.")
        self.type: ParamType = convert_type(type, default)
        if isinstance(self.type, Tuple) and nargs is None:
            self.nargs = len(self.type.types)
        if self.multiple and self.nargs == -1:
            raise ValueError("A variadic parameter cannot also be repeatable.")

    @property
    def variadic(self) -> bool:
        return self.nargs == -1

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        raise NotImplementedError

    def make_metavar(self) -> t.Optional[str]:
        if self.metavar is not None:
            return self.metavar
        if isinstance(self.type, Tuple):
            return self.type.get_metavar(self)
        tm = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs == -1:
            return f"{tm}..."
        if self.nargs != 1:
            return " ".join([tm] * self.nargs)
        return tm

    def get_default(self, ctx: t.Optional[Context]) -> t.Any:
        d = self.default
        if callable(d):
            d = d()
        if d is None:
            return MISSING
        if self.multiple and not isinstance(d, (list, tuple)):
            raise BadParameter("option needs an iterable (sequence) default.", ctx=ctx, param=self)
        return d

    def default_for_invoke(self, ctx: Context) -> t.Any:
        d = self.get_default(ctx)
        if d is MISSING:
            return self._empty_value()
        return self.type_cast_value(ctx, d)

    def _empty_value(self) -> t.Any:
        if self.multiple or self.variadic:
            return ()
        return None

    # -- value sources ----------------------------------------------------

    def _env_names(self, ctx: Context) -> t.List[str]:
        names = list(self.envvar or [])
        return names

    # spec: N-000227–N-000233 (env values: first set wins; empty means unset; split for repeatable)
    def value_from_envvar(self, ctx: Context) -> t.Any:
        names = self._env_names(ctx)
        raw: t.Any = MISSING
        for name in names:
            value = os.environ.get(name)
            if value:
                raw = value
                break
        if raw is MISSING:
            return MISSING
        if self.is_flag:
            return self._flag_from_env(raw)
        if self.count:
            return MISSING
        if self.multiple or self.nargs != 1 or isinstance(self.type, Tuple):
            tokens = self.type.split_envvar_value(raw)
            if self.multiple:
                return _chunk(tokens, self.nargs)
            return tuple(tokens)
        return raw

    # spec: N-000234–N-000242 (boolean flag environment values)
    def _flag_from_env(self, value: str) -> t.Any:
        stripped = value.strip()
        if not isinstance(self.flag_value, bool) and value == str(self.flag_value):
            return self.flag_value
        if not stripped:
            return False
        low = stripped.lower()
        if low in TRUE_VALUES:
            return self.flag_value
        if low in FALSE_VALUES:
            return False
        if isinstance(self.flag_value, bool):
            raise BadParameter(f"{value!r} is not a valid boolean.", param=self)
        return MISSING

    # spec: N-000450–N-000462 (default-map strings split only when arity is not one)
    def _from_default_map(self, value: t.Any, ctx: Context) -> t.Any:
        if isinstance(value, str) and (self.nargs != 1 or isinstance(self.type, Tuple)):
            tokens = self.type.split_envvar_value(value)
            if self.multiple:
                return _chunk(tokens, self.nargs)
            return tuple(tokens)
        if isinstance(value, str) and self.multiple:
            raise BadParameter("option needs an iterable (sequence) default.", ctx=ctx, param=self)
        return value

    def _prompt_value(self, ctx: Context, default: t.Any) -> t.Any:
        return None  # overridden by Option

    # -- conversion and processing ----------------------------------------

    def _cast_occurrence(self, ctx: Context, occ: t.Any) -> t.Any:
        if isinstance(self.type, Tuple):
            return self.type.convert(occ, self, ctx)
        if self.nargs == 1 and not self.variadic:
            return self.type.convert(occ, self, ctx)
        if isinstance(occ, (str, bytes)):
            occ = (occ,)
        return tuple(self.type.convert(x, self, ctx) for x in occ)

    def type_cast_value(self, ctx: Context, raw: t.Any) -> t.Any:
        if self.is_flag or self.count:
            return raw
        if self.multiple:
            if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple)):
                raw = [raw]
            return tuple(self._cast_occurrence(ctx, occ) for occ in raw)
        return self._cast_occurrence(ctx, raw)

    def run_callback(self, ctx: Context, value: t.Any) -> t.Any:
        if self.callback is None:
            return value
        try:
            return self.callback(ctx, self, value)
        except BadParameter as e:
            if e.ctx is None:
                e.ctx = ctx
            if e.param is None:
                e.param = self
            raise

    def warn_deprecated(self) -> None:
        label = self.opts[0] if self.opts else self.name
        kind = self.param_type_name
        message = f"DeprecationWarning: The {kind} '{label}' is deprecated."
        if isinstance(self.deprecated, str):
            message += " " + self.deprecated
        termui.echo(message, err=True)

    def gather(self, ctx: Context, parser: "_Parser") -> t.Tuple[t.Any, t.Optional[ParameterSource]]:
        raise NotImplementedError

    # spec: N-000250–N-000267 (callbacks; refusal is usage error; deprecation only when supplied)
    def handle_parse_result(self, ctx: Context, parser: "_Parser") -> t.Tuple[t.Any, t.Optional[ParameterSource]]:
        raw, source = self.gather(ctx, parser)
        if raw is MISSING:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self)
            value = self._empty_value()
            source = None
        elif source is ParameterSource.PROMPT:
            value = raw
            if self.multiple:
                value = (raw,)
        else:
            value = self.type_cast_value(ctx, raw)
        if self.deprecated and source is ParameterSource.COMMANDLINE:
            self.warn_deprecated()
        value = self.run_callback(ctx, value)
        return value, source

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


def _chunk(tokens: t.Sequence[str], n: int) -> t.List[t.Any]:
    if n == 1:
        return list(tokens)
    return [tuple(tokens[i : i + n]) for i in range(0, len(tokens), n)]


# spec: N-000881–N-000883, N-000226, N-000188–N-000195 (prefixes, on/off pairs, destination names)
def _split_decls(decls: t.Sequence[str]) -> t.Tuple[t.List[str], t.List[str], t.Optional[str]]:
    opts: t.List[str] = []
    secondary: t.List[str] = []
    name: t.Optional[str] = None
    for decl in decls:
        if not decl:
            continue
        if decl[0] in PREFIX_CHARS:
            idx = decl.find("/", 1)
            if idx > 0:
                opts.append(decl[:idx])
                secondary.append(decl[idx + 1 :])
            else:
                opts.append(decl)
        else:
            if name is not None:
                raise TypeError(f"Name '{name}' defined twice.")
            name = decl
    return opts, secondary, name


# spec: N-000178–N-000225 (options: flags, counts, repeatable, nargs, optional value)
class Option(Parameter):
    """A named parameter introduced by a prefix character (``-``, ``--``, ``/``, ``+``)."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Optional[t.Sequence[str]] = None,
        show_default: t.Any = None,
        prompt: t.Any = False,
        confirmation_prompt: bool = False,
        prompt_required: t.Optional[bool] = None,
        hide_input: bool = False,
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        multiple: bool = False,
        count: bool = False,
        allow_from_autoenv: bool = True,
        type: t.Any = None,
        help: t.Optional[str] = None,
        hidden: bool = False,
        show_choices: bool = True,
        show_envvar: bool = False,
        deprecated: t.Any = False,
        required: bool = False,
        default: t.Any = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        nargs: t.Optional[int] = None,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
        name: t.Optional[str] = None,
    ) -> None:
        opts, secondary, dest = _split_decls(tuple(param_decls or ()))
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        if dest is None:
            longs = [o for o in opts if len(o) > 1 and o[1] == o[0]]
            base = (longs or opts)[0]
            dest = base.lstrip("".join(PREFIX_CHARS)).replace("-", "_")
        if name is not None:
            dest = name
        if is_flag is None:
            is_flag = bool(count or secondary)
        if count:
            is_flag = True
        if deprecated and required:
            raise ValueError("A deprecated option cannot also be required.")
        if deprecated and prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        if is_flag and secondary:
            flag_value = True
        auto_default = False
        if is_flag:
            if flag_value is None:
                flag_value = True
            if default is None and not count:
                default = False
                auto_default = True
            if count:
                if default is None:
                    default = 0
                if type is None:
                    type = INT
            elif type is None:
                type = BOOL
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.optional_value = (not self.is_flag) and flag_value is not None
        self.prompt = prompt
        if prompt:
            if prompt_required is None:
                prompt_required = True
            if required:
                prompt_required = True
        self.prompt_required = bool(prompt_required) if prompt_required is not None else False
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_choices = show_choices
        self.show_envvar = show_envvar
        super().__init__(
            dest,
            opts=opts,
            secondary_opts=secondary,
            type=type,
            required=required,
            default=default,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
            help=help,
            show_default=show_default,
            allow_from_autoenv=allow_from_autoenv,
        )
        self._auto_default = auto_default
        if self.is_flag and self.nargs != 1:
            raise ValueError("A flag takes no values.")

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        return " / ".join(f"'{o}'" for o in self.opts)

    def _env_names(self, ctx: Context) -> t.List[str]:
        names = list(self.envvar or [])
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None and not self.count:
            auto = f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_")
            names.append(auto)
        return names

    def _prompt_value(self, ctx: Context, default: t.Any) -> t.Any:
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if callable(default):
            default = default()
        return termui.prompt(
            text,
            default=None if default is MISSING else default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda v: self._cast_occurrence(ctx, v),
            show_default=bool(self.show_default) if self.show_default is not None else True,
        )

    def _flag_result(self, secondary: bool) -> t.Any:
        if self.count:
            return 1
        if secondary:
            return False
        return self.flag_value

    def gather(self, ctx: Context, parser: "_Parser") -> t.Tuple[t.Any, t.Optional[ParameterSource]]:
        # spec: N-000243–N-000245, N-000246–N-000249 (value source precedence and feature-switch groups)
        prompt_marker = False
        info = parser.seen.get(self)
        if info is not None:
            values = info["values"]
            if self.count:
                return sum(values), ParameterSource.COMMANDLINE
            if self.multiple:
                if any(v is _PROMPT_MARK for v in values):
                    prompt_marker = True
                cooked = [self.flag_value if v is _FLAG_MARK else v for v in values if v is not _PROMPT_MARK]
                if cooked:
                    return cooked, ParameterSource.COMMANDLINE
            else:
                last = values[-1]
                if last is _PROMPT_MARK:
                    prompt_marker = True
                elif last is _FLAG_MARK:
                    return self.flag_value, ParameterSource.COMMANDLINE
                else:
                    return last, ParameterSource.COMMANDLINE

        env = self.value_from_envvar(ctx)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT

        default_map = ctx.lookup_default(self.name)
        if self.prompt and (self.prompt_required or prompt_marker):
            dflt = default_map if default_map is not MISSING else self.get_default(ctx)
            return self._prompt_value(ctx, dflt), ParameterSource.PROMPT

        if default_map is not MISSING:
            return self._from_default_map(default_map, ctx), ParameterSource.DEFAULT_MAP
        return self.get_default(ctx), ParameterSource.DEFAULT

    def get_help_record(self, ctx: Context) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden:
            return None
        first = ", ".join(self.opts)
        if self.secondary_opts:
            first = f"{', '.join(self.opts)} / {', '.join(self.secondary_opts)}"
        if not self.is_flag:
            mv = self.make_metavar()
            if mv:
                first += " " + mv
        # spec: N-000146–N-000151, N-000152 (show-default, env var display, deprecation mark)
        parts: t.List[str] = []
        if self.deprecated:
            parts.append("(Deprecated)")
        if self.help:
            parts.append(self.help)
        show_default = self.show_default if self.show_default is not None else ctx.show_default
        if show_default:
            if isinstance(show_default, str):
                parts.append(f"[default: {show_default}]")
            else:
                dflt = self.default
                if callable(dflt):
                    dflt_text = "(dynamic)"
                elif dflt is None or (self.is_flag and dflt is False and not self.count):
                    dflt_text = None
                elif isinstance(dflt, (list, tuple)):
                    dflt_text = ", ".join(str(x) for x in dflt)
                else:
                    dflt_text = str(dflt)
                if dflt_text:
                    parts.append(f"[default: {dflt_text}]")
        if self.show_envvar and self.envvar:
            parts.append(f"[env var: {', '.join(self.envvar)}]")
        return first, " ".join(parts)


# spec: N-000285–N-000329 (positional arguments)
class Argument(Parameter):
    """A positional parameter. Tokens bind to arguments in declaration order."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: t.Optional[t.Sequence[str]] = None,
        required: t.Optional[bool] = None,
        type: t.Any = None,
        default: t.Any = None,
        nargs: t.Optional[int] = None,
        envvar: t.Any = None,
        deprecated: t.Any = False,
        help: t.Optional[str] = None,
        metavar: t.Optional[str] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        hidden: bool = False,
        name: t.Optional[str] = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
        multiple: bool = False,
        show_default: t.Any = None,
    ) -> None:
        decls = [d for d in (param_decls or ()) if d]
        dest = name
        if dest is None:
            if len(decls) != 1:
                raise TypeError("An argument takes exactly one destination name.")
            dest = decls[0]
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise ValueError("A deprecated argument cannot be required.")
        super().__init__(
            dest,
            type=type,
            required=required,
            default=default,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
            help=help,
            show_default=show_default,
            allow_from_autoenv=False,
        )

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        return f"'{self.name}'"

    def make_usage_piece(self) -> str:
        placeholder = self.metavar or self.name.upper()
        core = placeholder if self.required else f"[{placeholder}]"
        if self.variadic:
            core += "..."
        return core

    def gather(self, ctx: Context, parser: "_Parser") -> t.Tuple[t.Any, t.Optional[ParameterSource]]:
        tokens = parser.arg_values.get(self, MISSING)
        if tokens is not MISSING and not (self.variadic and not tokens):
            if self.nargs == 1 and not self.variadic:
                return tokens, ParameterSource.COMMANDLINE
            return tuple(tokens), ParameterSource.COMMANDLINE
        env = self.value_from_envvar(ctx)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT
        if self.default is not None:
            return self._from_default_map(self.get_default(ctx), ctx), ParameterSource.DEFAULT
        return MISSING, None

    def get_help_record(self, ctx: Context) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden or not self.help:
            return None
        return (self.metavar or self.name.upper()), self.help


# spec: N-000188–N-000199, N-000268–N-000274, N-000283–N-000284 (tokens, stacking, unknown options)
class _Parser:
    """Splits a token list into option values and positional tokens."""

    def __init__(self, ctx: Context, params: t.Sequence[Parameter]) -> None:
        self.ctx = ctx
        self.params = params
        self.opt_map: t.Dict[str, t.Tuple[Option, bool]] = {}
        self.prefixes = {"-"}
        for p in params:
            if isinstance(p, Option):
                for name in p.opts:
                    self._add(name, p, False)
                for name in p.secondary_opts:
                    self._add(name, p, True)
        self.allow_interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        self.seen: t.Dict[Parameter, dict] = {}
        self.counter = 0
        self.arg_values: t.Dict[Parameter, t.Any] = {}

    def _add(self, name: str, p: Option, secondary: bool) -> None:
        self.opt_map[name] = (p, secondary)
        self.prefixes.add(name[0])

    def is_option_like(self, tok: str) -> bool:
        return len(tok) > 1 and tok[0] in self.prefixes

    def _record(self, param: Parameter, value: t.Any) -> None:
        info = self.seen.get(param)
        if info is None:
            info = self.seen[param] = {"first": self.counter, "values": []}
        self.counter += 1
        info["values"].append(value)

    def _flag_result(self, hit: t.Tuple[Option, bool]) -> t.Any:
        param, secondary = hit
        return param._flag_result(secondary)

    def _take_value(self, param: Option, rargs: t.List[str], inline: t.Optional[str], name: str) -> t.Any:
        if param.nargs > 1:
            tokens: t.List[str] = []
            if inline is not None:
                tokens.append(inline)
            while len(tokens) < param.nargs and rargs:
                tokens.append(rargs.pop(0))
            if len(tokens) < param.nargs:
                raise BadOptionUsage(
                    f"Option {param.get_error_hint(self.ctx)} requires {param.nargs} arguments.", self.ctx
                )
            return tuple(tokens)
        if inline is not None:
            return inline
        if param.optional_value:
            if rargs and not self.is_option_like(rargs[0]):
                return rargs.pop(0)
            return _FLAG_MARK
        if rargs:
            return rargs.pop(0)
        if param.prompt:
            return _PROMPT_MARK
        raise BadOptionUsage(f"Option {param.get_error_hint(self.ctx)} requires an argument.", self.ctx)

    def _apply(self, hit: t.Tuple[Option, bool], name: str, inline: t.Optional[str], rargs: t.List[str]) -> None:
        param, secondary = hit
        if param.is_flag:
            if inline is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            self._record(param, self._flag_result(hit))
            return
        self._record(param, self._take_value(param, rargs, inline, name))

    def _no_such(self, name: str) -> NoSuchOption:
        close = difflib.get_close_matches(name, list(self.opt_map), n=3, cutoff=0.6)
        return NoSuchOption(name, possibilities=close, ctx=self.ctx)

    def _handle(self, tok: str, rargs: t.List[str], largs: t.List[t.Tuple[str, bool]]) -> None:
        hit = self.opt_map.get(tok)
        if hit is not None:
            self._apply(hit, tok, None, rargs)
            return
        if "=" in tok:
            name, _, inline = tok.partition("=")
            hit = self.opt_map.get(name)
            if hit is not None:
                self._apply(hit, name, inline, rargs)
                return
        prefix = tok[0]
        if len(tok) > 1 and tok[1] == prefix:
            if self.ignore_unknown:
                largs.append((tok, False))
                return
            raise self._no_such(tok.split("=", 1)[0])
        chars = tok[1:]
        i = 0
        while i < len(chars):
            name = prefix + chars[i]
            hit = self.opt_map.get(name)
            if hit is None:
                if self.ignore_unknown:
                    largs.append((prefix + chars[i:], False))
                    return
                raise self._no_such(name)
            if hit[0].is_flag:
                self._record(hit[0], self._flag_result(hit))
                i += 1
                continue
            rest = chars[i + 1 :]
            self._apply(hit, name, rest if rest else None, rargs)
            return

    # spec: N-000196–N-000199, N-000304–N-000306 (leaf mixing vs group, and the -- terminator)
    def parse(self, args: t.Sequence[str]) -> t.List[t.Tuple[str, bool]]:
        rargs = list(args)
        largs: t.List[t.Tuple[str, bool]] = []
        while rargs:
            tok = rargs.pop(0)
            if tok == "--":
                largs.extend((x, True) for x in rargs)
                rargs = []
                break
            if self.is_option_like(tok):
                self._handle(tok, rargs, largs)
                continue
            largs.append((tok, False))
            if not self.allow_interspersed:
                largs.extend((x, False) for x in rargs)
                rargs = []
                break
        return largs

    # spec: N-000291–N-000303 (positional binding; variadic once; too few tokens)
    def bind_arguments(
        self, tokens: t.List[t.Tuple[str, bool]], arguments: t.Sequence[Argument]
    ) -> t.List[t.Tuple[str, bool]]:
        pos = 0
        for idx, arg in enumerate(arguments):
            later_required = sum(a.nargs for a in arguments[idx + 1 :] if a.required and a.nargs > 0)
            avail = len(tokens) - pos - later_required
            if arg.variadic:
                take = max(avail, 0)
                self.arg_values[arg] = [x for x, _ in tokens[pos : pos + take]]
                pos += take
            elif avail <= 0:
                continue
            elif arg.nargs == 1:
                self.arg_values[arg] = tokens[pos][0]
                pos += 1
            else:
                if avail < arg.nargs:
                    raise BadArgumentUsage(
                        f"Argument '{arg.name}' takes {arg.nargs} values but got {avail}.", self.ctx
                    )
                self.arg_values[arg] = tuple(x for x, _ in tokens[pos : pos + arg.nargs])
                pos += arg.nargs
        return tokens[pos:]


def _expand_windows_args(args: t.List[str]) -> t.List[str]:
    """On Windows the shell does not expand globs, '~' or environment variables."""
    import glob

    out: t.List[str] = []
    for arg in args:
        arg = os.path.expanduser(os.path.expandvars(arg))
        if any(ch in arg for ch in "*?["):
            matches = sorted(glob.glob(arg))
            if matches:
                out.extend(matches)
                continue
        out.append(arg)
    return out


# spec: N-000110–N-000113 (help prints and exits 0, callback not run)
def _help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color, nl=False)
    ctx.exit()


# spec: N-000850–N-000861 (command instance)
class Command:
    """A leaf command: parses its slice of the command line and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(
        self,
        name: t.Optional[str],
        context_settings: t.Optional[t.Dict[str, t.Any]] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        params: t.Optional[t.List[Parameter]] = None,
        help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: t.Any = False,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        if help is not None:
            self.help: t.Optional[str] = _clean_help(help, explicit=True)
        elif callback is not None and callback.__doc__:
            self.help = _clean_help(callback.__doc__, explicit=False)
        else:
            self.help = None
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    # -- declarations -----------------------------------------------------

    # spec: N-000153–N-000161, N-000176–N-000177 (help names; author-declared overlap; disabled help)
    def get_help_option(self, ctx: Context) -> t.Optional[Option]:
        if not self.add_help_option or not ctx.help_option_names:
            return None
        declared = set()
        for p in self.params:
            if isinstance(p, Option):
                declared.update(p.opts)
                declared.update(p.secondary_opts)
        names = [n for n in ctx.help_option_names if n not in declared]
        if not names:
            return None
        return Option(
            names,
            is_flag=True,
            expose_value=False,
            is_eager=True,
            help="Show this message and exit.",
            callback=_help_callback,
        )

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        rv = list(self.params)
        help_opt = self.get_help_option(ctx)
        if help_opt is not None:
            rv.append(help_opt)
        return rv

    # -- running ----------------------------------------------------------

    # spec: N-000854–N-000860 (main), N-000716–N-000735 (exit classes)
    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run the command as a program (or in-process when ``standalone_mode`` is off)."""
        windows_expand = bool(extra.pop("windows_expand_args", True))
        args = list(sys.argv[1:] if args is None else args)
        if args is not None and os.name == "nt" and windows_expand and sys.argv[1:] == args:
            args = _expand_windows_args(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "main") or "main"
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import handle_completion

            handle_completion(self, prog_name, complete_var, instruction)
            sys.exit(0)

        try:
            with self.make_context(prog_name, args, **extra) as ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo(file=sys.stderr)
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except OSError as e:
            if not standalone_mode:
                raise
            import errno

            if e.errno == errno.EPIPE:
                sys.exit(1)
            raise
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        return None

    # spec: N-000854–N-000860 (context made from settings and tokens)
    def make_context(self, info_name: t.Optional[str], args: t.Sequence[str], parent: t.Optional[Context] = None, **extra: t.Any) -> Context:
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        _state.push_context(ctx)
        try:
            self.parse_args(ctx, list(args))
        except BaseException:
            # Parsing failed: release whatever was opened while parsing.
            _state.pop_context()
            ctx.close()
            raise
        _state.pop_context()
        return ctx

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        # spec: N-000170–N-000175, N-000406–N-000410 (no-args-is-help is a usage failure)
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx=ctx, message="No arguments given.")
        params = self.get_params(ctx)
        parser = _Parser(ctx, params)
        largs = parser.parse(args)
        arguments = [p for p in params if isinstance(p, Argument)]
        leftover = parser.bind_arguments(largs, arguments)
        self._process_params(ctx, params, parser)
        rest = [tok for tok, _ in leftover]
        if rest:
            if not ctx.allow_extra_args:
                ctx.fail(f"Got unexpected extra argument{'s' if len(rest) > 1 else ''} ({' '.join(rest)})")
            if ctx.allow_interspersed_args and not ctx.ignore_unknown_options:
                for tok, literal in leftover:
                    if not literal and parser.is_option_like(tok):
                        ctx.fail(f"Got unexpected extra argument ({tok})")
        ctx.args = rest
        return rest

    def _process_params(self, ctx: Context, params: t.List[Parameter], parser: _Parser) -> None:
        def order(item: t.Tuple[int, Parameter]) -> tuple:
            index, param = item
            info = parser.seen.get(param)
            first = info["first"] if info is not None else 10**9
            return (0 if param.is_eager else 1, first, index)

        for index, param in sorted(enumerate(params), key=order):
            value, source = param.handle_parse_result(ctx, parser)
            if not param.expose_value:
                continue
            rank = (
                SOURCE_RANK[source] if source is not None else 9,
                1 if param._auto_default and source is ParameterSource.DEFAULT else 0,
                -index,
            )
            prev = ctx._dest_rank.get(param.name)
            if prev is None or rank < prev:
                ctx.params[param.name] = value
                ctx._sources[param.name] = source or ParameterSource.DEFAULT
                ctx._dest_rank[param.name] = rank

    def invoke(self, ctx: Context) -> t.Any:
        if self.deprecated:
            message = f"DeprecationWarning: The command '{self.name}' is deprecated."
            if isinstance(self.deprecated, str):
                message += " " + self.deprecated
            termui.echo(message, err=True)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    # -- help -------------------------------------------------------------

    # spec: N-000122–N-000124 (short help: first sentence, cut at 45 characters)
    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help:
            text = self.short_help
        else:
            text = self.help or ""
            first_para = text.strip().split("\n\n")[0]
            flat = " ".join(first_para.split())
            sentence_end = None
            for i, ch in enumerate(flat):
                if ch in ".!?" and (i + 1 == len(flat) or flat[i + 1] == " "):
                    sentence_end = i + 1
                    break
            text = flat[:sentence_end] if sentence_end else flat
        if len(text) > limit:
            text = text[: limit - 3].rstrip() + "..."
        return text

    def collect_usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces: t.List[str] = []
        if self.options_metavar:
            pieces.extend(self.options_metavar.split())
        for p in self.get_params(ctx):
            if isinstance(p, Argument) and not p.hidden:
                pieces.append(p.make_usage_piece())
        return pieces

    def get_usage(self, ctx: Context) -> str:
        pieces = self.collect_usage_pieces(ctx)
        return " ".join(["Usage: " + ctx.command_path] + pieces)

    def get_help(self, ctx: Context) -> str:
        return self.format_help(ctx)

    # spec: N-000827–N-000845 (help page layout and order)
    def format_help(self, ctx: Context) -> str:
        width = ctx.get_wrap_width()
        sections: t.List[str] = [ctx.get_usage()]
        description = self.help or ""
        if self.deprecated:
            description = "(Deprecated) " + description if description else "(Deprecated)"
        if description:
            sections.append(wrap_text(description, width=width))
        params = self.get_params(ctx)
        arg_rows = [
            (p.metavar or p.name.upper(), p.help)
            for p in params
            if isinstance(p, Argument) and not p.hidden and p.help
        ]
        if arg_rows:
            sections.append("Positional arguments:\n" + "\n".join(write_definition_list(arg_rows, width)))
        opt_rows = [r for r in (p.get_help_record(ctx) for p in params if isinstance(p, Option)) if r]
        sections.append("Options:\n" + "\n".join(write_definition_list(opt_rows, width)))
        cmd_section = self._format_commands(ctx, width)
        if cmd_section:
            sections.append(cmd_section)
        if self.epilog:
            sections.append(wrap_text(self.epilog, width=width))
        return "\n\n".join(sections) + "\n"

    def _format_commands(self, ctx: Context, width: int) -> t.Optional[str]:
        return None


# spec: N-000388–N-000433 (groups, nesting, lazy loading, chaining refusals)
class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable[..., t.Any]] = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        if commands is None:
            commands = {}
        elif isinstance(commands, list):
            commands = {c.name: c for c in commands}
        self.commands: t.Dict[str, Command] = dict(commands)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    # -- children ---------------------------------------------------------

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        name = name or cmd.name
        # spec: N-000869–N-000871, N-000612–N-000614 (no group beneath a chaining group)
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("A group cannot be attached beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        from .decorators import command as _command

        if args and callable(args[0]) and not isinstance(args[0], Command):
            cmd = _command()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f: t.Callable[..., t.Any]) -> Command:
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        from .decorators import group as _group

        if args and callable(args[0]) and not isinstance(args[0], Command):
            cmd = _group()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f: t.Callable[..., t.Any]) -> Group:
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self) -> t.Callable[[t.Callable[..., t.Any]], t.Callable[..., t.Any]]:
        def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    # spec: N-000429–N-000432 (unknown subcommand is a usage error)
    def resolve_command(self, ctx: Context, args: t.List[str]) -> t.Tuple[str, Command, t.List[str]]:
        cmd_name = args[0]
        cmd = self.get_command(ctx, cmd_name)
        normalize = ctx.token_normalize_func
        if cmd is None and normalize is not None:
            wanted = normalize(cmd_name)
            for name in self.list_commands(ctx):
                if normalize(name) == wanted:
                    cmd_name = name
                    cmd = self.get_command(ctx, name)
                    break
        if cmd is None:
            ctx.fail(f"No such command '{cmd_name}'.")
        return cmd_name, cmd, list(args[1:])

    # -- running ----------------------------------------------------------

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        rest = super().parse_args(ctx, args)
        ctx.protected_args = list(rest)
        ctx.args = []
        return rest

    def _process_result(self, ctx: Context, value: t.Any) -> t.Any:
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, value, **ctx.params)
        return value

    def invoke(self, ctx: Context) -> t.Any:
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                value = super().invoke(ctx)
                return self._process_result(ctx, value)
            ctx.fail("Missing command.")
        args = list(ctx.protected_args)
        ctx.protected_args = []
        cmd_name, cmd, rest = self.resolve_command(ctx, args)
        ctx.invoked_subcommand = cmd_name
        super().invoke(ctx)
        sub_ctx = cmd.make_context(cmd_name, rest, parent=ctx)
        with sub_ctx:
            value = sub_ctx.command.invoke(sub_ctx)
        return self._process_result(ctx, value)

    # spec: N-000593–N-000608 (chaining: order, result callback, return list)
    def _invoke_chain(self, ctx: Context) -> t.List[t.Any]:
        args = list(ctx.protected_args)
        ctx.protected_args = []
        if not args and not self.invoke_without_command:
            ctx.fail("Missing command.")
        ctx.invoked_subcommand = "*" if args else None
        super().invoke(ctx)
        contexts: t.List[Context] = []
        try:
            while args:
                cmd_name, cmd, rest = self.resolve_command(ctx, args)
                sub = cmd.make_context(
                    cmd_name, rest, parent=ctx, allow_extra_args=True, allow_interspersed_args=False
                )
                contexts.append(sub)
                args = list(sub.args)
                sub.args = []
        except BaseException:
            for sub in contexts:
                sub.close()
            raise
        results: t.List[t.Any] = []
        for sub in contexts:
            with sub:
                results.append(sub.command.invoke(sub))
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results

    # -- help -------------------------------------------------------------

    def _visible_commands(self, ctx: Context) -> t.List[t.Tuple[str, Command]]:
        out = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None and not cmd.hidden:
                out.append((name, cmd))
        return out

    def collect_usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces = super().collect_usage_pieces(ctx)
        lead = "[COMMAND]" if self.invoke_without_command else "COMMAND"
        pieces.append(f"{lead} [ARGS]...")
        if self.chain:
            pieces.append("[COMMAND [ARGS]...]...")
        return pieces

    def _format_commands(self, ctx: Context, width: int) -> t.Optional[str]:
        rows = []
        for name, cmd in self._visible_commands(ctx):
            short = cmd.get_short_help_str(limit=45)
            if cmd.deprecated:
                short = ("(Deprecated) " + short).strip()
            rows.append((name, short))
        if not rows:
            return None
        return "Commands:\n" + "\n".join(write_definition_list(rows, width))


# spec: N-000422–N-000425, N-000878–N-000880 (union of source groups)
class CommandCollection(Group):
    """A group that presents the subcommands of several source groups together."""

    def __init__(self, name: t.Optional[str] = None, sources: t.Optional[t.List[Group]] = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names: t.Set[str] = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
