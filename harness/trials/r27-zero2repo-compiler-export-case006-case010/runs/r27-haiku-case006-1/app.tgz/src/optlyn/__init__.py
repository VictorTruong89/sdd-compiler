"""Optlyn: a composable command line interface toolkit (pure Python, no dependencies)."""

from __future__ import annotations

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .param_types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, get_app_dir, open_file
from ._state import get_current_context

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "Argument",
    "ParamType", "BadParameter", "Abort", "ParameterSource", "UsageError", "OptlynError",
    "FileError", "MissingParameter", "NoSuchOption", "BadOptionUsage", "BadArgumentUsage", "Exit",
    # parameter types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
]
