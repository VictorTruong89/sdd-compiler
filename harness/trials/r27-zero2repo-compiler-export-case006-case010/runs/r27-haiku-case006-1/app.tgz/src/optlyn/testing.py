"""In-process runner: invoke a command with argument tokens and capture its output."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t

from .exceptions import OptlynError


# spec: N-001038–N-001044, N-000739–N-000740 (runner result fields)
class Result:
    """The outcome of ``CliRunner.invoke``."""

    def __init__(
        self,
        chunks: t.List[t.Tuple[str, bytes]],
        charset: str,
        exit_code: int,
        exception: t.Optional[BaseException],
        exc_info: t.Any = None,
    ) -> None:
        self._chunks = chunks
        self._charset = charset
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _channel(self, name: str) -> bytes:
        return b"".join(data for ch, data in self._chunks if ch == name)

    @property
    def stdout_bytes(self) -> bytes:
        return self._channel("stdout")

    @property
    def stderr_bytes(self) -> bytes:
        return self._channel("stderr")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self._charset, "replace")

    @property
    def output(self) -> str:
        return b"".join(data for _, data in self._chunks).decode(self._charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


# spec: N-000751–N-000755 (default capture: interpreter streams, order kept)
class _CapturedStream(io.TextIOBase):
    """A text stream that records every write, in order, into a shared log."""

    def __init__(self, channel: str, log: t.List[t.Tuple[str, bytes]], charset: str) -> None:
        self._channel = channel
        self._log = log
        self._charset = charset
        self.buffer = _CapturedBuffer(channel, log)

    @property
    def encoding(self) -> str:
        return self._charset

    def write(self, s: str) -> int:
        self._log.append((self._channel, s.encode(self._charset, "backslashreplace")))
        return len(s)

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class _CapturedBuffer(io.BufferedIOBase):
    def __init__(self, channel: str, log: t.List[t.Tuple[str, bytes]]) -> None:
        self._channel = channel
        self._log = log

    def write(self, b: t.Any) -> int:
        data = bytes(b)
        self._log.append((self._channel, data))
        return len(data)

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


# spec: N-000748–N-000750 (input echo)
class _EchoingStdin(io.TextIOWrapper):
    """Standard input that echoes every read into the captured output."""

    _optlyn_echo_reads = True

    def __init__(self, buffer: t.Any, charset: str, log: t.List[t.Tuple[str, bytes]]) -> None:
        super().__init__(buffer, encoding=charset)
        self._log = log
        self._cs = charset

    def _echo(self, text: str) -> None:
        if text:
            self._log.append(("stdout", text.encode(self._cs, "backslashreplace")))

    def readline(self, *args: t.Any) -> str:
        line = super().readline(*args)
        self._echo(line)
        return line

    def read(self, *args: t.Any) -> str:
        data = super().read(*args)
        self._echo(data)
        return data


# spec: N-001038–N-001044, N-000742–N-000743, N-000756–N-000761 (runner)
class CliRunner:
    """Invoke a command in-process, capturing standard streams and the exit status."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: t.Any) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input: t.Any = None, env: t.Optional[t.Mapping[str, t.Optional[str]]] = None):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        log: t.List[t.Tuple[str, bytes]] = []
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        env_all = dict(self.env)
        if env:
            env_all.update(env)
        saved_env: t.Dict[str, t.Optional[str]] = {}
        for key, value in env_all.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        stdin_obj = io.BufferedReader(io.BytesIO(data))
        if self.echo_stdin:
            sys.stdin = _EchoingStdin(stdin_obj, self.charset, log)
        else:
            sys.stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
        if self.capture == "sys":
            sys.stdout = _CapturedStream("stdout", log, self.charset)
            sys.stderr = _CapturedStream("stderr", log, self.charset)
            try:
                yield log
            finally:
                sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
                self._restore_env(saved_env)
        else:
            with tempfile.TemporaryFile() as out_f, tempfile.TemporaryFile() as err_f:
                for s in (old_stdout, old_stderr):
                    with contextlib.suppress(Exception):
                        s.flush()
                saved_fds = (os.dup(1), os.dup(2))
                os.dup2(out_f.fileno(), 1)
                os.dup2(err_f.fileno(), 2)
                sys.stdout = io.TextIOWrapper(open(os.dup(1), "wb"), encoding=self.charset, line_buffering=True)
                sys.stderr = io.TextIOWrapper(open(os.dup(2), "wb"), encoding=self.charset, line_buffering=True)
                try:
                    yield log
                finally:
                    sys.stdout.flush()
                    sys.stderr.flush()
                    sys.stdout.close()
                    sys.stderr.close()
                    os.dup2(saved_fds[0], 1)
                    os.dup2(saved_fds[1], 2)
                    os.close(saved_fds[0])
                    os.close(saved_fds[1])
                    sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
                    out_f.seek(0)
                    err_f.seek(0)
                    log.append(("stdout", out_f.read()))
                    log.append(("stderr", err_f.read()))
                    self._restore_env(saved_env)

    @staticmethod
    def _restore_env(saved: t.Dict[str, t.Optional[str]]) -> None:
        for key, value in saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def invoke(
        self,
        cli: t.Any,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        """Run ``cli`` with the argument tokens ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        extra.setdefault("color", color)
        extra.setdefault("prog_name", self.get_default_prog_name(cli))
        exit_code = 0
        exception: t.Optional[BaseException] = None
        exc_info = None
        with self.isolation(input=input, env=env) as log:
            try:
                cli.main(args=list(args or []), **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
                if exit_code != 0:
                    exception = e
                exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = e.exit_code if isinstance(e, OptlynError) else 1
                exc_info = sys.exc_info()
        return Result(log, self.charset, exit_code, exception, exc_info)

    @contextlib.contextmanager
    # spec: N-000744–N-000747, N-000762–N-000763 (isolated filesystem)
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None):
        """Change into a new empty directory for the duration of the block."""
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
