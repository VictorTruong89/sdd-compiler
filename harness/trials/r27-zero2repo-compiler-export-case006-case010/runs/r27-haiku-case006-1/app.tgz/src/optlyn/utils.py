"""File helpers, application directories, filename formatting and launching."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
import typing as t

from .exceptions import FileError

# Text wrappers around the standard streams must stay alive: if one were
# garbage collected it would close the underlying buffer.
_KEEP_ALIVE: list = []


# spec: N-000588–N-000590, N-000546–N-000547, N-000648 (standard streams not closed)
class _NonClosing:
    """Proxy for a standard stream: closing it only flushes it."""

    def __init__(self, stream: t.Any) -> None:
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.flush()

    def close(self) -> None:
        self._stream.flush()

    def __repr__(self) -> str:
        return f"<optlyn non-closing {self._stream!r}>"


# spec: N-000538–N-000545 (atomic write replaces target on close)
class _AtomicFile:
    """Writes to a sibling temporary file; the target is replaced on close."""

    def __init__(self, path: str, mode: str, encoding: t.Optional[str], errors: t.Optional[str]) -> None:
        directory = os.path.dirname(os.path.abspath(path))
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-atomic-", suffix=".tmp")
        if "b" in mode:
            self._f = os.fdopen(fd, mode)
        else:
            self._f = os.fdopen(fd, mode, encoding=encoding, errors=errors)
        self._tmp = tmp
        self._path = path
        self._closed = False

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def __enter__(self):
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._path)


def _std_stream(mode: str, encoding: t.Optional[str], errors: t.Optional[str]) -> t.Any:
    writing = "w" in mode
    base = sys.stdout if writing else sys.stdin
    binary = "b" in mode
    if binary:
        stream = getattr(base, "buffer", base)
    elif encoding is not None:
        buffer = getattr(base, "buffer", None)
        if buffer is None:
            stream = base
        else:
            from io import TextIOWrapper

            stream = TextIOWrapper(buffer, encoding=encoding, errors=errors or "strict")
            _KEEP_ALIVE.append(stream)
    else:
        stream = base
    return _NonClosing(stream)


def _open_real(filename: str, mode: str, encoding: t.Optional[str], errors: t.Optional[str], atomic: bool) -> t.Any:
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    if atomic and "w" in mode:
        return _AtomicFile(filename, mode, encoding, errors)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors or "strict")


# spec: N-000532–N-000545, N-000578–N-000582 (lazy open on first I/O)
class LazyFile:
    """A file that is opened on first I/O rather than when it is created."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: t.Optional[str] = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f: t.Any = None

    def _open(self) -> t.Any:
        if self._f is None:
            try:
                self._f = _open_real(self.name, self.mode, self._encoding, self._errors, self._atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, name: str) -> t.Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __next__(self):
        return next(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._f is not None:
            self._f.close()

    def __repr__(self) -> str:
        return f"<LazyFile {self.name!r} mode={self.mode!r}>"


# spec: N-000532–N-000545, N-000667 (open helper; '-' is stdin or stdout)
def open_file(
    filename: str,
    mode: str = "r",
    encoding: t.Optional[str] = None,
    errors: t.Optional[str] = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or a standard stream when ``filename`` is ``-``.

    Opens immediately unless ``lazy`` is true. Errors from an immediate open
    are raised as ``OSError``.
    """
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


# spec: N-000674–N-000678 (per-user config directory)
def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)


# spec: N-000575–N-000577 (printable, strict UTF-8, names stay distinct)
def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Turn a (possibly non-Unicode) path into printable, strict-UTF-8 text.

    Undecodable bytes are written as ``\\xNN`` escapes so that different
    names remain different.
    """
    raw = os.fspath(filename)
    if isinstance(raw, str):
        raw = os.fsencode(raw)
    if shorten:
        raw = os.path.basename(raw)
    return raw.decode("utf-8", "backslashreplace")


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` (or a path) with the default application."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        cmd = ["open"] + (["-R"] if locate else [])
    else:
        cmd = ["xdg-open"]
    exe = shutil.which(cmd[0])
    if exe is None:
        return 127
    proc = subprocess.Popen([exe] + cmd[1:] + [url])
    if wait:
        return proc.wait()
    return 0
