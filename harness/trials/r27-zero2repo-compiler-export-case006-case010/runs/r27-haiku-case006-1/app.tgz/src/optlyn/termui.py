"""Terminal helpers: echo, styling, prompts, pager, progress, editor, and friends."""

from __future__ import annotations

import contextlib
import os
import re
import shlex
import subprocess
import shutil
import sys
import tempfile
import time
import typing as t

from ._state import get_current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLORS = {
    "black": 0, "red": 1, "green": 2, "yellow": 3, "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
    "bright_black": 8, "bright_red": 9, "bright_green": 10, "bright_yellow": 11,
    "bright_blue": 12, "bright_magenta": 13, "bright_cyan": 14, "bright_white": 15,
}


def _is_tty(stream: t.Any) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def _is_interactive() -> bool:
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _stdin_echoes() -> bool:
    return bool(getattr(sys.stdin, "_optlyn_echo_reads", False))


def _current_color() -> t.Optional[bool]:
    ctx = get_current_context(silent=True)
    return getattr(ctx, "color", None) if ctx is not None else None


# spec: N-000628–N-000640 (unstyle)
def unstyle(text: str) -> str:
    """Remove ANSI style sequences, leaving the other text."""
    return _ANSI_RE.sub("", text)


def _write(file: t.Any, text: str) -> None:
    enc = (getattr(file, "encoding", None) or "").lower()
    if enc in ("ascii", "us-ascii", "ansi_x3.4-1968"):
        buffer = getattr(file, "buffer", None)
        file.flush()
        data = text.encode("utf-8")
        if buffer is not None:
            buffer.write(data)
            buffer.flush()
        else:
            file.write(data.decode("ascii", "backslashreplace"))
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        file.write(text.encode(enc or "utf-8", "backslashreplace").decode(enc or "utf-8"))


# spec: N-000619–N-000627, N-000681–N-000683 (echo, styles kept only on terminal or when forced)
def echo(
    message: t.Any = None,
    file: t.Optional[t.Any] = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
) -> None:
    """Write ``message`` (text or bytes) to stdout, stderr, or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        if nl:
            message = bytes(message) + b"\n"
        buffer = getattr(file, "buffer", file)
        file.flush()
        buffer.write(bytes(message))
        buffer.flush()
        return
    if not isinstance(message, str):
        message = str(message)
    if nl:
        message += "\n"
    if color is None:
        color = _current_color()
    keep = color if color is not None else _is_tty(file)
    if not keep:
        message = unstyle(message)
    _write(file, message)
    file.flush()


# spec: N-000628–N-000640 (styling; invalid colours raise)
def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: t.Optional[bool] = None,
    dim: t.Optional[bool] = None,
    underline: t.Optional[bool] = None,
    overline: t.Optional[bool] = None,
    italic: t.Optional[bool] = None,
    blink: t.Optional[bool] = None,
    reverse: t.Optional[bool] = None,
    strikethrough: t.Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences."""
    bits: t.List[str] = []
    if fg is not None:
        bits.append(_color_code(fg, background=False))
    if bg is not None:
        bits.append(_color_code(bg, background=True))
    for flag, code in (
        (bold, "1"), (dim, "2"), (italic, "3"), (underline, "4"), (blink, "5"),
        (reverse, "7"), (strikethrough, "9"), (overline, "53"),
    ):
        if flag:
            bits.append(code)
    if not isinstance(text, str):
        text = str(text)
    if bits:
        text = f"\x1b[{';'.join(bits)}m{text}"
    if reset:
        text += "\x1b[0m"
    return text


def _color_code(color: t.Any, background: bool) -> str:
    base = 40 if background else 30
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, str):
        name = color.lower()
        if name == "reset":
            return str(base + 9)
        if name in _COLORS:
            idx = _COLORS[name]
            code = base + idx if idx < 8 else base + 60 + (idx - 8)
            return str(code)
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{base + 8};5;{color}"
        raise TypeError(f"Color {color!r} out of range.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base + 8};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Unknown color {color!r}.")


def secho(
    message: t.Any = None,
    file: t.Optional[t.Any] = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
    **styles: t.Any,
) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _read_line(hide: bool = False) -> str:
    stream = sys.stdin
    if stream is None:
        raise Abort()
    if hide and _is_tty(stream):
        import getpass

        try:
            line = getpass.getpass("")
        except EOFError as e:
            raise Abort() from e
        return line
    line = stream.readline()
    if not line:
        raise Abort()
    return line.rstrip("\r\n")


def _echo_input(line: str, err: bool) -> None:
    if not _stdin_echoes() and not _is_tty(sys.stdin):
        echo(line, err=err)


# spec: N-000488–N-000491, N-000520–N-000522, N-000510–N-000512 (prompts, re-ask, hidden input)
def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Optional[t.Callable[[str], t.Any]] = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
) -> t.Any:
    """Ask for a value on standard input, converting it; re-ask until valid."""
    from .param_types import convert_type

    ptype = convert_type(type, default if not callable(default) else None)
    ctx = get_current_context(silent=True)

    def ask(question: str, dflt: t.Any) -> str:
        shown = ""
        if show_default and dflt is not None and not hide_input and not callable(dflt):
            shown = f" [{dflt}]"
        echo(f"{question}{shown}{prompt_suffix}", nl=False, err=err)
        line = _read_line(hide_input)
        if not hide_input:
            _echo_input(line, err)
        return line

    while True:
        dflt = default() if callable(default) else default
        answer = ask(text, dflt)
        if answer == "":
            if dflt is None:
                continue  # no default: an empty line is asked again
            answer_value = dflt
        else:
            answer_value = answer
        try:
            if value_proc is not None:
                value = value_proc(answer_value)
            else:
                value = ptype.convert(answer_value, None, ctx)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue
        if confirmation_prompt:
            second = ask("Repeat for confirmation", None)
            if second != answer:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return value


# spec: N-000501–N-000509, N-000524 (confirm answers; EOF aborts)
def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question; raise Abort on end of input or on a declined abort."""
    shown = "[Y/n]" if default else "[y/N]"
    question = f"{text} {shown}" if show_default else text
    while True:
        echo(question + prompt_suffix, nl=False, err=err)
        line = _read_line(False)
        _echo_input(line, err)
        answer = line.strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if not result and abort:
        raise Abort()
    return result


# spec: N-000658–N-000661 (single character; interrupt and EOF distinct)
def getchar(echo: bool = False) -> str:
    """Read one character from the controlling terminal (or standard input)."""
    fd = None
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        fd = None
    data: bytes
    if fd is None:
        ch = sys.stdin.read(1)
        if not ch:
            raise EOFError()
        data = ch.encode("utf-8")
    else:
        try:
            import termios
            import tty

            try:
                old = termios.tcgetattr(fd)
            except termios.error:
                old = None
            try:
                if old is not None:
                    tty.setraw(fd)
                data = os.read(fd, 1)
            finally:
                if old is not None:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    if data in (b"\x03",):
        raise KeyboardInterrupt()
    if data in (b"\x04", b""):
        raise EOFError()
    text = data.decode("utf-8", "replace")
    if echo:
        _echo_text(text)
    return text


def _echo_text(text: str) -> None:
    echo(text, nl=False)


# spec: N-000662–N-000663, N-000686–N-000687 (pause; never blocks when not interactive)
def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Print a message and wait for a key press when the session is interactive."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    if _is_interactive():
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    echo("", err=err)


def _pager_command() -> t.Optional[t.List[str]]:
    cmd = os.environ.get("PAGER") or "less"
    parts = shlex.split(cmd)
    if not parts or shutil.which(parts[0]) is None:
        return None
    return parts


# spec: N-000641–N-000648 (pager output, flushed per chunk)
def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    """Write long text through a pager when the session is interactive."""
    gen = text_or_generator() if callable(text_or_generator) and not isinstance(text_or_generator, str) else text_or_generator
    chunks = [gen] if isinstance(gen, str) else gen
    if not _is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    cmd = _pager_command()
    if cmd is None:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            text = chunk if color else unstyle(chunk)
            proc.stdin.write(text.encode("utf-8"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        with contextlib.suppress(BrokenPipeError):
            proc.stdin.close()
        proc.wait()


class _PagerWriter:
    def __init__(self, proc: t.Any, color: t.Optional[bool]) -> None:
        self._proc = proc
        self._color = color

    def write(self, text: str) -> int:
        data = (text if self._color else unstyle(text)).encode("utf-8")
        self._proc.stdin.write(data)
        self._proc.stdin.flush()
        return len(text)

    def flush(self) -> None:
        self._proc.stdin.flush()


@contextlib.contextmanager
def get_pager_file(color: t.Optional[bool] = None):
    """Context manager yielding a writable text stream that goes through the pager."""
    cmd = _pager_command() if _is_interactive() else None
    if cmd is None:
        from .utils import _NonClosing

        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        yield _PagerWriter(proc, color)
    finally:
        with contextlib.suppress(BrokenPipeError):
            proc.stdin.close()
        proc.wait()


def _format_eta(seconds: float) -> str:
    seconds = int(max(seconds, 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


# spec: N-000649–N-000657, N-000684–N-000685 (progress bar; visits every item)
class ProgressBar:
    """A progress bar that is also an iterator over the wrapped items."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self._begun = False
        self._finished = False
        self.is_tty = (not hidden) and _is_tty(sys.stdout)

    def _begin(self) -> None:
        if self._begun:
            return
        self._begun = True
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label)

    def __enter__(self) -> "ProgressBar":
        self._begin()
        return self

    def __exit__(self, *exc) -> None:
        self.finish()

    def __iter__(self):
        self._begin()
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        self.finish()

    def update(self, n_steps: int) -> None:
        self.pos += n_steps
        self._render()

    def _render(self) -> None:
        if not self.is_tty:
            return
        elapsed = time.time() - self.start
        if self.length:
            pct = min(self.pos / self.length, 1.0)
            filled = int(pct * 30)
            bar = "#" * filled + "-" * (30 - filled)
            eta = (elapsed / pct - elapsed) if pct > 0 else 0
            line = f"{self.label} [{bar}] {self.pos}/{self.length}  eta {_format_eta(eta)}"
        else:
            line = f"{self.label} {self.pos}  elapsed {_format_eta(elapsed)}"
        sys.stdout.write("\r" + line)
        sys.stdout.flush()

    def finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        if self.is_tty:
            sys.stdout.write("\n")
            sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options) -> ProgressBar:
    """Return a progress bar wrapping ``iterable`` (or a bar of ``length`` steps)."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# spec: N-000664–N-000666 (editor on text or filename)
def edit(
    text: t.Optional[str] = None,
    editor: t.Optional[str] = None,
    env: t.Optional[t.Mapping[str, str]] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Optional[str] = None,
) -> t.Optional[str]:
    """Open an editor on text or on a file; return the saved text (or None)."""
    env_all = dict(os.environ)
    if env:
        env_all.update(env)
    if editor is None:
        editor = env_all.get("VISUAL") or env_all.get("EDITOR")
    if not editor:
        editor = "notepad" if os.name == "nt" else "vi"
    if filename is not None:
        subprocess.call(shlex.split(editor) + [filename], env=env_all)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        original = (text or "").replace("\r\n", "\n")
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(original)
        subprocess.call(shlex.split(editor) + [path], env=env_all)
        with open(path, encoding="utf-8") as f:
            result = f.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


# spec: N-000667–N-000671 (launch with default opener)
def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    from .utils import launch as _launch

    return _launch(url, wait=wait, locate=locate)


# spec: N-000672–N-000673 (screen clear)
def clear() -> None:
    """Clear the visible terminal; does nothing when not on a terminal."""
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[1;1H")
    sys.stdout.flush()
