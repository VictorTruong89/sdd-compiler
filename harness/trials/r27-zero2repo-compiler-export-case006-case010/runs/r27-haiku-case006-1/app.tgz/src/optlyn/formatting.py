"""Text wrapping and definition-list layout used by help pages."""

from __future__ import annotations

import re
import textwrap
import typing as t

DEFAULT_WRAP_WIDTH = 100


# spec: N-000133–N-000138, N-000679–N-000680 (rewrapping, backspace paragraphs)
def wrap_text(
    text: str,
    width: int = DEFAULT_WRAP_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is a lone backspace is kept verbatim (its backspace line is
    dropped).
    """
    if not text:
        return ""
    width = max(width, 1)
    out: t.List[str] = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = para.split("\n")
        if lines and lines[0].strip("\n") in ("\b", "\x08"):
            kept = [ln.rstrip() for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln if i == 0 else subsequent_indent + ln for i, ln in enumerate(kept)))
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            continue
        out.append(
            textwrap.fill(
                flat,
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(out)


# spec: N-000837–N-000841 (option entries contiguous, name first)
def write_definition_list(rows: t.Sequence[t.Tuple[str, str]], width: int, indent: int = 2, max_first: int = 30) -> t.List[str]:
    """Lay out ``(first, help)`` pairs as an indented two-column list."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), max_first)
    col = first_width + 2
    lines: t.List[str] = []
    help_width = max(width - indent - col, 20)
    for first, second in rows:
        pad = " " * indent
        if not second:
            lines.append(pad + first)
            continue
        helpful = wrap_text(second, width=help_width).split("\n")
        if len(first) <= first_width:
            lines.append(pad + first.ljust(col) + helpful[0])
            rest = helpful[1:]
        else:
            lines.append(pad + first)
            rest = helpful
        for ln in rest:
            lines.append(pad + " " * col + ln)
    return lines
