"""Exceptions raised by Optlyn, and the exit classes they map to."""

from __future__ import annotations

import sys
import typing as t

if t.TYPE_CHECKING:  # pragma: no cover
    from .core import Context, Parameter


class OptlynError(Exception):
    """Base class for errors Optlyn reports to the user (general error class)."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.format_message()}\n")
        file.flush()

    def __str__(self) -> str:
        return self.message


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class, exit 1)."""

    exit_code = 1

    def __init__(self, filename: str, hint: str) -> None:
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.ui_filename = filename
        self.hint = hint


class Exit(RuntimeError):
    """Raised by ``Context.exit``: an author clean stop with a status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class Abort(RuntimeError):
    """Abort class (exit 1): declined confirmation, EOF, interrupt, author abort."""


class UsageError(OptlynError):
    """A usage failure (exit status 2)."""

    exit_code = 2

    def __init__(self, message: str, ctx: t.Optional["Context"] = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            file.write(self.ctx.get_usage() + "\n")
            if self.ctx.command.get_help_option(self.ctx) is not None:
                name = self.ctx.help_option_names[0]
                file.write(f"Try '{self.ctx.command_path} {name}' for help.\n")
            file.write("\n")
        file.write(f"Error: {self.format_message()}\n")
        file.flush()


class BadParameter(UsageError):
    """A value was refused: bad conversion, failed check, refusing callback."""

    def __init__(
        self,
        message: str,
        ctx: t.Optional["Context"] = None,
        param: t.Optional["Parameter"] = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(
        self,
        message: str = "",
        ctx: t.Optional["Context"] = None,
        param: t.Optional["Parameter"] = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx, param, param_hint)

    def format_message(self) -> str:
        hint = None
        kind = "parameter"
        if self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
            kind = self.param.param_type_name
        return f"Missing {kind} {hint or ''}".rstrip() + "."


class NoSuchOption(UsageError):
    """An option token that matches no declared option."""

    def __init__(
        self,
        option_name: str,
        message: t.Optional[str] = None,
        possibilities: t.Optional[t.Sequence[str]] = None,
        ctx: t.Optional["Context"] = None,
    ) -> None:
        if message is None:
            message = f"No such option: {option_name}"
            if possibilities:
                if len(possibilities) == 1:
                    message += f" Did you mean {possibilities[0]}?"
                else:
                    message += " Did you mean one of " + ", ".join(possibilities) + "?"
        super().__init__(message, ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly (for example too few tokens)."""


class NoArgsIsHelp(UsageError):
    """Help shown because no arguments were given (usage failure, exit 2)."""

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            file.write(self.ctx.get_help())
        file.flush()
