"""Declaration decorators: command, group, option, argument and the ready-made options."""

from __future__ import annotations

import functools
import importlib.metadata
import sys
import typing as t

from . import termui
from ._state import get_current_context
from .core import Argument, Command, Context, Group, Option, Parameter
from .exceptions import Abort

F = t.TypeVar("F", bound=t.Callable[..., t.Any])


def _attach_param(f: t.Any, param: Parameter) -> None:
    params = f.__dict__.get("__optlyn_params__")
    if params is None:
        params = []
        f.__optlyn_params__ = params
    params.append(param)


def _take_params(f: t.Any) -> t.List[Parameter]:
    """Move declarations attached to ``f`` out of it, in declaration order."""
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    del f.__optlyn_params__
    return list(reversed(params))


def _default_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


# spec: N-000850–N-000853, N-000079–N-000082 (declaration and naming)
def command(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a ``Command`` (use as ``@command()`` or ``@command``)."""
    if cls is None:
        cls = Command
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f: t.Callable[..., t.Any]) -> Command:
        params = _take_params(f)
        cmd_name = name if name is not None else _default_name(f.__name__)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


# spec: N-000862–N-000864 (group declaration)
def group(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a ``Group`` (use as ``@group()`` or ``@group``)."""
    if cls is None:
        cls = Group
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f: t.Callable[..., t.Any]) -> Group:
        params = _take_params(f)
        grp_name = name if name is not None else _default_name(f.__name__)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


# spec: N-000881–N-000884 (option declaration)
def option(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable[[F], F]:
    """Attach an option to the function beneath the decorator."""
    if cls is None:
        cls = Option

    def decorator(f: F) -> F:
        _attach_param(f, cls(param_decls, **attrs))
        return f

    return decorator


# spec: N-000910–N-000912 (argument declaration)
def argument(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable[[F], F]:
    """Attach a positional argument to the function beneath the decorator."""
    if cls is None:
        cls = Argument

    def decorator(f: F) -> F:
        _attach_param(f, cls(param_decls, **attrs))
        return f

    return decorator


# -- ready-made options -------------------------------------------------------


def _decorate(opt: Option) -> t.Callable[[F], F]:
    """Return a decorator that attaches the prepared option to the function."""

    def decorator(f: F) -> F:
        _attach_param(f, opt)
        return f

    return decorator


def _show_help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color, nl=False)
    ctx.exit()


# spec: N-000929 (extra help option)
def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """An extra eager help flag (the automatic one is always present too)."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return _decorate(Option(param_decls, **kwargs))


def _caller_module(depth: int = 2) -> t.Optional[str]:
    try:
        return sys._getframe(depth).f_globals.get("__name__")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        return None


# spec: N-000162–N-000169 (installed distribution; a module's own version is not consulted)
def _detect_version(package_name: str) -> str:
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        mapping = importlib.metadata.packages_distributions()
    except Exception:  # pragma: no cover - very old metadata backends
        mapping = {}
    for dist_name in mapping.get(package_name, []):
        try:
            return importlib.metadata.version(dist_name)
        except importlib.metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not determine the version of {package_name!r}.")


# spec: N-000930–N-000931, N-000162–N-000169 (version flag, eager)
def version_option(
    version: t.Optional[str] = None,
    *param_decls: str,
    package_name: t.Optional[str] = None,
    prog_name: t.Optional[str] = None,
    message: t.Optional[str] = None,
    **kwargs: t.Any,
) -> t.Callable[[F], F]:
    """An eager ``--version`` flag that prints the version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        package_name = _caller_module(2)
    if message is None:
        message = "%(prog)s, version %(version)s"

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name
        if prog is None:
            prog = ctx.find_root().info_name
        ver = version
        if ver is None:
            ver = _detect_version(package_name or "")
        termui.echo(message % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return _decorate(Option(param_decls, **kwargs))


# spec: N-000932, N-000168–N-000169 (callback identity printed as-is)
def custom_version_option(callback_fn: t.Callable[[Context], str], *param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """An eager version flag whose whole identity is the string ``callback_fn(ctx)`` returns."""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        termui.echo(callback_fn(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return _decorate(Option(param_decls, **kwargs))


# spec: N-000924–N-000928, N-000484–N-000487 (password option)
def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """A prompting, hidden-input, confirmed option."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return _decorate(Option(param_decls, **kwargs))


# spec: N-000513–N-000519 (confirmation option)
def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """A yes-style flag that asks for confirmation when omitted; declining aborts."""
    if not param_decls:
        param_decls = ("--yes",)
    question = kwargs.pop("prompt", None) or "Do you want to continue?"

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if value or ctx.resilient_parsing:
            return
        if not termui.confirm(question):
            raise Abort()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback
    return _decorate(Option(param_decls, **kwargs))


# -- callback decorators -------------------------------------------------------


# spec: N-000434–N-000443 (current context passed to callback)
def pass_context(f: F) -> F:
    """Pass the current ``Context`` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return t.cast(F, new_func)


def pass_obj(f: F) -> F:
    """Pass the current context's ``obj`` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return t.cast(F, new_func)


# spec: N-000434–N-000443 (nearest object of a type; ensure creates one)
def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable[[F], F]:
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f: F) -> F:
        @functools.wraps(f)
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return ctx.invoke(f, obj, *args, **kwargs)

        return t.cast(F, new_func)

    return decorator
