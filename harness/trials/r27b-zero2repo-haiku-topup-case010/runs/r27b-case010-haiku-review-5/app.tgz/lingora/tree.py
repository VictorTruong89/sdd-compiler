"""Constituent trees (FP-05)."""

import re

__all__ = ["Tree"]

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled ordered tree. Children are leaves (e.g. ``str``) or ``Tree`` nodes."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or children is None:
            raise TypeError(
                "Tree children must be a list of children, not %s" % type(children).__name__
            )
        if not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text such as ``(S (NP I) (VP sleep))``."""
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring expects str")
        toks = _TOKEN_RE.findall(s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(toks) or toks[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(toks) or toks[pos] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text")
            label = toks[pos]
            pos += 1
            children = []
            while pos < len(toks) and toks[pos] != ")":
                if toks[pos] == "(":
                    children.append(parse_node())
                else:
                    children.append(toks[pos])
                    pos += 1
            if pos >= len(toks):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            pos += 1  # consume ')'
            return cls(label, children)

        tree = parse_node()
        if pos != len(toks):
            raise ValueError("trailing text after bracketed tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        parts = [str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child.pformat())
            elif isinstance(child, tuple) and len(child) == 2:
                parts.append("%s/%s" % (child[0], child[1]))
            else:
                parts.append(str(child))
        return "(" + " ".join(parts) + ")"

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()
