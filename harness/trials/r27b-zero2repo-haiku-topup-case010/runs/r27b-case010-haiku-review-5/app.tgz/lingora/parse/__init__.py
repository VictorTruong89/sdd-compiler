"""Parsers over context-free grammars (FP-05)."""

from lingora.tree import Tree
from lingora.grammar import Nonterminal

__all__ = ["ChartParser", "ShiftReduceParser"]

_MAX_SHIFT_REDUCE_STEPS = 100000


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str):
        raise TypeError("parse expects a list of tokens, not a str")
    tokens = list(tokens)
    known = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str, got %r" % (tok,))
        if tok not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % tok)
    return tokens


class ChartParser:
    """Exhaustive parser: returns every parse tree the grammar assigns to the tokens."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        memo = {}
        active = set()
        grammar = self._grammar

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, str):
                if i < j and tokens[i] == sym:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [sym] + rest
                return
            for m in range(i, j + 1):
                for sub in trees(sym, i, m):
                    for rest in seq(rhs, k + 1, m, j):
                        yield [sub] + rest

        def trees(sym, i, j):
            key = (str(sym), i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            results = []
            for prod in grammar.productions(sym if isinstance(sym, Nonterminal) else Nonterminal(sym)):
                for children in seq(prod.rhs(), 0, i, j):
                    results.append(Tree(str(prod.lhs()), children))
            active.discard(key)
            memo[key] = results
            return results

        return iter(list(trees(grammar.start(), 0, len(tokens))))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        grammar = self._grammar
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        start = str(grammar.start())
        stack = []
        remaining = list(tokens)
        pos = 0
        steps = 0

        def matches(item, sym):
            if isinstance(sym, str):
                return isinstance(item, str) and item == sym
            return isinstance(item, Tree) and item.label() == str(sym)

        while steps < _MAX_SHIFT_REDUCE_STEPS:
            steps += 1
            reduced = False
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if len(stack) < k:
                    continue
                top = stack[len(stack) - k:]
                if all(matches(item, sym) for item, sym in zip(top, rhs)):
                    children = list(top)
                    del stack[len(stack) - k:]
                    stack.append(Tree(str(prod.lhs()), children))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(remaining):
                stack.append(remaining[pos])
                pos += 1
            else:
                break

        if pos == len(remaining) and len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])
