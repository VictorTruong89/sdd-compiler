"""Sentence generation from a context-free grammar (FP-05)."""

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal tokens) derivable from ``start``.

    Productions are expanded in their written order. ``depth`` bounds the
    derivation depth (``None`` for no bound); ``n`` bounds the number of
    sentences produced (``None`` for no limit). A quoted empty string
    contributes an empty-string token; an empty production contributes none.
    """
    if n is not None and n <= 0:
        return
    if start is None:
        start_sym = grammar.start()
    elif isinstance(start, Nonterminal):
        start_sym = start
    else:
        start_sym = Nonterminal(str(start))

    # Each form is a list of items: ('t', terminal) or ('n', nonterminal, level).
    stack = [[("n", start_sym, 0)]]
    produced = 0
    while stack:
        form = stack.pop()
        idx = None
        for k, item in enumerate(form):
            if item[0] == "n":
                idx = k
                break
        if idx is None:
            yield [item[1] for item in form]
            produced += 1
            if n is not None and produced >= n:
                return
            continue
        _, nt, level = form[idx]
        if depth is not None and level >= depth:
            continue
        expansions = []
        for prod in grammar.productions(nt):
            items = [
                ("t", sym) if isinstance(sym, str) else ("n", sym, level + 1)
                for sym in prod.rhs()
            ]
            expansions.append(form[:idx] + items + form[idx + 1:])
        stack.extend(reversed(expansions))
