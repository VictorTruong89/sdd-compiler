"""BLEU score (FP-07)."""

import math
from collections import Counter

__all__ = ["bleu", "add_one_smoothing"]

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def add_one_smoothing(counts):
    """Add-one smoothing: ``counts`` is a list of ``(matches, total)`` per order."""
    return [(m + 1) / (t + 1) for m, t in counts]


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU (Papineni et al., 2002) of ``hypothesis`` against ``references``.

    ``references`` is a list of token lists and ``hypothesis`` a token list.
    ``weights`` gives one weight per n-gram order from unigrams; the default is
    equal weights on unigrams through 4-grams. Without ``smoothing_function``
    the score is 0 whenever a weighted order has no match. A smoothing function
    takes the list of ``(matches, total)`` pairs and returns one precision per order.
    """
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    weights = tuple(_DEFAULT_WEIGHTS if weights is None else weights)
    if not references:
        raise ValueError("bleu needs at least one reference")
    if not hypothesis:
        return 0.0

    counts = []
    for n in range(1, len(weights) + 1):
        cand = Counter(_ngrams(hypothesis, n))
        total = sum(cand.values())
        max_ref = Counter()
        for ref in references:
            ref_counts = Counter(_ngrams(ref, n))
            for gram in cand:
                if ref_counts[gram] > max_ref[gram]:
                    max_ref[gram] = ref_counts[gram]
        matches = sum(min(c, max_ref[g]) for g, c in cand.items())
        counts.append((matches, total))

    if smoothing_function is not None:
        precisions = list(smoothing_function(counts))
    else:
        precisions = [m / t if t > 0 else 0.0 for m, t in counts]

    score = 0.0
    for w, p in zip(weights, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        score += w * math.log(p)
    score = math.exp(score)

    c = len(hypothesis)
    r = min((len(ref) for ref in references), key=lambda rl: (abs(rl - c), rl))
    if c > r:
        bp = 1.0
    else:
        bp = math.exp(1 - r / c)
    return bp * score
