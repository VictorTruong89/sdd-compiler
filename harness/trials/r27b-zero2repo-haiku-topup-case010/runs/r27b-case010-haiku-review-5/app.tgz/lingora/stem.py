"""Stemmers (FP-02)."""

import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]


# ---------------------------------------------------------------------------
# Porter (default mode: LINGORA extensions)
# ---------------------------------------------------------------------------

_PORTER_IRREGULAR = {
    "skis": "ski",
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "idly": "idl",
    "gently": "gentl",
    "ugly": "ugli",
    "early": "earli",
    "only": "onli",
    "singly": "singl",
    "sky": "sky",
    "news": "news",
    "howe": "howe",
    "atlas": "atlas",
    "cosmos": "cosmos",
    "bias": "bias",
    "andes": "andes",
}


def _p_cons(w, i):
    c = w[i]
    if c in "aeiou":
        return False
    if c == "y":
        return i == 0 or not _p_cons(w, i - 1)
    return True


def _p_measure(s):
    n = len(s)
    m = 0
    i = 0
    while i < n and _p_cons(s, i):
        i += 1
    while i < n:
        while i < n and not _p_cons(s, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _p_cons(s, i):
            i += 1
    return m


def _p_has_vowel(s):
    return any(not _p_cons(s, i) for i in range(len(s)))


def _p_star_o(s):
    """*o: stem ends consonant-vowel-consonant, final consonant not w, x or y.

    Also holds for a two-letter stem made of a vowel followed by a consonant.
    """
    n = len(s)
    if n == 2:
        return (not _p_cons(s, 0)) and _p_cons(s, 1) and s[1] not in "wxy"
    if n < 3:
        return False
    return (
        _p_cons(s, n - 3)
        and not _p_cons(s, n - 2)
        and _p_cons(s, n - 1)
        and s[-1] not in "wxy"
    )


def _p_ends_double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _p_cons(w, len(w) - 1)


_P2_STEP2 = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
]
_P2_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _porter_step2(w, lingora):
    # LINGORA: -alli -> -al is tried first; the result goes through Step 2 again.
    if lingora and w.endswith("alli") and _p_measure(w[:-4]) > 0:
        return _porter_step2(w[:-4] + "al", lingora)
    if lingora and w.endswith("logi") and _p_measure(w[:-3]) > 0:
        return w[:-1]
    rules = _P2_STEP2 if lingora else [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
        ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
        ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
        ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
    ]
    for suf, rep in sorted(rules, key=lambda r: -len(r[0])):
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if _p_measure(stem) > 0:
                return stem + rep
            return w
    return w


def _porter_step3(w):
    for suf, rep in sorted(_P2_STEP3, key=lambda r: -len(r[0])):
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if _p_measure(stem) > 0:
                return stem + rep
            return w
    return w


def _porter_step4(w):
    for suf in sorted(_P2_STEP4, key=len, reverse=True):
        if w.endswith(suf):
            stem = w[: -len(suf)]
            if suf == "ion":
                if stem and stem[-1] in "st" and _p_measure(stem) > 1:
                    return stem
                return w
            if _p_measure(stem) > 1:
                return stem
            return w
    return w


def _porter_stem_word(word, lingora):
    if lingora and word in _PORTER_IRREGULAR:
        return _PORTER_IRREGULAR[word]
    if len(word) <= 2:
        return word
    w = word

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        if lingora and len(w) == 4:
            w = w[:-1]  # ties -> tie
        else:
            w = w[:-2]  # ties -> ti (published rule)
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]

    # Step 1b
    skip_1b = False
    if lingora and w.endswith("ied"):
        w = w[:-1] if len(w) == 4 else w[:-2]
        skip_1b = True
    if not skip_1b:
        if w.endswith("eed"):
            if _p_measure(w[:-3]) > 0:
                w = w[:-1]
        elif w.endswith("ed") or w.endswith("ing"):
            stem = w[:-2] if w.endswith("ed") else w[:-3]
            if _p_has_vowel(stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w = w + "e"
                elif _p_ends_double_cons(w) and w[-1] not in "lsz":
                    w = w[:-1]
                elif _p_measure(w) == 1 and _p_star_o(w):
                    w = w + "e"

    # Step 1c
    if w.endswith("y"):
        stem = w[:-1]
        if lingora:
            if len(stem) >= 2 and _p_cons(stem, len(stem) - 1):
                w = stem + "i"
        elif _p_has_vowel(stem):
            w = stem + "i"

    w = _porter_step2(w, lingora)
    w = _porter_step3(w)
    w = _porter_step4(w)

    # Step 5a
    if w.endswith("e"):
        stem = w[:-1]
        m = _p_measure(stem)
        if m > 1 or (m == 1 and not _p_star_o(stem)):
            w = stem

    # Step 5b
    if _p_measure(w) > 1 and w.endswith("ll"):
        w = w[:-1]
    return w


class PorterStemmer:
    """Porter stemmer. The default mode is the LINGORA extensions."""

    ORIGINAL_ALGORITHM = "original"
    MARTIN_EXTENSIONS = "martin"
    LINGORA_EXTENSIONS = "lingora"

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.LINGORA_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode

    def stem(self, word, to_lowercase=True):
        if to_lowercase:
            word = word.lower()
        return _porter_stem_word(word, lingora=(self._mode == self.LINGORA_EXTENSIONS))


# ---------------------------------------------------------------------------
# Snowball (English = Porter2; porter = original Porter algorithm)
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_P2_EXCEPTIONS = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
    "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_VOWELS = "aeiouy"


def _p2_short_syllable_at_end(w):
    n = len(w)
    if n == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    if n >= 3:
        return (
            w[-3] not in _P2_VOWELS
            and w[-2] in _P2_VOWELS
            and w[-1] not in _P2_VOWELS
            and w[-1] not in "wxY"
        )
    return False


def _porter2_stem(word):
    if word in _P2_EXCEPTIONS:
        return _P2_EXCEPTIONS[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    # Mark y as a consonant (Y) when it starts the word or follows a vowel.
    w = "".join(
        "Y" if (c == "y" and (i == 0 or w[i - 1] in _P2_VOWELS)) else c
        for i, c in enumerate(w)
    )
    if w.startswith(("gener", "commun", "arsen")):
        r1 = 6 if w.startswith("commun") else 5
    else:
        r1 = _p2_region_marked(w, 0)
    r2 = _p2_region_marked(w, r1)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(c in _P2_VOWELS for c in w[:-2]):
            w = w[:-1]

    # Step 1b
    if w.endswith("eedly"):
        if len(w) - 5 >= r1:
            w = w[:-5] + "ee"
    elif w.endswith("eed"):
        if len(w) - 3 >= r1:
            w = w[:-3] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if any(c in _P2_VOWELS for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w = w + "e"
                    elif _p_ends_double_cons_p2(w):
                        w = w[:-1]
                    elif len(w) <= r1 and _p2_short_syllable_at_end(w):
                        w = w + "e"
                break

    # Step 1c
    if (w.endswith("y") or w.endswith("Y")) and len(w) >= 3 and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    # Step 2
    w = _p2_step2(w, r1)
    # Step 3
    w = _p2_step3(w, r1, r2)
    # Step 4
    w = _p2_step4(w, r2)
    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable_at_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


def _p_ends_double_cons_p2(w):
    return len(w) >= 2 and w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")


def _p2_region_marked(w, start):
    for i in range(start + 1, len(w)):
        if w[i] not in _P2_VOWELS and w[i - 1] in _P2_VOWELS:
            return i + 1
    return len(w)


def _p2_suffix(w, suffixes, r):
    for suf in sorted(suffixes, key=len, reverse=True):
        if w.endswith(suf):
            return suf, len(w) - len(suf) >= r
    return None, False


_P2_S2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "fulli": "ful", "lessli": "less", "ogi": "og", "li": "",
}


def _p2_step2(w, r1):
    suf, ok = _p2_suffix(w, _P2_S2.keys(), r1)
    if suf is None or not ok:
        return w
    if suf == "ogi" and not w[:-3].endswith("l"):
        return w
    if suf == "li" and not (len(w) >= 3 and w[-3] in "cdeghkmnrt"):
        return w
    return w[: -len(suf)] + _P2_S2[suf]


_P2_S3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic",
          "iciti": "ic", "ical": "ic", "ful": "", "ness": "", "ative": ""}


def _p2_step3(w, r1, r2):
    suf, _ = _p2_suffix(w, _P2_S3.keys(), r1)
    if suf is None:
        return w
    start = len(w) - len(suf)
    if suf == "ative":
        if start >= r2:
            return w[:start]
        return w
    if start >= r1:
        return w[:start] + _P2_S3[suf]
    return w


_P2_S4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
          "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]


def _p2_step4(w, r2):
    suf, _ = _p2_suffix(w, _P2_S4, r2)
    if suf is None:
        return w
    start = len(w) - len(suf)
    if start < r2:
        return w
    if suf == "ion" and not (start >= 1 and w[start - 1] in "st"):
        return w
    return w[:start]


class SnowballStemmer:
    """Snowball stemmer. ``english`` is Porter2; ``porter`` is the original Porter algorithm."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language %r; supported: %s"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemming for %r is not implemented in this build" % language
            )
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            path = data.require(
                "corpora/stopwords/%s" % language,
                what="stopwords list for %r" % language,
            )
            self._stopwords = {ln.strip().lower() for ln in data.read_lines(path) if ln.strip()}

    def stem(self, word):
        lowered = word.lower()
        if self._stopwords is not None and lowered in self._stopwords:
            return lowered
        if self._language == "english":
            return _porter2_stem(lowered)
        return _porter_stem_word(lowered, lingora=False)


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Paice/Husk rules: <suffix><digit><appended letters><'*' = intact only><'.' stop | '>' continue>
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "earl3y>", "ee2.",
]
_RULE_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")


def _parse_lancaster_rules(rules):
    parsed = []
    for rule in rules:
        m = _RULE_RE.match(rule)
        if m is None:
            raise ValueError("bad Lancaster rule %r" % rule)
        suffix, intact, digit, appended, end = m.groups()
        parsed.append((suffix, int(digit), appended, bool(intact), end == "."))
    return parsed


_PARSED_LANCASTER = _parse_lancaster_rules(_LANCASTER_RULES)


def _lancaster_acceptable(word):
    if not word:
        return False
    if word[0] in "aeiouy":
        return len(word) >= 2
    return len(word) >= 3 and re.search(r"[aeiouy]", word[1:]) is not None


class LancasterStemmer:
    def stem(self, word):
        word = word.lower()
        intact = True
        changed = True
        while changed:
            changed = False
            for suffix, digit, appended, need_intact, terminal in _PARSED_LANCASTER:
                if need_intact and not intact:
                    continue
                if not word.endswith(suffix) or digit > len(word):
                    continue
                candidate = word[: len(word) - digit] + appended
                if not _lancaster_acceptable(candidate):
                    continue
                word = candidate
                intact = False
                if terminal:
                    return word
                changed = True
                break
        return word


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._pattern = re.compile(regexp)

    def stem(self, word):
        return self._pattern.sub("", word)


# ---------------------------------------------------------------------------
# Out-of-scope families: exist, but are not implemented in this build.
# ---------------------------------------------------------------------------

class ARLSTem:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("ARLSTem2 is not implemented in this build")


class WordNetLemmatizer:
    def __init__(self):
        data.require("corpora/wordnet", what="WordNet")
        raise NotImplementedError("WordNetLemmatizer is not implemented in this build")

    def lemmatize(self, word):
        raise NotImplementedError("WordNetLemmatizer is not implemented in this build")
