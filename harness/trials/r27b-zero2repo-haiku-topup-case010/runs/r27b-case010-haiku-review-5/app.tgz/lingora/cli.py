"""Command line (``lingora.cli``).

``cli.main(args=['tokenize'], standalone_mode=True)`` runs the tokenize command:
it reads UTF-8 text from standard input and, for each input line, writes one
line with the recommended word tokenizer's tokens (sentence splitting included)
joined by the delimiter. Without the Punkt model for the language it fails
before writing anything.
"""

import sys

from lingora import _punkt
from lingora.tokenize import word_tokenize

__all__ = ["cli", "main_entry"]

_USAGE = """Usage: lingora tokenize [OPTIONS]

  Tokenize each line of standard input with the recommended word tokenizer.

Options:
  -l, --language TEXT   Punkt language directory name (default: english)
  -d, --delimiter TEXT  Token delimiter (default: a single space)
  -h, --help            Show this message and exit.
"""


class _UsageError(Exception):
    pass


class Group:
    def __init__(self, name):
        self.name = name
        self._commands = {}

    def command(self, name):
        def register(func):
            self._commands[name] = func
            return func

        return register

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._dispatch(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    def _dispatch(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(_USAGE)
            return 0
        name, rest = args[0], args[1:]
        if name not in self._commands:
            sys.stderr.write("Error: no such command %r.\n" % name)
            return 2
        try:
            return self._commands[name](rest)
        except _UsageError as exc:
            sys.stderr.write("Error: %s\n" % exc)
            return 2


cli = Group("lingora")


def _parse_options(args, defaults):
    opts = dict(defaults)
    aliases = {"-l": "language", "--language": "language",
               "-d": "delimiter", "--delimiter": "delimiter"}
    k = 0
    while k < len(args):
        arg = args[k]
        if arg in ("-h", "--help"):
            sys.stdout.write(_USAGE)
            raise _Help()
        if arg in aliases:
            if k + 1 >= len(args):
                raise _UsageError("option %s needs a value" % arg)
            opts[aliases[arg]] = args[k + 1]
            k += 2
            continue
        raise _UsageError("unknown option %r" % arg)
    return opts


class _Help(Exception):
    pass


def _read_stdin():
    buf = getattr(sys.stdin, "buffer", None)
    if buf is not None:
        return buf.read().decode("utf-8")
    return sys.stdin.read()


@cli.command("tokenize")
def _tokenize_command(args):
    try:
        opts = _parse_options(args, {"language": "english", "delimiter": " "})
    except _Help:
        return 0
    language = opts["language"]
    delimiter = opts["delimiter"]

    try:
        _punkt.load(language)
    except Exception as exc:  # missing or unreadable Punkt model
        sys.stderr.write("Error: %s\n" % exc)
        return 1

    text = _read_stdin()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    for line in lines:
        if line.endswith("\r"):
            line = line[:-1]
        try:
            tokens = word_tokenize(line, language=language, preserve_line=False)
        except Exception as exc:
            sys.stderr.write("Error: %s\n" % exc)
            return 1
        sys.stdout.write(delimiter.join(tokens) + "\n")
    sys.stdout.flush()
    return 0


def main_entry():
    cli.main()
