"""Tokenizers (FP-01)."""

import re

from lingora import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


# ---------------------------------------------------------------------------
# Word/punctuation tokenizer
# ---------------------------------------------------------------------------

_WORD_PUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    def tokenize(self, text):
        return _WORD_PUNCT_RE.findall(text)

    def span_tokenize(self, text):
        for m in _WORD_PUNCT_RE.finditer(text):
            yield (m.start(), m.end())


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Penn Treebank conventions (shared by TreebankWordTokenizer and word_tokenize)
# ---------------------------------------------------------------------------

_OPEN_CONTEXT = r"(?:^|(?<=[\s(\[{<]))"

_TB_FUSED = [
    (re.compile(r"\b(can)(not)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(d)('ye)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(gim)(me)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(gon)(na)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(got)(ta)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(lem)(me)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(more)('n)\b", re.I), r"\1 \2"),
    (re.compile(r"\b(wan)(na)\b", re.I), r"\1 \2"),
    (re.compile(r"(?<!\S)('t)(is|was)\b", re.I), r"\1 \2"),
]
_CLITIC_NT = re.compile(r"(?i)\b(\w+?)(n't)\b")
_CLITIC_OTHER = re.compile(r"(?i)(?<=\w)('(?:s|m|d|ll|re|ve))\b")
_BARE_APOS = re.compile(r"(?<=\w)'(?=\s|$)")


def _treebank_tokenize(text, improved=False, keep_cannot=False):
    # Straight double quotes: opening (`` ) at start/after space or opening bracket,
    # otherwise closing ('').  The improved tokenizer makes a quote at the very
    # start of the text a closing quote.
    if improved:
        text = re.sub(r'^"', " '' ", text)
        text = re.sub(_OPEN_CONTEXT + '"', " `` ", text)
    else:
        text = re.sub(_OPEN_CONTEXT + '"', " `` ", text)
    text = text.replace('"', " '' ")

    if improved:
        text = re.sub(r"[“”„‟‘’‚‛]", r" \g<0> ", text)
        text = re.sub(r"[‒-―*]", r" \g<0> ", text)
        text = re.sub(r"\.{2,}", r" \g<0> ", text)
        text = text.replace("--", " -- ")
    else:
        text = re.sub(r"\.\.\.", " ... ", text)

    text = re.sub(r"[;@#$%&?!]", r" \g<0> ", text)
    text = re.sub(r"[\[\](){}<>]", r" \g<0> ", text)
    text = re.sub(r"[:,](?!\d)", r" \g<0> ", text)
    text = re.sub(r"([^.])(\.)([\]\)}>\"']*)\s*$", r"\1 \2\3 ", text)

    if not keep_cannot:
        for regexp, repl in _TB_FUSED:
            text = regexp.sub(repl, text)
    else:
        for regexp, repl in _TB_FUSED[1:]:
            text = regexp.sub(repl, text)

    text = _CLITIC_NT.sub(r"\1 \2", text)
    text = _CLITIC_OTHER.sub(r" \1", text)
    text = _BARE_APOS.sub(" '", text)
    return text.split()


class TreebankWordTokenizer:
    def tokenize(self, text):
        return _treebank_tokenize(text)


# ---------------------------------------------------------------------------
# Recommended word tokenizer and sentence tokenizer
# ---------------------------------------------------------------------------

def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``."""
    params = _punkt.load(language)
    return [text[s:e] for s, e in _punkt.sentence_spans(text, params)]


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language=language)
    tokens = []
    for sent in sentences:
        tokens.extend(_treebank_tokenize(sent, improved=True, keep_cannot=True))
    return tokens


# ---------------------------------------------------------------------------
# Whitespace, blank-line, regular-expression tokenizers
# ---------------------------------------------------------------------------

class WhitespaceTokenizer:
    _re = re.compile(r"\S+")

    def tokenize(self, text):
        return self._re.findall(text)

    def span_tokenize(self, text):
        for m in self._re.finditer(text):
            yield (m.start(), m.end())


_BLANKLINE_SEP = re.compile(r"\s*\n[^\S\n]*\n\s*")


def blankline_tokenize(text):
    pieces = _BLANKLINE_SEP.split(text)
    return [p for p in pieces if p]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._pattern = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def span_tokenize(self, text):
        if self._gaps:
            spans = []
            pos = 0
            for m in self._pattern.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._pattern.finditer(text)]
        for s, e in spans:
            if e > s or not self._discard_empty:
                yield (s, e)

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text)]


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = r"""(?:[<>]?[:;=8][\-o*']?[)(\]\[dDpP/:}{@|\\]|[)(\]\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?)"""
_URL = r"""https?://\S+|www\.\S+"""
_HANDLE = r"""@\w+"""
_HASHTAG = r"""#\w+"""
_CONTRACTION = r"""\w+'\w+"""
_WORD = r"""\w+(?:[\-\.]\w+)*"""
_PUNCT = r"""[^\w\s]"""

_TWEET_RE = re.compile(
    "|".join(
        [
            "(?:%s)" % _URL,
            "(?:%s)" % _EMOTICON,
            "(?:%s)" % _HANDLE,
            "(?:%s)" % _HASHTAG,
            "(?:%s)" % _CONTRACTION,
            "(?:%s)" % _WORD,
            "(?:%s)" % _PUNCT,
        ]
    ),
    re.UNICODE,
)
_EMOTICON_RE = re.compile(_EMOTICON)
_HANDLE_STRIP_RE = re.compile(r"(?<![\w])@[A-Za-z0-9_]{1,15}(?![\w])")
_REPEAT_RE = re.compile(r"(.)\1{3,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        if self._strip_handles:
            text = _HANDLE_STRIP_RE.sub(" ", text)
        if self._reduce_len:
            text = _REPEAT_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_RE.findall(text)
        if not self._preserve_case:
            tokens = [t if _EMOTICON_RE.fullmatch(t) else t.lower() for t in tokens]
        return tokens
