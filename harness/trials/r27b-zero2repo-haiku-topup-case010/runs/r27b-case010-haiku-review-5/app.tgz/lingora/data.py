"""Packaged-resource finder (``lingora.data``).

``path`` is a mutable list of directories searched for packaged resources.
Callers may replace its contents in place. Initially it holds the directories
named in the ``LINGORA_DATA`` environment variable (``os.pathsep`` separated)
followed by ``~/lingora_data``.
"""

import os


class ResourceNotFoundError(LookupError):
    """A packaged resource is not visible in any directory on ``data.path``."""


def _initial_path():
    dirs = []
    env = os.environ.get("LINGORA_DATA", "")
    dirs.extend(p for p in env.split(os.pathsep) if p)
    dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return dirs


path = _initial_path()


def find(relpath):
    """Return the first existing ``os.path.join(dir, relpath)``, or ``None``."""
    for directory in list(path):
        candidate = os.path.join(directory, relpath)
        if os.path.exists(candidate):
            return candidate
    return None


def require(relpath, what=None):
    """Like :func:`find`, but raise :class:`ResourceNotFoundError` when absent."""
    found = find(relpath)
    if found is None:
        label = what or relpath
        raise ResourceNotFoundError(
            "packaged resource %r (%s) is not installed in any directory on data.path"
            % (relpath, label)
        )
    return found


def read_lines(filepath):
    """Read a UTF-8 text file; each line without its terminator is one entry."""
    with open(filepath, encoding="utf-8") as fh:
        return fh.read().splitlines()
