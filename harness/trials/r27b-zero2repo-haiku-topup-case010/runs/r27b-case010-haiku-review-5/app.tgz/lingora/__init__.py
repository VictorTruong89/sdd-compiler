"""Lingora Language Toolkit: a pure-Python NLP processing library.

Importing this package downloads nothing and needs no packaged data.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: F401
from lingora import tokenize  # noqa: F401
from lingora import stem  # noqa: F401
from lingora import tag  # noqa: F401
from lingora import chunk  # noqa: F401
from lingora import grammar  # noqa: F401
from lingora import tree  # noqa: F401
from lingora import parse  # noqa: F401
from lingora import classify  # noqa: F401
from lingora import metrics  # noqa: F401
from lingora import translate  # noqa: F401
