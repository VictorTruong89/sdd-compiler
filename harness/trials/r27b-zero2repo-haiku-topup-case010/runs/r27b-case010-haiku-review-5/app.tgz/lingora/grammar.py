"""Context-free grammars (FP-05).

Grammar text has one production per line, ``LHS -> RHS``. ``RHS`` is a
space-separated sequence of nonterminals (unquoted identifiers) and terminals
(single- or double-quoted text); ``|`` separates alternatives. A production with
nothing after ``->`` is an empty production.
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_\-']*$")
_RHS_TOKEN_RE = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class Nonterminal:
    """A grammar nonterminal. ``str()`` is its name; it is not a ``str`` itself."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and self._lhs == other._lhs
            and self._rhs == other._rhs
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        def show(sym):
            return repr(sym) if isinstance(sym, str) else str(sym)

        return "%s -> %s" % (self._lhs, " ".join(show(s) for s in self._rhs))


def _parse_rhs(text):
    """Split an RHS into alternatives, each a tuple of terminals and Nonterminals."""
    alternatives = [[]]
    for tok in _RHS_TOKEN_RE.findall(text):
        if tok == "|":
            alternatives.append([])
        elif tok[0] in "'\"":
            alternatives[-1].append(tok[1:-1])
        else:
            if not _IDENT_RE.match(tok):
                raise ValueError("bad grammar symbol %r" % tok)
            alternatives[-1].append(Nonterminal(tok))
    return [tuple(a) for a in alternatives]


class CFG:
    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(str(start))
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for prod in self._productions:
            self._by_lhs.setdefault(prod.lhs(), []).append(prod)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects grammar text")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production without '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT_RE.match(lhs_text):
                raise ValueError("bad left-hand side %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            for alt in _parse_rhs(rhs_text.strip()):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._by_lhs.get(lhs, []))

    def terminals(self):
        out = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str):
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
