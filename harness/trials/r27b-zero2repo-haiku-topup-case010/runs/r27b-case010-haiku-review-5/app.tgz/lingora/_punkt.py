"""Punkt sentence-boundary detection using packaged Punkt parameters.

The packaged model for a language lives in ``tokenizers/punkt_tab/<language>/``
and holds ``abbrev_types.txt``, ``sent_starters.txt``, ``collocations.tab`` and
``ortho_context.tab`` (layout in the Interface Contract).

The decision procedure follows the Kiss and Strunk (2006) heuristics: a token
ending in a sentence-final mark is a candidate boundary; abbreviations and
initials need orthographic evidence from the following word, collocations
never break, and a lower-case following word does not start a sentence.
"""

import os
import re
import threading

from lingora import data

_CLOSERS = "\"')]}>»”’"
_OPENERS = "\"'([{<«“‘"
_ORTHO_UC_START = 2
_ORTHO_UC_INSIDE = 4
_ORTHO_LC_START = 16
_ORTHO_LC_INSIDE = 32
_NUMBER_RE = re.compile(r"^[\-\.,]*\d[\d\.,\-]*$")
_QUANT_RE = re.compile(r"\{\d*,?\d*\}")

_cache = {}
_cache_lock = threading.Lock()


class PunktParameters:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


def _load_parameters(language):
    model_dir = data.require(
        os.path.join("tokenizers", "punkt_tab", language),
        what="Punkt model for %r" % language,
    )
    if not os.path.isdir(model_dir):
        raise data.ResourceNotFoundError(
            "Punkt model path %r is not a directory" % model_dir
        )

    def file_lines(name):
        return [ln for ln in data.read_lines(os.path.join(model_dir, name)) if ln.strip()]

    abbrev = {ln.strip().lower() for ln in file_lines("abbrev_types.txt")}
    starters = {ln.strip().lower() for ln in file_lines("sent_starters.txt")}
    colloc = set()
    for ln in file_lines("collocations.tab"):
        parts = ln.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0].lower(), parts[1].lower()))
    ortho = {}
    for ln in file_lines("ortho_context.tab"):
        parts = ln.split("\t")
        if len(parts) == 2:
            ortho[parts[0].lower()] = int(parts[1])
    return PunktParameters(abbrev, starters, colloc, ortho)


def load(language):
    """Return the Punkt parameters for ``language``; raise if not installed."""
    key = (language, tuple(data.path))
    with _cache_lock:
        if key not in _cache:
            _cache[key] = _load_parameters(language)
        return _cache[key]


def _is_break(word, next_word, params):
    """Decide whether a sentence ends after ``word`` (followed by ``next_word``)."""
    core = word.rstrip(_CLOSERS)
    if not core or core[-1] not in ".?!":
        return False
    if next_word is None:
        return True
    if core[-1] in "?!":
        return True

    next_core = next_word.lstrip(_OPENERS)
    first = next_core[:1]
    first_upper = first.isupper()
    first_lower = first.islower()

    stripped = core.rstrip(".")
    typ = stripped.lower()
    if _NUMBER_RE.match(stripped):
        typ = "##number##"
    next_typ = next_core.rstrip(".,;:!?" + _CLOSERS).lower()
    if _NUMBER_RE.match(next_core.rstrip(".,;:!?" + _CLOSERS)):
        next_typ = "##number##"

    if (typ, next_typ) in params.collocations:
        return False

    ellipsis = core.endswith("...")
    abbreviation = (
        typ in params.abbrev_types
        or (len(typ) == 1 and typ.isalpha())
        or ellipsis
    )

    if abbreviation:
        if not first_upper:
            return False
        if next_typ in params.sent_starters:
            return True
        bits = params.ortho_context.get(next_typ, 0)
        if bits & _ORTHO_UC_START:
            return True
        # No sentence-start evidence: an abbreviation before a capitalised
        # word (often a name, as in "Mr. Smith") does not end the sentence.
        return False

    if first_lower:
        return False
    return True


def sentence_spans(text, params):
    """Return ``(start, end)`` character spans of the sentences of ``text``."""
    words = [(m.start(), m.end()) for m in re.finditer(r"\S+", text)]
    if not words:
        return []
    spans = []
    start = words[0][0]
    for k, (s, e) in enumerate(words):
        if k + 1 < len(words):
            ns, ne = words[k + 1]
            if _is_break(text[s:e], text[ns:ne], params):
                spans.append((start, e))
                start = ns
        else:
            spans.append((start, e))
    return spans
