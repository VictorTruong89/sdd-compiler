"""Text classifiers (FP-06)."""

import collections
import math

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda lab: self._probs[lab])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_labeled(labeled):
    labeled = list(labeled)
    if not labeled:
        raise ValueError("training needs at least one labeled featureset")
    for fs, _ in labeled:
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
    return labeled


class NaiveBayesClassifier:
    """Naive Bayes with expected-likelihood (add-1/2) smoothing."""

    def __init__(self, label_counts, label_totals, feature_values, cond, total):
        self._label_counts = label_counts
        self._label_totals = label_totals
        self._feature_values = feature_values
        self._cond = cond
        self._total = total
        self._labels = list(label_counts.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        label_counts = collections.OrderedDict()
        feature_values = collections.defaultdict(set)
        cond = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
        for fs, label in labeled:
            label_counts[label] = label_counts.get(label, 0) + 1
            for f, v in fs.items():
                feature_values[f].add(v)
                cond[label][f][v] += 1
        label_totals = dict(label_counts)
        return cls(dict(label_counts), label_totals, dict(feature_values), cond, len(labeled))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            lp = math.log(self._label_counts[label] / self._total)
            for f, v in featureset.items():
                if f not in self._feature_values:
                    continue
                bins = len(self._feature_values[f]) + 1
                count = self._cond[label][f][v] if label in self._cond else 0
                p = (count + 0.5) / (self._label_totals[label] + 0.5 * bins)
                lp += math.log(p)
            scores[label] = lp
        return scores

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = self._labels[0]
        for label in self._labels[1:]:
            if scores[label] > scores[best]:
                best = label
        return best

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {lab: math.exp(s - top) for lab, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({lab: e / total for lab, e in exps.items()})


def _entropy(labels):
    counts = collections.Counter(labels)
    n = len(labels)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _majority(labels):
    counts = collections.Counter(labels)
    best = None
    best_count = -1
    for lab in labels:
        if counts[lab] > best_count:
            best = lab
            best_count = counts[lab]
    return best


class _DTNode:
    __slots__ = ("feature", "children", "majority")

    def __init__(self, feature, children, majority):
        self.feature = feature
        self.children = children
        self.majority = majority


class DecisionTreeClassifier:
    """ID3-style decision tree over feature tests; absent features test as ``None``."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        features = sorted({f for fs, _ in labeled for f in fs}, key=repr)
        return cls(cls._build(labeled, features))

    @classmethod
    def _build(cls, examples, features):
        labels = [lab for _, lab in examples]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _DTNode(None, {}, majority)
        base = _entropy(labels)
        best_feature = None
        best_gain = 0.0
        for f in features:
            groups = collections.defaultdict(list)
            for fs, lab in examples:
                groups[fs.get(f)].append(lab)
            remainder = sum(len(g) / len(examples) * _entropy(g) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_gain = gain
                best_feature = f
        if best_feature is None:
            return _DTNode(None, {}, majority)
        rest = [f for f in features if f != best_feature]
        by_value = collections.OrderedDict()
        for fs, lab in examples:
            by_value.setdefault(fs.get(best_feature), []).append((fs, lab))
        children = {v: cls._build(subset, rest) for v, subset in by_value.items()}
        return _DTNode(best_feature, children, majority)

    def classify(self, featureset):
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.majority
        return node.majority


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs the classifier labels correctly."""
    gold = list(gold)
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for fs, lab in gold if classifier.classify(fs) == lab)
    return correct / len(gold)
