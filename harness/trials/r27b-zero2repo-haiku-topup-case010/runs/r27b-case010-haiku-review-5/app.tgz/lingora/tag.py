"""Part-of-speech taggers (FP-03)."""

import collections
import json
import os
import re

from lingora import data

__all__ = [
    "AveragedPerceptronTagger",
    "DefaultTagger",
    "RegexpTagger",
    "UnigramTagger",
    "pos_tag",
]


class _SequentialTagger:
    """Base class: a tagger may name a backoff tagger for unassigned tokens."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose(self, tokens):
        """Return one tag (or None) per token from this tagger alone."""
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a str")
        tokens = list(tokens)
        tags = self._choose(tokens)
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                backed = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, backed):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _choose(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = collections.defaultdict(collections.Counter)
        for sent in train or []:
            for token, tag in sent:
                counts[token][tag] += 1
        # Most frequent tag per word; ties go to the tag seen first.
        self._model = {
            word: max(c.items(), key=lambda kv: kv[1])[0] for word, c in counts.items()
        }

    def _choose(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(_SequentialTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = []
        for pattern, tag in regexps:
            self._rules.append((re.compile(pattern), tag))

    def _choose(self, tokens):
        out = []
        for t in tokens:
            tag = None
            for rx, rule_tag in self._rules:
                if rx.match(t):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended English / Russian tagger)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "NUM": "NUM",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "INTJ": "INTJ",
    "SPRO": "PRON", "APRO": "DET", "ADVPRO": "ADV", "ANUM": "ADJ",
    "PRAEDIC": "ADV", "PARENTH": "X", "COM": "X",
}


class AveragedPerceptronTagger:
    """Greedy averaged perceptron tagger reading the packaged resource for ``lang``."""

    _loaded = {}

    def __init__(self, lang):
        if lang not in ("eng", "rus"):
            raise ValueError("unsupported tagger language %r" % (lang,))
        key = (lang, tuple(data.path))
        if key not in AveragedPerceptronTagger._loaded:
            AveragedPerceptronTagger._loaded[key] = self._load(lang)
        self.weights, self.tagdict, self.classes = AveragedPerceptronTagger._loaded[key]

    @staticmethod
    def _load(lang):
        base = os.path.join("taggers", "averaged_perceptron_tagger_%s" % lang)
        directory = data.require(base, what="averaged perceptron tagger for %r" % lang)
        stem = "averaged_perceptron_tagger_%s" % lang

        def read_json(name):
            with open(os.path.join(directory, name), encoding="utf-8") as fh:
                return json.load(fh)

        weights = read_json(stem + ".weights.json")
        tagdict = read_json(stem + ".tagdict.json")
        classes = set(read_json(stem + ".classes.json"))
        return weights, tagdict, classes

    @staticmethod
    def _normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word[:1].isdigit():
            return "!DIGITS"
        return word.lower()

    def _predict(self, features):
        scores = collections.defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: (scores[label], label))

    def _features(self, i, word, context, prev, prev2):
        features = collections.defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def tag(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [self._normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self._predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


def _universal_eng_map():
    directory = data.require(
        os.path.join("taggers", "universal_tagset"),
        what="universal tagset tables",
    )
    mapping = {}
    for ln in data.read_lines(os.path.join(directory, "en-ptb.map")):
        parts = ln.split("\t")
        if len(parts) == 2 and parts[0]:
            mapping[parts[0]] = parts[1]
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a list of tokens with LINGORA's recommended tagger."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag expects a list of tokens, not a str")
    if lang not in ("eng", "rus"):
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tokens = list(tokens)
    tagger = AveragedPerceptronTagger(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _universal_eng_map()
            tagged = [(w, mapping.get(t, "X") if t is not None else None) for w, t in tagged]
        else:
            tagged = [
                (
                    w,
                    _RNC_TO_UNIVERSAL.get(t.split("=")[0], "X") if t is not None else None,
                )
                for w, t in tagged
            ]
    return tagged
