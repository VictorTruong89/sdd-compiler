"""Chunking with chunk grammars (FP-04).

Grammar text: a clause begins with ``<LABEL>: <pattern>``; further patterns of
the clause follow on indented lines. A pattern ``{...}`` is a chunk rule and
``}...{`` is a chink rule. Tag patterns are sequences of ``<regex>`` elements,
each optionally followed by ``?``, ``*``, ``+`` or ``{m}``, ``{m,}``, ``{m,n}``.
"""

import re

from lingora.tree import Tree
from lingora import data

__all__ = ["RegexpParser", "ne_chunk", "ChunkRule", "ChinRule"]

SENTENCE_LABEL = "S"
_INF = float("inf")
_QUANT_RE = re.compile(r"\{(\d*)(,?)(\d*)\}")


class _Element:
    __slots__ = ("regex", "lo", "hi")

    def __init__(self, regex, lo, hi):
        self.regex = regex
        self.lo = lo
        self.hi = hi


def _compile_tag_pattern(text):
    """Compile a tag pattern (whitespace ignored) into a list of ``_Element``."""
    t = re.sub(r"\s+", "", text)
    elements = []
    k = 0
    while k < len(t):
        if t[k] != "<":
            raise ValueError("tag pattern element must start with '<': %r" % text)
        end = t.find(">", k)
        if end < 0:
            raise ValueError("unterminated '<' in tag pattern: %r" % text)
        content = t[k + 1:end]
        k = end + 1
        lo, hi = 1, 1
        if k < len(t):
            q = t[k]
            if q == "?":
                lo, hi = 0, 1
                k += 1
            elif q == "*":
                lo, hi = 0, _INF
                k += 1
            elif q == "+":
                lo, hi = 1, _INF
                k += 1
            elif q == "{":
                m = _QUANT_RE.match(t, k)
                if m is None:
                    raise ValueError("bad quantifier in tag pattern: %r" % text)
                a, comma, b = m.group(1), m.group(2), m.group(3)
                if not comma:
                    lo = hi = int(a)
                else:
                    lo = int(a) if a else 0
                    hi = int(b) if b else _INF
                k = m.end()
        try:
            regex = re.compile(content)
        except re.error as exc:
            raise ValueError("bad tag regex %r: %s" % (content, exc))
        elements.append(_Element(regex, lo, hi))
    if not elements:
        raise ValueError("empty tag pattern")
    return elements


def _match_ends(elements, tags, pos):
    """Return the set of end positions reachable by matching ``elements`` at ``pos``."""
    states = {pos}
    for el in elements:
        nxt = set()
        for s in states:
            cur = s
            count = 0
            while True:
                if count >= el.lo:
                    nxt.add(cur)
                if count >= el.hi or cur >= len(tags):
                    break
                if el.regex.fullmatch(tags[cur]) is None:
                    break
                cur += 1
                count += 1
        states = nxt
        if not states:
            return states
    return states


def _longest_match(elements, tags, pos):
    ends = _match_ends(elements, tags, pos)
    ends = [e for e in ends if e > pos]
    return max(ends) if ends else None


class ChunkRule:
    """A chunk rule stage: tokens matching ``pattern`` become chunks labelled ``label``."""

    kind = "chunk"

    def __init__(self, label, pattern):
        self.label = label
        self.pattern = pattern
        self.elements = _compile_tag_pattern(pattern)


class ChinRule:
    """A chink rule stage: tokens matching ``pattern`` are removed from chunks."""

    kind = "chink"

    def __init__(self, label, pattern):
        self.label = label
        self.pattern = pattern
        self.elements = _compile_tag_pattern(pattern)


class _Node:
    __slots__ = ("pair", "label", "children", "clause")

    def __init__(self, pair=None, label=None, children=None, clause=None):
        self.pair = pair
        self.label = label
        self.children = children
        self.clause = clause

    @property
    def is_leaf(self):
        return self.pair is not None

    @property
    def tag(self):
        return self.pair[1] if self.is_leaf else self.label

    def to_tree_child(self):
        if self.is_leaf:
            return self.pair
        return Tree(self.label, [c.to_tree_child() for c in self.children])


def _parse_grammar_text(text):
    """Return a list of stages (ChunkRule / ChinRule) grouped into clauses."""
    stages = []
    clause_no = -1
    current_label = None
    pattern_re = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0] in " \t":
            if current_label is None:
                raise ValueError("indented pattern before any clause label")
            rest = raw.strip()
        else:
            m = re.match(r"^\s*([^:\s{}<>]+)\s*:\s*(.*)$", raw)
            if m is None:
                raise ValueError("expected a clause line '<LABEL>: <pattern>': %r" % raw)
            current_label = m.group(1)
            clause_no += 1
            rest = m.group(2).strip()
        for kind, inner in _split_patterns(rest):
            cls = ChunkRule if kind == "chunk" else ChinRule
            stage = cls(current_label, inner)
            stage.clause = clause_no
            stages.append(stage)
    return stages


def _split_patterns(s):
    """Split a clause's pattern text into ``(kind, inner_text)`` pairs."""
    out = []
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c == "{":
            kind, closer = "chunk", "}"
        elif c == "}":
            kind, closer = "chink", "{"
        else:
            raise ValueError("pattern must start with '{' or '}': %r" % s)
        j = i + 1
        in_angle = False
        while True:
            if j >= n:
                raise ValueError("unterminated pattern: %r" % s)
            ch = s[j]
            if ch == "<":
                in_angle = True
            elif ch == ">":
                in_angle = False
            elif not in_angle:
                if ch == "{" and _QUANT_RE.match(s, j):
                    j = _QUANT_RE.match(s, j).end()
                    continue
                if ch == closer:
                    break
            j += 1
        out.append((kind, s[i + 1:j]))
        i = j + 1
    return out


def _is_eligible(node, clause_no):
    """Chunk rules may match loose tokens and chunks from earlier clauses."""
    return node.is_leaf or node.clause != clause_no


def _apply_chunk(nodes, rule, clause_no):
    runs = []
    start = None
    for k, node in enumerate(nodes):
        if _is_eligible(node, clause_no):
            if start is None:
                start = k
        else:
            if start is not None:
                runs.append((start, k))
                start = None
    if start is not None:
        runs.append((start, len(nodes)))

    matches = []
    for a, b in runs:
        tags = [nodes[k].tag for k in range(a, b)]
        pos = 0
        while pos < len(tags):
            end = _longest_match(rule.elements, tags, pos)
            if end is not None:
                matches.append((a + pos, a + end))
                pos = end
            else:
                pos += 1

    # Chunks that touch, with no token between them, are joined into one chunk.
    merged = []
    for s, e in matches:
        if merged and merged[-1][1] == s:
            merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))

    result = []
    k = 0
    for s, e in merged:
        result.extend(nodes[k:s])
        result.append(_Node(label=rule.label, children=nodes[s:e], clause=clause_no))
        k = e
    result.extend(nodes[k:])
    return result


def _apply_chink(nodes, rule, clause_no):
    result = []
    for node in nodes:
        if node.is_leaf or node.clause != clause_no:
            result.append(node)
            continue
        children = node.children
        removed = [False] * len(children)
        k = 0
        while k < len(children):
            if not children[k].is_leaf:
                k += 1
                continue
            run_end = k
            while run_end < len(children) and children[run_end].is_leaf:
                run_end += 1
            tags = [children[x].tag for x in range(k, run_end)]
            pos = 0
            while pos < len(tags):
                end = _longest_match(rule.elements, tags, pos)
                if end is not None:
                    for x in range(pos, end):
                        removed[k + x] = True
                    pos = end
                else:
                    pos += 1
            k = run_end
        piece = []
        for idx, child in enumerate(children):
            if removed[idx]:
                if piece:
                    result.append(_Node(label=node.label, children=piece, clause=clause_no))
                    piece = []
                result.append(child)
            else:
                piece.append(child)
        if piece:
            result.append(_Node(label=node.label, children=piece, clause=clause_no))
    return result


class RegexpParser:
    """Chunk parser built from a chunk grammar (text, or a list of stages)."""

    def __init__(self, grammar, root_label=SENTENCE_LABEL):
        if isinstance(grammar, str):
            stages = _parse_grammar_text(grammar)
        elif isinstance(grammar, list):
            for stage in grammar:
                if not isinstance(stage, (ChunkRule, ChinRule)):
                    raise TypeError("grammar list must hold chunk-parser stages")
            stages = []
            clause_no = -1
            previous = None
            for stage in grammar:
                if previous is None or stage.label != previous:
                    clause_no += 1
                    previous = stage.label
                stage.clause = clause_no
                stages.append(stage)
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")
        self._stages = stages
        self._root_label = root_label

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("parse expects a list of (token, tag) pairs")
        nodes = []
        for pair in tagged:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("each tagged token must be a (token, tag) pair")
            nodes.append(_Node(pair=pair))
        for stage in self._stages:
            if stage.kind == "chunk":
                nodes = _apply_chunk(nodes, stage, stage.clause)
            else:
                nodes = _apply_chink(nodes, stage, stage.clause)
        return Tree(self._root_label, [n.to_tree_child() for n in nodes])


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires its packaged model and the English wordlist."""
    data.require(
        "chunkers/maxent_ne_chunker_tab/english_ace_multiclass",
        what="named-entity chunker model",
    )
    data.require("corpora/words", what="English wordlist")
    raise NotImplementedError("named-entity chunking is not implemented in this build")
