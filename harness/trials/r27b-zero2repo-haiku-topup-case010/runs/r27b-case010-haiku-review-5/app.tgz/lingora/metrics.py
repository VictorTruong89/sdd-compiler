"""Evaluation metrics (FP-07)."""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)" % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def _levenshtein(s1, s2, substitution_cost):
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1, 1):
        cur = [i]
        for j, c2 in enumerate(s2, 1):
            sub = 0 if c1 == c2 else substitution_cost
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub))
        prev = cur
    return prev[-1]


def _damerau_levenshtein(a, b, substitution_cost):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    n, m = len(a), len(b)
    maxdist = n + m
    # D[x + 1][y + 1] holds the algorithm's d[x][y], for x in -1..n and y in -1..m.
    D = [[0] * (m + 2) for _ in range(n + 2)]
    D[0][0] = maxdist
    for x in range(n + 1):
        D[x + 1][0] = maxdist
        D[x + 1][1] = x
    for y in range(m + 1):
        D[0][y + 1] = maxdist
        D[1][y + 1] = y
    last_row = {}
    for i in range(1, n + 1):
        last_col = 0
        for j in range(1, m + 1):
            k = last_row.get(b[j - 1], 0)
            ell = last_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_col = j
            else:
                cost = substitution_cost
            D[i + 1][j + 1] = min(
                D[i][j] + cost,
                D[i + 1][j] + 1,
                D[i][j + 1] + 1,
                D[k][ell] + (i - k - 1) + 1 + (j - ell - 1),
            )
        last_row[a[i - 1]] = i
    return D[n + 1][m + 1]


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Edit distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance expects two str arguments")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    return _levenshtein(s1, s2, substitution_cost)


def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance expects two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure require sets")


def precision(reference, test):
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; ``None`` when undefined."""
    _check_sets(reference, test)
    if not reference or not test:
        return None
    inter = reference & test
    if not inter:
        return None
    p = len(inter) / len(test)
    r = len(inter) / len(reference)
    return 1 / (alpha / p + (1 - alpha) / r)
