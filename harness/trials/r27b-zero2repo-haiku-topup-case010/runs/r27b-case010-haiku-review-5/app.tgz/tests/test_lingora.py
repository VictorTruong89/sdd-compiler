"""Behavioural tests for LINGORA. Packaged resources are faked in a temp directory."""

import io
import json
import os
import sys

import pytest

import lingora.data as ldata
from lingora.chunk import RegexpParser
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.cli import cli
from lingora.grammar import CFG
from lingora.metrics import accuracy as list_accuracy
from lingora.metrics import edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def fake_data(tmp_path, monkeypatch):
    """Install fake Punkt and perceptron resources as the only visible data."""
    root = tmp_path / "data"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("dr\nmr\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\nhe\nit\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("the\t32\n", encoding="utf-8")

    tagger = root / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        json.dumps({"bias": {"NN": 1.0}, "i word the": {"DT": 5.0}}), encoding="utf-8"
    )
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT"}), encoding="utf-8"
    )
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["DT", "NN"]), encoding="utf-8"
    )
    monkeypatch.setattr(ldata, "path", [str(root)])
    return root


@pytest.fixture
def no_data(monkeypatch):
    monkeypatch.setattr(ldata, "path", [])


# --- tokenizers -------------------------------------------------------------

def test_wordpunct_and_spans():
    assert wordpunct_tokenize("Hi, 3.50 ok!") == ["Hi", ",", "3", ".", "50", "ok", "!"]
    spans = list(WordPunctTokenizer().span_tokenize("ab  cd!"))
    assert ["ab  cd!"[s:e] for s, e in spans] == ["ab", "cd", "!"]


def test_empty_and_whitespace_are_empty(no_data):
    assert wordpunct_tokenize("") == []
    assert wordpunct_tokenize("  \n ") == []
    assert TreebankWordTokenizer().tokenize("   ") == []
    assert WhitespaceTokenizer().tokenize(" \t ") == []


def test_treebank_quotes_clitics_and_fused_forms():
    out = TreebankWordTokenizer().tokenize('"Hi," she said. I\'m gonna go.')
    assert out[:2] == ["``", "Hi"]
    assert "''" in out and "gon" in out and "na" in out and "'m" in out
    assert TreebankWordTokenizer().tokenize("We cannot.") == ["We", "can", "not", "."]
    assert TreebankWordTokenizer().tokenize("3,000 and a, b") == ["3,000", "and", "a", ",", "b"]


def test_treebank_point_only_at_end_of_text():
    assert TreebankWordTokenizer().tokenize("Pay 3.88 now.") == ["Pay", "3.88", "now", "."]
    assert TreebankWordTokenizer().tokenize("Hi there. Bye") == ["Hi", "there.", "Bye"]


def test_word_tokenize_preserve_line_needs_no_model(no_data):
    out = word_tokenize("cannot stop...", preserve_line=True)
    assert out == ["cannot", "stop", "..."]


def test_sentence_split_requires_punkt(no_data):
    with pytest.raises(LookupError):
        sent_tokenize("A b. C d.")
    with pytest.raises(LookupError):
        word_tokenize("A b. C d.")


def test_sentence_split_with_model(fake_data):
    sents = sent_tokenize("Dr. Jones went home. He was tired!  It was late")
    assert sents == ["Dr. Jones went home.", "He was tired!", "It was late"]
    assert sent_tokenize("") == []
    assert word_tokenize("The dog barks.") == ["The", "dog", "barks", "."]


def test_whitespace_blankline_regexp():
    assert WhitespaceTokenizer().tokenize("a\tb\n c") == ["a", "b", "c"]
    assert blankline_tokenize("a b\n\n  c\nd\n \n\ne") == ["a b", "c\nd", "e"]
    assert RegexpTokenizer(r"\d+").tokenize("a12b3") == ["12", "3"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "b"]
    assert RegexpTokenizer(r",", gaps=True, discard_empty=False).tokenize("a,,b") == ["a", "", "b"]


def test_tweet_tokenizer_defaults():
    toks = TweetTokenizer().tokenize("@bob Don't CAFÉ :) #tag")
    assert "Don't" in toks and "CAFÉ" in toks and ":)" in toks
    assert "@bob" in toks and "#tag" in toks
    lower = TweetTokenizer(preserve_case=False, strip_handles=True).tokenize("@bob CAFÉ")
    assert lower == ["café"]


# --- stemmers ----------------------------------------------------------------

def test_porter_lingora_extensions():
    p = PorterStemmer()
    assert p.stem("ties") == "tie"
    assert p.stem("Running") == "run"  # lowercasing is on by default
    assert p.stem("ab") == "ab"
    assert p.stem("generalization") == "gener"
    assert p.stem("Running", to_lowercase=False) == "Run"  # case kept


def test_snowball_english_and_errors(no_data):
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("running") == "run"
    with pytest.raises(ValueError, match="bogus"):
        SnowballStemmer("bogus")
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_regexp_stemmer_and_lancaster_lowercases():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("cars") == "cars"
    assert isinstance(LancasterStemmer().stem("Running"), str)


# --- taggers -----------------------------------------------------------------

def test_sequential_taggers():
    train = [[("the", "DT"), ("dog", "NN")], [("dog", "NN")]]
    ut = UnigramTagger(train)
    assert ut.tag(["dog", "zzz"]) == [("dog", "NN"), ("zzz", None)]
    backed = UnigramTagger(train, backoff=DefaultTagger("XX"))
    assert backed.tag(["dog", "zzz"]) == [("dog", "NN"), ("zzz", "XX")]
    assert RegexpTagger([(r".*ing$", "VBG")]).tag(["running", "dog"]) == [
        ("running", "VBG"),
        ("dog", None),
    ]
    assert DefaultTagger("NN").tag([]) == []


def test_pos_tag_refusals_and_resources(fake_data, no_data):
    with pytest.raises(TypeError):
        pos_tag("the dog")
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="fra")
    with pytest.raises(LookupError):
        pos_tag(["x"])


def test_pos_tag_with_model(fake_data):
    assert pos_tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]
    # The universal mapping table is not in the fake data, so mapping must fail.
    with pytest.raises(LookupError):
        pos_tag(["the"], tagset="universal")


# --- chunking ----------------------------------------------------------------

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barks", "VBZ")]


def test_chunk_rule_and_root_label():
    t = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert t.label() == "S"
    assert t[0].label() == "NP"
    assert t[0].leaves() == [("the", "DT"), ("big", "JJ"), ("dog", "NN")]
    assert t[1] == ("barks", "VBZ")


def test_chink_splits_chunk():
    t = RegexpParser("NP: {<DT|JJ|NN|VBZ>+}\n }<VBZ>{").parse(TAGGED)
    labels = [c.label() if isinstance(c, Tree) else c[0] for c in t]
    assert labels == ["NP", "barks"]


def test_chunk_refuses_bad_grammar():
    with pytest.raises(TypeError):
        RegexpParser(42)
    assert RegexpParser("NP: {<NN>}").parse([]).leaves() == []


# --- grammars and parsing ----------------------------------------------------

GRAMMAR = CFG.fromstring(
    """
S -> NP VP
NP -> 'I' | Det N
VP -> V NP
Det -> 'the' | 'a'
N -> 'man' | 'dog'
V -> 'saw'
"""
)


def test_chart_parser_finds_tree_and_empty_result():
    trees = list(ChartParser(GRAMMAR).parse("I saw the man".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == ["I", "saw", "the", "man"]
    assert list(ChartParser(GRAMMAR).parse(["I", "saw"])) == []


def test_unknown_token_raises():
    with pytest.raises(ValueError):
        list(ChartParser(GRAMMAR).parse(["zebra"]))


def test_shift_reduce_agrees_on_unambiguous():
    toks = "I saw the man".split()
    assert list(ShiftReduceParser(GRAMMAR).parse(toks)) == list(ChartParser(GRAMMAR).parse(toks))


def test_generate_bounded():
    g = CFG.fromstring('S -> "a" S | "b"')
    assert list(generate(g, depth=3, n=3)) == [["a", "a", "b"], ["a", "b"], ["b"]]


def test_tree_refusals_and_equality():
    with pytest.raises(TypeError):
        Tree("S", "x")
    with pytest.raises(TypeError):
        Tree("S")
    assert Tree("S", []).leaves() == []
    t = Tree.fromstring("(S (NP I) (VP (V saw)))")
    assert t == Tree("S", [Tree("NP", ["I"]), Tree("VP", [Tree("V", ["saw"])])])
    assert "saw" in t.pformat() and "VP" in t.pformat()


# --- classification ----------------------------------------------------------

def test_naive_bayes_distribution_sums_to_one():
    nb = NaiveBayesClassifier.train(
        [({"w": "good"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "good", "x": 1}, "pos")]
    )
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert nb.classify({"w": "bad"}) == "neg"
    assert nb.classify({"never": 1}) in nb.labels()
    assert sorted(nb.labels()) == ["neg", "pos"]


def test_decision_tree_fits_training_and_accuracy():
    data = [({"a": 1, "b": 0}, "x"), ({"a": 0, "b": 1}, "y"), ({"a": 0, "b": 0}, "z")]
    dt = DecisionTreeClassifier.train(data)
    assert accuracy(dt, data) == 1.0
    assert dt.classify({"q": 1}) in {"x", "y", "z"}


# --- metrics -----------------------------------------------------------------

def test_metric_values():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("", "") == 0
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)


def test_metric_refusals_and_absent_numbers():
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])
    with pytest.raises(TypeError):
        precision([1], {1})
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None


def test_bleu():
    ref = ["the", "cat", "is", "on", "the", "mat"]
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([["a", "b", "c", "d"]], ["a", "b", "x", "d"]) == 0.0


# --- command line ------------------------------------------------------------

def test_cli_tokenize_success(fake_data, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("The dog barks. Dr. Jones sleeps.\n\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code == 0
    out = capsys.readouterr().out
    assert out.splitlines()[0] == "The dog barks . Dr. Jones sleeps ."
    assert out.splitlines()[1] == ""


def test_cli_tokenize_fails_without_model(no_data, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("A b. C d.\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code != 0
    assert capsys.readouterr().out == ""
