"""Shared fixtures: small packaged-resource trees written to a temp directory.

They follow the file layout of spec pack 06 and are not real models.
"""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


@pytest.fixture
def resources(tmp_path, monkeypatch):
    base = str(tmp_path / "res")
    punkt = os.path.join(base, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "mr\ndr\netc\nst\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\nthey\nthen\nyes\n")
    _write(os.path.join(punkt, "collocations.tab"), "Mr\tSmith\n")
    _write(os.path.join(punkt, "ortho_context.tab"), "mr\t2\nsmith\t2\nhello\t16\nthe\t16\nit\t16\nfine\t32\n")

    tagdir = os.path.join(base, "taggers", "averaged_perceptron_tagger_eng")
    weights = {"bias": {"NN": 1.0}, "i word the": {"DT": 5.0}, "i word run": {"VB": 3.0}}
    _write(os.path.join(tagdir, "averaged_perceptron_tagger_eng.weights.json"), json.dumps(weights))
    _write(os.path.join(tagdir, "averaged_perceptron_tagger_eng.tagdict.json"), json.dumps({"dog": "NN"}))
    _write(os.path.join(tagdir, "averaged_perceptron_tagger_eng.classes.json"), json.dumps(["DT", "NN", "VB"]))

    univ = os.path.join(base, "taggers", "universal_tagset")
    _write(os.path.join(univ, "en-ptb.map"), "DT\tDET\nNN\tNOUN\nVB\tVERB\n")

    _write(os.path.join(base, "corpora", "stopwords", "english"), "the\na\nof\n")

    monkeypatch.setattr(data, "path", [base], raising=False)
    data.path[:] = [base]
    yield base
    data.path[:] = []


@pytest.fixture
def no_resources():
    saved = list(data.path)
    data.path[:] = []
    yield
    data.path[:] = saved
