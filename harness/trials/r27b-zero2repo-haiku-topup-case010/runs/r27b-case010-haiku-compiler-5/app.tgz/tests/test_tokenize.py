import pytest

from lingora import data
from lingora import tokenize as tk
from lingora.tokenize import (
    RegexpTokenizer, TreebankWordTokenizer, TweetTokenizer, WhitespaceTokenizer,
    WordPunctTokenizer, blankline_tokenize, sent_tokenize, word_tokenize, wordpunct_tokenize,
)


def test_N000089_wordpunct_splits_words_and_punctuation():
    assert wordpunct_tokenize("Hello, world!") == ["Hello", ",", "world", "!"]
    assert WordPunctTokenizer().tokenize("") == []


def test_N000126_N000127_span_tokenize_slices_back_to_tokens():
    text = "ab, c  d"
    spans = list(WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == WordPunctTokenizer().tokenize(text)
    assert all(isinstance(x, int) for pair in spans for x in pair)


def test_N000097_N000099_penn_treebank_quotes_commas_and_clitics():
    toks = TreebankWordTokenizer().tokenize('"I can\'t go, really." She said')
    assert toks[:2] == ["``", "I"]
    assert "ca" in toks and "n't" in toks
    assert "," in toks


def test_N000101_N000102_penn_fused_forms_split():
    assert TreebankWordTokenizer().tokenize("gonna") == ["gon", "na"]
    assert TreebankWordTokenizer().tokenize("cannot") == ["can", "not"]


def test_N000110_recommended_keeps_cannot_whole(no_resources):
    assert word_tokenize("cannot", preserve_line=True) == ["cannot"]


def test_N000105_N000106_recommended_start_quote_is_closing(no_resources):
    assert word_tokenize('"Hi"', preserve_line=True) == ["''", "Hi", "''"]


def test_N000107_N000108_N000109_recommended_dashes_points_double_hyphen(no_resources):
    toks = word_tokenize("a–b wait.... x--y *z", preserve_line=True)
    assert "–" in toks
    assert "...." in toks
    assert "--" in toks
    assert "*" in toks


def test_N000113_whitespace_tokens():
    assert WhitespaceTokenizer().tokenize(" a\tb\nc ") == ["a", "b", "c"]


def test_N000114_N000115_blankline_segments():
    assert blankline_tokenize("a b\nc\n\n\n d\n\n e") == ["a b\nc", "d", "e"]
    assert blankline_tokenize("   ") == []


def test_N000116_N000118_regexp_token_and_gap_modes():
    assert RegexpTokenizer(r"\d+").tokenize("a12b3") == ["12", "3"]
    assert RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["a", "b"]
    assert RegexpTokenizer(r"\s+", gaps=True, discard_empty=False).tokenize(" a") == ["", "a"]


def test_N000121_N000123_N000124_N000125_tweet_options():
    tz = TweetTokenizer(preserve_case=False)
    assert tz.tokenize("I LOVE :D") == ["i", "love", ":D"]
    assert TweetTokenizer().tokenize("@bob hi") == ["@bob", "hi"]
    assert TweetTokenizer(strip_handles=True).tokenize("hi @bob there") == ["hi", "there"]
    assert TweetTokenizer(reduce_len=True).tokenize("sooooo") == ["sooo"]
    assert TweetTokenizer().tokenize("can't stop café") == ["can't", "stop", "café"]


def test_N000136_empty_inputs(no_resources):
    assert wordpunct_tokenize("") == []
    assert WhitespaceTokenizer().tokenize("   ") == []
    assert word_tokenize("   ", preserve_line=True) == []


def test_N000137_N000138_N000413_sentence_split_without_model_raises(no_resources):
    with pytest.raises(LookupError):
        sent_tokenize("One. Two.")
    with pytest.raises(LookupError):
        word_tokenize("One. Two.")


def test_N000129_N000133_punkt_splits_sentences(resources):
    out = sent_tokenize("Mr. Smith went home. Then he slept. It was fine! Really? Yes.")
    assert out == ["Mr. Smith went home.", "Then he slept.", "It was fine!", "Really?", "Yes."]
    assert sent_tokenize("") == []


def test_N000086_N000409_N000410_word_tokenize_with_sentences(resources):
    toks = word_tokenize("Mr. Smith went home. He slept.")
    assert toks == ["Mr.", "Smith", "went", "home", ".", "He", "slept", "."]
    assert word_tokenize("Mr. Smith.", preserve_line=True) == ["Mr.", "Smith", "."]


def test_N000413_word_tokenize_needs_model_without_preserve_line(no_resources):
    with pytest.raises(LookupError):
        word_tokenize("One line.")


def test_N000385_data_path_is_mutable_list(resources):
    assert isinstance(data.path, list)
    assert data.find("tokenizers/punkt_tab/english/abbrev_types.txt") is not None
    data.path[:] = []
    assert data.find("tokenizers/punkt_tab/english/abbrev_types.txt") is None
