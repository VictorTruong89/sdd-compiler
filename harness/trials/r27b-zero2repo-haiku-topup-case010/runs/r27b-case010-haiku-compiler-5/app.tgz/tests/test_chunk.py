import pytest

from lingora.chunk import RegexpParser
from lingora.tree import Tree

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("ran", "VBD"), ("home", "NN")]


def test_N000236_chunk_rule_builds_labelled_chunk():
    t = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert t.label() == "S"
    assert t[0] == Tree("NP", [("the", "DT"), ("big", "JJ"), ("dog", "NN")])
    assert t[1] == ("ran", "VBD")


def test_N000243_N000245_chink_splits_chunk():
    t = RegexpParser("NP: {<DT><JJ><NN>}\n  }<JJ>{").parse(TAGGED)
    assert t[0] == Tree("NP", [("the", "DT")])
    assert t[1] == ("big", "JJ")
    assert t[2] == Tree("NP", [("dog", "NN")])


def test_N000246_N000249_later_clause_sees_chunk_as_unit():
    grammar = "NP: {<DT>?<JJ>*<NN>}\nVP: {<VBD><NP>}"
    t = RegexpParser(grammar).parse(TAGGED)
    assert isinstance(t[0], Tree)
    assert t[0].label() == "VP" or t[0].label() == "NP"


def test_N000250_N000252_leaves_preserved_and_empty_input():
    t = RegexpParser("NP: {<NN>}").parse(TAGGED)
    assert t.leaves() == TAGGED
    empty = RegexpParser("NP: {<NN>}").parse([])
    assert empty.label() == "S" and len(empty) == 0


def test_N000253_N000256_bad_grammar_type_refused():
    with pytest.raises(TypeError):
        RegexpParser(42)


def test_N000448_tagged_must_be_list_of_pairs():
    with pytest.raises(TypeError):
        RegexpParser("NP: {<NN>}").parse(["dog"])
