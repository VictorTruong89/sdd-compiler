import pytest

from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag


def test_N000198_default_tagger():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]


def test_N000199_N000201_unigram_most_frequent_and_none_for_unseen():
    train = [[("the", "DT"), ("run", "VB")], [("run", "NN"), ("run", "NN")]]
    t = UnigramTagger(train=train)
    assert t.tag(["the", "run", "zzz"]) == [("the", "DT"), ("run", "NN"), ("zzz", None)]


def test_N000205_N000206_backoff_only_for_untagged():
    t = UnigramTagger(train=[[("a", "X")]], backoff=DefaultTagger("Z"))
    assert t.tag(["a", "b"]) == [("a", "X"), ("b", "Z")]


def test_N000202_N000204_regexp_tagger_first_rule_wins():
    t = RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD")])
    assert t.tag(["running", "12", "cat"]) == [("running", "VBG"), ("12", "CD"), ("cat", None)]


def test_N000196_N000197_empty_list_and_str_refused():
    assert DefaultTagger("NN").tag([]) == []
    with pytest.raises(TypeError):
        DefaultTagger("NN").tag("a string")


def test_N000442_pos_tag_refuses_str():
    with pytest.raises(TypeError):
        pos_tag("a string")


def test_N000443_pos_tag_bad_lang_raises(resources):
    with pytest.raises(ValueError):
        pos_tag(["a"], lang="fra")


def test_N000224_N000207_english_perceptron(resources):
    out = pos_tag(["the", "dog", "run"])
    assert out == [("the", "DT"), ("dog", "NN"), ("run", "VB")]


def test_N000215_N000216_universal_tagset(resources):
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


def test_N000224_missing_english_resource_raises(no_resources):
    with pytest.raises(LookupError):
        pos_tag(["the"])


def test_N000219_N000220_pos_tag_missing_resource_for_rus(resources):
    with pytest.raises(LookupError):
        pos_tag(["кот"], lang="rus")
