import subprocess
import sys

import pytest

from lingora.cli import cli


def test_N000414_N000416_cli_tokenize_writes_one_line_per_input_line(resources, capsys, monkeypatch):
    import io
    monkeypatch.setattr("sys.stdin", io.TextIOWrapper(io.BytesIO(b"Mr. Smith went home. He slept.\n"), encoding="utf-8"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    out = capsys.readouterr().out
    assert code == 0
    assert out == "Mr. Smith went home . He slept .\n"


def test_N000417_N000419_cli_failure_writes_no_token_line(no_resources):
    proc = subprocess.run(
        [sys.executable, "-c", "from lingora.cli import cli; cli.main(args=['tokenize'])"],
        input=b"Hello there.\n", capture_output=True,
        cwd="/app", env={"LINGORA_DATA": "/nonexistent", "HOME": "/nonexistent", "PATH": "/usr/bin:/bin"},
    )
    assert proc.returncode != 0
    assert proc.stdout == b""
