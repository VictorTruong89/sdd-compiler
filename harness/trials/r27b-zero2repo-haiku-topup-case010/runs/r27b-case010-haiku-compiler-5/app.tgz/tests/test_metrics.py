import pytest

from lingora import classify as cl
from lingora.metrics import accuracy, edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.translate import bleu


def test_N000322_N000324_edit_distance_costs():
    assert edit_distance("rain", "shine") == 3
    assert edit_distance("rain", "shine", substitution_cost=2) == 5
    assert edit_distance("", "") == 0


def test_N000325_N000327_transposition_option():
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ca", "abc", transpositions=True) == 2


def test_N000328_N000329_symmetric_and_self_zero():
    assert edit_distance("kitten", "sitting") == edit_distance("sitting", "kitten")
    assert edit_distance("same", "same") == 0


def test_N000330_accuracy_positions():
    assert accuracy([1, 2, 3, 4], [1, 0, 3, 0]) == 0.5


def test_N000343_N000502_accuracy_different_lengths_raises():
    with pytest.raises(ValueError):
        accuracy([1, 2], [1])


def test_N000332_N000333_precision_recall_fmeasure():
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)


def test_N000344_N000347_none_results_and_non_set_refused():
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        precision([1], {1})


def test_N000331_jaccard():
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


def test_N000335_N000339_bleu_identical_and_zero():
    ref = "the cat sat on the mat".split()
    assert bleu([ref], list(ref)) == pytest.approx(1.0)
    assert bleu([ref], "x y z w v".split()) == 0.0


def test_N000340_bleu_exact_tokens():
    ref = ["The", "cat"]
    assert bleu([ref], ["the", "cat"]) == 0.0


def test_N000302_N000309_naive_bayes_classifies_and_lists_labels():
    train = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "great"}, "pos")]
    nb = cl.NaiveBayesClassifier.train(train)
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"w": "bad"}) == "neg"
    assert sorted(nb.labels()) == ["neg", "pos"]
    dist = nb.prob_classify({"w": "bad"})
    assert sum(dist.prob(l) for l in dist.samples()) == pytest.approx(1.0)
    assert isinstance(dist.prob("neg"), float)


def test_N000315_N000317_unseen_features_still_get_trained_label():
    nb = cl.NaiveBayesClassifier.train([({"a": 1}, "x"), ({"a": 2}, "y")])
    assert nb.classify({"zzz": 1}) in ("x", "y")
    dt = cl.DecisionTreeClassifier.train([({"a": 1}, "x"), ({"a": 2}, "y")])
    assert dt.classify({"zzz": 1}) in ("x", "y")


def test_N000310_N000314_decision_tree_separates_training_data():
    train = [({"f": "p"}, "yes"), ({"f": "q"}, "no"), ({"f": "p", "g": 1}, "yes"), ({"f": "q", "g": 2}, "no")]
    dt = cl.DecisionTreeClassifier.train(train)
    for fs, label in train:
        assert dt.classify(fs) == label


def test_N000318_classifier_accuracy():
    nb = cl.NaiveBayesClassifier.train([({"w": 1}, "a"), ({"w": 2}, "b")])
    assert cl.accuracy(nb, [({"w": 1}, "a"), ({"w": 2}, "b")]) == 1.0
