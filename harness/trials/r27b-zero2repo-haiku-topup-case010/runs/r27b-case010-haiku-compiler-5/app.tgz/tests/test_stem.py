import pytest

from lingora import data
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer, WordNetLemmatizer


def test_N000422_N000424_porter_default_lowercases_and_extension_ties():
    p = PorterStemmer()
    assert p.stem("Running") == "run"
    assert p.stem("ties") == "tie"  # LINGORA Step 1a extension (four letters, -ies -> -ie)
    assert PorterStemmer(mode="ORIGINAL_ALGORITHM").stem("ties") == "ti"


def test_N000153_N000157_porter_short_words_untouched():
    p = PorterStemmer()
    assert p.stem("as") == "as"
    assert p.stem("A") == "a"


def test_N000422_porter_to_lowercase_false_keeps_case():
    assert PorterStemmer().stem("Running", to_lowercase=False) == "Run"
    assert PorterStemmer().stem("Ties", to_lowercase=False) == "Tie"


def test_N000158_N000160_porter_ied_rule():
    p = PorterStemmer()
    assert p.stem("died") == "die"
    assert p.stem("carried") == "carri"


def test_N000426_N000427_porter_classic_outputs():
    p = PorterStemmer(mode="ORIGINAL_ALGORITHM")
    assert p.stem("caresses") == "caress"
    assert p.stem("generalization") == "gener"
    assert p.stem("hopefulness") == "hope"
    assert p.stem("controlling") == "control"


def test_N000170_N000171_lancaster_known_outputs():
    l = LancasterStemmer()
    assert l.stem("maximum") == "maxim"
    assert l.stem("presumably") == "presum"


def test_N000178_N000180_regexp_stemmer_removes_match_only():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("cat") == "cat"


def test_N000173_N000175_snowball_english_porter2():
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("cried") == "cri"
    assert s.stem("skies") == "sky"
    assert s.stem("succeed") == "succeed"


def test_N000181_N000182_snowball_unknown_language_names_it():
    with pytest.raises(ValueError) as exc:
        SnowballStemmer("klingon")
    assert "klingon" in str(exc.value)


def test_N000183_N000184_snowball_stopwords_missing_raises(no_resources):
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N000177_snowball_stopword_skipping(resources):
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"
    assert s.stem("running") == "run"


def test_N000185_N000186_wordnet_missing_raises(no_resources):
    with pytest.raises(LookupError):
        WordNetLemmatizer()
