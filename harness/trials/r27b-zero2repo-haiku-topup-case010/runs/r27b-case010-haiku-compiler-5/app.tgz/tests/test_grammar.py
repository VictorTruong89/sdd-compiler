import pytest

from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

G = """
S -> NP VP
NP -> 'the' N | 'a' N
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'saw' | 'ran'
"""


def test_N000464_N000467_grammar_reading():
    g = CFG.fromstring(G)
    assert str(g.start()) == "S"
    rhs = g.productions()[0].rhs()
    assert [str(s) for s in rhs] == ["NP", "VP"]
    np = g.productions()[1]
    assert np.rhs()[0] == "the"
    assert not isinstance(np.rhs()[1], str)


def test_N000471_one_production_per_alternative():
    g = CFG.fromstring(G)
    assert len([p for p in g.productions() if str(p.lhs()) == "N"]) == 2


def test_N000266_N000268_chart_parser_all_trees():
    amb = CFG.fromstring('S -> S S | "a"')
    assert len(list(ChartParser(amb).parse(["a", "a", "a"]))) == 2


def test_N000266_chart_parser_builds_tree():
    trees = list(ChartParser(CFG.fromstring(G)).parse(["the", "dog", "ran"]))
    assert len(trees) == 1
    assert trees[0].leaves() == ["the", "dog", "ran"]
    assert trees[0].label() == "S"


def test_N000273_N000275_shift_reduce_matches_chart_on_unambiguous():
    g = CFG.fromstring(G)
    sr = list(ShiftReduceParser(g).parse(["the", "dog", "ran"]))
    ch = list(ChartParser(g).parse(["the", "dog", "ran"]))
    assert sr == ch


def test_N000292_N000294_underivable_gives_empty_and_unknown_token_raises():
    g = CFG.fromstring(G)
    assert list(ChartParser(g).parse(["dog", "ran"])) == []
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])
    with pytest.raises(ValueError):
        ShiftReduceParser(g).parse(["zebra"])


def test_N000276_N000280_generator_order_and_limit():
    out = list(generate(CFG.fromstring(G), n=4))
    assert out[0] == ["the", "dog", "saw", "the", "dog"]
    assert len(out) == 4


def test_N000281_N000291_tree_semantics():
    t = Tree("S", ["a", Tree("N", ["b"])])
    assert len(t) == 2 and t[0] == "a"
    assert t == Tree("S", ["a", Tree("N", ["b"])])
    assert t != Tree("S", ["a"])
    assert Tree("X", []) == Tree("X", [])
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")


def test_N000286_N000489_fromstring_equals_constructed():
    t = Tree.fromstring("(S (NP the dog) (VP ran))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["ran"])])
    assert t.leaves() == ["the", "dog", "ran"]


def test_N000287_pformat_preorder():
    s = Tree.fromstring("(S (NP the dog) (VP ran))").pformat()
    assert s.index("S") < s.index("NP") < s.index("VP") < s.index("ran")
