"""Command line. # spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000135 N-000134 N-000139

``from lingora.cli import cli`` — a command group. ``cli.main(args=[...], standalone_mode=True)``.
Options (language, delimiter, encoding) and exit codes are the implementer's choice:
``--language`` (default ``english``), ``--delimiter`` (default one space), ``--encoding`` (default UTF-8).
Failures exit with status 1 and write a message to standard error.
"""

import sys

__all__ = ["cli", "Group", "UsageError"]


class UsageError(Exception):
    pass


class Group:
    def __init__(self, name):
        self.name = name
        self._commands = {}

    def command(self, name):
        def register(fn):
            self._commands[name] = fn
            return fn
        return register

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            if not args or args[0] in ("-h", "--help"):
                code = self._usage()
            elif args[0] not in self._commands:
                raise UsageError("unknown command %r" % (args[0],))
            else:
                code = self._commands[args[0]](args[1:])
        except UsageError as exc:
            if not standalone_mode:
                raise
            sys.stderr.write("%s: %s\n" % (self.name, exc))
            sys.exit(2)
        except Exception as exc:
            if not standalone_mode:
                raise
            sys.stderr.write("%s: error: %s\n" % (self.name, exc))
            sys.exit(1)
        if standalone_mode:
            sys.exit(code)
        return code

    def _usage(self):
        sys.stdout.write("Usage: %s COMMAND [OPTIONS]\nCommands: %s\n" % (self.name, ", ".join(sorted(self._commands))))
        return 0


def _parse_options(args, allowed):
    opts = dict(allowed)
    i = 0
    while i < len(args):
        a = args[i]
        if a.startswith("--") and "=" in a:
            key, value = a[2:].split("=", 1)
        elif a.startswith("--"):
            key = a[2:]
            if i + 1 >= len(args):
                raise UsageError("option --%s needs a value" % key)
            i += 1
            value = args[i]
        else:
            raise UsageError("unexpected argument %r" % (a,))
        if key not in allowed:
            raise UsageError("no such option: --%s" % key)
        opts[key] = value
        i += 1
    return opts


cli = Group("lingora")


@cli.command("tokenize")
def _tokenize(args):
    """Apply the recommended word tokenizer (with sentence splitting) to each stdin line. # spec: N-000414 N-000415 N-000416 N-000417 N-000418"""
    from .tokenize import word_tokenize

    opts = _parse_options(args, {"language": "english", "delimiter": " ", "encoding": "utf-8"})
    encoding = opts["encoding"]
    in_stream = getattr(sys.stdin, "buffer", None)
    out_stream = getattr(sys.stdout, "buffer", None)
    if in_stream is None or out_stream is None:
        for raw in sys.stdin:
            line = raw.rstrip("\r\n")
            tokens = word_tokenize(line, language=opts["language"], preserve_line=False)
            sys.stdout.write(opts["delimiter"].join(tokens) + "\n")
            sys.stdout.flush()
        return 0
    for raw in in_stream:
        line = raw.decode(encoding).rstrip("\r\n")
        tokens = word_tokenize(line, language=opts["language"], preserve_line=False)
        out_stream.write((opts["delimiter"].join(tokens) + "\n").encode(encoding))
        out_stream.flush()
    return 0
