"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

# spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000086 N-000137 N-000138

Parameters come from the packaged resource ``tokenizers/punkt_tab/<language>/``:
``abbrev_types.txt``, ``sent_starters.txt``, ``collocations.tab`` and
``ortho_context.tab`` (format in spec pack 06).
"""

import os
import re

from . import data

ORTHO_BEG_UC = 2
ORTHO_MID_UC = 4
ORTHO_UNK_UC = 8
ORTHO_BEG_LC = 16
ORTHO_MID_LC = 32
ORTHO_UNK_LC = 64

NUMBER_TYPE = "##number##"
_NUMBER_RE = re.compile(r"^-?[.,]?\d[\d,.\-]*\.?$")
_CLOSERS = "\"'”’»)]}>"
_END_CHARS = ".?!"


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.sent_starters = set()
        self.collocations = set()
        self.ortho_context = {}


def _read_lines(filename):
    with open(filename, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


def load_parameters(language):
    """Load the packaged Punkt parameters for ``language``.

    Raises :class:`lingora.data.ResourceMissing` when the model is not visible.
    """
    if not language or "/" in language or "\\" in language or language in (".", ".."):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    base = data.require("tokenizers/punkt_tab/%s" % language, "Punkt model for %s" % language)
    params = PunktParameters()
    params.abbrev_types = {l.strip().lower() for l in _read_lines(os.path.join(base, "abbrev_types.txt")) if l.strip()}
    params.sent_starters = {l.strip().lower() for l in _read_lines(os.path.join(base, "sent_starters.txt")) if l.strip()}
    for line in _read_lines(os.path.join(base, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[0] and parts[1]:
            params.collocations.add((parts[0], parts[1]))
    for line in _read_lines(os.path.join(base, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[0]:
            params.ortho_context[parts[0]] = int(parts[1])
    return params


_CACHE = {}


def get_parameters(language):
    """Return cached parameters, loading them on first use from the current data path."""
    key = (language, tuple(data.path))
    if key not in _CACHE:
        _CACHE.clear()
        _CACHE[key] = load_parameters(language)
    return _CACHE[key]


class _Tok:
    __slots__ = ("start", "end", "core", "type", "period", "ends", "first_upper", "first_lower", "number")


def _make_tok(start, end, word):
    tok = _Tok()
    tok.start, tok.end = start, end
    core = word.rstrip(_CLOSERS)
    if not core:
        core = word
    tok.core = core
    tok.ends = core[-1] in _END_CHARS
    tok.period = core.endswith(".")
    stripped = core.rstrip(_END_CHARS)
    tok.number = bool(_NUMBER_RE.match(stripped)) if stripped else False
    tok.type = NUMBER_TYPE if tok.number else stripped.lower()
    alpha = [c for c in stripped if c.isalpha()]
    tok.first_upper = bool(alpha) and alpha[0].isupper()
    tok.first_lower = bool(alpha) and alpha[0].islower()
    return tok


def _ortho_break(params, nxt):
    """Return True (break), False (no break), or None (undecided) from orthographic context of ``nxt``."""
    ctx = params.ortho_context.get(nxt.type, 0)
    if nxt.first_upper and (ctx & (ORTHO_MID_LC | ORTHO_UNK_LC)) and not (ctx & ORTHO_BEG_UC):
        return False
    if nxt.first_lower and (ctx & (ORTHO_BEG_UC | ORTHO_UNK_UC)) and not (ctx & (ORTHO_BEG_LC | ORTHO_MID_LC | ORTHO_UNK_LC)):
        return True
    return None


def sentence_spans(text, params):
    """Return ``(start, end)`` character spans of the sentences of ``text``."""
    toks = [_make_tok(m.start(), m.end(), m.group()) for m in re.finditer(r"\S+", text)]
    if not toks:
        return []
    spans = []
    first = 0
    for i, tok in enumerate(toks):
        if not tok.ends:
            continue
        nxt = toks[i + 1] if i + 1 < len(toks) else None
        if nxt is None:
            break_here = True
        elif tok.core[-1] in "?!":
            break_here = True
        else:
            break_here = _period_break(params, tok, nxt)
        if break_here:
            spans.append((toks[first].start, tok.end))
            first = i + 1
    if first < len(toks):
        spans.append((toks[first].start, toks[-1].end))
    return spans


def _period_break(params, tok, nxt):
    if (tok.type, nxt.type) in params.collocations:
        return False
    ortho = _ortho_break(params, nxt)
    if tok.type in params.abbrev_types or tok.number:
        if nxt.first_upper and nxt.type in params.sent_starters:
            return ortho is not False
        return False
    if ortho is False:
        return False
    if nxt.first_lower:
        return False
    return True


def sentences(text, language="english"):
    """Split ``text`` into sentence strings, in order, without the separating whitespace."""
    params = get_parameters(language)
    return [text[s:e] for s, e in sentence_spans(text, params)]
