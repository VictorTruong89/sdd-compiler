"""Chunking with chunk grammars. Feature point FP-04.

# spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235 N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242 N-000243 N-000244 N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256 N-000257 N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460

Decisions (see NOTES.md):
* Chunk rules match only tokens not yet in a chunk, plus chunks built by an
  earlier clause, which are seen as one unit labelled with the chunk's label;
  a match that includes such a unit absorbs it, so the result stays shallow.
* Chink rules only remove tokens from chunks built earlier in the same clause.
* Touching matches stay separate chunks.
"""

import re

from .tree import Tree

DEFAULT_ROOT_LABEL = "S"
_BARRIER = "\x00"
_CLAUSE_RE = re.compile(r"^(\w+)\s*:\s*(.*)$")
_QUANT_RE = re.compile(r"\?|\*|\+|\{\d*,?\d*\}")

__all__ = ["RegexpParser", "ne_chunk"]


class _Chunk:
    __slots__ = ("label", "clause")

    def __init__(self, label, clause):
        self.label = label
        self.clause = clause


class _Elem:
    __slots__ = ("pair", "chunk")

    def __init__(self, pair):
        self.pair = pair
        self.chunk = None


def _tag_pattern_regex(pattern):
    """Translate a tag pattern (``<...>`` elements with quantifiers) into a regex over the tag string."""
    text = re.sub(r"\s+", "", pattern)
    out = []
    i = 0
    while i < len(text):
        if text[i] != "<":
            raise ValueError("tag pattern must consist of <...> elements, found %r in %r" % (text[i], pattern))
        j = text.find(">", i)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern %r" % (pattern,))
        content = text[i + 1:j]
        if "<" in content:
            raise ValueError("nested '<' in tag pattern %r" % (pattern,))
        content = content.replace(".", "[^<>]")
        try:
            re.compile(content)
        except re.error as exc:
            raise ValueError("bad element %r in tag pattern: %s" % (content, exc))
        i = j + 1
        m = _QUANT_RE.match(text, i)
        quant = ""
        if m:
            quant = m.group(0)
            i = m.end()
        out.append("(?:<(?:%s)>)%s" % (content, quant))
    return "".join(out)


def _parse_grammar(text):
    """Return a list of clauses; each clause is ``(label, [rule, ...])`` with rules ``('chunk'|'chink', regex)``."""
    clauses = []
    current = None
    for lineno, raw in enumerate(text.splitlines(), 1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indented = raw[0].isspace()
        line = raw.strip()
        if not indented:
            m = _CLAUSE_RE.match(line)
            if not m:
                raise ValueError("line %d: expected '<LABEL>: <pattern>'" % lineno)
            current = (m.group(1), [])
            clauses.append(current)
            line = m.group(2).strip()
            if not line:
                continue
        if current is None:
            raise ValueError("line %d: pattern before any clause label" % lineno)
        current[1].append(_parse_pattern(line, lineno))
    return clauses


def _parse_pattern(line, lineno):
    if line.startswith("{") and line.endswith("}"):
        return ("chunk", re.compile(_tag_pattern_regex(line[1:-1])))
    if line.startswith("}") and line.endswith("{"):
        return ("chink", re.compile(_tag_pattern_regex(line[1:-1])))
    raise ValueError("line %d: pattern must be {<tags>} or }<tags>{" % lineno)


class RegexpParser:
    """Chunk parser for a chunk grammar (text, or a list of parser stages). # spec: N-000446 N-000447 N-000449 N-000450 N-000451 N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460"""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list):
            clauses = []
            for stage in grammar:
                if isinstance(stage, RegexpParser):
                    clauses.extend(stage._clauses)
                elif isinstance(stage, str):
                    clauses.extend(_parse_grammar(stage))
                else:
                    raise TypeError("chunk grammar stages must be RegexpParser objects or grammar text")
            self._clauses = clauses
        else:
            raise TypeError("chunk grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("parse() takes a list of (token, tag) pairs")
        elems = []
        for pair in tagged:
            if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                raise TypeError("each item must be a (token, tag) pair")
            elems.append(_Elem((pair[0], pair[1])))
        for clause_no, (label, rules) in enumerate(self._clauses):
            for kind, regex in rules:
                if kind == "chunk":
                    _apply_chunk(elems, regex, label, clause_no)
                else:
                    _apply_chink(elems, regex, clause_no)
        return Tree(DEFAULT_ROOT_LABEL, _to_children(elems))


def _apply_chunk(elems, regex, label, clause_no):
    # Units: unchunked tokens and earlier-clause chunks (as one unit each); same-clause chunks are barriers.
    units = []  # (start_elem, end_elem, tag or None)
    i = 0
    while i < len(elems):
        ch = elems[i].chunk
        if ch is None:
            units.append((i, i + 1, elems[i].pair[1]))
            i += 1
        elif ch.clause == clause_no:
            units.append((i, i + 1, None))
            i += 1
        else:
            j = i
            while j < len(elems) and elems[j].chunk is ch:
                j += 1
            units.append((i, j, ch.label))
            i = j
    text_parts = []
    start_of = {}  # char offset where a unit starts -> unit index
    end_of = {}    # char offset where a unit ends -> unit index + 1
    pos = 0
    for idx, (_, _, tag) in enumerate(units):
        part = _BARRIER if tag is None else "<%s>" % tag
        start_of[pos] = idx
        pos += len(part)
        end_of[pos] = idx + 1
        text_parts.append(part)
    s = "".join(text_parts)
    for m in regex.finditer(s):
        if m.end() == m.start():
            continue
        us = start_of.get(m.start())
        ue = end_of.get(m.end())
        if us is None or ue is None:
            continue
        first = units[us][0]
        last = units[ue - 1][1]
        chunk = _Chunk(label, clause_no)
        for k in range(first, last):
            elems[k].chunk = chunk


def _apply_chink(elems, regex, clause_no):
    parts = []
    for elem in elems:
        ch = elem.chunk
        if ch is not None and ch.clause != clause_no:
            parts.append(_BARRIER)
        else:
            parts.append("<%s>" % elem.pair[1])
    s = "".join(parts)
    start_of = {}
    end_of = {}
    pos = 0
    for idx, part in enumerate(parts):
        start_of[pos] = idx
        pos += len(part)
        end_of[pos] = idx + 1
    for m in regex.finditer(s):
        if m.end() == m.start():
            continue
        a = start_of.get(m.start())
        b = end_of.get(m.end())
        if a is None or b is None:
            continue
        for k in range(a, b):
            if elems[k].chunk is not None and elems[k].chunk.clause == clause_no:
                elems[k].chunk = None


def _to_children(elems):
    children = []
    i = 0
    while i < len(elems):
        ch = elems[i].chunk
        if ch is None:
            children.append(elems[i].pair)
            i += 1
            continue
        j = i
        pairs = []
        while j < len(elems) and elems[j].chunk is ch:
            pairs.append(elems[j].pair)
            j += 1
        children.append(Tree(ch.label, pairs))
        i = j
    return children


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Raises LookupError when its model or the English wordlist is not visible. # spec: N-000452"""
    from . import data
    data.require("corpora/words", "English wordlist")
    data.require("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", "named-entity chunker")
    raise NotImplementedError("the packaged named-entity chunker model format is not implemented")
