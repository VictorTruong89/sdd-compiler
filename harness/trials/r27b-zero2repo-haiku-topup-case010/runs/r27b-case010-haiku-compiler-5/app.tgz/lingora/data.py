"""Packaged-resource finder. # spec: N-000385 N-000386 N-000387 N-000388 N-000397 N-000398 N-000402

``path`` is a mutable list of directories searched for packaged resources.
Callers may replace its contents in place; every lookup reads it at call time.
"""

import os

__all__ = ["path", "find", "require", "ResourceMissing"]


class ResourceMissing(LookupError):
    """Raised when a required packaged resource is not visible on ``path``."""


def _initial_path():
    dirs = []
    env = os.environ.get("LINGORA_DATA", "")
    dirs.extend(d for d in env.split(os.pathsep) if d)
    dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return dirs


# spec: N-000385 — the initial contents are the implementer's choice.
path = _initial_path()


def find(relpath):
    """Return the absolute path of ``relpath`` under the first directory of
    ``path`` that holds it, or ``None`` when no directory on ``path`` has it."""
    for base in list(path):
        candidate = os.path.join(base, *relpath.split("/"))
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    return None


def require(relpath, what=None):
    """Like :func:`find`, but raise :class:`ResourceMissing` when absent."""
    found = find(relpath)
    if found is None:
        label = what or relpath
        raise ResourceMissing(
            "packaged resource %r (%s) is not visible on lingora.data.path" % (relpath, label)
        )
    return found
