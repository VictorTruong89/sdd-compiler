"""LINGORA Language Toolkit: a pure-Python NLP library.

Importing the package downloads nothing and reads no resource.
"""

__version__ = "0.1.0"
