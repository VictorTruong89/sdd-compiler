"""Tokenizers. # spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412 N-000413

Feature point FP-01 (word, punctuation and sentence tokenization).
"""

import re

from . import _punkt
from . import data

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _spans_from_tokens(text, tokens):
    spans = []
    pos = 0
    for tok in tokens:
        idx = text.index(tok, pos)
        spans.append((idx, idx + len(tok)))
        pos = idx + len(tok)
    return spans


class WordPunctTokenizer:
    """Word/punctuation tokenizer. # spec: N-000089 N-000090 N-000091 N-000126 N-000127 N-000128"""

    _pattern = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        return [m.span() for m in self._pattern.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Tokens are maximal runs of non-whitespace. # spec: N-000113"""

    def tokenize(self, text):
        return text.split()

    def span_tokenize(self, text):
        return [m.span() for m in re.finditer(r"\S+", text)]


_SEPARATOR_RE = re.compile(r"[ \t\r\f\v]*\n[ \t\r\f\v]*\n\s*")


def blankline_tokenize(text):
    """Segments separated by a blank line. # spec: N-000114 N-000115"""
    pieces = _SEPARATOR_RE.split(text)
    return [p.strip() for p in pieces if p.strip()]


class RegexpTokenizer:
    """Regular-expression tokenizer. # spec: N-000116 N-000117 N-000118 N-000126 N-000127 N-000128

    In token mode (default) the tokens are the matches of ``pattern``; in gap
    mode (``gaps=True``) they are the pieces between matches. Empty pieces are
    dropped unless ``discard_empty=False``.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._regexp = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text)]

    def span_tokenize(self, text):
        spans = []
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


# ---------------------------------------------------------------------------
# Penn Treebank conventions. # spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103
# ---------------------------------------------------------------------------

_PTB_STARTING_QUOTES = [
    (re.compile(r"^\""), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r"([ \(\[{<])(\"|'{2})"), r"\1 `` "),
]

_PTB_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]

_PTB_BRACKETS = [(re.compile(r"[\]\[\(\)\{\}<>]"), r" \g<0> ")]

_PTB_ENDING_QUOTES = [
    (re.compile(r"\""), " '' "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]

_PTB_CONTRACTIONS = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)('t)(is)\b"), r"\1 \2"),
    (re.compile(r"(?i)('t)(was)\b"), r"\1 \2"),
]


def _ptb_tokenize(text, recommended=False):
    if recommended:
        # Typographic quotation marks, dashes U+2012-U+2015 and asterisks are split off.
        text = re.sub(r"([\u201c\u201d\u201e\u2018\u2019\u00ab\u00bb])", r" \1 ", text)
        text = re.sub(r"([\u2012-\u2015*])", r" \1 ", text)
        # A double hyphen is a token; a run of two or more points is a token.
        text = re.sub(r"--", " -- ", text)
        text = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), text)
    first_quote = recommended and text.startswith('"')
    for regexp, sub in _PTB_STARTING_QUOTES:
        text = regexp.sub(sub, text)
    if first_quote:
        # A straight double quote at the very start of the text is a closing quote.
        text = text.replace("``", "''", 1)
    for regexp, sub in _PTB_PUNCTUATION:
        if recommended and regexp.pattern == r"\.\.\.":
            continue  # runs of points are already tokens on this path
        text = regexp.sub(sub, text)
    for regexp, sub in _PTB_BRACKETS:
        text = regexp.sub(sub, text)
    text = " " + text + " "
    for regexp, sub in _PTB_ENDING_QUOTES:
        text = regexp.sub(sub, text)
    contractions = _PTB_CONTRACTIONS
    if recommended:
        # The recommended tokenizer keeps "cannot" as one token.
        contractions = _PTB_CONTRACTIONS[1:]
    for regexp, sub in contractions:
        text = regexp.sub(sub, text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer. # spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103"""

    def tokenize(self, text):
        return _ptb_tokenize(text, recommended=False)


# ---------------------------------------------------------------------------
# Tweet tokenizer. # spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125
# ---------------------------------------------------------------------------

_EMOTICON = r"(?:[:;=8][\-o\*']?[\)\]\(\[dDpP/\\:}{@\|]|<3|:\*)"
_TWEET_RE = re.compile(
    r"(?P<url>https?://\S+|www\.\S+)"
    r"|(?P<handle>@\w+)"
    r"|(?P<hashtag>#\w+)"
    r"|(?P<emoticon>" + _EMOTICON + r")"
    r"|(?P<word>\w+(?:'\w+)+|\w+)"
    r"|(?P<ellipsis>\.{2,})"
    r"|(?P<punct>[^\w\s])"
)
_HANDLE_STRIP_RE = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tweet-style tokenizer. # spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125"""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        if self._strip_handles:
            text = _HANDLE_STRIP_RE.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE_LEN_RE.sub(lambda m: m.group(1) * 3, text)
        out = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group(0)
            if not self._preserve_case and m.lastgroup != "emoticon":
                tok = tok.lower()
            out.append(tok)
        return out


# ---------------------------------------------------------------------------
# Recommended tokenizers. # spec: N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000134 N-000135
# ---------------------------------------------------------------------------

def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (Punkt). # spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000086 N-000137 N-000138"""
    return _punkt.sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer. # spec: N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000409 N-000410

    With ``preserve_line=False`` the text is first split into sentences, which
    needs the Punkt model for ``language``.
    """
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_ptb_tokenize(sentence, recommended=True))
    return tokens
