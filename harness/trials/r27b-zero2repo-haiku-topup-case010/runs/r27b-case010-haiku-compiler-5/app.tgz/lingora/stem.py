"""Stemmers. Feature point FP-02. # spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428 N-000429 N-000430 N-000431 N-000432

Implemented: Porter (default LINGORA mode, plus the original and Martin
Porter modes), Lancaster, Snowball ``english`` (Porter2) and ``porter``,
the regular-expression stemmer, and a WordNet lemmatizer.
"""

import re

from . import data

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

__all__ = [
    "ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
    "SnowballStemmer", "WordNetLemmatizer",
]

_VOWELS = "aeiou"


# ---------------------------------------------------------------------------
# Porter. # spec: N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167 N-000168 N-000169
# ---------------------------------------------------------------------------

def _is_cons(w, i):
    c = w[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _is_cons(w, i - 1)
    return True


def _measure(stem):
    form = "".join("c" if _is_cons(stem, i) else "v" for i in range(len(stem)))
    return len(re.findall("vc", form))


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_cvc(stem, extended):
    if extended and len(stem) == 2 and not _is_cons(stem, 0) and _is_cons(stem, 1):
        return True
    return (len(stem) >= 3 and _is_cons(stem, -3) and not _is_cons(stem, -2)
            and _is_cons(stem, -1) and stem[-1] not in "wxy")


_STEP2_ORIG = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_EXT = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _longest_suffix(word, suffixes):
    best = None
    for s in suffixes:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def _porter_step2(w, table, extended):
    if extended and w.endswith("alli") and _measure(w[:-4]) > 0:
        return _porter_step2(w[:-4] + "al", table, extended)
    suffix = _longest_suffix(w, [s for s, _ in table] + (["logi"] if extended else []))
    if suffix is None:
        return w
    stem = w[: -len(suffix)]
    if suffix == "logi":
        # LINGORA: -logi -> -log, measured on the part before "-ogi".
        if _measure(w[:-3]) > 0:
            return w[:-1]
        return w
    if _measure(stem) > 0:
        repl = dict(table)[suffix]
        return stem + repl
    return w


def _porter_core(word, extended):
    w = word
    if len(w) <= 2:
        return w
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        w = w[:-1] if (extended and len(w) == 4) else w[:-2]
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]
    # Step 1b
    flag = False
    if extended and w.endswith("ied"):
        w = w[:-1] if len(w) == 4 else w[:-2]
        return _porter_step1c_onward(w, extended)
    if w.endswith("eed"):
        if _measure(w[:-3]) > 0:
            w = w[:-1]
    elif w.endswith("ed") and _has_vowel(w[:-2]):
        w = w[:-2]
        flag = True
    elif w.endswith("ing") and _has_vowel(w[:-3]):
        w = w[:-3]
        flag = True
    if flag:
        if w.endswith(("at", "bl", "iz")):
            w += "e"
        elif len(w) >= 2 and w[-1] == w[-2] and w[-1] not in "lsz":
            w = w[:-1]
        elif _measure(w) == 1 and _ends_cvc(w, extended):
            w += "e"
    return _porter_step1c_onward(w, extended)


def _porter_step1c_onward(w, extended):
    # Step 1c
    if w.endswith("y") and len(w) > 2:
        if extended:
            if not _is_cons(w, len(w) - 2) or len(w) - 2 == 0:
                pass
            elif _is_cons(w, len(w) - 2):
                w = w[:-1] + "i"
        elif _has_vowel(w[:-1]):
            w = w[:-1] + "i"
    # Step 2
    w = _porter_step2(w, _STEP2_EXT if extended else _STEP2_ORIG, extended)
    # Step 3
    suffix = _longest_suffix(w, [s for s, _ in _STEP3])
    if suffix is not None and _measure(w[: -len(suffix)]) > 0:
        w = w[: -len(suffix)] + dict(_STEP3)[suffix]
    # Step 4
    suffix = _longest_suffix(w, _STEP4)
    if suffix is not None:
        stem = w[: -len(suffix)]
        if suffix == "ion":
            ok = stem.endswith(("s", "t")) and _measure(stem) > 1
        else:
            ok = _measure(stem) > 1
        if ok:
            w = stem
    # Step 5a
    if w.endswith("e"):
        stem = w[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _ends_cvc(stem, extended)):
            w = stem
    # Step 5b
    if _measure(w) > 1 and w.endswith("ll"):
        w = w[:-1]
    return w


class PorterStemmer:
    """Porter stemmer. ``mode`` is ``"LINGORA"`` (default), ``"ORIGINAL_ALGORITHM"``
    or ``"MARTIN_EXTENSIONS"``. # spec: N-000149 N-000150 N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167 N-000168 N-000169 N-000422 N-000424 N-000425
    """

    MODES = ("LINGORA", "ORIGINAL_ALGORITHM", "MARTIN_EXTENSIONS")

    def __init__(self, mode="LINGORA"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        lowered = word.lower()
        extended = self._mode == "LINGORA"
        stem = _porter_core(lowered, extended)
        if to_lowercase or not lowered.startswith(stem):
            return stem
        # Keep the letter case of the input: the stem is a prefix of the word.
        return word[:len(stem)]


# ---------------------------------------------------------------------------
# Porter2 (Snowball "english"). # spec: N-000173 N-000174 N-000175 N-000176
# ---------------------------------------------------------------------------

_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_V = "aeiouy"


def _is_v(ch):
    return ch in _V


def _r_start(w, start):
    for i in range(max(start + 1, 1), len(w)):
        if _is_v(w[i - 1]) and not _is_v(w[i]):
            return i + 1
    return len(w)


def _regions(w):
    for prefix in ("commun", "gener", "arsen"):
        if w.startswith(prefix):
            r1 = len(prefix)
            break
    else:
        r1 = _r_start(w, -1)
    r2 = _r_start(w, r1)
    return r1, r2


def _short_syllable_end(w):
    if len(w) == 2:
        return _is_v(w[0]) and not _is_v(w[1])
    if len(w) >= 3:
        return (not _is_v(w[-3]) and _is_v(w[-2]) and not _is_v(w[-1])
                and w[-1] not in "wxY")
    return False


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _EXC1:
        return _EXC1[word]
    w = word
    if w[0] == "y":
        w = "Y" + w[1:]
    w = re.sub(r"(?<=[aeiouy])y", "Y", w)
    r1, r2 = _regions(w)
    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(_is_v(c) for c in w[:-2]):
            w = w[:-1]
    if w in _EXC2:
        return w.replace("Y", "y")
    # Step 1b
    r1, r2 = _regions(w)
    if w.endswith(("eedly", "eed")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if any(_is_v(c) for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt":
                        w = w[:-1]
                    else:
                        r1b, _ = _regions(w)
                        if r1b >= len(w) and _short_syllable_end(w):
                            w += "e"
                break
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and not _is_v(w[-2]):
        w = w[:-1] + "i"
    # Step 2 (within R1)
    r1, r2 = _regions(w)
    step2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
        ("ational", "ate"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
        ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
        ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"),
        ("bli", "ble"), ("fulli", "ful"), ("lessli", "less"),
    ]
    done = False
    for suf, rep in sorted(step2, key=lambda t: -len(t[0])):
        if w.endswith(suf):
            if len(w) - len(suf) >= r1:
                w = w[: -len(suf)] + rep
            done = True
            break
    if not done:
        if w.endswith("ogi") and len(w) - 3 >= r1 and w[-4:-3] == "l":
            w = w[:-1]
        elif w.endswith("li") and len(w) - 2 >= r1 and w[-3:-2] in ("c", "d", "e", "g", "h", "k", "m", "n", "r", "t"):
            w = w[:-2]
    # Step 3
    r1, r2 = _regions(w)
    for suf, rep in (("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
                     ("iciti", "ic"), ("ical", "ic"), ("ative", ""), ("ful", ""), ("ness", "")):
        if w.endswith(suf):
            if suf == "ative":
                if len(w) - len(suf) >= r2:
                    w = w[: -len(suf)] + rep
            elif len(w) - len(suf) >= r1:
                w = w[: -len(suf)] + rep
            break
    # Step 4 (within R2)
    r1, r2 = _regions(w)
    for suf in ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "al", "er",
                "ic", "ism", "ate", "iti", "ous", "ive", "ize"):
        if w.endswith(suf):
            if len(w) - len(suf) >= r2:
                w = w[: -len(suf)]
            break
    else:
        if w.endswith("ion") and len(w) - 3 >= r2 and w[-4:-3] in ("s", "t"):
            w = w[:-3]
    # Step 5
    r1, r2 = _regions(w)
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _short_syllable_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]
    return w.replace("Y", "y")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk). # spec: N-000170 N-000171
# ---------------------------------------------------------------------------

# Rule table in Paice/Husk notation: reversed suffix, optional "*" (applies only
# to an intact word), remove-count digit, optional append letters, and "." (stop)
# or ">" (continue). Reproduced from the published table; see NOTES.md.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.",
    "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.",
    "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "lu2.", "lai3y>", "lau3>", "la2>",
    "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>",
    "na2>", "nee0.", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>",
    "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>",
    "su*2.", "s*1>", "s0.", "tacilp4y.", "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.",
    "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1.",
    "u1.", "uqi3.", "ugo1.", "vis3j>", "vie2.", "vi1.", "ylb1>", "yli3y>", "ylp0.",
    "yl2>", "ygo1.", "yhp1.", "ymo1.", "ymp0.", "ypo1.", "yrtsi5.", "yr2>", "yrta2.",
    "yr2>", "y2s.", "yb1s.", "yb1>", "ydl1>", "yli2>", "ylpsi2.", "yt2>", "yrt1.",
]


def _parse_lancaster(rule):
    m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", rule)
    if not m:
        return None
    suffix = m.group(1)[::-1]
    return suffix, bool(m.group(2)), int(m.group(3)), m.group(4), m.group(5) == ">"


_LANCASTER = [r for r in (_parse_lancaster(x) for x in _LANCASTER_RULES) if r is not None]


class LancasterStemmer:
    """Paice/Husk Lancaster stemmer. # spec: N-000170 N-000171 N-000186"""

    def stem(self, word):
        w = word.lower()
        if not w.isalpha():
            return w
        intact = True
        while True:
            applied = None
            for suffix, needs_intact, remove, append, proceed in _LANCASTER:
                if not w.endswith(suffix):
                    continue
                if needs_intact and not intact:
                    continue
                remaining = len(w) - remove
                if remaining < 2:
                    continue
                applied = (suffix, remove, append, proceed)
                break
            if applied is None:
                return w
            suffix, remove, append, proceed = applied
            w = w[:-remove] + append if remove else w + append
            if proceed:
                intact = False
                continue
            return w


# ---------------------------------------------------------------------------
# Regular-expression stemmer. # spec: N-000178 N-000179 N-000180
# ---------------------------------------------------------------------------

class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        return self._regexp.sub("", word)


# ---------------------------------------------------------------------------
# Snowball. # spec: N-000172 N-000177 N-000181 N-000182 N-000183 N-000184
# ---------------------------------------------------------------------------

class SnowballStemmer:
    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in ("english", "porter"):
            raise NotImplementedError("Snowball algorithm for %r is not implemented" % (language,))
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            found = data.require("corpora/stopwords/%s" % language, "stopwords for %s" % language)
            with open(found, encoding="utf-8") as fh:
                self._stopwords = {line.strip() for line in fh if line.strip()}

    def stem(self, word, to_lowercase=True):
        w = word.lower()
        if self._stopwords is not None and w in self._stopwords:
            return w
        if self._language == "english":
            return _porter2(w)
        return _porter_core(w, extended=False)


class ARLSTem:
    """Arabic light stemmer. Stemming results are outside this specification; not implemented."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is outside the specification and is not implemented")


class ARLSTem2(ARLSTem):
    """Arabic light stemmer v2. Outside the specification; not implemented."""


# ---------------------------------------------------------------------------
# WordNet lemmatizer. # spec: N-000185 N-000186 N-000432
# ---------------------------------------------------------------------------

class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet resource (``corpora/wordnet``).

    Raises :class:`lingora.data.ResourceMissing` at construction when WordNet is not visible.
    """

    _RULES = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
              ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
              ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }

    def __init__(self):
        base = data.require("corpora/wordnet", "WordNet")
        self._index = {}
        self._exc = {}
        for pos, fname in (("n", "noun"), ("v", "verb"), ("a", "adj"), ("r", "adv")):
            idx = set()
            ipath = _first_existing(base, "index.%s" % fname)
            if ipath:
                with open(ipath, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        if line.startswith(" ") or not line.strip():
                            continue
                        idx.add(line.split(" ", 1)[0])
            self._index[pos] = idx
            epath = _first_existing(base, "%s.exc" % fname)
            exc = {}
            if epath:
                with open(epath, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        parts = line.split()
                        if len(parts) >= 2:
                            exc[parts[0]] = parts[1]
            self._exc[pos] = exc

    def lemmatize(self, word, pos="n"):
        if pos not in self._RULES:
            raise ValueError("unknown WordNet part of speech %r" % (pos,))
        w = word.lower()
        idx = self._index[pos]
        if w in self._exc[pos]:
            return self._exc[pos][w]
        if w in idx:
            return w
        for suffix, repl in self._RULES[pos]:
            if w.endswith(suffix):
                cand = w[: -len(suffix)] + repl
                if cand in idx:
                    return cand
        return w


def _first_existing(base, name):
    import os
    for cand in (os.path.join(base, name), os.path.join(base, "dict", name)):
        if os.path.isfile(cand):
            return cand
    return None
