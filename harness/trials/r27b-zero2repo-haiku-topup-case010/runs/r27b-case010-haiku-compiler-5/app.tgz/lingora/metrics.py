"""Evaluation metrics. Feature point FP-07. # spec: N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329 N-000330 N-000331 N-000332 N-000333 N-000334 N-000340 N-000341 N-000342 N-000343 N-000344 N-000345 N-000346 N-000347 N-000348 N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509 N-000510

Decisions (NOTES.md): accuracy on lists of different lengths raises; the
transposition edit is the unrestricted Damerau-Levenshtein distance.
"""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def accuracy(reference, test):
    """Fraction of positions with equal values. Lists of different lengths raise ValueError."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        return 0.0
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Edit distance: insertion and deletion cost 1; substitution costs ``substitution_cost``.

    With ``transpositions=True`` the unrestricted Damerau-Levenshtein distance
    (Lowrance and Wagner, 1975) is returned, where an adjacent transposition costs 1.
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = [j * 1 for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub)
        prev = cur
    return prev[len(s2)]


def _damerau(a, b, sub_cost):
    maxd = len(a) + len(b)
    da = {}
    # D is offset by one: D[i + 1][j + 1] corresponds to the classic d[i][j].
    D = [[maxd] * (len(b) + 2) for _ in range(len(a) + 2)]
    for i in range(len(a) + 1):
        D[i + 1][1] = i
    for j in range(len(b) + 1):
        D[1][j + 1] = j
    D[1][1] = 0
    for i in range(1, len(a) + 1):
        db = 0
        for j in range(1, len(b) + 1):
            k = da.get(b[j - 1], 0)
            l = db
            if a[i - 1] == b[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub_cost
            D[i + 1][j + 1] = min(
                D[i][j] + cost,
                D[i + 1][j] + 1,
                D[i][j + 1] + 1,
                D[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        da[a[i - 1]] = i
    return D[len(a) + 1][len(b) + 1]


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union|. Two empty sets have distance 0."""
    s1, s2 = set(label1), set(label2)
    union = s1 | s2
    if not union:
        return 0.0
    return len(s1 ^ s2) / len(union)


def _check_sets(reference, test):
    for arg in (reference, test):
        if not isinstance(arg, (set, frozenset)):
            raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    """|reference ∩ test| / |test|, or None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|, or None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either set is empty or they share no element."""
    _check_sets(reference, test)
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    return 1.0 / (alpha / p + (1 - alpha) / r)
