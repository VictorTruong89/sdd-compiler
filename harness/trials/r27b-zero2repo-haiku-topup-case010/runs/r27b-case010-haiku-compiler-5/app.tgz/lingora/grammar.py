"""Context-free grammars. Feature point FP-05. # spec: N-000461 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470 N-000471

Nonterminals are :class:`Nonterminal` objects whose ``str()`` is the name;
terminals are plain ``str`` values (quotes removed).
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    """A nonterminal symbol. ``str(nt)`` is its name. # spec: N-000466 N-000467 N-000468"""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name

    def __repr__(self):
        return "Nonterminal(%r)" % (self.name,)

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other.name == self.name

    def __hash__(self):
        return hash(("Nonterminal", self.name))


class Production:
    """One alternative ``lhs -> rhs``. # spec: N-000471"""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs) or "")


_SYMBOL_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|([A-Za-z_][\w\-]*))""")


def _parse_rhs(text, lineno):
    rhs_alts = []
    for alt in text.split("|"):
        symbols = []
        pos = 0
        alt_stripped = alt.strip()
        if not alt_stripped:
            rhs_alts.append([])
            continue
        while pos < len(alt):
            m = _SYMBOL_RE.match(alt, pos)
            if not m or m.end() == pos:
                if alt[pos:].strip() == "":
                    break
                raise ValueError("line %d: cannot read symbol in %r" % (lineno, alt.strip()))
            if m.group(1) is not None:
                symbols.append(m.group(1))
            elif m.group(2) is not None:
                symbols.append(m.group(2))
            else:
                symbols.append(("N", m.group(3)))
            pos = m.end()
        rhs_alts.append(symbols)
    return rhs_alts


class CFG:
    """A context-free grammar read from text. # spec: N-000461 N-000464 N-000465 N-000471 N-000475"""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring takes grammar text")
        productions = []
        start = None
        nonterminals = {}

        def nt(name):
            if name not in nonterminals:
                nonterminals[name] = Nonterminal(name)
            return nonterminals[name]

        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("line %d: expected 'LHS -> RHS'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_name = lhs_text.strip()
            if not re.fullmatch(r"[A-Za-z_][\w\-]*", lhs_name):
                raise ValueError("line %d: invalid left-hand side %r" % (lineno, lhs_name))
            lhs = nt(lhs_name)
            if start is None:
                start = lhs
            for alt in _parse_rhs(rhs_text, lineno):
                rhs = [nt(s[1]) if isinstance(s, tuple) else s for s in alt]
                productions.append(Production(lhs, rhs))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self):
        return list(self._productions)

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)

    def _terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}
