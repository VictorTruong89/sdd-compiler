"""Constituent trees. # spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488 N-000489 N-000490 N-000491"""


class Tree:
    """A node with a string label and an ordered list of children.

    A child is a leaf (a token string, or any non-tree item such as a
    ``(token, tag)`` pair) or another :class:`Tree`.
    """

    def __init__(self, label, children):
        if not isinstance(children, list):
            raise TypeError("Tree children must be a list, got %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    def label(self):
        return self._label

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    @classmethod
    def fromstring(cls, s):
        tokens = s.replace("(", " ( ").replace(")", " ) ").split()
        if not tokens:
            raise ValueError("empty bracketed tree text")
        pos = 0

        def read():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text at token %d" % pos)
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos]
            pos += 1
            children = []
            while pos < len(tokens) and tokens[pos] != ")":
                if tokens[pos] == "(":
                    children.append(read())
                else:
                    children.append(tokens[pos])
                    pos += 1
            if pos >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            pos += 1  # consume ')'
            return cls(label, children)

        tree = read()
        if pos != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree

    def pformat(self, indent=2):
        lines = []

        def emit(node, depth):
            pad = " " * (indent * depth)
            if isinstance(node, Tree):
                if all(not isinstance(c, Tree) for c in node._children):
                    body = " ".join(str(c) if not isinstance(c, tuple) else _fmt_pair(c)
                                    for c in node._children)
                    lines.append("%s(%s %s)" % (pad, node._label, body) if body else "%s(%s)" % (pad, node._label))
                else:
                    lines.append("%s(%s" % (pad, node._label))
                    for c in node._children:
                        emit(c, depth + 1)
                    lines.append("%s)" % pad)
            else:
                lines.append("%s%s" % (pad, _fmt_pair(node) if isinstance(node, tuple) else node))

        emit(self, 0)
        return "\n".join(lines)

    def __str__(self):
        return self.pformat()


def _fmt_pair(pair):
    return "/".join(str(x) for x in pair)
