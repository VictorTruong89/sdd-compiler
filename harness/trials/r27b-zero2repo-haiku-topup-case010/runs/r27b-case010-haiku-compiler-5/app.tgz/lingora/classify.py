"""Classifiers. Feature point FP-06. # spec: N-000292 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317 N-000318 N-000492 N-000493 N-000494 N-000495 N-000496 N-000497

Feature points: a featureset is a dict; labels are hashable.
"""

import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]


class ProbDist:
    """Probability distribution over labels. ``prob(label)`` is a float; ``samples()`` lists the labels. # spec: N-000496 N-000497"""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda k: self._probs[k])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    out = []
    for fs, label in labeled_featuresets:
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
        out.append((dict(fs), label))
    return out


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing. # spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000315 N-000316 N-000317"""

    def __init__(self, label_counts, feature_counts, value_sets, total):
        self._label_counts = label_counts
        self._feature_counts = feature_counts
        self._value_sets = value_sets
        self._total = total
        self._labels = list(label_counts.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        label_counts = Counter(label for _, label in data)
        feature_counts = defaultdict(Counter)  # (label) -> Counter of (name, value)
        value_sets = defaultdict(set)
        for fs, label in data:
            for name, value in fs.items():
                feature_counts[label][(name, value)] += 1
                value_sets[name].add(value)
        return cls(dict(label_counts), feature_counts, value_sets, len(data))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            n_label = self._label_counts[label]
            logp = math.log(n_label / self._total)
            for name, value in featureset.items():
                if name not in self._value_sets:
                    continue
                vocab = len(self._value_sets[name]) + 1
                count = self._feature_counts[label].get((name, value), 0)
                logp += math.log((count + 1) / (n_label + vocab))
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        top = max(scores.values())
        exps = {k: math.exp(v - top) for k, v in scores.items()}
        z = sum(exps.values())
        return ProbDist({k: v / z for k, v in exps.items()})

    def classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        return max(self._labels, key=lambda k: scores[k])


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(labels):
    n = len(labels)
    if n == 0:
        return 0.0
    counts = Counter(labels)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


class DecisionTreeClassifier:
    """Decision tree that splits on the feature whose values best separate the labels (information gain). # spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317"""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        features = sorted({name for fs, _ in data for name in fs}, key=str)
        return cls(cls._build(data, features))

    @classmethod
    def _build(cls, data, features):
        labels = [label for _, label in data]
        majority = Counter(labels).most_common(1)[0][0] if labels else None
        if len(set(labels)) <= 1 or not features:
            return _Leaf(majority)
        base = _entropy(labels)
        best = None
        best_gain = 0.0
        for name in features:
            groups = defaultdict(list)
            for fs, label in data:
                groups[fs.get(name)].append((fs, label))
            if len(groups) < 2:
                continue
            remainder = sum(len(g) / len(data) * _entropy([l for _, l in g]) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_gain = gain
                best = (name, groups)
        if best is None:
            return _Leaf(majority)
        name, groups = best
        children = {}
        rest = [f for f in features if f != name]
        for value, group in groups.items():
            children[value] = cls._build(group, rest)
        return _Node(name, children, majority)

    def classify(self, featureset):
        fs = dict(featureset)
        node = self._root
        while isinstance(node, _Node):
            value = fs.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


def accuracy(classifier, gold):
    """Fraction of ``gold`` (featureset, label) pairs the classifier labels correctly. # spec: N-000318"""
    gold = list(gold)
    if not gold:
        return 0.0
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
