import sys

from .cli import cli

if __name__ == "__main__":
    cli.main(sys.argv[1:])
