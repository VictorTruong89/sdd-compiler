"""BLEU. # spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342

The default weights are equal over unigrams to 4-grams (PRD FP-07); the PRD
takes precedence over the interface default (see NOTES.md).
"""

import math
from collections import Counter

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing=None):
    """Sentence BLEU of ``hypothesis`` (token list) against ``references`` (list of token lists).

    ``weights`` gives one weight per n-gram order from unigrams. Unsmoothed by
    default; ``smoothing`` is an optional callable taking the list of
    ``(clipped_matches, total)`` pairs and returning the list of precisions.
    """
    if not isinstance(references, list) or not all(isinstance(r, list) for r in references):
        raise TypeError("references must be a list of token lists")
    if not isinstance(hypothesis, list):
        raise TypeError("hypothesis must be a token list")
    if weights is None:
        weights = [0.25, 0.25, 0.25, 0.25]
    weights = list(weights)
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")
    c = len(hypothesis)
    if c == 0 or not references:
        return 0.0
    ref_lens = [len(r) for r in references]
    r = min(ref_lens, key=lambda rl: (abs(rl - c), rl))
    bp = 1.0 if c > r else math.exp(1 - r / c)

    pairs = []
    for n in range(1, len(weights) + 1):
        cand = _ngrams(hypothesis, n)
        total = sum(cand.values())
        clipped = 0
        for gram, count in cand.items():
            max_ref = max((_ngrams(ref, n).get(gram, 0) for ref in references), default=0)
            clipped += min(count, max_ref)
        pairs.append((clipped, total))
    if smoothing is not None:
        precisions = list(smoothing(pairs))
    else:
        precisions = [(m / t) if t else 0.0 for m, t in pairs]
    if any(p <= 0 for p, w in zip(precisions, weights) if w > 0):
        return 0.0
    log_sum = sum(w * math.log(p) for p, w in zip(precisions, weights))
    return bp * math.exp(log_sum)
