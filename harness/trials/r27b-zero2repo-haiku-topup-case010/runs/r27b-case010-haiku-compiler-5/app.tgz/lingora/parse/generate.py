"""Sentence generator. # spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480"""

from ..grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield up to ``n`` sentences (lists of terminal strings) derivable from ``start``.

    ``depth`` bounds the derivation depth (number of nested nonterminal expansions).
    A quoted empty terminal contributes ``''``; an empty production contributes nothing.
    """
    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(prod.lhs().name, []).append(prod)
    if start is None:
        start_name = grammar.start().name
    elif isinstance(start, Nonterminal):
        start_name = start.name
    else:
        start_name = str(start)

    def expand_seq(rhs, level):
        if not rhs:
            yield []
            return
        head, rest = rhs[0], rhs[1:]
        if isinstance(head, str):
            for tail in expand_seq(rest, level):
                yield [head] + tail
        else:
            for sub in expand(head.name, level):
                for tail in expand_seq(rest, level):
                    yield sub + tail

    def expand(name, level):
        if depth is not None and level >= depth:
            return
        for prod in by_lhs.get(name, []):
            yield from expand_seq(prod.rhs(), level + 1)

    count = 0
    for sentence in expand(start_name, 0):
        if n is not None and count >= n:
            return
        count += 1
        yield sentence
