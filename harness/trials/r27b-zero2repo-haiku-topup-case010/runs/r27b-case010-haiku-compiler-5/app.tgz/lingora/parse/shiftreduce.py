"""Shift-reduce parser (single pass, no backtracking). # spec: N-000272 N-000273 N-000274 N-000275 N-000292 N-000293 N-000294"""

from ..grammar import Nonterminal
from ..tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._terminals = grammar._terminals()

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("parse() takes a list of str tokens")
        tokens = list(tokens)
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("tokens must be str")
            if tok not in self._terminals:
                raise ValueError("token %r is produced by no production of the grammar" % (tok,))
        prods = [p for p in self._grammar.productions() if len(p.rhs()) > 0]
        stack = []
        pos = 0
        start = self._grammar.start().name
        while True:
            reduced = False
            for prod in prods:
                rhs = prod.rhs()
                n = len(rhs)
                if len(stack) < n:
                    continue
                if all(_matches(sym, item) for sym, item in zip(rhs, stack[len(stack) - n:])):
                    children = stack[len(stack) - n:]
                    del stack[len(stack) - n:]
                    stack.append(Tree(prod.lhs().name, list(children)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


def _matches(sym, item):
    if isinstance(sym, str):
        return isinstance(item, str) and item == sym
    return isinstance(item, Tree) and item.label() == sym.name
