"""Exhaustive chart parser. # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000292 N-000293 N-000294"""

from ..grammar import Nonterminal
from ..tree import Tree


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._by_lhs = {}
        for prod in grammar.productions():
            self._by_lhs.setdefault(prod.lhs().name, []).append(prod)
        self._terminals = grammar._terminals()

    def parse(self, tokens):
        """Return an iterator over every parse tree of ``tokens``.

        Raises ValueError when a token is produced by no production (this is
        detected by the call itself).
        """
        if isinstance(tokens, str):
            raise TypeError("parse() takes a list of str tokens")
        tokens = list(tokens)
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("tokens must be str")
            if tok not in self._terminals:
                raise ValueError("token %r is produced by no production of the grammar" % (tok,))
        trees = self._trees(self._grammar.start().name, 0, len(tokens), tokens, frozenset())[0]
        return iter(trees)

    def _trees(self, sym, i, j, tokens, path):
        """Return (trees, cut) for symbol ``sym`` spanning tokens[i:j].

        ``cut`` is True when a cycle guard truncated the result, in which case it is not memoised.
        """
        key = (sym, i, j)
        if key in path:
            return [], True
        path = path | {key}
        results = []
        cut = False
        for prod in self._by_lhs.get(sym, []):
            for children, c in self._match(prod.rhs(), i, j, tokens, path):
                cut = cut or c
                results.append(Tree(sym, children))
        return results, cut

    def _match(self, rhs, i, j, tokens, path):
        """Yield (children, cut) for sequences of rhs symbols covering tokens[i:j]."""
        if not rhs:
            if i == j:
                yield [], False
            return
        head, rest = rhs[0], rhs[1:]
        if isinstance(head, str):
            if head == "":
                yield from self._match(rest, i, j, tokens, path)
            elif i < j and tokens[i] == head:
                for children, c in self._match(rest, i + 1, j, tokens, path):
                    yield [head] + children, c
            return
        assert isinstance(head, Nonterminal)
        for k in range(i, j + 1):
            subtrees, cut = self._trees(head.name, i, k, tokens, path)
            if not subtrees:
                continue
            for st in subtrees:
                for children, c in self._match(rest, k, j, tokens, path):
                    yield [st] + children, (c or cut)
