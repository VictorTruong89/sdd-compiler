"""Part-of-speech taggers. Feature point FP-03.

# spec: N-000187 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000197 N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
"""

import json
import re
from collections import Counter, defaultdict

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


class _SequentialTagger:
    """Base: subclasses implement ``_tag_one_pass(tokens)`` returning a tag or None per token."""

    backoff = None

    def _primary(self, tokens):
        raise NotImplementedError

    def _tags(self, tokens):
        tags = list(self._primary(tokens))
        if self.backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                sub = self.backoff._tags([tokens[i] for i in missing])
                for i, t in zip(missing, sub):
                    tags[i] = t
        return tags

    def tag(self, tokens):
        """Return ``[(token, tag_or_None), ...]``, one pair per input token. # spec: N-000196 N-000197 N-000205 N-000206 N-000442 N-000444 N-000445"""
        if isinstance(tokens, str):
            raise TypeError("tag() takes a list of tokens, not a str")
        tokens = list(tokens)
        return list(zip(tokens, self._tags(tokens)))


class DefaultTagger(_SequentialTagger):
    """Assigns one tag to every token. # spec: N-000198"""

    def __init__(self, tag):
        self._tag = tag

    def _primary(self, tokens):
        return [self._tag for _ in tokens]


class UnigramTagger(_SequentialTagger):
    """Most frequent training tag per word. # spec: N-000199 N-000200 N-000201 N-000436 N-000437 N-000439"""

    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for word, tag in sentence:
                    counts[word][tag] += 1
            for word, c in counts.items():
                # Ties are broken by the tag string, so training is deterministic.
                best = max(c.items(), key=lambda kv: (kv[1], str(kv[0])))
                self._model[word] = best[0]

    def _primary(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; each matches a token from its first character. # spec: N-000202 N-000203 N-000204 N-000438 N-000439"""

    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = [(re.compile(pat), tag) for pat, tag in regexps]

    def _primary(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for rx, t in self._rules:
                if rx.match(tok):
                    tag = t
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------------------
# Averaged perceptron (recommended English and Russian taggers).
# # spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

_RUS_POS_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "NUM": "NUM", "SPRO": "PRON", "APRO": "DET", "ANUM": "ADJ",
    "INTJ": "X", "ADVPRO": "ADV",
}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = set(classes)

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = _features(i, word, context, prev, prev2)
                tag = self.predict(features)
            out.append(tag)
            prev2, prev = prev, tag
        return out


def _features(i, word, context, prev, prev2):
    i += len(_START)
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


_PERCEPTRON_CACHE = {}


def _load_perceptron(lang):
    key = (lang, tuple(data.path))
    if key in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[key]
    base = data.require(
        "taggers/averaged_perceptron_tagger_%s" % lang,
        "averaged perceptron tagger for %s" % lang,
    )
    stem = "averaged_perceptron_tagger_%s" % lang
    import os

    def _load(suffix):
        with open(os.path.join(base, "%s.%s.json" % (stem, suffix)), encoding="utf-8") as fh:
            return json.load(fh)

    model = _Perceptron(_load("weights"), _load("tagdict"), _load("classes"))
    _PERCEPTRON_CACHE.clear()
    _PERCEPTRON_CACHE[key] = model
    return model


def _load_universal_map():
    import os
    base = data.require("taggers/universal_tagset", "universal tagset tables")
    mapping = {}
    with open(os.path.join(base, "en-ptb.map"), encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Recommended tagger for English (``lang='eng'``) and Russian (``'rus'``). # spec: N-000207 N-000213 N-000215 N-000216 N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227

    ``tagset`` is ``None`` (native tags) or ``'universal'``.
    """
    if isinstance(tokens, str):
        raise TypeError("pos_tag() takes a list of tokens, not a str")
    if lang not in ("eng", "rus"):
        raise ValueError("pos_tag supports lang 'eng' or 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tokens = list(tokens)
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("pos_tag() takes a list of str tokens")
    model = _load_perceptron(lang)
    tags = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_universal_map()
            tags = [mapping.get(t, t) for t in tags]
        else:
            tags = [_RUS_POS_TO_UNIVERSAL.get(t.split("=")[0], "X") for t in tags]
    return list(zip(tokens, tags))
