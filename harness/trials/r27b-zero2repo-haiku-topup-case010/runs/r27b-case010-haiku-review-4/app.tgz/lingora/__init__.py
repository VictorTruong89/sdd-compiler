"""LINGORA: a Python natural-language processing library.

Importing this package downloads nothing and reads no packaged resources.
"""
from lingora import data

__version__ = "0.1.0"

__all__ = ["data", "__version__"]
