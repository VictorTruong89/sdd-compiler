"""BLEU score over token lists."""
import math
from collections import Counter

DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU (Papineni et al., 2002).

    ``smoothing_function``, if given, is called as
    ``f(numerators, denominators)`` with one (matches, total) count per order and
    returns the list of precisions to use.
    """
    if weights is None:
        weights = DEFAULT_WEIGHTS
    weights = [float(w) for w in weights]
    if not weights:
        raise ValueError("bleu needs at least one weight")
    hyp = list(hypothesis)
    refs = [list(r) for r in references]
    if not refs:
        raise ValueError("bleu needs at least one reference")
    if not hyp:
        return 0.0
    max_n = len(weights)
    numerators, denominators = [], []
    for n in range(1, max_n + 1):
        hyp_counts = _ngrams(hyp, n)
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        total = max(len(hyp) - n + 1, 0)
        numerators.append(clipped)
        denominators.append(total)
    if smoothing_function is not None:
        precisions = list(smoothing_function(numerators, denominators))
    else:
        precisions = []
        for num, den in zip(numerators, denominators):
            precisions.append(num / den if den else 0.0)
    if any(w > 0 and p <= 0 for w, p in zip(weights, precisions)):
        return 0.0
    log_avg = sum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0)
    score = math.exp(log_avg)
    c = len(hyp)
    ref_lengths = [len(r) for r in refs]
    # Reference length closest to the candidate; the shorter one on a tie.
    r = min(ref_lengths, key=lambda rl: (abs(rl - c), rl))
    bp = 1.0 if c > r else math.exp(1 - r / c)
    return score * bp
