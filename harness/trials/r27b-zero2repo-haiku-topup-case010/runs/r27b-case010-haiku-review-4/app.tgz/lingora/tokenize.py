"""Tokenizers: word/punctuation, Penn Treebank, recommended word, sentence, whitespace,
blank-line, regular-expression, and tweet tokenizers."""
import re

from lingora import _punkt

_UNICODE_WS = r"\s"


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("expected str, got %s" % type(text).__name__)


class WordPunctTokenizer:
    _pattern = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        _check_text(text)
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in self._pattern.finditer(text):
            yield (m.start(), m.end())


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# Penn Treebank conventions (FP-01).
_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)\b"),
]
_CONTRACTIONS3 = [
    re.compile(r"(?i)\b('t)(is)\b"),
    re.compile(r"(?i)\b('t)(was)\b"),
]
_CLITIC_RE = re.compile(r"(?i)([^\s'])('s|'m|'d|'ll|'re|'ve|n't)(?=\s|$)")
_BARE_APOS_RE = re.compile(r"([^\s'])(')(?=\s|$)")
_PUNCT_RE = re.compile(r"([;@#$%&?!])")
_BRACKET_RE = re.compile(r"([\[\](){}<>])")
_COMMA_COLON_RE = re.compile(r"([,:])(?!\d)")
_END_PERIOD_RE = re.compile(r"([^.\s])\.(['\")\]}>]*)\s*$")
_OPEN_QUOTE_RE = re.compile(r"(?<=[\s(\[{<])\"")
_TYPOGRAPHIC_QUOTE_RE = re.compile("[\u201c\u201d\u201e\u201f\u00ab\u00bb\u2018\u2019\u201a\u201b]")
_DASH_STAR_RE = re.compile("[\u2012-\u2015*]")


def _penn_preprocess(text, recommended):
    """Apply the Penn Treebank conventions; returns a space-separated string."""
    text = " " + text + " "
    if recommended:
        # A straight double quote at the very start of the text is a closing quote.
        text = re.sub(r"^ \"", " '' ", text)
    # Opening quotes are classified on the original context (start, space or opening bracket).
    text = _OPEN_QUOTE_RE.sub(" `` ", text)
    if recommended:
        text = _TYPOGRAPHIC_QUOTE_RE.sub(lambda m: " %s " % m.group(0), text)
        text = _DASH_STAR_RE.sub(lambda m: " %s " % m.group(0), text)
        text = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), text)
        text = text.replace("--", " -- ")
    else:
        text = re.sub(r"\.\.\.", " ... ", text)
    text = _PUNCT_RE.sub(r" \1 ", text)
    text = _BRACKET_RE.sub(r" \1 ", text)
    text = _COMMA_COLON_RE.sub(r" \1 ", text)
    text = _END_PERIOD_RE.sub(lambda m: "%s ." % m.group(1) + m.group(2) + " ", text)
    # Remaining double quotes are closing quotes.
    text = text.replace('"', " '' ")
    contractions2 = _CONTRACTIONS2[1:] if recommended else _CONTRACTIONS2
    for rx in contractions2:
        text = rx.sub(lambda m: " %s %s " % (m.group(1), m.group(2)), text)
    for rx in _CONTRACTIONS3:
        text = rx.sub(lambda m: " %s %s " % (m.group(1), m.group(2)), text)
    text = _CLITIC_RE.sub(lambda m: "%s %s" % (m.group(1), m.group(2)), text)
    text = _BARE_APOS_RE.sub(lambda m: "%s '" % m.group(1), text)
    return text


class TreebankWordTokenizer:
    def tokenize(self, text):
        _check_text(text)
        return _penn_preprocess(text, recommended=False).split()


def _word_tokenize_line(line):
    """Recommended word tokenizer on one already-delimited line (no sentence split)."""
    _check_text(line)
    return _penn_preprocess(line, recommended=True).split()


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    _check_text(text)
    if preserve_line:
        return _word_tokenize_line(text)
    out = []
    for sent in sent_tokenize(text, language=language):
        out.extend(_word_tokenize_line(sent))
    return out


def sent_tokenize(text, language="english"):
    """Punkt sentence tokenizer. Raises LookupError when the Punkt model is not visible."""
    _check_text(text)
    return _punkt.sentences(text, language=language)


class WhitespaceTokenizer:
    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        for m in re.finditer(r"\S+", text):
            yield (m.start(), m.end())


def blankline_tokenize(text):
    _check_text(text)
    pieces = re.split(r"\s*\n\s*\n\s*", text)
    return [p for p in pieces if p]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True):
        self._regexp = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        if not self._gaps:
            return [(m.start(), m.end()) for m in self._regexp.finditer(text)]
        spans = []
        prev = 0
        for m in self._regexp.finditer(text):
            spans.append((prev, m.start()))
            prev = m.end()
        spans.append((prev, len(text)))
        return spans

    def tokenize(self, text):
        _check_text(text)
        out = []
        for s, e in self._spans(text):
            piece = text[s:e]
            if self._discard_empty and not piece:
                continue
            out.append(piece)
        return out

    def span_tokenize(self, text):
        _check_text(text)
        for s, e in self._spans(text):
            if self._discard_empty and s == e:
                continue
            yield (s, e)


# Tweet tokenizer.
_EMOTICON = (r"(?:[<>]?[:;=8][\-o\*']?[\)\]\(\[dDpP/:\}\{@\|\\]"
             r"|[\)\]\(\[dDpP/:\}\{@\|\\][\-o\*']?[:;=8][<>]?|<3|\^_\^)")
_URL = r"(?:https?://|www\.)\S+"
_HASH_HANDLE = r"[#@]\w+"
_WORD = r"\w+(?:['’]\w+)*"
_TWEET_RE = re.compile("|".join([_EMOTICON, _URL, _HASH_HANDLE, _WORD, r"[^\w\s]"]), re.UNICODE)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_EMOTICON_RE = re.compile(_EMOTICON)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE_RE.sub(lambda m: m.group(1) * 3, text)
        out = []
        for tok in _TWEET_RE.findall(text):
            if not self._preserve_case and not _EMOTICON_RE.fullmatch(tok):
                tok = tok.lower()
            out.append(tok)
        return out
