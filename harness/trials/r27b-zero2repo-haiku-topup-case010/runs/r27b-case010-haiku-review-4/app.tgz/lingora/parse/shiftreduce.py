"""Single-pass shift-reduce parser without backtracking."""
from lingora.grammar import Nonterminal
from lingora.parse.chart import _check_tokens
from lingora.tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._run(tokens))

    def _run(self, tokens):
        grammar = self._grammar
        productions = grammar.productions()
        start = str(grammar.start())
        stack = []      # items: str leaves or Tree nodes
        pos = 0
        seen = set()    # (stack signature, pos) states already visited
        while True:
            reduced = False
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if k > len(stack):
                    continue
                if not _matches(stack[len(stack) - k:], rhs):
                    continue
                new_stack = stack[:len(stack) - k] + [Tree(str(prod.lhs()), stack[len(stack) - k:])]
                state = (_signature(new_stack), pos)
                if state in seen:
                    continue
                seen.add(state)
                stack = new_stack
                reduced = True
                break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return [stack[0]]
        return []


def _matches(items, rhs):
    for item, sym in zip(items, rhs):
        if isinstance(sym, str):
            if not (isinstance(item, str) and item == sym):
                return False
        else:
            if not (isinstance(item, Tree) and item.label() == str(sym)):
                return False
    return True


def _signature(stack):
    return tuple(("leaf", s) if isinstance(s, str) else ("tree", s.label()) for s in stack)
