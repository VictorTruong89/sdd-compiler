"""Enumerate sentences derived from a grammar."""
from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield lists of terminal strings, leftmost derivations in production order.

    ``depth`` bounds the derivation depth (the start symbol is at depth 1; a
    nonterminal at depth d may be expanded only when d <= depth). ``n`` limits
    the number of sentences. A quoted empty terminal contributes an empty-string
    token; an empty production contributes nothing.
    """
    if start is None:
        start_name = str(grammar.start())
    else:
        start_name = str(start)
    if n is not None and n <= 0:
        return
    emitted = 0
    # Each work item: (prefix tokens, pending [(symbol, depth)]).
    stack = [([], [(Nonterminal(start_name), 1)])]
    while stack:
        prefix, pending = stack.pop()
        if not pending:
            yield list(prefix)
            emitted += 1
            if n is not None and emitted >= n:
                return
            continue
        sym, d = pending[0]
        rest = pending[1:]
        if isinstance(sym, str):
            stack.append((prefix + [sym], rest))
            continue
        name = str(sym)
        if depth is not None and d > depth:
            continue
        # Push alternatives in reverse so they are popped in written order.
        options = []
        for prod in grammar.productions():
            if str(prod.lhs()) != name:
                continue
            new_pending = [(s, d + 1) for s in prod.rhs()] + rest
            options.append((prefix, new_pending))
        for item in reversed(options):
            stack.append(item)
