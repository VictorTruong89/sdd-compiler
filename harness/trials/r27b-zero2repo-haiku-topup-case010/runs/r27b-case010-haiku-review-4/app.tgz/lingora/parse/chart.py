"""Exhaustive chart parser.

Builds, for every span of the input, the set of trees each nonterminal derives
over that span. A tree may not repeat the same (symbol, span) on one path from
root to leaf, so cyclic grammars (unit cycles, epsilon loops) give a finite set
of parse trees.
"""
from lingora.grammar import Nonterminal
from lingora.tree import Tree


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        grammar = self._grammar
        n = len(tokens)
        # chart[(i, j)][symbol_name] -> dict canonical -> (tree, keys)
        chart = {}

        def entries(name, i, j):
            return chart.get((i, j), {}).get(name, {})

        def add(name, i, j, tree, keys):
            cell = chart.setdefault((i, j), {}).setdefault(name, {})
            canon = _canon(tree)
            if canon in cell:
                return False
            cell[canon] = (tree, keys)
            return True

        def match_rhs(rhs, idx, pos, end, span_i, span_j):
            """Yield (children, keys) for ways rhs[idx:] derives tokens[pos:end]."""
            if idx == len(rhs):
                if pos == end:
                    yield [], frozenset()
                return
            sym = rhs[idx]
            if isinstance(sym, str):
                if pos < end and tokens[pos] == sym:
                    for rest, keys in match_rhs(rhs, idx + 1, pos + 1, end, span_i, span_j):
                        yield [tokens[pos]] + rest, keys
                return
            name = str(sym)
            for k in range(pos, end + 1):
                cands = entries(name, pos, k)
                if not cands:
                    continue
                for tree, tkeys in list(cands.values()):
                    for rest, keys in match_rhs(rhs, idx + 1, k, end, span_i, span_j):
                        yield [tree] + rest, tkeys | keys

        # Process spans by increasing length; within a span iterate to a fixpoint
        # so that epsilon and unit productions are handled.
        for length in range(0, n + 1):
            for i in range(0, n - length + 1):
                j = i + length
                changed = True
                while changed:
                    changed = False
                    for prod in grammar.productions():
                        name = str(prod.lhs())
                        for children, keys in list(match_rhs(prod.rhs(), 0, i, j, i, j)):
                            node_keys = keys | {(name, i, j)}
                            if (name, i, j) in keys:
                                continue  # would repeat a symbol over the same span
                            tree = Tree(name, children)
                            if add(name, i, j, tree, node_keys):
                                changed = True
        start = str(grammar.start())
        return [tree for tree, _ in entries(start, 0, n).values()]


def _canon(tree):
    if isinstance(tree, Tree):
        return (tree.label(), tuple(_canon(c) for c in tree))
    return ("leaf", tree)


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("parser expects a list of tokens")
    tokens = list(tokens)
    known = grammar.terminals()
    for tok in tokens:
        if tok not in known:
            raise ValueError("token %r is produced by no production of the grammar" % (tok,))
    return tokens
