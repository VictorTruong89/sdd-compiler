"""Chunk parser: a chunk grammar applied to a list of (token, tag) pairs.

Internal representation while a grammar runs. Root-level nodes are:
  ("tok", (token, tag))          a tagged token not yet in any chunk
  ("unit", Tree)                 a chunk built by an earlier clause; it matches
                                 by its label, and this clause cannot chink it
  ("chunk", label, [children])   a chunk built by the current clause
"""
import os
import re

from lingora import data
from lingora.tree import Tree

SENTENCE_LABEL = "S"
_SEP = "\x00"   # stands for a chunk of this clause: no tag pattern can match it
_QUANT_RE = re.compile(r"\{\d*(?:,\d*)?\}|[?*+]")


class ChunkRule:
    """A chunk stage: ``{pattern}`` under clause ``label``. Pass a list of these to RegexpParser."""

    kind = "chunk"

    def __init__(self, label, pattern):
        self.label = label
        self.pattern = pattern


class ChinkRule(ChunkRule):
    """A chink stage: ``}pattern{`` under clause ``label``."""

    kind = "chink"


def _dot_to_class(content):
    out = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^<>\x00]" if c == "." else c)
        i += 1
    return "".join(out)


def _compile_tag_pattern(pattern):
    """Translate a tag pattern into a regex over the string '<tag><tag>...'."""
    pattern = re.sub(r"\s+", "", pattern)
    parts = []
    pos = 0
    while pos < len(pattern):
        if pattern[pos] != "<":
            raise ValueError("tag pattern expects '<' at %r" % pattern[pos:])
        end = pattern.find(">", pos)
        if end < 0:
            raise ValueError("unterminated tag element in %r" % pattern)
        content = _dot_to_class(pattern[pos + 1:end])
        pos = end + 1
        quant = ""
        m = _QUANT_RE.match(pattern, pos)
        if m:
            quant = m.group(0)
            pos = m.end()
        try:
            re.compile(content)
        except re.error as exc:
            raise ValueError("bad tag regex %r: %s" % (content, exc)) from exc
        parts.append("(?:<(?:%s)>)%s" % (content, quant))
    if not parts:
        raise ValueError("empty tag pattern")
    return re.compile("".join(parts))


def _scan_pattern(body):
    """Split a clause pattern into ChunkRule/ChinkRule stages, skipping quantifier braces."""
    stages = []
    i = 0
    while i < len(body):
        c = body[i]
        if c.isspace():
            i += 1
            continue
        if c == "{":
            close, cls, want = "}", ChunkRule, "}"
        elif c == "}":
            close, cls, want = "{", ChinkRule, "{"
        else:
            raise ValueError("unrecognised text in chunk grammar: %r" % body[i:])
        j = i + 1
        while True:
            if j >= len(body):
                raise ValueError("unterminated chunk or chink pattern: %r" % body)
            qm = _QUANT_RE.match(body, j) if body[j] == "{" else None
            if qm:
                j = qm.end()
                continue
            if body[j] == close:
                break
            j += 1
        stages.append((cls, body[i + 1:j]))
        i = j + 1
    return stages


def _parse_grammar(text):
    """Return the list of stage objects described by grammar text."""
    stages = []
    label = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[:1].isspace():
            if label is None:
                raise ValueError("pattern line before any clause label: %r" % raw)
            body = raw.strip()
        else:
            if ":" not in raw:
                raise ValueError("clause line needs 'LABEL: pattern': %r" % raw)
            label, body = raw.split(":", 1)
            label = label.strip()
            body = body.strip()
            if not label:
                raise ValueError("empty clause label: %r" % raw)
        for cls, pattern in _scan_pattern(body):
            stages.append(cls(label, pattern))
    return stages


class RegexpParser:
    def __init__(self, grammar):
        if isinstance(grammar, str):
            stages = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, ChunkRule) for s in grammar):
            stages = list(grammar)
        else:
            raise TypeError("grammar must be text or a list of chunk-parser stages")
        self._stages = [(s.kind, s.label, _compile_tag_pattern(s.pattern)) for s in stages]

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("parse expects a list of (token, tag) pairs")
        nodes = [("tok", tuple(pair)) for pair in tagged]
        # Consecutive stages with the same label form one clause.
        clauses = []
        for kind, label, rx in self._stages:
            if clauses and clauses[-1][0] == label:
                clauses[-1][1].append((kind, rx))
            else:
                clauses.append((label, [(kind, rx)]))
        for label, rules in clauses:
            nodes = _apply_clause(label, rules, nodes)
        return Tree(SENTENCE_LABEL, [_to_child(n) for n in nodes])


def _to_tree(node):
    """Convert a clause-local chunk node to a Tree (recursively)."""
    return Tree(node[1], [_to_child(c) for c in node[2]])


def _to_child(node):
    if node[0] == "tok":
        return node[1]
    if node[0] == "unit":
        return node[1]
    return _to_tree(node)


def _tag_of(node):
    if node[0] == "tok":
        return node[1][1]
    return node[1].label()   # unit


def _apply_clause(label, rules, nodes):
    # Chunks from earlier clauses become opaque units for this clause.
    nodes = [("unit", _to_tree(n)) if n[0] == "chunk" else n for n in nodes]
    for kind, rx in rules:
        nodes = _chunk(label, rx, nodes) if kind == "chunk" else _chink(rx, nodes)
    return nodes


def _layout(items):
    """Build the match string: one '<tag>' per matchable item, _SEP for each non-matchable.

    Returns (text, start_index, end_index) where start_index maps a character
    offset to the item index it begins and end_index maps an end offset to the
    exclusive item index it closes.
    """
    pieces = [_SEP if item is None else "<%s>" % item for item in items]
    start_index, end_index = {}, {}
    pos = 0
    for i, piece in enumerate(pieces):
        start_index[pos] = i
        pos += len(piece)
        end_index[pos] = i + 1
    return "".join(pieces), start_index, end_index


def _spans_of(rx, text, start_index, end_index):
    for m in rx.finditer(text):
        if m.end() <= m.start():
            continue
        if m.start() in start_index and m.end() in end_index:
            yield start_index[m.start()], end_index[m.end()]


def _chunk(label, rx, nodes):
    items = [None if n[0] == "chunk" else _tag_of(n) for n in nodes]
    text, start_index, end_index = _layout(items)
    member = [False] * len(nodes)
    for a, b in _spans_of(rx, text, start_index, end_index):
        for k in range(a, b):
            member[k] = True
    out = []
    k = 0
    while k < len(nodes):
        if not member[k]:
            out.append(nodes[k])
            k += 1
            continue
        kids = []
        while k < len(nodes) and member[k]:
            kids.append(nodes[k])
            k += 1
        out.append(("chunk", label, kids))
    return _join_touching(out)


def _join_touching(nodes):
    """Chunks of one clause with no token between them are joined into one chunk."""
    out = []
    for node in nodes:
        if node[0] == "chunk" and out and out[-1][0] == "chunk" and out[-1][1] == node[1]:
            out[-1] = ("chunk", node[1], out[-1][2] + node[2])
        else:
            out.append(node)
    return out


def _chink(rx, nodes):
    out = []
    for node in nodes:
        if node[0] != "chunk":
            out.append(node)
            continue
        label, children = node[1], node[2]
        items = [child[1][1] if child[0] == "tok" else None for child in children]
        text, start_index, end_index = _layout(items)
        removed = [False] * len(children)
        for a, b in _spans_of(rx, text, start_index, end_index):
            for k in range(a, b):
                if children[k][0] == "tok":
                    removed[k] = True
        if not any(removed):
            out.append(node)
            continue
        run = []
        for child, gone in zip(children, removed):
            if gone:
                if run:
                    out.append(("chunk", label, run))
                    run = []
                out.append(child)
            else:
                run.append(child)
        if run:
            out.append(("chunk", label, run))
    return out


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Raises when its model or the English wordlist is not visible."""
    data.find(os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"))
    data.find(os.path.join("corpora", "words"))
    raise NotImplementedError(
        "the named-entity model is visible, but its published layout is not supported by this build")
