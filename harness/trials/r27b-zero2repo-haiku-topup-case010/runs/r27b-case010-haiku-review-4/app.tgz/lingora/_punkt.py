"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), reading packaged parameters.

The packaged model for a language lives in ``tokenizers/punkt_tab/<language>/``
and holds abbrev_types.txt, sent_starters.txt, collocations.tab and
ortho_context.tab (see the Interface Contract, "Packaged resources").
"""
import os
import re

from lingora import data

NUMBER_TYPE = "##number##"
_UPPER_START = 2
_UPPER_INSIDE = 4
_LOWER_START = 16
_LOWER_INSIDE = 32

_WORD_RE = re.compile(r"\S+")
_NUMBER_RE = re.compile(r"^[+-]?[\d.,:/%-]*\d[\d.,:/%-]*$")


class PunktParameters:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


_cache = {}


def _read_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


def load_parameters(language):
    """Return the PunktParameters for ``language``; raise LookupError if no model is visible."""
    rel = os.path.join("tokenizers", "punkt_tab", language)
    model_dir = data.find(rel)
    if not os.path.isdir(model_dir):
        raise data.ResourceNotFound("Punkt model for %r is not a directory: %s" % (language, model_dir))
    if model_dir in _cache:
        return _cache[model_dir]
    abbrev = {l.strip().lower() for l in _read_lines(os.path.join(model_dir, "abbrev_types.txt")) if l.strip()}
    starters = {l.strip().lower() for l in _read_lines(os.path.join(model_dir, "sent_starters.txt")) if l.strip()}
    colloc = set()
    for line in _read_lines(os.path.join(model_dir, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines(os.path.join(model_dir, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, starters, colloc, ortho)
    _cache[model_dir] = params
    return params


def _is_number(word):
    return bool(_NUMBER_RE.match(word))


def _split_trailing(word):
    """Split a word into (core, trailing closing punctuation) for period detection."""
    m = re.match(r"^(.*?)([\"')\]}>]*)$", word)
    return m.group(1), m.group(2)


def sentences(text, language="english"):
    """Split ``text`` into sentences; each is the original text of that sentence."""
    params = load_parameters(language)
    words = [(m.start(), m.end(), m.group(0)) for m in _WORD_RE.finditer(text)]
    if not words:
        return []
    n = len(words)

    def wtype(core):
        if _is_number(core):
            return NUMBER_TYPE
        return core.lower()

    # Describe each word: (core, has_final_period, type_for_abbrev_test)
    info = []
    for _, _, w in words:
        core, closers = _split_trailing(w)
        if core.endswith(".") and len(core) > 1:
            base = core[:-1]
            info.append({"ends": True, "base": base, "type": wtype(base), "closers": closers})
        else:
            info.append({"ends": False, "base": core, "type": wtype(core), "closers": closers,
                         "core": core})
            if core[-1:] in ("?", "!"):
                info[-1]["hard"] = True

    def ortho_flags(tok):
        return params.ortho_context.get(tok, 0)

    boundaries = []   # index of word that ends a sentence
    for i in range(n):
        inf = info[i]
        if i == n - 1:
            boundaries.append(i)
            continue
        if inf.get("hard"):
            boundaries.append(i)
            continue
        if not inf["ends"]:
            continue
        nxt = info[i + 1]
        nxt_word = words[i + 1][2]
        if (inf["type"], nxt["type"]) in params.collocations:
            continue
        starts_upper = nxt_word[:1].isupper()
        starts_lower = nxt_word[:1].islower()
        if inf["type"] in params.abbrev_types:
            # Abbreviation: a break only before a capitalised sentence starter.
            if starts_upper and (nxt["type"] in params.sent_starters
                                 or ortho_flags(nxt["type"]) & _UPPER_START):
                boundaries.append(i)
            continue
        # Ordinary period: a break unless the next word continues in lower case.
        if starts_lower:
            continue
        boundaries.append(i)

    result = []
    start_word = 0
    for b in boundaries:
        if b < start_word:
            continue
        begin = words[start_word][0]
        end = words[b][1]
        result.append(text[begin:end])
        start_word = b + 1
    if start_word < n:
        result.append(text[words[start_word][0]:words[n - 1][1]])
    return result
