"""Packaged-resource finder.

``path`` is a mutable list of directories searched for packaged resources.
Its initial contents come from the ``LINGORA_DATA`` environment variable
(``os.pathsep``-separated); otherwise it is empty, so no packaged resource is
visible until the caller adds directories.
"""
import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


class ResourceNotFound(LookupError):
    """A packaged resource needed by a call is not visible on ``path``."""


def find(relative):
    """Return the absolute path of the first visible match for ``relative``.

    Raises ``ResourceNotFound`` when no directory in ``path`` holds it.
    """
    for base in list(path):
        candidate = os.path.join(base, relative)
        if os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r not found in data.path %r" % (relative, list(path))
    )


def exists(relative):
    try:
        find(relative)
    except ResourceNotFound:
        return False
    return True
