"""Stemmers: Porter (default LINGORA mode), Lancaster, Snowball, regular-expression."""
import re

from lingora import data

_VOWELS = "aeiou"


# ----------------------------------------------------------------- Porter

_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "news": "news", "innings": "inning", "inning": "inning", "outings": "outing",
    "outing": "outing", "cannings": "canning", "canning": "canning",
    "howe": "howe", "proceed": "proceed", "exceed": "exceed", "succeed": "succeed",
}

ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
LINGORA_EXTENSIONS = "LINGORA_EXTENSIONS"


class PorterStemmer:
    """Porter's algorithm. The default mode is LINGORA's extensions."""

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, LINGORA_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._ext = mode == LINGORA_EXTENSIONS

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        if to_lowercase:
            word = word.lower()
        if self._ext and word in _IRREGULAR:
            return _IRREGULAR[word]
        if len(word) <= 2:
            return word
        if self._ext:
            return _porter_lingora(word)
        return _porter_original(word)


def _is_cons(word, i):
    c = word[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    m = 0
    prev_vowel = False
    for i in range(len(stem)):
        cons = _is_cons(stem, i)
        if prev_vowel and cons:
            m += 1
        prev_vowel = not cons
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(stem):
    return len(stem) >= 2 and stem[-1] == stem[-2] and _is_cons(stem, len(stem) - 1)


def _cvc(stem, ext):
    """*o: stem ends consonant-vowel-consonant and the last is not w, x or y.

    With LINGORA extensions a two-letter stem of vowel + consonant also qualifies.
    """
    n = len(stem)
    if n == 2 and ext:
        return (not _is_cons(stem, 0)) and _is_cons(stem, 1) and stem[1] not in "wxy"
    if n < 3:
        return False
    return (_is_cons(stem, n - 3) and not _is_cons(stem, n - 2)
            and _is_cons(stem, n - 1) and stem[-1] not in "wxy")


def _step1a(word):
    if word.endswith("sses"):
        return word[:-2]
    if word.endswith("ies"):
        return word[:-2]
    if word.endswith("ss"):
        return word
    if word.endswith("s"):
        return word[:-1]
    return word


def _step1b_rest(word, ext):
    """Step 1b after the ied check; returns the new word."""
    if word.endswith("eed"):
        stem = word[:-3]
        return stem + "ee" if _measure(stem) > 0 else word
    flag = False
    for suffix in ("ed", "ing"):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _has_vowel(stem):
                word = stem
                flag = True
            break
    if not flag:
        return word
    if word.endswith(("at", "bl", "iz")):
        return word + "e"
    if _double_cons(word) and word[-1] not in "lsz":
        return word[:-1]
    if _measure(word) == 1 and _cvc(word, ext):
        return word + "e"
    return word


def _step1c(word, ext):
    if not word.endswith("y"):
        return word
    stem = word[:-1]
    if ext:
        if len(stem) >= 2 and _is_cons(stem, len(stem) - 1):
            return stem + "i"
        return word
    if _has_vowel(stem):
        return stem + "i"
    return word


_STEP2 = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_EXT = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"), ("logi", "log"),
]


def _step2(word, ext):
    if ext and word.endswith("alli") and _measure(word[:-4]) > 0:
        return _step2(word[:-4] + "al", ext)
    table = _STEP2_EXT if ext else _STEP2
    for suffix, repl in table:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if suffix == "logi":
                # -ogi -> -og when the part before -ogi has positive measure
                if _measure(word[:-3]) > 0:
                    return word[:-1]
                return word
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
          ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
          "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize"]


def _step3(word):
    for suffix, repl in _STEP3:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if _measure(stem) > 0:
                return stem + repl
            return word
    return word


def _step4(word):
    for suffix in _STEP4:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if suffix == "ion":
                if _measure(stem) > 1 and stem[-1:] in ("s", "t"):
                    return stem
                return word
            if _measure(stem) > 1:
                return stem
            return word
    return word


def _step5(word, ext):
    if word.endswith("e"):
        stem = word[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _cvc(stem, ext)):
            word = stem
    if word.endswith("ll") and _measure(word) > 1:
        word = word[:-1]
    return word


def _porter_common(word, ext):
    if ext and word.endswith("ies") and len(word) == 4:
        word = word[:-1]   # LINGORA Step 1a: four-letter -ies -> -ie
    else:
        word = _step1a(word)
    if ext and word.endswith("ied"):
        # 4-letter -ied -> -ie, otherwise -ied -> -i; the rest of step 1b is skipped.
        word = word[:-1] if len(word) == 4 else word[:-2]
    else:
        word = _step1b_rest(word, ext)
    word = _step1c(word, ext)
    word = _step2(word, ext)
    word = _step3(word)
    word = _step4(word)
    word = _step5(word, ext)
    return word


def _porter_lingora(word):
    return _porter_common(word, True)


def _porter_original(word):
    return _porter_common(word, False)


# -------------------------------------------------------------- Lancaster

_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.",
    "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.",
    "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3y.",
    "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3y.", "lo2l>", "lu2.", "lai3>", "lau3>",
    "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>",
    "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "pihs2>", "pp1.", "re2>", "rae0.", "ra2.",
    "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.", "si2>", "ss0.", "suo3]",
    "su*2.", "s*1>", "s0.", "tacilp4y.", "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.",
    "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1.",
    "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>", "ylp0.", "yl2>",
    "ygo1.", "yhp1.", "ymo1.", "ypo2.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>",
    "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)
_RULE_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>.\]])$")


def _parse_lancaster_rules():
    table = {}
    for text in _LANCASTER_RULES:
        m = _RULE_RE.match(text)
        if not m:
            raise ValueError("bad Lancaster rule %r" % text)
        reversed_ending, star, remove, append, cont = m.groups()
        # Paice writes each ending reversed (e.g. "gni" is the suffix "ing").
        ending = reversed_ending[::-1]
        table.setdefault(ending[-1], []).append(
            (ending, star == "*", int(remove), append, cont == ">"))
    return table


_LANCASTER = None


class LancasterStemmer:
    """Paice/Husk stemmer with its published rule table."""

    def __init__(self):
        global _LANCASTER
        if _LANCASTER is None:
            _LANCASTER = _parse_lancaster_rules()
        self._rules = _LANCASTER

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        word = word.lower()
        intact = True
        while True:
            applied = False
            for ending, needs_intact, remove, append, cont in self._rules.get(word[-1:], []):
                if not word.endswith(ending):
                    continue
                if needs_intact and not intact:
                    continue
                stem = word[: len(word) - remove] if remove else word
                if not _lancaster_acceptable(stem):
                    continue
                word = stem + append
                intact = False
                applied = True
                if not cont:
                    return word
                break
            if not applied:
                return word


def _lancaster_acceptable(stem):
    if not stem:
        return False
    if stem[0] in _VOWELS:
        return len(stem) >= 2
    return len(stem) >= 3 and any(c in "aeiouy" for c in stem)


# ------------------------------------------------------------- Regexp

class RegexpStemmer:
    """Removes every match of the caller's pattern; nothing else changes."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a pattern string")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        return self._regexp.sub("", word)


# ------------------------------------------------------------ Snowball

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)


class SnowballStemmer:
    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "the Snowball algorithm for %r is not implemented in this build" % (language,))
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            path = data.find("corpora/stopwords/%s" % language)
            with open(path, encoding="utf-8") as fh:
                self._stopwords = {line.strip().lower() for line in fh if line.strip()}
        if language == "english":
            self._impl = _porter2
        else:
            self._impl = lambda w: PorterStemmer(ORIGINAL_ALGORITHM).stem(w, to_lowercase=False)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        return self._impl(word)


class ARLSTem:
    """Arabic light stemmer. Listed by the product; its stemming results are outside this build."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    """Second ARLSTem variant; not implemented in this build."""


class WordNetLemmatizer:
    def __init__(self):
        data.find("corpora/wordnet")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")


# --------------------------------------------------- Porter2 (English)

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_VOWELS = "aeiouy"


def _p2_regions(word):
    r1 = len(word)
    for prefix in ("gener", "commun", "arsen"):
        if word.startswith(prefix):
            r1 = len(prefix)
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            r2 = i + 1
            break
    return min(r1, len(word)), min(r2, len(word))


def _p2_short_syllable_end(word):
    n = len(word)
    if n >= 3:
        return (word[-3] not in _P2_VOWELS and word[-2] in _P2_VOWELS
                and word[-1] not in _P2_VOWELS and word[-1] not in "wxY")
    if n == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    return False


def _porter2(word):
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if len(word) <= 2:
        return word
    if word[0] == "'":
        word = word[1:]
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    word = "".join(chars)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if word.endswith(suffix):
            word = word[: -len(suffix)]
            break

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-2] if len(word) > 4 else word[:-1]
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        if any(c in _P2_VOWELS for c in word[:-2]):
            word = word[:-1]

    if word in _P2_EXC2:
        return word.replace("Y", "y")

    r1, r2 = _p2_regions(word)

    # Step 1b
    if word.endswith(("eed", "eedly")):
        suffix = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suffix) >= r1:
            word = word[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                if any(c in _P2_VOWELS for c in stem):
                    word = stem
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif word[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        word = word[:-1]
                    elif _p2_short_word(word):
                        word += "e"
                break

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _P2_VOWELS:
        word = word[:-1] + "i"

    r1, r2 = _p2_regions(word)

    # Step 2
    step2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
        ("ational", "ate"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
        ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
        ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"),
        ("logi", "log"),
    ]
    for suffix, repl in step2:
        if word.endswith(suffix):
            if len(word) - len(suffix) >= r1:
                word = word[: -len(suffix)] + repl
            break
    else:
        if word.endswith("li") and len(word) - 2 >= r1 and len(word) >= 3 \
                and word[-3] in "cdeghkmnrt":
            word = word[:-2]

    # Step 3
    for suffix, repl in (("tional", "tion"), ("ational", "ate"), ("alize", "al"),
                         ("icate", "ic"), ("iciti", "ic"), ("ical", "ic"),
                         ("ative", ""), ("ful", ""), ("ness", "")):
        if word.endswith(suffix):
            base = len(word) - len(suffix)
            if suffix == "ative":
                if base >= r2:
                    word = word[:base] + repl
            elif base >= r1:
                word = word[:base] + repl
            break

    # Step 4
    for suffix in ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
                   "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"):
        if word.endswith(suffix):
            base = len(word) - len(suffix)
            if base >= r2:
                if suffix == "ion":
                    if base >= 1 and word[base - 1] in "st":
                        word = word[:base]
                else:
                    word = word[:base]
            break

    # Step 5
    if word.endswith("e"):
        base = len(word) - 1
        if base >= r2 or (base >= r1 and not _p2_short_syllable_end(word[:base])):
            word = word[:base]
    elif word.endswith("ll") and len(word) - 1 >= r2:
        word = word[:-1]

    return word.replace("Y", "y")


def _p2_short_word(word):
    r1, _ = _p2_regions(word)
    return r1 >= len(word) and _p2_short_syllable_end(word)
