"""Context-free grammar reader."""
import re


class Nonterminal:
    """A nonterminal symbol. Not a ``str``; ``str()`` gives its name."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(_sym_text(s) for s in self._rhs) or "")


def _sym_text(sym):
    if isinstance(sym, Nonterminal):
        return str(sym)
    return "'%s'" % sym


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects grammar text")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production line has no '->': %r" % raw)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not re.fullmatch(r"[A-Za-z_][\w\-]*", lhs_text):
                raise ValueError("bad left-hand side: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            for alt in _split_alternatives(rhs_text):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        out = self._productions
        if lhs is not None:
            out = [p for p in out if p.lhs() == lhs or str(p.lhs()) == str(lhs)]
        return list(out)

    def is_terminal(self, sym):
        return isinstance(sym, str)

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


_TOKEN_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([A-Za-z_][\w\-]*)|(\S))""")


def _split_alternatives(rhs_text):
    """Split the text after '->' into alternatives, each a list of symbols."""
    alternatives = [[]]
    pos = 0
    rhs_text = rhs_text.rstrip()
    while pos < len(rhs_text):
        m = _TOKEN_RE.match(rhs_text, pos)
        if not m or m.end() == pos:
            if rhs_text[pos:].strip() == "":
                break
            raise ValueError("cannot parse right-hand side: %r" % rhs_text)
        pos = m.end()
        dq, sq, bar, ident, other = m.groups()
        if dq is not None:
            alternatives[-1].append(dq)
        elif sq is not None:
            alternatives[-1].append(sq)
        elif bar is not None:
            alternatives.append([])
        elif ident is not None:
            alternatives[-1].append(Nonterminal(ident))
        elif other is not None:
            raise ValueError("unexpected character %r in production" % other)
    return alternatives
