"""Command-line group. ``cli.main(args=['tokenize'], standalone_mode=True)``.

Implemented without a third-party CLI framework so the runtime stays pure Python
with no extra dependencies.
"""
import sys

from lingora import _punkt
from lingora.tokenize import word_tokenize

USAGE = "usage: lingora tokenize [--language LANG] [--delimiter STR]"
EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_USAGE = 2


class _Group:
    name = "lingora"

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(USAGE + "\n")
            return EXIT_OK if args else EXIT_USAGE
        command, options = args[0], args[1:]
        if command != "tokenize":
            sys.stderr.write("lingora: no such command %r\n%s\n" % (command, USAGE))
            return EXIT_USAGE
        return _tokenize_command(options)


def _parse_options(options):
    language, delimiter = "english", " "
    i = 0
    while i < len(options):
        opt = options[i]
        if opt in ("--language", "-l", "--delimiter", "-d") and i + 1 < len(options):
            if opt in ("--language", "-l"):
                language = options[i + 1]
            else:
                delimiter = options[i + 1]
            i += 2
        else:
            raise ValueError("unrecognised option %r" % opt)
    return language, delimiter


def _tokenize_command(options):
    try:
        language, delimiter = _parse_options(options)
    except ValueError as exc:
        sys.stderr.write("lingora tokenize: %s\n%s\n" % (exc, USAGE))
        return EXIT_USAGE
    # Sentence splitting needs the Punkt model: fail before writing anything.
    try:
        _punkt.load_parameters(language)
    except LookupError as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return EXIT_FAILURE
    out = sys.stdout
    for line in sys.stdin:
        line = line.rstrip("\r\n")
        try:
            tokens = word_tokenize(line, language=language, preserve_line=False)
        except LookupError as exc:
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return EXIT_FAILURE
        out.write(delimiter.join(tokens) + "\n")
    out.flush()
    return EXIT_OK


cli = _Group()


def cli_entry():
    """Console-script entry point."""
    cli.main(args=sys.argv[1:], standalone_mode=True)
