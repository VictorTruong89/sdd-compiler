"""Constituent trees: build, read from bracketed text, compare, pretty-print."""


class Tree:
    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError(
                "Tree children must be a list of children, not %s" % type(children).__name__
            )
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Parse bracketed tree text ``(LABEL child ...)``."""
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring expects str")
        tokens = _tokenize_brackets(s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("node has no label")
            label = tokens[pos]
            pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced parentheses in bracketed tree text")
                tok = tokens[pos]
                if tok == ")":
                    pos += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos += 1

        root = parse_node()
        if pos != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return root

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        parts = []
        self._pformat_into(parts)
        return "".join(parts)

    def _pformat_into(self, parts):
        parts.append("(%s" % (self._label,))
        for child in self._children:
            parts.append(" ")
            if isinstance(child, Tree):
                child._pformat_into(parts)
            else:
                parts.append(_leaf_text(child))
        parts.append(")")

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


def _tokenize_brackets(s):
    tokens = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
        elif c in "()":
            tokens.append(c)
            i += 1
        else:
            j = i
            while j < len(s) and not s[j].isspace() and s[j] not in "()":
                j += 1
            tokens.append(s[i:j])
            i = j
    return tokens
