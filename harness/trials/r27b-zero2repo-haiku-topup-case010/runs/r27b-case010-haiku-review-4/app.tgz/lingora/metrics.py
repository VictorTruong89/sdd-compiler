"""Evaluation metrics: pure functions of their arguments."""
import math


def accuracy(reference, test):
    """Fraction of equal positions. Lists must have equal length; empty lists raise."""
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d vs %d)"
                         % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy of empty lists is undefined")
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    if not transpositions:
        return _levenshtein(s1, s2, substitution_cost)
    return _damerau(s1, s2, substitution_cost)


def _levenshtein(s1, s2, sub):
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1, 1):
        cur = [i]
        for j, c2 in enumerate(s2, 1):
            cost = 0 if c1 == c2 else sub
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost))
        prev = cur
    return prev[-1]


def _damerau(s1, s2, sub):
    """Lowrance-Wagner unrestricted Damerau-Levenshtein distance."""
    maxdist = len(s1) + len(s2)
    last_row = {}
    d = [[0] * (len(s2) + 2) for _ in range(len(s1) + 2)]
    d[0][0] = maxdist
    for i in range(len(s1) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(s2) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len(s1) + 1):
        last_match_col = 0
        for j in range(1, len(s2) + 1):
            i1 = last_row.get(s2[j - 1], 0)
            j1 = last_match_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[s1[i - 1]] = i
    return d[len(s1) + 1][len(s2) + 1]


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union|. Two empty sets are at distance 0."""
    s1, s2 = set(label1), set(label2)
    union = s1 | s2
    if not union:
        return 0.0
    return len(s1 ^ s2) / len(union)


def _check_sets(reference, test):
    for arg in (reference, test):
        if not isinstance(arg, (set, frozenset)):
            raise TypeError("precision, recall and f_measure require sets, not %s"
                            % type(arg).__name__)


def precision(reference, test):
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean; None when either set is empty or they share no element."""
    _check_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or p == 0 or r == 0:
        return None
    return 1 / (alpha / p + (1 - alpha) / r)
