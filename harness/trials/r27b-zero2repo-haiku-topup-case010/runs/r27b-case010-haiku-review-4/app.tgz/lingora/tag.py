"""Part-of-speech taggers: sequential taggers and the averaged perceptron tagger."""
import json
import os
import re
from collections import Counter, defaultdict

from lingora import data


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("taggers expect a list of tokens, not %s" % type(tokens).__name__)
    return list(tokens)


class TaggerI:
    """Base class: ``tag`` returns one (token, tag-or-None) pair per token."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def choose_tag(self, tokens):
        """Return a list of tags (str or None), one per token."""
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = list(self.choose_tag(tokens))
        if self._backoff is not None:
            open_idx = [i for i, t in enumerate(tags) if t is None]
            if open_idx:
                filled = self._backoff.tag([tokens[i] for i in open_idx])
                for i, (_, t) in zip(open_idx, filled):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(TaggerI):
    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def choose_tag(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(TaggerI):
    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        if train is None:
            raise TypeError("UnigramTagger requires training sentences")
        counts = defaultdict(Counter)
        for sentence in train:
            for token, tag in sentence:
                if tag is not None:
                    counts[token][tag] += 1
        self._model = {w: c.most_common(1)[0][0] for w, c in counts.items()}

    def choose_tag(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(TaggerI):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for rx, t in self._rules:
                if rx.match(tok):
                    tag = t
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------- perceptron

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_cache = {}


def _normalize(word):
    if word and "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or not value:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        if not self.classes:
            return max(scores, key=lambda l: (scores[l], l)) if scores else None
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(_features(i, word, context, prev, prev2))
            out.append(tag)
            prev2, prev = prev, tag
        return out


def _load_model(lang):
    rel = os.path.join("taggers", "averaged_perceptron_tagger_%s" % lang)
    model_dir = data.find(rel)
    if model_dir in _cache:
        return _cache[model_dir]
    base = os.path.join(model_dir, "averaged_perceptron_tagger_%s" % lang)
    with open(base + ".weights.json", encoding="utf-8") as fh:
        weights = json.load(fh)
    with open(base + ".tagdict.json", encoding="utf-8") as fh:
        tagdict = json.load(fh)
    with open(base + ".classes.json", encoding="utf-8") as fh:
        classes = json.load(fh)
    model = _Perceptron(weights, tagdict, classes)
    _cache[model_dir] = model
    return model


_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "A-NUM": "ADJ", "NUM": "NUM",
    "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "INTJ": "X",
    "S-PRO": "PRON", "A-PRO": "DET", "ADV-PRO": "ADV", "PRAEDIC": "ADV",
    "PRAEDIC-PRO": "ADV", "PARENTH": "X",
}


def _map_russian(tag):
    head = tag.split("=", 1)[0]
    return _RNC_TO_UNIVERSAL.get(head, "X")


def _load_en_map():
    path = os.path.join("taggers", "universal_tagset", "en-ptb.map")
    try:
        full = data.find(path)
    except data.ResourceNotFound as exc:
        raise data.ResourceNotFound(
            "universal tagset tables are not installed; cannot map English tags") from exc
    mapping = {}
    with open(full, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """LINGORA's recommended tagger (averaged perceptron) for English or Russian."""
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for the recommended tagger: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    model = _load_model(lang)
    tags = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_en_map()
            tags = [mapping.get(t, t) for t in tags]
        else:
            tags = [_map_russian(t) for t in tags]
    return list(zip(tokens, tags))
