"""Naive Bayes and decision-tree classifiers over in-memory featuresets."""
import math
from collections import Counter, defaultdict


class ProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda k: (self._probs[k], str(k)))

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes)) or not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    if not labeled_featuresets:
        raise ValueError("cannot train on an empty list")
    out = []
    for fs, label in labeled_featuresets:
        if not isinstance(fs, dict):
            raise TypeError("featureset must be a dict")
        out.append((dict(fs), label))
    return out


class NaiveBayesClassifier:
    """Multinomial-style Naive Bayes with add-one smoothing of feature values."""

    def __init__(self, label_counts, feature_label_counts, value_counts, feature_values, total):
        self._label_counts = label_counts          # label -> examples
        self._flc = feature_label_counts           # (label, fname) -> examples having fname
        self._value_counts = value_counts          # (label, fname, value) -> examples
        self._feature_values = feature_values      # fname -> distinct values seen
        self._total = total
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        label_counts = Counter()
        flc = Counter()
        vc = Counter()
        fvals = defaultdict(set)
        for fs, label in data:
            label_counts[label] += 1
            for fname, value in fs.items():
                flc[(label, fname)] += 1
                vc[(label, fname, value)] += 1
                fvals[fname].add(value)
        fvals = {f: len(v) for f, v in fvals.items()}
        return cls(dict(label_counts), dict(flc), dict(vc), fvals, len(data))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            logp = math.log(self._label_counts[label] / self._total)
            for fname, value in featureset.items():
                if fname not in self._feature_values:
                    continue  # feature name never seen in training
                distinct = self._feature_values[fname]
                num = self._value_counts.get((label, fname, value), 0) + 1
                den = self._flc.get((label, fname), 0) + distinct + 1
                logp += math.log(num / den)
            scores[label] = logp
        return scores

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        return max(self._labels, key=lambda l: scores[l])

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {l: math.exp(s - top) for l, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({l: e / total for l, e in exps.items()})


class DecisionTreeClassifier:
    """ID3-style tree: splits on the feature with the highest information gain."""

    def __init__(self, root, default):
        self._root = root          # node: ("leaf", label) or ("split", fname, {value: node}, majority)
        self._default = default

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        features = sorted({f for fs, _ in data for f in fs}, key=str)
        root = _build(data, features)
        return cls(root, _majority([l for _, l in data]))

    def classify(self, featureset):
        node = self._root
        while node[0] == "split":
            _, fname, children, majority = node
            key = featureset.get(fname)  # an absent feature counts as the None value
            if key not in children:
                return majority
            node = children[key]
        return node[1]


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for l in labels:
        if counts[l] == best:
            return l


def _entropy(labels):
    counts = Counter(labels)
    n = len(labels)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


def _build(data, features):
    labels = [l for _, l in data]
    if len(set(labels)) == 1:
        return ("leaf", labels[0])
    majority = _majority(labels)
    base = _entropy(labels)
    best_gain, best_feature = 0.0, None
    for f in features:
        groups = defaultdict(list)
        for fs, l in data:
            groups[fs.get(f)].append(l)
        remainder = sum(len(g) / len(data) * _entropy(g) for g in groups.values())
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_gain, best_feature = gain, f
    if best_feature is None:
        return ("leaf", majority)
    groups = defaultdict(list)
    for fs, l in data:
        groups[fs.get(best_feature)].append((fs, l))
    remaining = [f for f in features if f != best_feature]
    children = {}
    for value, subset in groups.items():
        children[value] = _build(subset, remaining)
    return ("split", best_feature, children, majority)


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    if not gold:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
