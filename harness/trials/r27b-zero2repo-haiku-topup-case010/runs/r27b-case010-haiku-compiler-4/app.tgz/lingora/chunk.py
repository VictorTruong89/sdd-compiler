"""Regular-expression chunk parser over tagged tokens.

# spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452
# spec: N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459
# spec: N-000460
# spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234
# spec: N-000235 N-000236 N-000237 N-000238 N-000239 N-000240 N-000241
# spec: N-000242 N-000243 N-000244 N-000245 N-000246 N-000247 N-000248
# spec: N-000249 N-000250 N-000251 N-000252 N-000253 N-000254 N-000255
# spec: N-000256 N-000257 N-000037
"""

import re

from . import data
from .errors import UnsupportedInput
from .tree import Tree

SENTENCE_LABEL = "S"


class ChunkRule:
    """A chunk rule: every match of the tag pattern becomes a chunk labelled
    ``label``. ``pattern`` is the text inside the braces."""

    def __init__(self, label, pattern):
        self.label = label
        self.pattern = pattern
        self._regex = _tag_pattern_regex(pattern)


class ChinkRule:
    """A chink rule: matching tokens are removed from the chunks built earlier
    in the same clause. ``pattern`` is the text between the braces."""

    def __init__(self, pattern):
        self.pattern = pattern
        self._regex = _tag_pattern_regex(pattern)


class _Clause:
    def __init__(self, label):
        self.label = label
        self.rules = []


def _tag_pattern_regex(pattern):
    """Translate a tag pattern (elements ``<...>`` with optional quantifiers)
    into a regular expression over the string ``<tag1><tag2>...``."""
    out = []
    i = 0
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch.isspace():
            i += 1
            continue
        if ch != "<":
            raise ValueError("tag pattern element must start with '<': %r" % pattern)
        j = pattern.find(">", i + 1)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern %r" % pattern)
        content = pattern[i + 1:j]
        element = []
        k = 0
        while k < len(content):
            c = content[k]
            if c == "\\" and k + 1 < len(content):
                element.append(content[k:k + 2])
                k += 2
                continue
            element.append("[^<>]" if c == "." else c)
            k += 1
        out.append("(?:<(?:%s)>)" % "".join(element))
        i = j + 1
        # Optional quantifier.
        if i < n and pattern[i] in "?*+":
            out.append(pattern[i])
            i += 1
        elif i < n and pattern[i] == "{":
            j = pattern.find("}", i)
            if j < 0:
                raise ValueError("unclosed quantifier in tag pattern %r" % pattern)
            quant = pattern[i:j + 1]
            if not re.fullmatch(r"\{\d*(,\d*)?\}", quant):
                raise ValueError("bad quantifier %r" % quant)
            out.append(quant)
            i = j + 1
    try:
        return re.compile("".join(out))
    except re.error as exc:  # pragma: no cover - defensive
        raise ValueError("bad tag pattern %r: %s" % (pattern, exc))


def _matches(tags, regex):
    """Non-overlapping, left-to-right, longest matches over ``tags`` as
    ``(first_index, end_index)`` pairs (end exclusive). Empty matches are
    skipped."""
    pieces = ["<%s>" % t for t in tags]
    starts = []
    ends = []
    pos = 0
    for piece in pieces:
        starts.append(pos)
        pos += len(piece)
        ends.append(pos)
    text = "".join(pieces)
    start_index = {s: i for i, s in enumerate(starts)}
    end_index = {e: i + 1 for i, e in enumerate(ends)}
    result = []
    for m in regex.finditer(text):
        if m.end() == m.start():
            continue
        a = start_index.get(m.start())
        b = end_index.get(m.end())
        if a is None or b is None:
            continue
        result.append((a, b))
    return result


def _parse_pattern(text):
    text = text.strip()
    if len(text) >= 2 and text[0] == "{" and text[-1] == "}":
        return ChunkRule(None, text[1:-1])
    if len(text) >= 2 and text[0] == "}" and text[-1] == "{":
        return ChinkRule(text[1:-1])
    raise ValueError("pattern must be {<tag pattern>} or }<tag pattern>{: %r" % text)


def _parse_grammar(text):
    clauses = []
    current = None
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if raw[:1] in (" ", "\t") and current is not None:
            current.rules.append(_parse_pattern(stripped))
            continue
        m = re.match(r"^\s*([^\s:]+)\s*:\s*(.*)$", raw)
        if not m:
            raise ValueError("clause line must be '<LABEL>: <pattern>': %r" % raw)
        current = _Clause(m.group(1))
        clauses.append(current)
        rest = m.group(2).strip()
        if rest:
            current.rules.append(_parse_pattern(rest))
    for clause in clauses:
        for rule in clause.rules:
            if isinstance(rule, ChunkRule):
                rule.label = clause.label
    return clauses


class RegexpParser:
    """Chunk parser for a chunk grammar (text, or a list of stages)."""

    # spec: N-000449 N-000450 N-000451
    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list):
            self._clauses = []
            for stage in grammar:
                if isinstance(stage, ChunkRule):
                    clause = _Clause(stage.label)
                    clause.rules.append(stage)
                elif isinstance(stage, ChinkRule):
                    clause = _Clause(None)
                    clause.rules.append(stage)
                else:
                    raise UnsupportedInput("chunk-parser stages must be ChunkRule or ChinkRule")
                self._clauses.append(clause)
        else:
            raise UnsupportedInput("chunk grammar must be a str or a list of stages")

    # spec: N-000446 N-000455 N-000456 N-000458 N-000459 N-000460
    # spec: N-000236 N-000240 N-000241 N-000243 N-000245 N-000246 N-000247
    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise UnsupportedInput("tagged must be a list of (token, tag) pairs")
        root = []
        for pair in tagged:
            if not isinstance(pair, tuple) or len(pair) != 2:
                raise UnsupportedInput("each item must be a (token, tag) pair")
            root.append(tuple(pair))
        for clause in self._clauses:
            clause_trees = []
            for rule in clause.rules:
                if isinstance(rule, ChunkRule):
                    root, created = _apply_chunk(root, rule)
                    clause_trees.extend(created)
                else:
                    root, clause_trees = _apply_chink(root, clause_trees, rule)
        return Tree(SENTENCE_LABEL, root)


def _apply_chunk(root, rule):
    new_root = []
    created = []
    i = 0
    n = len(root)
    while i < n:
        if isinstance(root[i], Tree):
            new_root.append(root[i])
            i += 1
            continue
        j = i
        while j < n and not isinstance(root[j], Tree):
            j += 1
        run = root[i:j]
        tags = [t for _, t in run]
        pos = 0
        for a, b in _matches(tags, rule._regex):
            new_root.extend(run[pos:a])
            tree = Tree(rule.label, run[a:b])
            created.append(tree)
            new_root.append(tree)
            pos = b
        new_root.extend(run[pos:])
        i = j
    return new_root, created


def _apply_chink(root, clause_trees, rule):
    clause_ids = {id(t) for t in clause_trees}
    new_root = []
    new_trees = []
    for item in root:
        if not (isinstance(item, Tree) and id(item) in clause_ids):
            new_root.append(item)
            continue
        leaves = item.leaves()
        tags = [t for _, t in leaves]
        matched = _matches(tags, rule._regex)
        if not matched:
            new_root.append(item)
            new_trees.append(item)
            continue
        pos = 0
        for a, b in matched:
            if a > pos:
                piece = Tree(item.label(), leaves[pos:a])
                new_trees.append(piece)
                new_root.append(piece)
            new_root.extend(leaves[a:b])
            pos = b
        if pos < len(leaves):
            piece = Tree(item.label(), leaves[pos:])
            new_trees.append(piece)
            new_root.append(piece)
    return new_root, new_trees


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Needs the named-entity model and the English
    wordlist; raises when either is not visible."""
    # spec: N-000452 N-000257
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise UnsupportedInput("tagged_tokens must be a list of (token, tag) pairs")
    data.find(data.NE_CHUNKER)
    data.find(data.ENGLISH_WORDS)
    raise NotImplementedError(
        "the named-entity chunker model is not implemented in this library"
    )
