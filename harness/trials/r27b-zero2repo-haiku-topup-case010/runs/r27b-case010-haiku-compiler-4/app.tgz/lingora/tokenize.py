"""Word, punctuation and sentence tokenizers.

# spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409
# spec: N-000410 N-000411 N-000412 N-000413
# spec: N-000081 N-000082 N-000083 N-000084 N-000085 N-000086 N-000087
# spec: N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094
# spec: N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101
# spec: N-000102 N-000103 N-000104 N-000105 N-000106 N-000107 N-000108
# spec: N-000109 N-000110 N-000111 N-000112 N-000113 N-000114 N-000115
# spec: N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122
# spec: N-000123 N-000124 N-000125 N-000126 N-000127 N-000128 N-000134
# spec: N-000135 N-000136 N-000137 N-000138 N-000139
# spec: N-000349 N-000065 N-000066 N-000067
"""

import re

from . import _punkt
from .errors import UnsupportedInput

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
    "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
    "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
]


def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise UnsupportedInput("%s must be a str, not %s" % (name, type(text).__name__))


def _check_bool(value, name):
    if not isinstance(value, bool):
        raise UnsupportedInput("%s must be a bool" % name)


# ---------------------------------------------------------------- word/punct

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space
    characters. Whitespace is never part of a token."""

    # spec: N-000089 N-000090 N-000091
    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    # spec: N-000126 N-000127 N-000128
    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in _WORDPUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ------------------------------------------------------------------ Treebank

# spec: N-000092 … N-000103 (Penn Treebank conventions) and
# spec: N-000104 … N-000110 (recommended word tokenizer improvements).

_FUSED = [
    (re.compile(r"\b(can)(not)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(d)('ye)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(gim)(me)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(gon)(na)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(got)(ta)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(lem)(me)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(more)('n)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"\b(wan)(na)\b", re.IGNORECASE), r"\1 \2"),
    (re.compile(r"(?<![\w'])('t)(is|was)\b", re.IGNORECASE), r"\1 \2"),
]

_TYPOGRAPHIC_DOUBLE = re.compile("([“”„‟«»])")
_TYPOGRAPHIC_SINGLE = re.compile("(?<![^\\W\\d_])’|’(?![^\\W\\d_])|([‘‚‛‹›])")
_DASHES_STARS = re.compile("([‒-―*])")


def _treebank(text, improved):
    if improved and text.startswith('"'):
        # Recommended tokenizer: a straight double quote at the very start
        # of the text is the closing-quote token.
        text = " '' " + text[1:]
    s = " " + text + " "
    # Starting quotes: after start, a space or an opening bracket -> ``
    s = re.sub(r'([ (\[{<])"', r"\1 `` ", s)
    if improved:
        s = _TYPOGRAPHIC_DOUBLE.sub(r" \1 ", s)
        s = _TYPOGRAPHIC_SINGLE.sub(lambda m: " %s " % m.group(0), s)
        s = _DASHES_STARS.sub(r" \1 ", s)
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), s)
        s = re.sub(r"--", " -- ", s)
    else:
        s = re.sub(r"\.\.\.", " ... ", s)
    # Commas and colons, unless a digit follows.
    s = re.sub(r"([:,])([^\d])", r" \1 \2", s)
    s = re.sub(r"([:,])$", r" \1 ", s)
    # Semicolons, @, #, $, %, &.
    s = re.sub(r"[;@#$%&]", lambda m: " %s " % m.group(0), s)
    # A point only at the end of the text, optionally followed by closers.
    s = re.sub(r"([^.])(\.)([\]\)}>\"']*)\s*$", r"\1 \2\3 ", s)
    # Question and exclamation marks.
    s = re.sub(r"[?!]", lambda m: " %s " % m.group(0), s)
    # Bare apostrophe ending a word.
    s = re.sub(r"([^'])' ", r"\1 ' ", s)
    # Brackets.
    s = re.sub(r"[\]\[\(\)\{\}<>]", lambda m: " %s " % m.group(0), s)
    if not improved:
        s = re.sub(r"--", " -- ", s)
    # Ending quotes.
    s = s.replace('"', " '' ")
    # Clitics.
    s = re.sub(r"([^' ])('[sS]|'[mM]|'[dD]|') ", r"\1 \2 ", s)
    s = re.sub(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ", r"\1 \2 ", s)
    if not improved:
        for pattern, repl in _FUSED:
            s = pattern.sub(repl, s)
    else:
        for pattern, repl in _FUSED[1:]:
            s = pattern.sub(repl, s)
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer."""

    def tokenize(self, text):
        _check_text(text)
        if not text.strip():
            return []
        return _treebank(text, improved=False)

    def span_tokenize(self, text):
        _check_text(text)
        return _align_spans(text, self.tokenize(text))


def _align_spans(text, tokens):
    spans = []
    pos = 0
    for tok in tokens:
        probe = tok
        if tok in ("``", "''"):
            probe = '"'
        idx = text.find(probe, pos)
        if idx < 0:
            raise ValueError("token %r cannot be aligned to the text" % tok)
        spans.append((idx, idx + len(probe)))
        pos = idx + len(probe)
    return spans


# -------------------------------------------------------- recommended tokenizers

def _sentence_tokens(sentence):
    return _treebank(sentence, improved=True)


def sent_tokenize(text, language="english"):
    """Sentences of ``text`` (Punkt). Raises when the models are not visible."""
    _check_text(text)
    if not text.strip():
        if not isinstance(language, str):
            raise UnsupportedInput("language must be a str")
        _punkt.load_parameters(language)  # the models are required regardless
        return []
    return _punkt.sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    _check_text(text)
    _check_bool(preserve_line, "preserve_line")
    if preserve_line:
        if not text.strip():
            return []
        return _sentence_tokens(text)
    tokens = []
    for sentence in sent_tokenize(text, language):
        tokens.extend(_sentence_tokens(sentence))
    return tokens


# ------------------------------------------------------------- whitespace etc.

class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters."""

    # spec: N-000113
    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in re.finditer(r"\S+", text)]


_BLANKLINE_RE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Segments separated by blank lines (newline, optional whitespace,
    newline). Single newlines inside a segment are kept."""
    _check_text(text)
    segments = []
    for piece in _BLANKLINE_RE.split(text):
        piece = piece.strip()
        if piece:
            segments.append(piece)
    return segments


class RegexpTokenizer:
    """Tokens are matches of ``pattern`` (token mode) or the pieces between
    matches (gap mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=False):
        if not isinstance(pattern, str):
            raise UnsupportedInput("pattern must be a str")
        _check_bool(gaps, "gaps")
        _check_bool(discard_empty, "discard_empty")
        self.pattern = pattern
        self._re = re.compile(pattern)
        self.gaps = gaps
        self.discard_empty = discard_empty

    def _spans(self, text):
        if not self.gaps:
            return [m.span() for m in self._re.finditer(text)]
        out = []
        pos = 0
        for m in self._re.finditer(text):
            out.append((pos, m.start()))
            pos = m.end()
        out.append((pos, len(text)))
        return out

    def tokenize(self, text):
        _check_text(text)
        tokens = [text[s:e] for s, e in self._spans(text)]
        if self.discard_empty:
            tokens = [t for t in tokens if t]
        return tokens

    def span_tokenize(self, text):
        _check_text(text)
        spans = self._spans(text)
        if self.discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


# ------------------------------------------------------------------- tweets

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[\)\]\(\[dDpP/:\}\{@|\\]"
    r"|[\)\]\(\[dDpP/:\}\{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_RE = re.compile(
    r"(?P<emo>" + _EMOTICON + r")"
    r"|(?P<url>https?://\S+|www\.\S+)"
    r"|(?P<hash>#\w+)"
    r"|(?P<handle>@\w+)"
    r"|(?P<num>\d+(?:[.,:]\d+)*)"
    r"|(?P<word>\w+(?:['’]\w+)*)"
    r"|(?P<ell>\.{2,})"
    r"|(?P<punct>[^\w\s])",
    re.UNICODE,
)
_HANDLE_STRIP = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REPEAT = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tokenizer for short social-media text."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        _check_bool(preserve_case, "preserve_case")
        _check_bool(reduce_len, "reduce_len")
        _check_bool(strip_handles, "strip_handles")
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLE_STRIP.sub(" ", text)
        if self.reduce_len:
            text = _REPEAT.sub(lambda m: m.group(1) * 3, text)
        tokens = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group(0)
            if not self.preserve_case and not m.group("emo"):
                tok = tok.lower()
            tokens.append(tok)
        return tokens
