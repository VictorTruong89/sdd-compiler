"""Sentence-level BLEU.

# spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
# spec: N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341
# spec: N-000342
"""

import math
from collections import Counter

from .errors import UnsupportedInput


def _check_tokens(tokens, name):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise UnsupportedInput("%s must be a token list" % name)
    for tok in tokens:
        if not isinstance(tok, str):
            raise UnsupportedInput("tokens in %s must be str" % name)


def epsilon_smoothing(counts, epsilon=0.1):
    """Replace a zero-count precision by ``epsilon / denominator``.

    ``counts`` is a list of ``(matches, total)`` pairs, one per n-gram order.
    Returns the list of smoothed precisions.
    """
    out = []
    for matches, total in counts:
        if total == 0:
            out.append(0.0)
        elif matches == 0:
            out.append(epsilon / total)
        else:
            out.append(matches / total)
    return out


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` against ``references``.

    ``weights`` gives one weight per n-gram order starting from unigrams; when
    omitted, unigrams and bigrams are weighted 0.5 each. Without a smoothing
    function the score is 0 when some weighted order has no match.
    ``smoothing_function(counts)`` receives ``(matches, total)`` pairs per
    order and returns the list of precisions to use (see
    :func:`epsilon_smoothing`).
    """
    # spec: N-000513 N-000514 N-000515 N-000337 N-000338 N-000339 N-000340
    # spec: N-000341 N-000342
    if isinstance(references, (str, bytes)) or not isinstance(references, (list, tuple)):
        raise UnsupportedInput("references must be a list of token lists")
    for ref in references:
        _check_tokens(ref, "references")
    _check_tokens(hypothesis, "hypothesis")
    if weights is None:
        weights = (0.5, 0.5)  # spec: N-000515 — unigrams and bigrams only
    weights = list(weights)
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise UnsupportedInput("weights must be numbers")
    if not weights:
        raise UnsupportedInput("weights must not be empty")
    if smoothing_function is not None and not callable(smoothing_function):
        raise UnsupportedInput("smoothing_function must be callable")
    if not references:
        raise UnsupportedInput("at least one reference is needed")

    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0.0

    counts = []
    for order in range(1, len(weights) + 1):
        hyp_ngrams = Counter(
            tuple(hypothesis[i:i + order]) for i in range(hyp_len - order + 1)
        )
        total = sum(hyp_ngrams.values())
        max_ref = Counter()
        for ref in references:
            ref_ngrams = Counter(
                tuple(ref[i:i + order]) for i in range(len(ref) - order + 1)
            )
            for gram, c in ref_ngrams.items():
                if c > max_ref[gram]:
                    max_ref[gram] = c
        matches = sum(min(c, max_ref[g]) for g, c in hyp_ngrams.items())
        counts.append((matches, total))

    if smoothing_function is None:
        precisions = []
        for (matches, total), w in zip(counts, weights):
            if w == 0:
                precisions.append(1.0)  # unscored order: contributes nothing
                continue
            if total == 0 or matches == 0:
                return 0.0
            precisions.append(matches / total)
    else:
        precisions = list(smoothing_function(counts))

    log_sum = 0.0
    for w, p in zip(weights, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)
    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > closest:
        bp = 1.0
    else:
        bp = math.exp(1 - closest / hyp_len)
    return bp * math.exp(log_sum)
