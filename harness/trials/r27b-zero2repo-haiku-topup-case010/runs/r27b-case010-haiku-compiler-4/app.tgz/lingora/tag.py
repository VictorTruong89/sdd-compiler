"""Part-of-speech taggers.

# spec: N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439
# spec: N-000440 N-000441 N-000442 N-000443 N-000444 N-000445
# spec: N-000187 N-000188 N-000189 N-000190 N-000191 N-000192 N-000193
# spec: N-000194 N-000195 N-000196 N-000197 N-000198 N-000199 N-000200
# spec: N-000201 N-000202 N-000203 N-000204 N-000205 N-000206 N-000207
# spec: N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
# spec: N-000215 N-000216 N-000217 N-000218 N-000219 N-000220 N-000221
# spec: N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
# spec: N-000024 N-000035 N-000036 N-000008
"""

import json
import os
import re
from collections import Counter, defaultdict

from . import data
from .errors import UnsupportedInput

__all__ = ["AffixTagger", "BigramTagger", "DefaultTagger", "NgramTagger", "RegexpTagger",
           "TrigramTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise UnsupportedInput("tokens must be a list of str, not %s" % type(tokens).__name__)
    for tok in tokens:
        if not isinstance(tok, str):
            raise UnsupportedInput("every token must be a str")
    return list(tokens)


class _SequentialTagger:
    """Shared behaviour: produce tags, then consult the backoff tagger for
    tokens left without a tag."""

    backoff = None

    def _choose(self, tokens):  # pragma: no cover - overridden
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._choose(tokens)
        if self.backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                sub = self.backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, sub):
                    tags[i] = t
        return [(tok, tags[i]) for i, tok in enumerate(tokens)]


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    # spec: N-000198
    def __init__(self, tag):
        self._tag = tag

    def _choose(self, tokens):
        return [self._tag for _ in tokens]


class UnigramTagger(_SequentialTagger):
    """Each word receives the tag it was most often given in training."""

    # spec: N-000199 N-000200 N-000201
    def __init__(self, train=None, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for pair in sentence:
                word, tag = pair
                counts[word][tag] += 1
        self._model = {}
        for word, counter in counts.items():
            # Ties: the tag seen first in training wins (Counter keeps insertion order).
            best = max(counter.items(), key=lambda kv: kv[1])[0]
            self._model[word] = best

    def _choose(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; the first whose pattern matches at the token's
    first character gives the tag."""

    # spec: N-000202 N-000203 N-000204
    def __init__(self, regexps, backoff=None):
        _check_backoff(backoff)
        self.backoff = backoff
        rules = []
        for pair in regexps:
            pattern, tag = pair
            rules.append((re.compile(pattern), tag))
        self._rules = rules

    def _choose(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for regex, value in self._rules:
                if regex.match(tok):
                    tag = value
                    break
            out.append(tag)
        return out


def _check_backoff(backoff):
    if backoff is not None and not isinstance(backoff, _SequentialTagger):
        raise UnsupportedInput("backoff must be another tagger or None")


class NgramTagger(_SequentialTagger):
    """Tags a token from the word and the previous ``n - 1`` tags it was
    trained with. The most frequent training tag for that context wins."""

    # spec: N-000189 — bigram and trigram taggers follow the same protocol.
    def __init__(self, n, train=None, backoff=None):
        if isinstance(n, bool) or not isinstance(n, int) or n < 1:
            raise UnsupportedInput("n must be a positive int")
        _check_backoff(backoff)
        self.backoff = backoff
        self._n = n
        counts = defaultdict(Counter)
        for sentence in (train or []):
            history = []
            for word, tag in sentence:
                counts[(self._context(history), word)][tag] += 1
                history.append(tag)
        self._model = {ctx: c.most_common(1)[0][0] for ctx, c in counts.items()}

    def _context(self, history):
        return tuple(history[-(self._n - 1):]) if self._n > 1 else ()

    def _choose(self, tokens):
        tags = []
        for tok in tokens:
            tags.append(self._model.get((self._context(tags), tok)))
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_SequentialTagger):
    """Tags a token by its suffix of ``affix_length`` characters."""

    # spec: N-000189
    def __init__(self, train=None, affix_length=3, backoff=None):
        if isinstance(affix_length, bool) or not isinstance(affix_length, int) or affix_length < 1:
            raise UnsupportedInput("affix_length must be a positive int")
        _check_backoff(backoff)
        self.backoff = backoff
        self._k = affix_length
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for word, tag in sentence:
                counts[word[-self._k:]][tag] += 1
        self._model = {aff: c.most_common(1)[0][0] for aff, c in counts.items()}

    def _choose(self, tokens):
        return [self._model.get(tok[-self._k:]) for tok in tokens]


# ------------------------------------------------------------ averaged perceptron

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))


class _PerceptronTagger:
    def __init__(self, directory, lang):
        self.model = _load_perceptron(directory, lang)

    def tag(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.model.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self.model.predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output

    @staticmethod
    def _features(i, word, context, prev, prev2):
        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        features = defaultdict(int)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features


_PERCEPTRON_CACHE = {}


def _load_perceptron(directory, lang):
    key = (directory, lang)
    if key in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[key]
    base = "averaged_perceptron_tagger_%s" % lang
    with open(os.path.join(directory, base + ".weights.json"), encoding="utf-8") as h:
        weights = json.load(h)
    with open(os.path.join(directory, base + ".tagdict.json"), encoding="utf-8") as h:
        tagdict = json.load(h)
    with open(os.path.join(directory, base + ".classes.json"), encoding="utf-8") as h:
        classes = json.load(h)
    model = _PerceptronModel(weights, tagdict, set(classes))
    _PERCEPTRON_CACHE[key] = model
    return model


_TAGGERS = {"eng": "english", "rus": "russian"}


def _universal_map():
    directory = data.find(data.UNIVERSAL_TAGSET)
    mapping = {}
    with open(os.path.join(directory, "en-ptb.map"), encoding="utf-8") as h:
        for line in h:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


# Russian National Corpus part-of-speech categories -> universal tagset.
_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "INTJ": "X", "NUM": "NUM", "SPRO": "PRON",
    "APRO": "DET", "ANUM": "ADJ", "PRAEDIC": "ADV", "PARENTH": "X",
    "COM": "ADJ",
}


def _map_rus(tag):
    head = tag.split("=", 1)[0]
    return _RUS_UNIVERSAL.get(head, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with LINGORA's recommended tagger.

    ``lang`` is ``'eng'`` (default) or ``'rus'``. ``tagset`` is ``None`` for
    the native tags or ``'universal'``. Raises for a string input, another
    language, a missing model, or an unknown tagset.
    """
    # spec: N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225
    tokens = _check_tokens(tokens)
    if not isinstance(lang, str) or lang not in _TAGGERS:
        raise UnsupportedInput("pos_tag supports lang 'eng' or 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise UnsupportedInput("tagset must be None or 'universal'")
    directory = data.find(data.AVERAGED_PERCEPTRON.format(lang=lang))
    if not tokens:
        return []
    tagger = _PerceptronTagger(directory, lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _universal_map()  # raises if the tables are not visible
            tagged = [(w, mapping.get(t, t)) for w, t in tagged]
        else:
            tagged = [(w, _map_rus(t)) for w, t in tagged]
    return tagged
