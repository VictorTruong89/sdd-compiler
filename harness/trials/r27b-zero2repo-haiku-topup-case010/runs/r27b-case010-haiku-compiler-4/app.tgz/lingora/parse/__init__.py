"""Parsers over a context-free grammar.

# spec: N-000259 N-000260 N-000261 N-000262 N-000263
# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
# spec: N-000272 N-000273 N-000274 N-000275
# spec: N-000292 N-000293 N-000294 N-000473 N-000474 N-000475 N-000476
"""

from ..errors import ParseError, UnsupportedInput
from ..tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise UnsupportedInput("tokens must be a list of str")
    for tok in tokens:
        if not isinstance(tok, str):
            raise UnsupportedInput("every token must be a str")
    terminals = grammar.terminals()
    for tok in tokens:
        if tok not in terminals:
            # spec: N-000292 N-000294 — a token no production produces is an error.
            raise ParseError("token %r is not produced by any production" % tok)
    return list(tokens)


class ChartParser:
    """Exhaustive chart parser: returns every parse tree of the token list.

    Trees are built span by span to a fixed point. A derivation in which a
    node reappears beneath itself (a cycle over the same span) is not kept,
    so the set of trees is finite.
    """

    # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        grammar = self._grammar
        tokens = _check_tokens(grammar, tokens)
        n = len(tokens)
        productions = grammar.productions()
        chart = {}  # (name, i, j) -> {Tree: frozenset of nodes in the subtree}

        changed = True
        while changed:
            changed = False
            for prod in productions:
                name = str(prod.lhs())
                for i in range(n + 1):
                    for j, children, desc in _match(prod.rhs(), 0, i, tokens, chart):
                        node = (name, i, j)
                        if node in desc:
                            continue
                        tree = Tree(name, list(children))
                        bucket = chart.setdefault(node, {})
                        if tree not in bucket:
                            bucket[tree] = frozenset(desc | {node})
                            changed = True
        start = str(grammar.start())
        return iter([t for t in chart.get((start, 0, n), {})])


def _match(rhs, k, i, tokens, chart):
    """Yield ``(end, children, nodes)`` for matching ``rhs[k:]`` from ``i``."""
    n = len(tokens)
    if k == len(rhs):
        yield i, (), frozenset()
        return
    sym = rhs[k]
    if isinstance(sym, str):
        if sym == "":
            # A quoted empty string is a terminal that adds no token.
            yield from _match(rhs, k + 1, i, tokens, chart)
        elif i < n and tokens[i] == sym:
            for j, children, desc in _match(rhs, k + 1, i + 1, tokens, chart):
                yield j, (sym,) + children, desc
        return
    name = str(sym)
    for j in range(i, n + 1):
        for tree, desc in list(chart.get((name, i, j), {}).items()):
            for end, children, rest in _match(rhs, k + 1, j, tokens, chart):
                yield end, (tree,) + children, desc | rest


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass, without backtracking."""

    # spec: N-000272 N-000273 N-000274 N-000275
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        grammar = self._grammar
        tokens = _check_tokens(grammar, tokens)
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        stack = []
        pos = 0
        while True:
            reduced = False
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if len(stack) < k:
                    continue
                if all(_entry_matches(entry, sym) for entry, sym in zip(stack[-k:], rhs)):
                    children = [entry for entry in stack[-k:]]
                    stack[-k:] = [Tree(str(prod.lhs()), children)]
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        start = str(grammar.start())
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


def _entry_matches(entry, sym):
    if isinstance(sym, str):
        return isinstance(entry, str) and entry == sym
    return isinstance(entry, Tree) and entry.label() == str(sym)
