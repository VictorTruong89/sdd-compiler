"""Generate sentences from a context-free grammar.

# spec: N-000276 N-000277 N-000278 N-000279 N-000280
# spec: N-000477 N-000478 N-000479 N-000480
# spec: N-000040 N-000041
"""

from ..errors import UnsupportedInput


def _check_bound(value, name):
    if value is not None and (isinstance(value, bool) or not isinstance(value, int)):
        raise UnsupportedInput("%s must be an int or None" % name)


def generate(grammar, start=None, depth=None, n=None):
    """Yield the sentences the grammar derives from ``start``.

    Each sentence is a list of terminal ``str`` tokens. Productions are
    expanded in their written order. ``n`` bounds the number of sentences;
    ``depth`` bounds the derivation depth. A terminal that is the empty string
    adds no token to a sentence.
    """
    _check_bound(depth, "depth")
    _check_bound(n, "n")
    if start is None:
        start = grammar.start()
    start_name = str(start)

    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(str(prod.lhs()), []).append(prod.rhs())
    limit_stall = 2 * len(by_lhs) + 5

    def expand(name, d, memo):
        if d <= 0:
            return []
        key = (name, d)
        if key in memo:
            return memo[key]
        results = []
        for rhs in by_lhs.get(name, []):
            partial = [[]]
            for sym in rhs:
                if isinstance(sym, str):
                    if sym != "":
                        partial = [p + [sym] for p in partial]
                else:
                    sub = expand(str(sym), d - 1, memo)
                    partial = [p + q for p in partial for q in sub]
                if not partial:
                    break
            results.extend(partial)
        memo[key] = results
        return results

    seen = set()
    count = 0
    if depth is not None:
        for sentence in expand(start_name, depth, {}):
            key = tuple(sentence)
            if key in seen:
                continue
            seen.add(key)
            yield list(sentence)
            count += 1
            if n is not None and count >= n:
                return
        return

    d = 1
    stall = 0
    while True:
        fresh = False
        for sentence in expand(start_name, d, {}):
            key = tuple(sentence)
            if key in seen:
                continue
            seen.add(key)
            fresh = True
            yield list(sentence)
            count += 1
            if n is not None and count >= n:
                return
        stall = 0 if fresh else stall + 1
        if stall > limit_stall:
            return
        d += 1
