"""A tiny memo for parsed packaged resources, keyed by resource directory."""

_store = {}


def cached(key, build):
    if key not in _store:
        _store[key] = build()
    return _store[key]
