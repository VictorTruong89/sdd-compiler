"""Command line: ``lingora tokenize`` reads text on standard input and writes
one line of tokens per input line.

# spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000032 N-000083 N-000135 N-000139
# spec: N-000065
"""

import argparse
import sys

from . import tokenize as _tok
from ._punkt import load_parameters
from .errors import LingoraError


class _CommandGroup:
    """The ``lingora`` command group."""

    prog = "lingora"

    def _parser(self):
        parser = argparse.ArgumentParser(prog=self.prog)
        sub = parser.add_subparsers(dest="command")
        tok = sub.add_parser("tokenize", help="tokenize each input line")
        tok.add_argument("--language", default="english",
                         help="Punkt language for sentence splitting (default: english)")
        tok.add_argument("--delimiter", default=" ",
                         help="string placed between tokens (default: one space)")
        tok.add_argument("--encoding", default="utf-8",
                         help="encoding of standard input (default: utf-8)")
        return parser

    def _read_input(self, encoding):
        stream = sys.stdin
        buffer = getattr(stream, "buffer", None)
        if buffer is not None:
            return buffer.read().decode(encoding)
        return stream.read()

    def _tokenize(self, opts):
        # spec: N-000139 — missing Punkt models: fail before writing anything.
        load_parameters(opts.language)
        text = self._read_input(opts.encoding)
        out = sys.stdout
        for line in text.splitlines():
            tokens = _tok.word_tokenize(line, language=opts.language)
            out.write(opts.delimiter.join(tokens) + "\n")
        out.flush()
        return 0

    def _dispatch(self, args):
        parser = self._parser()
        opts = parser.parse_args(args)
        if opts.command is None:
            parser.print_usage(sys.stderr)
            return 2
        if opts.command == "tokenize":
            return self._tokenize(opts)
        return 2

    def main(self, args=None, standalone_mode=True):
        """Run the command group.

        With ``standalone_mode=True`` the process exits: status 0 on success,
        non-zero on failure. With ``standalone_mode=False`` the status is
        returned, and failures propagate as exceptions.
        """
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            code = self._dispatch(args)
        except LingoraError as exc:
            if not standalone_mode:
                raise
            sys.stderr.write("lingora: error: %s\n" % exc)
            code = 1
        except (OSError, UnicodeDecodeError, NotImplementedError) as exc:
            if not standalone_mode:
                raise
            sys.stderr.write("lingora: error: %s\n" % exc)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code


cli = _CommandGroup()


if __name__ == "__main__":
    cli.main()
