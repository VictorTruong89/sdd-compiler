"""Punkt-style sentence boundary detection driven by packaged parameters.

# spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000137 N-000138
# spec: N-000086 N-000413

The packaged parameters (abbreviation types, sentence starters, collocations
and orthographic context) are read from the Punkt resource directory found
through ``lingora.data``. Decisions follow the Punkt idea: a period is
ambiguous and is resolved from the word before it (abbreviation or not), the
pair of words around it (collocation), the next word (sentence starter and
capitalisation) and the orthographic context of the next word.
"""

import os
import re

from . import data

# Orthographic observation bits (spec, pack 06).
ORTHO_UPPER_SENT_START = 2
ORTHO_UPPER_INSIDE = 4
ORTHO_UPPER_UNKNOWN = 8
ORTHO_LOWER_SENT_START = 16
ORTHO_LOWER_INSIDE = 32
ORTHO_LOWER_UNKNOWN = 64

_NUMBER_RE = re.compile(r"^[-+]?[\d.,:/%]*\d[\d.,:/%]*$")
_CLOSERS = "\"')]}>”’"


class PunktParameters:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho = ortho


def _read_lines(filename):
    with open(filename, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.strip()]


def load_parameters(language):
    """Read the Punkt parameters for ``language``; raise if not visible."""
    from ._cache import cached

    directory = data.find(data.PUNKT.format(language=language))

    def build():
        abbrev = set()
        for line in _read_lines(os.path.join(directory, "abbrev_types.txt")):
            abbrev.add(line.strip().lower())
        starters = set()
        for line in _read_lines(os.path.join(directory, "sent_starters.txt")):
            starters.add(line.strip().lower())
        collocations = set()
        for line in _read_lines(os.path.join(directory, "collocations.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                collocations.add((parts[0].strip().lower(), parts[1].strip().lower()))
        ortho = {}
        for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                try:
                    ortho[parts[0].strip().lower()] = int(parts[1].strip())
                except ValueError:
                    continue
        return PunktParameters(abbrev, starters, collocations, ortho)

    return cached(("punkt", directory), build)


class _Token:
    __slots__ = ("start", "end", "text", "lead", "core", "period_final",
                 "ellipsis", "end_mark", "typ", "lower_type", "first_upper")


def _make_token(start, end, text):
    tok = _Token()
    tok.start, tok.end, tok.text = start, end, text
    lead = text.lstrip("(\"'[{“‘")
    stripped = lead.rstrip(_CLOSERS)
    tok.lead = lead
    tok.core = stripped
    tok.ellipsis = stripped.endswith("...") or stripped.endswith("…")
    tok.period_final = (stripped.endswith(".") and not tok.ellipsis
                        and len(stripped) > 1)
    tok.end_mark = stripped[-1:] in ("?", "!")
    if tok.period_final:
        body = stripped[:-1]
    elif tok.ellipsis:
        body = stripped.rstrip(".…")
    else:
        body = stripped
    if body and _NUMBER_RE.match(body):
        tok.typ = "##number##"
    else:
        tok.typ = body.lower()
    tok.lower_type = tok.typ
    tok.first_upper = lead[:1].isupper()
    return tok


def _is_abbreviation(tok, params):
    if not tok.period_final:
        return False
    if tok.typ in params.abbrev_types or tok.typ == "##number##":
        return True
    if "." in tok.typ:  # e.g. "e.g", "u.s"
        return True
    return len(tok.typ) == 1 and tok.typ.isalpha()


def _ortho_says_break(next_tok, params):
    """Orthographic heuristic for the word after a possible boundary.

    Returns True (a boundary is likely), False (a boundary is unlikely) or
    None (no evidence).
    """
    obs = params.ortho.get(next_tok.lower_type, None)
    if obs is None:
        return None
    if next_tok.first_upper:
        if obs & ORTHO_UPPER_SENT_START and not obs & ORTHO_LOWER_INSIDE:
            return True
        if obs & ORTHO_LOWER_INSIDE and not obs & ORTHO_UPPER_SENT_START:
            return False
        return None
    if obs & ORTHO_LOWER_SENT_START or obs & ORTHO_LOWER_INSIDE:
        return False
    return None


def _decide(tok, nxt, params):
    """Return True when a sentence boundary follows ``tok``."""
    if nxt is None:
        return True
    if tok.end_mark:
        return True
    if tok.ellipsis:
        # An ellipsis ends a sentence when the next word starts one.
        return nxt.first_upper
    if not tok.period_final:
        return False
    if (tok.typ, nxt.lower_type) in params.collocations:
        return False
    if _is_abbreviation(tok, params):
        # Abbreviation: break only when the next word looks like a sentence start.
        if not nxt.first_upper:
            return False
        if nxt.lower_type in params.sent_starters:
            return True
        return bool(_ortho_says_break(nxt, params))
    # Ordinary period.
    if nxt.first_upper:
        return True
    verdict = _ortho_says_break(nxt, params)
    if verdict is not None:
        return verdict
    return not nxt.lead[:1].islower()


def sentence_spans(text, language):
    """Return ``(start, end)`` character spans of the sentences of ``text``.

    Raises :class:`ResourceNotFound` when the Punkt models for ``language``
    are not visible.
    """
    params = load_parameters(language)
    tokens = [
        _make_token(m.start(), m.end(), m.group(0))
        for m in re.finditer(r"\S+", text)
    ]
    if not tokens:
        return []
    spans = []
    seg_start = tokens[0].start
    for i, tok in enumerate(tokens):
        nxt = tokens[i + 1] if i + 1 < len(tokens) else None
        blank_after = False
        if nxt is not None:
            gap = text[tok.end:nxt.start]
            blank_after = bool(re.search(r"\n[ \t\r\f\v]*\n", gap))
        if blank_after or _decide(tok, nxt, params):
            spans.append((seg_start, tok.end))
            if nxt is not None:
                seg_start = nxt.start
    return spans


def sentences(text, language="english"):
    """The sentences of ``text`` as strings, in their original order."""
    return [text[s:e] for s, e in sentence_spans(text, language)]
