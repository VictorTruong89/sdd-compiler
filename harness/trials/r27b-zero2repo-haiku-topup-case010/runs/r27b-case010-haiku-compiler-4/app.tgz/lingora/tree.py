"""Constituent trees and bracketed tree text.

# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487
# spec: N-000282 N-000283 N-000284 N-000290 N-000291
# spec: N-000488 N-000489 N-000490 N-000491
"""

import re

from .errors import UnsupportedInput


class Tree:
    """A labelled node with an ordered list of children.

    A child is a token string (a leaf), a ``(token, tag)`` pair (a leaf of a
    tagged chunk structure), or another :class:`Tree`.
    """

    __slots__ = ("_label", "_children")

    # spec: N-000486 N-000487 N-000488 — children must be a list; a str or a
    # missing child list is refused.
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise UnsupportedInput(
                "Tree children must be a list of children, not %s" % type(children).__name__
            )
        self._label = label
        self._children = list(children)

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    # spec: N-000287 — pre-order listing of every label and leaf.
    def pformat(self, indent=0):
        pad = "  " * indent
        if all(not isinstance(c, Tree) for c in self._children):
            return "%s(%s)" % (pad, _join_node(self._label, self._children))
        lines = ["%s(%s" % (pad, _label_text(self._label))]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child.pformat(indent + 1))
            else:
                lines.append("%s  %s" % (pad, _leaf_text(child)))
        lines[-1] += ")"
        return "\n".join(lines)

    # spec: N-000489 — bracketed tree text: (label child ...)
    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise UnsupportedInput("Tree.fromstring needs a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        pos = [0]

        def parse():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("node without a label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while pos[0] < len(tokens) and tokens[pos[0]] != ")":
                if tokens[pos[0]] == "(":
                    children.append(parse())
                else:
                    children.append(tokens[pos[0]])
                    pos[0] += 1
            if pos[0] >= len(tokens):
                raise ValueError("missing ')' in bracketed tree text")
            pos[0] += 1
            return cls(label, children)

        tree = parse()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree


def _label_text(label):
    return str(label)


def _leaf_text(leaf):
    if isinstance(leaf, tuple):
        return "/".join(str(x) for x in leaf)
    return str(leaf)


def _join_node(label, children):
    return " ".join([_label_text(label)] + [_leaf_text(c) for c in children])
