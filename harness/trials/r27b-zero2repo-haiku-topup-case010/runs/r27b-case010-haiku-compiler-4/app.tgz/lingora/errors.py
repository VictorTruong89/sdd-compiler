"""Exception classes shared by the lingora modules."""


class LingoraError(Exception):
    """Base class for every error raised by lingora."""


class ResourceNotFound(LingoraError, LookupError):
    """A packaged resource needed by a call is not visible on ``data.path``."""


class UnsupportedInput(LingoraError, TypeError):
    """An argument has a type or value that the entry does not accept."""


class ParseError(LingoraError, ValueError):
    """A token list cannot be parsed by the grammar at all (a token that no
    production produces), as distinct from a list with no parse."""
