"""Stemmers and the WordNet lemmatizer.

# spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427
# spec: N-000428 N-000429 N-000430 N-000431 N-000432
# spec: N-000142 N-000143 N-000144 N-000145 N-000146
# spec: N-000147 N-000148 N-000149 N-000150 N-000151 N-000152 N-000153
# spec: N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160
# spec: N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167
# spec: N-000168 N-000169 N-000170 N-000171 N-000174
# spec: N-000175 N-000176 N-000177 N-000178 N-000179 N-000180 N-000181
# spec: N-000182 N-000183 N-000184 N-000185 N-000186
"""

import os
import re

from . import data
from .errors import UnsupportedInput

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


def _check_word(word):
    if not isinstance(word, str):
        raise UnsupportedInput("word must be a str, not %s" % type(word).__name__)


def _check_bool(value, name):
    if not isinstance(value, bool):
        raise UnsupportedInput("%s must be a bool" % name)


# ================================================================ Porter

_VOWELS = "aeiou"


def _is_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    """Porter measure m: the number of VC sequences in the stem."""
    m = 0
    prev_vowel = False
    for i in range(len(stem)):
        vowel = not _is_cons(stem, i)
        if prev_vowel and not vowel:
            m += 1
        prev_vowel = vowel
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _star_o(stem, extensions):
    """*o: the stem ends consonant-vowel-consonant, the last not w, x or y."""
    n = len(stem)
    if n == 2 and extensions:
        # LINGORA extension: a two-letter stem made of a vowel then a consonant.
        return (not _is_cons(stem, 0)) and _is_cons(stem, 1) and stem[1] not in "wxy"
    if n < 3:
        return False
    return (_is_cons(stem, n - 3) and not _is_cons(stem, n - 2)
            and _is_cons(stem, n - 1) and stem[-1] not in "wxy")


_STEP2_RULES = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("fulli", "ful"),
    ("entli", "ent"), ("eli", "e"), ("ousli", "ous"), ("ization", "ize"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("iveness", "ive"),
    ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"),
    ("biliti", "ble"), ("logi", "log"),
]
_STEP2_ORIGINAL = [r for r in _STEP2_RULES if r[0] not in ("fulli", "logi", "bli")]
_STEP2_ORIGINAL.insert(5, ("abli", "able"))

_STEP3_RULES = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]

_STEP4_SUFFIXES = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


class _Porter:
    """Porter's algorithm. ``extensions=True`` gives the LINGORA extensions;
    ``extensions=False`` gives the original published algorithm."""

    def __init__(self, extensions=True):
        self.ext = extensions
        self.step2_rules = _STEP2_RULES if extensions else _STEP2_ORIGINAL

    def stem(self, word):
        if len(word) <= 2:
            return word
        word = self._step1a(word)
        word = self._step1b(word)
        word = self._step1c(word)
        word = self._step2(word)
        word = self._step3(word)
        word = self._step4(word)
        word = self._step5a(word)
        word = self._step5b(word)
        return word

    def _step1a(self, word):
        if word.endswith("sses"):
            return word[:-2]
        if word.endswith("ies"):
            if self.ext and len(word) == 4:
                return word[:-1]  # LINGORA: a four-letter -ies word becomes -ie
            return word[:-2]
        if word.endswith("ss"):
            return word
        if word.endswith("s"):
            return word[:-1]
        return word

    def _step1b(self, word):
        if word.endswith("eed"):
            if _measure(word[:-3]) > 0:
                return word[:-1]
            return word
        if self.ext and word.endswith("ied"):
            # LINGORA: -ied -> -ie for four letters, -i otherwise; rest of 1b skipped.
            return word[:-1] if len(word) == 4 else word[:-2]
        flag = False
        if word.endswith("ed") and _has_vowel(word[:-2]):
            word = word[:-2]
            flag = True
        elif word.endswith("ing") and _has_vowel(word[:-3]):
            word = word[:-3]
            flag = True
        if flag:
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif _double_cons(word) and word[-1] not in "lsz":
                word = word[:-1]
            elif _measure(word) == 1 and _star_o(word, self.ext):
                word += "e"
        return word

    def _step1c(self, word):
        if word.endswith("y") and len(word) >= 2:
            if self.ext:
                # LINGORA: y -> i only after a consonant that is not the first letter.
                if len(word) >= 3 and _is_cons(word, len(word) - 2):
                    return word[:-1] + "i"
            elif _has_vowel(word[:-1]):
                return word[:-1] + "i"
        return word

    def _step2(self, word):
        for suffix, repl in self.step2_rules:
            if word.endswith(suffix):
                stem = word[:-len(suffix)]
                if _measure(stem) > 0:
                    word = stem + repl
                    if self.ext and suffix == "alli":
                        return self._step2(word)
                break
        return word

    def _step3(self, word):
        for suffix, repl in _STEP3_RULES:
            if word.endswith(suffix):
                stem = word[:-len(suffix)]
                if _measure(stem) > 0:
                    word = stem + repl
                break
        return word

    def _step4(self, word):
        for suffix in _STEP4_SUFFIXES:
            if word.endswith(suffix):
                stem = word[:-len(suffix)]
                if suffix == "ion":
                    if _measure(stem) > 1 and stem[-1:] in ("s", "t"):
                        return stem
                    return word
                if _measure(stem) > 1:
                    return stem
                return word
        return word

    def _step5a(self, word):
        if word.endswith("e"):
            stem = word[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _star_o(stem, self.ext)):
                return stem
        return word

    def _step5b(self, word):
        if _measure(word) > 1 and _double_cons(word) and word.endswith("l"):
            return word[:-1]
        return word


class PorterStemmer:
    """Porter stemmer. The default mode is the LINGORA extensions.

    ``stem(word, to_lowercase=False)``: with ``to_lowercase=True`` the word is
    lowercased first; otherwise the letter case is kept.
    """

    # spec: N-000422 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158
    # spec: N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165
    # spec: N-000166 N-000167 N-000168 N-000169 N-000149 N-000150
    def __init__(self, mode="lingora"):
        if mode not in ("lingora", "original"):
            raise UnsupportedInput("unknown Porter mode %r" % (mode,))
        self._algo = _Porter(extensions=(mode == "lingora"))

    def stem(self, word, to_lowercase=False):
        _check_word(word)
        _check_bool(to_lowercase, "to_lowercase")
        if to_lowercase:
            word = word.lower()
        return self._algo.stem(word)


# ================================================================ Porter2 (English)

_VOWEL_SET = set("aeiouy")
_LI_ENDINGS = set("cdeghkmnrt")
_EXCEPTIONS1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_EXCEPTIONS2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
                "exceed", "succeed"}


def _e_region(word, start):
    for i in range(start + 1, len(word)):
        if word[i] not in _VOWEL_SET and word[i - 1] in _VOWEL_SET:
            return i + 1
    return len(word)


def _short_syllable(word):
    if len(word) == 2:
        return word[0] in _VOWEL_SET and word[1] not in _VOWEL_SET
    if len(word) >= 3:
        return (word[-3] not in _VOWEL_SET and word[-2] in _VOWEL_SET
                and word[-1] not in _VOWEL_SET and word[-1] not in "wxY")
    return False


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _EXCEPTIONS1:
        return _EXCEPTIONS1[word]
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _VOWEL_SET:
            chars[i] = "Y"
    word = "".join(chars)

    if word[:5] == "gener" or word[:6] == "commun":
        r1 = 5 if word[:5] == "gener" else 6
    elif word[:5] == "arsen":
        r1 = 5
    elif word[:4] in ("past",):
        r1 = 4
    else:
        r1 = _e_region(word, 0)
    r2 = _e_region(word, r1)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if word.endswith(suf):
            word = word[:-len(suf)]
            break

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-1] if len(word) <= 4 else word[:-2]
    elif word.endswith("us") or word.endswith("ss"):
        pass
    elif word.endswith("s"):
        if _has_vowel_before_last(word[:-2]):
            word = word[:-1]

    if word in _EXCEPTIONS2:
        return word.replace("Y", "y")

    # Step 1b
    if word.endswith(("eedly", "eed")):
        suf = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suf) >= r1:
            word = word[: -len(suf)] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if word.endswith(suf):
                stem = word[:-len(suf)]
                if _has_vowel_any(stem):
                    word = stem
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif _double_cons(word) and word[-1] not in "lsz":
                        word = word[:-1]
                    elif _short_word(word, r1):
                        word += "e"
                break

    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _VOWEL_SET:
        word = word[:-1] + "i"

    # Step 2 (R1)
    step2 = [
        ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
        ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
        ("fulli", "ful"), ("ogi", "og"), ("li", ""),
    ]
    for suf, repl in step2:
        if word.endswith(suf):
            if len(word) - len(suf) >= r1:
                if suf == "ogi":
                    if word[-4:-3] == "l":
                        word = word[:-3] + repl
                elif suf == "li":
                    if len(word) >= 3 and word[-3] in _LI_ENDINGS:
                        word = word[:-2]
                else:
                    word = word[: -len(suf)] + repl
            break

    # Step 3 (R1 / R2)
    step3 = [
        ("tional", "tion", r1), ("ational", "ate", r1), ("alize", "al", r1),
        ("icate", "ic", r1), ("iciti", "ic", r1), ("ical", "ic", r1),
        ("ful", "", r1), ("ness", "", r1), ("ative", "", r2),
    ]
    for suf, repl, region in step3:
        if word.endswith(suf):
            if len(word) - len(suf) >= region:
                word = word[: -len(suf)] + repl
            break

    # Step 4 (R2)
    step4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
             "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    for suf in step4:
        if word.endswith(suf):
            if len(word) - len(suf) >= r2:
                if suf == "ion":
                    if word[-4:-3] in ("s", "t"):
                        word = word[:-3]
                else:
                    word = word[: -len(suf)]
            break

    # Step 5
    if word.endswith("e"):
        if len(word) - 1 >= r2 or (len(word) - 1 >= r1 and not _short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if len(word) - 1 >= r2 and word[-2:-1] == "l":
            word = word[:-1]

    return word.replace("Y", "y")


def _has_vowel_before_last(stem):
    return any(c in _VOWEL_SET for c in stem)


def _has_vowel_any(stem):
    return any(c in _VOWEL_SET for c in stem)


def _short_word(word, r1):
    # Porter2 short word: R1 is empty and the word ends in a short syllable.
    return _short_syllable(word) and r1 >= len(word)


# ================================================================ Snowball

class SnowballStemmer:
    """Snowball stemmer for ``language``.

    ``english`` implements the Porter2 (English) algorithm and ``porter``
    implements the original Porter algorithm. Other supported names are
    accepted by the constructor (with stopword checking), but their stemming
    algorithms are not implemented in this library.
    """

    # spec: N-000428 N-000429 N-000430 N-000431 N-000174
    # spec: N-000175 N-000176 N-000177 N-000183 N-000184 N-000181 N-000182
    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise UnsupportedInput(
                "unsupported Snowball language %r; supported: %s"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        _check_bool(ignore_stopwords, "ignore_stopwords")
        self.language = language
        self.ignore_stopwords = ignore_stopwords
        self._stopwords = frozenset()
        if ignore_stopwords:
            path = data.find(data.STOPWORDS.format(language=language), kind="file")
            with open(path, encoding="utf-8") as handle:
                self._stopwords = frozenset(
                    line.strip().lower() for line in handle if line.strip()
                )

    def stem(self, word):
        _check_word(word)
        if self.ignore_stopwords:
            lowered = word.lower()
            if lowered in self._stopwords:
                return lowered
        if self.language == "english":
            return _porter2(word.lower())
        if self.language == "porter":
            return _Porter(extensions=False).stem(word.lower())
        raise NotImplementedError(
            "Snowball stemming for %r is not implemented in this library" % self.language
        )


# ================================================================ Lancaster

_LANCASTER_RULES = """
ai*2. a*1. bb1. city3s. ci2> cn1t> dd1. dei3y> deec2ss. dee1. de2> dooh4>
e1> feil1v. fi2> gni3> gai3y. ga2> gg1. ht*2. hsiug5ct. hsi3> i*1. i1y>
ji1d. juf1s. ju1d. jo1d. jeh1r. jrev1t. jsim2t. jn1d. j1s. lbaifi6. lbai4y.
lba3y. lbi3. lib2l> lc1. lufi4y. luf3y. lo2l> lu2. lai3y> lau3> la2> ll1.
mui3. mu*2. msi3> mm1. nois4j> noix4ct. noi3> nai3y. na2> nee0. ne2> nn1.
pihs4> pp1. re2> rae0. ra2. ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2>
ssen4> ss0. suo3> su*2. s*1> s0. tacilp4y. ta2> tnem4> tne3> tna3> tpir2b.
tpro2b. tcud1. tpmus2. tpec2iv. tulo2v. tsis0. tsi3> tt1. uqi3. ugo1.
vis3j> vie0. vi2> ylb1> yli3y> ylp0. yl2> ygo1. yhp1. ymo1. ypo2. yti3>
yte3> ytl2. yrtsi5. yra3> yro3> yfi3. ygo1. zi2> zy1s.
"""

# The rule strings below are the Paice/Husk table as published (reversed
# suffix, count of letters to remove, letters to append, then '.' to stop or
# '>' to continue; '*' means the rule applies only while the word is intact).
_LANCASTER_PARSED = []
for _rule in _LANCASTER_RULES.split():
    _m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", _rule)
    if _m:
        _LANCASTER_PARSED.append((_m.group(1), bool(_m.group(2)), int(_m.group(3)),
                                  _m.group(4), _m.group(5) == ">"))


class LancasterStemmer:
    """Paice/Husk (Lancaster) stemmer."""

    # spec: N-000170 N-000171
    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        while True:
            applied = False
            for pattern, needs_intact, remove, append, cont in _LANCASTER_PARSED:
                if needs_intact and not intact:
                    continue
                if not word.endswith(pattern[::-1]):
                    continue
                if not _lancaster_ok(word, remove):
                    continue
                word = word[:-remove] + append if remove else word + append
                intact = False
                applied = True
                if not cont:
                    return word
                break
            if not applied:
                return word


def _lancaster_ok(word, remove):
    rest = word[:-remove] if remove else word
    if not rest:
        return False
    if rest[0] in "aeiouy":
        return len(rest) >= 2
    return len(rest) >= 3 and any(c in "aeiouy" for c in rest)


# ================================================================ Regexp

class RegexpStemmer:
    """Removes every match of ``regexp`` from the word."""

    # spec: N-000178 N-000179 N-000180
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise UnsupportedInput("regexp must be a str")
        self._re = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._re.sub("", word)


# ================================================================ Arabic light stemmers

_ARABIC_PREFIXES = ("وال", "بال", "كال", "فال", "ال", "لل", "و")
_ARABIC_SUFFIXES = ("ها", "ان", "ات", "ون", "ين", "يه", "ية", "ه", "ة", "ي")


class ARLSTem:
    """Light Arabic stemmer. Its results are outside this specification."""

    def stem(self, word):
        _check_word(word)
        for prefix in _ARABIC_PREFIXES:
            if word.startswith(prefix) and len(word) - len(prefix) >= 3:
                word = word[len(prefix):]
                break
        for suffix in _ARABIC_SUFFIXES:
            if word.endswith(suffix) and len(word) - len(suffix) >= 3:
                word = word[: -len(suffix)]
                break
        return word


class ARLSTem2(ARLSTem):
    """Second light Arabic stemmer. Its results are outside this specification."""


# ================================================================ WordNet

class WordNetLemmatizer:
    """Lemmatizer backed by the packaged WordNet resource (N-000142).

    Raises :class:`ResourceNotFound` at construction when WordNet is not
    visible on ``data.path``.
    """

    # spec: N-000432 N-000185 N-000186
    def __init__(self):
        self._dir = data.find(data.WORDNET)
        self._lemmas = {}
        for pos in ("noun", "verb", "adj", "adv"):
            self._lemmas[pos] = self._read_index(pos)

    def _read_index(self, pos):
        lemmas = set()
        filename = os.path.join(self._dir, "index." + pos)
        if not os.path.isfile(filename):
            return lemmas
        with open(filename, encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if not line or line.startswith(" "):
                    continue
                lemmas.add(line.split(" ", 1)[0])
        return lemmas

    _RULES = {
        "noun": [("s", ""), ("ses", "s"), ("xes", "x"), ("zes", "z"),
                 ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "verb": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"),
                 ("ed", ""), ("ing", "e"), ("ing", "")],
        "adj": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    }

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        key = {"n": "noun", "v": "verb", "a": "adj", "s": "adj", "r": "adv"}.get(pos, pos)
        if key not in self._lemmas:
            raise UnsupportedInput("unknown part of speech %r" % (pos,))
        lemmas = self._lemmas[key]
        if word in lemmas:
            return word
        for suffix, repl in self._RULES.get(key, []):
            if word.endswith(suffix):
                candidate = word[: -len(suffix)] + repl
                if candidate in lemmas:
                    return candidate
        return word
