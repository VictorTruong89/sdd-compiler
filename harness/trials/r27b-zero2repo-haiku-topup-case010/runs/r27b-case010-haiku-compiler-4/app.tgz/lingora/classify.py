"""Text classifiers: Naive Bayes and decision tree.

# spec: N-000492 N-000493 N-000494 N-000495 N-000496 N-000497
# spec: N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301
# spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308
# spec: N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315
# spec: N-000316 N-000317 N-000044 N-000045
"""

import math
from collections import Counter, defaultdict

from .errors import UnsupportedInput


def _check_featuresets(labeled):
    if isinstance(labeled, (str, bytes)) or not isinstance(labeled, (list, tuple)):
        raise UnsupportedInput("labeled_featuresets must be a list of (featureset, label) pairs")
    out = []
    for pair in labeled:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise UnsupportedInput("each item must be a (featureset, label) pair")
        featureset, label = pair
        if not isinstance(featureset, dict):
            raise UnsupportedInput("a featureset must be a dict")
        out.append((dict(featureset), label))
    return out


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes over featuresets, with smoothed per-feature estimates."""

    # spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
    def __init__(self):
        self._labels = []
        self._label_count = Counter()
        self._total = 0
        self._feature_values = defaultdict(set)     # feature -> seen values
        self._counts = defaultdict(Counter)          # (feature, value) -> label counts
        self._feature_label_total = defaultdict(Counter)  # feature -> label -> count

    @classmethod
    def train(cls, labeled_featuresets):
        clf = cls()
        for featureset, label in _check_featuresets(labeled_featuresets):
            if label not in clf._label_count:
                clf._labels.append(label)
            clf._label_count[label] += 1
            clf._total += 1
            for name, value in featureset.items():
                clf._feature_values[name].add(value)
                clf._counts[(name, value)][label] += 1
                clf._feature_label_total[name][label] += 1
        return clf

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            logp = math.log(self._label_count[label] / self._total)
            for name, value in featureset.items():
                if name not in self._feature_values:
                    continue  # a feature never seen in training is ignored
                # Expected-likelihood smoothing: no value gets probability zero.
                k = len(self._feature_values[name]) + 1
                count = self._counts[(name, value)][label] if (name, value) in self._counts else 0
                denom = self._label_count[label] + 0.5 * k
                logp += math.log((count + 0.5) / denom)
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise UnsupportedInput("featureset must be a dict")
        scores = self._log_scores(featureset)
        if not scores:
            return ProbDist({})
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: v / total for label, v in exps.items()})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise UnsupportedInput("featureset must be a dict")
        scores = self._log_scores(featureset)
        if not scores:
            raise ValueError("the classifier has not been trained")
        # Highest posterior; ties go to the label seen first in training.
        best = self._labels[0]
        for label in self._labels:
            if scores[label] > scores[best]:
                best = label
        return best


class _Node:
    __slots__ = ("feature", "majority", "children")

    def __init__(self, feature, majority, children):
        self.feature = feature
        self.majority = majority
        self.children = children


def _entropy(labels):
    total = len(labels)
    if total == 0:
        return 0.0
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


class DecisionTreeClassifier:
    """Decision tree that splits on the feature with the largest information
    gain. A feature absent from a featureset counts as having no value."""

    # spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
    def __init__(self, root, labels):
        self._root = root
        self._labels = labels

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_featuresets(labeled_featuresets)
        labels_order = []
        for _, label in data:
            if label not in labels_order:
                labels_order.append(label)
        features = []
        for fs, _ in data:
            for name in fs:
                if name not in features:
                    features.append(name)
        root = cls._build(data, features)
        return cls(root, labels_order)

    @staticmethod
    def _majority(labels):
        counts = Counter(labels)
        best = None
        for label in labels:  # first-seen wins ties
            if best is None or counts[label] > counts[best]:
                best = label
        return best

    @classmethod
    def _build(cls, data, features):
        labels = [label for _, label in data]
        majority = cls._majority(labels)
        if len(set(labels)) <= 1 or not features:
            return _Node(None, majority, {})
        base = _entropy(labels)
        best_feature = None
        best_gain = 0.0
        for name in features:
            groups = defaultdict(list)
            for fs, label in data:
                groups[fs.get(name)].append(label)
            if len(groups) < 2:
                continue
            remainder = sum(len(g) / len(labels) * _entropy(g) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_gain = gain
                best_feature = name
        if best_feature is None:
            return _Node(None, majority, {})
        partitions = defaultdict(list)
        for fs, label in data:
            partitions[fs.get(best_feature)].append((fs, label))
        rest = [f for f in features if f != best_feature]
        children = {value: cls._build(part, rest) for value, part in partitions.items()}
        return _Node(best_feature, majority, children)

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise UnsupportedInput("featureset must be a dict")
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.majority
            node = child
        return node.majority


def accuracy(classifier, gold):
    """Fraction of gold examples whose featureset the classifier labels correctly."""
    # spec: N-000309 — exact label match, position by position.
    pairs = _check_featuresets(gold)
    if not pairs:
        return 0.0
    correct = sum(1 for fs, label in pairs if classifier.classify(fs) == label)
    return correct / len(pairs)
