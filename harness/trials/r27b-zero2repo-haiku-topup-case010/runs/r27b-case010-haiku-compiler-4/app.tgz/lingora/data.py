"""Packaged resources: the directory list the data finder searches.

# spec: N-000385 N-000386 N-000387 N-000388 N-000389 N-000390 N-000391
# spec: N-000392 N-000393 N-000394 N-000395 N-000396 N-000397 N-000398
# spec: N-000399 N-000400 N-000401 N-000402
"""

import os

from .errors import ResourceNotFound

# spec: N-000385 — ``data.path`` is a mutable list of directory strings.
# Its initial contents are the implementer's choice: the entries of the
# LINGORA_DATA environment variable (os.pathsep separated), then a
# per-user directory and a system-wide directory.
_ENV_VAR = "LINGORA_DATA"


def _initial_path():
    entries = []
    env = os.environ.get(_ENV_VAR, "")
    for item in env.split(os.pathsep):
        if item:
            entries.append(item)
    entries.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    entries.append(os.path.join(os.sep, "usr", "share", "lingora"))
    return entries


path = _initial_path()

# Resource names, relative to a directory on ``path`` (spec table, pack 06).
PUNKT = "tokenizers/punkt_tab/{language}"
AVERAGED_PERCEPTRON = "taggers/averaged_perceptron_tagger_{lang}"
UNIVERSAL_TAGSET = "taggers/universal_tagset"
NE_CHUNKER = "chunkers/maxent_ne_chunker_tab/english_ace_multiclass"
ENGLISH_WORDS = "corpora/words"
STOPWORDS = "corpora/stopwords/{language}"
WORDNET = "corpora/wordnet"


def find(resource, kind="dir"):
    """Return the absolute path of ``resource`` in the first ``data.path``
    directory that holds it, or raise :class:`ResourceNotFound`.

    ``kind`` is ``"dir"`` (a model directory) or ``"file"``.
    """
    for base in list(path):
        if not base:
            continue
        candidate = os.path.join(base, *resource.split("/"))
        if kind == "dir" and os.path.isdir(candidate):
            return candidate
        if kind == "file" and os.path.isfile(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r is not visible in data.path %r" % (resource, list(path))
    )


def is_visible(resource, kind="dir"):
    """True when :func:`find` would succeed for ``resource``."""
    try:
        find(resource, kind)
    except ResourceNotFound:
        return False
    return True
