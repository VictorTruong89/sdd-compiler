"""Evaluation metrics: edit distance, Jaccard, accuracy, precision, recall, f-measure.

# spec: N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504
# spec: N-000505 N-000506 N-000507 N-000508 N-000509 N-000510
# spec: N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325
# spec: N-000326 N-000327 N-000328 N-000329 N-000330 N-000331 N-000332
# spec: N-000333 N-000334 N-000343 N-000344 N-000345 N-000346 N-000347
# spec: N-000348
"""

from .errors import UnsupportedInput


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _check_list(value, name):
    if not isinstance(value, (list, tuple)):
        raise UnsupportedInput("%s must be a list" % name)


def _check_set(value, name):
    # spec: N-000345 N-000509 — lists, tuples and other non-set collections are refused.
    if not isinstance(value, (set, frozenset)):
        raise UnsupportedInput("%s must be a set or frozenset" % name)


def accuracy(reference, test):
    """Fraction of positions at which the two lists hold equal values.

    Lists of different lengths raise (the interface contract's statement is
    followed where the PRD and the interface disagree; see NOTES.md).
    """
    _check_list(reference, "reference")
    _check_list(test, "test")
    if len(reference) != len(test):
        raise UnsupportedInput("accuracy needs lists of equal length")
    if not reference:
        return 0.0
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Edit distance between two strings.

    Insertion and deletion cost 1; substitution costs ``substitution_cost``.
    With ``transpositions=True`` two adjacent characters may be transposed
    for cost 1 (optimal string alignment: nothing is inserted or deleted
    between the transposed characters).
    """
    # spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000328 N-000329
    # spec: N-000503 N-000504 N-000505 N-000506 N-000348
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise UnsupportedInput("edit_distance needs two str arguments")
    if not _is_number(substitution_cost):
        raise UnsupportedInput("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise UnsupportedInput("transpositions must be a bool")
    m, n = len(s1), len(s2)
    d = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        d[i][0] = i
    for j in range(n + 1):
        d[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                cost = 0
            else:
                cost = substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if (transpositions and i > 1 and j > 1
                    and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]):
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[m][n]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over the size of the union."""
    # spec: N-000507
    _check_set(label1, "label1")
    _check_set(label2, "label2")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def precision(reference, test):
    """|reference & test| / |test|; None when the test set is empty."""
    # spec: N-000332 N-000344 N-000347
    _check_set(reference, "reference")
    _check_set(test, "test")
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; None when the reference set is empty."""
    # spec: N-000332 N-000344 N-000347
    _check_set(reference, "reference")
    _check_set(test, "test")
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1-alpha)/recall).

    None when either set is empty or when the two sets share no element.
    """
    # spec: N-000333 N-000334 N-000346
    _check_set(reference, "reference")
    _check_set(test, "test")
    if not _is_number(alpha) or not 0 <= alpha <= 1:
        raise UnsupportedInput("alpha must be a number between 0 and 1")
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
