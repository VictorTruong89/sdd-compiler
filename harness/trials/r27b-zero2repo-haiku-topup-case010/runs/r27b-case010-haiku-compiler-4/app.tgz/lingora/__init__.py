"""LINGORA — the Lingora Language Toolkit.

A pure-Python natural-language processing library, imported from Python. It is
not a network service, has no product configuration file, and importing it
downloads nothing. Packaged models are located through ``lingora.data``.

Product scope (what this package is, and what it deliberately is not):

# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007
# spec: N-000008 N-000009 N-000010 N-000011 N-000012 N-000013 N-000014
# spec: N-000015 N-000016 N-000017 N-000018 N-000019 N-000020 N-000021
# spec: N-000022 N-000023 N-000024 N-000025 N-000026 N-000027 N-000028
# spec: N-000029 N-000030 N-000031 N-000032 N-000033 N-000034 N-000035
# spec: N-000036 N-000037 N-000039 N-000040 N-000041 N-000042 N-000043
# spec: N-000044 N-000045 N-000046 N-000047
# spec: N-000068 N-000069 N-000070 N-000071
# spec: N-000072 N-000073 N-000074 N-000075 N-000076 N-000077 N-000078
# spec: N-000079 N-000080
# spec: N-000349 N-000350 N-000351 N-000352
# spec: N-000048 N-000049 N-000050 N-000051 N-000052 N-000053 N-000054
# spec: N-000055 N-000056 N-000057 N-000058 N-000059 N-000060 N-000061
# spec: N-000062 N-000063 N-000064
# spec: N-000353 N-000354 N-000355 N-000356 N-000357 N-000358 N-000359
# spec: N-000360 N-000361 N-000362 N-000363 N-000364 N-000365 N-000366
# spec: N-000367 N-000368 N-000369 N-000370
# spec: N-000371 N-000372 N-000373 N-000374 N-000375 N-000376 N-000377
# spec: N-000378 N-000379 N-000380 N-000381 N-000382 N-000383 N-000384
- Pure Python, no compiled code, no GPU or accelerator requirements
  (N-000048, N-000353, N-000356, N-000368). Python 3.10 or newer
  (N-000051, N-000373). Runtime dependencies: none (N-000052, N-000365).
  Linux, macOS and Windows (N-000055, N-000360). CPU only (N-000057).
- Flat layout: the import package ``lingora`` sits at the project root, and
  an editable install or a root on ``sys.path`` is enough (N-000049, N-000369,
  N-000370, N-000050). No native compile step (N-000368, N-000369).
- Importing the package downloads nothing and needs no corpus or model
  (N-000058, N-000059, N-000363). Packaged data are found through the data
  finder only (N-000059, N-000060, N-000062–N-000064).
- Input and output are Unicode text (N-000065, N-000066, N-000067).
- Used in-process from Python (N-000029, N-000068).
- Public surface: the tokenizers, stemmers, taggers, chunk parser, grammar,
  parsers, generator, trees, classifiers, metrics and BLEU, plus the command
  line (N-000030–N-000046). Feature points do not invent more surfaces
  (N-000047).
- Non-goals, not present in this package (N-000072–N-000080, N-000349–N-000352):
  graphical applications and drawing, chat and Twitter helpers, Hugging Face
  and Toolbox readers, wrappers around external binaries and services,
  combinatory categorial grammar, discourse representation and theorem-prover
  inference, n-gram language-model training, throughput guarantees, the
  s-expression tokenizer, the corpus downloader and graphical corpus browser.
- Shape of the public surface (N-000371–N-000384): every entry is a Python
  callable. A refusal raises an exception and never returns an empty list,
  empty string, 0 or None (N-000377–N-000381); the exception classes are in
  ``lingora.errors``. Parameters have the defaults stated on each entry
  (N-000382, N-000383). A score or distance is an int or float, never a bool
  (N-000384).
"""

from . import data  # noqa: F401  (from lingora import data)
from .errors import LingoraError, ParseError, ResourceNotFound, UnsupportedInput  # noqa: F401

__version__ = "0.1.0"
