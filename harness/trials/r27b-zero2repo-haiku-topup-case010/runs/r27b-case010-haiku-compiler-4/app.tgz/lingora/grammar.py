"""Context-free grammars read from text.

# spec: N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467
# spec: N-000468 N-000469 N-000470 N-000471 N-000472
# spec: N-000264 N-000265 N-000266
# spec: N-000040 N-000041 N-000042 N-000043
"""

import re

from .errors import UnsupportedInput


class Nonterminal:
    """A nonterminal symbol. ``str()`` is its name; it is not a ``str``."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    """``lhs -> rhs``. ``rhs()`` is a tuple of :class:`Nonterminal` objects
    and terminal ``str`` values (quotes removed)."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and other._lhs == self._lhs
                and other._rhs == self._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs))


_TOKEN_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([^\s"'|]+))""")


def _parse_rhs(text, lhs_name):
    """Parse the text after '->' into alternatives (lists of symbols)."""
    alternatives = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN_RE.match(text, pos)
        if not m or m.end() == pos:
            if text[pos:].strip() == "":
                break
            raise ValueError("bad production text near %r in %s" % (text[pos:], lhs_name))
        pos = m.end()
        if m.group(3):
            alternatives.append([])
        elif m.group(1) is not None:
            alternatives[-1].append(m.group(1))
        elif m.group(2) is not None:
            alternatives[-1].append(m.group(2))
        else:
            alternatives[-1].append(Nonterminal(m.group(4)))
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the
    first production."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise UnsupportedInput("grammar text must be a str")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production must be '<LHS> -> <RHS>': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_name = lhs_text.strip()
            if not lhs_name or re.search(r"\s", lhs_name):
                raise ValueError("bad left-hand side in %r" % line)
            lhs = Nonterminal(lhs_name)
            if start is None:
                start = lhs
            for alt in _parse_rhs(rhs_text, lhs_name):
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self):
        return list(self._productions)

    def nonterminals(self):
        return {p.lhs() for p in self._productions}

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    out.add(s)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
