"""Shared fixtures: a small fake packaged-resource tree.

The real packaged models are not part of this repository. These fixtures write
tiny, hand-made resources in the published layout so that the model-dependent
paths can be exercised. Tests that need "no model visible" clear data.path.
"""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture
def resources(tmp_path, monkeypatch):
    base = str(tmp_path / "data")
    punkt = os.path.join(base, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "dr\nmr\nst\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\nin\n")
    _write(os.path.join(punkt, "collocations.tab"), "Mr\tSmith\n")
    _write(os.path.join(punkt, "ortho_context.tab"), "the\t32\nit\t16\nsmith\t68\n")

    stop = os.path.join(base, "corpora", "stopwords")
    _write(os.path.join(stop, "english"), "the\nand\nof\n")
    _write(os.path.join(stop, "german"), "und\nder\n")

    tagger = os.path.join(base, "taggers", "averaged_perceptron_tagger_eng")
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.weights.json"),
           json.dumps({"bias": {"NN": 1.0}, "i word the": {"DT": 5.0}}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.tagdict.json"),
           json.dumps({"ran": "VBD"}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.classes.json"),
           json.dumps(["DT", "NN", "VBD"]))

    _write(os.path.join(base, "taggers", "universal_tagset", "en-ptb.map"),
           "DT\tDET\nNN\tNOUN\nVBD\tVERB\n")

    monkeypatch.setattr(data, "path", [base])
    return base


@pytest.fixture
def no_resources(monkeypatch, tmp_path):
    monkeypatch.setattr(data, "path", [str(tmp_path / "empty")])
    return str(tmp_path / "empty")
