"""Grammars, parsers, generation, trees, classifiers, metrics, BLEU, CLI.

# spec: N-000264 N-000266 N-000267 N-000272 N-000276 N-000280 N-000281
# spec: N-000285 N-000286 N-000288 N-000289 N-000292 N-000294 N-000302
# spec: N-000306 N-000307 N-000310 N-000315 N-000318 N-000322 N-000325
# spec: N-000326 N-000328 N-000333 N-000335 N-000343 N-000344 N-000346
# spec: N-000348 N-000414 N-000417 N-000480 N-000486 N-000489 N-000496
# spec: N-000501 N-000502 N-000505 N-000506 N-000513 N-000516
"""

import io
import sys

import pytest

from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.cli import cli
from lingora.errors import ParseError, UnsupportedInput
from lingora.grammar import CFG
from lingora.metrics import (
    accuracy as list_accuracy,
    edit_distance,
    f_measure,
    jaccard_distance,
    precision,
    recall,
)
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import bleu
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> 'the' N | N
VP -> V NP | V
N -> 'dog' | 'cat'
V -> 'saw' | 'ran'
"""


def test_N_000264_alternatives_are_productions():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions()) == 9


def test_N_000266_chart_parser_all_parses():
    g = CFG.fromstring("S -> S S | 'a'")
    assert len(list(ChartParser(g).parse(["a", "a", "a"]))) == 2


def test_N_000266_chart_parser_tree_shape():
    g = CFG.fromstring(GRAMMAR)
    (tree,) = list(ChartParser(g).parse("the dog saw the cat".split()))
    assert tree.label() == "S"
    assert tree.leaves() == "the dog saw the cat".split()


def test_N_000267_uncovered_list_gives_no_parse():
    g = CFG.fromstring(GRAMMAR)
    assert list(ChartParser(g).parse(["dog", "ran", "ran"])) == []


def test_N_000292_unknown_token_raises():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ParseError):
        list(ChartParser(g).parse(["bird"]))


def test_N_000272_shift_reduce_same_as_chart_on_unambiguous():
    g = CFG.fromstring("S -> 'a' S 'b' | 'x'")
    toks = ["a", "a", "x", "b", "b"]
    sr = list(ShiftReduceParser(g).parse(toks))
    ch = list(ChartParser(g).parse(toks))
    assert sr == ch and len(sr) == 1


def test_N_000276_generator_sentences():
    g = CFG.fromstring("S -> 'a' S | 'b'")
    out = list(generate(g, depth=3))
    assert ["b"] in out and ["a", "b"] in out
    assert all(isinstance(t, str) for s in out for t in s)


def test_N_000480_empty_terminal_adds_no_token():
    g = CFG.fromstring("S -> 'x' '' | 'y'")
    assert ["x"] in list(generate(g))


def test_N_000285_tree_equality_and_bracketed_text():
    t = Tree.fromstring("(S (NP the dog) (VP ran))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["ran"])])
    assert len(t) == 2 and t[0].label() == "NP"


def test_N_000486_tree_child_list_rules():
    with pytest.raises(UnsupportedInput):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")
    assert Tree("S", []).leaves() == []


def test_N_000287_pformat_has_every_leaf():
    text = Tree.fromstring("(S (NP the dog) (VP ran))").pformat()
    for word in ("S", "NP", "the", "dog", "VP", "ran"):
        assert word in text


def test_N_000302_naive_bayes_and_posterior():
    train = [({"w": "good"}, "pos"), ({"w": "great"}, "pos"),
             ({"w": "bad"}, "neg"), ({"w": "awful"}, "neg")]
    nb = NaiveBayesClassifier.train(train)
    assert nb.classify({"w": "good"}) == "pos"
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(l) for l in nb.labels()) - 1.0) < 1e-9
    assert nb.classify({"never": 1}) in ("pos", "neg")


def test_N_000310_decision_tree_separates_training():
    train = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg")]
    dt = DecisionTreeClassifier.train(train)
    assert accuracy(dt, train) == 1.0
    assert dt.classify({"other": 1}) in ("pos", "neg")


def test_N_000496_accuracy_helper():
    train = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg")]
    assert accuracy(NaiveBayesClassifier.train(train), train) == 1.0


def test_N_000322_edit_distance_values():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("", "") == 0
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("a", "b", substitution_cost=2) == 2


def test_N_000505_transposition_is_adjacent_only():
    assert edit_distance("ca", "abc", transpositions=True) == 3


def test_N_000333_precision_recall_f():
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, {2, 3}) == 0.5


def test_N_000344_empty_sets_give_no_number():
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None


def test_N_000345_non_set_refused():
    with pytest.raises(UnsupportedInput):
        precision([1], {1})


def test_N_000326_jaccard():
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


def test_N_000501_accuracy_lists():
    assert list_accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)


def test_N_000502_accuracy_unequal_lengths_refused():
    with pytest.raises(UnsupportedInput):
        list_accuracy([1, 2], [1])


def test_N_000513_bleu_identical_is_one():
    ref = ["the", "cat", "sat", "on", "the", "mat"]
    assert bleu([ref], list(ref)) == pytest.approx(1.0)


def test_N_000335_bleu_no_unigram_match_is_zero():
    assert bleu([["a", "b"]], ["x", "y"]) == 0.0


def test_N_000516_bleu_unsmoothed_zero_for_missing_order():
    ref = ["the", "cat", "is", "on", "the", "mat"]
    hyp = ["the", "cat", "sat", "on", "the", "mat"]
    assert bleu([ref], hyp, weights=[0.25] * 4) == 0.0


def test_N_000414_cli_tokenize_lines(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello there.\nSecond line.\n"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    assert code == 0
    assert capsys.readouterr().out == "Hello there .\nSecond line .\n"
