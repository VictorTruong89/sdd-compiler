"""Taggers, chunk parser, packaged-data paths.

# spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204
# spec: N-000205 N-000206 N-000207 N-000208 N-000213 N-000214 N-000215
# spec: N-000219 N-000220 N-000222 N-000223 N-000224 N-000225 N-000226
# spec: N-000227 N-000236 N-000240 N-000243 N-000245 N-000246 N-000249
# spec: N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256
# spec: N-000257 N-000452
"""

import pytest

from lingora.chunk import RegexpParser, ne_chunk
from lingora.errors import ResourceNotFound, UnsupportedInput
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree

TAGGED = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("ran", "VBD"),
          ("home", "NN"), (".", ".")]


def test_N_000198_default_tagger():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]


def test_N_000199_unigram_most_frequent_tag():
    t = UnigramTagger([[("a", "X"), ("b", "Y")], [("a", "X")]])
    assert t.tag(["a", "b", "c"]) == [("a", "X"), ("b", "Y"), ("c", None)]


def test_N_000205_backoff_only_for_untagged():
    t = UnigramTagger([[("a", "X")]], backoff=DefaultTagger("Z"))
    assert t.tag(["a", "q"]) == [("a", "X"), ("q", "Z")]


def test_N_000202_regexp_first_rule_wins():
    t = RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD")])
    assert t.tag(["running", "12", "x", "1ing"]) == [
        ("running", "VBG"), ("12", "CD"), ("x", None), ("1ing", "VBG")]


def test_N_000196_empty_tagging_is_empty():
    assert UnigramTagger([]).tag([]) == []


def test_N_000442_pos_tag_refuses_string(resources):
    with pytest.raises(UnsupportedInput):
        pos_tag("the dog")


def test_N_000443_pos_tag_unknown_language(resources):
    with pytest.raises(UnsupportedInput):
        pos_tag(["the"], lang="fra")


def test_N_000224_pos_tag_needs_model(no_resources):
    with pytest.raises(ResourceNotFound):
        pos_tag(["the"], lang="eng")


def test_N_000212_pos_tag_perceptron(resources):
    assert pos_tag(["the", "dog", "ran"]) == [
        ("the", "DT"), ("dog", "NN"), ("ran", "VBD")]


def test_N_000215_universal_mapping(resources):
    assert pos_tag(["the", "ran"], tagset="universal") == [
        ("the", "DET"), ("ran", "VERB")]


def test_N_000226_universal_needs_tables(no_resources, resources):
    import os
    import shutil

    from lingora import data

    tables = os.path.join(resources, "taggers", "universal_tagset")
    shutil.rmtree(tables)
    with pytest.raises(ResourceNotFound):
        pos_tag(["the"], tagset="universal")
    assert data.path == [resources]


def test_N_000236_chunk_rule_and_root_label():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert tree.label() == "S"
    labels = [c.label() for c in tree if isinstance(c, Tree)]
    assert labels == ["NP", "NP"]


def test_N_000245_chink_splits_chunk():
    tree = RegexpParser("NP: {<DT|JJ|NN>+}\n  }<JJ>{").parse(TAGGED[:3])
    assert tree[0] == Tree("NP", [("the", "DT")])
    assert tree[1] == ("little", "JJ")
    assert tree[2] == Tree("NP", [("dog", "NN")])


def test_N_000249_chunk_cannot_chink_earlier_clause():
    grammar = "NP: {<DT><JJ>*<NN>}\nVP: }<NP>{"
    tree = RegexpParser(grammar).parse(TAGGED[:3])
    assert tree == Tree("S", [Tree("NP", TAGGED[:3])])


def test_N_000250_leaves_are_input_tokens():
    tree = RegexpParser("NP: {<NN>}").parse(TAGGED)
    assert tree.leaves() == TAGGED


def test_N_000252_empty_input_gives_empty_sentence():
    assert RegexpParser("NP: {<NN>}").parse([]) == Tree("S", [])


def test_N_000253_bad_grammar_refused():
    with pytest.raises(UnsupportedInput):
        RegexpParser(42)


def test_N_000257_ne_chunk_needs_resources(no_resources):
    with pytest.raises(ResourceNotFound):
        ne_chunk(TAGGED)
