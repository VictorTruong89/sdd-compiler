"""Tokenizers and sentence splitting.

# spec: N-000089 N-000090 N-000091 N-000092 N-000104 N-000113 N-000114
# spec: N-000116 N-000119 N-000120 N-000121 N-000123 N-000124 N-000126
# spec: N-000129 N-000136 N-000137 N-000138 N-000139 N-000413
"""

import pytest

from lingora.errors import ResourceNotFound
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


def test_N_000089_wordpunct_runs(resources):
    assert wordpunct_tokenize("Hello, world!") == ["Hello", ",", "world", "!"]


def test_N_000126_wordpunct_spans(resources):
    text = "ab, cd"
    spans = WordPunctTokenizer().span_tokenize(text)
    assert [text[s:e] for s, e in spans] == ["ab", ",", "cd"]


def test_N_000092_treebank_clitics_and_quotes(resources):
    toks = TreebankWordTokenizer().tokenize('He said "hi" and can\'t go.')
    assert toks[:3] == ["He", "said", "``"]
    assert "n't" in toks and "ca" in toks


def test_N_000102_treebank_fused_forms_split(resources):
    assert TreebankWordTokenizer().tokenize("gonna") == ["gon", "na"]


def test_N_000110_recommended_keeps_cannot(resources):
    assert word_tokenize("I cannot go.", preserve_line=True) == [
        "I", "cannot", "go", "."]


def test_N_000113_whitespace(resources):
    assert WhitespaceTokenizer().tokenize(" a\tb\n c ") == ["a", "b", "c"]


def test_N_000114_blankline_segments(resources):
    assert blankline_tokenize("a\nb\n\n\n c\n\n") == ["a\nb", "c"]


def test_N_000116_regexp_token_mode(resources):
    assert RegexpTokenizer(r"\w+").tokenize("x y, z") == ["x", "y", "z"]


def test_N_000117_regexp_gap_mode(resources):
    assert RegexpTokenizer(r",\s*", gaps=True).tokenize("a, b,c") == ["a", "b", "c"]


def test_N_000119_tweet_contraction_and_emoticon(resources):
    toks = TweetTokenizer(preserve_case=True).tokenize("Don't stop :) #fun")
    assert toks == ["Don't", "stop", ":)", "#fun"]


def test_N_000123_tweet_strip_handles(resources):
    toks = TweetTokenizer(strip_handles=True).tokenize("@bob hi")
    assert toks == ["hi"]


def test_N_000124_tweet_reduce_len(resources):
    assert TweetTokenizer(reduce_len=True).tokenize("nooooo") == ["nooo"]


def test_N_000125_tweet_lowercase_when_preserve_off(resources):
    assert TweetTokenizer(preserve_case=False).tokenize("HeLLo :D") == ["hello", ":D"]


def test_N_000129_sentences(resources):
    text = "Hello world. This is Dr. Smith speaking! Is it ok? yes."
    assert sent_tokenize(text) == [
        "Hello world.",
        "This is Dr. Smith speaking!",
        "Is it ok?",
        "yes.",
    ]


def test_N_000136_empty_string_no_model_needed(resources):
    assert wordpunct_tokenize("") == []
    assert WhitespaceTokenizer().tokenize("   ") == []


def test_N_000137_sentences_need_punkt(no_resources):
    with pytest.raises(ResourceNotFound):
        sent_tokenize("A sentence. Another one.")


def test_N_000138_word_tokenize_needs_punkt(no_resources):
    with pytest.raises(ResourceNotFound):
        word_tokenize("A sentence. Another one.")


def test_N_000413_preserve_line_needs_no_model(no_resources):
    assert word_tokenize("A line.", preserve_line=True) == ["A", "line", "."]


def test_N_000139_cli_fails_without_models(no_resources, monkeypatch, capsys):
    import io
    import sys

    from lingora.cli import cli

    monkeypatch.setattr(sys, "stdin", io.StringIO("A sentence.\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code != 0
    assert capsys.readouterr().out == ""
