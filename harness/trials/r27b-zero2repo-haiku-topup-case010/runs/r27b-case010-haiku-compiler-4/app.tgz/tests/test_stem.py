"""Stemmers and the WordNet lemmatizer.

# spec: N-000149 N-000153 N-000158 N-000159 N-000162 N-000163 N-000168
# spec: N-000170 N-000178 N-000181 N-000183 N-000185 N-000186 N-000432
"""

import pytest

from lingora.errors import ResourceNotFound, UnsupportedInput
from lingora.stem import (
    LancasterStemmer,
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
    WordNetLemmatizer,
)


def test_N_000153_porter_default_words():
    p = PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("motoring") == "motor"
    assert p.stem("relational") == "relat"


def test_N_000158_porter_ies_four_letters_gives_ie():
    assert PorterStemmer().stem("ties") == "tie"


def test_N_000159_porter_ied_rule():
    assert PorterStemmer().stem("tied") == "tie"
    assert PorterStemmer().stem("studied") == "studi"


def test_N_000162_porter_y_to_i_after_consonant():
    assert PorterStemmer().stem("happy") == "happi"


def test_N_000156_short_words_unchanged():
    assert PorterStemmer().stem("is") == "is"


def test_N_000422_porter_keeps_case_by_default():
    assert PorterStemmer().stem("Caresses") == "Caress"
    assert PorterStemmer().stem("Caresses", to_lowercase=True) == "caress"


def test_N_000170_lancaster_known_stems():
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert LancasterStemmer().stem("provision") == "provid"


def test_N_000178_regexp_removes_matches():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("cat") == "cat"


def test_N_000172_snowball_english():
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("running") == "run"


def test_N_000174_porter_and_english_differ():
    assert SnowballStemmer("porter").stem("generously") == "gener"
    assert SnowballStemmer("english").stem("generously") != "gener"


def test_N_000181_unsupported_language_names_request():
    with pytest.raises(UnsupportedInput) as info:
        SnowballStemmer("klingon")
    assert "klingon" in str(info.value)


def test_N_000183_stopwords_need_list(no_resources):
    with pytest.raises(ResourceNotFound):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N_000184_stopwords_for_other_language_do_not_count(resources):
    with pytest.raises(ResourceNotFound):
        SnowballStemmer("french", ignore_stopwords=True)


def test_N_000177_stopword_skipping(resources):
    assert SnowballStemmer("english", ignore_stopwords=True).stem("The") == "the"


def test_N_000185_wordnet_needs_resource(no_resources):
    with pytest.raises(ResourceNotFound):
        WordNetLemmatizer()
