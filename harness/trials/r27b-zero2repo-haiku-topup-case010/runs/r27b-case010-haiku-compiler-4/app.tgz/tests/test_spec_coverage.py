"""Every id in spec/CHECKLIST.md is implemented (referenced by a `# spec:`
marker in lingora/ or tests/) or is listed as not done with a reason in NOTES.md.

The spec directory is optional at test time; the check is skipped when it is
absent.
"""

import os
import re

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECKLIST = os.path.join(ROOT, "spec", "CHECKLIST.md")
NOTES = os.path.join(ROOT, "NOTES.md")

# Ids that are not implemented; each is explained in NOTES.md under "Not done".
NOT_DONE = {
    "N-000038": "named-entity chunker model not implemented",
    "N-000140": "ISRI, Cistem and RSLP stemmer families not implemented",
    "N-000141": "ISRI, Cistem and RSLP stemmer families not implemented",
    "N-000172": "Snowball algorithms for 14 of the 16 languages not implemented",
    "N-000173": "Snowball Dutch algorithm not implemented",
    "N-000258": "recursive-descent parser not implemented",
}


def _ids(text):
    return set(re.findall(r"N-\d{6}", text))


@pytest.mark.skipif(not os.path.exists(CHECKLIST), reason="spec not present")
def test_every_checklist_id_is_accounted_for():
    checklist = _ids(open(CHECKLIST, encoding="utf-8").read())
    code_text = ""
    for base in ("lingora", "tests"):
        for dirpath, _, files in os.walk(os.path.join(ROOT, base)):
            for name in files:
                if name.endswith(".py") and name != "test_spec_coverage.py":
                    with open(os.path.join(dirpath, name), encoding="utf-8") as h:
                        code_text += h.read()
    referenced = _ids(code_text)
    missing = sorted(checklist - referenced - set(NOT_DONE))
    assert not missing, "ids neither implemented nor listed as not done: %s" % missing
    notes = open(NOTES, encoding="utf-8").read()
    for ident in NOT_DONE:
        assert ident in notes, "%s is not done but NOTES.md does not say so" % ident
