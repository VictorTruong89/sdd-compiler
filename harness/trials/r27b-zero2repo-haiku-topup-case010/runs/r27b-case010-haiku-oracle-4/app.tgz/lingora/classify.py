"""Classifiers (spec: FP-06 Text classification; Interface Contract "Classifiers";
ids N-000295..N-000318, N-000492..N-000497)."""

import collections
import math

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


def _check_labeled(labeled_featuresets):
    if not isinstance(labeled_featuresets, (list, tuple)) or not labeled_featuresets:
        raise ValueError("training needs a non-empty list of (featureset, label) pairs")
    for pair in labeled_featuresets:
        if not isinstance(pair, (tuple, list)) or len(pair) != 2:
            raise TypeError("each training item must be a (featureset, label) pair")
        if not isinstance(pair[0], dict):
            raise TypeError("a featureset is a dict from feature names to values")


class ProbDist(object):
    """A probability distribution over labels (N-000496, N-000497)."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: (self._probs[label], str(label)))

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier(object):
    """Naive Bayes with add-one smoothing per feature name.

    Features whose name was never seen in training are ignored (N-000304, N-000305).
    """

    def __init__(self, label_counts, feature_counts, feature_values, total):
        self._label_counts = label_counts
        self._labels = list(label_counts.keys())
        self._feature_counts = feature_counts  # (label, fname) -> Counter(value -> count)
        self._feature_values = feature_values  # fname -> set of values seen
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        _check_labeled(labeled_featuresets)  # spec: N-000302, N-000303
        label_counts = collections.OrderedDict()
        feature_counts = collections.defaultdict(collections.Counter)
        feature_values = collections.defaultdict(set)
        for featureset, label in labeled_featuresets:
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, value in featureset.items():
                feature_counts[(label, fname)][value] += 1
                feature_values[fname].add(value)
        return cls(label_counts, feature_counts, feature_values, len(labeled_featuresets))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            logp = math.log(self._label_counts[label] / float(self._total))
            for fname, value in featureset.items():
                if fname not in self._feature_values:
                    continue
                values = self._feature_values[fname]
                counts = self._feature_counts.get((label, fname))
                seen = sum(counts.values()) if counts else 0
                count = counts.get(value, 0) if counts else 0
                # Add-one smoothing; one extra slot for values never seen with any label.
                logp += math.log((count + 1.0) / (seen + len(values) + 1.0))
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        norm = sum(exps.values())
        return ProbDist({label: exps[label] / norm for label in self._labels})

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = self._labels[0]
        for label in self._labels[1:]:
            if scores[label] > scores[best]:
                best = label
        return best


class _Node(object):
    __slots__ = ("label", "feature", "children")

    def __init__(self, label, feature=None, children=None):
        self.label = label
        self.feature = feature
        self.children = children or {}


def _entropy(labels):
    total = float(len(labels))
    counts = collections.Counter(labels)
    return -sum((c / total) * math.log(c / total, 2) for c in counts.values())


def _majority(labels):
    counts = collections.Counter(labels)
    best = None
    for label in labels:  # first-seen order breaks ties deterministically
        if best is None or counts[label] > counts[best]:
            best = label
    return best


class DecisionTreeClassifier(object):
    """ID3-style tree: at each node the feature with the largest information gain splits
    the examples by value (a missing feature counts as value ``None``)."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        _check_labeled(labeled_featuresets)  # spec: N-000310..N-000314
        examples = [(dict(fs), label) for fs, label in labeled_featuresets]
        features = sorted({f for fs, _ in examples for f in fs}, key=str)
        return cls(cls._grow(examples, features))

    @classmethod
    def _grow(cls, examples, features):
        labels = [label for _, label in examples]
        if len(set(labels)) == 1 or not features:
            return _Node(_majority(labels))
        base = _entropy(labels)
        best_feature = None
        best_gain = None
        best_groups = None
        for feature in features:
            groups = collections.OrderedDict()
            for fs, label in examples:
                groups.setdefault(fs.get(feature), []).append((fs, label))
            remainder = 0.0
            for group in groups.values():
                remainder += len(group) / float(len(examples)) * _entropy([l for _, l in group])
            gain = base - remainder
            if best_gain is None or gain > best_gain + 1e-12:
                best_feature, best_gain, best_groups = feature, gain, groups
        if best_gain is None or best_gain <= 1e-12:
            return _Node(_majority(labels))
        rest = [f for f in features if f != best_feature]
        children = {}
        for value, group in best_groups.items():
            children[value] = cls._grow(group, rest)
        return _Node(_majority(labels), best_feature, children)

    def classify(self, featureset):
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.label
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs whose label the classifier gets right."""  # spec: N-000299, N-000318
    if isinstance(gold, str) or not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = 0
    for featureset, label in gold:
        if classifier.classify(featureset) == label:
            correct += 1
    return correct / float(len(gold))
