"""Part-of-speech taggers (spec: FP-03 Part-of-speech tagging; Interface Contract
"Taggers"; ids N-000187..N-000227, N-000433..N-000445)."""

import collections
import json
import os
import re

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    if not isinstance(tokens, (list, tuple)) or not all(isinstance(t, str) for t in tokens):
        raise TypeError("tokens must be a list of str")


class _SequentialTagger(object):
    """Base class: a primary rule per token, with an optional backoff tagger.

    The backoff tagger is consulted only for the tokens the primary leaves untagged
    (N-000205, N-000206).
    """

    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _primary(self, tokens):  # pragma: no cover - overridden
        raise NotImplementedError

    def tag(self, tokens):
        """Return ``[(token, tag_or_None), ...]``, one pair per input token, in order."""  # spec: N-000196, N-000444
        _check_tokens(tokens)
        if not tokens:
            return []
        tags = list(self._primary(tokens))
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, fallback):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token (N-000198)."""

    def __init__(self, tag, backoff=None):
        super(DefaultTagger, self).__init__(backoff)
        self._tag = tag

    def _primary(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    """Each word seen in training gets the tag it most often had (N-000199..N-000201)."""

    def __init__(self, train=None, backoff=None):
        super(UnigramTagger, self).__init__(backoff)
        counts = collections.defaultdict(collections.Counter)
        for sentence in train or []:
            for pair in sentence:
                word, tag = pair
                counts[word][tag] += 1
        self._model = {}
        for word, tag_counts in counts.items():
            # Ties are broken by tag name, so training is deterministic (N-000200).
            best = sorted(tag_counts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
            self._model[word] = best

    def _primary(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; the first rule whose pattern matches at the token start wins."""

    def __init__(self, regexps, backoff=None):
        super(RegexpTagger, self).__init__(backoff)
        if not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _primary(self, tokens):
        result = []
        for token in tokens:
            tag = None
            for pattern, candidate in self._rules:
                if pattern.match(token):
                    tag = candidate
                    break
            result.append(tag)
        return result


# ---------------------------------------------------------------------------
# Recommended averaged perceptron tagger (N-000207..N-000214).
# Feature templates and word normalisation follow the greedy averaged
# perceptron tagger of Honnibal (2013). The model is read from the packaged
# resource ``taggers/averaged_perceptron_tagger_<lang>/``.
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_LANGS = ("eng", "rus")


def _normalize(word):
    if not word:
        return word
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _AveragedPerceptron(object):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def _predict(self, features):
        scores = collections.defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    @staticmethod
    def _features(i, word, context, prev, prev2):
        i += len(_START)
        feats = collections.defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def tag(self, tokens):
        """Tag the whole token list as one sentence, left to right."""  # spec: N-000209..N-000212
        context = _START + [_normalize(w) for w in tokens] + _END
        prev, prev2 = _START
        output = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                feats = self._features(i, word, context, prev, prev2)
                tag = self._predict(feats)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_perceptron_cache = {}


def _load_perceptron(lang):
    if lang in _perceptron_cache:
        return _perceptron_cache[lang]
    base = os.path.join("taggers", "averaged_perceptron_tagger_%s" % lang)
    directory = data.require(base)
    stem = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)

    def read_json(suffix):
        full = stem + suffix
        if not os.path.isfile(full):
            raise data.ResourceNotFound("missing tagger file %s" % full)
        with open(full, encoding="utf-8") as handle:
            return json.load(handle)

    model = _AveragedPerceptron(
        read_json(".weights.json"), read_json(".tagdict.json"), read_json(".classes.json")
    )
    _perceptron_cache[lang] = model
    return model


_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "ANUM": "ADJ", "A": "ADJ", "COM": "ADJ", "V": "VERB", "ADV": "ADV",
    "ADVPRO": "ADV", "PRAEDIC": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
    "PARENTH": "PRT", "NUM": "NUM", "SPRO": "PRON", "APRO": "DET", "INTJ": "X",
}


def _map_russian(tag):
    base = tag.split("=", 1)[0]
    return _RUS_TO_UNIVERSAL.get(base, "X")


_en_map_cache = {}


def _load_english_map():
    if "map" not in _en_map_cache:
        found = data.require(os.path.join("taggers", "universal_tagset", "en-ptb.map"))
        table = {}
        with open(found, encoding="utf-8") as handle:
            for line in handle:
                parts = line.rstrip("\r\n").split("\t")
                if len(parts) == 2:
                    table[parts[0]] = parts[1]
        _en_map_cache["map"] = table
    return _en_map_cache["map"]


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a list of tokens with LINGORA's recommended tagger.

    ``lang`` is ``'eng'`` (default) or ``'rus'``; ``tagset`` is ``None`` (native
    tags) or ``'universal'``. Raises for a raw string, an unsupported language,
    an unknown tagset, or a missing model.
    """  # spec: N-000219..N-000227, N-000440..N-000443
    if isinstance(tokens, str):
        raise TypeError("pos_tag takes a list of tokens, not a raw string")
    _check_tokens(tokens)
    if lang not in _PERCEPTRON_LANGS:
        raise ValueError("unsupported language %r (supported: eng, rus)" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unknown tagset %r" % (tagset,))
    model = _load_perceptron(lang)
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _load_english_map()
            tagged = [(w, table.get(t, t)) for w, t in tagged]
        else:
            tagged = [(w, _map_russian(t)) for w, t in tagged]
    return tagged
