"""Parsers over a :class:`lingora.grammar.CFG` (spec: FP-05 "Chart parser" and
"Shift-reduce parser"; Interface Contract "Parsing"; ids N-000266..N-000276, N-000292..N-000294,
N-000473..N-000476)."""

from ..grammar import CFG
from ..tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if not isinstance(grammar, CFG):
        raise TypeError("the grammar must be a CFG")
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for tok in tokens:
        if tok not in known:
            # A token that no production produces does not succeed (N-000292..N-000294).
            raise ValueError("no production of the grammar produces the token %r" % (tok,))


class ChartParser(object):
    """Exhaustive chart parser: every tree the grammar assigns to the token list."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("the grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        busy = set()
        grammar = self._grammar

        def trees(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in busy:  # cyclic re-entry on the same span: cut the cycle
                return []
            busy.add(key)
            result = []
            for prod in grammar.productions(sym):
                for children in seq(prod.rhs(), 0, i, j):
                    result.append(Tree(sym.symbol(), children))
            busy.discard(key)
            memo[key] = result
            return result

        def seq(rhs, k, i, j):
            if k == len(rhs):
                return [[]] if i == j else []
            sym = rhs[k]
            out = []
            if isinstance(sym, str):
                if sym == "":
                    return seq(rhs, k + 1, i, j)
                if i < j and tokens[i] == sym:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        out.append([sym] + rest)
                return out
            for m in range(i, j + 1):
                subs = trees(sym, i, m)
                if not subs:
                    continue
                for rest in seq(rhs, k + 1, m, j):
                    for sub in subs:
                        out.append([sub] + rest)
            return out

        return iter(trees(grammar.start(), 0, n))


class ShiftReduceParser(object):
    """Single left-to-right shift-reduce pass without backtracking."""

    _MAX_REDUCTIONS = 10000

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("the grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        # Empty productions would reduce forever on an empty stack top; they are skipped.
        prods = [p for p in self._grammar.productions() if len(p.rhs()) > 0]
        start = self._grammar.start().symbol()
        stack = []

        def reduce_once():
            for prod in prods:
                n = len(prod.rhs())
                if n > len(stack):
                    continue
                top = stack[len(stack) - n:]
                ok = True
                for sym, item in zip(prod.rhs(), top):
                    if isinstance(sym, str):
                        if isinstance(item, Tree) or item != sym:
                            ok = False
                            break
                    elif not (isinstance(item, Tree) and item.label() == sym.symbol()):
                        ok = False
                        break
                if ok:
                    del stack[len(stack) - n:]
                    stack.append(Tree(prod.lhs().symbol(), top))
                    return True
            return False

        pos = 0
        reductions = 0
        while True:
            while reduce_once():
                reductions += 1
                if reductions > self._MAX_REDUCTIONS:
                    return iter([])
            if pos >= len(tokens):
                break
            stack.append(tokens[pos])
            pos += 1
            reductions = 0

        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])
