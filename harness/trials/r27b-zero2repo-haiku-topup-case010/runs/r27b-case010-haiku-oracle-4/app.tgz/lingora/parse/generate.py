"""Sentence generation from a grammar (spec: FP-05 "Generator"; Interface Contract
"Generation"; ids N-000276..N-000280, N-000477..N-000480)."""

from ..grammar import CFG, Nonterminal

__all__ = ["generate"]


def _resolve_start(grammar, start):
    if start is None:
        return grammar.start()
    if isinstance(start, Nonterminal):
        return start
    if isinstance(start, str):
        return Nonterminal(start)
    raise TypeError("start must be a symbol or None")


def _check_int(name, value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("%s must be an int or None" % name)
    return value


def _derivations(grammar, start, bound, exact, limit_state):
    """Leftmost derivations within ``bound`` derivation depth.

    Yields ``(tokens, depth)`` pairs. With ``exact`` only derivations whose depth
    equals ``bound`` are yielded. ``limit_state['pruned']`` is set when a
    nonterminal could not be expanded because of the bound.
    """
    by_lhs = {}
    for prod in grammar.productions():
        by_lhs.setdefault(prod.lhs(), []).append(prod)

    def expand(pending, out, depth):
        # Pending items are (symbol, depth) in left-to-right order.
        while pending:
            sym, d = pending[0]
            if isinstance(sym, str):
                if sym != "":
                    out = out + [sym]
                pending = pending[1:]
                continue
            break
        else:
            if not exact or depth == bound:
                yield list(out), depth
            return
        sym, d = pending[0]
        rest = pending[1:]
        prods = by_lhs.get(sym, [])
        if d + 1 > bound:
            if prods:
                limit_state["pruned"] = True
            return
        for prod in prods:
            child = tuple((s, d + 1) for s in prod.rhs())
            new_depth = max(depth, d + 1)
            for item in expand(child + rest, out, new_depth):
                yield item

    return expand(((start, 0),), [], 0)


def generate(grammar, start=None, depth=None, n=None):
    """Enumerate sentences (lists of terminal tokens) derived from ``start``.

    ``depth`` bounds the derivation depth (``None`` lifts the bound by iterative
    deepening, so a finite language is enumerated completely); ``n`` caps the
    number of sentences (``None`` means no cap).
    """  # spec: N-000276..N-000280, N-000477..N-000479
    if not isinstance(grammar, CFG):
        raise TypeError("generate takes a CFG")
    start_sym = _resolve_start(grammar, start)
    depth = _check_int("depth", depth)
    n = _check_int("n", n)
    return _generate(grammar, start_sym, depth, n)


def _generate(grammar, start_sym, depth, n):
    produced = 0
    if n is not None and n <= 0:
        return
    if depth is not None:
        for tokens, _ in _derivations(grammar, start_sym, depth, False, {}):
            yield tokens
            produced += 1
            if n is not None and produced >= n:
                return
        return
    bound = 1
    while True:
        state = {"pruned": False}
        for tokens, _ in _derivations(grammar, start_sym, bound, True, state):
            yield tokens
            produced += 1
            if n is not None and produced >= n:
                return
        if not state["pruned"]:
            return
        bound += 1
