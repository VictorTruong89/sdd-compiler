"""Evaluation metrics (spec: FP-07 Evaluation metrics; Interface Contract "Metrics";
ids N-000322..N-000348, N-000498..N-000512)."""

__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]


def accuracy(reference, test):
    """Fraction of positions where two equal-length lists hold equal values."""  # spec: N-000330, N-000501, N-000502
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    equal = sum(1 for a, b in zip(reference, test) if a == b)
    return equal / float(len(reference))


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions=True`` adjacent transpositions cost 1.

    The transposition form is the restricted one: only two characters adjacent in
    both strings may be swapped, with nothing inserted or deleted between them
    (N-000505, N-000506; see NOTES.md).
    """  # spec: N-000322..N-000329, N-000348
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s1[i - 1] == s2[j - 1]:
                sub = d[i - 1][j - 1]
            else:
                sub = d[i - 1][j - 1] + substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, sub)
            if transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def _check_sets(*values):
    for value in values:
        if not isinstance(value, (set, frozenset)):
            raise TypeError("precision, recall and f-measure take sets, not %s" % type(value).__name__)


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union|; 0 when both sets are empty."""  # spec: N-000507
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / float(len(union))


def precision(reference, test):
    """|reference ∩ test| / |test|, or ``None`` when ``test`` is empty."""  # spec: N-000332, N-000344..N-000347
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / float(len(test))


def recall(reference, test):
    """|reference ∩ test| / |reference|, or ``None`` when ``reference`` is empty."""  # spec: N-000332, N-000344..N-000347
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / float(len(reference))


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; ``None`` when no number results
    (an empty set, or no shared element; see NOTES.md)."""  # spec: N-000333, N-000334, N-000345..N-000347
    _check_sets(reference, test)
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1.0 - alpha) / r)
