"""Context-free grammars (spec: FP-05 "Grammar reader"; Interface Contract "Grammars and
parsers"; ids N-000461..N-000480)."""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_SYMBOL_RE = re.compile(r"""'[^']*'|"[^"]*"|\|| *[^\s|'"]+""")


class Nonterminal(object):
    """A nonterminal symbol. ``str()`` gives its name (N-000467)."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production(object):
    """One alternative of a rule: ``lhs -> rhs``. ``rhs`` holds ``Nonterminal`` objects
    and ``str`` terminals (quotes removed)."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "Production(%s)" % self

    def __str__(self):
        parts = []
        for sym in self._rhs:
            parts.append(repr(sym) if isinstance(sym, str) else str(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))


class CFG(object):
    """A context-free grammar. The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        if not isinstance(start, Nonterminal):
            start = Nonterminal(start)
        self._start = start
        self._productions = list(productions)
        self._nonterminals = set(p.lhs() for p in self._productions)

    @classmethod
    def fromstring(cls, input):
        """Read productions ``<LHS> -> <RHS>``, one per line; ``|`` separates alternatives."""  # spec: N-000464..N-000471
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line:
                continue
            if "->" not in line:
                raise ValueError("production without '->': %r" % line)
            left, right = line.split("->", 1)
            lhs_text = left.strip()
            if not lhs_text or re.search(r"[\s'\"|]", lhs_text):
                raise ValueError("bad left-hand side in production: %r" % line)
            lhs = Nonterminal(lhs_text)
            alternatives = [[]]
            for token in _SYMBOL_RE.findall(right):
                token = token.strip()
                if not token:
                    continue
                if token == "|":
                    alternatives.append([])
                elif token[0] in "'\"":
                    alternatives[-1].append(token[1:-1])
                else:
                    alternatives[-1].append(Nonterminal(token))
            for rhs in alternatives:
                productions.append(Production(lhs, rhs))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if not isinstance(lhs, Nonterminal):
            lhs = Nonterminal(lhs)
        return [p for p in self._productions if p.lhs() == lhs]

    def is_nonterminal(self, symbol):
        return isinstance(symbol, Nonterminal)

    def is_terminal(self, symbol):
        return isinstance(symbol, str)

    def terminals(self):
        """Every terminal that appears on some right-hand side."""
        out = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str):
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)

    def __str__(self):
        return "\n".join(str(p) for p in self._productions)
