"""Command line (spec: FP-01 "Command line"; Interface Contract "Command line — lingora.cli";
ids N-000414..N-000420).

``cli.main(args=['tokenize'], standalone_mode=True)`` reads UTF-8 text from standard input and
writes, for each input line, the recommended word tokenizer's tokens (with sentence splitting)
joined by the delimiter. Failure ends with a non-zero status and no token line for the failing input.
"""

import io
import sys

from . import tokenize as _tokenize

__all__ = ["cli"]

USAGE = (
    "Usage: lingora tokenize [--language NAME] [--delimiter TEXT] [--encoding NAME]\n"
    "Tokenize each line of standard input, one output line per input line.\n"
)


class _Group(object):
    """A command group with a click-like ``main`` entry."""

    name = "lingora"

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(USAGE)
            return 0
        command = args[0]
        if command != "tokenize":
            sys.stderr.write("Error: no such command %r.\n" % command)
            return 2
        language = "english"
        delimiter = " "
        encoding = None
        i = 1
        while i < len(args):
            opt = args[i]
            if opt in ("--language", "-l", "--delimiter", "-d", "--encoding", "-e") and i + 1 < len(args):
                value = args[i + 1]
                if opt in ("--language", "-l"):
                    language = value
                elif opt in ("--delimiter", "-d"):
                    delimiter = value
                else:
                    encoding = value
                i += 2
                continue
            sys.stderr.write("Error: unexpected argument %r.\n" % opt)
            return 2
        return self._tokenize(language, delimiter, encoding)

    def _tokenize(self, language, delimiter, encoding):
        stdin = sys.stdin
        if encoding and hasattr(stdin, "buffer"):
            stdin = io.TextIOWrapper(stdin.buffer, encoding=encoding)
        stdout = sys.stdout
        for raw in stdin:
            line = raw.rstrip("\r\n")
            try:
                tokens = _tokenize.word_tokenize(line, language=language)
            except Exception as exc:  # the failing input gets no token line
                sys.stderr.write("lingora: tokenization failed: %s\n" % exc)
                return 1
            stdout.write(delimiter.join(tokens) + "\n")
        stdout.flush()
        return 0


cli = _Group()
