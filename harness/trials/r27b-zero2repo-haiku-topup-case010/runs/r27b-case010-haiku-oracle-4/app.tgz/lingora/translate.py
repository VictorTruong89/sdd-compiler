"""Sentence-level BLEU (spec: FP-07 BLEU; Interface Contract "Metrics", ``lingora.translate``;
ids N-000335..N-000342, N-000511..N-000517)."""

import collections
import math

__all__ = ["bleu"]


def _ngrams(tokens, n):
    return collections.Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _check_tokens(name, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("%s must be a token list (a list of str)" % name)
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("%s must be a token list (a list of str)" % name)


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    """Score ``hypothesis`` against ``references`` with BLEU.

    ``weights`` gives one weight per n-gram order starting from unigrams; the default
    weights unigrams and bigrams equally. Without a ``smoothing_function`` the score is
    0 when any weighted order has no match (N-000341, N-000342). A smoothing function is
    called as ``f(numerators, denominators)`` with one entry per order and returns the
    list of precisions to use.
    """  # spec: N-000335..N-000342, N-000511..N-000517
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    for ref in references:
        _check_tokens("each reference", ref)
    _check_tokens("hypothesis", hypothesis)
    if not isinstance(weights, (list, tuple)) or not weights:
        raise TypeError("weights must be a non-empty sequence of numbers")
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")
    if not references:
        raise ValueError("bleu needs at least one reference")

    order = len(weights)
    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0.0

    numerators = []
    denominators = []
    for n in range(1, order + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = sum(hyp_counts.values())
        max_ref = collections.Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        numerators.append(clipped)
        denominators.append(total)

    if smoothing_function is None:
        precisions = []
        for num, den in zip(numerators, denominators):
            if den == 0 or num == 0:
                return 0.0
            precisions.append(num / float(den))
    else:
        precisions = list(smoothing_function(numerators, denominators))

    log_sum = 0.0
    for w, p in zip(weights, precisions):
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)

    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > closest:
        brevity = 1.0
    else:
        brevity = math.exp(1 - closest / float(hyp_len))
    return brevity * math.exp(log_sum)
