"""Packaged-resource finder.

``data.path`` is a mutable list of directories searched for packaged
resources (spec: Interface Contract, ``lingora.data``; ids N-000385..N-000402).
A caller may replace its contents in place; every lookup reads the list at
call time. Nothing is downloaded: a resource is either found in one of the
listed directories or it is not visible.
"""

import os
import sys


class ResourceNotFound(LookupError):
    """A packaged resource that a path needs is not visible on ``data.path``."""


def _initial_path():
    # Implementer's choice (N-000385): an environment override, a per-user
    # directory and a prefix-relative share directory. None of them is shipped
    # with the source tree, so by default no packaged model is visible.
    paths = []
    env = os.environ.get("LINGORA_DATA", "")
    paths.extend(p for p in env.split(os.pathsep) if p)
    paths.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    paths.append(os.path.join(sys.prefix, "share", "lingora"))
    return paths


path = _initial_path()


def find(resource):
    """Return the first existing ``<dir>/<resource>`` on ``path``, or ``None``."""
    for directory in list(path):
        if not isinstance(directory, str) or not directory:
            continue
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    return None


def require(resource):
    """Return the location of ``resource`` or raise :class:`ResourceNotFound`."""
    found = find(resource)
    if found is None:
        raise ResourceNotFound(
            "packaged resource %r is not visible on lingora.data.path" % resource
        )
    return found
