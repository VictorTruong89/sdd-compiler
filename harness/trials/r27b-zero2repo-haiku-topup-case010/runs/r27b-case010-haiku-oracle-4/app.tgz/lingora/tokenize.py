"""Tokenizers (spec: FP-01 Word, punctuation, and sentence tokenization;
Interface Contract "Tokenizers"; ids N-000081..N-000139, N-000403..N-000413)."""

import re

from . import _punkt

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
    "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
    "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
]


def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str, not %s" % (name, type(text).__name__))


# ---------------------------------------------------------------------------
# Word/punctuation tokenizer (N-000089..N-000091)
# ---------------------------------------------------------------------------

_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer(object):
    """Maximal runs of word characters, and maximal runs of other non-space characters."""

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _WORDPUNCT.finditer(text):
            yield match.span()


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Penn Treebank conventions (N-000092..N-000103) and LINGORA's recommended
# word tokenizer (N-000104..N-000112).
# ---------------------------------------------------------------------------

_PENN_STARTING_QUOTES = [
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r"([ \(\[{<])(\"|'{2})"), r"\1 `` "),
]
_PENN_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]
_PENN_PARENS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
_PENN_DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
_PENN_ENDING_QUOTES = [
    (re.compile(r"\""), " '' "),
    (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]
_PENN_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_PENN_CONTRACTIONS3 = [
    re.compile(r"(?i) ('t)(is)\b"),
    re.compile(r"(?i) ('t)(was)\b"),
]

_TYPO_QUOTES = re.compile(r"[“”„«»‘]|(?<!\w)’|’(?!\w)")
_DASHES_ASTERISK = re.compile(r"[\u2012-\u2015*]")
_MANY_POINTS = re.compile(r"\.{2,}")


def _penn_tokens(text, improved):
    if improved:
        # A straight double quote at the very start of the text is the closing quote.
        if text.startswith('"'):
            text = "\x01" + text[1:]
        text = _TYPO_QUOTES.sub(lambda m: " %s " % m.group(0), text)
        text = _DASHES_ASTERISK.sub(lambda m: " %s " % m.group(0), text)
        text = _MANY_POINTS.sub(lambda m: " %s " % m.group(0), text)
    text = " " + text + " "
    for pattern, repl in _PENN_STARTING_QUOTES:
        text = pattern.sub(repl, text)
    for pattern, repl in _PENN_PUNCTUATION:
        if improved and pattern.pattern == r"\.\.\.":
            continue
        text = pattern.sub(repl, text)
    text = _PENN_PARENS[0].sub(_PENN_PARENS[1], text)
    text = _PENN_DOUBLE_DASHES[0].sub(_PENN_DOUBLE_DASHES[1], text)
    text = " " + text + " "
    for pattern, repl in _PENN_ENDING_QUOTES:
        text = pattern.sub(repl, text)
    contractions2 = _PENN_CONTRACTIONS2
    if improved:
        contractions2 = [p for p in contractions2 if p.pattern != r"(?i)\b(can)(not)\b"]
    for pattern in contractions2:
        text = pattern.sub(r" \1 \2 ", text)
    for pattern in _PENN_CONTRACTIONS3:
        text = pattern.sub(r" \1 \2 ", text)
    if improved:
        text = text.replace("\x01", " '' ")
    return text.split()


class TreebankWordTokenizer(object):
    """Penn Treebank word tokenizer (N-000092..N-000103)."""

    def tokenize(self, text):
        _check_text(text)
        if not text.strip():
            return []
        return _penn_tokens(text, improved=False)


def _recommended_line(text):
    """LINGORA's recommended word tokenizer applied to one delimited line."""
    if not text.strip():
        return []
    return _penn_tokens(text, improved=True)


# ---------------------------------------------------------------------------
# Sentence tokenizer and word_tokenize (N-000086..N-000088, N-000129..N-000138)
# ---------------------------------------------------------------------------

def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model for ``language``.

    Raises :class:`lingora.data.ResourceNotFound` when the model is not visible.
    """
    _check_text(text)
    return _punkt.sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    With ``preserve_line=False`` the text is first split into sentences (this
    needs the Punkt model for ``language``); with ``preserve_line=True`` the
    text is one already-delimited line.
    """
    _check_text(text)
    if preserve_line:
        return _recommended_line(text)
    tokens = []
    for sentence in sent_tokenize(text, language):
        tokens.extend(_recommended_line(sentence))
    return tokens


# ---------------------------------------------------------------------------
# Whitespace, blank-line, regular-expression tokenizers (N-000113..N-000118)
# ---------------------------------------------------------------------------

_NON_SPACE = re.compile(r"\S+")
_BLANK_SEPARATOR = re.compile(r"\s*\n\s*\n\s*")


class WhitespaceTokenizer(object):
    def tokenize(self, text):
        _check_text(text)
        return _NON_SPACE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _NON_SPACE.finditer(text):
            yield match.span()


def blankline_tokenize(text):
    """Segments of ``text`` separated by blank lines; empty segments are dropped."""
    _check_text(text)
    segments = []
    for piece in _BLANK_SEPARATOR.split(text):
        piece = piece.strip()
        if piece:
            segments.append(piece)
    return segments


class RegexpTokenizer(object):
    """Token mode (default) or gap mode (``gaps=True``) with a caller pattern."""

    def __init__(self, pattern, gaps=False, discard_empty=False, flags=0):
        self._regexp = re.compile(pattern, flags)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        if not self._gaps:
            for match in self._regexp.finditer(text):
                if match.start() == match.end() and self._discard_empty:
                    continue
                yield match.span()
            return
        # Gap mode: the pieces between successive matches, and before the first and after the last.
        start = 0
        for match in self._regexp.finditer(text):
            yield (start, match.start())
            start = match.end()
        yield (start, len(text))

    def span_tokenize(self, text):
        _check_text(text)
        for start, end in self._spans(text):
            if self._gaps and self._discard_empty and start == end:
                continue
            yield (start, end)

    def tokenize(self, text):
        _check_text(text)
        tokens = []
        for start, end in self.span_tokenize(text):
            tokens.append(text[start:end])
        return tokens


# ---------------------------------------------------------------------------
# Tweet tokenizer (N-000119..N-000125)
# ---------------------------------------------------------------------------

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[\)\]\(\[dDpP/:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/:\}\{@\|\\][\-o*']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_RE = re.compile(
    "|".join([
        _EMOTICON,
        r"https?://\S+|www\.\S+",           # URLs
        r"<[^>]+>",                         # HTML tags
        r"@\w+",                            # @-handles
        r"#+\w[\w'\-]*",                    # hashtags
        r"\w+(?:['\-]\w+)+",                # words with internal apostrophe or hyphen
        r"[+\-]?\d+(?:[,/.:\-]\d+)+[+\-]?",  # numbers and dates
        r"\.(?:\s*\.)+",                    # ellipsis
        r"\w+",                             # words (accented letters included)
        r"\S",                              # everything else, one character at a time
    ]),
    re.UNICODE | re.IGNORECASE,
)
_EMOTICON_FULL = re.compile(_EMOTICON, re.UNICODE | re.IGNORECASE)
_HANDLE = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_RUN = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer(object):
    """Tweet-style tokenizer. Case is preserved by default; emoticons keep their case."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE.sub(" ", text)
        if self._reduce_len:
            text = _RUN.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_RE.findall(text)
        if not self._preserve_case:
            tokens = [
                tok if _EMOTICON_FULL.fullmatch(tok) else tok.lower()
                for tok in tokens
            ]
        return tokens
