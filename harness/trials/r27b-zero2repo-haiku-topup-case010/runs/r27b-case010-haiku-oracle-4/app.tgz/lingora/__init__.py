"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing. Packaged models are located through
``lingora.data.path``; a path that needs a missing model raises.
"""

from . import data
from . import tokenize
from . import stem
from . import tag
from . import tree
from . import grammar
from . import parse
from . import chunk
from . import classify
from . import metrics
from . import translate
from . import cli

__all__ = [
    "data", "tokenize", "stem", "tag", "tree", "grammar", "parse",
    "chunk", "classify", "metrics", "translate", "cli",
]
__version__ = "0.1.0"
