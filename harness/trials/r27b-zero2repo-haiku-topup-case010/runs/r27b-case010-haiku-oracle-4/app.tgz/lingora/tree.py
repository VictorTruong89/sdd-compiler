"""Constituent trees (spec: FP-05 "Trees"; Interface Contract "Trees"; ids N-000281..N-000291,
N-000481..N-000491)."""

__all__ = ["Tree"]


class Tree(object):
    """A labelled node with an ordered list of children.

    A child is a leaf (a token string, or any non-tree leaf such as a
    ``(token, tag)`` pair) or another :class:`Tree`.
    """

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("children must be a list of children, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text ``(<label> <child> ...)``."""  # spec: N-000489
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = s.replace("(", " ( ").replace(")", " ) ").split()
        if not tokens:
            raise ValueError("empty bracketed tree text")
        pos = [0]

        def parse_node():
            if tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(tokens):
                    raise ValueError("unbalanced brackets in tree text")
                tok = tokens[pos[0]]
                if tok == ")":
                    pos[0] += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos[0] += 1

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        """The leaves under this node, in left-to-right order."""
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat(margin=10**9)

    def pformat(self, margin=70):
        """Pretty-printed bracketed text; every label and leaf appears in pre-order."""  # spec: N-000287, N-000490
        flat = self._flat()
        if len(flat) <= margin:
            return flat
        lines = []
        self._pformat_lines(lines, 0)
        return "\n".join(lines)

    def _flat(self):
        parts = [str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(str(child))
        return "(" + " ".join(parts) + ")"

    def _pformat_lines(self, lines, depth):
        pad = "  " * depth
        flat = self._flat()
        if len(pad) + len(flat) <= 70 or not any(isinstance(c, Tree) for c in self._children):
            lines.append(pad + flat)
            return
        lines.append(pad + "(" + str(self._label))
        for child in self._children:
            if isinstance(child, Tree):
                child._pformat_lines(lines, depth + 1)
            else:
                lines.append(pad + "  " + str(child))
        lines[-1] += ")"
