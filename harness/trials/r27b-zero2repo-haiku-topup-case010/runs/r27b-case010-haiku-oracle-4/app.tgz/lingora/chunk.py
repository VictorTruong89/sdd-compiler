"""Chunking with chunk grammars (spec: FP-04 Chunking; Interface Contract "Chunking";
ids N-000228..N-000257, N-000446..N-000460)."""

import os
import re

from . import data
from .tree import Tree

__all__ = ["ChinkRule", "ChunkRule", "RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"  # implementer's choice of the sentence label (N-000456)
_CLAUSE_RE = re.compile(r"^([^\s:{}<>]+)\s*:\s*(.*)$")
_NOT_QUANTIFIED_BRACE = re.compile(r"\{(?!\d*,?\d*\})")
_BRACE_QUANT = re.compile(r"\{\d*,?\d*\}")


def _translate_content(content):
    """Translate an element's regular expression over a tag: ``.`` stays inside one tag."""
    out = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        i += 1
    return "".join(out)


def _tag_pattern_regex(body):
    """Compile a tag pattern (``<...>`` elements with quantifiers) over encoded tags."""
    s = re.sub(r"\s+", "", body)
    if not s:
        raise ValueError("empty tag pattern")
    parts = []
    i = 0
    while i < len(s):
        if s[i] != "<":
            raise ValueError("tag pattern element must be written in angle brackets: %r" % body)
        j = s.find(">", i)
        if j < 0:
            raise ValueError("unterminated tag pattern element: %r" % body)
        content = s[i + 1:j]
        if not content:
            raise ValueError("empty tag pattern element: %r" % body)
        element = "(?:<(?:%s)>)" % _translate_content(content)
        i = j + 1
        quant = ""
        if i < len(s) and s[i] in "?*+":
            quant = s[i]
            i += 1
        elif i < len(s) and s[i] == "{":
            m = _BRACE_QUANT.match(s, i)
            if m:
                quant = m.group(0)
                i = m.end()
        parts.append(element + quant)
    return re.compile("".join(parts))


class ChunkRule(object):
    """A chunk rule ``{<tag pattern>}``: every match becomes one chunk labelled ``label``."""

    kind = "chunk"

    def __init__(self, label, tag_pattern):
        self.label = str(label)
        self.tag_pattern = tag_pattern
        self.regex = _tag_pattern_regex(tag_pattern)

    def __repr__(self):
        return "ChunkRule(%r, %r)" % (self.label, self.tag_pattern)


class ChinkRule(ChunkRule):
    """A chink rule ``}<tag pattern>{``: matching tokens are removed from the clause's chunks."""

    kind = "chink"

    def __repr__(self):
        return "ChinkRule(%r, %r)" % (self.label, self.tag_pattern)


def _parse_patterns(text, label):
    rules = []
    rest = text.strip()
    while rest:
        if rest[0] == "{":
            depth = 0
            end = None
            for k, ch in enumerate(rest):
                if ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        end = k
                        break
            if end is None:
                raise ValueError("unterminated chunk rule: %r" % rest)
            rules.append(ChunkRule(label, rest[1:end]))
            rest = rest[end + 1:].strip()
        elif rest[0] == "}":
            m = _NOT_QUANTIFIED_BRACE.search(rest, 1)
            if m is None:
                raise ValueError("unterminated chink rule: %r" % rest)
            rules.append(ChinkRule(label, rest[1:m.start()]))
            rest = rest[m.end():].strip()
        else:
            raise ValueError("expected '{' or '}' in chunk grammar, found %r" % rest)
    return rules


def _parse_grammar(text):
    """Return the clauses of a chunk grammar as a list of ``(label, [rules])``."""
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        line = raw.strip()
        # Further patterns of a clause are indented; a line starting with a brace is one too.
        continuation = raw[0] in " \t" or line[0] in "{}"
        if current is None or not continuation:
            m = _CLAUSE_RE.match(line)
            if m is None:
                raise ValueError("a clause must begin with '<LABEL>: <pattern>': %r" % line)
            current = (m.group(1), [])
            clauses.append(current)
            current[1].extend(_parse_patterns(m.group(2), m.group(1)))
        else:
            current[1].extend(_parse_patterns(line, current[0]))
    if not clauses:
        raise ValueError("the chunk grammar has no clauses")
    return clauses


def _tag_of(unit):
    return unit[1] if isinstance(unit, tuple) else unit.label()


def _find_spans(regex, tags):
    encoded = "".join("<%s>" % t for t in tags)
    offsets = {}
    pos = 0
    for i, t in enumerate(tags):
        offsets[pos] = i
        pos += len(t) + 2
    offsets[pos] = len(tags)
    spans = []
    for m in regex.finditer(encoded):
        s, e = m.span()
        if s == e or s not in offsets or e not in offsets:
            continue
        spans.append((offsets[s], offsets[e]))
    return spans


def _apply_chunk(units, rule, made):
    spans = _find_spans(rule.regex, [_tag_of(u) for u in units])
    if not spans:
        return units
    out = []
    pos = 0
    for i, j in spans:
        out.extend(units[pos:i])
        chunk = Tree(rule.label, units[i:j])
        made.append(chunk)
        out.append(chunk)
        pos = j
    out.extend(units[pos:])
    return out


def _apply_chink(units, rule, made):
    out = []
    for unit in units:
        if not (isinstance(unit, Tree) and any(unit is m for m in made)):
            out.append(unit)
            continue
        children = list(unit)
        spans = _find_spans(rule.regex, [_tag_of(c) for c in children])
        if not spans:
            out.append(unit)
            continue
        pos = 0
        for i, j in spans:
            if i > pos:
                piece = Tree(unit.label(), children[pos:i])
                made.append(piece)
                out.append(piece)
            out.extend(children[i:j])
            pos = j
        if pos < len(children):
            piece = Tree(unit.label(), children[pos:])
            made.append(piece)
            out.append(piece)
    return out


class RegexpParser(object):
    """Chunk parser over a chunk grammar (text, or a list of :class:`ChunkRule` /
    :class:`ChinkRule` stages)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, ChunkRule) for s in grammar):
            self._clauses = [(stage.label, [stage]) for stage in grammar]
        else:
            raise TypeError("the chunk grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        """Chunk a list of ``(token, tag)`` pairs; returns a :class:`Tree` rooted at a sentence label."""  # spec: N-000455..N-000460
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        units = []
        for pair in tagged:
            if not isinstance(pair, (tuple, list)) or len(pair) != 2:
                raise TypeError("tagged must be a list of (token, tag) pairs")
            units.append((pair[0], pair[1]))
        for _label, rules in self._clauses:
            made = []
            for rule in rules:
                if rule.kind == "chink":
                    units = _apply_chink(units, rule, made)
                else:
                    units = _apply_chunk(units, rule, made)
        return Tree(ROOT_LABEL, units)


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires its packaged model and the English wordlist.

    Raises :class:`lingora.data.ResourceNotFound` when either is not visible.
    """  # spec: N-000452, N-000257
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    data.require(os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"))
    data.require(os.path.join("corpora", "words"))
    raise NotImplementedError(
        "the named-entity chunker model format is not implemented in this build (see NOTES.md)"
    )
