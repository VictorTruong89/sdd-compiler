"""Stemmers (spec: FP-02 Stemming; Interface Contract "Stemmers"; ids N-000140..N-000186,
N-000421..N-000432)."""

import os
import re

from . import data

__all__ = [
    "ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer",
    "RegexpStemmer", "SnowballStemmer", "WordNetLemmatizer",
]


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str, not %s" % type(word).__name__)


# ---------------------------------------------------------------------------
# Porter (N-000149..N-000169, N-000422..N-000427).
# Modes: "LINGORA" (default, with the LINGORA extensions), "MARTIN" (Martin's
# extensions only) and "ORIGINAL" (Porter's 1980 algorithm).
# ---------------------------------------------------------------------------

PORTER_MODES = ("LINGORA", "MARTIN", "ORIGINAL")

# Small built-in table of irregular forms (N-000155). Entries are an implementer's choice.
_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes", "inning": "inning",
    "innings": "inning", "outing": "outing", "canning": "can", "herring": "herring",
    "earring": "earring", "proceed": "proceed", "exceed": "exceed", "succeed": "succeed",
}

_VOWELS = "aeiou"


def _cons(word, i):
    """Porter's consonant test: ``y`` is a consonant at the start or after a vowel."""
    c = word[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _cons(word, i - 1)
    return True


def _measure(stem):
    n = len(stem)
    m = 0
    i = 0
    while i < n and _cons(stem, i):
        i += 1
    while True:
        while i < n and not _cons(stem, i):
            i += 1
        if i >= n:
            break
        while i < n and _cons(stem, i):
            i += 1
        m += 1
    return m


def _has_vowel(stem):
    return any(not _cons(stem, i) for i in range(len(stem)))


def _ends_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _cons(word, len(word) - 1)


def _star_o(stem, lingora):
    """The *o condition: consonant-vowel-consonant, last consonant not w, x or y."""
    n = len(stem)
    if n == 2:
        if not lingora:
            return False
        return (not _cons(stem, 0)) and _cons(stem, 1) and stem[1] not in "wxy"
    if n < 3:
        return False
    return (_cons(stem, n - 3) and not _cons(stem, n - 2) and _cons(stem, n - 1)
            and stem[-1] not in "wxy")


_P2_STEP2 = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("alli", "al"), ("entli", "ent"), ("eli", "e"), ("ousli", "ous"),
    ("ization", "ize"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"),
    ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"),
    ("iviti", "ive"), ("biliti", "ble"),
]
_P2_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"),
    ("ful", ""), ("ness", ""),
]
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _longest_suffix(word, suffixes):
    best = None
    for suf in suffixes:
        if word.endswith(suf) and (best is None or len(suf) > len(best)):
            best = suf
    return best


def _porter_step2(word, mode):
    lingora = mode == "LINGORA"
    if lingora and word.endswith("alli") and _measure(word[:-4]) > 0:
        return _porter_step2(word[:-4] + "al", mode)
    rules = list(_P2_STEP2)
    if mode == "ORIGINAL":
        rules.append(("abli", "able"))
    else:
        rules.append(("bli", "ble"))
    if mode in ("LINGORA", "MARTIN"):
        rules.append(("logi", "log"))
    if lingora:
        rules.append(("fulli", "ful"))
    suf = _longest_suffix(word, [r[0] for r in rules])
    if suf is None:
        return word
    repl = dict(rules)[suf]
    stem = word[: -len(suf)]
    if suf == "logi":
        return word[:-4] + "log" if _measure(word[:-3]) > 0 else word
    if _measure(stem) > 0:
        return stem + repl
    return word


def _porter_stem(word, mode):
    w = word
    if len(w) <= 2:
        return w
    lingora = mode == "LINGORA"
    if lingora and w in _PORTER_IRREGULAR:
        return _PORTER_IRREGULAR[w]

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        w = w[:-2]
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if _has_vowel(w[:-1]):
            w = w[:-1]

    # Step 1b
    if lingora and w.endswith("ied"):
        w = w[:-1] if len(w) == 4 else w[:-2]
    elif w.endswith("eed"):
        if _measure(w[:-3]) > 0:
            w = w[:-1]
    elif w.endswith("ed") or w.endswith("ing"):
        suf = "ed" if w.endswith("ed") else "ing"
        stem = w[: -len(suf)]
        if _has_vowel(stem):
            w = stem
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif _ends_double_cons(w) and w[-1] not in "lsz":
                w = w[:-1]
            elif _measure(w) == 1 and _star_o(w, lingora):
                w += "e"

    # Step 1c
    if w.endswith("y") and len(w) >= 2:
        if lingora:
            cond = len(w) >= 3 and _cons(w, len(w) - 2)
        else:
            cond = _has_vowel(w[:-1])
        if cond:
            w = w[:-1] + "i"

    # Step 2
    w = _porter_step2(w, mode)

    # Step 3
    suf = _longest_suffix(w, [r[0] for r in _P2_STEP3])
    if suf is not None:
        stem = w[: -len(suf)]
        if _measure(stem) > 0:
            w = stem + dict(_P2_STEP3)[suf]

    # Step 4
    suf = _longest_suffix(w, _P2_STEP4)
    if suf is not None:
        stem = w[: -len(suf)]
        if suf == "ion":
            if _measure(stem) > 1 and stem[-1:] in ("s", "t"):
                w = stem
        elif _measure(stem) > 1:
            w = stem

    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _star_o(stem, lingora)):
            w = stem
    if _measure(w) > 1 and w.endswith("ll"):
        w = w[:-1]
    return w


class PorterStemmer(object):
    """Porter stemmer. ``stem(word, to_lowercase=False)`` keeps the letter case it is given."""

    def __init__(self, mode="LINGORA"):
        if mode not in PORTER_MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=False):
        _check_word(word)
        if to_lowercase:
            word = word.lower()
        return _porter_stem(word, self.mode)


# ---------------------------------------------------------------------------
# Lancaster / Paice-Husk (N-000170..N-000171).
# Rules are written in Paice's notation: the letters before the digit are the
# suffix reversed, the digit is the number of characters removed, ``*`` means
# the rule applies only to an intact word, the text after the digit is appended,
# and the terminator ``>`` allows further rules to apply, ``.`` stops.
# The table below is reconstructed from the published rule set.
# ---------------------------------------------------------------------------

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lbi3.", "lib2l.", "lc1.", "lufi4y.", "luf3y.",
    "mm1.", "mu*2.", "nois4j>", "noix4ct.", "noi3>", "nt1.", "pihs4.", "rai3y.", "sei3y>", "sis2.",
    "si2>", "suo3>", "su*2.", "s*1>", "s0.", "ta2>", "tnem4>", "tne3>", "tna3>",
    "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.",
    "tsi3>", "tt1.", "uqi3>", "ugo1>", "vis3j>", "vie2>", "ylb1>", "yli3y>",
    "yl2>", "yrtsi5y.", "ys3>", "zi2>", "zy1s.", "ymo1>",
]


def _parse_lancaster_rule(text):
    m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([>.]?)$", text)
    if m is None:
        raise ValueError("bad Lancaster rule %r" % text)
    letters, star, digit, append, term = m.groups()
    return {
        "suffix": letters[::-1],
        "intact": bool(star),
        "remove": int(digit),
        "append": append,
        "cont": term == ">",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer(object):
    """Paice/Husk stemmer. Words are lowercased; no prefix is stripped."""

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        changed = True
        guard = 0
        while changed and guard < 100:
            guard += 1
            changed = False
            for rule in _LANCASTER_PARSED:
                if rule["intact"] and not intact:
                    continue
                if not w.endswith(rule["suffix"]):
                    continue
                stem = w[: len(w) - rule["remove"]]
                if len(stem) < 2 or (len(stem) < 3 and stem[0] not in _VOWELS):
                    continue
                w = stem + rule["append"]
                intact = False
                if rule["cont"]:
                    changed = True
                break
        return w


# ---------------------------------------------------------------------------
# Snowball (N-000172..N-000181). "english" is Porter2; "porter" is the original
# Porter algorithm. The other listed languages are accepted by the constructor
# but their stemming is not implemented (see NOTES.md).
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_P2_EXCEPTIONS1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_INVARIANT = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_P2_VOWELS = "aeiouy"
_P2_LI_ENDINGS = "cdeghkmnrt"


def _p2_region(word, start):
    for i in range(start + 1, len(word)):
        if word[i] not in _P2_VOWELS and word[i - 1] in _P2_VOWELS:
            return i + 1
    return len(word)


def _p2_r1r2(word):
    if word.startswith(("gener", "arsen")):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1 = _p2_region(word, 0)
    r2 = _p2_region(word, r1)
    return min(r1, len(word)), min(r2, len(word))


def _p2_short_syllable_end(word):
    n = len(word)
    if n == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if n >= 3:
        return (word[-3] not in _P2_VOWELS and word[-2] in _P2_VOWELS
                and word[-1] not in _P2_VOWELS and word[-1] not in "wxY")
    return False


def _p2_is_short(word):
    r1 = _p2_r1r2(word)[0]
    return r1 >= len(word) and _p2_short_syllable_end(word)


def english_stem(word):
    """Porter2 (Snowball "english") stemmer."""
    if len(word) <= 2:
        return word
    if word in _P2_EXCEPTIONS1:
        return _P2_EXCEPTIONS1[word]
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        stem = w[:-3]
        w = stem + ("i" if len(stem) > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(c in _P2_VOWELS for c in w[:-2]):
            w = w[:-1]

    if w in _P2_INVARIANT:
        return w.replace("Y", "y")

    r1, r2 = _p2_r1r2(w)

    # Step 1b
    if w.endswith(("eedly", "eed")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if any(c in _P2_VOWELS for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        w = w[:-1]
                    elif _p2_is_short(w):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    r1, r2 = _p2_r1r2(w)

    # Step 2
    step2 = [
        ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
        ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"), ("alli", "al"),
        ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"), ("iveness", "ive"),
        ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"), ("ogi", "og"),
        ("fulli", "ful"), ("lessli", "less"), ("li", ""),
    ]
    suf = _longest_suffix(w, [s for s, _ in step2])
    if suf is not None and len(w) - len(suf) >= r1:
        repl = dict(step2)[suf]
        if suf == "ogi":
            if w[-4:-3] == "l":
                w = w[:-3] + repl
        elif suf == "li":
            if w[-3:-2] in list(_P2_LI_ENDINGS):
                w = w[:-2]
        else:
            w = w[: -len(suf)] + repl

    # Step 3
    step3 = [
        ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
        ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
    ]
    suf = _longest_suffix(w, [s for s, _ in step3])
    if suf is not None:
        if suf == "ative":
            if len(w) - len(suf) >= r2:
                w = w[: -len(suf)]
        elif len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + dict(step3)[suf]

    # Step 4
    step4 = [
        "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
        "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
    ]
    suf = _longest_suffix(w, step4)
    if suf is not None and len(w) - len(suf) >= r2:
        if suf != "ion" or w[-4:-3] in ("s", "t"):
            w = w[: -len(suf)]

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_is_short(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


_STEMMERS_UNIMPLEMENTED_NOTE = (
    "Snowball stemming for %r is not implemented in this build (see NOTES.md)"
)


class SnowballStemmer(object):
    """Snowball stemmer for one of :data:`SNOWBALL_LANGUAGES`."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language: %r (supported: %s)"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            found = data.require(os.path.join("corpora", "stopwords", language))
            with open(found, encoding="utf-8") as handle:
                self._stopwords = set(line.strip().lower() for line in handle if line.strip())

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if self._stopwords is not None and w in self._stopwords:
            return w
        if self.language == "english":
            return english_stem(w)
        if self.language == "porter":
            return _porter_stem(w, "ORIGINAL")
        raise NotImplementedError(_STEMMERS_UNIMPLEMENTED_NOTE % self.language)


# ---------------------------------------------------------------------------
# Regular-expression stemmer (N-000178..N-000180)
# ---------------------------------------------------------------------------

class RegexpStemmer(object):
    """Removes every match of the caller's pattern from the word; nothing else changes."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# ---------------------------------------------------------------------------
# Families named by the Interface Contract whose stemming is outside this
# specification (N-000143..N-000146). Constructing them works; stemming raises.
# ---------------------------------------------------------------------------

class _OutOfScopeStemmer(object):
    _name = "stemmer"

    def stem(self, word):
        raise NotImplementedError("%s stemming is outside this specification" % self._name)


class ARLSTem(_OutOfScopeStemmer):
    _name = "ARLSTem"


class ARLSTem2(_OutOfScopeStemmer):
    _name = "ARLSTem2"


# ---------------------------------------------------------------------------
# WordNet lemmatizer (N-000185..N-000186, N-000432). Requires the WordNet resource.
# ---------------------------------------------------------------------------

_POS_FILES = {"n": "noun", "v": "verb", "a": "adj", "s": "adj", "r": "adv"}
_MORPHY = {
    "noun": [("s", ""), ("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
             ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "verb": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
             ("ing", "e"), ("ing", "")],
    "adj": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "adv": [],
}


class WordNetLemmatizer(object):
    """Lemmatizer over the packaged WordNet database files (``corpora/wordnet``)."""

    def __init__(self):
        self._dir = data.require(os.path.join("corpora", "wordnet"))
        self._lemmas = {}
        self._exceptions = {}

    def _load(self, name):
        if name in self._lemmas:
            return
        lemmas = set()
        index = os.path.join(self._dir, "index.%s" % name)
        if os.path.isfile(index):
            with open(index, encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    if line.startswith(" ") or not line.strip():
                        continue
                    lemmas.add(line.split(" ", 1)[0])
        exc = {}
        exc_file = os.path.join(self._dir, "%s.exc" % name)
        if os.path.isfile(exc_file):
            with open(exc_file, encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], parts[1])
        self._lemmas[name] = lemmas
        self._exceptions[name] = exc

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        name = _POS_FILES.get(pos)
        if name is None:
            raise ValueError("unknown part of speech %r" % (pos,))
        self._load(name)
        lemmas = self._lemmas[name]
        if word in self._exceptions[name]:
            return self._exceptions[name][word]
        if word in lemmas:
            return word
        for suffix, repl in _MORPHY[name]:
            if word.endswith(suffix) and len(word) > len(suffix):
                candidate = word[: -len(suffix)] + repl
                if candidate in lemmas:
                    return candidate
        return word
