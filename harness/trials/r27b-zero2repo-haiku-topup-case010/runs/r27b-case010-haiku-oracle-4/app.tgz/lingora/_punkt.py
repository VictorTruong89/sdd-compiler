"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

Spec: FP-01 "Sentence tokenizer"; Interface Contract ``sent_tokenize``.
The learned parameters (abbreviation types, collocations, sentence starters,
orthographic context) come from the packaged resource
``tokenizers/punkt_tab/<language>/`` (spec: ``lingora.data``, N-000389, N-000397..N-000402).

Decision rules follow the Punkt paper: a period-final token is first marked
as an abbreviation or a candidate break; a second pass uses collocations,
the orthographic heuristic and sentence-starter evidence on the next word.
"""

import os
import re

from . import data

# Bit flags of the orthographic context file (N-000402).
ORTHO_BEG_UC = 2
ORTHO_MID_UC = 4
ORTHO_UNK_UC = 8
ORTHO_BEG_LC = 16
ORTHO_MID_LC = 32
ORTHO_UNK_LC = 64
ORTHO_LC = ORTHO_BEG_LC | ORTHO_MID_LC | ORTHO_UNK_LC

_NUMBER = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"\.\.+$")
_CLOSERS = "\"')]}»”’>"
_OPENERS = "\"'([{«“‘"
_LANGUAGE = re.compile(r"[a-z_]+")


class PunktParameters(object):
    """Parameters loaded from one packaged Punkt model directory."""

    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


_cache = {}


def _read_lines(directory, name):
    full = os.path.join(directory, name)
    if not os.path.isfile(full):
        return []
    with open(full, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.strip()]


def load_parameters(language):
    """Load the packaged Punkt parameters for ``language``.

    Raises :class:`lingora.data.ResourceNotFound` when the model is not visible.
    """
    if not isinstance(language, str) or not _LANGUAGE.fullmatch(language):
        raise ValueError("unsupported Punkt language name: %r" % (language,))
    directory = data.require(os.path.join("tokenizers", "punkt_tab", language))
    key = os.path.abspath(directory)
    if key in _cache:
        return _cache[key]
    abbrev = set(line.strip().lower() for line in _read_lines(directory, "abbrev_types.txt"))
    starters = set(line.strip().lower() for line in _read_lines(directory, "sent_starters.txt"))
    collocations = set()
    for line in _read_lines(directory, "collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines(directory, "ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, collocations, starters, ortho)
    _cache[key] = params
    return params


class _Tok(object):
    __slots__ = (
        "start", "end", "typ", "tnp", "tns", "period_final", "ellipsis",
        "is_initial", "first_upper", "first_lower", "ab", "el", "sb",
    )


def _make_tokens(text, params):
    toks = []
    for match in re.finditer(r"\S+", text):
        raw = match.group()
        core = raw.rstrip(_CLOSERS) or raw
        lead = core.lstrip(_OPENERS) or core
        tok = _Tok()
        tok.start, tok.end = match.start(), match.end()
        tok.typ = _NUMBER.sub("##number##", core.lower())
        tok.period_final = core.endswith(".")
        tok.ellipsis = bool(_ELLIPSIS.search(core))
        tok.tnp = tok.typ[:-1] if tok.period_final else tok.typ
        tok.tns = tok.tnp if tok.period_final else tok.typ
        tok.is_initial = tok.period_final and len(core) == 2 and core[0].isalpha()
        tok.first_upper = lead[0].isupper()
        tok.first_lower = lead[0].islower()
        # First pass (Punkt 4.1 / 3.1): sentence-final marks, abbreviations, periods.
        tok.ab = False
        tok.el = False
        tok.sb = False
        if core[-1] in "?!":
            tok.sb = True
        elif tok.ellipsis:
            tok.el = True
        elif tok.period_final:
            base = tok.tnp
            last = base.split("-")[-1]
            if base in params.abbrev_types or last in params.abbrev_types:
                tok.ab = True
            else:
                tok.sb = True
        toks.append(tok)
    return toks


def _ortho(tok, params):
    """Orthographic heuristic: True (starter), False (not), or None (unknown)."""
    if tok.first_lower:
        return False
    if not tok.first_upper:
        return None
    oc = params.ortho_context.get(tok.tns, 0)
    if oc & ORTHO_BEG_UC and not oc & ORTHO_MID_UC:
        return True
    if oc & ORTHO_MID_UC and not oc & ORTHO_BEG_UC:
        return False
    return None


def _decide(tok, nxt, params):
    """Whether a sentence ends after ``tok`` when ``nxt`` follows (second pass)."""
    if not tok.period_final:
        return tok.sb
    typ = tok.tnp
    nt = nxt.tns
    if (typ, nt) in params.collocations:
        return False
    if tok.ab or tok.el:
        verdict = _ortho(nxt, params)
        if verdict is True:
            return True
        if nxt.first_upper and nt in params.sent_starters:
            return True
    if tok.is_initial or typ == "##number##":
        verdict = _ortho(nxt, params)
        if verdict is False:
            return False
        if verdict is None and tok.is_initial and nxt.first_upper and not (
            params.ortho_context.get(nt, 0) & ORTHO_LC
        ):
            return False
    return tok.sb


def sentence_spans(text, language="english"):
    """Return ``(start, end)`` character offsets of each sentence of ``text``."""
    params = load_parameters(language)
    toks = _make_tokens(text, params)
    spans = []
    if not toks:
        return spans
    start = toks[0].start
    last = len(toks) - 1
    for i, tok in enumerate(toks):
        is_break = True if i == last else _decide(tok, toks[i + 1], params)
        if is_break:
            spans.append((start, tok.end))
            if i != last:
                start = toks[i + 1].start
    return spans


def sentences(text, language="english"):
    """Return the sentences of ``text`` as strings, in original order."""
    return [text[s:e] for s, e in sentence_spans(text, language)]
