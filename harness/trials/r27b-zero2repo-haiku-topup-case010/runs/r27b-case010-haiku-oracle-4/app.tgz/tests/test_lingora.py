"""Tests for the lingora package. Run with: python -m pytest -q tests

Packaged models are not shipped, so the model-dependent paths are exercised
against small synthetic model directories written to a temporary location.
"""

import io
import json
import os
import sys
import contextlib

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402
from lingora import classify, chunk, grammar, metrics, stem, tag, tokenize, translate  # noqa: E402
from lingora.cli import cli  # noqa: E402
from lingora.data import ResourceNotFound  # noqa: E402
from lingora.grammar import CFG  # noqa: E402
from lingora.parse import ChartParser, ShiftReduceParser  # noqa: E402
from lingora.parse.generate import generate  # noqa: E402
from lingora.tree import Tree  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture(scope="module")
def model_dir(tmp_path_factory):
    """A synthetic packaged-data directory with a Punkt model, a tagger and a universal map."""
    root = str(tmp_path_factory.mktemp("lingora_data"))
    punkt = os.path.join(root, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "dr\nmr\nmrs\ne.g\ni\nst\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\nthey\nwe\n")
    _write(os.path.join(punkt, "collocations.tab"), "Mr\tSmith\n")
    _write(os.path.join(punkt, "ortho_context.tab"),
           "the\t16\nhe\t16\nsmith\t6\nthey\t18\nparis\t2\nit\t16\nmr\t4\ndr\t4\n")
    tagger = os.path.join(root, "taggers", "averaged_perceptron_tagger_eng")
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.weights.json"),
           json.dumps({"bias": {"NN": 1.0}, "i suffix ing": {"VBG": 2.0}}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.tagdict.json"),
           json.dumps({"the": "DT", "dog": "NN"}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.classes.json"),
           json.dumps(["DT", "NN", "VBG"]))
    _write(os.path.join(root, "taggers", "universal_tagset", "en-ptb.map"),
           "DT\tDET\nNN\tNOUN\nVBG\tVERB\n")
    return root


@pytest.fixture
def with_models(model_dir, monkeypatch):
    monkeypatch.setattr(data, "path", [model_dir])
    return model_dir


@pytest.fixture
def no_models(monkeypatch):
    monkeypatch.setattr(data, "path", [])


# --- data.path -------------------------------------------------------------

def test_data_path_empty_hides_resources(no_models):
    assert data.find("tokenizers/punkt_tab/english") is None
    with pytest.raises(ResourceNotFound):
        data.require("corpora/words")


# --- tokenizers ------------------------------------------------------------

def test_wordpunct_tokenize_runs_without_models(no_models):
    assert tokenize.wordpunct_tokenize("Hello, world! It's 3.14") == [
        "Hello", ",", "world", "!", "It", "'", "s", "3", ".", "14"]
    assert tokenize.wordpunct_tokenize("   ") == []


def test_wordpunct_spans():
    spans = list(tokenize.WordPunctTokenizer().span_tokenize("ab, cd"))
    assert spans == [(0, 2), (2, 3), (4, 6)]


def test_treebank_clitics_and_quotes():
    out = tokenize.TreebankWordTokenizer().tokenize('He said "hi," and it\'s "fine."')
    assert out[:4] == ["He", "said", "``", "hi"]
    assert "'s" in out
    assert "''" in out


def test_treebank_splits_fused_forms():
    out = tokenize.TreebankWordTokenizer().tokenize("We cannot go, gonna")
    assert "can" in out and "not" in out
    assert "gon" in out and "na" in out


def test_recommended_keeps_cannot_and_splits_ellipsis():
    out = tokenize._recommended_line("We cannot.... stop")
    assert "cannot" in out
    assert "...." in out


def test_recommended_leading_quote_is_closing():
    out = tokenize._recommended_line('"Hi" she said')
    assert out[0] == "''"


def test_tweet_tokenizer_keeps_emoticons_and_case():
    out = tokenize.TweetTokenizer().tokenize("@bob I LOVE this :) #yay http://x.co don't")
    assert "@bob" in out and ":)" in out and "#yay" in out and "http://x.co" in out
    assert "don't" in out and "LOVE" in out


def test_tweet_tokenizer_options():
    tk = tokenize.TweetTokenizer(preserve_case=False, reduce_len=True, strip_handles=True)
    out = tk.tokenize("@bob I LOVE this :D soooo")
    assert "bob" not in out
    assert "love" in out
    assert ":D" in out
    assert "sooo" in out


def test_blankline_and_whitespace_and_regexp():
    assert tokenize.blankline_tokenize("a b\n\n\n  c\nd \n \n e") == ["a b", "c\nd", "e"]
    assert tokenize.WhitespaceTokenizer().tokenize(" a\tb\n c ") == ["a", "b", "c"]
    assert tokenize.RegexpTokenizer(r"\d+").tokenize("a12b3c") == ["12", "3"]
    assert tokenize.RegexpTokenizer(r"\s*,\s*", gaps=True, discard_empty=True).tokenize(
        "a , b,c ,, d") == ["a", "b", "c", "d"]


def test_sent_tokenize_needs_model(no_models):
    with pytest.raises(ResourceNotFound):
        tokenize.sent_tokenize("Hello there. Bye.")
    with pytest.raises(ResourceNotFound):
        tokenize.word_tokenize("Hello there. Bye.")


def test_sent_tokenize_and_word_tokenize_with_model(with_models):
    assert tokenize.sent_tokenize("Hello there. The dog barked! Did it stop?") == [
        "Hello there.", "The dog barked!", "Did it stop?"]
    assert tokenize.sent_tokenize("Dr. Smith went to Paris. He left.") == [
        "Dr. Smith went to Paris.", "He left."]
    assert tokenize.sent_tokenize("He said hi... Then left.") == ["He said hi... Then left."]
    assert tokenize.word_tokenize("Dr. Smith went home.") == [
        "Dr.", "Smith", "went", "home", "."]
    assert tokenize.word_tokenize("No split here.", preserve_line=True) == [
        "No", "split", "here", "."]


def test_sent_tokenize_empty_text(with_models):
    assert tokenize.sent_tokenize("   ") == []


# --- stemmers --------------------------------------------------------------

@pytest.mark.parametrize("word,expected", [
    ("caresses", "caress"), ("ponies", "poni"), ("ties", "ti"), ("feed", "feed"),
    ("agreed", "agre"), ("plastered", "plaster"), ("motoring", "motor"),
    ("happy", "happi"), ("relational", "relat"), ("conditional", "condit"),
    ("generalization", "gener"), ("electrical", "electr"), ("controll", "control"),
    ("dying", "die"), ("a", "a"), ("ab", "ab"),
])
def test_porter_lingora_mode(word, expected):
    assert stem.PorterStemmer().stem(word) == expected


def test_porter_lowercasing_is_opt_in():
    assert stem.PorterStemmer().stem("Running") == "Run"  # case of the given letters is kept
    assert stem.PorterStemmer().stem("Running", to_lowercase=True) == "run"


def test_porter_original_mode():
    p = stem.PorterStemmer(mode="ORIGINAL")
    assert p.stem("generalization") == "gener"
    assert p.stem("oscillators") == "oscil"


@pytest.mark.parametrize("word,expected", [
    ("consigned", "consign"), ("consistency", "consist"), ("generously", "generous"),
    ("skies", "sky"), ("dying", "die"), ("news", "news"), ("happiness", "happi"),
    ("cried", "cri"), ("friendly", "friend"),
])
def test_snowball_english(word, expected):
    assert stem.SnowballStemmer("english").stem(word) == expected


def test_snowball_rejects_unknown_language_by_name():
    with pytest.raises(ValueError) as info:
        stem.SnowballStemmer("klingon")
    assert "klingon" in str(info.value)


def test_snowball_stopwords_require_list(no_models):
    with pytest.raises(ResourceNotFound):
        stem.SnowballStemmer("english", ignore_stopwords=True)


def test_lancaster_and_regexp_stemmer():
    lan = stem.LancasterStemmer()
    assert lan.stem("maximum") == "maxim"
    assert lan.stem("cats") == "cat"
    assert stem.RegexpStemmer(r"(ing|s)$").stem("running") == "runn"
    assert stem.RegexpStemmer(r"(ing|s)$").stem("dog") == "dog"


def test_wordnet_lemmatizer_needs_resource(no_models):
    with pytest.raises(ResourceNotFound):
        stem.WordNetLemmatizer()


# --- taggers ---------------------------------------------------------------

def test_default_unigram_regexp_taggers_and_backoff():
    train = [[("the", "DT"), ("dog", "NN")], [("dog", "NN"), ("runs", "VBZ")], [("dog", "VB")]]
    uni = tag.UnigramTagger(train=train, backoff=tag.DefaultTagger("UNK"))
    assert uni.tag(["the", "dog", "zzz"]) == [("the", "DT"), ("dog", "NN"), ("zzz", "UNK")]
    assert tag.UnigramTagger(train=train).tag(["zzz"]) == [("zzz", None)]
    assert tag.DefaultTagger("X").tag(["a", "b"]) == [("a", "X"), ("b", "X")]
    rx = tag.RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD")])
    assert rx.tag(["running", "12", "x"]) == [("running", "VBG"), ("12", "CD"), ("x", None)]
    assert tag.UnigramTagger().tag([]) == []


def test_tagger_rejects_string():
    with pytest.raises(TypeError):
        tag.DefaultTagger("X").tag("a b")


def test_pos_tag_recommended_needs_model(no_models):
    with pytest.raises(ResourceNotFound):
        tag.pos_tag(["the", "dog"])


def test_pos_tag_with_model(with_models):
    assert tag.pos_tag(["the", "dog", "running"]) == [
        ("the", "DT"), ("dog", "NN"), ("running", "VBG")]
    assert tag.pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]
    with pytest.raises(TypeError):
        tag.pos_tag("the dog")
    with pytest.raises(ValueError):
        tag.pos_tag(["x"], lang="fra")


# --- trees and grammars ----------------------------------------------------

def test_tree_basics():
    t = Tree.fromstring("(S (NP the dog) (VP (V barks) (ADV loudly)))")
    assert t.label() == "S"
    assert t.leaves() == ["the", "dog", "barks", "loudly"]
    assert len(t) == 2
    assert t[0] == Tree("NP", ["the", "dog"])
    assert t == Tree.fromstring(str(t))
    assert "S" in t.pformat() and "barks" in t.pformat()
    assert Tree("S", []).leaves() == []


def test_tree_refuses_bad_children():
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")


GRAMMAR = """
S -> NP VP
NP -> Det N | 'the' N
VP -> V NP | VP PP
PP -> P NP
V -> 'saw' | 'ate'
Det -> 'the' | 'a'
N -> 'man' | 'dog' | 'telescope'
P -> 'with'
"""


def test_cfg_reading():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions()) == 14
    rhs = g.productions("NP")[1].rhs()
    assert rhs[0] == "the" and not isinstance(rhs[0], grammar.Nonterminal)
    assert not isinstance(rhs[1], str)


def test_chart_parser_all_parses_and_errors():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the man saw the dog with a telescope".split()))
    assert len(trees) == 4
    assert all(t.leaves() == "the man saw the dog with a telescope".split() for t in trees)
    assert list(ChartParser(g).parse(["the", "man"])) == []
    with pytest.raises(ValueError):
        list(ChartParser(g).parse(["zebra"]))


def test_shift_reduce_parser():
    g = CFG.fromstring("S -> 'a' S | 'b'")
    out = list(ShiftReduceParser(g).parse(["a", "b"]))
    assert out == [Tree("S", ["a", Tree("S", ["b"])])]
    assert list(ShiftReduceParser(g).parse(["b", "a"])) == []


def test_chart_and_shift_reduce_agree_on_unambiguous():
    g = CFG.fromstring("S -> A B\nA -> 'x'\nB -> 'y'")
    assert list(ChartParser(g).parse(["x", "y"])) == list(ShiftReduceParser(g).parse(["x", "y"]))


def test_generate_bounded_and_complete():
    g = CFG.fromstring("S -> A B\nA -> 'x' | 'y'\nB -> 'z' | ''")
    assert sorted(" ".join(s) for s in generate(g)) == ["x", "x z", "y", "y z"]
    rec = CFG.fromstring("S -> 'a' S | 'b'")
    assert sorted(" ".join(s) for s in generate(rec, depth=3)) == sorted(["b", "a b", "a a b"])
    assert len(list(generate(rec, n=4))) == 4


# --- chunking --------------------------------------------------------------

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("chased", "VBD"),
          ("a", "DT"), ("cat", "NN"), (".", ".")]


def test_chunk_rule_and_cascade():
    parser = chunk.RegexpParser("NP: {<DT>?<JJ>*<NN.*>}\nVP: {<VB.*><NP>}")
    t = parser.parse(TAGGED)
    assert t.label() == "S"
    labels = [c.label() if isinstance(c, Tree) else c[0] for c in t]
    assert labels == ["NP", "VP", "."]
    assert t.leaves() == TAGGED


def test_chink_rule_splits_chunk():
    t = chunk.RegexpParser("NP: {<DT>?<JJ>*<NN>}\n}<JJ>{").parse(TAGGED)
    assert t[0] == Tree("NP", [("the", "DT")])
    assert t[1] == ("big", "JJ")
    assert t[2] == Tree("NP", [("dog", "NN")])


def test_chunk_repeat_braces_and_empty():
    assert chunk.RegexpParser("X: {<NN>{2}}").parse([("a", "NN"), ("b", "NN")]) == Tree(
        "S", [Tree("X", [("a", "NN"), ("b", "NN")])])
    assert chunk.RegexpParser([]).parse([]) == Tree("S", [])


def test_chunk_grammar_refused():
    with pytest.raises(TypeError):
        chunk.RegexpParser(42)


def test_ne_chunk_needs_resources(no_models):
    with pytest.raises(ResourceNotFound):
        chunk.ne_chunk(TAGGED)


# --- classifiers and metrics -----------------------------------------------

def test_naive_bayes():
    nb = classify.NaiveBayesClassifier.train([
        ({"a": 1, "b": 0}, "x"), ({"a": 1, "b": 1}, "x"),
        ({"a": 0, "b": 1}, "y"), ({"a": 0, "b": 0}, "y")])
    assert nb.classify({"a": 1, "b": 0}) == "x"
    assert nb.classify({"never": 5}) in ("x", "y")
    dist = nb.prob_classify({"a": 1, "b": 1})
    assert abs(sum(dist.prob(l) for l in dist.samples()) - 1.0) < 1e-9
    assert dist.prob("x") > dist.prob("y")
    assert sorted(nb.labels()) == ["x", "y"]


def test_decision_tree_separable():
    dt = classify.DecisionTreeClassifier.train([
        ({"f": "a"}, "p"), ({"f": "b"}, "q"), ({"f": "c"}, "p")])
    assert [dt.classify({"f": v}) for v in "abc"] == ["p", "q", "p"]
    assert dt.classify({"other": 1}) in ("p", "q")


def test_classifier_accuracy_and_training_errors():
    dt = classify.DecisionTreeClassifier.train([({"f": 1}, "p"), ({"f": 2}, "q")])
    assert classify.accuracy(dt, [({"f": 1}, "p"), ({"f": 2}, "p")]) == 0.5
    with pytest.raises(ValueError):
        classify.NaiveBayesClassifier.train([])


def test_metrics_values():
    assert metrics.accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    assert metrics.edit_distance("kitten", "sitting") == 3
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("ab", "ba") == 2
    assert metrics.edit_distance("ca", "abc", transpositions=True) == 3
    assert metrics.edit_distance("", "") == 0
    assert metrics.edit_distance("a", "b", substitution_cost=2) == 2
    assert metrics.jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert metrics.precision({1, 2}, {2, 3}) == 0.5
    assert metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)


def test_metrics_no_number_and_refusals():
    assert metrics.precision({1}, set()) is None
    assert metrics.recall(set(), {1}) is None
    assert metrics.f_measure({1}, {2}) is None
    assert metrics.f_measure({1}, set()) is None
    with pytest.raises(TypeError):
        metrics.precision([1], [1])
    with pytest.raises(ValueError):
        metrics.accuracy([1], [1, 2])
    with pytest.raises(TypeError):
        metrics.edit_distance("a", "b", substitution_cost=True)


def test_bleu():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert translate.bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert translate.bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) == pytest.approx(
        0.7071067811865476)
    assert translate.bleu(ref, ["a", "b", "c"]) == 0.0
    assert translate.bleu(ref, ["the", "cat", "is", "on", "the", "mat"],
                          weights=(0.25, 0.25, 0.25, 0.25)) > 0.0


# --- command line ----------------------------------------------------------

def test_cli_tokenize_writes_lines(with_models, monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Dr. Smith went home. They were tired.\n"))
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        with pytest.raises(SystemExit) as info:
            cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code == 0
    assert out.getvalue() == "Dr. Smith went home . They were tired .\n"


def test_cli_fails_without_model(no_models, monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello there.\n"))
    out = io.StringIO()
    err = io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        with pytest.raises(SystemExit) as info:
            cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code != 0
    assert out.getvalue() == ""
