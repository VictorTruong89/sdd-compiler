"""Behavioural tests for LINGORA, derived from the Full PRD and Interface Contract."""

import io
import os
import sys

import pytest

from lingora import data
from lingora import classify, metrics, tag, tokenize
from lingora.chunk import RegexpParser
from lingora.cli import cli
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def punkt_dir(tmp_path, monkeypatch):
    base = tmp_path / "tokenizers" / "punkt_tab" / "english"
    base.mkdir(parents=True)
    (base / "abbrev_types.txt").write_text("mr\ndr\nmrs\n", encoding="utf-8")
    (base / "sent_starters.txt").write_text("the\nhe\nshe\nit\n", encoding="utf-8")
    (base / "collocations.tab").write_text("j.\tbach\n", encoding="utf-8")
    (base / "ortho_context.tab").write_text(
        "mr\t4\nsmith\t32\nwent\t32\nhome\t32\nthe\t18\nhe\t18\n", encoding="utf-8"
    )
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    return tmp_path


def test_wordpunct_and_spans():
    assert tokenize.wordpunct_tokenize("Hi, there! $3.50") == ["Hi", ",", "there", "!", "$", "3", ".", "50"]
    text = "ab, cd"
    spans = tokenize.WordPunctTokenizer().span_tokenize(text)
    assert [text[s:e] for s, e in spans] == ["ab", ",", "cd"]
    assert tokenize.WordPunctTokenizer().tokenize("") == []
    assert tokenize.WordPunctTokenizer().tokenize("  \n ") == []


def test_treebank_rules():
    tb = tokenize.TreebankWordTokenizer()
    assert tb.tokenize("They'll save and invest more.") == ["They", "'ll", "save", "and", "invest", "more", "."]
    assert tb.tokenize("I can't go") == ["I", "ca", "n't", "go"]
    assert tb.tokenize('He said "hi"') == ["He", "said", "``", "hi", "''"]
    assert tb.tokenize("cannot") == ["can", "not"]
    assert tb.tokenize("costs 3,000 and 3.88 dollars") == ["costs", "3,000", "and", "3.88", "dollars"]
    assert tb.tokenize("wanna gonna") == ["wan", "na", "gon", "na"]


def test_recommended_word_tokenizer_preserve_line():
    wt = lambda s: tokenize.word_tokenize(s, preserve_line=True)
    assert wt("cannot stop") == ["cannot", "stop"]
    assert wt("wait -- what") == ["wait", "--", "what"]
    assert "..." in wt("so...")


def test_whitespace_blankline_regexp_tweet():
    assert tokenize.WhitespaceTokenizer().tokenize(" a\tb\n c ") == ["a", "b", "c"]
    assert tokenize.blankline_tokenize("a\nb\n\n\n c\n\n") == ["a\nb", "c"]
    assert tokenize.RegexpTokenizer(r"\d+").tokenize("a1bb22") == ["1", "22"]
    assert tokenize.RegexpTokenizer(r",", gaps=True).tokenize("a,,b,") == ["a", "b"]
    assert tokenize.RegexpTokenizer(r",", gaps=True, discard_empty=False).tokenize("a,,b") == ["a", "", "b"]
    tw = tokenize.TweetTokenizer(preserve_case=False)
    assert tw.tokenize("@bob LOVE :-) #Yay http://x.org") == ["@bob", "love", ":-)", "#yay", "http://x.org"]
    assert tokenize.TweetTokenizer().tokenize("LOVE") == ["LOVE"]
    assert tokenize.TweetTokenizer(strip_handles=True).tokenize("hi @bob there") == ["hi", "there"]
    assert tokenize.TweetTokenizer(reduce_len=True).tokenize("yaaaaay") == ["yaaay"]


def test_sentence_tokenizer_requires_model(monkeypatch, tmp_path):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(Exception):
        tokenize.sent_tokenize("Hello there.")
    with pytest.raises(Exception):
        tokenize.word_tokenize("Hello there.")


def test_sentence_splitting_with_model(punkt_dir):
    sents = tokenize.sent_tokenize("Hello there. Mr. Smith went home. He said hi! Is it? Yes.")
    assert sents == ["Hello there.", "Mr. Smith went home.", "He said hi!", "Is it?", "Yes."]
    assert tokenize.sent_tokenize("") == []
    assert tokenize.word_tokenize("Hi there. Bye.") == ["Hi", "there", ".", "Bye", "."]


def test_stemmers():
    p = PorterStemmer()
    assert p.stem("ties") == "tie"
    assert p.stem("caresses") == "caress"
    assert p.stem("at") == "at"
    assert p.stem("died") == "die"
    assert p.stem("cried") == "cri"
    assert p.stem("dying") == "die"
    assert p.stem("Running", to_lowercase=True) == "run"
    assert PorterStemmer("original").stem("ties") == "ti"
    assert LancasterStemmer().stem("maximum") == "maxim"
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("cried") == "cri"
    with pytest.raises(Exception) as err:
        SnowballStemmer("klingon")
    assert "klingon" in str(err.value)
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("walk") == "walk"


def test_snowball_stopwords_require_list(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(Exception):
        SnowballStemmer("english", ignore_stopwords=True)


def test_default_and_unigram_taggers():
    assert tag.DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert tag.DefaultTagger("NN").tag([]) == []
    train = [[("the", "DT"), ("dog", "NN")], [("dog", "VB")], [("dog", "NN")]]
    u = tag.UnigramTagger(train=train)
    assert u.tag(["the", "dog", "cat"]) == [("the", "DT"), ("dog", "NN"), ("cat", None)]
    ub = tag.UnigramTagger(train=train, backoff=tag.DefaultTagger("X"))
    assert ub.tag(["cat"]) == [("cat", "X")]
    r = tag.RegexpTagger([(r".*ing$", "VBG"), (r"\d+$", "CD")])
    assert r.tag(["running", "42", "x"]) == [("running", "VBG"), ("42", "CD"), ("x", None)]


def test_pos_tag_refusals(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(TypeError):
        tag.pos_tag("a b")
    with pytest.raises(Exception):
        tag.pos_tag(["a"])
    with pytest.raises(Exception):
        tag.pos_tag(["a"], lang="fra")


def test_regexp_chunking():
    tagged = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("the", "DT"), ("cat", "NN")]
    t = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(tagged)
    assert t.label() == "S"
    assert [c.label() for c in t if isinstance(c, Tree)] == ["NP", "NP"]
    assert t.leaves() == tagged
    cascade = RegexpParser("NP: {<DT>?<JJ>*<NN>}\nVP: {<NP><VBD>}").parse(tagged)
    assert any(isinstance(c, Tree) and c.label() == "VP" for c in cascade)
    chink = RegexpParser("NP: {<.*>+}\n    }<VBD>{").parse(tagged)
    assert sum(1 for c in chink if isinstance(c, Tree)) == 2
    assert RegexpParser("S: {<NN>}").parse([]) == Tree("S", [])
    with pytest.raises(TypeError):
        RegexpParser(42)


GRAMMAR = """
S -> NP VP
NP -> Det N | 'John'
VP -> V NP | VP PP
PP -> P NP
Det -> 'the' | 'a'
N -> 'man' | 'dog' | 'park'
V -> 'saw'
P -> 'with'
"""


def test_chart_and_shift_reduce():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    toks = "John saw the dog with the man".split()
    trees = list(ChartParser(g).parse(toks))
    assert len(trees) == 1
    for t in trees:
        assert t.label() == "S" and t.leaves() == toks
    assert list(ChartParser(g).parse(["John", "saw"])) == []
    with pytest.raises(Exception):
        ChartParser(g).parse(["zebra"])
    sr = list(ShiftReduceParser(CFG.fromstring("S -> 'a' 'b'")).parse(["a", "b"]))
    assert len(sr) == 1
    assert sr[0] == Tree("S", ["a", "b"])


def test_generate_bounds():
    g = CFG.fromstring('S -> "a" S | "b"')
    assert list(generate(g, depth=4)) == [["a", "a", "a", "b"], ["a", "a", "b"], ["a", "b"], ["b"]]
    assert len(list(generate(g, depth=6, n=3))) == 3


def test_trees():
    assert Tree("NP", ["dog"]) != Tree("VP", ["dog"])
    with pytest.raises(TypeError):
        Tree("NP", "dog")
    with pytest.raises(TypeError):
        Tree("NP")
    assert len(Tree("X", [])) == 0
    t = Tree.fromstring("(S (NP a b) c)")
    assert t[1] == "c" and len(t) == 2 and t[0][1] == "b"
    assert t == Tree("S", [Tree("NP", ["a", "b"]), "c"])
    assert "a" in t.pformat() and "c" in t.pformat()


def test_classifiers():
    train = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "fine"}, "pos"), ({"w": "awful"}, "neg")]
    nb = classify.NaiveBayesClassifier.train(train)
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"w": "never"}) in ("pos", "neg")
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(l) for l in dist.samples()) - 1.0) < 1e-9
    assert sorted(nb.labels()) == ["neg", "pos"]
    dt = classify.DecisionTreeClassifier.train(train)
    assert [dt.classify(fs) for fs, _ in train] == [l for _, l in train]
    assert dt.classify({"zzz": 1}) in ("pos", "neg")
    assert classify.accuracy(dt, train) == 1.0


def test_metrics():
    assert metrics.edit_distance("kitten", "sitting") == 3
    assert metrics.edit_distance("ca", "ac") == 2
    assert metrics.edit_distance("ca", "ac", transpositions=True) == 1
    assert metrics.edit_distance("", "") == 0
    assert metrics.jaccard_distance({1, 2, 3}, {2, 3, 4}) == 0.5
    assert metrics.accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(Exception):
        metrics.accuracy([1], [1, 2])
    assert metrics.precision({1, 2}, {2, 3}) == 0.5
    assert metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)
    assert metrics.precision({1}, set()) is None
    assert metrics.recall(set(), {1}) is None
    assert metrics.f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        metrics.precision([1], {1})


def test_bleu():
    ref = "the cat is on the mat".split()
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([ref], ["the", "cat"]) == pytest.approx(0.1353352832366127)
    assert bleu([ref], ["a", "b", "c", "d"]) == 0.0


def test_cli_tokenize(punkt_dir, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there. Bye.\nSecond one\n"))
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exc.value.code == 0
    assert capsys.readouterr().out == "Hi there . Bye .\nSecond one\n"


def test_cli_fails_without_model(monkeypatch, capsys):
    monkeypatch.setattr(data, "path", [])
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hi there.\n"))
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exc.value.code != 0
    assert capsys.readouterr().out == ""
