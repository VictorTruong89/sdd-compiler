"""Constituent trees with bracketed-text input and pretty printing."""

import re

__all__ = ["Tree"]

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree(list):
    """A labelled ordered tree. Children are strings or tuples (leaves) or Trees.

    ``Tree(label, children)``; ``children`` must be a list (a ``str`` or a
    missing argument is refused).
    """

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        list.__init__(self, children)
        self._label = label

    # -- construction -------------------------------------------------
    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring expects a str")
        tokens = _TOKEN_RE.findall(s)
        pos = [0]

        def parse_node():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in "()":
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while pos[0] < len(tokens) and tokens[pos[0]] != ")":
                if tokens[pos[0]] == "(":
                    children.append(parse_node())
                else:
                    children.append(tokens[pos[0]])
                    pos[0] += 1
            if pos[0] >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            pos[0] += 1  # consume ')'
            return cls(label, children)

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree

    # -- accessors ----------------------------------------------------
    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    # -- comparison ---------------------------------------------------
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    # -- printing -----------------------------------------------------
    def _one_line(self):
        parts = [str(self._label)]
        for child in self:
            if isinstance(child, Tree):
                parts.append(child._one_line())
            else:
                parts.append(_leaf_text(child))
        return "(" + " ".join(parts) + ")"

    def _block(self, indent):
        """Layout for ``pformat``: a subtree that fits on the rest of its
        line is printed on one line; otherwise children go on their own lines."""
        one = self._one_line()
        if indent + len(one) <= 70:
            return one
        head = "(" + str(self._label)
        lines = []
        for child in self:
            if isinstance(child, Tree):
                lines.append(" " * (indent + 2) + child._block(indent + 2))
            else:
                lines.append(" " * (indent + 2) + _leaf_text(child))
        if not lines:
            return head + ")"
        lines[-1] = lines[-1] + ")"
        return head + "\n" + "\n".join(lines)

    def pformat(self, margin=70):
        one = self._one_line()
        if len(one) <= margin:
            return one
        return self._block(0)

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()


def _leaf_text(leaf):
    if isinstance(leaf, tuple):
        return "/".join(str(x) for x in leaf)
    return str(leaf)
