"""Evaluation metrics: accuracy, edit distance, Jaccard distance, precision, recall, f-measure."""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def accuracy(reference, test):
    """Fraction of positions at which ``reference`` and ``test`` hold equal values.
    Lists of different lengths are refused. Two empty lists give 0.0."""
    if isinstance(reference, (str, bytes)) or isinstance(test, (str, bytes)):
        raise TypeError("accuracy expects lists")
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy requires lists of equal length")
    if not reference:
        return 0.0
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions=True`` the unrestricted
    Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance expects two strings")
    if not transpositions:
        return _levenshtein(s1, s2, substitution_cost)
    return _lowrance_wagner(s1, s2, substitution_cost)


def _levenshtein(s1, s2, sub):
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            if s1[i - 1] == s2[j - 1]:
                c = 0
            else:
                c = sub
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
        prev = cur
    return prev[len(s2)]


def _lowrance_wagner(s1, s2, sub):
    len1, len2 = len(s1), len(s2)
    maxdist = len1 + len2
    d = [[0] * (len2 + 2) for _ in range(len1 + 2)]
    d[0][0] = maxdist
    for i in range(len1 + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len2 + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    da = {}
    for i in range(1, len1 + 1):
        db = 0
        for j in range(1, len2 + 1):
            k = da.get(s2[j - 1], 0)
            l = db
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        da[s1[i - 1]] = i
    return d[len1 + 1][len2 + 1]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference over the size of the union (0.0 for two empty sets)."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance expects sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision/recall/f_measure expect sets")


def precision(reference, test):
    """|reference & test| / |test|; None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1-alpha)/recall).
    None when either set is empty or the sets share no element."""
    _check_sets(reference, test)
    if not reference or not test:
        return None
    shared = len(reference & test)
    if shared == 0:
        return None
    p = shared / len(test)
    r = shared / len(reference)
    return 1.0 / (alpha / p + (1.0 - alpha) / r)
