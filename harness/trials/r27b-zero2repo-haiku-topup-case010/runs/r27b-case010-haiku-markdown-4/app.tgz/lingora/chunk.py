"""Regular-expression chunk parser over tagged tokens, and the named-entity
chunker entry (which requires its packaged model)."""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ChunkRule", "ChinkRule", "ne_chunk", "SENTENCE_LABEL"]

SENTENCE_LABEL = "S"

_QUANT_OR_ELEMENT_RE = re.compile(r"\s*<([^<>]*)>\s*(\?|\*|\+|\{\d*,?\d*\})?\s*")


class ChunkRule:
    """A chunk stage: tokens matching ``tag_pattern`` become a chunk labelled ``label``."""

    kind = "chunk"

    def __init__(self, label, tag_pattern):
        self.label = label
        self.tag_pattern = tag_pattern
        self._re = _compile_tag_pattern(tag_pattern)

    def __repr__(self):
        return "ChunkRule(%r, %r)" % (self.label, self.tag_pattern)


class ChinkRule:
    """A chink stage: tokens matching ``tag_pattern`` are removed from this clause's chunks."""

    kind = "chink"

    def __init__(self, label, tag_pattern):
        self.label = label
        self.tag_pattern = tag_pattern
        self._re = _compile_tag_pattern(tag_pattern)

    def __repr__(self):
        return "ChinkRule(%r, %r)" % (self.label, self.tag_pattern)


def _compile_tag_pattern(pattern):
    if not isinstance(pattern, str):
        raise TypeError("tag pattern must be str")
    parts = []
    pos = 0
    stripped = pattern
    while pos < len(stripped):
        if stripped[pos].isspace():
            pos += 1
            continue
        m = _QUANT_OR_ELEMENT_RE.match(stripped, pos)
        if not m:
            raise ValueError("bad tag pattern near %r" % stripped[pos:])
        content = m.group(1).replace(".", "[^<>]")
        quant = m.group(2) or ""
        parts.append("(?:<(?:%s)>)%s" % (content, quant))
        pos = m.end()
    return re.compile("".join(parts))


def _find_spans(tags, regex):
    """Non-overlapping, left-to-right matches over a tag sequence, as (start, end) unit indices."""
    encoded = "".join("<%s>" % t for t in tags)
    spans = []
    for m in regex.finditer(encoded):
        if m.end() == m.start():
            continue
        spans.append((encoded.count("<", 0, m.start()), encoded.count("<", 0, m.end())))
    return spans


def _tag_of(unit):
    if isinstance(unit, Tree):
        return unit.label()
    tag = unit[1]
    return "" if tag is None else str(tag)


def _split_grammar(text):
    """Parse grammar text into a list of (label, kind, body) stages."""
    stages = []
    label = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0] if "#" in raw and not raw.lstrip().startswith("<") else raw
        if not line.strip():
            continue
        indented = line[0].isspace()
        body = line.strip()
        if not indented:
            m = re.match(r"^([^\s:{}<>]+)\s*:(.*)$", body)
            if not m:
                raise ValueError("grammar clause must start with '<LABEL>:': %r" % raw)
            label = m.group(1)
            body = m.group(2).strip()
        if label is None:
            raise ValueError("grammar pattern without a clause label: %r" % raw)
        pos = 0
        while pos < len(body):
            c = body[pos]
            if c.isspace():
                pos += 1
            elif c == "{":
                depth = 0
                end = None
                for j in range(pos, len(body)):
                    if body[j] == "{":
                        depth += 1
                    elif body[j] == "}":
                        depth -= 1
                        if depth == 0:
                            end = j
                            break
                if end is None:
                    raise ValueError("unbalanced '{' in grammar: %r" % body)
                stages.append((label, "chunk", body[pos + 1:end]))
                pos = end + 1
            elif c == "}":
                m = re.compile(r"\{(?![\d,])").search(body, pos + 1)
                if not m:
                    raise ValueError("chink rule without closing '{': %r" % body)
                stages.append((label, "chink", body[pos + 1:m.start()]))
                pos = m.end()
            else:
                raise ValueError("unexpected text in grammar: %r" % body[pos:])
    return stages


def _apply_chunk(root, rule, clause_ids, new_ids):
    """Apply one chunk rule. Matches are searched among units not already in a
    chunk of this clause; each match becomes a chunk. A new chunk that touches an
    existing chunk of this clause is joined into it."""
    matches = []
    run = []
    runs = []
    for k, unit in enumerate(root):
        if id(unit) in clause_ids:
            if run:
                runs.append(run)
                run = []
        else:
            run.append(k)
    if run:
        runs.append(run)
    for run in runs:
        tags = [_tag_of(root[k]) for k in run]
        for s, e in _find_spans(tags, rule._re):
            matches.append((run[s], run[e - 1] + 1))
    if not matches:
        return root
    matches.sort()
    out = []
    k = 0
    mi = 0
    while k < len(root):
        if mi < len(matches) and matches[mi][0] == k:
            s, e = matches[mi]
            mi += 1
            chunk = Tree(rule.label, root[s:e])
            # join with an adjacent chunk of this clause (no token between)
            if out and id(out[-1]) in clause_ids and out[-1].label() == rule.label and not _is_new(out[-1], new_ids):
                out[-1].extend(chunk)
                k = e
                continue
            clause_ids.add(id(chunk))
            new_ids.add(id(chunk))
            out.append(chunk)
            k = e
        else:
            unit = root[k]
            out.append(unit)
            k += 1
    # a chunk that now touches an older chunk on its right is joined into it
    merged = []
    for unit in out:
        if (
            merged
            and isinstance(unit, Tree)
            and id(unit) in new_ids
            and id(merged[-1]) in clause_ids
            and id(merged[-1]) not in new_ids
            and merged[-1].label() == unit.label()
        ):
            merged[-1].extend(unit)
            clause_ids.discard(id(unit))
            continue
        merged.append(unit)
    return merged


def _is_new(unit, new_ids):
    return id(unit) in new_ids


def _apply_chink(root, rule, clause_ids, new_ids):
    out = []
    for unit in root:
        if not (isinstance(unit, Tree) and id(unit) in clause_ids):
            out.append(unit)
            continue
        children = list(unit)
        tags = [_tag_of(c) for c in children]
        spans = _find_spans(tags, rule._re)
        if not spans:
            out.append(unit)
            continue
        chinked = set()
        for s, e in spans:
            chinked.update(range(s, e))
        cur = []
        for idx, child in enumerate(children):
            if idx in chinked:
                if cur:
                    piece = Tree(unit.label(), cur)
                    clause_ids.add(id(piece))
                    out.append(piece)
                    cur = []
                out.append(child)
            else:
                cur.append(child)
        if cur:
            piece = Tree(unit.label(), cur)
            clause_ids.add(id(piece))
            out.append(piece)
        clause_ids.discard(id(unit))
    return out


class RegexpParser:
    """Chunk parser built from a chunk grammar (text) or a list of stages."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = []
            for label, kind, body in _split_grammar(grammar):
                if kind == "chunk":
                    stage = ChunkRule(label, body)
                else:
                    stage = ChinkRule(label, body)
                if self._clauses and self._clauses[-1][0] == label:
                    self._clauses[-1][1].append(stage)
                else:
                    self._clauses.append((label, [stage]))
        elif isinstance(grammar, list):
            self._clauses = []
            for stage in grammar:
                if not isinstance(stage, (ChunkRule, ChinkRule)):
                    raise TypeError("grammar stages must be ChunkRule or ChinkRule objects")
                if self._clauses and self._clauses[-1][0] == stage.label:
                    self._clauses[-1][1].append(stage)
                else:
                    self._clauses.append((stage.label, [stage]))
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("parse expects a list of (token, tag) pairs")
        root = []
        for item in tagged:
            if not (isinstance(item, (tuple, list)) and len(item) == 2):
                raise TypeError("tagged tokens must be (token, tag) pairs")
            root.append((item[0], item[1]))
        for _label, stages in self._clauses:
            clause_ids = set()
            for stage in stages:
                new_ids = set()
                if stage.kind == "chunk":
                    root = _apply_chunk(root, stage, clause_ids, new_ids)
                else:
                    root = _apply_chink(root, stage, clause_ids, new_ids)
        return Tree(SENTENCE_LABEL, root)


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires its packaged model and the English wordlist."""
    if not data.is_visible("chunkers/maxent_ne_chunker_tab/english_ace_multiclass"):
        raise LookupError("named-entity chunker model is not installed")
    if not data.is_visible("corpora/words"):
        raise LookupError("English wordlist (corpora/words) is not installed")
    raise NotImplementedError("named-entity chunking is outside the LINGORA specification")
