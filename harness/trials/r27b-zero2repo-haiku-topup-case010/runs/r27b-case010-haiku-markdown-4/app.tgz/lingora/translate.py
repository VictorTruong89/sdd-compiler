"""BLEU score over token lists (Papineni et al., 2002)."""

import math
from collections import Counter

__all__ = ["bleu", "add_one_smoothing"]


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def add_one_smoothing(pairs):
    """Example smoothing function: add one to numerators and denominators.
    Takes a list of (numerator, denominator) pairs, returns precisions."""
    return [(num + 1) / (den + 1) for num, den in pairs]


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against one or more ``references``.

    ``weights`` gives one weight per n-gram order starting from unigrams; by
    default unigrams and bigrams are weighted equally. Without a smoothing
    function the score is 0 when any weighted order has no match.
    ``smoothing_function`` maps a list of (numerator, denominator) pairs to a
    list of precisions.
    """
    if isinstance(references, (str, bytes)) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    if isinstance(hypothesis, (str, bytes)):
        raise TypeError("hypothesis must be a token list")
    refs = [list(r) for r in references]
    hyp = list(hypothesis)
    weights = list(weights)
    if not refs:
        raise ValueError("at least one reference is required")
    if not weights:
        raise ValueError("weights must not be empty")
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")

    if not hyp:
        return 0.0

    pairs = []
    for n in range(1, len(weights) + 1):
        counts = Counter(_ngrams(hyp, n))
        max_ref = Counter()
        for ref in refs:
            for gram, c in Counter(_ngrams(ref, n)).items():
                if c > max_ref[gram]:
                    max_ref[gram] = c
        clipped = sum(min(c, max_ref[g]) for g, c in counts.items())
        denom = max(0, len(hyp) - n + 1)
        pairs.append((clipped, denom))

    if smoothing_function is None:
        precisions = []
        for (num, den), w in zip(pairs, weights):
            if num == 0 or den == 0:
                if w > 0:
                    return 0.0
                precisions.append(1.0)
            else:
                precisions.append(num / den)
    else:
        precisions = list(smoothing_function(pairs))

    log_sum = 0.0
    for p, w in zip(precisions, weights):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)

    c = len(hyp)
    ref_len = min((len(r) for r in refs), key=lambda r: (abs(r - c), r))
    if c > ref_len:
        bp = 1.0
    else:
        bp = math.exp(1 - ref_len / c)
    return bp * math.exp(log_sum)
