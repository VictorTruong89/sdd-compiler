"""Tokenizers: word/punctuation, Penn Treebank, recommended word tokenizer,
Punkt sentence tokenizer, whitespace, blank-line, regular-expression and tweet
tokenizers, plus span extraction."""

import os
import re
import threading

from lingora import data

__all__ = [
    "TokenizerI",
    "WordPunctTokenizer",
    "TreebankWordTokenizer",
    "WhitespaceTokenizer",
    "RegexpTokenizer",
    "TweetTokenizer",
    "wordpunct_tokenize",
    "word_tokenize",
    "sent_tokenize",
    "blankline_tokenize",
    "PunktParameters",
    "PunktSentenceTokenizer",
    "PunktModelNotFound",
]


class PunktModelNotFound(LookupError):
    """The Punkt sentence models for the requested language are not visible."""


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------

class TokenizerI:
    def tokenize(self, text):  # pragma: no cover - abstract
        raise NotImplementedError

    def span_tokenize(self, text):
        """Return ``(start, end)`` offsets, one per token, in token order."""
        spans = []
        pos = 0
        for token in self.tokenize(text):
            idx = text.find(token, pos)
            if idx < 0:
                raise ValueError("token %r cannot be located in the input" % token)
            spans.append((idx, idx + len(token)))
            pos = idx + len(token)
        return spans


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be str, not %s" % type(text).__name__)


# ---------------------------------------------------------------------------
# Word/punctuation and whitespace tokenizers
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer(TokenizerI):
    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in _WORDPUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer(TokenizerI):
    _RE = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in self._RE.finditer(text)]


_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    _check_text(text)
    return [piece for piece in _BLANKLINE_SEP.split(text) if piece.strip()]


# ---------------------------------------------------------------------------
# Regular-expression tokenizer
# ---------------------------------------------------------------------------

class RegexpTokenizer(TokenizerI):
    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be str")
        self._pattern = pattern
        self._re = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _pieces(self, text):
        """Return (start, end) spans of the tokens."""
        spans = []
        if self._gaps:
            pos = 0
            for m in self._re.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            for m in self._re.finditer(text):
                spans.append((m.start(), m.end()))
        if self._discard_empty:
            spans = [s for s in spans if s[1] > s[0]]
        return spans

    def tokenize(self, text):
        _check_text(text)
        return [text[s:e] for s, e in self._pieces(text)]

    def span_tokenize(self, text):
        _check_text(text)
        return self._pieces(text)


# ---------------------------------------------------------------------------
# Penn Treebank word tokenizer and LINGORA's recommended word tokenizer
# ---------------------------------------------------------------------------

_TB_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r"([ (\[{<])(\"|'{2})"), r"\1 `` "),
]

_TB_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]

_TB_PARENS = re.compile(r"[\]\[\(\)\{\}<>]")

_TB_CLITICS = re.compile(r"(?i)([^\s'])(n't|'ll|'re|'ve|'s|'m|'d)\b")
_TB_BARE_APOS = re.compile(r"([^\s'])'(?=\s|$)")

_TB_CONTRACTIONS2 = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
]
_TB_CONTRACTIONS3 = [
    (re.compile(r"(?i)(^|\s)('t)(is)\b"), r"\1\2 \3"),
    (re.compile(r"(?i)(^|\s)('t)(was)\b"), r"\1\2 \3"),
]

# Improved (recommended) tokenizer extras.
_IMP_TYPOGRAPHIC_QUOTES = re.compile("([“”‘’„«»])")
_IMP_STRAIGHT_LEADING_DQ = re.compile(r'^"')
_IMP_DASHES_ASTERISKS = re.compile("([‒–—―*])")
_IMP_DOUBLE_HYPHEN = re.compile(r"--")
_IMP_POINT_RUN = re.compile(r"\.{2,}")


def _treebank_core(text, improved):
    if improved:
        text = _IMP_TYPOGRAPHIC_QUOTES.sub(r" \1 ", text)
        text = _IMP_STRAIGHT_LEADING_DQ.sub("'' ", text)
        for regex, repl in _TB_STARTING_QUOTES[1:]:
            text = regex.sub(repl, text)
        text = _IMP_DASHES_ASTERISKS.sub(r" \1 ", text)
        text = _IMP_POINT_RUN.sub(lambda m: " " + m.group(0) + " ", text)
        text = _IMP_DOUBLE_HYPHEN.sub(" -- ", text)
    else:
        for regex, repl in _TB_STARTING_QUOTES:
            text = regex.sub(repl, text)

    # Pad so that the end-of-text rules see a following space.
    text = " " + text + " "
    for regex, repl in _TB_PUNCTUATION:
        text = regex.sub(repl, text)
    text = _TB_PARENS.sub(lambda m: " " + m.group(0) + " ", text)
    if improved:
        text = re.sub(r"[\"]", " '' ", text)
        text = text.replace("''", " '' ")
    else:
        text = text.replace("''", " '' ")
        text = text.replace('"', " '' ")
    text = _TB_CLITICS.sub(r"\1 \2", text)
    text = _TB_BARE_APOS.sub(r"\1 '", text)
    for regex, repl in _TB_CONTRACTIONS2:
        if improved and regex.pattern == r"(?i)\b(can)(not)\b":
            continue
        text = regex.sub(repl, text)
    for regex, repl in _TB_CONTRACTIONS3:
        text = regex.sub(repl, text)
    return text.split()


class TreebankWordTokenizer(TokenizerI):
    """Penn Treebank word tokenizer."""

    def tokenize(self, text):
        _check_text(text)
        return _treebank_core(text, improved=False)


def _word_tokenize_line(text):
    return _treebank_core(text, improved=True)


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON_RE = re.compile(
    r"[:;=]['\-]?[)(\]\[dDpP/\\|]"   # :-) :( ;D =P
    r"|[)(\]\[dDpP/\\|]['\-]?[:;=]"   # (: D:
    r"|<3"                                # heart
    r"|[xX]D"                             # xD
    r"|\^_\^"
    r"|o_O|O_o|-_-"
)
_URL_RE = re.compile(r"(?:https?://|www\.)\S+")
_HANDLE_RE = re.compile(r"@[A-Za-z0-9_]+")
_HASHTAG_RE = re.compile(r"#\w+")
_WORD_RE = re.compile(r"\w+(?:['’]\w+)*")
_NUMBER_RE = re.compile(r"[+-]?\d+(?:[.,:]\d+)*")
_STRIP_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)

_TWEET_TOKEN_RE = re.compile(
    "|".join(
        [
            _EMOTICON_RE.pattern,
            _URL_RE.pattern,
            _HANDLE_RE.pattern,
            _HASHTAG_RE.pattern,
            _WORD_RE.pattern,
            _NUMBER_RE.pattern,
            r"\S",
        ]
    )
)


class TweetTokenizer(TokenizerI):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _STRIP_HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _REDUCE_LEN_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = []
        for raw in [m.group(0) for m in _TWEET_TOKEN_RE.finditer(text)]:
            if _EMOTICON_RE.fullmatch(raw):
                tokens.append(raw)
            elif self._preserve_case:
                tokens.append(raw)
            else:
                tokens.append(raw.lower())
        return tokens


# ---------------------------------------------------------------------------
# Punkt sentence tokenizer
# ---------------------------------------------------------------------------

_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_UNKNOWN = "unknown"

_NON_WORD_CHARS = r"""[)\";}\]\*:@'({\[]"""
_PERIOD_CONTEXT_RE = re.compile(
    r"\S*[.?!](?=(?P<after_tok>" + _NON_WORD_CHARS + r"|\s+(?P<next_tok>\S+)))"
)
_BOUNDARY_REALIGN_RE = re.compile(r"[\"')\]}]+?(?:\s+|(?=--)|$)", re.MULTILINE)
_NUMBER_TYPE_RE = re.compile(r"^-?[.,]?\d[\d,.-]*\.?$")
_ELLIPSIS_RE = re.compile(r"\.\.+$")
_INITIAL_RE = re.compile(r"[^\W\d]\.")


class PunktParameters:
    """Packaged Punkt parameters for one language."""

    def __init__(self):
        self.abbrev_types = set()
        self.sent_starters = set()
        self.collocations = set()
        self.ortho_context = {}


def _read_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh if line.strip("\r\n") != ""]


_PARAM_CACHE = {}
_PARAM_LOCK = threading.Lock()


def load_punkt_parameters(language="english"):
    """Locate and read the Punkt model for ``language``; raise if not visible."""
    if not isinstance(language, str) or not language or os.sep in language or "/" in language or language in (".", ".."):
        raise ValueError("invalid Punkt language name %r" % (language,))
    relative = os.path.join("tokenizers", "punkt_tab", language)
    try:
        directory = data.find(relative)
    except data.ResourceNotFound as exc:
        raise PunktModelNotFound(
            "Punkt models for %r are not installed (looked for %s)" % (language, relative)
        ) from exc
    if not os.path.isdir(directory):
        raise PunktModelNotFound("Punkt model path %s is not a directory" % directory)
    with _PARAM_LOCK:
        if directory in _PARAM_CACHE:
            return _PARAM_CACHE[directory]
    params = PunktParameters()
    for line in _read_lines(os.path.join(directory, "abbrev_types.txt")):
        params.abbrev_types.add(line.strip().lower())
    for line in _read_lines(os.path.join(directory, "sent_starters.txt")):
        params.sent_starters.add(line.strip().lower())
    for line in _read_lines(os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            params.collocations.add((parts[0].strip().lower(), parts[1].strip().lower()))
    for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            params.ortho_context[parts[0].strip().lower()] = int(parts[1])
    with _PARAM_LOCK:
        _PARAM_CACHE[directory] = params
    return params


class _AugTok:
    __slots__ = (
        "tok", "type", "period_final", "type_no_period", "type_no_sentperiod",
        "first_upper", "first_lower", "is_initial", "is_ellipsis",
        "sentbreak", "abbr", "ellipsis",
    )

    def __init__(self, tok):
        self.tok = tok
        self.period_final = tok.endswith(".")
        base = tok[:-1] if self.period_final else tok
        self.type_no_period = _get_type(tok[:-1]) if self.period_final else _get_type(tok)
        self.type = _get_type(tok)
        self.type_no_sentperiod = self.type_no_period
        letters = [c for c in tok if c.isalpha()]
        first = letters[0] if letters else (tok[:1] or "")
        self.first_upper = first.isupper()
        self.first_lower = first.islower()
        self.is_initial = bool(_INITIAL_RE.fullmatch(tok))
        self.is_ellipsis = bool(_ELLIPSIS_RE.match(tok))
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False


def _get_type(tok):
    return _NUMBER_TYPE_RE.sub("##number##", tok.lower())


_WORD_SPLIT_LEAD = re.compile(r"""^([(\"'`{\[:;&#*@]*)""")
_WORD_SPLIT_TRAIL = re.compile(r"""([)\]}\"'`,;:]*)$""")


def _punkt_words(text):
    """Split text into the words the Punkt annotation looks at: whitespace
    separated, with leading openers and trailing closers split off."""
    out = []
    for raw in text.split():
        lead = _WORD_SPLIT_LEAD.match(raw).group(1)
        rest = raw[len(lead):]
        trail = _WORD_SPLIT_TRAIL.search(rest)
        trail_text = trail.group(1) if trail else ""
        core = rest[: len(rest) - len(trail_text)] if trail_text else rest
        out.extend(lead)
        end_mark = re.match(r"^(.*?)([?!]+)$", core) if core else None
        if end_mark and end_mark.group(1):
            out.append(end_mark.group(1))
            out.extend(end_mark.group(2))
        elif core:
            out.append(core)
        out.extend(trail_text)
    return out


def _ortho_heuristic(params, aug):
    """True: looks like a sentence starter; False: does not; UNKNOWN otherwise."""
    if aug.tok in (".", "?", "!"):
        return _UNKNOWN
    ortho = params.ortho_context.get(aug.type_no_sentperiod, 0)
    if aug.first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
        return False
    if aug.first_lower and ((ortho & _ORTHO_UC) or not (ortho & _ORTHO_BEG_LC)):
        return False
    if aug.first_upper and (ortho & (_ORTHO_BEG_UC | _ORTHO_UNK_UC)) and not (ortho & _ORTHO_LC):
        return True
    return _UNKNOWN


def _first_pass(params, aug):
    tok = aug.tok
    if tok in (".", "?", "!"):
        aug.sentbreak = True
    elif aug.is_ellipsis or tok.endswith(".."):
        aug.ellipsis = True
    elif aug.period_final:
        base = aug.type_no_period
        if base in params.abbrev_types or base.split("-")[-1] in params.abbrev_types:
            aug.abbr = True
        else:
            aug.sentbreak = True


def _second_pass(params, aug1, aug2):
    if aug2 is None or not aug1.period_final:
        return
    typ = aug1.type_no_period
    next_typ = aug2.type_no_sentperiod
    tok_is_initial = aug1.is_initial

    # Collocation heuristic: a known collocation is not a sentence break.
    if (typ, next_typ) in params.collocations:
        aug1.sentbreak = False
        aug1.abbr = True
        return

    # Token-based reclassification of abbreviations and ellipses.
    if (aug1.abbr or aug1.ellipsis) and not tok_is_initial:
        if _ortho_heuristic(params, aug2) is True:
            aug1.sentbreak = True
            return
        if aug2.first_upper and next_typ in params.sent_starters:
            aug1.sentbreak = True
            return

    # Initials and ordinals.
    if tok_is_initial or typ == "##number##":
        starter = _ortho_heuristic(params, aug2)
        if starter is False:
            aug1.sentbreak = False
            aug1.abbr = True
            return
        if (
            starter == _UNKNOWN
            and tok_is_initial
            and aug2.first_upper
            and not (params.ortho_context.get(next_typ, 0) & _ORTHO_LC)
        ):
            aug1.sentbreak = False
            aug1.abbr = True


def _annotate(params, words):
    augs = [_AugTok(w) for w in words]
    for aug in augs:
        _first_pass(params, aug)
    for i in range(len(augs)):
        nxt = augs[i + 1] if i + 1 < len(augs) else None
        _second_pass(params, augs[i], nxt)
    return augs


def _text_contains_sentbreak(params, context):
    return any(a.sentbreak for a in _annotate(params, _punkt_words(context)))


def _slices(params, text):
    """Return (start, stop) boundaries of sentence candidates."""
    out = []
    last_break = 0
    for match in _PERIOD_CONTEXT_RE.finditer(text):
        context = match.group() + (match.group("after_tok") or "")
        if _text_contains_sentbreak(params, context):
            out.append([last_break, match.end()])
            if match.group("next_tok"):
                last_break = match.start("next_tok")
            else:
                last_break = match.end()
    out.append([last_break, len(text)])
    return out


def _realign(text, spans):
    """Move closing quotes/brackets that begin a sentence back to the sentence before."""
    for i in range(1, len(spans)):
        start = spans[i][0]
        m = _BOUNDARY_REALIGN_RE.match(text, start)
        if m and m.end() > start and spans[i - 1][1] <= start:
            spans[i - 1][1] = m.end()
            spans[i][0] = m.end()
    return spans


class PunktSentenceTokenizer(TokenizerI):
    """Punkt unsupervised sentence-boundary detection with packaged parameters."""

    def __init__(self, language="english"):
        self.language = language
        self.params = load_punkt_parameters(language)

    def span_tokenize(self, text):
        _check_text(text)
        spans = _realign(text, _slices(self.params, text))
        out = []
        for start, stop in spans:
            piece = text[start:stop]
            stripped_left = len(piece) - len(piece.lstrip())
            piece_stripped = piece.strip()
            if not piece_stripped:
                continue
            s = start + stripped_left
            out.append((s, s + len(piece_stripped)))
        return out

    def tokenize(self, text):
        _check_text(text)
        return [text[s:e] for s, e in self.span_tokenize(text)]


def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (requires Punkt models)."""
    _check_text(text)
    tokenizer = PunktSentenceTokenizer(language)
    return tokenizer.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer.

    With ``preserve_line=False`` the text is first split into sentences with the
    Punkt-based sentence tokenizer (which requires the models for ``language``).
    """
    _check_text(text)
    if preserve_line:
        return _word_tokenize_line(text)
    sentences = sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_word_tokenize_line(sentence))
    return tokens
