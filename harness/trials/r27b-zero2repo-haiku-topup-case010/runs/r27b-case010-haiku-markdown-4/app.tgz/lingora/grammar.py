"""Context-free grammars read from text: one production per alternative."""

import re

__all__ = ["Nonterminal", "Production", "CFG"]

_RHS_TOKEN_RE = re.compile(r"""'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+)""")


class Nonterminal:
    """A nonterminal symbol. Its ``str()`` is its name; it is not a ``str``."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = str(name)

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and self._lhs == other._lhs
            and self._rhs == other._rhs
        )

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for sym in self._rhs:
            parts.append(repr(sym) if isinstance(sym, str) else str(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects grammar text")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line:
                continue
            if "->" not in line:
                raise ValueError("grammar line %d has no '->': %r" % (lineno, raw))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not re.fullmatch(r"[^\s'\"|]+", lhs_text):
                raise ValueError("bad left-hand side on line %d: %r" % (lineno, lhs_text))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            alternatives = [[]]
            consumed = 0
            for m in _RHS_TOKEN_RE.finditer(rhs_text):
                gap = rhs_text[consumed:m.start()]
                if gap.strip():
                    raise ValueError("bad right-hand side on line %d: %r" % (lineno, rhs_text))
                consumed = m.end()
                if m.group(3):
                    alternatives.append([])
                elif m.group(1) is not None:
                    alternatives[-1].append(m.group(1))
                elif m.group(2) is not None:
                    alternatives[-1].append(m.group(2))
                else:
                    alternatives[-1].append(Nonterminal(m.group(4)))
            if rhs_text[consumed:].strip():
                raise ValueError("unterminated quote or bad text on line %d" % lineno)
            for alt in alternatives:
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        name = str(lhs)
        return [p for p in self._productions if str(p.lhs()) == name]

    def terminals(self):
        out = set()
        for p in self._productions:
            for sym in p.rhs():
                if isinstance(sym, str):
                    out.add(sym)
        return out

    def __str__(self):
        return "\n".join(str(p) for p in self._productions)
