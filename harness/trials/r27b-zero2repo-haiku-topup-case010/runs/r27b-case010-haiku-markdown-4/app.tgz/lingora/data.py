"""Packaged-resource finder.

``path`` is a mutable list of directories searched for packaged resources.
Its initial contents come from the ``LINGORA_DATA`` environment variable
(separated by ``os.pathsep``); it is empty when that variable is unset.
Importing LINGORA never downloads anything.
"""

import os

__all__ = ["path", "find", "is_visible", "ResourceNotFound"]


class ResourceNotFound(LookupError):
    """Raised when a packaged resource is not visible on ``path``."""


def _initial_path():
    raw = os.environ.get("LINGORA_DATA", "")
    return [p for p in raw.split(os.pathsep) if p]


path = _initial_path()


def find(relative):
    """Return the absolute location of ``relative`` inside the first
    directory on ``path`` that holds it. Raises ``ResourceNotFound``."""
    for base in list(path):
        candidate = os.path.join(base, relative)
        if os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r not found in data.path %r" % (relative, list(path))
    )


def is_visible(relative):
    try:
        find(relative)
    except ResourceNotFound:
        return False
    return True
