"""Enumerate sentences derived from a grammar."""

import sys

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Yield token lists derivable from ``start`` (the grammar's start symbol by default).

    ``depth`` bounds the derivation depth (None: unbounded); ``n`` bounds the
    number of sentences produced (None: unbounded). Productions are expanded
    in their written order. A quoted empty-string terminal contributes an
    empty-string token; an empty production contributes no token.
    """
    if start is None:
        start = grammar.start()
    if depth is None:
        depth = sys.maxsize
    if n is not None and (not isinstance(n, int) or isinstance(n, bool)):
        raise TypeError("n must be an int or None")
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool)):
        raise TypeError("depth must be an int or None")
    return _limited(_gen_all(grammar, [start], depth), n)


def _limited(iterator, n):
    count = 0
    for sentence in iterator:
        if n is not None and count >= n:
            return
        count += 1
        yield sentence
        if n is not None and count >= n:
            return


def _gen_all(grammar, items, depth):
    if not items:
        yield []
        return
    first = items[0]
    rest = items[1:]
    if isinstance(first, str):
        for tail in _gen_all(grammar, rest, depth):
            yield [first] + tail
        return
    if depth <= 0:
        return
    name = str(first)
    for prod in grammar.productions(name):
        for frag in _gen_all(grammar, list(prod.rhs()), depth - 1):
            for tail in _gen_all(grammar, rest, depth):
                yield frag + tail
