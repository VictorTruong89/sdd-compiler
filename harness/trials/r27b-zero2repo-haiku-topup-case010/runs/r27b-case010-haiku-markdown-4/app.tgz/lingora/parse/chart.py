"""Exhaustive chart parser: returns every parse tree the grammar assigns."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("parse expects a list of tokens, not a string")
        tokens = list(tokens)
        terminals = self._grammar.terminals()
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("tokens must be str")
            if tok not in terminals:
                raise ValueError("token %r is not produced by any production" % tok)
        return _ChartRun(self._grammar, tokens).run()


class _ChartRun:
    def __init__(self, grammar, tokens):
        self.grammar = grammar
        self.tokens = tokens
        self.memo = {}
        self.by_lhs = {}
        for p in grammar.productions():
            self.by_lhs.setdefault(str(p.lhs()), []).append(p)
        self.cut = False

    def run(self):
        start = str(self.grammar.start())
        return iter(self.spans(start, 0, len(self.tokens), frozenset()))

    def spans(self, sym, i, j, active):
        key = (sym, i, j)
        if key in self.memo:
            return self.memo[key]
        if key in active:
            self.cut = True
            return []
        saved_cut = self.cut
        self.cut = False
        active = active | {key}
        results = []
        for prod in self.by_lhs.get(sym, []):
            for children in self.seq(prod.rhs(), 0, i, j, active):
                results.append(Tree(sym, children))
        if not self.cut:
            self.memo[key] = results
        self.cut = saved_cut or self.cut
        return results

    def seq(self, rhs, idx, i, j, active):
        if idx == len(rhs):
            if i == j:
                yield []
            return
        sym = rhs[idx]
        if isinstance(sym, str):
            if i < j and self.tokens[i] == sym:
                for rest in self.seq(rhs, idx + 1, i + 1, j, active):
                    yield [sym] + rest
            return
        for k in range(i, j + 1):
            for sub in self.spans(str(sym), i, k, active):
                for rest in self.seq(rhs, idx + 1, k, j, active):
                    yield [sub] + rest
