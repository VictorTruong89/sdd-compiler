"""Single-pass shift-reduce parser without backtracking."""

from lingora.tree import Tree

_MAX_CONSECUTIVE_REDUCTIONS = 10000


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._productions = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("parse expects a list of tokens, not a string")
        tokens = list(tokens)
        terminals = self._grammar.terminals()
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("tokens must be str")
            if tok not in terminals:
                raise ValueError("token %r is not produced by any production" % tok)
        return iter(self._run(tokens))

    def _run(self, tokens):
        stack = []  # items: ("tok", str) or ("tree", Tree)
        pos = 0
        reductions = 0
        while True:
            reduced = False
            for prod in self._productions:
                rhs = prod.rhs()
                n = len(rhs)
                if len(stack) < n:
                    continue
                top = stack[len(stack) - n:]
                ok = True
                for sym, item in zip(rhs, top):
                    if isinstance(sym, str):
                        if item[0] != "tok" or item[1] != sym:
                            ok = False
                            break
                    else:
                        if item[0] != "tree" or item[1].label() != str(sym):
                            ok = False
                            break
                if not ok:
                    continue
                children = [item[1] for item in top]
                tree = Tree(str(prod.lhs()), children)
                del stack[len(stack) - n:]
                stack.append(("tree", tree))
                reduced = True
                reductions += 1
                break
            if reduced:
                if reductions > _MAX_CONSECUTIVE_REDUCTIONS:
                    return []
                continue
            reductions = 0
            if pos < len(tokens):
                stack.append(("tok", tokens[pos]))
                pos += 1
                continue
            break
        if len(stack) == 1 and stack[0][0] == "tree":
            tree = stack[0][1]
            if tree.label() == str(self._grammar.start()):
                return [tree]
        return []
