"""Naive Bayes and decision tree classifiers over labelled featuresets."""

import math
from collections import Counter, OrderedDict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = OrderedDict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs.items(), key=lambda kv: kv[1])[0]

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_featuresets(labeled):
    if isinstance(labeled, (str, bytes)):
        raise TypeError("expected a list of (featureset, label) pairs")
    out = []
    for item in labeled:
        if not (isinstance(item, (tuple, list)) and len(item) == 2):
            raise TypeError("each training item must be a (featureset, label) pair")
        fs, label = item
        if not isinstance(fs, dict):
            raise TypeError("featureset must be a dict")
        out.append((dict(fs), label))
    if not out:
        raise ValueError("training data is empty")
    return out


class NaiveBayesClassifier:
    """Multinomial-style Naive Bayes with expected-likelihood (0.5) smoothing."""

    def __init__(self, label_probdist_counts, feature_counts, value_sets, label_feature_totals, total):
        self._label_counts = label_probdist_counts
        self._feature_counts = feature_counts
        self._value_sets = value_sets
        self._label_feature_totals = label_feature_totals
        self._total = total
        self._labels = list(label_probdist_counts.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_featuresets(labeled_featuresets)
        label_counts = OrderedDict()
        feature_counts = Counter()
        value_sets = {}
        lf_totals = Counter()
        for fs, label in data:
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, value in fs.items():
                value_sets.setdefault(fname, set()).add(value)
                feature_counts[(label, fname, value)] += 1
                lf_totals[(label, fname)] += 1
        return cls(label_counts, feature_counts, value_sets, lf_totals, len(data))

    def labels(self):
        return list(self._labels)

    def _log_joint(self, featureset):
        scores = OrderedDict()
        for label in self._labels:
            logp = math.log(self._label_counts[label] / self._total)
            for fname, value in featureset.items():
                if fname not in self._value_sets:
                    continue
                bins = len(self._value_sets[fname])
                count = self._feature_counts.get((label, fname, value), 0)
                denom = self._label_feature_totals.get((label, fname), 0) + 0.5 * bins
                logp += math.log((count + 0.5) / denom)
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        scores = self._log_joint(dict(featureset))
        peak = max(scores.values())
        exps = OrderedDict((l, math.exp(s - peak)) for l, s in scores.items())
        total = sum(exps.values())
        return ProbDist((l, v / total) for l, v in exps.items())

    def classify(self, featureset):
        scores = self._log_joint(dict(featureset))
        best = None
        best_label = None
        for label in self._labels:
            if best is None or scores[label] > best:
                best = scores[label]
                best_label = label
        return best_label


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Node:
    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(counts, total):
    h = 0.0
    for c in counts.values():
        if c:
            p = c / total
            h -= p * math.log2(p)
    return h


def _majority(examples):
    counts = Counter()
    order = []
    for _, label in examples:
        if label not in counts:
            order.append(label)
        counts[label] += 1
    best = None
    best_label = None
    for label in order:
        if best is None or counts[label] > best:
            best = counts[label]
            best_label = label
    return best_label


class DecisionTreeClassifier:
    """ID3-style decision tree choosing, at each node, the feature with the highest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_featuresets(labeled_featuresets)
        features = sorted({f for fs, _ in data for f in fs}, key=repr)
        return cls(cls._build(data, features))

    @classmethod
    def _build(cls, examples, features):
        labels = {label for _, label in examples}
        if len(labels) == 1 or not features:
            return _Leaf(_majority(examples))
        total = len(examples)
        label_counts = Counter(label for _, label in examples)
        parent_h = _entropy(label_counts, total)
        best_gain = 0.0
        best_feature = None
        best_groups = None
        for feat in features:
            groups = {}
            for fs, label in examples:
                groups.setdefault(fs.get(feat), []).append((fs, label))
            remainder = 0.0
            for group in groups.values():
                gc = Counter(label for _, label in group)
                remainder += len(group) / total * _entropy(gc, len(group))
            gain = parent_h - remainder
            if gain > best_gain + 1e-12:
                best_gain = gain
                best_feature = feat
                best_groups = groups
        if best_feature is None:
            return _Leaf(_majority(examples))
        remaining = [f for f in features if f != best_feature]
        children = {
            value: cls._build(group, remaining) for value, group in best_groups.items()
        }
        return _Node(best_feature, children, _majority(examples))

    def classify(self, featureset):
        fs = dict(featureset)
        node = self._root
        while isinstance(node, _Node):
            value = fs.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` classified correctly."""
    gold = list(gold)
    if not gold:
        return 0.0
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
