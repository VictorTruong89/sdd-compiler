"""Part-of-speech taggers: sequential taggers that can be trained in memory
(default, unigram, n-gram, affix, regular expression, with backoff), and the
recommended averaged-perceptron tagger for English and Russian."""

import json
import os
import re
import threading
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "TaggerI",
    "DefaultTagger",
    "UnigramTagger",
    "NgramTagger",
    "BigramTagger",
    "TrigramTagger",
    "AffixTagger",
    "RegexpTagger",
    "AveragedPerceptronTagger",
    "pos_tag",
]


class TaggerI:
    """Base class. ``tag`` returns one ``(token, tag)`` tuple per token; a tag
    of ``None`` means no tag was assigned."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def choose_tag(self, tokens, index, history):  # pragma: no cover - abstract
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tag expects a list of tokens, not a string")
        tokens = list(tokens)
        for tok in tokens:
            if not isinstance(tok, str):
                raise TypeError("tokens must be str")
        history = []
        chosen = []
        for i in range(len(tokens)):
            t = self.choose_tag(tokens, i, history)
            history.append(t)
            chosen.append(t)
        if self._backoff is not None and any(t is None for t in chosen):
            fallback = self._backoff.tag(tokens)
            chosen = [
                fallback[i][1] if t is None else t for i, t in enumerate(chosen)
            ]
        return list(zip(tokens, chosen))


class DefaultTagger(TaggerI):
    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class UnigramTagger(TaggerI):
    def __init__(self, train=None, model=None, backoff=None):
        super().__init__(backoff)
        self._model = {}
        if model is not None:
            self._model = dict(model)
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for word, tag in sentence:
                    counts[word][tag] += 1
            for word, c in counts.items():
                best = sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
                self._model[word] = best

    def choose_tag(self, tokens, index, history):
        return self._model.get(tokens[index])


class NgramTagger(TaggerI):
    """Tags with the most frequent tag for (previous n-1 tags, word)."""

    def __init__(self, n, train=None, backoff=None):
        super().__init__(backoff)
        if n < 1:
            raise ValueError("n must be >= 1")
        self._n = n
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                history = [None] * (n - 1)
                for word, tag in sentence:
                    counts[(tuple(history), word)][tag] += 1
                    history = (history + [tag])[-(n - 1):] if n > 1 else []
            for key, c in counts.items():
                self._model[key] = sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    def choose_tag(self, tokens, index, history):
        ctx = tuple(history[-(self._n - 1):]) if self._n > 1 else ()
        if len(ctx) < self._n - 1:
            ctx = (None,) * (self._n - 1 - len(ctx)) + ctx
        return self._model.get((ctx, tokens[index]))


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train=train, backoff=backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train=train, backoff=backoff)


class AffixTagger(TaggerI):
    """Tags by the prefix (length > 0) or suffix (length < 0) of each word."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self._length = affix_length
        self._min_stem = min_stem_length
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for word, tag in sentence:
                    affix = self._affix(word)
                    if affix is not None:
                        counts[affix][tag] += 1
            for affix, c in counts.items():
                self._model[affix] = sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    def _affix(self, word):
        if len(word) < self._min_stem:
            return None
        if self._length > 0:
            return word[: self._length]
        return word[self._length:]

    def choose_tag(self, tokens, index, history):
        affix = self._affix(tokens[index])
        if affix is None:
            return None
        return self._model.get(affix)


class RegexpTagger(TaggerI):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        if not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = []
        for item in regexps:
            if not (isinstance(item, (list, tuple)) and len(item) == 2):
                raise TypeError("each regexp rule must be a (pattern, tag) pair")
            pattern, tag = item
            self._rules.append((re.compile(pattern), tag))

    def choose_tag(self, tokens, index, history):
        token = tokens[index]
        for regex, tag in self._rules:
            if regex.match(token):
                return tag
        return None


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended English and Russian tagger)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _Perceptron:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


class AveragedPerceptronTagger:
    """Greedy averaged perceptron tagger reading packaged weights, tag dictionary and classes."""

    def __init__(self, lang):
        self.lang = lang
        base = "taggers/averaged_perceptron_tagger_%s" % lang
        directory = data.find(base)
        prefix = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
        with open(prefix + ".weights.json", encoding="utf-8") as fh:
            weights = json.load(fh)
        with open(prefix + ".tagdict.json", encoding="utf-8") as fh:
            self.tagdict = json.load(fh)
        with open(prefix + ".classes.json", encoding="utf-8") as fh:
            classes = set(json.load(fh))
        self.model = _Perceptron(weights, classes)

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def tag(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self.model.predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_PERCEPTRON_CACHE = {}
_PERCEPTRON_LOCK = threading.Lock()

_RUS_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "ANUM": "ADJ", "NUM": "NUM", "V": "VERB",
    "ADV": "ADV", "ADVPRO": "ADV", "PRAEDIC": "ADV", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PART", "INTJ": "INTJ", "SPRO": "PRON",
    "APRO": "DET", "PREDK": "ADV", "PARENTH": "PART",
}


def _get_perceptron(lang):
    try:
        data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    except data.ResourceNotFound as exc:
        raise LookupError(
            "averaged perceptron tagger for %r is not installed" % lang
        ) from exc
    with _PERCEPTRON_LOCK:
        if lang in _PERCEPTRON_CACHE:
            return _PERCEPTRON_CACHE[lang]
    tagger = AveragedPerceptronTagger(lang)
    with _PERCEPTRON_LOCK:
        _PERCEPTRON_CACHE[lang] = tagger
    return tagger


def _load_en_ptb_map():
    try:
        path = data.find(os.path.join("taggers", "universal_tagset", "en-ptb.map"))
    except data.ResourceNotFound as exc:
        raise LookupError("universal tagset tables are not installed") from exc
    mapping = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Recommended tagger. ``lang`` is 'eng' or 'rus'; ``tagset`` is None (native
    tags) or 'universal'. Raises when the request cannot be served."""
    if isinstance(tokens, str):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    tokens = list(tokens)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str")
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for pos_tag: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset: %r" % (tagset,))
    if tagset == "universal" and lang == "eng":
        table = _load_en_ptb_map()
    else:
        table = None
    tagger = _get_perceptron(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            tagged = [(w, table.get(t, "X") if t is not None else None) for w, t in tagged]
        else:
            tagged = [
                (w, _RUS_UNIVERSAL.get(t.split("=")[0], "X") if t else None)
                for w, t in tagged
            ]
    return tagged
