"""Stemmers: Porter (with LINGORA extensions), Lancaster (Paice/Husk),
Snowball (English Porter2 and the original Porter algorithm), regular
expression stemmer, and entries whose results are outside the specification."""

import re

from lingora import data

__all__ = [
    "PorterStemmer",
    "LancasterStemmer",
    "SnowballStemmer",
    "RegexpStemmer",
    "ARLSTem",
    "ARLSTem2",
    "WordNetLemmatizer",
    "SNOWBALL_LANGUAGES",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

# ---------------------------------------------------------------------------
# Porter
# ---------------------------------------------------------------------------

# Small table of irregular forms (LINGORA extension). Keys are lowercase.
_PORTER_IRREGULAR = {
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "news": "news",
    "innings": "inning",
    "inning": "inning",
    "outings": "outing",
    "outing": "outing",
    "cannings": "can",
    "canning": "can",
    "howe": "howe",
    "proceed": "proceed",
    "exceed": "exceed",
    "succeed": "succeed",
}


def _cons(w, i):
    """Porter's consonant test; 'y' is a consonant unless preceded by a consonant."""
    c = w[i]
    if c in "aeiou":
        return False
    if c == "y":
        return i == 0 or not _cons(w, i - 1)
    return True


def _measure(stem):
    """Number of VC sequences in the stem's [C](VC)^m[V] form."""
    cv = "".join("c" if _cons(stem, i) else "v" for i in range(len(stem)))
    collapsed = re.sub(r"(.)\1+", r"\1", cv)
    return collapsed.count("vc")


def _has_vowel(stem):
    return any(not _cons(stem, i) for i in range(len(stem)))


def _double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _cons(w, len(w) - 1)


def _cvc(w):
    return (
        len(w) >= 3
        and _cons(w, len(w) - 3)
        and not _cons(w, len(w) - 2)
        and _cons(w, len(w) - 1)
        and w[-1] not in "wxy"
    )


def _star_o(w, lingora):
    if _cvc(w):
        return True
    # LINGORA extension: a two-letter stem of vowel + consonant also has *o.
    return (
        lingora
        and len(w) == 2
        and not _cons(w, 0)
        and _cons(w, 1)
        and w[1] not in "wxy"
    )


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


class PorterStemmer:
    """Porter stemmer. ``mode`` is ``'lingora'`` (the default LINGORA
    extensions), ``'original'`` (Porter's 1980 algorithm) or ``'martin'``
    (treated as the original algorithm here; its results are outside the
    specification)."""

    MODES = ("lingora", "original", "martin")

    def __init__(self, mode="lingora"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._lingora = mode == "lingora"

    def stem(self, word, to_lowercase=False):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        if to_lowercase:
            word = word.lower()
        if self._lingora:
            if word in _PORTER_IRREGULAR:
                return _PORTER_IRREGULAR[word]
            if len(word) <= 2:
                return word
        w = word
        w = self._step1a(w)
        w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5a(w)
        w = self._step5b(w)
        return w

    # -- steps ----------------------------------------------------------
    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if self._lingora and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    def _step1b(self, w):
        if self._lingora and w.endswith("ied"):
            return w[:-3] + ("ie" if len(w) == 4 else "i")
        if w.endswith("eed"):
            stem = w[:-3]
            if _measure(stem) > 0:
                return stem + "ee"
            return w
        suffix = None
        for suf in ("ed", "ing"):
            if w.endswith(suf):
                suffix = suf
                break
        if suffix is None:
            return w
        stem = w[: -len(suffix)]
        if not _has_vowel(stem):
            return w
        w = stem
        if w.endswith(("at", "bl", "iz")):
            return w + "e"
        if _double_cons(w) and w[-1] not in "lsz":
            return w[:-1]
        if _measure(w) == 1 and _cvc(w):
            return w + "e"
        return w

    def _step1c(self, w):
        if not w.endswith("y"):
            return w
        stem = w[:-1]
        if self._lingora:
            if len(stem) >= 2 and _cons(stem, len(stem) - 1):
                return stem + "i"
            return w
        if _has_vowel(stem):
            return stem + "i"
        return w

    def _step2(self, w):
        if self._lingora:
            if w.endswith("alli") and _measure(w[:-4]) > 0:
                return self._step2(w[:-2])
            if w.endswith("fulli") and _measure(w[:-5]) > 0:
                return w[:-2]
            if w.endswith("logi") and _measure(w[:-3]) > 0:
                return w[:-1]
            if w.endswith("bli") and _measure(w[:-3]) > 0:
                return w[:-1] + "e"
            table = [(s, r) for s, r in _STEP2_ORIGINAL if s != "abli"]
        else:
            table = _STEP2_ORIGINAL
        for suffix, repl in table:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step3(self, w):
        for suffix, repl in _STEP3:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step4(self, w):
        for suffix in _STEP4:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if suffix == "ion" and not (stem and stem[-1] in "st"):
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    def _step5a(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _star_o(stem, self._lingora)):
                return stem
        return w

    def _step5b(self, w):
        if _measure(w) > 1 and _double_cons(w) and w.endswith("l"):
            return w[:-1]
        return w


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rules in the Paice/Husk notation: reversed suffix, '*' = only while the word
# is intact, digit = letters removed, letters = appended, '.' stop, '>' continue.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.",
    "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>",
    "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.",
    "ra2.", "ro2>", "ru2>", "rov3>", "rr1.", "rt1>", "rei3>", "sei3y>",
    "sis2.", "si2>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.",
    "tpm1.", "tu*2.", "tt1.", "uqi3>", "ugo1.", "vis3j>", "vie2>", "vi2>",
    "ylb1>", "yli3y>", "ylp1>", "yli3>", "ylb1.", "yrtsi5.", "yr3>",
    "yt3>", "yu3>", "yn1>", "yhp1.", "yl3>", "zi2>", "zy1s.",
]


def _parse_lancaster_rule(rule):
    m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    return {
        "suffix": m.group(1)[::-1],
        "intact": m.group(2) == "*",
        "remove": int(m.group(3)),
        "append": m.group(4),
        "stop": m.group(5) == ".",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer:
    """Paice/Husk Lancaster stemmer."""

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        word = word.lower()
        intact = True
        while True:
            applied = None
            for rule in _LANCASTER_PARSED:
                if not word.endswith(rule["suffix"]):
                    continue
                if rule["intact"] and not intact:
                    continue
                stem = word[: len(word) - rule["remove"]] if rule["remove"] else word
                if len(stem) < 2:
                    continue
                applied = rule
                break
            if applied is None:
                return word
            word = word[: len(word) - applied["remove"]] + applied["append"]
            if applied["stop"]:
                return word
            intact = False


# ---------------------------------------------------------------------------
# Snowball: English (Porter2) and the original Porter algorithm
# ---------------------------------------------------------------------------

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_P2_EXC2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed",
    "succeed",
}
_P2_VOWELS = "aeiouy"
_P2_LI_ENDINGS = "cdeghkmnrt"
_P2_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
    ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
    ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
    ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
]
_P2_STEP2.sort(key=lambda p: -len(p[0]))
_P2_STEP3 = [
    ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
    ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
]
_P2_STEP3.sort(key=lambda p: -len(p[0]))
_P2_STEP4 = sorted(
    ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
     "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"],
    key=lambda s: -len(s),
)


def _p2_vowel(c):
    return c in _P2_VOWELS


def _p2_region(w, start):
    for i in range(start + 1, len(w)):
        if _p2_vowel(w[i - 1]) and not _p2_vowel(w[i]):
            return i + 1
    return len(w)


def _p2_short_syllable(w):
    if len(w) == 2:
        return _p2_vowel(w[0]) and not _p2_vowel(w[1])
    if len(w) >= 3:
        return (
            not _p2_vowel(w[-3])
            and _p2_vowel(w[-2])
            and not _p2_vowel(w[-1])
            and w[-1] not in "wxY"
        )
    return False


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and _p2_vowel(chars[i - 1]):
            chars[i] = "Y"
    w = "".join(chars)

    r1 = _p2_region(w, 0)
    for prefix in ("gener", "commun", "arsen"):
        if w.startswith(prefix):
            r1 = len(prefix)
            break
    r2 = _p2_region(w, r1)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-3] + ("i" if len(w) - 3 > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        stem = w[:-1]
        if any(_p2_vowel(c) for c in stem[:-1]):
            w = stem

    if w in _P2_EXC2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eedly", "eed")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        suf = None
        for cand in ("ingly", "edly", "ing", "ed"):
            if w.endswith(cand):
                suf = cand
                break
        if suf is not None:
            stem = w[: -len(suf)]
            if any(_p2_vowel(c) for c in stem):
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    w = w + "e"
                elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                    w = w[:-1]
                elif len(w) <= r1 and _p2_short_syllable(w):
                    w = w + "e"

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and not _p2_vowel(w[-2]):
        w = w[:-1] + "i"

    # Step 2
    for suffix, repl in _P2_STEP2:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                if suffix == "ogi":
                    if len(w) >= 4 and w[-4] == "l":
                        w = w[:-3] + repl
                elif suffix == "li":
                    if len(w) >= 3 and w[-3] in _P2_LI_ENDINGS:
                        w = w[:-2]
                else:
                    w = w[: -len(suffix)] + repl
            break

    # Step 3
    for suffix, repl in _P2_STEP3:
        if w.endswith(suffix):
            if suffix == "ative":
                if len(w) - len(suffix) >= r2:
                    w = w[: -len(suffix)] + repl
            elif len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + repl
            break

    # Step 4
    for suffix in _P2_STEP4:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix == "ion":
                    if len(w) >= 4 and w[-4] in "st":
                        w = w[:-3]
                else:
                    w = w[: -len(suffix)]
            break

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable(w[:-1])):
            w = w[:-1]
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w[-2:-1] == "l":
            w = w[:-1]

    return w.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmer.

    Implemented here: ``english`` (Porter2) and ``porter`` (the original Porter
    algorithm). The other Snowball language names are accepted by name but the
    stemming algorithms for them are not implemented; constructing such a
    stemmer raises ``NotImplementedError`` (see NOTES.md).
    """

    _IMPLEMENTED = ("english", "porter")

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language: %r" % (language,)
            )
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            relative = "corpora/stopwords/" + language
            try:
                path = data.find(relative)
            except data.ResourceNotFound as exc:
                raise LookupError(
                    "stopwords list for Snowball language %r is not installed" % language
                ) from exc
            with open(path, encoding="utf-8") as fh:
                self._stopwords = {line.strip().lower() for line in fh if line.strip()}
        if language not in self._IMPLEMENTED:
            raise NotImplementedError(
                "Snowball stemming algorithm for %r is not implemented in LINGORA"
                % language
            )
        self._ignore_stopwords = bool(ignore_stopwords)
        self._porter = PorterStemmer("original") if language == "porter" else None

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        word = word.lower()
        if self._ignore_stopwords and word in self._stopwords:
            return word
        if self._porter is not None:
            return self._porter.stem(word)
        return _porter2(word)


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be str")
        self._re = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be str")
        return self._re.sub("", word)


# ---------------------------------------------------------------------------
# Entries whose results are outside this specification
# ---------------------------------------------------------------------------

class ARLSTem:
    """Arabic light stemmer. Exists in the product; its results are outside the spec."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is not implemented in LINGORA")


class ARLSTem2(ARLSTem):
    """Arabic light stemmer 2. Results are outside the spec."""


class WordNetLemmatizer:
    """Requires the WordNet resource; raises when it is not visible."""

    def __init__(self):
        if not data.is_visible("corpora/wordnet"):
            raise LookupError("WordNet is not installed (corpora/wordnet not visible)")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is not implemented in LINGORA")
