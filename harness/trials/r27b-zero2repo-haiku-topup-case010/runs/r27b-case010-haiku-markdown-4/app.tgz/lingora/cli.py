"""Command line: ``lingora tokenize`` applies the recommended word tokenizer to
each line of standard input (with sentence splitting, which needs Punkt)."""

import sys

from lingora import tokenize as _tok

__all__ = ["cli", "Group", "main"]

USAGE = "usage: lingora tokenize [--language LANG] [--delimiter STR] [--encoding ENC]"


class Group:
    """A minimal command group: ``main(args=[...], standalone_mode=True)``."""

    def __init__(self, name="lingora"):
        self.name = name
        self._commands = {"tokenize": self._tokenize_command}

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    # -- argument handling ---------------------------------------------
    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write(USAGE + "\n")
            return 0 if args else 2
        command = args[0]
        if command not in self._commands:
            sys.stderr.write("lingora: unknown command %r\n%s\n" % (command, USAGE))
            return 2
        try:
            options = _parse_options(args[1:])
        except ValueError as exc:
            sys.stderr.write("lingora %s: %s\n%s\n" % (command, exc, USAGE))
            return 2
        return self._commands[command](options)

    # -- tokenize ------------------------------------------------------
    def _tokenize_command(self, options):
        language = options.get("language", "english")
        delimiter = options.get("delimiter", " ")
        encoding = options.get("encoding", "utf-8")
        try:
            # Fail before writing anything when the Punkt models are not visible.
            _tok.load_punkt_parameters(language)
        except Exception as exc:  # noqa: BLE001 - reported on stderr
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        try:
            stdin = sys.stdin
            if hasattr(stdin, "buffer"):
                raw_lines = stdin.buffer.read().decode(encoding).splitlines()
            else:
                raw_lines = stdin.read().splitlines()
            for line in raw_lines:
                tokens = _tok.word_tokenize(line, language=language, preserve_line=False)
                sys.stdout.write(delimiter.join(tokens) + "\n")
            sys.stdout.flush()
        except Exception as exc:  # noqa: BLE001 - reported on stderr
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        return 0


def _parse_options(args):
    options = {}
    names = {"--language": "language", "--delimiter": "delimiter", "--encoding": "encoding"}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in names:
            if i + 1 >= len(args):
                raise ValueError("option %s needs a value" % arg)
            options[names[arg]] = args[i + 1]
            i += 2
        else:
            raise ValueError("unexpected argument %r" % arg)
    return options


cli = Group("lingora")


def main(argv=None):
    return cli.main(args=sys.argv[1:] if argv is None else argv, standalone_mode=True)


if __name__ == "__main__":
    main()
