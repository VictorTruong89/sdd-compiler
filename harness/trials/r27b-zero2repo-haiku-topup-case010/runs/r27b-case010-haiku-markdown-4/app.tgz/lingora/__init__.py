"""LINGORA: a pure-Python natural language processing library."""

from lingora import data

__version__ = "0.1.0"

__all__ = ["data", "__version__"]
