from lingora.cli import main

main()
