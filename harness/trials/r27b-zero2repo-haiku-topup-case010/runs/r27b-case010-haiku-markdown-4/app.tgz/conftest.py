# Makes the flat `lingora` package importable when pytest runs from /app,
# without requiring an editable install.
