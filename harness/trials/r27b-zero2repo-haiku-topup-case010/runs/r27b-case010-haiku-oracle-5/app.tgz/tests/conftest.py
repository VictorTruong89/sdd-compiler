"""Shared fixtures: a tiny packaged-data tree built in tmp_path, set as data.path for a test."""
import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


@pytest.fixture
def pkg_data(tmp_path, monkeypatch):
    """Build a minimal data directory (Punkt english, perceptron eng, universal map, stopwords)."""
    base = str(tmp_path / "lingora_data")
    punkt = os.path.join(base, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "mr\nmrs\ndr\nst\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\n")
    _write(os.path.join(punkt, "collocations.tab"), "")
    _write(os.path.join(punkt, "ortho_context.tab"), "the\t16\nhe\t16\nsmith\t4\nit\t16\nhello\t8\n")
    tagger = os.path.join(base, "taggers", "averaged_perceptron_tagger_eng")
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.weights.json"),
           json.dumps({"bias": {"NN": 1.0}, "i word dog": {"NN": 2.0}}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.tagdict.json"), json.dumps({"the": "DT"}))
    _write(os.path.join(tagger, "averaged_perceptron_tagger_eng.classes.json"), json.dumps(["DT", "NN", "VB"]))
    _write(os.path.join(base, "taggers", "universal_tagset", "en-ptb.map"), "NN\tNOUN\nDT\tDET\nVB\tVERB\n")
    _write(os.path.join(base, "corpora", "stopwords", "english"), "a\nthe\nis\n")
    monkeypatch.setattr(data, "path", [base], raising=False)
    data.path[:] = [base]
    yield base
    data.path[:] = []


@pytest.fixture
def no_data():
    saved = list(data.path)
    data.path[:] = []
    yield
    data.path[:] = saved
