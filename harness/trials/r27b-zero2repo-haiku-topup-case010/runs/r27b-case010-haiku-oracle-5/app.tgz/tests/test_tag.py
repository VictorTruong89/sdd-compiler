# spec: N-000187 .. N-000227, N-000433 .. N-000445 (FP-03 and lingora.tag)
import pytest

from lingora import tag as tg
from lingora.errors import ResourceNotFoundError, UnsupportedError


def test_N_000198_default_tagger_tags_every_token():
    assert tg.DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]


def test_N_000199_unigram_most_frequent_tag_and_unseen_none():
    tr = [[("a", "DT"), ("b", "NN")], [("b", "VB"), ("b", "NN")]]
    assert tg.UnigramTagger(tr).tag(["a", "b", "zz"]) == [("a", "DT"), ("b", "NN"), ("zz", None)]


def test_N_000205_backoff_only_for_untagged_tokens():
    tr = [[("a", "DT")]]
    assert tg.UnigramTagger(tr, backoff=tg.DefaultTagger("NN")).tag(["a", "zz"]) == [("a", "DT"), ("zz", "NN")]


def test_N_000202_regexp_tagger_first_rule_wins_at_start():
    rt = tg.RegexpTagger([(r".*ing$", "VBG"), (r".*", "NN")])
    assert rt.tag(["running", "dog"]) == [("running", "VBG"), ("dog", "NN")]


def test_N_000196_empty_list_yields_empty():
    assert tg.DefaultTagger("NN").tag([]) == []


def test_N_000442_string_refused():
    with pytest.raises(TypeError):
        tg.pos_tag("not tokens")


def test_N_000443_unknown_lang_raises(pkg_data):
    with pytest.raises(UnsupportedError):
        tg.pos_tag(["a"], lang="fra")


def test_N_000224_missing_model_raises(no_data):
    with pytest.raises(ResourceNotFoundError):
        tg.pos_tag(["the", "dog"])


def test_N_000207_perceptron_tags_with_tagdict_and_features(pkg_data):
    assert tg.pos_tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]


def test_N_000215_universal_mapping_english(pkg_data):
    assert tg.pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


def test_N_000233_english_universal_table_missing_fails(pkg_data, tmp_path):
    import os
    os.remove(os.path.join(pkg_data, "taggers", "universal_tagset", "en-ptb.map"))
    with pytest.raises(ResourceNotFoundError):
        tg.pos_tag(["the"], tagset="universal")
