# spec: N-000140 .. N-000186, N-000421 .. N-000432 (FP-02 and lingora.stem)
import pytest

from lingora import stem as s
from lingora.errors import ResourceNotFoundError, UnsupportedError


PORTER_WORDS = {
    "caresses": "caress", "ponies": "poni", "caress": "caress", "cats": "cat", "feed": "feed",
    "agreed": "agre", "plastered": "plaster", "motoring": "motor", "sing": "sing",
    "conflated": "conflat", "hopping": "hop", "falling": "fall", "happy": "happi",
    "relational": "relat", "rational": "ration", "generalizations": "gener", "hopefulness": "hope",
}


def test_N_000153_porter_default_mode_known_outputs():
    p = s.PorterStemmer()
    for word, stem in {"caresses": "caress", "hopping": "hop", "happy": "happi", "motoring": "motor"}.items():
        assert p.stem(word) == stem


def test_N_000158_ies_four_letters_becomes_ie_in_lingora_mode():
    assert s.PorterStemmer().stem("ties") == "tie"
    assert s.PorterStemmer(s.ORIGINAL_ALGORITHM).stem("ties") == "ti"


def test_N_000155_irregular_table_hit():
    assert s.PorterStemmer().stem("dying") == "die"


def test_N_000156_short_words_returned_as_is():
    assert s.PorterStemmer().stem("ab") == "ab"
    assert s.PorterStemmer().stem("Is", to_lowercase=False) == "Is"


def test_N_000154_lowercase_default_on_and_optional():
    assert s.PorterStemmer().stem("Running") == "run"
    assert s.PorterStemmer().stem("Running", to_lowercase=False) == "Run"


def test_N_000159_ied_rule():
    assert s.PorterStemmer().stem("tied") == "tie"


def test_N_000162_final_y_rule_lingora():
    assert s.PorterStemmer().stem("happy") == "happi"


def test_N_000170_lancaster_lowercases_and_stems():
    assert s.LancasterStemmer().stem("Maximum") == "maxim"


def test_N_000178_regexp_stemmer_removes_every_match_only():
    assert s.RegexpStemmer("ing$").stem("running") == "runn"
    assert s.RegexpStemmer("s").stem("glass cats") == "gla cat"
    assert s.RegexpStemmer("zzz").stem("hello") == "hello"


def test_N_000172_snowball_english_porter2():
    e = s.SnowballStemmer("english")
    assert e.stem("generously") == "generous"
    assert e.stem("running") == "run"
    assert e.stem("ties") == "tie"
    assert e.stem("skies") == "sky"


def test_N_000175_snowball_porter_differs_from_english():
    assert s.SnowballStemmer("porter").stem("generalizations") == "gener"
    assert s.SnowballStemmer("english").stem("generalizations") == "general"


def test_N_000181_unsupported_language_names_request():
    with pytest.raises(UnsupportedError) as exc:
        s.SnowballStemmer("klingon")
    assert "klingon" in str(exc.value)


def test_N_000183_stopword_skipping_needs_list(no_data):
    with pytest.raises(ResourceNotFoundError):
        s.SnowballStemmer("english", ignore_stopwords=True)


def test_N_000176_stopword_returned_lowercased(pkg_data):
    st = s.SnowballStemmer("english", ignore_stopwords=True)
    assert st.stem("The") == "the"
    assert st.stem("running") == "run"


def test_N_000185_wordnet_lemmatizer_needs_wordnet(pkg_data):
    with pytest.raises(ResourceNotFoundError):
        s.WordNetLemmatizer()


def test_N_000152_stems_treat_whole_string_as_token():
    assert s.PorterStemmer().stem("two words") == "two word"
