# spec: N-000258 .. N-000294, N-000461 .. N-000491 (FP-05, lingora.grammar / parse / tree)
import pytest

from lingora import parse as p
from lingora.errors import ParseError, UnsupportedError
from lingora.grammar import CFG
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> Det N | 'John'
VP -> V NP | V
Det -> 'the' | 'a'
N -> 'dog' | 'cat'
V -> 'saw' | 'ran'
"""


def test_N_000264_start_is_first_lhs_and_alternatives_split():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions(g.start())) == 1
    assert len(g.productions()) == 11


def test_N_000469_terminal_is_str_nonterminal_is_not():
    g = CFG.fromstring(GRAMMAR)
    rhs = g.productions(g.start())[0].rhs()
    assert not isinstance(rhs[0], str)
    det = [pr for pr in g.productions() if str(pr.lhs()) == "Det"][0].rhs()
    assert det == ("the",) or det[0] == "the"


def test_N_000266_chart_returns_all_trees_for_ambiguous_sentence():
    g = CFG.fromstring("S -> A | B\nA -> 'x'\nB -> 'x'")
    trees = list(p.ChartParser(g).parse(["x"]))
    assert len(trees) == 2
    assert all(t.label() == "S" and t.leaves() == ["x"] for t in trees)


def test_N_000266_chart_empty_for_underivable_covered_tokens():
    g = CFG.fromstring(GRAMMAR)
    assert list(p.ChartParser(g).parse("John ran dog".split())) == []


def test_N_000292_token_no_production_produces_raises():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(UnsupportedError):
        list(p.ChartParser(g).parse(["John", "flew"]))


def test_N_000272_shift_reduce_matches_chart_on_unambiguous():
    g = CFG.fromstring(GRAMMAR)
    sr = list(p.ShiftReduceParser(g).parse("John ran".split()))
    ch = list(p.ChartParser(g).parse("John ran".split()))
    assert len(sr) == 1 and sr[0] == ch[0]


def test_N_000274_shift_reduce_no_backtracking_gives_none_when_greedy_fails():
    g = CFG.fromstring(GRAMMAR)
    assert list(p.ShiftReduceParser(g).parse("John saw the dog".split())) == []


def test_N_000276_generate_expands_in_written_order_and_bounds():
    g = CFG.fromstring(GRAMMAR)
    first = list(generate(g, depth=5, n=2))
    assert first == [["the", "dog", "saw", "the", "dog"], ["the", "dog", "saw", "the", "cat"]]


def test_N_000279_quoted_empty_string_token_and_empty_production():
    g = CFG.fromstring("S -> 'a' '' | 'b' X\nX ->")
    sents = list(generate(g))
    assert ["a", ""] in sents
    assert ["b"] in sents


def test_N_000281_tree_from_label_and_children_equality():
    t = Tree("S", [Tree("NP", ["John"]), Tree("VP", ["ran"])])
    assert t == Tree.fromstring("(S (NP John) (VP ran))")
    assert len(t) == 2 and t[0] == Tree("NP", ["John"])
    assert t.leaves() == ["John", "ran"]


def test_N_000288_string_children_refused_and_missing_refused():
    with pytest.raises(TypeError):
        Tree("S", "John")
    with pytest.raises(TypeError):
        Tree("S")


def test_N_000291_empty_child_list_is_valid():
    t = Tree("S", [])
    assert len(t) == 0 and t.leaves() == []


def test_N_000287_pformat_shows_labels_and_leaves_in_preorder():
    t = Tree.fromstring("(S (NP John) (VP (V ran)))")
    text = t.pformat()
    order = [w for w in text.replace("(", " ").replace(")", " ").split()]
    assert order == ["S", "NP", "John", "VP", "V", "ran"]


def test_N_000489_bracketed_text_round_trip():
    t = Tree.fromstring("(S (NP (D the) (N dog)) (VP barked))")
    assert Tree.fromstring(t.pformat()) == t


def test_N_000487_bad_tree_text_raises():
    with pytest.raises(ParseError):
        Tree.fromstring("(S (NP John)")
