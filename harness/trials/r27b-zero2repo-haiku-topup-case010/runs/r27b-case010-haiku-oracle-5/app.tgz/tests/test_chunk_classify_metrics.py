# spec: N-000228 .. N-000257 (FP-04), N-000295 .. N-000318 (FP-06), N-000319 .. N-000348 (FP-07)
import pytest

from lingora import chunk as ch
from lingora import classify as cl
from lingora import metrics as m
from lingora.translate import bleu
from lingora.tree import Tree

TAGGED = [("the", "DT"), ("little", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("a", "DT"), ("cat", "NN")]


def test_N_000236_chunk_rule_matches_longest_left_to_right():
    t = ch.RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert [c.label() for c in t if isinstance(c, Tree)] == ["NP", "NP"]
    assert t[0].leaves() == [("the", "DT"), ("little", "JJ"), ("dog", "NN")]


def test_N_000250_leaves_are_exactly_input_pairs():
    t = ch.RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert t.leaves() == TAGGED


def test_N_000243_chink_splits_chunk():
    t = ch.RegexpParser("NP: {<DT|JJ|NN>+}\n  }<JJ>{").parse(TAGGED[:3])
    assert [c.label() for c in t if isinstance(c, Tree)] == ["NP", "NP"]
    assert ("little", "JJ") in list(t)


def test_N_000252_empty_input_gives_sentence_root_no_children():
    t = ch.RegexpParser("NP: {<NN>}").parse([])
    assert t.label() == "S" and len(t) == 0


def test_N_000253_bad_grammar_refused():
    with pytest.raises(TypeError):
        ch.RegexpParser(42)


def test_N_000246_later_clause_sees_chunks_as_units():
    t = ch.RegexpParser("NP: {<DT>?<NN>}\nVP: {<VBD><NP>}").parse(TAGGED[3:] + [("x", "NN")][:0] + TAGGED[:3])
    assert any(isinstance(c, Tree) and c.label() == "VP" for c in t)


def test_N_000257_ne_chunk_refused_without_resources(no_data):
    from lingora.errors import ResourceNotFoundError
    with pytest.raises(ResourceNotFoundError):
        ch.ne_chunk(TAGGED)


def test_N_000302_naive_bayes_classifies_and_probs_sum_to_one():
    nb = cl.NaiveBayesClassifier.train([({"w": "good"}, "pos"), ({"w": "bad"}, "neg"),
                                        ({"w": "great"}, "pos"), ({"w": "awful"}, "neg")])
    assert nb.classify({"w": "good"}) == "pos"
    assert nb.classify({"w": "awful"}) == "neg"
    dist = nb.prob_classify({"w": "good"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert sorted(nb.labels()) == ["neg", "pos"]


def test_N_000315_unseen_featureset_gets_a_trained_label():
    nb = cl.NaiveBayesClassifier.train([({"w": "a"}, "x"), ({"w": "b"}, "y")])
    assert nb.classify({"zzz": 1}) in {"x", "y"}
    dt = cl.DecisionTreeClassifier.train([({"w": "a"}, "x"), ({"w": "b"}, "y")])
    assert dt.classify({"zzz": 1}) in {"x", "y"}


def test_N_000310_decision_tree_separates_training_data():
    train = [({"a": 1, "b": 0}, "x"), ({"a": 0, "b": 1}, "y"), ({"a": 1, "b": 1}, "x"), ({"a": 0, "b": 0}, "y")]
    dt = cl.DecisionTreeClassifier.train(train)
    assert all(dt.classify(fs) == lab for fs, lab in train)


def test_N_000318_classifier_accuracy_and_list_length_metrics():
    nb = cl.NaiveBayesClassifier.train([({"w": "good"}, "pos"), ({"w": "bad"}, "neg")])
    assert cl.accuracy(nb, [({"w": "good"}, "pos"), ({"w": "bad"}, "neg")]) == 1.0
    with pytest.raises(ValueError):
        m.accuracy([1, 2], [1])


def test_N_000322_edit_distance_costs():
    assert m.edit_distance("kitten", "sitting") == 3
    assert m.edit_distance("kitten", "sitting", substitution_cost=2) == 5
    assert m.edit_distance("", "") == 0
    assert m.edit_distance("ab", "ba") == 2
    assert m.edit_distance("ab", "ba", transpositions=True) == 1
    assert m.edit_distance("ca", "abc", transpositions=True) == 2


def test_N_000328_edit_distance_symmetric_and_zero_to_self():
    assert m.edit_distance("flaw", "lawn") == m.edit_distance("lawn", "flaw")
    assert m.edit_distance("same", "same") == 0


def test_N_000330_jaccard_distance():
    assert m.jaccard_distance({1, 2, 3}, {2, 3, 4}) == pytest.approx(0.5)


def test_N_000332_precision_recall_f_measure():
    assert m.precision({1, 2}, {2, 3}) == 0.5
    assert m.recall({1, 2}, {2, 3}) == 0.5
    assert m.f_measure({1, 2}, {2, 3}) == pytest.approx(0.5)


def test_N_000344_no_number_cases_are_none():
    assert m.precision({1}, set()) is None
    assert m.recall(set(), {1}) is None
    assert m.f_measure({1}, {2}) is None


def test_N_000344_non_set_refused():
    with pytest.raises(TypeError):
        m.precision([1, 2], {1})


def test_N_000335_bleu_identical_and_zero_without_match():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["zzz"]) == 0.0


def test_N_000341_unsmoothed_zero_when_higher_order_missing():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) == 0.0


def test_N_000339_brevity_penalty_applies_to_short_candidate():
    ref = [["a", "b", "c", "d", "e", "f"]]
    assert bleu(ref, ["a", "b", "c", "d"], weights=(1,)) < 1.0
