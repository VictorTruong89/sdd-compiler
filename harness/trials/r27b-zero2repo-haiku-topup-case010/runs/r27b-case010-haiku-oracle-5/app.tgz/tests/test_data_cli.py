# spec: N-000385 .. N-000402 (lingora.data), N-000414 .. N-000420 (CLI)
import io
import sys

import pytest

from lingora import data
from lingora.cli import cli
from lingora.errors import ResourceNotFoundError


def test_N_000385_data_path_is_mutable_list_read_on_each_call(pkg_data, tmp_path):
    assert isinstance(data.path, list)
    data.path[:] = []
    with pytest.raises(ResourceNotFoundError):
        data.find("taggers/averaged_perceptron_tagger_eng")
    data.path[:] = [pkg_data]
    assert data.exists("taggers/averaged_perceptron_tagger_eng")


def test_N_000386_empty_list_means_nothing_visible(no_data):
    assert not data.exists("tokenizers/punkt_tab/english")


def test_N_000398_read_lines_strips_terminators(pkg_data):
    import os
    fp = os.path.join(pkg_data, "corpora", "stopwords")
    assert data.read_lines(fp, "english") == ["a", "the", "is"]


def test_N_000414_cli_tokenize_one_line_per_input(pkg_data, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello world. It works.\n\nlast line\n"))
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exc.value.code == 0
    assert capsys.readouterr().out == "Hello world . It works .\n\nlast line\n"


def test_N_000417_cli_failure_status_and_no_token_line(no_data, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello.\n"))
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exc.value.code != 0
    assert capsys.readouterr().out == ""


def test_N_000420_cli_delimiter_option(pkg_data, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("a b.\n"))
    assert cli.main(args=["tokenize", "-d", "|"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "a|b|.\n"
