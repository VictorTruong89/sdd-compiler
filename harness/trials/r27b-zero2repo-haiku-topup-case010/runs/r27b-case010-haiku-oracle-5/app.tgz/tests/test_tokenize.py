# spec: N-000081 .. N-000139, N-000403 .. N-000413 (FP-01 and lingora.tokenize)
import pytest

from lingora import tokenize as t
from lingora.errors import ResourceNotFoundError


def test_N_000089_wordpunct_runs():
    assert t.wordpunct_tokenize("Hello, world! 3.14 can't") == ["Hello", ",", "world", "!", "3", ".", "14", "can", "'", "t"]


def test_N_000136_empty_and_whitespace_yield_empty_list():
    assert t.wordpunct_tokenize("") == []
    assert t.WhitespaceTokenizer().tokenize("  \n\t ") == []
    assert t.TreebankWordTokenizer().tokenize("   ") == []


def test_N_000126_span_tokenize_slices_back_to_tokens():
    text = "Good  muffins, ok."
    spans = list(t.WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == t.WordPunctTokenizer().tokenize(text)
    prev_end = 0
    for s, e in spans:
        assert s >= prev_end and isinstance(s, int) and isinstance(e, int)
        prev_end = e


def test_N_000092_treebank_quotes_and_clitics():
    out = t.TreebankWordTokenizer().tokenize('"Good muffins cost $3.88 in New York." They\'ll gonna.')
    assert out == ["``", "Good", "muffins", "cost", "$", "3.88", "in", "New", "York.", "''", "They", "'ll", "gon", "na", "."]


def test_N_000100_point_split_only_at_end_of_text():
    assert t.TreebankWordTokenizer().tokenize("Mr. Smith") == ["Mr.", "Smith"]


def test_N_000099_comma_kept_before_digit():
    assert t.TreebankWordTokenizer().tokenize("1,000 and a, b") == ["1,000", "and", "a", ",", "b"]


def test_N_000102_fused_forms_split_treebank_but_cannot_kept_by_recommended():
    assert t.TreebankWordTokenizer().tokenize("cannot") == ["can", "not"]
    assert t.word_tokenize("cannot", preserve_line=True) == ["cannot"]


def test_N_000108_run_of_points_is_token_for_recommended():
    assert t.word_tokenize("wait.. ok", preserve_line=True) == ["wait", "..", "ok"]


def test_N_000109_double_hyphen_token_for_recommended():
    assert t.word_tokenize("a--b", preserve_line=True) == ["a", "--", "b"]


def test_N_000107_dash_and_asterisk_split_for_recommended():
    assert t.word_tokenize("a*b—c", preserve_line=True) == ["a", "*", "b", "—", "c"]


def test_N_000111_recommended_splits_sentences_first(pkg_data):
    assert t.word_tokenize("Hello world. This is it.") == ["Hello", "world", ".", "This", "is", "it", "."]


def test_N_000137_sentence_splitting_needs_model(no_data):
    with pytest.raises(ResourceNotFoundError):
        t.sent_tokenize("A sentence.")
    with pytest.raises(ResourceNotFoundError):
        t.word_tokenize("A sentence.")
    assert t.word_tokenize("A sentence.", preserve_line=True) == ["A", "sentence", "."]


def test_N_000129_punkt_keeps_abbreviations(pkg_data):
    sents = t.sent_tokenize("Mr. Smith went home. The dog barked! Did it?")
    assert sents == ["Mr. Smith went home.", "The dog barked!", "Did it?"]


def test_N_000114_blankline_segments():
    assert t.blankline_tokenize("a b\n\n\n c\nd\n\n") == ["a b", "c\nd"]


def test_N_000116_regexp_token_and_gap_modes():
    assert t.RegexpTokenizer(r"\d+").tokenize("a1b22") == ["1", "22"]
    assert t.RegexpTokenizer(r"\s+", gaps=True).tokenize("a  b c ") == ["a", "b", "c"]
    assert t.RegexpTokenizer(r"\s+", gaps=True, discard_empty=False).tokenize(" a") == ["", "a"]


def test_N_000119_tweet_contractions_emoticons_hashtags_urls():
    tok = t.TweetTokenizer().tokenize("@bob LOL :) I don't #Yay http://x.com")
    assert tok == ["@bob", "LOL", ":)", "I", "don't", "#Yay", "http://x.com"]
    assert "don't" in t.TweetTokenizer(preserve_case=False).tokenize("I don't")
    assert ":)" in t.TweetTokenizer(preserve_case=False).tokenize("Hi :)")


def test_N_000123_tweet_strip_handles_and_reduce_len():
    assert t.TweetTokenizer(strip_handles=True).tokenize("hi @bob there") == ["hi", "there"]
    assert t.TweetTokenizer(reduce_len=True).tokenize("nooooo") == ["nooo"]


def test_N_000125_tweet_lowercases_unless_preserved_except_emoticons():
    assert t.TweetTokenizer(preserve_case=False).tokenize("HeLLo :D") == ["hello", ":D"]
    assert t.TweetTokenizer().tokenize("HeLLo") == ["HeLLo"]


def test_N_000122_accented_words_stay_whole():
    assert t.TweetTokenizer().tokenize("café naïve") == ["café", "naïve"]


def test_N_000113_whitespace_tokens_and_span_offsets():
    assert t.WhitespaceTokenizer().tokenize("a\tb\nc") == ["a", "b", "c"]
    assert t.WhitespaceTokenizer().span_tokenize("ab  cd") == [(0, 2), (4, 6)]


def test_N_000405_pattern_must_be_str():
    with pytest.raises(TypeError):
        t.RegexpTokenizer(42)
