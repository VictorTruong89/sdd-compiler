"""Packaged-resource finder.

``data.path`` is a mutable list of directories searched for packaged resources.
The list is read on every lookup, so in-place edits by the caller take effect.

# spec: N-000385 N-000386 N-000387 N-000388 (data.path, initial contents chosen by the implementer)
# spec: N-000389 N-000390 N-000391 N-000392 N-000393 N-000394 N-000395 N-000396 N-000397 (resource names)
# spec: N-000398 N-000399 N-000400 N-000401 N-000402 (model file formats; parsed in punkt.py / tag.py / tokenize.py)
"""
import os

from .errors import ResourceNotFoundError

_env = os.environ.get("LINGORA_DATA", "")
path = [p for p in _env.split(os.pathsep) if p] + [
    os.path.join(os.path.expanduser("~"), "lingora_data"),
    "/usr/share/lingora",
    "/usr/local/share/lingora",
]

# Resource names, relative to a directory on data.path.
PUNKT = "tokenizers/punkt_tab/{language}"
PERCEPTRON_TAGGER = "taggers/averaged_perceptron_tagger_{lang}"
UNIVERSAL_TAGSET = "taggers/universal_tagset"
NE_CHUNKER = "chunkers/maxent_ne_chunker_tab/english_ace_multiclass"
WORDLIST = "corpora/words"
STOPWORDS = "corpora/stopwords/{language}"
WORDNET = "corpora/wordnet"


def find(relpath, kind="dir"):
    """Return the first existing ``<dir>/<relpath>`` on ``data.path``.

    Raises ResourceNotFoundError when no listed directory holds it.
    """
    for base in list(path):
        candidate = os.path.join(base, relpath)
        if kind == "dir" and os.path.isdir(candidate):
            return candidate
        if kind == "file" and os.path.isfile(candidate):
            return candidate
    raise ResourceNotFoundError(
        "packaged resource %r not found in data.path %r" % (relpath, list(path))
    )


def exists(relpath, kind="dir"):
    try:
        find(relpath, kind)
    except ResourceNotFoundError:
        return False
    return True


def read_lines(directory, filename):
    """Lines of a UTF-8 model file, without line terminators. Missing file -> []."""
    fp = os.path.join(directory, filename)
    if not os.path.isfile(fp):
        return []
    with open(fp, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]
