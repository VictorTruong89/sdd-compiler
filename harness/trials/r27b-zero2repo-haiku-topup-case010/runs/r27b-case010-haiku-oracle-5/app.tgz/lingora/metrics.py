"""Evaluation metrics.

# spec: N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329 N-000330 N-000331
# spec: N-000332 N-000333 N-000334 N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342
# spec: N-000343 N-000344 N-000345 N-000346 N-000347 N-000348
# spec: N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509 N-000510
# spec: N-000319 N-000320 N-000321
"""
from .translate import bleu  # noqa: F401  (BLEU is also exposed here)


def accuracy(reference, test):
    """Fraction of equal positions. Lists of different lengths raise ValueError."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("lists must have the same length")
    if not reference:
        raise ValueError("accuracy needs non-empty lists")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions=True`` the unrestricted Damerau-Levenshtein distance.

    Insertions and deletions cost 1; substitution costs ``substitution_cost``.
    # spec: N-000322 .. N-000329
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str arguments")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be bool")
    if not transpositions:
        prev = [j for j in range(len(s2) + 1)]
        for i in range(1, len(s1) + 1):
            cur = [i] + [0] * len(s2)
            for j in range(1, len(s2) + 1):
                cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            prev = cur
        return prev[len(s2)] if s2 or s1 else 0
    # Lowrance and Wagner (1975) unrestricted Damerau-Levenshtein.
    n, m = len(s1), len(s2)
    maxdist = n + m
    d = [[0] * (m + 2) for _ in range(n + 2)]
    d[0][0] = maxdist
    for i in range(n + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(m + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, n + 1):
        last_col = 0
        for j in range(1, m + 1):
            k = last_row.get(s2[j - 1], 0)
            l = last_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        last_row[s1[i - 1]] = i
    return d[n + 1][m + 1]


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union|. Two empty sets give 0."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    """|reference & test| / |test|; None when test is empty. Lists and tuples are refused."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; None when reference is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when no number results.

    No number results when either set is empty or the sets share no element (CF-000038: the
    boundary rule is taken over the zero-precision formula).
    """
    _check_sets(reference, test)
    if isinstance(alpha, bool) or not isinstance(alpha, (int, float)):
        raise TypeError("alpha must be a number")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or not (reference & test):
        return None
    return 1.0 / (alpha / p + (1 - alpha) / r)
