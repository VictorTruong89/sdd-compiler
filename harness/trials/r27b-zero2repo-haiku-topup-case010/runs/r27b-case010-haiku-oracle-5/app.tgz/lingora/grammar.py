"""Context-free grammars read from text.

# spec: N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470 N-000471
# spec: N-000264 N-000265  (grammar reader, FP-05)
"""
import re

from .errors import ParseError


class Nonterminal:
    """A nonterminal symbol. ``str()`` gives its name; it is not a ``str`` itself."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __hash__(self):
        return hash(("NT", self._symbol))


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (other._lhs, other._rhs) == (self._lhs, self._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs) or "")


_SYMBOL_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|([A-Za-z_][A-Za-z0-9_\-]*))""")


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for p in self._productions:
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ParseError("line %d: production needs '->'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_\-]*", lhs_text):
                raise ParseError("line %d: bad left-hand side %r" % (lineno, lhs_text))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alt in rhs_text.split("|"):
                symbols = []
                pos = 0
                alt_s = alt.strip()
                while pos < len(alt_s):
                    m = _SYMBOL_RE.match(alt_s, pos)
                    if not m or m.end() == pos:
                        raise ParseError("line %d: cannot read symbols in %r" % (lineno, alt_s))
                    if m.group(1) is not None:
                        symbols.append(m.group(1))
                    elif m.group(2) is not None:
                        symbols.append(m.group(2))
                    else:
                        symbols.append(Nonterminal(m.group(3)))
                    pos = m.end()
                    if alt_s[pos:].strip() == "":
                        break
                productions.append(Production(lhs, symbols))
        if start is None:
            raise ParseError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._by_lhs.get(lhs, []))

    def is_nonterminal(self, symbol):
        return isinstance(symbol, Nonterminal)

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    out.add(s)
        return out

    def __repr__(self):
        return "<CFG with %d productions, start %s>" % (len(self._productions), self._start)
