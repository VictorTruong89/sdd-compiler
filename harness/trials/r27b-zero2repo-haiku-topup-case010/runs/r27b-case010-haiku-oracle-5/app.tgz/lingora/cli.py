"""Command line: ``lingora tokenize`` reads stdin lines and writes one token line per input line.

Usage from Python: ``from lingora.cli import cli; cli.main(args=['tokenize'], standalone_mode=True)``.
Implemented with the standard library only (no click).

# spec: N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420
# spec: N-000083 N-000084 N-000085 N-000134 N-000135 N-000139
"""
import argparse
import sys

from . import punkt
from .errors import LingoraError
from .tokenize import word_tokenize


class _CLI:
    """A command group. ``main`` ends the process when ``standalone_mode`` is true."""

    prog = "lingora"

    def _parser(self):
        parser = argparse.ArgumentParser(prog=self.prog, description="LINGORA command line")
        sub = parser.add_subparsers(dest="command", required=True)
        tk = sub.add_parser("tokenize", help="tokenize each stdin line (recommended word tokenizer)")
        tk.add_argument("-l", "--language", default="english", help="Punkt language directory name")
        tk.add_argument("-d", "--delimiter", default=" ", help="token delimiter (default: one space)")
        tk.add_argument("-e", "--encoding", default="utf-8", help="input/output encoding")
        return parser

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        parser = self._parser()
        try:
            ns = parser.parse_args(list(args))
        except SystemExit as exc:
            if standalone_mode:
                raise
            return exc.code
        code = self._tokenize(ns.language, ns.delimiter, ns.encoding)
        if standalone_mode:
            sys.exit(code)
        return code

    def _tokenize(self, language, delimiter, encoding):
        # Check the Punkt model before any output, so a failure writes no token line.
        try:
            punkt.get_tokenizer(language)
        except LingoraError as exc:
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        if encoding:
            try:
                sys.stdin.reconfigure(encoding=encoding)
                sys.stdout.reconfigure(encoding=encoding)
            except (AttributeError, ValueError):
                pass
        for line in sys.stdin:
            line = line.rstrip("\r\n")
            try:
                tokens = word_tokenize(line, language=language)
            except LingoraError as exc:
                sys.stderr.write("lingora tokenize: %s\n" % exc)
                return 1
            sys.stdout.write(delimiter.join(tokens) + "\n")
        sys.stdout.flush()
        return 0


cli = _CLI()


def main():
    cli.main()


if __name__ == "__main__":
    main()
