"""Exception types shared across LINGORA.

# spec: N-000377 N-000378 N-000380 (calls that do not succeed raise; refusals never return empty values)
"""


class LingoraError(Exception):
    """Base class for every failure raised by LINGORA."""


class ResourceNotFoundError(LingoraError, LookupError):
    """A packaged resource a path needs is not visible on ``data.path``.

    # spec: N-000387 (a path that needs a packaged model fails observably)
    """


class UnsupportedError(LingoraError, ValueError):
    """An argument names something the library does not support."""


class ParseError(LingoraError, ValueError):
    """Grammar, tree, or rule text is malformed."""
