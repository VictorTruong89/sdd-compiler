"""Chunk parsing with chunk grammars (regular-expression chunking over tag sequences).

# spec: N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000457
# spec: N-000458 N-000459 N-000460
# spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235 N-000236 N-000237 N-000238 N-000239
# spec: N-000240 N-000241 N-000242 N-000243 N-000244 N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251
# spec: N-000252 N-000253 N-000254 N-000255 N-000256 N-000257
"""
import re

from . import data
from .errors import ParseError, ResourceNotFoundError
from .tree import Tree

ROOT_LABEL = "S"
_ELEMENT_RE = re.compile(r"<([^<>]*)>(\?|\*|\+|\{\d*,?\d*\})?")


class ChunkRule:
    """One stage: ``kind`` is 'chunk' or 'chink'; ``pattern`` is the tag pattern text."""

    __slots__ = ("label", "kind", "pattern", "_regex")

    def __init__(self, label, kind, pattern):
        if kind not in ("chunk", "chink"):
            raise ParseError("rule kind must be 'chunk' or 'chink'")
        self.label = label
        self.kind = kind
        self.pattern = pattern
        self._regex = _compile_tag_pattern(pattern)

    def __repr__(self):
        return "ChunkRule(%r, %r, %r)" % (self.label, self.kind, self.pattern)


def _compile_tag_pattern(pattern):
    """Translate a tag pattern to a regex over the string ``<tag1><tag2>...``."""
    text = re.sub(r"\s+", "", pattern)
    if not text:
        raise ParseError("empty tag pattern")
    out = []
    pos = 0
    while pos < len(text):
        m = _ELEMENT_RE.match(text, pos)
        if not m:
            raise ParseError("bad tag pattern near %r" % text[pos:pos + 10])
        content = m.group(1)
        if content == "":
            raise ParseError("empty tag element in pattern")
        # '.' matches any character of one tag, never a tag boundary
        content = re.sub(r"(?<!\\)\.", r"[^<>]", content)
        quant = m.group(2) or ""
        out.append("(?:<(?:%s)>)%s" % (content, quant))
        pos = m.end()
    try:
        return re.compile("".join(out))
    except re.error as exc:
        raise ParseError("bad tag pattern %r: %s" % (pattern, exc)) from exc


def parse_grammar(text):
    """Read a chunk grammar text into a list of ChunkRule objects (clause order preserved)."""
    rules = []
    label = None
    for lineno, raw in enumerate(text.splitlines(), 1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        line = raw.strip()
        continuation = line.startswith(("{", "}")) and label is not None
        if not continuation:
            m = re.match(r"^([^\s:{}<>]+)\s*:\s*(.*)$", line)
            if not m:
                raise ParseError("line %d: clause must start with '<LABEL>: <pattern>'" % lineno)
            label, body = m.group(1), m.group(2)
        else:
            body = line
        body = body.strip()
        if body.startswith("{") and body.endswith("}"):
            kind, inner = "chunk", body[1:-1]
        elif body.startswith("}") and body.endswith("{"):
            kind, inner = "chink", body[1:-1]
        else:
            raise ParseError("line %d: pattern must be {...} (chunk) or }...{ (chink)" % lineno)
        rules.append(ChunkRule(label, kind, inner))
    if not rules:
        raise ParseError("chunk grammar has no clauses")
    return rules


def _unit_tag(node):
    if isinstance(node, Tree):
        return node.label()
    return node[1]


def _find_matches(rule, tags):
    """Non-overlapping, left-to-right, non-empty matches as (start, end) unit indices."""
    s = "".join("<%s>" % t for t in tags)
    starts = {}
    ends = {}
    pos = 0
    for i, t in enumerate(tags):
        starts[pos] = i
        pos += len(t) + 2
        ends[pos] = i + 1
    spans = []
    for m in rule._regex.finditer(s):
        if m.end() == m.start():
            continue
        if m.start() in starts and m.end() in ends:
            spans.append((starts[m.start()], ends[m.end()]))
    return spans


def _segments(mask):
    """Runs of consecutive indices where mask is True."""
    runs = []
    start = None
    for i, ok in enumerate(mask):
        if ok and start is None:
            start = i
        elif not ok and start is not None:
            runs.append((start, i))
            start = None
    if start is not None:
        runs.append((start, len(mask)))
    return runs


def _apply_chunk(rule, nodes, own):
    """Chunk rule: matches among units that are not chunks built in this clause; touching matches join."""
    mask = [not (isinstance(n, Tree) and id(n) in own) for n in nodes]
    matches = []
    for a, b in _segments(mask):
        seg_tags = [_unit_tag(n) for n in nodes[a:b]]
        for s, e in _find_matches(rule, seg_tags):
            matches.append((a + s, a + e))
    matches.sort()
    merged = []
    for s, e in matches:
        if merged and merged[-1][1] == s:
            merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    if not merged:
        return nodes
    out = []
    pos = 0
    for s, e in merged:
        out.extend(nodes[pos:s])
        chunk = Tree(rule.label, nodes[s:e])
        own.add(id(chunk))
        out.append(chunk)
        pos = e
    out.extend(nodes[pos:])
    return out


def _apply_chink(rule, nodes, own):
    """Chink rule: removes matching tokens from chunks built earlier in this clause."""
    result = []
    for node in nodes:
        if not (isinstance(node, Tree) and id(node) in own):
            result.append(node)
            continue
        children = list(node)
        mask = [not isinstance(c, Tree) for c in children]
        removed = [False] * len(children)
        for a, b in _segments(mask):
            seg_tags = [c[1] for c in children[a:b]]
            for s, e in _find_matches(rule, seg_tags):
                for k in range(a + s, a + e):
                    removed[k] = True
        if not any(removed):
            result.append(node)
            continue
        group = []
        for child, gone in zip(children, removed):
            if gone:
                if group:
                    piece = Tree(node.label(), group)
                    own.add(id(piece))
                    result.append(piece)
                    group = []
                result.append(child)
            else:
                group.append(child)
        if group:
            piece = Tree(node.label(), group)
            own.add(id(piece))
            result.append(piece)
    return result


class RegexpParser:
    """Chunk parser built from a chunk grammar text (or a list of ChunkRule stages).

    # spec: N-000446 N-000449 N-000450 N-000451 N-000453 N-000454 N-000455 N-000456 N-000457 N-000458 N-000459 N-000460
    """

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._rules = parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(r, ChunkRule) for r in grammar):
            self._rules = list(grammar)
        else:
            raise TypeError("grammar must be a chunk grammar string or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        nodes = []
        for pair in tagged:
            if not (isinstance(pair, (list, tuple)) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            nodes.append((pair[0], pair[1]))
        # Group consecutive rules of the same clause label; each clause runs in order.
        clauses = []
        for rule in self._rules:
            if clauses and clauses[-1][0] == rule.label:
                clauses[-1][1].append(rule)
            else:
                clauses.append((rule.label, [rule]))
        for label, rules in clauses:
            own = set()
            for rule in rules:
                if rule.kind == "chunk":
                    nodes = _apply_chunk(_ClauseRule(rule), nodes, own)
                else:
                    nodes = _apply_chink(_ClauseRule(rule), nodes, own)
        return Tree(ROOT_LABEL, nodes)


class _ClauseRule:
    """Adapter giving a ChunkRule the label used for the chunks it builds."""

    def __init__(self, rule):
        self.label = rule.label
        self._regex = rule._regex


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Raises when its model or the English wordlist is not installed.

    # spec: N-000452 N-000257
    """
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    try:
        data.find(data.NE_CHUNKER)
        data.find(data.WORDLIST)
    except ResourceNotFoundError as exc:
        raise ResourceNotFoundError("named-entity chunker resources are not installed: %s" % exc) from exc
    raise NotImplementedError("the named-entity chunker model is not implemented in this build")
