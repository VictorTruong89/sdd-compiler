"""Parsers over a CFG and a token list.

# spec: N-000258 N-000259 N-000260 N-000261 N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
# spec: N-000272 N-000273 N-000274 N-000275 N-000292 N-000293 N-000294 N-000472 N-000473 N-000474 N-000475 N-000476
"""
from ..errors import UnsupportedError
from ..grammar import Nonterminal, CFG
from ..tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str")
        if tok not in known:
            # spec: N-000475 N-000476 / CF-000090 — raise, distinct from an empty parse set
            raise UnsupportedError("token %r is produced by no production of the grammar" % tok)


class ChartParser:
    """Exhaustive parser: every tree the grammar assigns to the tokens.

    # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
    """

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        active = set()

        def parse_sym(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            results = []
            for prod in self._grammar.productions(sym):
                for children in parse_seq(prod.rhs(), 0, i, j):
                    results.append(Tree(sym.symbol(), children))
            active.discard(key)
            memo[key] = results
            return results

        def parse_seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, Nonterminal):
                for mid in range(i, j + 1):
                    for sub in parse_sym(sym, i, mid):
                        for rest in parse_seq(rhs, k + 1, mid, j):
                            yield [sub] + rest
            else:
                if i < j and tokens[i] == sym:
                    for rest in parse_seq(rhs, k + 1, i + 1, j):
                        yield [sym] + rest
                elif sym == "" and i <= j:
                    # quoted empty terminal matches no input
                    for rest in parse_seq(rhs, k + 1, i, j):
                        yield rest

        return iter(parse_sym(self._grammar.start(), 0, n))


class ShiftReduceParser:
    """One left-to-right shift-reduce pass, no backtracking.

    # spec: N-000272 N-000273 N-000274 N-000275
    """

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        productions = [p for p in self._grammar.productions() if len(p.rhs()) > 0]
        stack = []  # items: str leaves or Tree
        pos = 0
        while True:
            reduced = False
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if len(stack) < k:
                    continue
                top = stack[len(stack) - k:]
                ok = True
                for sym, item in zip(rhs, top):
                    if isinstance(sym, Nonterminal):
                        if not (isinstance(item, Tree) and item.label() == sym.symbol()):
                            ok = False
                            break
                    else:
                        if not (isinstance(item, str) and not isinstance(item, Tree) and item == sym):
                            ok = False
                            break
                if ok:
                    children = stack[len(stack) - k:]
                    del stack[len(stack) - k:]
                    stack.append(Tree(prod.lhs().symbol(), children))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        start = self._grammar.start().symbol()
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


class RecursiveDescentParser:
    """Top-down parser that returns every tree (outside the specified parsers; provided for completeness)."""

    def __init__(self, grammar):
        self._chart = ChartParser(grammar)

    def parse(self, tokens):
        return self._chart.parse(tokens)
