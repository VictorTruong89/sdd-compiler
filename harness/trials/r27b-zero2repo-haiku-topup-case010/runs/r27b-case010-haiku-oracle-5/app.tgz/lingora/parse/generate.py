"""Enumerate sentences a grammar derives.

# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000477 N-000478 N-000479 N-000480
"""
from ..grammar import CFG, Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of str tokens) derived from ``start``.

    Productions are expanded in written order (leftmost first). ``depth`` bounds
    the derivation-tree depth; ``n`` bounds the number of sentences yielded.
    A quoted empty terminal yields an empty-string token; an empty production yields nothing.
    """
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        start_sym = grammar.start()
    elif isinstance(start, Nonterminal):
        start_sym = start
    else:
        start_sym = Nonterminal(str(start))
    if n is not None and n <= 0:
        return
    produced = 0
    # Each pending item is (symbol, level); a sentential form is a stack of pending items.
    stack0 = [(start_sym, 0)]

    def walk(pending, tokens):
        nonlocal produced
        if not pending:
            yield list(tokens)
            return
        (sym, level), rest = pending[0], pending[1:]
        if not isinstance(sym, Nonterminal):
            yield from walk(rest, tokens + [sym])
            return
        if depth is not None and level >= depth:
            return
        for prod in grammar.productions(sym):
            children = [(s, level + 1) for s in prod.rhs()]
            yield from walk(children + rest, tokens)

    for sentence in walk(stack0, []):
        yield sentence
        produced += 1
        if n is not None and produced >= n:
            return
