"""Constituent trees.

# spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488 N-000489 N-000490 N-000491
# spec: N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289 N-000290 N-000291
"""
import re

from .errors import ParseError

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled node with an ordered list of children (str leaves or Trees)."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if children is None or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed text ``(label child ...)``."""
        if not isinstance(s, str):
            raise TypeError("fromstring expects str")
        stack = []
        root = None
        toks = _TOKEN_RE.findall(s)
        i = 0
        while i < len(toks):
            t = toks[i]
            if t == "(":
                if i + 1 >= len(toks) or toks[i + 1] in ("(", ")"):
                    raise ParseError("missing label after '(' in tree text")
                node = cls(toks[i + 1], [])
                if stack:
                    stack[-1]._children.append(node)
                elif root is None:
                    root = node
                else:
                    raise ParseError("tree text has more than one root")
                stack.append(node)
                i += 2
            elif t == ")":
                if not stack:
                    raise ParseError("unbalanced ')' in tree text")
                stack.pop()
                i += 1
            else:
                if not stack:
                    raise ParseError("leaf outside any node in tree text")
                stack[-1]._children.append(t)
                i += 1
        if stack or root is None:
            raise ParseError("unbalanced or empty tree text")
        return root

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, i):
        return self._children[i]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        res = self.__eq__(other)
        return res if res is NotImplemented else not res

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    @staticmethod
    def _leaf_text(leaf):
        if isinstance(leaf, tuple) and len(leaf) == 2:
            return "%s/%s" % (leaf[0], leaf[1])
        return str(leaf)

    def _flat(self):
        parts = []
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(self._leaf_text(child))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, width=70):
        """Pretty-printed bracketed text; every label and leaf appears in pre-order."""
        return self._pformat(0, width)

    def _pformat(self, indent, width):
        flat = self._flat()
        if len(flat) + indent <= width or not any(isinstance(c, Tree) for c in self._children):
            return " " * indent + flat
        lines = ["%s(%s" % (" " * indent, self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child._pformat(indent + 2, width))
            else:
                lines.append("%s%s" % (" " * (indent + 2), self._leaf_text(child)))
        lines[-1] += ")"
        return "\n".join(lines)

    def __str__(self):
        return self.pformat()
