"""Stemmers.

# spec: N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000151 N-000152
# spec: N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164
# spec: N-000165 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000174 N-000175 N-000176
# spec: N-000177 N-000178 N-000179 N-000180 N-000181 N-000182 N-000183 N-000184 N-000185 N-000186
# spec: N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428 N-000429 N-000430 N-000431 N-000432
"""
import re

from . import data
from .errors import ResourceNotFoundError, UnsupportedError

ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
LINGORA_EXTENSIONS = "LINGORA_EXTENSIONS"

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian", "italian",
    "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)

# Small built-in table of irregular forms (entries are outside the specification).
_IRREGULAR = {
    "sky": "sky", "skis": "ski", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
    "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}

_VOWELS_PLAIN = "aeiou"


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be str")


def _check_bool(name, value):
    if not isinstance(value, bool):
        raise TypeError("%s must be bool" % name)


# =========================================================================== Porter
class PorterStemmer:
    """M. F. Porter's algorithm (1980).

    ``mode`` selects ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, or LINGORA_EXTENSIONS (the default).
    # spec: N-000149 N-000150 N-000151 N-000153 .. N-000169
    """

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in (ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, LINGORA_EXTENSIONS):
            raise UnsupportedError("unknown Porter mode %r" % (mode,))
        self._mode = mode
        self._lingora = mode == LINGORA_EXTENSIONS
        self._martin = mode in (MARTIN_EXTENSIONS, LINGORA_EXTENSIONS)

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        _check_bool("to_lowercase", to_lowercase)
        if to_lowercase:
            word = word.lower()
        if self._lingora and word in _IRREGULAR:
            return _IRREGULAR[word]
        if len(word) <= 2:
            return word
        w = self._step1a(word)
        w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5(w)
        return w

    # ---- helpers -----------------------------------------------------------
    @staticmethod
    def _cons(w, i):
        ch = w[i]
        if ch in "aeiou":
            return False
        if ch == "y":
            return i == 0 or not PorterStemmer._cons(w, i - 1)
        return True

    @classmethod
    def _measure(cls, stem):
        forms = "".join("c" if cls._cons(stem, i) else "v" for i in range(len(stem)))
        forms = re.sub(r"c+", "c", re.sub(r"v+", "v", forms))
        return forms.count("vc")

    @classmethod
    def _has_vowel(cls, stem):
        return any(not cls._cons(stem, i) for i in range(len(stem)))

    def _ends_cvc(self, stem):
        if len(stem) == 2 and self._lingora:
            # LINGORA extension: a two-letter stem of vowel then consonant also counts.
            return (not self._cons(stem, 0)) and self._cons(stem, 1) and stem[1] not in "wxy"
        if len(stem) < 3:
            return False
        return (self._cons(stem, -3) and not self._cons(stem, -2) and self._cons(stem, -1)
                and stem[-1] not in "wxy")

    @staticmethod
    def _first_match(w, table):
        for suffix, repl in table:
            if w.endswith(suffix):
                return suffix, repl
        return None

    # ---- steps -------------------------------------------------------------
    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if self._lingora and len(w) == 4:
                return w[:-1]  # -ies -> -ie
            return w[:-2]  # -ies -> -i
        if w.endswith("ss"):
            return w
        if w.endswith("s") and self._has_vowel(w[:-1]):
            return w[:-1]
        return w

    def _step1b(self, w):
        if self._lingora and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            stem = w[:-3]
            return stem + "ee" if self._measure(stem) > 0 else w
        removed = False
        for suffix in ("ed", "ing"):
            if w.endswith(suffix) and self._has_vowel(w[:-len(suffix)]):
                w = w[:-len(suffix)]
                removed = True
                break
        if not removed:
            return w
        if w.endswith(("at", "bl", "iz")):
            return w + "e"
        if len(w) >= 2 and w[-1] == w[-2] and w[-1] not in "lsz" and self._cons(w, len(w) - 1):
            return w[:-1]
        if self._measure(w) == 1 and self._ends_cvc(w):
            return w + "e"
        return w

    def _step1c(self, w):
        if w.endswith("y"):
            if self._lingora:
                if len(w) > 2 and self._cons(w, len(w) - 2):
                    return w[:-1] + "i"
            elif self._has_vowel(w[:-1]):
                return w[:-1] + "i"
        return w

    _STEP2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("izer", "ize"),
        ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"), ("ousli", "ous"),
        ("ization", "ize"), ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("iveness", "ive"),
        ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
    ]

    def _step2(self, w):
        if self._lingora and w.endswith("alli") and self._measure(w[:-4]) > 0:
            return self._step2(w[:-4] + "al")  # -alli -> -al is tried first, then Step 2 again
        table = list(self._STEP2)
        if self._martin:
            # bli -> ble replaces abli -> able; logi and fulli are added.
            table = [(s, r) for s, r in table if s != "abli"]
            table.insert(table.index(("entli", "ent")), ("bli", "ble"))
        if self._lingora:
            table.append(("fulli", "ful"))
        hit = self._first_match(w, table)
        if hit is None:
            if self._martin and w.endswith("logi") and self._measure(w[:-3]) > 0:
                return w[:-1]
            return w
        suffix, repl = hit
        stem = w[:-len(suffix)]
        return stem + repl if self._measure(stem) > 0 else w

    _STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"),
              ("ful", ""), ("ness", "")]

    def _step3(self, w):
        hit = self._first_match(w, self._STEP3)
        if hit is None:
            return w
        suffix, repl = hit
        stem = w[:-len(suffix)]
        return stem + repl if self._measure(stem) > 0 else w

    _STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
              "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize"]

    def _step4(self, w):
        for suffix in self._STEP4:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if suffix == "ion":
                    if stem and stem[-1] in "st" and self._measure(stem) > 1:
                        return stem
                    return w
                return stem if self._measure(stem) > 1 else w
        return w

    def _step5(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = self._measure(stem)
            if m > 1 or (m == 1 and not self._ends_cvc(stem)):
                w = stem
        if self._measure(w) > 1 and w.endswith("ll"):
            w = w[:-1]
        return w


# =========================================================================== Porter2 (Snowball english)
_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
    "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
    "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_P2_LI = set("cdeghkmnrt")
_P2_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"), ("entli", "ent"),
    ("izer", "ize"), ("ization", "ize"), ("ational", "ate"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
    ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
]
_P2_STEP3 = [("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
             ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", "")]
_P2_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
             "ism", "ate", "iti", "ous", "ive", "ize", "ion"]


def _p2_regions(w):
    """R1 and R2 start indices (len(w) when empty)."""
    def region(word, start=0):
        for i in range(max(start, 1), len(word)):
            if word[i] not in "aeiouy" and word[i - 1] in "aeiouy":
                return i + 1
        return len(word)
    r1 = None
    for prefix in ("gener", "commun", "arsen"):
        if w.startswith(prefix):
            r1 = len(prefix)
            break
    if r1 is None:
        r1 = region(w)
    r2 = region(w, r1)
    return r1, r2


_SHORT_END_A = re.compile(r"[^aeiouy][aeiouy][^aeiouwxY]$")


def _p2_short_syllable_end(w):
    return bool(_SHORT_END_A.search(w)) or bool(re.fullmatch(r"[aeiouy][^aeiouy]", w))


def _porter2(word):
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    w = word[1:] if word.startswith("'") else word
    if len(w) <= 2:
        return w.replace("Y", "y")
    chars = list(w)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in "aeiouy":
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        stem = w[:-3]
        w = stem + ("i" if len(stem) > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s") and any(c in "aeiouy" for c in w[:-2]):
        w = w[:-1]
    if w in _P2_EXC2:
        return w.replace("Y", "y")
    # Step 1b
    r1, r2 = _p2_regions(w)
    if w.endswith(("eedly", "eed")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix) and any(c in "aeiouy" for c in w[:-len(suffix)]):
                w = w[:-len(suffix)]
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(_P2_DOUBLES):
                    w = w[:-1]
                elif _p2_short_syllable_end(w) and _p2_regions(w)[0] >= len(w):
                    w += "e"
                break
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in "aeiouy":
        w = w[:-1] + "i"
    # Step 2
    r1, r2 = _p2_regions(w)
    for suffix, repl in _P2_STEP2:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                if suffix == "ogi":
                    if w[-4:-3] == "l":
                        w = w[:-3] + "og"
                elif suffix == "li":
                    if w[-3:-2] in _P2_LI:
                        w = w[:-2]
                else:
                    w = w[:-len(suffix)] + repl
            break
    # Step 3
    r1, r2 = _p2_regions(w)
    for suffix, repl in _P2_STEP3:
        if w.endswith(suffix):
            start = len(w) - len(suffix)
            if suffix == "ative":
                if start >= r2:
                    w = w[:start] + repl
            elif start >= r1:
                w = w[:start] + repl
            break
    # Step 4
    r1, r2 = _p2_regions(w)
    for suffix in _P2_STEP4:
        if w.endswith(suffix):
            start = len(w) - len(suffix)
            if start >= r2:
                if suffix == "ion":
                    if start >= 1 and w[start - 1] in "st":
                        w = w[:start]
                else:
                    w = w[:start]
            break
    # Step 5
    r1, r2 = _p2_regions(w)
    if w.endswith("e"):
        if len(w) - 1 >= r2:
            w = w[:-1]
        elif len(w) - 1 >= r1 and not _p2_short_syllable_end(w[:-1]):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]
    return w.replace("Y", "y")


# =========================================================================== Lancaster (Paice/Husk)
# Rule table in Paice/Husk notation: reversed suffix, '*' = only while intact, digit = letters
# removed, optional replacement letters, '.' = stop after applying, '>' = continue.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "earth3>", "eh1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.",
    "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.",
    "lib2l>", "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.",
    "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.",
    "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.",
    "rei3y>", "sei2>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpm1.", "tu2.", "uq1.",
    "ud*1.", "ue2>", "up1.", "us*2>", "uu1.", "vsi3>", "vis3j>", "vie5>", "yl2>", "ylb1>",
    "yli3y>", "ym1>", "yrtsi5.", "zi2>", "zy1s.",
]
_LANCASTER_PARSED = []
for _rule in _LANCASTER_RULES:
    _m = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>])", _rule)
    if _m:
        _LANCASTER_PARSED.append((_m.group(1)[::-1], bool(_m.group(2)), int(_m.group(3)),
                                  _m.group(4), _m.group(5)))


class LancasterStemmer:
    """Paice/Husk stemmer. Lowercases the word; strips no prefix.

    # spec: N-000170 N-000171
    """

    MIN_STEM = 2

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        while True:
            for suffix, star, remove, repl, end in _LANCASTER_PARSED:
                if not w.endswith(suffix) or (star and not intact):
                    continue
                if remove == 0 and end == ">":
                    continue
                stem = w[:len(w) - remove]
                if len(stem) < self.MIN_STEM:
                    continue
                w = stem + repl
                intact = False
                if end == ".":
                    return w
                break
            else:
                return w


# =========================================================================== regexp / snowball / misc
class RegexpStemmer:
    """Removes every match of ``regexp`` from the word; nothing else changes.

    # spec: N-000178 N-000179 N-000180
    """

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be str")
        self._re = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._re.sub("", word)


class SnowballStemmer:
    """Snowball stemmers. ``language`` must be one of SNOWBALL_LANGUAGES.

    Implemented here: ``english`` (Porter2) and ``porter`` (the original Porter algorithm, as
    Snowball renders it). The other listed languages are validated but not implemented, so
    constructing them raises NotImplementedError.

    # spec: N-000172 N-000174 N-000175 N-000176 N-000177 N-000181 N-000182 N-000183 N-000184
    """

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise UnsupportedError("unsupported Snowball language %r" % (language,))
        _check_bool("ignore_stopwords", ignore_stopwords)
        self._language = language
        self._stopwords = frozenset()
        if ignore_stopwords:
            try:
                path = data.find(data.STOPWORDS.format(language=language), kind="file")
            except ResourceNotFoundError as exc:
                raise ResourceNotFoundError("stopwords list for %r is not installed" % language) from exc
            with open(path, encoding="utf-8") as fh:
                self._stopwords = frozenset(line.strip() for line in fh if line.strip())
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball algorithm for %r is not implemented in this build" % language)

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if w in self._stopwords:
            return w
        if self._language == "porter":
            return PorterStemmer(ORIGINAL_ALGORITHM).stem(w, to_lowercase=False)
        return _porter2(w)


class WordNetLemmatizer:
    """WordNet lemmatizer. Requires the packaged WordNet resource.

    # spec: N-000432 (raises when WordNet is not visible)
    """

    def __init__(self):
        data.find(data.WORDNET)  # raises ResourceNotFoundError when absent

    def lemmatize(self, word):
        _check_word(word)
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")


class ARLSTem:
    """Arabic light stemmer (outside this specification; construction is allowed, stem is not implemented)."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    """Arabic light stemmer v2 (outside this specification)."""
