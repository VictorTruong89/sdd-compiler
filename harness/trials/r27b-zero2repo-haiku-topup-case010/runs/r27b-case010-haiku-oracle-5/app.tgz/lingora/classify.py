"""Naive Bayes and decision-tree classifiers over featuresets.

# spec: N-000492 N-000493 N-000494 N-000495 N-000496 N-000497
# spec: N-000295 N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305
# spec: N-000306 N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
# spec: N-000318
"""
import math
from collections import Counter, defaultdict


def _check_labeled(labeled):
    if isinstance(labeled, str) or not isinstance(labeled, (list, tuple)):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    out = []
    for item in labeled:
        if not (isinstance(item, (list, tuple)) and len(item) == 2):
            raise TypeError("each item must be a (featureset, label) pair")
        fs, label = item
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
        out.append((dict(fs), label))
    return out


class ProbDist:
    """Probability distribution over labels. ``prob(label)`` is a float; ``samples()`` lists labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda k: (self._probs[k], str(k)))

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with smoothed feature-value estimates (no zero probabilities).

    # spec: N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
    """

    def __init__(self, label_counts, value_counts, feature_values, total):
        self._label_counts = label_counts          # label -> count
        self._value_counts = value_counts          # (label, feature, value) -> count
        self._feature_values = feature_values      # feature -> set of values seen
        self._total = total

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        value_counts = Counter()
        feature_values = defaultdict(set)
        for fs, label in labeled:
            label_counts[label] += 1
            for feat, value in fs.items():
                value_counts[(label, feat, value)] += 1
                feature_values[feat].add(value)
        return cls(label_counts, value_counts, dict(feature_values), len(labeled))

    def labels(self):
        return list(self._label_counts.keys())

    def _log_scores(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = {}
        for label, n_label in self._label_counts.items():
            logp = math.log(n_label / self._total)
            for feat, value in featureset.items():
                if feat not in self._feature_values:
                    continue  # a feature never seen in training is ignored
                b = len(self._feature_values[feat]) + 1
                c = self._value_counts.get((label, feat, value), 0)
                logp += math.log((c + 0.5) / (n_label + 0.5 * b))
            scores[label] = logp
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {k: math.exp(v - top) for k, v in scores.items()}
        z = sum(exps.values())
        return ProbDist({k: v / z for k, v in exps.items()})

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = None
        for label in self.labels():
            if best is None or scores[label] > scores[best]:
                best = label
        return best


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(counts, n):
    h = 0.0
    for c in counts.values():
        if c:
            p = c / n
            h -= p * math.log2(p)
    return h


class DecisionTreeClassifier:
    """ID3-style tree: at each node the feature with the greatest information gain is tested.

    A feature absent from a featureset counts as having the value ``None``.
    # spec: N-000310 N-000311 N-000312 N-000313 N-000314 N-000315 N-000316 N-000317
    """

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        features = set()
        for fs, _ in labeled:
            features.update(fs.keys())

        def majority(examples):
            counts = Counter(label for _, label in examples)
            return sorted(counts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

        def build(examples, avail):
            counts = Counter(label for _, label in examples)
            if len(counts) == 1 or not avail:
                return _Leaf(majority(examples))
            n = len(examples)
            base = _entropy(counts, n)
            best_feat, best_gain = None, 0.0
            for feat in sorted(avail, key=str):
                groups = defaultdict(list)
                for fs, label in examples:
                    groups[fs.get(feat)].append((fs, label))
                remainder = 0.0
                for group in groups.values():
                    gc = Counter(label for _, label in group)
                    remainder += len(group) / n * _entropy(gc, len(group))
                gain = base - remainder
                if gain > best_gain + 1e-12:
                    best_feat, best_gain = feat, gain
            if best_feat is None:
                return _Leaf(majority(examples))
            groups = defaultdict(list)
            for fs, label in examples:
                groups[fs.get(best_feat)].append((fs, label))
            children = {value: build(group, avail - {best_feat}) for value, group in groups.items()}
            return _Node(best_feat, children, majority(examples))

        if not labeled:
            raise ValueError("cannot train a decision tree on no examples")
        return cls(build(labeled, features))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.default
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    gold = _check_labeled(gold)
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
