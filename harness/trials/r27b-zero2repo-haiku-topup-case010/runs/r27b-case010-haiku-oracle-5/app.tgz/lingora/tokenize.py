"""Word, punctuation and sentence tokenizers.

# spec: N-000081 N-000082 N-000083 N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091
# spec: N-000092 N-000093 N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103
# spec: N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112
# spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125
# spec: N-000126 N-000127 N-000128 N-000134 N-000135 N-000136 N-000138 N-000139
# spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412 N-000413
"""
import re

from . import punkt
from .errors import UnsupportedError

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
    "WordPunctTokenizer", "blankline_tokenize", "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be str, got %s" % type(text).__name__)


def _check_bool(name, value):
    if not isinstance(value, bool):
        raise TypeError("%s must be bool" % name)


# --------------------------------------------------------------------------- word/punctuation
_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-whitespace characters."""

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in _WORDPUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# --------------------------------------------------------------------------- Penn Treebank
_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r"([ (\[{<])(\"|'{2})"), r"\1 `` "),
]
_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]
_PARENS_BRACKETS = re.compile(r"[\]\[\(\)\{\}<>]")
_ENDING_QUOTES = [
    (re.compile(r'"'), " '' "),
    (re.compile(r"(\S)('')"), r"\1 \2 "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]
_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_CONTRACTIONS3 = [
    re.compile(r"(?i) ('t)(is)\b"),
    re.compile(r"(?i) ('t)(was)\b"),
]


def _treebank_core(text, recommended):
    for regexp, sub in _STARTING_QUOTES:
        text = regexp.sub(sub, text)
    if recommended:
        text = re.sub(r"([“”„‘’«»])", r" \1 ", text)
        text = re.sub(r"([‒-―*])", r" \1 ", text)
        text = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), text)
        text = re.sub(r"--", " -- ", text)
        punct = [p for p in _PUNCTUATION if p[0].pattern != r"\.\.\."]
    else:
        punct = _PUNCTUATION
    for regexp, sub in punct:
        text = regexp.sub(sub, text)
    text = _PARENS_BRACKETS.sub(r" \g<0> ", text)
    text = " " + text + " "
    for regexp, sub in _ENDING_QUOTES:
        text = regexp.sub(sub, text)
    if not recommended:
        for regexp in _CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
    else:
        for regexp in _CONTRACTIONS2[1:]:
            text = regexp.sub(r" \1 \2 ", text)
    for regexp in _CONTRACTIONS3:
        text = regexp.sub(r" \1 \2 ", text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank tokenization conventions.

    # spec: N-000092 .. N-000103
    """

    def tokenize(self, text):
        _check_text(text)
        return _treebank_core(text, recommended=False)


class _RecommendedWordTokenizer:
    """The recommended word tokenizer: Treebank conventions with LINGORA's improvements."""

    def tokenize_line(self, text):
        return _treebank_core(text, recommended=True)


def _sentences(text, language):
    tokenizer = punkt.get_tokenizer(language)
    return tokenizer.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer. With preserve_line=False it first splits sentences (needs Punkt)."""
    _check_text(text)
    _check_bool("preserve_line", preserve_line)
    if not isinstance(language, str):
        raise TypeError("language must be str")
    if preserve_line:
        sentences = [text]
    else:
        sentences = _sentences(text, language)
    tokens = []
    rec = _RecommendedWordTokenizer()
    for sent in sentences:
        tokens.extend(rec.tokenize_line(sent))
    return tokens


def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (Punkt). Raises when the Punkt model is not visible."""
    _check_text(text)
    if not isinstance(language, str):
        raise TypeError("language must be str")
    return _sentences(text, language)


# --------------------------------------------------------------------------- whitespace / blank line
class WhitespaceTokenizer:
    _re = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in self._re.finditer(text)]


_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    _check_text(text)
    return [seg for seg in _BLANKLINE_SEP.split(text) if seg]


# --------------------------------------------------------------------------- regexp
class RegexpTokenizer:
    """Tokens are pattern matches (token mode) or the pieces between matches (gap mode).

    ``discard_empty`` defaults to True (PRD FP-01): empty pieces are dropped.
    # spec: N-000116 N-000117 N-000118
    """

    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be str")
        _check_bool("gaps", gaps)
        _check_bool("discard_empty", discard_empty)
        self._pattern = re.compile(pattern)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            pieces = []
            pos = 0
            for m in self._pattern.finditer(text):
                pieces.append(text[pos:m.start()])
                pos = m.end()
            pieces.append(text[pos:])
        else:
            pieces = [m.group(0) for m in self._pattern.finditer(text)]
        if self._discard_empty:
            pieces = [p for p in pieces if p]
        return pieces

    def span_tokenize(self, text):
        _check_text(text)
        spans = []
        if self._gaps:
            pos = 0
            for m in self._pattern.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._pattern.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


# --------------------------------------------------------------------------- tweet
_EMOTICON = r"(?:[<>]?[:;=8][\-o\*']?[\)\]\(\[dDpP/:\}\{@\|\\]|<3|</?3|\^_\^|[\)\]\(\[dDpP/:\}\{@\|\\][\-o\*']?[:;=8][<>]?)"
_URL = r"(?:https?://|www\.)\S+"
_HANDLE = r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}"
_HASHTAG = r"#\w+"
_WORD = r"\w+(?:['’\-]\w+)*"
_TWEET_RE = re.compile(
    r"(?P<emo>(?i:%s))|(?P<url>%s)|(?P<handle>%s)|(?P<hash>%s)|(?P<word>%s)|(?P<punct>\.{2,}|[!?]+|[^\w\s])"
    % (_EMOTICON, _URL, _HANDLE, _HASHTAG, _WORD)
)
_HANDLE_RE = re.compile(_HANDLE)


class TweetTokenizer:
    """Tweet-aware tokenizer.

    ``preserve_case`` (default True) keeps case. The spec's default-off lowercasing is
    applied when ``preserve_case=False``: tokens are lowercased except emoticons (PRD FP-01, CF-000054).
    ``strip_handles`` and ``reduce_len`` default to False.
    """

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        _check_bool("preserve_case", preserve_case)
        _check_bool("reduce_len", reduce_len)
        _check_bool("strip_handles", strip_handles)
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.DOTALL)
        out = []
        for m in _TWEET_RE.finditer(text):
            tok = m.group(0)
            if m.lastgroup == "emo" or self._preserve_case:
                out.append(tok)
            else:
                out.append(tok.lower())
        return out

