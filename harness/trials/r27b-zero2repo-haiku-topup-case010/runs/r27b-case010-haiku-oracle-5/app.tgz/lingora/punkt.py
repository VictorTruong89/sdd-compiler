"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006), reading packaged parameters.

# spec: N-000129 N-000130 N-000131 N-000132 N-000133 N-000137 N-000138 N-000413
"""
import os
import re

from . import data
from .errors import ResourceNotFoundError

_CLOSERS = "\"')]}>»”’"
_NUMBER_RE = re.compile(r"^-?[.,]?\d[\d,.\-]*\.?$")

# ortho_context bit flags (see pack 06)
ORTHO_UC_START = 2
ORTHO_UC_MID = 4
ORTHO_UC_UNK = 8
ORTHO_LC_START = 16
ORTHO_LC_MID = 32
ORTHO_LC_UNK = 64


class PunktParameters:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = set(abbrev_types)
        self.sent_starters = set(sent_starters)
        self.collocations = set(collocations)
        self.ortho_context = dict(ortho_context)


def _type_of(word):
    """Punkt type: lowercased, final period removed, numbers collapsed."""
    w = word.lower()
    if _NUMBER_RE.match(w):
        return "##number##"
    return w


def load_parameters(language):
    """Load the packaged Punkt model for ``language``. Raises ResourceNotFoundError if absent."""
    directory = data.find(data.PUNKT.format(language=language))
    abbrev = [l.strip() for l in data.read_lines(directory, "abbrev_types.txt") if l.strip()]
    starters = [l.strip() for l in data.read_lines(directory, "sent_starters.txt") if l.strip()]
    colloc = set()
    for line in data.read_lines(directory, "collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for line in data.read_lines(directory, "ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    return PunktParameters(abbrev, starters, colloc, ortho)


_cache = {}


def parameters_for(language):
    """Cached parameters, keyed by the resolved model directory so data.path edits are honoured."""
    directory = data.find(data.PUNKT.format(language=language))
    if directory not in _cache:
        _cache[directory] = load_parameters(language)
    return _cache[directory]


class _Tok:
    __slots__ = ("text", "start", "end", "type", "period", "ellipsis", "upper", "lower", "abbr", "initial")

    def __init__(self, text, start, end):
        self.text = text
        self.start = start
        self.end = end
        core = text.lstrip("\"'([{<“‘«")
        core_stripped = core.rstrip(_CLOSERS)
        self.period = core_stripped.endswith(".") or core_stripped.endswith("!") or core_stripped.endswith("?")
        self.ellipsis = core_stripped.endswith("...") or core_stripped.endswith("..")
        bare = core_stripped.rstrip(".!?")
        self.type = _type_of(bare) if bare else ""
        first = bare[:1]
        self.upper = first.isupper()
        self.lower = first.islower()
        self.initial = len(bare) == 1 and first.isalpha() and first.isupper()
        self.abbr = False


class PunktSentenceTokenizer:
    """Split text into sentences with the packaged Punkt parameters of one language."""

    def __init__(self, language="english"):
        self.language = language
        self.params = parameters_for(language)

    def _tokens(self, text):
        return [_Tok(m.group(0), m.start(), m.end()) for m in re.finditer(r"\S+", text)]

    def _ortho(self, tok):
        return self.params.ortho_context.get(tok.type, 0)

    def _is_abbrev(self, tok):
        p = self.params
        if tok.type in p.abbrev_types:
            return True
        return tok.initial

    def _breaks_after(self, t1, t2, parastart):
        """Decide whether a sentence boundary falls after token t1 (which ends a sentence-like unit)."""
        if t2 is None:
            return True
        p = self.params
        if t2.type in p.sent_starters and t2.upper:
            return True
        if t1.type and (t1.type, t2.type) in p.collocations:
            return False
        if parastart:
            return True
        if self._is_abbrev(t1) or t1.ellipsis or t1.type == "##number##":
            if not t2.upper:
                return False
            obs = self._ortho(t2)
            # the next word is seen capitalised only at sentence starts
            return bool(obs & ORTHO_UC_START) and not (obs & ORTHO_UC_MID)
        if t2.lower and not t1.text.rstrip(_CLOSERS).endswith(("!", "?")):
            return False
        return True

    def tokenize_spans(self, text):
        """Return ``[(start, end), ...]`` character spans, one per sentence."""
        toks = self._tokens(text)
        if not toks:
            return []
        spans = []
        sent_start = toks[0].start
        for idx, tok in enumerate(toks):
            if not tok.period:
                continue
            t2 = toks[idx + 1] if idx + 1 < len(toks) else None
            # newline before the next token is a paragraph-like break
            parastart = False
            if t2 is not None:
                gap = text[tok.end:t2.start]
                parastart = gap.count("\n") >= 2
            if self._breaks_after(tok, t2, parastart):
                spans.append((sent_start, tok.end))
                if t2 is not None:
                    sent_start = t2.start
        if sent_start is not None and (not spans or spans[-1][1] != toks[-1].end):
            spans.append((sent_start, toks[-1].end))
        return spans

    def tokenize(self, text):
        return [text[s:e] for s, e in self.tokenize_spans(text)]


def get_tokenizer(language="english"):
    """A PunktSentenceTokenizer, raising ResourceNotFoundError when the model is not visible."""
    if not isinstance(language, str):
        raise TypeError("language must be str")
    try:
        data.find(data.PUNKT.format(language=language))
    except ResourceNotFoundError as exc:
        raise ResourceNotFoundError(
            "Punkt sentence models for language %r are not installed: %s" % (language, exc)
        ) from exc
    return PunktSentenceTokenizer(language)
