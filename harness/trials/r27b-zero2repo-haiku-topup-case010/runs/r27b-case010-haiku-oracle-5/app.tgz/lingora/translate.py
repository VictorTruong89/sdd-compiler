"""BLEU score (Papineni et al., 2002), sentence level.

# spec: N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
# spec: N-000335 N-000336 N-000337 N-000338 N-000339 N-000340 N-000341 N-000342
"""
import math
from collections import Counter

DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _check_tokens(seq, what):
    if isinstance(seq, str) or not isinstance(seq, (list, tuple)):
        raise TypeError("%s must be a list of str tokens" % what)
    for t in seq:
        if not isinstance(t, str):
            raise TypeError("%s must contain str tokens" % what)
    return list(seq)


def bleu(references, hypothesis, weights=DEFAULT_WEIGHTS, smoothing_function=None):
    """BLEU of ``hypothesis`` against ``references`` (lists of token lists).

    ``weights`` gives one weight per n-gram order from unigrams. Unsmoothed unless
    ``smoothing_function`` is given: a callable taking a list of (matches, total) pairs per order
    and returning a list of precisions.
    """
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    refs = [_check_tokens(r, "a reference") for r in references]
    hyp = _check_tokens(hypothesis, "hypothesis")
    if isinstance(weights, str) or not isinstance(weights, (list, tuple)) or not weights:
        raise TypeError("weights must be a non-empty sequence of numbers")
    if not refs:
        raise ValueError("bleu needs at least one reference")
    if not hyp:
        return 0.0

    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for r in refs:
            for gram, c in _ngrams(r, n).items():
                if c > max_ref[gram]:
                    max_ref[gram] = c
        matches = sum(min(c, max_ref[g]) for g, c in hyp_counts.items())
        pairs.append((matches, total))

    if smoothing_function is None:
        precisions = [(m / t) if t else 0.0 for m, t in pairs]
    else:
        precisions = list(smoothing_function(pairs))

    if any(p == 0 for p, w in zip(precisions, weights) if w):
        return 0.0
    log_avg = sum(w * math.log(p) for p, w in zip(precisions, weights) if w)

    c = len(hyp)
    r = min((len(ref) for ref in refs), key=lambda L: (abs(L - c), L))
    bp = 1.0 if c > r else math.exp(1 - r / c)
    return bp * math.exp(log_avg)
