"""LINGORA — the Lingora Language Toolkit: a pure-Python NLP library.

Importing the package downloads nothing and reads no resource.

# spec: N-000371 N-000372 (importable package named lingora at the repository root)
"""
from . import errors, data  # noqa: F401
from . import tokenize, stem, tag, chunk, grammar, tree, classify, metrics, translate, cli  # noqa: F401
from . import parse  # noqa: F401

__version__ = "0.1.0"
