"""Part-of-speech taggers.

# spec: N-000187 N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000197
# spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218
# spec: N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
# spec: N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439 N-000440 N-000441 N-000442 N-000443 N-000444 N-000445
"""
import json
import os
import re
from collections import Counter, defaultdict

from . import data
from .errors import ResourceNotFoundError, UnsupportedError

__all__ = ["DefaultTagger", "UnigramTagger", "BigramTagger", "TrigramTagger", "NgramTagger",
           "AffixTagger", "RegexpTagger", "PerceptronTagger", "pos_tag"]

# Russian National Corpus part-of-speech category -> universal category (the part before '=').
_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "NUM": "NUM", "INTJ": "X", "SPRO": "PRON", "APRO": "DET", "NONLEX": "X",
    "PRAEDIC": "ADV", "PARENTH": "X", "PRO": "PRON",
}


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not a string")
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("every token must be str")
    return list(tokens)


def _check_train(train):
    if train is None:
        return []
    if isinstance(train, str) or not isinstance(train, (list, tuple)):
        raise TypeError("train must be a list of tagged sentences")
    out = []
    for sent in train:
        pairs = []
        for pair in sent:
            if not (isinstance(pair, (list, tuple)) and len(pair) == 2):
                raise TypeError("each training item must be a (token, tag) pair")
            pairs.append((pair[0], pair[1]))
        out.append(pairs)
    return out


def _check_backoff(backoff):
    if backoff is not None and not hasattr(backoff, "tag"):
        raise TypeError("backoff must be a tagger or None")
    return backoff


class _SequentialTagger:
    """Base: tags a token list, consulting ``backoff`` only where this tagger leaves None."""

    backoff = None

    def _raw(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        if not tokens:
            return []
        tags = list(self._raw(tokens))
        if self.backoff is not None and any(t is None for t in tags):
            fallback = self.backoff.tag(tokens)
            tags = [b if t is None else t for t, (_, b) in zip(tags, fallback)]
        return list(zip(tokens, tags))

    def tag_sents(self, sentences):
        return [self.tag(s) for s in sentences]


class DefaultTagger(_SequentialTagger):
    """Assigns one tag to every token. # spec: N-000198"""

    def __init__(self, tag):
        if tag is not None and not isinstance(tag, str):
            raise TypeError("tag must be str or None")
        self._tag = tag

    def _raw(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    """Most frequent training tag per word. Ties: the lexically smallest tag. # spec: N-000199..N-000201"""

    def __init__(self, train=None, backoff=None):
        self.backoff = _check_backoff(backoff)
        counts = defaultdict(Counter)
        for sent in _check_train(train):
            for word, tag in sent:
                counts[word][tag] += 1
        self._model = {}
        for word, c in counts.items():
            best = sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
            self._model[word] = best

    def _raw(self, tokens):
        return [self._model.get(t) for t in tokens]


class NgramTagger(_SequentialTagger):
    """Tag from the word and the previous n-1 assigned tags (outside the specified taggers)."""

    def __init__(self, n, train=None, backoff=None):
        if not isinstance(n, int) or n < 1:
            raise TypeError("n must be a positive int")
        self._n = n
        self.backoff = _check_backoff(backoff)
        counts = defaultdict(Counter)
        for sent in _check_train(train):
            history = ()
            for word, tag in sent:
                counts[(history, word)][tag] += 1
                history = (history + (tag,))[-(n - 1):] if n > 1 else ()
        self._model = {}
        for key, c in counts.items():
            self._model[key] = sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    def _raw(self, tokens):
        out = []
        history = ()
        for word in tokens:
            tag = self._model.get((history, word))
            out.append(tag)
            if self._n > 1:
                history = (history + ((tag,) if tag is not None else (None,)))[-(self._n - 1):]
        return out


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_SequentialTagger):
    """Tag by the word's suffix (negative affix_length) or prefix (positive). Outside the specified taggers."""

    def __init__(self, train=None, affix_length=-3, backoff=None):
        if not isinstance(affix_length, int) or affix_length == 0:
            raise TypeError("affix_length must be a non-zero int")
        self._len = affix_length
        self.backoff = _check_backoff(backoff)
        counts = defaultdict(Counter)
        for sent in _check_train(train):
            for word, tag in sent:
                counts[self._affix(word)][tag] += 1
        self._model = {a: sorted(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
                       for a, c in counts.items()}

    def _affix(self, word):
        if self._len > 0:
            return word[:self._len]
        return word[self._len:] if len(word) >= -self._len else word

    def _raw(self, tokens):
        return [self._model.get(self._affix(t)) for t in tokens]


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; the first whose pattern matches at the token's first character wins.

    # spec: N-000202 N-000203 N-000204
    """

    def __init__(self, regexps, backoff=None):
        if isinstance(regexps, str) or not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = []
        for item in regexps:
            if not (isinstance(item, (list, tuple)) and len(item) == 2):
                raise TypeError("each rule must be a (pattern, tag) pair")
            self._rules.append((re.compile(item[0]), item[1]))
        self.backoff = _check_backoff(backoff)

    def _raw(self, tokens):
        out = []
        for t in tokens:
            tag = None
            for rx, rule_tag in self._rules:
                if rx.match(t):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


# --------------------------------------------------------------------------- averaged perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


class PerceptronTagger:
    """Greedy averaged perceptron tagger (Honnibal's textblob-aptagger feature templates).

    # spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
    """

    def __init__(self, lang):
        if lang not in ("eng", "rus"):
            raise UnsupportedError("averaged perceptron tagger supports only 'eng' and 'rus', not %r" % (lang,))
        base = data.find(data.PERCEPTRON_TAGGER.format(lang=lang))
        stem = "averaged_perceptron_tagger_%s" % lang

        def load(suffix):
            fp = os.path.join(base, "%s.%s.json" % (stem, suffix))
            if not os.path.isfile(fp):
                raise ResourceNotFoundError("perceptron tagger file %s missing in %s" % (stem + "." + suffix, base))
            with open(fp, encoding="utf-8") as fh:
                return json.load(fh)

        self.weights = load("weights")
        self.tagdict = load("tagdict")
        self.classes = set(load("classes"))

    def _predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    @staticmethod
    def _features(i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def tag(self, tokens):
        context = _START + [_normalize(w) for w in tokens] + _END
        prev, prev2 = _START
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append(tag)
            prev2, prev = prev, tag
        return out


_perceptron_cache = {}


def _perceptron(lang):
    base = data.find(data.PERCEPTRON_TAGGER.format(lang=lang))
    key = (base, lang)
    if key not in _perceptron_cache:
        _perceptron_cache[key] = PerceptronTagger(lang)
    return _perceptron_cache[key]


def _english_map():
    directory = data.find(data.UNIVERSAL_TAGSET)
    mapping = {}
    fp = os.path.join(directory, "en-ptb.map")
    if not os.path.isfile(fp):
        raise ResourceNotFoundError("universal tagset table en-ptb.map is not installed")
    with open(fp, encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Recommended tagger: English (Penn Treebank tags) or Russian (RNC tags).

    ``tagset='universal'`` maps tags to the universal tagset. English mapping needs the packaged table.

    # spec: N-000219 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
    """
    if isinstance(tokens, str):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise UnsupportedError("pos_tag supports lang 'eng' or 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise UnsupportedError("tagset must be None or 'universal'")
    model = _perceptron(lang)
    if not tokens:
        return []
    tags = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _english_map()
            tags = [mapping.get(t, t) for t in tags]
        else:
            tags = [_RNC_TO_UNIVERSAL.get(t.split("=", 1)[0], "X") for t in tags]
    return list(zip(tokens, tags))
