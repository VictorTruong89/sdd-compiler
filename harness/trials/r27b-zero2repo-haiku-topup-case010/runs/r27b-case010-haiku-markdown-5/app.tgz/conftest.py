"""Puts the repository root on sys.path so ``import lingora`` works under pytest from /app."""
