"""Tokenizers (``lingora.tokenize``)."""

import re

from lingora import _punkt
from lingora._util import check_text

# ---------------------------------------------------------------- word/punctuation

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Splits into maximal runs of word characters and of non-word, non-space characters."""

    def tokenize(self, text):
        check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        check_text(text)
        return [(m.start(), m.end()) for m in _WORDPUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------- Penn Treebank family

_START_QUOTE_RE = re.compile(r'(^|(?<=[\s(\[{<]))"')
_TYPOGRAPHIC_QUOTE_RE = re.compile("[«»“”‘’„‚‹›]")
_CLITIC_RE = re.compile(r"(?i)([^\s'])('ll|'re|'ve|'s|'m|'d|n't)(?=\s)")
_BARE_APOS_RE = re.compile(r"([^'])' ")
_FINAL_PERIOD_RE = re.compile(r"(^|[^.])\.([\]\)}>\"']*)\s*$")
_FUSED = [
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
    re.compile(r"(?i)(?<!\S)('t)(is|was)\b"),
]
_CANNOT_RE = re.compile(r"(?i)\b(can)(not)\b")


def _penn_tokens(text, improved):
    s = text
    if improved:
        s = _TYPOGRAPHIC_QUOTE_RE.sub(lambda m: " %s " % m.group(0), s)
        s = re.sub(r'^"', " '' ", s)
    s = _START_QUOTE_RE.sub(" `` ", s)
    s = " " + s + " "
    if improved:
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), s)
    else:
        s = re.sub(r"\.\.\.", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"[;@#$%&?!]", lambda m: " %s " % m.group(0), s)
    if improved:
        s = re.sub(r"[*\u2012-\u2015]", lambda m: " %s " % m.group(0), s)
        s = s.replace("--", " -- ")
    s = re.sub(r"[\[\](){}<>]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"([:,])(?!\d)", lambda m: " %s " % m.group(1), s)
    s = _FINAL_PERIOD_RE.sub(lambda m: "%s ." % m.group(1) + m.group(2) + " ", s)
    s = _BARE_APOS_RE.sub(lambda m: m.group(1) + " ' ", s)
    if improved:
        s = re.sub(r"([»”’])", lambda m: " %s " % m.group(1), s)
    s = s.replace("''", " '' ")
    s = s.replace('"', " '' ")
    s = _CLITIC_RE.sub(lambda m: m.group(1) + " " + m.group(2), s)
    if not improved:
        s = _CANNOT_RE.sub(lambda m: m.group(1) + " " + m.group(2), s)
    for rx in _FUSED:
        s = rx.sub(lambda m: m.group(1) + " " + m.group(2), s)
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenization conventions (no sentence splitting)."""

    def tokenize(self, text):
        check_text(text)
        return _penn_tokens(text, improved=False)


# ---------------------------------------------------------------- recommended tokenizer


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model for ``language``."""
    check_text(text)
    return _punkt.sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (improved Penn Treebank rules)."""
    check_text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_penn_tokens(sentence, improved=True))
    return tokens


# ---------------------------------------------------------------- whitespace / blank line

_WHITESPACE_RE = re.compile(r"\S+")
_BLANKLINE_SEP_RE = re.compile(r"\s*\n\s*\n\s*")


class WhitespaceTokenizer:
    def tokenize(self, text):
        check_text(text)
        return _WHITESPACE_RE.findall(text)

    def span_tokenize(self, text):
        check_text(text)
        return [(m.start(), m.end()) for m in _WHITESPACE_RE.finditer(text)]


def blankline_tokenize(text):
    check_text(text)
    return [segment for segment in _BLANKLINE_SEP_RE.split(text) if segment]


# ---------------------------------------------------------------- regular expression


class RegexpTokenizer:
    """Tokens are the matches of ``pattern`` (token mode) or the gaps between matches (gaps mode)."""

    def __init__(self, pattern, gaps=False, discard_empty=False, flags=0):
        self._regex = re.compile(pattern, flags) if isinstance(pattern, str) else pattern
        self.gaps = bool(gaps)
        self.discard_empty = bool(discard_empty)

    def _spans(self, text):
        if self.gaps:
            spans = []
            last = 0
            for m in self._regex.finditer(text):
                spans.append((last, m.start()))
                last = m.end()
            spans.append((last, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regex.finditer(text)]
        if self.discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans

    def tokenize(self, text):
        check_text(text)
        return [text[s:e] for s, e in self._spans(text)]

    def span_tokenize(self, text):
        check_text(text)
        return self._spans(text)


# ---------------------------------------------------------------- tweet tokenizer

_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o*']?[)\]\(\[dDpP/:}{@|\\]"
    r"|[)\]\(\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_RE = re.compile(
    "|".join(
        [
            r"(?:https?://|www\.)\S+",
            r"[#@]\w+",
            _EMOTICON,
            r"\w+(?:['’]\w+)+",
            r"\d+(?:[.,]\d+)+",
            r"\w+",
            r"\.{2,}",
            r"\S",
        ]
    )
)
_EMOTICON_FULL_RE = re.compile(_EMOTICON)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REPEAT_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        check_text(text)
        s = text
        if self.strip_handles:
            s = _HANDLE_RE.sub(" ", s)
        if self.reduce_len:
            s = _REPEAT_RE.sub(lambda m: m.group(1) * 3, s)
        tokens = []
        for m in _TWEET_RE.finditer(s):
            tok = m.group(0)
            if not self.preserve_case and not _EMOTICON_FULL_RE.fullmatch(tok):
                tok = tok.lower()
            tokens.append(tok)
        return tokens


__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]
