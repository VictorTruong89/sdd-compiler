"""Context-free grammars (``lingora.grammar``)."""

import re


class Nonterminal:
    """A nonterminal symbol. Not a str; ``str()`` gives its name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """``lhs -> rhs`` where rhs holds Nonterminals and str terminals."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for sym in self._rhs:
            parts.append(str(sym) if isinstance(sym, Nonterminal) else "'%s'" % sym)
        return ("%s -> %s" % (self._lhs, " ".join(parts))).rstrip()

    def __repr__(self):
        return "Production(%s)" % self


_IDENT_RE = re.compile(r"[^\s'\"|]+")
_RHS_TOKEN_RE = re.compile(r"""\s*(?:'([^']*)'|"([^"]*)"|(\|)|([^\s'"|]+))""")


def _parse_alternatives(text):
    alternatives = [[]]
    pos = 0
    while True:
        m = _RHS_TOKEN_RE.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("cannot parse production right-hand side: %r" % text[pos:])
        pos = m.end()
        if m.group(3):
            alternatives.append([])
        elif m.group(1) is not None:
            alternatives[-1].append(m.group(1))
        elif m.group(2) is not None:
            alternatives[-1].append(m.group(2))
        else:
            alternatives[-1].append(Nonterminal(m.group(4)))
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)
        self._by_lhs = {}
        for p in self._productions:
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring takes a str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production has no '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT_RE.fullmatch(lhs_text):
                raise ValueError("invalid left-hand side: %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            for alt in _parse_alternatives(rhs_text):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._by_lhs.get(lhs, []))

    def terminals(self):
        out = set()
        for p in self._productions:
            for sym in p.rhs():
                if isinstance(sym, str) and sym != "":
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions, start %s>" % (len(self._productions), self._start)
