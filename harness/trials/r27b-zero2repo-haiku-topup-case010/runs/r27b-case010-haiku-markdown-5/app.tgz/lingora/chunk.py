"""Chunk parsing with chunk grammars (``lingora.chunk``)."""

import os
import re

from lingora import data
from lingora.tree import Tree

_ROOT_LABEL = "S"
_QUANT_BRACE_RE = re.compile(r"\{(\d*)(,?)(\d*)\}")
_HEADER_RE = re.compile(r"([^\s{}<>:]+)\s*:(.*)$")


class ChunkRule:
    """A chunk stage: tokens matching ``pattern`` (tag pattern) become a chunk labelled ``label``."""

    kind = "chunk"

    def __init__(self, label, pattern):
        self.label = label
        self.pattern = pattern
        self._regex = _tag_pattern_regex(pattern)


class ChinkRule(ChunkRule):
    """A chink stage: tokens matching ``pattern`` are removed from this clause's chunks."""

    kind = "chink"


def _element_regex(content):
    content = re.sub(r"\s+", "", content)
    if not content:
        raise ValueError("empty tag element in chunk grammar")
    # '.' matches any character of a tag, but never a tag boundary
    content = re.sub(r"(?<!\\)\.", "[^<>]", content)
    return content


def _tag_pattern_regex(text):
    """Compile a tag pattern (sequence of ``<...>`` elements with quantifiers) to a regex.

    The regex runs over the string ``<tag1><tag2>...`` so each element matches one token.
    """
    body = text
    parts = []
    i = 0
    n = len(body)
    while i < n:
        if body[i].isspace():
            i += 1
            continue
        if body[i] != "<":
            raise ValueError("expected '<' in tag pattern at %r" % body[i:])
        j = body.find(">", i)
        if j < 0:
            raise ValueError("unterminated tag element in %r" % text)
        content = _element_regex(body[i + 1 : j])
        i = j + 1
        quant = ""
        if i < n and body[i] in "?*+":
            quant = body[i]
            i += 1
        else:
            m = _QUANT_BRACE_RE.match(body, i)
            if m and (m.group(1) or m.group(3)):
                lo, comma, hi = m.group(1), m.group(2), m.group(3)
                quant = "{%s}" % lo if not comma else "{%s,%s}" % (lo or "0", hi)
                i = m.end()
        parts.append("(?:<(?:%s)>)%s" % (content, quant))
    try:
        return re.compile("".join(parts))
    except re.error as exc:
        raise ValueError("invalid tag pattern %r: %s" % (text, exc))


def _parse_grammar_text(text):
    """Return a list of (label, [(kind, regex), ...]) clauses from grammar text."""
    clauses = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if not raw[0].isspace():
            m = _HEADER_RE.match(raw.strip())
            if not m:
                raise ValueError("expected a clause header '<LABEL>:' in %r" % raw)
            current = (m.group(1), [m.group(2)])
            clauses.append(current)
        else:
            if current is None:
                raise ValueError("indented pattern before any clause label: %r" % raw)
            current[1].append(raw)
    return [(label, _parse_rules(" ".join(bodies))) for label, bodies in clauses]


def _parse_rules(body):
    rules = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c.isspace():
            i += 1
            continue
        if c == "{":
            kind, close = "chunk", "}"
        elif c == "}":
            kind, close = "chink", "{"
        else:
            raise ValueError("unexpected %r in chunk grammar" % c)
        i += 1
        elems = []
        while True:
            while i < n and body[i].isspace():
                i += 1
            if i >= n:
                raise ValueError("unterminated chunk/chink rule in %r" % body)
            if body[i] == close:
                i += 1
                break
            if body[i] != "<":
                raise ValueError("expected '<' in chunk rule at %r" % body[i:])
            j = body.find(">", i)
            if j < 0:
                raise ValueError("unterminated tag element in %r" % body)
            content = body[i : j + 1]
            i = j + 1
            quant = ""
            if i < n and body[i] in "?*+":
                quant = body[i]
                i += 1
            else:
                m = _QUANT_BRACE_RE.match(body, i)
                if m and (m.group(1) or m.group(3)):
                    quant = m.group(0)
                    i = m.end()
            elems.append(content + quant)
        pattern = "".join(elems)
        rx = _tag_pattern_regex(pattern)
        rules.append((kind, rx))
    return rules


def _match_spans(rx, tags):
    """Token-index (start, end) spans of non-empty matches, left to right, non-overlapping."""
    s = "".join("<%s>" % t for t in tags)
    offsets = []
    pos = 0
    for t in tags:
        offsets.append(pos)
        pos += len(t) + 2
    offsets.append(pos)
    index = {off: k for k, off in enumerate(offsets)}
    spans = []
    for m in rx.finditer(s):
        a, b = m.start(), m.end()
        if a == b:
            continue
        if a in index and b in index:
            spans.append((index[a], index[b]))
    return spans


class _Chunk:
    __slots__ = ("label", "members")

    def __init__(self, label, members):
        self.label = label
        self.members = list(members)


def _apply_chunk(items, label, rx, clause):
    out = []
    new = {}
    i = 0
    n = len(items)
    while i < n:
        if items[i][0] == "leaf":
            j = i
            while j < n and items[j][0] == "leaf":
                j += 1
            run = [items[k][1] for k in range(i, j)]
            pos = 0
            for a, b in _match_spans(rx, [str(g) for _, g in run]):
                out.extend(("leaf", p) for p in run[pos:a])
                chunk = _Chunk(label, run[a:b])
                clause[id(chunk)] = chunk
                new[id(chunk)] = chunk
                out.append(("chunk", chunk))
                pos = b
            out.extend(("leaf", p) for p in run[pos:])
            i = j
        else:
            out.append(items[i])
            i += 1
    # chunks that touch (no token between them) are joined when at least one is new
    merged = []
    for kind, obj in out:
        if kind == "chunk" and merged and merged[-1][0] == "chunk":
            prev = merged[-1][1]
            if id(prev) in clause and id(obj) in clause and (id(prev) in new or id(obj) in new):
                prev.members.extend(obj.members)
                clause.pop(id(obj), None)
                new.pop(id(obj), None)
                continue
        merged.append((kind, obj))
    return merged


def _apply_chink(items, rx, clause):
    out = []
    for kind, obj in items:
        if kind != "chunk" or id(obj) not in clause:
            out.append((kind, obj))
            continue
        members = obj.members
        spans = _match_spans(rx, [str(g) for _, g in members])
        if not spans:
            out.append((kind, obj))
            continue
        removed = [False] * len(members)
        for a, b in spans:
            for k in range(a, b):
                removed[k] = True
        clause.pop(id(obj), None)
        cur = []
        for k, pair in enumerate(members):
            if removed[k]:
                if cur:
                    piece = _Chunk(obj.label, cur)
                    clause[id(piece)] = piece
                    out.append(("chunk", piece))
                    cur = []
                out.append(("leaf", pair))
            else:
                cur.append(pair)
        if cur:
            piece = _Chunk(obj.label, cur)
            clause[id(piece)] = piece
            out.append(("chunk", piece))
    return out


class RegexpParser:
    """Chunk parser over a chunk grammar (text, or a list of ChunkRule/ChinkRule stages)."""

    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._clauses = _parse_grammar_text(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, ChunkRule) for s in grammar):
            self._clauses = [(s.label, [(s.kind, s._regex)]) for s in grammar]
        else:
            raise TypeError("grammar must be a str or a list of chunk-parser stages")
        self._root = _ROOT_LABEL

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not (isinstance(pair, (list, tuple)) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            items.append(("leaf", (pair[0], pair[1])))
        for label, rules in self._clauses:
            clause = {}
            for kind, rx in rules:
                if kind == "chunk":
                    items = _apply_chunk(items, label, rx, clause)
                else:
                    items = _apply_chink(items, rx, clause)
            # chunks of this clause keep their label; nothing else to do
        children = []
        for kind, obj in items:
            if kind == "leaf":
                children.append(obj)
            else:
                children.append(Tree(obj.label, list(obj.members)))
        return Tree(self._root, children)


_NE_MODEL = os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass")
_EN_WORDS = os.path.join("corpora", "words")


def ne_chunk(tagged_tokens):
    """Named-entity chunking. Needs the NE model and the English wordlist to be visible.

    This build does not load the packaged maximum-entropy model; it chunks runs of
    proper nouns (NNP/NNPS) as ``NE`` chunks. See NOTES.md.
    """
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    data.require(_NE_MODEL, "Named-entity chunker model", directory=True)
    data.require(_EN_WORDS, "English wordlist")
    grammar = "NE: {<NNP>+}"
    return RegexpParser(grammar).parse(list(tagged_tokens))


__all__ = ["ChinkRule", "ChunkRule", "RegexpParser", "ne_chunk"]
