"""Command line (``lingora.cli``).

``cli.main(args=[...], standalone_mode=True)`` runs a command. ``tokenize`` reads UTF-8
text from standard input and writes, for each input line, that line's
recommended-word-tokenizer tokens (sentence splitting included) joined by a delimiter.
"""

import sys

from lingora import _punkt
from lingora.data import ResourceNotFoundError
from lingora.tokenize import word_tokenize

_USAGE = """Usage: lingora tokenize [OPTIONS]

  Tokenize each line of standard input with the recommended word tokenizer.

Options:
  -l, --language TEXT   Punkt language directory name (default: english).
  -d, --delimiter TEXT  Token delimiter (default: one space).
  -e, --encoding TEXT   Input/output encoding (default: utf-8).
  -h, --help            Show this message and exit.
"""


class UsageError(Exception):
    pass


def _tokenize_command(options):
    language = options["language"]
    delimiter = options["delimiter"]
    encoding = options["encoding"]
    # Fail before writing anything when the sentence model is not visible.
    _punkt.load_params(language)
    text = _read_stdin(encoding)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    for line in lines:
        line = line[:-1] if line.endswith("\r") else line
        tokens = word_tokenize(line, language=language, preserve_line=False)
        sys.stdout.write(delimiter.join(tokens) + "\n")
    sys.stdout.flush()
    return 0


def _read_stdin(encoding):
    stream = sys.stdin
    if hasattr(stream, "buffer"):
        return stream.buffer.read().decode(encoding)
    return stream.read()


class Group:
    """A command group: ``main(args=..., standalone_mode=...)`` dispatches to its commands."""

    def __init__(self, name):
        self.name = name
        self._commands = {"tokenize": _tokenize_command}

    def main(self, args=None, standalone_mode=True):
        argv = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(argv)
        except UsageError as exc:
            sys.stderr.write(_USAGE + "\nError: %s\n" % exc)
            code = 2
        except ResourceNotFoundError as exc:
            sys.stderr.write("Error: %s\n" % exc)
            code = 1
        except (ValueError, OSError, UnicodeDecodeError) as exc:
            sys.stderr.write("Error: %s\n" % exc)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, argv):
        if not argv or argv[0] in ("-h", "--help"):
            sys.stdout.write(_USAGE)
            return 0
        name = argv[0]
        if name not in self._commands:
            raise UsageError("no such command '%s'" % name)
        options = {"language": "english", "delimiter": " ", "encoding": "utf-8"}
        flags = {"-l": "language", "--language": "language", "-d": "delimiter",
                 "--delimiter": "delimiter", "-e": "encoding", "--encoding": "encoding"}
        rest = argv[1:]
        i = 0
        while i < len(rest):
            arg = rest[i]
            if arg in ("-h", "--help"):
                sys.stdout.write(_USAGE)
                return 0
            if arg in flags:
                if i + 1 >= len(rest):
                    raise UsageError("option %s requires a value" % arg)
                options[flags[arg]] = rest[i + 1]
                i += 2
                continue
            raise UsageError("unexpected argument '%s'" % arg)
        return self._commands[name](options)


cli = Group("lingora")


def main_entry():
    cli.main()


__all__ = ["cli", "main_entry"]
