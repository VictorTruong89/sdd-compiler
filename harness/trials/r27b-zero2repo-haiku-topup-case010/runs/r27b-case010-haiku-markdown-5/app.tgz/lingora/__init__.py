"""LINGORA: the Lingora Language Toolkit, a pure-Python NLP library.

Submodules are imported on demand, e.g. ``from lingora.tokenize import word_tokenize``.
Importing this package downloads nothing.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: F401  (packaged-resource finder)
