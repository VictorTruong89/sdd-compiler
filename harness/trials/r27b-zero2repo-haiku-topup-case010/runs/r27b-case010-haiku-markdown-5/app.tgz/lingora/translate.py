"""BLEU (``lingora.translate``): Papineni et al. (2002), sentence level."""

import math
from collections import Counter


def _ngrams(tokens, n):
    return [tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1)]


class SmoothingFunction:
    """Optional smoothing for ``bleu``. Each method maps [(numerator, denominator), ...] to precisions."""

    def method1(self, p_n, epsilon=0.1):
        out = []
        for num, den in p_n:
            if den == 0:
                out.append(0.0)
            elif num == 0:
                out.append(epsilon / den)
            else:
                out.append(num / den)
        return out

    def method2(self, p_n):
        out = []
        for idx, (num, den) in enumerate(p_n):
            if idx == 0:
                out.append(num / den if den else 0.0)
            else:
                out.append((num + 1) / (den + 1))
        return out


def bleu(references, hypothesis, weights=(0.5, 0.5), smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` against one or more ``references`` (lists of tokens)."""
    if not isinstance(references, (list, tuple)) or not references:
        raise TypeError("references must be a non-empty list of token lists")
    if not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a token list")
    weights = tuple(float(w) for w in weights)
    if not weights:
        raise ValueError("weights must not be empty")
    hyp = list(hypothesis)
    refs = [list(r) for r in references]
    if not hyp:
        return 0.0

    p_n = []
    for n in range(1, len(weights) + 1):
        hyp_counts = Counter(_ngrams(hyp, n))
        max_ref = Counter()
        for ref in refs:
            for gram, count in Counter(_ngrams(ref, n)).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        total = max(0, len(hyp) - n + 1)
        p_n.append((clipped, total))

    if smoothing_function is not None:
        precisions = smoothing_function(p_n)
    else:
        precisions = [num / den if den else 0.0 for num, den in p_n]

    for w, p in zip(weights, precisions):
        if w > 0 and p <= 0:
            return 0.0
    log_mean = sum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0)
    geometric = math.exp(log_mean)

    c = len(hyp)
    r = min((len(ref) for ref in refs), key=lambda L: (abs(L - c), L))
    if c > r:
        bp = 1.0
    else:
        bp = math.exp(1 - r / c)
    return bp * geometric


__all__ = ["SmoothingFunction", "bleu"]
