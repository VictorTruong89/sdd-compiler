"""Part-of-speech taggers (``lingora.tag``)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data
from lingora._util import check_token_list


class _Tagger:
    """Base class: ``tag`` gives each token its primary tag, then consults the backoff."""

    backoff = None

    def _primary(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = check_token_list(tokens)
        if not tokens:
            return []
        tags = list(self._primary(tokens))
        if self.backoff is not None and any(t is None for t in tags):
            fallback = self.backoff.tag(tokens)
            tags = [
                fb_tag if tag is None else tag
                for tag, (_, fb_tag) in zip(tags, fallback)
            ]
        return list(zip(tokens, tags))


class DefaultTagger(_Tagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):
        self._tag = tag
        self.backoff = backoff

    def _primary(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_Tagger):
    """Tags each word with the tag it most often had in training; unseen words get no tag."""

    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                counts[token][tag] += 1
        self._model = {}
        for token, c in counts.items():
            # most frequent tag; ties broken by tag string so the result is deterministic
            self._model[token] = min(c.items(), key=lambda kv: (-kv[1], str(kv[0])))[0]

    def _primary(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(_Tagger):
    """The first rule whose pattern matches at the token's start gives the tag."""

    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = []
        for pattern, tag in regexps:
            self._rules.append((re.compile(pattern), tag))

    def _primary(self, tokens):
        out = []
        for t in tokens:
            tag = None
            for rx, rule_tag in self._rules:
                if rx.match(t):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------- averaged perceptron

_RESOURCE_LANGS = ("eng", "rus")
_RU_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "PRAEDIC": "ADV",
    "PR": "ADP", "CONJ": "CCONJ", "PART": "PART", "NUM": "NUM", "SPRO": "PRON",
    "APRO": "DET", "INTJ": "INTJ", "PARENTH": "PART", "PRAEDIC_PRO": "PRON",
}


def _perceptron_files(lang):
    name = "averaged_perceptron_tagger_%s" % lang
    directory = data.require(
        os.path.join("taggers", name),
        "Averaged perceptron tagger for %r" % lang,
        directory=True,
    )
    base = os.path.join(directory, name)
    files = {
        "weights": base + ".weights.json",
        "tagdict": base + ".tagdict.json",
        "classes": base + ".classes.json",
    }
    for key, fn in files.items():
        if not os.path.exists(fn):
            raise data.ResourceNotFoundError(
                "Averaged perceptron tagger for %r is incomplete: missing %s" % (lang, os.path.basename(fn))
            )
    return files


_PCACHE = {}


class _PerceptronTagger:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes or sorted({t for feats in weights.values() for t in feats})

    @staticmethod
    def normalize(word):
        if not word:
            return word
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    @staticmethod
    def features(i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_PerceptronTagger.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = self.START
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self.features(i, word, context, prev, prev2))
            out.append(tag)
            prev2 = prev
            prev = tag
        return out


def _load_perceptron(lang):
    files = _perceptron_files(lang)
    key = (tuple(sorted(files.items())), tuple(os.path.getmtime(f) for f in files.values()))
    if key not in _PCACHE:
        with open(files["weights"], encoding="utf-8") as fh:
            weights = json.load(fh)
        with open(files["tagdict"], encoding="utf-8") as fh:
            tagdict = json.load(fh)
        with open(files["classes"], encoding="utf-8") as fh:
            classes = json.load(fh)
        _PCACHE.clear()
        _PCACHE[key] = _PerceptronTagger(weights, tagdict, classes)
    return _PCACHE[key]


def _load_universal_english():
    path = data.require(
        os.path.join("taggers", "universal_tagset", "en-ptb.map"),
        "Universal tagset table for English",
    )
    mapping = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) >= 2:
                mapping[parts[0]] = parts[1]
    return mapping


def _map_russian(tag):
    head = tag.split("=")[0]
    pos = head.split(",")[0]
    return _RU_TO_UNIVERSAL.get(pos, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the recommended averaged perceptron tagger.

    ``lang`` is ``'eng'`` (Penn Treebank tags) or ``'rus'`` (Russian National
    Corpus tags). ``tagset`` is ``None`` (native tags) or ``'universal'``.
    """
    if isinstance(tokens, str):
        raise TypeError("pos_tag takes a list of tokens, not a str")
    tokens = check_token_list(tokens)
    if lang not in _RESOURCE_LANGS:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    tagger = _load_perceptron(lang)
    universal = None
    if tagset == "universal" and lang == "eng":
        universal = _load_universal_english()
    if not tokens:
        return []
    tags = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            tags = [universal.get(t, "X") for t in tags]
        else:
            tags = [_map_russian(t) for t in tags]
    return list(zip(tokens, tags))


__all__ = [
    "DefaultTagger",
    "RegexpTagger",
    "UnigramTagger",
    "pos_tag",
]
