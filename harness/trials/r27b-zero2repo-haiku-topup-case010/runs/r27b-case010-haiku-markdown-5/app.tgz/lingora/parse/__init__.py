"""Grammar-based parsers (``lingora.parse``).

``ChartParser`` is exhaustive: it returns every tree the grammar assigns to the
tokens. ``ShiftReduceParser`` makes one left-to-right pass without backtracking.
Both raise ValueError when a token is produced by no production of the grammar.
"""

from lingora.grammar import Nonterminal
from lingora.tree import Tree
from lingora._util import check_token_list


def _check_tokens(grammar, tokens):
    tokens = check_token_list(tokens)
    known = grammar.terminals()
    for tok in tokens:
        if tok not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % tok)
    return tokens


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        grammar = self._grammar
        memo = {}
        active = set()

        def parse_sym(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:  # a derivation cycle over the same span; cut it
                return []
            active.add(key)
            results = []
            for prod in grammar.productions(lhs=sym):
                for children in match_rhs(prod.rhs(), 0, i, j):
                    results.append(Tree(str(sym), children))
            active.discard(key)
            memo[key] = results
            return results

        def match_rhs(rhs, k, pos, end):
            if k == len(rhs):
                if pos == end:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, Nonterminal):
                for mid in range(pos, end + 1):
                    for sub in parse_sym(sym, pos, mid):
                        for rest in match_rhs(rhs, k + 1, mid, end):
                            yield [sub] + rest
            elif sym == "":
                for rest in match_rhs(rhs, k + 1, pos, end):
                    yield rest
            elif pos < end and tokens[pos] == sym:
                for rest in match_rhs(rhs, k + 1, pos + 1, end):
                    yield [sym] + rest

        return iter(parse_sym(grammar.start(), 0, len(tokens)))


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        grammar = self._grammar
        start = grammar.start()
        # empty productions would reduce forever; they are not used by this pass
        productions = [p for p in grammar.productions() if p.rhs() and "" not in p.rhs()]
        stack = []  # entries: (key, leaf-or-tree); key is a Nonterminal or a token string
        seen = set()
        i = 0
        while True:
            reduced = False
            for prod in productions:
                n = len(prod.rhs())
                if n > len(stack):
                    continue
                if any(stack[len(stack) - n + k][0] != sym for k, sym in enumerate(prod.rhs())):
                    continue
                new_keys = tuple([e[0] for e in stack[: len(stack) - n]] + [prod.lhs()])
                state = (new_keys, i)
                if state in seen and n == 1:
                    continue
                children = [e[1] for e in stack[len(stack) - n :]]
                del stack[len(stack) - n :]
                stack.append((prod.lhs(), Tree(str(prod.lhs()), children)))
                seen.add(state)
                reduced = True
                break
            if reduced:
                continue
            if i < len(tokens):
                stack.append((tokens[i], tokens[i]))
                i += 1
                continue
            break
        if len(stack) == 1 and stack[0][0] == start:
            return iter([stack[0][1]])
        return iter([])


__all__ = ["ChartParser", "ShiftReduceParser"]
