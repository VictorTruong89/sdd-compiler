"""Enumerate the sentences a grammar derives (``lingora.parse.generate``)."""

from lingora.grammar import Nonterminal


def _derive(grammar, sym, maxd, memo, cut):
    """All derivations of ``sym`` whose tree depth is at most ``maxd``.

    Returns a list of (tokens_tuple, depth). ``cut[0]`` is set when a production
    was skipped only because the depth bound was reached.
    """
    key = (sym, maxd)
    if key in memo:
        return memo[key]
    results = []
    if maxd >= 1:
        for prod in grammar.productions(lhs=sym):
            has_nt = any(isinstance(s, Nonterminal) for s in prod.rhs())
            if has_nt and maxd - 1 < 1:
                cut[0] = True
                continue
            partial = [((), 0)]
            for s in prod.rhs():
                if isinstance(s, Nonterminal):
                    options = _derive(grammar, s, maxd - 1, memo, cut)
                    partial = [
                        (toks + sub_toks, max(mc, sub_depth))
                        for toks, mc in partial
                        for sub_toks, sub_depth in options
                    ]
                elif s == "":
                    continue
                else:
                    partial = [(toks + (s,), mc) for toks, mc in partial]
            for toks, mc in partial:
                results.append((toks, mc + 1))
    memo[key] = results
    return results


def generate(grammar, start=None, depth=None, n=None):
    """Yield the sentences (lists of str tokens) derived from ``start``.

    Derivations are produced in order of their tree depth; within a depth, productions
    are expanded in their written order. ``depth`` bounds the derivation tree depth;
    ``n`` bounds the number of sentences. With neither bound, enumeration of an
    infinite language continues indefinitely.
    """
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    if n is not None and n <= 0:
        return
    limit = depth
    count = 0
    d = 1
    while limit is None or d <= limit:
        cut = [False]
        memo = {}
        for toks, depth_used in _derive(grammar, start, d, memo, cut):
            if depth_used != d:
                continue
            yield list(toks)
            count += 1
            if n is not None and count >= n:
                return
        if limit is None and not cut[0]:
            return
        d += 1
