"""Constituent trees (``lingora.tree``)."""

import re

_TREE_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


class Tree:
    """A labelled tree. Children are leaves (token strings, or other leaf values) or Trees."""

    def __init__(self, label, children):
        if not isinstance(children, list):
            raise TypeError("Tree children must be a list, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring takes a str")
        tokens = _TREE_TOKEN_RE.findall(s)
        if not tokens or tokens[0] != "(":
            raise ValueError("bracketed tree text must start with '('")
        tree, pos = _parse_bracketed(tokens, 0)
        if pos != len(tokens):
            raise ValueError("unexpected text after the tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def _format(self):
        parts = [str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._format())
            else:
                parts.append(_leaf_text(child))
        return "(" + " ".join(parts) + ")"

    def pformat(self):
        return self._format()

    def __str__(self):
        return self._format()


def _parse_bracketed(tokens, pos):
    # tokens[pos] == "("
    if pos + 1 >= len(tokens) or tokens[pos + 1] in ("(", ")"):
        raise ValueError("bracketed tree node has no label")
    label = tokens[pos + 1]
    children = []
    pos += 2
    while pos < len(tokens):
        tok = tokens[pos]
        if tok == "(":
            child, pos = _parse_bracketed(tokens, pos)
            children.append(child)
        elif tok == ")":
            return Tree(label, children), pos + 1
        else:
            children.append(tok)
            pos += 1
    raise ValueError("unbalanced parentheses in bracketed tree text")
