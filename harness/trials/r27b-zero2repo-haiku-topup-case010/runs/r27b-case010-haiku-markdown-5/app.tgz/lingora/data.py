"""Packaged-resource finder (``lingora.data``).

``path`` is a mutable list of directories searched, in order, for packaged
resources (Punkt models, tagger weights, stopword lists, WordNet, ...). A caller
may replace its contents in place. Initially it holds the directories listed in
the ``LINGORA_DATA`` environment variable (``os.pathsep`` separated) followed by
``~/lingora_data``.
"""

import os


class ResourceNotFoundError(LookupError):
    """A packaged resource needed by a call is not visible on ``data.path``."""


def _initial_path():
    entries = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
    entries.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return entries


path = _initial_path()


def find(resource, directory=False):
    """Return the first existing ``<dir>/<resource>`` over ``path``, or None."""
    for base in list(path):
        candidate = os.path.join(os.fspath(base), resource)
        if directory:
            if os.path.isdir(candidate):
                return candidate
        elif os.path.exists(candidate):
            return candidate
    return None


def require(resource, what, directory=False):
    """Like :func:`find`, but raise :class:`ResourceNotFoundError` when absent."""
    found = find(resource, directory=directory)
    if found is None:
        raise ResourceNotFoundError(
            "%s is not installed: '%s' is not visible on lingora.data.path" % (what, resource)
        )
    return found
