"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), applied with packaged parameters.

Only the sentence-splitting (annotation) half of Punkt is implemented. The
parameters (abbreviation types, collocations, sentence starters, orthographic
context) are read from the packaged Punkt model directory; training is not done.
"""

import os
import re

from lingora import data
from lingora.data import ResourceNotFoundError  # noqa: F401  (re-exported for callers)

_UC_MASK = 2 | 4 | 8  # upper-case: beginning, middle, unknown
_LC_MASK = 16 | 32 | 64  # lower-case: beginning, middle, unknown
_MID_UC = 4

_NONWORD = r"""(?:[?!)\";}\]\*:@'\({\[])"""
_WORDSTART = r"""[^\(\"\`{\[:;&\#\*@\)}\]\-,]"""
_MULTICHAR = r"""(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"""

_WORD_TOKEN_RE = re.compile(
    "(" + _MULTICHAR + "|(?=" + _WORDSTART + r")\S+?(?=\s|$|" + _NONWORD + "|" + _MULTICHAR
    + "|,(?=$|\\s|" + _NONWORD + "|" + _MULTICHAR + ")))"
)
_PERIOD_CONTEXT_RE = re.compile(
    r"\S*[.?!](?=(?P<after_tok>" + _NONWORD + r"|\s+(?P<next_tok>\S+)))"
)
_REALIGN_RE = re.compile(r"""["')\]}]+?(?:\s+|(?=--)|$)""", re.MULTILINE)
_NUMBER_TYPE_RE = re.compile(r"^-?[.,]?\d[\d,.-]*\.?$")
_INITIAL_RE = re.compile(r"[^\W\d_]\.")
_ELLIPSIS_RE = re.compile(r"\.\.+")
_LANGUAGE_RE = re.compile(r"[A-Za-z0-9_\-]+")


def _get_type(tok):
    lowered = tok.lower()
    return "##number##" if _NUMBER_TYPE_RE.match(lowered) else lowered


class _Tok:
    def __init__(self, tok):
        self.tok = tok
        self.period_final = tok.endswith(".")
        self.type = _get_type(tok)
        if self.period_final and len(tok) > 1:
            self.type_no_period = _get_type(tok[:-1])
        else:
            self.type_no_period = self.type
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_initial = bool(_INITIAL_RE.fullmatch(tok))
        self.is_ellipsis = bool(_ELLIPSIS_RE.fullmatch(tok))
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type


class PunktParameters:
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


def _ortho_heuristic(t, params):
    if t.tok in (".", "?", "!"):
        return False
    ortho = params.ortho_context.get(t.type_no_sentperiod, 0)
    if t.first_upper and (ortho & _LC_MASK) and not (ortho & _MID_UC):
        return True
    if t.first_lower and ((ortho & _UC_MASK) or not (ortho & _LC_MASK)):
        return False
    return None


def _first_pass(t, params):
    if t.tok in (".", "?", "!"):
        t.sentbreak = True
    elif t.is_ellipsis:
        t.ellipsis = True
    elif t.period_final and not t.tok.endswith(".."):
        base = t.tok[:-1].lower()
        if base in params.abbrev_types or base.split("-")[-1] in params.abbrev_types:
            t.abbr = True
        else:
            t.sentbreak = True


def _second_pass(t1, t2, params):
    if t2 is None or not t1.period_final:
        return
    typ = t1.type_no_period
    next_typ = t2.type_no_sentperiod
    is_initial = t1.is_initial
    if (typ, next_typ) in params.collocations:
        t1.sentbreak = False
        t1.abbr = True
        return
    if (t1.abbr or t1.ellipsis) and not is_initial:
        starter = _ortho_heuristic(t2, params)
        if starter is True:
            t1.sentbreak = True
            return
        if t2.first_upper and next_typ in params.sent_starters:
            t1.sentbreak = True
            return
    if is_initial or typ == "##number##":
        starter = _ortho_heuristic(t2, params)
        if starter is False:
            t1.sentbreak = False
            t1.abbr = True
            return
        if t2.first_upper and next_typ in params.sent_starters:
            t1.sentbreak = True


def _annotate(tokens, params):
    for t in tokens:
        _first_pass(t, params)
    for t1, t2 in zip(tokens, tokens[1:]):
        _second_pass(t1, t2, params)
    return tokens


def _contains_sentbreak(context, params):
    toks = _annotate([_Tok(w) for w in _WORD_TOKEN_RE.findall(context)], params)
    found = False
    for t in toks:
        if found:
            return True
        if t.sentbreak:
            found = True
    return False


def _realign(text, spans):
    if not spans:
        return []
    out = []
    cur_start, cur_end = spans[0]
    for nxt_start, nxt_end in spans[1:]:
        m = _REALIGN_RE.match(text[nxt_start:nxt_end])
        if m:
            out.append((cur_start, nxt_start + len(m.group(0).rstrip())))
            cur_start = nxt_start + m.end()
            cur_end = nxt_end
        else:
            out.append((cur_start, cur_end))
            cur_start, cur_end = nxt_start, nxt_end
    out.append((cur_start, cur_end))
    return out


def split(text, params):
    """Return the sentences of ``text`` (each stripped of surrounding whitespace)."""
    spans = []
    last = 0
    for m in _PERIOD_CONTEXT_RE.finditer(text):
        context = m.group(0) + m.group("after_tok")
        if _contains_sentbreak(context, params):
            spans.append((last, m.end()))
            last = m.start("next_tok") if m.group("next_tok") else m.end()
    spans.append((last, len(text)))
    sentences = []
    for s, e in _realign(text, spans):
        sent = text[s:e].strip()
        if sent:
            sentences.append(sent)
    return sentences


def _read_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        lines = [line.rstrip("\r\n") for line in fh]
    return [line for line in lines if line]


_CACHE = {}


def load_params(language):
    """Load the packaged Punkt parameters for ``language``; raise if not visible."""
    if not isinstance(language, str) or not _LANGUAGE_RE.fullmatch(language):
        raise ValueError("invalid Punkt language name: %r" % (language,))
    directory = data.require(
        os.path.join("tokenizers", "punkt_tab", language),
        "Punkt sentence model for %r" % language,
        directory=True,
    )
    files = {
        "abbrev": os.path.join(directory, "abbrev_types.txt"),
        "starters": os.path.join(directory, "sent_starters.txt"),
        "colloc": os.path.join(directory, "collocations.tab"),
        "ortho": os.path.join(directory, "ortho_context.tab"),
    }
    stamp = tuple(os.path.getmtime(f) if os.path.exists(f) else None for f in files.values())
    key = (os.path.abspath(directory), stamp)
    if key in _CACHE:
        return _CACHE[key]

    abbrev = {line.strip().lower() for line in _read_lines(files["abbrev"])}
    starters = {line.strip().lower() for line in _read_lines(files["starters"])}
    collocations = set()
    for line in _read_lines(files["colloc"]):
        parts = line.split("\t")
        if len(parts) >= 2:
            collocations.add((parts[0].lower(), parts[1].lower()))
    ortho = {}
    for line in _read_lines(files["ortho"]):
        parts = line.split("\t")
        if len(parts) >= 2:
            try:
                ortho[parts[0].lower()] = int(parts[1])
            except ValueError:
                continue
    params = PunktParameters(abbrev, collocations, starters, ortho)
    _CACHE.clear()
    _CACHE[key] = params
    return params


def sentences(text, language):
    """Split ``text`` into sentences with the Punkt model for ``language``."""
    return split(text, load_params(language))
