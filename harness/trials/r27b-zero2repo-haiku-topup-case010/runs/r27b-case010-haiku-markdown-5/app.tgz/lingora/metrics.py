"""Evaluation metrics (``lingora.metrics``)."""

from lingora._util import check_text


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)" % (len(reference), len(test)))
    if not reference:
        return 0.0
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    check_text(s1, "s1")
    check_text(s2, "s2")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[len(s2)]


def _damerau(a, b, sub):
    """Unrestricted Damerau-Levenshtein (Lowrance and Wagner, 1975)."""
    maxdist = len(a) + len(b)
    # d has an extra leading row/column holding maxdist (index -1 maps to 0)
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = maxdist
    for i in range(len(a) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            i1 = last_row.get(b[j - 1], 0)
            j1 = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[a[i - 1]] = i
    return d[len(a) + 1][len(b) + 1]


def _check_sets(*args):
    for arg in args:
        if not isinstance(arg, (set, frozenset)):
            raise TypeError("precision, recall and f_measure take sets")


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union| of two sets (0 when both are empty)."""
    _check_sets(label1, label2)
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def precision(reference, test):
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    _check_sets(reference, test)
    if not reference or not test:
        return None
    if not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)


__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]
