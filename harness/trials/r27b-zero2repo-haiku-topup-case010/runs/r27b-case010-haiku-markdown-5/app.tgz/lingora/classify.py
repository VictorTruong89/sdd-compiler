"""Text classifiers (``lingora.classify``): Naive Bayes and decision trees."""

import math
from collections import Counter, defaultdict


def _check_pairs(labeled):
    if not isinstance(labeled, (list, tuple)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    pairs = []
    for item in labeled:
        if not (isinstance(item, (list, tuple)) and len(item) == 2 and isinstance(item[0], dict)):
            raise TypeError("each example must be a (featureset dict, label) pair")
        pairs.append((item[0], item[1]))
    if not pairs:
        raise ValueError("cannot train a classifier on an empty list")
    return pairs


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with expected-likelihood (add-1/2) smoothing of feature-value frequencies."""

    def __init__(self, label_counts, feature_counts, feature_values, totals, n):
        self._label_counts = label_counts
        self._feature_counts = feature_counts  # (label, fname) -> Counter(value -> count)
        self._feature_values = feature_values  # fname -> set of values seen in training
        self._totals = totals  # (label, fname) -> total count
        self._n = n
        self._labels = list(label_counts.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_pairs(labeled_featuresets)
        label_counts = Counter()
        feature_counts = defaultdict(Counter)
        feature_values = defaultdict(set)
        for fs, label in pairs:
            label_counts[label] += 1
            for fname, value in fs.items():
                feature_counts[(label, fname)][value] += 1
                feature_values[fname].add(value)
        totals = {key: sum(c.values()) for key, c in feature_counts.items()}
        return cls(label_counts, dict(feature_counts), dict(feature_values), totals, len(pairs))

    def labels(self):
        return list(self._labels)

    def _log_joint(self, featureset):
        scores = {}
        for label in self._labels:
            score = math.log(self._label_counts[label] / self._n)
            for fname, value in featureset.items():
                if fname not in self._feature_values:
                    continue
                values = self._feature_values[fname]
                bins = len(values) if value in values else len(values) + 1
                counts = self._feature_counts.get((label, fname))
                seen = counts.get(value, 0) if counts else 0
                total = self._totals.get((label, fname), 0)
                score += math.log((seen + 0.5) / (total + 0.5 * bins))
            scores[label] = score
        return scores

    def classify(self, featureset):
        scores = self._log_joint(featureset)
        return max(self._labels, key=lambda label: scores[label])

    def prob_classify(self, featureset):
        scores = self._log_joint(featureset)
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: v / total for label, v in exps.items()})


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = None
    best_count = -1
    for label in labels:  # first-seen wins ties
        if counts[label] > best_count:
            best, best_count = label, counts[label]
    return best


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Split:
    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


class DecisionTreeClassifier:
    """ID3-style tree: at each node test the feature with the highest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_pairs(labeled_featuresets)
        features = sorted({f for fs, _ in pairs for f in fs}, key=repr)
        return cls(cls._build(pairs, features))

    @classmethod
    def _build(cls, pairs, features):
        labels = [label for _, label in pairs]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Leaf(majority)
        base = _entropy(labels)
        best_feature = None
        best_gain = 0.0
        best_parts = None
        n = len(pairs)
        for f in features:
            parts = defaultdict(list)
            for fs, label in pairs:
                parts[fs.get(f)].append((fs, label))
            if len(parts) < 2:
                continue
            remainder = sum(
                (len(part) / n) * _entropy([lab for _, lab in part]) for part in parts.values()
            )
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feature, best_gain, best_parts = f, gain, parts
        if best_feature is None:
            return _Leaf(majority)
        rest = [f for f in features if f != best_feature]
        children = {
            value: cls._build(part, rest) for value, part in best_parts.items()
        }
        return _Split(best_feature, children, majority)

    def classify(self, featureset):
        node = self._root
        while isinstance(node, _Split):
            value = featureset.get(node.feature)
            if value not in node.children:
                return node.default
            node = node.children[value]
        return node.label


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs whose label the classifier gets right."""
    if not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        return 0.0
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)


__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]
