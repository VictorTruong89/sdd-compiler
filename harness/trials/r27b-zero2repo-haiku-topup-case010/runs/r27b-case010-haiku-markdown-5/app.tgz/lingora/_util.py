"""Small argument-checking helpers shared by the lingora modules."""


def check_text(value, name="text"):
    if not isinstance(value, str):
        raise TypeError("%s must be a str, not %s" % (name, type(value).__name__))
    return value


def check_token_list(value, name="tokens"):
    if isinstance(value, str) or not isinstance(value, (list, tuple)):
        raise TypeError("%s must be a list of str, not %s" % (name, type(value).__name__))
    for item in value:
        if not isinstance(item, str):
            raise TypeError("%s must contain only str, found %s" % (name, type(item).__name__))
    return list(value)
