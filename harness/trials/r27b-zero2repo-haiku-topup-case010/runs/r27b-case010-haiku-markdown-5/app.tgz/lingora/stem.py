"""Stemmers (``lingora.stem``).

Implemented here: Porter (original, Martin-extensions, and LINGORA-extensions
modes), Snowball for ``english`` (Porter2) and ``porter`` (original Porter),
Lancaster (Paice/Husk engine), the regular-expression stemmer, and WordNet
lemmatization (needs the packaged WordNet directory). ARLSTem/ARLSTem2 are
approximate light stemmers. Snowball stemmers for the other listed languages are
not implemented in this build and raise NotImplementedError.
"""

import os
import re

from lingora import data
from lingora._util import check_text

_VOWELS = "aeiou"

# ---------------------------------------------------------------- Porter core helpers


def _is_cons(w, i):
    c = w[i]
    if c in _VOWELS:
        return False
    if c == "y":
        return i == 0 or not _is_cons(w, i - 1)
    return True


def _measure(stem):
    m = 0
    seen_vowel = False
    for i in range(len(stem)):
        if _is_cons(stem, i):
            if seen_vowel:
                m += 1
                seen_vowel = False
        else:
            seen_vowel = True
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _is_cons(w, len(w) - 1)


def _cvc(stem, lingora):
    n = len(stem)
    if n >= 3:
        return (
            _is_cons(stem, n - 3)
            and not _is_cons(stem, n - 2)
            and _is_cons(stem, n - 1)
            and stem[-1] not in "wxy"
        )
    if n == 2 and lingora:
        return (not _is_cons(stem, 0)) and _is_cons(stem, 1) and stem[1] not in "wxy"
    return False


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_MARTIN = [("bli", "ble") if s == "abli" else (s, r) for s, r in _STEP2_ORIGINAL]
_STEP2_MARTIN.extend([("logi", "log")])
_STEP2_LINGORA = [("bli", "ble") if s == "abli" else (s, r) for s, r in _STEP2_ORIGINAL]
_STEP2_LINGORA.extend([("fulli", "ful"), ("logi", "log")])
_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
    "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]
_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}


class PorterStemmer:
    """Porter's suffix-stripping algorithm (1980).

    ``mode`` is one of ``ORIGINAL_ALGORITHM``, ``MARTIN_EXTENSIONS`` or
    ``LINGORA_EXTENSIONS`` (the default).
    """

    ORIGINAL_ALGORITHM = "original"
    MARTIN_EXTENSIONS = "martin"
    LINGORA_EXTENSIONS = "lingora"
    MODES = ("original", "martin", "lingora")

    def __init__(self, mode="lingora"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode: %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=False):
        check_text(word, "word")
        w = word.lower() if to_lowercase else word
        lg = self.mode == self.LINGORA_EXTENSIONS
        if lg and w in _IRREGULAR:
            return _IRREGULAR[w]
        if len(w) <= 2:
            return w
        w = self._step1a(w, lg)
        w = self._step1b(w, lg)
        w = self._step1c(w, lg)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5(w, lg)
        return w

    def _step2_rules(self):
        if self.mode == self.LINGORA_EXTENSIONS:
            return _STEP2_LINGORA
        if self.mode == self.MARTIN_EXTENSIONS:
            return _STEP2_MARTIN
        return _STEP2_ORIGINAL

    def _step1a(self, w, lg):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if lg and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("s") and not w.endswith("ss"):
            return w[:-1]
        return w

    def _step1b(self, w, lg):
        if lg and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            return w[:-1] if _measure(w[:-3]) > 0 else w
        for suf in ("ed", "ing"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if not _has_vowel(stem):
                    return w
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    return w + "e"
                if _ends_double_cons(w) and w[-1] not in "lsz":
                    return w[:-1]
                if _measure(w) == 1 and _cvc(w, lg):
                    return w + "e"
                return w
        return w

    def _step1c(self, w, lg):
        if w.endswith("y") and len(w) > 1:
            stem = w[:-1]
            if lg:
                ok = len(stem) >= 2 and _is_cons(w, len(stem) - 1)
            else:
                ok = _has_vowel(stem)
            if ok:
                return stem + "i"
        return w

    def _step2(self, w):
        if self.mode == self.LINGORA_EXTENSIONS and w.endswith("alli") and _measure(w[:-4]) > 0:
            return self._step2_again(w[:-2])
        return self._apply_first(w, self._step2_rules())

    def _step2_again(self, w):
        return self._apply_first(w, self._step2_rules())

    def _step3(self, w):
        return self._apply_first(w, _STEP3)

    @staticmethod
    def _apply_first(w, rules):
        for suf, rep in rules:
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if suffix_measure_ok(suf, w):
                    return stem + rep
                return w
        return w

    def _step4(self, w):
        for suf in _STEP4:
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if suf == "ion":
                    if stem and stem[-1] in "st" and _measure(stem) > 1:
                        return stem
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    def _step5(self, w, lg):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _cvc(stem, lg)):
                w = stem
        if _measure(w) > 1 and _ends_double_cons(w) and w.endswith("l"):
            w = w[:-1]
        return w


def suffix_measure_ok(suf, w):
    """Measure condition for a Porter Step 2/3 rule; ``logi`` is measured before ``ogi``."""
    if suf == "logi":
        return _measure(w[:-3]) > 0
    return _measure(w[: -len(suf)]) > 0


# ---------------------------------------------------------------- Snowball (english = Porter2)

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_V = "aeiouy"
_P2_S2 = sorted(
    [
        ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
        ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
        ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
    ],
    key=lambda p: -len(p[0]),
)
_P2_S3 = sorted(
    [
        ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
        ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
    ],
    key=lambda p: -len(p[0]),
)
_P2_S4 = sorted(
    [
        "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
        "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
    ],
    key=lambda s: -len(s),
)


def _p2_r1(w):
    if w.startswith(("gener", "commun")):
        return 5
    if w.startswith("arsen"):
        return 4
    return _p2_region(w, 0)


def _p2_region(w, start):
    for i in range(start + 1, len(w)):
        if w[i] not in _P2_V and w[i - 1] in _P2_V:
            return i + 1
    return len(w)


def _p2_short(w):
    if len(w) == 2:
        return w[0] in _P2_V and w[1] not in _P2_V
    if len(w) >= 3:
        return (
            w[-3] not in _P2_V
            and w[-2] in _P2_V
            and w[-1] not in _P2_V
            and w[-1] not in "wxY"
        )
    return False


def _porter2(word):
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_V:
            chars[i] = "Y"
    w = "".join(chars)
    # R1 and R2 are fixed once, before step 0 (Snowball semantics)
    r1 = _p2_r1(w)
    r2 = r1 + _p2_region(w[r1:], 0)

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if w.endswith(suf):
            w = w[: -len(suf)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith("s"):
        if not w.endswith(("us", "ss")) and any(c in _P2_V for c in w[:-2]):
            w = w[:-1]
    if w in _P2_EXC2:
        return w.replace("Y", "y")
    # Step 1b
    if w.endswith(("eed", "eedly")):
        suf = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suf) >= r1:
            w = w[: -len(suf)] + "ee"
    else:
        for suf in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suf):
                stem = w[: -len(suf)]
                if any(c in _P2_V for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif len(w) >= 2 and w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        w = w[:-1]
                    elif _p2_short(w) and r1 >= len(w):
                        w += "e"
                break
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_V:
        w = w[:-1] + "i"
    # Step 2 (longest matching suffix only; it must start in R1)
    for suf, rep in _P2_S2:
        if w.endswith(suf):
            start = len(w) - len(suf)
            if start >= r1:
                if suf == "ogi":
                    if len(w) >= 4 and w[-4] == "l":
                        w = w[:-3] + "og"
                elif suf == "li":
                    if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                        w = w[:-2]
                else:
                    w = w[:start] + rep
            break
    # Step 3
    for suf, rep in _P2_S3:
        if w.endswith(suf):
            start = len(w) - len(suf)
            if suf in ("ful", "ness", "ative"):
                if start >= r2:
                    w = w[:start]
            elif start >= r1:
                w = w[:start] + rep
            break
    # Step 4 (must start in R2)
    for suf in _P2_S4:
        if w.endswith(suf):
            start = len(w) - len(suf)
            if start >= r2:
                if suf == "ion":
                    if start >= 1 and w[start - 1] in "st":
                        w = w[:start]
                else:
                    w = w[:start]
            break
    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2:
            w = w[:-1]
        elif len(w) - 1 >= r1 and not _p2_short(w[:-1]):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and len(w) >= 2 and w[-2] == "l":
        w = w[:-1]
    return w.replace("Y", "y")


# ---------------------------------------------------------------- Snowball facade

_SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)


class SnowballStemmer:
    """Snowball stemmers. ``english`` is Porter2; ``porter`` is the original Porter algorithm."""

    languages = _SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in _SNOWBALL_LANGUAGES:
            raise ValueError("Snowball stemmer does not support language %r" % (language,))
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            found = data.require(
                os.path.join("corpora", "stopwords", language),
                "Stopwords list for %r" % language,
            )
            with open(found, encoding="utf-8") as fh:
                self._stopwords = {line.strip().lower() for line in fh if line.strip()}
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemmer for %r is not implemented in this build" % language
            )

    def stem(self, word):
        check_text(word, "word")
        w = word.lower()
        if self._stopwords is not None and w in self._stopwords:
            return w
        if self.language == "english":
            return _porter2(w)
        return PorterStemmer(mode="original").stem(w)


# ---------------------------------------------------------------- Lancaster (Paice/Husk)

# (forward suffix, needs intact word, letters removed from the suffix's end,
#  text appended, continue after applying)
# Partial reconstruction of the Paice/Husk rule table; see NOTES.md.
_LANCASTER_RULES = [
    ("ia", True, 2, "", False),
    ("a", True, 1, "", False),
    ("bb", False, 1, "", False),
    ("ytic", False, 3, "s", False),
    ("dd", False, 1, "", False),
    ("ied", False, 3, "y", False),
    ("ceed", False, 2, "ss", False),
    ("eed", False, 1, "", False),
    ("ed", False, 2, "", True),
    ("hood", False, 4, "", True),
    ("e", False, 1, "", True),
]


class LancasterStemmer:
    def stem(self, word):
        check_text(word, "word")
        w = word.lower()
        intact = True
        while True:
            applied = False
            for suffix, needs_intact, removed, appended, keep_going in _LANCASTER_RULES:
                if not w.endswith(suffix):
                    continue
                if needs_intact and not intact:
                    continue
                base = w[: -len(suffix)] + suffix[: len(suffix) - removed] + appended
                if not _lancaster_acceptable(base):
                    continue
                w = base
                intact = False
                applied = True
                if not keep_going:
                    return w
                break
            if not applied:
                return w


def _lancaster_acceptable(base):
    return len(base) >= 2 and any(c in "aeiouy" for c in base)


# ---------------------------------------------------------------- regular expression


class RegexpStemmer:
    """Removes every match of ``regexp`` from the word and changes nothing else."""

    def __init__(self, regexp):
        self._regex = re.compile(regexp) if isinstance(regexp, str) else regexp

    def stem(self, word):
        check_text(word, "word")
        return self._regex.sub("", word)


# ---------------------------------------------------------------- Arabic light stemmers

_AR_PREFIXES = ("وال", "بال", "كال", "فال", "ال", "و", "ب", "ف", "ل", "ك")
_AR_SUFFIXES_1 = ("ات", "ان", "ون", "ين", "ها", "ية", "ه", "ة", "ي")
_AR_SUFFIXES_2 = ("كما", "هما", "ات", "ان", "ون", "ين", "ها", "ية", "ه", "ة", "ي", "تم", "نا")


def _arabic_light(word, suffixes):
    w = word
    for p in _AR_PREFIXES:
        if w.startswith(p) and len(w) - len(p) >= 3:
            w = w[len(p):]
            break
    for s in suffixes:
        if w.endswith(s) and len(w) - len(s) >= 3:
            w = w[: -len(s)]
            break
    return w


class ARLSTem:
    """Approximate light stemmer for Arabic (not the published ARLSTem algorithm)."""

    def stem(self, word):
        check_text(word, "word")
        return _arabic_light(word, _AR_SUFFIXES_1)


class ARLSTem2:
    """Approximate light stemmer for Arabic (not the published ARLSTem2 algorithm)."""

    def stem(self, word):
        check_text(word, "word")
        return _arabic_light(word, _AR_SUFFIXES_2)


# ---------------------------------------------------------------- WordNet lemmatizer

_WN_RULES = {
    "n": [("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y"), ("s", "")],
    "v": [("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", ""), ("s", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [("er", ""), ("est", "")],
}
_WN_INDEX_CACHE = {}


class WordNetLemmatizer:
    """Lemmatizer over the packaged WordNet index files (needs ``corpora/wordnet``)."""

    def __init__(self):
        self._dir = data.require(os.path.join("corpora", "wordnet"), "WordNet", directory=True)

    def _index(self, pos):
        key = (self._dir, pos)
        if key not in _WN_INDEX_CACHE:
            words = set()
            name = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}[pos]
            fn = os.path.join(self._dir, "index." + name)
            if os.path.exists(fn):
                with open(fn, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        if line.startswith(" "):
                            continue
                        words.add(line.split(" ", 1)[0])
            _WN_INDEX_CACHE[key] = words
        return _WN_INDEX_CACHE[key]

    def lemmatize(self, word, pos="n"):
        check_text(word, "word")
        if pos not in _WN_RULES:
            raise ValueError("unknown WordNet part of speech: %r" % (pos,))
        index = self._index(pos)
        if word in index:
            return word
        for suf, rep in _WN_RULES[pos]:
            if word.endswith(suf) and len(word) > len(suf) + 1:
                cand = word[: -len(suf)] + rep
                if cand in index:
                    return cand
        return word


__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]
