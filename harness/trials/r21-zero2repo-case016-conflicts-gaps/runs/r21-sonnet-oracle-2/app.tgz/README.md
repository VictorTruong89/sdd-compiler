# prosecheck
Local, standard-library detector for AI-writing patterns (`scripts/detect.py`, Python 3.9+) plus Node.js plugin hooks under `hooks/`. No build step. See `NOTES.md` for decisions.
