#!/usr/bin/env node
'use strict';
try {
  const lib = require('./prosecheck-lib');
  lib.readStdinJson();
  const existed = (() => { try { return lib.fs.existsSync(lib.flagPath()); } catch (e) { return false; } })();
  lib.pruneLedgers();
  let level = lib.currentLevel();
  if (!lib.storedLevel()) lib.storeLevel(level);
  if (level !== 'off') {
    let out = '';
    if (!existed) out += lib.welcomeText() + '\n';
    out += lib.contractText(level, { detector: lib.detectorPath() });
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
