#!/usr/bin/env node
'use strict';
const lib = require('./prosecheck-lib');
const { fs, path } = lib;

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpReply(level) {
  return [
    'prosecheck help - current level: ' + level,
    'Always left alone: code, commits, config, and chat are never touched.',
    '',
    '/prosecheck lite - turn on the writing contract, no scoring of saved files',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard with a lower threshold of 20, plus the cleanup scrub',
    '/prosecheck off | on - disable the tool / re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list files scored in this session',
    '/prosecheck check <file> - score one file and report only, without a rewrite',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the prose score of this session',
    '/prosecheck init - export the contract to AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".'
  ].join('\n');
}

function stripArg(a) {
  let s = (a || '').trim();
  for (let i = 0; i < 2; i++) {
    if (s[0] === '@') s = s.slice(1).trim();
    const m = /^(["'])(.*)\1$/.exec(s);
    if (m) s = m[2];
  }
  return s;
}

function checkReply(arg, cwd) {
  const p0 = stripArg(arg);
  if (!p0) return 'Usage: /prosecheck check <file> - give the path of a prose file to score.';
  const full = path.resolve(cwd || process.cwd(), p0);
  const base = path.basename(full);
  let st;
  try { st = fs.statSync(full); } catch (e) { return 'cannot read ' + p0 + ': it is not on disk.'; }
  if (!st.isFile()) return p0 + ' is not a file.';
  const ext = path.extname(full).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf' || lib.ALL_EXT.indexOf(ext) < 0) return base + ': no readable text (not a supported prose format).';
  const plain = lib.PLAIN_EXT.indexOf(ext) >= 0;
  const cap = plain ? lib.PLAIN_CAP : lib.ARCHIVE_CAP;
  if (st.size > cap) return base + ' is over ' + (cap / 1024) + ' KB, so it was not scored.';
  const r = lib.runDetector([full], { timeout: plain ? 8000 : 15000 });
  if (r.status === 'fail') {
    if (r.kind === 'timeout') return base + ' failed: the detector timed out.';
    if (r.kind === 'empty') return base + ' failed: the detector gave no usable result.';
    return 'detector unavailable: Python or the bundled detector could not be run, so nothing was scored.';
  }
  if (r.code !== 0) {
    const e = (r.stderr || '').trim();
    return base + ' failed: ' + (e || 'the detector run did not succeed.');
  }
  if (!r.stdout.trim()) return base + ': no report was produced by the detector.';
  const pr = lib.parseReport(r.stdout);
  if (!pr.report) return 'no report: the detector output was not a usable report.';
  const m = pr.report._metrics;
  const L = [];
  L.push(base + ' - ' + lib.phrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  L.push('confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated) L.push('coverage: first 262,144 characters only');
  const fs_ = lib.findings(pr.report).slice(0, 8);
  L.push(fs_.length ? 'tells: ' + fs_.map(f => f.label + ' (x' + f.count + ')').join('; ') : 'tells: none');
  L.push('This is a report only; the file was not changed.');
  return L.join('\n');
}

function doctorReply(form) {
  const level = lib.currentLevel();
  const lines = [];
  let allOk = true;
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[off] mode: off - tool is switched off; turn it back with /prosecheck on');
  const det = lib.detectorPath();
  lines.push(det ? '[OK] detector: bundled script present' : '[FAIL] detector: bundled script missing from the plugin tree');
  if (!det) allOk = false;
  let pyLine;
  if (!det) {
    pyLine = '[FAIL] python: cannot run the bundled detector because it is missing';
    allOk = false;
  } else {
    const r = lib.runDetector([], { input: 'The cat sat on the mat. It rained all day, so we stayed in and played cards.', timeout: 15000 });
    if (r.status === 'fail' && r.kind === 'nopython') {
      pyLine = '[FAIL] python not found - the writing contract still applies to new prose, but saved files are not re-scored until Python is available';
      allOk = false;
    } else if (r.status === 'ran' && r.code === 0 && lib.parseReport(r.stdout).report) {
      pyLine = '[OK] python ran the bundled detector and returned a numeric score';
    } else {
      pyLine = '[FAIL] python ran but the result was not a numeric score';
      allOk = false;
    }
  }
  lines.push(pyLine);
  let writable = false;
  try {
    fs.mkdirSync(lib.configDir(), { recursive: true });
    const probe = path.join(lib.configDir(), '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    writable = true;
  } catch (e) { writable = false; }
  lines.push(writable ? '[OK] settings folder is writable' : '[FAIL] settings folder is not writable');
  if (!writable) allOk = false;
  let closer;
  if (!allOk) closer = 'Some checks failed. Please fix the faulty checks above, then run /prosecheck doctor again.';
  else if (!modeOk) closer = 'The install is healthy. While the mode is off, saving files triggers no scoring and nothing gets scored. Run ' + form + ' on to turn the tool back on.';
  else closer = 'prosecheck is active. Plain text is read up to 512 KB and archives up to 4 MB, and only the first 262,144 characters are scanned. Use ' + form + ' show to see files that were only partly scanned or skipped.';
  return ['prosecheck doctor - health check'].concat(lines, [closer]).join('\n');
}

function showReply(sid) {
  const recs = lib.readLedger(sid);
  if (!recs.length) return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  const L = ['prosecheck show - files from this session, newest first:'];
  for (const r of recs.slice().reverse()) {
    const b = r.base || '(unnamed)';
    if (r.status === 'scored') {
      let s = b + ' - ' + lib.phrase(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first 262,144 characters only' : '') + ')';
      if (r.labels && r.labels.length) s += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      L.push(s);
    } else if (r.status === 'skipped') {
      L.push(b + ' - not scored: larger than the ' + r.capKb + ' KB limit');
    } else if (r.status === 'binary') {
      L.push(b + ' - binary file, not re-scored');
    } else {
      L.push(b + ' - not scored: ' + (r.reason || 'the check failed'));
    }
  }
  return L.join('\n');
}

function newestJsonl(dir) {
  let best = null;
  const walk = (d, depth) => {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory() && depth < 4) walk(p, depth + 1);
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try { const m = fs.statSync(p).mtimeMs; if (!best || m > best.m) best = { p, m }; } catch (x) { /* */ }
      }
    }
  };
  walk(dir, 0);
  return best && best.p;
}

function statsReply(tp) {
  const level = lib.currentLevel();
  let file = null;
  if (typeof tp === 'string' && tp) file = tp;
  else file = newestJsonl(path.join(lib.configDir(), 'projects'));
  let raw = null;
  if (file) { try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) return 'prosecheck stats - level: ' + level + '\nNo readable session transcript was found, so there are no token figures.';
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const key = typeof m.id === 'string' && m.id ? m.id : '#' + (anon++);
    const u = m.usage || {};
    const t = [];
    if (Array.isArray(m.content)) for (const c of m.content) if (c && c.type === 'text' && typeof c.text === 'string') t.push(c.text);
    const prev = byId.get(key);
    const rec = { out: +u.output_tokens || 0, cache: +u.cache_read_input_tokens || 0, text: t.join('\n'), order: prev ? prev.order : byId.size };
    if (prev) { rec.out = Math.max(rec.out, prev.out); rec.cache = Math.max(rec.cache, prev.cache); if (!rec.text) rec.text = prev.text; else if (prev.text && prev.text !== rec.text) rec.text = prev.text + '\n' + rec.text; }
    byId.set(key, rec);
  }
  let turns = 0, out = 0, cache = 0;
  const recs = Array.from(byId.values()).sort((a, b) => a.order - b.order);
  for (const r of recs) { turns++; out += r.out; cache += r.cache; if (r.text) texts.push(r.text); }
  const L = ['prosecheck stats', '  level: ' + level, '  assistant turns: ' + turns, '  output tokens: ' + out, '  cache-read input tokens: ' + cache];
  let prose = texts.join('\n\n').replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n {0,3}\1[`~]*[ \t]*(?=\n|$)|$)/gm, '');
  prose = prose.slice(-40000).trim();
  if (prose.length > 200) {
    const r = lib.runDetector([], { input: prose, timeout: 15000 });
    if (r.status === 'ran' && r.code === 0) {
      const pr = lib.parseReport(r.stdout);
      if (pr.report) L.push('  session prose ai_tell_score: ' + pr.report._metrics.ai_tell_score);
    }
  }
  return L.join('\n');
}

function initReply(form) {
  const level = lib.currentLevel();
  if (level === 'off') return 'prosecheck is switched off, so init wrote no files. Run ' + form + ' on to allow the export.';
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  const BEGIN = '<!-- prosecheck:begin -->', END = '<!-- prosecheck:end -->';
  const section = BEGIN + '\n' + lib.contractText(level, { portable: true }) + END + '\n';
  let existing = '';
  let readOk = true;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') readOk = false; }
  if (!readOk) {
    out.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing.indexOf(BEGIN) >= 0 || existing.indexOf('# Prose contract') >= 0) {
    out.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    let add = section;
    if (existing.length) add = (existing.endsWith('\n') ? '' : '\n') + '\n' + section;
    try { fs.appendFileSync(agents, add); out.push('Wrote the writing contract to AGENTS.md.'); } catch (e) { out.push('cannot write AGENTS.md, so the contract was not exported.'); }
  }
  const dst = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dst)) {
    out.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    try {
      const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.writeFileSync(dst, data);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) { out.push('cannot write the Cursor rule .cursor/rules/prosecheck.mdc.'); }
  }
  return out.join('\n');
}

function main() {
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    lib.storeLevel('off');
    return block('prosecheck is now off. Turn it back on with /prosecheck on.');
  }
  const m = /^\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/.exec(trimmed);
  if (!m) {
    const level = lib.currentLevel();
    if (level === 'off') return;
    process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: 'prosecheck is active at level ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.' } }));
    return;
  }
  const form = lib.typedForm(trimmed);
  const rest = m[1].trim();
  const sp = /^(\S+)\s*([\s\S]*)$/.exec(rest);
  const sub = sp ? sp[1].toLowerCase() : 'help';
  const arg = sp ? sp[2].trim() : '';
  const level = lib.currentLevel();
  switch (sub) {
    case 'help': return block(helpReply(level));
    case 'lite': case 'full': case 'strict': case 'off':
      lib.storeLevel(sub);
      return block('prosecheck level set to ' + sub + (sub === 'off' ? ': the tool is off.' : '.'));
    case 'on':
      lib.storeLevel('full');
      return block('prosecheck is on (full).');
    case 'status': return block('prosecheck level: ' + level);
    case 'show': return block(showReply(input.session_id));
    case 'check': return block(checkReply(arg, typeof input.cwd === 'string' ? input.cwd : undefined));
    case 'doctor': return block(doctorReply(form));
    case 'stats': return block(statsReply(input.transcript_path));
    case 'init': return block(initReply(form));
    default:
      return block('unknown subcommand "' + sub + '". Valid words: lite, full, strict, off, on, status, show, check, doctor, stats, init, help.');
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
