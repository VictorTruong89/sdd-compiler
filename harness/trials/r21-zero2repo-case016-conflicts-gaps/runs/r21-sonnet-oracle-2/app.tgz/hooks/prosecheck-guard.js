#!/usr/bin/env node
'use strict';
const lib = require('./prosecheck-lib');
const { fs, path } = lib;
const MAX_PATHS = 16;
const TOOLS = ['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch'];
const INSTR = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function patchPaths(cmd) {
  const out = [];
  for (const line of String(cmd).split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m && m[1].trim()) out.push(m[1].trim());
  }
  return out;
}

function skipPath(full) {
  const parts = full.split(/[\\/]+/);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return true;
  const root = path.resolve(lib.pluginRoot());
  if (full === root || full.indexOf(root + path.sep) === 0) return true;
  const base = path.basename(full).toLowerCase();
  if (INSTR.indexOf(base) >= 0) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (INSTR_STEMS.indexOf(stem) >= 0 && lib.PLAIN_EXT.concat(lib.ZIP_EXT, ['.ipynb']).indexOf(ext) < 0) return true;
  return false;
}

function failRec(base, reason) { return { base, status: 'failed', reason, t: Date.now() }; }

function scoreOne(full, level) {
  const base = path.basename(full);
  const ext = path.extname(full).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return { rec: { base, status: 'binary', t: Date.now() } };
  if (lib.ALL_EXT.indexOf(ext) < 0) return null;
  let st;
  try { st = fs.statSync(full); } catch (e) { return { rec: failRec(base, 'file could not be read (not found or unreadable)') }; }
  if (!st.isFile()) return null;
  const plain = lib.PLAIN_EXT.indexOf(ext) >= 0;
  const cap = plain ? lib.PLAIN_CAP : lib.ARCHIVE_CAP;
  if (st.size > cap) return { rec: { base, status: 'skipped', capKb: cap / 1024, t: Date.now() } };
  const r = lib.runDetector([full], { timeout: plain ? 8000 : 15000 });
  if (r.status === 'fail') {
    if (r.kind === 'nopython') return { rec: failRec(base, 'Python was not found') };
    if (r.kind === 'timeout') return { rec: failRec(base, 'the detector timed out') };
    if (r.kind === 'nodetector') return { rec: failRec(base, 'the bundled detector was not found') };
    return { rec: failRec(base, 'the detector produced no output or no usable result') };
  }
  if (r.code !== 0 || !r.stdout.trim()) return { rec: failRec(base, 'the detector produced no output or no usable result') };
  const pr = lib.parseReport(r.stdout);
  if (pr.kind === 'notreport') return { rec: failRec(base, 'the detector printed text that is not a structured report') };
  if (pr.kind === 'noscore') return { rec: failRec(base, 'the report had no numeric score') };
  const m = pr.report._metrics;
  const threshold = level === 'strict' ? 20 : 40;
  const labels = lib.findings(pr.report).slice(0, 5).map(f => f.label);
  const flagged = m.ai_tell_score > threshold;
  const rec = { base, status: 'scored', score: m.ai_tell_score, band: m.ai_tell_band, labels, flagged, truncated: !!m.truncated, t: Date.now() };
  let line = null;
  if (flagged) {
    line = 'prosecheck: ' + base + ' ' + lib.phrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + (m.truncated ? ', first 262,144 characters only' : '') + '). Flagged: ' + (labels.length ? labels.join('; ') : 'patterns') + '. Please fix the flagged spans, keeping sentence rhythm varied.';
  }
  return { rec, line };
}

function main() {
  const input = lib.readStdinJson();
  const level = lib.currentLevel();
  if (level === 'off' || level === 'lite') return;
  if (typeof input.tool_name === 'string' && TOOLS.indexOf(input.tool_name) < 0) return;
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cands = [];
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) cands.push(ti.file_path.trim());
  if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) cands.push(ti.notebook_path.trim());
  if (typeof ti.command === 'string') for (const p of patchPaths(ti.command)) cands.push(p);
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const seen = [];
  for (const c of cands) {
    const full = path.resolve(cwd, c);
    if (seen.indexOf(full) < 0) seen.push(full);
    if (seen.length >= MAX_PATHS) break;
  }
  const lines = [];
  const recs = [];
  for (const full of seen) {
    if (skipPath(full)) continue;
    const r = scoreOne(full, level);
    if (!r) continue;
    recs.push(r.rec);
    if (r.line) lines.push(r.line);
  }
  if (recs.length) lib.addLedger(input.session_id, recs);
  if (lines.length) process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') } }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
