'use strict';
// Shared helpers for prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const ALL_EXT = PLAIN_EXT.concat(ZIP_EXT, ['.ipynb']);
const LEDGER_MAX = 20;
const LEDGER_AGE_MS = 7 * 24 * 3600 * 1000;
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const o = JSON.parse(raw);
    return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
  } catch (e) { return {}; }
}

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function storedLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    if (LEVELS.indexOf(v) >= 0) return v;
  } catch (e) { /* none */ }
  return null;
}
function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}
function currentLevel() { return storedLevel() || envLevel() || 'full'; }
function storeLevel(l) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), l);
    return true;
  } catch (e) { return false; }
}

function ledgerName(sid) {
  const s = typeof sid === 'string' ? sid.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 100) : '';
  return s ? '.prosecheck-ledger-' + s : '.prosecheck-ledger';
}
function ledgerPath(sid) { return path.join(configDir(), ledgerName(sid)); }
function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) return [];
    const a = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(a) ? a : [];
  } catch (e) { return []; }
}
function addLedger(sid, recs) {
  try {
    let a = readLedger(sid).concat(recs);
    a = a.slice(-LEDGER_MAX);
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(a));
  } catch (e) { /* ignore */ }
}
function pruneLedgers() {
  try {
    const d = configDir();
    for (const f of fs.readdirSync(d)) {
      if (f === '.prosecheck-ledger' || f.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(d, f);
        try { if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(p); } catch (e) { /* */ }
      }
    }
  } catch (e) { /* */ }
}

function detectorPath() {
  const r = pluginRoot();
  for (const rel of [path.join('scripts', 'detect.py'), path.join('skills', 'prosecheck', 'scripts', 'detect.py')]) {
    const p = path.join(r, rel);
    try { if (fs.statSync(p).isFile()) return p; } catch (e) { /* */ }
  }
  return null;
}

// Run the detector. Returns {status:'ok', report} or {status:'fail', kind, stderr, code}
function runDetector(args, opts) {
  opts = opts || {};
  const det = detectorPath();
  if (!det) return { status: 'fail', kind: 'nodetector' };
  let lastErr = null;
  for (const py of ['python3', 'python', 'py']) {
    const r = cp.spawnSync(py, [det].concat(args), { input: opts.input, timeout: opts.timeout || 15000, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, cwd: opts.cwd });
    if (r.error && r.error.code === 'ENOENT') { lastErr = r.error; continue; }
    if (r.error && (r.error.code === 'ETIMEDOUT' || r.signal)) return { status: 'fail', kind: 'timeout' };
    if (r.error) return { status: 'fail', kind: 'empty', stderr: String(r.error.message || '') };
    return { status: 'ran', code: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { status: 'fail', kind: 'nopython', error: lastErr };
}

function parseReport(stdout) {
  let o;
  try { o = JSON.parse(stdout); } catch (e) { return { kind: 'notreport' }; }
  if (!o || typeof o !== 'object' || !o._metrics) return { kind: 'notreport' };
  const s = o._metrics.ai_tell_score;
  if (typeof s !== 'number' || !isFinite(s)) return { kind: 'noscore' };
  return { report: o };
}

function phrase(band) {
  return ({ 'clean': 'reads clean', 'light tells': 'reads mostly clean', 'mixed': 'reads with some AI tells', 'heavy tells': 'reads with heavy AI tells', 'pervasive tells': 'reads with pervasive AI tells' })[band] || 'reads with some AI tells';
}

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (f && typeof f.label === 'string') out.push({ label: f.label, count: f.count || 0 });
  }
  out.sort((a, b) => b.count - a.count);
  return out;
}

// ------------------------------------------------------------ writing contract
function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('# Prose contract');
  L.push('');
  L.push('This contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.');
  L.push('It never touches code comments, commit messages, JSON, YAML or other configuration, CLI output, logs, error messages, or the conversational register of chat. Never apply it to source code.');
  L.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly. No metronome, and no mechanical short-long alternation.');
  L.push('- Never use these words: ' + BANNED.join(', ') + '.');
  L.push('- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Keep factual or encyclopedic content in a neutral third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this contract: never announce it, never name the checker, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    const target = level === 'strict' ? 20 : 40;
    const bandTxt = level === 'strict' ? 'the clean band' : 'the clean or light tells band';
    let how;
    if (opts.detector) {
      how = 'python3 "' + opts.detector + '"';
    } else {
      how = 'the bundled detect.py script';
    }
    if (opts.portable) {
      L.push('After writing a prose file, run the bundled detector (scripts/detect.py) on that file. Use CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the prosecheck detector in your installed skills or plugins.');
    } else {
      L.push('After writing a prose file, run ' + how + ' on that file.');
    }
    L.push('If the score is above ' + target + ' (target: ' + bandTxt + ', score at most ' + target + '), fix the flagged spans and run it again, at most two fix passes, keeping rhythm variation.');
    if (level === 'strict') {
      L.push('Finish with the detector\'s cleanup switch, written --clean, to scrub stray invisible characters, odd spaces, and lookalike letters from the final text.');
    }
  }
  return L.join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and no upload; everything stays on this machine. This notice is shown once.',
    'Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help.',
    ''
  ].join('\n');
}

function typedForm(prompt) {
  return /^\s*\/prosecheck:prosecheck\b/.test(prompt || '') ? '/prosecheck:prosecheck' : '/prosecheck';
}

module.exports = { fs, os, path, cp, LEVELS, WINDOW, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ZIP_EXT, ALL_EXT, BANNED, readStdinJson, configDir, pluginRoot, flagPath, storedLevel, envLevel, currentLevel, storeLevel, ledgerPath, readLedger, addLedger, pruneLedgers, detectorPath, runDetector, parseReport, phrase, findings, contractText, welcomeText, typedForm };
