#!/usr/bin/env node
'use strict';
try {
  const lib = require('./prosecheck-lib');
  lib.readStdinJson();
  const level = lib.currentLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractText(level, { detector: lib.detectorPath() }) } }));
  }
} catch (e) { /* */ }
process.exit(0);
