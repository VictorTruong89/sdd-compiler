#!/usr/bin/env node
'use strict';
// Stats are served by the prompt-submit router (`/prosecheck stats`); this entry
// forwards a prompt-shaped payload to it so it can also be run on its own.
try {
  const lib = require('./prosecheck-lib');
  const input = lib.readStdinJson();
  const cp = require('child_process');
  const r = cp.spawnSync(process.execPath, [require('path').join(__dirname, 'prosecheck-tracker.js')], {
    input: JSON.stringify({ prompt: '/prosecheck stats', transcript_path: input.transcript_path, session_id: input.session_id }), encoding: 'utf8'
  });
  try { const o = JSON.parse(r.stdout); if (o.reason) process.stdout.write(o.reason + '\n'); } catch (e) { /* */ }
} catch (e) { /* */ }
process.exit(0);
