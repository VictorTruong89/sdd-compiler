---
description: prosecheck - writing contract levels, check, doctor, show, init, stats
argument-hint: "[lite|full|strict|off|on|status|show|check|doctor|stats|init|help]"
---
/prosecheck $ARGUMENTS
