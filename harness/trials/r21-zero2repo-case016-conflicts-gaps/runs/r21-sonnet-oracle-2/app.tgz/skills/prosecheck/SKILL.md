---
name: prosecheck
description: Rewrite flagged prose when asked to "prosecheck this" or "humanize this". Prose only, never code.
---
Run `python3 scripts/detect.py FILE` from the plugin root, fix the flagged spans in prose only, keep numbers, names, quotes, and citations, and never invent facts. Scores describe writing, not authorship.
