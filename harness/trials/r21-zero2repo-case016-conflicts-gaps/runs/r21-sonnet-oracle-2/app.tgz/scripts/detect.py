#!/usr/bin/env python3
"""prosecheck detector: local, stdlib-only AI-writing-pattern scanner."""
import sys, os, re, json, math, random, zipfile, unicodedata, io
from xml.etree import ElementTree as ET
from html.parser import HTMLParser

WINDOW = 262144
USAGE = "usage: detect.py [--clean] [--ci] [--] [FILE]\n\nScore prose for AI-writing patterns (JSON report), or scrub characters with --clean.\n  --clean  print scrubbed text instead of the report\n  --ci     add a resampled low/high interval on the score\n  --       end of options\n  FILE     one file; omit to read standard input\n"
BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]
PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
MEMBER_CAP = 64 * 1024 * 1024


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg, self.code = msg, code


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]

# ---------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", "replace")
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            return b[2:].decode("utf-16", "replace")
    t = b.decode("utf-8", "replace")
    return t


def _ln(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _zread(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return b""
    return z.read(name)


def _parse(b):
    try:
        return ET.fromstring(b)
    except Exception:
        return None


def _para_text(p, tmap):
    out = []
    for el in p.iter():
        n = _ln(el.tag)
        if n in tmap["t"] and el.text:
            out.append(el.text)
        elif n in tmap["tab"]:
            out.append("\t")
        elif n in tmap["br"]:
            out.append("\n")
    return "".join(out)


def ex_docx(z):
    names = [n for n in z.namelist() if n == "word/document.xml"]
    paras = []
    for n in names:
        root = _parse(_zread(z, n))
        if root is None:
            continue
        for p in root.iter():
            if _ln(p.tag) == "p":
                t = _para_text(p, {"t": ("t",), "tab": ("tab",), "br": ("br", "cr")})
                if t.strip():
                    paras.append(t)
    return "\n".join(paras)


def _numkey(n):
    m = re.findall(r"\d+", n)
    return (int(m[-1]) if m else 0, n)


def ex_pptx(z):
    names = sorted([n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)], key=_numkey)
    out = []
    for n in names:
        root = _parse(_zread(z, n))
        if root is None:
            continue
        for p in root.iter():
            if _ln(p.tag) == "p":
                t = _para_text(p, {"t": ("t",), "tab": (), "br": ("br",)})
                if t.strip():
                    out.append(t)
    return "\n".join(out)


def ex_xlsx(z):
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        root = _parse(_zread(z, "xl/sharedStrings.xml"))
        if root is not None:
            for si in root:
                if _ln(si.tag) == "si":
                    shared.append("".join(e.text or "" for e in si.iter() if _ln(e.tag) == "t"))
    names = sorted([n for n in z.namelist() if re.match(r"xl/worksheets/[^/]+\.xml$", n)], key=_numkey)
    out = []
    for n in names:
        root = _parse(_zread(z, n))
        if root is None:
            continue
        for c in root.iter():
            if _ln(c.tag) != "c":
                continue
            t = c.get("t")
            val = None
            if t == "inlineStr":
                val = "".join(e.text or "" for e in c.iter() if _ln(e.tag) == "t")
            elif t in ("s", "str"):
                v = None
                for ch in c:
                    if _ln(ch.tag) == "v":
                        v = ch.text
                if v is None:
                    continue
                if t == "s":
                    v = v.strip()
                    if not re.fullmatch(r"\d+", v):
                        continue
                    i = int(v)
                    if i >= len(shared):
                        continue
                    val = shared[i]
                else:
                    val = v
            if val and val.strip():
                out.append(val)
    return "\n".join(out)


def ex_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    root = _parse(_zread(z, "content.xml"))
    if root is None:
        return ""
    out = []

    def walk(el, buf):
        n = _ln(el.tag)
        if n == "s":
            try:
                buf.append(" " * int(el.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c") or 1))
            except Exception:
                buf.append(" ")
        elif n == "tab":
            buf.append("\t")
        elif n == "line-break":
            buf.append("\n")
        else:
            if el.text:
                buf.append(el.text)
            for ch in el:
                walk(ch, buf)
        if el.tail and el is not None:
            buf.append(el.tail)

    def blocks(el):
        n = _ln(el.tag)
        if n in ("p", "h"):
            buf = []
            if el.text:
                buf.append(el.text)
            for ch in el:
                walk(ch, buf)
            t = "".join(buf)
            if t.strip():
                out.append(t)
            return
        for ch in el:
            blocks(ch)

    blocks(root)
    return "\n".join(out)


class _Html(HTMLParser):
    BLOCK = {"p", "div", "br", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr", "blockquote", "section", "article", "pre", "td", "th", "dt", "dd", "hr"}
    SKIP = {"style", "script", "nav", "head", "title"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.out.append("\n")

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.out.append("\n")

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


def ex_epub(z):
    names = [n for n in z.namelist() if re.search(r"\.(x?html?|xml)$", n, re.I) and not n.startswith("META-INF/")]
    order = []
    # spine order from the package document when present
    try:
        opf = [n for n in z.namelist() if n.lower().endswith(".opf")]
        if opf:
            root = _parse(_zread(z, opf[0]))
            base = os.path.dirname(opf[0])
            man, spine = {}, []
            for el in root.iter():
                if _ln(el.tag) == "item":
                    man[el.get("id")] = el.get("href")
                elif _ln(el.tag) == "itemref":
                    spine.append(el.get("idref"))
            for i in spine:
                h = man.get(i)
                if h:
                    p = os.path.normpath(os.path.join(base, h)).replace("\\", "/")
                    if p in names and p not in order:
                        order.append(p)
    except Exception:
        order = []
    for n in sorted(names):
        if n not in order and re.search(r"\.x?html?$", n, re.I):
            order.append(n)
    out = []
    for n in order:
        raw = _zread(z, n)
        txt = decode_bytes(raw)
        p = _Html()
        try:
            p.feed(txt)
            p.close()
        except Exception:
            pass
        t = re.sub(r"[ \t\r\f\v]*\n[ \t\r\f\v\n]*", "\n", "".join(p.out)).strip()
        if t:
            out.append(t)
    return "\n".join(out)


def ex_ipynb(b):
    try:
        nb = json.loads(decode_bytes(b))
        cells = nb["cells"]
        if not isinstance(cells, list):
            return ""
        out = []
        for c in cells:
            if not isinstance(c, dict) or c.get("cell_type") != "markdown":
                continue
            s = c.get("source")
            if isinstance(s, list):
                if not all(isinstance(x, str) for x in s):
                    continue
                s = "".join(s)
            if isinstance(s, str) and s.strip():
                out.append(s.strip("\n"))
        return "\n".join(out)
    except Exception:
        return ""


def extract(path):
    ext = os.path.splitext(path)[1].lower()
    with open(path, "rb") as f:
        data = f.read()
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except Exception as e:
            raise Fail("cannot read input: not a readable zip archive (%s)" % path)
        try:
            if ext in (".docx", ".docm"):
                t = ex_docx(z)
            elif ext in (".pptx", ".pptm"):
                t = ex_pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = ex_xlsx(z)
            elif ext == ".epub":
                t = ex_epub(z)
            else:
                t = ex_odf(z)
        except Fail:
            raise
        except Exception:
            t = ""
        return t.strip()
    if ext == ".ipynb":
        return ex_ipynb(data).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(data)

# ---------------------------------------------------------------- character layer

LOOK = {}
for _a, _b in [
    ("а", "a"), ("с", "c"), ("е", "e"), ("о", "o"), ("р", "p"), ("х", "x"), ("у", "y"), ("і", "i"), ("ј", "j"), ("ѕ", "s"), ("ԁ", "d"), ("һ", "h"), ("ԝ", "w"), ("ѵ", "v"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"), ("Ј", "J"), ("К", "K"), ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"), ("Т", "T"), ("Х", "X"), ("У", "Y"),
    ("ο", "o"), ("ν", "v"), ("α", "a"), ("ρ", "p"), ("υ", "u"), ("ι", "i"), ("χ", "x"), ("γ", "y"),
    ("Α", "A"), ("Β", "B"), ("Ε", "E"), ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"), ("Ν", "N"), ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Υ", "Y"), ("Χ", "X"),
    ("ց", "g"), ("օ", "o"), ("ո", "n"), ("ս", "u"), ("հ", "h"), ("ԛ", "q"), ("Տ", "S"), ("Օ", "O"), ("Ս", "U"),
    ("ﻫ", "o"), ("ھ", "o"), ("٥", "o"),
]:
    LOOK[_a] = _b

SCRIPT_FREE = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F)]
JOINING = [(0x0590, 0x08FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFC)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFC), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F), (0x2E80, 0x2FDF), (0x3005, 0x3007)]
EXTRA_INVIS = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0, 0x00AD, 0x061C, 0x180E, 0xFEFF}


def _in(c, rngs):
    o = ord(c)
    for a, b in rngs:
        if a <= o <= b:
            return True
    return False


def is_invisible(c):
    o = ord(c)
    if o < 0x80:
        return o < 0x20 and c not in "\t\n\r" or o == 0x7F
    if o in EXTRA_INVIS:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0000 <= o <= 0xE0FFF or 0x180B <= o <= 0x180F:
        return True
    if 0x2060 <= o <= 0x206F or 0x200B <= o <= 0x200F or 0x202A <= o <= 0x202E:
        return True
    if 0x1BCA0 <= o <= 0x1BCA3 or 0x1D173 <= o <= 0x1D17A:
        return True
    cat = unicodedata.category(c)
    if cat in ("Cf", "Cc", "Cs"):
        return o != 0x85
    return False


def _is_emoji_sym(c):
    o = ord(c)
    return o >= 0x1F000 or unicodedata.category(c) in ("So", "Sk") or 0x2190 <= o <= 0x2BFF or o in (0x2122, 0x00A9, 0x00AE)


def _keep(text, i, c, has_rtl):
    o = ord(c)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if 0xE0000 <= o <= 0xE0FFF:
        if 0xE0100 <= o <= 0xE01EF:
            return bool(prev) and _in(prev, CJK)
        j = i - 1
        while j >= 0 and 0xE0000 <= ord(text[j]) <= 0xE007F:
            j -= 1
        return j >= 0 and ord(text[j]) == 0x1F3F4 and j < i
    if 0xFE00 <= o <= 0xFE0F:
        if nxt == "\u20e3":
            return True
        return bool(prev) and (_is_emoji_sym(prev) or _in(prev, CJK))
    if o == 0x200B:
        return (bool(prev) and _in(prev, SCRIPT_FREE)) or (bool(nxt) and _in(nxt, SCRIPT_FREE))
    if o == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return has_rtl
    if 0x180B <= o <= 0x180F:
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if o in (0x17B4, 0x17B5):
        return (bool(prev) and 0x1780 <= ord(prev) <= 0x17FF) or (bool(nxt) and 0x1780 <= ord(nxt) <= 0x17FF)
    if o in (0x200C, 0x200D):
        for ch in (prev, nxt):
            if ch and ((ch.isalpha() and _in(ch, JOINING)) or _is_emoji_sym(ch) or _in(ch, JOINING)):
                return True
        return False
    return False


def _hold_space(text, i, c):
    if c not in "\u00a0\u202f":
        return False
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


_SPACEISH = re.compile(r"[^\x00-\x7f]")


def scrub_chars(text):
    """returns (cleaned_text, invisible_count, nonstandard_space_count, homoglyph_runs)"""
    if not _SPACEISH.search(text) and not re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", text):
        return text, 0, 0, 0
    has_rtl = any(_in(c, RTL) for c in text if ord(c) >= 0x0590)
    out = []
    inv = sp = 0
    for i, c in enumerate(text):
        if ord(c) < 0x80 and c not in "\x7f" and (ord(c) >= 0x20 or c in "\t\n\r"):
            out.append(c)
            continue
        if is_invisible(c):
            if _keep(text, i, c, has_rtl):
                out.append(c)
            else:
                inv += 1
            continue
        o = ord(c)
        if o in (0x2028, 0x2029, 0x85):
            out.append("\n")
            continue
        if unicodedata.category(c) == "Zs" and c != " ":
            if _hold_space(text, i, c):
                out.append(c)
            else:
                out.append(" ")
                sp += 1
            continue
        out.append(c)
    t = "".join(out)
    # homoglyph folding
    hg = 0
    if any(ch in LOOK for ch in t):
        def fold_tok(m):
            nonlocal hg
            tok = m.group(0)
            res = []
            pos = 0
            for r in re.finditer(r"[^\W\d_]+", tok):
                run = r.group(0)
                has_ascii = any(ch < "\x80" for ch in run)
                nonasc = [ch for ch in run if ch >= "\x80"]
                if has_ascii and nonasc and all(ch in LOOK for ch in nonasc):
                    res.append(tok[pos:r.start()])
                    res.append("".join(LOOK.get(ch, ch) for ch in run))
                    pos = r.end()
                    hg += 1
            res.append(tok[pos:])
            return "".join(res)
        t = re.sub(r"\S+", fold_tok, t)
    return t, inv, sp, hg


def clean_text(text):
    t, _, _, _ = scrub_chars(text)
    ended_lf = t.endswith("\n")
    t = re.sub(r"[ \t]+(?=\r?\n|\Z)", "", t)
    t = re.sub(r"\A(?:[ \t]*\r?\n)+", "", t)
    t = re.sub(r"\s+\Z", "", t)
    t = t.lstrip(" \t") if False else t
    if ended_lf and t:
        t += "\n"
    return t

# ---------------------------------------------------------------- masking

FENCE_OPEN = re.compile(r"^( {0,3})(`{3,}|~{3,})(.*)$")


def mask_text(text):
    lines = text.split("\n")
    n = len(lines)
    masked = [False] * n
    i = 0
    # front matter
    if lines and lines[0].rstrip() == "---":
        for j in range(1, n):
            if lines[j].rstrip() in ("---", "..."):
                for k in range(0, j + 1):
                    masked[k] = True
                i = j + 1
                break
    while i < n:
        m = FENCE_OPEN.match(lines[i])
        if m and not (m.group(2)[0] == "`" and "`" in m.group(3)):
            ch, ln = m.group(2)[0], len(m.group(2))
            masked[i] = True
            j = i + 1
            while j < n:
                masked[j] = True
                mm = re.match(r"^ {0,3}(" + re.escape(ch) + "{%d,})[ \t]*$" % ln, lines[j])
                if mm:
                    break
                j += 1
            i = j + 1
            continue
        i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not masked[i] and re.match(r"^ {0,3}>", lines[i]):
            j = i
            while j + 1 < n and not masked[j + 1] and re.match(r"^ {0,3}>", lines[j + 1]):
                j += 1
            if j > i:
                for k in range(i, j + 1):
                    masked[k] = True
            i = j + 1
        else:
            i += 1
    badge = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
    badge2 = re.compile(r"^\s*(?:!\[[^\]]*\]\([^)]*\)\s*)+$")
    for i, ln in enumerate(lines):
        if masked[i]:
            continue
        if re.match(r"^\s*\|.*\|\s*$", ln) or badge.match(ln) or badge2.match(ln):
            masked[i] = True
    res = [(" " * len(l) if masked[k] else l) for k, l in enumerate(lines)]
    t = "\n".join(res)
    t = re.sub(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", lambda m: " " * len(m.group(0)), t, flags=re.S)
    return t

# ---------------------------------------------------------------- patterns

def infl(w):
    w = w.lower()
    if w.endswith("e"):
        forms = [w, w + "s", w + "d", w[:-1] + "ing"]
    elif w.endswith("y"):
        forms = [w, w[:-1] + "ies", w[:-1] + "ied", w + "ing", w + "s", w + "ed"]
    else:
        forms = [w, w + "s", w + "es", w + "ed", w + "ing"]
    return "|".join(re.escape(f) for f in forms)


def words_re(words, extra=""):
    return r"\b(?:" + "|".join("(?:%s)" % infl(w) for w in words) + extra + r")\b"

AI1_WORDS = ("additionally,align with,crucial,delve,tapestry,pivotal,vibrant,meticulous,testament,underscore,intricate,intricacies,interplay,garner,bolster,foster,showcase,emphasize,enduring,enhance,leverage,utilize,facilitate,encompass,harness,holistic,paradigm,transformative,unprecedented,myriad,plethora,robust,seamless,navigate,embark,craft,landscape,journey,realm,multifaceted,elevate,empower,unlock").split(",")
AI1 = words_re([w for w in AI1_WORDS if w not in ("intricacies", "additionally", "align with")], r"|intricacies|additionally|aligns? with|aligned with|aligning with|capture[sd]? the (?:essence|spirit|imagination|heart|magic)|capturing the (?:essence|spirit|imagination|heart|magic)")

R = re.I
SPECS = []  # (num, slug, label, compiled, kind)


def P(num, slug, label, pat, flags=R, adv=False, cs=False):
    SPECS.append((num, slug, label, re.compile(pat, 0 if cs else flags), adv))

P(1, "ai_vocabulary", "AI vocabulary", AI1)
DIALECT = (r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)"
           r"|resonates? deeply|game[- ]chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioniz(?:e|es|ed|ing)|doubl(?:e|es|ed|ing) down on"
           r"|div(?:e|es|ed|ing) deep(?:er)? into|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)|tak(?:e|es|ing) [^.!?\n]{1,40}? to the next level)\b")
P(2, "model_dialect", "Model-dialect vocabulary", DIALECT)
PROMO = (r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|esteemed organization"
         r"|valuable asset|passion for excellence|proven track record|results-oriented|wealth of experience|dynamic team|fast-paced environment|deeply passionate|perfectly situated|(?:close|tight)-knit team"
         r"|i am excited to (?:apply|bring)|uniquely positioned to|leading (?:provider|company|platform|expert|authority))\b")
P(3, "promotional", "Promotional language", PROMO)
P(5, "simple_yet", "\u201cSimple yet X\u201d cliché", r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
SYN = [
    "protagonist|main character|central figure|hero|heroine", "company|firm|organization|enterprise|business",
    "author|writer|novelist|scribe", "report|study|analysis|investigation|examination",
    "technology|tool|system|platform|solution", "technique|method|approach|strategy|tactic",
    "challenge|obstacle|difficulty|hurdle|barrier", "benefit|advantage|upside|strength"]
P(10, "significance_inflation", "Significance inflation",
  r"\b(?:(?:stands?|stood|serves?|served|standing|serving) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)"
  r"|(?:underscor|highlight)(?:es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)"
  r"|reflects? a broader (?:trend|shift|pattern)|marks? a turning point|marks? a (?:milestone|watershed|new chapter|new era)|symboli[sz]es"
  r"|sets? the stage for|left an indelible mark|plays? an? (?:crucial|pivotal|vital|key|central|significant) role|has (?:shaped|sparked)|has come to (?:define|symbolize))\b")
P(11, "notability", "Notability name-dropping",
  r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+)(?:the\s+)?[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*(?:\s*,\s*(?:and\s+|or\s+)?(?:the\s+)?[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*|\s+and\s+(?:the\s+)?[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*)+"
  r"|\b\d[\d,.]*\s*[kKmM]?\+?\s+followers\b|\b(?:strong|active|robust|notable|significant)\s+(?:online|digital|social[- ]media)\s+presence\b|\bwidely covered\b|\bindependent coverage\b", flags=0)
P(12, "vague_attribution", "Vague attributions",
  r"\b(?:experts (?:argue|believe|say|claim|note|suggest)|industry (?:reports|observers|analysts)|observers have (?:cited|noted)|some critics argue|researchers have found|studies suggest|it is widely believed)\b")
P(13, "title_as_proper_noun", "Article title as proper noun",
  r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of [^.!?\n]{1,80}? is (?:a|an|the)\b", flags=0)
P(14, "ecosystem_padding", "Conservation / ecosystem padding",
  r"\b(?:plays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem|conservation efforts are (?:underway|ongoing|in place)|serves? as an indicator species|contributes? to biodiversity)\b")
P(15, "false_range", "False ranges",
  r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?]{0,150}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
P(16, "ing_tail", "Superficial -ing tail clauses",
  r",\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")
P(17, "negative_parallelism", "Negative parallelism", r"\bit['’]s not (?:just|merely) (?:about|an?)\b|\bnot only\b[^.!?]{0,40}?\bbut\b|\bdoesn['’]t just\b[^,.]{0,40}?\bit\b", adv=True)
P(17, "tailing_negation", "Tailing negation", r"(?<=[\w\)\]'’\"]), no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", adv=True)
P(18, "not_x_just_y", "\u201cNot X, just Y\u201d",
  r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+|\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+(?:\s+\w+){0,3}?\s*(?:,|—|–|--)\s*(?:it['’]s|it is|it was|they['’]re|they are|they were|that['’]s|but)\b")
P(19, "filler", "Filler phrases", r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to|it is important to note that|it should be mentioned that|needless to say)\b", adv=True)
P(20, "empty_pivot", "Empty pivot phrases",
  r"\b(?:it['’]s worth (?:noting|mentioning) that|it bears (?:noting|mentioning) that|one thing to (?:consider|keep in mind) is|it is interesting to note that|a key consideration is|a point to highlight is)")
P(21, "outcome_speculation", "Outcome-speculation tails",
  r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward)\b")
P(22, "authority_tropes", "Persuasive authority tropes",
  r"\b(?:here['’]s the thing|make no mistake|the truth is|let['’]s be honest|the simple fact is|at its core|what really matters|more than anything|at the end of the day|the bottom line is|in reality|the real question is|the heart of the matter|the deeper issue|when you get down to it|when all is said and done)\b|\bfundamentally,", adv=True)
P(23, "editorial", "Editorial interjections",
  r"\b(?:it['’]s|it is) important to (?:remember|note|understand|recognize)\b|\bone must note that\b|\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasized that\b")
P(24, "self_thoroughness", "Self-thoroughness phrases",
  r"\b(?:this comprehensive (?:guide|overview|analysis)|this in-depth (?:analysis|look|examination)|this complete (?:guide|overview)|a thorough examination of|everything you need to know about)\b")
P(25, "qa_rhetorical", "Question-answer rhetorical pattern",
  r"(?:^|[.!?]\s+|\n)(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|May|Might|Must|Has|Have|Had)\b[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)\s*[.!]", flags=0)
P(26, "concrete_evidence", "\u201cConcrete evidence\u201d defense phrase",
  r"\b(?:without concrete evidence|do you have concrete evidence|i (?:would )?need concrete (?:evidence|examples)|absent concrete proof|provide concrete evidence)\b")
P(27, "intro_hook", "Compulsive intro hooks",
  r"\bin today['’]s (?:\w+ ){0,2}(?:world|landscape|environment|market)\b|\bin a world where\b|\bin an era of\b|\bin recent years,|\bmore than ever before\b|\bwe live in a (?:time|world) when\b|\b(?:great|exciting|big) news\s*[!:]|\bever (?:wanted|wondered|dreamed|wished) to\b[^.!?]*\?|\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")
P(30, "diff_anchored", "Diff-anchored writing",
  r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b|\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b|\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b|\bpreviously\b[^.!?]*\bnow\b|\bwe(?:['’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b|\b(?:wasn['’]t|weren['’]t) there before\b")
P(31, "signposting", "Signposting and announcements",
  r"\blet['’]s (?:dive|delve|explore|break (?:this|it) down)\b|\bhere['’]s what you need to know\b|\bwithout further ado\b|\bnow let['’]s look at\b|\bbuckle up\b|\bstay with me\b|\b(?:are you )?ready to dive in\b")
P(32, "cataloguing", "Cataloguing lead-ins",
  r"\b(?:used|uses|employs|employed|relied on|utili[sz]es)\s+(?:several|various|a number of|multiple|different|many|numerous)\s+\w+|(?:^|[.!?]\s+)These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?(?:information|insights?|understanding|details|data)\b|\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b")
P(33, "inline_header_list", "Inline-header vertical lists", r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?(?:\*\*[^*\n]+?:\*\*|\*\*[^*\n]+?\*\*:)", flags=re.M)
P(36, "formulaic_challenges", "Formulaic challenges sections",
  r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|\bchallenges and (?:(?:future )?prospects|outlook|legacy)\b|\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b|\bfaces (?:several|many|numerous) challenges\b")
P(38, "compulsive_conclusion", "Compulsive conclusion phrases", r"^[ \t>*_#-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b", flags=re.I | re.M)
P(39, "generic_positive_conclusion", "Generic positive conclusions",
  r"\b(?:the future looks bright|exciting times lie ahead|journey toward excellence|step in the right direction|(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40}?)? (?:is|looks|remains) bright|well[- ]positioned for (?:whatever comes next|the future|the road ahead))\b")
P(47, "chatbot_artifacts", "Chatbot artifacts",
  r"\bi hope this helps\b|\bcertainly!|\bof course!|\blet me know if you\b|\bwould you like me to\b|\bfeel free to (?:ask|reach out)\b|\bhappy to help[.!]?(?:\s|$)|\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b|\bhere (?:are|is)(?:'s)? (?:a )?(?:few|some|two|three) (?:options|drafts|versions|variations)\b|\bhere['’]s (?:a )?(?:few|some|two|three) (?:options|drafts|versions|variations)\b|\bhere(?: is|['’]s) a draft\b|\bdepending on the (?:vibe|tone|style)\b|\bi hope (?:this email )?finds you well\b|\bas an (?:ai|llm|ai assistant|ai language model|large language model|language model)\b|\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b|\byour question (?:about|regarding|concerning)\b|\bas (?:you )?(?:requested|asked), here\b|\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b")
P(48, "sycophantic", "Sycophantic tone",
  r"\byou(?:['’]re| are) absolutely right\b|\b(?:great question|excellent point)\s*[!.,]|\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\s*[!.,]|\bthat['’]s an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\s*[!.,]")
P(50, "knowledge_cutoff", "Knowledge-cutoff disclaimers",
  r"\bas of my (?:last )?(?:training|knowledge)\b|\bup to my (?:last )?(?:training|knowledge)\b|\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b|\bbased on (?:the )?available information\b|\bas of my (?:knowledge )?cutoff\b|\b(?:maintains a low profile|keeps (?:his|her|their) personal life private)\b")
P(51, "copula_avoidance", "Copula avoidance",
  r"\b(?:serves as|stands as|functions as|acts as|represents (?:a|the)|marks (?:a|the)|boasts?|boasting|features (?:a|an|the|\d+|several|many|numerous|multiple|various|two|three|four|five|six|seven|eight|nine|ten)|offers an?|refers to)\b")
P(54, "hedge_stacking", "Hedge stacking", r"(?!)", adv=True)
P(56, "boldface", "Boldface overuse", r"\*\*[^*\n]+?\*\*")
P(57, "emoji", "Emojis", "[\U0001F300-\U0001FAFF\u2600-\u27BF\U0001F000-\U0001F2FF\u2B50\u2B55\u2705\u274C]")
P(58, "em_dash", "Em-dash overuse", r"(?!)", adv=True)
P(60, "curly_quotes", "Curly quotation marks", "[\u2018\u2019\u201c\u201d]", adv=True)
P(61, "hyphen_range", "Hyphen-for-en-dash in numeric ranges", r"\b(?:1\d{3}|20\d{2})-(?:1\d{3}|20\d{2})\b", adv=True)
P(63, "placeholder", "Placeholder text",
  r"(?i:\[(?:your|insert|add|enter|placeholder|todo|tbd|tk|(?:[^\]\n]{0,30}\b(?:name|company|client|place|source|person|city|date)\b))[^\]\n]{0,60}\])(?![(\[])|\[(?=[^\]\n]*[A-Z])[A-Z][A-Z0-9 _/'-]{2,40}\](?![(\[])|\{\{[^}\n]{1,60}\}\}|\b[xX]{3,}\b|\blorem ipsum\b", flags=0)
P(64, "chat_markup", "Chatbot reference markup", r"\bcite(?:turn|start|nav)\w*|\boai_citation\b|\bcontentReference\b|\bnavlist\b|【\d+†[^】]*】", flags=0)
P(65, "ai_tracking_params", "AI tracking parameters", r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![\w-])(?!\.[A-Za-z0-9])", flags=re.I)
P(69, "marketing_slop", "Canonical marketing-slop phrases",
  r"\b(?:unlocking (?:its |their |your |the )?full potential|navigating the complexities|a testament to the (?:power|importance)|staying ahead of the curve|turning challenges into opportunities|taking [^.!?\n]{1,30}? to the next level|harnessing the power of|paving the way for|saying goodbye to|imagining a world where)\b")
P(4, "hyphenated_pairs", "Hyphenated word-pair overuse",
  r"\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|data-driven|forward-thinking|detail-oriented|customer-centric|game-changing|ground-breaking|well-rounded|high-quality|user-friendly|end-to-end|mission-critical|next-generation|industry-leading|award-winning|top-notch|cross-functional|full-service|one-stop|tech-savvy|thought-provoking|far-reaching|ever-evolving|fast-growing|high-impact|high-performance|time-saving|cost-effective|best-of-breed|value-added|deeply-rooted|world-renowned|time-tested|ever-changing|results-focused|client-focused)\b", adv=True)

TRANS_RE = re.compile(r"(?:^|[.!?][\"')\]]*[ \t]+|\n[ \t]*)(Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b")
HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?(?: to| like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
SHORT_SET = set(list(range(1, 40)) + [47, 48, 49, 50, 51, 69])
WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")
SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]]*\s+(?=[\"'(\[]?[A-Z0-9])")
RHYTHM = {40, 44}


def sentences(text):
    out = []
    for para in re.split(r"\n\s*\n", text):
        para = " ".join(l for l in para.split("\n") if not re.match(r"^\s*(?:#{1,6}\s|[-*+]\s|\d+[.)]\s)", l))
        para = para.strip()
        if not para:
            continue
        for s in SENT_SPLIT.split(para):
            if WORD_RE.search(s):
                out.append(s.strip())
    return out


def paragraphs(text):
    return [p for p in re.split(r"\n\s*\n", text) if p.strip()]


def wc(s):
    return len(WORD_RE.findall(s))


def cv(vals):
    m = sum(vals) / len(vals)
    if m == 0:
        return 99
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / m


def excerpt(raw, s, e):
    a, b = max(0, s - 40), min(len(raw), e + 40)
    t = raw[a:b].replace("\n", " ")
    t = re.sub(r"\s+", " ", t) if False else t
    return ("..." if a > 0 else "") + t + ("..." if b < len(raw) else "")


def scan(window, want_findings=True):
    """window: text (CRLF normalized). returns dict of findings: key -> (label,count,samples,num,adv)"""
    raw = window
    _, inv, sp, hg = scrub_chars(raw)
    m = mask_text(raw)
    F = {}

    def add(num, slug, label, count, samples, adv):
        if count > 0:
            F["%d_%s" % (num, slug)] = {"label": label, "count": count, "samples": samples[:3], "_num": num, "_adv": adv}

    for num, slug, label, rx, adv in SPECS:
        ms = list(rx.finditer(m))
        if num == 2 and len(ms) < 2:
            continue
        if not ms:
            continue
        if num == 1:
            samples = [excerpt(raw, x.start(), x.end()) for x in ms[:3]]
        else:
            samples = [re.sub(r"\s+", " ", x.group(0)).strip()[:80] for x in ms[:3]]
        add(num, slug, label, len(ms), samples, adv)
    # 3: imperative sentences
    imp = re.compile(r"(?:^|[.!?]\s+|\n)\s*(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b", re.I)
    ims = imp.findall(m)
    if len(ims) >= 3:
        k = "3_promotional"
        if k in F:
            F[k]["count"] += len(ims)
        else:
            add(3, "promotional", "Promotional language", len(ims), [x.strip() for x in ims[:3]], False)
    # 6 stacked adjectives
    adjs = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$")
    stock = {"innovative", "powerful", "seamless", "robust", "dynamic", "cutting-edge", "scalable", "intuitive", "sleek", "modern", "elegant", "reliable", "flexible", "efficient", "comprehensive", "vibrant", "stunning", "beautiful", "exciting", "unique", "versatile", "secure", "fast", "lightweight", "simple", "clean", "rich", "bold"}
    c6, s6 = 0, []
    for x in re.finditer(r"\b[A-Za-z][A-Za-z-]*(?:,\s+[A-Za-z][A-Za-z-]*){2,}(?:,?\s+and\s+[A-Za-z][A-Za-z-]*)?(?:\s+[A-Za-z]+)?", m):
        items = [w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]*", x.group(0)) if w.lower() != "and"]
        if len(items) >= 4 and any(adjs.search(w) or w in stock for w in items[:-1] + items[-1:]) and sum(1 for w in items if adjs.search(w) or w in stock) >= 2:
            c6 += 1
            s6.append(x.group(0)[:80])
    add(6, "stacked_adjectives", "Stacked adjective chains", c6, s6, False)
    # 8 synonym cycling
    lw = re.findall(r"[a-z][a-z-]*(?: [a-z]+)?", m.lower())
    low = m.lower()
    c8, s8 = 0, []
    for cl in SYN:
        found = set()
        tot = 0
        for mem in cl.split("|"):
            n = len(re.findall(r"\b" + re.escape(mem) + r"(?:s|es|ies)?\b", low)) if not mem.endswith("y") else len(re.findall(r"\b(?:" + re.escape(mem) + r"|" + re.escape(mem[:-1]) + r"ies)\b", low))
            if n:
                found.add(mem)
                tot += n
        if len(found) >= 3:
            c8 += tot
            s8.append("/".join(sorted(found)))
    add(8, "synonym_cycling", "Synonym cycling", c8, s8, False)
    # text-structure
    paras = paragraphs(m)
    # 37 transitions
    c37, s37 = 0, []
    for p in paras:
        ts = TRANS_RE.findall(p)
        if len(ts) >= 2:
            c37 += len(ts)
            s37.append(", ".join(ts[:3]))
    add(37, "transition_clusters", "Transition cluster overuse", c37, s37, False)
    # 54 hedges, 58 em dash, 42 opener repetition
    c54 = 0
    for s in sentences(m):
        if len(HEDGE_RE.findall(s)) >= 2:
            c54 += 1
    add(54, "hedge_stacking", "Hedge stacking", c54, [], True)
    c58 = sum(1 for p in paras if p.count("\u2014") >= 2)
    add(58, "em_dash", "Em-dash overuse", c58, [], True)
    c42 = 0
    for p in paras:
        ss = sentences(p)
        if len(ss) >= 3:
            opens = {}
            for s in ss:
                w = [x.lower() for x in WORD_RE.findall(s)[:2]]
                if len(w) == 2:
                    opens[tuple(w)] = opens.get(tuple(w), 0) + 1
            if any(v >= 3 for v in opens.values()):
                c42 += 1
    add(42, "opener_repetition", "Opener repetition", c42, [], True)
    # sentence rhythm
    sents = sentences(m)
    lens = [wc(s) for s in sents]
    if len(lens) >= 3 and cv(lens) < 0.35:
        add(40, "sentence_monotony", "Sentence-length monotony", 1, ["%d sentences, similar length" % len(lens)], False)
    # 41
    run, best = 0, 0
    for i in range(2, len(lens)):
        d1, d2 = lens[i - 1] - lens[i - 2], lens[i] - lens[i - 1]
        if abs(d1) >= 5 and abs(d2) >= 5 and (d1 > 0) != (d2 > 0):
            run = run + 1 if run else 2
        else:
            run = 0
        best = max(best, run)
    # run counts sentences alternating
    if best >= 6:
        add(41, "length_alternation", "Mechanical sentence-length alternation", 1, [], True)
    # 44
    body = [p for p in paras if not re.match(r"\s*#", p)]
    pl = [wc(p) for p in body if wc(p)]
    if len(pl) >= 4 and cv(pl) < 0.4:
        add(44, "uniform_paragraphs", "Uniform paragraph length", 1, [], False)
    # 46
    nwords = wc(m)
    if nwords >= 300 and ";" not in m and m.count("(") <= 1:
        add(46, "semicolon_underuse", "Semicolon and parenthesis underuse", 1, [], True)
    # 55
    toks = [w.lower() for w in WORD_RE.findall(m)]
    fp = sum(1 for w in toks if w in ("i", "me", "my", "we", "our", "us", "i'm", "i’m", "i've", "we're"))
    if toks and fp / len(toks) >= 0.02 and fp >= 3:
        full = len(re.findall(r"\b(?:do|does|did|is|are|was|were|have|has|had|can|will|would|could|should) not\b|\bcannot\b|\bI (?:am|have|will|would)\b|\b(?:it|that|there) is\b|\b(?:they|we|you) are\b|\blet us\b", m, re.I))
        con = len(re.findall(r"\w['’](?:t|s|re|ve|ll|d|m)\b", m))
        if full >= 3 and full > 0.6 * (full + con):
            add(55, "contraction_absence", "Contraction absence", full, [], True)
    # 34 bullet injection
    if not re.search(r"^#{1,6}\s", m, re.M):
        listp = prose = 0
        for p in paras:
            ls = [l for l in p.split("\n") if l.strip()]
            if ls and all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", l) for l in ls):
                listp += 1
            else:
                prose += 1
        if listp >= 1 and prose >= 2:
            add(34, "bullet_injection", "Mid-essay bullet injection", listp, [], False)
    # 35 fragmented headers
    lines = m.split("\n")
    c35 = 0
    for i, l in enumerate(lines):
        hm = re.match(r"^#{1,6}\s+(.+?)\s*#*\s*$", l)
        if hm:
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines):
                nl = lines[j].strip()
                if not re.match(r"^(#|[-*+]\s|\d+[.)]\s|\|)", nl) and 0 < wc(nl) <= 4:
                    hw = {w.lower() for w in re.findall(r"[A-Za-z]{3,}", hm.group(1))}
                    if any(w.lower() in hw for w in re.findall(r"[A-Za-z]{3,}", nl)):
                        c35 += 1
    add(35, "fragmented_headers", "Fragmented headers", c35, [], False)
    # 59 title case
    small = {"a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "of", "in", "on", "at", "to", "by", "up", "as", "off", "per", "via", "is", "from", "with", "into", "over"}
    c59 = 0
    for l in lines:
        hm = re.match(r"^#{1,6}\s+(.+?)\s*#*\s*$", l)
        if not hm:
            continue
        h = hm.group(1)
        ws = re.findall(r"[^\s]+", h)
        if len(ws) < 3 or not h[0].isalpha() or h.isupper():
            continue
        major = [w for w in ws if w.lower().strip(".,:;!?") not in small]
        if len(major) >= 2 and all(w[0].isupper() for w in major if w[0].isalpha()):
            c59 += 1
    add(59, "title_case_headings", "Title case in headings", c59, [], False)
    # 70
    hr = len(re.findall(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,}|(?:\*[ \t]+){2,}\*|(?:-[ \t]+){2,}-)[ \t]*$", m, re.M))
    nonempty = sum(1 for l in lines if l.strip())
    if hr >= 3 and len(lines) >= 24:
        add(70, "horizontal_rules", "Decorative horizontal rules", hr, [], False)
    # 71
    if len(toks) >= 12:
        grams = {}
        for i in range(len(toks) - 5):
            g = tuple(toks[i:i + 6])
            grams[g] = grams.get(g, 0) + 1
        total = len(toks) - 5
        rep = sum(v for v in grams.values() if v > 1)
        if total > 0 and rep / total >= 0.2:
            add(71, "degenerate_repetition", "Degenerate repetition", rep, [], False)
    # 68 trailing whitespace
    c68 = len(re.findall(r"[ \t]+$", raw, re.M))
    if raw and raw[0].isspace():
        c68 += 1
    if re.search(r"\n\n+\s*\Z", raw) or re.search(r"[ \t]\Z", raw):
        c68 += 1
    add(68, "trailing_whitespace", "Trailing / stray whitespace", c68, [], True)
    # character layer
    add(62, "invisible_chars", "Invisible / zero-width characters", inv, ["%d invisible character(s)" % inv], False)
    add(66, "homoglyphs", "Homoglyph / mixed-script confusables", hg, ["%d mixed-script token(s)" % hg], False)
    add(67, "nonstandard_spaces", "Non-standard spaces", sp, ["%d non-standard space(s)" % sp], False)
    return F, inv, sp, hg, nwords


def compute_score(F, nwords):
    sm = {k: v for k, v in F.items() if not v["_adv"]}
    nums = {v["_num"] for v in sm.values()}
    base = 0
    for k, v in sm.items():
        c = v["count"]
        if v["_num"] in DECISIVE:
            base += 22 + min(c - 1, 3) * 3
        elif v["_num"] in RHYTHM:
            base += 8
        else:
            base += 12 + min(c - 1, 3) * 2
    nf = len(nums)
    if nwords < 40:
        conf = "none"
    elif nwords < 120:
        conf = "low"
    elif nwords < 300:
        conf = "low" if nf == 1 else "moderate"
    else:
        conf = "high"
    score = min(100, int(round(base)))
    dec = nums & DECISIVE
    if nf == 1:
        score = min(score, 40)
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf not in ("none", "low"):
        score = max(score, 45)
    if nwords < 120:
        k = len(nums & SHORT_SET)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    elif nwords >= 400:
        if nf >= 6:
            score = max(score, 45)
        elif nf >= 5:
            score = max(score, 25)
    if nums and nums <= RHYTHM:
        score = min(score, 40)
    if nums == {40}:
        score = min(score, 20)
    score = max(0, min(100, score))
    return score, conf, nf


def conf_reason(conf, nwords, nf):
    if conf == "none":
        return "fewer than 40 words; too short to score reliably"
    if conf == "low":
        if nwords < 120:
            return "fewer than 120 words; the score is a rough indication"
        return "fewer than 300 words and only one score-moving pattern family fired"
    if conf == "moderate":
        return "fewer than 300 words; more text would make the score steadier"
    return ""


def build_report(prose, ci=False):
    truncated = len(prose) > WINDOW
    window = prose[:WINDOW]
    window = window.replace("\r\n", "\n")
    F, inv, sp, hg, nwords = scan(window)
    score, conf, nf = compute_score(F, nwords)
    rep = {}
    for k in sorted(F, key=lambda k: (F[k]["_num"], k)):
        v = F[k]
        rep[k] = {"label": v["label"], "count": v["count"], "samples": v["samples"]}
    met = {
        "scanned_chars": len(prose[:WINDOW]), "truncated": truncated, "ai_tell_score": score,
        "ai_tell_band": band_of(score), "confidence": conf, "confidence_reason": conf_reason(conf, nwords, nf),
        "patterns_flagged": len(rep), "invisible_chars": inv, "nonstandard_spaces": sp, "homoglyphs": hg,
        "words": nwords, "score_moving_families": nf,
    }
    if ci:
        sents = sentences(mask_text(window))
        if len(sents) >= 4:
            rnd = random.Random(20240601)
            reps = 30 if len(window) < 20000 else 6
            scores = []
            for _ in range(reps):
                pick = [sents[rnd.randrange(len(sents))] for _ in sents]
                t = "\n\n".join(pick) if False else " ".join(pick)
                F2, _a, _b, _c, nw2 = scan(t)
                scores.append(compute_score(F2, nw2)[0])
            scores.sort()
            lo = scores[int(0.05 * (len(scores) - 1))]
            hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
            met["score_ci"] = [min(lo, score), max(hi, score)]
            met["score_ci_note"] = "bootstrap interval over resampled sentences; the point score is unchanged"
        else:
            met["score_ci"] = None
            met["score_ci_note"] = "too few sentences for an interval (need at least four)"
    rep["_metrics"] = met
    return rep

# ---------------------------------------------------------------- main

def err(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    return code


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
    clean = ci = False
    ops = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            ops.extend(argv[i + 1:])
            break
        if a in ("--help", "-h"):
            sys.stdout.write(USAGE)
            return 0
        if a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-") and a != "-":
            return err("unknown option: %s (see --help)" % a, 2)
        else:
            ops.append(a)
        i += 1
    try:
        if ops:
            if len(ops) > 1:
                sys.stderr.write("prosecheck: only the first file was scanned: %s\n" % ops[0])
            try:
                prose = extract(ops[0])
            except Fail as f:
                return err(f.msg, f.code)
            except Exception as e:
                return err("cannot read input: %s" % (getattr(e, "strerror", None) or e.__class__.__name__), 1)
        else:
            prose = decode_bytes(sys.stdin.buffer.read())
        if prose.startswith("\ufeff"):
            prose = prose[1:]
        if not prose.strip():
            return err("empty input", 1)
        if clean:
            sys.stdout.write(clean_text(prose))
            return 0
        rep = build_report(prose, ci)
        sys.stdout.write(json.dumps(rep, ensure_ascii=False, indent=1) + "\n")
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:  # never a traceback
        return err("cannot read input: %s" % e.__class__.__name__, 1)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
