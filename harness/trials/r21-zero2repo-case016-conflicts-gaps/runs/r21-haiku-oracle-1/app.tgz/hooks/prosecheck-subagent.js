'use strict';
// subagent-start entry. Returns the writing contract for the stored level inside the
// JSON envelope the host keeps for a subagent-start event. Off prints nothing.
// Always exits 0.

const core = require('./lib/prosecheck-core.js');

function main() {
  core.readPayload();
  const level = core.effectiveLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.liveContract(level),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // a hook must never fail the host session
}
process.exitCode = 0;
