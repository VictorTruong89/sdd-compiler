'use strict';
// stats entry: token totals from the session transcript and, when there is enough
// assistant prose, a score of that prose. Standard library only; no network.
// Run directly, it reads the host prompt-submit JSON on standard input and answers
// a "/prosecheck stats" prompt with a block decision. The tracker also calls statsReply.

const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

// spec: N-001103–N-001121 — read the named transcript, else the newest under projects.
function newestTranscript(dir) {
  const projects = path.join(dir, 'projects');
  let best = null;
  function walk(d, depth) {
    if (depth > 4) return;
    let entries;
    try {
      entries = fs.readdirSync(d, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(d, ent.name);
      if (ent.isDirectory()) {
        walk(full, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime };
        } catch (e) {
          // skip
        }
      }
    }
  }
  walk(projects, 0);
  return best ? best.file : null;
}

function readTranscript(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    const t = line.trim();
    if (!t) continue;
    let entry;
    try {
      entry = JSON.parse(t);
    } catch (e) {
      continue;
    }
    if (!entry || entry.type !== 'assistant' || !entry.message || typeof entry.message !== 'object') {
      continue;
    }
    const msg = entry.message;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const key = typeof msg.id === 'string' && msg.id ? msg.id : 'anon-' + (anon++);
    byId.set(key, {
      output: Number(usage.output_tokens) || 0,
      cache: Number(usage.cache_read_input_tokens) || 0,
    });
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  }
  let output = 0;
  let cache = 0;
  for (const v of byId.values()) {
    output += v.output;
    cache += v.cache;
  }
  return { turns: byId.size, output, cache, prose: texts.join('\n') };
}

function proseScore(prose) {
  let text = prose.replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '');
  text = text.slice(-core.STATS_TEXT_TAIL);
  const trimmed = text.trim();
  if (trimmed.length <= core.STATS_MIN_PROSE) return null;
  const res = core.runDetector(['--'], { input: trimmed, timeout: core.PLAIN_TIMEOUT_MS });
  const report = core.parseReport(res.stdout || '');
  return report ? report._metrics.ai_tell_score : null;
}

// Reply text for "/prosecheck stats". transcriptPath may be empty.
function statsReply(transcriptPath, level, dir) {
  const cfg = dir || core.configDir();
  let file = transcriptPath && String(transcriptPath).trim() ? String(transcriptPath).trim() : null;
  if (!file) file = newestTranscript(cfg);
  const data = file ? readTranscript(file) : null;
  if (!data) {
    return 'prosecheck stats: could not read a session transcript' +
      (file ? ' at ' + file : '') + '. level: ' + level;
  }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.output,
    'cache-read input tokens: ' + data.cache,
  ];
  const score = proseScore(data.prose);
  if (score !== null) lines.push('session prose ai_tell_score: ' + score);
  return lines.join('\n');
}

module.exports = { statsReply, readTranscript, newestTranscript };

if (require.main === module) {
  try {
    const payload = core.readPayload();
    const prompt = String(payload.prompt || '').trim();
    if (/^\/prosecheck(?::prosecheck)?\s+stats$/i.test(prompt)) {
      const level = core.effectiveLevel();
      const reply = statsReply(payload.transcript_path, level);
      process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
    }
  } catch (e) {
    // a hook must never fail the host session
  }
  process.exitCode = 0;
}
