'use strict';
// prompt-submit entry and the /prosecheck command router.
// Reads host JSON on standard input. Command prompts get a block decision whose
// reason is the reply; ordinary prompts get the live-level reminder. Always exits 0.

const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');
const { statsReply } = require('./prosecheck-stats.js');

function emitBlock(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reason }) + '\n');
}

function emitContext(text) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: text },
  }) + '\n');
}

// spec: N-000909–N-000934 — help lists every subcommand with its words.
function helpReply(level, form) {
  const f = '/prosecheck';
  return [
    'prosecheck level: ' + level,
    'Code, commits, configuration, and chat are never touched; only prose deliverables follow the writing contract.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
    f + ' lite         Writing contract only, with no saved-file scoring.',
    f + ' full         Contract plus the saved-file guard, threshold 40 (default).',
    f + ' strict       Contract plus the saved-file guard, threshold 20, and a cleanup scrub.',
    f + ' off | on     off: disable the tool; on: re-enable it at full.',
    f + ' status       Show the stored level in one line.',
    f + ' show         List the files scored in this session, newest first.',
    f + ' check <file> Score one file; report only, it does not rewrite the file.',
    f + ' doctor       Health check of the install.',
    f + ' stats        Session token totals and the score of the session prose.',
    f + ' init         Write the contract to ./AGENTS.md for agents other than Claude Code.',
    'Bare ' + f + ' also shows this list.',
  ].join('\n');
}

function doctorReply(form, dir) {
  const level = core.effectiveLevel(dir);
  const root = core.pluginRoot();
  const det = core.detectorPath(root);
  const lines = [];
  lines.push('prosecheck doctor');
  // mode line (never mentions the detector, python, or settings)
  if (level === 'off') {
    lines.push('mode: off; saved files are not scored. Run /prosecheck on to turn the tool back on.');
  } else {
    lines.push('mode: ' + level + ' [OK]');
  }
  // detector line (never mentions python)
  if (det) {
    lines.push('detector: bundled detector found [OK]');
  } else {
    lines.push('detector: bundled detector not found under the plugin root');
  }
  // python line (the only line that names python): run the bundled scorer on a sample
  const probe = core.runDetector([], {
    input: 'This is a short sample sentence for the health check of the bundled scorer. It has two sentences.',
    timeout: 8000,
  });
  let pythonOk = false;
  if (probe.launchFailed) {
    lines.push('python: python not found; the writing contract still applies to new prose, but saved files are not re-scored until python is available');
  } else {
    pythonOk = !!core.parseReport(probe.stdout || '');
    lines.push(pythonOk
      ? 'python: ran the bundled scorer and got a numeric score [OK]'
      : 'python: the bundled scorer returned no numeric score');
  }
  // settings line (never mentions python)
  const writable = core.settingsWritable(dir || core.configDir());
  lines.push(writable ? 'settings: the settings folder is writable [OK]' : 'settings: the settings folder is not writable');

  const modeOk = level !== 'off';
  const detOk = !!det;
  const pyOk = pythonOk;
  const setOk = writable;
  const others = detOk && pyOk && setOk;
  let closer;
  if (modeOk && others) {
    closer = 'Everything is in order and the tool is active. Files up to 512 KB (plain text) or 4 MB (archives and notebooks) are scored on their first 262,144 characters. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (!others) {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  } else {
    closer = 'Saved files are not scored while the tool is off. Run ' + form + ' on to turn scoring back on.';
  }
  return ['', ...lines, closer].join('\n');
}

function unitBase(file) {
  return path.basename(file);
}

function checkReply(argText, cwd, form) {
  const raw = core.cleanPathArg(argText);
  if (!raw) {
    return 'usage: ' + form + ' check <path>. This scores one file and is report only; the file is not changed.';
  }
  const abs = path.resolve(cwd || process.cwd(), raw);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + raw + ': the file does not exist or is not readable.';
  }
  if (st.isDirectory() || !st.isFile()) {
    return raw + ' is not a file.';
  }
  const base = unitBase(abs);
  const ext = path.extname(abs).toLowerCase();
  if (core.BINARY_EXTS.has(ext)) {
    return base + ': no readable text in this format.';
  }
  if (core.ARCHIVE_EXTS.has(ext) && st.size > core.ARCHIVE_CAP_BYTES) {
    return base + ': over ' + core.ARCHIVE_CAP_KB + ' KB, the archive limit.';
  }
  if (!core.ARCHIVE_EXTS.has(ext) && st.size > core.PLAIN_CAP_BYTES) {
    return base + ': over ' + core.PLAIN_CAP_KB + ' KB, the plain-text limit.';
  }
  const result = core.scoreFile(abs, ext);
  if (result.kind === 'failed') {
    if (result.code === 'launch') return base + ': detector unavailable.';
    if (result.exitOk && result.code === 'silent') return base + ': no report.';
    if (result.exitOk && (result.code === 'notreport' || result.code === 'nonnumeric')) {
      return 'no report: the detector printed something other than a report.';
    }
    const detail = result.code === 'timeout' ? 'the detector timed out' : (result.errorText || result.reason);
    return base + ': failed (' + detail + ').';
  }
  const rep = result.report;
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + m.ai_tell_hook_phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + core.WINDOW_TEXT + ' characters only');
  const labels = Object.keys(rep).filter((k) => k !== '_metrics').map((k) => ({
    label: rep[k].label, count: rep[k].count,
  }));
  if (labels.length) {
    const shown = labels.slice(0, core.CHECK_LABEL_CAP).map((x) => x.label + ' (x' + x.count + ')');
    lines.push('tells: ' + shown.join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function showReply(sessionId, form, dir) {
  const cfg = dir || core.configDir();
  const file = core.ledgerFile(sessionId, cfg);
  const rows = core.readLedger(file).slice().reverse();
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files in this session, newest first:'];
  for (const r of rows) {
    const base = r.base || '(unnamed)';
    let body;
    if (r.kind === 'scored') {
      body = r.phrase + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '') + ')';
      if (r.labels && r.labels.length) {
        const state = r.flagged ? 'flagged' : 'under threshold';
        body += ' - ' + state + ': ' + r.labels.slice(0, core.SHOW_LABEL_CAP).join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: file is over the ' + r.capKb + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'not re-scored: this binary format has no readable prose';
    } else {
      body = 'not scored: ' + (r.reason || 'unknown reason');
    }
    lines.push(base + ' - ' + body);
  }
  return lines.join('\n');
}

function initReply(form, cwd, dir) {
  const level = core.effectiveLevel(dir);
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const root = cwd || process.cwd();
  const out = [];
  const agents = path.join(root, 'AGENTS.md');
  let existing = null;
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readable = false;
  }
  if (!readable) {
    out.push('cannot read AGENTS.md; the contract was not written there.');
  } else if (existing !== null && (existing.indexOf(core.CONTRACT_START) !== -1 ||
      existing.indexOf(core.CONTRACT_FIRST_LINE) !== -1)) {
    out.push('AGENTS.md already contains the writing contract; left unchanged.');
  } else {
    try {
      const block = core.exportBlock(level);
      const sep = existing && existing.length && !existing.endsWith('\n') ? '\n\n' : (existing ? '\n' : '');
      fs.writeFileSync(agents, (existing || '') + sep + block, 'utf8');
      out.push('Wrote the writing contract to AGENTS.md.');
    } catch (e) {
      out.push('cannot write AGENTS.md; the contract was not written there.');
    }
  }
  const ruleDst = path.join(root, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDst)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; left unchanged.');
  } else {
    const ruleSrc = path.join(core.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    let body = null;
    try {
      body = fs.readFileSync(ruleSrc, 'utf8');
    } catch (e) {
      out.push('cannot read the shipped Cursor rule.');
    }
    if (body !== null) {
      try {
        fs.mkdirSync(path.dirname(ruleDst), { recursive: true });
        fs.writeFileSync(ruleDst, body, 'utf8');
        out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
      } catch (e) {
        out.push('cannot write .cursor/rules/prosecheck.mdc.');
      }
    }
  }
  return out.join('\n');
}

function setLevel(level, dir) {
  try {
    core.writeLevel(level, dir);
    return true;
  } catch (e) {
    return false;
  }
}

// Routes one prompt. Returns the reply text, or null when the prompt is not a command.
function route(prompt, payload, dir) {
  const cfg = dir || core.configDir();
  const text = String(prompt || '').trim();
  const lower = text.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    if (!setLevel('off', cfg)) return 'prosecheck could not store the off level.';
    return 'prosecheck is off. Saved files are not scored until you run /prosecheck on.';
  }
  const m = text.match(/^\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/i);
  if (!m) return null;
  const form = core.prefixOf(text);
  const rest = m[1].trim();
  const sp = rest.search(/\s/);
  const sub = (sp === -1 ? rest : rest.slice(0, sp)).toLowerCase();
  const arg = sp === -1 ? '' : rest.slice(sp + 1).trim();
  if (!sub || sub === 'help') return helpReply(core.effectiveLevel(cfg), form);
  if (!core.SUBCOMMANDS.includes(sub)) {
    return 'unknown subcommand: ' + (sp === -1 ? rest : sub) + '. Valid subcommands: ' +
      core.SUBCOMMANDS.join(', ') + '. The stored level is unchanged.';
  }
  switch (sub) {
    case 'lite':
    case 'full':
    case 'strict':
    case 'off':
      if (!setLevel(sub, cfg)) return 'prosecheck could not store the ' + sub + ' level.';
      if (sub === 'off') return 'prosecheck level set to off. Saved files are not scored until you run ' + form + ' on.';
      if (sub === 'lite') return 'prosecheck level set to lite: the writing contract is on and saved files are not scored.';
      if (sub === 'full') return 'prosecheck level set to full: the writing contract is on and the saved-file guard uses threshold 40.';
      return 'prosecheck level set to strict: the writing contract is on, the saved-file guard uses threshold 20, and cleanup scrub applies.';
    case 'on':
      if (!setLevel('full', cfg)) return 'prosecheck could not store the full level.';
      return 'prosecheck is on at level full (re-enabled).';
    case 'status':
      return 'prosecheck level: ' + core.effectiveLevel(cfg);
    case 'show':
      return showReply(payload.session_id, form, cfg);
    case 'check':
      return checkReply(arg, payload.cwd, form);
    case 'doctor':
      return doctorReply(form, cfg);
    case 'stats':
      return statsReply(payload.transcript_path, core.effectiveLevel(cfg), cfg);
    case 'init':
      return initReply(form, payload.cwd, cfg);
    default:
      return helpReply(core.effectiveLevel(cfg), form);
  }
}

function main() {
  const payload = core.readPayload();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const reply = route(prompt, payload);
  if (reply !== null) {
    if (/^\s*\/prosecheck/i.test(prompt) || /^\s*stop prosecheck\s*$/i.test(prompt) ||
        /^\s*prosecheck off\s*$/i.test(prompt)) {
      emitBlock(reply);
    }
    return;
  }
  // ordinary prompt: live-level reminder unless the level is off
  const level = core.effectiveLevel();
  if (level === 'off') return;
  emitContext('prosecheck is ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.');
}

module.exports = { route, helpReply, doctorReply, checkReply, showReply, initReply };

if (require.main === module) {
  try {
    main();
  } catch (e) {
    // a hook must never fail the host session
  }
  process.exitCode = 0;
}
