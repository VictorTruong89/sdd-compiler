'use strict';
// session-start entry. Prints the welcome (first start only) and the writing contract
// for the stored level as plain text. Off prints nothing. Always exits 0.

const fs = require('fs');
const core = require('./lib/prosecheck-core.js');

function main() {
  core.readPayload();
  const dir = core.configDir();
  const hadFlag = fs.existsSync(core.flagFile(dir));
  core.pruneLedgers(dir);
  const level = core.effectiveLevel(dir);
  if (!hadFlag) {
    // first start of a fresh install: store the effective level so later hooks see it
    try {
      core.writeLevel(level, dir);
    } catch (e) {
      // settings folder not writable: the level still applies for this session
    }
  }
  if (level === 'off') return;
  const parts = [];
  if (!hadFlag) parts.push(core.welcomeText());
  parts.push(core.liveContract(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (e) {
  // a hook must never fail the host session
}
process.exitCode = 0;
