'use strict';
// post-tool-use entry: the saved-file guard. After Write, Edit, MultiEdit, NotebookEdit or
// apply_patch saves a prose file, scores it and, when the score is above the threshold,
// returns a nudge naming the file. Always exits 0.

const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

const PATCH_LINE = /^\*\*\*\s(?:Add File|Update File|Move to):(.*)$/gm;
const INSTRUCTION_BASENAME = new Set(core.INSTRUCTION_NAMES);

// spec: N-000395–N-000401 — paths named by the payload.
function pathsFromPayload(payload) {
  const tool = String(payload.tool_name || '');
  const input = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const out = [];
  if (tool === 'apply_patch' || typeof input.command === 'string' && /^\*\*\*\s/m.test(input.command)) {
    const body = typeof input.command === 'string' ? input.command : (typeof input.input === 'string' ? input.input : '');
    let m;
    PATCH_LINE.lastIndex = 0;
    while ((m = PATCH_LINE.exec(body)) !== null) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
    return out;
  }
  if (tool === 'NotebookEdit') {
    const p = input.notebook_path || input.file_path;
    if (typeof p === 'string' && p.trim()) out.push(p.trim());
    return out;
  }
  if (typeof input.file_path === 'string' && input.file_path.trim()) out.push(input.file_path.trim());
  return out;
}

function isSkipped(abs, pluginDir) {
  const parts = abs.split(path.sep);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  if (pluginDir && (abs === pluginDir || abs.startsWith(pluginDir + path.sep))) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTRUCTION_BASENAME.has(base)) return true;
  const ext = path.extname(base);
  const stem = base.slice(0, base.length - ext.length);
  if (core.INSTRUCTION_STEMS.has(stem) && !core.PROSE_EXTS.has(ext)) return true;
  return false;
}

function main() {
  const payload = core.readPayload();
  const level = core.effectiveLevel();
  if (level === 'off' || level === 'lite') return;
  const threshold = core.THRESHOLDS[level];
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const sessionId = payload.session_id;
  const pluginDir = path.resolve(core.pluginRoot());

  const seen = new Set();
  const lines = [];
  for (const raw of pathsFromPayload(payload)) {
    if (seen.size >= core.SCORED_PATHS_CAP) break;
    const abs = path.resolve(cwd, raw);
    if (seen.has(abs)) continue;
    seen.add(abs);
    if (isSkipped(abs, pluginDir)) continue;
    let st;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      core.appendLedger(sessionId, { base: path.basename(abs), kind: 'failed', reason: 'cannot read the file' });
      continue;
    }
    if (!st.isFile()) continue;
    const ext = path.extname(abs).toLowerCase();
    const base = path.basename(abs);
    if (core.BINARY_EXTS.has(ext)) {
      core.appendLedger(sessionId, { base, kind: 'binary' });
      continue;
    }
    if (!core.PROSE_EXTS.has(ext)) continue;
    const isArchive = core.ARCHIVE_EXTS.has(ext);
    const cap = isArchive ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
    if (st.size > cap) {
      core.appendLedger(sessionId, { base, kind: 'skipped', capKb: isArchive ? core.ARCHIVE_CAP_KB : core.PLAIN_CAP_KB });
      continue;
    }
    const result = core.scoreFile(abs, ext);
    if (result.kind === 'failed') {
      core.appendLedger(sessionId, { base, kind: 'failed', reason: result.reason });
      continue;
    }
    const m = result.report._metrics;
    const flagged = m.ai_tell_score > threshold;
    const labels = (m.flagged_labels || []).slice(0, core.NUDGE_LABEL_CAP);
    core.appendLedger(sessionId, {
      base, kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band,
      phrase: m.ai_tell_hook_phrase, labels: m.flagged_labels || [], flagged, truncated: !!m.truncated,
    });
    if (!flagged) continue;
    const coverage = m.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
    lines.push('prosecheck: ' + base + ' ' + m.ai_tell_hook_phrase + ' (score ' + m.ai_tell_score +
      ', band ' + m.ai_tell_band + coverage + '). Flagged: ' + (labels.join('; ') || 'none listed') +
      '. Fix the flagged spans.');
  }
  if (!lines.length) return;
  const out = {
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // a hook must never fail the host session
}
process.exitCode = 0;
