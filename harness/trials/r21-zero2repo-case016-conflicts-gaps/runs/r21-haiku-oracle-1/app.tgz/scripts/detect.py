#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With FILE, the file is read (plain text or one of the twenty supported formats).
Without FILE, standard input is read as plain text. Output is a JSON report on
standard output, or scrubbed text with --clean. Failures print one JSON object
{"error": ...} as the last line of standard error and exit 1 (empty input,
unreadable input) or 2 (unknown option).

Nothing here touches the network. Only the Python standard library is used.
Lines marked "# spec:" name the spec ids a piece of code satisfies.
"""
import bisect
import io
import json
import os
import posixpath
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000236–N-000240 — the scan window is the first 262,144 characters of extracted prose.
SCAN_WINDOW = 262144
# spec: N-000248 — caps in binary units (enforced by the plugin; kept here for reference).
PLAIN_CAP_BYTES = 512 * 1024
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024

# spec: N-000245–N-000253 — the twenty supported formats.
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
BINARY_EXTS = {'.pdf', '.rtf'}  # spec: N-000282 — not among the twenty; no extracted prose.
SUPPORTED_EXTS = PLAIN_EXTS | ZIP_EXTS | NOTEBOOK_EXTS

# spec: N-000704 N-000708 N-000712 — error objects and exit statuses.
EXIT_OK = 0
EXIT_EMPTY_OR_UNREADABLE = 1
EXIT_UNKNOWN_OPTION = 2

USAGE_LINE = 'usage: detect.py [--clean] [--ci] [--] [FILE]'
USAGE = (
    USAGE_LINE + '\n'
    'Score prose for AI-writing patterns. Reads FILE, or standard input when no FILE is given.\n'
    '  --clean      print the cleaned text instead of the JSON report\n'
    '  --ci         add a low/high interval on the score (needs at least four sentences)\n'
    '  --           end option parsing, so FILE may begin with a dash\n'
    '  -h, --help   print this message and exit 0\n'
)

# spec: N-000115 — the five bands.
BANDS = [
    (20, 'clean', 'reads clean'),
    (40, 'light tells', 'reads mostly clean'),
    (60, 'mixed', 'reads with some AI tells'),
    (80, 'heavy tells', 'reads with heavy AI tells'),
    (100, 'pervasive tells', 'reads with pervasive AI tells'),
]

# spec: N-000116 — catalogue numbers with no detector; never reported as findings.
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
# spec: N-000116–N-000122 — writing advice: reported, weight zero.
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
# spec: N-000135 — decisive findings.
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
# spec: N-000138 — numbers that count toward the short-document floor.
SHORT_FLOOR_NUMBERS = set(range(1, 40)) | set(range(47, 52)) | {69}
# spec: N-000144 — rhythm kinds that can move the score.
RHYTHM_MOVING = {'40', '44'}

LABELS = {
    1: 'AI vocabulary', 2: 'model-dialect vocabulary', 3: 'promotional language',
    4: 'hyphenated word-pair overuse', 5: 'simple yet X cliche', 6: 'stacked adjective chains',
    7: 'rule of three overuse', 8: 'synonym cycling', 9: 'generic character naming',
    10: 'significance inflation', 11: 'notability name-dropping', 12: 'vague attributions',
    13: 'article title as proper noun', 14: 'conservation padding', 15: 'false ranges',
    16: 'superficial -ing tail clauses', 17: 'negative parallelisms', 18: 'not X, just Y',
    19: 'filler phrases', 20: 'empty pivot phrases', 21: 'outcome speculation tails',
    22: 'persuasive authority tropes', 23: 'editorial interjections',
    24: 'self-thoroughness phrases', 25: 'question-answer rhetorical pattern',
    26: 'concrete evidence defense phrase', 27: 'compulsive intro hooks', 28: 'meandering intro',
    29: 'prompt echo', 30: 'diff-anchored writing', 31: 'signposting and announcements',
    32: 'cataloguing lead-ins', 33: 'inline-header vertical lists',
    34: 'mid-essay bullet injection', 35: 'fragmented headers',
    36: 'formulaic challenges sections', 37: 'transition cluster overuse',
    38: 'compulsive conclusion phrases', 39: 'generic positive conclusions',
    40: 'sentence-length monotony', 41: 'mechanical sentence-length alternation',
    42: 'opener repetition', 43: 'avoidance of fragments and run-ons',
    44: 'uniform paragraph length', 45: 'identical paragraph structure',
    46: 'semicolon and parenthesis underuse', 47: 'chatbot artifacts', 48: 'sycophantic tone',
    49: 'helpful-assistant register', 50: 'knowledge-cutoff disclaimer', 51: 'copula avoidance',
    52: 'passive voice and subjectless fragments', 53: 'two-way passive-voice drift',
    54: 'excessive hedging', 55: 'contraction absence', 56: 'boldface overuse', 57: 'emojis',
    58: 'em-dash overuse', 59: 'title case in headings', 60: 'curly quotation marks',
    61: 'hyphen-for-en-dash in ranges', 62: 'invisible or zero-width characters',
    63: 'placeholder text', 64: 'chat reference markup', 65: 'AI tracking parameters',
    66: 'mixed-script lookalikes', 67: 'non-standard spaces', 68: 'trailing whitespace',
    69: 'canonical marketing phrases', 70: 'decorative horizontal rules',
    71: 'degenerate repetition',
}
# spec: N-000150 — catalogue 17 has two forms with fixed keys.
SLUGS = {17: 'negative_parallelism'}

# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------


class CannotRead(Exception):
    """Unreadable path, or an archive-named file whose bytes are not a readable zip."""


def decode_plain(data):
    """Decode a plain-text body: UTF-8 (optional BOM) or UTF-16 with a BOM."""
    # spec: N-000254 N-000241 — UTF-8 with optional BOM, or UTF-16 with a BOM.
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', 'replace')
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        return data.decode('cp1252', 'replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1] if '}' in tag else tag


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _docx_like_text(root, para_name, text_name, tab_name='tab', br_name='br'):
    """Paragraph text of a WordprocessingML or DrawingML part, one paragraph per line."""
    paragraphs = []
    for p in root.iter():
        if _local(p.tag) != para_name:
            continue
        parts = []
        for node in p.iter():
            name = _local(node.tag)
            if name == text_name:
                parts.append(node.text or '')
            elif name == tab_name:
                parts.append('\t')
            elif name == br_name:
                parts.append('\n')
        text = ''.join(parts)
        if text.strip():
            paragraphs.append(text)
    return '\n'.join(paragraphs)


def _zip_member(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


def _extract_xlsx(zf):
    sst = []
    raw = _zip_member(zf, 'xl/sharedStrings.xml')
    sroot = _parse_xml(raw) if raw else None
    if sroot is not None:
        for si in sroot:
            if _local(si.tag) == 'si':
                sst.append(''.join((t.text or '') for t in si.iter() if _local(t.tag) == 't'))
    sheets = []
    wb_raw = _zip_member(zf, 'xl/workbook.xml')
    rels_raw = _zip_member(zf, 'xl/_rels/workbook.xml.rels')
    wb = _parse_xml(wb_raw) if wb_raw else None
    rels = _parse_xml(rels_raw) if rels_raw else None
    if wb is not None and rels is not None:
        targets = {}
        for rel in rels:
            targets[rel.get('Id')] = rel.get('Target', '')
        for sh in wb.iter():
            if _local(sh.tag) != 'sheet':
                continue
            rid = None
            for k, v in sh.attrib.items():
                if k.rsplit('}', 1)[-1] == 'id':
                    rid = v
            target = targets.get(rid)
            if target:
                target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
                sheets.append(posixpath.normpath(target))
    if not sheets:
        sheets = sorted(n for n in zf.namelist()
                        if re.match(r'xl/worksheets/sheet\d+\.xml$', n))
    lines = []
    for name in sheets:
        raw = _zip_member(zf, name)
        root = _parse_xml(raw) if raw else None
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            value = None
            inline = None
            for child in c:
                cname = _local(child.tag)
                if cname == 'v':
                    value = child.text or ''
                elif cname == 'is':
                    inline = ''.join((t.text or '') for t in child.iter() if _local(t.tag) == 't')
            if kind == 's' and value is not None:
                v = value.strip()
                if v.isdigit() and int(v) < len(sst):
                    lines.append(sst[int(v)])
            elif kind == 'inlineStr' and inline is not None:
                lines.append(inline)
            elif kind == 'str' and value is not None:
                lines.append(value)
    return '\n'.join(s for s in lines if s.strip())


class _OdfWalker:
    """Visible text of an OpenDocument body: paragraphs, headings, spaces, tabs, breaks."""

    def __init__(self):
        self.out = []

    def walk(self, el):
        name = _local(el.tag)
        if name in ('p', 'h', 'table-cell', 'table-row', 'list-item'):
            self.out.append('\n')
            if el.text:
                self.out.append(el.text)
            for child in el:
                self.walk(child)
                if child.tail:
                    self.out.append(child.tail)
            self.out.append('\n')
            return
        if name == 's':
            try:
                count = int(el.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c', '1'))
            except ValueError:
                count = 1
            self.out.append(' ' * max(1, count))
            return
        if name == 'tab':
            self.out.append('\t')
            return
        if name == 'line-break':
            self.out.append('\n')
            return
        if el.text:
            self.out.append(el.text)
        for child in el:
            self.walk(child)
            if child.tail:
                self.out.append(child.tail)


def _extract_odf(root):
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    walker = _OdfWalker()
    walker.walk(body)
    return ''.join(walker.out)


BLOCK_HTML = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
              'blockquote', 'pre', 'article', 'header', 'footer', 'table', 'ul', 'ol', 'dd', 'dt'}
SKIP_HTML = {'script', 'style', 'head', 'nav', 'title'}


class _HtmlText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_HTML:
            self.skip += 1
        if tag in BLOCK_HTML:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in SKIP_HTML and self.skip:
            self.skip -= 1
        if tag in BLOCK_HTML:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_text(data):
    parser = _HtmlText()
    try:
        parser.feed(data.decode('utf-8', 'replace'))
        parser.close()
    except Exception:  # lenient: a broken chapter yields what it had
        pass
    return ''.join(parser.parts)


def _extract_epub(zf):
    names = zf.namelist()
    ordered = []
    container = _zip_member(zf, 'META-INF/container.xml')
    croot = _parse_xml(container) if container else None
    opf_path = None
    if croot is not None:
        for el in croot.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
    if opf_path:
        opf_raw = _zip_member(zf, opf_path)
        opf = _parse_xml(opf_raw) if opf_raw else None
        if opf is not None:
            base = posixpath.dirname(opf_path)
            manifest = {}
            spine = []
            for el in opf.iter():
                lname = _local(el.tag)
                if lname == 'item':
                    manifest[el.get('id')] = (el.get('href', ''), el.get('properties', '') or '')
                elif lname == 'itemref':
                    spine.append(el.get('idref'))
            for idref in spine:
                item = manifest.get(idref)
                if not item or 'nav' in item[1].split():
                    continue
                href = posixpath.normpath(posixpath.join(base, item[0])) if base else item[0]
                ordered.append(href)
    if not ordered:
        ordered = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')))
    chapters = []
    for name in ordered:
        raw = _zip_member(zf, name)
        if raw is None:
            continue
        text = _html_text(raw).strip()
        if text:
            chapters.append(text)
    return '\n'.join(chapters)


def _extract_notebook(data):
    try:
        nb = json.loads(data.decode('utf-8', 'replace'))
    except (ValueError, UnicodeDecodeError):
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        if src.strip():
            parts.append(src.strip())
    return '\n'.join(parts)


def extract_zip_document(ext, data):
    """Visible prose of a zip-based document or an epub."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise CannotRead('cannot read input: not a readable zip archive')
    try:
        with zf:
            if ext in ('.docx', '.docm'):
                raw = _zip_member(zf, 'word/document.xml')
                root = _parse_xml(raw) if raw else None
                text = _docx_like_text(root, 'p', 't') if root is not None else ''
            elif ext in ('.pptx', '.pptm'):
                slides = []
                for name in zf.namelist():
                    m = re.match(r'ppt/slides/slide(\d+)\.xml$', name)
                    if m:
                        slides.append((int(m.group(1)), name))
                texts = []
                for _, name in sorted(slides):
                    root = _parse_xml(_zip_member(zf, name) or b'')
                    if root is not None:
                        t = _docx_like_text(root, 'p', 't')
                        if t:
                            texts.append(t)
                text = '\n'.join(texts)
            elif ext in ('.xlsx', '.xlsm'):
                text = _extract_xlsx(zf)
            elif ext in ('.odt', '.odp', '.ods'):
                raw = _zip_member(zf, 'content.xml')
                root = _parse_xml(raw) if raw else None
                text = _extract_odf(root) if root is not None else ''
            elif ext == '.epub':
                text = _extract_epub(zf)
            else:
                text = ''
    except (zipfile.BadZipFile, KeyError, ValueError, OSError):
        raise CannotRead('cannot read input: damaged zip archive')
    return text.strip()


def extract_bytes(path_ext, data):
    """Extracted prose for file bytes with the given lower-case extension."""
    if path_ext in ZIP_EXTS:
        return extract_zip_document(path_ext, data)
    if path_ext in NOTEBOOK_EXTS:
        return _extract_notebook(data).strip()
    if path_ext in BINARY_EXTS:
        return ''
    return decode_plain(data)


def extract_path(path):
    """Extracted prose for a path, or raise CannotRead."""
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise CannotRead('cannot read input: %s' % (exc.strerror or exc))
    return extract_bytes(ext, data)


# ---------------------------------------------------------------------------
# Masking and paragraph/sentence structure (FP-01 exclusions)
# ---------------------------------------------------------------------------

MASK = '\x01'
FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
BADGE_LINE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
INLINE_CODE = re.compile(r'`[^`\n]+`')


def mask_excluded(window):
    """Replace text the detector must not score with MASK, keeping offsets and newlines.

    Excluded: front matter, fenced code, runs of two or more blockquote lines,
    markdown table rows, badge lines and inline code spans.
    """
    # spec: N-000149 — inside the window: no findings from code, quotes, tables, badges, front matter.
    lines = window.split('\n')
    keep = [True] * len(lines)  # True = scored; False = masked
    n = len(lines)
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() in ('---', '...'):
                for k in range(0, j + 1):
                    keep[k] = False
                break
    i = 0
    while i < n:
        line = lines[i]
        m = FENCE_OPEN.match(line)
        if m and keep[i]:
            fence = m.group(1)
            ch, size = fence[0], len(fence)
            close_re = re.compile(r'^ {0,3}' + re.escape(ch) + '{' + str(size) + r',}\s*$')
            keep[i] = False
            j = i + 1
            while j < n and not close_re.match(lines[j]):
                keep[j] = False
                j += 1
            if j < n:
                keep[j] = False
            i = j + 1
            continue
        if line.lstrip().startswith('>') and i + 1 < n and lines[i + 1].lstrip().startswith('>'):
            j = i
            while j < n and lines[j].lstrip().startswith('>'):
                keep[j] = False
                j += 1
            i = j
            continue
        if line.lstrip().startswith('|'):
            keep[i] = False
        elif BADGE_LINE.match(line):
            keep[i] = False
        i += 1
    out = []
    for idx, line in enumerate(lines):
        if not keep[idx]:
            out.append(MASK * len(line))
            continue
        out.append(INLINE_CODE.sub(lambda mm: MASK * len(mm.group()), line))
    return '\n'.join(out)


BLANK_SPLIT = re.compile(r'\n[ \t\r]*\n')
WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")
SENT_END = re.compile(r'[.!?…]+["\')\]”’»]*(?=\s|$)')
LIST_LINE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S')
HEADING_LINE = re.compile(r'^(#{1,6})\s+(.*)$')


def has_word(text):
    return any(any(c.isalnum() for c in m.group()) for m in WORD_RE.finditer(text))


def words_in(text):
    return [m for m in WORD_RE.finditer(text) if any(c.isalnum() for c in m.group())]


def paragraph_spans(text):
    """(start, end) of each blank-line-separated paragraph, trimmed of outer whitespace."""
    spans = []
    pos = 0
    bounds = [(m.start(), m.end()) for m in BLANK_SPLIT.finditer(text)]
    bounds.append((len(text), len(text)))
    for bs, be in bounds:
        seg = text[pos:bs]
        stripped = seg.strip()
        if stripped:
            start = pos + (len(seg) - len(seg.lstrip()))
            spans.append((start, start + len(stripped)))
        pos = be
    return spans


def sentence_spans(text):
    """(start, end) of sentences that contain at least one word."""
    out = []
    for ps, pe in paragraph_spans(text):
        start = ps
        for m in SENT_END.finditer(text, ps, pe):
            if m.end() > start:
                out.append((start, m.end()))
                start = m.end()
        if start < pe:
            out.append((start, pe))
    return [(s, e) for s, e in out if has_word(text[s:e])]


def coefficient_of_variation(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return (var ** 0.5) / mean


# ---------------------------------------------------------------------------
# Pattern helpers
# ---------------------------------------------------------------------------

B_L = r'(?<![^\W_])'
B_R = r'(?![^\W_])'
RE_FLAGS = re.IGNORECASE


def _inflected(word):
    """Regex for a word and its common inflections (verb or noun forms)."""
    esc = re.escape(word)
    if word.endswith('e') and len(word) > 3:
        stem = re.escape(word[:-1])
        forms = '(?:%s|%ss|%sed|%sing)' % (esc, esc, stem, stem)
    elif word.endswith('y') and len(word) > 3 and word[-2] not in 'aeiou':
        stem = re.escape(word[:-1])
        forms = '(?:%s|%sies|%sied|%sying)' % (esc, stem, stem, stem)
    else:
        forms = '(?:%s|%ss|%ses|%sed|%sing)' % (esc, esc, esc, esc, esc)
    return B_L + forms + B_R


def _phrase(text):
    parts = text.split()
    body = r'\s+'.join(re.escape(p).replace("'", "['’]") for p in parts)
    return B_L + body + B_R


def _item(text):
    """A single word becomes an inflected pattern; a phrase becomes a spaced pattern."""
    return _phrase(text) if ' ' in text else _inflected(text)


def _alt(items):
    return re.compile('|'.join('(?:%s)' % _item(x) for x in items), RE_FLAGS)


def _regex_list(patterns):
    return [re.compile(p, RE_FLAGS) for p in patterns]


def _spans(regexes, text):
    spans = []
    for rx in regexes:
        for m in rx.finditer(text):
            spans.append((m.start(), m.end()))
    spans.sort()
    return spans


ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$')
STOCK_ADJ = {
    'vibrant', 'powerful', 'seamless', 'robust', 'innovative', 'cutting-edge', 'dynamic',
    'comprehensive', 'intuitive', 'elegant', 'sleek', 'stunning', 'bold', 'rich', 'lush',
    'pristine', 'transformative', 'revolutionary', 'groundbreaking', 'world-class',
    'state-of-the-art', 'modern', 'efficient', 'reliable', 'scalable', 'versatile',
    'exceptional', 'remarkable',
}
STOPWORDS = {
    'the', 'and', 'for', 'with', 'that', 'this', 'from', 'into', 'about', 'your', 'their',
    'they', 'have', 'been', 'were', 'will', 'would', 'could', 'should', 'there', 'which',
    'when', 'what', 'where', 'while', 'also', 'more', 'than', 'such', 'some', 'many',
}
SMALL_TITLE_WORDS = {
    'a', 'an', 'the', 'and', 'or', 'but', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at',
    'to', 'by', 'as', 'up', 'from', 'via', 'per', 'vs', 'into', 'onto', 'off', 'out', 'with',
}
MARKETING_IMPERATIVES = {
    'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
    'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
    'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop',
    'start',
}
FIRST_PERSON = re.compile(r'\b(?:I|me|my|we|us|our)\b')
CONTRACTED = re.compile(
    r"\b(?:don[’']t|doesn[’']t|didn[’']t|isn[’']t|aren[’']t|"
    r"wasn[’']t|weren[’']t|won[’']t|can[’']t|haven[’']t|hasn[’']t|"
    r"I[’']m|I[’']ve|I[’']ll|I[’']d|we[’']re|we[’']ve|"
    r"they[’']re|that[’']s|it[’']s|there[’']s|you[’']re|let[’']s)\b")
WRITTEN_OUT = re.compile(
    r"\b(?:do not|does not|did not|is not|are not|was not|were not|will not|cannot|"
    r"can not|have not|has not|I am|I have|I will|I would|we are|we have|we will|"
    r"they are|they have|that is|it is|there is|you are|let us)\b")
HEDGE = re.compile(
    r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|'
    r'fairly|seems? (?:to|like)|appears? to|kind of|sort of)\b')
TRANSITION_OPEN = re.compile(
    r'(?:(?<=^)|(?<=[.!?]\s)|(?<=\n))(Additionally|Furthermore|Moreover|However|'
    r'Nevertheless|Consequently|Subsequently|Notably)\b', re.IGNORECASE | re.MULTILINE)
EMOJI = re.compile('[\U0001F000-\U0001FAFF☀-➿⭐⭕⬆⬇⬅⤴⤵'
                   '〰〽㊗㊙©®‼⁉™ℹ↔-↙'
                   '↩↪⌚⌛⌨⏏⏩-⏳⏸-⏺Ⓜ▪'
                   '▫▶◀◻-◾]')

# ---------------------------------------------------------------------------
# Catalogue patterns (FP-01)
# ---------------------------------------------------------------------------

AI_VOCAB_WORDS = [
    'additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
    'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
    'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
    'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
    'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
    'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock',
]
AI_VOCAB_PHRASES = [
    'align with', 'capture the essence', 'capture the spirit', 'capture the imagination',
    'capture the heart', 'capture the magic',
]
DIALECT_WORDS = ['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
                 'strikingly', 'compellingly', 'supercharge', 'skyrocket', 'turbocharge',
                 'revolutionize']
DIALECT_PHRASES = ['quietly powerful', 'quietly profound', 'quietly radical', 'deeply human',
                   'deeply personal', 'deeply felt', 'deeply unsettling', 'resonates deeply',
                   'double down on']
DIALECT_RX = [
    r'\bgame[- ]chang(?:er|ers|ing)\b',
    r'\bdive deep(?:er)? into\b',
    r'\bunlock (?:the )?(?:power|potential|value)\b',
    r'\btake\b[^.!?\n]{0,40}?\bto the next level\b',
]
PROMO_PHRASES = [
    'nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
    'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
    'unparalleled', 'premier', 'leading', 'esteemed organization', 'valuable asset',
    'passion for excellence', 'proven track record', 'results-oriented', 'wealth of experience',
    'dynamic team', 'fast-paced environment', 'deeply passionate', 'perfectly situated',
    'close-knit team', 'tight-knit team', 'uniquely positioned to',
]
PROMO_RX = [r'\bI am excited to (?:apply|bring)\b']
SIMPLE_YET = [r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b']
SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SIGNIFICANCE_RX = [
    r'\b(?:stands|serves|stood|served) as (?:a |an |the )?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\bunderscor(?:es|ed|ing)\b[^.!?\n]{0,12}?\b(?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\bhighlight(?:s|ed|ing)?\b[^.!?\n]{0,12}?\b(?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects? a broader (?:trend|shift|pattern)\b',
    r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymboliz(?:es|ed|ing)\b',
    r'\bsets? the stage for\b',
    r'\bleft an indelible mark\b',
    r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\bhas (?:shaped|sparked)\b',
    r'\bhas come to (?:define|symbolize)\b',
]
VAGUE_ATTRIBUTION_RX = [
    r'\bexperts? (?:argue|believe|say|claim|note|suggest)s?\b',
    r'\bindustry (?:reports|observers|analysts)\b',
    r'\bobservers have (?:cited|noted)\b',
    r'\bsome critics argue\b',
    r'\bresearchers have found\b',
    r'\bstudies suggest\b',
    r'\bit is widely believed\b',
]
ARTICLE_TITLE_RX = [
    r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [\w'’:&\-]+(?:[ \t]+[\w'’:&\-]+){0,11}[ \t]+(?:is|are) (?:a|an|the)\b",
]
CONSERVATION_RX = [
    r'\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts are (?:underway|ongoing|in place)\b',
    r'\bserves as an indicator species\b',
    r'\bcontributes to biodiversity\b',
]
FALSE_RANGE_RX = [
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b',
]
ING_TAIL_RX = [
    r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
    r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
    r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b',
]
PARALLEL_RX = [  # weight zero: the parallelism form of catalogue 17
    r'\bit[’\']s not (?:just|merely) (?:about|a|an)\b',
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn[’\']t just\b[^,.!?\n]{0,40}?\bit\b',
]
TAILING_NEG_RX = [  # score-moving: the tailing-negation form of catalogue 17
    r',\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b',
]
NOT_X_JUST_Y_RX = [
    r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
    r'\b(?:not|isn[’\']t|aren[’\']t|wasn[’\']t|weren[’\']t) (?:just|merely) (?:a |an |the )?\w+(?:,\s*|\s*[—–-]\s*)(?:it[’\']s|it is|it was|they[’\']re|they are|they were|that[’\']s|but)\b',
]
PIVOT_RX = [
    r"\bit[’']s worth (?:noting|mentioning) that\b",
    r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to (?:consider|keep in mind) is\b',
    r'\bit is interesting to note that\b',
    r'\ba key consideration is\b',
    r'\ba point to highlight is\b',
]
OUTCOME_TAIL_RX = [
    r',\s+(?:raising questions about|prompting reflection on|sparking debate about|'
    r'with broader implications for|reshaping our understanding of|paving the way for|'
    r'signaling a shift toward)\b',
]
INTRO_HOOK_RX = [
    r"\bin today[’']s (?:[\w\-]+ ){0,2}?(?:world|landscape|environment|market)\b",
    r'\bin a world where\b',
    r'\bin an era of\b',
    r'\bin recent years,',
    r'\bmore than ever before\b',
    r'\bwe live in a (?:time|world) when\b',
    r'\b(?:great|exciting|big) news\b(?=\s*[!:])',
    r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b',
]
FORMULAIC_CHALLENGE_RX = [
    r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
    r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
    r'\bcontinues to thrive\b',
    r'\btypical of (?:emerging|urban|modern)\b',
    r'\bfaces (?:several|many|numerous) challenges\b',
]
CONCLUSION_RX = [
    r'^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b',
]
POSITIVE_CONCLUSION_RX = [
    r'\bthe future looks bright\b',
    r'\bexciting times lie ahead\b',
    r'\bjourney toward excellence\b',
    r'\bstep in the right direction\b',
    r'\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned (?:for|to) (?:whatever comes next|the future|the road ahead)\b',
]
FILLER_PHRASES = [
    'in order to', 'due to the fact that', 'at this point in time', 'in the event that',
    'has the ability to', 'it is important to note that', 'it should be mentioned that',
    'needless to say',
]
PERSUASIVE_PHRASES = [
    "here's the thing", 'make no mistake', 'the truth is', "let's be honest",
    'the simple fact is', 'at its core', 'what really matters', 'more than anything',
    'at the end of the day', 'the bottom line is', 'in reality', 'fundamentally,',
    'the real question is', 'the heart of the matter', 'the deeper issue',
    'when you get down to it', 'when all is said and done',
]
SELF_THOROUGH_RX = [
    r'\bthis (?:comprehensive|complete) (?:guide|overview|analysis)\b',
    r'\bthis in-depth (?:analysis|look|examination)\b',
    r'\ba thorough examination of\b',
    r'\beverything you need to know about\b',
]
QA_RX = [
    r'(?:^|(?<=[.!?] )|(?<=\n))(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|'
    r'Was|Were|Might|May|Must)\b[^.?!\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]',
]
CONCRETE_EVIDENCE_RX = [
    r'\bwithout concrete (?:evidence|proof)\b',
    r'\bdo you have concrete (?:evidence|proof)\b',
    r'\bI (?:would )?need concrete (?:evidence|examples) to\b',
    r'\babsent concrete (?:evidence|proof)\b',
    r'\bprovide concrete (?:evidence|proof)\b',
]
DIFF_ANCHOR_RX = [
    r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
    r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b',
    r'\bpreviously\b[^.!?\n]{0,80}\bnow\b',
    r"\bwasn[’']t there before\b",
    r"\bweren[’']t there before\b",
    r"\bwe[’']ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b",
    r'\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
]
SIGNPOST_RX = [
    r"\blet[’']s (?:dive|delve|explore)\b",
    r"\blet[’']s break (?:this|it) down\b",
    r"\bhere[’']s what you need to know\b",
    r'\bwithout further ado\b',
    r"\bnow let[’']s look at\b",
    r'\bbuckle up\b',
    r'\bstay with me\b',
    r'\bare you ready to dive in\b',
]
CATALOGUE_LEAD_RX = [
    r'\b(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+',
    r'\bThese (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b',
]
INLINE_HEADER_RX = [
    r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]*:\s*\*\*',
    r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+\*\*:',
]
MARKETING_SLOP_RX = [
    r"\bunlock(?:ing)? (?:your|its|their|the|full) (?:full )?potential\b",
    r'\bnavigat(?:e|es|ing) the complexities\b',
    r'\ba testament to the (?:power|importance) of\b',
    r'\bstay(?:ing)? ahead of the curve\b',
    r'\bturn(?:ing)? challenges into opportunities\b',
    r'\btak(?:e|es|ing) (?:it|something|your \w+|\w+) to the next level\b',
    r'\bharness(?:ing)? the power of\b',
    r'\bpav(?:e|es|ing) the way for\b',
    r'\bsaying goodbye to\b',
    r'\bimagin(?:e|ing) a world where\b',
]
CHATBOT_RX = [
    r'\bI hope this helps\b',
    r'\bCertainly!',
    r'\bOf course!',
    r'\blet me know if you\b',
    r'\bwould you like me to\b',
    r'\bfeel free to (?:ask|reach out)\b',
    r'\bhappy to help[.!]',
    r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
    r'\bhere (?:are|is|’s|\'s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
    r'\bhere (?:is|’s|\'s) (?:a|the) draft\b',
    r'\bdepending on the (?:vibe|tone|style)\b',
    r'\bI hope (?:this email )?finds you well\b',
    r'\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
    r'\bto answer your question\b',
    r'\bto address your question\b',
    r'\bin response to your question\b',
    r'\bin answer to your question\b',
    r'\byour question (?:about|regarding|concerning)\b',
    r'\bas (?:you )?(?:requested|asked),? here\b',
    r'\bhere (?:is|’s|\'s) (?:the )?(?:draft|first pass|revised version) (?:of|for your)\b',
]
SYCOPHANCY_RX = [
    r'\byou(?:’re| are) absolutely right\b',
    r'\b(?:great|excellent|good|fantastic|wonderful|thoughtful|brilliant|insightful) (?:question|point)\s*[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic|brilliant|excellent|insightful) question\b',
    r'\bthat’s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b',
    r"\bthat's a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b",
]
CUTOFF_RX = [
    r'\bas of my (?:last )?(?:training|knowledge)\b',
    r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bwhile specific details are (?:limited|scarce|not extensively documented|not widely documented)\b',
    r'\bbased on (?:the )?available information\b',
    r'\bas of my (?:knowledge )?cutoff\b',
    r'\bmaintains a low profile\b',
    r'\bkeeps (?:his|her|their) personal life private\b',
]
COPULA_RX = [
    r'\b(?:serves|stands|functions|acts) as\b',
    r'\brepresents (?:a|the)\b',
    r'\bmarks (?:a|the)\b',
    r'\bboast(?:s|ed|ing)?\b',
    r'\bfeatures (?:a|an|the|\d[\d,.]*|several|many|numerous|multiple|various|two|three|four|five)\b',
    r'\boffers an? \b',
    r'\brefers to\b',
]
PLACEHOLDER_RX = [
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])',
    r'\[(?:name|company|client|place|source|person|organi[sz]ation)\](?![\(\[])',
    r'\[[A-Z][A-Z0-9 _\-]{2,}\](?![\(\[])',
    r'\{\{[^}\n]*\}\}',
    r'(?<![A-Za-z])x{3,}(?![A-Za-z])',
    r'\blorem ipsum\b',
]
CHAT_MARKUP_RX = [
    r'\bcite(?:turn|start|nav)\w*',
    r'\boai_citation\w*',
    r'contentReference',
    r'\bnavlist\b',
    r'【\d+†[^】\n]*】',
]
AI_TRACKING_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
                     'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}
UTM_RX = re.compile(r'utm_source=([A-Za-z0-9.\-]+)')

NOTABILITY_OUTLETS = [
    'New York Times', 'Forbes', 'BBC', 'CNN', 'Reuters', 'Bloomberg', 'The Guardian', 'Wired',
    'TechCrunch', 'The Verge', 'Washington Post', 'Wall Street Journal', 'NPR',
    'Associated Press', 'Business Insider', 'The Economist', 'Fortune', 'Axios', 'Politico',
]
NOTABILITY_CREDIT = re.compile(
    r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by)\b',
    re.IGNORECASE)
NOTABILITY_FOLLOWERS = re.compile(
    r'\b\d[\d,.]*\s*(?:[kKmM]|thousand|million)?\s+(?:followers|subscribers)\b', re.IGNORECASE)
NOTABILITY_STOCK = [
    r'\b(?:strong|active|growing|robust)\s+(?:online|digital|social[- ]media)\s+presence\b',
    r'\bwidely covered\b',
    r'\bindependent coverage\b',
]

HOMOGLYPH_MAP = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'о': 'o', 'р': 'p', 'ѕ': 's', 'у': 'y', 'х': 'x',
    'ѵ': 'v', 'ԝ': 'w', 'ա': 'a', 'օ': 'o', 'ո': 'n', 'հ': 'h',
    'ο': 'o', 'ν': 'v', 'ρ': 'p', 'υ': 'u', 'χ': 'x', 'ι': 'i',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S',
    'Т': 'T', 'Х': 'X', 'У': 'Y', 'Α': 'A', 'Β': 'B', 'Ε': 'E',
    'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N',
    'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X',
}

# ---------------------------------------------------------------------------
# Character layer (FP-01 62, 66, 67; FP-03 cleanup)
# ---------------------------------------------------------------------------

NBSP_CHARS = ('\u00a0', '\u202f')
FILLERS = {0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0}
MONGOL_SEL = {0x180B, 0x180C, 0x180D, 0x180F}
BIDI_CTRL = {0x061C, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
             0x2066, 0x2067, 0x2068, 0x2069}


def _is_ideograph(cp):
    return (0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF
            or 0x20000 <= cp <= 0x2FFFF)


def _no_space_script(cp):
    return (0x0E00 <= cp <= 0x0EFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF
            or 0x3040 <= cp <= 0x30FF or _is_ideograph(cp))


def _joining_script(cp):
    return (0x0590 <= cp <= 0x05FF or 0x0600 <= cp <= 0x06FF or 0x0900 <= cp <= 0x0DFF
            or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF)


def _symbolic(ch):
    if not ch:
        return False
    cp = ord(ch)
    return cp >= 0x1F000 or unicodedata.category(ch) in ('So', 'Sm', 'Sk')


def _rtl_present(text):
    for ch in text:
        cp = ord(ch)
        if 0x0590 <= cp <= 0x08FF or 0xFB1D <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF:
            return True
    return False


def _invisible_candidate(ch, cp):
    if cp in (9, 10, 13) or cp == 1:
        return False
    cat = unicodedata.category(ch)
    if cat in ('Cf', 'Cc'):
        return True
    if 0xE0000 <= cp <= 0xE0FFF or 0xFE00 <= cp <= 0xFE0F:
        return True
    if cp in FILLERS or cp in MONGOL_SEL:
        return True
    return False


def _invisible_removable(text, i, rtl):
    """True when cleanup removes the invisible character at text[i] (FP-03 keeps some)."""
    ch = text[i]
    cp = ord(ch)
    if not _invisible_candidate(ch, cp):
        return False
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0000 <= cp <= 0xE007F:
        # keep a tag character inside an emoji tag sequence (black-flag base and cancel tag)
        j = i - 1
        steps = 0
        while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F and steps < 64:
            j -= 1
            steps += 1
        base = ord(text[j]) if j >= 0 else 0
        if base == 0x1F3F4 or base >= 0x1F000:
            return False
        return True
    if (0xFE00 <= cp <= 0xFE0F) or (0xE0100 <= cp <= 0xE01EF):
        if prev and (_is_ideograph(ord(prev)) or _symbolic(prev)) or nxt == '\u20e3':
            return False
        return True
    if cp == 0x200B:
        if (prev and _no_space_script(ord(prev))) or (nxt and _no_space_script(ord(nxt))):
            return False
        return True
    if cp == 0x00AD:
        if prev.isalpha() and nxt.isalpha():
            return False
        return True
    if cp in (0x200C, 0x200D):
        if ((prev and (_joining_script(ord(prev)) or _symbolic(prev)))
                or (nxt and (_joining_script(ord(nxt)) or _symbolic(nxt)))):
            return False
        return True
    if cp in BIDI_CTRL:
        return not rtl
    if cp in MONGOL_SEL:
        if prev and 0x1800 <= ord(prev) <= 0x18AF:
            return False
        return True
    if cp in (0x17B4, 0x17B5):
        if (prev and 0x1780 <= ord(prev) <= 0x17FF) or (nxt and 0x1780 <= ord(nxt) <= 0x17FF):
            return False
        return True
    return True


def _nbsp_kept(text, i):
    """A no-break space or narrow no-break space that holds something together (FP-03)."""
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def _nonstandard_space_removable(text, i):
    ch = text[i]
    if ch == ' ' or unicodedata.category(ch) != 'Zs':
        return False
    if ch in NBSP_CHARS and _nbsp_kept(text, i):
        return False
    return True


def _is_homoglyph_token(tok):
    """A token whose letters mix ASCII Latin letters with lookalikes and no other non-ASCII letter."""
    has_ascii = False
    has_look = False
    for c in tok:
        if c.isascii():
            if c.isalpha():
                has_ascii = True
        elif c in HOMOGLYPH_MAP:
            has_look = True
        elif c.isalpha():
            return False
    return has_ascii and has_look


def character_layer(masked):
    """Offsets of invisible characters and non-standard spaces in masked text."""
    rtl = _rtl_present(masked)
    invisible = []
    nonstd = []
    for i, ch in enumerate(masked):
        if ch == ' ' or (ch.isascii() and ch.isalnum()):
            continue
        cp = ord(ch)
        if _invisible_candidate(ch, cp) and _invisible_removable(masked, i, rtl):
            invisible.append(i)
            continue
        if cp > 127 and unicodedata.category(ch) == 'Zs' and _nonstandard_space_removable(masked, i):
            nonstd.append(i)
    return invisible, nonstd


def homoglyph_tokens(view):
    """(start, end, lookalike_count) for each qualifying token."""
    out = []
    for m in re.finditer(r'\S+', view):
        tok = m.group()
        if _is_homoglyph_token(tok):
            count = sum(1 for c in tok if c in HOMOGLYPH_MAP)
            out.append((m.start(), m.end(), count))
    return out


def scrub(text):
    """Cleanup (FP-03): drop invisible characters, normalise spaces, fold lookalikes, trim."""
    rtl = _rtl_present(text)
    out = []
    for i, ch in enumerate(text):
        cp = ord(ch)
        if ch == ' ' or ch in '\t\n\r':
            out.append(ch)
            continue
        if _invisible_candidate(ch, cp) and _invisible_removable(text, i, rtl):
            continue
        cat = unicodedata.category(ch)
        if cat == 'Zs':
            if ch in NBSP_CHARS and _nbsp_kept(text, i):
                out.append(ch)
            else:
                out.append(' ')
        elif cat in ('Zl', 'Zp'):
            out.append('\n')
        else:
            out.append(ch)
    body = ''.join(out)

    def fold(m):
        tok = m.group()
        if _is_homoglyph_token(tok):
            return ''.join(HOMOGLYPH_MAP.get(c, c) for c in tok)
        return tok

    body = re.sub(r'\S+', fold, body)
    lines = body.split('\n')
    lines = [re.sub(r'[ \t]+(?=\r?$)', '', ln) for ln in lines]
    body = '\n'.join(lines)
    ended_nl = text.endswith('\n')
    crlf = text.endswith('\r\n')
    result = body.strip(' \t\r\n')
    if result and ended_nl:
        result += '\r\n' if crlf else '\n'
    return result


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------


class Finding(object):
    __slots__ = ('num', 'slug', 'label', 'count', 'starts', 'spans', 'family', 'moving',
                 'decisive', 'key', 'samples')

    def __init__(self, num, slug, label, spans, family, moving, decisive):
        self.num = num
        self.slug = slug
        self.label = label
        self.spans = spans
        self.count = len(spans)
        self.starts = [s for s, _ in spans]
        self.family = family
        self.moving = moving
        self.decisive = decisive
        self.key = '%d_%s' % (num, slug)
        self.samples = []


def _excerpt(window, s, e):
    a = max(0, s - 30)
    b = min(len(window), e + 30)
    text = re.sub(r'\s+', ' ', window[a:b]).strip()
    prefix = '...' if a > 0 else ''
    suffix = '...' if b < len(window) else ''
    return prefix + text + suffix


def _family_for(num):
    return str(num)


class Analysis(object):
    """Everything computed for one scan window."""

    def __init__(self, prose):
        self.prose = prose
        self.window = prose[:SCAN_WINDOW]
        self.truncated = len(prose) > SCAN_WINDOW
        self.masked = mask_excluded(self.window)
        self.view = self.masked.replace(MASK, ' ')
        self.findings = []
        self.sentences = []
        self.paragraphs = []
        self.invisible = []
        self.nonstd = []
        self.homoglyph_count = 0
        self._run()

    def _add(self, num, label, spans, slug=None, family=None, moving=None, decisive=None):
        spans = [(s, e) for s, e in spans]
        if not spans:
            return None
        if slug is None:
            slug = SLUGS.get(num, re.sub(r'[^a-z0-9]+', '_', LABELS[num].lower()).strip('_'))
        if moving is None:
            moving = num not in ADVICE
        if decisive is None:
            decisive = num in DECISIVE
        if family is None:
            family = _family_for(num)
        f = Finding(num, slug, label, spans, family, moving, decisive)
        f.samples = [_excerpt(self.window, s, e) for s, e in spans[:3]]
        self.findings.append(f)
        return f

    def _add_doc(self, num, label, count, family=None, moving=None, decisive=None):
        """A document-level finding with no positions (count only)."""
        if count <= 0:
            return None
        slug = re.sub(r'[^a-z0-9]+', '_', LABELS[num].lower()).strip('_')
        if moving is None:
            moving = num not in ADVICE
        if decisive is None:
            decisive = num in DECISIVE
        if family is None:
            family = _family_for(num)
        f = Finding(num, slug, label, [(0, 0)] * count, family, moving, decisive)
        f.starts = None
        f.samples = []
        self.findings.append(f)
        return f

    def _run(self):
        masked = self.masked
        view = self.view
        win = self.window
        self.sentences = sentence_spans(view)
        self.paragraphs = paragraph_spans(view)
        sent_words = [len(words_in(view[s:e])) for s, e in self.sentences]
        para_words = [len(words_in(view[s:e])) for s, e in self.paragraphs]
        self.word_count = len(words_in(view))
        self.word_spans = [(m.start(), m.end()) for m in words_in(view)]

        # --- character layer: 62, 66, 67, 68
        self.invisible, self.nonstd = character_layer(masked)
        self._add(62, LABELS[62], [(i, i + 1) for i in self.invisible])
        self._add(67, LABELS[67], [(i, i + 1) for i in self.nonstd], moving=True)
        tokens = homoglyph_tokens(view)
        self.homoglyph_count = sum(c for _, _, c in tokens)
        self._add(66, LABELS[66], [(s, e) for s, e, _ in tokens])
        trailing = []
        for m in re.finditer(r'[ \t]+(?=\r?\n|$)', masked, re.MULTILINE):
            trailing.append((m.start(), m.end()))
        if masked[:1] and masked[0] in ' \t\n\r':
            trailing.append((0, 1))
        if re.search(r'\n[ \t\r]*\n[ \t\r\n]*\Z', masked):
            trailing.append((len(masked) - 1, len(masked)))
        self._add(68, LABELS[68], trailing)

        # --- lexical families
        self._lexical()

        # --- structural families
        self._structural(view, win, sent_words, para_words)

    def _lexical(self):
        view = self.view
        win = self.window
        # 1 AI vocabulary
        rx1 = [_alt(AI_VOCAB_WORDS + AI_VOCAB_PHRASES),
               re.compile(r'\bcapture the (?:essence|spirit|imagination|heart|magic)\b', RE_FLAGS)]
        self._add(1, LABELS[1], _spans(rx1, view))
        # 2 model-dialect vocabulary (fires on two or more hits)
        rx2 = [_alt(DIALECT_WORDS + DIALECT_PHRASES)] + _regex_list(DIALECT_RX)
        dial = _spans(rx2, view)
        if len(dial) >= 2:
            self._add(2, LABELS[2], dial)
        # 3 promotional language
        promo = [_alt(PROMO_PHRASES)] + _regex_list(PROMO_RX)
        spans3 = _spans(promo, view)
        imperative = []
        for s, e in self.sentences:
            first = WORD_RE.search(view, s, e)
            if first and first.group().lower() in MARKETING_IMPERATIVES:
                imperative.append((first.start(), first.end()))
        if len(imperative) >= 3:
            spans3 = sorted(spans3 + imperative)
        self._add(3, LABELS[3], spans3)
        # 4 hyphenated word-pair overuse (advice)
        self._add(4, LABELS[4], _spans([_alt(['cutting-edge', 'game-changing', 'state-of-the-art',
                                               'fast-paced', 'results-driven', 'data-driven',
                                               'best-in-class', 'user-friendly', 'next-generation',
                                               'top-notch', 'long-term', 'high-quality'])], view))
        # 5 simple yet X
        self._add(5, LABELS[5], _spans(_regex_list(SIMPLE_YET), view))
        # 6 stacked adjective chains
        self._add(6, LABELS[6], self._stacked_adjectives(view))
        # 8 synonym cycling
        spans8 = []
        for cluster in SYNONYM_CLUSTERS:
            found = {}
            for member in cluster:
                ms = _spans([_item_rx(member)], view)
                if ms:
                    found[member] = ms
            if len(found) >= 3:
                for ms in found.values():
                    spans8.extend(ms)
        self._add(8, LABELS[8], sorted(spans8))
        # 10 significance inflation
        self._add(10, LABELS[10], _spans(_regex_list(SIGNIFICANCE_RX), view))
        # 11 notability name-dropping
        self._add(11, LABELS[11], self._notability(view))
        # 12 vague attributions
        self._add(12, LABELS[12], _spans(_regex_list(VAGUE_ATTRIBUTION_RX), view))
        # 13 article title as proper noun (decisive)
        self._add(13, LABELS[13], _spans(_regex_list(ARTICLE_TITLE_RX), view))
        # 14 conservation padding
        self._add(14, LABELS[14], _spans(_regex_list(CONSERVATION_RX), view))
        # 15 false ranges
        self._add(15, LABELS[15], _spans(_regex_list(FALSE_RANGE_RX), view))
        # 16 superficial -ing tails
        self._add(16, LABELS[16], _spans(_regex_list(ING_TAIL_RX), view))
        # 17 parallelism (weight zero) and tailing negation (score-moving)
        self._add(17, LABELS[17], _spans(_regex_list(PARALLEL_RX), view),
                  slug='negative_parallelism', family='17p', moving=False, decisive=False)
        self._add(17, 'tailing negations', _spans(_regex_list(TAILING_NEG_RX), view),
                  slug='tailing_negation', family='17t', moving=True, decisive=False)
        # 18 not X, just Y
        self._add(18, LABELS[18], _spans(_regex_list(NOT_X_JUST_Y_RX), view))
        # 19 filler phrases (advice)
        self._add(19, LABELS[19], _spans([_alt(FILLER_PHRASES)], view))
        # 20 empty pivot phrases
        self._add(20, LABELS[20], _spans(_regex_list(PIVOT_RX), view))
        # 21 outcome-speculation tails
        self._add(21, LABELS[21], _spans(_regex_list(OUTCOME_TAIL_RX), view))
        # 22 persuasive authority tropes (advice)
        self._add(22, LABELS[22], _spans([_alt(PERSUASIVE_PHRASES)], view))
        # 23 editorial interjections
        self._add(23, LABELS[23], _spans(_regex_list([
            r"\bit(?:[’']s| is) important to (?:remember|note|understand|recognize)\b",
            r'\bone must note that\b',
            r'\bit is worth pointing out\b',
            r'\bit cannot be overstated that\b',
            r'\bit must be emphasized that\b']), view))
        # 24 self-thoroughness phrases
        self._add(24, LABELS[24], _spans(_regex_list(SELF_THOROUGH_RX), view))
        # 25 question-answer rhetorical pattern
        self._add(25, LABELS[25], _spans(_regex_list(QA_RX), view))
        # 26 concrete evidence defence phrase
        self._add(26, LABELS[26], _spans(_regex_list(CONCRETE_EVIDENCE_RX), view))
        # 27 compulsive intro hooks
        self._add(27, LABELS[27], _spans(_regex_list(INTRO_HOOK_RX), view))
        # 30 diff-anchored writing
        self._add(30, LABELS[30], _spans(_regex_list(DIFF_ANCHOR_RX), view))
        # 31 signposting and announcements
        self._add(31, LABELS[31], _spans(_regex_list(SIGNPOST_RX), view))
        # 32 cataloguing lead-ins
        self._add(32, LABELS[32], _spans(_regex_list(CATALOGUE_LEAD_RX), view))
        # 33 inline-header vertical lists
        self._add(33, LABELS[33], _spans(_regex_list(INLINE_HEADER_RX), view))
        # 36 formulaic challenges
        self._add(36, LABELS[36], _spans(_regex_list(FORMULAIC_CHALLENGE_RX), view))
        # 38 compulsive conclusions (line start)
        self._add(38, LABELS[38], _spans(_regex_list(CONCLUSION_RX), view))
        # 39 generic positive conclusions
        self._add(39, LABELS[39], _spans(_regex_list(POSITIVE_CONCLUSION_RX), view))
        # 47 chatbot artifacts (decisive)
        self._add(47, LABELS[47], _spans([re.compile(p, RE_FLAGS) for p in CHATBOT_RX], view))
        # 48 sycophantic tone (decisive)
        self._add(48, LABELS[48], _spans(_regex_list(SYCOPHANCY_RX), view))
        # 50 knowledge-cutoff disclaimers (decisive)
        self._add(50, LABELS[50], _spans(_regex_list(CUTOFF_RX), view))
        # 51 copula avoidance
        self._add(51, LABELS[51], _spans(_regex_list(COPULA_RX), view))
        # 54 excessive hedging (advice): sentences with two or more hedges
        hedge_spans = []
        for s, e in self.sentences:
            hits = [(m.start(), m.end()) for m in HEDGE.finditer(view, s, e)]
            if len(hits) >= 2:
                hedge_spans.append((s, e))
        self._add(54, LABELS[54], hedge_spans)
        # 56 boldface overuse (heading lines excluded)
        nohead = '\n'.join(' ' * len(ln) if HEADING_LINE.match(ln) else ln
                           for ln in view.split('\n'))
        self._add(56, LABELS[56], _spans([re.compile(r'\*\*[^*\n]+\*\*')], nohead))
        # 57 emojis
        self._add(57, LABELS[57], _spans([EMOJI], view))
        # 60 curly quotation marks (advice)
        self._add(60, LABELS[60], _spans([re.compile('[‘’“”]')], view))
        # 61 hyphen-for-en-dash in year ranges (advice)
        self._add(61, LABELS[61], _spans([re.compile(r'\b(?:1\d{3}|2\d{3})-(?:1\d{3}|2\d{3})\b')], view))
        # 63 placeholder text (decisive)
        self._add(63, LABELS[63], _spans([re.compile(p, RE_FLAGS) for p in PLACEHOLDER_RX], view))
        # 64 chat reference markup (decisive)
        self._add(64, LABELS[64], _spans([re.compile(p, RE_FLAGS) for p in CHAT_MARKUP_RX], view))
        # 65 AI tracking parameters (decisive)
        utm = []
        for m in UTM_RX.finditer(view):
            host = m.group(1).rstrip('.').lower()
            if host in AI_TRACKING_HOSTS:
                utm.append((m.start(), m.end()))
        self._add(65, LABELS[65], utm)
        # 69 canonical marketing phrases
        self._add(69, LABELS[69], _spans(_regex_list(MARKETING_SLOP_RX), view))
        # 4/19/22 handled above; 40, 41, 42, 44 and others in _structural

    def _stacked_adjectives(self, view):
        item = r'[A-Za-z][A-Za-z\-]*'
        rx = re.compile(r'\b(%s),\s+(%s),\s+(%s),?\s+(?:(?:and|or)\s+)?(%s)\b' % (item, item, item, item))

        def is_adj(word):
            low = word.lower()
            return low in STOCK_ADJ or bool(ADJ_SUFFIX.search(low))

        spans = []
        for m in rx.finditer(view):
            items = [m.group(i) for i in range(1, 5)]
            if any(is_adj(x) for x in items[:3]) and not is_adj(items[3]) \
                    and items[3].lower() not in STOPWORDS:
                spans.append((m.start(), m.end()))
        return spans

    def _notability(self, view):
        spans = []
        outlet_rx = [re.compile(re.escape(o)) for o in NOTABILITY_OUTLETS]
        for m in NOTABILITY_CREDIT.finditer(view):
            sent_end = len(view)
            for ch_pos in range(m.end(), len(view)):
                if view[ch_pos] in '.!?\n':
                    sent_end = ch_pos
                    break
            window_text = view[m.end():sent_end]
            names = {o.pattern for o in outlet_rx if o.search(window_text)}
            if len(names) >= 2:
                spans.append((m.start(), m.end()))
        spans.extend((m.start(), m.end()) for m in NOTABILITY_FOLLOWERS.finditer(view))
        spans.extend(_spans(_regex_list(NOTABILITY_STOCK), view))
        return sorted(spans)

    def _structural(self, view, win, sent_words, para_words):
        # 40 sentence-length monotony (rhythm)
        if len(sent_words) >= 3:
            cv = coefficient_of_variation(sent_words)
            if cv is not None and cv < 0.35:
                self._add_doc(40, LABELS[40], 1)
        # 44 uniform paragraph length (rhythm)
        pw = [w for w in para_words if w > 0]
        if len(pw) >= 4:
            cv = coefficient_of_variation(pw)
            if cv is not None and cv < 0.4:
                self._add_doc(44, LABELS[44], 1)
        # 41 mechanical sentence-length alternation (advice)
        alt_spans = []
        i = 0
        L = sent_words
        while i + 5 < len(L):
            run_ok = True
            for k in range(5):
                d = L[i + k + 1] - L[i + k]
                if abs(d) < 4:
                    run_ok = False
                    break
                if k > 0:
                    prev = L[i + k] - L[i + k - 1]
                    if (prev > 0) == (d > 0):
                        run_ok = False
                        break
            if run_ok:
                s, _ = self.sentences[i]
                _, e = self.sentences[i + 5]
                alt_spans.append((s, e))
                i += 6
            else:
                i += 1
        self._add(41, LABELS[41], alt_spans)
        # 42 opener repetition, per paragraph (advice)
        opener_spans = []
        sent_starts = [s for s, _ in self.sentences]
        for ps, pe in self.paragraphs:
            lo_i = bisect.bisect_left(sent_starts, ps)
            hi_i = bisect.bisect_left(sent_starts, pe)
            sents = [(s, e) for s, e in self.sentences[lo_i:hi_i] if e <= pe]
            if len(sents) < 3:
                continue
            groups = {}
            for s, e in sents:
                words = WORD_RE.findall(view[s:e])
                if len(words) >= 2:
                    key = ' '.join(w.lower() for w in words[:2])
                    groups.setdefault(key, []).append((s, e))
            for key, members in groups.items():
                if len(members) >= 3:
                    opener_spans.extend(members)
        self._add(42, LABELS[42], sorted(opener_spans))
        # 34 mid-essay bullet injection
        if not re.search(r'^\s{0,3}#{1,6}\s', view, re.MULTILINE):
            list_pars = []
            prose_pars = 0
            for ps, pe in self.paragraphs:
                lines = [ln for ln in view[ps:pe].split('\n') if ln.strip()]
                if lines and all(LIST_LINE.match(ln) for ln in lines):
                    list_pars.append((ps, pe))
                elif lines:
                    prose_pars += 1
            if list_pars and prose_pars >= 2:
                self._add(34, LABELS[34], list_pars)
        # 35 fragmented headers
        frag = []
        lines = view.split('\n')
        offsets = []
        pos = 0
        for ln in lines:
            offsets.append(pos)
            pos += len(ln) + 1
        for idx, ln in enumerate(lines):
            m = HEADING_LINE.match(ln)
            if not m:
                continue
            head_words = {w.lower() for w in WORD_RE.findall(m.group(2))
                          if len(w) >= 4 and w.lower() not in STOPWORDS}
            j = idx + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j >= len(lines):
                continue
            nxt = lines[j].strip()
            if not nxt or nxt.startswith('#') or nxt.startswith('|') or LIST_LINE.match(lines[j]):
                continue
            nwords = WORD_RE.findall(nxt)
            if not nwords or len(nwords) > 5:
                continue
            if head_words and any(w.lower() in head_words for w in nwords):
                frag.append((offsets[j], offsets[j] + len(lines[j])))
        self._add(35, LABELS[35], frag)
        # 37 transition clusters, per paragraph (two or more openers)
        trans = []
        for ps, pe in self.paragraphs:
            hits = [(m.start(), m.end()) for m in TRANSITION_OPEN.finditer(view, ps, pe)]
            if len(hits) >= 2:
                trans.extend(hits)
        self._add(37, LABELS[37], trans)
        # 46 semicolon and parenthesis underuse (advice), long documents only
        if self.word_count >= 300 and ';' not in view and view.count('(') <= 1:
            self._add_doc(46, LABELS[46], 1)
        # 55 contraction absence (advice): first-person writing, contractable forms written out
        fp = len(FIRST_PERSON.findall(view))
        if self.word_count and fp >= 3 and fp / float(self.word_count) >= 0.02:
            written = len(WRITTEN_OUT.findall(view))
            contracted = len(CONTRACTED.findall(view))
            if written >= 2 and written > contracted:
                self._add_doc(55, LABELS[55], 1)
        # 58 em-dash overuse, per paragraph (advice)
        dash_spans = []
        for ps, pe in self.paragraphs:
            dashes = [(m.start(), m.end()) for m in re.finditer('—', view[ps:pe])]
            dashes = [(ps + s, ps + e) for s, e in dashes]
            if len(dashes) >= 2:
                dash_spans.extend(dashes)
        self._add(58, LABELS[58], dash_spans)
        # 59 title case in headings
        title_spans = []
        for m in re.finditer(r'^#{1,6}[ \t]+(.+)$', view, re.MULTILINE):
            text = m.group(1).strip()
            words = text.split()
            if len(words) < 3 or text.isupper() or not text[0].isalpha():
                continue
            majors = [w.strip('*_`"\'()[]:;,.!?') for w in words]
            majors = [w for w in majors if w and w.lower() not in SMALL_TITLE_WORDS]
            if len(majors) >= 2 and all(w[0].isupper() for w in majors):
                title_spans.append((m.start(1), m.end(1)))
        self._add(59, LABELS[59], title_spans)
        # 70 decorative horizontal rules
        lines = view.split('\n')
        if len(lines) >= 24:
            hr = []
            pos = 0
            for ln in lines:
                if re.match(r'^ {0,3}(?:-{3,}|\*{3,}|_{3,})\s*$', ln):
                    hr.append((pos, pos + len(ln)))
                pos += len(ln) + 1
            if len(hr) >= 3:
                self._add(70, LABELS[70], hr)
        # 71 degenerate repetition: six-word runs repeated across the document
        words = self.word_spans
        if len(words) >= 12:
            grams = {}
            vals = [view[s:e].lower() for s, e in words]
            for k in range(len(vals) - 5):
                key = tuple(vals[k:k + 6])
                grams.setdefault(key, []).append(k)
            total = len(vals) - 5
            repeated = [k for ks in grams.values() if len(ks) > 1 for k in ks]
            if repeated and len(repeated) / float(total) >= 0.2:
                spans = []
                for ks in grams.values():
                    if len(ks) > 1:
                        spans.append((words[ks[0]][0], words[ks[0]][1]))
                self._add(71, LABELS[71], spans)
        # 2 model dialect counted above; 43, 45, 49, 52, 53, 7, 9, 28, 29: no detector.

    # ---- metrics and scoring helpers

    def fam_counts(self, findings=None):
        counts = {}
        for f in (findings if findings is not None else self.findings):
            if f.moving:
                counts[f.family] = counts.get(f.family, 0) + f.count
        return counts


def _item_rx(text):
    return re.compile(_item(text), RE_FLAGS)


def confidence_for(words, n_families):
    """Confidence label and the reason shown when it is not high (FP-01)."""
    if words < 40:
        return 'none', 'only %d words; at least 40 are needed' % words
    if words < 120:
        return 'low', 'only %d words; at least 120 are needed' % words
    if words < 300 and n_families <= 1:
        return 'low', 'only one kind of pattern in %d words; at least 300 words or two kinds are needed' % words
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def _family_number(fam):
    return int(fam.rstrip('tp'))


def compute_score(fam_counts, decisive, words):
    """Score 0-100 and confidence from distinct score-moving families (FP-01)."""
    fams = set(fam_counts)
    n = len(fams)
    conf, _ = confidence_for(words, n)
    rank = {'none': 0, 'low': 1, 'moderate': 2, 'high': 3}[conf]
    base = sum(8 + min(c - 1, 6) * 2 for c in fam_counts.values()) if n else 0
    score = min(base, 100)
    if n == 1:
        (only,) = fams
        if only in decisive and rank > 1:
            score = max(score, 45)
        else:
            score = min(score, 40)
    if n and fams <= RHYTHM_MOVING:
        score = min(score, 20 if fams == {'40'} else 40)
    dec_n = len(fams & decisive)
    if dec_n >= 2:
        score = max(score, 65)
    if dec_n == 1 and rank > 1:
        score = max(score, 45)
    if words < 120:
        k = sum(1 for f in fams if _family_number(f) in SHORT_FLOOR_NUMBERS)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if words >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    return int(min(max(score, 0), 100)), conf


def band_for(score):
    for top, name, phrase in BANDS:
        if score <= top:
            return name, phrase
    return BANDS[-1][1], BANDS[-1][2]


def _interval(analysis, decisive, replicates=200, seed=0):
    sents = analysis.sentences
    if len(sents) < 4:
        return None, 'too few sentences for an interval (%d; need 4)' % len(sents)
    starts = [s for s, _ in sents]
    sent_words = [len(words_in(analysis.view[s:e])) for s, e in sents]
    per_sent = [dict() for _ in sents]
    fixed = {}
    for f in analysis.findings:
        if not f.moving:
            continue
        if f.starts is None:
            fixed[f.family] = fixed.get(f.family, 0) + f.count
            continue
        for st in f.starts:
            idx = bisect.bisect_right(starts, st) - 1
            if idx < 0:
                continue
            per_sent[idx][f.family] = per_sent[idx].get(f.family, 0) + 1
    rng = random.Random(seed)
    n = len(sents)
    scores = []
    for _ in range(replicates):
        counts = dict(fixed)
        words = 0
        for _k in range(n):
            idx = rng.randrange(n)
            words += sent_words[idx]
            for fam, c in per_sent[idx].items():
                counts[fam] = counts.get(fam, 0) + c
        sc, _ = compute_score(counts, decisive, words)
        scores.append(sc)
    scores.sort()
    lo = scores[int(0.025 * (len(scores) - 1))]
    hi = scores[int(round(0.975 * (len(scores) - 1)))]
    if lo > hi:
        lo, hi = hi, lo
    note = 'low and high of %d resampled replicates over %d sentences (seed 0)' % (replicates, n)
    return [lo, hi], note


def analyze(prose, want_ci=False):
    """Full report dictionary for extracted prose."""
    a = Analysis(prose)
    fam_counts = a.fam_counts()
    fam_decisive = {f.family for f in a.findings if f.moving and f.decisive}
    score, conf = compute_score(fam_counts, fam_decisive, a.word_count)
    _, reason = confidence_for(a.word_count, len(fam_counts))
    band, phrase = band_for(score)
    report = {}
    for f in sorted(a.findings, key=lambda x: (x.num, x.slug)):
        report[f.key] = {'label': f.label, 'count': f.count, 'samples': f.samples[:3]}
    flagged = [f.label for f in sorted(a.findings, key=lambda x: (x.num, x.slug)) if f.moving]
    metrics = {
        'scanned_chars': len(a.window),
        'truncated': a.truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'ai_tell_hook_phrase': phrase,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(a.findings),
        'invisible_chars': len(a.invisible),
        'nonstandard_spaces': len(a.nonstd),
        'homoglyphs': a.homoglyph_count,
        'words': a.word_count,
        'sentences': len(a.sentences),
        'flagged_labels': flagged,
    }
    if want_ci:
        ci, note = _interval(a, {str(n) for n in DECISIVE})
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------


def _error(message, status):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.stderr.flush()
    return status


def _write_out(data):
    sys.stdout.buffer.write(data)
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    end_of_options = False
    for arg in argv:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_options = True
            continue
        if arg in ('-h', '--help'):
            _write_out((USAGE).encode('utf-8'))
            return EXIT_OK
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            ci = True
            continue
        if arg.startswith('-'):
            return _error("unknown option '%s'; see --help" % arg, EXIT_UNKNOWN_OPTION)
        operands.append(arg)

    if len(operands) > 1:
        sys.stderr.write("detect.py: note: scanned only the first file, %s; the other files were not scanned\n"
                         % operands[0])
        sys.stderr.flush()

    try:
        if operands:
            prose = extract_path(operands[0])
        else:
            data = sys.stdin.buffer.read()
            prose = decode_plain(data)
    except CannotRead as exc:
        return _error(str(exc), EXIT_EMPTY_OR_UNREADABLE)

    if not prose.strip():
        return _error('empty input', EXIT_EMPTY_OR_UNREADABLE)

    if clean:
        _write_out(scrub(prose).encode('utf-8'))
        return EXIT_OK

    report = analyze(prose, want_ci=ci)
    payload = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    _write_out(payload.encode('utf-8'))
    return EXIT_OK


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
