"""Tests for scripts/detect.py. Run: python3 -m unittest discover -s /app/tests -v"""
import importlib.util
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
DETECT = os.path.join(os.path.dirname(HERE), 'scripts', 'detect.py')

_spec = importlib.util.spec_from_file_location('detect', DETECT)
detect = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(detect)


def run_cli(args, stdin=b''):
    proc = subprocess.run([sys.executable, '-I', DETECT] + args, input=stdin,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return proc.returncode, proc.stdout, proc.stderr.decode('utf-8', 'replace')


HUMAN = (
    "We rewrote the parser last week. It was slow on large files, so Maria profiled it and found "
    "two hot loops. The fix was boring: we stopped copying the buffer on every line.\n\n"
    "The results surprised us. Parse time dropped from about nine seconds to under two. I don't "
    "think we would have found it without the profiler, and I'm not sure the team would have "
    "trusted a guess.\n\n"
    "Next we want to check memory. If the numbers hold, we'll ship it on Friday; if not, we roll "
    "back and try again. Either way the notes go in the wiki.\n"
)

AI = (
    "# Unlocking the Power of Modern Tooling\n\n"
    "In today's fast-paced world, it is crucial to delve into the tapestry of modern development. "
    "Additionally, this comprehensive guide will navigate the landscape of robust, seamless, and "
    "innovative solutions.\n\n"
    "Furthermore, the team leverages a multifaceted approach to foster collaboration. Moreover, it "
    "is worth noting that the platform serves as a testament to the power of community.\n\n"
    "Notably, the results underscore its pivotal role. It's not just a tool, it's a game-changer. "
    "In conclusion, the future looks bright.\n\n"
    "Let's dive in. Here's the thing: this journey is vibrant, genuinely fascinating, and deeply "
    "human. I hope this helps!\n"
)


class ReportShape(unittest.TestCase):
    def test_report_members_and_metrics(self):
        report = detect.analyze(AI)
        metrics = report['_metrics']
        for name in ('scanned_chars', 'truncated', 'ai_tell_score', 'ai_tell_band', 'confidence',
                     'confidence_reason', 'patterns_flagged', 'invisible_chars',
                     'nonstandard_spaces', 'homoglyphs'):
            self.assertIn(name, metrics)
        self.assertNotIn('score_ci', metrics)  # only with --ci
        for key, member in report.items():
            if key == '_metrics':
                continue
            self.assertRegex(key, r'^\d+_\S+$')
            self.assertIsInstance(member['count'], int)
            self.assertLessEqual(len(member['samples']), 3)

    def test_human_prose_scores_clean(self):
        metrics = detect.analyze(HUMAN)['_metrics']
        self.assertLessEqual(metrics['ai_tell_score'], 20)
        self.assertEqual(metrics['ai_tell_band'], 'clean')

    def test_ai_prose_scores_high_and_names_catalogue_keys(self):
        report = detect.analyze(AI)
        self.assertGreaterEqual(report['_metrics']['ai_tell_score'], 61)
        self.assertIn('1_ai_vocabulary', report)
        self.assertIn('47_chatbot_artifacts', report)

    def test_seventeen_has_two_fixed_keys(self):
        report = detect.analyze("It's not just about speed. It's not only fast but also kind. "
                                "The shop is open, no waste, no hassle.")
        self.assertIn('17_negative_parallelism', report)
        self.assertIn('17_tailing_negation', report)

    def test_bands(self):
        self.assertEqual(detect.band_for(0)[0], 'clean')
        self.assertEqual(detect.band_for(21)[0], 'light tells')
        self.assertEqual(detect.band_for(41)[0], 'mixed')
        self.assertEqual(detect.band_for(61)[0], 'heavy tells')
        self.assertEqual(detect.band_for(81)[0], 'pervasive tells')

    def test_confidence_bands(self):
        self.assertEqual(detect.confidence_for(39, 3)[0], 'none')
        self.assertEqual(detect.confidence_for(100, 3)[0], 'low')
        self.assertEqual(detect.confidence_for(200, 1)[0], 'low')
        self.assertEqual(detect.confidence_for(200, 2)[0], 'moderate')
        self.assertEqual(detect.confidence_for(300, 1)[0], 'high')


class ScoreRules(unittest.TestCase):
    def test_single_family_caps_at_forty(self):
        score, _ = detect.compute_score({'1': 50}, set(), 500)
        self.assertLessEqual(score, 40)

    def test_single_decisive_family_floor_needs_confidence_above_low(self):
        score, conf = detect.compute_score({'47': 1}, {'47'}, 500)
        self.assertEqual(conf, 'high')
        self.assertGreaterEqual(score, 45)
        score_low, conf_low = detect.compute_score({'47': 1}, {'47'}, 60)
        self.assertEqual(conf_low, 'low')
        self.assertLessEqual(score_low, 40)

    def test_two_decisive_families_floor_sixty_five(self):
        score, _ = detect.compute_score({'47': 1, '50': 1}, {'47', '50'}, 500)
        self.assertGreaterEqual(score, 65)

    def test_monotony_only_is_clean(self):
        score, _ = detect.compute_score({'40': 1}, set(), 500)
        self.assertLessEqual(score, 20)

    def test_rhythm_only_caps_at_forty(self):
        score, _ = detect.compute_score({'40': 1, '44': 1}, set(), 500)
        self.assertLessEqual(score, 40)

    def test_short_document_floors(self):
        two, _ = detect.compute_score({'1': 1, '2': 2}, set(), 100)
        self.assertGreaterEqual(two, 25)
        three, _ = detect.compute_score({'1': 1, '2': 1, '3': 1}, set(), 100)
        self.assertGreaterEqual(three, 45)

    def test_long_document_floors(self):
        five = {str(n): 1 for n in (1, 2, 3, 4, 5)}
        five_score, _ = detect.compute_score(five, set(), 500)
        self.assertGreaterEqual(five_score, 25)


class CharacterLayer(unittest.TestCase):
    """AC N-000305 / N-000309: after cleanup, a rescan reports zero character-layer hits."""

    SAMPLE = ("Hello​ world, this is a test­ ok.  \n"
              "Price is 10 % more and a b here　x.   \n"
              "Cyrаnd here: pаssword and оi\n"
              "tab\there⁠and word joiner﻿ end   ")

    def test_N_000305_cleanup_removes_invisible_characters(self):
        self.assertGreater(detect.analyze(self.SAMPLE)['_metrics']['invisible_chars'], 0)
        cleaned = detect.scrub(self.SAMPLE)
        self.assertEqual(detect.analyze(cleaned)['_metrics']['invisible_chars'], 0)

    def test_N_000309_cleanup_normalises_non_standard_spaces(self):
        self.assertGreater(detect.analyze(self.SAMPLE)['_metrics']['nonstandard_spaces'], 0)
        cleaned = detect.scrub(self.SAMPLE)
        self.assertEqual(detect.analyze(cleaned)['_metrics']['nonstandard_spaces'], 0)

    def test_cleanup_keeps_nbsp_before_percent_and_folds_lookalikes(self):
        cleaned = detect.scrub(self.SAMPLE)
        self.assertIn('10 %', cleaned)
        self.assertIn('password', cleaned)
        self.assertNotIn('​', cleaned)

    def test_cleanup_trims_trailing_whitespace_and_keeps_one_final_newline(self):
        self.assertEqual(detect.scrub('a  \nb\t\n\n\n'), 'a\nb\n')
        self.assertEqual(detect.scrub('a\n'), 'a\n')

    def test_cleanup_keeps_zwj_between_devanagari(self):
        text = 'ह‍ष'
        self.assertEqual(detect.scrub(text), text)

    def test_codes_and_quotes_produce_no_findings(self):
        text = "Intro text here.\n\n```\nlet x = 'delve' ​\n```\n\nSome `delve` inline.\n"
        report = detect.analyze(text)
        self.assertEqual([k for k in report if k != '_metrics'], [])


class Extraction(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def _zip(self, name, files):
        path = os.path.join(self.tmp, name)
        with zipfile.ZipFile(path, 'w') as zf:
            for member, data in files.items():
                zf.writestr(member, data)
        return path

    def test_docx_paragraphs(self):
        body = ('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                '<w:body><w:p><w:r><w:t>Hello &amp; welcome.</w:t></w:r></w:p></w:body></w:document>')
        path = self._zip('a.docx', {'word/document.xml': body})
        self.assertEqual(detect.extract_path(path), 'Hello & welcome.')

    def test_notebook_markdown_cells_only(self):
        nb = {'cells': [{'cell_type': 'markdown', 'source': ['# Title\n', 'Prose.']},
                        {'cell_type': 'code', 'source': ["print('code')"]}]}
        path = os.path.join(self.tmp, 'n.ipynb')
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(nb, fh)
        prose = detect.extract_path(path)
        self.assertIn('Prose.', prose)
        self.assertNotIn('print', prose)
        self.assertFalse(prose.startswith((' ', '\n')))

    def test_epub_skips_script_and_nav(self):
        files = {
            'META-INF/container.xml': '<container><rootfiles><rootfile full-path="OEBPS/c.opf"/></rootfiles></container>',
            'OEBPS/c.opf': '<package><manifest><item id="c1" href="ch1.xhtml"/><item id="nav" href="nav.xhtml" properties="nav"/></manifest><spine><itemref idref="c1"/></spine></package>',
            'OEBPS/ch1.xhtml': '<html><head><style>p{}</style></head><body><p>Chapter <em>one</em>.</p><script>var x;</script></body></html>',
            'OEBPS/nav.xhtml': '<html><body><p>NAVTEXT</p></body></html>',
        }
        path = self._zip('b.epub', files)
        prose = detect.extract_path(path)
        self.assertIn('Chapter one.', prose)
        self.assertNotIn('NAVTEXT', prose)
        self.assertNotIn('var x', prose)

    def test_utf16_bom_plain_text(self):
        path = os.path.join(self.tmp, 'u.txt')
        with open(path, 'wb') as fh:
            fh.write('UTF16 body text here.'.encode('utf-16'))
        self.assertEqual(detect.extract_path(path), 'UTF16 body text here.')

    def test_bad_zip_is_cannot_read(self):
        path = os.path.join(self.tmp, 'bad.docx')
        with open(path, 'wb') as fh:
            fh.write(b'not a zip')
        with self.assertRaises(detect.CannotRead):
            detect.extract_path(path)

    def test_pdf_has_no_prose(self):
        path = os.path.join(self.tmp, 'a.pdf')
        with open(path, 'wb') as fh:
            fh.write(b'%PDF-1.4')
        self.assertEqual(detect.extract_path(path), '')


class CommandLine(unittest.TestCase):
    def test_help_is_stdout_and_exit_zero(self):
        code, out, _ = run_cli(['--help'])
        self.assertEqual(code, 0)
        self.assertEqual(out.decode('utf-8').splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_unknown_option_exit_two(self):
        code, out, err = run_cli(['--nope'])
        self.assertEqual(code, 2)
        self.assertEqual(out, b'')
        error = json.loads(err.strip().splitlines()[-1])['error']
        self.assertIn('unknown option', error)
        self.assertIn("'--nope'", error)
        self.assertIn('--help', error)

    def test_empty_stdin_exit_one(self):
        code, out, err = run_cli([], stdin=b'  \n')
        self.assertEqual(code, 1)
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unreadable_path_exit_one(self):
        code, _, err = run_cli(['/definitely/not/here.md'])
        self.assertEqual(code, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_clean_prints_text_and_exit_zero(self):
        code, out, _ = run_cli(['--clean'], stdin='Hello​ world.   \n'.encode('utf-8'))
        self.assertEqual(code, 0)
        self.assertEqual(out.decode('utf-8'), 'Hello world.\n')

    def test_two_files_scans_first_and_notes_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            first = os.path.join(tmp, 'first.md')
            second = os.path.join(tmp, 'second.md')
            with open(first, 'w', encoding='utf-8') as fh:
                fh.write(HUMAN)
            with open(second, 'w', encoding='utf-8') as fh:
                fh.write(AI)
            code, out, err = run_cli([first, second])
            self.assertEqual(code, 0)
            self.assertIn(first, err)
            self.assertEqual(json.loads(out)['_metrics']['ai_tell_score'],
                             detect.analyze(HUMAN)['_metrics']['ai_tell_score'])

    def test_ci_interval_and_null_for_short_text(self):
        code, out, _ = run_cli(['--ci'], stdin=AI.encode('utf-8'))
        metrics = json.loads(out)['_metrics']
        self.assertEqual(code, 0)
        low, high = metrics['score_ci']
        self.assertLessEqual(low, high)
        code, out, _ = run_cli(['--ci'], stdin=b'One short sentence only.')
        metrics = json.loads(out)['_metrics']
        self.assertIsNone(metrics['score_ci'])
        self.assertIn('too few sentences', metrics['score_ci_note'])


class Window(unittest.TestCase):
    def test_truncation_and_window_size(self):
        text = 'word ' * 60000  # 300,000 characters
        metrics = detect.analyze(text)['_metrics']
        self.assertTrue(metrics['truncated'])
        self.assertEqual(metrics['scanned_chars'], detect.SCAN_WINDOW)

    def test_exactly_window_is_not_truncated(self):
        text = 'a' * detect.SCAN_WINDOW
        self.assertFalse(detect.analyze(text)['_metrics']['truncated'])

    def test_character_past_window_is_not_a_finding(self):
        text = 'Plain words here. ' * 15000 + '​'
        metrics = detect.analyze(text)['_metrics']
        self.assertEqual(metrics['invisible_chars'], 0)


if __name__ == '__main__':
    unittest.main()
