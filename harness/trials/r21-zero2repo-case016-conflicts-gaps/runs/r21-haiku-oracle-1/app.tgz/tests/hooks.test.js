'use strict';
// Tests for the prosecheck hooks. Run: node --test /app/tests/hooks.test.js
// Each hook runs as a separate process, as the host runs it.

const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const HOOKS = path.resolve(__dirname, '..', 'hooks');
const AI_TEXT = 'In today\'s fast-paced world, it is crucial to delve into the tapestry of modern development. ' +
  'Additionally, this comprehensive guide will navigate the landscape of robust, seamless, and innovative solutions. ' +
  'Furthermore, the team leverages a multifaceted approach to foster collaboration. Moreover, the platform serves as ' +
  'a testament to the power of community. Notably, the results underscore its pivotal role. It\'s not just a tool, ' +
  "it's a game-changer. In conclusion, the future looks bright. I hope this helps!\n";

function freshDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function runHook(name, payload, env) {
  const res = spawnSync(process.execPath, [path.join(HOOKS, name)], {
    input: payload === undefined ? '' : JSON.stringify(payload),
    encoding: 'utf8',
    env: Object.assign({}, process.env, env),
    timeout: 60000,
  });
  return { status: res.status, stdout: res.stdout, stderr: res.stderr };
}

function prompt(text, env, extra) {
  const payload = Object.assign({ prompt: text, session_id: 'sess-1' }, extra || {});
  const res = runHook('prosecheck-tracker.js', payload, env);
  assert.strictEqual(res.status, 0);
  return res.stdout.trim() ? JSON.parse(res.stdout) : null;
}

function reasonOf(text, env, extra) {
  const out = prompt(text, env, extra);
  assert.ok(out && out.decision === 'block', 'expected a block decision for ' + text);
  return out.reason;
}

test('session start: welcome once, then contract only', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const first = runHook('prosecheck-activate.js', {}, env);
  assert.strictEqual(first.status, 0);
  assert.match(first.stdout, /prosecheck is installed and on/);
  assert.match(first.stdout, /71 documented patterns/);
  assert.match(first.stdout, /512 KB/);
  assert.match(first.stdout, /262,144 characters/);
  assert.strictEqual(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'full');
  const second = runHook('prosecheck-activate.js', {}, env);
  assert.doesNotMatch(second.stdout, /installed and on/);
  assert.match(second.stdout, /Writing contract/);
});

test('off prints nothing from session start, subagent start, and prompt reminders', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  reasonOf('/prosecheck off', env);
  assert.strictEqual(runHook('prosecheck-activate.js', {}, env).stdout, '');
  assert.strictEqual(runHook('prosecheck-subagent.js', {}, env).stdout, '');
  assert.strictEqual(prompt('hello there', env), null);
});

test('subagent start returns the contract in the JSON envelope', () => {
  const cfg = freshDir('pc-cfg-');
  const out = JSON.parse(runHook('prosecheck-subagent.js', {}, { CLAUDE_CONFIG_DIR: cfg }).stdout);
  assert.strictEqual(out.hookSpecificOutput.hookEventName, 'SubagentStart');
  assert.match(out.hookSpecificOutput.additionalContext, /never name prosecheck/);
});

test('strict and lite contract shape', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  reasonOf('/prosecheck strict', env);
  const strict = JSON.parse(runHook('prosecheck-subagent.js', {}, env).stdout).hookSpecificOutput.additionalContext;
  assert.match(strict, /--clean/);
  assert.match(strict, /\b20\b/);
  reasonOf('/prosecheck lite', env);
  const lite = JSON.parse(runHook('prosecheck-subagent.js', {}, env).stdout).hookSpecificOutput.additionalContext;
  assert.doesNotMatch(lite, /\b40\b/);
  assert.doesNotMatch(lite, /light tells/);
});

test('command router: status, unknown word, help, namespaced form', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  assert.strictEqual(reasonOf('/prosecheck:prosecheck status', env), 'prosecheck level: full');
  const unknown = reasonOf('/prosecheck flarp', env);
  assert.match(unknown, /unknown/);
  assert.match(unknown, /flarp/);
  assert.strictEqual(reasonOf('/prosecheck status', env), 'prosecheck level: full');
  const help = reasonOf('/prosecheck', env);
  assert.match(help.split('\n').find((l) => l.trim()), /full/);
  assert.ok(!help.split('\n').some((l) => l.startsWith('/prosecheck help')));
  for (const word of ['lite', 'full', 'strict', 'status', 'show', 'check', 'doctor', 'stats', 'init']) {
    assert.match(help, new RegExp('/prosecheck ' + word + '\\b'));
  }
  assert.match(help, /\/prosecheck off \| on/);
});

test('stop phrase stores off only for the entire prompt', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  assert.match(reasonOf('Stop Prosecheck', env), /off/);
  assert.strictEqual(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'off');
  reasonOf('/prosecheck on', env);
  const ordinary = prompt('please stop prosecheck now', env);
  assert.ok(ordinary && ordinary.hookSpecificOutput, 'ordinary prompt keeps the reminder');
  assert.strictEqual(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'full');
});

test('doctor: four check lines, closers by state', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const reply = reasonOf('/prosecheck doctor', env);
  const body = reply.split('\n').filter((l) => l.trim());
  assert.strictEqual(body[0], 'prosecheck doctor');
  assert.strictEqual((reply.match(/\[OK\]/g) || []).length, 4);
  assert.match(body[body.length - 1], /512 KB/);
  assert.match(body[body.length - 1], /\/prosecheck show/);
  reasonOf('/prosecheck off', env);
  const off = reasonOf('/prosecheck doctor', env);
  assert.match(off, /\/prosecheck on/);
  assert.match(off, /scored/);
  assert.doesNotMatch(off, /\/prosecheck doctor/);
});

test('doctor without python: python line says python not found and not re-scored', () => {
  const cfg = freshDir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg, PATH: '/nonexistent-bin' };
  const payload = { prompt: '/prosecheck doctor', session_id: 's' };
  const res = spawnSync(process.execPath, [path.join(HOOKS, 'prosecheck-tracker.js')], {
    input: JSON.stringify(payload), encoding: 'utf8', env: Object.assign({}, process.env, env),
  });
  const reason = JSON.parse(res.stdout).reason;
  const pyLine = reason.split('\n').find((l) => /^python:/.test(l));
  assert.match(pyLine, /python not found/);
  assert.match(pyLine, /not re-scored/);
  assert.match(pyLine, /prose/);
  assert.doesNotMatch(pyLine, /\[OK\]/);
});

test('check: report-only summary with coverage and tells', () => {
  const cfg = freshDir('pc-cfg-');
  const proj = freshDir('pc-proj-');
  const file = path.join(proj, 'draft.md');
  fs.writeFileSync(file, AI_TEXT);
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const reply = reasonOf('/prosecheck check "draft.md"', env, { cwd: proj });
  assert.match(reply, /^draft\.md - /);
  assert.match(reply, /score \d+\/100, band: /);
  assert.match(reply, /report only/);
  assert.match(reply, /tells: /);
  assert.strictEqual(fs.readFileSync(file, 'utf8'), AI_TEXT);
  assert.match(reasonOf('/prosecheck check missing.md', env, { cwd: proj }), /cannot read/);
  assert.match(reasonOf('/prosecheck check ' + proj, env, { cwd: proj }), /not a file/);
});

test('post-tool-use guard nudges flagged prose and records the ledger', () => {
  const cfg = freshDir('pc-cfg-');
  const proj = freshDir('pc-proj-');
  fs.writeFileSync(path.join(proj, 'ai.md'), AI_TEXT);
  fs.writeFileSync(path.join(proj, 'CLAUDE.md'), AI_TEXT);
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const payload = { tool_name: 'Write', tool_input: { file_path: 'ai.md' }, cwd: proj, session_id: 'g1' };
  const res = runHook('prosecheck-guard.js', payload, env);
  assert.strictEqual(res.status, 0);
  const ctx = JSON.parse(res.stdout).hookSpecificOutput.additionalContext;
  assert.match(ctx, /^prosecheck: ai\.md /);
  assert.match(ctx, /Fix the flagged spans/);
  // instruction files are skipped and not recorded
  const skipped = runHook('prosecheck-guard.js', Object.assign({}, payload, { tool_input: { file_path: 'CLAUDE.md' } }), env);
  assert.strictEqual(skipped.stdout, '');
  const show = reasonOf('/prosecheck show', env, { session_id: 'g1' });
  assert.match(show, /^ai\.md - /m);
  assert.doesNotMatch(show, /CLAUDE\.md/);
  assert.strictEqual(reasonOf('/prosecheck show', env, { session_id: 'other' }).split('\n')[0].indexOf('nothing scored yet'), 0);
});

test('post-tool-use guard handles apply_patch paths and binary formats', () => {
  const cfg = freshDir('pc-cfg-');
  const proj = freshDir('pc-proj-');
  fs.writeFileSync(path.join(proj, 'ai.md'), AI_TEXT);
  fs.writeFileSync(path.join(proj, 'a.pdf'), '%PDF-1.4');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const patch = '*** Begin Patch\n*** Update File: ai.md\n@@\n-x\n+y\n*** Move to: a.pdf\n*** End Patch';
  const res = runHook('prosecheck-guard.js', { tool_name: 'apply_patch', tool_input: { command: patch }, cwd: proj, session_id: 'p1' }, env);
  assert.match(JSON.parse(res.stdout).hookSpecificOutput.additionalContext, /ai\.md/);
  const show = reasonOf('/prosecheck show', env, { session_id: 'p1' });
  assert.match(show, /a\.pdf - not re-scored/);
});

test('hooks exit zero on malformed input', () => {
  const cfg = freshDir('pc-cfg-');
  const res = spawnSync(process.execPath, [path.join(HOOKS, 'prosecheck-guard.js')], {
    input: '{not json', encoding: 'utf8', env: Object.assign({}, process.env, { CLAUDE_CONFIG_DIR: cfg }),
  });
  assert.strictEqual(res.status, 0);
  for (const name of ['prosecheck-activate.js', 'prosecheck-subagent.js', 'prosecheck-tracker.js', 'prosecheck-stats.js']) {
    const r = spawnSync(process.execPath, [path.join(HOOKS, name)], {
      input: '[]', encoding: 'utf8', env: Object.assign({}, process.env, { CLAUDE_CONFIG_DIR: cfg }),
    });
    assert.strictEqual(r.status, 0, name);
  }
});

test('stats reads the named transcript and counts unique assistant messages', () => {
  const cfg = freshDir('pc-cfg-');
  const tr = path.join(freshDir('pc-tr-'), 't.jsonl');
  const lines = [
    { type: 'user', message: { content: 'hi' } },
    { type: 'assistant', message: { id: 'm1', usage: { output_tokens: 10, cache_read_input_tokens: 500 }, content: [{ type: 'text', text: 'Short.' }] } },
    { type: 'assistant', message: { id: 'm1', usage: { output_tokens: 12, cache_read_input_tokens: 500 }, content: [{ type: 'text', text: 'Again.' }] } },
    { type: 'assistant', message: { id: 'm2', usage: { output_tokens: 7, cache_read_input_tokens: 100 }, content: [{ type: 'tool_use' }] } },
  ];
  fs.writeFileSync(tr, lines.map((l) => JSON.stringify(l)).join('\n'));
  const reply = reasonOf('/prosecheck stats', { CLAUDE_CONFIG_DIR: cfg }, { transcript_path: tr });
  assert.match(reply, /assistant turns: 2/);
  assert.match(reply, /output tokens: 19/);
  assert.match(reply, /cache-read input tokens: 600/);
  assert.match(reply, /level: full/);
  assert.doesNotMatch(reply, /session prose ai_tell_score/);
});

test('init writes AGENTS.md once and the Cursor rule when absent', () => {
  const cfg = freshDir('pc-cfg-');
  const proj = freshDir('pc-proj-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const first = reasonOf('/prosecheck init', env, { cwd: proj });
  assert.match(first, /Wrote the writing contract to AGENTS\.md/);
  const agents = fs.readFileSync(path.join(proj, 'AGENTS.md'), 'utf8');
  assert.strictEqual(agents.split('Writing contract for prose deliverables').length - 1, 1);
  assert.doesNotMatch(agents, new RegExp(os.homedir().replace(/[/\\]/g, '\\$&')));
  assert.ok(fs.existsSync(path.join(proj, '.cursor', 'rules', 'prosecheck.mdc')));
  const again = reasonOf('/prosecheck init', env, { cwd: proj });
  assert.match(again, /already/);
  assert.match(again, /AGENTS\.md/);
  assert.match(again, /prosecheck\.mdc already exists/);
  const rule = fs.readFileSync(path.join(proj, '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
  assert.match(rule, /globs: \*\.md,\*\.mdx,\*\.markdown,\*\.txt,\*\.rst,\*\.tex,\*\.org,\*\.adoc/);
  assert.doesNotMatch(rule, /detect/);
});

test('init when off writes nothing', () => {
  const cfg = freshDir('pc-cfg-');
  const proj = freshDir('pc-proj-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  reasonOf('/prosecheck off', env);
  const reply = reasonOf('/prosecheck:prosecheck init', env, { cwd: proj });
  assert.match(reply, /switched off/);
  assert.match(reply, /\/prosecheck:prosecheck on/);
  assert.ok(!fs.existsSync(path.join(proj, 'AGENTS.md')));
});
