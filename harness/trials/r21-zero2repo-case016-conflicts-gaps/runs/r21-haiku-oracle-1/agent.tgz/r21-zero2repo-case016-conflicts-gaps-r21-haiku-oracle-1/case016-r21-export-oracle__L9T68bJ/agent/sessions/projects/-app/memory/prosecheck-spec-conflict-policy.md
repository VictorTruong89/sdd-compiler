---
name: prosecheck-spec-conflict-policy
description: "How the prosecheck build resolved the 23 unsettled spec contradictions in /app/spec; read before changing scoring, ledger, stats, or stop-phrase behavior."
metadata:
  node_type: memory
  type: project
  originSessionId: 7571fd7c-a98e-4983-bc8d-d7ece8754e58
  modified: 2026-11-06T06:49:46.129Z
---

The prosecheck spec in /app/spec was built from scratch into /app (detector in scripts/detect.py, Node hooks in hooks/, tests in tests/, decisions in NOTES.md).

**Why:** the export was made with --allow-open, so 23 contradictions have no human verdict. Any follow-up change to behavior should keep the same choices unless the user says otherwise.

**How to apply:**
- Policy: PRD packs (Full_PRD) govern behavior; Interface_Contract packs govern output shape. Where both are explicit, take the more specific statement.
- Chosen sides (full list with quotes in /app/NOTES.md): ledger keeps newest 20; NBSP kept beside digits and before : ; ! ? » › % € or after « ‹; help goes to stdout; decisive single family reaches 45 only at moderate/high confidence; stop phrase only when it is the entire prompt; named transcript beats newer; trailing two-space hard break is removed; utm_source only for seven AI hosts; first file scanned when several operands; two transitions per paragraph; hedge stacking is weight zero; apply_patch scores up to 16 paths; ledgers age out after 7 days; env default mode applies only when nothing valid is stored; session-prose score needs more than 200 characters; catalogue 17 tailing negation is score-moving, parallelism is weight zero.
- The detector's base score formula is my own (the spec gives only caps and floors).
- Tests: `python3 -m unittest discover -s /app/tests -t /app/tests` and `node --test /app/tests/hooks.test.js`.
