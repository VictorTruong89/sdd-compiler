#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic AI-writing pattern scanner.

Standard library only. No network, no model, no random component in the
default scan (the --ci interval uses a fixed seed).

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import sys
import os
import re
import io
import json
import math
import random
import codecs
import zipfile
import posixpath
import unicodedata
from collections import Counter
from urllib.parse import unquote
from xml.etree import ElementTree as ET
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024
ZIP_MEMBER_CAP = 64 * 1024 * 1024

PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXTS = frozenset(['.ipynb'])
NO_PROSE_EXTS = frozenset(['.pdf', '.rtf'])

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan FILE, or standard input when no FILE is given, for AI-writing patterns.
Prints one JSON object (findings plus _metrics) on standard output.

  --clean      print the scrubbed text instead of the report: invisible
               characters removed, non-standard spaces normalised, mixed-script
               lookalikes folded, trailing whitespace trimmed
  --ci         add a low/high interval on the score (needs four or more sentences)
  --           end option parsing, so FILE may begin with a dash
  -h, --help   print this message

Formats: .md .mdx .markdown .txt .text .rst .tex .org .adoc
         .docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub .ipynb
Only the first 262,144 characters of extracted prose are scanned.
"""


def fail(message, code):
    sys.stderr.write(json.dumps({"error": message}, ensure_ascii=True) + "\n")
    sys.stderr.flush()
    sys.exit(code)


# ---------------------------------------------------------------- loading

def decode_plain(data):
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode('utf-8', 'replace')
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        return data.decode('utf-16', 'replace')
    return data.decode('utf-8', 'replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _read_member(zf, name):
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > ZIP_MEMBER_CAP:
        return None
    try:
        return zf.read(name)
    except (zipfile.BadZipFile, OSError, RuntimeError, ValueError):
        return None


def _xml(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _para_text(el):
    parts = []
    for x in el.iter():
        t = _local(x.tag)
        if t in ('t', 'text'):
            parts.append(x.text or '')
        elif t == 'tab':
            parts.append('\t')
        elif t in ('br', 'cr'):
            parts.append('\n')
    return ''.join(parts)


def _docx_text(zf):
    root = _xml(_read_member(zf, 'word/document.xml'))
    if root is None:
        return ''
    paras = [_para_text(el) for el in root.iter() if _local(el.tag) == 'p']
    return '\n'.join(p for p in paras if p.strip())


def _pptx_text(zf):
    names = []
    for n in zf.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m:
            names.append((int(m.group(1)), n))
    names.sort()
    slides = []
    for _, n in names:
        root = _xml(_read_member(zf, n))
        if root is None:
            continue
        paras = [_para_text(el) for el in root.iter() if _local(el.tag) == 'p']
        slides.append('\n'.join(p for p in paras if p.strip()))
    return '\n'.join(s for s in slides if s.strip())


def _xlsx_sheet_paths(zf):
    rels = _xml(_read_member(zf, 'xl/_rels/workbook.xml.rels'))
    targets = {}
    if rels is not None:
        for r in rels.iter():
            if _local(r.tag) == 'Relationship':
                targets[r.get('Id')] = r.get('Target')
    wb = _xml(_read_member(zf, 'xl/workbook.xml'))
    ordered = []
    if wb is not None:
        for s in wb.iter():
            if _local(s.tag) != 'sheet':
                continue
            rid = None
            for k, v in s.attrib.items():
                if k == 'r:id' or k.endswith('}id'):
                    rid = v
            tgt = targets.get(rid)
            if not tgt:
                continue
            if tgt.startswith('/'):
                ordered.append(tgt.lstrip('/'))
            else:
                ordered.append(posixpath.normpath(posixpath.join('xl', tgt)))
    if ordered:
        return ordered
    found = []
    for n in zf.namelist():
        m = re.match(r'xl/worksheets/sheet(\d+)\.xml$', n)
        if m:
            found.append((int(m.group(1)), n))
    return [n for _, n in sorted(found)]


def _child_text(el, name):
    for ch in el:
        if _local(ch.tag) == name:
            return ch.text
    return None


def _xlsx_text(zf):
    shared = []
    sst = _xml(_read_member(zf, 'xl/sharedStrings.xml'))
    if sst is not None:
        for si in sst.iter():
            if _local(si.tag) == 'si':
                shared.append(''.join((t.text or '') for t in si.iter() if _local(t.tag) == 't'))
    cells = []
    for path in _xlsx_sheet_paths(zf):
        root = _xml(_read_member(zf, path))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            txt = None
            if t == 's':
                v = _child_text(c, 'v')
                if v is not None and re.fullmatch(r'\s*[0-9]+\s*', v):
                    idx = int(v.strip())
                    if idx < len(shared):
                        txt = shared[idx]
            elif t == 'inlineStr':
                txt = ''.join((x.text or '') for x in c.iter() if _local(x.tag) == 't')
            elif t == 'str':
                txt = _child_text(c, 'v')
            if txt and txt.strip():
                cells.append(txt)
    return '\n'.join(cells)


def _odf_walk(el, out):
    tag = _local(el.tag)
    if tag in ('desc', 'title', 'script', 'style', 'binary-data'):
        return
    if tag == 's':
        n = 1
        for k, v in el.attrib.items():
            if _local(k) == 'c':
                try:
                    n = max(0, int(v))
                except ValueError:
                    n = 1
        out.append(' ' * n)
    elif tag == 'tab':
        out.append('\t')
    elif tag == 'line-break':
        out.append('\n')
    if el.text:
        out.append(el.text)
    for ch in el:
        _odf_walk(ch, out)
        if ch.tail:
            out.append(ch.tail)
    if tag in ('p', 'h'):
        out.append('\n')


def _odf_text(zf):
    root = _xml(_read_member(zf, 'content.xml'))
    if root is None:
        return ''
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    out = []
    _odf_walk(body, out)
    return ''.join(out)


class _HtmlText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
             'article', 'blockquote', 'pre', 'ul', 'ol', 'table', 'header', 'footer',
             'figure', 'figcaption', 'dd', 'dt', 'hr', 'aside'}
    SKIP = {'script', 'style', 'head', 'nav', 'title'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            if self.skip:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data.replace('\n', ' ').replace('\r', ' ').replace('\t', ' '))


def _html_text(data):
    p = _HtmlText()
    try:
        p.feed(decode_plain(data))
        p.close()
    except Exception:
        pass
    lines = []
    for line in ''.join(p.out).split('\n'):
        line = re.sub(r' {2,}', ' ', line).strip()
        lines.append(line)
    text = '\n'.join(lines)
    return re.sub(r'\n{3,}', '\n\n', text).strip()


def _epub_chapters(zf):
    names = []
    cont = _xml(_read_member(zf, 'META-INF/container.xml'))
    opf_path = None
    if cont is not None:
        for el in cont.iter():
            if _local(el.tag) == 'rootfile':
                opf_path = el.get('full-path')
                break
    if opf_path:
        opf = _xml(_read_member(zf, opf_path))
        if opf is not None:
            base = posixpath.dirname(opf_path)
            manifest = {}
            spine = []
            for el in opf.iter():
                tag = _local(el.tag)
                if tag == 'item':
                    manifest[el.get('id')] = (el.get('href') or '', el.get('properties') or '')
                elif tag == 'itemref':
                    spine.append(el.get('idref'))
            for idref in spine:
                if idref not in manifest:
                    continue
                href, props = manifest[idref]
                if 'nav' in props.split():
                    continue
                names.append(posixpath.normpath(posixpath.join(base, unquote(href))))
            if names:
                return names
    for n in sorted(zf.namelist()):
        low = n.lower()
        if low.endswith(('.xhtml', '.html', '.htm')) and 'nav' not in posixpath.basename(low):
            names.append(n)
    return names


def _epub_text(zf):
    parts = []
    for name in _epub_chapters(zf):
        data = _read_member(zf, name)
        if data is None:
            continue
        txt = _html_text(data)
        if txt:
            parts.append(txt)
    return '\n'.join(parts)


def extract_zip(data, path, ext):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError, EOFError):
        fail('cannot read input: %s is not a readable zip archive' % path, 1)
    try:
        if ext in ('.docx', '.docm'):
            text = _docx_text(zf)
        elif ext in ('.pptx', '.pptm'):
            text = _pptx_text(zf)
        elif ext in ('.xlsx', '.xlsm'):
            text = _xlsx_text(zf)
        elif ext == '.epub':
            text = _epub_text(zf)
        else:
            text = _odf_text(zf)
    except (zipfile.BadZipFile, KeyError, ValueError, RuntimeError, OSError):
        text = ''
    finally:
        zf.close()
    return text.strip()


def extract_notebook(data):
    try:
        nb = json.loads(decode_plain(data))
    except ValueError:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        src = src.strip()
        if src:
            parts.append(src)
    return '\n'.join(parts).strip()


def load_text(path):
    if path is None:
        return decode_plain(sys.stdin.buffer.read())
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        fail('cannot read input: %s: %s' % (path, exc.strerror or exc), 1)
    ext = os.path.splitext(path)[1].lower()
    if ext in ZIP_EXTS:
        return extract_zip(data, path, ext)
    if ext in NOTEBOOK_EXTS:
        return extract_notebook(data)
    if ext in NO_PROSE_EXTS:
        return ''
    return decode_plain(data)


# ---------------------------------------------------------------- spans and masking

def _trim(text, s, e):
    while s < e and text[s].isspace():
        s += 1
    while e > s and text[e - 1].isspace():
        e -= 1
    return (s, e)


def line_spans(text):
    out = []
    pos = 0
    for ln in text.split('\n'):
        out.append((pos, pos + len(ln)))
        pos += len(ln) + 1
    return out


PARA_RX = re.compile(r'(?:[^\n]|\n(?![ \t\r]*\n))+')


def paragraph_spans(text):
    out = []
    for m in PARA_RX.finditer(text):
        s, e = _trim(text, m.start(), m.end())
        if e > s:
            out.append((s, e))
    return out


SENT_END_RX = re.compile(r'[.!?]+["\')\]]*(?=\s|$)')
UNIT_RX = re.compile(r'\s*(?:#{1,6}\s|[-*+]\s|\d+[.)]\s|\|)')


def sentence_spans(text):
    out = []
    for ls, le in line_spans(text):
        line = text[ls:le]
        if not line.strip():
            continue
        if UNIT_RX.match(line):
            out.append(_trim(text, ls, le))
            continue
        pos = ls
        for m in SENT_END_RX.finditer(line):
            e = ls + m.end()
            if text[pos:e].strip():
                out.append(_trim(text, pos, e))
            pos = e
        if text[pos:le].strip():
            out.append(_trim(text, pos, le))
    return out


WORD_RX = re.compile(r"[^\W_](?:[^\W_]|['\-’])*")


def word_count(text):
    return len(WORD_RX.findall(text))


def _mask_regions(raw, regions):
    regions.sort()
    merged = []
    for s, e in regions:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    pieces = []
    excluded = bytearray(len(raw))
    pos = 0
    for s, e in merged:
        pieces.append(raw[pos:s])
        pieces.append(re.sub(r'[^\n]', ' ', raw[s:e]))
        excluded[s:e] = b'\x01' * (e - s)
        pos = e
    pieces.append(raw[pos:])
    return ''.join(pieces), excluded


FRONT_MATTER_RX = re.compile(r'\A---[ \t]*\n(?:.*?\n)?---[ \t]*(?=\n|\Z)', re.S)
FENCE_OPEN_RX = re.compile(r'^ {0,3}(`{3,}|~{3,})([^\n]*)$')
FENCE_CLOSE_RX = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
BQ_RX = re.compile(r'^ {0,3}>')
TABLE_DELIM_RX = re.compile(r'^[ \t]*\|?[ \t]*:?-{3,}:?[ \t]*(\|[ \t]*:?-{3,}:?[ \t]*)*\|?[ \t]*$')
BADGE_RX = re.compile(r'^(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
INLINE_CODE_RX = re.compile(r'(`+)(?!`)(.*?)(?<!`)\1(?!`)')


def mask_text(raw):
    """Return (masked, excluded) where excluded regions produce no findings."""
    regions = []
    n = len(raw)
    fm = FRONT_MATTER_RX.match(raw)
    if fm:
        regions.append([0, fm.end()])
    lines = line_spans(raw)
    i = 0
    while i < len(lines):
        ls, le = lines[i]
        line = raw[ls:le]
        m = FENCE_OPEN_RX.match(line)
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            j = i + 1
            closed = False
            while j < len(lines):
                cs, ce = lines[j]
                cm = FENCE_CLOSE_RX.match(raw[cs:ce])
                if cm and cm.group(1)[0] == fence[0] and len(cm.group(1)) >= len(fence):
                    closed = True
                    break
                j += 1
            if closed:
                regions.append([ls, lines[j][1]])
                i = j + 1
            else:
                regions.append([ls, n])
                i = len(lines)
            continue
        i += 1
    # blockquote runs of two or more lines, tables, badge lines
    run_start = None
    run_len = 0
    for idx, (ls, le) in enumerate(lines):
        line = raw[ls:le]
        if BQ_RX.match(line):
            if run_start is None:
                run_start = ls
                run_len = 0
            run_len += 1
            run_end = le
            continue
        if run_start is not None and run_len >= 2:
            regions.append([run_start, run_end])
        run_start = None
        stripped = line.strip()
        if stripped.startswith('|') and stripped.count('|') >= 2:
            regions.append([ls, le])
        elif '|' in line and TABLE_DELIM_RX.match(line):
            regions.append([ls, le])
        elif stripped and BADGE_RX.match(stripped):
            regions.append([ls, le])
    if run_start is not None and run_len >= 2:
        regions.append([run_start, run_end])
    for m in INLINE_CODE_RX.finditer(raw):
        regions.append([m.start(), m.end()])
    return _mask_regions(raw, regions)


class Ctx(object):
    def __init__(self, raw, masked, excluded):
        self.raw = raw
        self.masked = masked
        self.excluded = excluded
        self._cache = {}

    def get(self, key, make):
        if key not in self._cache:
            self._cache[key] = make(self)
        return self._cache[key]

    @property
    def sents(self):
        return self.get('sents', lambda c: sentence_spans(c.masked))

    @property
    def paras(self):
        return self.get('paras', lambda c: paragraph_spans(c.masked))

    @property
    def invisible(self):
        return self.get('invisible', lambda c: invisible_positions(c.raw))


# ---------------------------------------------------------------- character layer

EXTRA_IGNORABLE = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0])


def _in(ch, lo, hi):
    return bool(ch) and lo <= ord(ch) <= hi


def _nospace_script(ch):
    return (_in(ch, 0x0E00, 0x0EFF) or _in(ch, 0x1000, 0x109F) or _in(ch, 0x1780, 0x17FF)
            or _in(ch, 0x3040, 0x30FF) or _in(ch, 0x3400, 0x4DBF) or _in(ch, 0x4E00, 0x9FFF)
            or _in(ch, 0xF900, 0xFAFF) or _in(ch, 0x20000, 0x2FFFF))


def _cjk(ch):
    return (_in(ch, 0x3400, 0x4DBF) or _in(ch, 0x4E00, 0x9FFF) or _in(ch, 0xF900, 0xFAFF)
            or _in(ch, 0x20000, 0x3FFFF))


def _joining_script(ch):
    return (_in(ch, 0x0590, 0x08FF) or _in(ch, 0x0900, 0x0DFF) or _in(ch, 0x1000, 0x109F)
            or _in(ch, 0x1780, 0x17FF) or _in(ch, 0xFB50, 0xFDFF) or _in(ch, 0xFE70, 0xFEFF))


def _symbolish(ch):
    if not ch:
        return False
    o = ord(ch)
    return o >= 0x1F000 or unicodedata.category(ch).startswith('S')


def _has_rtl(text):
    for c in text:
        o = ord(c)
        if 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFEFC:
            return True
    return False


def _kept(text, i, ch, o, rtl):
    n = len(text)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < n else ''
    if 0xE0020 <= o <= 0xE007F:
        j = i - 1
        while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F:
            j -= 1
        return j >= 0 and ord(text[j]) == 0x1F3F4
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return _symbolish(prev) or _cjk(prev) or nxt == '⃣'
    if o == 0x200B:
        return _nospace_script(prev) or _nospace_script(nxt)
    if o == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return rtl
    if 0x180B <= o <= 0x180F:
        return _in(prev, 0x1800, 0x18AF)
    if o in (0x17B4, 0x17B5):
        return _in(prev, 0x1780, 0x17FF) or _in(nxt, 0x1780, 0x17FF)
    if o in (0x200C, 0x200D):
        return any(_joining_script(x) or _symbolish(x) for x in (prev, nxt) if x)
    return False


def invisible_positions(text):
    out = []
    rtl = None
    for i, ch in enumerate(text):
        o = ord(ch)
        if o < 0x80:
            if (o < 0x20 or o == 0x7F) and ch not in '\t\n\r':
                out.append(i)
            continue
        cat = unicodedata.category(ch)
        candidate = (cat in ('Cc', 'Cf') or 0xE0000 <= o <= 0xE0FFF or o in EXTRA_IGNORABLE
                     or 0xFE00 <= o <= 0xFE0F or 0x180B <= o <= 0x180F)
        if not candidate:
            continue
        if rtl is None:
            rtl = _has_rtl(text)
        if _kept(text, i, ch, o, rtl):
            continue
        out.append(i)
    return out


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def nonstandard_space_positions(text):
    out = []
    for i, ch in enumerate(text):
        if ch in '  ':
            out.append(i)
        elif ch != ' ' and unicodedata.category(ch) == 'Zs':
            if ch in '  ' and _nbsp_kept(text, i):
                continue
            out.append(i)
    return out


# Mixed-script lookalikes: Cyrillic, Greek, and Armenian letters drawn like Latin letters.
CONFUSABLE = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'ո': 'n', 'о': 'o', 'р': 'p', 'ѕ': 's', 'ս': 'u',
    'ѵ': 'v', 'ԝ': 'w', 'х': 'x', 'у': 'y', 'ɡ': 'g', 'ο': 'o',
    'ν': 'v', 'ι': 'i', 'ε': 'e', 'υ': 'u', 'ρ': 'p', 'χ': 'x',
    'α': 'a', 'ѡ': 'w', 'ց': 'g',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'Ν': 'N', 'Ο': 'O', 'Р': 'P',
    'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'Υ': 'Y', 'Ζ': 'Z', 'Α': 'A',
    'Β': 'B', 'Ε': 'E', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M',
    'Ρ': 'P', 'Τ': 'T', 'Χ': 'X',
}


def is_homoglyph_token(tok):
    letters = [c for c in tok if c.isalpha()]
    non = [c for c in letters if ord(c) > 127]
    if not non or len(non) == len(letters):
        return False
    if not any(c.isascii() for c in letters):
        return False
    return all(c in CONFUSABLE for c in non)


def homoglyph_spans(text):
    out = []
    for m in re.finditer(r'\S+', text):
        if is_homoglyph_token(m.group(0)):
            out.append(m.span())
    return out


def fold_token(tok):
    if not is_homoglyph_token(tok):
        return tok
    return ''.join(CONFUSABLE.get(c, c) for c in tok)


def scrub(text):
    inv = set(invisible_positions(text))
    pieces = []
    for i, ch in enumerate(text):
        if i in inv:
            continue
        if ch in '  ':
            pieces.append('\n')
            continue
        if ch != ' ' and unicodedata.category(ch) == 'Zs':
            if ch in '  ' and _nbsp_kept(text, i):
                pieces.append(ch)
            else:
                pieces.append(' ')
            continue
        pieces.append(ch)
    s = ''.join(pieces)
    s = re.sub(r'\S+', lambda m: fold_token(m.group(0)), s)
    lines = []
    for ln in s.split('\n'):
        if ln.endswith('\r'):
            lines.append(ln[:-1].rstrip(' \t') + '\r')
        else:
            lines.append(ln.rstrip(' \t'))
    while lines and lines[0].strip(' \t\r') == '':
        lines.pop(0)
    body = '\n'.join(lines).rstrip()
    if text.endswith('\n'):
        body += '\n'
    return body


# ---------------------------------------------------------------- pattern families

def _excerpt(s):
    s = s.replace('\r', ' ').replace('\n', ' ')
    s = re.sub(r'\s{2,}', ' ', s).strip()
    if len(s) > 90:
        s = s[:87] + '...'
    return s


def _lit(phrase):
    out = []
    for w in phrase.split():
        e = re.escape(w).replace('’', "['’]").replace("'", "['’]")
        out.append(e)
    return r'\s+'.join(out)


def _infl(word):
    stem = word[:-1] if word.endswith('e') else word
    return re.escape(stem) + r'(?:es|ed|ing|s|d)?'


def _alt_rx(items, infl=False):
    parts = []
    for it in items:
        if infl and ' ' not in it and '-' not in it:
            parts.append(_infl(it))
        else:
            parts.append(_lit(it))
    return re.compile(r'(?<!\w)(?:' + '|'.join(parts) + r')(?!\w)', re.I)


def A(items, infl=False):
    rx = _alt_rx(items, infl)
    return lambda ctx: [m.span() for m in rx.finditer(ctx.masked)]


def R(*pats, **kw):
    flags = kw.get('flags', re.I)
    rxs = [re.compile(p, flags) for p in pats]
    return lambda ctx: [m.span() for r in rxs for m in r.finditer(ctx.masked)]


def C(*fns):
    return lambda ctx: [s for f in fns for s in f(ctx)]


def _cv(vals):
    if not vals:
        return None
    mean = sum(vals) / float(len(vals))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def _sent_lens(ctx):
    out = []
    for s, e in ctx.sents:
        out.append((s, e, word_count(ctx.masked[s:e])))
    return [x for x in out if x[2] > 0]


DIALECT_WORDS = ['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
                 'strikingly', 'compellingly']
AI_VOCAB = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
            'meticulous', 'testament', 'underscore', 'intricate', 'intricacies', 'interplay',
            'garner', 'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance',
            'leverage', 'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
            'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
            'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
            'elevate', 'empower', 'unlock']
PROMO = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
         'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
         'unparalleled', 'premier', 'leading', 'esteemed organization', 'valuable asset',
         'passion for excellence', 'proven track record', 'results-oriented', 'wealth of experience',
         'dynamic team', 'fast-paced environment', 'deeply passionate', 'perfectly situated',
         'close-knit team', 'tight-knit team', 'uniquely positioned to']
IMPERATIVES = ['install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
               'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
               'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop',
               'start']
IMPERATIVE_RX = re.compile(r'^(?:' + '|'.join(IMPERATIVES) + r')\b', re.I)
STOCK_ADJ = {'innovative', 'robust', 'seamless', 'comprehensive', 'powerful', 'dynamic', 'vibrant',
             'elegant', 'intuitive', 'cutting-edge', 'modern', 'bold', 'fresh', 'sleek', 'smart',
             'scalable', 'reliable', 'secure', 'fast', 'efficient', 'effortless', 'premier'}
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al',
              'ial', 'ary', 'ory', 'ish')
STOPWORDS = {'a', 'an', 'the', 'of', 'and', 'to', 'in', 'for', 'with', 'on', 'by', 'at', 'from',
             'or', 'is', 'are', 'was', 'were', 'it', 'this', 'that', 'these', 'those', 'they',
             'we', 'you', 'he', 'she', 'not', 'be', 'as', 'its', 'their', 'our', 'your', 'his', 'her'}
STACK_RX = re.compile(r"(?<![\w'\-])([A-Za-z][A-Za-z\-]*)(,\s*(?:and\s+)?|\s+and\s+)"
                      r"([A-Za-z][A-Za-z\-]*)(,\s*(?:and\s+)?|\s+and\s+)"
                      r"([A-Za-z][A-Za-z\-]*)(,\s*(?:and\s+)?|\s+and\s+)"
                      r"([A-Za-z][A-Za-z\-]*)(?![\w'\-])")


def _is_adj(w):
    lw = w.lower()
    return lw in STOCK_ADJ or lw.endswith(ADJ_SUFFIX)


def f_adjective_chains(ctx):
    out = []
    for m in STACK_RX.finditer(ctx.masked):
        words = [m.group(1), m.group(3), m.group(5), m.group(7)]
        if ',' not in m.group(0):
            continue
        if any(w.lower() in STOPWORDS for w in words):
            continue
        if not any(_is_adj(w) for w in words[:3]):
            continue
        if _is_adj(words[3]):
            continue
        out.append(m.span())
    return out


SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SYNONYM_RX = [[(m, re.compile(r'(?<!\w)' + _lit(m) + r'(?:e?s)?(?!\w)', re.I)) for m in cl]
              for cl in SYNONYM_CLUSTERS]


def f_synonym_cycling(ctx):
    out = []
    for cluster in SYNONYM_RX:
        found = []
        for word, rx in cluster:
            spans = [m.span() for m in rx.finditer(ctx.masked)]
            if spans:
                found.append(spans)
        if len(found) >= 3:
            for spans in found:
                out.extend(spans)
    return out


OUTLETS = ['The New York Times', 'New York Times', 'Forbes', 'BBC', 'CNN', 'The Wall Street Journal',
           'Wall Street Journal', 'The Guardian', 'Reuters', 'Bloomberg', 'The Washington Post',
           'Washington Post', 'TechCrunch', 'Wired', 'The Verge', 'NPR', 'Associated Press',
           'Business Insider', 'The Economist', 'Financial Times']
OUTLET_RX = _alt_rx(OUTLETS)
CREDIT_RX = re.compile(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\b', re.I)


def f_notability(ctx):
    out = []
    for s, e in ctx.sents:
        sent = ctx.masked[s:e]
        if CREDIT_RX.search(sent):
            outlets = set(m.group(0).lower() for m in OUTLET_RX.finditer(sent))
            if len(outlets) >= 2:
                out.append((s, e))
    out.extend(m.span() for m in re.finditer(
        r'\b\d[\d,.]*\s*(?:[kKmM]\+?)?\s+(?:followers|subscribers)\b', ctx.masked))
    out.extend(m.span() for m in re.finditer(
        r'\b(?:strong|active|robust)\s+(?:online|digital|social[- ]media)\s+presence\b'
        r'|\bwidely\s+covered\b|\bindependent\s+coverage\b', ctx.masked, re.I))
    return out


def f_rule_parallel_tail(ctx):
    return [m.span() for m in re.finditer(
        r"[^\n,.!?]{3,80},\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b",
        ctx.masked, re.I)]


def f_parallelism(ctx):
    out = []
    for p in [r"\bit[’']s\s+not\s+(?:just|merely)\s+(?:about|a|an)\b",
              r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b",
              r"\bdoesn[’']t\s+just\b[^.,\n]{0,40}?\bit\b"]:
        out.extend(m.span() for m in re.finditer(p, ctx.masked, re.I))
    return out


def f_not_x_just_y(ctx):
    out = []
    for p in [r"\b(?:no|not)\s+(?:[A-Za-z][\w'\-]*\s+){0,2}?[A-Za-z][\w'\-]*,\s+(?:just|only|simply)\s+[A-Za-z]",
              r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t)\s+(?:just|merely)\s+"
              r"(?:a|an|the)\s+[\w'\-’]+(?:,|—|–|\s-\s)\s*"
              r"(?:it[’']s|it\s+is|it\s+was|they[’']re|they\s+are|they\s+were|that[’']s|but)\b"]:
        out.extend(m.span() for m in re.finditer(p, ctx.masked, re.I))
    return out


def f_question_answer(ctx):
    return [m.span() for m in re.finditer(
        r"(?:^|(?<=[.!?\n]))[ \t]*((?:Is|Are|Am|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|"
        r"Shall|May|Might|Must|Has|Have|Had)\s[^?.!\n]{1,80}\?)\s+"
        r"(?i:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]", ctx.masked, re.M)]


def f_intro_hooks(ctx):
    out = []
    pats = [r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
            r"\bin\s+a\s+world\s+where\b", r"\bin\s+an\s+era\s+of\b", r"\bin\s+recent\s+years,",
            r"\bmore\s+than\s+ever\s+before\b", r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b",
            r"\b(?:great|exciting|big)\s+news\s*[!:]",
            r"\bever\s+(?:wanted|wondered|dreamed|wished\s+to)\b[^?\n]{0,120}\?",
            r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b"]
    for p in pats:
        out.extend(m.span() for m in re.finditer(p, ctx.masked, re.I))
    return out


def f_cataloguing(ctx):
    out = []
    pats = [r"\b(?:used|uses|employs?|employed|relied\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|"
            r"multiple|different|many|numerous)\s+\w+",
            r"(?:^|(?<=[.!?]\s))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+"
            r"(?:\w+\s+)?(?:information|insight|understanding|details|data)\b",
            r"\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|"
            r"lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b"]
    for p in pats:
        out.extend(m.span() for m in re.finditer(p, ctx.masked, re.I | re.M))
    return out


def f_inline_headers(ctx):
    out = []
    for p in [r'(?m)^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]*:[^*\n]*\*\*',
              r'(?m)^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+\*\*:']:
        out.extend(m.span() for m in re.finditer(p, ctx.masked))
    return out


LIST_LINE_RX = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S')
HEADING_RX = re.compile(r'(?m)^ {0,3}#{1,6}[ \t]')


def f_mid_essay_bullets(ctx):
    if HEADING_RX.search(ctx.masked):
        return []
    lists = []
    prose = 0
    for s, e in ctx.paras:
        lines = [ln for ln in ctx.masked[s:e].split('\n') if ln.strip()]
        if lines and all(LIST_LINE_RX.match(ln) for ln in lines):
            lists.append((s, e))
        else:
            prose += 1
    return lists if lists and prose >= 2 else []


def f_fragmented_headers(ctx):
    out = []
    spans = line_spans(ctx.masked)
    lines = [ctx.masked[s:e] for s, e in spans]
    for i, ln in enumerate(lines):
        if not re.match(r'^ {0,3}#{1,6}[ \t]+\S', ln):
            continue
        head_words = set(w.lower() for w in re.findall(r'[A-Za-z]{3,}', ln))
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        cand = lines[j].strip()
        if not cand or cand.startswith('#') or LIST_LINE_RX.match(lines[j]) or '|' in cand:
            continue
        words = re.findall(r'[A-Za-z]+', cand)
        if not words or len(words) > 4:
            continue
        if head_words & set(w.lower() for w in words):
            s, e = spans[j]
            out.append(_trim(ctx.masked, s, e))
    return out


TRANSITION_RX = re.compile(r'(?:^|(?<=[.!?])\s+|(?<=\n))(?:Additionally|Furthermore|Moreover|However|'
                           r'Nevertheless|Consequently|Subsequently|Notably)\b', re.M)


def f_transitions(ctx):
    out = []
    for s, e in ctx.paras:
        ms = [m.span() for m in TRANSITION_RX.finditer(ctx.masked, s, e)]
        if len(ms) >= 2:
            out.extend(ms)
    return out


def f_monotony(ctx):
    lens = _sent_lens(ctx)
    if len(lens) < 3:
        return []
    cv = _cv([x[2] for x in lens])
    if cv is not None and cv < 0.35:
        return [(lens[0][0], lens[0][1])]
    return []


def f_alternation(ctx):
    lens = _sent_lens(ctx)
    if len(lens) < 6:
        return []
    vals = [x[2] for x in lens]
    mean = sum(vals) / float(len(vals))
    out = []
    i = 0
    while i + 5 < len(vals):
        win = vals[i:i + 6]
        diffs = [win[k + 1] - win[k] for k in range(5)]
        alt = sum(1 for k in range(4) if (diffs[k] > 0) != (diffs[k + 1] > 0)
                  and diffs[k] != 0 and diffs[k + 1] != 0)
        big = all(abs(d) >= max(4.0, 0.35 * mean) for d in diffs)
        if alt >= 4 and big:
            out.append((lens[i][0], lens[i + 5][1]))
            i += 6
        else:
            i += 1
    return out


def f_opener_repetition(ctx):
    out = []
    lens = _sent_lens(ctx)
    for ps, pe in ctx.paras:
        inside = [x for x in lens if ps <= x[0] and x[1] <= pe]
        if len(inside) < 3:
            continue
        openers = []
        for s, e, _ in inside:
            ws = re.findall(r"[^\W_]+", ctx.masked[s:e].lower())
            openers.append((' '.join(ws[:2]), (s, e)))
        cnt = Counter(o for o, _ in openers)
        for o, sp in openers:
            if cnt[o] >= 3 and o:
                out.append(sp)
    return out


def f_uniform_paragraphs(ctx):
    paras = ctx.paras
    counts = [word_count(ctx.masked[s:e]) for s, e in paras]
    counts = [c for c in counts if c > 0]
    if len(counts) >= 4 and _cv(counts) is not None and _cv(counts) < 0.4:
        return [paras[0]] if paras else []
    return []


def f_semicolon(ctx):
    if word_count(ctx.masked) < 300:
        return []
    if ';' in ctx.masked or ctx.masked.count('(') > 1:
        return []
    return [(0, min(len(ctx.masked), 1))]


HEDGE_RX = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|"
                      r"appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")


def f_hedge(ctx):
    out = []
    for s, e in ctx.sents:
        if len(HEDGE_RX.findall(ctx.masked[s:e])) >= 2:
            out.append((s, e))
    return out


FIRST_PERSON_RX = re.compile(r"\b(?:I|me|my|mine|we|our|ours|us)\b", re.I)
EXPANDED_RX = re.compile(r"\b(?:I am|I will|I have|I would|I do|I had|do not|does not|did not|is not|are not|"
                         r"was not|were not|will not|would not|should not|could not|cannot|can not|"
                         r"have not|has not|that is|it is|we are|we have|they are|you are|let us|"
                         r"there is|we will|we would)\b", re.I)
CONTRACTION_RX = re.compile(r"\b\w+['’](?:t|s|re|ve|ll|d|m)\b", re.I)


def f_contraction(ctx):
    words = word_count(ctx.masked)
    if words < 50:
        return []
    fp = len(FIRST_PERSON_RX.findall(ctx.masked))
    if fp < 0.03 * words:
        return []
    expanded = [m.span() for m in EXPANDED_RX.finditer(ctx.masked)]
    contr = len(CONTRACTION_RX.findall(ctx.masked))
    if len(expanded) >= 3 and contr <= 0.25 * len(expanded):
        return expanded
    return []


def f_em_dash(ctx):
    out = []
    for s, e in ctx.paras:
        idx = [i for i in range(s, e) if ctx.masked[i] == '—']
        if len(idx) >= 2:
            out.extend((i, i + 1) for i in idx)
    return out


MINOR_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'at', 'by', 'in', 'of',
               'on', 'to', 'up', 'as', 'from', 'with', 'into', 'onto', 'over', 'off', 'per', 'via',
               'upon', 'than', 'like', 'out'}


def f_title_case(ctx):
    out = []
    for m in re.finditer(r'(?m)^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$', ctx.masked):
        title = m.group(1)
        if not title or not title[0].isalpha():
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’\-]*", title)
        if len(words) < 3:
            continue
        if title == title.upper():
            continue
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            out.append(m.span(1))
    return out


CURLY_RX = re.compile('[‘’“”]')
EN_RANGE_RX = re.compile(r'\b(1\d{3}|2\d{3})-(1\d{3}|2\d{3})\b')


def f_curly(ctx):
    return [m.span() for m in CURLY_RX.finditer(ctx.masked)]


def f_year_hyphen(ctx):
    out = []
    for m in EN_RANGE_RX.finditer(ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            out.append(m.span())
    return out


def f_invisible(ctx):
    return [(i, i + 1) for i in ctx.invisible]


def f_homoglyph(ctx):
    return homoglyph_spans(ctx.raw)


def f_nonstandard(ctx):
    return [(i, i + 1) for i in nonstandard_space_positions(ctx.raw)]


def f_trailing(ctx):
    raw = ctx.raw
    out = []
    for ls, le in line_spans(raw):
        if ls < len(raw) and ctx.excluded[ls]:
            continue
        m = re.search(r'[ \t]+$', raw[ls:le])
        if m:
            out.append((ls + m.start(), le))
    if raw and raw[0].isspace():
        out.append((0, 1))
    m = re.search(r'\n\n+\Z', raw)
    if m:
        out.append(m.span())
    return out


HR_RX = re.compile(r'(?m)^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$')


def f_hr(ctx):
    total = ctx.masked.count('\n') + 1
    spans = [m.span() for m in HR_RX.finditer(ctx.masked)]
    if len(spans) >= 3 and total >= 24:
        return spans
    return []


def f_degenerate(ctx):
    toks = [(m.group(0).lower(), m.span()) for m in re.finditer(r"[A-Za-z0-9']+", ctx.masked)]
    if len(toks) < 6:
        return []
    grams = [tuple(t for t, _ in toks[i:i + 6]) for i in range(len(toks) - 5)]
    cnt = Counter(grams)
    dup = [i for i, g in enumerate(grams) if cnt[g] > 1]
    if not dup or len(dup) < 0.2 * len(grams):
        return []
    return [(toks[i][1][0], toks[i + 5][1][1]) for i in dup]


def f_hyphen_pairs(ctx):
    return R(r'\b(?:cutting-edge|state-of-the-art|best-in-class|data-driven|results-driven|'
             r'user-centric|customer-centric|next-generation|value-added|forward-thinking|'
             r'high-performing)\b')(ctx)


def f_imperatives(ctx):
    sents = [(s, e) for s, e in ctx.sents if IMPERATIVE_RX.match(ctx.masked[s:e].lstrip('#*- '))]
    return sents if len(sents) >= 3 else []


# Ordered list of entries: (number, slug, label, matcher, advice, decisive, fmt, min_hits)
PATTERNS = []


def P(num, slug, label, fn, advice=False, decisive=False, fmt='excerpt', min_hits=1):
    PATTERNS.append({'num': num, 'slug': slug, 'label': label, 'fn': fn, 'advice': advice,
                     'decisive': decisive, 'fmt': fmt, 'min_hits': min_hits})


P(1, 'ai_vocabulary', 'AI vocabulary',
  C(A(AI_VOCAB, True), R(r"\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b")))
P(2, 'model_dialect', 'Model-dialect vocabulary',
  C(A(DIALECT_WORDS), R(r"\bquietly\s+(?:powerful|profound|radical)\b",
                        r"\bdeeply\s+(?:human|personal|felt|unsettling)\b",
                        r"\bresonates\s+deeply\b",
                        r"\bgame[- ]?chang(?:er|ers|ing)\b",
                        r"\bsupercharg(?:e|es|ed|ing)\b", r"\bskyrocket(?:s|ed|ing)?\b",
                        r"\bturbocharg(?:e|es|ed|ing)\b", r"\brevolutioniz(?:e|es|ed|ing)\b",
                        r"\bdouble\s+down\s+on\b", r"\bdive\s+deep(?:er)?\s+into\b",
                        r"\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b",
                        r"\btake\b[^.!?\n]{1,60}?\bto\s+the\s+next\s+level\b")), min_hits=2)
P(3, 'promotional_language', 'Promotional language',
  C(A(PROMO), R(r"\bI\s+(?:am|’m|'m)\s+excited\s+to\s+(?:apply|bring)\b"), f_imperatives))
P(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', f_hyphen_pairs, advice=True)
P(5, 'simple_yet', 'Simple yet X cliche',
  R(r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"))
P(6, 'adjective_chains', 'Stacked adjective chains', f_adjective_chains)
P(8, 'synonym_cycling', 'Synonym cycling', f_synonym_cycling)
P(10, 'significance_inflation', 'Significance inflation',
  R(r"\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor|highlight)(?:s|es|ed|ing)?\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymboli[sz]es\b", r"\bsets?\s+the\s+stage\s+for\b", r"\bleft\s+an?\s+indelible\s+mark\b",
    r"\bplays?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\bhas\s+(?:shaped|sparked)\b", r"\bhas\s+come\s+to\s+(?:define|symbolize)\b"))
P(11, 'notability_name_dropping', 'Notability name-dropping', f_notability)
P(12, 'vague_attributions', 'Vague attributions',
  R(r"\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry\s+(?:reports|observers|analysts)\b", r"\bobservers\s+(?:have\s+)?(?:cited|noted)\b",
    r"\bsome\s+critics\s+argue\b", r"\bresearchers\s+have\s+found\b", r"\bstudies\s+suggest\b",
    r"\bit\s+is\s+widely\s+believed\b"))
P(13, 'article_title_proper_noun', 'Article title used as a proper noun',
  R(r"\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+(?:[^\s.!?,;:]+\s+){1,6}?(?:is|was)\s+(?:a|an|the)\b",
    flags=0), decisive=True)
P(14, 'conservation_padding', 'Conservation and ecosystem padding',
  R(r"\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves\s+as\s+an\s+indicator\s+species\b", r"\bcontributes\s+to\s+biodiversity\b"))
P(15, 'false_ranges', 'False ranges',
  R(r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?"
    r"\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
    r"\bfrom\s+(?:the\s+)?humble\b[^.!?\n]{0,200}?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b"))
P(16, 'ing_tails', 'Superficial -ing tail clauses',
  R(r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|"
    r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|"
    r"indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b"))
P(17, 'tailing_negation', 'Tailing negation', f_rule_parallel_tail)
P(17, 'negative_parallelism', 'Negative parallelism', f_parallelism, advice=True)
P(18, 'not_x_just_y', 'Not X, just Y framing', f_not_x_just_y)
P(19, 'filler_phrases', 'Filler phrases', R(
    r"\bin\s+order\s+to\b", r"\bdue\s+to\s+the\s+fact\s+that\b", r"\bat\s+this\s+point\s+in\s+time\b",
    r"\bin\s+the\s+event\s+that\b", r"\bhas\s+the\s+ability\s+to\b",
    r"\bit\s+is\s+important\s+to\s+note\s+that\b", r"\bit\s+should\s+be\s+mentioned\s+that\b",
    r"\bneedless\s+to\s+say\b"), advice=True)
P(20, 'empty_pivots', 'Empty pivot phrases', R(
    r"\bit[’']s\s+worth\s+(?:noting|mentioning)\s+that\b", r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b", r"\bit\s+is\s+interesting\s+to\s+note\s+that\b",
    r"\ba\s+key\s+consideration\s+is\b", r"\ba\s+point\s+to\s+highlight\s+is\b"))
P(21, 'outcome_speculation', 'Outcome-speculation tails', R(
    r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|"
    r"with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|"
    r"signaling\s+a\s+shift\s+toward)\b"))
P(22, 'persuasive_tropes', 'Persuasive authority tropes', A([
    "here's the thing", "make no mistake", "the truth is", "let's be honest", "the simple fact is",
    "at its core", "what really matters", "more than anything", "at the end of the day",
    "the bottom line is", "in reality", "fundamentally,", "the real question is",
    "the heart of the matter", "the deeper issue", "when you get down to it",
    "when all is said and done"]), advice=True)
P(23, 'editorial_interjections', 'Editorial interjections', R(
    r"\bit(?:[’']s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b",
    r"\bone\s+must\s+note\s+that\b", r"\bit\s+is\s+worth\s+pointing\s+out\b",
    r"\bit\s+cannot\s+be\s+overstated\s+that\b", r"\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b"))
P(24, 'self_thoroughness', 'Self-thoroughness phrases', R(
    r"\bthis\s+(?:comprehensive\s+(?:guide|overview|analysis)|in-depth\s+(?:analysis|look|examination)|"
    r"complete\s+(?:guide|overview))\b",
    r"\ba\s+thorough\s+examination\s+of\b", r"\beverything\s+you\s+need\s+to\s+know\s+about\b"))
P(25, 'question_answer', 'Question-answer rhetorical pattern', f_question_answer, decisive=False)
P(26, 'concrete_evidence', 'Concrete evidence defense phrase', R(
    r"\bwithout\s+concrete\s+(?:evidence|proof)\b", r"\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b",
    r"\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b",
    r"\babsent\s+concrete\s+(?:evidence|proof)\b", r"\bprovide\s+concrete\s+(?:evidence|proof)\b"))
P(27, 'intro_hooks', 'Compulsive intro hooks', f_intro_hooks)
P(30, 'diff_anchored', 'Diff-anchored writing', R(
    r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b",
    r"\bthis\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\bthe\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b",
    r"\bpreviously\b[^.!?\n]{0,200}?\bnow\b",
    r"\bwas(?:n[’']t|\s+not)\s+there\s+before\b|\bwere(?:n[’']t|\s+not)\s+there\s+before\b",
    r"\bwe(?:[’']ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b"))
P(31, 'signposting', 'Signposting and announcements', R(
    r"\blet[’']s\s+(?:dive|delve|explore)\b", r"\blet[’']s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere[’']s\s+what\s+you\s+need\s+to\s+know\b", r"\bwithout\s+further\s+ado\b",
    r"\bnow\s+let[’']s\s+look\s+at\b", r"\bbuckle\s+up\b", r"\bstay\s+with\s+me\b",
    r"\bready\s+to\s+dive\s+in\b"))
P(32, 'cataloguing_leadins', 'Cataloguing lead-ins', f_cataloguing)
P(33, 'inline_header_lists', 'Inline-header vertical lists', f_inline_headers)
P(34, 'mid_essay_bullets', 'Mid-essay bullet injection', f_mid_essay_bullets)
P(35, 'fragmented_headers', 'Fragmented headers', f_fragmented_headers)
P(36, 'formulaic_challenges', 'Formulaic challenges sections', R(
    r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b",
    r"\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b",
    r"\bcontinues\s+to\s+thrive\b", r"\btypical\s+of\s+(?:emerging|urban|modern)\b",
    r"\bfaces\s+(?:several|many|numerous)\s+challenges\b"))
P(37, 'transition_clusters', 'Transition cluster overuse', f_transitions)
P(38, 'compulsive_conclusions', 'Compulsive conclusion phrases', R(
    r"(?m)^[ \t]*(?:[-*>][ \t]+)?(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|"
    r"all\s+in\s+all|in\s+essence|ultimately)\b"))
P(39, 'generic_positive_conclusions', 'Generic positive conclusions', R(
    r"\bthe\s+future\s+looks\s+bright\b", r"\bexciting\s+times\s+lie\s+ahead\b",
    r"\bjourney\s+toward\s+excellence\b", r"\bstep\s+in\s+the\s+right\s+direction\b",
    r"\b(?:outlook|future)\s+(?:for\s+[^.,;\n]{1,40}\s+)?(?:is|looks|remains)\s+bright\b",
    r"\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b"))
P(40, 'sentence_length_monotony', 'Sentence-length monotony', f_monotony)
P(41, 'mechanical_alternation', 'Mechanical sentence-length alternation', f_alternation, advice=True)
P(42, 'opener_repetition', 'Opener repetition', f_opener_repetition, advice=True)
P(44, 'uniform_paragraph_length', 'Uniform paragraph length', f_uniform_paragraphs)
P(46, 'semicolon_parenthesis_underuse', 'Semicolon and parenthesis underuse', f_semicolon, advice=True)
P(47, 'chatbot_artifacts', 'Chatbot artifacts', R(
    r"\b(?:Certainly|Of course)!", r"\bhappy\s+to\s+help[.!](?=\s|$)", r"\bI\s+hope\s+this\s+helps\b",
    r"\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b", r"\blet\s+me\s+know\s+if\s+you\b",
    r"\bwould\s+you\s+like\s+me\s+to\b", r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b",
    r"\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b",
    r"\bhere\s+(?:are|is|’s|'s)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
    r"\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere\s+(?:is|’s|'s)\s+(?:a\s+|the\s+)?draft\b",
    r"\bhere\s+(?:is|’s|'s)\s+the\s+(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)\b",
    r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r"\bto\s+(?:answer|address)\s+your\s+question\b", r"\bin\s+(?:response|answer)\s+to\s+your\s+question\b",
    r"\byour\s+question\s+(?:about|regarding|concerning)\b",
    r"\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b"), decisive=True)
P(48, 'sycophantic_tone', 'Sycophantic tone', R(
    r"\byou(?:[’']re|\s+are)\s+absolutely\s+right\b",
    r"\b(?:great|excellent|wonderful|fantastic|brilliant|thoughtful)\s+(?:question|point)\s*[!.,]",
    r"\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b",
    r"\bthat[’']s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b"),
  decisive=True)
P(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers', R(
    r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b", r"\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b",
    r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively\s+|widely\s+)?documented)\b",
    r"\bbased\s+on\s+(?:the\s+)?available\s+information\b", r"\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b",
    r"\bmaintains\s+a\s+low\s+profile\b", r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b"),
  decisive=True)
P(51, 'copula_avoidance', 'Copula avoidance', R(
    r"\b(?:serves|stands|functions|acts)\s+as\b", r"\brepresents\s+(?:a|the)\b", r"\bmarks\s+(?:a|the)\b",
    r"\bboasts\b", r"\bfeatures\s+(?:a|an|the|\d+|several|many|numerous|multiple|various|a\s+number\s+of)\b",
    r"\boffers\s+a\b", r"\brefers\s+to\b"))
P(54, 'hedge_stacking', 'Hedge stacking', f_hedge, advice=True)
P(55, 'contraction_absence', 'Contraction absence', f_contraction, advice=True)
P(56, 'boldface_overuse', 'Boldface overuse', R(r"\*\*[^*\n]+\*\*", flags=0))
P(57, 'emoji', 'Emoji', R(
    '[\U0001F000-\U0001FAFF☀-➿⭐⭕⤴⤵〰〽㊗㊙©®'
    '‼⁉™ℹ↔-↙↩↪⌚⌛⌨⏏⏩-⏳⏸-⏺'
    'Ⓜ▪▫▶◀◻-◾]', flags=0))
P(58, 'em_dash_overuse', 'Em-dash overuse', f_em_dash, advice=True)
P(59, 'title_case_headings', 'Title case in headings', f_title_case)
P(60, 'curly_quotes', 'Curly quotation marks', f_curly, advice=True)
P(61, 'year_hyphen_range', 'Hyphen used for en dash in year ranges', f_year_hyphen, advice=True)
P(62, 'invisible_characters', 'Invisible or zero-width characters', f_invisible, decisive=True, fmt='char')
P(63, 'placeholder_text', 'Placeholder text', C(
    R(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,80}\](?![(\[])"),
    R(r"\[[^\]\n]{0,40}\b(?:name|company|client|place|source)\b[^\]\n]{0,40}\](?![(\[])"),
    R(r"\[(?=[A-Z0-9 _\-]*[A-Z])[A-Z0-9][A-Z0-9 _\-]{2,}\](?![(\[])", flags=0),
    R(r"\{\{[^{}\n]{0,80}\}\}"),
    R(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])", flags=0),
    R(r"\blorem\s+ipsum\b")), decisive=True)
P(64, 'chat_reference_markup', 'Chat reference markup', R(
    r"\bcite(?:turn|start|nav)\w*", r"\boai_citation\w*", r"contentReference", r"\bnavlist\b",
    "【\\d+†[^】\n]*】"), decisive=True)
P(65, 'ai_tracking_params', 'AI tracking parameters', R(
    r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|"
    r"copilot\.microsoft\.com|poe\.com)(?![\w-]|\.\w)"), decisive=True)
P(66, 'mixed_script_homoglyphs', 'Mixed-script homoglyphs', f_homoglyph, decisive=True, fmt='token')
P(67, 'nonstandard_spaces', 'Non-standard spaces', f_nonstandard, fmt='char')
P(68, 'trailing_whitespace', 'Trailing or stray whitespace', f_trailing, advice=True)
P(69, 'marketing_slop', 'Canonical marketing-slop phrases', R(
    r"\bunlocking\s+(?:its\s+|your\s+|the\s+)?full\s+potential\b", r"\bnavigating\s+the\s+complexities\b",
    r"\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b", r"\bstaying\s+ahead\s+of\s+the\s+curve\b",
    r"\bturning\s+challenges\s+into\s+opportunities\b", r"\bharnessing\s+the\s+power\s+of\b",
    r"\bpaving\s+the\s+way\s+for\b", r"\bsaying\s+goodbye\s+to\b", r"\bimagining\s+a\s+world\s+where\b",
    r"\bin\s+the\s+ever-(?:evolving|changing)\s+(?:landscape|world)\b"))
P(70, 'decorative_rules', 'Decorative horizontal rules', f_hr)
P(71, 'degenerate_repetition', 'Degenerate repetition', f_degenerate)


# ---------------------------------------------------------------- scoring

DECISIVE_NUMS = frozenset([62, 63, 64, 65, 66, 13, 47, 50, 48])
SCORE_FLOOR_SHORT_NUMS = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


HOOK_PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def confidence_of(words, families):
    if words < 40:
        return 'none'
    if words < 120 or (words < 300 and families == 1):
        return 'low'
    if words < 300:
        return 'moderate'
    return 'high'


CONFIDENCE_REASON = {
    'none': 'fewer than 40 words; too little prose to score',
    'low': 'fewer than 120 words, or under 300 words with a single pattern family',
    'moderate': 'fewer than 300 words',
    'high': '',
}


def score_from(num_hits, words):
    fam = set(n for n, h in num_hits.items() if h > 0)
    pts = 0.0
    for n in fam:
        h = num_hits[n]
        p = 8.0 + 1.5 * min(h - 1, 4)
        if n in DECISIVE_NUMS:
            p += 6.0
        pts += p
    raw = min(100, int(round(pts)))
    cap = 100
    if len(fam) == 1:
        cap = 40
    if fam <= set([40]):
        cap = min(cap, 20)
    elif fam <= set([40, 44]):
        cap = min(cap, 40)
    score = min(raw, cap)
    conf = confidence_of(words, len(fam))
    dec = fam & DECISIVE_NUMS
    floors = []
    if len(dec) >= 2:
        floors.append(65)
    elif len(dec) == 1 and conf in ('moderate', 'high'):
        floors.append(45)
    sub = fam & SCORE_FLOOR_SHORT_NUMS
    if words < 120:
        if len(sub) >= 3:
            floors.append(45)
        elif len(sub) >= 2:
            floors.append(25)
    if words >= 400:
        if len(fam) >= 6:
            floors.append(45)
        elif len(fam) >= 5:
            floors.append(25)
    for f in floors:
        score = max(score, f)
    return max(0, min(100, score)), conf


def run_patterns(ctx):
    """Return list of (pattern, spans) for every pattern that fired."""
    fired = []
    for pat in PATTERNS:
        spans = pat['fn'](ctx)
        if len(spans) < pat['min_hits']:
            continue
        if spans:
            fired.append((pat, spans))
    return fired


def build_ctx(raw):
    masked, excluded = mask_text(raw)
    return Ctx(raw, masked, excluded)


def sample_for(pat, raw, s, e):
    if pat['fmt'] == 'char':
        ch = raw[s] if s < len(raw) else ''
        return 'U+%04X at character %d' % (ord(ch) if ch else 0, s + 1)
    return _excerpt(raw[s:e])


def analyze(text, want_ci=False):
    truncated = len(text) > WINDOW
    win = text[:WINDOW]
    ctx = build_ctx(win)
    fired = run_patterns(ctx)
    words = word_count(ctx.masked)

    report = {}
    num_hits = {}
    decisive_fired = False
    n_inv = n_ns = n_hg = 0
    for pat, spans in fired:
        count = len(spans)
        samples = []
        for s, e in spans[:3]:
            samples.append(sample_for(pat, win, s, e))
        key = '%d_%s' % (pat['num'], pat['slug'])
        report[key] = {'label': pat['label'], 'count': count, 'samples': samples}
        if pat['num'] == 62:
            n_inv = count
        elif pat['num'] == 67:
            n_ns = count
        elif pat['num'] == 66:
            n_hg = count
        if not pat['advice']:
            num_hits[pat['num']] = num_hits.get(pat['num'], 0) + count

    score, conf = score_from(num_hits, words)
    metrics = {
        'scanned_chars': len(win),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': CONFIDENCE_REASON[conf],
        'patterns_flagged': len(report),
        'invisible_chars': n_inv,
        'nonstandard_spaces': n_ns,
        'homoglyphs': n_hg,
        'words': words,
    }
    if want_ci:
        metrics.update(interval_metrics(ctx, words, num_hits))
    report['_metrics'] = metrics
    return report


DOC_LEVEL_NUMS = frozenset([34, 35, 40, 41, 42, 44, 46, 70, 71])


def interval_metrics(ctx, words, full_hits):
    sents = ctx.sents
    if len(sents) < 4:
        return {'score_ci': None,
                'score_ci_note': 'too few sentences (%d); an interval needs at least four' % len(sents)}
    per = []
    for s, e in sents:
        sub_text = ctx.masked[s:e]
        sub_ctx = Ctx(sub_text, sub_text, bytearray(len(sub_text)))
        hits = {}
        for pat, spans in run_patterns(sub_ctx):
            if not pat['advice'] and pat['num'] not in DOC_LEVEL_NUMS:
                hits[pat['num']] = hits.get(pat['num'], 0) + len(spans)
        per.append((hits, word_count(sub_text)))
    constant = dict((n, h) for n, h in full_hits.items() if n in DOC_LEVEL_NUMS)
    rng = random.Random(1729)
    k = len(per)
    scores = []
    for _ in range(40):
        agg = dict(constant)
        wsum = words
        for _ in range(k):
            hits, w = per[rng.randrange(k)]
            wsum += w
            for n, h in hits.items():
                agg[n] = agg.get(n, 0) + h
        scores.append(score_from(agg, wsum)[0])
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(0.95 * (len(scores) - 1))]
    lo, hi = min(lo, hi), max(lo, hi)
    return {'score_ci': [lo, hi],
            'score_ci_note': 'low/high 5th and 95th percentiles over 40 seeded resamples of sentences; '
                             'the point score is unchanged'}


# ---------------------------------------------------------------- CLI

def main(argv):
    clean = False
    ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == '--':
            end = True
            continue
        if arg in ('-h', '--help'):
            sys.stdout.buffer.write(USAGE.encode('utf-8'))
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            ci = True
            continue
        if arg.startswith('-'):
            fail("unknown option '%s' (see --help)" % arg, 2)
        operands.append(arg)

    path = operands[0] if operands else None
    if len(operands) > 1:
        sys.stderr.write('prosecheck: scanning only the first file: %s (%d other operand(s) ignored)\n'
                         % (operands[0], len(operands) - 1))
        sys.stderr.flush()

    text = load_text(path)
    if not text.strip():
        fail('empty input', 1)

    if clean:
        out = scrub(text)
        sys.stdout.buffer.write(out.encode('utf-8', 'replace'))
        return 0

    report = analyze(text, want_ci=ci)
    out = json.dumps(report, ensure_ascii=False, indent=2)
    sys.stdout.buffer.write((out + '\n').encode('utf-8', 'replace'))
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except BrokenPipeError:
        code = 0
    sys.exit(code)
