---
name: prosecheck
description: Rewrite prose that prosecheck flagged. Use when the user says "prosecheck this" or "humanize this", or when a saved-file nudge asks for flagged spans to be fixed.
---

# Rewriting flagged prose

The detector reports findings and a score; the host agent does the rewrite. Work only on prose deliverables. Never touch code, comments, configuration, commits, or chat.

1. Run the detector on the file: `python3 <plugin root>/scripts/detect.py <file>`. Read the findings and their sample excerpts.
2. Fix only the flagged spans. Keep facts, numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly as written.
3. Vary sentence length. Do not replace one stock phrase with another.
4. Re-run the detector. Make at most two fix passes.
5. Do not announce the rewrite, the score, or the tool in the reply.
