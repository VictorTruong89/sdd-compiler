#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const path = require('path');
const fs = require('fs');
const P = require('./lib/prosecheck.js');

const FILE_TOOLS = ['Write', 'Edit', 'MultiEdit'];
const PATCH_RX = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  let m;
  PATCH_RX.lastIndex = 0;
  while ((m = PATCH_RX.exec(body)) !== null) {
    const p = m[1].trim();
    if (p && !out.includes(p)) out.push(p);
  }
  return out;
}

function candidatePaths(payload) {
  const tool = String(payload.tool_name || '');
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  if (FILE_TOOLS.includes(tool)) {
    return typeof ti.file_path === 'string' && ti.file_path.trim() ? [ti.file_path.trim()] : [];
  }
  if (tool === 'NotebookEdit') {
    const p = ti.notebook_path || ti.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  if (tool === 'apply_patch') {
    return patchPaths(typeof ti.command === 'string' ? ti.command : ti.patch);
  }
  return [];
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (P.INSTRUCTION_NAMES.includes(lower)) return true;
  const ext = path.extname(lower);
  const stem = lower.slice(0, lower.length - ext.length);
  const prose = P.PLAIN_EXTS.includes(ext) || P.ARCHIVE_EXTS.includes(ext);
  return !prose && P.INSTRUCTION_STEMS.includes(stem);
}

function skippedLocation(abs) {
  const norm = abs.split(path.sep).join('/');
  if (/(^|\/)(node_modules|\.git)(\/|$)/.test(norm)) return true;
  const root = path.resolve(P.pluginRoot());
  const rel = path.relative(root, abs);
  return !!rel && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function main() {
  const payload = P.readStdinJson();
  const level = P.currentLevel();
  if (level === 'off' || level === 'lite') return;
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const sid = payload.session_id;
  const lines = [];
  const threshold = P.THRESHOLD[level];

  for (const raw of candidatePaths(payload).slice(0, P.GUARD_PATH_CAP)) {
    const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
    const base = path.basename(abs);
    const ext = path.extname(abs).toLowerCase();
    if (isInstructionFile(base)) continue;
    if (skippedLocation(abs)) continue;
    if (P.BINARY_EXTS.includes(ext)) {
      P.appendLedger(sid, { base, kind: 'binary', ext });
      continue;
    }
    const eligible = P.PLAIN_EXTS.includes(ext) || P.ARCHIVE_EXTS.includes(ext);
    if (!eligible) continue;
    let st;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      P.appendLedger(sid, { base, kind: 'failed', reason: 'file could not be read' });
      continue;
    }
    if (!st.isFile()) continue;
    const isPlain = P.PLAIN_EXTS.includes(ext);
    const cap = isPlain ? P.PLAIN_CAP : P.ARCHIVE_CAP;
    if (st.size > cap) {
      P.appendLedger(sid, { base, kind: 'skipped', capKb: cap / 1024 });
      continue;
    }
    const r = P.scoreFile(abs, ext);
    if (!r.ok) {
      P.appendLedger(sid, { base, kind: 'failed', reason: r.reason });
      continue;
    }
    const flagged = r.score > threshold;
    const labelList = r.labels.map((l) => l.label);
    P.appendLedger(sid, {
      base, kind: 'scored', score: r.score, band: r.band, phrase: P.phraseOf(r.band),
      labels: labelList.slice(0, P.LABEL_CAP_GUARD), flagged, truncated: r.truncated,
    });
    if (flagged) {
      const coverage = r.truncated ? ', first ' + P.WINDOW_TEXT + ' characters only' : '';
      const flaggedList = labelList.slice(0, P.LABEL_CAP_GUARD).join('; ') || 'no labels listed';
      lines.push('prosecheck: ' + base + ' ' + P.phraseOf(r.band) + ' (score ' + r.score + ', band ' +
        r.band + coverage + '). Flagged: ' + flaggedList + '. Please fix the flagged spans, keeping ' +
        'sentence-length variation.');
    }
  }

  if (lines.length) {
    P.emitJson({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    });
  }
}

try {
  main();
} catch (e) {
  /* malformed input or internal error: no nudge, success */
}
process.exitCode = 0;
