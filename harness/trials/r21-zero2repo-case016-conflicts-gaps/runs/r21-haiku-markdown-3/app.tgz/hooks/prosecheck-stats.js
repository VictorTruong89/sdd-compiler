#!/usr/bin/env node
'use strict';
// Stats: session token totals from a transcript and, when there is enough prose, a score
// for the session's own assistant text. Also runnable as a stand-alone hook: it reads a
// prompt-submit object and answers with a block decision.
const fs = require('fs');
const path = require('path');
const P = require('./lib/prosecheck.js');

const PROSE_TAIL = 40000;
const PROSE_MIN = 500;

function newestTranscript() {
  const root = path.join(P.configDir(), 'projects');
  let best = null;
  function walk(dir, depth) {
    if (depth > 6) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(full, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mt = fs.statSync(full).mtimeMs;
          if (!best || mt > best.mt) best = { file: full, mt };
        } catch (e) { /* skip */ }
      }
    }
  }
  walk(root, 0);
  return best ? best.file : null;
}

function readTranscript(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const seen = new Set();
  let turns = 0;
  let outTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant') continue;
    const msg = row.message && typeof row.message === 'object' ? row.message : {};
    const id = msg.id || row.uuid || null;
    if (id) {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    }
  }
  return { turns, outTokens, cacheRead, texts };
}

function proseScore(texts) {
  let prose = texts.join('\n\n').replace(/```[\s\S]*?```/g, '');
  prose = prose.slice(-PROSE_TAIL).trim();
  if (prose.length <= PROSE_MIN) return null;
  const r = P.runDetector([], { input: prose, timeoutMs: 8000 });
  if (r.notFound || r.timeout || r.status !== 0) return null;
  const parsed = P.parseReport(r.stdout);
  return parsed.report ? parsed.report._metrics.ai_tell_score : null;
}

function statsReply(transcriptPath, level) {
  let file = null;
  if (typeof transcriptPath === 'string' && transcriptPath.trim()) {
    file = transcriptPath.trim();
  } else {
    file = newestTranscript();
  }
  const data = file ? readTranscript(file) : null;
  if (!data) {
    return 'prosecheck stats: no readable session transcript' +
      (file ? ' at ' + file : '') + ', so there are no turn or token counts. Level: ' + level + '.';
  }
  const lines = [
    'prosecheck stats for this session',
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.outTokens,
    'cache-read input tokens: ' + data.cacheRead,
  ];
  const score = proseScore(data.texts);
  if (score !== null) {
    lines.push('session prose ai_tell_score: ' + score + ' (band ' + P.bandOf(score) + ')');
  }
  lines.push('Token totals are taken from the transcript usage fields, not estimated.');
  return lines.join('\n');
}

function main() {
  const payload = P.readStdinJson();
  const level = P.currentLevel();
  P.emitJson({ decision: 'block', reason: statsReply(payload.transcript_path, level) });
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    main();
  } catch (e) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
