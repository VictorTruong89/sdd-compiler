#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router, the stop phrases, and the ordinary
// prompt reminder.
const fs = require('fs');
const path = require('path');
const P = require('./lib/prosecheck.js');
const { statsReply } = require('./prosecheck-stats.js');

const STOP_PHRASES = ['stop prosecheck', 'prosecheck off'];

function block(reason) {
  P.emitJson({ decision: 'block', reason });
}

function helpReply(level) {
  return [
    'prosecheck help. Current level: ' + level + '.',
    'Code, commits, config, and chat are never touched; the writing contract covers prose deliverables only.',
    '/prosecheck lite - turns on the writing contract without scoring saved files.',
    '/prosecheck full (default) - adds the saved-file guard with its threshold of 40 on top of the contract.',
    '/prosecheck strict - lowers the guard threshold to 20 and adds the cleanup scrub.',
    '/prosecheck off | on - off switches the tool off (disable); on switches it back on at full (re-enable).',
    '/prosecheck check <file> - scores one file and prints a report; it never rewrites the file.',
    '/prosecheck doctor - checks the install (health).',
    '/prosecheck stats - session token use and the score of this session\'s own prose.',
    '/prosecheck init - exports the writing contract to ./AGENTS.md for agents other than Claude Code.',
    '/prosecheck status - one line with the current level.',
    '/prosecheck show - lists the files saved and scored in this session.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unknownReply(word) {
  return 'Unknown subcommand: ' + word + ' (unknown word). Valid subcommands: ' +
    P.SUBCOMMANDS.join(', ') + '. The stored level is unchanged.';
}

function stripPathArg(arg) {
  let s = String(arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1);
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) {
    s = s.slice(1, -1);
  }
  return s;
}

function scoredRows(sid) {
  return P.readLedger(sid).slice().reverse();
}

function showReply(sid) {
  const rows = scoredRows(sid);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf ' +
      'deliverables, are saved.';
  }
  const out = ['prosecheck show: files saved in this session, newest first.'];
  for (const r of rows) {
    let body;
    if (r.kind === 'scored') {
      body = r.phrase + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + P.WINDOW_TEXT + ' characters only' : '') + ')';
      if (r.labels && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' +
          r.labels.slice(0, P.LABEL_CAP_SHOW).join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: file is over the ' + r.capKb + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'not re-scored: binary format (' + r.ext + ')';
    } else {
      body = 'not scored: ' + (r.reason || 'unknown reason');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

function checkReply(arg, form) {
  const typed = stripPathArg(arg);
  if (!typed) {
    return 'Usage: ' + form + ' check <file>. Give one file path. The file is scored and not changed.';
  }
  const abs = path.resolve(process.cwd(), typed);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (!st.isFile()) return typed + ' is not a file.';
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  if (P.BINARY_EXTS.includes(ext)) {
    return base + ': no readable text (' + ext + ' files are not extracted).';
  }
  const isPlain = !P.ARCHIVE_EXTS.includes(ext);
  const cap = isPlain ? P.PLAIN_CAP : P.ARCHIVE_CAP;
  if (st.size > cap) {
    return base + ': over ' + (cap / 1024) + ' KB, the ' + (isPlain ? 'plain-text' : 'archive') +
      ' limit; it was not scored.';
  }
  const r = P.scoreFile(abs, ext);
  if (!r.ok) {
    if (r.code === 'python') {
      return 'detector unavailable: Python was not found, so ' + base + ' was not scored.';
    }
    if (r.code === 'timeout') return base + ': scoring failed: the detector timed out.';
    if (r.code === 'exit') {
      return base + ': scoring failed (exit status ' + r.status + ')' +
        (r.stderr ? ': ' + r.stderr : '') + '.';
    }
    if (r.code === 'empty') return base + ': no report (the detector printed nothing).';
    return 'Detector returned no report.';
  }
  const lines = [];
  lines.push(base + ' - ' + P.phraseOf(r.band) + ' (score ' + r.score + '/100, band: ' + r.band + ')');
  let conf = 'confidence: ' + r.confidence;
  if (r.confidence !== 'high' && r.confidenceReason) conf += ' - ' + r.confidenceReason;
  lines.push(conf);
  if (r.truncated) {
    lines.push('coverage: first ' + P.WINDOW_TEXT + ' characters only; only that prefix was included in the scan.');
  }
  if (r.labels.length) {
    const parts = r.labels.slice(0, P.LABEL_CAP_CHECK).map((l) => l.label + ' (x' + l.count + ')');
    lines.push('tells: ' + parts.join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only: the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = P.currentLevel();
  const lines = [];
  lines.push('prosecheck doctor: install health check');
  if (level === 'off') {
    lines.push('mode: off - not a fault of the install; saving files triggers no scoring in this mode. ' +
      'Run /prosecheck on to switch it back on.');
  } else {
    lines.push('mode: ' + level + ' [OK]');
  }
  const det = P.detectorPath();
  if (det) {
    lines.push('detector: bundled detector found at ' + det + ' [OK]');
  } else {
    lines.push('detector: bundled detector is missing from the plugin tree');
  }
  const probe = P.runDetector([], {
    input: 'This is a short sample sentence for the install check.',
    timeoutMs: 8000,
  });
  let pyOk = false;
  if (!det) {
    lines.push('Python: not run, because the bundled detector is missing.');
  } else if (probe.notFound) {
    lines.push('Python: python not found on this machine, so saved files are not re-scored until Python is ' +
      'available; the writing contract still applies to new prose.');
  } else if (probe.timeout) {
    lines.push('Python: the bundled detector timed out on the install check.');
  } else {
    const parsed = P.parseReport(probe.stdout || '');
    if (parsed.report) {
      pyOk = true;
      lines.push('Python: ran the bundled detector and got a numeric score [OK]');
    } else {
      lines.push('Python: ran the bundled detector, but it returned no numeric score.');
    }
  }
  let writable = true;
  const dir = P.configDir();
  try {
    fs.mkdirSync(dir, { recursive: true });
    const probeFile = path.join(dir, '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(probeFile, 'ok', 'utf8');
    fs.unlinkSync(probeFile);
  } catch (e) {
    writable = false;
  }
  lines.push(writable
    ? 'settings: config folder ' + dir + ' is writable [OK]'
    : 'settings: config folder ' + dir + ' is not writable');

  const modeOk = level !== 'off';
  const detOk = !!det;
  const allOk = modeOk && detOk && pyOk && writable;
  const offOnly = level === 'off' && detOk && pyOk && writable;
  let closer;
  if (allOk) {
    closer = 'The tool is active. Limits: plain text up to 512 KB, archives and notebooks up to 4 MB, and ' +
      'the first ' + P.WINDOW_TEXT + ' characters of extracted prose are scanned. Run ' + form +
      ' show to see files that were only partly scanned or skipped.';
  } else if (offOnly) {
    closer = 'The install is healthy. Saved files are not scored in this mode. Run ' + form +
      ' on to switch scoring back on.';
  } else {
    closer = 'Fix the faulty checks above, then run /prosecheck doctor again.';
  }
  const out = lines.slice();
  out.push(closer);
  return out.join('\n');
}

function initReply(form) {
  const level = P.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written. Run ' + form +
      ' on to allow the export.';
  }
  const cwd = process.cwd();
  const notes = [];
  const agents = path.join(cwd, 'AGENTS.md');
  const section = '<!-- prosecheck:contract:start -->\n## Prose writing contract (prosecheck)\n\n' +
    P.contractText(level, { live: false }) + '\n<!-- prosecheck:contract:end -->\n';
  let existing = null;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    return 'cannot read AGENTS.md: ' + (e.code || e.message) + '; the contract was not written.';
  }
  if (existing !== null && /Prose writing contract \(prosecheck\)|prosecheck:contract:start/.test(existing)) {
    notes.push('AGENTS.md already contains the prose contract; it was left unchanged.');
  } else {
    try {
      let next;
      if (existing === null) {
        next = section;
      } else {
        const sep = existing.length === 0 ? '' : (existing.endsWith('\n') ? '\n' : '\n\n');
        next = existing + sep + section;
      }
      fs.writeFileSync(agents, next, 'utf8');
      notes.push('Wrote the prose contract to AGENTS.md (level ' + level + ').');
    } catch (e) {
      return 'cannot write AGENTS.md: ' + (e.code || e.message) + '; the contract was not written.';
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    notes.push('.cursor/rules/prosecheck.mdc already exists; it was left unchanged.');
  } else {
    try {
      const src = path.join(P.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const body = fs.readFileSync(src, 'utf8');
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, body, 'utf8');
      notes.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      notes.push('cannot write .cursor/rules/prosecheck.mdc: ' + (e.code || e.message) + '.');
    }
  }
  return notes.join('\n');
}

function commandReply(sub, arg, form, sid, payload) {
  const level = P.currentLevel();
  switch (sub) {
    case 'lite':
    case 'full':
    case 'strict':
      P.writeLevel(sub);
      return 'Writing contract level set to ' + sub + '.';
    case 'off':
      P.writeLevel('off');
      return 'prosecheck switched off (off). Saved files are not scored and the contract is not placed in ' +
        'new sessions. Run ' + form + ' on to switch it back on.';
    case 'on':
      P.writeLevel('full');
      return 'prosecheck is on (full). Use ' + form + ' lite, ' + form + ' full, or ' + form +
        ' strict to change the level.';
    case 'status':
      return 'prosecheck status: level is ' + level + '.';
    case 'show':
      return showReply(sid);
    case 'check':
      return checkReply(arg, form);
    case 'doctor':
      return doctorReply(form);
    case 'stats':
      return statsReply(payload.transcript_path, level);
    case 'init':
      return initReply(form);
    default:
      return helpReply(level);
  }
}

function main() {
  const payload = P.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const sid = payload.session_id;
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();

  if (STOP_PHRASES.includes(lower)) {
    P.writeLevel('off');
    block('prosecheck switched off (off). Run /prosecheck on to switch it back on.');
    return;
  }

  let form = null;
  if (lower === '/prosecheck' || lower.startsWith('/prosecheck ')) form = '/prosecheck';
  else if (lower === '/prosecheck:prosecheck' || lower.startsWith('/prosecheck:prosecheck ')) {
    form = '/prosecheck:prosecheck';
  }
  if (form) {
    const rest = trimmed.slice(form.length).trim();
    const space = rest.search(/\s/);
    const sub = (space === -1 ? rest : rest.slice(0, space)).toLowerCase();
    const arg = space === -1 ? '' : rest.slice(space).trim();
    if (!sub || sub === 'help') {
      block(helpReply(P.currentLevel()));
      return;
    }
    if (!P.SUBCOMMANDS.includes(sub)) {
      block(unknownReply(sub));
      return;
    }
    block(commandReply(sub, arg, form, sid, payload));
    return;
  }

  const level = P.currentLevel();
  if (level === 'off') return;
  P.emitJson({
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: P.reminderText(level) },
  });
}

try {
  main();
} catch (e) {
  /* malformed input or internal error: the host session is never failed */
}
process.exitCode = 0;
