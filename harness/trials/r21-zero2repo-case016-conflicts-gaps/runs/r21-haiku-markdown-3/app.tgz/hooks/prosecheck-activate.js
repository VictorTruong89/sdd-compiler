#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (with the one-time welcome on a fresh install).
const P = require('./lib/prosecheck.js');

function main() {
  const payload = P.readStdinJson();
  void payload;
  P.pruneLedgers();
  const level = P.currentLevel();
  if (level === 'off') return;
  const firstRun = !P.flagExists();
  if (P.storedLevel() === null) P.writeLevel(level);
  const parts = [];
  if (firstRun) parts.push(P.welcomeText());
  parts.push(P.contractText(level, { live: true, detector: P.detectorPath() }));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (e) {
  /* a hook never fails the host session */
}
process.exitCode = 0;
