#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract for delegated prose.
const P = require('./lib/prosecheck.js');

function main() {
  P.readStdinJson();
  const level = P.currentLevel();
  if (level === 'off') return;
  P.emitJson({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: P.contractText(level, { live: true, detector: P.detectorPath() }),
    },
  });
}

try {
  main();
} catch (e) {
  /* never fail the host */
}
process.exitCode = 0;
