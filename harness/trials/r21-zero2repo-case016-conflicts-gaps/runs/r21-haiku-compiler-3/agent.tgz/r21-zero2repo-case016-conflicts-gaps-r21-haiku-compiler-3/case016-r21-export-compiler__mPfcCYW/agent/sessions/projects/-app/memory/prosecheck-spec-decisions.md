---
name: prosecheck-spec-decisions
description: Conflict resolutions and unstated defaults chosen when building prosecheck from spec/ in /app; read before changing scoring, ledger, stats, or guard behaviour.
metadata:
  type: project
---

prosecheck was built from `spec/` in `/app` (detector `scripts/detect.py`, Node hooks under `hooks/`, tests under `tests/`). The full list of conflicts and assumptions is in `/app/NOTES.md`; these are the choices that a future change could easily undo by mistake.

- Ledger keeps the newest 20 records (PRD FP-05), not 50 (interface). Ledgers older than 7 days are hidden and pruned, not 1 day.
- `--help` prints usage to stdout; errors go to stderr as one JSON line.
- Decisive single-family 45 floor applies only at moderate or high confidence.
- "stop prosecheck" / "prosecheck off" match only as the entire prompt.
- `stats`: a named transcript_path wins over the newest file; session-prose score shown above 500 chars (interface), not 200 (PRD).
- apply_patch scores at most 10 paths (interface), not 16 (PRD).
- Trailing spaces are removed by cleanup even when they were a markdown hard break (FP-03 "required").

**Why:** the spec export left 16 contradictions unsettled and the choices above resolve them; a hidden test may follow either side, so changing one needs a matching NOTES.md update.
**How to apply:** when touching these behaviours, check NOTES.md first and update both files together.

Also: with `CLAUDE_PLUGIN_ROOT` unset, the plugin root is the repo (`/app`), so the guard skips prose files under `/app` by design (interface N-000694). See NOTES.md item 15.
