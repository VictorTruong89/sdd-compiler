---
description: prosecheck writing contract, saved-file guard, and operator commands
argument-hint: [lite|full|strict|off|on|status|show|check <path>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
