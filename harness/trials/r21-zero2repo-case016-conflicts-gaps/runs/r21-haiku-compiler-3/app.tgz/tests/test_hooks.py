"""Hook-level checks for hooks/*.js. Run: python3 -m unittest discover -s tests -v

Each test uses its own CLAUDE_CONFIG_DIR and working directory in a temp folder.
"""
import json
import os
import shutil
import subprocess
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOOKS = os.path.join(ROOT, 'hooks')

PROSE = ("In today's world, it is crucial to delve into the robust landscape of modern tools. "
         "Additionally, the platform will leverage synergy to foster growth. Moreover, the tapestry of "
         "vibrant communities is pivotal. Furthermore, we must embark on a journey to unlock potential.\n\n"
         "It's not just a tool, it's a movement. Let's dive in. It's worth noting that the results are "
         "genuinely fascinating. In conclusion, the future looks bright, and exciting times lie ahead.")


def run_hook(name, payload, env, cwd):
    data = payload if isinstance(payload, str) else json.dumps(payload)
    p = subprocess.run(['node', os.path.join(HOOKS, name)], input=data.encode('utf-8'),
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=cwd, timeout=60)
    return p.returncode, p.stdout.decode('utf-8')


class HookCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = os.path.join(self.tmp, 'cfg')
        self.work = os.path.join(self.tmp, 'work')
        os.makedirs(self.work)
        self.env = dict(os.environ, CLAUDE_CONFIG_DIR=self.cfg)
        self.env.pop('PROSECHECK_DEFAULT_MODE', None)
        self.env.pop('CLAUDE_PLUGIN_ROOT', None)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def prompt(self, text, sid='sess-1'):
        code, out = run_hook('prosecheck-tracker.js', {'prompt': text, 'session_id': sid}, self.env, self.work)
        self.assertEqual(code, 0)
        return json.loads(out)['reason'] if out.strip() else ''

    def level(self):
        with open(os.path.join(self.cfg, '.prosecheck-active')) as fh:
            return fh.read().strip()


class TestSessionStart(HookCase):
    # spec: N-000370..N-000379
    def test_first_start_has_welcome_and_stores_full(self):
        code, out = run_hook('prosecheck-activate.js', {}, self.env, self.work)
        self.assertEqual(code, 0)
        self.assertIn('71', out)
        self.assertIn('512 KB', out)
        self.assertIn('4 MB', out)
        self.assertIn('262,144', out)
        for cmd in ('/prosecheck doctor', '/prosecheck check', '/prosecheck off', '/prosecheck help'):
            self.assertIn(cmd, out)
        self.assertEqual(self.level(), 'full')

    def test_second_start_has_no_welcome(self):
        run_hook('prosecheck-activate.js', {}, self.env, self.work)
        code, out = run_hook('prosecheck-activate.js', {}, self.env, self.work)
        self.assertNotIn('shown once', out)
        self.assertIn('source code', out)

    def test_off_prints_nothing(self):
        self.prompt('/prosecheck off')
        code, out = run_hook('prosecheck-activate.js', {}, self.env, self.work)
        self.assertEqual(out, '')

    def test_lite_contract_has_no_full_target(self):
        self.prompt('/prosecheck lite')
        code, out = run_hook('prosecheck-activate.js', {}, self.env, self.work)
        self.assertNotIn('40', out)
        self.assertNotIn('light tells', out)


class TestRouter(HookCase):
    # spec: N-000468..N-000577, N-000870..N-000908
    def test_help_lists_every_subcommand(self):
        reason = self.prompt('/prosecheck')
        first = reason.splitlines()[0]
        self.assertIn('full', first)
        self.assertNotIn('strict', first)
        for word in ('lite', 'full', 'strict', 'off', 'status', 'show', 'check', 'doctor', 'stats', 'init'):
            self.assertIn('/prosecheck ' + word, reason)
        self.assertIn('/prosecheck off | on', reason)  # spec: off and on may share one line
        self.assertNotIn('/prosecheck help', reason)

    def test_unknown_word_keeps_level(self):
        self.prompt('/prosecheck strict')
        reason = self.prompt('/prosecheck wibble')
        self.assertIn('unknown', reason)
        self.assertIn('wibble', reason)
        self.assertEqual(self.level(), 'strict')

    def test_stop_phrase_entire_prompt_only(self):
        self.assertIn('off', self.prompt('stop prosecheck'))
        self.assertEqual(self.level(), 'off')
        self.prompt('/prosecheck on')
        code, out = run_hook('prosecheck-tracker.js', {'prompt': 'please stop prosecheck now'}, self.env, self.work)
        self.assertIn('hookSpecificOutput', out)  # ordinary prompt, not a block
        self.assertEqual(self.level(), 'full')

    def test_off_ordinary_prompt_is_silent(self):
        self.prompt('/prosecheck off')
        code, out = run_hook('prosecheck-tracker.js', {'prompt': 'draft a memo'}, self.env, self.work)
        self.assertEqual(out, '')

    def test_on_stores_full(self):
        self.prompt('/prosecheck off')
        reason = self.prompt('/prosecheck on')
        self.assertIn('on', reason)
        self.assertIn('full', reason)
        self.assertEqual(self.level(), 'full')

    def test_status_names_one_level(self):
        self.prompt('/prosecheck strict')
        reason = self.prompt('/prosecheck status')
        self.assertIn('strict', reason)
        for other in ('lite', 'full', 'off'):
            self.assertNotIn(other, reason)

    def test_namespaced_follow_up_uses_typed_form(self):
        self.assertIn('/prosecheck:prosecheck show', self.prompt('/prosecheck:prosecheck doctor'))
        self.assertIn('/prosecheck:prosecheck on', self.prompt('/prosecheck:prosecheck off') and
                      self.prompt('/prosecheck:prosecheck doctor'))


class TestDoctor(HookCase):
    # spec: N-000497..N-000517, N-000995..N-001028
    def test_healthy_has_four_ok_lines(self):
        reason = self.prompt('/prosecheck doctor')
        lines = reason.splitlines()
        self.assertEqual(lines[0], 'prosecheck doctor')
        self.assertEqual(sum(1 for l in lines if '[OK]' in l), 4)
        self.assertIn('512 KB', lines[-1])
        self.assertIn('262,144', lines[-1])
        self.assertIn('/prosecheck show', lines[-1])
        self.assertNotIn('/prosecheck doctor', lines[-1])

    def test_missing_python_line(self):
        bin_dir = os.path.join(self.tmp, 'bin')
        os.makedirs(bin_dir)
        os.symlink(shutil.which('node'), os.path.join(bin_dir, 'node'))
        env = dict(self.env, PATH=bin_dir)  # node reachable, python not on PATH
        p = subprocess.run(['node', os.path.join(HOOKS, 'prosecheck-tracker.js')],
                           input=json.dumps({'prompt': '/prosecheck doctor'}).encode(),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=self.work, timeout=60)
        reason = json.loads(p.stdout.decode())['reason']
        self.assertIn('python not found', reason)
        self.assertIn('not re-scored', reason)
        self.assertIn('prose', reason)

    def test_off_closer_names_on(self):
        self.prompt('/prosecheck off')
        reason = self.prompt('/prosecheck doctor')
        lines = reason.splitlines()
        self.assertIn('/prosecheck on', lines[1])
        self.assertIn('scored', lines[-1])
        self.assertNotIn('/prosecheck doctor', lines[-1])
        self.assertNotIn('[OK] mode', reason)


class TestInit(HookCase):
    # spec: N-000529..N-000542, N-001061..N-001102
    def test_init_writes_once_and_is_idempotent(self):
        self.prompt('/prosecheck full')
        reason = self.prompt('/prosecheck init')
        self.assertIn('AGENTS.md', reason)
        path = os.path.join(self.work, 'AGENTS.md')
        self.assertTrue(os.path.exists(path))
        with open(path, encoding='utf-8') as fh:
            before = fh.read()
        self.assertEqual(before.count('prosecheck:writing-contract:start'), 1)
        self.assertIn('CLAUDE_PLUGIN_ROOT', before)
        again = self.prompt('/prosecheck init')
        self.assertIn('already', again)
        with open(path, encoding='utf-8') as fh:
            self.assertEqual(fh.read(), before)

    def test_init_off_writes_nothing(self):
        self.prompt('/prosecheck off')
        reason = self.prompt('/prosecheck init')
        self.assertIn('switched off', reason)
        self.assertIn('/prosecheck on', reason)
        self.assertFalse(os.path.exists(os.path.join(self.work, 'AGENTS.md')))

    def test_lite_export_has_no_plugin_root(self):
        self.prompt('/prosecheck lite')
        self.prompt('/prosecheck init')
        with open(os.path.join(self.work, 'AGENTS.md'), encoding='utf-8') as fh:
            text = fh.read()
        self.assertNotIn('CLAUDE_PLUGIN_ROOT', text)
        self.assertNotIn('skills', text)
        self.assertNotIn('40', text)

    def test_cursor_rule_globs_are_prose_only(self):
        self.prompt('/prosecheck init')
        rule = open(os.path.join(self.work, '.cursor', 'rules', 'prosecheck.mdc'), encoding='utf-8').read()
        self.assertIn('*.md,*.mdx,*.markdown,*.txt,*.rst,*.tex,*.org,*.adoc', rule)
        self.assertNotIn('*.py', rule)
        self.assertNotIn('detect', rule.lower())


class TestGuard(HookCase):
    # spec: N-000395..N-000456
    def guard(self, payload):
        code, out = run_hook('prosecheck-guard.js', payload, self.env, self.work)
        self.assertEqual(code, 0)
        return json.loads(out)['hookSpecificOutput']['additionalContext'] if out.strip() else ''

    def test_flagged_file_nudge_names_file_phrase_and_fix(self):
        path = os.path.join(self.work, 'essay.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        ctx = self.guard({'tool_name': 'Write', 'tool_input': {'file_path': path}, 'session_id': 's'})
        self.assertIn('prosecheck: essay.md', ctx)
        self.assertIn('reads ', ctx)
        self.assertIn('Fix', ctx)

    def test_lite_is_silent(self):
        self.prompt('/prosecheck lite')
        path = os.path.join(self.work, 'essay.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        self.assertEqual(self.guard({'tool_name': 'Write', 'tool_input': {'file_path': path}}), '')

    def test_instruction_file_skipped_and_not_recorded(self):
        path = os.path.join(self.work, 'CLAUDE.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        self.assertEqual(self.guard({'tool_name': 'Write', 'tool_input': {'file_path': path}}), '')
        self.assertIn('nothing scored yet', self.prompt('/prosecheck show'))

    def test_pdf_recorded_as_binary_and_no_nudge(self):
        path = os.path.join(self.work, 'deliverable.pdf')
        with open(path, 'wb') as fh:
            fh.write(b'%PDF-1.4')
        self.assertEqual(self.guard({'tool_name': 'Write', 'tool_input': {'file_path': path}, 'session_id': 'sess-1'}), '')
        self.assertIn('not re-scored', self.prompt('/prosecheck show'))

    def test_apply_patch_paths(self):
        path = os.path.join(self.work, 'essay.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        body = '*** Begin Patch\n*** Update File: ' + path + '\n@@\n-a\n+b\n*** End Patch'
        ctx = self.guard({'tool_name': 'apply_patch', 'tool_input': {'command': body}})
        self.assertIn('essay.md', ctx)


class TestCheckAndShow(HookCase):
    # spec: N-000490..N-000496, N-000518..N-000528, N-000963..N-000992
    def test_check_is_report_only_and_quotes_stripped(self):
        path = os.path.join(self.work, 'essay.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        with open(path, 'rb') as fh:
            before = fh.read()
        reason = self.prompt("/prosecheck check @'%s'" % path)
        self.assertIn('score', reason)
        self.assertIn('report only', reason)
        self.assertIn('tells:', reason)
        self.assertNotIn('was written by', reason)
        with open(path, 'rb') as fh:
            self.assertEqual(fh.read(), before)

    def test_check_missing_and_directory(self):
        self.assertIn('cannot read', self.prompt('/prosecheck check nope.md'))
        self.assertIn('not a file', self.prompt('/prosecheck check %s' % self.work))

    def test_show_is_per_session(self):
        path = os.path.join(self.work, 'essay.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE)
        run_hook('prosecheck-guard.js', {'tool_name': 'Write', 'tool_input': {'file_path': path}, 'session_id': 'a'},
                 self.env, self.work)
        self.assertIn('essay.md', self.prompt('/prosecheck show', sid='a'))
        self.assertIn('nothing scored yet', self.prompt('/prosecheck show', sid='b'))


class TestStats(HookCase):
    # spec: N-001103..N-001121
    def test_counts_and_missing(self):
        t = os.path.join(self.tmp, 't.jsonl')
        rows = [
            {'type': 'user', 'message': {'content': 'hi'}},
            {'type': 'assistant', 'message': {'id': 'm1', 'content': [{'type': 'text', 'text': 'Hello there.'}],
                                              'usage': {'output_tokens': 12, 'cache_read_input_tokens': 100}}},
            {'type': 'assistant', 'message': {'id': 'm1', 'content': [{'type': 'text', 'text': 'Hello there.'}],
                                              'usage': {'output_tokens': 12, 'cache_read_input_tokens': 100}}},
            {'type': 'assistant', 'message': {'id': 'm2', 'content': [{'type': 'text', 'text': 'Two.'}],
                                              'usage': {'output_tokens': 7, 'cache_read_input_tokens': 50}}},
        ]
        with open(t, 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(json.dumps(r) for r in rows))
        reason = self.prompt('/prosecheck stats')  # no transcript named: nothing to read
        self.assertIn('could not be read', reason)
        code, out = run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck stats', 'transcript_path': t},
                             self.env, self.work)
        reason = json.loads(out)['reason']
        self.assertIn('assistant turns: 2', reason)
        self.assertIn('output tokens: 19', reason)
        self.assertIn('cache-read input tokens: 150', reason)


if __name__ == '__main__':
    unittest.main()
