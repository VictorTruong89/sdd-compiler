"""Behavior checks for scripts/detect.py. Run: python3 -m unittest discover -s tests -v

Named after the spec ids they exercise (see NOTES.md for the id map).
"""
import importlib.util
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')

spec = importlib.util.spec_from_file_location('detect', DETECT)
det = importlib.util.module_from_spec(spec)
spec.loader.exec_module(det)


def run_cli(args, stdin=b''):
    p = subprocess.run([sys.executable, DETECT] + args, input=stdin,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    return p.returncode, p.stdout.decode('utf-8'), p.stderr.decode('utf-8')


def report_for(text):
    return det.build_report(text)


PLAIN_HUMAN = ("The river rose after three days of rain. Farmers moved their cattle to higher ground "
               "and the county opened two shelters near the bridge. Officials expect the water to fall "
               "by Friday, although the forecast calls for more storms next week. Nobody was hurt.")


class TestBands(unittest.TestCase):
    # spec: N-000115 five bands
    def test_band_edges(self):
        self.assertEqual(det.band_of(0), 'clean')
        self.assertEqual(det.band_of(20), 'clean')
        self.assertEqual(det.band_of(21), 'light tells')
        self.assertEqual(det.band_of(40), 'light tells')
        self.assertEqual(det.band_of(41), 'mixed')
        self.assertEqual(det.band_of(61), 'heavy tells')
        self.assertEqual(det.band_of(81), 'pervasive tells')
        self.assertEqual(det.band_of(100), 'pervasive tells')


class TestScoring(unittest.TestCase):
    # spec: N-000131..N-000148 floors, caps, confidence

    def test_single_family_capped_at_40(self):
        text = ' '.join(['This is a crucial point.'] * 30)  # one family, many hits
        r = report_for(text)
        self.assertLessEqual(r['_metrics']['ai_tell_score'], 40)

    def test_monotony_only_at_most_20(self):
        sents = ['Plain words sit here today.', 'Other plain words sit here now.',
                 'Some more plain words sit here too.', 'Last plain words sit here as well.']
        text = ' '.join(sents)
        r = report_for(text)
        self.assertIn('40_sentence_monotony', r)
        self.assertLessEqual(r['_metrics']['ai_tell_score'], 20)

    def test_advice_only_scores_zero(self):
        text = PLAIN_HUMAN + "  \n\nIt is worth 4 things; well, more."  # trailing spaces only
        r = report_for(text)
        self.assertEqual(r['_metrics']['ai_tell_score'], 0)

    def test_advice_does_not_change_score(self):
        base = PLAIN_HUMAN + ' Certainly! This is fine.'
        extra = base + ' Here is a note — with a dash — and another — one more.'
        a = report_for(base)['_metrics']['ai_tell_score']
        b = report_for(extra)['_metrics']['ai_tell_score']
        self.assertEqual(a, b)

    def test_two_decisive_families_floor_65(self):
        text = 'Certainly! Great question. ' + PLAIN_HUMAN
        r = report_for(text)
        self.assertGreaterEqual(r['_metrics']['ai_tell_score'], 65)

    def test_confidence_bands(self):
        self.assertEqual(report_for('short text here.')['_metrics']['confidence'], 'none')
        words = ' '.join(['word'] * 60) + '.'
        self.assertEqual(report_for(words)['_metrics']['confidence'], 'low')
        self.assertIn(report_for(' '.join(['word'] * 320) + '.')['_metrics']['confidence'], ('high',))

    def test_non_high_confidence_has_reason(self):
        r = report_for('short text here.')['_metrics']
        self.assertTrue(r['confidence_reason'])


class TestPatterns(unittest.TestCase):
    # spec: N-000152, N-000153, N-000171, N-000177, N-000180

    def test_ai_vocab_fires_and_inflects(self):
        r = report_for('We will leverage and leveraged tools while delving into it.')
        self.assertIn('1_ai_vocabulary', r)
        self.assertGreaterEqual(r['1_ai_vocabulary']['count'], 3)

    def test_dialect_needs_two_hits(self):
        r = report_for('This is genuinely a good plan for the team today and tomorrow.')
        self.assertNotIn('2_model_dialect', r)
        r = report_for('It is genuinely good. It is genuinely fascinating for everyone here.')
        self.assertIn('2_model_dialect', r)

    def test_nine_detectorless_numbers_never_appear(self):
        text = PLAIN_HUMAN + ' ' + 'Lorem ipsum dolor. ' * 3
        keys = [k for k in report_for(text) if k != '_metrics']
        for num in (7, 9, 28, 29, 43, 45, 49, 52, 53):
            self.assertFalse(any(k.startswith('%d_' % num) for k in keys), num)

    def test_tracking_param_only_for_listed_hosts(self):
        self.assertIn('65_tracking_param', report_for('See https://x.test/?utm_source=chatgpt.com today now.'))
        self.assertNotIn('65_tracking_param', report_for('See https://x.test/?utm_source=google today now.'))

    def test_trailing_whitespace_is_advice_not_score(self):
        r = report_for('Line one.   \nLine two here.\n')
        self.assertIn('68_trailing_whitespace', r)
        self.assertEqual(r['68_trailing_whitespace']['label'], 'Trailing or stray whitespace')

    def test_code_fence_generates_no_findings(self):
        text = '```\nIt is crucial to delve into this.\n```\n' + PLAIN_HUMAN
        self.assertNotIn('1_ai_vocabulary', report_for(text))

    def test_writing_advice_labels_present_for_em_dash(self):
        text = 'One — two — three in the same paragraph here, plainly stated.'
        self.assertIn('58_em_dash', report_for(text))


class TestCharacterLayer(unittest.TestCase):
    # spec: N-000303..N-000331 cleanup; N-000171 invisible; N-000177 homoglyph

    def test_zero_width_space_removed_in_latin_text(self):
        t = 'hello​world'
        self.assertEqual(det.scrub(t), 'helloworld')

    def test_zwsp_kept_beside_thai(self):
        t = 'ภาษา​ไทย'
        self.assertEqual(det.scrub(t), t)

    def test_nbsp_kept_between_digits(self):
        t = '5 kg'
        self.assertEqual(det.scrub(t), t)
        self.assertEqual(det.scrub('a b'), 'a b')

    def test_cleanup_rescan_is_clean(self):
        t = 'aб​c d e­ f﻿ g'
        s = det.scrub(t)
        self.assertEqual(det.invisible_indices(s), [])
        self.assertEqual(det.nonstandard_space_indices(s), [])
        self.assertEqual(det.homoglyph_tokens(s), [])

    def test_homoglyph_folded_only_in_mixed_tokens(self):
        self.assertEqual(det.scrub('pаssword'), 'password')
        self.assertEqual(det.scrub('привет мир'), 'привет мир')

    def test_trim_rules(self):
        self.assertEqual(det.scrub('\n\n  Hello   \n\n\n'), '  Hello\n')

    def test_window_counts(self):
        text = 'a' * (det.WINDOW - 5) + '​' + 'x' * 10 + '​'
        r = report_for(text)
        self.assertTrue(r['_metrics']['truncated'])
        self.assertEqual(r['_metrics']['invisible_chars'], 1)


class TestExtraction(unittest.TestCase):
    # spec: N-000256..N-000281 (zip-based documents), N-000271 (notebooks)

    def _zip(self, parts):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            for name, data in parts.items():
                z.writestr(name, data)
        return buf.getvalue()

    def test_docx(self):
        doc = ('<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Hello &amp; welcome.</w:t></w:r></w:p>'
               '<w:p><w:r><w:t>Second.</w:t></w:r></w:p></w:body></w:document>')
        out = det.extract_from_bytes(self._zip({'word/document.xml': doc}), '.docx')
        self.assertEqual(out, 'Hello & welcome.\nSecond.')

    def test_notebook_markdown_only(self):
        nb = {'cells': [{'cell_type': 'markdown', 'source': ['# T\n', 'Prose.']},
                        {'cell_type': 'code', 'source': ['print(1)']}]}
        out = det.extract_from_bytes(json.dumps(nb).encode(), '.ipynb')
        self.assertEqual(out, '# T\nProse.')
        self.assertEqual(det.extract_from_bytes(b'not json', '.ipynb'), '')

    def test_bad_zip_is_cannot_read(self):
        with self.assertRaises(det.InputError) as cm:
            det.extract_from_bytes(b'nope', '.docx')
        self.assertTrue(str(cm.exception).startswith('cannot read input:'))

    def test_pdf_has_no_prose(self):
        self.assertEqual(det.extract_from_bytes(b'%PDF-1.4 text', '.pdf'), '')


class TestCLI(unittest.TestCase):
    # spec: N-000226..N-000242, N-000777..N-000787

    def test_report_on_stdin(self):
        code, out, err = run_cli([], PLAIN_HUMAN.encode())
        self.assertEqual(code, 0)
        self.assertIn('_metrics', json.loads(out))

    def test_empty_input_exit_1_json_error(self):
        code, out, err = run_cli([], b'   \n')
        self.assertEqual(code, 1)
        self.assertEqual(out, '')
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})
        self.assertNotIn('Traceback', err)

    def test_unknown_option_exit_2(self):
        code, out, err = run_cli(['--zzz'], b'x')
        self.assertEqual(code, 2)
        last = json.loads(err.strip().splitlines()[-1])
        self.assertIn('unknown option', last['error'])
        self.assertIn('--zzz', last['error'])
        self.assertIn('--help', last['error'])

    def test_help_exit_0_stdout_usage_first_line(self):
        code, out, err = run_cli(['--help'])
        self.assertEqual(code, 0)
        self.assertEqual(out.splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_double_dash_allows_dash_name(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, '-odd.md')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(PLAIN_HUMAN)
            code, out, err = run_cli(['--', path])
            self.assertEqual(code, 0)

    def test_two_files_scan_first_with_notice(self):
        with tempfile.TemporaryDirectory() as d:
            a = os.path.join(d, 'a.md')
            b = os.path.join(d, 'b.md')
            for p in (a, b):
                with open(p, 'w', encoding='utf-8') as fh:
                    fh.write(PLAIN_HUMAN)
            code, out, err = run_cli([a, b])
            self.assertEqual(code, 0)
            self.assertIn(a, err)

    def test_clean_prints_text_not_json(self):
        code, out, err = run_cli(['--clean'], 'Hi  ​ there\n'.encode())
        self.assertEqual(code, 0)
        self.assertEqual(out, 'Hi   there\n')

    def test_ci_interval_present_only_with_flag(self):
        code, out, _ = run_cli([], PLAIN_HUMAN.encode())
        self.assertNotIn('score_ci', json.loads(out)['_metrics'])
        code, out, _ = run_cli(['--ci'], PLAIN_HUMAN.encode())
        m = json.loads(out)['_metrics']
        self.assertIn('score_ci', m)
        self.assertLessEqual(m['score_ci'][0], m['score_ci'][1])


if __name__ == '__main__':
    unittest.main()
