#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is
// flagged. Always exits 0. Silent when the level is off or lite.
// spec: N-000395..N-000456 (FP-05 saved-file guard)
// spec: N-000729..N-000730 and N-000770..N-000835 (post-tool-use reply shape)

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const MAX_PATHS = 10; // spec: interface contract (PRD FP-05 says 16; see NOTES.md)
const PLAIN_TIMEOUT = 8000;
const ARCHIVE_TIMEOUT = 15000;
const BODY_PATH_RE = /^\*\*\*\s*(Add File|Update File|Move to)\s*:\s*(.+?)\s*$/gm;

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (common.INSTRUCTION_NAMES.includes(lower)) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (common.INSTRUCTION_STEMS.includes(stem) && !common.PROSE_EXTS.includes(ext)) return true;
  return false;
}

function insidePluginTree(abs) {
  const root = common.pluginRoot();
  const rel = path.relative(root, abs);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function collectPaths(tool, ti) {
  const out = [];
  if (tool === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : '');
    let m;
    BODY_PATH_RE.lastIndex = 0;
    while ((m = BODY_PATH_RE.exec(body)) !== null) {
      const p = m[2].trim();
      if (p) out.push(p);
    }
    return out;
  }
  if (tool === 'NotebookEdit') {
    const p = ti.notebook_path || ti.file_path;
    if (typeof p === 'string' && p.trim()) out.push(p.trim());
    return out;
  }
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) out.push(ti.file_path.trim());
  return out;
}

function scoreOne(rawPath, cwd, level, sid) {
  const abs = path.isAbsolute(rawPath) ? rawPath : path.resolve(cwd || process.cwd(), rawPath);
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const segments = abs.split(/[\\/]/);
  if (segments.includes('node_modules') || segments.includes('.git')) return null;
  if (insidePluginTree(abs)) return null;
  if (isInstructionFile(base)) return null;
  if (common.NO_PROSE_EXTS.includes(ext)) {
    common.appendLedger(sid, { base, status: 'binary', ext });
    return null;
  }
  if (!common.PROSE_EXTS.includes(ext)) return null;

  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    common.appendLedger(sid, { base, status: 'failed', reason: 'cannot read file' });
    return null;
  }
  if (!st.isFile()) return null;

  const archive = common.ARCHIVE_EXTS.includes(ext);
  const cap = archive ? common.ARCHIVE_CAP : common.PLAIN_CAP;
  if (st.size > cap) {
    const kb = Math.round(cap / 1024);
    common.appendLedger(sid, { base, status: 'skipped', cap: kb, reason: 'over ' + kb + ' KB limit' });
    return null;
  }

  const run = common.runDetector(['--', abs], undefined, archive ? ARCHIVE_TIMEOUT : PLAIN_TIMEOUT);
  const parsed = common.parseReport(run);
  if (!parsed.ok) {
    common.appendLedger(sid, { base, status: 'failed', reason: parsed.reason });
    return null;
  }
  const m = parsed.report._metrics;
  const score = m.ai_tell_score;
  const band = m.ai_tell_band;
  const labels = common.findingLabels(parsed.report).map((x) => x.label).slice(0, 5);
  const flagged = score > common.threshold(level);
  common.appendLedger(sid, {
    base, status: 'scored', score, band, labels, flagged, truncated: !!m.truncated,
  });
  if (!flagged) return null;

  const coverage = m.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  const labelText = labels.length ? labels.join('; ') : 'none';
  return 'prosecheck: ' + base + ' ' + common.hookPhrase(band) + ' (score ' + score + ', band ' + band +
    coverage + '). Flagged: ' + labelText + '. Fix the flagged spans, keeping the sentence rhythm.';
}

function main() {
  const input = common.readInput();
  const level = common.effectiveLevel();
  if (level === 'off' || level === 'lite') return;
  const tool = typeof input.tool_name === 'string' ? input.tool_name : '';
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : null;
  const sid = typeof input.session_id === 'string' ? input.session_id : '';

  let paths = collectPaths(tool, ti);
  paths = paths.filter((p, i) => paths.indexOf(p) === i);
  if (paths.length === 0) return;
  paths = paths.slice(0, MAX_PATHS);

  const lines = [];
  for (const p of paths) {
    const line = scoreOne(p, cwd, level, sid);
    if (line) lines.push(line);
  }
  if (lines.length === 0) return;
  common.emitJson({
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: lines.join('\n'),
    },
  });
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
