#!/usr/bin/env node
'use strict';
// Stats for `/prosecheck stats`. Reads the session transcript the host named
// (transcript_path) or else the newest .jsonl under the config folder's
// projects folder. Prints a block decision whose reason is the reply.
// spec: N-001103..N-001121 (stats), N-000543..N-000555 (FP-06 stats)

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const FENCE_RE = /```[\s\S]*?```|~~~[\s\S]*?~~~/g;
const SLICE_CHARS = 40000;
const SCORE_MIN_CHARS = 500; // spec: N-001115 (interface contract); PRD says 200

function newestTranscript() {
  const root = path.join(common.configDir(), 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 4) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(p, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        const mtime = fs.statSync(p).mtimeMs;
        if (!best || mtime > best.mtime) best = { path: p, mtime };
      }
    }
  };
  walk(root, 0);
  return best ? best.path : null;
}

function readTranscript(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const byId = new Map();
  let anon = 0;
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : 'anon-' + (anon++);
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const texts = [];
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    }
    byId.set(id, {
      output: Number(usage.output_tokens) || 0,
      cacheRead: Number(usage.cache_read_input_tokens) || 0,
      text: texts.join('\n'),
    });
  }
  let output = 0;
  let cacheRead = 0;
  const parts = [];
  for (const v of byId.values()) {
    output += v.output;
    cacheRead += v.cacheRead;
    if (v.text) parts.push(v.text);
  }
  return { turns: byId.size, output, cacheRead, text: parts.join('\n') };
}

function statsReply(input) {
  const level = common.effectiveLevel();
  let file = null;
  if (typeof input.transcript_path === 'string' && input.transcript_path.trim()) {
    file = input.transcript_path.trim();
  } else {
    file = newestTranscript();
  }
  const data = file ? readTranscript(file) : null;
  if (!data) {
    return 'prosecheck stats: the transcript could not be read, so no turn or token figures are available. level: ' + level;
  }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.output,
    'cache-read input tokens: ' + data.cacheRead,
  ];
  const prose = data.text.replace(FENCE_RE, ' ').slice(-SLICE_CHARS).trim();
  if (prose.length > SCORE_MIN_CHARS) {
    const run = common.runDetector([], prose, 15000);
    const parsed = common.parseReport(run);
    if (parsed.ok) {
      lines.push('session prose ai_tell_score: ' + parsed.report._metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const input = common.readInput();
    common.emitJson({ decision: 'block', reason: statsReply(input) });
  } catch (e) {
    // never fail the host
  }
  process.exitCode = 0;
}
