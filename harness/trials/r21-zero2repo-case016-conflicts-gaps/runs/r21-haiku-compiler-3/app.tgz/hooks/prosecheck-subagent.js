#!/usr/bin/env node
'use strict';
// Subagent-start hook. Returns the writing contract inside the JSON envelope
// the host keeps for a subagent-start event. Nothing when the level is off.
// spec: N-000813..N-000818 (hooks/prosecheck-subagent.js)

const common = require('./lib/common');

try {
  common.readInput();
  const level = common.effectiveLevel();
  if (level !== 'off') {
    common.emitJson({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: common.contractText(level),
      },
    });
  }
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
