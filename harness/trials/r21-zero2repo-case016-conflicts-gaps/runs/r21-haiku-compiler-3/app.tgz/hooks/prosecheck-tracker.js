#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router. Always exits 0.
// spec: N-000380..N-000385 (reminder), N-000457..N-000577 (FP-06 commands),
//       N-000870..N-000908 (/prosecheck interface), N-000993..N-001102 (doctor, init)

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');
const stats = require('./prosecheck-stats');

const CMD_RE = /^\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/i;

function cleanPathArg(s) {
  let p = String(s || '').trim();
  if (p.startsWith('@')) p = p.slice(1).trim();
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  return p;
}

function block(reason) {
  return { decision: 'block', reason };
}

// ----------------------------------------------------------------- subcommands

function setLevelReply(level, form) {
  if (level === 'off') {
    common.writeLevel('off');
    return 'prosecheck is off. Saved files are no longer scored and the writing contract is not added. Run ' + form + ' on to switch it back on.';
  }
  if (level === 'on') {
    common.writeLevel('full');
    return 'prosecheck on: the tool is on at level full (the default).';
  }
  common.writeLevel(level);
  return 'prosecheck level set to ' + level + '.';
}

function statusReply() {
  return 'prosecheck status: level is ' + common.effectiveLevel() + '.';
}

function unknownReply(word) {
  return 'unknown subcommand: ' + word + '. Valid subcommands: ' + common.SUBCOMMANDS.join(', ') + '.';
}

function helpReply(form) {
  const f = '/prosecheck';
  const live = common.effectiveLevel();
  const lines = [
    'prosecheck: the live level is ' + live + '.',
    'Code, commits, config, and chat are always left alone; the writing contract never touches them.',
    f + ' lite - turns on the writing contract without scoring saved files.',
    f + ' full - writing contract plus the saved-file guard with its threshold of 40 (default).',
    f + ' strict - lowers the guard threshold to 20 and adds the cleanup scrub.',
    f + ' off | on - off: disable the tool; on: re-enable it at full.',
    f + ' status - reports the current level in one line.',
    f + ' check <path> - scores one file as a report only; check does not rewrite the file.',
    f + ' show - lists this session\'s saved-file scores, newest first.',
    f + ' doctor - a health check of the install.',
    f + ' stats - token use for this session and the score of its own prose.',
    f + ' init - exports the contract to AGENTS.md for agents other than Claude Code.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ];
  return lines.join('\n');
}

function checkReply(rawArg) {
  const target = cleanPathArg(rawArg);
  if (!target) {
    return 'usage: /prosecheck check <path>. Give the path of one prose file to score.';
  }
  const cwd = process.cwd();
  const abs = path.isAbsolute(target) ? target : path.resolve(cwd, target);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + target + ': no such file.';
  }
  if (!st.isFile()) return target + ' is not a file.';
  const ext = path.extname(abs).toLowerCase();
  if (common.NO_PROSE_EXTS.includes(ext)) {
    return base + ': no readable text in this format (' + ext + ' is not scored).';
  }
  if (!common.PROSE_EXTS.includes(ext)) {
    return base + ': no readable text; this extension is not one of the supported prose formats.';
  }
  const archive = common.ARCHIVE_EXTS.includes(ext);
  const cap = archive ? common.ARCHIVE_CAP : common.PLAIN_CAP;
  if (st.size > cap) {
    const kb = archive ? common.ARCHIVE_MB * 1024 : common.PLAIN_KB;
    return base + ' is over ' + kb + ' KB and was not scored.';
  }
  const run = common.runDetector(['--', abs], undefined, archive ? 15000 : 8000);
  if (run.notFound) return 'detector unavailable: Python was not found, so ' + base + ' was not scored.';
  if (run.timedOut) return base + ' failed: the detector timed out.';
  const out = (run.stdout || '').trim();
  if (run.status === 0 && !out) return 'no report for ' + base + '.';
  const parsed = common.parseReport(run);
  if (!parsed.ok) {
    if (parsed.reason === 'detector output is not a report' && run.status === 0) {
      return 'no report: the detector printed text that is not a report.';
    }
    if (parsed.reason === 'report has no numeric score' && run.status === 0) {
      return 'no report: the detector printed text that is not a report.';
    }
    const errText = (run.stderr || '').trim().split('\n').filter(Boolean).pop() || '';
    return base + ' failed: ' + (errText || 'the detector produced no usable result') + '.';
  }
  const r = parsed.report;
  const m = r._metrics;
  const lines = [];
  lines.push(base + ' - ' + common.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + common.WINDOW_TEXT + ' characters only');
  const labels = common.findingLabels(r).slice(0, 8);
  if (labels.length === 0) {
    lines.push('tells: none');
  } else {
    lines.push('tells: ' + labels.map((x) => x.label + ' (x' + x.count + ')').join('; '));
  }
  lines.push('This is report only: the check does not rewrite the file.');
  return lines.join('\n');
}

function showReply(sid) {
  const { rows, stale } = common.readLedger(sid);
  void stale;
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['prosecheck ledger for this session, newest first:'];
  for (const row of rows.slice().reverse()) {
    const base = String(row.base || '');
    if (row.status === 'scored') {
      let body = common.hookPhrase(row.band) + ' (score ' + row.score + '/' + row.band;
      if (row.truncated) body += ', first ' + common.WINDOW_TEXT + ' characters only';
      body += ')';
      if (Array.isArray(row.labels) && row.labels.length) {
        const state = row.flagged ? 'flagged' : 'under threshold';
        body += ' - ' + state + ': ' + row.labels.slice(0, 5).join('; ');
      }
      out.push('  ' + base + ' - ' + body);
    } else if (row.status === 'skipped') {
      out.push('  ' + base + ' - not scored: this file is over the ' + row.cap + ' KB limit');
    } else if (row.status === 'binary') {
      out.push('  ' + base + ' - not re-scored: ' + (row.ext || 'binary') + ' files have no readable text');
    } else {
      out.push('  ' + base + ' - not scored: ' + (row.reason || 'unknown reason'));
    }
  }
  return out.join('\n');
}

// Doctor: four check lines, a title, and a closer.
function doctorReply(form) {
  const level = common.effectiveLevel();
  const off = level === 'off';
  const modeOk = !off;

  const detector = common.detectorPath();
  const detectorOk = !!detector;

  const pyRun = detectorOk
    ? common.runDetector([], 'This is a short sample sentence for the health check.\n', 8000)
    : { notFound: false, timedOut: false, status: -1, stdout: '', stderr: '', missingScript: true };
  let pyOk = false;
  let pyLine;
  if (!detectorOk) {
    pyLine = 'python: not run, because the bundled detector is missing from the plugin tree.';
  } else if (pyRun.notFound) {
    pyLine = 'python not found: saved files are not re-scored until Python is available, but prose is still shaped by the writing contract.';
  } else {
    const parsed = common.parseReport(pyRun);
    if (parsed.ok) {
      pyOk = true;
      pyLine = '[OK] python: the detector ran and returned a numeric score (' + parsed.report._metrics.ai_tell_score + ').';
    } else {
      pyLine = 'python: the detector ran but did not return a numeric score.';
    }
  }

  let settingsOk = false;
  try {
    fs.mkdirSync(common.configDir(), { recursive: true });
    fs.accessSync(common.configDir(), fs.constants.W_OK);
    settingsOk = true;
  } catch (e) {
    settingsOk = false;
  }

  const modeLine = modeOk
    ? '[OK] mode: ' + level
    : 'mode: off (not a fault of the install); run /prosecheck on to switch the tool back on.';
  const detectorLine = detectorOk
    ? '[OK] detector: the bundled detector is present in the plugin tree.'
    : 'fault: detector: the bundled detector was not found in the plugin tree.';
  const settingsLine = settingsOk
    ? '[OK] settings: the config folder is writable.'
    : 'fault: settings: the config folder is not writable.';

  const faults = [!detectorOk, !pyOk, !settingsOk].some(Boolean);
  let closer;
  if (!faults && modeOk) {
    closer = 'prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored; the first 262,144 characters are scanned. Use ' +
      form + ' show to see files that were only partly scanned or skipped.';
  } else if (faults) {
    closer = 'Fix the faulty checks above, then run /prosecheck doctor again.';
  } else {
    closer = 'Everything else is healthy. While the tool is off, saving files triggers no scoring; run ' +
      form + ' on to turn it back on and have saved files scored.';
  }

  return ['prosecheck doctor', modeLine, detectorLine, pyLine, settingsLine, closer].join('\n');
}

// Init writes the contract into ./AGENTS.md and copies the Cursor rule.
function initReply(form) {
  const level = common.effectiveLevel();
  if (level === 'off') {
    return 'switched off: init wrote no files. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let agentsExists = false;
  try {
    agentsExists = fs.existsSync(agents);
    if (agentsExists) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    lines.push('cannot read AGENTS.md; the writing contract was not added to it.');
    existing = null;
    agentsExists = true;
  }
  if (existing !== null && existing.indexOf(common.CONTRACT_MARKER_START) !== -1) {
    lines.push('AGENTS.md already has the writing contract; it was left unchanged.');
  } else if (!(agentsExists && existing === null)) {
    try {
      const prefix = existing === null || existing.length === 0 ? '' : (existing.endsWith('\n') ? existing : existing + '\n') + '\n';
      fs.writeFileSync(agents, prefix + common.exportSection(level), 'utf8');
      lines.push('wrote the writing contract to AGENTS.md.');
    } catch (e) {
      lines.push('cannot write AGENTS.md; the writing contract was not added.');
    }
  }

  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  const shipped = path.join(common.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    lines.push('.cursor/rules/prosecheck.mdc already exists; it was left unchanged.');
  } else {
    try {
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.copyFileSync(shipped, rule);
      lines.push('copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc; the Cursor rule was not created.');
    }
  }
  return lines.join('\n');
}

// ----------------------------------------------------------------- router

function route(prompt, input, form) {
  const m = CMD_RE.exec(prompt);
  const rest = m[1] || '';
  const trimmed = rest.trim();
  const sp = trimmed.search(/\s/);
  const word = (sp === -1 ? trimmed : trimmed.slice(0, sp)).toLowerCase();
  const arg = sp === -1 ? '' : trimmed.slice(sp).trim();

  if (!word || word === 'help') return block(helpReply(form));
  if (['lite', 'full', 'strict', 'off', 'on'].includes(word)) return block(setLevelReply(word, form));
  if (word === 'status') return block(statusReply());
  if (word === 'show') return block(showReply(input.session_id));
  if (word === 'check') return block(checkReply(arg));
  if (word === 'doctor') return block(doctorReply(form));
  if (word === 'stats') return block(stats.statsReply(input));
  if (word === 'init') return block(initReply(form));
  return block(unknownReply(word));
}

function main() {
  const input = common.readInput();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const level = common.effectiveLevel();

  // stop phrases: the entire prompt, letter case ignored
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    common.writeLevel('off');
    common.emitJson(block('prosecheck is off. Run /prosecheck on to switch the tool back on.'));
    return;
  }

  const cm = CMD_RE.exec(trimmed);
  if (cm) {
    const form = /^\/prosecheck:prosecheck/i.test(trimmed) ? '/prosecheck:prosecheck' : '/prosecheck';
    common.emitJson(route(trimmed, input, form));
    return;
  }

  if (level === 'off') return;
  common.emitJson({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: common.promptReminder(level),
    },
  });
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
