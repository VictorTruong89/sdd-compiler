#!/usr/bin/env node
'use strict';
// Session-start hook. Prints the writing contract (plain text) for the stored
// level; prints nothing when the level is off. Always exits 0.
// spec: N-000788..N-000794 (hooks/prosecheck-activate.js)
// spec: N-000335, N-000370..N-000379 (session start, welcome, stored level)

const common = require('./lib/common');

function main() {
  const input = common.readInput();
  void input; // malformed or empty input is an empty object
  common.pruneLedgers();
  const first = !common.flagExists();
  const level = common.effectiveLevel();
  // a fresh install stores the default level; an environment override is not written
  if (first) common.writeLevel(common.DEFAULT_LEVEL);
  if (level === 'off') return;
  common.emit(common.sessionStartText(level, first));
}

try {
  main();
} catch (e) {
  // a hook never fails the host session
}
process.exitCode = 0;
