# Checklist status

Accounting for every id in `spec/CHECKLIST.md`. Each pack is marked by where its ids are implemented.
The mapping is per pack (I did not test each of the 1126 ids separately). Behaviour is checked by
`tests/test_detect.py` and `tests/test_hooks.py` (61 tests in total); see NOTES.md for what was not run.

State legend: **implemented** (code exists for the pack; see location), **not done** (reason given),
Total ids in CHECKLIST.md: 1126. Listed as not done: 1.


## Pack 01 — 01-hardware-requirements--hardware-requirements.md

No ids in this pack (`no node`). Text is still spec and is covered by the location below: no build or install step; `scripts/detect.py` (stdlib only), `hooks/*.js` (Node only).

## Pack 02 — 02-hardware-requirements--summary.md

- ids: N-000588 to N-000592 (5)
- state: implemented (per pack) — same as 01 (CPU-only, no native code, no runtime dependencies)

## Pack 03 — 03-hardware-requirements--execution-profiles.md

- ids: N-000593 to N-000602 (10)
- state: implemented (per pack) — `scripts/detect.py` run from the repo root; `hooks/*.js` run with `node`

## Pack 04 — 04-full-prd--product-overview.md

- ids: N-000001 to N-000018 (18)
- state: implemented (per pack) — `scripts/detect.py` (report, scoring, scan window); `hooks/prosecheck-*.js` (contract, guard, commands)

## Pack 05 — 05-full-prd--terminology.md

- ids: N-000019 to N-000040 (22)
- state: implemented (per pack) — terminology used throughout; score/band/window in `scripts/detect.py`; ledger and levels in `hooks/lib/common.js`

## Pack 06 — 06-full-prd--public-surface-inventory.md

- ids: N-000041 to N-000051 (11)
- state: implemented (per pack) — surface: `scripts/detect.py`, `hooks/prosecheck-*.js`, `commands/prosecheck.md`
- N-000050: **not done** — bundled skill file (rewrite instructions for the host agent) is not shipped; it is not a detector obligation and not a feature point

## Pack 07 — 07-full-prd--non-functional-constraints.md

- ids: N-000052 to N-000077 (26)
- state: implemented (per pack) — stdlib-only detector; no network code; local-only hooks; deterministic scan (`scripts/detect.py`)

## Pack 08 — 08-full-prd--required-substance-global.md

- ids: N-000078 to N-000081 (4)
- state: implemented (per pack) — every feature point runs in the real detector or real hooks

## Pack 09 — 09-full-prd--non-goals.md

- ids: N-000082 to N-000093 (12)
- state: implemented (per pack) — non-goals: satisfied by absence (no PDF/RTF reading, no hosted service, no in-place rewrite)

## Pack 10 — 10-full-prd--fp-01-local-detector-scan-0-100-score-an.md

- ids: N-000094 to N-000242 (149)
- state: implemented (per pack) — `scripts/detect.py`: families/rules (`RULES`), scoring (`compute_score`), report (`build_report`), errors and CLI (`main`)

## Pack 11 — 11-full-prd--fp-02-twenty-format-extraction-size-caps.md

- ids: N-000243 to N-000298 (56)
- state: implemented (per pack) — `scripts/detect.py`: `extract_from_bytes`, `_docx_text`, `_pptx_text`, `_xlsx_text`, `_odf_text`, `_epub_text`, `_notebook_text`; caps in `hooks/lib/common.js`

## Pack 12 — 12-full-prd--fp-03-deterministic-character-cleanup.md

- ids: N-000299 to N-000331 (33)
- state: implemented (per pack) — `scripts/detect.py`: `invisible_indices`, `nonstandard_space_indices`, `homoglyph_tokens`, `scrub` (cleanup switch)

## Pack 13 — 13-full-prd--fp-04-always-on-writing-contract-at-sess.md

- ids: N-000332 to N-000394 (63)
- state: implemented (per pack) — `hooks/prosecheck-activate.js`, `hooks/prosecheck-tracker.js` (reminder), `hooks/prosecheck-subagent.js`, contract text in `hooks/lib/common.js`

## Pack 14 — 14-full-prd--fp-05-saved-file-guard-on-supported-file.md

- ids: N-000395 to N-000456 (62)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`collectPaths`, `scoreOne`, skip rules, ledger records)

## Pack 15 — 15-full-prd--fp-06-prosecheck-commands-levels-check-d.md

- ids: N-000457 to N-000577 (121)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` (router, `checkReply`, `doctorReply`, `initReply`), `hooks/prosecheck-stats.js`

## Pack 16 — 16-full-prd--cross-cutting-obligations-all-feature-po.md

- ids: N-000578 to N-000587 (10)
- state: implemented (per pack) — cross-cutting: no network code anywhere; contract forbids narration; hooks exit 0

## Pack 17 — 17-interface-contract--product-overview.md

- ids: N-000603 to N-000626 (24)
- state: implemented (per pack) — overview: `hooks/lib/common.js` (layout, names, env vars), `scripts/detect.py` (report)

## Pack 18 — 18-interface-contract--shape-of-the-public-surface.md

- ids: N-000627 to N-000673 (47)
- state: implemented (per pack) — public surface: `scripts/detect.py` CLI, `hooks/hooks.json`, `.claude-plugin/plugin.json`, `commands/prosecheck.md`, `.cursor/rules/prosecheck.mdc`

## Pack 19 — 19-interface-contract--naming-conventions.md

- ids: N-000674 to N-000702 (29)
- state: implemented (per pack) — naming and env: `hooks/lib/common.js` (`CLAUDE_CONFIG_DIR`, `CLAUDE_PLUGIN_ROOT`, `PROSECHECK_DEFAULT_MODE`, flag and ledger names)

## Pack 20 — 20-interface-contract--global-observables-an-implementer-must-r.md

- ids: N-000703 to N-000730 (28)
- state: implemented (per pack) — global observables: exit codes in `scripts/detect.py`; hook exit 0 in every `hooks/*.js`; ledger in `hooks/lib/common.js`

## Pack 21 — 21-interface-contract--scripts-detect-py.md

- ids: N-000731 to N-000787 (57)
- state: implemented (per pack) — `scripts/detect.py`: `parse_args`, `main`, `build_report`, `ci_interval`, `scrub`

## Pack 22 — 22-interface-contract--hooks-prosecheck-activate-js.md

- ids: N-000788 to N-000812 (25)
- state: implemented (per pack) — `hooks/prosecheck-activate.js` with `sessionStartText` in `hooks/lib/common.js`

## Pack 23 — 23-interface-contract--hooks-prosecheck-subagent-js.md

- ids: N-000813 to N-000818 (6)
- state: implemented (per pack) — `hooks/prosecheck-subagent.js`

## Pack 24 — 24-interface-contract--post-tool-use-reply.md

- ids: N-000819 to N-000835 (17)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`main` output envelope, ask text names "Fix")

## Pack 25 — 25-interface-contract--content.md

- ids: N-000836 to N-000840 (5)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` reads `tool_input.content` as part of the request (not used for scoring)

## Pack 26 — 26-interface-contract--cwd.md

- ids: N-000841 to N-000843 (3)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`cwd` at top level, relative path resolution)

## Pack 27 — 27-interface-contract--file-path.md

- ids: N-000844 to N-000846 (3)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`collectPaths`, `file_path` under `tool_input`)

## Pack 28 — 28-interface-contract--prompt.md

- ids: N-000847 to N-000856 (10)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` (`prompt`, `session_id`, stop phrases)

## Pack 29 — 29-interface-contract--tool-input.md

- ids: N-000857 to N-000863 (7)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`tool_input`: `file_path`, `notebook_path`, `command`)

## Pack 30 — 30-interface-contract--tool-name.md

- ids: N-000864 to N-000869 (6)
- state: implemented (per pack) — `hooks/prosecheck-guard.js` (`tool_name`, `apply_patch` handling)

## Pack 31 — 31-interface-contract--prosecheck.md

- ids: N-000870 to N-000908 (39)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` (block decision, unknown word, stop phrases, ordinary prompts, `$ARGUMENTS` menu document)

## Pack 32 — 32-interface-contract--help.md

- ids: N-000909 to N-000934 (26)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `helpReply`

## Pack 33 — 33-interface-contract--status.md

- ids: N-000935 to N-000941 (7)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `statusReply`

## Pack 34 — 34-interface-contract--lite-full-strict-off-on.md

- ids: N-000942 to N-000951 (10)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `setLevelReply`

## Pack 35 — 35-interface-contract--check.md

- ids: N-000952 to N-000992 (41)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `checkReply`

## Pack 36 — 36-interface-contract--doctor.md

- ids: N-000993 to N-001028 (36)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `doctorReply`

## Pack 37 — 37-interface-contract--show.md

- ids: N-001029 to N-001060 (32)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `showReply`, `hooks/lib/common.js` ledger

## Pack 38 — 38-interface-contract--init.md

- ids: N-001061 to N-001102 (42)
- state: implemented (per pack) — `hooks/prosecheck-tracker.js` `initReply`; `hooks/lib/common.js` `exportSection`; `.cursor/rules/prosecheck.mdc`

## Pack 39 — 39-interface-contract--stats.md

- ids: N-001103 to N-001121 (19)
- state: implemented (per pack) — `hooks/prosecheck-stats.js`

## Pack 40 — 40-interface-contract--transcript-path.md

- ids: N-001122 to N-001126 (5)
- state: implemented (per pack) — `hooks/prosecheck-stats.js` (`transcript_path` handling)

