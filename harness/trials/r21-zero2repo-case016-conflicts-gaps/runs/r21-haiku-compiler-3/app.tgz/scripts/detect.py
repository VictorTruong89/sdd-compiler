#!/usr/bin/env python3
"""prosecheck detector: score prose for AI-writing patterns.

Standard library only (Python 3.9+). No network, no model, deterministic.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

Without FILE the text is read from standard input. The default output is a
single JSON report on standard output. --clean prints the scrubbed text
instead. Failures print one JSON object {"error": ...} as the last line on
standard error and exit non-zero; no traceback is printed.

spec: N-000094 (FP-01 public entry), N-000744 (report shape), N-000777 (errors)
"""

import codecs
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000248 caps are binary units; the scan window is 262,144 characters
WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024

# spec: N-000243..N-000253 the twenty supported formats
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
PROSE_EXTS = PLAIN_EXTS | ZIP_EXTS | NOTEBOOK_EXTS
NO_PROSE_EXTS = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score prose for AI-writing patterns. Reads FILE, or standard input when no FILE is given.
  --clean     print the scrubbed text instead of the JSON report
  --ci        add a low/high interval on the score (needs four or more sentences)
  --          end option parsing, so FILE may begin with a dash
  -h, --help  print this message and exit 0
"""


class InputError(Exception):
    """Empty input, unreadable input, or unusable archive. Exit 1."""


class OptionError(Exception):
    """Unknown option. Exit 2."""


# ---------------------------------------------------------------- extraction

def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _strip_tags(data):
    text = data.decode('utf-8', errors='replace')
    text = re.sub(r'<[^>]+>', ' ', text)
    return re.sub(r'[ \t]+', ' ', text)


def _docx_text(zf):
    names = zf.namelist()
    part = 'word/document.xml' if 'word/document.xml' in names else None
    if part is None:
        cands = sorted(n for n in names if re.match(r'word/document\d*\.xml$', n))
        part = cands[0] if cands else None
    if part is None:
        return ''
    root = _parse_xml(zf.read(part))
    if root is None:
        return _strip_tags(zf.read(part))
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        bits = []
        for node in p.iter():
            ln = _local(node.tag)
            if ln == 't' and node.text:
                bits.append(node.text)
            elif ln == 'tab':
                bits.append('\t')
            elif ln in ('br', 'cr'):
                bits.append('\n')
        paras.append(''.join(bits))
    return '\n'.join(paras)


def _pptx_text(zf):
    slides = []
    for n in zf.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m:
            slides.append((int(m.group(1)), n))
    slides.sort()
    out = []
    for _, n in slides:
        root = _parse_xml(zf.read(n))
        if root is None:
            out.append(_strip_tags(zf.read(n)))
            continue
        paras = []
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            paras.append(''.join(node.text or '' for node in p.iter() if _local(node.tag) == 't'))
        out.append('\n'.join(paras))
    return '\n'.join(out)


def _xlsx_text(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = _parse_xml(zf.read('xl/sharedStrings.xml'))
        if root is not None:
            for si in root:
                if _local(si.tag) == 'si':
                    shared.append(''.join(node.text or '' for node in si.iter() if _local(node.tag) == 't'))
    sheets = []
    for n in zf.namelist():
        m = re.match(r'xl/worksheets/sheet(\d+)\.xml$', n)
        if m:
            sheets.append((int(m.group(1)), n))
    sheets.sort()
    out = []
    for _, n in sheets:
        root = _parse_xml(zf.read(n))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            ctype = c.get('t')
            text = None
            if ctype == 's':
                v = None
                for node in c:
                    if _local(node.tag) == 'v':
                        v = node.text
                if v is not None and re.fullmatch(r'\s*\d+\s*', v):
                    idx = int(v)
                    if 0 <= idx < len(shared):
                        text = shared[idx]
            elif ctype == 'inlineStr':
                text = ''.join(node.text or '' for node in c.iter() if _local(node.tag) == 't')
            elif ctype == 'str':
                for node in c:
                    if _local(node.tag) == 'v':
                        text = node.text
            if text:
                out.append(text)
    return '\n'.join(out)


def _odf_walk(node, out):
    ln = _local(node.tag)
    if ln == 's':
        count = 1
        for k, v in node.attrib.items():
            if _local(k) == 'c':
                try:
                    count = int(v)
                except ValueError:
                    count = 1
        out.append(' ' * count)
    elif ln == 'tab':
        out.append('\t')
    elif ln == 'line-break':
        out.append('\n')
    if node.text:
        out.append(node.text)
    for child in node:
        _odf_walk(child, out)
        if child.tail:
            out.append(child.tail)
    if ln in ('p', 'h'):
        out.append('\n')


def _odf_text(zf):
    if 'content.xml' not in zf.namelist():
        return ''
    root = _parse_xml(zf.read('content.xml'))
    if root is None:
        return _strip_tags(zf.read('content.xml'))
    body = None
    for node in root.iter():
        if _local(node.tag) == 'body':
            body = node
            break
    out = []
    _odf_walk(body if body is not None else root, out)
    return ''.join(out)


class _ChapterParser(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
             'section', 'article', 'blockquote', 'pre', 'table', 'ul', 'ol', 'dt', 'dd'}
    SKIP = {'script', 'style', 'head', 'title', 'nav'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_to_text(data):
    parser = _ChapterParser()
    try:
        parser.feed(data.decode('utf-8', errors='replace'))
        parser.close()
    except Exception:  # malformed markup: keep what was read
        pass
    lines = []
    for line in ''.join(parser.parts).split('\n'):
        line = re.sub(r'\s+', ' ', line).strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)


def _epub_text(zf):
    names = set(zf.namelist())
    chapters = []
    opf_path = None
    if 'META-INF/container.xml' in names:
        root = _parse_xml(zf.read('META-INF/container.xml'))
        if root is not None:
            for node in root.iter():
                if _local(node.tag) == 'rootfile' and node.get('full-path'):
                    opf_path = node.get('full-path')
                    break
    if opf_path and opf_path in names:
        opf = _parse_xml(zf.read(opf_path))
        base = opf_path.rsplit('/', 1)[0] + '/' if '/' in opf_path else ''
        if opf is not None:
            manifest = {}
            spine = []
            for node in opf.iter():
                ln = _local(node.tag)
                if ln == 'item' and node.get('id'):
                    manifest[node.get('id')] = node
                elif ln == 'itemref' and node.get('idref'):
                    spine.append(node.get('idref'))
            for idref in spine:
                item = manifest.get(idref)
                if item is None:
                    continue
                props = (item.get('properties') or '').split()
                if 'nav' in props:
                    continue
                href = item.get('href') or ''
                path = base + href
                if path in names:
                    chapters.append(path)
    if not chapters:
        for n in sorted(names):
            if re.search(r'\.(x?html?|xml)$', n, re.I) and not re.search(r'nav|toc', n, re.I):
                if not n.startswith('META-INF/'):
                    chapters.append(n)
    texts = []
    for n in chapters:
        t = _html_to_text(zf.read(n))
        if t:
            texts.append(t)
    return '\n'.join(texts)


def _notebook_text(data):
    try:
        nb = json.loads(data.decode('utf-8-sig', errors='replace'))
    except (ValueError, UnicodeDecodeError):
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        out.append(src)
    return '\n'.join(out)


def decode_text(data):
    """UTF-8 (optional BOM), or UTF-16 with a byte-order mark."""
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        try:
            return data.decode('utf-16')
        except UnicodeDecodeError:
            return data.decode('utf-16', errors='replace')
    if data.startswith(codecs.BOM_UTF8):
        data = data[3:]
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        return data.decode('utf-8', errors='replace')


def extract_from_bytes(data, ext):
    """Return extracted prose for bytes of a file with extension `ext` (lowercase)."""
    if ext in NO_PROSE_EXTS:
        return ''
    if ext in NOTEBOOK_EXTS:
        return _trim_ends(_notebook_text(data))
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise InputError('cannot read input: not a readable zip archive')
        with zf:
            if ext in ('.docx', '.docm'):
                text = _docx_text(zf)
            elif ext in ('.pptx', '.pptm'):
                text = _pptx_text(zf)
            elif ext in ('.xlsx', '.xlsm'):
                text = _xlsx_text(zf)
            elif ext == '.epub':
                text = _epub_text(zf)
            else:
                text = _odf_text(zf)
        return _trim_ends(text)
    return decode_text(data)


def _trim_ends(text):
    return text.strip()


def extract_file(path):
    if not os.path.exists(path):
        raise InputError('cannot read input: no such file: ' + path)
    if os.path.isdir(path):
        raise InputError('cannot read input: not a file: ' + path)
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise InputError('cannot read input: ' + (exc.strerror or 'unreadable') + ': ' + path)
    return extract_from_bytes(data, ext)


def extract_stdin():
    data = sys.stdin.buffer.read()
    return decode_text(data)


# ---------------------------------------------------------------- helpers

WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")
SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]”’]*\s+|\n+")
PARA_SPLIT = re.compile(r"\n[ \t]*\n")


def words_of(text):
    return [w for w in WORD_RE.findall(text) if re.search(r'[^\W_]', w)]


def split_sentences(text):
    out = []
    for piece in SENT_SPLIT.split(text):
        piece = piece.strip()
        if piece and re.search(r'[^\W_]', piece):
            out.append(piece)
    return out


def split_paragraphs(text):
    return [p.strip() for p in PARA_SPLIT.split(text) if p.strip()]


def excerpt(text, start, end, pad=40):
    a = max(0, start - pad)
    b = min(len(text), end + pad)
    frag = re.sub(r'\s+', ' ', text[a:b]).strip()
    if a > 0:
        frag = '...' + frag
    if b < len(text):
        frag = frag + '...'
    return frag


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / len(values)
    if mean <= 0:
        return None
    sd = math.sqrt(sum((v - mean) ** 2 for v in values) / len(values))
    return sd / mean


# ---------------------------------------------------------------- masking

def mask_nonprose(text):
    """Blank out regions that generate no findings: YAML front matter, fenced
    code, inline code spans, blockquote runs, table rows, badge lines."""
    lines = text.split('\n')
    keep = [True] * len(lines)

    # YAML front matter at the very start
    if lines and lines[0].rstrip() == '---':
        for i in range(1, len(lines)):
            if lines[i].rstrip() == '---':
                for j in range(0, i + 1):
                    keep[j] = False
                break

    # CommonMark fenced code blocks
    i = 0
    fence_re = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
    while i < len(lines):
        m = fence_re.match(lines[i])
        if m and keep[i]:
            fence = m.group(1)
            ch = fence[0]
            j = i + 1
            closed = len(lines)
            while j < len(lines):
                cm = re.match(r'^ {0,3}(`{3,}|~{3,})\s*$', lines[j])
                if cm and cm.group(1)[0] == ch and len(cm.group(1)) >= len(fence):
                    closed = j
                    break
                j += 1
            end = min(closed, len(lines) - 1)
            for k in range(i, end + 1):
                keep[k] = False
            i = end + 1
            continue
        i += 1

    # blockquote runs (two or more consecutive lines), table rows, badge lines
    badge = re.compile(r'^\s*(\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
    table = re.compile(r'^\s*\|.*\|\s*$')
    i = 0
    while i < len(lines):
        if not keep[i]:
            i += 1
            continue
        line = lines[i]
        if table.match(line) or badge.match(line):
            keep[i] = False
            i += 1
            continue
        if line.lstrip().startswith('>'):
            j = i
            while j < len(lines) and keep[j] and lines[j].lstrip().startswith('>'):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    keep[k] = False
            i = j
            continue
        i += 1

    out_lines = []
    for idx, line in enumerate(lines):
        out_lines.append(line if keep[idx] else ' ' * len(line))
    masked = '\n'.join(out_lines)
    masked = re.sub(r'`[^`\n]+`', lambda m: ' ' * len(m.group(0)), masked)
    return masked


# ---------------------------------------------------------------- character layer

KEEP_NONE = 0
LOOKALIKE = {}
for _src, _dst in [
    ('а', 'a'), ('с', 'c'), ('ԁ', 'd'), ('е', 'e'), ('һ', 'h'),
    ('і', 'i'), ('ј', 'j'), ('о', 'o'), ('р', 'p'), ('ѕ', 's'),
    ('ա', 'a'), ('օ', 'o'), ('ս', 'u'), ('ո', 'n'), ('ց', 'g'),
    ('у', 'y'), ('х', 'x'), ('ѵ', 'v'), ('ԝ', 'w'),
    ('А', 'A'), ('В', 'B'), ('С', 'C'), ('Е', 'E'), ('Н', 'H'),
    ('І', 'I'), ('Ј', 'J'), ('К', 'K'), ('М', 'M'), ('О', 'O'),
    ('Р', 'P'), ('Ѕ', 'S'), ('Т', 'T'), ('Х', 'X'), ('У', 'Y'),
    ('Α', 'A'), ('Β', 'B'), ('Ε', 'E'), ('Ζ', 'Z'), ('Η', 'H'),
    ('Ι', 'I'), ('Κ', 'K'), ('Μ', 'M'), ('Ν', 'N'), ('Ο', 'O'),
    ('Ρ', 'P'), ('Τ', 'T'), ('Υ', 'Y'), ('Χ', 'X'),
    ('α', 'a'), ('ο', 'o'), ('ν', 'v'), ('ρ', 'p'), ('ι', 'i'),
    ('υ', 'u'), ('χ', 'x'),
]:
    LOOKALIKE[_src] = _dst

LATIN_LETTERS = set('acdeghijnopsuvwxyABCEHIJKMNOPSTXYZ')
LOOKALIKE = {k: v for k, v in LOOKALIKE.items() if v in LATIN_LETTERS}

DEFAULT_IGNORABLE_EXTRA = {0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5,
                           0x180B, 0x180C, 0x180D, 0x180F}
NSSCRIPT_RE = re.compile(r'[\u0e00-\u0eff\u1000-\u109f\u1780-\u17ff\u3040-\u30ff\u3400-\u9fff\uf900-\ufaff\U00020000-\U0002ffff]')
JOIN_RE = re.compile(r'[\u0590-\u08ff\u0900-\u0dff\u1000-\u109f\u1780-\u17ff]')
CJK_RE = re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U0002ffff]')
RTL_RE = re.compile(r'[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')


def _is_sym(ch):
    if not ch:
        return False
    cp = ord(ch)
    if 0x1F000 <= cp <= 0x1FAFF:
        return True
    return unicodedata.category(ch).startswith('S')


def _tag_kept(t, i):
    j = i - 1
    while j >= 0 and 0xE0000 <= ord(t[j]) <= 0xE007F:
        j -= 1
    return j >= 0 and ord(t[j]) >= 0x1F000


def invisible_indices(t):
    """Indices of invisible characters that cleanup removes. Characters the
    cleanup keeps (they do a job in their position) are not listed."""
    rtl = RTL_RE.search(t) is not None
    out = []
    n = len(t)
    for i, ch in enumerate(t):
        if ch in '\t\n\r':
            continue
        cp = ord(ch)
        prev = t[i - 1] if i > 0 else ''
        nxt = t[i + 1] if i + 1 < n else ''
        cat = unicodedata.category(ch)
        if cat == 'Cc':
            out.append(i)
            continue
        if 0xE0000 <= cp <= 0xE007F:
            if not _tag_kept(t, i):
                out.append(i)
            continue
        if (0xFE00 <= cp <= 0xFE0F) or (0xE0100 <= cp <= 0xE01EF):
            if (prev and (CJK_RE.match(prev) or _is_sym(prev))) or nxt == '\u20e3':
                continue
            out.append(i)
            continue
        if cp == 0x00AD:
            if prev.isalpha() and nxt.isalpha():
                continue
            out.append(i)
            continue
        if cp == 0x200B:
            if (prev and NSSCRIPT_RE.match(prev)) or (nxt and NSSCRIPT_RE.match(nxt)):
                continue
            out.append(i)
            continue
        if cp in (0x200C, 0x200D):
            near = [c for c in (prev, nxt) if c]
            if any(JOIN_RE.match(c) or _is_sym(c) for c in near):
                continue
            out.append(i)
            continue
        if 0x180B <= cp <= 0x180F and cp != 0x180E:
            if prev and 0x1800 <= ord(prev) <= 0x18AF:
                continue
            out.append(i)
            continue
        if cp in (0x17B4, 0x17B5):
            if (prev and 0x1780 <= ord(prev) <= 0x17FF) or (nxt and 0x1780 <= ord(nxt) <= 0x17FF):
                continue
            out.append(i)
            continue
        if cp in (0x200E, 0x200F, 0x061C) or (0x202A <= cp <= 0x202E) or (0x2066 <= cp <= 0x2069):
            if rtl:
                continue
            out.append(i)
            continue
        if cat == 'Cf' or cp in DEFAULT_IGNORABLE_EXTRA:
            out.append(i)
            continue
    return out


def _remove_indices(t, idx):
    if not idx:
        return t
    drop = set(idx)
    return ''.join(ch for i, ch in enumerate(t) if i not in drop)


def nbsp_kept(t, i):
    """A no-break space or narrow no-break space that holds something together."""
    prev = t[i - 1] if i > 0 else ''
    nxt = t[i + 1] if i + 1 < len(t) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?\u00bb\u203a%\u20ac':
        return True
    if prev and prev in '\u00ab\u2039':
        return True
    return False


def nonstandard_space_indices(t):
    out = []
    for i, ch in enumerate(t):
        if ch == ' ':
            continue
        if unicodedata.category(ch) == 'Zs':
            if ch in ('\u00a0', '\u202f') and nbsp_kept(t, i):
                continue
            out.append(i)
    return out


def _normalize_spaces(t):
    idx = set(nonstandard_space_indices(t))
    if not idx:
        return t
    return ''.join(' ' if i in idx else ch for i, ch in enumerate(t))


def homoglyph_tokens(t):
    """Token spans (start, end) that mix ASCII Latin letters with lookalike
    letters of another script and contain no other non-ASCII letter."""
    spans = []
    for m in re.finditer(r'\S+', t):
        tok = m.group(0)
        has_ascii = False
        has_look = False
        other = False
        for ch in tok:
            if ch.isalpha():
                if ch.isascii():
                    has_ascii = True
                elif ch in LOOKALIKE:
                    has_look = True
                else:
                    other = True
                    break
        if has_ascii and has_look and not other:
            spans.append((m.start(), m.end()))
    return spans


def homoglyph_stats(t):
    spans = homoglyph_tokens(t)
    chars = 0
    for a, b in spans:
        chars += sum(1 for ch in t[a:b] if ch in LOOKALIKE)
    return len(spans), chars


def _fold_homoglyphs(t):
    spans = homoglyph_tokens(t)
    if not spans:
        return t
    out = []
    last = 0
    for a, b in spans:
        out.append(t[last:a])
        out.append(''.join(LOOKALIKE.get(ch, ch) for ch in t[a:b]))
        last = b
    out.append(t[last:])
    return ''.join(out)


def character_counts(window):
    inv = len(invisible_indices(window))
    nbsp = len(nonstandard_space_indices(window))
    hg_tokens, hg_chars = homoglyph_stats(window)
    return {'invisible': inv, 'nonstandard': nbsp, 'homoglyph_tokens': hg_tokens,
            'homoglyph_chars': hg_chars}


def scrub(text):
    """Cleanup: remove invisible characters, normalize spaces, fold lookalikes,
    trim whitespace. Repeats the invisible pass until it is stable."""
    t = text
    for _ in range(5):
        idx = invisible_indices(t)
        if not idx:
            break
        t = _remove_indices(t, idx)
    t = _normalize_spaces(t)
    t = _fold_homoglyphs(t)
    t = t.replace('\u2028', '\n').replace('\u2029', '\n')
    t = re.sub(r'[ \t]+(?=\r?\n)', '', t)
    t = re.sub(r'[ \t]+$', '', t)
    t = re.sub(r'^(?:[ \t]*\r?\n)+', '', t)
    had_nl = t.endswith('\n') or text.endswith('\n')
    t = t.rstrip()
    if t and had_nl:
        t = t + '\n'
    return t


# ---------------------------------------------------------------- rules

def rx_rule(*patterns, flags=re.I):
    comp = [re.compile(p, flags) for p in patterns]

    def run(ctx):
        hits = []
        spans = []
        for c in comp:
            for m in c.finditer(ctx.t):
                # overlapping alternatives of one rule are one hit
                if any(m.start() < e and s < m.end() for s, e in spans):
                    continue
                spans.append((m.start(), m.end()))
                hits.append(excerpt(ctx.t, m.start(), m.end()))
        return hits
    return run


def _infl(word):
    if ' ' in word:
        return re.escape(word).replace(r'\ ', r'\s+')
    stem = word[:-1] if word.endswith('e') else word
    return re.escape(stem) + r'(?:e|es|ed|ing|s|d)?'


def _words_rule(words, extra=()):
    alts = [_infl(w) for w in words] + list(extra)
    pat = r'\b(?:' + '|'.join(alts) + r')\b'
    return rx_rule(pat)


AI_VOCAB = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
            'meticulous', 'testament', 'underscore', 'intricate', 'intricacies', 'interplay',
            'garner', 'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance',
            'leverage', 'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
            'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
            'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
            'elevate', 'empower', 'unlock']
f_ai_vocab = _words_rule(AI_VOCAB, extra=[r'capture\s+the\s+(?:essence|spirit|imagination|heart|magic)'])

_dialect_raw = rx_rule(
    r'\bgenuinely\b', r'\bfascinating\b', r'\bnuanced\b', r'\bthoughtfully\b', r'\brefreshingly\b',
    r'\bstrikingly\b', r'\bcompellingly\b', r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b', r'\bresonates deeply\b',
    r'\bgame[- ]changer\w*', r'\bgame[- ]changing\b', r'\bsupercharg\w*', r'\bskyrocket\w*',
    r'\bturbocharg\w*', r'\brevolutioniz\w*', r'\bdouble down on\b', r'\bdive deep(?:er)? into\b',
    r'\bunlock (?:the )?(?:power|potential|value)\b', r'\btake\b[^.!?\n]{0,60}?\bto the next level\b')

def f_dialect(ctx):
    # spec: N-000153 and N-000359..N-000362: the dialect family needs two hits
    hits = _dialect_raw(ctx)
    return hits if len(hits) >= 2 else []


f_promo_phrase = rx_rule(
    r'\bnestled\b', r'\bbreathtaking\b', r'\bmust-visit\b', r'\bstunning\b', r'\bpicturesque\b',
    r'\bcharming\b', r'\bidyllic\b', r'\bvibrant community\b', r'\brich cultural heritage\b',
    r'\bin the heart of\b', r'\bworld-class\b', r'\btop-tier\b', r'\bunparalleled\b', r'\bpremier\b',
    r'\bleading\b', r'\besteemed organization\b', r'\bvaluable asset\b', r'\bpassion for excellence\b',
    r'\bproven track record\b', r'\bresults-oriented\b', r'\bwealth of experience\b',
    r'\bdynamic team\b', r'\bfast-paced environment\b', r'\bdeeply passionate\b',
    r'\bperfectly situated\b', r'\bclose-knit\b', r'\btight-knit team\b',
    r'\bI am excited to (?:apply|bring)\b', r'\buniquely positioned to\b')

MARKETING_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                   'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                   'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
                   'stop', 'start'}


def f_promo(ctx):
    hits = f_promo_phrase(ctx)
    openers = []
    for s in ctx.sents:
        first = re.match(r'\s*([A-Za-z]+)', s)
        if first and first.group(1).lower() in MARKETING_VERBS:
            openers.append(s)
    if len(openers) >= 3:
        hits.append(excerpt(openers[0], 0, len(openers[0]), pad=0))
    return hits


f_simple_yet = rx_rule(r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')

ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
STOCK_ADJ = {'robust', 'innovative', 'seamless', 'powerful', 'elegant', 'vibrant', 'dynamic',
             'comprehensive', 'holistic', 'scalable', 'intuitive', 'cutting-edge', 'modern',
             'reliable', 'efficient', 'secure', 'bold', 'thoughtful', 'stunning', 'beautiful',
             'exceptional', 'premier', 'unparalleled', 'transformative', 'meticulous'}
_W = r"[A-Za-z][A-Za-z\-]*"
_SEP = r"(?:,\s+(?:and\s+)?|\s+and\s+)"
CHAIN_RE = re.compile(r"\b(%s)%s(%s)%s(%s)%s(%s)\s+(%s)\b" % (_W, _SEP, _W, _SEP, _W, _SEP, _W, _W))


def f_stacked_adj(ctx):
    hits = []
    for m in CHAIN_RE.finditer(ctx.t):
        chain = [m.group(i) for i in range(1, 5)]
        if any(ADJ_SUFFIX.search(w) or w.lower() in STOCK_ADJ for w in chain):
            hits.append(excerpt(ctx.t, m.start(), m.end()))
    return hits


SYN_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def f_synonyms(ctx):
    hits = []
    low = ctx.t.lower()
    for cluster in SYN_CLUSTERS:
        present = []
        total = 0
        for member in cluster:
            pat = r'\b' + re.escape(member).replace(r'\ ', r'\s+') + r'(?:s|es)?\b'
            n = len(re.findall(pat, low))
            if n:
                present.append(member)
                total += n
        if len(present) >= 3:
            hits.append('members: ' + ', '.join(present) + ' (%d uses)' % total)
    return hits


f_significance = rx_rule(
    r'\b(?:stands|serves|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor\w*|highlight\w*) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects a broader (?:trend|shift|pattern)\b',
    r'\bmarks a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymbolizes?\b', r'\bsets the stage for\b', r'\bleft an indelible mark\b',
    r'\bplays a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize)\b')

CREDIT_RE = re.compile(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+([^.!?\n]*)', re.I)


def f_notability(ctx):
    hits = []
    for m in CREDIT_RE.finditer(ctx.t):
        named = re.findall(r'\b[A-Z][\w&.\-]+', m.group(1))
        if len(named) >= 2:
            hits.append(excerpt(ctx.t, m.start(), m.end()))
    hits += rx_rule(
        r'\b\d[\d,.]*\s*(?:\+\s*)?(?:k\s+)?(?:followers|subscribers)\b',
        r'\b(?:strong|active) (?:online|digital|social[- ]media) presence\b',
        r'\bwidely (?:covered|reported)\b', r'\bindependent coverage\b', flags=0)(ctx)
    return hits


f_vague_attr = rx_rule(
    r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b',
    r'\bindustry (?:reports|observers|analysts)\b',
    r'\bobservers (?:have cited|noted)\b', r'\bsome critics argue\b',
    r'\bresearchers have found\b', r'\bstudies suggest\b', r'\bit is widely believed\b')

f_article_title = rx_rule(
    r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [A-Za-z][\w\'\- ]{1,80}? (?:is|are) (?:a|an|the)\b')

f_conservation = rx_rule(
    r'\bplays a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts are (?:underway|ongoing|in place)\b',
    r'\bserves as an indicator species\b', r'\bcontributes to biodiversity\b')

f_false_range = rx_rule(
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b')

f_ing_tails = rx_rule(
    r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
    r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
    r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')

f_parallelism = rx_rule(
    r'\bit[’\']s not (?:just|merely) (?:about|an?)\b',
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn[’\']t just\b[^,.\n]{0,40}?\bit\b')

f_tailing_neg = rx_rule(
    r',\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b')

f_not_x_just_y = rx_rule(
    r'\b(?:no|not) \w+,\s+(?:just|only|simply)\s+\w+',
    r'\b(?:not|isn[’\']t|aren[’\']t|wasn[’\']t|weren[’\']t) (?:just|merely) (?:a|an|the) \w+(?:,|\s+[-–—])\s*(?:it[’\']s|it is|it was|they[’\']re|they are|they were|that[’\']s|but)\b')

f_filler = rx_rule(
    r'\bin order to\b', r'\bdue to the fact that\b', r'\bat this point in time\b',
    r'\bin the event that\b', r'\bhas the ability to\b', r'\bit is important to note that\b',
    r'\bit should be mentioned that\b', r'\bneedless to say\b')

f_empty_pivot = rx_rule(
    r'\bit[’\']s worth (?:noting|mentioning) that\b', r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to consider is\b', r'\bone thing to keep in mind is\b',
    r'\bit is interesting to note that\b', r'\ba key consideration is\b', r'\ba point to highlight is\b')

f_outcome_tail = rx_rule(
    r',\s+(?:raising questions about|prompting reflection on|sparking debate about|'
    r'with broader implications for|reshaping our understanding of|paving the way for|'
    r'signaling a shift toward)\b')

f_persuasive = rx_rule(
    r'\bhere[’\']s the thing\b', r'\bmake no mistake\b', r'\bthe truth is\b',
    r'\blet[’\']s be honest\b', r'\bthe simple fact is\b', r'\bat its core\b',
    r'\bwhat really matters\b', r'\bmore than anything\b', r'\bat the end of the day\b',
    r'\bthe bottom line is\b', r'\bin reality\b', r'\bfundamentally,', r'\bthe real question is\b',
    r'\bthe heart of the matter\b', r'\bthe deeper issue\b', r'\bwhen you get down to it\b',
    r'\bwhen all is said and done\b')

f_editorial = rx_rule(
    r'\bit[’\']s important to (?:remember|note|understand|recognize)\b',
    r'\bit is important to (?:remember|note|understand|recognize)\b',
    r'\bone must note that\b', r'\bit is worth pointing out\b',
    r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b')

f_self_thorough = rx_rule(
    r'\bthis comprehensive (?:guide|overview|analysis)\b', r'\bthis in-depth (?:analysis|look|examination)\b',
    r'\bthis complete (?:guide|overview)\b', r'\ba thorough examination of\b',
    r'\beverything you need to know about\b')

AUX = {'is', 'are', 'was', 'were', 'do', 'does', 'did', 'can', 'could', 'will', 'would', 'should',
       'has', 'have', 'had', 'may', 'might', 'must', 'shall'}
ONE_WORD_ANS = re.compile(r'^(yes|no|absolutely|never|maybe|probably|always)[.!]$', re.I)


def f_qa(ctx):
    hits = []
    s = ctx.sents
    for i in range(len(s) - 1):
        q = s[i]
        if not q.endswith('?'):
            continue
        words = q.split()
        if len(words) > 10:
            continue
        first = re.sub(r'[^A-Za-z]', '', words[0]).lower() if words else ''
        if first in AUX and ONE_WORD_ANS.match(s[i + 1].strip()):
            hits.append(excerpt(q, 0, len(q), pad=0))
    return hits


f_concrete = rx_rule(
    r'\bwithout concrete (?:evidence|proof)\b', r'\bdo you have concrete evidence\b',
    r'\bI (?:would )?need concrete (?:evidence|examples) to\b', r'\babsent concrete proof\b',
    r'\bprovide concrete evidence\b')

f_intro_hooks = rx_rule(
    r'\bin today[’\']s (?:\w+\s+){0,2}(?:world|landscape|environment|market)\b',
    r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,', r'\bmore than ever before\b',
    r'\bwe live in a (?:time|world) when\b', r'\b(?:great|exciting|big) news\s*[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b')

f_formulaic_chal = rx_rule(
    r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
    r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
    r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
    r'\bfaces (?:several|many|numerous) challenges\b')

TRANSITIONS = r'(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)'
TRANS_RE = re.compile(r'(?:^|(?<=[.!?])\s+|\n\s*)(' + TRANSITIONS + r')\b', re.M)


def f_transitions(ctx):
    hits = []
    for para in split_paragraphs(ctx.t):
        n = len(TRANS_RE.findall(para))
        if n >= 2:
            hits.append('%d sentence-opening transitions in one paragraph' % n)
    return hits


f_conclusions = rx_rule(
    r'^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b',
    flags=re.I | re.M)

f_generic_pos = rx_rule(
    r'\bthe future looks bright\b', r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b',
    r'\bstep in the right direction\b', r'\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned (?:for )?(?:whatever comes next|the future|the road ahead)\b')


def sentence_lengths(ctx):
    return [len(words_of(s)) for s in ctx.sents]


def f_monotony(ctx):
    lens = sentence_lengths(ctx)
    if len(lens) < 3:
        return []
    cv = _cv(lens)
    if cv is not None and cv < 0.35:
        return ['%d sentences with near-equal lengths (cv %.2f)' % (len(lens), cv)]
    return []


def f_mech_alt(ctx):
    lens = sentence_lengths(ctx)
    if len(lens) < 6:
        return []
    mean = sum(lens) / len(lens)
    hits = []
    run = 0
    prev_d = None
    for i in range(len(lens) - 1):
        d = lens[i + 1] - lens[i]
        if abs(d) < max(3, 0.5 * mean):
            run = 0
            prev_d = None
            continue
        if prev_d is not None and d * prev_d < 0:
            run += 1
            if run == 4:
                hits.append('alternating sentence lengths from sentence %d' % (i - 4))
        else:
            run = 0
        prev_d = d
    return hits


def f_opener_rep(ctx):
    hits = []
    for para in split_paragraphs(ctx.t):
        sents = split_sentences(para)
        if len(sents) < 3:
            continue
        counts = {}
        for s in sents:
            ws = [w.lower() for w in words_of(s)[:2]]
            if len(ws) == 2:
                key = ' '.join(ws)
                counts[key] = counts.get(key, 0) + 1
        for key, n in counts.items():
            if n >= 3:
                hits.append('%d sentences open with "%s"' % (n, key))
    return hits


def f_uniform_para(ctx):
    paras = split_paragraphs(ctx.t)
    lens = [len(words_of(p)) for p in paras]
    lens = [n for n in lens if n > 0]
    if len(lens) < 4:
        return []
    cv = _cv(lens)
    if cv is not None and cv < 0.4:
        return ['%d paragraphs with near-equal lengths (cv %.2f)' % (len(lens), cv)]
    return []


def f_semicolon(ctx):
    if len(ctx.words) < 300:
        return []
    if ';' not in ctx.t and ctx.t.count('(') <= 1:
        return ['no semicolons and almost no parentheses in a long document']
    return []


FIRST_PERSON = {'i', 'we', 'my', 'our', 'me', 'us'}
UNCONTRACTED = re.compile(r"\b(I am|I have|I will|I would|I had|we are|we have|we will|we would|we had|"
                          r"do not|does not|did not|is not|are not|was not|were not|cannot|will not|"
                          r"would not|should not|could not|have not|has not|that is|it is|let us|"
                          r"you are|they are|there is)\b")
CONTRACTED = re.compile(r"\b\w+[’']\w+\b")


def f_contractions(ctx):
    words = [w.lower() for w in ctx.words]
    if not words:
        return []
    fp = sum(1 for w in words if w in FIRST_PERSON)
    if fp < 3 or fp / len(words) < 0.02:
        return []
    un = len(UNCONTRACTED.findall(ctx.t))
    con = len(CONTRACTED.findall(ctx.t))
    if un >= 3 and un / float(un + con) > 0.5:
        return ['%d uncontracted forms, %d contracted' % (un, con)]
    return []


def f_chatbot(ctx):
    return _chatbot_hits(ctx)


def _chatbot_hits(ctx):
    return rx_rule(
        r'\bI hope this helps\b', r'\b(?:Certainly|Of course)!', r'\blet me know if you\b',
        r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help\.(?=\s|$)',
        r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
        r"\bhere(?:'s|’s| is| are)\s+(?:a few|some|two|three)?\s*(?:options|drafts|versions|variations)\b",
        r"\bhere (?:is|’s|'s) (?:a |the )?draft\b",
        r'\bdepending on the (?:vibe|tone|style)\b', r'\bI hope (?:this email )?finds you well\b',
        r'\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
        r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
        r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked), here\b',
        r'\bhere is (?:the )?(?:draft|first pass|revised version)\b', flags=re.I)(ctx)


f_sycophancy = rx_rule(
    r'\byou[’\']re absolutely right\b', r'\byou are absolutely right\b',
    r'\b(?:great|excellent|wonderful|fantastic|brilliant|thoughtful) (?:question|point)[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question[!.,]',
    r'\bthat[’\']s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)[!.,]')

f_cutoff = rx_rule(
    r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bwhile specific details are (?:limited|scarce|not extensively (?:documented|widely documented)|not widely documented)\b',
    r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
    r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b')

f_copula = rx_rule(
    r'\b(?:serves|stands|functions|acts) as\b', r'\b(?:represents|marks) (?:a|the)\b',
    r'\bboasts\b', r'\bfeatures (?:a|an|the|\d[\d,]*|one|two|three|several|many|numerous|multiple)\b',
    r'\boffers a\b', r'\brefers to\b')

HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|"
                      r"appears? to|somewhat|relatively|fairly|kind of|sort of)\b")


def f_hedges(ctx):
    hits = []
    for s in ctx.sents:
        n = len(HEDGE_RE.findall(s))
        if n >= 2:
            hits.append(excerpt(s, 0, len(s), pad=0))
    return hits


def f_bold(ctx):
    spans = re.findall(r'\*\*[^*\n]+?\*\*', ctx.t)
    if len(spans) >= 3:
        return ['%d bold spans' % len(spans)]
    return []


EMOJI_RE = re.compile('[\U0001F000-\U0001FAFF☀-➿]')


def f_emoji(ctx):
    return ['%s' % m.group(0) for m in EMOJI_RE.finditer(ctx.t)]


def f_dashes(ctx):
    hits = []
    for para in split_paragraphs(ctx.t):
        n = para.count('—')
        if n >= 2:
            hits.append('%d em dashes in one paragraph' % n)
    return hits


SMALL_WORDS = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with', 'from', 'as',
               'into', 'onto', 'via', 'per', 'than', 'and', 'or', 'but', 'nor', 'so', 'yet'}


def f_title_case(ctx):
    hits = []
    for line in ctx.t.split('\n'):
        m = re.match(r'^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$', line)
        if not m:
            continue
        head = m.group(1).strip()
        if not head or not head[0].isalpha():
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’\-]*", head)
        if len(words) < 3:
            continue
        if head.upper() == head:
            continue
        major = [w for w in words if w.lower() not in SMALL_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            hits.append(head)
    return hits


f_curly = rx_rule(r'[“”‘’]', flags=0)

def _year_ranges(ctx):
    hits = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', ctx.t):
        if int(m.group(1)) < int(m.group(2)):
            hits.append(excerpt(ctx.t, m.start(), m.end()))
    return hits


def f_invisible(ctx):
    return ['U+%04X' % ord(ctx.raw[i]) for i in invisible_indices(ctx.raw)]


PLACEHOLDER_KEYWORDS = ('name', 'company', 'client', 'place', 'source', 'date', 'city', 'address',
                        'organization', 'email', 'phone', 'title')


def f_placeholder(ctx):
    hits = []
    t = ctx.t
    for m in re.finditer(r'\[([^\[\]\n]{1,120})\]', t):
        end = m.end()
        if end < len(t) and t[end] in '([':
            continue
        inner = m.group(1).strip()
        low = inner.lower()
        if re.match(r'(your|insert|add|enter|placeholder|todo|tbd|tk)\b', low) or \
                any(k in low for k in PLACEHOLDER_KEYWORDS):
            hits.append(excerpt(t, m.start(), m.end()))
            continue
        if re.fullmatch(r'[A-Z][A-Z _\-]{2,}', inner):
            hits.append(excerpt(t, m.start(), m.end()))
    for m in re.finditer(r'\{\{[^}\n]*\}\}', t):
        hits.append(excerpt(t, m.start(), m.end()))
    for m in re.finditer(r'\bx{3,}\b', t, re.I):
        hits.append(excerpt(t, m.start(), m.end()))
    for m in re.finditer(r'\blorem ipsum\b', t, re.I):
        hits.append(excerpt(t, m.start(), m.end()))
    return hits


f_chat_markup = rx_rule(
    r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\b', r'\bnavlist\b',
    r'【\d+†[^】\n]*】', flags=0)

f_tracking = rx_rule(
    r'utm_source=(?:gemini\.google\.com|copilot\.microsoft\.com|chat\.openai\.com|chatgpt\.com|'
    r'perplexity\.ai|claude\.ai|poe\.com)(?!\.?[A-Za-z0-9\-])', flags=re.I)


def f_homoglyph(ctx):
    out = []
    for a, b in homoglyph_tokens(ctx.raw):
        out.append(ctx.raw[a:b][:40])
    return out


def f_nonstandard(ctx):
    return ['U+%04X' % ord(ctx.raw[i]) for i in nonstandard_space_indices(ctx.raw)]


STOCK_HYPHEN = ['cutting-edge', 'state-of-the-art', 'game-changing', 'best-in-class', 'next-generation',
                'results-driven', 'data-driven', 'user-centric', 'future-proof', 'turn-key',
                'high-impact', 'value-driven', 'forward-thinking', 'customer-centric',
                'innovation-driven', 'industry-leading', 'groundbreaking', 'top-notch']
f_hyphen_pairs = rx_rule(*[r'\b' + re.escape(w) + r'\b' for w in STOCK_HYPHEN])

f_slop = rx_rule(
    r'\bunlocking (?:your|its|full|the|their) (?:full )?potential\b', r'\bnavigating the complexities\b',
    r'\ba testament to the (?:power|importance) of\b', r'\bstaying ahead of the curve\b',
    r'\bturning challenges into opportunities\b', r'\btaking (?:something|it|your \w+|\w+) to the next level\b',
    r'\bharnessing the power of\b', r'\bpaving the way for\b', r'\bsaying goodbye to\b',
    r'\bimagining a world where\b')

HR_RE = re.compile(r'^\s{0,3}(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$', re.M)


def f_hr(ctx):
    lines = ctx.t.count('\n') + 1
    rules = HR_RE.findall(ctx.t)
    if len(rules) >= 3 and lines >= 24:
        return ['%d horizontal rules' % len(rules)]
    return []


def f_degenerate(ctx):
    toks = [w.lower() for w in re.findall(r'\w+', ctx.t)]
    if len(toks) < 6:
        return []
    grams = [' '.join(toks[i:i + 6]) for i in range(len(toks) - 5)]
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = sum(1 for g in grams if counts[g] > 1)
    if repeated == 0:
        return []
    share = repeated / float(len(grams))
    if share >= 0.2:
        return ['%d of %d six-word runs repeat' % (repeated, len(grams))]
    return []


def f_fragment_headers(ctx):
    hits = []
    lines = ctx.t.split('\n')
    for i, line in enumerate(lines):
        m = re.match(r'^#{1,6}\s+(.*)$', line)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(#|[-*+]\s|\d+[.)]\s|\||>)', nxt):
            continue
        if len(nxt.split()) > 4:
            continue
        head_words = set(w.lower() for w in re.findall(r'[A-Za-z]{4,}', m.group(1)))
        nxt_words = set(w.lower() for w in re.findall(r'[A-Za-z]{4,}', nxt))
        if head_words & nxt_words:
            hits.append(excerpt(nxt, 0, len(nxt), pad=0))
    return hits


INLINE_HEADER_RE = re.compile(r'^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]*?:\s*\*\*|^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+\*\*:', re.M)


def f_inline_header(ctx):
    return [excerpt(ctx.t, m.start(), m.end()) for m in INLINE_HEADER_RE.finditer(ctx.t)]


def f_mid_bullets(ctx):
    if re.search(r'^#{1,6}\s', ctx.t, re.M):
        return []
    paras = split_paragraphs(ctx.t)
    listy = []
    prose = 0
    for p in paras:
        lines = [l for l in p.split('\n') if l.strip()]
        if lines and all(re.match(r'^\s*(?:[-*+]|\d+[.)])\s+', l) for l in lines):
            listy.append(p)
        else:
            prose += 1
    if listy and prose >= 2:
        return ['%d bulleted paragraph(s) in a document without headings' % len(listy)]
    return []


f_cataloguing = rx_rule(
    r'\b(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+',
    r'(?:^|[.!?]\s+)These (?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b',
    flags=re.I | re.M)

f_signposting = rx_rule(
    r"\blet[’']s (?:dive|delve|explore)\b", r"\blet[’']s break (?:this|it) down\b",
    r"\bhere[’']s what you need to know\b", r'\bwithout further ado\b', r'\bnow let[’\']s look at\b',
    r'\bbuckle up\b', r'\bstay with me\b', r'\b(?:are you )?ready to dive in\b')

f_diff_anchor = rx_rule(
    r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
    r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b',
    r'\bpreviously\b[^.!?\n]{0,200}?\bnow\b',
    r'\b(?:wasn|weren)[’\']t there before\b',
    r'\bwe[’\']ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
    r'\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b')

# ---------------------------------------------------------------- registry

DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
RHYTHM = {40, 44}
SMALL_FAMILY_RANGE = set(range(1, 40)) | set(range(47, 52)) | {69}

# (number, slug, label, function, weight, kind)
#   kind: 'score' | 'advice' | 'rhythm'
RULES = [
    (1, 'ai_vocabulary', 'AI vocabulary', f_ai_vocab, 8, 'score'),
    (2, 'model_dialect', 'Model-dialect vocabulary', f_dialect, 8, 'score'),
    (3, 'promotional', 'Promotional language', f_promo, 8, 'score'),
    (4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', f_hyphen_pairs, 0, 'advice'),
    (5, 'simple_yet', 'Simple-yet cliche', f_simple_yet, 8, 'score'),
    (6, 'stacked_adjectives', 'Stacked adjective chains', f_stacked_adj, 8, 'score'),
    (8, 'synonym_cycling', 'Synonym cycling', f_synonyms, 8, 'score'),
    (10, 'significance_inflation', 'Significance inflation', f_significance, 8, 'score'),
    (11, 'notability', 'Notability name-dropping', f_notability, 8, 'score'),
    (12, 'vague_attribution', 'Vague attributions', f_vague_attr, 8, 'score'),
    (13, 'article_title_noun', 'Article title used as proper noun', f_article_title, 12, 'score'),
    (14, 'conservation_padding', 'Conservation or ecosystem padding', f_conservation, 8, 'score'),
    (15, 'false_range', 'False range', f_false_range, 8, 'score'),
    (16, 'ing_tails', 'Superficial -ing tail clause', f_ing_tails, 8, 'score'),
    (17, 'negative_parallelism', 'Negative parallelism', f_parallelism, 0, 'advice'),
    (17, 'tailing_negation', 'Tailing negation', f_tailing_neg, 8, 'score'),
    (18, 'not_x_just_y', 'Not X, just Y', f_not_x_just_y, 8, 'score'),
    (19, 'filler', 'Filler phrase', f_filler, 0, 'advice'),
    (20, 'empty_pivot', 'Empty pivot phrase', f_empty_pivot, 8, 'score'),
    (21, 'outcome_tail', 'Outcome-speculation tail', f_outcome_tail, 8, 'score'),
    (22, 'persuasive_trope', 'Persuasive authority trope', f_persuasive, 0, 'advice'),
    (23, 'editorial_interjection', 'Editorial interjection', f_editorial, 8, 'score'),
    (24, 'self_thorough', 'Self-thoroughness phrase', f_self_thorough, 8, 'score'),
    (25, 'qa_rhetorical', 'Question-answer rhetorical pattern', f_qa, 8, 'score'),
    (26, 'concrete_evidence', 'Concrete-evidence defense phrase', f_concrete, 8, 'score'),
    (27, 'intro_hook', 'Compulsive intro hook', f_intro_hooks, 8, 'score'),
    (30, 'diff_anchored', 'Diff-anchored writing', f_diff_anchor, 8, 'score'),
    (31, 'signposting', 'Signposting and announcement', f_signposting, 8, 'score'),
    (32, 'cataloguing', 'Cataloguing lead-in', f_cataloguing, 8, 'score'),
    (33, 'inline_header', 'Inline-header vertical list', f_inline_header, 8, 'score'),
    (34, 'mid_essay_bullets', 'Mid-essay bullet injection', f_mid_bullets, 8, 'score'),
    (35, 'fragmented_header', 'Fragmented header', f_fragment_headers, 8, 'score'),
    (36, 'formulaic_challenges', 'Formulaic challenges section', f_formulaic_chal, 8, 'score'),
    (37, 'transition_cluster', 'Transition cluster', f_transitions, 8, 'score'),
    (38, 'conclusion_opener', 'Compulsive conclusion opener', f_conclusions, 8, 'score'),
    (39, 'generic_positive', 'Generic positive conclusion', f_generic_pos, 8, 'score'),
    (40, 'sentence_monotony', 'Sentence-length monotony', f_monotony, 4, 'rhythm'),
    (41, 'mechanical_alternation', 'Mechanical sentence-length alternation', f_mech_alt, 0, 'advice'),
    (42, 'opener_repetition', 'Opener repetition', f_opener_rep, 0, 'advice'),
    (44, 'uniform_paragraphs', 'Uniform paragraph length', f_uniform_para, 4, 'rhythm'),
    (46, 'semicolon_underuse', 'Semicolon and parenthesis underuse', f_semicolon, 0, 'advice'),
    (47, 'chatbot_artifact', 'Chatbot artifact', f_chatbot, 12, 'score'),
    (48, 'sycophancy', 'Sycophantic tone', f_sycophancy, 12, 'score'),
    (50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimer', f_cutoff, 12, 'score'),
    (51, 'copula_avoidance', 'Copula avoidance', f_copula, 8, 'score'),
    (54, 'hedge_stacking', 'Hedge stacking', f_hedges, 0, 'advice'),
    (55, 'contraction_absence', 'Contraction absence', f_contractions, 0, 'advice'),
    (56, 'boldface', 'Boldface overuse', f_bold, 4, 'score'),
    (57, 'emoji', 'Emoji', f_emoji, 6, 'score'),
    (58, 'em_dash', 'Em-dash overuse', f_dashes, 0, 'advice'),
    (59, 'title_case_heading', 'Title case in headings', f_title_case, 8, 'score'),
    (60, 'curly_quotes', 'Curly quotation marks', f_curly, 0, 'advice'),
    (61, 'hyphen_en_dash', 'Hyphen for en dash in ranges', _year_ranges, 0, 'advice'),
    (62, 'invisible', 'Invisible or zero-width characters', f_invisible, 12, 'score'),
    (63, 'placeholder', 'Placeholder text', f_placeholder, 12, 'score'),
    (64, 'chat_markup', 'Chat reference markup', f_chat_markup, 12, 'score'),
    (65, 'tracking_param', 'AI tracking parameter', f_tracking, 12, 'score'),
    (66, 'homoglyph', 'Mixed-script homoglyphs', f_homoglyph, 12, 'score'),
    (67, 'nonstandard_space', 'Non-standard spaces', f_nonstandard, 6, 'score'),
    (68, 'trailing_whitespace', 'Trailing or stray whitespace', None, 0, 'advice'),
    (69, 'marketing_slop', 'Canonical marketing phrase', f_slop, 8, 'score'),
    (70, 'decorative_rules', 'Decorative horizontal rules', f_hr, 8, 'score'),
    (71, 'degenerate_repetition', 'Degenerate repetition', f_degenerate, 8, 'score'),
]


def _trailing_hits(ctx):
    raw = ctx.raw
    hits = []
    for m in re.finditer(r'[ \t]+(?=\r?\n)', raw):
        hits.append('trailing spaces on a line')
    if raw and raw[-1] in ' \t':
        hits.append('whitespace at end of text')
    if raw.endswith('\n\n'):
        hits.append('extra newlines at end of text')
    if raw and raw[0].isspace():
        hits.append('whitespace before first character')
    return hits


RULE_FUNCS = []
for _num, _slug, _label, _fn, _w, _kind in RULES:
    RULE_FUNCS.append((_num, _slug, _label, _fn if _fn is not None else _trailing_hits, _w, _kind))


# ---------------------------------------------------------------- scoring

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]
HOOK_PHRASE = {'clean': 'reads clean', 'light tells': 'reads mostly clean',
               'mixed': 'reads with some AI tells', 'heavy tells': 'reads with heavy AI tells',
               'pervasive tells': 'reads with pervasive AI tells'}


def band_of(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return 'pervasive tells'


class Ctx(object):
    def __init__(self, raw):
        self.raw = raw
        self.t = mask_nonprose(raw)
        self.words = words_of(self.t)
        self.paras = split_paragraphs(self.t)
        self.sents = split_sentences(self.t)


def run_rules(ctx):
    results = []
    for num, slug, label, fn, weight, kind in RULE_FUNCS:
        hits = fn(ctx)
        if hits:
            results.append({'num': num, 'slug': slug, 'label': label, 'count': len(hits),
                            'samples': hits[:3], 'weight': weight, 'kind': kind})
    return results


def compute_score(results, n_words):
    """Return (score, families, decisive, confidence, reason)."""
    score_items = [r for r in results if r['kind'] in ('score', 'rhythm') and r['weight'] > 0]
    families = set(r['num'] for r in score_items)
    decisive = families & DECISIVE

    if not families:
        base = 0.0
    else:
        base = 0.0
        for r in score_items:
            factor = 1.0 + 0.15 * min(r['count'] - 1, 6)
            base += r['weight'] * factor
    score = min(100, int(round(base)))

    # confidence (spec: FP-01 confidence rule)
    n = len(families)
    if n_words < 40:
        conf = 'none'
    elif n_words < 120 or (n_words < 300 and n == 1):
        conf = 'low'
    elif n_words < 300:
        conf = 'moderate'
    else:
        conf = 'high'

    # caps: a single family is at most 40; rhythm-only is at most 40; monotony-only is 20
    if families:
        if families <= {40}:
            score = min(score, 20)
        elif families <= {40, 44}:
            score = min(score, 40)
        elif len(families) == 1:
            score = min(score, 40)

    # floors
    if families:
        if len(families) == 1 and decisive and conf in ('moderate', 'high'):
            score = max(score, 45)
        if len(decisive) >= 2:
            score = max(score, 65)
        if n_words < 120:
            small = families & SMALL_FAMILY_RANGE
            if len(small) >= 3:
                score = max(score, 45)
            elif len(small) >= 2:
                score = max(score, 25)
        if n_words >= 400:
            if len(families) >= 6:
                score = max(score, 45)
            elif len(families) >= 5:
                score = max(score, 25)
    score = max(0, min(100, score))

    if conf == 'high':
        reason = ''
    elif conf == 'none':
        reason = 'fewer than 40 words (%d); too little text to score' % n_words
    elif conf == 'low':
        reason = 'fewer than 120 words (%d), or fewer than 300 with one pattern family' % n_words
    else:
        reason = 'fewer than 300 words (%d); 300 or more give high confidence' % n_words
    return score, families, decisive, conf, reason


def score_text(raw_window):
    ctx = Ctx(raw_window)
    results = run_rules(ctx)
    score, families, decisive, conf, reason = compute_score(results, len(ctx.words))
    return score, results, conf, reason, len(ctx.words)


def ci_interval(window):
    sents = split_sentences(mask_nonprose(window))
    if len(sents) < 4:
        return None, 'too few sentences (%d); an interval needs at least 4' % len(sents)
    # Large windows: draw from an evenly spaced pool of 400 sentences so the
    # interval stays quick. Recorded in score_ci_note.
    pool = sents
    if len(pool) > 400:
        step = len(pool) / 400.0
        pool = [sents[int(i * step)] for i in range(400)]
    resamples = 50 if len(pool) <= 150 else 25
    rng = random.Random(1234)
    scores = []
    for _ in range(resamples):
        pick = [pool[rng.randrange(len(pool))] for _ in range(len(pool))]
        s, _, _, _, _ = score_text(' '.join(pick))
        scores.append(s)
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(round(0.95 * (len(scores) - 1)))]
    if lo > hi:
        lo, hi = hi, lo
    return [lo, hi], 'bootstrap over %d sentences: %d resamples, seed 1234' % (len(pool), resamples)


def build_report(text, want_ci=False):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    ctx = Ctx(window)
    results = run_rules(ctx)
    n_words = len(ctx.words)
    score, families, decisive, conf2, reason2 = compute_score(results, n_words)
    counts = character_counts(window)

    report = {}
    used_keys = set()
    for r in sorted(results, key=lambda x: (x['num'], x['slug'])):
        key = '%d_%s' % (r['num'], r['slug'])
        report[key] = {'label': r['label'], 'count': r['count'], 'samples': r['samples']}
        used_keys.add(key)

    metrics = {
        'scanned_chars': len(window),
        'truncated': bool(truncated),
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf2,
        'confidence_reason': reason2,
        'patterns_flagged': len(results),
        'invisible_chars': counts['invisible'],
        'nonstandard_spaces': counts['nonstandard'],
        'homoglyphs': counts['homoglyph_chars'],
        'word_count': n_words,
        'score_families': len(families),
    }
    if want_ci:
        ci, note = ci_interval(window)
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------- CLI

def _write_out(data):
    sys.stdout.buffer.write(data.encode('utf-8'))
    sys.stdout.buffer.flush()


def _write_err(line):
    sys.stderr.buffer.write((line + '\n').encode('utf-8', errors='replace'))
    sys.stderr.buffer.flush()


def parse_args(argv):
    clean = False
    ci = False
    show_help = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == '--':
            end = True
            continue
        if arg in ('--help', '-h'):
            show_help = True
            continue
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            ci = True
            continue
        if arg.startswith('-'):
            raise OptionError("unknown option '%s'; see --help" % arg)
        operands.append(arg)
    return clean, ci, show_help, operands


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    try:
        clean, ci, show_help, operands = parse_args(argv)
    except OptionError as exc:
        _write_err(json.dumps({'error': str(exc)}))
        return 2
    if show_help:
        _write_out(USAGE)
        return 0
    try:
        if operands:
            first = operands[0]
            if len(operands) > 1:
                _write_err('note: scanning only the first file operand: %s (ignored %d more)'
                           % (first, len(operands) - 1))
            text = extract_file(first)
        else:
            text = extract_stdin()
        if not text.strip():
            raise InputError('empty input')
        if clean:
            out = scrub(text)
            if not out.strip():
                raise InputError('empty input')
            _write_out(out)
            return 0
        report = build_report(text, want_ci=ci)
        _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        return 0
    except InputError as exc:
        _write_err(json.dumps({'error': str(exc)}))
        return 1
    except Exception as exc:  # never a traceback on the error stream
        _write_err(json.dumps({'error': 'cannot read input: internal failure (%s)' % type(exc).__name__}))
        return 1


if __name__ == '__main__':
    sys.exit(main())
