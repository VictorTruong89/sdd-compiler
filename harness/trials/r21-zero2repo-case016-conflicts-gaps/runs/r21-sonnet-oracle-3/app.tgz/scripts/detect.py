#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only AI-writing pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import sys
import os
import re
import json
import math
import random
import unicodedata
import zipfile
import posixpath
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144  # spec: FP-01 scan window
USAGE = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE_FULL = (
    USAGE + "\n\n"
    "Scores prose for AI-writing patterns (0-100) and prints a JSON report.\n"
    "  --clean   print scrubbed text instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        stop option parsing (file names may begin with a dash)\n"
    "  FILE      one file operand; with none, standard input is read\n"
)

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}
MEMBER_CAP = 64 * 1024 * 1024  # archive-member size cutoff (implementer's choice)

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]


class Fail(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code


# ----------------------------------------------------------------- decoding
def decode_bytes(b):
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", "replace")
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except UnicodeDecodeError:
            return b.decode("utf-16", "replace")
    return b.decode("utf-8", "replace")


# --------------------------------------------------------------- extraction
def _local(tag):
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1]


def _read_member(zf, name):
    info = zf.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return None
    return zf.read(name)


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _strip_tags(data):
    s = data.decode("utf-8", "replace")
    s = re.sub(r"<[^>]+>", " ", s)
    return s


def _para_text(el, tmap):
    """Concatenate text for a paragraph element. tmap maps local names to behaviour."""
    out = []

    def walk(e):
        n = _local(e.tag)
        if n in tmap["text"]:
            out.append(e.text or "")
        elif n in tmap["tab"]:
            out.append("\t")
        elif n in tmap["br"]:
            out.append("\n")
        elif n == "s" and tmap.get("odf"):
            try:
                out.append(" " * int(e.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c") or e.get("c") or 1))
            except ValueError:
                out.append(" ")
        elif n in tmap.get("skip", ()):
            return
        else:
            if tmap.get("odf") and e.text:
                out.append(e.text)
            for c in e:
                walk(c)
                if tmap.get("odf") and c.tail:
                    out.append(c.tail)
            return
        # leaf handled; tail text is irrelevant in ooxml
        return

    if tmap.get("odf"):
        if el.text:
            out.append(el.text)
        for c in el:
            walk(c)
            if c.tail:
                out.append(c.tail)
    else:
        for c in el:
            walk(c)
    return "".join(out)


OOXML_P = {"text": {"t"}, "tab": {"tab"}, "br": {"br", "cr"}}
ODF_P = {"text": set(), "tab": {"tab"}, "br": {"line-break"}, "odf": True, "skip": {"annotation"}}


def extract_docx(zf):
    names = zf.namelist()
    target = "word/document.xml"
    if target not in names:
        return ""
    data = _read_member(zf, target)
    if data is None:
        return ""
    root = _parse_xml(data)
    if root is None:
        return re.sub(r"\s+", " ", _strip_tags(data))
    paras = []
    for p in root.iter():
        if _local(p.tag) == "p":
            paras.append(_para_text(p, OOXML_P))
    return "\n".join(paras)


def _num_key(name):
    m = re.search(r"(\d+)", posixpath.basename(name))
    return (int(m.group(1)) if m else 0, name)


def extract_pptx(zf):
    slides = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    slides.sort(key=_num_key)
    out = []
    for n in slides:
        data = _read_member(zf, n)
        if data is None:
            continue
        root = _parse_xml(data)
        if root is None:
            out.append(re.sub(r"\s+", " ", _strip_tags(data)).strip())
            continue
        ps = []
        for p in root.iter():
            if _local(p.tag) == "p":
                t = _para_text(p, {"text": {"t"}, "tab": set(), "br": {"br"}})
                if t:
                    ps.append(t)
        out.append("\n".join(ps))
    return "\n".join(x for x in out if x)


def _si_text(si):
    parts = []

    def walk(e, in_ph):
        n = _local(e.tag)
        if n == "rPh":
            return
        if n == "t":
            parts.append(e.text or "")
        for c in e:
            walk(c, in_ph)

    walk(si, False)
    return "".join(parts)


def extract_xlsx(zf):
    names = zf.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        data = _read_member(zf, "xl/sharedStrings.xml")
        root = _parse_xml(data) if data else None
        if root is not None:
            for si in root:
                if _local(si.tag) == "si":
                    shared.append(_si_text(si))
    sheets = [n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)]
    sheets.sort(key=_num_key)
    out = []
    for n in sheets:
        data = _read_member(zf, n)
        root = _parse_xml(data) if data else None
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            t = c.get("t")
            text = None
            if t == "s":
                v = None
                for ch in c:
                    if _local(ch.tag) == "v":
                        v = (ch.text or "").strip()
                if v is not None and re.fullmatch(r"\d+", v) and int(v) < len(shared):
                    text = shared[int(v)]
            elif t == "inlineStr":
                for ch in c:
                    if _local(ch.tag) == "is":
                        text = _si_text(ch)
            elif t == "str":
                for ch in c:
                    if _local(ch.tag) == "v":
                        text = ch.text or ""
            if text and text.strip():
                out.append(text)
    return "\n".join(out)


def extract_odf(zf):
    if "content.xml" not in zf.namelist():
        return ""
    data = _read_member(zf, "content.xml")
    root = _parse_xml(data) if data else None
    if root is None:
        return re.sub(r"[ \t]+", " ", _strip_tags(data or b""))
    paras = []

    def walk(e):
        n = _local(e.tag)
        if n in ("p", "h") and e.tag.endswith("urn:oasis:names:tc:opendocument:xmlns:text:1.0}" + n):
            paras.append(_para_text(e, ODF_P))
            return
        for c in e:
            walk(c)

    walk(root)
    return "\n".join(p for p in paras if p != "")


class _Html(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
             "section", "article", "ul", "ol", "table", "pre", "dt", "dd", "figcaption", "hr"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK and not self.skip:
            self.out.append("\n")

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK and not self.skip:
            self.out.append("\n")

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        if tag in self.BLOCK and not self.skip:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def _html_text(data):
    p = _Html()
    try:
        p.feed(data.decode("utf-8", "replace"))
        p.close()
    except Exception:
        pass
    lines = []
    for line in "".join(p.out).split("\n"):
        line = re.sub(r"[ \t\r\f\v]+", " ", line).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def extract_epub(zf):
    names = zf.namelist()
    order = []
    nav_items = set()
    try:
        cdata = _read_member(zf, "META-INF/container.xml")
        croot = _parse_xml(cdata) if cdata else None
        opf = None
        if croot is not None:
            for e in croot.iter():
                if _local(e.tag) == "rootfile":
                    opf = e.get("full-path")
                    break
        if opf and opf in names:
            oroot = _parse_xml(_read_member(zf, opf))
            base = posixpath.dirname(opf)
            manifest = {}
            for e in oroot.iter():
                if _local(e.tag) == "item":
                    href = e.get("href")
                    if href:
                        full = posixpath.normpath(posixpath.join(base, href.split("#")[0]))
                        manifest[e.get("id")] = full
                        if "nav" in (e.get("properties") or "").split():
                            nav_items.add(full)
            for e in oroot.iter():
                if _local(e.tag) == "itemref":
                    f = manifest.get(e.get("idref"))
                    if f and f in names and f not in order:
                        order.append(f)
    except Exception:
        order = []
    docs = [n for n in names if re.search(r"\.(x?html?)$", n, re.I)]
    if not order:
        order = sorted(docs)
    else:
        order = [n for n in order if re.search(r"\.(x?html?)$", n, re.I)]
    out = []
    for n in order:
        if n in nav_items or re.search(r"(^|/)(nav|toc)\.x?html?$", n, re.I):
            continue
        data = _read_member(zf, n)
        if data is None:
            continue
        t = _html_text(data)
        if t:
            out.append(t)
    return "\n".join(out)


def extract_ipynb(raw):
    try:
        nb = json.loads(decode_bytes(raw))
    except Exception:
        return ""
    if not isinstance(nb, dict):
        return ""
    cells = nb.get("cells")
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, list) and all(isinstance(x, str) for x in src):
            src = "".join(src)
        if isinstance(src, str) and src.strip():
            out.append(src.strip())
    return "\n".join(out)


def extract(path, raw):
    ext = os.path.splitext(path)[1].lower() if path else ""
    if ext in ZIP_EXT:
        try:
            zf = zipfile.ZipFile(__import__("io").BytesIO(raw))
        except Exception as e:
            raise Fail("cannot read input: not a readable zip archive (%s)" % path)
        try:
            if ext in (".docx", ".docm"):
                t = extract_docx(zf)
            elif ext in (".pptx", ".pptm"):
                t = extract_pptx(zf)
            elif ext in (".xlsx", ".xlsm"):
                t = extract_xlsx(zf)
            elif ext == ".epub":
                t = extract_epub(zf)
            else:
                t = extract_odf(zf)
        except Exception:
            t = ""
        return t.strip()
    if ext in NB_EXT:
        return extract_ipynb(raw).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(raw)


# ------------------------------------------------------------ character layer
def _rng(*pairs):
    return pairs


def _in(c, ranges):
    o = ord(c)
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
NOSPACE = [(0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x3040, 0x30FF), (0x31F0, 0x31FF),
           (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF), (0xFF66, 0xFF9F),
           (0x3000, 0x303F)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF)]
JOINING = [(0x0590, 0x08FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0xFB1D, 0xFDFF),
           (0xFE70, 0xFEFF)]
MONGOLIAN = [(0x1800, 0x18AF)]
KHMER = [(0x1780, 0x17FF)]
EMOJI = [(0x1F000, 0x1FAFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x2460, 0x24FF), (0x25A0, 0x27BF),
         (0x2900, 0x297F), (0x2B00, 0x2BFF), (0x3030, 0x3030), (0x303D, 0x303D), (0x3297, 0x3299),
         (0xA9, 0xA9), (0xAE, 0xAE), (0x203C, 0x203C), (0x2049, 0x2049), (0x2122, 0x2122), (0x2139, 0x2139)]
BIDI = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}
EXTRA_INVIS = {0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5, 0x180E, 0x2060, 0x200B, 0x200C, 0x200D,
               0xFEFF, 0x00AD, 0x061C}


def is_invisible(c):
    o = ord(c)
    if o < 0x80:
        return o < 0x20 and c not in "\t\n\r" or o == 0x7F
    if o in EXTRA_INVIS:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0xE0000 <= o <= 0xE0FFF:
        return True
    if 0x180B <= o <= 0x180F:
        return True
    cat = unicodedata.category(c)
    if cat == "Cc":
        return True
    if cat == "Cf":
        return True
    return False


def _is_symbolish(c):
    if _in(c, EMOJI):
        return True
    cat = unicodedata.category(c)
    return cat in ("So", "Sk", "Sm", "Sc")


def has_rtl(text):
    for c in text:
        if ord(c) >= 0x0590 and _in(c, RTL) and c.isalpha():
            return True
    return False


def keeps_invisible(text, i, rtl):
    """True when the invisible char at text[i] does a job in its position."""
    c = text[i]
    o = ord(c)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if 0xE0000 <= o <= 0xE0FFF:
        # emoji tag sequence: black flag, tags, cancel tag
        if 0xE0020 <= o <= 0xE007F:
            j = i - 1
            while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007E:
                j -= 1
            if j >= 0 and ord(text[j]) == 0x1F3F4:
                return True
        return False
    if 0xE0100 <= o <= 0xE01EF:
        return bool(prev) and _in(prev, CJK)
    if 0xFE00 <= o <= 0xFE0F:
        if prev and (_in(prev, CJK) or _is_symbolish(prev)):
            return True
        if nxt == "⃣":
            return True
        return False
    if o == 0x200B:
        return (bool(prev) and _in(prev, NOSPACE)) or (bool(nxt) and _in(nxt, NOSPACE))
    if o == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if o in BIDI:
        return rtl
    if 0x180B <= o <= 0x180F:
        return bool(prev) and _in(prev, MONGOLIAN)
    if o in (0x17B4, 0x17B5):
        return (bool(prev) and _in(prev, KHMER)) or (bool(nxt) and _in(nxt, KHMER))
    if o in (0x200C, 0x200D):
        for n in (prev, nxt):
            if n and ((_in(n, JOINING) and n.isalpha()) or _is_symbolish(n)):
                return True
        return False
    return False


NBSPS = (" ", " ")


def keeps_nbsp(text, i):
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


def is_space_sep(c):
    return c != " " and unicodedata.category(c) == "Zs"


LOOK = {}


def _addmap(s, t):
    for a, b in zip(s, t):
        LOOK[a] = b


_addmap("асеорхуіјѕԁһԝ", "acepxyijsdhw")
_addmap("АВСЕНІЈКМОРЅТХҮУ", "ABCEHIJKMOPSTXYY")
_addmap("ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ", "ABEZHIKMNOPTYX")
_addmap("οανρυιϲϳ", "oavpuicj")
_addmap("սօոցհ", "uong" "h")
_addmap("ԱՕՍՏ", "AOST") if False else None
LOOK_SET = set(LOOK)


def homoglyph_runs(text):
    """Return list of (start, end) indices of tokens that meet the homoglyph condition."""
    res = []
    for m in re.finditer(r"\S+", text):
        tok = m.group()
        if tok.isascii():
            continue
        has_look = False
        bad = False
        has_ascii = False
        for ch in tok:
            if ch in LOOK_SET:
                has_look = True
            elif ord(ch) >= 128 and ch.isalpha():
                bad = True
                break
            elif ch.isascii() and ch.isalpha():
                has_ascii = True
        if has_look and has_ascii and not bad:
            # require a single run of letters mixing both
            ok = False
            for r in re.finditer(r"[^\W\d_]+", tok):
                run = r.group()
                if any(ch in LOOK_SET for ch in run) and any(ch.isascii() for ch in run):
                    ok = True
                    break
            if ok:
                res.append((m.start(), m.end()))
    return res


def char_layer(text):
    """Return (invisible_positions, space_positions, homoglyph_char_count)."""
    inv = []
    sp = []
    rtl = None
    n = len(text)
    # fast path
    if text.isascii():
        for i, c in enumerate(text):
            o = ord(c)
            if (o < 0x20 and c not in "\t\n\r") or o == 0x7F:
                inv.append(i)
        return inv, sp, 0
    for i, c in enumerate(text):
        if ord(c) < 0x80:
            o = ord(c)
            if (o < 0x20 and c not in "\t\n\r") or o == 0x7F:
                inv.append(i)
            continue
        if is_invisible(c):
            if ord(c) in BIDI and rtl is None:
                rtl = has_rtl(text)
            if not keeps_invisible(text, i, bool(rtl)):
                inv.append(i)
        elif is_space_sep(c):
            if c in NBSPS and keeps_nbsp(text, i):
                continue
            sp.append(i)
    hg = 0
    for a, b in homoglyph_runs(text):
        hg += sum(1 for ch in text[a:b] if ch in LOOK_SET)
    return inv, sp, hg


def cleanup(text):
    inv, sp, _ = char_layer(text)
    drop = set(inv)
    spset = set(sp)
    out = []
    for i, c in enumerate(text):
        if i in drop:
            continue
        if i in spset:
            out.append(" ")
        elif c in (" ", " "):
            out.append("\n")
        else:
            out.append(c)
    s = "".join(out)
    # fold homoglyphs
    if not s.isascii():
        pieces = []
        last = 0
        for a, b in homoglyph_runs(s):
            pieces.append(s[last:a])
            pieces.append("".join(LOOK.get(ch, ch) for ch in s[a:b]))
            last = b
        pieces.append(s[last:])
        s = "".join(pieces)
    ended_lf = text.endswith("\n") or text.endswith(" ") or text.endswith(" ")
    s = re.sub(r"[ \t]+(?=\r?\n|\r|$)", "", s)
    s = re.sub(r"\A(?:[ \t]*\r?\n)+", "", s)
    s = s.rstrip(" \t\r\n\f\v")
    if ended_lf and s:
        s += "\n"
    return s


# ------------------------------------------------------------------ masking
FENCE_RE = re.compile(r"^( {0,3})(`{3,}|~{3,})(.*)$")


def mask_markdown(text):
    """Blank (with spaces) regions that never generate findings. Length preserved."""
    n = len(text)
    keep = list(text)

    def blank(a, b):
        for k in range(a, b):
            if keep[k] != "\n":
                keep[k] = " "

    # front matter
    pos = 0
    if text.startswith("---"):
        m = re.match(r"---[ \t]*\n(?:.*?\n)?(?:---|\.\.\.)[ \t]*(?:\n|$)", text, re.S)
        if m:
            blank(0, m.end())
            pos = m.end()
    # line pass
    lines = []
    idx = 0
    for ln in text.split("\n"):
        lines.append((idx, idx + len(ln), ln))
        idx += len(ln) + 1
    i = 0
    nl = len(lines)
    fence = None
    quote_run = []
    in_front = pos
    while i < nl:
        a, b, ln = lines[i]
        if b <= pos and a < pos:
            i += 1
            continue
        if fence is not None:
            fch, flen, fstart = fence
            m = re.match(r"^ {0,3}(`+|~+)[ \t]*$", ln)
            blank(a, b)
            if m and m.group(1)[0] == fch and len(m.group(1)) >= flen:
                fence = None
            i += 1
            continue
        m = FENCE_RE.match(ln)
        if m and not (m.group(2)[0] == "`" and "`" in m.group(3)):
            fence = (m.group(2)[0], len(m.group(2)), a)
            blank(a, b)
            i += 1
            continue
        i += 1
    # blockquote runs, table rows, badge lines (skip fenced, already blank)
    i = 0
    badge = re.compile(r"^\s*(?:\[?!\[[^\]]*\]\([^)]*\)(?:\]\([^)]*\))?\s*)+$")
    while i < nl:
        a, b, ln = lines[i]
        cur = "".join(keep[a:b])
        if cur.lstrip().startswith(">"):
            j = i
            while j < nl and "".join(keep[lines[j][0]:lines[j][1]]).lstrip().startswith(">"):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    blank(lines[k][0], lines[k][1])
            i = j
            continue
        s = cur.strip()
        if s.startswith("|") and s.count("|") >= 2:
            blank(a, b)
        elif s and badge.match(cur):
            blank(a, b)
        i += 1
    s = "".join(keep)
    # inline code spans
    out = []
    last = 0
    for m in re.finditer(r"(?<!`)(`+)(?!`)((?:(?!\n[ \t]*\n).)*?)(?<!`)\1(?!`)", s, re.S):
        out.append(s[last:m.start()])
        out.append("".join(" " if ch != "\n" else "\n" for ch in m.group()))
        last = m.end()
    out.append(s[last:])
    return "".join(out)


# ---------------------------------------------------------------- lexicon
def infl(w):
    forms = {w, w + "s", w + "es", w + "ed", w + "d", w + "ing"}
    if w.endswith("e"):
        forms.add(w[:-1] + "ing")
    if w.endswith("y"):
        forms |= {w[:-1] + "ies", w[:-1] + "ied"}
    forms.add(w + w[-1] + "ed")
    forms.add(w + w[-1] + "ing")
    return sorted(forms, key=len, reverse=True)


def words_re(words, inflect=False, flags=re.I):
    alts = []
    for w in words:
        if inflect and " " not in w and "-" not in w:
            alts.extend(re.escape(f) for f in infl(w))
        else:
            alts.append(re.escape(w).replace(r"\ ", r"\s+"))
    return re.compile(r"(?<![\w-])(?:" + "|".join(alts) + r")(?![\w-])", flags)


APOS = "['’]"


def rx(p, flags=re.I):
    return re.compile(p.replace("'", APOS), flags)


AI_WORDS = ("additionally crucial delve tapestry pivotal vibrant meticulous testament underscore intricate "
            "intricacies interplay garner bolster foster showcase emphasize enduring enhance leverage utilize "
            "facilitate encompass harness holistic paradigm transformative unprecedented myriad plethora robust "
            "seamless navigate embark craft landscape journey realm multifaceted elevate empower unlock").split()
RE_AI = re.compile(
    words_re(AI_WORDS, True).pattern + r"|(?<![\w-])align(?:s|ed|ing)?\s+with(?![\w-])"
    r"|(?<![\w-])captur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic)(?![\w-])", re.I)

RE_DIALECT = re.compile(
    r"(?<![\w-])(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly"
    r"|quietly\s+(?:powerful|profound|radical)|deeply\s+(?:human|personal|felt|unsettling)"
    r"|resonates?\s+deeply|game[- ]chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|skyrocket(?:s|ed|ing)?"
    r"|turbocharg(?:e|es|ed|ing)|revolutioniz(?:e|es|ed|ing)|doubl(?:e|es|ed|ing)\s+down\s+on"
    r"|div(?:e|es|ed|ing)\s+deep(?:er)?\s+into|unlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)"
    r"|tak(?:e|es|ing)\s+\w+(?:\s+\w+){0,3}?\s+to\s+the\s+next\s+level)(?![\w-])", re.I)

PROMO = ("nestled breathtaking must-visit stunning picturesque charming idyllic vibrant\\s+community "
         "rich\\s+cultural\\s+heritage in\\s+the\\s+heart\\s+of world-class top-tier unparalleled premier leading "
         "esteemed\\s+organization valuable\\s+asset passion\\s+for\\s+excellence proven\\s+track\\s+record "
         "results-oriented wealth\\s+of\\s+experience dynamic\\s+team fast-paced\\s+environment deeply\\s+passionate "
         "perfectly\\s+situated (?:close|tight)-knit\\s+team I\\s+am\\s+excited\\s+to\\s+(?:apply|bring) "
         "uniquely\\s+positioned\\s+to").split()
RE_PROMO = re.compile(r"(?<![\w-])(?:" + "|".join(PROMO) + r")(?![\w-])", re.I)
IMPERATIVES = ("install join grab download try discover experience escape transform reclaim unlock elevate boost say "
               "imagine explore meet introducing upgrade claim unleash supercharge level stop start").split()
RE_IMPER = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))\s*(?:" + "|".join(IMPERATIVES) + r")\b", re.I)

HYPH = ("cutting-edge state-of-the-art best-in-class world-class results-driven data-driven forward-thinking "
        "fast-paced well-rounded high-quality cross-functional end-to-end next-generation mission-critical "
        "ground-breaking customer-centric value-added top-notch user-friendly results-oriented detail-oriented "
        "award-winning hands-on high-performing high-impact game-changing thought-provoking future-proof "
        "innovative-minded self-starter team-oriented client-focused solution-oriented growth-oriented "
        "forward-looking industry-leading best-of-breed full-service one-stop").split()
RE_HYPH = re.compile(r"(?<![\w-])(?:" + "|".join(re.escape(h) for h in HYPH) + r")(?![\w-])", re.I)

RE_SIMPLEYET = re.compile(r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b", re.I)

SYN = [
    "protagonist|main character|central figure|hero|heroine",
    "company|firm|organization|enterprise|business",
    "author|writer|novelist|scribe",
    "report|study|analysis|investigation|examination",
    "technology|tool|system|platform|solution",
    "technique|method|approach|strategy|tactic",
    "challenge|obstacle|difficulty|hurdle|barrier",
    "benefit|advantage|upside|strength",
]


def _plural_alts(group):
    alts = []
    for w in group.split("|"):
        alts.append(re.escape(w).replace(r"\ ", r"\s+"))
        if w.endswith("y") and " " not in w:
            alts.append(re.escape(w[:-1]) + "ies")
        elif w.endswith(("s", "x", "ch")) :
            alts.append(re.escape(w) + "es")
        else:
            alts.append(re.escape(w) + "s")
    return alts


SYN_RES = []
for g in SYN:
    members = g.split("|")
    res = []
    for w in members:
        alts = _plural_alts(w)
        res.append(re.compile(r"(?<![\w-])(?:" + "|".join(alts) + r")(?![\w-])", re.I))
    SYN_RES.append(res)

RE_SIGNIF = rx(
    r"\b(?:stand(?:s|ing)?|stood|serv(?:es|ed|ing|e))\s+as\s+(?:a|an|the)\s+(?:\w+\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b"
    r"|\bunderscor(?:es|ed|ing|e)|\bhighlight(?:s|ed|ing)?\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b"
    r"|\breflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)\b"
    r"|\bmark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b"
    r"|\bsymboli[sz](?:es|ed|ing)\b|\bsets?\s+the\s+stage\s+for\b|\bleft\s+an\s+indelible\s+mark\b"
    r"|\bplay(?:s|ed|ing)?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b"
    r"|\bhas\s+(?:shaped|sparked)\b|\bhas\s+come\s+to\s+(?:define|symbolize|symbolise)\b")
RE_VAGUE = rx(
    r"\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b|\bindustry\s+(?:reports|observers|analysts)\b"
    r"|\bobservers\s+have\s+(?:cited|noted)\b|\bsome\s+critics\s+argue\b|\bresearchers\s+have\s+found\b"
    r"|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b")
RE_TITLE = re.compile(
    r"\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+[\w'’:,&\- ]{1,80}?\s+(?:is|are)\s+(?:a|an|the)\b")
RE_ECO = rx(r"\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b"
            r"|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b|\bserves\s+as\s+an\s+indicator\s+species\b"
            r"|\bcontributes?\s+to\s+biodiversity\b")
RE_FALSERANGE = rx(
    r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
RE_ING = rx(r",\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising)\b")
RE_NOTX = rx(r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+"
             r"|\b(?:not|isn't|aren't|wasn't|weren't)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+\s*(?:,|\s[—–-]+|—|–)\s*(?:it's|it\s+is|it\s+was|they're|they\s+are|they\s+were|that's|but)\b")
RE_PAR1 = rx(r"\bit's\s+not\s+(?:just|merely)\s+(?:about|an?)\b")
RE_PAR2 = rx(r"\bnot\s+only\b[^.!?]{0,40}?\bbut\b")
RE_PAR3 = rx(r"\bdoesn't\s+just\b[^,.]{0,40}?\bit\b")
RE_TAILNEG = rx(r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")
RE_PIVOT = rx(r"\bit's\s+worth\s+(?:noting|mentioning)\s+that\b|\bit\s+bears\s+(?:noting|mentioning)\s+that\b"
              r"|\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b|\bit\s+is\s+interesting\s+to\s+note\s+that\b"
              r"|\bit\s+is\s+worth\s+(?:noting|mentioning)\s+that\b|\ba\s+key\s+consideration\s+is\b|\ba\s+point\s+to\s+highlight\s+is\b")
RE_OUTCOME = rx(r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b")
RE_HOOK = rx(r"\bin\s+today's\s+(?:\w+\s+){0,2}(?:world|landscape|environment|market)\b|\bin\s+a\s+world\s+where\b"
             r"|\bin\s+an\s+era\s+of\b|\bin\s+recent\s+years,|\bmore\s+than\s+ever\s+before\b|\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b"
             r"|\b(?:great|exciting|big)\s+news\s*[!:]|\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]*\?"
             r"|\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b")
RE_CHALL = rx(r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b|\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b"
              r"|\bcontinues\s+to\s+thrive\b|\btypical\s+of\s+(?:emerging|urban|modern)\b|\bfaces\s+(?:several|many|numerous)\s+challenges\b")
TRANS = "Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably"
RE_TRANS = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=[.!?][\"”’)]\s)|(?<=\n))[ \t]*(?:" + TRANS + r")\b")
RE_CONCL = re.compile(r"^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b", re.I | re.M)
RE_POSCONC = rx(r"\bthe\s+future\s+looks\s+bright\b|\bexciting\s+times\s+lie\s+ahead\b|\bjourney\s+toward\s+excellence\b"
                r"|\bstep\s+in\s+the\s+right\s+direction\b|\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b"
                r"|\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b")
RE_FILLER = rx(r"\bin\s+order\s+to\b|\bdue\s+to\s+the\s+fact\s+that\b|\bat\s+this\s+point\s+in\s+time\b|\bin\s+the\s+event\s+that\b"
               r"|\bhas\s+the\s+ability\s+to\b|\bit\s+is\s+important\s+to\s+note\s+that\b|\bit\s+should\s+be\s+mentioned\s+that\b|\bneedless\s+to\s+say\b")
RE_AUTH = rx(r"\bhere's\s+the\s+thing\b|\bmake\s+no\s+mistake\b|\bthe\s+truth\s+is\b|\blet's\s+be\s+honest\b|\bthe\s+simple\s+fact\s+is\b"
             r"|\bat\s+its\s+core\b|\bwhat\s+really\s+matters\b|\bmore\s+than\s+anything\b|\bat\s+the\s+end\s+of\s+the\s+day\b"
             r"|\bthe\s+bottom\s+line\s+is\b|\bin\s+reality\b|\bfundamentally,|\bthe\s+real\s+question\s+is\b|\bthe\s+heart\s+of\s+the\s+matter\b"
             r"|\bthe\s+deeper\s+issue\b|\bwhen\s+you\s+get\s+down\s+to\s+it\b|\bwhen\s+all\s+is\s+said\s+and\s+done\b")
RE_EDIT = rx(r"\bit's\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b|\bit\s+is\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b"
             r"|\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b|\bit\s+cannot\s+be\s+overstated\s+that\b|\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b")
RE_THOROUGH = rx(r"\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b|\bthis\s+in-depth\s+(?:analysis|look|examination)\b"
                 r"|\bthis\s+complete\s+(?:guide|overview)\b|\ba\s+thorough\s+examination\s+of\b|\beverything\s+you\s+need\s+to\s+know\s+about\b")
RE_QA = re.compile(
    r"(?:^|(?<=[.!?]\s)|(?<=\n))((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|May|Might|Must|Has|Have|Had)\b[^.!?\n]{0,80}\?)\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Sometimes)[.!]")
RE_CONCRETE = rx(r"\bwithout\s+concrete\s+(?:evidence|proof)\b|\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b"
                 r"|\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\b|\babsent\s+concrete\s+(?:proof|evidence)\b|\bprovide\s+concrete\s+(?:evidence|proof)\b")
RE_DIFF = rx(r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b"
             r"|\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b"
             r"|\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b|\bpreviously\b[^.!?\n]*\bnow\b"
             r"|\b(?:wasn't|weren't)\s+there\s+before\b|\bwe(?:'ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b")
RE_SIGNPOST = rx(r"\blet's\s+(?:dive|delve|explore)\b|\blet's\s+break\s+(?:this|it)\s+down\b|\bhere's\s+what\s+you\s+need\s+to\s+know\b"
                 r"|\bwithout\s+further\s+ado\b|\bnow\s+let's\s+look\s+at\b|\bbuckle\s+up\b|\bstay\s+with\s+me\b|\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b")
RE_CATALOG = rx(r"\b(?:used|uses|employs|employed|relied\s+on|utilizes|utilises)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+"
                r"|(?:^|(?<=[.!?]\s)|(?<=\n))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|insights|understanding|details|data)\b"
                r"|\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b")
RE_BOLDHEAD = re.compile(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*[ \t]?:)", re.M)
RE_HEADING = re.compile(r"^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t#]*$", re.M)
RE_CHATBOT = rx(
    r"\bI\s+hope\s+this\s+helps\b|\bCertainly!|\bOf\s+course!|\blet\s+me\s+know\s+if\s+you\b|\bwould\s+you\s+like\s+me\s+to\b"
    r"|\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b|\bhappy\s+to\s+help\s*(?:[.!]|$)"
    r"|\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b"
    r"|\bhere\s+(?:are|is)\s+(?:a\s+)?(?:few|some|two|three)\s+(?:options|drafts|versions|variations)\b|\bhere's\s+(?:a\s+)?(?:few|some|two|three)\s+(?:options|drafts|versions|variations)\b"
    r"|\bhere\s+is\s+a\s+draft\b|\bhere's\s+a\s+draft\b|\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b|\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b"
    r"|\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b"
    r"|\bto\s+(?:answer|address)\s+your\s+question\b|\bin\s+(?:response|answer)\s+to\s+your\s+question\b|\byour\s+question\s+(?:about|regarding|concerning)\b"
    r"|\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b|\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b")
RE_SYCO = rx(r"\byou(?:'re|\s+are)\s+absolutely\s+right\b|\b(?:great\s+question|excellent\s+point)\s*[!.,]"
             r"|\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b"
             r"|\bthat's\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\s*[!.,]")
RE_CUTOFF = rx(r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b"
               r"|\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b"
               r"|\bbased\s+on\s+(?:the\s+)?available\s+information\b|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b"
               r"|\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b")
RE_COPULA = rx(r"\b(?:serves|stands|functions|acts)\s+as\b|\brepresents\s+(?:a|the)\b|\bmarks\s+(?:a|the)\b|\bboasts?\b"
               r"|\bfeatures\s+(?:a|an|the|\d+|several|many|numerous|multiple|various|some|two|three|four|five)\b|\boffers\s+a\b|\brefers\s+to\b")
RE_HEDGE_WORDS = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")
RE_NOTABLE = rx(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+(?:[A-Z][\w&.-]*(?:\s+[A-Z][\w&.-]*)*)(?:,\s*(?:and\s+)?|\s+and\s+)(?:[A-Z][\w&.-]*)"
                r"|\b\d[\d,.]*[kKmM]?\s+(?:followers|subscribers)\b"
                r"|\b(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence\b|\bwidely\s+covered\b|\bindependent\s+coverage\b", 0)
RE_CONTRACTIBLE = re.compile(r"\b(?:do|does|did|is|are|was|were|will|would|should|could|have|has|had)\s+not\b|\bcannot\b|\bcan\s+not\b"
                             r"|\b(?:I\s+am|I\s+have|I\s+will|I\s+would|we\s+are|we\s+have|we\s+will|they\s+are|you\s+are|it\s+is|that\s+is|there\s+is|let\s+us)\b", re.I)
RE_CONTRACTED = re.compile(r"\b\w+(?:n['’]t|['’](?:m|re|ve|ll|d))\b|\b(?:it|that|there|let)['’]s\b", re.I)
RE_FIRSTP = re.compile(r"\b(?:I|me|my|mine|myself|we|our|ours|us|I['’]m|I['’]ve|I['’]ll|I['’]d)\b")
RE_BOLD = re.compile(r"\*\*[^*\n]+\*\*")
RE_EMOJI = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⭐⭕⌚⌛⏩-⏺✅❌✨‼⁉]")
RE_CURLY = re.compile("[‘’“”‚„‛‟]")
RE_YEARS = re.compile(r"(?<![\d-])(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})(?![\d-])")
RE_SLOP = rx(r"\bunlock(?:ing)?\s+(?:your\s+|its\s+|their\s+|the\s+)?full\s+potential\b|\bnavigat(?:e|es|ed|ing)\s+the\s+complexit(?:y|ies)\b"
             r"|\ba\s+testament\s+to\s+the\s+(?:power|importance)\b|\bstay(?:s|ed|ing)?\s+ahead\s+of\s+the\s+curve\b"
             r"|\bturn(?:s|ed|ing)?\s+challenges\s+into\s+opportunities\b|\btak(?:e|es|ing)\s+(?:\w+\s+){1,3}?to\s+the\s+next\s+level\b"
             r"|\bharness(?:es|ed|ing)?\s+the\s+power\s+of\b|\bpav(?:e|es|ed|ing)\s+the\s+way\s+for\b|\bsaying\s+goodbye\s+to\b"
             r"|\bimagin(?:e|ing)\s+a\s+world\s+where\b|\bunleash(?:es|ed|ing)?\s+the\s+power\s+of\b|\bin\s+the\s+ever-evolving\s+(?:world|landscape)\s+of\b"
             r"|\bembark(?:s|ed|ing)?\s+on\s+a\s+journey\b|\bgame-changing\s+solution\b")
RE_HR = re.compile(r"^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$", re.M)

PH_NAME = re.compile(r"\[\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\]|\[[ A-Za-z]{0,30}\b(?:name|company|client|city|place|person|source|recipient|location)\b[ A-Za-z]{0,30}\]", re.I)
PH_CAPS = re.compile(r"\[[A-Z][A-Z0-9 _/\-]{2,40}\]")
PH_SHORT = re.compile(r"^(?:[A-Z]{1,2}\d*|[A-Z][a-z]?\d+|[A-Z]{1,3}\d+|[IVXLCDM]{1,5})$")
PH_BRACE = re.compile(r"\{\{[^}\n]+\}\}")
PH_X = re.compile(r"(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])")
PH_LOREM = re.compile(r"\blorem\s+ipsum\b", re.I)
RE_CHATREF = re.compile(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|\bnavlist\b|【\d+†[^】]*】")
RE_UTM = re.compile(r"utm_source=([A-Za-z0-9.\-]+)", re.I)
UTM_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com", "copilot.microsoft.com", "poe.com"}

RE_WORD = re.compile(r"(?:[^\W_]|['’-])+")
RE_ADJ = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$")
STOCK_ADJ = set("dynamic bold bright sleek modern powerful innovative elegant stunning vibrant rich dynamic seamless robust "
                "comprehensive cutting-edge exciting beautiful unique flexible scalable reliable".split())


# ---------------------------------------------------------------- analysis
LABELS = {
    1: "AI vocabulary", 2: "Model-dialect vocabulary", 3: "Promotional language", 4: "Hyphenated word-pair overuse",
    5: "\"Simple yet X\" cliche", 6: "Stacked adjective chains", 8: "Synonym cycling", 10: "Significance inflation",
    11: "Notability name-dropping", 12: "Vague attributions", 13: "Article title as proper noun",
    14: "Conservation / ecosystem padding", 15: "False ranges", 16: "Superficial -ing tail clauses",
    "17p": "Negative parallelism", "17t": "Tailing negation", 18: "\"Not X, just Y\" construction",
    19: "Filler phrases", 20: "Empty pivot phrases", 21: "Outcome speculation tails", 22: "Persuasive authority tropes",
    23: "Editorial interjections", 24: "Self-thoroughness phrases", 25: "Question-answer rhetorical pattern",
    26: "\"Concrete evidence\" defense phrase", 27: "Compulsive intro hooks", 30: "Diff-anchored writing",
    31: "Signposting and announcements", 32: "Cataloguing lead-ins", 33: "Inline-header vertical lists",
    34: "Mid-essay bullet injection", 35: "Fragmented headers", 36: "Formulaic challenges section",
    37: "Transition cluster overuse", 38: "Compulsive conclusion phrases", 39: "Generic positive conclusions",
    40: "Sentence-length monotony", 41: "Mechanical sentence-length alternation", 42: "Opener repetition",
    44: "Uniform paragraph length", 46: "Semicolon and parenthesis underuse", 47: "Chatbot artifacts",
    48: "Sycophantic tone", 50: "Knowledge-cutoff disclaimer", 51: "Copula avoidance", 54: "Excessive hedging",
    55: "Contraction absence", 56: "Boldface overuse", 57: "Emojis", 58: "Em-dash overuse", 59: "Title case in headings",
    60: "Curly quotation marks", 61: "Hyphen for en dash in ranges", 62: "Invisible / zero-width characters",
    63: "Placeholder text", 64: "Chatbot reference-markup leak", 65: "AI tracking parameters",
    66: "Homoglyph / mixed-script confusables", 67: "Non-standard spaces", 68: "Trailing / stray whitespace",
    69: "Canonical marketing-slop phrases", 70: "Decorative horizontal rules", 71: "Degenerate repetition",
}
SLUGS = {k: re.sub(r"[^a-z0-9]+", "_", v.lower()).strip("_") for k, v in LABELS.items() if isinstance(k, int)}
SLUGS["17p"] = "negative_parallelism"
SLUGS["17t"] = "tailing_negation"
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, "17p"}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 41, 44, 55}
BASE = {62: 20, 63: 20, 64: 20, 65: 20, 66: 20, 13: 18, 47: 18, 50: 18, 48: 16, 40: 8, 44: 6, 56: 4, 57: 5,
        59: 4, 70: 6, 71: 12, 35: 6, 34: 6, 33: 6, 51: 6, 6: 6, 8: 6, 16: 8, 32: 8, 37: 8, 38: 8, 11: 8, 18: 10}
SHORT_FLOOR_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}


def fnum(k):
    return 17 if k in ("17p", "17t") else k


def collapse(s, n=80):
    s = s.replace("\n", " ")
    if len(s) > n:
        s = s[:n].rstrip() + "..."
    return s


def split_paragraphs(text):
    return [p for p in re.split(r"\n[ \t]*\n", text) if p.strip()]


RE_SENT_SPLIT = re.compile(r"(?<=[.!?])[\"'”’)\]]*\s+")
RE_LISTLINE = re.compile(r"^[ \t]*(?:[-*+]|\d+[.)])[ \t]+")


def para_sentences(par):
    """Sentences of a prose paragraph; headings, list items, rules dropped."""
    keep = []
    for ln in par.split("\n"):
        if re.match(r"^[ \t]{0,3}#{1,6}[ \t]", ln) or RE_HR.match(ln):
            continue
        keep.append(RE_LISTLINE.sub("", ln).strip())
    joined = " ".join(x for x in keep if x)
    out = []
    for s in RE_SENT_SPLIT.split(joined):
        s = s.strip()
        if s and RE_WORD.search(s) and re.search(r"[^\W_]", s):
            out.append(s)
    return out


def wcount(s):
    return sum(1 for w in RE_WORD.findall(s) if re.search(r"[^\W_]", w))


def cv(xs):
    m = sum(xs) / len(xs)
    if m == 0:
        return 9.9
    var = sum((x - m) ** 2 for x in xs) / len(xs)
    return math.sqrt(var) / m


def analyze(win):
    """win: window text (CRLF normalised). Returns (findings, metrics-dict)."""
    masked = mask_markdown(win)
    F = {}

    def add(key, spans, texts=None, excerpt=False, count=None):
        n = count if count is not None else len(spans)
        if n <= 0:
            return
        samples = []
        if excerpt:
            for s, e in spans[:3]:
                a = max(0, s - 30)
                b = min(len(win), e + 30)
                t = win[a:b].replace("\n", " ")
                samples.append(("..." if a > 0 else "") + t + ("..." if b < len(win) else ""))
        elif texts is not None:
            samples = [collapse(t) for t in texts[:3]]
        else:
            samples = [collapse(win[s:e]) for s, e in spans[:3]]
        F[key] = {"label": LABELS[key], "count": int(n), "samples": samples}

    def rx_add(key, regex, **kw):
        spans = [m.span() for m in regex.finditer(masked)]
        add(key, spans, **kw)

    paras = split_paragraphs(masked)
    wl = [w for w in RE_WORD.findall(masked) if re.search(r"[^\W_]", w)]
    nwords = len(wl)
    sent_by_par = [para_sentences(p) for p in paras]
    sents = [s for ss in sent_by_par for s in ss]

    # --- lexical families
    spans = [m.span() for m in RE_AI.finditer(masked)]
    add(1, spans, excerpt=True)
    spans = [m.span() for m in RE_DIALECT.finditer(masked)]
    if len(spans) >= 2:
        add(2, spans)
    spans = [m.span() for m in RE_PROMO.finditer(masked)]
    imp = sum(1 for ss in sent_by_par for s in ss if re.match(r"(?:" + "|".join(IMPERATIVES) + r")\b", s, re.I))
    texts = [masked[a:b] for a, b in spans]
    if imp >= 3:
        texts.append("%d sentences open with a marketing imperative" % imp)
    n3 = len(spans) + (imp if imp >= 3 else 0)
    if n3:
        add(3, [], texts=texts, count=n3)
    rx_add(4, RE_HYPH)
    rx_add(5, RE_SIMPLEYET)
    # 6 stacked adjective chains
    chains = []
    for m in re.finditer(r"\b[A-Za-z][A-Za-z-]*(?:,\s+(?:and\s+)?[A-Za-z][A-Za-z-]*){3,}|\b[A-Za-z][A-Za-z-]*(?:,\s+[A-Za-z][A-Za-z-]*){2,},?\s+and\s+[A-Za-z][A-Za-z-]*", masked):
        ws = re.findall(r"[A-Za-z-]+", m.group())
        ws = [w for w in ws if w.lower() != "and"]
        if len(ws) < 4:
            continue
        lw = [w.lower() for w in ws]
        adj = any(w in STOCK_ADJ or RE_ADJ.search(w) for w in lw)
        last = lw[-1]
        if adj and not (last in STOCK_ADJ or RE_ADJ.search(last)):
            chains.append(m.span())
    add(6, chains)
    # 8 synonym cycling
    hits8 = []
    for res in SYN_RES:
        present = [r for r in res if r.search(masked)]
        if len(present) >= 3:
            ms = [r.search(masked) for r in present]
            hits8.append(" / ".join(m.group().lower() for m in ms))
    if hits8:
        add(8, [], texts=hits8, count=len(hits8))
    rx_add(10, RE_SIGNIF)
    rx_add(11, RE_NOTABLE)
    rx_add(12, RE_VAGUE)
    rx_add(13, RE_TITLE)
    rx_add(14, RE_ECO)
    rx_add(15, RE_FALSERANGE)
    rx_add(16, RE_ING)
    pa = [m.span() for r in (RE_PAR1, RE_PAR2, RE_PAR3) for m in r.finditer(masked)]
    add("17p", sorted(pa))
    rx_add("17t", RE_TAILNEG)
    rx_add(18, RE_NOTX)
    rx_add(19, RE_FILLER)
    rx_add(20, RE_PIVOT)
    rx_add(21, RE_OUTCOME)
    rx_add(22, RE_AUTH)
    rx_add(23, RE_EDIT)
    rx_add(24, RE_THOROUGH)
    rx_add(25, RE_QA)
    rx_add(26, RE_CONCRETE)
    rx_add(27, RE_HOOK)
    rx_add(30, RE_DIFF)
    rx_add(31, RE_SIGNPOST)
    rx_add(32, RE_CATALOG)
    rx_add(33, RE_BOLDHEAD)
    # 34 bullet injection
    if not RE_HEADING.search(masked):
        listp = 0
        prosep = 0
        for p in paras:
            lines = [l for l in p.split("\n") if l.strip()]
            if lines and all(RE_LISTLINE.match(l) for l in lines):
                listp += 1
            elif not any(RE_LISTLINE.match(l) for l in lines) and not p.strip().startswith("|"):
                prosep += 1
        if listp >= 1 and prosep >= 2:
            add(34, [], texts=["bulleted paragraph amid prose"], count=listp)
    # 35 fragmented headers
    h35 = []
    mlines = masked.split("\n")
    for i, ln in enumerate(mlines):
        m = re.match(r"^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t#]*$", ln)
        if not m:
            continue
        j = i + 1
        while j < len(mlines) and not mlines[j].strip():
            j += 1
        if j >= len(mlines):
            continue
        nx = mlines[j].strip()
        if re.match(r"^#{1,6}\s", nx) or RE_LISTLINE.match(nx) or nx.startswith("|") or RE_HR.match(nx):
            continue
        nw = re.findall(r"[A-Za-z0-9']+", nx)
        if 0 < len(nw) <= 4 and not re.search(r"[.!?]\s+\S", nx):
            hw = {w.lower() for w in re.findall(r"[A-Za-z0-9']+", m.group(1)) if len(w) > 2}
            if any(w.lower() in hw for w in nw if len(w) > 2):
                h35.append(m.group(1) + " / " + nx)
    if h35:
        add(35, [], texts=h35, count=len(h35))
    rx_add(36, RE_CHALL)
    # 37 transitions
    n37 = 0
    for p in paras:
        c = len(RE_TRANS.findall(p))
        if c >= 2:
            n37 += c
    if n37:
        sp = [m.span() for m in RE_TRANS.finditer(masked)]
        add(37, [], texts=[masked[a:b].strip() for a, b in sp], count=n37)
    rx_add(38, RE_CONCL)
    rx_add(39, RE_POSCONC)
    # 40 monotony
    if len(sents) >= 3:
        lens = [wcount(s) for s in sents]
        c = cv(lens)
        if c < 0.35:
            add(40, [], texts=["coefficient of variation %.2f over %d sentences" % (c, len(sents))], count=1)
        # 41 alternation
        run = 1
        best = []
        cur_start = 0
        for i in range(1, len(lens) - 1 + 1):
            pass
        diffs = [lens[i + 1] - lens[i] for i in range(len(lens) - 1)]
        i = 0
        n41 = 0
        while i < len(diffs):
            j = i
            while j + 1 < len(diffs) and diffs[j] * diffs[j + 1] < 0 and abs(diffs[j]) >= 6 and abs(diffs[j + 1]) >= 6:
                j += 1
            if abs(diffs[i]) >= 6 and (j - i + 2) >= 6 and diffs[j] != 0:
                n41 += 1
                i = j + 1
            else:
                i += 1
        if n41:
            add(41, [], texts=["lengths alternate up and down"], count=n41)
    # 42 opener repetition
    n42 = 0
    t42 = []
    for ss in sent_by_par:
        if len(ss) >= 3:
            from collections import Counter
            c = Counter(" ".join(s.lower().split()[:2]) for s in ss if len(s.split()) >= 2)
            for k, v in c.items():
                if v >= 3:
                    n42 += 1
                    t42.append(k)
    if n42:
        add(42, [], texts=t42, count=n42)
    # 44 uniform paragraph length
    pw = [wcount(p) for p in paras]
    pw = [x for x in pw if x > 0]
    if len(pw) >= 4 and cv(pw) < 0.4:
        add(44, [], texts=["%d paragraphs of near-equal length" % len(pw)], count=1)
    # 46
    if nwords >= 300 and ";" not in masked and len(re.findall(r"\([^)\n]{1,200}\)", masked)) <= 1:
        add(46, [], texts=["no semicolons, almost no parentheticals"], count=1)
    rx_add(47, RE_CHATBOT)
    rx_add(48, RE_SYCO)
    rx_add(50, RE_CUTOFF)
    rx_add(51, RE_COPULA)
    # 54 hedge stacking
    n54 = 0
    t54 = []
    for s in sents:
        hs = RE_HEDGE_WORDS.findall(s)
        if len(hs) >= 2:
            n54 += 1
            t54.append(s)
    if n54:
        add(54, [], texts=t54, count=n54)
    # 55 contraction absence
    fp = len(RE_FIRSTP.findall(masked))
    if nwords and fp >= 3 and fp / nwords >= 0.02:
        full = len(RE_CONTRACTIBLE.findall(masked))
        con = len(RE_CONTRACTED.findall(masked))
        if full >= 3 and full > 2 * con:
            add(55, [], texts=["%d contractible forms written out" % full], count=full)
    rx_add(56, RE_BOLD)
    rx_add(57, RE_EMOJI)
    # 58 em dash
    n58 = sum(1 for p in paras if p.count("—") >= 2)
    if n58:
        add(58, [], texts=["two or more em dashes in a paragraph"], count=n58)
    # 59 title case headings
    SMALL = set("a an the and but or nor for so yet of in on at to by up as is via per vs with from into over than off out".split())
    h59 = []
    for m in RE_HEADING.finditer(masked):
        h = m.group(1).strip()
        ws = re.findall(r"[^\s]+", h)
        if len(ws) < 3 or not h[0].isalpha() or h.upper() == h:
            continue
        major = [w for w in ws if w.lower().strip(".,:;!?") not in SMALL]
        if len(major) >= 2 and all(w.lstrip("([\"'")[:1].isupper() for w in major if w.lstrip("([\"'")[:1].isalpha()) \
                and all(w.lstrip("([\"'")[:1].isalpha() for w in major):
            h59.append(h)
    if h59:
        add(59, [], texts=h59, count=len(h59))
    rx_add(60, RE_CURLY)
    spans = [m.span() for m in RE_YEARS.finditer(masked) if int(m.group(2)) > int(m.group(1))]
    add(61, spans)
    # character layer (raw window)
    inv, sp, hg = char_layer(win)
    if inv:
        add(62, [], texts=["U+%04X" % ord(win[i]) for i in inv[:3]], count=len(inv))
    # 63 placeholders
    ph = []
    for m in PH_NAME.finditer(masked):
        nxt = masked[m.end():m.end() + 1]
        if nxt not in ("(", "["):
            ph.append(m.span())
    for m in PH_CAPS.finditer(masked):
        inner = m.group()[1:-1]
        nxt = masked[m.end():m.end() + 1]
        if nxt in ("(", "[") or PH_SHORT.match(inner.strip()):
            continue
        ph.append(m.span())
    for r in (PH_BRACE, PH_X, PH_LOREM):
        ph.extend(m.span() for m in r.finditer(masked))
    add(63, sorted(set(ph)))
    rx_add(64, RE_CHATREF)
    ut = []
    for m in RE_UTM.finditer(masked):
        host = m.group(1).rstrip(".").lower()
        if host in UTM_HOSTS:
            ut.append(m.span())
    add(65, ut)
    if hg:
        toks = [win[a:b] for a, b in homoglyph_runs(win)]
        add(66, [], texts=toks, count=hg)
    if sp:
        add(67, [], texts=["U+%04X" % ord(win[i]) for i in sp[:3]], count=len(sp))
    # 68 trailing whitespace
    n68 = len(re.findall(r"[ \t]+(?=\n)", win))
    if len(win) <= WINDOW and win:
        if re.search(r"[ \t]\Z", win):
            n68 += 1
        if re.search(r"\n\n+\Z", win) or re.search(r"\n[ \t\n]*\n\Z", win):
            n68 += 1
    if win and win[0].isspace():
        n68 += 1
    if n68:
        add(68, [], texts=["stray whitespace"], count=n68)
    rx_add(69, RE_SLOP)
    # 70 horizontal rules
    hr = [m.span() for m in RE_HR.finditer(masked)]
    if len(hr) >= 3 and masked.count("\n") + 1 >= 24:
        add(70, hr)
    # 71 degenerate repetition
    lw = [w.lower() for w in wl]
    if len(lw) >= 12:
        grams = [tuple(lw[i:i + 6]) for i in range(len(lw) - 5)]
        from collections import Counter
        cnt = Counter(grams)
        rep = sum(1 for g in grams if cnt[g] > 1)
        if rep and rep / len(grams) >= 0.2:
            top = [" ".join(g) for g, v in cnt.most_common(3) if v > 1]
            add(71, [], texts=top, count=rep)
    return F, nwords, len(sents)


def score_of(F, nwords):
    moving = {k: v for k, v in F.items() if k not in ADVICE}
    fams = {fnum(k) for k in moving}
    total = 0
    for k, v in moving.items():
        base = BASE.get(k, 10)
        total += min(max(25, base), base + 3 * (v["count"] - 1))
    total = min(total, 100)
    if nwords < 40:
        conf = "none"
    elif nwords < 120:
        conf = "low"
    elif nwords < 300:
        conf = "low" if len(fams) <= 1 else "moderate"
    else:
        conf = "high"
    if len(fams) == 1:
        total = min(total, 40)
    if fams and fams <= RHYTHM:
        total = min(total, 40)
    if fams == {40}:
        total = min(total, 20)
    dec = {k for k in moving if k in DECISIVE}
    if len(dec) >= 2:
        total = max(total, 65)
    elif len(dec) == 1 and conf not in ("none", "low"):
        total = max(total, 45)
    nf = len(fams)
    if nwords < 120:
        c = len({f for f in fams if f in SHORT_FLOOR_SET})
        if c >= 3:
            total = max(total, 45)
        elif c >= 2:
            total = max(total, 25)
    if nwords >= 400:
        if nf >= 6:
            total = max(total, 45)
        elif nf >= 5:
            total = max(total, 25)
    total = int(max(0, min(100, total)))
    return total, conf, len(F)


def conf_reason(conf, nwords, nfams):
    if conf == "none":
        return "only %d words; too short for a meaningful score" % nwords
    if conf == "low":
        if nwords < 120:
            return "short text (%d words); the score is a rough indication only" % nwords
        return "only one pattern family fired in a text under 300 words"
    if conf == "moderate":
        return "text is under 300 words; more text would firm up the score"
    return ""


def build_report(text, ci=False):
    truncated = len(text) > WINDOW
    win = text[:WINDOW]
    win = win.replace("\r\n", "\n")
    F, nwords, nsent = analyze(win)
    score, conf, nflag = score_of(F, nwords)
    fams = {fnum(k) for k in F if k not in ADVICE}
    inv, sp, hg = char_layer(win)
    report = {}
    for k, v in F.items():
        report["%s_%s" % (fnum(k), SLUGS[k])] = v
    m = {
        "scanned_chars": min(len(text), WINDOW),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": conf_reason(conf, nwords, len(fams)),
        "patterns_flagged": len(F),
        "invisible_chars": len(inv),
        "nonstandard_spaces": len(sp),
        "homoglyphs": hg,
        "word_count": nwords,
    }
    if ci:
        if nsent >= 4:
            lo, hi = resample_ci(win, score)
            m["score_ci"] = [lo, hi]
            m["score_ci_note"] = "resampled over sentences (seeded); 5th-95th percentile"
        else:
            m["score_ci"] = None
            m["score_ci_note"] = "too few sentences (fewer than 4) for an interval"
    report["_metrics"] = m
    return report


def resample_ci(win, score):
    masked = mask_markdown(win)
    sents = [s for p in split_paragraphs(masked) for s in para_sentences(p)]
    rnd = random.Random(20240601)
    n = len(sents)
    reps = 40 if len(win) < 40000 else 10
    vals = []
    for _ in range(reps):
        pick = [sents[rnd.randrange(n)] for _ in range(n)]
        t = " ".join(pick)
        F, nw, _ = analyze(t)
        vals.append(score_of(F, nw)[0])
    vals.sort()
    lo = vals[int(0.05 * (len(vals) - 1))]
    hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
    lo = min(lo, score)
    hi = max(hi, score)
    return int(lo), int(hi)


# --------------------------------------------------------------------- main
def err(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        i += 1
        if stop:
            operands.append(a)
        elif a == "--":
            stop = True
        elif a in ("--help", "-h"):
            sys.stdout.buffer.write(USAGE_FULL.encode("utf-8"))
            sys.stdout.flush()
            return 0
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-"):
            return err("unknown option: %s (see --help)" % a, 2)
        else:
            operands.append(a)
    path = None
    try:
        if operands:
            path = operands[0]
            if len(operands) > 1:
                sys.stderr.write("note: %d files given; only the first file was scanned: %s\n" % (len(operands), path))
            try:
                with open(path, "rb") as f:
                    raw = f.read()
            except (OSError, IOError) as e:
                raise Fail("cannot read input: %s" % (e.strerror or str(e)))
            text = extract(path, raw)
        else:
            raw = sys.stdin.buffer.read()
            text = decode_bytes(raw)
        if not text.strip():
            raise Fail("empty input")
        if clean:
            out = cleanup(text)
            sys.stdout.buffer.write(out.encode("utf-8", "replace"))
            sys.stdout.flush()
            return 0
        report = build_report(text, ci)
        sys.stdout.buffer.write((json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8", "replace"))
        sys.stdout.flush()
        return 0
    except Fail as e:
        return err(e.msg, e.code)
    except RecursionError:
        return err("cannot read input: nesting too deep", 1)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
