#!/usr/bin/env node
'use strict';
// Subagent-start hook: same contract inside the SubagentStart envelope. Always exits 0.
const lib = require('./lib');
try {
  lib.readStdinJson();
  const level = lib.currentLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractFor(level) },
    }));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
